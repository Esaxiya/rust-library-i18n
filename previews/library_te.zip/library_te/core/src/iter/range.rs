use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// *వారసుడు* మరియు *ముందున్న* కార్యకలాపాల భావన ఉన్న వస్తువులు.
///
/// *వారసుడు* ఆపరేషన్ ఎక్కువ పోల్చిన విలువల వైపు కదులుతుంది.
/// *మునుపటి* ఆపరేషన్ తక్కువ పోల్చిన విలువల వైపు కదులుతుంది.
///
/// # Safety
///
/// ఈ trait `unsafe` ఎందుకంటే `unsafe trait TrustedLen` అమలుల భద్రత కోసం దాని అమలు ఖచ్చితంగా ఉండాలి, మరియు ఈ trait ను ఉపయోగించడం యొక్క ఫలితాలు `unsafe` కోడ్ ద్వారా విశ్వసించబడతాయి మరియు సరైనవి మరియు జాబితా చేయబడిన బాధ్యతలను నెరవేరుస్తాయి.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// `start` నుండి `end` వరకు పొందడానికి అవసరమైన *వారసుడు* దశల సంఖ్యను చూపుతుంది.
    ///
    /// దశల సంఖ్య `usize` ని పొంగిపోతుంటే `None` ని అందిస్తుంది (లేదా అనంతం, లేదా `end` ఎప్పటికీ చేరుకోకపోతే).
    ///
    ///
    /// # Invariants
    ///
    /// ఏదైనా `a`, `b` మరియు `n` కోసం:
    ///
    /// * `steps_between(&a, &b) == Some(n)` ఉంటే మరియు `Step::forward_checked(&a, n) == Some(b)` ఉంటే మాత్రమే
    /// * `steps_between(&a, &b) == Some(n)` ఉంటే మరియు `Step::backward_checked(&a, n) == Some(a)` ఉంటే మాత్రమే
    /// * `steps_between(&a, &b) == Some(n)` `a <= b` ఉంటే మాత్రమే
    ///   * పరస్పర సంబంధం: `steps_between(&a, &b) == Some(0)` ఉంటే మరియు `a == b` ఉంటే మాత్రమే
    ///   * `a <= b` _not_ `steps_between(&a, &b) != None` ను సూచిస్తుందని గమనించండి;
    ///     `b` కి వెళ్ళడానికి `usize::MAX` కంటే ఎక్కువ దశలు అవసరమయ్యే సందర్భం ఇది
    /// * `steps_between(&a, &b) == None` `a > b` ఉంటే
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// `self` `count` సార్లు * వారసుడిని తీసుకోవడం ద్వారా పొందగలిగే విలువను చూపుతుంది.
    ///
    /// ఇది `Self` చేత మద్దతిచ్చే విలువల పరిధిని పొంగిపోతే, `None` ను అందిస్తుంది.
    ///
    /// # Invariants
    ///
    /// ఏదైనా `a`, `n` మరియు `m` కోసం:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// `n + m` పొంగి ప్రవహించని `a`, `n` మరియు `m` కోసం:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// ఏదైనా `a` మరియు `n` కోసం:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// `self` `count` సార్లు * వారసుడిని తీసుకోవడం ద్వారా పొందగలిగే విలువను చూపుతుంది.
    ///
    /// ఇది `Self` చేత మద్దతిచ్చే విలువల పరిధిని పొంగిపోతే, ఈ ఫంక్షన్ panic, ర్యాప్ లేదా సంతృప్తతకు అనుమతించబడుతుంది.
    ///
    /// డీబగ్ వాదనలు ప్రారంభించినప్పుడు panic కు సూచించబడిన ప్రవర్తన, లేకపోతే చుట్టడం లేదా సంతృప్తపరచడం.
    ///
    /// అసురక్షిత కోడ్ ఓవర్ఫ్లో తర్వాత ప్రవర్తన యొక్క సరైనదానిపై ఆధారపడకూడదు.
    ///
    /// # Invariants
    ///
    /// ఏదైనా `a`, `n` మరియు `m` కోసం, ఓవర్ఫ్లో జరగని చోట:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// ఏదైనా `a` మరియు `n` కోసం, ఓవర్ఫ్లో జరగని చోట:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// `self` `count` సార్లు * వారసుడిని తీసుకోవడం ద్వారా పొందగలిగే విలువను చూపుతుంది.
    ///
    /// # Safety
    ///
    /// ఈ ఆపరేషన్ `Self` చేత మద్దతిచ్చే విలువల పరిధిని పొంగిపోవటం నిర్వచించబడని ప్రవర్తన.
    /// ఇది పొంగిపోదని మీరు హామీ ఇవ్వలేకపోతే, బదులుగా `forward` లేదా `forward_checked` ఉపయోగించండి.
    ///
    /// # Invariants
    ///
    /// ఏదైనా `a` కోసం:
    ///
    /// * `b > a` వంటి `b` ఉంటే, `Step::forward_unchecked(a, 1)` కి కాల్ చేయడం సురక్షితం
    /// * `steps_between(&a, &b) == Some(n)`, `n` వంటి `b` ఉంటే, ఏదైనా `m <= n` కోసం `Step::forward_unchecked(a, m)` కి కాల్ చేయడం సురక్షితం.
    ///
    ///
    /// ఏదైనా `a` మరియు `n` కోసం, ఓవర్ఫ్లో జరగని చోట:
    ///
    /// * `Step::forward_unchecked(a, n)` `Step::forward(a, n)` కు సమానం
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// `self` `count` సార్లు *పూర్వీకుడు* తీసుకోవడం ద్వారా పొందగలిగే విలువను అందిస్తుంది.
    ///
    /// ఇది `Self` చేత మద్దతిచ్చే విలువల పరిధిని పొంగిపోతే, `None` ను అందిస్తుంది.
    ///
    /// # Invariants
    ///
    /// ఏదైనా `a`, `n` మరియు `m` కోసం:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// ఏదైనా `a` మరియు `n` కోసం:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// `self` `count` సార్లు *పూర్వీకుడు* తీసుకోవడం ద్వారా పొందగలిగే విలువను అందిస్తుంది.
    ///
    /// ఇది `Self` చేత మద్దతిచ్చే విలువల పరిధిని పొంగిపోతే, ఈ ఫంక్షన్ panic, ర్యాప్ లేదా సంతృప్తతకు అనుమతించబడుతుంది.
    ///
    /// డీబగ్ వాదనలు ప్రారంభించినప్పుడు panic కు సూచించబడిన ప్రవర్తన, లేకపోతే చుట్టడం లేదా సంతృప్తపరచడం.
    ///
    /// అసురక్షిత కోడ్ ఓవర్ఫ్లో తర్వాత ప్రవర్తన యొక్క సరైనదానిపై ఆధారపడకూడదు.
    ///
    /// # Invariants
    ///
    /// ఏదైనా `a`, `n` మరియు `m` కోసం, ఓవర్ఫ్లో జరగని చోట:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// ఏదైనా `a` మరియు `n` కోసం, ఓవర్ఫ్లో జరగని చోట:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// `self` `count` సార్లు *పూర్వీకుడు* తీసుకోవడం ద్వారా పొందగలిగే విలువను అందిస్తుంది.
    ///
    /// # Safety
    ///
    /// ఈ ఆపరేషన్ `Self` చేత మద్దతిచ్చే విలువల పరిధిని పొంగిపోవటం నిర్వచించబడని ప్రవర్తన.
    /// ఇది పొంగిపోదని మీరు హామీ ఇవ్వలేకపోతే, బదులుగా `backward` లేదా `backward_checked` ఉపయోగించండి.
    ///
    /// # Invariants
    ///
    /// ఏదైనా `a` కోసం:
    ///
    /// * `b < a` వంటి `b` ఉంటే, `Step::backward_unchecked(a, 1)` కి కాల్ చేయడం సురక్షితం
    /// * `steps_between(&b, &a) == Some(n)`, `n` వంటి `b` ఉంటే, ఏదైనా `m <= n` కోసం `Step::backward_unchecked(a, m)` కి కాల్ చేయడం సురక్షితం.
    ///
    ///
    /// ఏదైనా `a` మరియు `n` కోసం, ఓవర్ఫ్లో జరగని చోట:
    ///
    /// * `Step::backward_unchecked(a, n)` `Step::backward(a, n)` కు సమానం
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// పూర్ణాంక అక్షరాస్యులు వివిధ రకాలుగా పరిష్కరిస్తున్నందున ఇవి ఇప్పటికీ స్థూల-ఉత్పత్తి.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // భద్రత: `start + n` పొంగిపోదని కాలర్ హామీ ఇవ్వాలి.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // భద్రత: `start - n` పొంగిపోదని కాలర్ హామీ ఇవ్వాలి.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // డీబగ్ బిల్డ్స్‌లో, ఓవర్‌ఫ్లో panic ను ప్రారంభించండి.
            // విడుదల నిర్మాణాలలో ఇది పూర్తిగా ఆప్టిమైజ్ చేయాలి.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // ఉదా. అనుమతించడానికి గణితాన్ని చుట్టడం చేయండి `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // డీబగ్ బిల్డ్స్‌లో, ఓవర్‌ఫ్లో panic ను ప్రారంభించండి.
            // విడుదల నిర్మాణాలలో ఇది పూర్తిగా ఆప్టిమైజ్ చేయాలి.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // ఉదా. అనుమతించడానికి గణితాన్ని చుట్టడం చేయండి `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // ఇది $u_narrower <=usize పై ఆధారపడుతుంది
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // n పరిధిలో లేకపోతే, `unsigned_start + n` చాలా ఉంది
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // n పరిధిలో లేకపోతే, `unsigned_start - n` చాలా ఉంది
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // ఇది $i_narrower <=usize పై ఆధారపడుతుంది
                        //
                        // ఐసైజ్ చేయడానికి ప్రసారం వెడల్పును విస్తరిస్తుంది కాని గుర్తును సంరక్షిస్తుంది.
                        // ఐసైజ్ స్థలంలో చుట్టడం_సబ్ ఉపయోగించండి మరియు ఐసైజ్ పరిధిలో సరిపోని వ్యత్యాసాన్ని లెక్కించడానికి వినియోగించుకోండి.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // i8 కోసం 200 పరిధిలో లేనప్పటికీ, చుట్టడం `Step::forward(-120_i8, 200) == Some(80_i8)` వంటి కేసులను నిర్వహిస్తుంది.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // చేరిక పొంగిపోయింది
                            }
                        }
                        // N ఉదా పరిధికి మించి ఉంటే
                        // u8, i8 యొక్క మొత్తం పరిధి కంటే ఇది పెద్దది కాబట్టి `any_i8 + n` తప్పనిసరిగా i8 ని పొంగిపోతుంది.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // i8 కోసం 200 పరిధిలో లేనప్పటికీ, చుట్టడం `Step::forward(-120_i8, 200) == Some(80_i8)` వంటి కేసులను నిర్వహిస్తుంది.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // వ్యవకలనం పొంగిపొర్లుతుంది
                            }
                        }
                        // N ఉదా పరిధికి మించి ఉంటే
                        // u8, i8 యొక్క మొత్తం పరిధి కంటే ఇది పెద్దది కాబట్టి `any_i8 - n` తప్పనిసరిగా i8 ని పొంగిపోతుంది.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // వ్యత్యాసం ఉదా
                            // i128, ఇది తక్కువ బిట్‌లతో ఉపయోగించడం చాలా పెద్దదిగా ఉంటుంది.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // భద్రత: res అనేది చెల్లుబాటు అయ్యే యూనికోడ్ స్కేలార్
            // (0x110000 క్రింద మరియు 0xD800..0xE000 లో కాదు)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // భద్రత: res అనేది చెల్లుబాటు అయ్యే యూనికోడ్ స్కేలార్
        // (0x110000 క్రింద మరియు 0xD800..0xE000 లో కాదు)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // భద్రత: కాలర్ ఇది పొంగిపోదని హామీ ఇవ్వాలి
        // చార్ కోసం విలువల పరిధి.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // భద్రత: కాలర్ ఇది పొంగిపోదని హామీ ఇవ్వాలి
            // చార్ కోసం విలువల పరిధి.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // భద్రత: మునుపటి ఒప్పందం కారణంగా, ఇది హామీ ఇవ్వబడుతుంది
        // కాలర్ ద్వారా చెల్లుబాటు అయ్యే చార్.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // భద్రత: కాలర్ ఇది పొంగిపోదని హామీ ఇవ్వాలి
        // చార్ కోసం విలువల పరిధి.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // భద్రత: కాలర్ ఇది పొంగిపోదని హామీ ఇవ్వాలి
            // చార్ కోసం విలువల పరిధి.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // భద్రత: మునుపటి ఒప్పందం కారణంగా, ఇది హామీ ఇవ్వబడుతుంది
        // కాలర్ ద్వారా చెల్లుబాటు అయ్యే చార్.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // భద్రత: ముందస్తు షరతును తనిఖీ చేసింది
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // భద్రత: ముందస్తు షరతును తనిఖీ చేసింది
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// ఈ మాక్రోలు వివిధ శ్రేణి రకాల కోసం `ExactSizeIterator` ఇంప్ల్స్‌ను ఉత్పత్తి చేస్తాయి.
//
// * `ExactSizeIterator::len` ఎల్లప్పుడూ ఖచ్చితమైన `usize` ను తిరిగి ఇవ్వడానికి అవసరం, కాబట్టి ఏ పరిధి `usize::MAX` కన్నా ఎక్కువ ఉండకూడదు.
//
// * `Range<_>` లోని పూర్ణాంక రకాలు కోసం, `usize` కన్నా ఇరుకైన లేదా వెడల్పు ఉన్న రకాల్లో ఇది ఉంటుంది.
//   `RangeInclusive<_>` లోని పూర్ణాంక రకాలు కోసం, ఉదా నుండి `usize` కన్నా *ఖచ్చితంగా ఇరుకైన* రకాలు
//   `(0..=u64::MAX).len()` `u64::MAX + 1` అవుతుంది.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // పైన పేర్కొన్న తార్కికం ప్రకారం ఇవి అసంబద్ధం, కానీ అవి Rust 1.0.0 లో స్థిరీకరించబడినందున వాటిని తొలగించడం విచ్ఛిన్నమైన మార్పు అవుతుంది.
    // కాబట్టి ఉదా
    // `(0..66_000_u32).len()` ఉదాహరణకు 16-బిట్ ప్లాట్‌ఫామ్‌లపై లోపం లేదా హెచ్చరికలు లేకుండా కంపైల్ చేస్తుంది, కానీ తప్పు ఫలితాన్ని ఇవ్వడం కొనసాగిస్తుంది.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // పైన పేర్కొన్న తార్కికం ప్రకారం ఇవి అసంబద్ధం, కానీ అవి Rust 1.26.0 లో స్థిరీకరించబడినందున వాటిని తొలగించడం విచ్ఛిన్నమైన మార్పు అవుతుంది.
    // కాబట్టి ఉదా
    // `(0..=u16::MAX).len()` ఉదాహరణకు 16-బిట్ ప్లాట్‌ఫామ్‌లపై లోపం లేదా హెచ్చరికలు లేకుండా కంపైల్ చేస్తుంది, కానీ తప్పు ఫలితాన్ని ఇవ్వడం కొనసాగిస్తుంది.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // భద్రత: ముందస్తు షరతును తనిఖీ చేసింది
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // భద్రత: ముందస్తు షరతును తనిఖీ చేసింది
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // భద్రత: ముందస్తు షరతును తనిఖీ చేసింది
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // భద్రత: ముందస్తు షరతును తనిఖీ చేసింది
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // భద్రత: ముందస్తు షరతును తనిఖీ చేసింది
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // భద్రత: ముందస్తు షరతును తనిఖీ చేసింది
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}