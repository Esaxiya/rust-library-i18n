//! కంపోజిబుల్ బాహ్య పునరావృతం.
//!
//! మీరు ఒక రకమైన సేకరణతో మిమ్మల్ని కనుగొని, మరియు చెప్పిన సేకరణ యొక్క అంశాలపై ఆపరేషన్ చేయాల్సిన అవసరం ఉంటే, మీరు త్వరగా 'iterators' లోకి ప్రవేశిస్తారు.
//! ఇడియొమాటిక్ Rust కోడ్‌లో ఇటరేటర్లను ఎక్కువగా ఉపయోగిస్తున్నారు, కాబట్టి వారితో పరిచయం పెంచుకోవడం విలువ.
//!
//! మరింత వివరించే ముందు, ఈ మాడ్యూల్ ఎలా నిర్మించబడిందనే దాని గురించి మాట్లాడుదాం:
//!
//! # Organization
//!
//! ఈ మాడ్యూల్ ఎక్కువగా రకం ద్వారా నిర్వహించబడుతుంది:
//!
//! * [Traits] ప్రధాన భాగం: ఈ traits ఎలాంటి ఇటరేటర్లు ఉన్నాయో మరియు మీరు వారితో ఏమి చేయవచ్చో నిర్వచించాయి.ఈ traits యొక్క పద్ధతులు కొంత అదనపు అధ్యయన సమయాన్ని ఉంచడం విలువ.
//! * [Functions] కొన్ని ప్రాథమిక ఇటరేటర్లను సృష్టించడానికి కొన్ని ఉపయోగకరమైన మార్గాలను అందించండి.
//! * [Structs] ఈ మాడ్యూల్ యొక్క traits లోని వివిధ పద్ధతుల యొక్క రిటర్న్ రకాలు.మీరు సాధారణంగా `struct` కాకుండా `struct` ను సృష్టించే పద్ధతిని చూడాలనుకుంటున్నారు.
//! ఎందుకు అనే దాని గురించి మరింత వివరాల కోసం, '[అమలు చేసే ఇటిరేటర్](#అమలు-మళ్ళి) చూడండి.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! అంతే!ఇటిరేటర్లలోకి చూద్దాం.
//!
//! # Iterator
//!
//! ఈ మాడ్యూల్ యొక్క గుండె మరియు ఆత్మ [`Iterator`] trait.[`Iterator`] యొక్క కోర్ ఇలా ఉంది:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! ఒక ఇరేటర్‌కు [`next`] అనే పద్ధతి ఉంది, దీనిని పిలిచినప్పుడు, [`ఎంపిక`]`ను అందిస్తుంది<Item>`.
//! [`next`] మూలకాలు ఉన్నంతవరకు [`Some(Item)`] ను తిరిగి ఇస్తుంది, మరియు అవి అన్నీ అయిపోయిన తర్వాత, పునరావృతం పూర్తయిందని సూచించడానికి `None` ను తిరిగి ఇస్తుంది.
//! వ్యక్తిగత పునరావృత్తులు పునరుక్తిని తిరిగి ప్రారంభించడానికి ఎంచుకోవచ్చు, కాబట్టి [`next`] ని మళ్లీ కాల్ చేయడం వల్ల ఏదో ఒక సమయంలో [`Some(Item)`] ను తిరిగి ఇవ్వడం ప్రారంభించకపోవచ్చు లేదా ప్రారంభించకపోవచ్చు (ఉదాహరణకు, [`TryIter`] చూడండి).
//!
//!
//! [`ఇటిరేటర్`] యొక్క పూర్తి నిర్వచనం అనేక ఇతర పద్ధతులను కలిగి ఉంది, కానీ అవి డిఫాల్ట్ పద్ధతులు, ఇవి [`next`] పైన నిర్మించబడ్డాయి, కాబట్టి మీరు వాటిని ఉచితంగా పొందుతారు.
//!
//! ఇటిరేటర్లు కూడా కంపోజబుల్, మరియు ప్రాసెసింగ్ యొక్క మరింత సంక్లిష్టమైన రూపాలను చేయడానికి వాటిని ఒకదానితో ఒకటి గొలుసు చేయడం సాధారణం.మరిన్ని వివరాల కోసం దిగువ [Adapters](#adapters) విభాగాన్ని చూడండి.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # పునరుక్తి యొక్క మూడు రూపాలు
//!
//! సేకరణ నుండి ఇటరేటర్లను సృష్టించగల మూడు సాధారణ పద్ధతులు ఉన్నాయి:
//!
//! * `iter()`, ఇది `&T` కంటే ఎక్కువ మళ్ళిస్తుంది.
//! * `iter_mut()`, ఇది `&mut T` కంటే ఎక్కువ మళ్ళిస్తుంది.
//! * `into_iter()`, ఇది `T` కంటే ఎక్కువ మళ్ళిస్తుంది.
//!
//! ప్రామాణిక లైబ్రరీలోని వివిధ విషయాలు తగిన వాటిలో మూడింటిలో ఒకటి లేదా అంతకంటే ఎక్కువ అమలు చేయవచ్చు.
//!
//! # ఇటిరేటర్‌ను అమలు చేస్తోంది
//!
//! మీ స్వంత ఇరేటర్‌ను సృష్టించడం రెండు దశలను కలిగి ఉంటుంది: ఇరేటర్ యొక్క స్థితిని ఉంచడానికి `struct` ను సృష్టించడం, ఆపై ఆ `struct` కోసం [`Iterator`] ను అమలు చేయడం.
//! అందువల్లనే ఈ మాడ్యూల్‌లో చాలా `స్ట్రక్ట్‌లు 'ఉన్నాయి: ప్రతి ఇరేటర్ మరియు ఇరేటర్ అడాప్టర్‌కు ఒకటి ఉంటుంది.
//!
//! `1` నుండి `5` వరకు లెక్కించే `Counter` అనే ఇటరేటర్‌ను తయారు చేద్దాం:
//!
//! ```
//! // మొదట, struct:
//!
//! /// ఒకటి నుండి ఐదు వరకు లెక్కించే ఇటరేటర్
//! struct Counter {
//!     count: usize,
//! }
//!
//! // మా లెక్కింపు ఒకదానితో ప్రారంభం కావాలని మేము కోరుకుంటున్నాము, కాబట్టి సహాయం చేయడానికి new() పద్ధతిని జోడిద్దాం.
//! // ఇది ఖచ్చితంగా అవసరం లేదు, కానీ సౌకర్యవంతంగా ఉంటుంది.
//! // మేము `count` ను సున్నా వద్ద ప్రారంభిస్తామని గమనించండి, క్రింద `next()`'s అమలులో ఎందుకు చూద్దాం.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // అప్పుడు, మేము మా `Counter` కోసం `Iterator` ను అమలు చేస్తాము:
//!
//! impl Iterator for Counter {
//!     // మేము వినియోగించుకుంటాము
//!     type Item = usize;
//!
//!     // next() అవసరమైన ఏకైక పద్ధతి
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // మా సంఖ్యను పెంచండి.అందుకే మేము సున్నా వద్ద ప్రారంభించాము.
//!         self.count += 1;
//!
//!         // మేము లెక్కింపు పూర్తి చేశామో లేదో తనిఖీ చేయండి.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // ఇప్పుడు మనం దాన్ని ఉపయోగించవచ్చు!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! ఈ విధంగా [`next`] కి కాల్ చేస్తే పునరావృతమవుతుంది.Rust ఒక నిర్మాణాన్ని కలిగి ఉంది, ఇది మీ ఇరేటర్‌లో [`next`] కి కాల్ చేయగలదు, ఇది `None` కి చేరుకునే వరకు.ఆ తరువాత వెళ్దాం.
//!
//! `Iterator` అంతర్గతంగా `next` అని పిలిచే `nth` మరియు `fold` వంటి పద్ధతుల యొక్క డిఫాల్ట్ అమలును అందిస్తుంది.
//! అయినప్పటికీ, `next` కి కాల్ చేయకుండా ఒక ఇరేటర్ వాటిని మరింత సమర్థవంతంగా లెక్కించగలిగితే `nth` మరియు `fold` వంటి పద్ధతుల యొక్క అనుకూల అమలును వ్రాయడం కూడా సాధ్యమే.
//!
//! # `for` ఉచ్చులు మరియు `IntoIterator`
//!
//! Rust యొక్క `for` లూప్ సింటాక్స్ వాస్తవానికి ఇటరేటర్లకు చక్కెర.`for` యొక్క ప్రాథమిక ఉదాహరణ ఇక్కడ ఉంది:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! ఇది ఒకటి నుండి ఐదు వరకు సంఖ్యలను వారి స్వంత పంక్తిలో ముద్రిస్తుంది.కానీ మీరు ఇక్కడ ఏదో గమనించవచ్చు: ఇటరేటర్‌ను ఉత్పత్తి చేయడానికి మేము మా vector లో దేనినీ పిలవలేదు.ఏమి ఇస్తుంది?
//!
//! ఏదో ఒక ఇటరేటర్‌గా మార్చడానికి ప్రామాణిక లైబ్రరీలో trait ఉంది: [`IntoIterator`].
//! ఈ trait ఒక పద్ధతి, [`into_iter`] ను కలిగి ఉంది, ఇది [`IntoIterator`] ను అమలు చేసే విషయాన్ని ఇటరేటర్‌గా మారుస్తుంది.
//! ఆ `for` లూప్‌ను మళ్ళీ పరిశీలిద్దాం, మరియు కంపైలర్ దానిని ఏది మారుస్తుంది:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust దీనిని డి-షుగర్ చేస్తుంది:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! మొదట, మేము విలువపై `into_iter()` అని పిలుస్తాము.అప్పుడు, మేము తిరిగి వచ్చే ఇటెరేటర్‌తో సరిపోలుతాము, మేము `None` ను చూసేవరకు [`next`] ని పదే పదే పిలుస్తాము.
//! ఆ సమయంలో, మేము లూప్ నుండి `break` అవుట్ చేసాము మరియు మేము మళ్ళిస్తున్నాము.
//!
//! ఇక్కడ మరో సూక్ష్మ బిట్ ఉంది: ప్రామాణిక లైబ్రరీలో [`IntoIterator`] యొక్క ఆసక్తికరమైన అమలు ఉంది:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! మరో మాటలో చెప్పాలంటే, అన్ని [`ఇటిరేటర్] లు తమను తాము తిరిగి ఇవ్వడం ద్వారా [`IntoIterator`] ను అమలు చేస్తాయి.దీని అర్థం రెండు విషయాలు:
//!
//! 1. మీరు [`Iterator`] వ్రాస్తుంటే, మీరు దీన్ని `for` లూప్‌తో ఉపయోగించవచ్చు.
//! 2. మీరు సేకరణను సృష్టిస్తుంటే, దాని కోసం [`IntoIterator`] ను అమలు చేయడం వలన మీ సేకరణను `for` లూప్‌తో ఉపయోగించడానికి అనుమతిస్తుంది.
//!
//! # రిఫరెన్స్ ద్వారా మళ్ళించడం
//!
//! [`into_iter()`] విలువ ద్వారా `self` ను తీసుకుంటుంది కాబట్టి, సేకరణపై మళ్ళించడానికి `for` లూప్‌ను ఉపయోగించడం ఆ సేకరణను వినియోగిస్తుంది.తరచుగా, మీరు సేకరణను తినకుండానే మళ్ళించాలనుకోవచ్చు.
//! అనేక సేకరణలు సాంప్రదాయకంగా వరుసగా `iter()` మరియు `iter_mut()` అని పిలువబడే సూచనలపై ఇటరేటర్లను అందించే పద్ధతులను అందిస్తాయి:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` ఇప్పటికీ ఈ ఫంక్షన్ యాజమాన్యంలో ఉంది.
//! ```
//!
//! సేకరణ రకం `C` `iter()` ను అందిస్తే, ఇది సాధారణంగా `&C` కోసం `IntoIterator` ను కూడా అమలు చేస్తుంది, అమలుతో `iter()` అని పిలుస్తుంది.
//! అదేవిధంగా, `iter_mut()` ను అందించే `C` సేకరణ సాధారణంగా `iter_mut()` కు అప్పగించడం ద్వారా `&mut C` కోసం `IntoIterator` ను అమలు చేస్తుంది.ఇది అనుకూలమైన సంక్షిప్తలిపిని అనుమతిస్తుంది:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // `values.iter_mut()` వలె ఉంటుంది
//!     *x += 1;
//! }
//! for x in &values { // `values.iter()` వలె ఉంటుంది
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! చాలా సేకరణలు `iter()` ను అందిస్తుండగా, అన్నీ `iter_mut()` ను అందించవు.
//! ఉదాహరణకు, [`HashSet<T>`] లేదా [`HashMap<K, V>`] యొక్క కీలను మార్చడం కీ హాష్‌లు మారితే సేకరణను అస్థిరమైన స్థితిలో ఉంచవచ్చు, కాబట్టి ఈ సేకరణలు `iter()` ను మాత్రమే అందిస్తాయి.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! [`Iterator`] తీసుకొని మరొక [`Iterator`] ను తిరిగి ఇచ్చే విధులను తరచుగా 'ఇరేటర్ ఎడాప్టర్లు' అని పిలుస్తారు, ఎందుకంటే అవి 'అడాప్టర్ యొక్క ఒక రూపం
//! pattern'.
//!
//! సాధారణ ఇటరేటర్ ఎడాప్టర్లలో [`map`], [`take`] మరియు [`filter`] ఉన్నాయి.
//! మరిన్ని కోసం, వారి డాక్యుమెంటేషన్ చూడండి.
//!
//! ఒక ఇరేటర్ అడాప్టర్ panics అయితే, ఇరేటర్ పేర్కొనబడని (కానీ మెమరీ సురక్షితమైన) స్థితిలో ఉంటుంది.
//! ఈ స్థితి Rust యొక్క సంస్కరణల్లో ఒకే విధంగా ఉంటుందని హామీ ఇవ్వబడలేదు, కాబట్టి మీరు భయపడిన ఇరేటర్ తిరిగి ఇచ్చిన ఖచ్చితమైన విలువలపై ఆధారపడకుండా ఉండాలి.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! ఇటెరేటర్లు (మరియు ఇటేరేటర్ [adapters](#adapters))*సోమరితనం*. దీని అర్థం ఇటేరేటర్‌ను సృష్టించడం వల్ల _do_ మొత్తం చాలా ఉండదు. మీరు [`next`] కి కాల్ చేసేవరకు ఏమీ జరగదు.
//! దాని దుష్ప్రభావాల కోసం మాత్రమే ఇరేటర్‌ను సృష్టించేటప్పుడు ఇది కొన్నిసార్లు గందరగోళానికి మూలం.
//! ఉదాహరణకు, [`map`] పద్ధతి ప్రతి మూలకంపై మూసివేతను పిలుస్తుంది:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! ఇది ఏ విలువలను ముద్రించదు, ఎందుకంటే మేము దానిని ఉపయోగించకుండా, ఇటరేటర్‌ను మాత్రమే సృష్టించాము.కంపైలర్ ఈ రకమైన ప్రవర్తన గురించి హెచ్చరిస్తుంది:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! [`map`] ను దాని దుష్ప్రభావాల కోసం వ్రాయడానికి ఇడియొమాటిక్ మార్గం `for` లూప్‌ను ఉపయోగించడం లేదా [`for_each`] పద్ధతిని పిలవడం:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! ఇటరేటర్‌ను అంచనా వేయడానికి మరొక సాధారణ మార్గం ఏమిటంటే, కొత్త సేకరణను రూపొందించడానికి [`collect`] పద్ధతిని ఉపయోగించడం.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! ఇటరేటర్లు పరిమితంగా ఉండవలసిన అవసరం లేదు.ఉదాహరణగా, ఓపెన్-ఎండ్ పరిధి అనంతమైన మళ్ళి:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! అనంతమైన ఇరేటర్‌ను పరిమితంగా మార్చడానికి [`take`] ఇరేటర్ అడాప్టర్‌ను ఉపయోగించడం సాధారణం:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! ఇది `0` సంఖ్యలను `4` ద్వారా ప్రింట్ చేస్తుంది, ప్రతి ఒక్కటి వారి స్వంత లైన్‌లో ఉంటుంది.
//!
//! అనంతమైన ఇటరేటర్లపై పద్ధతులు, పరిమిత సమయంలో గణితశాస్త్రపరంగా ఫలితాన్ని నిర్ణయించగల పద్ధతులు కూడా అంతం కావు అని గుర్తుంచుకోండి.
//! ప్రత్యేకించి, [`min`] వంటి పద్ధతులు, సాధారణ సందర్భంలో ఇటెరేటర్‌లోని ప్రతి మూలకాన్ని దాటడం అవసరం, అనంతమైన ఇటరేటర్లకు విజయవంతంగా తిరిగి రాకపోవచ్చు.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // అరెరే!అనంతమైన లూప్!
//! // `ones.min()` అనంతమైన లూప్‌కు కారణమవుతుంది, కాబట్టి మేము ఈ దశకు చేరుకోము!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;