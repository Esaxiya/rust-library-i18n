use crate::iter::{FusedIterator, TrustedLen};

/// అందించిన మూసివేతను ప్రారంభించడం ద్వారా సరిగ్గా ఒకసారి విలువను సోమరితనం ఉత్పత్తి చేసే ఒక ఇరేటర్‌ను సృష్టిస్తుంది.
///
/// ఒకే విలువ జెనరేటర్‌ను [`chain()`] ఇతర రకాల పునరుక్తికి అనుగుణంగా మార్చడానికి ఇది సాధారణంగా ఉపయోగించబడుతుంది.
/// బహుశా మీరు దాదాపు ప్రతిదీ కవర్ చేసే ఒక ఇరేటర్ కలిగి ఉండవచ్చు, కానీ మీకు అదనపు ప్రత్యేక సందర్భం అవసరం.
/// బహుశా మీకు ఇటరేటర్లలో పనిచేసే ఫంక్షన్ ఉండవచ్చు, కానీ మీరు ఒక విలువను మాత్రమే ప్రాసెస్ చేయాలి.
///
/// [`once()`] కాకుండా, ఈ ఫంక్షన్ అభ్యర్థనపై విలువను సోమరిగా ఉత్పత్తి చేస్తుంది.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// ప్రాథమిక వినియోగం:
///
/// ```
/// use std::iter;
///
/// // ఒకటి ఒంటరి సంఖ్య
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // ఒకటి, మనకు లభిస్తుంది
/// assert_eq!(None, one.next());
/// ```
///
/// మరొక ఇటరేటర్‌తో కలిసి బంధించడం.
/// మేము `.foo` డైరెక్టరీ యొక్క ప్రతి ఫైల్‌పై మళ్ళించాలనుకుంటున్నాము, కానీ కాన్ఫిగరేషన్ ఫైల్ కూడా,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // మేము DirEntry-s యొక్క మళ్ళి నుండి పాత్‌బఫ్స్ యొక్క మళ్ళిగా మార్చాలి, కాబట్టి మేము మ్యాప్‌ను ఉపయోగిస్తాము
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ఇప్పుడు, మా కాన్ఫిగర్ ఫైల్ కోసం మా ఇటరేటర్
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // రెండు ఇటరేటర్లను ఒక పెద్ద ఇటరేటర్‌గా కలపండి
/// let files = dirs.chain(config);
///
/// // ఇది మాకు .foo మరియు .foorc లోని అన్ని ఫైళ్ళను ఇస్తుంది
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// అందించిన మూసివేత `F: FnOnce() -> A` ను వర్తింపజేయడం ద్వారా `A` రకం యొక్క ఒకే మూలకాన్ని ఇచ్చే ఇటరేటర్.
///
///
/// ఈ `struct` [`once_with()`] ఫంక్షన్ ద్వారా సృష్టించబడుతుంది.
/// మరిన్ని కోసం దాని డాక్యుమెంటేషన్ చూడండి.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}