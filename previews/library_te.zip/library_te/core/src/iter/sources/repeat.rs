use crate::iter::{FusedIterator, TrustedLen};

/// ఒకే మూలకాన్ని అనంతంగా పునరావృతం చేసే క్రొత్త మళ్ళిని సృష్టిస్తుంది.
///
/// `repeat()` ఫంక్షన్ ఒకే విలువను పదే పదే పునరావృతం చేస్తుంది.
///
/// `repeat()` వంటి అనంతమైన ఇరేటర్లను తరచుగా [`Iterator::take()`] వంటి ఎడాప్టర్లతో ఉపయోగిస్తారు, వాటిని పరిమితంగా చేయడానికి.
///
/// మీకు అవసరమైన ఇరేటర్ యొక్క మూలకం రకం `Clone` ను అమలు చేయకపోతే, లేదా మీరు పదేపదే మూలకాన్ని మెమరీలో ఉంచకూడదనుకుంటే, మీరు బదులుగా [`repeat_with()`] ఫంక్షన్‌ను ఉపయోగించవచ్చు.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// ప్రాథమిక వినియోగం:
///
/// ```
/// use std::iter;
///
/// // సంఖ్య నాలుగు 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // అయ్యో, ఇంకా నాలుగు
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// [`Iterator::take()`] తో పరిమితంగా వెళుతోంది:
///
/// ```
/// use std::iter;
///
/// // చివరి ఉదాహరణ చాలా ఫోర్లు.నాలుగు ఫోర్లు మాత్రమే తీసుకుందాం.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... మరియు ఇప్పుడు మేము పూర్తి చేసాము
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// ఒక మూలకాన్ని అనంతంగా పునరావృతం చేసే ఇటరేటర్.
///
/// ఈ `struct` [`repeat()`] ఫంక్షన్ ద్వారా సృష్టించబడుతుంది.మరిన్ని కోసం దాని డాక్యుమెంటేషన్ చూడండి.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}