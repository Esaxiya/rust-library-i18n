use crate::iter::{FusedIterator, TrustedLen};

/// అందించిన మూసివేత, రిపీటర్‌ను వర్తింపజేయడం ద్వారా `A` రకం యొక్క అంశాలను అనంతంగా పునరావృతం చేసే కొత్త ఇటరేటర్‌ను సృష్టిస్తుంది. `F: FnMut() -> A`.
///
/// `repeat_with()` ఫంక్షన్ రిపీటర్‌ను పదే పదే పిలుస్తుంది.
///
/// `repeat_with()` వంటి అనంతమైన ఇరేటర్లను తరచుగా [`Iterator::take()`] వంటి ఎడాప్టర్లతో ఉపయోగిస్తారు, వాటిని పరిమితంగా చేయడానికి.
///
/// మీకు అవసరమైన ఇరేటర్ యొక్క మూలకం రకం [`Clone`] ను అమలు చేస్తే, మరియు మూల మూలకాన్ని మెమరీలో ఉంచడం సరే, మీరు బదులుగా [`repeat()`] ఫంక్షన్‌ను ఉపయోగించాలి.
///
///
/// `repeat_with()` చేత ఉత్పత్తి చేయబడిన ఇటరేటర్ [`DoubleEndedIterator`] కాదు.
/// [`DoubleEndedIterator`] ను తిరిగి ఇవ్వడానికి మీకు `repeat_with()` అవసరమైతే, దయచేసి మీ వినియోగ కేసును వివరిస్తూ GitHub సమస్యను తెరవండి.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// ప్రాథమిక వినియోగం:
///
/// ```
/// use std::iter;
///
/// // `Clone` కాని లేదా ఖరీదైనది కనుక ఇంకా మెమరీని కలిగి ఉండకూడదనుకునే రకం యొక్క కొంత విలువ మనకు ఉందని అనుకుందాం:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // ఒక నిర్దిష్ట విలువ ఎప్పటికీ:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// మ్యుటేషన్ ఉపయోగించడం మరియు పరిమితంగా వెళ్లడం:
///
/// ```rust
/// use std::iter;
///
/// // సున్నా నుండి రెండు యొక్క మూడవ శక్తి వరకు:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... మరియు ఇప్పుడు మేము పూర్తి చేసాము
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// అందించిన మూసివేత `F: FnMut() -> A` ను వర్తింపజేయడం ద్వారా `A` రకం యొక్క అంశాలను అనంతంగా పునరావృతం చేసే ఒక ఇరేటర్.
///
///
/// ఈ `struct` [`repeat_with()`] ఫంక్షన్ ద్వారా సృష్టించబడుతుంది.
/// మరిన్ని కోసం దాని డాక్యుమెంటేషన్ చూడండి.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}