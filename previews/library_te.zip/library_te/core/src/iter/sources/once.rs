use crate::iter::{FusedIterator, TrustedLen};

/// ఒక మూలకాన్ని సరిగ్గా ఒకసారి ఇచ్చే ఇటరేటర్‌ను సృష్టిస్తుంది.
///
/// ఒకే విలువను [`chain()`] ఇతర రకాల పునరుక్తిగా మార్చడానికి ఇది సాధారణంగా ఉపయోగించబడుతుంది.
/// బహుశా మీరు దాదాపు ప్రతిదీ కవర్ చేసే ఒక ఇరేటర్ కలిగి ఉండవచ్చు, కానీ మీకు అదనపు ప్రత్యేక సందర్భం అవసరం.
/// బహుశా మీకు ఇటరేటర్లలో పనిచేసే ఫంక్షన్ ఉండవచ్చు, కానీ మీరు ఒక విలువను మాత్రమే ప్రాసెస్ చేయాలి.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// ప్రాథమిక వినియోగం:
///
/// ```
/// use std::iter;
///
/// // ఒకటి ఒంటరి సంఖ్య
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // ఒకటి, మనకు లభిస్తుంది
/// assert_eq!(None, one.next());
/// ```
///
/// మరొక ఇటరేటర్‌తో కలిసి బంధించడం.
/// మేము `.foo` డైరెక్టరీ యొక్క ప్రతి ఫైల్‌పై మళ్ళించాలనుకుంటున్నాము, కానీ కాన్ఫిగరేషన్ ఫైల్ కూడా,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // మేము DirEntry-s యొక్క మళ్ళి నుండి పాత్‌బఫ్స్ యొక్క మళ్ళిగా మార్చాలి, కాబట్టి మేము మ్యాప్‌ను ఉపయోగిస్తాము
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ఇప్పుడు, మా కాన్ఫిగర్ ఫైల్ కోసం మా ఇటరేటర్
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // రెండు ఇటరేటర్లను ఒక పెద్ద ఇటరేటర్‌గా కలపండి
/// let files = dirs.chain(config);
///
/// // ఇది మాకు .foo మరియు .foorc లోని అన్ని ఫైళ్ళను ఇస్తుంది
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// ఒక మూలకాన్ని సరిగ్గా ఒకసారి ఇచ్చే ఇటరేటర్.
///
/// ఈ `struct` [`once()`] ఫంక్షన్ ద్వారా సృష్టించబడుతుంది.మరిన్ని కోసం దాని డాక్యుమెంటేషన్ చూడండి.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}