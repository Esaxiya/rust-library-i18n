use crate::fmt;
use crate::iter::{FusedIterator, TrustedLen};
use crate::marker;

/// ఏమీ ఇవ్వని ఇటరేటర్‌ను సృష్టిస్తుంది.
///
/// # Examples
///
/// ప్రాథమిక వినియోగం:
///
/// ```
/// use std::iter;
///
/// // ఇది i32 కంటే ఎక్కువ మళ్ళి కావచ్చు, కానీ అయ్యో, ఇది కాదు.
/// let mut nope = iter::empty::<i32>();
///
/// assert_eq!(None, nope.next());
/// ```
#[stable(feature = "iter_empty", since = "1.2.0")]
#[rustc_const_stable(feature = "const_iter_empty", since = "1.32.0")]
pub const fn empty<T>() -> Empty<T> {
    Empty(marker::PhantomData)
}

/// ఏమీ ఇవ్వని మళ్ళి.
///
/// ఈ `struct` [`empty()`] ఫంక్షన్ ద్వారా సృష్టించబడుతుంది.మరిన్ని కోసం దాని డాక్యుమెంటేషన్ చూడండి.
#[stable(feature = "iter_empty", since = "1.2.0")]
pub struct Empty<T>(marker::PhantomData<T>);

#[stable(feature = "iter_empty_send_sync", since = "1.42.0")]
unsafe impl<T> Send for Empty<T> {}
#[stable(feature = "iter_empty_send_sync", since = "1.42.0")]
unsafe impl<T> Sync for Empty<T> {}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T> fmt::Debug for Empty<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Empty")
    }
}

#[stable(feature = "iter_empty", since = "1.2.0")]
impl<T> Iterator for Empty<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(0))
    }
}

#[stable(feature = "iter_empty", since = "1.2.0")]
impl<T> DoubleEndedIterator for Empty<T> {
    fn next_back(&mut self) -> Option<T> {
        None
    }
}

#[stable(feature = "iter_empty", since = "1.2.0")]
impl<T> ExactSizeIterator for Empty<T> {
    fn len(&self) -> usize {
        0
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Empty<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Empty<T> {}

// కాదు#[ఉత్పన్నం] ఎందుకంటే ఇది T కి కట్టుబడి ఉన్న క్లోన్‌ను జతచేస్తుంది, ఇది అవసరం లేదు.
//
#[stable(feature = "iter_empty", since = "1.2.0")]
impl<T> Clone for Empty<T> {
    fn clone(&self) -> Empty<T> {
        Empty(marker::PhantomData)
    }
}

// కాదు#[ఉత్పన్నం] ఎందుకంటే ఇది T కి అప్రమేయంగా కట్టుబడి ఉంటుంది, ఇది అవసరం లేదు.
//
#[stable(feature = "iter_empty", since = "1.2.0")]
impl<T> Default for Empty<T> {
    fn default() -> Empty<T> {
        Empty(marker::PhantomData)
    }
}