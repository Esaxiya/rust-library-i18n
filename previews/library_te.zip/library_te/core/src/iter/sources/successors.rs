use crate::{fmt, iter::FusedIterator};

/// క్రొత్త ఐటెరేటర్‌ను సృష్టిస్తుంది, ఇక్కడ ప్రతి వరుస అంశం మునుపటి దాని ఆధారంగా లెక్కించబడుతుంది.
///
/// ఇటేరేటర్ ఇచ్చిన మొదటి ఐటెమ్‌తో (ఏదైనా ఉంటే) మొదలవుతుంది మరియు ప్రతి అంశం యొక్క వారసుడిని లెక్కించడానికి ఇచ్చిన `FnMut(&T) -> Option<T>` మూసివేతను పిలుస్తుంది.
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // ఈ ఫంక్షన్ `impl Iterator<Item=T>` ను తిరిగి ఇస్తే అది `unfold` పై ఆధారపడి ఉంటుంది మరియు ప్రత్యేక రకం అవసరం లేదు.
    //
    // అయితే పేరున్న `Successors<T, F>` రకాన్ని కలిగి ఉండటం `T` మరియు `F` ఉన్నప్పుడు `Clone` గా ఉండటానికి అనుమతిస్తుంది.
    Successors { next: first, succ }
}

/// క్రొత్త ఐటెరేటర్, ఇక్కడ ప్రతి వరుస అంశం మునుపటి ఆధారంగా లెక్కించబడుతుంది.
///
/// ఈ `struct` [`iter::successors()`] ఫంక్షన్ ద్వారా సృష్టించబడుతుంది.
/// మరిన్ని కోసం దాని డాక్యుమెంటేషన్ చూడండి.
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}