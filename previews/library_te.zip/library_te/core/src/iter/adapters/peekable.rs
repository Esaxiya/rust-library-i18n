use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// `peek()` తో ఒక ఇరేటర్ తదుపరి మూలకానికి ఐచ్ఛిక సూచనను అందిస్తుంది.
///
///
/// ఈ `struct` [`Iterator`] లో [`peekable`] పద్ధతి ద్వారా సృష్టించబడుతుంది.
/// మరిన్ని కోసం దాని డాక్యుమెంటేషన్ చూడండి.
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// ఏదీ కాకపోయినా, పీక్ చేసిన విలువను గుర్తుంచుకోండి.
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// `.peek()` పద్ధతిలో ఏదీ కనిపించకపోతే పీక్ చేయదగినది గుర్తుంచుకోవాలి.
// ఇది `.peek() అని నిర్ధారిస్తుంది;.peek();` లేదా `.peek();.next();` అంతర్లీన ఇటరేటర్‌ను ఒకేసారి మాత్రమే అభివృద్ధి చేస్తుంది.
// ఇది ఇరేటర్‌ను ఫ్యూజ్ చేయదు.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// ఇరేటర్‌ను అభివృద్ధి చేయకుండా next() విలువకు సూచనను అందిస్తుంది.
    ///
    /// [`next`] మాదిరిగా, విలువ ఉంటే, అది `Some(T)` లో చుట్టబడి ఉంటుంది.
    /// పునరావృతం ముగిస్తే, `None` తిరిగి వస్తుంది.
    ///
    /// [`next`]: Iterator::next
    ///
    /// `peek()` ఒక సూచనను తిరిగి ఇస్తుంది మరియు చాలా మంది ఇరేటర్లు సూచనలపై మళ్ళిస్తారు, తిరిగి వచ్చే విలువ డబుల్ రిఫరెన్స్ అయిన గందరగోళ పరిస్థితి ఉండవచ్చు.
    /// మీరు ఈ ప్రభావాన్ని క్రింది ఉదాహరణలలో చూడవచ్చు.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() future లోకి చూద్దాం
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // మేము అనేకసార్లు `peek` చేసినా ఇటరేటర్ ముందుకు సాగదు
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // ఇరేటర్ పూర్తయిన తర్వాత, `peek()` కూడా ఉంది
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// ఇరేటర్‌ను ముందుకు సాగకుండా next() విలువకు మార్చగల సూచనను అందిస్తుంది.
    ///
    /// [`next`] మాదిరిగా, విలువ ఉంటే, అది `Some(T)` లో చుట్టబడి ఉంటుంది.
    /// పునరావృతం ముగిస్తే, `None` తిరిగి వస్తుంది.
    ///
    /// `peek_mut()` ఒక సూచనను తిరిగి ఇస్తుంది మరియు చాలా మంది ఇరేటర్లు సూచనలపై మళ్ళిస్తారు, తిరిగి వచ్చే విలువ డబుల్ రిఫరెన్స్ అయిన గందరగోళ పరిస్థితి ఉండవచ్చు.
    /// మీరు ఈ ప్రభావాన్ని క్రింది ఉదాహరణలలో చూడవచ్చు.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // `peek()` మాదిరిగానే, ఇటరేటర్‌ను అభివృద్ధి చేయకుండా మేము future లోకి చూడవచ్చు.
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // మళ్ళిని పరిశీలించి, మార్చగల సూచన వెనుక విలువను సెట్ చేయండి.
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // మళ్ళి కొనసాగుతున్నప్పుడు మేము ఉంచిన విలువ మళ్లీ కనిపిస్తుంది.
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// ఒక షరతు నిజమైతే ఈ ఇటరేటర్ యొక్క తదుపరి విలువను తీసుకోండి మరియు తిరిగి ఇవ్వండి.
    /// ఈ ఇరేటర్ యొక్క తదుపరి విలువ కోసం `func` `true` ను తిరిగి ఇస్తే, దానిని వినియోగించి తిరిగి ఇవ్వండి.
    /// లేకపోతే, `None` ను తిరిగి ఇవ్వండి.
    /// # Examples
    /// 0 కి సమానంగా ఉంటే సంఖ్యను తీసుకోండి.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // మళ్ళి యొక్క మొదటి అంశం 0;దానిని తినేయండి.
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // తిరిగి వచ్చిన తదుపరి అంశం ఇప్పుడు 1, కాబట్టి `consume` `false` ను తిరిగి ఇస్తుంది.
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` `expected` కు సమానం కాకపోతే తదుపరి అంశం యొక్క విలువను ఆదా చేస్తుంది.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// 10 కంటే తక్కువ సంఖ్యను తీసుకోండి.
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // అన్ని సంఖ్యలను 10 కన్నా తక్కువ తీసుకోండి
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // తిరిగి వచ్చిన తదుపరి విలువ 10 అవుతుంది
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // మేము `self.next()` అని పిలిచినందున, మేము `self.peeked` ను వినియోగించాము.
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// `expected` కి సమానంగా ఉంటే తదుపరి వస్తువును తీసుకోండి మరియు తిరిగి ఇవ్వండి.
    /// # Example
    /// 0 కి సమానంగా ఉంటే సంఖ్యను తీసుకోండి.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // మళ్ళి యొక్క మొదటి అంశం 0;దానిని తినేయండి.
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // తిరిగి వచ్చిన తదుపరి అంశం ఇప్పుడు 1, కాబట్టి `consume` `false` ను తిరిగి ఇస్తుంది.
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` `expected` కు సమానం కాకపోతే తదుపరి అంశం యొక్క విలువను ఆదా చేస్తుంది.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // భద్రత: అసురక్షిత ఫంక్షన్ అదే అవసరాలతో అసురక్షిత ఫంక్షన్‌కు ఫార్వార్డింగ్
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}