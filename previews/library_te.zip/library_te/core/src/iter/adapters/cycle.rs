use crate::{iter::FusedIterator, ops::Try};

/// అనంతంగా పునరావృతమయ్యే ఇటరేటర్.
///
/// ఈ `struct` [`Iterator`] లో [`cycle`] పద్ధతి ద్వారా సృష్టించబడుతుంది.
/// మరిన్ని కోసం దాని డాక్యుమెంటేషన్ చూడండి.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // చక్రం మళ్ళి ఖాళీ లేదా అనంతం
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // ప్రస్తుత మళ్ళిని పూర్తిగా మళ్ళించండి.
        // ఇది అవసరం ఎందుకంటే `self.orig` లేనప్పుడు కూడా `self.iter` ఖాళీగా ఉండవచ్చు
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // పూర్తి చక్రం పూర్తి చేయండి, సైక్లింగ్ ఇరేటర్ ఖాళీగా ఉందో లేదో ట్రాక్ చేస్తుంది.
        // అనంతమైన లూప్‌ను నివారించడానికి ఖాళీ ఇరేటర్ విషయంలో మేము ముందుగానే తిరిగి రావాలి
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // `fold` ఓవర్రైడ్ లేదు, ఎందుకంటే `fold` `Cycle` కి పెద్దగా అర్ధం కాదు మరియు డిఫాల్ట్ కంటే మెరుగైనది ఏమీ చేయలేము.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}