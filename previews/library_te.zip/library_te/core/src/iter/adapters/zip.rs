use crate::cmp;
use crate::fmt::{self, Debug};
use crate::iter::{DoubleEndedIterator, ExactSizeIterator, FusedIterator, Iterator};
use crate::iter::{InPlaceIterable, SourceIter, TrustedLen};

/// ఒకేసారి మరో రెండు ఇరేటర్లను మళ్ళించే ఇరేటర్.
///
/// ఈ `struct` [`Iterator::zip`] చే సృష్టించబడింది.
/// మరిన్ని కోసం దాని డాక్యుమెంటేషన్ చూడండి.
#[derive(Clone)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Zip<A, B> {
    a: A,
    b: B,
    // ఇండెక్స్, లెన్ మరియు ఎ_లెన్ జిప్ యొక్క ప్రత్యేక వెర్షన్ ద్వారా మాత్రమే ఉపయోగించబడతాయి
    index: usize,
    len: usize,
    a_len: usize,
}
impl<A: Iterator, B: Iterator> Zip<A, B> {
    pub(in crate::iter) fn new(a: A, b: B) -> Zip<A, B> {
        ZipImpl::new(a, b)
    }
    fn super_nth(&mut self, mut n: usize) -> Option<(A::Item, B::Item)> {
        while let Some(x) = Iterator::next(self) {
            if n == 0 {
                return Some(x);
            }
            n -= 1;
        }
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> Iterator for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        ZipImpl::next(self)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        ZipImpl::size_hint(self)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        ZipImpl::nth(self, n)
    }

    #[inline]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        // భద్రత: `ZipImpl::__iterator_get_unchecked` కి అదే భద్రత ఉంది
        // `Iterator::__iterator_get_unchecked` గా అవసరాలు.
        unsafe { ZipImpl::get_unchecked(self, idx) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> DoubleEndedIterator for Zip<A, B>
where
    A: DoubleEndedIterator + ExactSizeIterator,
    B: DoubleEndedIterator + ExactSizeIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)> {
        ZipImpl::next_back(self)
    }
}

// జిప్ స్పెషలైజేషన్ trait
#[doc(hidden)]
trait ZipImpl<A, B> {
    type Item;
    fn new(a: A, b: B) -> Self;
    fn next(&mut self) -> Option<Self::Item>;
    fn size_hint(&self) -> (usize, Option<usize>);
    fn nth(&mut self, n: usize) -> Option<Self::Item>;
    fn next_back(&mut self) -> Option<Self::Item>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator;
    // ఇది `Iterator::__iterator_get_unchecked` వలె అదే భద్రతా అవసరాలను కలిగి ఉంది
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item
    where
        Self: Iterator + TrustedRandomAccess;
}

// జనరల్ జిప్ impl
#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);
    default fn new(a: A, b: B) -> Self {
        Zip {
            a,
            b,
            index: 0, // unused
            len: 0,   // unused
            a_len: 0, // unused
        }
    }

    #[inline]
    default fn next(&mut self) -> Option<(A::Item, B::Item)> {
        let x = self.a.next()?;
        let y = self.b.next()?;
        Some((x, y))
    }

    #[inline]
    default fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.super_nth(n)
    }

    #[inline]
    default fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        let a_sz = self.a.len();
        let b_sz = self.b.len();
        if a_sz != b_sz {
            // A, b ను సమాన పొడవుకు సర్దుబాటు చేయండి
            if a_sz > b_sz {
                for _ in 0..a_sz - b_sz {
                    self.a.next_back();
                }
            } else {
                for _ in 0..b_sz - a_sz {
                    self.b.next_back();
                }
            }
        }
        match (self.a.next_back(), self.b.next_back()) {
            (Some(x), Some(y)) => Some((x, y)),
            (None, None) => None,
            _ => unreachable!(),
        }
    }

    #[inline]
    default fn size_hint(&self) -> (usize, Option<usize>) {
        let (a_lower, a_upper) = self.a.size_hint();
        let (b_lower, b_upper) = self.b.size_hint();

        let lower = cmp::min(a_lower, b_lower);

        let upper = match (a_upper, b_upper) {
            (Some(x), Some(y)) => Some(cmp::min(x, y)),
            (Some(x), None) => Some(x),
            (None, Some(y)) => Some(y),
            (None, None) => None,
        };

        (lower, upper)
    }

    default unsafe fn get_unchecked(&mut self, _idx: usize) -> <Self as Iterator>::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: TrustedRandomAccess + Iterator,
    B: TrustedRandomAccess + Iterator,
{
    fn new(a: A, b: B) -> Self {
        let a_len = a.size();
        let len = cmp::min(a_len, b.size());
        Zip { a, b, index: 0, len, a_len }
    }

    #[inline]
    fn next(&mut self) -> Option<(A::Item, B::Item)> {
        if self.index < self.len {
            let i = self.index;
            self.index += 1;
            // భద్రత: `i` `self.len` కన్నా చిన్నది, తద్వారా `self.a.len()` మరియు `self.b.len()` కన్నా చిన్నది
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else if A::MAY_HAVE_SIDE_EFFECT && self.index < self.a_len {
            let i = self.index;
            self.index += 1;
            self.len += 1;
            // బేస్ అమలు యొక్క సంభావ్య దుష్ప్రభావాలతో సరిపోలండి భద్రత: మేము `i` <`self.a.len()` అని తనిఖీ చేసాము
            //
            unsafe {
                self.a.__iterator_get_unchecked(i);
            }
            None
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len - self.index;
        (len, Some(len))
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let delta = cmp::min(n, self.len - self.index);
        let end = self.index + delta;
        while self.index < end {
            let i = self.index;
            self.index += 1;
            if A::MAY_HAVE_SIDE_EFFECT {
                // భద్రత: `delta` ను లెక్కించడానికి `cmp::min` వాడకం
                // `end` `self.len` కన్నా చిన్నది లేదా సమానమని నిర్ధారిస్తుంది, కాబట్టి `i` కూడా `self.len` కన్నా చిన్నది.
                //
                unsafe {
                    self.a.__iterator_get_unchecked(i);
                }
            }
            if B::MAY_HAVE_SIDE_EFFECT {
                // భద్రత: పైన చెప్పినట్లే.
                unsafe {
                    self.b.__iterator_get_unchecked(i);
                }
            }
        }

        self.super_nth(n - delta)
    }

    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        if A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT {
            let sz_a = self.a.size();
            let sz_b = self.b.size();
            // A, b ను సమాన పొడవుకు సర్దుబాటు చేయండి, `next_back` యొక్క మొదటి కాల్ మాత్రమే దీన్ని చేస్తుందని నిర్ధారించుకోండి, లేకపోతే `get_unchecked()` కి కాల్ చేసిన తర్వాత `self.next_back()` కి కాల్స్ చేసే పరిమితిని మేము విచ్ఛిన్నం చేస్తాము.
            //
            //
            if sz_a != sz_b {
                let sz_a = self.a.size();
                if A::MAY_HAVE_SIDE_EFFECT && sz_a > self.len {
                    for _ in 0..sz_a - self.len {
                        self.a.next_back();
                    }
                    self.a_len = self.len;
                }
                let sz_b = self.b.size();
                if B::MAY_HAVE_SIDE_EFFECT && sz_b > self.len {
                    for _ in 0..sz_b - self.len {
                        self.b.next_back();
                    }
                }
            }
        }
        if self.index < self.len {
            self.len -= 1;
            self.a_len -= 1;
            let i = self.len;
            // భద్రత: `self.len` యొక్క మునుపటి విలువ కంటే `i` చిన్నది,
            // ఇది `self.a.len()` మరియు `self.b.len()` కన్నా చిన్నది లేదా సమానం
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else {
            None
        }
    }

    #[inline]
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item {
        let idx = self.index + idx;
        // భద్రత: కాలర్ `Iterator::__iterator_get_unchecked` కోసం ఒప్పందాన్ని సమర్థించాలి.
        //
        unsafe { (self.a.__iterator_get_unchecked(idx), self.b.__iterator_get_unchecked(idx)) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> ExactSizeIterator for Zip<A, B>
where
    A: ExactSizeIterator,
    B: ExactSizeIterator,
{
}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<A, B> TrustedRandomAccess for Zip<A, B>
where
    A: TrustedRandomAccess,
    B: TrustedRandomAccess,
{
    const MAY_HAVE_SIDE_EFFECT: bool = A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT;
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A, B> FusedIterator for Zip<A, B>
where
    A: FusedIterator,
    B: FusedIterator,
{
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, B> TrustedLen for Zip<A, B>
where
    A: TrustedLen,
    B: TrustedLen,
{
}

// సంగ్రహించదగిన "source" గా జిప్ మళ్ళా యొక్క ఎడమ వైపును ఏకపక్షంగా ఎంచుకుంటుంది, దీనికి రెండింటినీ ప్రయత్నించడానికి ప్రతికూల trait bounds అవసరం.
//
#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S, A, B> SourceIter for Zip<A, B>
where
    A: SourceIter<Source = S>,
    B: Iterator,
    S: Iterator,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // భద్రత: అసురక్షిత ఫంక్షన్ అదే అవసరాలతో అసురక్షిత ఫంక్షన్‌కు ఫార్వార్డింగ్
        unsafe { SourceIter::as_inner(&mut self.a) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
// అంశానికి పరిమితం: విశ్వసనీయ రాండమ్ యాక్సెస్ యొక్క జిప్ ఉపయోగం మరియు మూలం యొక్క డ్రాప్ అమలు మధ్య పరస్పర చర్య అస్పష్టంగా ఉన్నందున కాపీ చేయండి.
//
// మూలం ఎన్నిసార్లు తార్కికంగా అభివృద్ధి చెందిందో తిరిగి ఇచ్చే అదనపు పద్ధతి (next()) కి కాల్ చేయకుండా మూలం యొక్క మిగిలిన భాగాన్ని సరిగ్గా వదలడానికి అవసరం.
//
//
unsafe impl<A: InPlaceIterable, B: Iterator> InPlaceIterable for Zip<A, B> where A::Item: Copy {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Debug, B: Debug> Debug for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        ZipFmt::fmt(self, f)
    }
}

trait ZipFmt<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result;
}

impl<A: Debug, B: Debug> ZipFmt<A, B> for Zip<A, B> {
    default fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Zip").field("a", &self.a).field("b", &self.b).finish()
    }
}

impl<A: Debug + TrustedRandomAccess, B: Debug + TrustedRandomAccess> ZipFmt<A, B> for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // కలిగి ఉన్న ఇటరేటర్‌లపై ఎఫ్‌ఎమ్‌టిని పిలవడం * సురక్షితం కాదు, ఎందుకంటే మేము మళ్ళించటం ప్రారంభించిన తర్వాత అవి వింతగా, అసురక్షితంగా ఉన్నాయని పేర్కొంది.
        //
        f.debug_struct("Zip").finish()
    }
}

/// యాదృచ్ఛికంగా ప్రాప్యత చేయగల వస్తువులను పునరుక్తి చేసేవాడు
///
/// # Safety
///
/// ఇరేటర్ యొక్క `size_hint` కాల్ చేయడానికి ఖచ్చితమైన మరియు చౌకగా ఉండాలి.
///
/// `size` భర్తీ చేయకపోవచ్చు.
///
/// `<Self as Iterator>::__iterator_get_unchecked` కింది షరతులు నెరవేర్చినట్లయితే కాల్ చేయడానికి సురక్షితంగా ఉండాలి.
///
/// 1. `0 <= idx` మరియు `idx < self.size()`.
/// 2. `self: !Clone` అయితే, `get_unchecked` ను ఒకే సూచికతో `self` లో ఒకటి కంటే ఎక్కువసార్లు పిలవరు.
/// 3. `self.get_unchecked(idx)` అని పిలిచిన తరువాత `next_back` చాలా `self.size() - idx - 1` సార్లు మాత్రమే పిలువబడుతుంది.
/// 4. `get_unchecked` అని పిలిచిన తరువాత, ఈ క్రింది పద్ధతులు మాత్రమే `self` లో పిలువబడతాయి:
///     * `std::clone::Clone::clone()`
///     * `std::iter::Iterator::size_hint()`
///     * `std::iter::Iterator::next_back()`
///     * `std::iter::Iterator::__iterator_get_unchecked()`
///     * `std::iter::TrustedRandomAccess::size()`
///
/// ఇంకా, ఈ షరతులు నెరవేర్చినందున, ఇది దీనికి హామీ ఇవ్వాలి:
///
/// * ఇది `size_hint` నుండి తిరిగి వచ్చిన విలువను మార్చదు
/// * అవసరమైన traits అమలు చేయబడిందని భావించి, `get_unchecked` కి కాల్ చేసిన తర్వాత `self` లో పైన పేర్కొన్న పద్ధతులను పిలవడం సురక్షితంగా ఉండాలి.
///
/// * `get_unchecked` కి కాల్ చేసిన తర్వాత `self` ను వదలడం కూడా సురక్షితంగా ఉండాలి.
///
///
///
///
#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
#[rustc_specialization_trait]
pub unsafe trait TrustedRandomAccess: Sized {
    // సౌకర్యవంతమైన పద్ధతి.
    fn size(&self) -> usize
    where
        Self: Iterator,
    {
        self.size_hint().0
    }
    /// `true` ఒక ఇరేటర్ మూలకాన్ని పొందినట్లయితే దుష్ప్రభావాలు ఉండవచ్చు.
    /// అంతర్గత ఇటరేటర్లను పరిగణనలోకి తీసుకోవడం గుర్తుంచుకోండి.
    const MAY_HAVE_SIDE_EFFECT: bool;
}

/// `Iterator::__iterator_get_unchecked` లాగా, కానీ కంపైలర్ `U: TrustedRandomAccess` అని తెలుసుకోవలసిన అవసరం లేదు.
///
///
/// ## Safety
///
/// `get_unchecked` ని నేరుగా కాల్ చేసే అదే అవసరాలు.
#[doc(hidden)]
pub(in crate::iter::adapters) unsafe fn try_get_unchecked<I>(it: &mut I, idx: usize) -> I::Item
where
    I: Iterator,
{
    // భద్రత: కాలర్ `Iterator::__iterator_get_unchecked` కోసం ఒప్పందాన్ని సమర్థించాలి.
    //
    unsafe { it.try_get_unchecked(idx) }
}

unsafe trait SpecTrustedRandomAccess: Iterator {
    /// `Self: TrustedRandomAccess` అయితే, `Iterator::__iterator_get_unchecked(self, index)` కి కాల్ చేయడం సురక్షితంగా ఉండాలి.
    ///
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item;
}

unsafe impl<I: Iterator> SpecTrustedRandomAccess for I {
    default unsafe fn try_get_unchecked(&mut self, _: usize) -> Self::Item {
        panic!("Should only be called on TrustedRandomAccess iterators");
    }
}

unsafe impl<I: Iterator + TrustedRandomAccess> SpecTrustedRandomAccess for I {
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item {
        // భద్రత: కాలర్ `Iterator::__iterator_get_unchecked` కోసం ఒప్పందాన్ని సమర్థించాలి.
        //
        unsafe { self.__iterator_get_unchecked(index) }
    }
}