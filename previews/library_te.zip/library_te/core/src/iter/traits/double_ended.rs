use crate::ops::{ControlFlow, Try};

/// రెండు చివరల నుండి మూలకాలను ఇవ్వగల ఒక ఇరేటర్.
///
/// `DoubleEndedIterator` ను అమలు చేసే ఏదో [`Iterator`] ను అమలు చేసే దానిపై ఒక అదనపు సామర్ధ్యం ఉంది: వెనుక నుండి, అలాగే ముందు నుండి `ఐటెమ్'లను కూడా తీసుకునే సామర్థ్యం.
///
///
/// ముందుకు వెనుకకు రెండూ ఒకే పరిధిలో పనిచేస్తాయని గమనించడం ముఖ్యం, మరియు దాటవద్దు: అవి మధ్యలో కలిసినప్పుడు పునరావృతం అయిపోతుంది.
///
/// [`Iterator`] ప్రోటోకాల్‌కు సమానమైన పద్ధతిలో, ఒకసారి `DoubleEndedIterator` [`next_back()`] నుండి [`None`] ను తిరిగి ఇస్తుంది, దాన్ని మళ్లీ పిలుస్తే [`Some`] ను తిరిగి ఇవ్వకపోవచ్చు లేదా తిరిగి రాకపోవచ్చు.
/// [`next()`] మరియు [`next_back()`] ఈ ప్రయోజనం కోసం పరస్పరం మార్చుకోగలవు.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// ప్రాథమిక వినియోగం:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// ఇరేటర్ చివరి నుండి ఒక మూలకాన్ని తీసివేస్తుంది మరియు తిరిగి ఇస్తుంది.
    ///
    /// ఎక్కువ అంశాలు లేనప్పుడు `None` ని అందిస్తుంది.
    ///
    /// [trait-level] డాక్స్ మరిన్ని వివరాలను కలిగి ఉంది.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// `డబుల్ఎండెడ్ఇటరేటర్` యొక్క పద్ధతుల ద్వారా లభించే అంశాలు [`ఇటిరేటర్`] యొక్క పద్ధతుల ద్వారా లభించే వాటికి భిన్నంగా ఉండవచ్చు:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// `n` మూలకాల ద్వారా వెనుక నుండి ఇరేటర్‌ను అభివృద్ధి చేస్తుంది.
    ///
    /// `advance_back_by` [`advance_by`] యొక్క రివర్స్ వెర్షన్.ఈ పద్ధతి [`None`] ఎదురయ్యే వరకు [`next_back`] ను [`next_back`] వరకు `n` సార్లు కాల్ చేయడం ద్వారా `n` మూలకాలను ఆసక్తిగా దాటవేస్తుంది.
    ///
    /// `advance_back_by(n)` `n` ఎలిమెంట్స్ ద్వారా ఇరేటర్ విజయవంతంగా అభివృద్ధి చెందితే [`Ok(())`] ను తిరిగి ఇస్తుంది, లేదా [`None`] ఎదురైతే [`Err(k)`], ఇక్కడ `k` అనేది ఎలిమెంట్స్ అయిపోయే ముందు ఇటరేటర్ అభివృద్ధి చేసిన మూలకాల సంఖ్య (అనగా
    /// మళ్ళి యొక్క పొడవు).
    /// `k` ఎల్లప్పుడూ `n` కన్నా తక్కువగా ఉంటుందని గమనించండి.
    ///
    /// `advance_back_by(0)` కి కాల్ చేస్తే ఏ మూలకాలు తినవు మరియు ఎల్లప్పుడూ [`Ok(())`] ను తిరిగి ఇస్తాయి.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // `&3` మాత్రమే దాటవేయబడింది
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// ఇరేటర్ చివరి నుండి `n` వ మూలకాన్ని చూపుతుంది.
    ///
    /// ఇది తప్పనిసరిగా [`Iterator::nth()`] యొక్క రివర్స్డ్ వెర్షన్.
    /// చాలా ఇండెక్సింగ్ ఆపరేషన్ల మాదిరిగానే, కౌంట్ సున్నా నుండి మొదలవుతుంది, కాబట్టి `nth_back(0)` మొదటి విలువను చివరి నుండి, `nth_back(1)` రెండవదాన్ని తిరిగి ఇస్తుంది.
    ///
    ///
    /// తిరిగి వచ్చిన మూలకంతో సహా ముగింపు మరియు తిరిగి వచ్చిన మూలకం మధ్య ఉన్న అన్ని అంశాలు వినియోగించబడతాయి.
    /// ఒకే ఇటరేటర్‌లో `nth_back(0)` ని పలుసార్లు కాల్ చేస్తే వేర్వేరు అంశాలు తిరిగి వస్తాయని దీని అర్థం.
    ///
    /// `nth_back()` `n` ఇరేటర్ యొక్క పొడవు కంటే ఎక్కువ లేదా సమానంగా ఉంటే [`None`] ను తిరిగి ఇస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// `nth_back()` ను అనేకసార్లు కాల్ చేస్తే ఇరేటర్ రివైండ్ చేయబడదు:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// `n + 1` కంటే తక్కువ మూలకాలు ఉంటే `None` ని తిరిగి ఇస్తోంది:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// ఇది [`Iterator::try_fold()`] యొక్క రివర్స్ వెర్షన్: ఇది ఇరేటర్ వెనుక నుండి ప్రారంభమయ్యే అంశాలను తీసుకుంటుంది.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // ఇది షార్ట్ సర్క్యూట్ అయినందున, మిగిలిన అంశాలు ఇప్పటికీ ఇరేటర్ ద్వారా అందుబాటులో ఉన్నాయి.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// ఇరేటర్ యొక్క మూలకాలను వెనుక నుండి ప్రారంభించి, ఒకే, తుది విలువకు తగ్గించే ఇటేరేటర్ పద్ధతి.
    ///
    /// ఇది [`Iterator::fold()`] యొక్క రివర్స్ వెర్షన్: ఇది ఇరేటర్ వెనుక నుండి ప్రారంభమయ్యే అంశాలను తీసుకుంటుంది.
    ///
    /// `rfold()` రెండు వాదనలు తీసుకుంటుంది: ప్రారంభ విలువ మరియు రెండు వాదనలతో మూసివేత: ఒక 'accumulator' మరియు మూలకం.
    /// మూసివేత తదుపరి పునరావృతం కోసం సంచితం కలిగి ఉన్న విలువను తిరిగి ఇస్తుంది.
    ///
    /// ప్రారంభ విలువ అనేది మొదటి కాల్‌లో సంచితానికి ఉండే విలువ.
    ///
    /// ఇటరేటర్ యొక్క ప్రతి మూలకానికి ఈ మూసివేతను వర్తింపజేసిన తరువాత, `rfold()` సంచితాన్ని తిరిగి ఇస్తుంది.
    ///
    /// ఈ ఆపరేషన్‌ను కొన్నిసార్లు 'reduce' లేదా 'inject' అంటారు.
    ///
    /// మీకు ఏదైనా సేకరణ ఉన్నప్పుడల్లా మడత ఉపయోగపడుతుంది మరియు దాని నుండి ఒకే విలువను ఉత్పత్తి చేయాలనుకుంటుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // a యొక్క అన్ని మూలకాల మొత్తం
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// ఈ ఉదాహరణ ఒక స్ట్రింగ్‌ను నిర్మిస్తుంది, ఇది ప్రారంభ విలువతో ప్రారంభమవుతుంది మరియు ప్రతి మూలకంతో వెనుక నుండి ముందు వరకు కొనసాగుతుంది:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Icate హించిన దాన్ని సంతృప్తిపరిచే వెనుక నుండి ఇరేటర్ యొక్క మూలకం కోసం శోధిస్తుంది.
    ///
    /// `rfind()` `true` లేదా `false` ను తిరిగి ఇచ్చే మూసివేతను తీసుకుంటుంది.
    /// ఇది ఇటరేటర్ యొక్క ప్రతి మూలకానికి ఈ మూసివేతను వర్తిస్తుంది, చివరికి ప్రారంభమవుతుంది మరియు వాటిలో ఏవైనా `true` ను తిరిగి ఇస్తే, `rfind()` [`Some(element)`] ను తిరిగి ఇస్తుంది.
    /// అవన్నీ `false` ను తిరిగి ఇస్తే, అది [`None`] ను తిరిగి ఇస్తుంది.
    ///
    /// `rfind()` షార్ట్ సర్క్యూటింగ్;మరో మాటలో చెప్పాలంటే, మూసివేత `true` ను తిరిగి ఇచ్చిన వెంటనే ఇది ప్రాసెసింగ్ ఆగిపోతుంది.
    ///
    /// ఎందుకంటే `rfind()` రిఫరెన్స్ తీసుకుంటుంది, మరియు చాలా మంది ఇరేటర్లు రిఫరెన్స్‌లపై మళ్ళిస్తారు, ఇది వాదన డబుల్ రిఫరెన్స్ అయిన గందరగోళ పరిస్థితికి దారితీస్తుంది.
    ///
    /// `&&x` తో, దిగువ ఉదాహరణలలో మీరు ఈ ప్రభావాన్ని చూడవచ్చు.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// మొదటి `true` వద్ద ఆగుతుంది:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // మరిన్ని అంశాలు ఉన్నందున మేము ఇంకా `iter` ను ఉపయోగించవచ్చు.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}