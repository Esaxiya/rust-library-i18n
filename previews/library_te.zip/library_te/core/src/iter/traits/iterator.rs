// విస్మరించు-చక్కనైన-ఫైల్లెంగ్త్ ఈ ఫైల్ దాదాపుగా `Iterator` యొక్క నిర్వచనాన్ని కలిగి ఉంటుంది.
// మేము దానిని బహుళ ఫైళ్ళగా విభజించలేము.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// ఇటరేటర్లతో వ్యవహరించడానికి ఒక ఇంటర్ఫేస్.
///
/// ఇది ప్రధాన మళ్ళి trait.
/// సాధారణంగా ఇరేటర్స్ భావన గురించి మరింత తెలుసుకోవడానికి, దయచేసి [module-level documentation] చూడండి.
/// ముఖ్యంగా, మీరు [implement `Iterator`][impl] ఎలా చేయాలో తెలుసుకోవచ్చు.
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// మూలకాల రకం మీద మళ్ళించబడుతుంది.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// ఇరేటర్‌ను అభివృద్ధి చేస్తుంది మరియు తదుపరి విలువను అందిస్తుంది.
    ///
    /// పునరావృతం పూర్తయినప్పుడు [`None`] ని అందిస్తుంది.
    /// వ్యక్తిగత పునరావృత అమలులు పునరావృతాన్ని తిరిగి ప్రారంభించటానికి ఎంచుకోవచ్చు, కాబట్టి `next()` ని మళ్లీ కాల్ చేయడం లేదా చివరికి [`Some(Item)`] ను తిరిగి ఇవ్వడం ప్రారంభించకపోవచ్చు.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // next() కి కాల్ తదుపరి విలువను అందిస్తుంది ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... ఆపై అది ముగిసిన తర్వాత ఏదీ లేదు.
    /// assert_eq!(None, iter.next());
    ///
    /// // మరిన్ని కాల్‌లు `None` ను తిరిగి ఇవ్వకపోవచ్చు.ఇక్కడ, వారు ఎల్లప్పుడూ రెడీ.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// ఇరేటర్ యొక్క మిగిలిన పొడవుపై హద్దులను అందిస్తుంది.
    ///
    /// ప్రత్యేకించి, `size_hint()` మొదటి మూలకం తక్కువ బౌండ్, మరియు రెండవ మూలకం ఎగువ బౌండ్ ఉన్న ఒక టుపుల్‌ను తిరిగి ఇస్తుంది.
    ///
    /// తిరిగి వచ్చిన టుపుల్ యొక్క రెండవ భాగం [[ఎంపిక`]`<`[`వినియోగించు`]`> `.
    /// ఇక్కడ [`None`] అంటే, ఎగువ బౌండ్ తెలియదు, లేదా ఎగువ బౌండ్ [`usize`] కన్నా పెద్దది.
    ///
    /// # అమలు గమనికలు
    ///
    /// ఇటెరేటర్ అమలు డిక్లేర్డ్ ఎలిమెంట్స్ సంఖ్యను ఇస్తుందని ఇది అమలు చేయబడదు.బగ్గీ ఇటరేటర్ తక్కువ బౌండ్ కంటే తక్కువ లేదా మూలకాల ఎగువ బౌండ్ కంటే ఎక్కువ దిగుబడిని ఇస్తుంది.
    ///
    /// `size_hint()` ఇటరేటర్ యొక్క మూలకాల కోసం స్థలాన్ని రిజర్వ్ చేయడం వంటి ఆప్టిమైజేషన్ల కోసం ఉపయోగించటానికి ప్రధానంగా ఉద్దేశించబడింది, కానీ ఉదా., అసురక్షిత కోడ్‌లో హద్దుల తనిఖీలను వదిలివేయండి.
    /// `size_hint()` యొక్క తప్పు అమలు మెమరీ భద్రతా ఉల్లంఘనలకు దారితీయకూడదు.
    ///
    /// ఇది సరైన అంచనాను అందించాలి, ఎందుకంటే ఇది trait యొక్క ప్రోటోకాల్ యొక్క ఉల్లంఘన అవుతుంది.
    ///
    /// డిఫాల్ట్ అమలు `(0,` [`ఏదీ`]`)`ను తిరిగి ఇస్తుంది, ఇది ఏదైనా మళ్ళికి సరైనది.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// మరింత క్లిష్టమైన ఉదాహరణ:
    ///
    /// ```
    /// // సున్నా నుండి పది వరకు సమాన సంఖ్యలు.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // మేము సున్నా నుండి పది రెట్లు మళ్ళించవచ్చు.
    /// // ఇది ఐదు అని తెలుసుకోవడం filter() ను అమలు చేయకుండా సాధ్యం కాదు.
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // chain() తో మరో ఐదు సంఖ్యలను చేర్చుదాం
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // ఇప్పుడు రెండు హద్దులు ఐదు పెరిగాయి
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// ఎగువ బౌండ్ కోసం `None` ని తిరిగి ఇస్తోంది:
    ///
    /// ```
    /// // అనంతమైన మళ్ళికి ఎగువ బౌండ్ లేదు మరియు గరిష్టంగా తక్కువ బౌండ్ ఉంటుంది
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// మళ్ళిని వినియోగిస్తుంది, పునరావృతాల సంఖ్యను లెక్కించి తిరిగి ఇస్తుంది.
    ///
    /// ఈ పద్ధతి [`None`] ను [`None`] ఎదుర్కొనే వరకు పదేపదే పిలుస్తుంది, ఇది [`Some`] ను ఎన్నిసార్లు చూసింది.
    /// ఇరేటర్‌కు ఏ మూలకాలు లేనప్పటికీ, [`next`] ను కనీసం ఒక్కసారైనా పిలవాలని గమనించండి.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # ఓవర్ఫ్లో బిహేవియర్
    ///
    /// ఈ పద్ధతి ఓవర్‌ఫ్లోస్‌కు రక్షణగా ఉండదు, కాబట్టి [`usize::MAX`] కంటే ఎక్కువ మూలకాలతో ఇరేటర్ యొక్క మూలకాలను లెక్కించడం తప్పు ఫలితాన్ని లేదా panics ను ఉత్పత్తి చేస్తుంది.
    ///
    /// డీబగ్ వాదనలు ప్రారంభించబడితే, panic హామీ ఇవ్వబడుతుంది.
    ///
    /// # Panics
    ///
    /// ఇరేటర్ [`usize::MAX`] కంటే ఎక్కువ మూలకాలను కలిగి ఉంటే ఈ ఫంక్షన్ panic కావచ్చు.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// చివరి మూలకాన్ని తిరిగి ఇటేరేటర్‌ను ఉపయోగిస్తుంది.
    ///
    /// [`None`] ను తిరిగి ఇచ్చేవరకు ఈ పద్ధతి ఇటరేటర్‌ను అంచనా వేస్తుంది.
    /// అలా చేస్తున్నప్పుడు, ఇది ప్రస్తుత మూలకాన్ని ట్రాక్ చేస్తుంది.
    /// [`None`] తిరిగి వచ్చిన తరువాత, `last()` అది చూసిన చివరి మూలకాన్ని తిరిగి ఇస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// `n` మూలకాల ద్వారా ఇరేటర్‌ను అభివృద్ధి చేస్తుంది.
    ///
    /// ఈ పద్ధతి [`None`] ఎదురయ్యే వరకు [`next`] ను `n` సార్లు కాల్ చేయడం ద్వారా `n` మూలకాలను ఆసక్తిగా దాటవేస్తుంది.
    ///
    /// `advance_by(n)` `n` ఎలిమెంట్స్ ద్వారా ఇరేటర్ విజయవంతంగా అభివృద్ధి చెందితే [`Ok(())`][Ok] ను తిరిగి ఇస్తుంది, లేదా [`None`] ఎదురైతే [`Err(k)`][Err], ఇక్కడ `k` అనేది ఎలిమెంట్స్ అయిపోయే ముందు ఇటరేటర్ అభివృద్ధి చేసిన మూలకాల సంఖ్య (అనగా
    /// మళ్ళి యొక్క పొడవు).
    /// `k` ఎల్లప్పుడూ `n` కన్నా తక్కువగా ఉంటుందని గమనించండి.
    ///
    /// `advance_by(0)` కి కాల్ చేస్తే ఏ మూలకాలు తినవు మరియు ఎల్లప్పుడూ [`Ok(())`][Ok] ను తిరిగి ఇస్తాయి.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // `&4` మాత్రమే దాటవేయబడింది
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// ఇరేటర్ యొక్క `n` వ మూలకాన్ని చూపుతుంది.
    ///
    /// చాలా ఇండెక్సింగ్ ఆపరేషన్ల మాదిరిగానే, కౌంట్ సున్నా నుండి మొదలవుతుంది, కాబట్టి `nth(0)` మొదటి విలువను, `nth(1)` రెండవదాన్ని తిరిగి ఇస్తుంది.
    ///
    /// అన్ని మునుపటి మూలకాలు, అలాగే తిరిగి వచ్చిన మూలకం ఇరేటర్ నుండి వినియోగించబడుతుందని గమనించండి.
    /// అంటే మునుపటి మూలకాలు విస్మరించబడతాయి మరియు అదే ఇరేటర్‌లో `nth(0)` ని పలుసార్లు కాల్ చేస్తే వేర్వేరు అంశాలు తిరిగి వస్తాయి.
    ///
    ///
    /// `nth()` `n` ఇరేటర్ యొక్క పొడవు కంటే ఎక్కువ లేదా సమానంగా ఉంటే [`None`] ను తిరిగి ఇస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// `nth()` ను అనేకసార్లు కాల్ చేస్తే ఇరేటర్ రివైండ్ చేయబడదు:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// `n + 1` కంటే తక్కువ మూలకాలు ఉంటే `None` ని తిరిగి ఇస్తోంది:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// అదే సమయంలో ప్రారంభమయ్యే ఒక ఇరేటర్‌ను సృష్టిస్తుంది, కానీ ప్రతి పునరావృతం వద్ద ఇచ్చిన మొత్తంతో అడుగు పెట్టడం.
    ///
    /// గమనిక 1: ఇచ్చిన దశతో సంబంధం లేకుండా, మళ్ళి యొక్క మొదటి మూలకం ఎల్లప్పుడూ తిరిగి ఇవ్వబడుతుంది.
    ///
    /// గమనిక 2: విస్మరించిన అంశాలు లాగబడిన సమయం నిర్ణయించబడలేదు.
    /// `StepBy` `next(), nth(step-1), nth(step-1),…` సీక్వెన్స్ లాగా ప్రవర్తిస్తుంది, కానీ సీక్వెన్స్ లాగా ప్రవర్తించడం కూడా ఉచితం
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// పనితీరు కారణాల వల్ల కొన్ని ఇటరేటర్లకు ఏ మార్గం ఉపయోగించబడుతుంది.
    /// రెండవ మార్గం ఇటెరేటర్‌ను ముందుగానే ముందుకు తీసుకువెళుతుంది మరియు మరిన్ని వస్తువులను తినవచ్చు.
    ///
    /// `advance_n_and_return_first` దీనికి సమానం:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// ఇచ్చిన దశ `0` అయితే పద్ధతి panic అవుతుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// రెండు ఇటరేటర్లను తీసుకుంటుంది మరియు రెండింటిలోనూ కొత్త ఇటరేటర్‌ను సృష్టిస్తుంది.
    ///
    /// `chain()` క్రొత్త మళ్ళిని తిరిగి ఇస్తుంది, ఇది మొదట మొదటి మళ్ళి నుండి విలువలపై మరియు రెండవ మళ్ళి నుండి విలువలపై మళ్ళిస్తుంది.
    ///
    /// మరో మాటలో చెప్పాలంటే, ఇది రెండు ఇటరేటర్లను ఒక గొలుసులో కలుపుతుంది.🔗
    ///
    /// [`once`] ఒకే విలువను ఇతర రకాల పునరుక్తి గొలుసుగా మార్చడానికి సాధారణంగా ఉపయోగిస్తారు.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `chain()` కు వాదన [`IntoIterator`] ను ఉపయోగిస్తుంది కాబట్టి, మనం [`Iterator`] గానే కాకుండా [`Iterator`] గా మార్చగల దేనినైనా పాస్ చేయవచ్చు.
    /// ఉదాహరణకు, (`&[T]`) ముక్కలు [`IntoIterator`] ను అమలు చేస్తాయి మరియు అందువల్ల నేరుగా `chain()` కు పంపవచ్చు:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// మీరు Windows API తో పని చేస్తే, మీరు [`OsStr`] ను `Vec<u16>` గా మార్చాలనుకోవచ్చు:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// జంటల ఒకే ఇరేటర్‌లోకి రెండు ఇరేటర్లను 'జిప్స్ అప్' చేయండి.
    ///
    /// `zip()` క్రొత్త ఇటరేటర్‌ను తిరిగి ఇస్తుంది, అది రెండు ఇతర ఇరేటర్‌లపై మళ్ళిస్తుంది, మొదటి మూలకం మొదటి ఇరేటర్ నుండి వస్తుంది, మరియు రెండవ మూలకం రెండవ మళ్ళి నుండి వస్తుంది.
    ///
    ///
    /// మరో మాటలో చెప్పాలంటే, ఇది రెండు ఇటరేటర్లను ఒకదానితో ఒకటి జిప్ చేస్తుంది.
    ///
    /// ఇరేటర్ [`None`] ను తిరిగి ఇస్తే, జిప్ చేసిన ఇరేటర్ నుండి [`next`] [`None`] ను తిరిగి ఇస్తుంది.
    /// మొదటి ఇరేటర్ [`None`] ను తిరిగి ఇస్తే, `zip` షార్ట్-సర్క్యూట్ అవుతుంది మరియు `next` రెండవ ఇరేటర్‌లో పిలువబడదు.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` కు వాదన [`IntoIterator`] ను ఉపయోగిస్తుంది కాబట్టి, మనం [`Iterator`] గానే కాకుండా [`Iterator`] గా మార్చగల దేనినైనా పాస్ చేయవచ్చు.
    /// ఉదాహరణకు, (`&[T]`) ముక్కలు [`IntoIterator`] ను అమలు చేస్తాయి మరియు అందువల్ల నేరుగా `zip()` కు పంపవచ్చు:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` అనంతమైన ఇటరేటర్‌ను పరిమితమైన వాటికి జిప్ చేయడానికి తరచుగా ఉపయోగిస్తారు.
    /// ఇది పనిచేస్తుంది ఎందుకంటే పరిమిత ఇటరేటర్ చివరికి [`None`] ను తిరిగి ఇస్తుంది, జిప్పర్‌తో ముగుస్తుంది.`(0..)` తో జిప్ చేయడం [`enumerate`] లాగా ఉంటుంది:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// అసలు ఇరేటర్ యొక్క ప్రక్కనే ఉన్న అంశాల మధ్య `separator` యొక్క కాపీని ఉంచే క్రొత్త ఇటరేటర్‌ను సృష్టిస్తుంది.
    ///
    /// ఒకవేళ `separator` [`Clone`] ను అమలు చేయకపోతే లేదా ప్రతిసారీ లెక్కించాల్సిన అవసరం ఉంటే, [`intersperse_with`] ను ఉపయోగించండి.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // `a` నుండి మొదటి మూలకం.
    /// assert_eq!(a.next(), Some(&100)); // విభజన.
    /// assert_eq!(a.next(), Some(&1));   // `a` నుండి తదుపరి మూలకం.
    /// assert_eq!(a.next(), Some(&100)); // విభజన.
    /// assert_eq!(a.next(), Some(&2));   // `a` నుండి చివరి మూలకం.
    /// assert_eq!(a.next(), None);       // ఇరేటర్ పూర్తయింది.
    /// ```
    ///
    /// `intersperse` సాధారణ మూలకాన్ని ఉపయోగించి ఇరేటర్ యొక్క అంశాలలో చేరడానికి చాలా ఉపయోగకరంగా ఉంటుంది:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// క్రొత్త ఇటరేటర్‌ను సృష్టిస్తుంది, ఇది `separator` ద్వారా ఉత్పత్తి చేయబడిన వస్తువును అసలు ఇరేటర్ యొక్క ప్రక్కనే ఉన్న అంశాల మధ్య ఉంచుతుంది.
    ///
    /// అంతర్లీన మళ్ళి నుండి రెండు ప్రక్కనే ఉన్న వస్తువుల మధ్య ఒక వస్తువు ఉంచిన ప్రతిసారీ మూసివేత పిలువబడుతుంది;
    /// ప్రత్యేకంగా, అంతర్లీన మళ్ళి రెండు అంశాల కంటే తక్కువ దిగుబడిని ఇస్తే మరియు చివరి వస్తువు దిగుబడి వచ్చిన తర్వాత మూసివేత అంటారు.
    ///
    ///
    /// ఇరేటర్ యొక్క అంశం [`Clone`] ను అమలు చేస్తే, [`intersperse`] ను ఉపయోగించడం సులభం కావచ్చు.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // `v` నుండి మొదటి మూలకం.
    /// assert_eq!(it.next(), Some(NotClone(99))); // విభజన.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // `v` నుండి తదుపరి మూలకం.
    /// assert_eq!(it.next(), Some(NotClone(99))); // విభజన.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // `v` నుండి చివరి మూలకం.
    /// assert_eq!(it.next(), None);               // ఇరేటర్ పూర్తయింది.
    /// ```
    ///
    /// `intersperse_with` విభజనను లెక్కించాల్సిన పరిస్థితులలో ఉపయోగించవచ్చు:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // మూసివేత ఒక వస్తువును ఉత్పత్తి చేయడానికి దాని సందర్భాన్ని పరస్పరం తీసుకుంటుంది.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// మూసివేతను తీసుకుంటుంది మరియు ప్రతి మూలకంపై ఆ మూసివేతను పిలిచే ఒక ఇరేటర్‌ను సృష్టిస్తుంది.
    ///
    /// `map()` దాని వాదన ద్వారా, ఒక ఇరేటర్‌ను మరొకదానికి మారుస్తుంది:
    /// [`FnMut`] ను అమలు చేసే ఏదో.ఇది కొత్త ఇరేటర్‌ను ఉత్పత్తి చేస్తుంది, ఇది అసలు ఇటరేటర్ యొక్క ప్రతి మూలకంపై ఈ మూసివేతను పిలుస్తుంది.
    ///
    /// మీరు రకాల్లో ఆలోచించడం మంచిది అయితే, మీరు `map()` గురించి ఇలా ఆలోచించవచ్చు:
    /// మీకు కొన్ని రకం `A` యొక్క మూలకాలను ఇచ్చే ఇటరేటర్ ఉంటే, మరియు మీకు వేరే రకం `B` యొక్క ఇరేటర్ కావాలనుకుంటే, మీరు `map()` ను ఉపయోగించవచ్చు, మూసివేతను దాటి `A` తీసుకొని `B` ను తిరిగి ఇస్తుంది.
    ///
    ///
    /// `map()` సంభావితంగా [`for`] లూప్‌తో సమానంగా ఉంటుంది.అయినప్పటికీ, `map()` సోమరితనం కాబట్టి, మీరు ఇప్పటికే ఇతర ఇటరేటర్లతో పని చేస్తున్నప్పుడు ఇది ఉత్తమంగా ఉపయోగించబడుతుంది.
    /// మీరు సైడ్ ఎఫెక్ట్ కోసం ఒక విధమైన లూపింగ్ చేస్తుంటే, `map()` కన్నా [`for`] ను ఉపయోగించడం మరింత ఇడియొమాటిక్ గా పరిగణించబడుతుంది.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// మీరు ఒక విధమైన సైడ్ ఎఫెక్ట్ చేస్తుంటే, [`for`] ను `map()` కి ఇష్టపడండి:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // దీన్ని చేయవద్దు:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // ఇది సోమరితనం అయినందున అది కూడా అమలు చేయదు.Rust దీని గురించి మిమ్మల్ని హెచ్చరిస్తుంది.
    ///
    /// // బదులుగా, వీటి కోసం ఉపయోగించండి:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// ఇటెరేటర్ యొక్క ప్రతి మూలకంపై మూసివేతను పిలుస్తుంది.
    ///
    /// మూసివేత నుండి `break` మరియు `continue` సాధ్యం కానప్పటికీ, ఇది ఇరేటర్‌లో [`for`] లూప్‌ను ఉపయోగించటానికి సమానం.
    /// ఇది సాధారణంగా `for` లూప్‌ను ఉపయోగించడం మరింత ఇడియొమాటిక్, అయితే పొడవైన ఇటరేటర్ గొలుసుల చివర వస్తువులను ప్రాసెస్ చేసేటప్పుడు `for_each` మరింత స్పష్టంగా ఉంటుంది.
    ///
    /// కొన్ని సందర్భాల్లో `for_each` కూడా లూప్ కంటే వేగంగా ఉండవచ్చు, ఎందుకంటే ఇది `Chain` వంటి ఎడాప్టర్లలో అంతర్గత పునరుక్తిని ఉపయోగిస్తుంది.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// అటువంటి చిన్న ఉదాహరణ కోసం, `for` లూప్ క్లీనర్ కావచ్చు, కానీ ఎక్కువసేపు ఇరేటర్లతో ఫంక్షనల్ స్టైల్‌ని ఉంచడానికి `for_each` మంచిది.
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// ఒక మూలకాన్ని ఇవ్వాలా వద్దా అని నిర్ణయించడానికి మూసివేతను ఉపయోగించే ఇటరేటర్‌ను సృష్టిస్తుంది.
    ///
    /// ఒక మూలకం ఇచ్చినట్లయితే మూసివేత `true` లేదా `false` ను తిరిగి ఇవ్వాలి.తిరిగి వచ్చిన ఇరేటర్ మూసివేత నిజమైనది అయిన అంశాలను మాత్రమే ఇస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `filter()` కు పంపిన మూసివేత ఒక సూచనను తీసుకుంటుంది, మరియు చాలా మంది ఇటరేటర్లు సూచనల మీద మళ్ళిస్తారు, ఇది బహుశా గందరగోళ పరిస్థితులకు దారితీస్తుంది, ఇక్కడ మూసివేత రకం డబుల్ రిఫరెన్స్:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // రెండు * లు కావాలి!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ఒకదాన్ని తీసివేయడానికి బదులుగా వాదనపై విధ్వంసాన్ని ఉపయోగించడం సాధారణం:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // &&* రెండూ
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// లేదా రెండూ:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // రెండు &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ఈ పొరలలో.
    ///
    /// `iter.filter(f).next()` `iter.find(f)` కి సమానం అని గమనించండి.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// ఫిల్టర్లు మరియు పటాలు రెండూ ఒక ఇరేటర్‌ను సృష్టిస్తుంది.
    ///
    /// తిరిగి వచ్చిన ఇరేటర్ `విలువ`లను మాత్రమే ఇస్తుంది, దీని కోసం సరఫరా చేసిన మూసివేత `Some(value)` ను అందిస్తుంది.
    ///
    /// `filter_map` [`filter`] మరియు [`map`] గొలుసులను మరింత సంక్షిప్తంగా చేయడానికి ఉపయోగించవచ్చు.
    /// దిగువ ఉదాహరణ `map().filter().map()` ను ఒకే కాల్‌కు `filter_map` కు ఎలా కుదించవచ్చో చూపిస్తుంది.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ఇక్కడ అదే ఉదాహరణ, కానీ [`filter`] మరియు [`map`] తో:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// ప్రస్తుత మళ్ళా గణనతో పాటు తదుపరి విలువను ఇచ్చే ఇటరేటర్‌ను సృష్టిస్తుంది.
    ///
    /// ఇటేరేటర్ రిటర్న్ దిగుబడి జతలు `(i, val)`, ఇక్కడ `i` ప్రస్తుత పునరుక్తి సూచిక మరియు `val` అనేది ఇరేటర్ తిరిగి ఇచ్చే విలువ.
    ///
    ///
    /// `enumerate()` దాని గణనను [`usize`] గా ఉంచుతుంది.
    /// మీరు వేరే పరిమాణ పూర్ణాంకం ద్వారా లెక్కించాలనుకుంటే, [`zip`] ఫంక్షన్ ఇలాంటి కార్యాచరణను అందిస్తుంది.
    ///
    /// # ఓవర్ఫ్లో బిహేవియర్
    ///
    /// ఈ పద్ధతి ఓవర్‌ఫ్లోస్‌కు రక్షణగా ఉండదు, కాబట్టి [`usize::MAX`] కంటే ఎక్కువ మూలకాలను లెక్కించడం తప్పు ఫలితాన్ని లేదా panics ను ఉత్పత్తి చేస్తుంది.
    /// డీబగ్ వాదనలు ప్రారంభించబడితే, panic హామీ ఇవ్వబడుతుంది.
    ///
    /// # Panics
    ///
    /// తిరిగి ఇవ్వవలసిన సూచిక [`usize`] ని పొంగిపోతే తిరిగి వచ్చిన మళ్ళి panic కావచ్చు.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// ఇటరేటర్ యొక్క తదుపరి మూలకాన్ని తినకుండా చూడటానికి [`peek`] ను ఉపయోగించగల ఒక ఇరేటర్‌ను సృష్టిస్తుంది.
    ///
    /// ఒక ఇరేటర్‌కు [`peek`] పద్ధతిని జోడిస్తుంది.మరింత సమాచారం కోసం దాని డాక్యుమెంటేషన్ చూడండి.
    ///
    /// [`peek`] ను మొదటిసారి పిలిచినప్పుడు అంతర్లీన ఇటరేటర్ ఇంకా అభివృద్ధి చెందుతుందని గమనించండి: తదుపరి మూలకాన్ని తిరిగి పొందడానికి, [`next`] ను అంతర్లీన ఇటరేటర్‌పై పిలుస్తారు, అందువల్ల ఏదైనా దుష్ప్రభావాలు (అనగా
    ///
    /// [`next`] పద్ధతి యొక్క తదుపరి విలువను పొందడం మినహా ఏదైనా జరుగుతుంది.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() future లోకి చూద్దాం
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // మేము అనేకసార్లు peek() చేయవచ్చు, మళ్ళి ముందుకు సాగదు
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // ఇరేటర్ పూర్తయిన తర్వాత, peek() కూడా ఉంటుంది
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// [`దాటవేయి] యొక్క అంశాలు icate హించిన దాని ఆధారంగా ఒక ఇరేటర్‌ను సృష్టిస్తుంది.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` మూసివేతను వాదనగా తీసుకుంటుంది.ఇది ఇటరేటర్ యొక్క ప్రతి మూలకంపై ఈ మూసివేతను పిలుస్తుంది మరియు ఇది `false` ను తిరిగి ఇచ్చేవరకు మూలకాలను విస్మరిస్తుంది.
    ///
    /// `false` తిరిగి వచ్చిన తరువాత, `skip_while()`'s ఉద్యోగం ముగిసింది, మరియు మిగిలిన అంశాలు లభిస్తాయి.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `skip_while()` కు పంపిన మూసివేత ఒక సూచనను తీసుకుంటుంది, మరియు చాలా మంది ఇటరేటర్లు రిఫరెన్స్‌లపై మళ్ళిస్తారు, ఇది బహుశా గందరగోళ పరిస్థితికి దారితీస్తుంది, ఇక్కడ మూసివేత వాదన రకం డబుల్ రిఫరెన్స్:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // రెండు * లు కావాలి!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ప్రారంభ `false` తర్వాత ఆగిపోతుంది:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // ఇది అబద్ధం అయినప్పటికీ, మనకు ఇప్పటికే తప్పుడు వచ్చింది కాబట్టి, skip_while() ఇకపై ఉపయోగించబడదు
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// ప్రిడికేట్ ఆధారంగా మూలకాలను ఇచ్చే ఇటరేటర్‌ను సృష్టిస్తుంది.
    ///
    /// `take_while()` మూసివేతను వాదనగా తీసుకుంటుంది.ఇది ఇరేటర్ యొక్క ప్రతి మూలకంపై ఈ మూసివేతను పిలుస్తుంది మరియు ఇది `true` ను తిరిగి ఇచ్చేటప్పుడు మూలకాలను ఇస్తుంది.
    ///
    /// `false` తిరిగి వచ్చిన తరువాత, `take_while()`'s ఉద్యోగం ముగిసింది, మరియు మిగిలిన అంశాలు విస్మరించబడతాయి.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take_while()` కు పంపిన మూసివేత ఒక సూచనను తీసుకుంటుంది, మరియు చాలా మంది ఇటరేటర్లు సూచనల మీద మళ్ళిస్తారు, ఇది బహుశా గందరగోళ పరిస్థితులకు దారితీస్తుంది, ఇక్కడ మూసివేత రకం డబుల్ రిఫరెన్స్:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // రెండు * లు కావాలి!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ప్రారంభ `false` తర్వాత ఆగిపోతుంది:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // మనకు సున్నా కంటే తక్కువ మూలకాలు ఉన్నాయి, కానీ మనకు ఇప్పటికే తప్పుడు వచ్చింది కాబట్టి, take_while() ఇకపై ఉపయోగించబడదు
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take_while()` విలువను చేర్చాలా వద్దా అని చూడటానికి దాని విలువను చూడవలసిన అవసరం ఉన్నందున, వినియోగించే ఇటరేటర్లు అది తీసివేయబడిందని చూస్తారు:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` ఇప్పుడు లేదు, ఎందుకంటే పునరావృతం ఆగిపోతుందా అని చూడటానికి దీనిని వినియోగించారు, కానీ తిరిగి ఇరేటర్‌లో ఉంచలేదు.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// రెండింటిని ప్రిడికేట్ మరియు మ్యాప్‌ల ఆధారంగా మూలకాలను ఇచ్చే ఇటరేటర్‌ను సృష్టిస్తుంది.
    ///
    /// `map_while()` మూసివేతను వాదనగా తీసుకుంటుంది.
    /// ఇది ఇరేటర్ యొక్క ప్రతి మూలకంపై ఈ మూసివేతను పిలుస్తుంది మరియు ఇది [`Some(_)`][`Some`] ను తిరిగి ఇచ్చేటప్పుడు మూలకాలను ఇస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ఇక్కడ అదే ఉదాహరణ, కానీ [`take_while`] మరియు [`map`] తో:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ప్రారంభ [`None`] తర్వాత ఆగిపోతుంది:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // u32 (4, 5) లో సరిపోయే మరిన్ని అంశాలు మన వద్ద ఉన్నాయి, కాని `map_while` `-3` కోసం `None` ను తిరిగి ఇచ్చింది (`predicate` `None` ను తిరిగి ఇచ్చినట్లుగా) మరియు `collect` మొదటి `None` ఎదుర్కొన్నప్పుడు ఆగుతుంది.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// `map_while()` విలువను చేర్చాలా వద్దా అని చూడటానికి దాని విలువను చూడవలసిన అవసరం ఉన్నందున, వినియోగించే ఇటరేటర్లు అది తీసివేయబడిందని చూస్తారు:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` ఇప్పుడు లేదు, ఎందుకంటే పునరావృతం ఆగిపోతుందా అని చూడటానికి దీనిని వినియోగించారు, కానీ తిరిగి ఇరేటర్‌లో ఉంచలేదు.
    ///
    /// [`take_while`] కాకుండా ఈ ఇటరేటర్ **కాదు** ఫ్యూజ్ చేయబడిందని గమనించండి.
    /// మొదటి [`None`] తిరిగి వచ్చిన తర్వాత ఈ ఇరేటర్ ఏది తిరిగి ఇస్తుందో కూడా పేర్కొనబడలేదు.
    /// మీకు ఫ్యూజ్డ్ ఇరేటర్ అవసరమైతే, [`fuse`] ఉపయోగించండి.
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// మొదటి `n` మూలకాలను దాటవేసే ఇటరేటర్‌ను సృష్టిస్తుంది.
    ///
    /// అవి తిన్న తరువాత, మిగిలిన మూలకాలు లభిస్తాయి.
    /// ఈ పద్ధతిని నేరుగా భర్తీ చేయకుండా, బదులుగా `nth` పద్ధతిని భర్తీ చేయండి.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// దాని మొదటి `n` మూలకాలను ఇచ్చే ఇటరేటర్‌ను సృష్టిస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` ఇది పరిమితంగా చేయడానికి తరచుగా అనంతమైన మళ్ళితో ఉపయోగించబడుతుంది:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `n` కన్నా తక్కువ మూలకాలు అందుబాటులో ఉంటే, `take` అంతర్లీన ఇటరేటర్ యొక్క పరిమాణానికి పరిమితం అవుతుంది:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// [`fold`] కు సమానమైన ఇరేటర్ అడాప్టర్ అంతర్గత స్థితిని కలిగి ఉంటుంది మరియు కొత్త ఇటరేటర్‌ను ఉత్పత్తి చేస్తుంది.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` రెండు వాదనలు తీసుకుంటుంది: ప్రారంభ స్థితిని అంతర్గత స్థితిని, మరియు రెండు వాదనలతో మూసివేయడం, మొదటిది అంతర్గత స్థితికి మార్చగల సూచన మరియు రెండవది మళ్ళి మూలకం.
    ///
    /// పునరావృతాల మధ్య స్థితిని పంచుకోవడానికి మూసివేత అంతర్గత స్థితికి కేటాయించవచ్చు.
    ///
    /// పునరుక్తిపై, మూసివేత మళ్ళి యొక్క ప్రతి మూలకానికి వర్తించబడుతుంది మరియు మూసివేత నుండి తిరిగి వచ్చే విలువ, [`Option`], మళ్ళి ద్వారా లభిస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // ప్రతి పునరావృతం, మేము మూలకం ద్వారా స్థితిని గుణిస్తాము
    ///     *state = *state * x;
    ///
    ///     // అప్పుడు, మేము రాష్ట్ర నిరాకరణను ఇస్తాము
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// మ్యాప్ లాగా పనిచేసే ఇటరేటర్‌ను సృష్టిస్తుంది, కాని సమూహ నిర్మాణాన్ని చదును చేస్తుంది.
    ///
    /// [`map`] అడాప్టర్ చాలా ఉపయోగకరంగా ఉంటుంది, కానీ మూసివేత వాదన విలువలను ఉత్పత్తి చేసినప్పుడు మాత్రమే.
    /// ఇది బదులుగా ఒక ఇరేటర్‌ను ఉత్పత్తి చేస్తే, అదనపు పొరల దిశ ఉంటుంది.
    /// `flat_map()` ఈ అదనపు పొరను దాని స్వంతంగా తొలగిస్తుంది.
    ///
    /// మీరు `flat_map(f)` ను [`మ్యాప్`] పింగ్ యొక్క సెమాంటిక్ సమానమైనదిగా భావించవచ్చు, ఆపై `map(f).flatten()` లో వలె [` చదును చేయండి].
    ///
    /// `flat_map()` గురించి ఆలోచించే మరో మార్గం: [`మ్యాప్`] యొక్క మూసివేత ప్రతి మూలకానికి ఒక అంశాన్ని అందిస్తుంది, మరియు `flat_map()`'s మూసివేత ప్రతి మూలకానికి ఒక ఇరేటర్‌ను అందిస్తుంది.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() మళ్ళిని అందిస్తుంది
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// సమూహ నిర్మాణాన్ని చదును చేసే ఇటరేటర్‌ను సృష్టిస్తుంది.
    ///
    /// మీకు ఇరేటర్స్ యొక్క ఇరేటర్ లేదా ఇటేరేటర్లుగా మార్చగలిగే విషయాల యొక్క ఇరేటర్ ఉన్నప్పుడు ఇది ఉపయోగపడుతుంది మరియు మీరు ఒక స్థాయి ఇండెక్షన్‌ను తొలగించాలనుకుంటున్నారు.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// మ్యాపింగ్ మరియు తరువాత చదును చేయడం:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() మళ్ళిని అందిస్తుంది
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// మీరు దీన్ని [`flat_map()`] పరంగా తిరిగి వ్రాయవచ్చు, ఇది ఉద్దేశాన్ని మరింత స్పష్టంగా తెలియజేస్తున్నందున ఈ సందర్భంలో మంచిది.
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() మళ్ళిని అందిస్తుంది
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// చదును చేయడం ఒక సమయంలో ఒక స్థాయి గూడును మాత్రమే తొలగిస్తుంది:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// `flatten()` ఒక "deep" చదును చేయదని ఇక్కడ మనం చూస్తాము.
    /// బదులుగా, ఒక స్థాయి గూడు మాత్రమే తొలగించబడుతుంది.అంటే, మీరు త్రిమితీయ శ్రేణిని `flatten()` చేస్తే, ఫలితం రెండు డైమెన్షనల్ మరియు ఒక డైమెన్షనల్ కాదు.
    /// ఒక డైమెన్షనల్ నిర్మాణాన్ని పొందడానికి, మీరు మళ్ళీ `flatten()` చేయాలి.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// మొదటి [`None`] తర్వాత ముగిసే ఇరేటర్‌ను సృష్టిస్తుంది.
    ///
    /// ఒక ఇరేటర్ [`None`] ను తిరిగి ఇచ్చిన తరువాత, future కాల్స్ [`Some(T)`] ను తిరిగి ఇవ్వకపోవచ్చు లేదా ఇవ్వకపోవచ్చు.
    /// `fuse()` ఒక ఇరేటర్‌ను అనుసరిస్తుంది, [`None`] ఇచ్చిన తర్వాత, ఇది ఎల్లప్పుడూ [`None`] ని ఎప్పటికీ తిరిగి ఇస్తుందని నిర్ధారిస్తుంది.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// // కొన్ని మరియు ఏదీ మధ్య ప్రత్యామ్నాయంగా ఉండే ఇటరేటర్
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // అది సమానంగా ఉంటే, Some(i32), లేకపోతే ఏదీ లేదు
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // మన ఇటరేటర్ ముందుకు వెనుకకు వెళ్లడాన్ని మనం చూడవచ్చు
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // అయితే, ఒకసారి మేము దానిని ఫ్యూజ్ చేసాము ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // ఇది ఎల్లప్పుడూ మొదటిసారి తర్వాత `None` ను తిరిగి ఇస్తుంది.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// ఇటరేటర్ యొక్క ప్రతి మూలకంతో ఏదో చేస్తుంది, విలువను దాటుతుంది.
    ///
    /// ఇటరేటర్లను ఉపయోగిస్తున్నప్పుడు, మీరు వాటిలో చాలాసార్లు కలిసి ఉంటారు.
    /// అటువంటి కోడ్‌లో పనిచేస్తున్నప్పుడు, పైప్‌లైన్‌లోని వివిధ భాగాలలో ఏమి జరుగుతుందో మీరు తనిఖీ చేయాలనుకోవచ్చు.అలా చేయడానికి, `inspect()` కు కాల్ చొప్పించండి.
    ///
    /// మీ తుది కోడ్‌లో ఉనికి కంటే `inspect()` ను డీబగ్గింగ్ సాధనంగా ఉపయోగించడం సర్వసాధారణం, అయితే విస్మరించడానికి ముందు లోపాలు లాగిన్ కావాల్సినప్పుడు కొన్ని సందర్భాల్లో అనువర్తనాలు ఉపయోగపడతాయి.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // ఈ మళ్ళి క్రమం సంక్లిష్టమైనది.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // ఏమి జరుగుతుందో పరిశోధించడానికి కొన్ని inspect() కాల్‌లను చేర్చుదాం
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// ఇది ముద్రించబడుతుంది:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// వాటిని విస్మరించడానికి ముందు లాగింగ్ లోపాలు:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// ఇది ముద్రించబడుతుంది:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// ఒక ఇటేరేటర్‌ను తీసుకుంటే దాన్ని తీసుకుంటుంది.
    ///
    /// అసలు ఇరేటర్ యొక్క యాజమాన్యాన్ని నిలుపుకుంటూ ఇటరేటర్ ఎడాప్టర్లను వర్తింపచేయడానికి ఇది ఉపయోగపడుతుంది.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // మేము మళ్ళీ iter ను ఉపయోగించడానికి ప్రయత్నిస్తే, అది పనిచేయదు.
    /// // కింది పంక్తి "లోపం: తరలించిన విలువ యొక్క ఉపయోగం: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // మళ్ళీ ప్రయత్నిద్దాం
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // బదులుగా, మేము .by_ref() లో చేర్చుతాము
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // ఇప్పుడు ఇది బాగానే ఉంది:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// ఇటరేటర్‌ను సేకరణగా మారుస్తుంది.
    ///
    /// `collect()` పునరుత్పాదక ఏదైనా తీసుకోవచ్చు మరియు దానిని సంబంధిత సేకరణగా మార్చవచ్చు.
    /// ప్రామాణిక లైబ్రరీలో ఇది చాలా శక్తివంతమైన పద్ధతుల్లో ఒకటి, ఇది వివిధ సందర్భాల్లో ఉపయోగించబడుతుంది.
    ///
    /// `collect()` ఉపయోగించబడే అత్యంత ప్రాధమిక నమూనా ఏమిటంటే, ఒక సేకరణను మరొక సేకరణగా మార్చడం.
    /// మీరు ఒక సేకరణ తీసుకోండి, దానిపై [`iter`] కి కాల్ చేయండి, కొంత పరివర్తనాలు చేయండి, ఆపై `collect()` చివరిలో.
    ///
    /// `collect()` సాధారణ సేకరణలు లేని రకాల ఉదాహరణలను కూడా సృష్టించవచ్చు.
    /// ఉదాహరణకు, [`చార్`] నుండి [`String`] ను నిర్మించవచ్చు మరియు [`Result<T, E>`][`Result`] అంశాల యొక్క ఇరేటర్‌ను `Result<Collection<T>, E>` లోకి సేకరించవచ్చు.
    ///
    /// మరిన్ని వివరాల కోసం క్రింది ఉదాహరణలు చూడండి.
    ///
    /// `collect()` చాలా సాధారణమైనందున, ఇది రకం అనుమితితో సమస్యలను కలిగిస్తుంది.
    /// అందుకని, 'turbofish' అని పిలువబడే సింటాక్స్ ను మీరు ప్రేమగా చూసే కొన్ని సార్లు `collect()` ఒకటి: `::<>`.
    /// మీరు ఏ సేకరణలో సేకరించడానికి ప్రయత్నిస్తున్నారో ప్రత్యేకంగా అర్థం చేసుకోవడానికి ఇది అనుమితి అల్గోరిథంకు సహాయపడుతుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// మాకు ఎడమ వైపు `: Vec<i32>` అవసరమని గమనించండి.ఎందుకంటే మనం బదులుగా [`VecDeque<T>`] లోకి సేకరించవచ్చు:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// `doubled` ను ఉల్లేఖించడానికి బదులుగా 'turbofish' ను ఉపయోగించడం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// `collect()` మీరు సేకరించే వాటి గురించి మాత్రమే పట్టించుకుంటుంది కాబట్టి, మీరు టర్బో ఫిష్‌తో `_` అనే పాక్షిక రకం సూచనను ఇప్పటికీ ఉపయోగించవచ్చు:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// [`String`] చేయడానికి `collect()` ని ఉపయోగించడం:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// మీకు [`ఫలితం 'జాబితా ఉంటే<T, E>`][`ఫలితం`], వాటిలో ఏమైనా విఫలమయ్యాయో లేదో చూడటానికి మీరు `collect()` ను ఉపయోగించవచ్చు:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // మాకు మొదటి లోపం ఇస్తుంది
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // మాకు సమాధానాల జాబితాను ఇస్తుంది
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// ఒక ఇరేటర్‌ను తీసుకుంటుంది, దాని నుండి రెండు సేకరణలను సృష్టిస్తుంది.
    ///
    /// `partition()` కు పంపిన ప్రిడికేట్ `true` లేదా `false` ను తిరిగి ఇవ్వగలదు.
    /// `partition()` ఒక జతని అందిస్తుంది, ఇది `true` ను తిరిగి ఇచ్చిన అన్ని అంశాలు మరియు `false` ను తిరిగి ఇచ్చిన అన్ని అంశాలు.
    ///
    ///
    /// [`is_partitioned()`] మరియు [`partition_in_place()`] కూడా చూడండి.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// ఇచ్చిన ప్రిడికేట్ ప్రకారం ఈ ఇరేటర్ *ఇన్-ప్లేస్* యొక్క మూలకాలను క్రమాన్ని మారుస్తుంది, అంటే `true` ను తిరిగి ఇచ్చేవారందరూ `false` ను తిరిగి ఇచ్చే అన్నింటికంటే ముందు ఉంటారు.
    ///
    /// కనుగొనబడిన `true` మూలకాల సంఖ్యను అందిస్తుంది.
    ///
    /// విభజన చేయబడిన వస్తువుల సాపేక్ష క్రమం నిర్వహించబడదు.
    ///
    /// [`is_partitioned()`] మరియు [`partition()`] కూడా చూడండి.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // ఈవ్న్స్ మరియు అసమానత మధ్య విభజన
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: గణన పొంగిపొర్లుతున్నట్లు మనం ఆందోళన చెందాలా?కంటే ఎక్కువ కలిగి ఉన్న ఏకైక మార్గం
        // `usize::MAX` మార్చగల సూచనలు విభజనకు ఉపయోగపడని ZST లతో ఉన్నాయి ...

        // `Self` లో సాధారణతను నివారించడానికి ఈ మూసివేత "factory" విధులు ఉన్నాయి.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // మొదటి `false` ను పదేపదే కనుగొని, చివరి `true` తో మార్చుకోండి.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// ఈ ఇటిరేటర్ యొక్క మూలకాలు ఇచ్చిన ప్రిడికేట్ ప్రకారం విభజించబడిందో లేదో తనిఖీ చేస్తుంది, అంటే `true` ను తిరిగి ఇచ్చేవన్నీ `false` ను తిరిగి ఇచ్చే అన్నింటికంటే ముందు ఉంటాయి.
    ///
    ///
    /// [`partition()`] మరియు [`partition_in_place()`] కూడా చూడండి.
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // అన్ని అంశాలు `true` ను పరీక్షిస్తాయి లేదా మొదటి నిబంధన `false` వద్ద ఆగుతుంది మరియు ఆ తర్వాత ఎక్కువ `true` అంశాలు లేవని మేము తనిఖీ చేస్తాము.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// ఒక ఫంక్షన్ విజయవంతంగా తిరిగి వచ్చినంత వరకు వర్తించే ఒక ఇరేటర్ పద్ధతి, ఒకే, తుది విలువను ఉత్పత్తి చేస్తుంది.
    ///
    /// `try_fold()` రెండు వాదనలు తీసుకుంటుంది: ప్రారంభ విలువ మరియు రెండు వాదనలతో మూసివేత: ఒక 'accumulator' మరియు మూలకం.
    /// మూసివేత విజయవంతంగా తిరిగి వస్తుంది, తదుపరి పునరావృతం కోసం సంచితం కలిగివున్న విలువతో, లేదా అది వైఫల్యాన్ని తిరిగి ఇస్తుంది, లోపం విలువతో వెంటనే (short-circuiting) కాలర్‌కు తిరిగి ప్రచారం చేయబడుతుంది.
    ///
    ///
    /// ప్రారంభ విలువ అనేది మొదటి కాల్‌లో సంచితానికి ఉండే విలువ.మూసివేతను వర్తింపజేయడం ఇరేటర్ యొక్క ప్రతి మూలకానికి వ్యతిరేకంగా విజయవంతమైతే, `try_fold()` తుది సంచితాన్ని విజయంగా అందిస్తుంది.
    ///
    /// మీకు ఏదైనా సేకరణ ఉన్నప్పుడల్లా మడత ఉపయోగపడుతుంది మరియు దాని నుండి ఒకే విలువను ఉత్పత్తి చేయాలనుకుంటుంది.
    ///
    /// # అమలు చేసేవారికి గమనిక
    ///
    /// అనేక ఇతర (forward) పద్ధతులు ఈ పరంగా డిఫాల్ట్ అమలులను కలిగి ఉన్నాయి, కాబట్టి ఇది డిఫాల్ట్ `for` లూప్ అమలు కంటే మెరుగైన పని చేయగలిగితే దీన్ని స్పష్టంగా అమలు చేయడానికి ప్రయత్నించండి.
    ///
    /// ముఖ్యంగా, ఈ ఇరేటర్ కంపోజ్ చేసిన అంతర్గత భాగాలపై ఈ కాల్ `try_fold()` ను కలిగి ఉండటానికి ప్రయత్నించండి.
    /// బహుళ కాల్‌లు అవసరమైతే, సంచిత విలువను కలుపుటకు `?` ఆపరేటర్ సౌకర్యవంతంగా ఉండవచ్చు, కాని ఆ ప్రారంభ రాబడికి ముందు సమర్థించాల్సిన ఏవైనా మార్పులను జాగ్రత్త వహించండి.
    /// ఇది `&mut self` పద్ధతి, కాబట్టి ఇక్కడ లోపం కొట్టిన తర్వాత పునరావృతం తిరిగి ప్రారంభించాల్సిన అవసరం ఉంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // శ్రేణి యొక్క అన్ని మూలకాల యొక్క తనిఖీ చేసిన మొత్తం
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // 100 మూలకాన్ని జోడించేటప్పుడు ఈ మొత్తం పొంగిపోతుంది
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // ఇది షార్ట్ సర్క్యూట్ అయినందున, మిగిలిన అంశాలు ఇప్పటికీ ఇరేటర్ ద్వారా అందుబాటులో ఉన్నాయి.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// ఇటెరేటర్‌లోని ప్రతి అంశానికి తప్పుదోవ పట్టించే ఫంక్షన్‌ను వర్తించే ఇటేరేటర్ పద్ధతి, మొదటి లోపం వద్ద ఆగి ఆ లోపాన్ని తిరిగి ఇస్తుంది.
    ///
    ///
    /// ఇది [`for_each()`] యొక్క తప్పు రూపంగా లేదా [`try_fold()`] యొక్క స్థితిలేని సంస్కరణగా కూడా భావించవచ్చు.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // ఇది షార్ట్ సర్క్యూట్ చేయబడింది, కాబట్టి మిగిలిన అంశాలు ఇప్పటికీ ఇరేటర్‌లో ఉన్నాయి:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// ఆపరేషన్ను వర్తింపజేయడం ద్వారా ప్రతి మూలకాన్ని సంచితంగా మడతపెట్టి, తుది ఫలితాన్ని ఇస్తుంది.
    ///
    /// `fold()` రెండు వాదనలు తీసుకుంటుంది: ప్రారంభ విలువ మరియు రెండు వాదనలతో మూసివేత: ఒక 'accumulator' మరియు మూలకం.
    /// మూసివేత తదుపరి పునరావృతం కోసం సంచితం కలిగి ఉన్న విలువను తిరిగి ఇస్తుంది.
    ///
    /// ప్రారంభ విలువ అనేది మొదటి కాల్‌లో సంచితానికి ఉండే విలువ.
    ///
    /// ఇటరేటర్ యొక్క ప్రతి మూలకానికి ఈ మూసివేతను వర్తింపజేసిన తరువాత, `fold()` సంచితాన్ని తిరిగి ఇస్తుంది.
    ///
    /// ఈ ఆపరేషన్‌ను కొన్నిసార్లు 'reduce' లేదా 'inject' అంటారు.
    ///
    /// మీకు ఏదైనా సేకరణ ఉన్నప్పుడల్లా మడత ఉపయోగపడుతుంది మరియు దాని నుండి ఒకే విలువను ఉత్పత్తి చేయాలనుకుంటుంది.
    ///
    /// Note: `fold()`, మరియు మొత్తం ఇటరేటర్‌లో ప్రయాణించే సారూప్య పద్ధతులు, అనంతమైన ఇరేటర్‌ల కోసం, traits లో కూడా ముగించబడవు, దీని కోసం ఫలితం పరిమిత సమయంలో నిర్ణయించబడుతుంది.
    ///
    /// Note: సంచిత రకం మరియు ఐటెమ్ రకం ఒకేలా ఉంటే, మొదటి మూలకాన్ని ప్రారంభ విలువగా ఉపయోగించడానికి [`reduce()`] ఉపయోగించవచ్చు.
    ///
    /// # అమలు చేసేవారికి గమనిక
    ///
    /// అనేక ఇతర (forward) పద్ధతులు ఈ పరంగా డిఫాల్ట్ అమలులను కలిగి ఉన్నాయి, కాబట్టి ఇది డిఫాల్ట్ `for` లూప్ అమలు కంటే మెరుగైన పని చేయగలిగితే దీన్ని స్పష్టంగా అమలు చేయడానికి ప్రయత్నించండి.
    ///
    ///
    /// ముఖ్యంగా, ఈ ఇరేటర్ కంపోజ్ చేసిన అంతర్గత భాగాలపై ఈ కాల్ `fold()` ను కలిగి ఉండటానికి ప్రయత్నించండి.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // శ్రేణి యొక్క అన్ని మూలకాల మొత్తం
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// పునరుక్తి యొక్క ప్రతి దశలో ఇక్కడ నడుద్దాం:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// కాబట్టి, మా తుది ఫలితం, `6`.
    ///
    /// ఇటరేటర్లను ఎక్కువగా ఉపయోగించని వ్యక్తులు ఫలితాన్ని రూపొందించడానికి విషయాల జాబితాతో `for` లూప్‌ను ఉపయోగించడం సాధారణం.వాటిని `fold()`s గా మార్చవచ్చు:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // లూప్ కోసం:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // వారు ఒకటే
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// తగ్గించే ఆపరేషన్‌ను పదేపదే వర్తింపజేయడం ద్వారా మూలకాలను ఒకే ఒక్కదానికి తగ్గిస్తుంది.
    ///
    /// ఇరేటర్ ఖాళీగా ఉంటే, [`None`] ను తిరిగి ఇస్తుంది;లేకపోతే, తగ్గింపు ఫలితాన్ని అందిస్తుంది.
    ///
    /// కనీసం ఒక మూలకం ఉన్న ఇటరేటర్లకు, ఇది ప్రారంభ విలువ వలె ఇరేటర్ యొక్క మొదటి మూలకంతో [`fold()`] కి సమానం, ప్రతి తదుపరి మూలకాన్ని దానిలోకి మడవగలదు.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// గరిష్ట విలువను కనుగొనండి:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// ఇరేటర్ యొక్క ప్రతి మూలకం ప్రిడికేట్‌తో సరిపోలితే పరీక్షలు.
    ///
    /// `all()` `true` లేదా `false` ను తిరిగి ఇచ్చే మూసివేతను తీసుకుంటుంది.ఇది ఇటరేటర్ యొక్క ప్రతి మూలకానికి ఈ మూసివేతను వర్తిస్తుంది మరియు అవన్నీ `true` ను తిరిగి ఇస్తే, అప్పుడు `all()` కూడా చేస్తుంది.
    /// వాటిలో ఏవైనా `false` ను తిరిగి ఇస్తే, అది `false` ను తిరిగి ఇస్తుంది.
    ///
    /// `all()` షార్ట్ సర్క్యూటింగ్;మరో మాటలో చెప్పాలంటే, ఇది `false` ను కనుగొన్న వెంటనే ప్రాసెసింగ్ ఆపివేస్తుంది, వేరే ఏమి జరిగినా, ఫలితం కూడా `false` అవుతుంది.
    ///
    ///
    /// ఖాళీ ఇరేటర్ `true` ను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// మొదటి `false` వద్ద ఆగుతుంది:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // మరిన్ని అంశాలు ఉన్నందున మేము ఇంకా `iter` ను ఉపయోగించవచ్చు.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// ఇరేటర్ యొక్క ఏదైనా మూలకం ప్రిడికేట్‌తో సరిపోలితే పరీక్షలు.
    ///
    /// `any()` `true` లేదా `false` ను తిరిగి ఇచ్చే మూసివేతను తీసుకుంటుంది.ఇది ఇటరేటర్ యొక్క ప్రతి మూలకానికి ఈ మూసివేతను వర్తింపజేస్తుంది మరియు వాటిలో ఏవైనా `true` ను తిరిగి ఇస్తే, అప్పుడు `any()` కూడా చేస్తుంది.
    /// అవన్నీ `false` ను తిరిగి ఇస్తే, అది `false` ను తిరిగి ఇస్తుంది.
    ///
    /// `any()` షార్ట్ సర్క్యూటింగ్;మరో మాటలో చెప్పాలంటే, ఇది `true` ను కనుగొన్న వెంటనే ప్రాసెసింగ్ ఆపివేస్తుంది, వేరే ఏమి జరిగినా, ఫలితం కూడా `true` అవుతుంది.
    ///
    ///
    /// ఖాళీ ఇరేటర్ `false` ను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// మొదటి `true` వద్ద ఆగుతుంది:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // మరిన్ని అంశాలు ఉన్నందున మేము ఇంకా `iter` ను ఉపయోగించవచ్చు.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Ic హించిన దాన్ని సంతృప్తిపరిచే ఇటరేటర్ యొక్క మూలకం కోసం శోధిస్తుంది.
    ///
    /// `find()` `true` లేదా `false` ను తిరిగి ఇచ్చే మూసివేతను తీసుకుంటుంది.
    /// ఇది ఇటరేటర్ యొక్క ప్రతి మూలకానికి ఈ మూసివేతను వర్తింపజేస్తుంది మరియు వాటిలో ఏవైనా `true` ను తిరిగి ఇస్తే, `find()` [`Some(element)`] ను తిరిగి ఇస్తుంది.
    /// అవన్నీ `false` ను తిరిగి ఇస్తే, అది [`None`] ను తిరిగి ఇస్తుంది.
    ///
    /// `find()` షార్ట్ సర్క్యూటింగ్;మరో మాటలో చెప్పాలంటే, మూసివేత `true` ను తిరిగి ఇచ్చిన వెంటనే ఇది ప్రాసెసింగ్ ఆగిపోతుంది.
    ///
    /// ఎందుకంటే `find()` రిఫరెన్స్ తీసుకుంటుంది, మరియు చాలా మంది ఇరేటర్లు రిఫరెన్స్‌లపై మళ్ళిస్తారు, ఇది వాదన డబుల్ రిఫరెన్స్ అయిన గందరగోళ పరిస్థితికి దారితీస్తుంది.
    ///
    /// `&&x` తో, దిగువ ఉదాహరణలలో మీరు ఈ ప్రభావాన్ని చూడవచ్చు.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// మొదటి `true` వద్ద ఆగుతుంది:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // మరిన్ని అంశాలు ఉన్నందున మేము ఇంకా `iter` ను ఉపయోగించవచ్చు.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// `iter.find(f)` `iter.filter(f).next()` కి సమానం అని గమనించండి.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// ఇరేటర్ యొక్క మూలకాలకు ఫంక్షన్‌ను వర్తింపజేస్తుంది మరియు మొదటిది కాని ఫలితాన్ని అందిస్తుంది.
    ///
    ///
    /// `iter.find_map(f)` `iter.filter_map(f).next()` కు సమానం.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// ఇరేటర్ యొక్క మూలకాలకు ఫంక్షన్‌ను వర్తింపజేస్తుంది మరియు మొదటి నిజమైన ఫలితం లేదా మొదటి లోపాన్ని అందిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// ఇటరేటర్‌లోని మూలకం కోసం శోధిస్తుంది, దాని సూచికను తిరిగి ఇస్తుంది.
    ///
    /// `position()` `true` లేదా `false` ను తిరిగి ఇచ్చే మూసివేతను తీసుకుంటుంది.
    /// ఇది ఇటరేటర్ యొక్క ప్రతి మూలకానికి ఈ మూసివేతను వర్తిస్తుంది మరియు వాటిలో ఒకటి `true` ను తిరిగి ఇస్తే, `position()` [`Some(index)`] ను తిరిగి ఇస్తుంది.
    /// ఇవన్నీ `false` ను తిరిగి ఇస్తే, అది [`None`] ను తిరిగి ఇస్తుంది.
    ///
    /// `position()` షార్ట్ సర్క్యూటింగ్;మరో మాటలో చెప్పాలంటే, ఇది `true` ను కనుగొన్న వెంటనే ప్రాసెసింగ్ ఆగిపోతుంది.
    ///
    /// # ఓవర్ఫ్లో బిహేవియర్
    ///
    /// ఈ పద్ధతి ఓవర్‌ఫ్లోస్‌కు రక్షణగా ఉండదు, కాబట్టి [`usize::MAX`] కంటే ఎక్కువ సరిపోలని అంశాలు ఉంటే, అది తప్పు ఫలితాన్ని ఇస్తుంది లేదా panics.
    ///
    /// డీబగ్ వాదనలు ప్రారంభించబడితే, panic హామీ ఇవ్వబడుతుంది.
    ///
    /// # Panics
    ///
    /// ఇరేటర్‌లో `usize::MAX` కంటే ఎక్కువ సరిపోలని అంశాలు ఉంటే ఈ ఫంక్షన్ panic కావచ్చు.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// మొదటి `true` వద్ద ఆగుతుంది:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // మరిన్ని అంశాలు ఉన్నందున మేము ఇంకా `iter` ను ఉపయోగించవచ్చు.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // తిరిగి వచ్చిన సూచిక ఇటరేటర్ స్థితిపై ఆధారపడి ఉంటుంది
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// కుడివైపు నుండి ఇటరేటర్‌లోని మూలకం కోసం శోధిస్తుంది, దాని సూచికను తిరిగి ఇస్తుంది.
    ///
    /// `rposition()` `true` లేదా `false` ను తిరిగి ఇచ్చే మూసివేతను తీసుకుంటుంది.
    /// ఇది చివరి నుండి ప్రారంభమయ్యే ఇటిరేటర్ యొక్క ప్రతి మూలకానికి ఈ మూసివేతను వర్తిస్తుంది మరియు వాటిలో ఒకటి `true` ను తిరిగి ఇస్తే, `rposition()` [`Some(index)`] ను తిరిగి ఇస్తుంది.
    ///
    /// ఇవన్నీ `false` ను తిరిగి ఇస్తే, అది [`None`] ను తిరిగి ఇస్తుంది.
    ///
    /// `rposition()` షార్ట్ సర్క్యూటింగ్;మరో మాటలో చెప్పాలంటే, ఇది `true` ను కనుగొన్న వెంటనే ప్రాసెసింగ్ ఆగిపోతుంది.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// మొదటి `true` వద్ద ఆగుతుంది:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // మరిన్ని అంశాలు ఉన్నందున మేము ఇంకా `iter` ను ఉపయోగించవచ్చు.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // ఇక్కడ ఓవర్ఫ్లో చెక్ అవసరం లేదు, ఎందుకంటే `ExactSizeIterator` మూలకాల సంఖ్య `usize` లోకి సరిపోతుందని సూచిస్తుంది.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// మళ్ళి యొక్క గరిష్ట మూలకాన్ని అందిస్తుంది.
    ///
    /// అనేక అంశాలు సమానంగా గరిష్టంగా ఉంటే, చివరి మూలకం తిరిగి ఇవ్వబడుతుంది.
    /// ఇరేటర్ ఖాళీగా ఉంటే, [`None`] తిరిగి ఇవ్వబడుతుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// ఇరేటర్ యొక్క కనీస మూలకాన్ని అందిస్తుంది.
    ///
    /// అనేక అంశాలు సమానంగా కనిష్టంగా ఉంటే, మొదటి మూలకం తిరిగి ఇవ్వబడుతుంది.
    /// ఇరేటర్ ఖాళీగా ఉంటే, [`None`] తిరిగి ఇవ్వబడుతుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// పేర్కొన్న ఫంక్షన్ నుండి గరిష్ట విలువను ఇచ్చే మూలకాన్ని అందిస్తుంది.
    ///
    ///
    /// అనేక అంశాలు సమానంగా గరిష్టంగా ఉంటే, చివరి మూలకం తిరిగి ఇవ్వబడుతుంది.
    /// ఇరేటర్ ఖాళీగా ఉంటే, [`None`] తిరిగి ఇవ్వబడుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// పేర్కొన్న పోలిక ఫంక్షన్‌కు సంబంధించి గరిష్ట విలువను ఇచ్చే మూలకాన్ని అందిస్తుంది.
    ///
    ///
    /// అనేక అంశాలు సమానంగా గరిష్టంగా ఉంటే, చివరి మూలకం తిరిగి ఇవ్వబడుతుంది.
    /// ఇరేటర్ ఖాళీగా ఉంటే, [`None`] తిరిగి ఇవ్వబడుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// పేర్కొన్న ఫంక్షన్ నుండి కనీస విలువను ఇచ్చే మూలకాన్ని అందిస్తుంది.
    ///
    ///
    /// అనేక అంశాలు సమానంగా కనిష్టంగా ఉంటే, మొదటి మూలకం తిరిగి ఇవ్వబడుతుంది.
    /// ఇరేటర్ ఖాళీగా ఉంటే, [`None`] తిరిగి ఇవ్వబడుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// పేర్కొన్న పోలిక ఫంక్షన్‌కు సంబంధించి కనీస విలువను ఇచ్చే మూలకాన్ని అందిస్తుంది.
    ///
    ///
    /// అనేక అంశాలు సమానంగా కనిష్టంగా ఉంటే, మొదటి మూలకం తిరిగి ఇవ్వబడుతుంది.
    /// ఇరేటర్ ఖాళీగా ఉంటే, [`None`] తిరిగి ఇవ్వబడుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// ఇరేటర్ యొక్క దిశను తిరగరాస్తుంది.
    ///
    /// సాధారణంగా, ఇటరేటర్లు ఎడమ నుండి కుడికి మళ్ళిస్తారు.
    /// `rev()` ఉపయోగించిన తరువాత, ఒక మళ్ళి బదులుగా కుడి నుండి ఎడమకు మళ్ళిస్తుంది.
    ///
    /// ఇరేటర్‌కు ముగింపు ఉంటేనే ఇది సాధ్యమవుతుంది, కాబట్టి `rev()` [`DoubleEndedIterator`] లలో మాత్రమే పనిచేస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// జతల ఇటరేటర్‌ను ఒక జత కంటైనర్‌లుగా మారుస్తుంది.
    ///
    /// `unzip()` జతల యొక్క మొత్తం ఇరేటర్‌ను వినియోగిస్తుంది, రెండు సేకరణలను ఉత్పత్తి చేస్తుంది: ఒకటి జతల ఎడమ మూలకాల నుండి మరియు ఒకటి కుడి మూలకాల నుండి.
    ///
    ///
    /// ఈ ఫంక్షన్ కొంత కోణంలో, [`zip`] కి వ్యతిరేకం.
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// దాని మూలకాలన్నింటినీ కాపీ చేసే ఇటరేటర్‌ను సృష్టిస్తుంది.
    ///
    /// మీకు `&T` కంటే ఎక్కువ ఇరేటర్ ఉన్నప్పుడు ఇది ఉపయోగపడుతుంది, కానీ మీకు `T` కన్నా ఎక్కువ ఇరేటర్ అవసరం.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // కాపీ చేయబడినది .map(|&x| x) వలె ఉంటుంది
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// [`క్లోన్`] దాని మూలకాలన్నింటిని ఇటేరేటర్‌ను సృష్టిస్తుంది.
    ///
    /// మీకు `&T` కంటే ఎక్కువ ఇరేటర్ ఉన్నప్పుడు ఇది ఉపయోగపడుతుంది, కానీ మీకు `T` కన్నా ఎక్కువ ఇరేటర్ అవసరం.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // పూర్ణాంకాల కోసం క్లోన్ చేయబడినది .map(|&x| x) వలె ఉంటుంది
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// ఇటరేటర్‌ను అనంతంగా పునరావృతం చేస్తుంది.
    ///
    /// [`None`] వద్ద ఆపడానికి బదులుగా, ఇరేటర్ మొదటి నుండి మళ్ళీ ప్రారంభమవుతుంది.మళ్ళీ మళ్ళించిన తరువాత, ఇది మళ్ళీ ప్రారంభంలో ప్రారంభమవుతుంది.మరలా.
    /// మరలా.
    /// Forever.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// మళ్ళి యొక్క మూలకాలను సంక్షిప్తం చేస్తుంది.
    ///
    /// ప్రతి మూలకాన్ని తీసుకుంటుంది, వాటిని కలుపుతుంది మరియు ఫలితాన్ని ఇస్తుంది.
    ///
    /// ఖాళీ ఇరేటర్ రకం యొక్క సున్నా విలువను తిరిగి ఇస్తుంది.
    ///
    /// # Panics
    ///
    /// `sum()` కి కాల్ చేసినప్పుడు మరియు ఆదిమ పూర్ణాంక రకాన్ని తిరిగి ఇస్తున్నప్పుడు, గణన ఓవర్ఫ్లో మరియు డీబగ్ వాదనలు ప్రారంభించబడితే ఈ పద్ధతి panic అవుతుంది.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// మొత్తం ఇటెరేటర్‌పై మళ్ళి, అన్ని అంశాలను గుణించాలి
    ///
    /// ఖాళీ ఇరేటర్ రకం యొక్క ఒక విలువను తిరిగి ఇస్తుంది.
    ///
    /// # Panics
    ///
    /// `product()` కి కాల్ చేసినప్పుడు మరియు ఆదిమ పూర్ణాంక రకాన్ని తిరిగి ఇస్తున్నప్పుడు, గణన ఓవర్ఫ్లోలు మరియు డీబగ్ వాదనలు ప్రారంభించబడితే పద్ధతి panic అవుతుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ఈ [`Iterator`] యొక్క మూలకాలను మరొకదానితో పోలుస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) పేర్కొన్న పోలిక ఫంక్షన్‌కు సంబంధించి ఈ [`Iterator`] యొక్క మూలకాలను మరొకటితో పోలుస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ఈ [`Iterator`] యొక్క మూలకాలను మరొకదానితో పోలుస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) పేర్కొన్న పోలిక ఫంక్షన్‌కు సంబంధించి ఈ [`Iterator`] యొక్క మూలకాలను మరొకటితో పోలుస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// ఈ [`Iterator`] యొక్క మూలకాలు మరొకదానికి సమానంగా ఉన్నాయో లేదో నిర్ణయిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// పేర్కొన్న సమానత్వ ఫంక్షన్‌కు సంబంధించి ఈ [`Iterator`] యొక్క మూలకాలు మరొకదానికి సమానంగా ఉన్నాయో లేదో నిర్ణయిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// ఈ [`Iterator`] యొక్క మూలకాలు మరొకదానికి అసమానంగా ఉన్నాయో లేదో నిర్ణయిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// ఈ [`Iterator`] యొక్క మూలకాలు మరొకటి కంటే [lexicographically](Ord#lexicographical-comparison) తక్కువగా ఉన్నాయో లేదో నిర్ణయిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// ఈ [`Iterator`] యొక్క మూలకాలు [lexicographically](Ord#lexicographical-comparison) తక్కువ లేదా మరొకదానికి సమానంగా ఉన్నాయో లేదో నిర్ణయిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// ఈ [`Iterator`] యొక్క మూలకాలు మరొకటి కంటే [lexicographically](Ord#lexicographical-comparison) ఎక్కువగా ఉన్నాయో లేదో నిర్ణయిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// ఈ [`Iterator`] యొక్క మూలకాలు [lexicographically](Ord#lexicographical-comparison) మరొకటి కంటే ఎక్కువ లేదా సమానంగా ఉన్నాయో లేదో నిర్ణయిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// ఈ ఇటరేటర్ యొక్క అంశాలు క్రమబద్ధీకరించబడిందో లేదో తనిఖీ చేస్తుంది.
    ///
    /// అంటే, ప్రతి మూలకం `a` మరియు దాని క్రింది మూలకం `b` కోసం, `a <= b` తప్పనిసరిగా కలిగి ఉండాలి.ఇరేటర్ సరిగ్గా సున్నా లేదా ఒక మూలకాన్ని ఇస్తే, `true` తిరిగి వస్తుంది.
    ///
    /// `Self::Item` అనేది `PartialOrd` మాత్రమే, కానీ `Ord` కాకపోతే, పైన పేర్కొన్న నిర్వచనం ఏదైనా రెండు వరుస వస్తువులను పోల్చలేకపోతే ఈ ఫంక్షన్ `false` ను తిరిగి ఇస్తుందని సూచిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// ఇచ్చిన కంపారిటర్ ఫంక్షన్‌ను ఉపయోగించి ఈ ఇరేటర్ యొక్క మూలకాలు క్రమబద్ధీకరించబడిందా అని తనిఖీ చేస్తుంది.
    ///
    /// `PartialOrd::partial_cmp` ను ఉపయోగించటానికి బదులుగా, ఈ ఫంక్షన్ రెండు మూలకాల క్రమాన్ని నిర్ణయించడానికి ఇచ్చిన `compare` ఫంక్షన్‌ను ఉపయోగిస్తుంది.
    /// అలా కాకుండా, ఇది [`is_sorted`] కి సమానం;మరింత సమాచారం కోసం దాని డాక్యుమెంటేషన్ చూడండి.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// ఇచ్చిన కీ వెలికితీత ఫంక్షన్‌ను ఉపయోగించి ఈ ఇరేటర్ యొక్క మూలకాలు క్రమబద్ధీకరించబడిందా అని తనిఖీ చేస్తుంది.
    ///
    /// ఇరేటర్ యొక్క మూలకాలను నేరుగా పోల్చడానికి బదులుగా, ఈ ఫంక్షన్ మూలకాల యొక్క కీలను `f` నిర్ణయించినట్లు పోలుస్తుంది.
    /// అలా కాకుండా, ఇది [`is_sorted`] కి సమానం;మరింత సమాచారం కోసం దాని డాక్యుమెంటేషన్ చూడండి.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// [TrustedRandomAccess] చూడండి
    // పద్ధతి రిజల్యూషన్‌లో పేరు గుద్దుకోవడాన్ని నివారించడం అసాధారణ పేరు #76479 చూడండి.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}