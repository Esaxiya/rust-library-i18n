use crate::iter;
use crate::num::Wrapping;

/// ఇటరేటర్‌ను సంక్షిప్తం చేయడం ద్వారా సృష్టించగల రకాలను సూచించడానికి Trait.
///
/// ఈ trait ఇటరేటర్లలో [`sum()`] పద్ధతిని అమలు చేయడానికి ఉపయోగించబడుతుంది.
/// trait ను అమలు చేసే రకాలను [`sum()`] పద్ధతి ద్వారా ఉత్పత్తి చేయవచ్చు.
/// [`FromIterator`] మాదిరిగా ఈ trait ను అరుదుగా నేరుగా పిలుస్తారు మరియు బదులుగా [`Iterator::sum()`] ద్వారా సంకర్షణ చెందాలి.
///
///
/// [`sum()`]: Sum::sum
/// [`FromIterator`]: iter::FromIterator
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Sum<A = Self>: Sized {
    /// ఒక ఇరేటర్‌ను తీసుకొని, మూలకాల నుండి "summing up" ద్వారా `Self` ను ఉత్పత్తి చేసే విధానం.
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn sum<I: Iterator<Item = A>>(iter: I) -> Self;
}

/// ఇటరేటర్ యొక్క మూలకాలను గుణించడం ద్వారా సృష్టించగల రకాలను సూచించడానికి Trait.
///
/// ఈ trait ఇటరేటర్లలో [`product()`] పద్ధతిని అమలు చేయడానికి ఉపయోగించబడుతుంది.
/// trait ను అమలు చేసే రకాలను [`product()`] పద్ధతి ద్వారా ఉత్పత్తి చేయవచ్చు.
/// [`FromIterator`] మాదిరిగా ఈ trait ను అరుదుగా నేరుగా పిలుస్తారు మరియు బదులుగా [`Iterator::product()`] ద్వారా సంకర్షణ చెందాలి.
///
///
/// [`product()`]: Product::product
/// [`FromIterator`]: iter::FromIterator
///
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Product<A = Self>: Sized {
    /// ఐటెరేటర్ తీసుకొని అంశాలను గుణించడం ద్వారా మూలకాల నుండి `Self` ను ఉత్పత్తి చేసే విధానం.
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn product<I: Iterator<Item = A>>(iter: I) -> Self;
}

macro_rules! integer_sum_product {
    (@impls $zero:expr, $one:expr, #[$attr:meta], $($a:ty)*) => ($(
        #[$attr]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[$attr]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*);
    ($($a:ty)*) => (
        integer_sum_product!(@impls 0, 1,
                #[stable(feature = "iter_arith_traits", since = "1.12.0")],
                $($a)*);
        integer_sum_product!(@impls Wrapping(0), Wrapping(1),
                #[stable(feature = "wrapping_iter_arith", since = "1.14.0")],
                $(Wrapping<$a>)*);
    );
}

macro_rules! float_sum_product {
    ($($a:ident)*) => ($(
        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*)
}

integer_sum_product! { i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize }
float_sum_product! { f32 f64 }

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Sum<Result<U, E>> for Result<T, E>
where
    T: Sum<U>,
{
    /// [`Iterator`] లోని ప్రతి మూలకాన్ని తీసుకుంటుంది: ఇది [`Err`] అయితే, మరిన్ని అంశాలు తీసుకోబడవు మరియు [`Err`] తిరిగి ఇవ్వబడుతుంది.
    /// [`Err`] సంభవించకపోతే, అన్ని మూలకాల మొత్తం తిరిగి ఇవ్వబడుతుంది.
    ///
    /// # Examples
    ///
    /// ఇది vector లోని ప్రతి పూర్ణాంకాన్ని సంక్షిప్తం చేస్తుంది, ప్రతికూల మూలకం ఎదురైతే మొత్తాన్ని తిరస్కరిస్తుంది:
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<i32, &'static str> = v.iter().map(|&x: &i32|
    ///     if x < 0 { Err("Negative element found") }
    ///     else { Ok(x) }
    /// ).sum();
    /// assert_eq!(res, Ok(3));
    /// ```
    ///
    ///
    fn sum<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.sum())
    }
}

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Product<Result<U, E>> for Result<T, E>
where
    T: Product<U>,
{
    /// [`Iterator`] లోని ప్రతి మూలకాన్ని తీసుకుంటుంది: ఇది [`Err`] అయితే, మరిన్ని అంశాలు తీసుకోబడవు మరియు [`Err`] తిరిగి ఇవ్వబడుతుంది.
    /// [`Err`] సంభవించకపోతే, అన్ని మూలకాల ఉత్పత్తి తిరిగి ఇవ్వబడుతుంది.
    ///
    fn product<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.product())
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Sum<Option<U>> for Option<T>
where
    T: Sum<U>,
{
    /// [`Iterator`] లోని ప్రతి మూలకాన్ని తీసుకుంటుంది: ఇది [`None`] అయితే, మరిన్ని అంశాలు తీసుకోబడవు మరియు [`None`] తిరిగి ఇవ్వబడుతుంది.
    /// [`None`] సంభవించకపోతే, అన్ని మూలకాల మొత్తం తిరిగి ఇవ్వబడుతుంది.
    ///
    /// # Examples
    ///
    /// ఇది vector తీగలలో 'a' అక్షరం యొక్క స్థానాన్ని సంక్షిప్తీకరిస్తుంది, ఒక పదానికి 'a' అక్షరం లేకపోతే ఆపరేషన్ `None` ను అందిస్తుంది:
    ///
    ///
    /// ```
    /// let words = vec!["have", "a", "great", "day"];
    /// let total: Option<usize> = words.iter().map(|w| w.find('a')).sum();
    /// assert_eq!(total, Some(5));
    /// ```
    ///
    fn sum<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).sum::<Result<_, _>>().ok()
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Product<Option<U>> for Option<T>
where
    T: Product<U>,
{
    /// [`Iterator`] లోని ప్రతి మూలకాన్ని తీసుకుంటుంది: ఇది [`None`] అయితే, మరిన్ని అంశాలు తీసుకోబడవు మరియు [`None`] తిరిగి ఇవ్వబడుతుంది.
    /// [`None`] సంభవించకపోతే, అన్ని మూలకాల ఉత్పత్తి తిరిగి ఇవ్వబడుతుంది.
    ///
    fn product<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).product::<Result<_, _>>().ok()
    }
}