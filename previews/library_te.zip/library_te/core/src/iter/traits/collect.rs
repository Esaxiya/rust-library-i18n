/// [`Iterator`] నుండి మార్పిడి.
///
/// ఒక రకం కోసం `FromIterator` ను అమలు చేయడం ద్వారా, ఇటిరేటర్ నుండి ఇది ఎలా సృష్టించబడుతుందో మీరు నిర్వచించారు.
/// ఒక రకమైన సేకరణను వివరించే రకాలకు ఇది సాధారణం.
///
/// [`FromIterator::from_iter()`] చాలా అరుదుగా స్పష్టంగా పిలుస్తారు మరియు బదులుగా [`Iterator::collect()`] పద్ధతి ద్వారా ఉపయోగించబడుతుంది.
///
/// మరిన్ని ఉదాహరణల కోసం [`Iterator::collect()`]'s డాక్యుమెంటేషన్ చూడండి.
///
/// ఇది కూడ చూడు: [`IntoIterator`].
///
/// # Examples
///
/// ప్రాథమిక వినియోగం:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// `FromIterator` ని సూటిగా ఉపయోగించడానికి [`Iterator::collect()`] ని ఉపయోగించడం:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// మీ రకం కోసం `FromIterator` ను అమలు చేస్తోంది:
///
/// ```
/// use std::iter::FromIterator;
///
/// // ఒక నమూనా సేకరణ, ఇది Vec పై ఒక రేపర్ మాత్రమే<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // దీనికి కొన్ని పద్ధతులు ఇద్దాం, అందువల్ల మనం ఒకదాన్ని సృష్టించి దానికి విషయాలను జోడించవచ్చు.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // మరియు మేము FromIterator ను అమలు చేస్తాము
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // ఇప్పుడు మనం కొత్త ఇటరేటర్ చేయవచ్చు ...
/// let iter = (0..5).into_iter();
///
/// // ... మరియు దాని నుండి మై కలెక్షన్ చేయండి
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // రచనలు కూడా సేకరించండి!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// మళ్ళి నుండి విలువను సృష్టిస్తుంది.
    ///
    /// మరిన్ని కోసం [module-level documentation] చూడండి.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// [`Iterator`] లోకి మార్చడం.
///
/// ఒక రకం కోసం `IntoIterator` ను అమలు చేయడం ద్వారా, అది ఇరేటర్‌గా ఎలా మార్చబడుతుందో మీరు నిర్వచించారు.
/// ఒక రకమైన సేకరణను వివరించే రకాలకు ఇది సాధారణం.
///
/// `IntoIterator` ను అమలు చేయడం వల్ల కలిగే ప్రయోజనం ఏమిటంటే, మీ రకం [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) అవుతుంది.
///
///
/// ఇది కూడ చూడు: [`FromIterator`].
///
/// # Examples
///
/// ప్రాథమిక వినియోగం:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// మీ రకం కోసం `IntoIterator` ను అమలు చేస్తోంది:
///
/// ```
/// // ఒక నమూనా సేకరణ, ఇది Vec పై ఒక రేపర్ మాత్రమే<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // దీనికి కొన్ని పద్ధతులు ఇద్దాం, అందువల్ల మనం ఒకదాన్ని సృష్టించి దానికి విషయాలను జోడించవచ్చు.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // మరియు మేము IntoIterator ను అమలు చేస్తాము
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // ఇప్పుడు మనం కొత్త సేకరణ చేయవచ్చు ...
/// let mut c = MyCollection::new();
///
/// // ... దీనికి కొన్ని అంశాలను జోడించండి ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... ఆపై దాన్ని ఇటేరేటర్‌గా మార్చండి:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// `IntoIterator` ను trait bound గా ఉపయోగించడం సాధారణం.ఇది ఇన్పుట్ సేకరణ రకాన్ని మార్చడానికి అనుమతిస్తుంది, ఇది ఇప్పటికీ ఇటరేటర్‌గా ఉంటుంది.
/// పరిమితం చేయడం ద్వారా అదనపు హద్దులను పేర్కొనవచ్చు
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// మూలకాల రకం మీద మళ్ళించబడుతుంది.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// మేము దీన్ని ఏ రకమైన ఇటరేటర్‌గా మారుస్తున్నాము?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// విలువ నుండి మళ్ళిని సృష్టిస్తుంది.
    ///
    /// మరిన్ని కోసం [module-level documentation] చూడండి.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// ఇటరేటర్ యొక్క విషయాలతో సేకరణను విస్తరించండి.
///
/// ఇటరేటర్లు విలువల శ్రేణిని ఉత్పత్తి చేస్తారు, మరియు సేకరణలు విలువల శ్రేణిగా కూడా భావించవచ్చు.
/// `Extend` trait ఈ అంతరాన్ని తగ్గిస్తుంది, ఆ ఇటరేటర్ యొక్క విషయాలను చేర్చడం ద్వారా సేకరణను విస్తరించడానికి మిమ్మల్ని అనుమతిస్తుంది.
/// ఇప్పటికే ఉన్న కీతో సేకరణను విస్తరించేటప్పుడు, ఆ ఎంట్రీ నవీకరించబడుతుంది లేదా సమాన కీలతో బహుళ ఎంట్రీలను అనుమతించే సేకరణల విషయంలో, ఆ ఎంట్రీ చేర్చబడుతుంది.
///
///
/// # Examples
///
/// ప్రాథమిక వినియోగం:
///
/// ```
/// // మీరు కొన్ని అక్షరాలతో స్ట్రింగ్‌ను విస్తరించవచ్చు:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend` అమలు చేస్తోంది:
///
/// ```
/// // ఒక నమూనా సేకరణ, ఇది Vec పై ఒక రేపర్ మాత్రమే<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // దీనికి కొన్ని పద్ధతులు ఇద్దాం, అందువల్ల మనం ఒకదాన్ని సృష్టించి దానికి విషయాలను జోడించవచ్చు.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // MyCollection i32 ల జాబితాను కలిగి ఉన్నందున, మేము i32 కోసం విస్తరించును అమలు చేస్తాము
/// impl Extend<i32> for MyCollection {
///
///     // కాంక్రీట్ రకం సంతకంతో ఇది కొంచెం సరళమైనది: మనం ఐటెరేటర్‌గా మార్చగలిగే దేనినైనా విస్తరించమని పిలుస్తాము, అది మనకు i32 లను ఇస్తుంది.
///     // ఎందుకంటే MyCollection లో పెట్టడానికి మనకు i32 లు అవసరం.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // అమలు చాలా సూటిగా ఉంటుంది: ఇరేటర్ ద్వారా లూప్, మరియు add() ప్రతి మూలకం మనకు.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // మన సేకరణను మరో మూడు సంఖ్యలతో విస్తరిద్దాం
/// c.extend(vec![1, 2, 3]);
///
/// // మేము ఈ అంశాలను చివరికి జోడించాము
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// ఇటరేటర్ యొక్క విషయాలతో సేకరణను విస్తరిస్తుంది.
    ///
    /// ఈ trait కి అవసరమైన ఏకైక పద్ధతి కనుక, [trait-level] డాక్స్ మరిన్ని వివరాలను కలిగి ఉంది.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// // మీరు కొన్ని అక్షరాలతో స్ట్రింగ్‌ను విస్తరించవచ్చు:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// సరిగ్గా ఒక మూలకంతో సేకరణను విస్తరిస్తుంది.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// ఇచ్చిన అదనపు అంశాల కోసం సేకరణలో నిల్వ నిల్వ సామర్థ్యం.
    ///
    /// డిఫాల్ట్ అమలు ఏమీ చేయదు.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}