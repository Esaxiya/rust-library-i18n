/// దాని ఖచ్చితమైన పొడవు తెలిసిన ఇటరేటర్.
///
/// చాలామంది [`ఇటిరేటర్]] వారు ఎన్నిసార్లు మళ్ళిస్తారో తెలియదు, కాని కొందరు అలా చేస్తారు.
/// ఒక ఇరేటర్ ఎన్నిసార్లు మళ్ళించగలదో తెలిస్తే, ఆ సమాచారానికి ప్రాప్యత అందించడం ఉపయోగపడుతుంది.
/// ఉదాహరణకు, మీరు వెనుకకు మళ్ళించాలనుకుంటే, ముగింపు ఎక్కడ ఉందో తెలుసుకోవడం మంచి ప్రారంభం.
///
/// `ExactSizeIterator` ను అమలు చేస్తున్నప్పుడు, మీరు కూడా [`Iterator`] ను అమలు చేయాలి.
/// అలా చేసినప్పుడు, [`Iterator::size_hint`]*యొక్క అమలు* మళ్ళి యొక్క ఖచ్చితమైన పరిమాణాన్ని తిరిగి ఇవ్వాలి.
///
/// [`len`] పద్ధతి డిఫాల్ట్ అమలును కలిగి ఉంది, కాబట్టి మీరు దీన్ని సాధారణంగా అమలు చేయకూడదు.
/// అయినప్పటికీ, మీరు డిఫాల్ట్ కంటే ఎక్కువ పనితీరును అందించగలుగుతారు, కాబట్టి ఈ సందర్భంలో దాన్ని భర్తీ చేయడం అర్ధమే.
///
///
/// ఈ trait సురక్షితమైన trait అని గమనించండి మరియు తిరిగి వచ్చిన పొడవు సరైనదని *కాదు* మరియు * హామీ ఇవ్వదు.
/// దీని అర్థం `unsafe` కోడ్ ** [`Iterator::size_hint`] యొక్క ఖచ్చితత్వంపై ఆధారపడకూడదు.
/// అస్థిర మరియు అసురక్షిత [`TrustedLen`](super::marker::TrustedLen) trait ఈ అదనపు హామీని ఇస్తుంది.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// ప్రాథమిక వినియోగం:
///
/// ```
/// // పరిమిత శ్రేణికి ఎన్నిసార్లు మళ్ళించాలో తెలుసు
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs] లో, మేము [`Iterator`] ను అమలు చేసాము, `Counter`.
/// దాని కోసం `ExactSizeIterator` ను కూడా అమలు చేద్దాం:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // మిగిలిన పునరావృత సంఖ్యలను మనం సులభంగా లెక్కించవచ్చు.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // ఇప్పుడు మనం దాన్ని ఉపయోగించవచ్చు!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// మళ్ళి యొక్క ఖచ్చితమైన పొడవును అందిస్తుంది.
    ///
    /// [`None`] ను తిరిగి ఇచ్చే ముందు, ఇరేటర్ [`Some(T)`] విలువను [`Some(T)`] విలువ కంటే ఎక్కువ రెట్లు తిరిగి ఇస్తుందని అమలు నిర్ధారిస్తుంది.
    ///
    /// ఈ పద్ధతి డిఫాల్ట్ అమలును కలిగి ఉంది, కాబట్టి మీరు దీన్ని నేరుగా అమలు చేయకూడదు.
    /// అయితే, మీరు మరింత సమర్థవంతమైన అమలును అందించగలిగితే, మీరు అలా చేయవచ్చు.
    /// ఉదాహరణ కోసం [trait-level] డాక్స్ చూడండి.
    ///
    /// ఈ ఫంక్షన్ [`Iterator::size_hint`] ఫంక్షన్ వలె అదే భద్రతా హామీలను కలిగి ఉంది.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// // పరిమిత శ్రేణికి ఎన్నిసార్లు మళ్ళించాలో తెలుసు
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: ఈ వాదన మితిమీరిన రక్షణాత్మకమైనది, కాని ఇది మార్పును తనిఖీ చేస్తుంది
        // trait ద్వారా హామీ ఇవ్వబడుతుంది.
        // ఈ trait rust-అంతర్గతమైతే, మేము debug_assert ను ఉపయోగించవచ్చు;assert_eq!అన్ని Rust వినియోగదారు అమలులను కూడా తనిఖీ చేస్తుంది.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// ఇరేటర్ ఖాళీగా ఉంటే `true` ని అందిస్తుంది.
    ///
    /// ఈ పద్ధతి [`ExactSizeIterator::len()`] ను ఉపయోగించి డిఫాల్ట్ అమలును కలిగి ఉంది, కాబట్టి మీరు దీన్ని మీరే అమలు చేయవలసిన అవసరం లేదు.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}