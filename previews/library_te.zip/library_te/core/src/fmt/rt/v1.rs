//! ఇది ifmt ఉపయోగించే అంతర్గత మాడ్యూల్!రన్‌టైమ్.ఫార్మాట్ తీగలను ముందుగానే కంపైల్ చేయడానికి ఈ నిర్మాణాలు స్టాటిక్ శ్రేణులకు విడుదలవుతాయి.
//!
//! ఈ నిర్వచనాలు వాటి `ct` సమానమైన వాటితో సమానంగా ఉంటాయి, అయితే వీటిని స్థిరంగా కేటాయించవచ్చు మరియు రన్‌టైమ్ కోసం కొద్దిగా ఆప్టిమైజ్ చేయబడతాయి.
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// ఆకృతీకరణ ఆదేశంలో భాగంగా అభ్యర్థించగల సాధ్యమైన అమరికలు.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// విషయాలను ఎడమ-సమలేఖనం చేయాలని సూచించడం.
    Left,
    /// విషయాలు కుడి-సమలేఖనం కావాలని సూచించడం.
    Right,
    /// విషయాలు మధ్యలో సమలేఖనం చేయబడాలని సూచించడం.
    Center,
    /// అమరిక అభ్యర్థించబడలేదు.
    Unknown,
}

/// [width](https://doc.rust-lang.org/std/fmt/#width) మరియు [precision](https://doc.rust-lang.org/std/fmt/#precision) స్పెసిఫైయర్లచే ఉపయోగించబడుతుంది.
#[derive(Copy, Clone)]
pub enum Count {
    /// అక్షర సంఖ్యతో పేర్కొనబడింది, విలువను నిల్వ చేస్తుంది
    Is(usize),
    /// `$` మరియు `*` వాక్యనిర్మాణాలను ఉపయోగించి పేర్కొనబడింది, సూచికను `args` లోకి నిల్వ చేస్తుంది
    Param(usize),
    /// పేర్కొనలేదు
    Implied,
}