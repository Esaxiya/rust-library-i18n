//! తీగలను ఆకృతీకరించడానికి మరియు ముద్రించడానికి యుటిలిటీస్.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// `Formatter::align` చేత తిరిగి ఇవ్వబడిన అమరికలు
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// విషయాలను ఎడమ-సమలేఖనం చేయాలని సూచించడం.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// విషయాలు కుడి-సమలేఖనం కావాలని సూచించడం.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// విషయాలు మధ్యలో సమలేఖనం చేయబడాలని సూచించడం.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// ఫార్మాటర్ పద్ధతుల ద్వారా తిరిగి వచ్చిన రకం.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// సందేశాన్ని స్ట్రీమ్‌లోకి ఫార్మాట్ చేయకుండా తిరిగి వచ్చిన లోపం రకం.
///
/// లోపం సంభవించినది కాకుండా లోపం ప్రసారం చేయడానికి ఈ రకం మద్దతు ఇవ్వదు.
/// ఏదైనా అదనపు సమాచారం ఇతర మార్గాల ద్వారా ప్రసారం చేయడానికి ఏర్పాటు చేయాలి.
///
/// గుర్తుంచుకోవలసిన ముఖ్యమైన విషయం ఏమిటంటే, `fmt::Error` రకం [`std::io::Error`] లేదా [`std::error::Error`] తో గందరగోళంగా ఉండకూడదు, ఇది మీకు కూడా పరిధిలో ఉండవచ్చు.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// యూనికోడ్-అంగీకరించే బఫర్‌లు లేదా స్ట్రీమ్‌లలోకి వ్రాయడం లేదా ఆకృతీకరించడం కోసం trait.
///
/// ఈ trait UTF-8-ఎన్కోడ్ చేసిన డేటాను మాత్రమే అంగీకరిస్తుంది మరియు ఇది [flushable] కాదు.
/// మీరు యూనికోడ్‌ను మాత్రమే అంగీకరించాలనుకుంటే మరియు మీకు ఫ్లషింగ్ అవసరం లేకపోతే, మీరు ఈ trait ను అమలు చేయాలి;
/// లేకపోతే మీరు [`std::io::Write`] ను అమలు చేయాలి.
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// ఈ రచయితకు స్ట్రింగ్ స్లైస్ వ్రాస్తూ, వ్రాత విజయవంతమైందో లేదో తిరిగి ఇస్తుంది.
    ///
    /// మొత్తం స్ట్రింగ్ స్లైస్ విజయవంతంగా వ్రాయబడితే మాత్రమే ఈ పద్ధతి విజయవంతం అవుతుంది మరియు అన్ని డేటా వ్రాయబడే వరకు లేదా లోపం సంభవించే వరకు ఈ పద్ధతి తిరిగి రాదు.
    ///
    ///
    /// # Errors
    ///
    /// ఈ ఫంక్షన్ లోపం మీద [`Error`] యొక్క ఉదాహరణను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// ఈ రచయితలో ఒక [`char`] వ్రాస్తుంది, వ్రాత విజయవంతమైందో లేదో తిరిగి ఇస్తుంది.
    ///
    /// ఒకే [`char`] ఒకటి కంటే ఎక్కువ బైట్లుగా ఎన్కోడ్ చేయబడవచ్చు.
    /// మొత్తం బైట్ క్రమం విజయవంతంగా వ్రాయబడితే మాత్రమే ఈ పద్ధతి విజయవంతం అవుతుంది మరియు అన్ని డేటా వ్రాయబడే వరకు లేదా లోపం సంభవించే వరకు ఈ పద్ధతి తిరిగి రాదు.
    ///
    ///
    /// # Errors
    ///
    /// ఈ ఫంక్షన్ లోపం మీద [`Error`] యొక్క ఉదాహరణను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// ఈ trait యొక్క అమలుదారులతో [`write!`] స్థూల ఉపయోగం కోసం జిగురు.
    ///
    /// ఈ పద్ధతిని సాధారణంగా మానవీయంగా ఉపయోగించకూడదు, కానీ [`write!`] స్థూల ద్వారానే.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// ఆకృతీకరణ కోసం ఆకృతీకరణ.
///
/// `Formatter` ఆకృతీకరణకు సంబంధించిన వివిధ ఎంపికలను సూచిస్తుంది.
/// వినియోగదారులు నేరుగా `ఫార్మాటర్'లను నిర్మించరు;[`Debug`] మరియు [`Display`] వంటి అన్ని ఫార్మాటింగ్ traits యొక్క `fmt` పద్ధతికి ఒకదానికి మార్చగల సూచన పంపబడుతుంది.
///
///
/// `Formatter` తో ఇంటరాక్ట్ అవ్వడానికి, ఫార్మాటింగ్‌కు సంబంధించిన వివిధ ఎంపికలను మార్చడానికి మీరు వివిధ పద్ధతులను పిలుస్తారు.
/// ఉదాహరణల కోసం, దయచేసి దిగువ `Formatter` లో నిర్వచించిన పద్ధతుల డాక్యుమెంటేషన్ చూడండి.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// ఆర్గ్యుమెంట్ తప్పనిసరిగా ఆప్టిమైజ్ చేయబడిన పాక్షికంగా అనువర్తిత ఆకృతీకరణ ఫంక్షన్, ఇది `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result` కి సమానం.

extern "C" {
    type Opaque;
}

/// ఈ స్ట్రక్ట్ జెనరిక్ "argument" ను సూచిస్తుంది, ఇది Xprintf ఫ్యామిలీ ఫంక్షన్లచే తీసుకోబడుతుంది.ఇచ్చిన విలువను ఫార్మాట్ చేయడానికి ఇది ఒక ఫంక్షన్‌ను కలిగి ఉంది.
/// కంపైల్ సమయంలో ఫంక్షన్ మరియు విలువ సరైన రకాలను కలిగి ఉన్నాయని నిర్ధారిస్తుంది, ఆపై ఈ స్ట్రక్ట్ ఒక రకానికి వాదనలను కానానికలైజ్ చేయడానికి ఉపయోగించబడుతుంది.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// ఫార్మాటింగ్ మౌలిక సదుపాయాలలో indices/counts తో అనుబంధించబడిన ఫంక్షన్ పాయింటర్‌కు ఇది ఒకే స్థిరమైన విలువకు హామీ ఇస్తుంది.
//
// ఎల్‌ఎల్‌విఎం ఐఆర్‌కు ప్రస్తుత తగ్గింపుతో ఫంక్షన్‌లు ఎల్లప్పుడూ పేరులేని_అడ్ఆర్ అని ట్యాగ్ చేయబడినందున నిర్వచించబడిన ఫంక్షన్ సరైనది కాదని గమనించండి, కాబట్టి వాటి చిరునామా ఎల్‌ఎల్‌విఎమ్‌కి ముఖ్యమైనదిగా పరిగణించబడదు మరియు అలాంటి_యూసైజ్ కాస్ట్ తప్పుగా కంపైల్ చేయబడి ఉండవచ్చు.
//
// ఆచరణలో, వినియోగించని డేటాను (ఫార్మాటింగ్ ఆర్గ్యుమెంట్స్ యొక్క స్టాటిక్ జనరేషన్ విషయంగా) మేము ఎప్పుడూ as_usize అని పిలవము, కాబట్టి ఇది కేవలం అదనపు తనిఖీ మాత్రమే.
//
// మేము ప్రాథమికంగా `USIZE_MARKER` వద్ద ఉన్న ఫంక్షన్ పాయింటర్ `&usize` ను వారి మొదటి వాదనగా తీసుకునే ఫంక్షన్లకు *మాత్రమే* చిరునామా ఉందని నిర్ధారించాలనుకుంటున్నాము.
// ఆమోదించిన రిఫరెన్స్ నుండి వినియోగాన్ని మేము సురక్షితంగా సిద్ధం చేయగలమని మరియు ఈ చిరునామా వినియోగించని టేకింగ్ ఫంక్షన్ వద్ద సూచించదని ఇక్కడ రీడ్_వోలేటైల్ నిర్ధారిస్తుంది.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // భద్రత: ptr ఒక సూచన
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // భద్రత: `mem::transmute(x)` సురక్షితం ఎందుకంటే
        //     1. `&'b T` ఇది `'b` తో ఉద్భవించిన జీవితకాలం ఉంచుతుంది (తద్వారా అపరిమితమైన జీవితకాలం ఉండకూడదు)
        //     2.
        //     `&'b T` మరియు `&'b Opaque` ఒకే మెమరీ లేఅవుట్‌ను కలిగి ఉంటాయి (`T` `Sized` అయినప్పుడు, ఇక్కడ ఉన్నట్లుగా) `fn(&T, &mut Formatter<'_>) -> Result` మరియు `fn(&Opaque, &mut Formatter<'_>) -> Result` ఒకే ABI ను కలిగి ఉన్నందున `mem::transmute(f)` సురక్షితం (`T` `Sized` ఉన్నంత వరకు)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // భద్రత: ఉంటే `formatter` ఫీల్డ్ USIZE_MARKER కు మాత్రమే సెట్ చేయబడుతుంది
            // విలువ వినియోగం, కాబట్టి ఇది సురక్షితం
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// ఫార్మాట్_ఆర్గ్స్ యొక్క v1 ఆకృతిలో జెండాలు అందుబాటులో ఉన్నాయి
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// ఫార్మాట్_ఆర్గ్స్! () మాక్రోను ఉపయోగిస్తున్నప్పుడు, ఈ ఫంక్షన్ ఆర్గ్యుమెంట్స్ నిర్మాణాన్ని రూపొందించడానికి ఉపయోగించబడుతుంది.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// ప్రామాణికం కాని ఆకృతీకరణ పారామితులను పేర్కొనడానికి ఈ ఫంక్షన్ ఉపయోగించబడుతుంది.
    /// చెల్లుబాటు అయ్యే ఆర్గ్యుమెంట్స్ నిర్మాణాన్ని నిర్మించడానికి `pieces` శ్రేణి కనీసం `fmt` వరకు ఉండాలి.
    /// అలాగే, `fmt` లేదా `CountIsNextParam` లోని `fmt` లోని ఏదైనా `Count` `argumentusize` తో సృష్టించబడిన వాదనను సూచించాలి.
    ///
    /// అయినప్పటికీ, అలా చేయడంలో విఫలమవడం అసురక్షితతను కలిగించదు, కానీ చెల్లదు.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// ఆకృతీకరించిన వచనం యొక్క పొడవును అంచనా వేస్తుంది.
    ///
    /// `format!` ఉపయోగిస్తున్నప్పుడు ప్రారంభ `String` సామర్థ్యాన్ని సెట్ చేయడానికి ఇది ఉపయోగించబడుతుంది.
    /// Note: ఇది దిగువ లేదా ఎగువ బంధం కాదు.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // ఫార్మాట్ స్ట్రింగ్ ఒక ఆర్గ్యుమెంట్‌తో మొదలవుతుంటే, ముక్కల పొడవు గణనీయంగా ఉంటే తప్ప, ఏదైనా ముందుగా కేటాయించవద్దు.
            //
            //
            0
        } else {
            // కొన్ని వాదనలు ఉన్నాయి, కాబట్టి ఏదైనా అదనపు పుష్ స్ట్రింగ్‌ను తిరిగి కేటాయిస్తుంది.
            //
            // దాన్ని నివారించడానికి, మేము ఇక్కడ "pre-doubling" సామర్థ్యం కలిగి ఉన్నాము.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// ఈ నిర్మాణం ఫార్మాట్ స్ట్రింగ్ యొక్క సురక్షితంగా ముందస్తుగా సంస్కరణను మరియు దాని వాదనలను సూచిస్తుంది.
/// ఇది రన్‌టైమ్‌లో ఉత్పత్తి చేయబడదు ఎందుకంటే ఇది సురక్షితంగా చేయలేము, కాబట్టి కన్స్ట్రక్టర్లు ఇవ్వబడరు మరియు సవరణలను నిరోధించడానికి ఫీల్డ్‌లు ప్రైవేట్‌గా ఉంటాయి.
///
///
/// [`format_args!`] స్థూల ఈ నిర్మాణం యొక్క ఉదాహరణను సురక్షితంగా సృష్టిస్తుంది.
/// మాక్రో ఫార్మాట్ స్ట్రింగ్‌ను కంపైల్-టైమ్‌లో ధృవీకరిస్తుంది కాబట్టి [`write()`] మరియు [`format()`] ఫంక్షన్ల వాడకాన్ని సురక్షితంగా చేయవచ్చు.
///
/// క్రింద చూసినట్లుగా మీరు `Debug` మరియు `Display` సందర్భాలలో [`format_args!`] తిరిగి ఇచ్చే `Arguments<'a>` ను ఉపయోగించవచ్చు.
/// ఉదాహరణ కూడా `Debug` మరియు `Display` ఆకృతిని ఒకే విషయానికి చూపిస్తుంది: `format_args!` లో ఇంటర్పోలేటెడ్ ఫార్మాట్ స్ట్రింగ్.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // ముద్రించడానికి స్ట్రింగ్ ముక్కలను ఫార్మాట్ చేయండి.
    pieces: &'a [&'static str],

    // ప్లేస్‌హోల్డర్ స్పెక్స్ లేదా అన్ని స్పెక్స్ డిఫాల్ట్‌గా ఉంటే `None` ("{}{}" లో ఉన్నట్లు).
    fmt: Option<&'a [rt::v1::Argument]>,

    // ఇంటర్పోలేషన్ కోసం డైనమిక్ ఆర్గ్యుమెంట్స్, స్ట్రింగ్ ముక్కలతో ఇంటర్‌లీవ్ చేయబడాలి.
    // (ప్రతి వాదనకు ముందు స్ట్రింగ్ పీస్ ఉంటుంది.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// ఫార్మాట్ చేయవలసిన వాదనలు లేనట్లయితే, ఫార్మాట్ చేసిన స్ట్రింగ్‌ను పొందండి.
    ///
    /// చాలా చిన్నవిషయమైన సందర్భంలో కేటాయింపులను నివారించడానికి ఇది ఉపయోగపడుతుంది.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` ప్రోగ్రామర్-ఫేసింగ్, డీబగ్గింగ్ సందర్భంలో అవుట్‌పుట్‌ను ఫార్మాట్ చేయాలి.
///
/// సాధారణంగా, మీరు `derive` ఒక `Debug` అమలు చేయాలి.
///
/// ప్రత్యామ్నాయ ఫార్మాట్ స్పెసిఫైయర్ `#?` తో ఉపయోగించినప్పుడు, అవుట్పుట్ అందంగా ముద్రించబడుతుంది.
///
/// ఫార్మాటర్లపై మరింత సమాచారం కోసం, [the module-level documentation][module] చూడండి.
///
/// [module]: ../../std/fmt/index.html
///
/// అన్ని ఫీల్డ్‌లు `Debug` ను అమలు చేస్తే ఈ trait ను `#[derive]` తో ఉపయోగించవచ్చు.
/// స్ట్రక్ట్స్ కోసం `ఉత్పన్నం అయినప్పుడు, ఇది `struct`, తరువాత `{`, ఆపై ప్రతి ఫీల్డ్ పేరు మరియు `Debug` విలువ యొక్క కామాతో వేరు చేయబడిన జాబితా, తరువాత `}` ను ఉపయోగిస్తుంది.
/// `Enum` ల కొరకు, ఇది వేరియంట్ పేరును ఉపయోగిస్తుంది మరియు వర్తిస్తే, `(`, అప్పుడు ఫీల్డ్ల యొక్క `Debug` విలువలు, తరువాత `)`.
///
/// # Stability
///
/// ఉత్పన్నమైన `Debug` ఆకృతులు స్థిరంగా లేవు మరియు future Rust సంస్కరణలతో మారవచ్చు.
/// అదనంగా, ప్రామాణిక లైబ్రరీ (`libstd`, `libcore`, `liballoc`, మొదలైనవి) అందించిన `Debug` అమలులు స్థిరంగా లేవు మరియు future Rust సంస్కరణలతో కూడా మారవచ్చు.
///
///
/// # Examples
///
/// అమలు చేయడం:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// మాన్యువల్‌గా అమలు చేస్తోంది:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// [`debug_struct`] వంటి మాన్యువల్ అమలులో మీకు సహాయపడటానికి [`Formatter`] struct లో అనేక సహాయక పద్ధతులు ఉన్నాయి.
///
/// `Debug` `derive` లేదా [`Formatter`] లోని డీబగ్ బిల్డర్ API ని ఉపయోగించి అమలులు ప్రత్యామ్నాయ జెండాను ఉపయోగించి అందంగా ముద్రించడానికి మద్దతు ఇస్తాయి: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// `#?` తో ప్రెట్టీ ప్రింటింగ్:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// ఇచ్చిన ఫార్మాటర్ ఉపయోగించి విలువను ఫార్మాట్ చేస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// trait `Debug` లేకుండా prelude నుండి స్థూల `Debug` ను తిరిగి ఎగుమతి చేయడానికి ప్రత్యేక మాడ్యూల్.
pub(crate) mod macros {
    /// trait `Debug` యొక్క impl ను ఉత్పత్తి చేసే స్థూల ఉత్పన్నం.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// ఖాళీ ఫార్మాట్ కోసం trait ను ఫార్మాట్ చేయండి, `{}`.
///
/// `Display` [`Debug`] ను పోలి ఉంటుంది, కానీ `Display` అనేది వినియోగదారు ఎదుర్కొంటున్న అవుట్పుట్ కోసం, కనుక దీనిని పొందలేము.
///
///
/// ఫార్మాటర్లపై మరింత సమాచారం కోసం, [the module-level documentation][module] చూడండి.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ఒక రకంపై `Display` ను అమలు చేస్తోంది:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// ఇచ్చిన ఫార్మాటర్ ఉపయోగించి విలువను ఫార్మాట్ చేస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait దాని అవుట్పుట్ను base-8 లో ఒక సంఖ్యగా ఫార్మాట్ చేయాలి.
///
/// ఆదిమ సంతకం చేసిన పూర్ణాంకాల కోసం (`i8` నుండి `i128`, మరియు `isize`), ప్రతికూల విలువలు రెండింటి పూరక ప్రాతినిధ్యంగా ఫార్మాట్ చేయబడతాయి.
///
///
/// ప్రత్యామ్నాయ జెండా, `#`, అవుట్పుట్ ముందు `0o` ను జతచేస్తుంది.
///
/// ఫార్మాటర్లపై మరింత సమాచారం కోసం, [the module-level documentation][module] చూడండి.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` తో ప్రాథమిక వినియోగం:
///
/// ```
/// let x = 42; // 42 అష్టపదిలో '52'
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// ఒక రకంపై `Octal` ను అమలు చేస్తోంది:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // i32 యొక్క అమలుకు ప్రతినిధి
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// ఇచ్చిన ఫార్మాటర్ ఉపయోగించి విలువను ఫార్మాట్ చేస్తుంది.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait దాని అవుట్‌పుట్‌ను బైనరీలో సంఖ్యగా ఫార్మాట్ చేయాలి.
///
/// ఆదిమ సంతకం చేసిన పూర్ణాంకాల కోసం ([`i8`] నుండి [`i128`], మరియు [`isize`]), ప్రతికూల విలువలు రెండింటి పూరక ప్రాతినిధ్యంగా ఫార్మాట్ చేయబడతాయి.
///
///
/// ప్రత్యామ్నాయ జెండా, `#`, అవుట్పుట్ ముందు `0b` ను జతచేస్తుంది.
///
/// ఫార్మాటర్లపై మరింత సమాచారం కోసం, [the module-level documentation][module] చూడండి.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// [`i32`] తో ప్రాథమిక వినియోగం:
///
/// ```
/// let x = 42; // 42 బైనరీలో '101010'
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// ఒక రకంపై `Binary` ను అమలు చేస్తోంది:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // i32 యొక్క అమలుకు ప్రతినిధి
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// ఇచ్చిన ఫార్మాటర్ ఉపయోగించి విలువను ఫార్మాట్ చేస్తుంది.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait దాని అవుట్పుట్‌ను హెక్సాడెసిమల్‌లో ఒక సంఖ్యగా ఫార్మాట్ చేయాలి, `a` ద్వారా `f` ద్వారా లోయర్ కేస్.
///
/// ఆదిమ సంతకం చేసిన పూర్ణాంకాల కోసం (`i8` నుండి `i128`, మరియు `isize`), ప్రతికూల విలువలు రెండింటి పూరక ప్రాతినిధ్యంగా ఫార్మాట్ చేయబడతాయి.
///
///
/// ప్రత్యామ్నాయ జెండా, `#`, అవుట్పుట్ ముందు `0x` ను జతచేస్తుంది.
///
/// ఫార్మాటర్లపై మరింత సమాచారం కోసం, [the module-level documentation][module] చూడండి.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` తో ప్రాథమిక వినియోగం:
///
/// ```
/// let x = 42; // 42 హెక్స్‌లో '2a'
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// ఒక రకంపై `LowerHex` ను అమలు చేస్తోంది:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // i32 యొక్క అమలుకు ప్రతినిధి
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// ఇచ్చిన ఫార్మాటర్ ఉపయోగించి విలువను ఫార్మాట్ చేస్తుంది.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait దాని అవుట్‌పుట్‌ను హెక్సాడెసిమల్‌లో ఒక సంఖ్యగా ఫార్మాట్ చేయాలి, `A` ద్వారా `F` ద్వారా ఎగువ సందర్భంలో.
///
/// ఆదిమ సంతకం చేసిన పూర్ణాంకాల కోసం (`i8` నుండి `i128`, మరియు `isize`), ప్రతికూల విలువలు రెండింటి పూరక ప్రాతినిధ్యంగా ఫార్మాట్ చేయబడతాయి.
///
///
/// ప్రత్యామ్నాయ జెండా, `#`, అవుట్పుట్ ముందు `0x` ను జతచేస్తుంది.
///
/// ఫార్మాటర్లపై మరింత సమాచారం కోసం, [the module-level documentation][module] చూడండి.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` తో ప్రాథమిక వినియోగం:
///
/// ```
/// let x = 42; // 42 హెక్స్‌లో '2A'
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// ఒక రకంపై `UpperHex` ను అమలు చేస్తోంది:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // i32 యొక్క అమలుకు ప్రతినిధి
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// ఇచ్చిన ఫార్మాటర్ ఉపయోగించి విలువను ఫార్మాట్ చేస్తుంది.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait దాని అవుట్‌పుట్‌ను మెమరీ స్థానంగా ఫార్మాట్ చేయాలి.
/// ఇది సాధారణంగా హెక్సాడెసిమల్‌గా ప్రదర్శించబడుతుంది.
///
/// ఫార్మాటర్లపై మరింత సమాచారం కోసం, [the module-level documentation][module] చూడండి.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `&i32` తో ప్రాథమిక వినియోగం:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // ఇది '0x7f06092ac6d0' వంటిదాన్ని ఉత్పత్తి చేస్తుంది
/// ```
///
/// ఒక రకంపై `Pointer` ను అమలు చేస్తోంది:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // `*const T` కి మార్చడానికి `as` ను ఉపయోగించండి, ఇది పాయింటర్‌ను అమలు చేస్తుంది, దీనిని మనం ఉపయోగించవచ్చు
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// ఇచ్చిన ఫార్మాటర్ ఉపయోగించి విలువను ఫార్మాట్ చేస్తుంది.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait దాని ఉత్పత్తిని శాస్త్రీయ సంజ్ఞామానం లోయర్-కేస్ `e` తో ఫార్మాట్ చేయాలి.
///
/// ఫార్మాటర్లపై మరింత సమాచారం కోసం, [the module-level documentation][module] చూడండి.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` తో ప్రాథమిక వినియోగం:
///
/// ```
/// let x = 42.0; // 42.0 శాస్త్రీయ సంజ్ఞామానం లో '4.2e1'
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// ఒక రకంపై `LowerExp` ను అమలు చేస్తోంది:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // f64 యొక్క అమలుకు ప్రతినిధి
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// ఇచ్చిన ఫార్మాటర్ ఉపయోగించి విలువను ఫార్మాట్ చేస్తుంది.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait దాని ఉత్పత్తిని శాస్త్రీయ సంజ్ఞామానం లో అప్పర్-కేస్ `E` తో ఫార్మాట్ చేయాలి.
///
/// ఫార్మాటర్లపై మరింత సమాచారం కోసం, [the module-level documentation][module] చూడండి.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` తో ప్రాథమిక వినియోగం:
///
/// ```
/// let x = 42.0; // 42.0 శాస్త్రీయ సంజ్ఞామానం లో '4.2E1'
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// ఒక రకంపై `UpperExp` ను అమలు చేస్తోంది:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // f64 యొక్క అమలుకు ప్రతినిధి
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// ఇచ్చిన ఫార్మాటర్ ఉపయోగించి విలువను ఫార్మాట్ చేస్తుంది.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `write` ఫంక్షన్ అవుట్పుట్ స్ట్రీమ్ను తీసుకుంటుంది మరియు `Arguments` స్ట్రక్ట్ ను `format_args!` మాక్రోతో ముందే కంపైల్ చేయవచ్చు.
///
///
/// పేర్కొన్న అవుట్పుట్ స్ట్రీమ్‌లోకి పేర్కొన్న ఫార్మాట్ స్ట్రింగ్ ప్రకారం వాదనలు ఫార్మాట్ చేయబడతాయి.
///
/// # Examples
///
/// ప్రాథమిక వినియోగం:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// దయచేసి [`write!`] ను ఉపయోగించడం మంచిది.ఉదాహరణ:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // మేము అన్ని వాదనలకు డిఫాల్ట్ ఆకృతీకరణ పారామితులను ఉపయోగించవచ్చు.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // ప్రతి స్పెక్‌కు సంబంధిత వాదన ఉంటుంది, అది స్ట్రింగ్ పీస్‌కు ముందు ఉంటుంది.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // భద్రత: arg మరియు args.args ఒకే వాదనల నుండి వచ్చాయి,
                // ఇది సూచికలు ఎల్లప్పుడూ హద్దుల్లో ఉంటాయని హామీ ఇస్తుంది.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // ఒక వెనుకంజలో ఉన్న స్ట్రింగ్ ముక్క మాత్రమే మిగిలి ఉంది.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // భద్రత: ఆర్గ్ మరియు అర్గ్‌లు ఒకే వాదనల నుండి వచ్చాయి,
    // ఇది సూచికలు ఎల్లప్పుడూ హద్దుల్లో ఉంటాయని హామీ ఇస్తుంది.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // సరైన వాదనను సంగ్రహించండి
    debug_assert!(arg.position < args.len());
    // భద్రత: ఆర్గ్ మరియు అర్గ్‌లు ఒకే వాదనల నుండి వచ్చాయి,
    // ఇది దాని సూచిక ఎల్లప్పుడూ హద్దుల్లో ఉంటుందని హామీ ఇస్తుంది.
    let value = unsafe { args.get_unchecked(arg.position) };

    // అప్పుడు నిజానికి కొంత ప్రింటింగ్ చేయండి
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // భద్రత: cnt మరియు args ఒకే వాదనల నుండి వచ్చాయి,
            // ఈ సూచిక ఎల్లప్పుడూ హద్దుల్లో ఉంటుందని హామీ ఇస్తుంది.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// ఏదో ముగిసిన తర్వాత పాడింగ్.`Formatter::padding` ద్వారా తిరిగి ఇవ్వబడింది.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// ఈ పోస్ట్ పాడింగ్ వ్రాయండి.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // మేము దీనిని మార్చాలనుకుంటున్నాము
            buf: wrap(self.buf),

            // మరియు వీటిని సంరక్షించండి
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // అన్ని ఆకృతీకరణ traits ఉపయోగించగల ఫార్మాటింగ్ వాదనలు పాడింగ్ మరియు ప్రాసెసింగ్ కోసం ఉపయోగించే సహాయక పద్ధతులు.
    //

    /// ఇప్పటికే ఒక str లోకి విడుదలయ్యే పూర్ణాంకం కోసం సరైన పాడింగ్ చేస్తుంది.
    /// స్ట్రింగ్ పూర్ణాంకం కోసం గుర్తును కలిగి ఉండకూడదు, అది ఈ పద్ధతి ద్వారా జోడించబడుతుంది.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, అసలు పూర్ణాంకం సానుకూలంగా లేదా సున్నాగా ఉందా.
    /// * ఉపసర్గ, '#' అక్షరం (Alternate) అందించబడితే, ఇది సంఖ్య ముందు ఉంచడానికి ఉపసర్గ.
    ///
    /// * buf, సంఖ్యను ఫార్మాట్ చేసిన బైట్ శ్రేణి
    ///
    /// ఈ ఫంక్షన్ సరిగ్గా అందించిన జెండాలతో పాటు కనీస వెడల్పుకు సరిగ్గా లెక్కించబడుతుంది.
    /// ఇది ఖచ్చితత్వాన్ని పరిగణనలోకి తీసుకోదు.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // మేము సంఖ్య అవుట్పుట్ నుండి "-" ను తొలగించాలి.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // సంకేతం ఉన్నట్లయితే వ్రాస్తుంది, ఆపై అభ్యర్థించినట్లయితే ఉపసర్గ
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // `width` ఫీల్డ్ ఈ సమయంలో `min-width` పరామితి కంటే ఎక్కువ.
        match self.width {
            // కనీస పొడవు అవసరాలు లేకపోతే మనం బైట్‌లను వ్రాయవచ్చు.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // మేము కనీస వెడల్పుకు మించి ఉన్నామో లేదో తనిఖీ చేయండి, అలా అయితే మనం కూడా బైట్లు వ్రాయవచ్చు.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // పూరక అక్షరం సున్నా అయితే గుర్తు మరియు ఉపసర్గ పాడింగ్ ముందు వెళ్తుంది
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // లేకపోతే, సైన్ మరియు ఉపసర్గ పాడింగ్ తరువాత వెళుతుంది
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// ఈ ఫంక్షన్ స్ట్రింగ్ స్లైస్ తీసుకుంటుంది మరియు పేర్కొన్న సంబంధిత ఆకృతీకరణ జెండాలను వర్తింపజేసిన తరువాత అంతర్గత బఫర్‌కు విడుదల చేస్తుంది.
    /// సాధారణ తీగలకు గుర్తించబడిన జెండాలు:
    ///
    /// * వెడల్పు, విడుదల చేయవలసిన కనీస వెడల్పు
    /// * fill/align - అందించిన స్ట్రింగ్ ప్యాడ్ చేయవలసి వస్తే ఏమి విడుదల చేయాలి మరియు ఎక్కడ విడుదల చేయాలి
    /// * ఖచ్చితత్వం, విడుదల చేసే గరిష్ట పొడవు, ఈ పొడవు కంటే పొడవుగా ఉంటే స్ట్రింగ్ కత్తిరించబడుతుంది
    ///
    /// ముఖ్యంగా ఈ ఫంక్షన్ `flag` పారామితులను విస్మరిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // ముందు వేగవంతమైన మార్గం ఉందని నిర్ధారించుకోండి
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // `precision` ఫీల్డ్‌ను స్ట్రింగ్ ఫార్మాట్ చేసినందుకు `max-width` గా అర్థం చేసుకోవచ్చు.
        //
        let s = if let Some(max) = self.precision {
            // మా స్ట్రింగ్ ఖచ్చితత్వానికి పొడవుగా ఉంటే, అప్పుడు మనకు కత్తిరించడం ఉండాలి.
            // అయితే `fill`, `width` మరియు `align` వంటి ఇతర జెండాలు ఎప్పటిలాగే పనిచేయాలి.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // ఇక్కడ LLVM `..i` panic `&s[..i]` కాదని నిరూపించదు, కానీ అది panic కాదని మాకు తెలుసు.
                // `unsafe` ను నివారించడానికి `get` + `unwrap_or` ను ఉపయోగించండి మరియు లేకపోతే ఇక్కడ panic-సంబంధిత కోడ్‌ను విడుదల చేయవద్దు.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // `width` ఫీల్డ్ ఈ సమయంలో `min-width` పరామితి కంటే ఎక్కువ.
        match self.width {
            // మేము గరిష్ట పొడవులో ఉంటే, మరియు కనీస పొడవు అవసరాలు లేకపోతే, అప్పుడు మేము స్ట్రింగ్‌ను విడుదల చేయవచ్చు
            //
            None => self.buf.write_str(s),
            // మేము గరిష్ట వెడల్పులో ఉంటే, మేము కనీస వెడల్పుకు మించి ఉన్నామో లేదో తనిఖీ చేయండి, అలా అయితే అది స్ట్రింగ్‌ను విడుదల చేసినంత సులభం.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // మేము గరిష్ట మరియు కనిష్ట వెడల్పు రెండింటిలో ఉంటే, పేర్కొన్న స్ట్రింగ్ + కొంత అమరికతో కనీస వెడల్పును పూరించండి.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// ప్రీ-పాడింగ్ వ్రాసి, అలిఖిత పోస్ట్-పాడింగ్‌ను తిరిగి ఇవ్వండి.
    /// పోస్ట్-పాడింగ్ ప్యాడ్ చేయబడిన విషయం తర్వాత వ్రాయబడిందని నిర్ధారించడానికి కాలర్లు బాధ్యత వహిస్తారు.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// ఆకృతీకరించిన భాగాలను తీసుకుంటుంది మరియు పాడింగ్ వర్తిస్తుంది.
    /// కాలర్ ఇప్పటికే అవసరమైన ఖచ్చితత్వంతో భాగాలను అన్వయించిందని, తద్వారా `self.precision` విస్మరించబడుతుంది.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // సైన్-అవేర్ జీరో పాడింగ్ కోసం, మేము మొదట సంకేతాన్ని అందిస్తాము మరియు మొదటి నుండి మనకు సంకేతం లేనట్లుగా ప్రవర్తిస్తాము.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // ఒక సంకేతం ఎల్లప్పుడూ మొదట వెళ్తుంది
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // ఆకృతీకరించిన భాగాల నుండి గుర్తును తొలగించండి
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // మిగిలిన భాగాలు సాధారణ పాడింగ్ ప్రక్రియ ద్వారా వెళ్తాయి.
            let len = formatted.len();
            let ret = if width <= len {
                // పాడింగ్ లేదు
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // ఇది సాధారణ సందర్భం మరియు మేము సత్వరమార్గాన్ని తీసుకుంటాము
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // భద్రత: ఇది `flt2dec::Part::Num` మరియు `flt2dec::Part::Copy` కోసం ఉపయోగించబడుతుంది.
            // ప్రతి చార్ `c` `b'0'` మరియు `b'9'` మధ్య ఉన్నందున `flt2dec::Part::Num` కోసం ఉపయోగించడం సురక్షితం, అంటే `s` చెల్లుబాటు అయ్యే UTF-8.
            // `buf` సాదా ASCII గా ఉండాలి కాబట్టి ఇది `flt2dec::Part::Copy(buf)` కోసం ఉపయోగించడం ఆచరణలో కూడా సురక్షితం, కానీ ఎవరైనా పబ్లిక్ ఫంక్షన్ అయినందున `buf` కోసం `flt2dec::to_shortest_str` లోకి చెడు విలువలో `flt2dec::to_shortest_str` లోకి వెళ్ళే అవకాశం ఉంది.
            //
            // FIXME: ఇది యుబికి దారితీస్తుందో లేదో నిర్ణయించండి.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 సున్నాలు
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// ఈ ఫార్మాటర్‌లో ఉన్న అంతర్లీన బఫర్‌కు కొంత డేటాను వ్రాస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // ఇది దీనికి సమానం:
    ///         // వ్రాయండి! (ఫార్మాటర్, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// ఈ సందర్భంలో కొన్ని ఆకృతీకరించిన సమాచారాన్ని వ్రాస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// ఆకృతీకరణ కోసం జెండాలు
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// అమరిక ఉన్నప్పుడు అక్షరం 'fill' గా ఉపయోగించబడుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // మేము ">" తో కుడివైపు అమరికను సెట్ చేసాము.
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// ఏ విధమైన అమరిక అభ్యర్థించబడిందో సూచించే ఫ్లాగ్.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// అవుట్పుట్ ఉండాలి అని ఐచ్ఛికంగా పేర్కొన్న పూర్ణాంక వెడల్పు.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // మేము వెడల్పును అందుకుంటే, మేము దానిని ఉపయోగిస్తాము
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // లేకపోతే మేము ప్రత్యేకంగా ఏమీ చేయము
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// సంఖ్యా రకాల కోసం ఐచ్ఛికంగా పేర్కొన్న ఖచ్చితత్వం.
    /// ప్రత్యామ్నాయంగా, స్ట్రింగ్ రకాలు గరిష్ట వెడల్పు.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // మేము ఖచ్చితత్వాన్ని అందుకుంటే, మేము దానిని ఉపయోగిస్తాము.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // లేకపోతే మనం 2 కి డిఫాల్ట్ అవుతాము.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// `+` జెండా పేర్కొనబడిందో నిర్ణయిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// `-` జెండా పేర్కొనబడిందో నిర్ణయిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // మీకు మైనస్ గుర్తు కావాలా?ఒకటి!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// `#` జెండా పేర్కొనబడిందో నిర్ణయిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// `0` జెండా పేర్కొనబడిందో నిర్ణయిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // మేము ఫార్మాటర్ యొక్క ఎంపికలను విస్మరిస్తాము.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: ఈ రెండు జెండాల కోసం మనకు ఏ పబ్లిక్ API కావాలో నిర్ణయించండి.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// స్ట్రక్ట్స్ కోసం [`fmt::Debug`] అమలులను రూపొందించడంలో సహాయపడటానికి రూపొందించిన [`DebugStruct`] బిల్డర్‌ను సృష్టిస్తుంది.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// టుపుల్ స్ట్రక్ట్స్ కోసం `fmt::Debug` అమలులను రూపొందించడంలో సహాయపడటానికి రూపొందించిన `DebugTuple` బిల్డర్‌ను సృష్టిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// జాబితా లాంటి నిర్మాణాల కోసం `fmt::Debug` అమలులను రూపొందించడంలో సహాయపడటానికి రూపొందించిన `DebugList` బిల్డర్‌ను సృష్టిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// సెట్-లాంటి నిర్మాణాల కోసం `fmt::Debug` అమలులను రూపొందించడంలో సహాయపడటానికి రూపొందించిన `DebugSet` బిల్డర్‌ను సృష్టిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// ఈ మరింత క్లిష్టమైన ఉదాహరణలో, మ్యాచ్ ఆయుధాల జాబితాను రూపొందించడానికి మేము [`format_args!`] మరియు `.debug_set()` ని ఉపయోగిస్తాము:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// మ్యాప్ లాంటి నిర్మాణాల కోసం `fmt::Debug` అమలులను రూపొందించడంలో సహాయపడటానికి రూపొందించిన `DebugMap` బిల్డర్‌ను సృష్టిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// కోర్ ఫార్మాటింగ్ traits యొక్క అమలులు

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // చార్ తప్పించుకోవాల్సిన అవసరం ఉంటే, ఇప్పటివరకు బ్యాక్‌లాగ్‌ను ఫ్లష్ చేసి రాయండి, లేకపోతే దాటవేయి
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // ప్రత్యామ్నాయ జెండాను ఇప్పటికే లోవర్‌హెక్స్ ప్రత్యేకమైనదిగా పరిగణిస్తుంది-ఇది 0x తో ఉపసర్గ చేయాలా అని సూచిస్తుంది.
        // సున్నా పొడిగించాలా వద్దా అనే దానిపై పని చేయడానికి మేము దీనిని ఉపయోగిస్తాము, ఆపై ఉపసర్గ పొందడానికి బేషరతుగా దాన్ని సెట్ చేస్తాము.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// వివిధ కోర్ రకాల కోసం Display/Debug అమలు

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell పరస్పరం అరువు తెచ్చుకుంది కాబట్టి మేము దాని విలువను ఇక్కడ చూడలేము.
                // బదులుగా ప్లేస్‌హోల్డర్‌ను చూపించు.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// పరీక్షలు ఇక్కడ ఉంటాయని మీరు If హించినట్లయితే, బదులుగా core/tests/fmt.rs ఫైల్‌ను చూడండి, ఇక్కడ అన్ని rt::Piece నిర్మాణాలను సృష్టించడం కంటే చాలా సులభం.
//
// కేటాయింపులు అవసరమైన వారికి, కేటాయించిన crate లో పరీక్షలు కూడా ఉన్నాయి.