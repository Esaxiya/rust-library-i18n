//! # Rust కోర్ లైబ్రరీ
//!
//! Rust కోర్ లైబ్రరీ అనేది [The Rust Standard Library](../std/index.html) యొక్క డిపెండెన్సీ-ఫ్రీ [^ ఉచిత] పునాది.
//! ఇది భాష మరియు దాని గ్రంథాలయాల మధ్య పోర్టబుల్ జిగురు, అన్ని Rust కోడ్ యొక్క అంతర్గత మరియు ఆదిమ బిల్డింగ్ బ్లాక్‌లను నిర్వచిస్తుంది.
//!
//! ఇది అప్‌స్ట్రీమ్ లైబ్రరీలకు, సిస్టమ్ లైబ్రరీలకు మరియు లిబ్‌సికి లింక్ చేయదు.
//!
//! [^free]: Strictly మాట్లాడుతూ, కొన్ని చిహ్నాలు అవసరం
//!          అవి ఎల్లప్పుడూ అవసరం లేదు.
//!
//! కోర్ లైబ్రరీ *కనిష్టమైనది*: ఇది కుప్ప కేటాయింపు గురించి కూడా తెలియదు, లేదా ఇది సమ్మతి లేదా I/O ను అందించదు.
//! ఈ విషయాలకు ప్లాట్‌ఫాం ఇంటిగ్రేషన్ అవసరం, మరియు ఈ లైబ్రరీ ప్లాట్‌ఫాం-అజ్ఞేయవాది.
//!
//! # కోర్ లైబ్రరీని ఎలా ఉపయోగించాలి
//!
//! దయచేసి ఈ వివరాలన్నీ ప్రస్తుతం స్థిరంగా పరిగణించబడవు.
//!
//!
//!
// FIXME: ఇంటర్ఫేస్ స్థిరపడినప్పుడు నన్ను మరింత వివరంగా నింపండి
//! ఈ లైబ్రరీ ఇప్పటికే ఉన్న కొన్ని చిహ్నాల on హపై నిర్మించబడింది:
//!
//! * `memcpy`, `memcmp`, `memset`, ఇవి కోర్ మెమరీ నిత్యకృత్యాలు, ఇవి తరచూ LLVM చేత ఉత్పత్తి చేయబడతాయి.
//! అదనంగా, ఈ లైబ్రరీ ఈ ఫంక్షన్లకు స్పష్టమైన కాల్స్ చేయగలదు.
//! వారి సంతకాలు సి లో కనిపించినట్లే.
//!   ఈ విధులు తరచుగా సిస్టమ్ libc చేత అందించబడతాయి, కానీ [compiler-builtins crate](https://crates.io/crates/compiler_builtins) ద్వారా కూడా అందించబడతాయి.
//!
//!
//! * `rust_begin_panic` - ఈ ఫంక్షన్ నాలుగు వాదనలు, ఒక `fmt::Arguments`, `&'static str` మరియు రెండు `u32` లను తీసుకుంటుంది.
//! ఈ నాలుగు వాదనలు panic సందేశాన్ని, panic ను ప్రారంభించిన ఫైల్ మరియు ఫైల్ లోపల ఉన్న లైన్ మరియు కాలమ్‌ను నిర్దేశిస్తాయి.
//! ఈ panic ఫంక్షన్‌ను నిర్వచించడం ఈ కోర్ లైబ్రరీ వినియోగదారులదే;ఇది తిరిగి రాదు.
//! దీనికి `panic_impl` అనే `lang` లక్షణం అవసరం.
//!
//! * `rust_eh_personality` - కంపైలర్ యొక్క వైఫల్య విధానాల ద్వారా ఉపయోగించబడుతుంది.
//! ఇది తరచూ GCC యొక్క వ్యక్తిత్వ ఫంక్షన్‌కు మ్యాప్ చేయబడుతుంది, అయితే panic ను ప్రేరేపించని crates ఈ ఫంక్షన్‌ను ఎప్పుడూ పిలవదని హామీ ఇవ్వవచ్చు.
//! `lang` లక్షణాన్ని `eh_personality` అంటారు.
//!
//!
//!

// లిబ్కోర్ అనేక ప్రాథమిక లాంగ్ ఐటెమ్‌లను నిర్వచిస్తుంది కాబట్టి, అన్ని పరీక్షలు విచిత్రమైన సమస్యలను నివారించడానికి ప్రత్యేక crate, libcoretest లో నివసిస్తాయి.
//
// ఇక్కడ మేము స్పష్టంగా#[cfg]-పరీక్షించేటప్పుడు ఈ మొత్తం crate నుండి.
// మేము దీన్ని చేయకపోతే, ఉత్పత్తి చేయబడిన టెస్ట్ ఆర్టిఫ్యాక్ట్ మరియు లింక్డ్ లిబ్టెస్ట్ (ఇది లిబ్‌కోర్‌ను ట్రాన్సిటివ్‌గా కలిగి ఉంటుంది) రెండూ ఒకే లాంగ్ ఐటెమ్‌లను నిర్వచిస్తాయి మరియు ఇది E0152 "found duplicate lang item" లోపానికి కారణమవుతుంది.
//
// వివరాల కోసం #50466 లో చర్చ చూడండి.
//
// ఈ cfg డాక్ పరీక్షలను ప్రభావితం చేయదు.
//
//
#![cfg(not(test))]
#![stable(feature = "core", since = "1.6.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![no_core]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(asm)]
#![feature(cfg_target_has_atomic)]
#![feature(const_heap)]
#![feature(const_alloc_layout)]
#![feature(const_assert_type)]
#![feature(const_discriminant)]
#![feature(const_cell_into_inner)]
#![feature(const_intrinsic_copy)]
#![feature(const_intrinsic_forget)]
#![feature(const_float_classify)]
#![feature(const_float_bits_conv)]
#![feature(const_int_unchecked_arith)]
#![feature(const_mut_refs)]
#![feature(const_refs_to_cell)]
#![feature(const_cttz)]
#![feature(const_panic)]
#![feature(const_pin)]
#![feature(const_fn)]
#![feature(const_fn_union)]
#![feature(const_impl_trait)]
#![feature(const_fn_floating_point_arithmetic)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(const_option)]
#![feature(const_precise_live_drops)]
#![feature(const_ptr_offset)]
#![feature(const_ptr_offset_from)]
#![feature(const_ptr_read)]
#![feature(const_ptr_write)]
#![feature(const_raw_ptr_comparison)]
#![feature(const_raw_ptr_deref)]
#![feature(const_slice_from_raw_parts)]
#![feature(const_slice_ptr_len)]
#![feature(const_size_of_val)]
#![feature(const_swap)]
#![feature(const_align_of_val)]
#![feature(const_type_id)]
#![feature(const_type_name)]
#![feature(const_likely)]
#![feature(const_unreachable_unchecked)]
#![feature(const_maybe_uninit_assume_init)]
#![feature(const_maybe_uninit_as_ptr)]
#![feature(custom_inner_attributes)]
#![feature(decl_macro)]
#![feature(doc_cfg)]
#![feature(doc_spotlight)]
#![feature(duration_consts_2)]
#![feature(duration_saturating_ops)]
#![feature(extended_key_value_attributes)]
#![feature(extern_types)]
#![feature(fundamental)]
#![feature(intra_doc_pointers)]
#![feature(intrinsics)]
#![feature(lang_items)]
#![feature(link_llvm_intrinsics)]
#![feature(llvm_asm)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(exhaustive_patterns)]
#![feature(no_core)]
#![feature(auto_traits)]
#![feature(or_patterns)]
#![feature(prelude_import)]
#![cfg_attr(not(bootstrap), feature(ptr_metadata))]
#![feature(repr_simd, platform_intrinsics)]
#![feature(rustc_attrs)]
#![feature(simd_ffi)]
#![feature(min_specialization)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(stmt_expr_attributes)]
#![feature(str_split_as_str)]
#![feature(str_split_inclusive_as_str)]
#![feature(trait_alias)]
#![feature(transparent_unions)]
#![feature(try_blocks)]
#![feature(unboxed_closures)]
#![feature(unsized_fn_params)]
#![feature(unwind_attributes)]
#![feature(variant_count)]
#![feature(tbm_target_feature)]
#![feature(sse4a_target_feature)]
#![feature(arm_target_feature)]
#![feature(powerpc_target_feature)]
#![feature(mips_target_feature)]
#![feature(aarch64_target_feature)]
#![feature(wasm_target_feature)]
#![feature(avx512_target_feature)]
#![feature(cmpxchg16b_target_feature)]
#![feature(rtm_target_feature)]
#![feature(f16c_target_feature)]
#![feature(hexagon_target_feature)]
#![feature(const_fn_transmute)]
#![feature(abi_unadjusted)]
#![feature(adx_target_feature)]
#![feature(external_doc)]
#![feature(associated_type_bounds)]
#![feature(const_caller_location)]
#![feature(slice_ptr_get)]
#![feature(no_niche)] // rust-lang/rust#68303
#![feature(int_error_matching)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![deny(unsafe_op_in_unsafe_fn)]

#[prelude_import]
#[allow(unused)]
use prelude::v1::*;

#[cfg(not(test))] // #65860 చూడండి
#[macro_use]
mod macros;

#[macro_use]
mod internal_macros;

#[path = "num/shells/int_macros.rs"]
#[macro_use]
mod int_macros;

#[path = "num/shells/i128.rs"]
pub mod i128;
#[path = "num/shells/i16.rs"]
pub mod i16;
#[path = "num/shells/i32.rs"]
pub mod i32;
#[path = "num/shells/i64.rs"]
pub mod i64;
#[path = "num/shells/i8.rs"]
pub mod i8;
#[path = "num/shells/isize.rs"]
pub mod isize;

#[path = "num/shells/u128.rs"]
pub mod u128;
#[path = "num/shells/u16.rs"]
pub mod u16;
#[path = "num/shells/u32.rs"]
pub mod u32;
#[path = "num/shells/u64.rs"]
pub mod u64;
#[path = "num/shells/u8.rs"]
pub mod u8;
#[path = "num/shells/usize.rs"]
pub mod usize;

#[path = "num/f32.rs"]
pub mod f32;
#[path = "num/f64.rs"]
pub mod f64;

#[macro_use]
pub mod num;

/* The libcore prelude, not as all-encompassing as the libstd prelude */

pub mod prelude;

/* Core modules for ownership management */

pub mod hint;
pub mod intrinsics;
pub mod mem;
pub mod ptr;

/* Core language traits */

pub mod borrow;
pub mod clone;
pub mod cmp;
pub mod convert;
pub mod default;
pub mod marker;
pub mod ops;

/* Core types and methods on primitives */

pub mod any;
pub mod array;
pub mod ascii;
pub mod cell;
pub mod char;
pub mod ffi;
pub mod iter;
#[unstable(feature = "once_cell", issue = "74465")]
pub mod lazy;
pub mod option;
pub mod panic;
pub mod panicking;
pub mod pin;
pub mod raw;
pub mod result;
#[unstable(feature = "async_stream", issue = "79024")]
pub mod stream;
pub mod sync;

pub mod fmt;
pub mod hash;
pub mod slice;
pub mod str;
pub mod time;

pub mod unicode;

/* Async */
pub mod future;
pub mod task;

/* Heap memory allocator trait */
#[allow(missing_docs)]
pub mod alloc;

// note: బహిరంగంగా ఉండవలసిన అవసరం లేదు
mod bool;
mod tuple;
mod unit;

#[stable(feature = "core_primitive", since = "1.43.0")]
pub mod primitive;

// `core_arch` crate లో నేరుగా లిబ్‌కోర్‌లోకి లాగండి.`core_arch` యొక్క విషయాలు వేరే రిపోజిటరీలో ఉన్నాయి: rust-lang/stdarch.
//
// `core_arch` లిబ్‌కోర్‌పై ఆధారపడి ఉంటుంది, కానీ ఈ మాడ్యూల్ యొక్క విషయాలు ఇక్కడ నేరుగా లాగడం ద్వారా అమర్చబడతాయి, అంటే crate ఈ crate ను దాని లిబ్‌కోర్‌గా ఉపయోగిస్తుంది.
//
//
//
#[path = "../../stdarch/crates/core_arch/src/mod.rs"]
#[allow(
    missing_docs,
    missing_debug_implementations,
    dead_code,
    unused_imports,
    unsafe_op_in_unsafe_fn
)]
#[cfg_attr(bootstrap, allow(non_autolinks))]
#[cfg_attr(not(bootstrap), allow(rustdoc::non_autolinks))]
// FIXME: క్లాషింగ్_ఎక్స్టర్న్_డిక్లరేషన్స్ తర్వాత ఈ ఉల్లేఖనాన్ని rust-lang/stdarch లోకి తరలించాలి
// విలీనం.lint ఇంకా నిర్వచించబడనందున బూట్స్ట్రాప్ విఫలమైనందున ఇది ప్రస్తుతం సాధ్యం కాదు.
#[allow(clashing_extern_declarations)]
#[unstable(feature = "stdsimd", issue = "48556")]
mod core_arch;

#[stable(feature = "simd_arch", since = "1.27.0")]
pub use core_arch::arch;