//! అక్షర మార్పిడులు.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// `u32` ను `char` గా మారుస్తుంది.
///
/// అన్ని [`చార్`] లు చెల్లుబాటు అయ్యేవి [`u32`] లు అని గమనించండి మరియు వీటిని ఒకదానితో వేయవచ్చు
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// అయితే, రివర్స్ నిజం కాదు: అన్ని చెల్లుబాటు అయ్యే [`u32`] లు చెల్లుబాటు కావు [`చార్`] లు.
/// `from_u32()` [`char`] కోసం ఇన్పుట్ చెల్లుబాటు అయ్యే విలువ కాకపోతే `None` ను తిరిగి ఇస్తుంది.
///
/// ఈ తనిఖీలను విస్మరించే ఈ ఫంక్షన్ యొక్క అసురక్షిత వెర్షన్ కోసం, [`from_u32_unchecked`] చూడండి.
///
///
/// # Examples
///
/// ప్రాథమిక వినియోగం:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// ఇన్పుట్ చెల్లుబాటు అయ్యే [`char`] కానప్పుడు `None` ని తిరిగి ఇస్తుంది:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// ప్రామాణికతను విస్మరించి, `u32` ను `char` గా మారుస్తుంది.
///
/// అన్ని [`చార్`] లు చెల్లుబాటు అయ్యేవి [`u32`] లు అని గమనించండి మరియు వీటిని ఒకదానితో వేయవచ్చు
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// అయితే, రివర్స్ నిజం కాదు: అన్ని చెల్లుబాటు అయ్యే [`u32`] లు చెల్లుబాటు కావు [`చార్`] లు.
/// `from_u32_unchecked()` దీన్ని విస్మరిస్తుంది మరియు గుడ్డిగా [`char`] కు ప్రసారం చేస్తుంది, బహుశా చెల్లనిదాన్ని సృష్టిస్తుంది.
///
///
/// # Safety
///
/// ఈ ఫంక్షన్ సురక్షితం కాదు, ఎందుకంటే ఇది చెల్లని `char` విలువలను నిర్మిస్తుంది.
///
/// ఈ ఫంక్షన్ యొక్క సురక్షిత సంస్కరణ కోసం, [`from_u32`] ఫంక్షన్ చూడండి.
///
/// # Examples
///
/// ప్రాథమిక వినియోగం:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // భద్రత: `i` చెల్లుబాటు అయ్యే చార్ విలువ అని కాలర్ హామీ ఇవ్వాలి.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// [`char`] ను [`u32`] గా మారుస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`] ను [`u64`] గా మారుస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // చార్ కోడ్ పాయింట్ యొక్క విలువకు ప్రసారం చేయబడుతుంది, తరువాత సున్నా 64 బిట్‌కు విస్తరించబడుతుంది.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] చూడండి
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// [`char`] ను [`u128`] గా మారుస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // చార్ కోడ్ పాయింట్ యొక్క విలువకు ప్రసారం చేయబడుతుంది, తరువాత సున్నా 128 బిట్‌కు విస్తరించబడుతుంది.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] చూడండి
        c as u128
    }
}

/// 0 +00 లో బైట్‌ను మ్యాప్ చేస్తుంది ..=0xFF ను `char` కి కోడ్ పాయింట్ అదే విలువను కలిగి ఉంటుంది, U + 0000 లో ..=U + 00FF.
///
/// IANA ISO-8859-1 అని పిలిచే అక్షర ఎన్‌కోడింగ్‌తో బైట్‌లను సమర్థవంతంగా డీకోడ్ చేసే విధంగా యూనికోడ్ రూపొందించబడింది.
/// ఈ ఎన్కోడింగ్ ASCII కి అనుకూలంగా ఉంటుంది.
///
/// ఇది ISO/IEC 8859-1 అకా నుండి భిన్నంగా ఉందని గమనించండి
/// ISO 8859-1 (ఒక తక్కువ హైఫన్‌తో), ఇది కొన్ని "blanks", బైట్ విలువలను ఏ అక్షరానికి కేటాయించదు.
/// ISO-8859-1 (IANA ఒకటి) వాటిని C0 మరియు C1 నియంత్రణ కోడ్‌లకు కేటాయిస్తుంది.
///
/// ఇది విండోస్-1252 అకా నుండి *కూడా* భిన్నంగా ఉందని గమనించండి
/// కోడ్ పేజీ 1252, ఇది సూపర్సెట్ ISO/IEC 8859-1, ఇది కొన్ని (అన్నీ కాదు!) ఖాళీలను విరామచిహ్నాలకు మరియు వివిధ లాటిన్ అక్షరాలకు కేటాయిస్తుంది.
///
/// విషయాలను మరింత గందరగోళపరిచేందుకు, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` మరియు `windows-1252` అన్నీ విండోస్-1252 యొక్క సూపర్‌సెట్ కోసం మారుపేర్లు, ఇవి మిగిలిన ఖాళీలను సంబంధిత C0 మరియు C1 నియంత్రణ కోడ్‌లతో నింపుతాయి.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// [`u8`] ను [`char`] గా మారుస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// చార్‌ను అన్వయించేటప్పుడు తిరిగి ఇవ్వగల లోపం.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // భద్రత: ఇది చట్టబద్ధమైన యూనికోడ్ విలువ అని తనిఖీ చేసింది
            Ok(unsafe { transmute(i) })
        }
    }
}

/// u32 నుండి చార్‌కు మార్పిడి విఫలమైనప్పుడు లోపం రకం తిరిగి వచ్చింది.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// ఇచ్చిన రాడిక్స్‌లోని అంకెను `char` గా మారుస్తుంది.
///
/// ఇక్కడ 'radix' ను కొన్నిసార్లు 'base' అని కూడా పిలుస్తారు.
/// రెండు యొక్క రాడిక్స్ కొన్ని సాధారణ విలువలను ఇవ్వడానికి బైనరీ సంఖ్యను, పది, దశాంశ, మరియు పదహారు, హెక్సాడెసిమల్ యొక్క రాడిక్స్ను సూచిస్తుంది.
///
/// ఏకపక్ష రేడిస్‌లకు మద్దతు ఉంది.
///
/// `from_digit()` ఇచ్చిన రాడిక్స్‌లో ఇన్‌పుట్ అంకె కాకపోతే `None` తిరిగి వస్తుంది.
///
/// # Panics
///
/// 36 కన్నా పెద్ద రాడిక్స్ ఇస్తే Panics.
///
/// # Examples
///
/// ప్రాథమిక వినియోగం:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // దశాంశం 11 బేస్ 16 లో ఒకే అంకె
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// ఇన్పుట్ అంకె కానప్పుడు `None` ని తిరిగి ఇస్తుంది:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// ఒక పెద్ద రాడిక్స్ను దాటి, panic కి కారణమవుతుంది:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}