//! impl చార్ {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// `char` కలిగి ఉన్న అత్యధిక చెల్లుబాటు అయ్యే కోడ్ పాయింట్.
    ///
    /// `char` అనేది [Unicode Scalar Value], అంటే ఇది [Code Point] అని అర్థం, కానీ ఒక నిర్దిష్ట పరిధిలో ఉన్నవి మాత్రమే.
    /// `MAX` చెల్లుబాటు అయ్యే [Unicode Scalar Value] అత్యధిక చెల్లుబాటు అయ్యే కోడ్ పాయింట్.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` డీకోడింగ్ లోపాన్ని సూచించడానికి యునికోడ్‌లో () ఉపయోగించబడుతుంది.
    ///
    /// ఉదాహరణకు, [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) కు చెడుగా ఏర్పడిన UTF-8 బైట్‌లను ఇచ్చేటప్పుడు ఇది సంభవించవచ్చు.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// [Unicode](http://www.unicode.org/) యొక్క సంస్కరణ `char` మరియు `str` పద్ధతుల యొక్క యూనికోడ్ భాగాలపై ఆధారపడి ఉంటుంది.
    ///
    /// యూనికోడ్ యొక్క క్రొత్త సంస్కరణలు క్రమం తప్పకుండా విడుదల చేయబడతాయి మరియు తరువాత యూనికోడ్‌ను బట్టి ప్రామాణిక లైబ్రరీలోని అన్ని పద్ధతులు నవీకరించబడతాయి.
    /// అందువల్ల కొన్ని `char` మరియు `str` పద్ధతుల ప్రవర్తన మరియు ఈ స్థిరమైన విలువ కాలక్రమేణా మారుతుంది.
    /// ఇది బ్రేకింగ్ మార్పుగా పరిగణించబడదు.
    ///
    /// వెర్షన్ నంబరింగ్ పథకం [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) లో వివరించబడింది.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// `iter` లో UTF-16 ఎన్కోడ్ చేసిన కోడ్ పాయింట్లపై ఇటరేటర్‌ను సృష్టిస్తుంది, జతచేయని సర్రోగేట్‌లను `ఎర్'లుగా తిరిగి ఇస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// `Err` ఫలితాలను పున character స్థాపన అక్షరంతో భర్తీ చేయడం ద్వారా నష్టపోయే డీకోడర్‌ను పొందవచ్చు:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32` ను `char` గా మారుస్తుంది.
    ///
    /// అన్ని `చార్`లు చెల్లుబాటు అయ్యేవి [`u32`] లు అని గమనించండి మరియు వీటిని ఒకదానితో వేయవచ్చు
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// అయితే, రివర్స్ నిజం కాదు: అన్ని చెల్లుబాటు అయ్యే [`u32`] లు చెల్లుబాటు అయ్యే`చార్`లు కాదు.
    /// `from_u32()` `char` కోసం ఇన్పుట్ చెల్లుబాటు అయ్యే విలువ కాకపోతే `None` ను తిరిగి ఇస్తుంది.
    ///
    /// ఈ తనిఖీలను విస్మరించే ఈ ఫంక్షన్ యొక్క అసురక్షిత వెర్షన్ కోసం, [`from_u32_unchecked`] చూడండి.
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// ఇన్పుట్ చెల్లుబాటు అయ్యే `char` కానప్పుడు `None` ని తిరిగి ఇస్తుంది:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// ప్రామాణికతను విస్మరించి, `u32` ను `char` గా మారుస్తుంది.
    ///
    /// అన్ని `చార్`లు చెల్లుబాటు అయ్యేవి [`u32`] లు అని గమనించండి మరియు వీటిని ఒకదానితో వేయవచ్చు
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// అయితే, రివర్స్ నిజం కాదు: అన్ని చెల్లుబాటు అయ్యే [`u32`] లు చెల్లుబాటు అయ్యే`చార్`లు కాదు.
    /// `from_u32_unchecked()` దీన్ని విస్మరిస్తుంది మరియు `char` కు గుడ్డిగా ప్రసారం చేస్తుంది, బహుశా చెల్లనిదాన్ని సృష్టిస్తుంది.
    ///
    ///
    /// # Safety
    ///
    /// ఈ ఫంక్షన్ సురక్షితం కాదు, ఎందుకంటే ఇది చెల్లని `char` విలువలను నిర్మిస్తుంది.
    ///
    /// ఈ ఫంక్షన్ యొక్క సురక్షిత సంస్కరణ కోసం, [`from_u32`] ఫంక్షన్ చూడండి.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // భద్రత: భద్రతా ఒప్పందాన్ని కాలర్ సమర్థించాలి.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// ఇచ్చిన రాడిక్స్‌లోని అంకెను `char` గా మారుస్తుంది.
    ///
    /// ఇక్కడ 'radix' ను కొన్నిసార్లు 'base' అని కూడా పిలుస్తారు.
    /// రెండు యొక్క రాడిక్స్ కొన్ని సాధారణ విలువలను ఇవ్వడానికి బైనరీ సంఖ్యను, పది, దశాంశ, మరియు పదహారు, హెక్సాడెసిమల్ యొక్క రాడిక్స్ను సూచిస్తుంది.
    ///
    /// ఏకపక్ష రేడిస్‌లకు మద్దతు ఉంది.
    ///
    /// `from_digit()` ఇచ్చిన రాడిక్స్‌లో ఇన్‌పుట్ అంకె కాకపోతే `None` తిరిగి వస్తుంది.
    ///
    /// # Panics
    ///
    /// 36 కన్నా పెద్ద రాడిక్స్ ఇస్తే Panics.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // దశాంశం 11 బేస్ 16 లో ఒకే అంకె
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// ఇన్పుట్ అంకె కానప్పుడు `None` ని తిరిగి ఇస్తుంది:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// ఒక పెద్ద రాడిక్స్ను దాటి, panic కి కారణమవుతుంది:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// ఇచ్చిన రాడిక్స్‌లో `char` అంకె అయితే తనిఖీ చేస్తుంది.
    ///
    /// ఇక్కడ 'radix' ను కొన్నిసార్లు 'base' అని కూడా పిలుస్తారు.
    /// రెండు యొక్క రాడిక్స్ కొన్ని సాధారణ విలువలను ఇవ్వడానికి బైనరీ సంఖ్యను, పది, దశాంశ, మరియు పదహారు, హెక్సాడెసిమల్ యొక్క రాడిక్స్ను సూచిస్తుంది.
    ///
    /// ఏకపక్ష రేడిస్‌లకు మద్దతు ఉంది.
    ///
    /// [`is_numeric()`] తో పోలిస్తే, ఈ ఫంక్షన్ `0-9`, `a-z` మరియు `A-Z` అక్షరాలను మాత్రమే గుర్తిస్తుంది.
    ///
    /// 'Digit' కింది అక్షరాలు మాత్రమే అని నిర్వచించబడింది:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit' గురించి మరింత సమగ్ర అవగాహన కోసం, [`is_numeric()`] చూడండి.
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// 36 కన్నా పెద్ద రాడిక్స్ ఇస్తే Panics.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// ఒక పెద్ద రాడిక్స్ను దాటి, panic కి కారణమవుతుంది:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// ఇచ్చిన రాడిక్స్‌లో `char` ను అంకెగా మారుస్తుంది.
    ///
    /// ఇక్కడ 'radix' ను కొన్నిసార్లు 'base' అని కూడా పిలుస్తారు.
    /// రెండు యొక్క రాడిక్స్ కొన్ని సాధారణ విలువలను ఇవ్వడానికి బైనరీ సంఖ్యను, పది, దశాంశ, మరియు పదహారు, హెక్సాడెసిమల్ యొక్క రాడిక్స్ను సూచిస్తుంది.
    ///
    /// ఏకపక్ష రేడిస్‌లకు మద్దతు ఉంది.
    ///
    /// 'Digit' కింది అక్షరాలు మాత్రమే అని నిర్వచించబడింది:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// ఇచ్చిన రాడిక్స్‌లో `char` అంకెను సూచించకపోతే `None` ని అందిస్తుంది.
    ///
    /// # Panics
    ///
    /// 36 కన్నా పెద్ద రాడిక్స్ ఇస్తే Panics.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// అంకెలు కాని ఫలితాలను దాటడం వైఫల్యానికి దారితీస్తుంది:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// ఒక పెద్ద రాడిక్స్ను దాటి, panic కి కారణమవుతుంది:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // `radix` స్థిరంగా మరియు 10 లేదా అంతకంటే తక్కువ సందర్భాల్లో అమలు వేగాన్ని మెరుగుపరచడానికి కోడ్ ఇక్కడ విభజించబడింది
        //
        let val = if likely(radix <= 10) {
            // అంకె కాకపోతే, రాడిక్స్ కంటే ఎక్కువ సంఖ్య సృష్టించబడుతుంది.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// అక్షరం యొక్క హెక్సాడెసిమల్ యునికోడ్ ఎస్కేప్‌ను `చార్`లుగా ఇచ్చే ఇరేటర్‌ను అందిస్తుంది.
    ///
    /// ఇది `\u{NNNNNN}` రూపం యొక్క Rust వాక్యనిర్మాణంతో అక్షరాల నుండి తప్పించుకుంటుంది, ఇక్కడ `NNNNNN` ఒక హెక్సాడెసిమల్ ప్రాతినిధ్యం.
    ///
    ///
    /// # Examples
    ///
    /// మళ్ళిగా:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// నేరుగా `println!` ను ఉపయోగించడం:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// రెండూ దీనికి సమానం:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` ఉపయోగించి:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1 c==0 కొరకు కోడ్ ఒక అంకెను ముద్రించాలని లెక్కిస్తుంది మరియు (ఇది ఒకే విధంగా ఉంటుంది)(31, 32) అండర్ ఫ్లోను నివారిస్తుంది
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // అత్యంత ముఖ్యమైన హెక్స్ అంకెల సూచిక
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// విస్తరించిన గ్రాఫిమ్ కోడ్‌పాయింట్ల నుండి తప్పించుకోవడానికి ఐచ్ఛికంగా అనుమతించే `escape_debug` యొక్క విస్తరించిన సంస్కరణ.
    /// స్ట్రింగ్ ప్రారంభంలో ఉన్నప్పుడు నాన్‌స్పేసింగ్ మార్కులు వంటి అక్షరాలను బాగా ఫార్మాట్ చేయడానికి ఇది మాకు అనుమతిస్తుంది.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// అక్షరం యొక్క అక్షర తప్పించుకునే కోడ్‌ను `చార్`లుగా ఇచ్చే ఇరేటర్‌ను అందిస్తుంది.
    ///
    /// ఇది `str` లేదా `char` యొక్క `Debug` అమలులకు సమానమైన అక్షరాల నుండి తప్పించుకుంటుంది.
    ///
    ///
    /// # Examples
    ///
    /// మళ్ళిగా:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// నేరుగా `println!` ను ఉపయోగించడం:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// రెండూ దీనికి సమానం:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` ఉపయోగించి:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// అక్షరం యొక్క అక్షర తప్పించుకునే కోడ్‌ను `చార్`లుగా ఇచ్చే ఇరేటర్‌ను అందిస్తుంది.
    ///
    /// C ++ 11 మరియు ఇలాంటి సి-ఫ్యామిలీ భాషలతో సహా వివిధ భాషలలో చట్టబద్ధమైన అక్షరాస్యతలను ఉత్పత్తి చేసే పక్షపాతంతో డిఫాల్ట్ ఎంపిక చేయబడుతుంది.
    /// ఖచ్చితమైన నియమాలు:
    ///
    /// * టాబ్ `\t` గా తప్పించుకుంది.
    /// * క్యారేజ్ రిటర్న్ `\r` గా తప్పించుకుంది.
    /// * లైన్ ఫీడ్ `\n` గా తప్పించుకుంది.
    /// * సింగిల్ కోట్ `\'` గా తప్పించుకుంది.
    /// * డబుల్ కోట్ `\"` గా తప్పించుకుంది.
    /// * బాక్ స్లాష్ `\\` గా తప్పించుకుంది.
    /// * 'ముద్రించదగిన ASCII' పరిధి `0x20` .. `0x7e` కలుపుకొని ఏదైనా అక్షరం తప్పించుకోలేదు.
    /// * అన్ని ఇతర పాత్రలకు హెక్సాడెసిమల్ యూనికోడ్ తప్పించుకుంటారు;[`escape_unicode`] చూడండి.
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// మళ్ళిగా:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// నేరుగా `println!` ను ఉపయోగించడం:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// రెండూ దీనికి సమానం:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` ఉపయోగించి:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// UTF-8 లో ఎన్కోడ్ చేయబడితే ఈ `char` కి అవసరమైన బైట్ల సంఖ్యను అందిస్తుంది.
    ///
    /// ఆ బైట్‌ల సంఖ్య ఎల్లప్పుడూ 1 మరియు 4 మధ్య ఉంటుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` రకం దాని విషయాలు UTF-8 అని హామీ ఇస్తుంది, కాబట్టి ప్రతి కోడ్ పాయింట్ `&str` లోనే `char` vs గా సూచించబడితే అది తీసుకునే పొడవును పోల్చవచ్చు:
    ///
    ///
    /// ```
    /// // అక్షరాలుగా
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // రెండింటినీ మూడు బైట్లుగా సూచించవచ్చు
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // &str గా, ఈ రెండు UTF-8 లో ఎన్కోడ్ చేయబడ్డాయి
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // వారు మొత్తం ఆరు బైట్లు తీసుకుంటున్నారని మనం చూడవచ్చు ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... &str లాగానే
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// UTF-16 లో ఎన్కోడ్ చేయబడితే ఈ `char` అవసరమయ్యే 16-బిట్ కోడ్ యూనిట్ల సంఖ్యను అందిస్తుంది.
    ///
    ///
    /// ఈ భావన యొక్క మరింత వివరణ కోసం [`len_utf8()`] కోసం డాక్యుమెంటేషన్ చూడండి.
    /// ఈ ఫంక్షన్ అద్దం, కానీ UTF-8 కు బదులుగా UTF-16 కోసం.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// అందించిన బైట్ బఫర్‌లో ఈ అక్షరాన్ని UTF-8 గా ఎన్‌కోడ్ చేసి, ఆపై ఎన్‌కోడ్ చేసిన అక్షరాన్ని కలిగి ఉన్న బఫర్ యొక్క సబ్‌లైస్‌ను తిరిగి ఇస్తుంది.
    ///
    ///
    /// # Panics
    ///
    /// బఫర్ తగినంత పెద్దది కాకపోతే Panics.
    /// ఏదైనా `char` ను ఎన్కోడ్ చేయడానికి తగినంత పొడవు నాలుగు బఫర్ పెద్దది.
    ///
    /// # Examples
    ///
    /// ఈ రెండు ఉదాహరణలలో, 'ß' ఎన్కోడ్ చేయడానికి రెండు బైట్లు తీసుకుంటుంది.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// చాలా చిన్న బఫర్:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // భద్రత: `char` సర్రోగేట్ కాదు, కాబట్టి ఇది చెల్లుబాటు అయ్యే UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// అందించిన `u16` బఫర్‌లోకి ఈ అక్షరాన్ని UTF-16 గా ఎన్‌కోడ్ చేసి, ఆపై ఎన్‌కోడ్ చేసిన అక్షరాన్ని కలిగి ఉన్న బఫర్ యొక్క సబ్‌లైస్‌ను తిరిగి ఇస్తుంది.
    ///
    ///
    /// # Panics
    ///
    /// బఫర్ తగినంత పెద్దది కాకపోతే Panics.
    /// పొడవు 2 యొక్క బఫర్ ఏదైనా `char` ను ఎన్కోడ్ చేయడానికి సరిపోతుంది.
    ///
    /// # Examples
    ///
    /// ఈ రెండు ఉదాహరణలలో, '𝕊' ఎన్కోడ్ చేయడానికి రెండు `u16` లను తీసుకుంటుంది.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// చాలా చిన్న బఫర్:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// ఈ `char` కి `Alphabetic` ఆస్తి ఉంటే `true` ని అందిస్తుంది.
    ///
    /// `Alphabetic` [Unicode Standard] యొక్క చాప్టర్ 4 (క్యారెక్టర్ ప్రాపర్టీస్) లో వివరించబడింది మరియు [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] లో పేర్కొనబడింది.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // ప్రేమ చాలా విషయాలు, కానీ అది అక్షరమాల కాదు
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// ఈ `char` కి `Lowercase` ఆస్తి ఉంటే `true` ని అందిస్తుంది.
    ///
    /// `Lowercase` [Unicode Standard] యొక్క చాప్టర్ 4 (క్యారెక్టర్ ప్రాపర్టీస్) లో వివరించబడింది మరియు [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] లో పేర్కొనబడింది.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // వివిధ చైనీస్ స్క్రిప్ట్‌లు మరియు విరామచిహ్నాలకు కేసు లేదు, మరియు:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// ఈ `char` కి `Uppercase` ఆస్తి ఉంటే `true` ని అందిస్తుంది.
    ///
    /// `Uppercase` [Unicode Standard] యొక్క చాప్టర్ 4 (క్యారెక్టర్ ప్రాపర్టీస్) లో వివరించబడింది మరియు [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] లో పేర్కొనబడింది.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // వివిధ చైనీస్ స్క్రిప్ట్‌లు మరియు విరామచిహ్నాలకు కేసు లేదు, మరియు:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// ఈ `char` కి `White_Space` ఆస్తి ఉంటే `true` ని అందిస్తుంది.
    ///
    /// `White_Space` [Unicode Character Database][ucd] [`PropList.txt`] లో పేర్కొనబడింది.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // విచ్ఛిన్నం కాని స్థలం
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// ఈ `char` [`is_alphabetic()`] లేదా [`is_numeric()`] ను సంతృప్తిపరిస్తే `true` ని అందిస్తుంది.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// ఈ `char` నియంత్రణ కోడ్‌ల కోసం సాధారణ వర్గాన్ని కలిగి ఉంటే `true` ని అందిస్తుంది.
    ///
    /// నియంత్రణ సంకేతాలు (`Cc` యొక్క సాధారణ వర్గంతో కోడ్ పాయింట్లు) [Unicode Standard] యొక్క చాప్టర్ 4 (క్యారెక్టర్ ప్రాపర్టీస్) లో వివరించబడ్డాయి మరియు [Unicode Character Database][ucd] [`UnicodeData.txt`] లో పేర్కొనబడ్డాయి.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// // U + 009C, STRING TERMINATOR
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// ఈ `char` కి `Grapheme_Extend` ఆస్తి ఉంటే `true` ని అందిస్తుంది.
    ///
    /// `Grapheme_Extend` [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] లో వివరించబడింది మరియు [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] లో పేర్కొనబడింది.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// ఈ `char` సంఖ్యలకు సాధారణ వర్గాలలో ఒకటి ఉంటే `true` ని అందిస్తుంది.
    ///
    /// సంఖ్యల కోసం సాధారణ వర్గాలు (దశాంశ అంకెలకు `Nd`, అక్షరం లాంటి సంఖ్యా అక్షరాల కోసం `Nl` మరియు ఇతర సంఖ్యా అక్షరాల కోసం `No`) [Unicode Character Database][ucd] [`UnicodeData.txt`] లో పేర్కొనబడ్డాయి.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// ఈ `char` యొక్క చిన్న అక్షర మ్యాపింగ్‌ను ఒకటి లేదా అంతకంటే ఎక్కువ ఇచ్చే ఇటరేటర్‌ను అందిస్తుంది
    /// `char`s.
    ///
    /// ఈ `char` లో చిన్న అక్షర మ్యాపింగ్ లేకపోతే, ఇరేటర్ అదే `char` ను ఇస్తుంది.
    ///
    /// ఈ `char` కి [Unicode Character Database][ucd] [`UnicodeData.txt`] ఇచ్చిన వన్-టు-వన్ లోవర్‌కేస్ మ్యాపింగ్ ఉంటే, ఇరేటర్ ఆ `char` ను ఇస్తుంది.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// ఈ `char` కి ప్రత్యేక పరిగణనలు అవసరమైతే (ఉదా. బహుళ `చార్`లు) ఇరేటర్ [`SpecialCasing.txt`] ఇచ్చిన`చార్` (ల) ను ఇస్తుంది.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// ఈ ఆపరేషన్ టైలరింగ్ లేకుండా షరతులు లేని మ్యాపింగ్ చేస్తుంది.అంటే, మార్పిడి సందర్భం మరియు భాష నుండి స్వతంత్రంగా ఉంటుంది.
    ///
    /// [Unicode Standard] లో, చాప్టర్ 4 (క్యారెక్టర్ ప్రాపర్టీస్) సాధారణంగా కేస్ మ్యాపింగ్ గురించి చర్చిస్తుంది మరియు చాప్టర్ 3 (Conformance) కేస్ మార్పిడి కోసం డిఫాల్ట్ అల్గోరిథం గురించి చర్చిస్తుంది.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// మళ్ళిగా:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// నేరుగా `println!` ను ఉపయోగించడం:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// రెండూ దీనికి సమానం:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` ఉపయోగించి:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // కొన్నిసార్లు ఫలితం ఒకటి కంటే ఎక్కువ అక్షరాలు:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // పెద్ద మరియు చిన్న అక్షరాలు రెండూ లేని అక్షరాలు తమను తాము మార్చుకుంటాయి.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// ఈ `char` యొక్క అప్పర్‌కేస్ మ్యాపింగ్‌ను ఒకటి లేదా అంతకంటే ఎక్కువ ఇచ్చే ఇటరేటర్‌ను అందిస్తుంది
    /// `char`s.
    ///
    /// ఈ `char` కి అప్పర్‌కేస్ మ్యాపింగ్ లేకపోతే, ఇరేటర్ అదే `char` ను ఇస్తుంది.
    ///
    /// ఈ `char` కి [Unicode Character Database][ucd] [`UnicodeData.txt`] ఇచ్చిన వన్-టు-వన్ అప్పర్‌కేస్ మ్యాపింగ్ ఉంటే, ఇరేటర్ ఆ `char` ను ఇస్తుంది.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// ఈ `char` కి ప్రత్యేక పరిగణనలు అవసరమైతే (ఉదా. బహుళ `చార్`లు) ఇరేటర్ [`SpecialCasing.txt`] ఇచ్చిన`చార్` (ల) ను ఇస్తుంది.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// ఈ ఆపరేషన్ టైలరింగ్ లేకుండా షరతులు లేని మ్యాపింగ్ చేస్తుంది.అంటే, మార్పిడి సందర్భం మరియు భాష నుండి స్వతంత్రంగా ఉంటుంది.
    ///
    /// [Unicode Standard] లో, చాప్టర్ 4 (క్యారెక్టర్ ప్రాపర్టీస్) సాధారణంగా కేస్ మ్యాపింగ్ గురించి చర్చిస్తుంది మరియు చాప్టర్ 3 (Conformance) కేస్ మార్పిడి కోసం డిఫాల్ట్ అల్గోరిథం గురించి చర్చిస్తుంది.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// మళ్ళిగా:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// నేరుగా `println!` ను ఉపయోగించడం:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// రెండూ దీనికి సమానం:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` ఉపయోగించి:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // కొన్నిసార్లు ఫలితం ఒకటి కంటే ఎక్కువ అక్షరాలు:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // పెద్ద మరియు చిన్న అక్షరాలు రెండూ లేని అక్షరాలు తమను తాము మార్చుకుంటాయి.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # లొకేల్‌పై గమనిక
    ///
    /// టర్కిష్ భాషలో, లాటిన్లో 'i' కి సమానమైనది రెండు బదులు ఐదు రూపాలను కలిగి ఉంది:
    ///
    /// * 'Dotless': I/ı, కొన్నిసార్లు వ్రాస్తారు
    /// * 'Dotted': /I
    ///
    /// చిన్న చుక్కల 'i' లాటిన్ మాదిరిగానే ఉంటుందని గమనించండి.అందువల్ల:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// ఇక్కడ `upper_i` యొక్క విలువ టెక్స్ట్ యొక్క భాషపై ఆధారపడి ఉంటుంది: మేము `en-US` లో ఉంటే, అది `"I"` గా ఉండాలి, కానీ మనం `tr_TR` లో ఉంటే, అది `"İ"` గా ఉండాలి.
    /// `to_uppercase()` దీన్ని పరిగణనలోకి తీసుకోదు మరియు:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// భాషలలో ఉంది.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// విలువ ASCII పరిధిలో ఉందో లేదో తనిఖీ చేస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// దాని ASCII అప్పర్ కేసులో విలువ యొక్క కాపీని సమానంగా చేస్తుంది.
    ///
    /// ASCII అక్షరాలు 'a' నుండి 'z' వరకు 'A' నుండి 'Z' వరకు మ్యాప్ చేయబడతాయి, కాని ASCII కాని అక్షరాలు మారవు.
    ///
    /// స్థానంలో ఉన్న విలువను పెద్దదిగా చేయడానికి, [`make_ascii_uppercase()`] ని ఉపయోగించండి.
    ///
    /// ASCII కాని అక్షరాలతో పాటు ASCII అక్షరాలను పెద్దదిగా చేయడానికి, [`to_uppercase()`] ఉపయోగించండి.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// దాని ASCII లోయర్ కేస్ సమానమైన విలువ యొక్క కాపీని చేస్తుంది.
    ///
    /// ASCII అక్షరాలు 'A' నుండి 'Z' వరకు 'a' నుండి 'z' వరకు మ్యాప్ చేయబడతాయి, కాని ASCII కాని అక్షరాలు మారవు.
    ///
    /// స్థానంలో ఉన్న విలువను తగ్గించడానికి, [`make_ascii_lowercase()`] ఉపయోగించండి.
    ///
    /// ASCII కాని అక్షరాలతో పాటు ASCII అక్షరాలను చిన్నదిగా చేయడానికి, [`to_lowercase()`] ని ఉపయోగించండి.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// రెండు విలువలు ASCII కేస్-ఇన్సెన్సిటివ్ మ్యాచ్ అని తనిఖీ చేస్తుంది.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` కి సమానం.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// ఈ రకాన్ని దాని ASCII అప్పర్ కేస్ సమానమైన స్థలంలోకి మారుస్తుంది.
    ///
    /// ASCII అక్షరాలు 'a' నుండి 'z' వరకు 'A' నుండి 'Z' వరకు మ్యాప్ చేయబడతాయి, కాని ASCII కాని అక్షరాలు మారవు.
    ///
    /// ఇప్పటికే ఉన్నదాన్ని సవరించకుండా క్రొత్త పెద్ద విలువను తిరిగి ఇవ్వడానికి, [`to_ascii_uppercase()`] ని ఉపయోగించండి.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// ఈ రకాన్ని దాని ASCII లోయర్ కేస్ సమానమైన స్థలంలోకి మారుస్తుంది.
    ///
    /// ASCII అక్షరాలు 'A' నుండి 'Z' వరకు 'a' నుండి 'z' వరకు మ్యాప్ చేయబడతాయి, కాని ASCII కాని అక్షరాలు మారవు.
    ///
    /// ఇప్పటికే ఉన్నదాన్ని సవరించకుండా క్రొత్త చిన్న విలువను తిరిగి ఇవ్వడానికి, [`to_ascii_lowercase()`] ని ఉపయోగించండి.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// విలువ ASCII అక్షర అక్షరం కాదా అని తనిఖీ చేస్తుంది:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', లేదా
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// విలువ ASCII పెద్ద అక్షరం కాదా అని తనిఖీ చేస్తుంది:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// విలువ ASCII చిన్న అక్షరం కాదా అని తనిఖీ చేస్తుంది:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// విలువ ASCII ఆల్ఫాన్యూమరిక్ అక్షరం కాదా అని తనిఖీ చేస్తుంది:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', లేదా
    /// - U + 0061 'a' ..=U + 007A 'z', లేదా
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// విలువ ASCII దశాంశ అంకె అయితే తనిఖీ చేస్తుంది:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// విలువ ASCII హెక్సాడెసిమల్ అంకె అయితే తనిఖీ చేస్తుంది:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', లేదా
    /// - U + 0041 'A' ..=U + 0046 'F', లేదా
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// విలువ ASCII విరామచిహ్న అక్షరం కాదా అని తనిఖీ చేస్తుంది:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, లేదా
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, లేదా
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, లేదా
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// విలువ ASCII గ్రాఫిక్ అక్షరమా అని తనిఖీ చేస్తుంది:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// విలువ ASCII వైట్‌స్పేస్ అక్షరమా అని తనిఖీ చేస్తుంది:
    /// U + 0020 SPACE, U + 0009 హారిజోంటల్ టాబ్, U + 000A లైన్ ఫీడ్, U + 000C ఫారం ఫీడ్, లేదా U + 000D CARRIAGE రిటర్న్.
    ///
    /// Rust వాట్డబ్ల్యుజి ఇన్ఫ్రా స్టాండర్డ్ యొక్క [definition of ASCII whitespace][infra-aw] ను ఉపయోగిస్తుంది.విస్తృత ఉపయోగంలో అనేక ఇతర నిర్వచనాలు ఉన్నాయి.
    /// ఉదాహరణకు, [the POSIX locale][pct] లో U + 000B VERTICAL TAB మరియు పైన పేర్కొన్న అన్ని అక్షరాలు ఉన్నాయి, కానీ-అదే స్పెసిఫికేషన్ నుండి-[బోర్న్ shell లో "field splitting" కోసం డిఫాల్ట్ నియమం][bfs]*మాత్రమే* SPACE, HORIZONTAL TAB మరియు వైట్‌స్పేస్‌గా LINE ఫీడ్.
    ///
    ///
    /// మీరు ఇప్పటికే ఉన్న ఫైల్ ఫార్మాట్‌ను ప్రాసెస్ చేసే ప్రోగ్రామ్‌ను వ్రాస్తుంటే, ఈ ఫంక్షన్‌ను ఉపయోగించే ముందు వైట్‌స్పేస్ యొక్క ఆ ఫార్మాట్ యొక్క నిర్వచనం ఏమిటో తనిఖీ చేయండి.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// విలువ ASCII నియంత్రణ అక్షరమైతే తనిఖీ చేస్తుంది:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR, లేదా U + 007F DELETE.
    /// చాలా ASCII వైట్‌స్పేస్ అక్షరాలు నియంత్రణ అక్షరాలు అని గమనించండి, కాని SPACE కాదు.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// ముడి u32 విలువను UTF-8 గా అందించిన బైట్ బఫర్‌లోకి ఎన్కోడ్ చేసి, ఆపై ఎన్కోడ్ చేసిన అక్షరాన్ని కలిగి ఉన్న బఫర్ యొక్క సబ్‌లైస్‌ను తిరిగి ఇస్తుంది.
///
///
/// `char::encode_utf8` కాకుండా, ఈ పద్ధతి సర్రోగేట్ పరిధిలో కోడ్‌పాయింట్‌లను కూడా నిర్వహిస్తుంది.
/// (సర్రోగేట్ పరిధిలో `char` ను సృష్టించడం UB.) ఫలితం చెల్లుబాటు అయ్యే [generalized UTF-8] కాని చెల్లుబాటు అయ్యే UTF-8 కాదు.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// బఫర్ తగినంత పెద్దది కాకపోతే Panics.
/// ఏదైనా `char` ను ఎన్కోడ్ చేయడానికి తగినంత పొడవు నాలుగు బఫర్ పెద్దది.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// ముడి u32 విలువను UTF-16 గా అందించిన `u16` బఫర్‌లోకి ఎన్కోడ్ చేసి, ఆపై ఎన్కోడ్ చేసిన అక్షరాన్ని కలిగి ఉన్న బఫర్ యొక్క సబ్‌లైస్‌ను తిరిగి ఇస్తుంది.
///
///
/// `char::encode_utf16` కాకుండా, ఈ పద్ధతి సర్రోగేట్ పరిధిలో కోడ్‌పాయింట్‌లను కూడా నిర్వహిస్తుంది.
/// (సర్రోగేట్ పరిధిలో `char` ను సృష్టించడం UB.)
///
/// # Panics
///
/// బఫర్ తగినంత పెద్దది కాకపోతే Panics.
/// పొడవు 2 యొక్క బఫర్ ఏదైనా `char` ను ఎన్కోడ్ చేయడానికి సరిపోతుంది.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // భద్రత: వ్రాయడానికి తగినంత బిట్స్ ఉన్నాయా అని ప్రతి చేయి తనిఖీ చేస్తుంది
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP ద్వారా వస్తుంది
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // అనుబంధ విమానాలు సర్రోగేట్లలోకి ప్రవేశిస్తాయి.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}