//! ఆదిమ traits మరియు రకాలు ప్రాథమిక లక్షణాలను సూచించే రకాలు.
//!
//! Rust రకాలను వాటి అంతర్గత లక్షణాల ప్రకారం వివిధ ఉపయోగకరమైన మార్గాల్లో వర్గీకరించవచ్చు.
//! ఈ వర్గీకరణలను traits గా సూచిస్తారు.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// థ్రెడ్ సరిహద్దుల్లో బదిలీ చేయగల రకాలు.
///
/// కంపైలర్ తగినదని నిర్ణయించినప్పుడు ఈ trait స్వయంచాలకంగా అమలు చేయబడుతుంది.
///
/// `పంపని` రకానికి ఉదాహరణ రిఫరెన్స్-కౌంటింగ్ పాయింటర్ [`rc::Rc`][`Rc`].
/// రెండు థ్రెడ్లు [`Rc`] లను ఒకే రిఫరెన్స్-లెక్కించిన విలువకు క్లోన్ చేయడానికి ప్రయత్నిస్తే, వారు ఒకే సమయంలో రిఫరెన్స్ కౌంట్‌ను అప్‌డేట్ చేయడానికి ప్రయత్నించవచ్చు, ఇది [undefined behavior][ub] ఎందుకంటే [`Rc`] అణు కార్యకలాపాలను ఉపయోగించదు.
///
/// దీని కజిన్ [`sync::Arc`][arc] అణు కార్యకలాపాలను ఉపయోగిస్తుంది (కొంత ఓవర్‌హెడ్‌తో ఉంటుంది) మరియు ఇది `Send`.
///
/// మరిన్ని వివరాల కోసం [the Nomicon](../../nomicon/send-and-sync.html) చూడండి.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// కంపైల్ సమయంలో తెలిసిన స్థిరమైన పరిమాణంతో రకాలు.
///
/// అన్ని రకం పారామితులు `Sized` యొక్క అవ్యక్త బంధాన్ని కలిగి ఉంటాయి.ప్రత్యేకమైన సింటాక్స్ `?Sized` సరైనది కాకపోతే ఈ బౌండ్‌ను తొలగించడానికి ఉపయోగించవచ్చు.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//లోపం: [i32] కోసం పరిమాణం అమలు చేయబడలేదు
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// ఒక మినహాయింపు trait యొక్క అవ్యక్త `Self` రకం.
/// trait కు అవ్యక్త `Sized` కట్టుబడి లేదు, ఎందుకంటే ఇది [trait ఆబ్జెక్ట్] లకు విరుద్ధంగా లేదు, ఇక్కడ, నిర్వచనం ప్రకారం, trait సాధ్యమయ్యే అన్ని అమలుదారులతో పనిచేయాల్సిన అవసరం ఉంది, అందువలన ఏ పరిమాణం అయినా కావచ్చు.
///
///
/// Rust మిమ్మల్ని `Sized` ను trait తో బంధించడానికి అనుమతించినప్పటికీ, మీరు తరువాత trait ఆబ్జెక్ట్‌ను రూపొందించడానికి ఉపయోగించలేరు:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // y: &dyn బార్= &Impl;//లోపం: trait `Bar` ను ఒక వస్తువుగా చేయలేము
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // డిఫాల్ట్ కోసం, ఉదాహరణకు, `[T]: !Default` మూల్యాంకనం కావాలి
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// డైనమిక్-పరిమాణ రకానికి "unsized" ఉండే రకాలు.
///
/// ఉదాహరణకు, పరిమాణ శ్రేణి రకం `[i8; 2]` `Unsize<[i8]>` మరియు `Unsize<dyn fmt::Debug>` ను అమలు చేస్తుంది.
///
/// `Unsize` యొక్క అన్ని అమలులు కంపైలర్ చేత స్వయంచాలకంగా అందించబడతాయి.
///
/// `Unsize` దీని కోసం అమలు చేయబడింది:
///
/// - `[T; N]` `Unsize<[T]>`
/// - `T` `T: Trait` ఉన్నప్పుడు `Unsize<dyn Trait>`
/// - `Foo<..., T, ...>` `Unsize<Foo<..., U, ...>>` ఉంటే:
///   - `T: Unsize<U>`
///   - Foo ఒక struct
///   - `Foo` యొక్క చివరి ఫీల్డ్ మాత్రమే `T` తో కూడిన రకాన్ని కలిగి ఉంది
///   - `T` ఏ ఇతర రంగాల రకంలో భాగం కాదు
///   - `Bar<T>: Unsize<Bar<U>>`, `Foo` యొక్క చివరి ఫీల్డ్ `Bar<T>` రకాన్ని కలిగి ఉంటే
///
/// `Unsize` [`Rc`] వంటి "user-defined" కంటైనర్లు డైనమిక్-పరిమాణ రకాలను కలిగి ఉండటానికి [`ops::CoerceUnsized`] తో పాటు ఉపయోగించబడుతుంది.
/// మరిన్ని వివరాల కోసం [DST coercion RFC][RFC982] మరియు [the nomicon entry on coercion][nomicon-coerce] చూడండి.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// నమూనా మ్యాచ్‌లలో ఉపయోగించే స్థిరాంకాలకు trait అవసరం.
///
/// `PartialEq` ను పొందిన ఏదైనా రకం ఈ trait ను స్వయంచాలకంగా అమలు చేస్తుంది, దాని రకం-పారామితులు `Eq` ను అమలు చేస్తాయా అనే దానితో సంబంధం లేకుండా *.
///
/// ఒక `const` అంశం ఈ trait ను అమలు చేయని కొన్ని రకాన్ని కలిగి ఉంటే, ఆ రకం (1.) `PartialEq` ను అమలు చేయదు (అంటే స్థిరంగా ఆ పోలిక పద్ధతిని అందించదు, ఏ కోడ్ తరం అందుబాటులో ఉందో) హిస్తుంది), లేదా (2.) అది అమలు చేస్తుంది * దాని స్వంతం `PartialEq` యొక్క సంస్కరణ (ఇది నిర్మాణ-సమానత్వ పోలికకు అనుగుణంగా లేదని మేము అనుకుంటాము).
///
///
/// పైన పేర్కొన్న రెండు దృశ్యాలలో, ఒక నమూనా మ్యాచ్‌లో అటువంటి స్థిరాంకాన్ని ఉపయోగించడాన్ని మేము తిరస్కరించాము.
///
/// [structural match RFC][RFC1445] మరియు [issue 63438] కూడా చూడండి, ఇది లక్షణ-ఆధారిత డిజైన్ నుండి ఈ trait కు వలస వెళ్ళడానికి ప్రేరేపించింది.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// నమూనా మ్యాచ్‌లలో ఉపయోగించే స్థిరాంకాలకు trait అవసరం.
///
/// `Eq` ను ఉత్పన్నమయ్యే ఏ రకం అయినా ఈ trait ను స్వయంచాలకంగా అమలు చేస్తుంది, దాని రకం పారామితులు `Eq` ను అమలు చేస్తాయా అనే దానితో సంబంధం లేకుండా *.
///
/// మా రకం వ్యవస్థలో పరిమితితో పనిచేయడానికి ఇది ఒక హాక్.
///
/// # Background
///
/// నమూనా సరిపోలికలలో ఉపయోగించే రకాలైన కాన్స్ట్‌లు `#[derive(PartialEq, Eq)]` లక్షణాన్ని కలిగి ఉండాలని మేము కోరుకుంటున్నాము.
///
/// మరింత ఆదర్శవంతమైన ప్రపంచంలో, ఇచ్చిన రకం `StructuralPartialEq` trait *మరియు*`Eq` trait రెండింటినీ అమలు చేస్తుందో లేదో తనిఖీ చేయడం ద్వారా మేము ఆ అవసరాన్ని తనిఖీ చేయవచ్చు.
/// అయినప్పటికీ, మీరు *X* X1X చేసే ADT లను కలిగి ఉండవచ్చు మరియు కంపైలర్ అంగీకరించాలని మేము కోరుకుంటున్నాము, ఇంకా స్థిరమైన రకం `Eq` ను అమలు చేయడంలో విఫలమవుతుంది.
///
/// నామంగా, ఇలాంటి కేసు:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (పై కోడ్‌లోని సమస్య ఏమిటంటే, `Wrap<fn(&())>` `PartialEq` లేదా `Eq` ను అమలు చేయదు, ఎందుకంటే `కోసం <'a> fn(&'a _)` does not implement those traits.)
///
/// అందువల్ల, మేము `StructuralPartialEq` మరియు కేవలం `Eq` కోసం అమాయక తనిఖీపై ఆధారపడలేము.
///
/// దీని చుట్టూ పనిచేయడానికి ఒక హాక్ వలె, మేము రెండింటిలో ప్రతి ఒక్కటి ఇంజెక్ట్ చేసిన రెండు వేర్వేరు traits ను ఉపయోగిస్తాము (`#[derive(PartialEq)]` మరియు `#[derive(Eq)]`) మరియు స్ట్రక్చరల్-మ్యాచ్ చెకింగ్‌లో భాగంగా ఈ రెండూ ఉన్నాయో లేదో తనిఖీ చేయండి.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// విలువలను బిట్‌లను కాపీ చేయడం ద్వారా నకిలీ చేయవచ్చు.
///
/// అప్రమేయంగా, వేరియబుల్ బైండింగ్స్‌కు 'మూవ్ సెమాంటిక్స్' ఉన్నాయి.వేరే పదాల్లో:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` `y` లోకి తరలించబడింది మరియు ఉపయోగించబడదు
///
/// // println! ("{: ?}", x);//లోపం: తరలించిన విలువ యొక్క ఉపయోగం
/// ```
///
/// ఏదేమైనా, ఒక రకం `Copy` ను అమలు చేస్తే, దానికి బదులుగా 'కాపీ సెమాంటిక్స్' ఉంటుంది:
///
/// ```
/// // మేము `Copy` అమలును పొందవచ్చు.
/// // `Clone` ఇది కూడా అవసరం, ఎందుకంటే ఇది `Copy` యొక్క సూపర్ ట్రైట్.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` `x` యొక్క కాపీ
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// ఈ రెండు ఉదాహరణలలో, అసైన్మెంట్ తర్వాత `x` ని యాక్సెస్ చేయడానికి మీకు అనుమతి ఉందా అనేది ఒకే తేడా.
/// హుడ్ కింద, ఒక కాపీ మరియు కదలిక రెండూ బిట్స్ మెమరీలో కాపీ చేయబడవచ్చు, అయినప్పటికీ ఇది కొన్నిసార్లు ఆప్టిమైజ్ అవుతుంది.
///
/// ## నేను `Copy` ను ఎలా అమలు చేయగలను?
///
/// మీ రకంపై `Copy` ను అమలు చేయడానికి రెండు మార్గాలు ఉన్నాయి.`derive` ను ఉపయోగించడం సరళమైనది:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// మీరు మానవీయంగా `Copy` మరియు `Clone` ను కూడా అమలు చేయవచ్చు:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// రెండింటి మధ్య చిన్న వ్యత్యాసం ఉంది: `derive` వ్యూహం కూడా `Copy` రకం పారామితులపై కట్టుబడి ఉంటుంది, ఇది ఎల్లప్పుడూ కోరుకోదు.
///
/// ## `Copy` మరియు `Clone` మధ్య తేడా ఏమిటి?
///
/// కాపీలు అవ్యక్తంగా జరుగుతాయి, ఉదాహరణకు అసైన్మెంట్ `y = x` లో భాగంగా.`Copy` యొక్క ప్రవర్తన ఓవర్లోడ్ కాదు;ఇది ఎల్లప్పుడూ సాధారణ బిట్ వారీ కాపీ.
///
/// క్లోనింగ్ అనేది స్పష్టమైన చర్య, `x.clone()`.[`Clone`] అమలు విలువలను సురక్షితంగా నకిలీ చేయడానికి అవసరమైన ఏ రకమైన నిర్దిష్ట ప్రవర్తనను అందిస్తుంది.
/// ఉదాహరణకు, [`String`] కోసం [`Clone`] అమలు కుప్పలో పాయింటెడ్-టు స్ట్రింగ్ బఫర్‌ను కాపీ చేయాలి.
/// [`String`] విలువల యొక్క సరళమైన బిట్‌వైస్ కాపీ కేవలం పాయింటర్‌ను కాపీ చేస్తుంది, తద్వారా ఇది డబుల్ ఫ్రీకి దారితీస్తుంది.
/// ఈ కారణంగా, [`String`] [`Clone`] కానీ `Copy` కాదు.
///
/// [`Clone`] `Copy` యొక్క సూపర్ ట్రైట్, కాబట్టి `Copy` ఉన్న ప్రతిదీ కూడా [`Clone`] ను అమలు చేయాలి.
/// ఒక రకం `Copy` అయితే, దాని [`Clone`] అమలుకు `*self` ను మాత్రమే తిరిగి ఇవ్వాలి (పై ఉదాహరణ చూడండి).
///
/// ## నా రకం `Copy` ఎప్పుడు ఉంటుంది?
///
/// ఒక రకం దాని అన్ని భాగాలు `Copy` ను అమలు చేస్తే `Copy` ను అమలు చేయవచ్చు.ఉదాహరణకు, ఈ struct `Copy` కావచ్చు:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// ఒక స్ట్రక్ట్ `Copy`, మరియు [`i32`] `Copy`, కాబట్టి `Point` `Copy` గా ఉండటానికి అర్హులు.
/// దీనికి విరుద్ధంగా, పరిగణించండి
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// స్ట్రక్ట్ `PointList` `Copy` ను అమలు చేయదు, ఎందుకంటే [`Vec<T>`] `Copy` కాదు.మేము `Copy` అమలును పొందడానికి ప్రయత్నిస్తే, మనకు లోపం వస్తుంది:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// షేర్డ్ రిఫరెన్సులు (`&T`) కూడా `Copy`, కాబట్టి ఒక రకం `Copy` కావచ్చు, ఇది `T` రకాలను భాగస్వామ్యం చేసినప్పటికీ *X* X కాదు * `Copy`.
/// `Copy` ను అమలు చేయగల కింది నిర్మాణాన్ని పరిగణించండి, ఎందుకంటే ఇది పై నుండి మా `కాపి` రకం `PointList` కు * భాగస్వామ్య సూచనను మాత్రమే కలిగి ఉంటుంది:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## నా రకం `Copy` ఎప్పుడు *కాదు*?
///
/// కొన్ని రకాలను సురక్షితంగా కాపీ చేయలేరు.ఉదాహరణకు, `&mut T` ను కాపీ చేయడం అలియాస్ మ్యూటబుల్ రిఫరెన్స్‌ను సృష్టిస్తుంది.
/// [`String`] ను కాపీ చేయడం వలన [`స్ట్రింగ్`] యొక్క బఫర్ నిర్వహణ బాధ్యత నకిలీ అవుతుంది, ఇది డబుల్ ఫ్రీకి దారితీస్తుంది.
///
/// తరువాతి కేసును సాధారణీకరించడం, [`Drop`] ను అమలు చేసే ఏ రకం `Copy` కాదు, ఎందుకంటే ఇది దాని స్వంత [`size_of::<T>`] బైట్‌లతో పాటు కొంత వనరును నిర్వహిస్తుంది.
///
/// మీరు `కాపి` కాని డేటాను కలిగి ఉన్న స్ట్రక్ట్ లేదా ఎనుమ్‌లో `Copy` ను అమలు చేయడానికి ప్రయత్నిస్తే, మీరు లోపం [E0204] ను పొందుతారు.
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## నా రకం `Copy` ఎప్పుడు * ఉండాలి?
///
/// సాధారణంగా, మీ రకం _can_ `Copy` ను అమలు చేస్తే, అది తప్పక.
/// `Copy` ను అమలు చేయడం మీ రకం యొక్క పబ్లిక్ API లో భాగం అని గుర్తుంచుకోండి.
/// future లో ఈ రకం నాన్-కాపి`గా మారితే, బ్రేకింగ్ API మార్పును నివారించడానికి, ఇప్పుడు `Copy` అమలును వదిలివేయడం వివేకం.
///
/// ## అదనపు అమలుదారులు
///
/// [implementors listed below][impls] తో పాటు, కింది రకాలు కూడా `Copy` ను అమలు చేస్తాయి:
///
/// * ఫంక్షన్ అంశం రకాలు (అనగా, ప్రతి ఫంక్షన్ కోసం నిర్వచించిన విభిన్న రకాలు)
/// * ఫంక్షన్ పాయింటర్ రకాలు (ఉదా., `fn() -> i32`)
/// * ఐటెమ్ రకం కూడా `Copy` (ఉదా., `[i32; 123456]`) ను అమలు చేస్తే, అన్ని పరిమాణాల కోసం అర్రే రకాలు
/// * ప్రతి భాగం `Copy` (ఉదా., `()`, `(i32, bool)`) ను అమలు చేస్తే టుపుల్ రకాలు
/// * మూసివేత రకాలు, అవి పర్యావరణం నుండి ఎటువంటి విలువను సంగ్రహించకపోతే లేదా అలాంటి అన్ని సంగ్రహించిన విలువలు `Copy` ను అమలు చేస్తే.
///   షేర్డ్ రిఫరెన్స్ ద్వారా సంగ్రహించబడిన వేరియబుల్స్ ఎల్లప్పుడూ `Copy` ను అమలు చేస్తాయని గమనించండి (రిఫరెన్స్ చేయకపోయినా), అయితే మ్యూటబుల్ రిఫరెన్స్ ద్వారా సంగ్రహించిన వేరియబుల్స్ `Copy` ను ఎప్పుడూ అమలు చేయవు.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) ఇది సంతృప్తి చెందని జీవితకాల హద్దుల కారణంగా `Copy` ను అమలు చేయని రకాన్ని కాపీ చేయడానికి అనుమతిస్తుంది (`A<'static>: Copy` మరియు `A<'_>: Clone` మాత్రమే ఉన్నప్పుడు `A<'_>` ను కాపీ చేయడం).
// ప్రామాణిక లైబ్రరీలో ఇప్పటికే ఉన్న `Copy` లో చాలా తక్కువ స్పెషలైజేషన్లు ఉన్నందున, ప్రస్తుతం ఈ లక్షణాన్ని ఇక్కడ కలిగి ఉన్నాము మరియు ప్రస్తుతం ఈ ప్రవర్తనను సురక్షితంగా కలిగి ఉండటానికి మార్గం లేదు.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// trait `Copy` యొక్క impl ను ఉత్పత్తి చేసే స్థూల ఉత్పన్నం.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// థ్రెడ్ల మధ్య సూచనలను పంచుకోవడం సురక్షితమైన రకాలు.
///
/// కంపైలర్ తగినదని నిర్ణయించినప్పుడు ఈ trait స్వయంచాలకంగా అమలు చేయబడుతుంది.
///
/// ఖచ్చితమైన నిర్వచనం: `T` రకం [`Sync`] అయితే `&T` [`Send`] అయితే మాత్రమే.
/// మరో మాటలో చెప్పాలంటే, థ్రెడ్ల మధ్య `&T` సూచనలను దాటినప్పుడు [undefined behavior][ub] (డేటా రేసులతో సహా) అవకాశం లేకపోతే.
///
/// ఒకరు expect హించినట్లుగా, [`u8`] మరియు [`f64`] వంటి ఆదిమ రకాలు అన్నీ [`Sync`], మరియు వాటిని కలిగి ఉన్న సాధారణ కంకర రకాలు, టుపుల్స్, స్ట్రక్ట్స్ మరియు ఎనుమ్స్ వంటివి.
/// ప్రాథమిక [`Sync`] రకాలకు మరిన్ని ఉదాహరణలు `&T` వంటి "immutable" రకాలు మరియు [`Box<T>`][box], [`Vec<T>`][vec] మరియు చాలా ఇతర సేకరణ రకాలు వంటి సాధారణ వారసత్వంగా ఉత్పరివర్తన చెందినవి.
///
/// (సాధారణ పారామితులు వాటి కంటైనర్ [`సమకాలీకరణ`] గా ఉండటానికి [`Sync`] ఉండాలి.)
///
/// నిర్వచనం యొక్క కొంత ఆశ్చర్యకరమైన పరిణామం ఏమిటంటే, `&mut T` అనేది `Sync` (`T` `Sync` అయితే) సమకాలీకరించని మ్యుటేషన్‌ను అందించినట్లు అనిపించినప్పటికీ.
/// ట్రిక్ ఏమిటంటే, షేర్డ్ రిఫరెన్స్ వెనుక ఉన్న మ్యూటబుల్ రిఫరెన్స్ (అనగా, `& &mut T`) చదవడానికి మాత్రమే అవుతుంది, ఇది `& &T` లాగా ఉంటుంది.
/// అందువల్ల డేటా రేస్‌కు ప్రమాదం లేదు.
///
/// `Sync` కాని రకాలు "interior mutability" ను థ్రెడ్-సురక్షిత రూపంలో లేని [`Cell`][cell] మరియు [`RefCell`][refcell] వంటివి.
/// ఈ రకాలు మార్పులేని, భాగస్వామ్య సూచన ద్వారా కూడా వాటి విషయాలను మార్చడానికి అనుమతిస్తాయి.
/// ఉదాహరణకు, [`Cell<T>`][cell] లోని `set` పద్ధతి `&self` తీసుకుంటుంది, కాబట్టి దీనికి భాగస్వామ్య సూచన [`&Cell<T>`][cell] మాత్రమే అవసరం.
/// పద్ధతి సమకాలీకరణను చేయదు, అందువలన [`Cell`][cell] `Sync` గా ఉండకూడదు.
///
/// `సింక్` రకానికి మరొక ఉదాహరణ రిఫరెన్స్-కౌంటింగ్ పాయింటర్ [`Rc`][rc].
/// ఏదైనా రిఫరెన్స్ [`&Rc<T>`][rc] ఇచ్చినట్లయితే, మీరు కొత్త [`Rc<T>`][rc] ను క్లోన్ చేయవచ్చు, రిఫరెన్స్ గణనలను అణు రహిత మార్గంలో సవరించవచ్చు.
///
/// ఒకరికి థ్రెడ్-సేఫ్ ఇంటీరియర్ మ్యూటబిలిటీ అవసరమైనప్పుడు, Rust [atomic data types] ను అందిస్తుంది, అలాగే [`sync::Mutex`][mutex] మరియు [`sync::RwLock`][rwlock] ద్వారా స్పష్టమైన లాకింగ్‌ను అందిస్తుంది.
/// ఈ రకాలు ఏదైనా మ్యుటేషన్ డేటా రేసులకు కారణం కాదని నిర్ధారిస్తాయి, అందువల్ల రకాలు `Sync`.
/// అదేవిధంగా, [`sync::Arc`][arc] [`Rc`][rc] యొక్క థ్రెడ్-సేఫ్ అనలాగ్ను అందిస్తుంది.
///
/// ఇంటీరియర్ మ్యూటబిలిటీ ఉన్న ఏ రకాలు అయినా value(s) చుట్టూ [`cell::UnsafeCell`][unsafecell] రేపర్ను ఉపయోగించాలి, వీటిని షేర్డ్ రిఫరెన్స్ ద్వారా మార్చవచ్చు.
/// దీన్ని చేయడంలో విఫలమైతే [undefined behavior][ub].
/// ఉదాహరణకు, [`ట్రాన్స్‌మ్యూట్`][ట్రాన్స్‌మ్యూట్]-ఇంగ్ `&T` నుండి `&mut T` వరకు చెల్లదు.
///
/// `Sync` గురించి మరిన్ని వివరాల కోసం [the Nomicon][nomicon-send-and-sync] చూడండి.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): బీటాలోని `rustc_on_unimplemented` భూములలో గమనికలను జోడించడానికి ఒకసారి మద్దతు ఇవ్వండి మరియు అవసరాల గొలుసులో మూసివేత ఎక్కడైనా ఉందో లేదో తనిఖీ చేయడానికి విస్తరించబడింది, దానిని (#48534) గా విస్తరించండి:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// "act like" వారు `T` కలిగి ఉన్న వస్తువులను గుర్తించడానికి ఉపయోగించే సున్నా-పరిమాణ రకం.
///
/// మీ రకానికి `PhantomData<T>` ఫీల్డ్‌ను జోడించడం కంపైలర్‌కు మీ రకం `T` రకం విలువను నిల్వ చేసినట్లుగా పనిచేస్తుందని చెబుతుంది, అది నిజంగా కాకపోయినా.
/// కొన్ని భద్రతా లక్షణాలను లెక్కించేటప్పుడు ఈ సమాచారం ఉపయోగించబడుతుంది.
///
/// `PhantomData<T>` ను ఎలా ఉపయోగించాలో మరింత లోతైన వివరణ కోసం, దయచేసి [the Nomicon](../../nomicon/phantom-data.html) చూడండి.
///
/// # భయంకరమైన గమనిక
///
/// వారిద్దరికీ భయానక పేర్లు ఉన్నప్పటికీ, `PhantomData` మరియు 'ఫాంటమ్ రకాలు' సంబంధించినవి, కానీ ఒకేలా ఉండవు.ఫాంటమ్ రకం పరామితి అనేది ఒక రకం పరామితి, ఇది ఎప్పుడూ ఉపయోగించబడదు.
/// Rust లో, ఇది తరచూ కంపైలర్ ఫిర్యాదు చేయడానికి కారణమవుతుంది మరియు `PhantomData` ద్వారా "dummy" వాడకాన్ని జోడించడం దీనికి పరిష్కారం.
///
/// # Examples
///
/// ## ఉపయోగించని జీవితకాల పారామితులు
///
/// `PhantomData` కోసం సర్వసాధారణమైన ఉపయోగ సందర్భం ఉపయోగించని జీవితకాల పరామితిని కలిగి ఉన్న ఒక స్ట్రక్ట్, సాధారణంగా కొన్ని అసురక్షిత కోడ్‌లో భాగంగా.
/// ఉదాహరణకు, ఇక్కడ ఒక స్ట్రక్ట్ `Slice` ఉంది, ఇది `*const T` రకం యొక్క రెండు పాయింటర్లను కలిగి ఉంది, బహుశా ఎక్కడో ఒక శ్రేణిలోకి సూచించబడుతుంది:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// ఉద్దేశ్యం ఏమిటంటే, అంతర్లీన డేటా జీవితకాల `'a` కి మాత్రమే చెల్లుతుంది, కాబట్టి `Slice` `'a` ను మించిపోకూడదు.
/// ఏదేమైనా, ఈ ఉద్దేశం కోడ్‌లో వ్యక్తీకరించబడలేదు, ఎందుకంటే జీవితకాలం `'a` యొక్క ఉపయోగాలు లేవు మరియు అందువల్ల ఇది ఏ డేటాకు వర్తిస్తుందో స్పష్టంగా తెలియదు.
/// కంపైలర్‌కు * `Slice` స్ట్రక్ట్‌లో `&'a T` రిఫరెన్స్ ఉన్నట్లుగా వ్యవహరించమని చెప్పడం ద్వారా మేము దీన్ని సరిదిద్దవచ్చు:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// దీనికి కూడా `T: 'a` ఉల్లేఖనం అవసరం, `T` లోని ఏదైనా సూచనలు జీవితకాల `'a` లో చెల్లుబాటు అవుతాయని సూచిస్తుంది.
///
/// `Slice` ను ప్రారంభించేటప్పుడు మీరు `phantom` ఫీల్డ్ కోసం `PhantomData` విలువను అందిస్తారు:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## ఉపయోగించని రకం పారామితులు
///
/// మీరు ఉపయోగించని రకం పారామితులను కలిగి ఉన్నారని ఇది కొన్నిసార్లు జరుగుతుంది, ఇది ఒక struct "tied" కు ఏ రకమైన డేటాను సూచిస్తుంది, ఆ డేటా వాస్తవానికి struct లోనే కనుగొనబడనప్పటికీ.
/// ఇది [FFI] తో ఉత్పన్నమయ్యే ఉదాహరణ ఇక్కడ ఉంది.
/// వివిధ రకాలైన Rust విలువలను సూచించడానికి విదేశీ ఇంటర్ఫేస్ `*mut ()` రకం హ్యాండిల్స్‌ను ఉపయోగిస్తుంది.
/// స్ట్రక్ట్ `ExternalResource` పై ఫాంటమ్ రకం పరామితిని ఉపయోగించి మేము Rust రకాన్ని ట్రాక్ చేస్తాము, ఇది హ్యాండిల్‌ను చుట్టేస్తుంది.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## యాజమాన్యం మరియు డ్రాప్ చెక్
///
/// `PhantomData<T>` రకం ఫీల్డ్‌ను జోడించడం వలన మీ రకం `T` రకం డేటాను కలిగి ఉందని సూచిస్తుంది.ఇది మీ రకం పడిపోయినప్పుడు, ఇది `T` రకం యొక్క ఒకటి లేదా అంతకంటే ఎక్కువ సందర్భాలను వదలవచ్చని సూచిస్తుంది.
/// ఇది Rust కంపైలర్ యొక్క [drop check] విశ్లేషణపై ప్రభావం చూపుతుంది.
///
/// మీ స్ట్రక్ట్ వాస్తవానికి `T` రకం డేటాను కలిగి ఉండకపోతే, యాజమాన్యాన్ని సూచించకుండా ఉండటానికి, `PhantomData<&'a T>` (ideally) లేదా `PhantomData<*const T>` (జీవితకాలం వర్తించకపోతే) వంటి సూచన రకాన్ని ఉపయోగించడం మంచిది.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// కంపైలర్-అంతర్గత trait ఎనుమ్ వివక్షత యొక్క రకాన్ని సూచించడానికి ఉపయోగిస్తారు.
///
/// ఈ trait ప్రతి రకానికి స్వయంచాలకంగా అమలు చేయబడుతుంది మరియు [`mem::Discriminant`] కు ఎటువంటి హామీలను జోడించదు.
/// `DiscriminantKind::Discriminant` మరియు `mem::Discriminant` మధ్య ప్రసారం చేయడం **నిర్వచించబడని ప్రవర్తన**.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// వివక్షత యొక్క రకం, ఇది `mem::Discriminant` కి అవసరమైన trait bounds ని సంతృప్తి పరచాలి.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// కంపైలర్-అంతర్గత trait ఒక రకంలో అంతర్గతంగా ఏదైనా `UnsafeCell` ఉందో లేదో తెలుసుకోవడానికి ఉపయోగిస్తారు, కానీ ఒక ఇందిరెక్షన్ ద్వారా కాదు.
///
/// ఉదాహరణకు, ఆ రకమైన `static` చదవడానికి-మాత్రమే స్టాటిక్ మెమరీలో లేదా రాయగల స్టాటిక్ మెమరీలో ఉంచబడిందా అనే దానిపై ఇది ప్రభావం చూపుతుంది.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// పిన్ చేసిన తర్వాత సురక్షితంగా తరలించగల రకాలు.
///
/// Rust లోనే స్థిరమైన రకాలు అనే భావన లేదు, మరియు కదలికలను (ఉదా., అసైన్‌మెంట్ ద్వారా లేదా [`mem::replace`] ద్వారా) ఎల్లప్పుడూ సురక్షితంగా భావిస్తుంది.
///
/// టైప్ సిస్టమ్ ద్వారా కదలికలను నివారించడానికి బదులుగా [`Pin`][Pin] రకం ఉపయోగించబడుతుంది.[`Pin<P<T>>`][Pin] రేపర్లో చుట్టబడిన పాయింటర్లు `P<T>` ను బయటకు తరలించలేము.
/// పిన్నింగ్ గురించి మరింత సమాచారం కోసం [`pin` module] డాక్యుమెంటేషన్ చూడండి.
///
/// `T` కోసం `Unpin` trait ను అమలు చేయడం వలన రకాన్ని పిన్ చేసే పరిమితులను ఎత్తివేస్తుంది, తరువాత `T` నుండి [`Pin<P<T>>`][Pin] నుండి `T` ను [`mem::replace`] వంటి ఫంక్షన్లతో తరలించడానికి అనుమతిస్తుంది.
///
///
/// `Unpin` పిన్ చేయని డేటాకు ఎటువంటి పరిణామాలు లేవు.
/// ముఖ్యంగా, [`mem::replace`] సంతోషంగా `!Unpin` డేటాను కదిలిస్తుంది (ఇది ఏదైనా `&mut T` కోసం పనిచేస్తుంది, `T: Unpin` ఉన్నప్పుడు మాత్రమే కాదు).
/// అయినప్పటికీ, మీరు [`Pin<P<T>>`][Pin] లోపల చుట్టబడిన డేటాలో [`mem::replace`] ను ఉపయోగించలేరు ఎందుకంటే మీకు అవసరమైన `&mut T` ను మీరు పొందలేరు మరియు ఈ వ్యవస్థ పని చేసేలా చేస్తుంది *.
///
/// కాబట్టి ఇది ఉదాహరణకు, `Unpin` ను అమలు చేసే రకాల్లో మాత్రమే చేయవచ్చు:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // `mem::replace` కి కాల్ చేయడానికి మాకు మ్యూటబుల్ రిఫరెన్స్ అవసరం.
/// // (implicitly) ను `Pin::deref_mut` ను ప్రారంభించడం ద్వారా మేము అలాంటి సూచనను పొందవచ్చు, కానీ `String` `Unpin` ను అమలు చేస్తుంది కాబట్టి ఇది సాధ్యమవుతుంది.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// ఈ trait దాదాపు ప్రతి రకానికి స్వయంచాలకంగా అమలు చేయబడుతుంది.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// `Unpin` ను అమలు చేయని మార్కర్ రకం.
///
/// ఒక రకంలో `PhantomPinned` ఉంటే, అది డిఫాల్ట్‌గా `Unpin` ను అమలు చేయదు.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// ఆదిమ రకాల కోసం `Copy` అమలు.
///
/// Rust లో వివరించలేని అమలులు `rustc_trait_selection` లో `traits::SelectionContext::copy_clone_conditions()` లో అమలు చేయబడతాయి.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// భాగస్వామ్య సూచనలు కాపీ చేయవచ్చు, కాని మార్చగల సూచనలు *చేయలేవు*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}