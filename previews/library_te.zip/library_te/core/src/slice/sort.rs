//! స్లైస్ సార్టింగ్
//!
//! ఈ మాడ్యూల్ ఓర్సన్ పీటర్స్ యొక్క నమూనా-ఓడించే icks బి ఆధారంగా ఒక సార్టింగ్ అల్గోరిథంను కలిగి ఉంది, ఇక్కడ ప్రచురించబడింది: <https://github.com/orlp/pdqsort>
//!
//!
//! అస్థిర సార్టింగ్ లిబ్‌కోర్‌తో అనుకూలంగా ఉంటుంది ఎందుకంటే ఇది మా స్థిరమైన సార్టింగ్ అమలుకు భిన్నంగా మెమరీని కేటాయించదు.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// పడిపోయినప్పుడు, `src` నుండి `dest` లోకి కాపీలు.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // భద్రత: ఇది సహాయక తరగతి.
        //          దయచేసి దాని వినియోగాన్ని సరైనది కోసం చూడండి.
        //          అవి, `ptr::copy_nonoverlapping` ద్వారా `src` మరియు `dst` అతివ్యాప్తి చెందవని ఖచ్చితంగా అనుకోవాలి.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// ఎక్కువ లేదా సమానమైన మూలకాన్ని ఎదుర్కొనే వరకు మొదటి మూలకాన్ని కుడి వైపుకు మారుస్తుంది.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // భద్రత: దిగువ అసురక్షిత కార్యకలాపాలు సరిహద్దు తనిఖీ లేకుండా సూచికను కలిగి ఉంటాయి (`get_unchecked` మరియు `get_unchecked_mut`)
    // మరియు మెమరీ (`ptr::copy_nonoverlapping`) ను కాపీ చేస్తుంది.
    //
    // a.సూచిక:
    //  1. మేము శ్రేణి యొక్క పరిమాణాన్ని>=2 కు తనిఖీ చేసాము.
    //  2. మేము చేసే అన్ని ఇండెక్సింగ్ ఎల్లప్పుడూ {0 <= index < len} మధ్య ఉంటుంది.
    //
    // బి.మెమరీ కాపీ
    //  1. మేము చెల్లుబాటు అయ్యే హామీ ఉన్న సూచనలకు పాయింటర్లను పొందుతున్నాము.
    //  2. అవి అతివ్యాప్తి చెందవు ఎందుకంటే మేము స్లైస్ యొక్క తేడా సూచికలకు పాయింటర్లను పొందుతాము.
    //     అవి, `i` మరియు `i-1`.
    //  3. స్లైస్ సరిగ్గా సమలేఖనం చేయబడితే, మూలకాలు సరిగ్గా సమలేఖనం చేయబడతాయి.
    //     స్లైస్ సరిగ్గా అమర్చబడిందని నిర్ధారించుకోవడం కాలర్ యొక్క బాధ్యత.
    //
    // మరింత వివరాల కోసం క్రింద వ్యాఖ్యలను చూడండి.
    unsafe {
        // మొదటి రెండు అంశాలు క్రమం తప్పకుండా ఉంటే ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // మొదటి మూలకాన్ని స్టాక్-కేటాయించిన వేరియబుల్‌లో చదవండి.
            // కింది పోలిక ఆపరేషన్ panics అయితే, `hole` పడిపోతుంది మరియు స్వయంచాలకంగా మూలకాన్ని తిరిగి స్లైస్‌లో వ్రాస్తుంది.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // `I`-th మూలకాన్ని ఒక ప్రదేశానికి ఎడమ వైపుకు తరలించండి, తద్వారా రంధ్రం కుడి వైపుకు మారుతుంది.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` పడిపోతుంది మరియు తద్వారా `tmp` ను `v` లోని మిగిలిన రంధ్రంలోకి కాపీ చేస్తుంది.
        }
    }
}

/// చిన్న లేదా సమాన మూలకాన్ని ఎదుర్కొనే వరకు చివరి మూలకాన్ని ఎడమ వైపుకు మారుస్తుంది.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // భద్రత: దిగువ అసురక్షిత కార్యకలాపాలు సరిహద్దు తనిఖీ లేకుండా సూచికను కలిగి ఉంటాయి (`get_unchecked` మరియు `get_unchecked_mut`)
    // మరియు మెమరీ (`ptr::copy_nonoverlapping`) ను కాపీ చేస్తుంది.
    //
    // a.సూచిక:
    //  1. మేము శ్రేణి యొక్క పరిమాణాన్ని>=2 కు తనిఖీ చేసాము.
    //  2. మేము చేసే అన్ని ఇండెక్సింగ్ ఎల్లప్పుడూ `0 <= index < len-1` మధ్య ఉంటుంది.
    //
    // బి.మెమరీ కాపీ
    //  1. మేము చెల్లుబాటు అయ్యే హామీ ఉన్న సూచనలకు పాయింటర్లను పొందుతున్నాము.
    //  2. అవి అతివ్యాప్తి చెందవు ఎందుకంటే మేము స్లైస్ యొక్క తేడా సూచికలకు పాయింటర్లను పొందుతాము.
    //     అవి, `i` మరియు `i+1`.
    //  3. స్లైస్ సరిగ్గా సమలేఖనం చేయబడితే, మూలకాలు సరిగ్గా సమలేఖనం చేయబడతాయి.
    //     స్లైస్ సరిగ్గా అమర్చబడిందని నిర్ధారించుకోవడం కాలర్ యొక్క బాధ్యత.
    //
    // మరింత వివరాల కోసం క్రింద వ్యాఖ్యలను చూడండి.
    unsafe {
        // చివరి రెండు అంశాలు వెలుపల ఉంటే ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // చివరి మూలకాన్ని స్టాక్-కేటాయించిన వేరియబుల్‌లో చదవండి.
            // కింది పోలిక ఆపరేషన్ panics అయితే, `hole` పడిపోతుంది మరియు స్వయంచాలకంగా మూలకాన్ని తిరిగి స్లైస్‌లో వ్రాస్తుంది.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // `I`-th మూలకాన్ని ఒక స్థలాన్ని కుడి వైపుకు తరలించండి, తద్వారా రంధ్రం ఎడమ వైపుకు మారుతుంది.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` పడిపోతుంది మరియు తద్వారా `tmp` ను `v` లోని మిగిలిన రంధ్రంలోకి కాపీ చేస్తుంది.
        }
    }
}

/// అనేక అవుట్-ఆర్డర్ ఎలిమెంట్లను చుట్టూ మార్చడం ద్వారా పాక్షికంగా ఒక స్లైస్‌ని క్రమబద్ధీకరిస్తుంది.
///
/// స్లైస్ చివరిలో క్రమబద్ధీకరించబడితే `true` ని అందిస్తుంది.ఈ ఫంక్షన్ *O*(*n*) చెత్త కేసు.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // మార్చబడే ప్రక్కనే ఉన్న అవుట్-ఆఫ్-ఆర్డర్ జతల గరిష్ట సంఖ్య.
    const MAX_STEPS: usize = 5;
    // స్లైస్ దీని కంటే తక్కువగా ఉంటే, ఏ అంశాలను మార్చవద్దు.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // భద్రత: మేము ఇప్పటికే స్పష్టంగా `i < len` తో బౌండ్ చెకింగ్ చేసాము.
        // మా తదుపరి ఇండెక్సింగ్ అన్ని `0 <= index < len` పరిధిలో మాత్రమే ఉంటుంది
        unsafe {
            // ప్రక్కనే ఉన్న వెలుపల ఉన్న మూలకాల యొక్క తదుపరి జతని కనుగొనండి.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // మేము పూర్తి చేశామా?
        if i == len {
            return true;
        }

        // పనితీరును కలిగి ఉన్న చిన్న శ్రేణులపై అంశాలను మార్చవద్దు.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // దొరికిన మూలకాల జతని మార్చుకోండి.ఇది వాటిని సరైన క్రమంలో ఉంచుతుంది.
        v.swap(i - 1, i);

        // చిన్న మూలకాన్ని ఎడమ వైపుకు మార్చండి.
        shift_tail(&mut v[..i], is_less);
        // ఎక్కువ మూలకాన్ని కుడి వైపుకు మార్చండి.
        shift_head(&mut v[i..], is_less);
    }

    // పరిమిత సంఖ్యలో దశల్లో స్లైస్‌ని క్రమబద్ధీకరించడానికి నిర్వహించలేదు.
    false
}

/// చొప్పించే క్రమాన్ని ఉపయోగించి స్లైస్‌ని క్రమబద్ధీకరిస్తుంది, ఇది *O*(*n*^ 2) చెత్త కేసు.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// *O*(*n*\*log(* n*)) చెత్త-కేసుకు హామీ ఇచ్చే హీప్‌సార్ట్ ఉపయోగించి `v` ని క్రమబద్ధీకరిస్తుంది.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // ఈ బైనరీ కుప్ప మార్పులేని `parent >= child` ను గౌరవిస్తుంది.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node` పిల్లలు:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // ఎక్కువ పిల్లవాడిని ఎంచుకోండి.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // మార్పులేనిది `node` వద్ద ఉంటే ఆపు.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // ఎక్కువ పిల్లలతో `node` ను మార్చుకోండి, ఒక అడుగు క్రిందికి కదిలించండి మరియు జల్లెడ కొనసాగించండి.
            v.swap(node, greater);
            node = greater;
        }
    };

    // సరళ సమయంలో కుప్పను నిర్మించండి.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // కుప్ప నుండి గరిష్ట అంశాలను పాప్ చేయండి.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// `v` `pivot` కన్నా చిన్న మూలకాలలోకి విభజనలు, తరువాత `pivot` కన్నా ఎక్కువ లేదా సమానమైన అంశాలు.
///
///
/// `pivot` కన్నా చిన్న మూలకాల సంఖ్యను అందిస్తుంది.
///
/// శాఖల కార్యకలాపాల వ్యయాన్ని తగ్గించడానికి విభజనను బ్లాక్-బై-బ్లాక్ చేస్తారు.
/// ఈ ఆలోచనను [BlockQuicksort][pdf] పేపర్‌లో ప్రదర్శించారు.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // సాధారణ బ్లాక్‌లోని మూలకాల సంఖ్య.
    const BLOCK: usize = 128;

    // విభజన అల్గోరిథం పూర్తయ్యే వరకు క్రింది దశలను పునరావృతం చేస్తుంది:
    //
    // 1. పైవట్ కంటే ఎక్కువ లేదా సమానమైన అంశాలను గుర్తించడానికి ఎడమ వైపు నుండి ఒక బ్లాక్‌ను కనుగొనండి.
    // 2. పైవట్ కంటే చిన్న అంశాలను గుర్తించడానికి కుడి వైపు నుండి ఒక బ్లాక్‌ను కనుగొనండి.
    // 3. గుర్తించిన అంశాలను ఎడమ మరియు కుడి వైపు మధ్య మార్పిడి చేయండి.
    //
    // మూలకాల బ్లాక్ కోసం మేము ఈ క్రింది వేరియబుల్స్‌ని ఉంచుతాము:
    //
    // 1. `block` - బ్లాక్‌లోని మూలకాల సంఖ్య.
    // 2. `start` - `offsets` శ్రేణిలోకి పాయింటర్ ప్రారంభించండి.
    // 3. `end` - `offsets` శ్రేణిలోకి పాయింటర్‌ను ముగించండి.
    // 4. `ఆఫ్‌సెట్‌లు, బ్లాక్‌లోని ఆర్డర్ మూలకాల సూచికలు.

    // ఎడమ వైపున ప్రస్తుత బ్లాక్ (`l` నుండి `l.add(block_l)`) వరకు.
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // కుడి వైపున ప్రస్తుత బ్లాక్ (`r.sub(block_r)` to `r`) నుండి.
    // భద్రత: .add() కోసం డాక్యుమెంటేషన్ ప్రత్యేకంగా `vec.as_ptr().add(vec.len())` ఎల్లప్పుడూ సురక్షితంగా ఉందని పేర్కొంది
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: మేము VLA లను పొందినప్పుడు, `min(v.len(), 2 * BLOCK పొడవు యొక్క ఒక శ్రేణిని సృష్టించడానికి ప్రయత్నించండి
    // పొడవు `BLOCK` యొక్క రెండు స్థిర-పరిమాణ శ్రేణుల కంటే.VLA లు మరింత కాష్-సమర్థవంతంగా ఉండవచ్చు.

    // పాయింటర్లు `l` (inclusive) మరియు `r` (exclusive) మధ్య మూలకాల సంఖ్యను అందిస్తుంది.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // `l` మరియు `r` చాలా దగ్గరగా ఉన్నప్పుడు బ్లాక్-బై-బ్లాక్ విభజనతో మేము పూర్తి చేసాము.
        // మధ్యలో మిగిలిన మూలకాలను విభజించడానికి మేము కొన్ని ప్యాచ్-అప్ పనిని చేస్తాము.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // మిగిలిన మూలకాల సంఖ్య (ఇప్పటికీ పైవట్‌తో పోల్చబడలేదు).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // ఎడమ మరియు కుడి బ్లాక్ అతివ్యాప్తి చెందకుండా బ్లాక్ పరిమాణాలను సర్దుబాటు చేయండి, కానీ మిగిలిన మొత్తం ఖాళీని కవర్ చేయడానికి ఖచ్చితంగా సమలేఖనం చేయండి.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // ఎడమ వైపు నుండి `block_l` మూలకాలను కనుగొనండి.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // భద్రత: దిగువ అసురక్షిత ఆపరేషన్లలో `offset` వాడకం ఉంటుంది.
                //         ఫంక్షన్ ద్వారా అవసరమైన షరతుల ప్రకారం, మేము వాటిని సంతృప్తిపరుస్తాము ఎందుకంటే:
                //         1. `offsets_l` స్టాక్-కేటాయించబడింది, అందువలన ప్రత్యేక కేటాయించిన వస్తువుగా పరిగణించబడుతుంది.
                //         2. `is_less` ఫంక్షన్ `bool` ను అందిస్తుంది.
                //            `bool` ను ప్రసారం చేయడం వలన `isize` ఎప్పటికీ పొంగిపోదు.
                //         3. `block_l` `<= BLOCK` అవుతుందని మేము హామీ ఇచ్చాము.
                //            అదనంగా, `end_l` ప్రారంభంలో `offsets_` యొక్క ప్రారంభ పాయింటర్‌కు సెట్ చేయబడింది, ఇది స్టాక్‌లో ప్రకటించబడింది.
                //            అందువల్ల, చెత్త సందర్భంలో కూడా (`is_less` యొక్క అన్ని ఆహ్వానాలు తప్పుడు తిరిగి ఇస్తాయని) మనకు తెలుసు, మనం గరిష్టంగా 1 బైట్ మాత్రమే ముగింపును దాటిపోతాము.
                //        ఇక్కడ మరొక అసురక్షిత ఆపరేషన్ `elem` ను డీఫరెన్సింగ్ చేయడం.
                //        ఏదేమైనా, `elem` ప్రారంభంలో స్లైస్‌కు ప్రారంభ పాయింటర్, ఇది ఎల్లప్పుడూ చెల్లుతుంది.
                unsafe {
                    // బ్రాంచ్లెస్ పోలిక.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // కుడి వైపు నుండి `block_r` మూలకాలను కనుగొనండి.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // భద్రత: దిగువ అసురక్షిత ఆపరేషన్లలో `offset` వాడకం ఉంటుంది.
                //         ఫంక్షన్ ద్వారా అవసరమైన షరతుల ప్రకారం, మేము వాటిని సంతృప్తిపరుస్తాము ఎందుకంటే:
                //         1. `offsets_r` స్టాక్-కేటాయించబడింది, అందువలన ప్రత్యేక కేటాయించిన వస్తువుగా పరిగణించబడుతుంది.
                //         2. `is_less` ఫంక్షన్ `bool` ను అందిస్తుంది.
                //            `bool` ను ప్రసారం చేయడం వలన `isize` ఎప్పటికీ పొంగిపోదు.
                //         3. `block_r` `<= BLOCK` అవుతుందని మేము హామీ ఇచ్చాము.
                //            అదనంగా, `end_r` ప్రారంభంలో `offsets_` యొక్క ప్రారంభ పాయింటర్‌కు సెట్ చేయబడింది, ఇది స్టాక్‌లో ప్రకటించబడింది.
                //            అందువల్ల, చెత్త సందర్భంలో కూడా (`is_less` యొక్క అన్ని ఆహ్వానాలు నిజమైనవి) మనకు తెలుసు, మనం గరిష్టంగా 1 బైట్ మాత్రమే ముగింపును దాటిపోతాము.
                //        ఇక్కడ మరొక అసురక్షిత ఆపరేషన్ `elem` ను డీఫరెన్సింగ్ చేయడం.
                //        అయినప్పటికీ, `elem` ప్రారంభంలో `1 *sizeof(T)` చివరలో ఉంది మరియు దానిని యాక్సెస్ చేయడానికి ముందు మేము దానిని `1* sizeof(T)` ద్వారా తగ్గిస్తాము.
                //        అదనంగా, `block_r` `BLOCK` కన్నా తక్కువ అని నొక్కిచెప్పబడింది మరియు `elem` కాబట్టి స్లైస్ ప్రారంభంలో సూచించబడుతుంది.
                unsafe {
                    // బ్రాంచ్లెస్ పోలిక.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // ఎడమ మరియు కుడి వైపు మధ్య మారడానికి అవుట్-ఆఫ్-ఆర్డర్ మూలకాల సంఖ్య.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // ఆ సమయంలో ఒక జతను మార్చుకునే బదులు, చక్రీయ ప్రస్తారణ చేయడం మరింత సమర్థవంతంగా ఉంటుంది.
            // ఇది ఇచ్చిపుచ్చుకోవటానికి ఖచ్చితంగా సమానం కాదు, కానీ తక్కువ మెమరీ ఆపరేషన్లను ఉపయోగించి ఇలాంటి ఫలితాన్ని ఇస్తుంది.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // ఎడమ బ్లాక్‌లోని అన్ని అవుట్-ఆర్డర్ అంశాలు తరలించబడ్డాయి.తదుపరి బ్లాక్‌కు తరలించండి.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // కుడి బ్లాక్‌లోని అన్ని అవుట్-ఆర్డర్ అంశాలు తరలించబడ్డాయి.మునుపటి బ్లాక్‌కు తరలించండి.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // ఇప్పుడు మిగిలి ఉన్నవన్నీ తరలించాల్సిన అవుట్-ఆర్డర్ ఎలిమెంట్స్‌తో గరిష్టంగా ఒక బ్లాక్‌లో (ఎడమ లేదా కుడి) ఉన్నాయి.
    // అటువంటి మిగిలిన మూలకాలను వాటి బ్లాక్‌లోనే చివరికి మార్చవచ్చు.
    //

    if start_l < end_l {
        // ఎడమ బ్లాక్ మిగిలి ఉంది.
        // దాని మిగిలిన అవుట్-ఆర్డర్ మూలకాలను కుడివైపుకి తరలించండి.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // కుడి బ్లాక్ మిగిలి ఉంది.
        // దాని మిగిలిన అవుట్-ఆర్డర్ మూలకాలను ఎడమవైపుకి తరలించండి.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // ఇంకేమీ చేయలేము, మేము పూర్తి చేసాము.
        width(v.as_mut_ptr(), l)
    }
}

/// `v` `v[pivot]` కన్నా చిన్న మూలకాలలోకి విభజనలు, తరువాత `v[pivot]` కన్నా ఎక్కువ లేదా సమానమైన అంశాలు.
///
///
/// వీటిని అందిస్తుంది:
///
/// 1. `v[pivot]` కన్నా చిన్న మూలకాల సంఖ్య.
/// 2. `v` ఇప్పటికే విభజించబడితే నిజం.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // స్లైస్ ప్రారంభంలో పైవట్ ఉంచండి.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // సామర్థ్యం కోసం పైవట్‌ను స్టాక్-కేటాయించిన వేరియబుల్‌లో చదవండి.
        // కింది పోలిక ఆపరేషన్ panics అయితే, పైవట్ స్వయంచాలకంగా స్లైస్‌లో తిరిగి వ్రాయబడుతుంది.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // అవుట్-ఆఫ్-ఆర్డర్ మూలకాల యొక్క మొదటి జతని కనుగొనండి.
        let mut l = 0;
        let mut r = v.len();

        // భద్రత: దిగువ అసురక్షితత శ్రేణిని సూచించడాన్ని కలిగి ఉంటుంది.
        // మొదటిదానికి: మేము ఇప్పటికే `l < r` తో ఇక్కడ తనిఖీలను చేస్తున్నాము.
        // రెండవదానికి: మనకు మొదట్లో `l == 0` మరియు `r == v.len()` ఉన్నాయి మరియు ప్రతి ఇండెక్సింగ్ ఆపరేషన్ వద్ద మేము `l < r` ను తనిఖీ చేసాము.
        //                     ఇక్కడ నుండి మనకు తెలుసు, `r` కనీసం `r == l` ఉండాలి, ఇది మొదటి నుండి చెల్లుబాటు అయ్యేదిగా చూపబడింది.
        unsafe {
            // పైవట్ కంటే ఎక్కువ లేదా సమానమైన మొదటి మూలకాన్ని కనుగొనండి.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // పైవట్ చిన్నదిగా ఉన్న చివరి మూలకాన్ని కనుగొనండి.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` పరిధి నుండి బయటకు వెళ్లి పివట్ (ఇది స్టాక్-కేటాయించిన వేరియబుల్) ను మొదట ఉన్న స్లైస్‌లో తిరిగి వ్రాస్తుంది.
        // భద్రతను నిర్ధారించడంలో ఈ దశ కీలకం!
        //
    };

    // రెండు విభజనల మధ్య పైవట్ ఉంచండి.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// `v[pivot]` కు సమానమైన మూలకాలకు `v` విభజనలు మరియు తరువాత `v[pivot]` కన్నా ఎక్కువ మూలకాలు.
///
/// పైవట్‌కు సమానమైన మూలకాల సంఖ్యను అందిస్తుంది.
/// `v` పైవట్ కంటే చిన్న అంశాలను కలిగి ఉండదని భావించబడుతుంది.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // స్లైస్ ప్రారంభంలో పైవట్ ఉంచండి.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // సామర్థ్యం కోసం పైవట్‌ను స్టాక్-కేటాయించిన వేరియబుల్‌లో చదవండి.
    // కింది పోలిక ఆపరేషన్ panics అయితే, పైవట్ స్వయంచాలకంగా స్లైస్‌లో తిరిగి వ్రాయబడుతుంది.
    // భద్రత: ఇక్కడ పాయింటర్ చెల్లుతుంది ఎందుకంటే ఇది ఒక స్లైస్‌కు సూచన నుండి పొందబడుతుంది.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // ఇప్పుడు స్లైస్ విభజన.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // భద్రత: దిగువ అసురక్షితత శ్రేణిని సూచించడాన్ని కలిగి ఉంటుంది.
        // మొదటిదానికి: మేము ఇప్పటికే `l < r` తో ఇక్కడ తనిఖీలను చేస్తున్నాము.
        // రెండవదానికి: మనకు మొదట్లో `l == 0` మరియు `r == v.len()` ఉన్నాయి మరియు ప్రతి ఇండెక్సింగ్ ఆపరేషన్ వద్ద మేము `l < r` ను తనిఖీ చేసాము.
        //                     ఇక్కడ నుండి మనకు తెలుసు, `r` కనీసం `r == l` ఉండాలి, ఇది మొదటి నుండి చెల్లుబాటు అయ్యేదిగా చూపబడింది.
        unsafe {
            // పైవట్ కంటే ఎక్కువ మొదటి మూలకాన్ని కనుగొనండి.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // పైవట్‌కు సమానమైన చివరి మూలకాన్ని కనుగొనండి.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // మేము పూర్తి చేశామా?
            if l >= r {
                break;
            }

            // వెలుపల ఉన్న మూలకాల యొక్క జతని మార్పిడి చేయండి.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // పైవట్‌కు సమానమైన `l` మూలకాలను మేము కనుగొన్నాము.పైవట్ కోసం ఖాతాకు 1 ని జోడించండి.
    l + 1

    // `_pivot_guard` పరిధి నుండి బయటకు వెళ్లి పివట్ (ఇది స్టాక్-కేటాయించిన వేరియబుల్) ను మొదట ఉన్న స్లైస్‌లో తిరిగి వ్రాస్తుంది.
    // భద్రతను నిర్ధారించడంలో ఈ దశ కీలకం!
}

/// Icks బిలో అసమతుల్య విభజనలకు కారణమయ్యే నమూనాలను విచ్ఛిన్నం చేసే ప్రయత్నంలో కొన్ని అంశాలను చెల్లాచెదురుగా చేస్తుంది.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // జార్జ్ మార్సాగ్లియా రాసిన "Xorshift RNGs" పేపర్ నుండి సూడోరాండం నంబర్ జనరేటర్.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // యాదృచ్ఛిక సంఖ్యలను మాడ్యులో తీసుకోండి.
        // ఈ సంఖ్య `usize` లోకి సరిపోతుంది ఎందుకంటే `len` `isize::MAX` కన్నా ఎక్కువ కాదు.
        let modulus = len.next_power_of_two();

        // కొంతమంది పివట్ అభ్యర్థులు ఈ సూచిక సమీపంలో ఉంటారు.వాటిని యాదృచ్ఛికంగా చేద్దాం.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // యాదృచ్ఛిక సంఖ్య మాడ్యులో `len` ను రూపొందించండి.
            // అయినప్పటికీ, ఖరీదైన కార్యకలాపాలను నివారించడానికి మేము మొదట దానిని మాడ్యులో రెండు శక్తిని తీసుకుంటాము, ఆపై `[0, len - 1]` పరిధికి సరిపోయే వరకు `len` ద్వారా తగ్గుతుంది.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` `2 * len` కన్నా తక్కువ అని హామీ ఇవ్వబడింది.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// `v` లో పైవట్‌ను ఎన్నుకుంటుంది మరియు స్లైస్ ఇప్పటికే క్రమబద్ధీకరించబడితే ఇండెక్స్ మరియు `true` ను తిరిగి ఇస్తుంది.
///
/// `v` లోని ఎలిమెంట్స్ ఈ ప్రక్రియలో క్రమాన్ని మార్చవచ్చు.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // మధ్యస్థ-మధ్యస్థ పద్ధతిని ఎంచుకోవడానికి కనీస పొడవు.
    // చిన్న ముక్కలు సాధారణ మధ్యస్థ-మూడు పద్ధతిని ఉపయోగిస్తాయి.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // ఈ ఫంక్షన్‌లో చేయగలిగే గరిష్ట సంఖ్యలో స్వాప్‌లు.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // మేము సూచికను ఎంచుకోబోయే మూడు సూచికలు.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // సూచికలను క్రమబద్ధీకరించేటప్పుడు మేము చేయబోయే మొత్తం స్వాప్‌ల సంఖ్యను లెక్కిస్తుంది.
    let mut swaps = 0;

    if len >= 8 {
        // సూచికలను మార్పిడి చేస్తుంది కాబట్టి `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // సూచికలను మార్పిడి చేస్తుంది కాబట్టి `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // `v[a - 1], v[a], v[a + 1]` యొక్క మధ్యస్థాన్ని కనుగొంటుంది మరియు సూచికను `a` లోకి నిల్వ చేస్తుంది.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // `a`, `b` మరియు `c` యొక్క పొరుగు ప్రాంతాలలో మధ్యస్థులను కనుగొనండి.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // `a`, `b` మరియు `c` లలో మధ్యస్థాన్ని కనుగొనండి.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // గరిష్ట సంఖ్యలో మార్పిడులు జరిగాయి.
        // స్లైస్ అవరోహణ లేదా ఎక్కువగా అవరోహణకు అవకాశాలు ఉన్నాయి, కాబట్టి రివర్సింగ్ బహుశా వేగంగా క్రమబద్ధీకరించడానికి సహాయపడుతుంది.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v` పునరావృతంగా క్రమబద్ధీకరిస్తుంది.
///
/// స్లైస్ అసలు శ్రేణిలో పూర్వీకుడిని కలిగి ఉంటే, అది `pred` గా పేర్కొనబడింది.
///
/// `limit` `heapsort` కి మారడానికి ముందు అనుమతించబడిన అసమతుల్య విభజనల సంఖ్య.
/// సున్నా అయితే, ఈ ఫంక్షన్ వెంటనే హీప్‌సోర్ట్‌కు మారుతుంది.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // ఈ పొడవు వరకు ముక్కలు చొప్పించే క్రమాన్ని ఉపయోగించి క్రమబద్ధీకరించబడతాయి.
    const MAX_INSERTION: usize = 20;

    // చివరి విభజన సహేతుకంగా సమతుల్యమైతే నిజం.
    let mut was_balanced = true;
    // చివరి విభజన మూలకాలను షఫుల్ చేయకపోతే నిజం (స్లైస్ ఇప్పటికే విభజించబడింది).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // చొప్పించే క్రమాన్ని ఉపయోగించి చాలా చిన్న ముక్కలు క్రమబద్ధీకరించబడతాయి.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // చాలా చెడ్డ పైవట్ ఎంపికలు చేయబడితే, `O(n * log(n))` చెత్త కేసుకు హామీ ఇవ్వడానికి హీప్‌సోర్ట్‌కు తిరిగి వస్తాయి.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // చివరి విభజన అసమతుల్యతతో ఉంటే, చుట్టూ కొన్ని అంశాలను మార్చడం ద్వారా స్లైస్‌లో నమూనాలను విచ్ఛిన్నం చేయడానికి ప్రయత్నించండి.
        // మేము ఈసారి మంచి ఇరుసును ఎన్నుకుంటామని ఆశిస్తున్నాము.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // పైవట్‌ను ఎంచుకుని, స్లైస్ ఇప్పటికే క్రమబద్ధీకరించబడిందో లేదో to హించడానికి ప్రయత్నించండి.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // చివరి విభజన మర్యాదగా సమతుల్యమైతే మరియు అంశాలను షఫుల్ చేయకపోతే, మరియు పైవట్ ఎంపిక if హించినట్లయితే స్లైస్ ఇప్పటికే క్రమబద్ధీకరించబడుతుంది ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // అనేక వెలుపల ఉన్న అంశాలను గుర్తించి, వాటిని సరైన స్థానాలకు మార్చడానికి ప్రయత్నించండి.
            // స్లైస్ పూర్తిగా క్రమబద్ధీకరించబడితే, మేము పూర్తి చేసాము.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // ఎంచుకున్న పైవట్ మునుపటితో సమానంగా ఉంటే, అది స్లైస్‌లోని అతిచిన్న మూలకం.
        // స్లైస్‌ను సమానమైన మూలకాలుగా మరియు పైవట్ కంటే ఎక్కువ మూలకాలగా విభజించండి.
        // స్లైస్ అనేక నకిలీ అంశాలను కలిగి ఉన్నప్పుడు ఈ కేసు సాధారణంగా కొట్టబడుతుంది.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // పైవట్ కంటే ఎక్కువ మూలకాలను క్రమబద్ధీకరించడం కొనసాగించండి.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // స్లైస్ విభజన.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // స్లైస్‌ను `left`, `pivot` మరియు `right` గా విభజించండి.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // మొత్తం పునరావృత కాల్‌ల సంఖ్యను తగ్గించడానికి మరియు తక్కువ స్టాక్ స్థలాన్ని వినియోగించడానికి మాత్రమే తక్కువ వైపుకు తిరిగి వెళ్లండి.
        // అప్పుడు పొడవైన వైపుతో కొనసాగండి (ఇది తోక పునరావృతానికి సమానం).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// నమూనా-ఓడించే క్విక్‌సోర్ట్‌ను ఉపయోగించి `v` ను క్రమబద్ధీకరిస్తుంది, ఇది *O*(*n*\*log(* n*)) చెత్త-కేసు.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // క్రమబద్ధీకరణకు సున్నా-పరిమాణ రకాలపై అర్ధవంతమైన ప్రవర్తన లేదు.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // అసమతుల్య విభజనల సంఖ్యను `floor(log2(len)) + 1` కి పరిమితం చేయండి.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // ఈ పొడవు వరకు ఉన్న ముక్కల కోసం వాటిని క్రమబద్ధీకరించడం చాలా వేగంగా ఉంటుంది.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // పైవట్ ఎంచుకోండి
        let (pivot, _) = choose_pivot(v, is_less);

        // ఎంచుకున్న పైవట్ మునుపటితో సమానంగా ఉంటే, అది స్లైస్‌లోని అతిచిన్న మూలకం.
        // స్లైస్‌ను సమానమైన మూలకాలుగా మరియు పైవట్ కంటే ఎక్కువ మూలకాలగా విభజించండి.
        // స్లైస్ అనేక నకిలీ అంశాలను కలిగి ఉన్నప్పుడు ఈ కేసు సాధారణంగా కొట్టబడుతుంది.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // మేము మా సూచికలో ఉత్తీర్ణులైతే, అప్పుడు మేము బాగున్నాము.
                if mid > index {
                    return;
                }

                // లేకపోతే, పైవట్ కంటే ఎక్కువ మూలకాలను క్రమబద్ధీకరించడం కొనసాగించండి.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // స్లైస్‌ను `left`, `pivot` మరియు `right` గా విభజించండి.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // మిడ్==ఇండెక్స్ అయితే, మిడ్ తరువాత అన్ని మూలకాలు మిడ్ కంటే ఎక్కువ లేదా సమానమని partition() హామీ ఇచ్చినందున మేము పూర్తి చేసాము.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // క్రమబద్ధీకరణకు సున్నా-పరిమాణ రకాలపై అర్ధవంతమైన ప్రవర్తన లేదు.ఏమీ చేయవద్దు.
    } else if index == v.len() - 1 {
        // గరిష్ట మూలకాన్ని కనుగొని, శ్రేణి యొక్క చివరి స్థానంలో ఉంచండి.
        // V ఇక్కడ ఖాళీగా ఉండకూడదని మాకు తెలుసు కాబట్టి మేము ఇక్కడ `unwrap()` ను ఉపయోగించడానికి ఉచితం.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // కనిష్ట మూలకాన్ని కనుగొని, శ్రేణి యొక్క మొదటి స్థానంలో ఉంచండి.
        // V ఇక్కడ ఖాళీగా ఉండకూడదని మాకు తెలుసు కాబట్టి మేము ఇక్కడ `unwrap()` ను ఉపయోగించడానికి ఉచితం.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}