//! ASCII `[u8]` లో కార్యకలాపాలు.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// ఈ స్లైస్‌లోని అన్ని బైట్‌లు ASCII పరిధిలో ఉన్నాయో లేదో తనిఖీ చేస్తుంది.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// రెండు ముక్కలు ASCII కేస్-ఇన్సెన్సిటివ్ మ్యాచ్ అని తనిఖీ చేస్తుంది.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` వలె ఉంటుంది, కానీ తాత్కాలికాలను కేటాయించకుండా మరియు కాపీ చేయకుండా.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// ఈ స్లైస్‌ను దాని ASCII అప్పర్ కేస్ సమానమైన స్థలానికి మారుస్తుంది.
    ///
    /// ASCII అక్షరాలు 'a' నుండి 'z' వరకు 'A' నుండి 'Z' వరకు మ్యాప్ చేయబడతాయి, కాని ASCII కాని అక్షరాలు మారవు.
    ///
    /// ఇప్పటికే ఉన్నదాన్ని సవరించకుండా క్రొత్త పెద్ద విలువను తిరిగి ఇవ్వడానికి, [`to_ascii_uppercase`] ని ఉపయోగించండి.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// ఈ స్లైస్‌ను దాని ASCII లోయర్ కేస్ సమానమైన స్థలానికి మారుస్తుంది.
    ///
    /// ASCII అక్షరాలు 'A' నుండి 'Z' వరకు 'a' నుండి 'z' వరకు మ్యాప్ చేయబడతాయి, కాని ASCII కాని అక్షరాలు మారవు.
    ///
    /// ఇప్పటికే ఉన్నదాన్ని సవరించకుండా క్రొత్త చిన్న విలువను తిరిగి ఇవ్వడానికి, [`to_ascii_lowercase`] ని ఉపయోగించండి.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// `v` అనే పదంలోని ఏదైనా బైట్ nonascii (>=128) అయితే `true` ని అందిస్తుంది.
/// `../str/mod.rs` నుండి స్నార్‌ఫెడ్, ఇది utf8 ధ్రువీకరణకు సమానమైనదాన్ని చేస్తుంది.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// ఆప్టిమైజ్ చేసిన ASCII పరీక్ష, ఇది బైట్-ఎట్-ఎ-టైమ్ ఆపరేషన్లకు బదులుగా (సాధ్యమైనప్పుడు) వినియోగించుకునే సమయ కార్యకలాపాలను ఉపయోగిస్తుంది.
///
/// మేము ఇక్కడ ఉపయోగించే అల్గోరిథం చాలా సులభం.`s` చాలా తక్కువగా ఉంటే, మేము ప్రతి బైట్‌ను తనిఖీ చేసి దానితో పూర్తి చేస్తాము.లేకపోతే:
///
/// - అన్‌లైన్ చేయని లోడ్‌తో మొదటి పదాన్ని చదవండి.
/// - పాయింటర్‌ను సమలేఖనం చేయండి, సమలేఖనం చేసిన లోడ్లతో చివరి వరకు తదుపరి పదాలను చదవండి.
/// - అన్‌లైన్ చేయని లోడ్‌తో `s` నుండి చివరి `usize` చదవండి.
///
/// ఈ లోడ్లు ఏవైనా `contains_nonascii` (above) నిజమైనదిగా తిరిగి ఉత్పత్తి చేస్తే, సమాధానం తప్పు అని మాకు తెలుసు.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // పదం అమలులో మనం ఏమీ పొందలేకపోతే, స్కేలార్ లూప్‌కు తిరిగి వస్తాయి.
    //
    // `usize` కోసం `size_of::<usize>()` తగినంత అమరిక లేని ఆర్కిటెక్చర్ల కోసం కూడా మేము దీన్ని చేస్తాము, ఎందుకంటే ఇది విచిత్రమైన edge కేసు.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // మేము ఎల్లప్పుడూ అన్‌లైన్ చేయని మొదటి పదాన్ని చదువుతాము, అంటే `align_offset`
    // 0, సమలేఖనం చేయబడిన రీడ్ కోసం మేము మళ్ళీ అదే విలువను చదువుతాము.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // భద్రత: మేము పైన `len < USIZE_SIZE` ను ధృవీకరిస్తాము.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // మేము దీన్ని కొంతవరకు అవ్యక్తంగా తనిఖీ చేసాము.
    // `offset_to_aligned` `align_offset` లేదా `USIZE_SIZE` అని గమనించండి, రెండూ పైన స్పష్టంగా తనిఖీ చేయబడతాయి.
    //
    debug_assert!(offset_to_aligned <= len);

    // భద్రత: word_ptr అనేది మనం చదవడానికి ఉపయోగించే (సరిగ్గా సమలేఖనం చేయబడిన) పిటిఆర్
    // స్లైస్ మధ్య భాగం.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` `word_ptr` యొక్క బైట్ సూచిక, ఇది లూప్ ఎండ్ తనిఖీల కోసం ఉపయోగించబడుతుంది.
    let mut byte_pos = offset_to_aligned;

    // మతిమరుపు అమరిక గురించి తనిఖీ చేయండి, ఎందుకంటే మేము సమలేఖనం చేయని లోడ్ల సమూహాన్ని చేయబోతున్నాము.
    // ఆచరణలో ఇది `align_offset` లో బగ్‌ను మినహాయించి అసాధ్యం.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // చివరి సమలేఖన పదం వరకు తరువాతి పదాలను చదవండి, చివరిగా సమలేఖనం చేయబడిన పదాన్ని తోక తనిఖీలో చేయవలసి ఉంటుంది, తోక ఎల్లప్పుడూ ఒక `usize` అని నిర్ధారించుకోవడానికి అదనపు branch `byte_pos == len` వరకు.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // చదవడానికి హద్దులు ఉన్నాయని తెలివి తనిఖీ చేయండి
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // మరియు `byte_pos` గురించి మా ump హలు ఉన్నాయి.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // భద్రత: `word_ptr` సరిగ్గా సమలేఖనం చేయబడిందని మాకు తెలుసు (ఎందుకంటే
        // `align_offset`), మరియు మాకు `word_ptr` మరియు ముగింపు మధ్య తగినంత బైట్లు ఉన్నాయని మాకు తెలుసు
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // భద్రత: `byte_pos <= len - USIZE_SIZE` అని మాకు తెలుసు
        // ఈ `add` తరువాత, `word_ptr` గరిష్టంగా ఒక-గత-ముగింపులో ఉంటుంది.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // నిజంగా ఒక `usize` మాత్రమే మిగిలి ఉందని నిర్ధారించడానికి తెలివి తనిఖీ.
    // ఇది మా లూప్ కండిషన్ ద్వారా హామీ ఇవ్వాలి.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // భద్రత: ఇది `len >= USIZE_SIZE` పై ఆధారపడుతుంది, ఇది మేము ప్రారంభంలో తనిఖీ చేస్తాము.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}