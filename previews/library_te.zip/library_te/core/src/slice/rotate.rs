// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// `[mid-left, mid+right)` పరిధిని తిరుగుతుంది, అంటే `mid` వద్ద ఉన్న మూలకం మొదటి మూలకం అవుతుంది.సమానంగా, పరిధి `left` మూలకాలను ఎడమ వైపుకు లేదా `right` మూలకాలను కుడి వైపుకు తిరుగుతుంది.
///
/// # Safety
///
/// పేర్కొన్న పరిధి చదవడానికి మరియు వ్రాయడానికి చెల్లుబాటులో ఉండాలి.
///
/// # Algorithm
///
/// అల్గోరిథం 1 `left + right` యొక్క చిన్న విలువలకు లేదా పెద్ద `T` కోసం ఉపయోగించబడుతుంది.
/// `mid - left` నుండి ప్రారంభమయ్యే మరియు `right` స్టెప్స్ మాడ్యులో `left + right` ద్వారా అభివృద్ధి చెందుతున్న మూలకాలు వాటి చివరి స్థానాల్లోకి తరలించబడతాయి, అంటే ఒక తాత్కాలిక మాత్రమే అవసరం.
/// చివరికి, మేము `mid - left` వద్ద తిరిగి వస్తాము.
/// అయినప్పటికీ, `gcd(left + right, right)` 1 కాకపోతే, పై దశలు మూలకాలపై దాటవేయబడతాయి.
/// ఉదాహరణకి:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// అదృష్టవశాత్తూ, ఖరారు చేసిన మూలకాల మధ్య దాటవేసిన అంశాల సంఖ్య ఎల్లప్పుడూ సమానంగా ఉంటుంది, కాబట్టి మనం మన ప్రారంభ స్థానాన్ని ఆఫ్‌సెట్ చేయవచ్చు మరియు ఎక్కువ రౌండ్లు చేయవచ్చు (మొత్తం రౌండ్ల సంఖ్య `gcd(left + right, right)` value).
///
/// అంతిమ ఫలితం ఏమిటంటే, అన్ని అంశాలు ఒక్కసారి మాత్రమే ఖరారు చేయబడతాయి.
///
/// `left + right` పెద్దదిగా ఉంటే అల్గోరిథం 2 ఉపయోగించబడుతుంది, అయితే `min(left, right)` స్టాక్ బఫర్‌కు సరిపోయేంత చిన్నది.
/// `min(left, right)` మూలకాలు బఫర్ పైకి కాపీ చేయబడతాయి, `memmove` ఇతరులకు వర్తించబడుతుంది మరియు బఫర్‌లోని వాటిని తిరిగి ఉద్భవించిన చోటికి ఎదురుగా ఉన్న రంధ్రంలోకి తరలించారు.
///
/// `left + right` తగినంత పెద్దదిగా మారిన తర్వాత వెక్టరైజ్ చేయగల అల్గోరిథంలు పైన పేర్కొన్న వాటిని మించిపోతాయి.
/// అల్గోరిథం 1 ను ఒకేసారి చంక్ చేయడం మరియు ప్రదర్శించడం ద్వారా వెక్టరైజ్ చేయవచ్చు, కానీ `left + right` అపారమైన వరకు సగటున చాలా తక్కువ రౌండ్లు ఉన్నాయి, మరియు ఒకే రౌండ్ యొక్క చెత్త కేసు ఎల్లప్పుడూ ఉంటుంది.
/// బదులుగా, అల్గోరిథం 3 ఒక చిన్న రొటేట్ సమస్య మిగిలిపోయే వరకు `min(left, right)` మూలకాల యొక్క పునరావృత మార్పిడిని ఉపయోగిస్తుంది.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// `left < right` మార్పిడి బదులుగా ఎడమ నుండి జరుగుతుంది.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. ఈ కేసులను తనిఖీ చేయకపోతే క్రింది అల్గోరిథంలు విఫలమవుతాయి
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // అల్గోరిథం 1 మైక్రోబెంచ్‌మార్క్‌లు `left + right == 32` వరకు యాదృచ్ఛిక మార్పుల యొక్క సగటు పనితీరు మెరుగ్గా ఉంటుందని సూచిస్తున్నాయి, అయితే చెత్త పనితీరు 16 చుట్టూ కూడా విరిగిపోతుంది.
            // 24 మిడిల్ గ్రౌండ్‌గా ఎంపిక చేయబడింది.
            // `T` యొక్క పరిమాణం 4 `యూసైజ్` కంటే పెద్దది అయితే, ఈ అల్గోరిథం ఇతర అల్గోరిథంలను కూడా అధిగమిస్తుంది.
            //
            //
            let x = unsafe { mid.sub(left) };
            // మొదటి రౌండ్ ప్రారంభం
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` `gcd(left + right, right)` ను లెక్కించడం ద్వారా చేతికి ముందు కనుగొనవచ్చు, కాని జిసిడిని సైడ్ ఎఫెక్ట్‌గా లెక్కించే ఒక లూప్ చేయడం వేగంగా ఉంటుంది, తరువాత మిగిలిన భాగం చేయండి
            //
            //
            let mut gcd = right;
            // ఒక తాత్కాలికతను ఒకసారి చదవడం, వెనుకకు కాపీ చేయడం, ఆపై ఆ తాత్కాలికతను చివర్లో వ్రాయడం బదులు తాత్కాలికాలను మార్పిడి చేయడం వేగవంతం అని బెంచ్‌మార్క్‌లు వెల్లడిస్తాయి.
            // తాత్కాలికాలను మార్పిడి చేయడం లేదా భర్తీ చేయడం రెండింటిని నిర్వహించాల్సిన అవసరం లేకుండా లూప్‌లో ఒక మెమరీ చిరునామాను మాత్రమే ఉపయోగిస్తుండటం దీనికి కారణం కావచ్చు.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // `i` ని పెంచడానికి బదులుగా, అది హద్దులు వెలుపల ఉందో లేదో తనిఖీ చేయడానికి బదులుగా, `i` తదుపరి ఇంక్రిమెంట్‌లో హద్దులు వెలుపల వెళ్తుందా అని మేము తనిఖీ చేస్తాము.
                // ఇది పాయింటర్లు లేదా `usize` యొక్క చుట్టడాన్ని నిరోధిస్తుంది.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // మొదటి రౌండ్ ముగింపు
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // `left + right >= 15` అయితే ఈ షరతు తప్పక ఇక్కడ ఉండాలి
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // ఎక్కువ రౌండ్లతో భాగం పూర్తి చేయండి
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` సున్నా-పరిమాణ రకం కాదు, కాబట్టి దాని పరిమాణంతో విభజించడం సరైందే.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // అల్గోరిథం 2 ఇక్కడ `[T; 0]` ఇది T కోసం తగిన విధంగా సమలేఖనం చేయబడిందని నిర్ధారించడం
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // అల్గోరిథం 3 ఈ అల్గోరిథం యొక్క చివరి స్వాప్ ఎక్కడ ఉంటుందో కనుగొనడం మరియు ఈ అల్గోరిథం వంటి ప్రక్కనే ఉన్న భాగాలను ఇచ్చిపుచ్చుకునే బదులు చివరి భాగాన్ని ఉపయోగించి మార్పిడి చేయడం వంటి ప్రత్యామ్నాయ మార్గం ఉంది, కానీ ఈ మార్గం ఇంకా వేగంగా ఉంది.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // అల్గోరిథం 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}