//! స్లైస్ యొక్క ఇరేటర్స్ ఉపయోగించే మాక్రోలు.

// Is_empty మరియు లెన్‌ను ఇన్లైన్ చేయడం వలన భారీ పనితీరు వ్యత్యాసం ఉంటుంది
macro_rules! is_empty {
    // మేము ఒక ZST ఇటరేటర్ యొక్క పొడవును ఎన్కోడ్ చేసే విధానం, ఇది ZST మరియు ZST కాని రెండింటికీ పనిచేస్తుంది.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// కొన్ని హద్దుల తనిఖీలను వదిలించుకోవడానికి (`position` చూడండి), మేము పొడవును కొంతవరకు unexpected హించని విధంగా లెక్కిస్తాము.
// (`కోడ్‌జెన్/స్లైస్-పొజిషన్-బౌండ్స్-చెక్` చే పరీక్షించబడింది.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // మేము కొన్నిసార్లు అసురక్షిత బ్లాక్‌లో ఉపయోగిస్తాము

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // ఈ _cannot_ `unchecked_sub` ను ఉపయోగిస్తుంది ఎందుకంటే మేము పొడవైన ZST స్లైస్ ఇటిరేటర్ల పొడవును సూచించడానికి చుట్టడం మీద ఆధారపడి ఉంటాము.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // `start <= end`, కాబట్టి `offset_from` కంటే మెరుగ్గా చేయగలదని మాకు తెలుసు, ఇది సంతకం చేయాల్సిన అవసరం ఉంది.
            // తగిన జెండాలను ఇక్కడ అమర్చడం ద్వారా మేము దీన్ని ఎల్‌ఎల్‌విఎమ్‌కి తెలియజేయవచ్చు, ఇది సరిహద్దుల తనిఖీలను తొలగించడంలో సహాయపడుతుంది.
            // భద్రత: మార్పు లేని రకం ద్వారా, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // టైప్ సైజు యొక్క ఖచ్చితమైన గుణకం ద్వారా పాయింటర్లు వేరుగా ఉన్నాయని LLVM కి చెప్పడం ద్వారా, ఇది `(end - start) < size` కు బదులుగా `len() == 0` ను `start == end` కి ఆప్టిమైజ్ చేస్తుంది.
            //
            // భద్రత: మార్పు లేని రకం ద్వారా, పాయింటర్లు సమలేఖనం చేయబడతాయి కాబట్టి
            //         వాటి మధ్య దూరం తప్పనిసరిగా పాయింటి పరిమాణంలో బహుళంగా ఉండాలి
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter` మరియు `IterMut` ఇరేటర్స్ యొక్క భాగస్వామ్య నిర్వచనం
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // మొదటి మూలకాన్ని తిరిగి ఇస్తుంది మరియు మళ్ళి యొక్క ప్రారంభాన్ని 1 ద్వారా ముందుకు కదిలిస్తుంది.
        // ఇన్లైన్ చేసిన ఫంక్షన్‌తో పోలిస్తే పనితీరును బాగా మెరుగుపరుస్తుంది.
        // మళ్ళి ఖాళీగా ఉండకూడదు.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // చివరి మూలకాన్ని తిరిగి ఇస్తుంది మరియు ఇటరేటర్ ముగింపును 1 వెనుకకు కదిలిస్తుంది.
        // ఇన్లైన్ చేసిన ఫంక్షన్‌తో పోలిస్తే పనితీరును బాగా మెరుగుపరుస్తుంది.
        // మళ్ళి ఖాళీగా ఉండకూడదు.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // T ఒక ZST అయినప్పుడు, ఇరేటర్ చివరను `n` ద్వారా వెనుకకు తరలించడం ద్వారా ఇరేటర్‌ను కుదించబడుతుంది.
        // `n` `self.len()` మించకూడదు.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // ఇరేటర్ నుండి స్లైస్ సృష్టించడానికి సహాయక ఫంక్షన్.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // భద్రత: పాయింటర్ ఉన్న స్లైస్ నుండి ఇరేటర్ సృష్టించబడింది
                // `self.ptr` మరియు పొడవు `len!(self)`.
                // `from_raw_parts` కోసం అన్ని అవసరాలు నెరవేరుతాయని ఇది హామీ ఇస్తుంది.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // ఇరేటర్ యొక్క ప్రారంభాన్ని `offset` మూలకాల ద్వారా ముందుకు తరలించడానికి సహాయక పనితీరు, పాత ప్రారంభాన్ని తిరిగి ఇస్తుంది.
            //
            // సురక్షితం కాదు ఎందుకంటే ఆఫ్‌సెట్ `self.len()` మించకూడదు.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // భద్రత: `offset` `self.len()` ను మించదని కాలర్ హామీ ఇస్తుంది,
                    // కాబట్టి ఈ క్రొత్త పాయింటర్ `self` లోపల ఉంది మరియు అందువల్ల శూన్యమైనది కాదని హామీ ఇవ్వబడుతుంది.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // ఇరేటర్ చివరను `offset` మూలకాల ద్వారా వెనుకకు తరలించడానికి సహాయక పనితీరు, కొత్త ముగింపును తిరిగి ఇస్తుంది.
            //
            // సురక్షితం కాదు ఎందుకంటే ఆఫ్‌సెట్ `self.len()` మించకూడదు.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // భద్రత: `offset` `self.len()` ను మించదని కాలర్ హామీ ఇస్తుంది,
                    // ఇది `isize` ని పొంగిపోకుండా హామీ ఇవ్వబడుతుంది.
                    // అలాగే, ఫలిత పాయింటర్ `slice` యొక్క సరిహద్దుల్లో ఉంటుంది, ఇది `offset` కోసం ఇతర అవసరాలను నెరవేరుస్తుంది.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // ముక్కలతో అమలు చేయవచ్చు, కానీ ఇది సరిహద్దుల తనిఖీలను నివారిస్తుంది

                // భద్రత: స్లైస్ ప్రారంభ పాయింటర్ నుండి `assume` కాల్స్ సురక్షితం
                // తప్పనిసరిగా శూన్యంగా ఉండాలి మరియు ZST కాని వాటిపై ముక్కలు కూడా శూన్య రహిత ముగింపు పాయింటర్ కలిగి ఉండాలి.
                // మొదట ఇరేటర్ ఖాళీగా ఉందో లేదో మేము తనిఖీ చేస్తున్నందున `next_unchecked!` కి కాల్ సురక్షితం.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // ఈ మళ్ళి ఇప్పుడు ఖాళీగా ఉంది.
                    if mem::size_of::<T>() == 0 {
                        // `ptr` ఎప్పుడూ 0 కాకపోవచ్చు కాబట్టి మేము ఈ విధంగా చేయాలి, కానీ `end` కావచ్చు (చుట్టడం వల్ల).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // భద్రత: T ZST కాకపోతే ముగింపు 0 గా ఉండకూడదు ఎందుకంటే ptr 0 కాదు మరియు ముగింపు>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // భద్రత: మేము హద్దులో ఉన్నాము.`post_inc_start` ZST లకు కూడా సరైన పని చేస్తుంది.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // మేము `try_fold` ను ఉపయోగించే డిఫాల్ట్ అమలును భర్తీ చేస్తాము, ఎందుకంటే ఈ సాధారణ అమలు తక్కువ LLVM IR ను ఉత్పత్తి చేస్తుంది మరియు కంపైల్ చేయడానికి వేగంగా ఉంటుంది.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // మేము `try_fold` ను ఉపయోగించే డిఫాల్ట్ అమలును భర్తీ చేస్తాము, ఎందుకంటే ఈ సాధారణ అమలు తక్కువ LLVM IR ను ఉత్పత్తి చేస్తుంది మరియు కంపైల్ చేయడానికి వేగంగా ఉంటుంది.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // మేము `try_fold` ను ఉపయోగించే డిఫాల్ట్ అమలును భర్తీ చేస్తాము, ఎందుకంటే ఈ సాధారణ అమలు తక్కువ LLVM IR ను ఉత్పత్తి చేస్తుంది మరియు కంపైల్ చేయడానికి వేగంగా ఉంటుంది.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // మేము `try_fold` ను ఉపయోగించే డిఫాల్ట్ అమలును భర్తీ చేస్తాము, ఎందుకంటే ఈ సాధారణ అమలు తక్కువ LLVM IR ను ఉత్పత్తి చేస్తుంది మరియు కంపైల్ చేయడానికి వేగంగా ఉంటుంది.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // మేము `try_fold` ను ఉపయోగించే డిఫాల్ట్ అమలును భర్తీ చేస్తాము, ఎందుకంటే ఈ సాధారణ అమలు తక్కువ LLVM IR ను ఉత్పత్తి చేస్తుంది మరియు కంపైల్ చేయడానికి వేగంగా ఉంటుంది.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // మేము `try_fold` ను ఉపయోగించే డిఫాల్ట్ అమలును భర్తీ చేస్తాము, ఎందుకంటే ఈ సాధారణ అమలు తక్కువ LLVM IR ను ఉత్పత్తి చేస్తుంది మరియు కంపైల్ చేయడానికి వేగంగా ఉంటుంది.
            // అలాగే, `assume` హద్దుల తనిఖీని నివారిస్తుంది.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // భద్రత: లూప్ మార్పు ద్వారా మేము సరిహద్దులుగా ఉంటామని హామీ ఇవ్వబడింది:
                        // `i >= n`, `self.next()` `None` ను తిరిగి ఇస్తుంది మరియు లూప్ విచ్ఛిన్నమవుతుంది.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // మేము `try_fold` ను ఉపయోగించే డిఫాల్ట్ అమలును భర్తీ చేస్తాము, ఎందుకంటే ఈ సాధారణ అమలు తక్కువ LLVM IR ను ఉత్పత్తి చేస్తుంది మరియు కంపైల్ చేయడానికి వేగంగా ఉంటుంది.
            // అలాగే, `assume` హద్దుల తనిఖీని నివారిస్తుంది.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // భద్రత: `i` `n` నుండి మొదలవుతుంది కాబట్టి `n` కంటే తక్కువగా ఉండాలి
                        // మరియు తగ్గుతోంది.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // భద్రత: కాలర్ `i` యొక్క సరిహద్దులో ఉందని హామీ ఇవ్వాలి
                // అంతర్లీన స్లైస్, కాబట్టి `i` ఒక `isize` ని పొంగి ప్రవహించదు, మరియు తిరిగి వచ్చిన సూచనలు స్లైస్ యొక్క మూలకాన్ని సూచించడానికి హామీ ఇవ్వబడతాయి మరియు తద్వారా చెల్లుబాటు అవుతుందని హామీ ఇవ్వబడుతుంది.
                //
                // అదే సూచికతో మనం మరలా పిలవబడలేదని, మరియు ఈ సబ్‌లైస్‌ను ప్రాప్యత చేసే ఇతర పద్ధతులు ఏవీ పిలువబడవని కూడా కాలర్ హామీ ఇస్తుందని గమనించండి, కాబట్టి తిరిగి వచ్చిన సూచన పరివర్తన చెందడానికి చెల్లుతుంది.
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // ముక్కలతో అమలు చేయవచ్చు, కానీ ఇది సరిహద్దుల తనిఖీలను నివారిస్తుంది

                // భద్రత: స్లైస్ యొక్క ప్రారంభ పాయింటర్ శూన్యంగా ఉండాలి కాబట్టి `assume` కాల్స్ సురక్షితం,
                // మరియు ZST కాని వాటిపై ముక్కలు తప్పనిసరిగా శూన్య రహిత ముగింపు పాయింటర్‌ను కలిగి ఉండాలి.
                // మొదట ఇరేటర్ ఖాళీగా ఉందో లేదో మేము తనిఖీ చేస్తున్నందున `next_back_unchecked!` కి కాల్ సురక్షితం.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // ఈ మళ్ళి ఇప్పుడు ఖాళీగా ఉంది.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // భద్రత: మేము హద్దులో ఉన్నాము.`pre_dec_end` ZST లకు కూడా సరైన పని చేస్తుంది.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}