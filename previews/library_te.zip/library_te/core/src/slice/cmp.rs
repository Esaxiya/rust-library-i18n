//! `[T]` కోసం traits పోలిక.

use crate::cmp;
use crate::cmp::Ordering::{self, Greater, Less};
use crate::mem;

use super::from_raw_parts;
use super::memchr;

extern "C" {
    /// కాల్స్ అమలు memcmp ను అందించింది.
    ///
    /// డేటాను u8 గా వివరిస్తుంది.
    ///
    /// సమానానికి 0, <0 కన్నా తక్కువ మరియు> 0 కన్నా ఎక్కువ తిరిగి ఇస్తుంది.
    ///
    // FIXME(#32610): రిటర్న్ రకం c_int అయి ఉండాలి
    fn memcmp(s1: *const u8, s2: *const u8, n: usize) -> i32;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> PartialEq<[B]> for [A]
where
    A: PartialEq<B>,
{
    fn eq(&self, other: &[B]) -> bool {
        SlicePartialEq::equal(self, other)
    }

    fn ne(&self, other: &[B]) -> bool {
        SlicePartialEq::not_equal(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for [T] {}

/// vectors [lexicographically](Ord#lexicographical-comparison) యొక్క పోలికను అమలు చేస్తుంది.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for [T] {
    fn cmp(&self, other: &[T]) -> Ordering {
        SliceOrd::compare(self, other)
    }
}

/// vectors [lexicographically](Ord#lexicographical-comparison) యొక్క పోలికను అమలు చేస్తుంది.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for [T] {
    fn partial_cmp(&self, other: &[T]) -> Option<Ordering> {
        SlicePartialOrd::partial_compare(self, other)
    }
}

#[doc(hidden)]
// స్లైస్ యొక్క పాక్షికఎక్ యొక్క స్పెషలైజేషన్ కోసం ఇంటర్మీడియట్ trait
trait SlicePartialEq<B> {
    fn equal(&self, other: &[B]) -> bool;

    fn not_equal(&self, other: &[B]) -> bool {
        !self.equal(other)
    }
}

// సాధారణ స్లైస్ సమానత్వం
impl<A, B> SlicePartialEq<B> for [A]
where
    A: PartialEq<B>,
{
    default fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        self.iter().zip(other.iter()).all(|(x, y)| x == y)
    }
}

// రకాలు అనుమతించినప్పుడు బైట్‌వైస్ సమానత్వం కోసం memcmp ఉపయోగించండి
impl<A, B> SlicePartialEq<B> for [A]
where
    A: BytewiseEquality<B>,
{
    fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        // భద్రత: `self` మరియు `other` సూచనలు మరియు అందువల్ల చెల్లుబాటు అయ్యేవి.
        // రెండు ముక్కలు పైన ఒకే పరిమాణంలో ఉన్నాయని తనిఖీ చేయబడ్డాయి.
        unsafe {
            let size = mem::size_of_val(self);
            memcmp(self.as_ptr() as *const u8, other.as_ptr() as *const u8, size) == 0
        }
    }
}

#[doc(hidden)]
// స్లైస్ యొక్క పాక్షిక ఆర్డర్ యొక్క స్పెషలైజేషన్ కోసం ఇంటర్మీడియట్ trait
trait SlicePartialOrd: Sized {
    fn partial_compare(left: &[Self], right: &[Self]) -> Option<Ordering>;
}

impl<A: PartialOrd> SlicePartialOrd for A {
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        let l = cmp::min(left.len(), right.len());

        // కంపైలర్‌లో బౌండ్ చెక్ ఎలిమినేషన్‌ను ప్రారంభించడానికి లూప్ మళ్ళా పరిధికి స్లైస్ చేయండి
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].partial_cmp(&rhs[i]) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }

        left.len().partial_cmp(&right.len())
    }
}

// ఇది మేము కలిగి ఉండాలనుకునే impl.దురదృష్టవశాత్తు ఇది ధ్వని కాదు.
// `partial_ord_slice.rs` చూడండి.
/*
impl<A> SlicePartialOrd for A
where
    A: Ord,
{
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}
*/

impl<A: AlwaysApplicableOrd> SlicePartialOrd for A {
    fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}

#[rustc_specialization_trait]
trait AlwaysApplicableOrd: SliceOrd + Ord {}

macro_rules! always_applicable_ord {
    ($([$($p:tt)*] $t:ty,)*) => {
        $(impl<$($p)*> AlwaysApplicableOrd for $t {})*
    }
}

always_applicable_ord! {
    [] u8, [] u16, [] u32, [] u64, [] u128, [] usize,
    [] i8, [] i16, [] i32, [] i64, [] i128, [] isize,
    [] bool, [] char,
    [T: ?Sized] *const T, [T: ?Sized] *mut T,
    [T: AlwaysApplicableOrd] &T,
    [T: AlwaysApplicableOrd] &mut T,
    [T: AlwaysApplicableOrd] Option<T>,
}

#[doc(hidden)]
// స్లైస్ ఆర్డ్ యొక్క స్పెషలైజేషన్ కోసం ఇంటర్మీడియట్ trait
trait SliceOrd: Sized {
    fn compare(left: &[Self], right: &[Self]) -> Ordering;
}

impl<A: Ord> SliceOrd for A {
    default fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let l = cmp::min(left.len(), right.len());

        // కంపైలర్‌లో బౌండ్ చెక్ ఎలిమినేషన్‌ను ప్రారంభించడానికి లూప్ మళ్ళా పరిధికి స్లైస్ చేయండి
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].cmp(&rhs[i]) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }

        left.len().cmp(&right.len())
    }
}

// memcmp సంతకం చేయని బైట్ల క్రమాన్ని లెక్సిగ్రాఫికల్‌గా పోలుస్తుంది.
// ఇది [u8] కోసం మనకు కావలసిన ఆర్డర్‌తో సరిపోతుంది, కాని ఇతరులు ([i8] కూడా కాదు).
impl SliceOrd for u8 {
    #[inline]
    fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let order =
            // భద్రత: `left` మరియు `right` సూచనలు మరియు అందువల్ల చెల్లుబాటు అయ్యేవి.
            // ఆ విరామంలో చదవడానికి రెండు ప్రాంతాలు చెల్లుబాటు అవుతాయని హామీ ఇచ్చే రెండు పొడవుల కనిష్టాన్ని మేము ఉపయోగిస్తాము.
            //
            unsafe { memcmp(left.as_ptr(), right.as_ptr(), cmp::min(left.len(), right.len())) };
        if order == 0 {
            left.len().cmp(&right.len())
        } else if order < 0 {
            Less
        } else {
            Greater
        }
    }
}

// `Eq` కి ఒక పద్ధతి ఉన్నప్పటికీ `Eq` లో ప్రత్యేకతను అనుమతించడానికి హాక్.
#[rustc_unsafe_specialization_marker]
trait MarkerEq<T>: PartialEq<T> {}

impl<T: Eq> MarkerEq<T> for T {}

#[doc(hidden)]
/// Trait వారి బైట్‌వైస్ ప్రాతినిధ్యాన్ని ఉపయోగించి సమానత్వం కోసం పోల్చగల రకాలు కోసం అమలు చేయబడింది
///
#[rustc_specialization_trait]
trait BytewiseEquality<T>: MarkerEq<T> + Copy {}

macro_rules! impl_marker_for {
    ($traitname:ident, $($ty:ty)*) => {
        $(
            impl $traitname<$ty> for $ty { }
        )*
    }
}

impl_marker_for!(BytewiseEquality,
                 u8 i8 u16 i16 u32 i32 u64 i64 u128 i128 usize isize char bool);

pub(super) trait SliceContains: Sized {
    fn slice_contains(&self, x: &[Self]) -> bool;
}

impl<T> SliceContains for T
where
    T: PartialEq,
{
    default fn slice_contains(&self, x: &[Self]) -> bool {
        x.iter().any(|y| *y == *self)
    }
}

impl SliceContains for u8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        memchr::memchr(*self, x).is_some()
    }
}

impl SliceContains for i8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        let byte = *self as u8;
        // భద్రత: `i8` మరియు `u8` ఒకే మెమరీ లేఅవుట్‌ను కలిగి ఉంటాయి, తద్వారా `x.as_ptr()` ను ప్రసారం చేస్తుంది
        // `*const u8` సురక్షితంగా ఉన్నందున.
        // `x.as_ptr()` ఒక రిఫరెన్స్ నుండి వచ్చింది మరియు అందువల్ల `x.len()` స్లైస్ యొక్క పొడవు కోసం చదవడానికి చెల్లుబాటు అవుతుందని హామీ ఇవ్వబడింది, ఇది `isize::MAX` కన్నా పెద్దదిగా ఉండకూడదు.
        // తిరిగి వచ్చిన స్లైస్ ఎప్పుడూ మార్చబడదు.
        let bytes: &[u8] = unsafe { from_raw_parts(x.as_ptr() as *const u8, x.len()) };
        memchr::memchr(byte, bytes).is_some()
    }
}