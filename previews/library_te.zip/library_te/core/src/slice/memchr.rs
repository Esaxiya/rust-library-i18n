// అసలు అమలు rust-memchr నుండి తీసుకోబడింది.
// కాపీరైట్ 2015 ఆండ్రూ గాల్లంట్, బ్లస్ మరియు నికోలస్ కోచ్

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// కత్తిరించడం ఉపయోగించండి.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// `x` ఏదైనా సున్నా బైట్ కలిగి ఉంటే `true` ను అందిస్తుంది.
///
/// *మాటర్స్ కంప్యూటేషనల్* నుండి, జె. అర్ండ్ట్:
///
/// "ప్రతి బైట్‌ల నుండి ఒకదాన్ని తీసివేసి, ఆపై by ణం అన్నిటికంటే ముఖ్యమైనదిగా ప్రచారం చేసే బైట్‌ల కోసం వెతకాలి.
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// `text` లో బైట్ `x` కి సరిపోయే మొదటి సూచికను అందిస్తుంది.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // చిన్న ముక్కల కోసం వేగవంతమైన మార్గం
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // ఒకేసారి రెండు `usize` పదాలను చదవడం ద్వారా ఒకే బైట్ విలువ కోసం స్కాన్ చేయండి.
    //
    // `text` ను మూడు భాగాలుగా విభజించండి
    // - అన్‌లైన్ చేయని ప్రారంభ భాగం, వచనంలో మొదటి పదం సమలేఖనం చేయబడిన చిరునామాకు ముందు
    // - శరీరం, ఒకేసారి 2 పదాల ద్వారా స్కాన్ చేయండి
    // - చివరి మిగిలిన భాగం, <2 పద పరిమాణం

    // సమలేఖనం చేసిన సరిహద్దు వరకు శోధించండి
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // టెక్స్ట్ యొక్క శరీరాన్ని శోధించండి
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // భద్రత: అయితే అంచనా కనీసం 2 * usize_bytes దూరానికి హామీ ఇస్తుంది
        // ఆఫ్‌సెట్ మరియు స్లైస్ ముగింపు మధ్య.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // సరిపోలే బైట్ ఉంటే విచ్ఛిన్నం
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // బాడీ లూప్ ఆగిపోయిన తర్వాత బైట్‌ను కనుగొనండి.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// `text` లో బైట్ `x` కి సరిపోయే చివరి సూచికను అందిస్తుంది.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // ఒకేసారి రెండు `usize` పదాలను చదవడం ద్వారా ఒకే బైట్ విలువ కోసం స్కాన్ చేయండి.
    //
    // `text` ను మూడు భాగాలుగా విభజించండి:
    // - క్రమబద్ధీకరించని తోక, వచనంలో చివరి పదం సమలేఖనం చేసిన చిరునామా తర్వాత,
    // - శరీరం, ఒకేసారి 2 పదాల ద్వారా స్కాన్ చేయబడింది,
    // - మొదటి మిగిలిన బైట్లు, <2 పద పరిమాణం.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // ఉపసర్గ మరియు ప్రత్యయం యొక్క పొడవును పొందడానికి మేము దీనిని పిలుస్తాము.
        // మధ్యలో మేము ఎల్లప్పుడూ ఒకేసారి రెండు భాగాలుగా ప్రాసెస్ చేస్తాము.
        // భద్రత: `align_to` చేత నిర్వహించబడే పరిమాణ వ్యత్యాసాలు మినహా `[u8]` ను `[usize]` కి బదిలీ చేయడం సురక్షితం.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // టెక్స్ట్ యొక్క శరీరాన్ని శోధించండి, మేము min_aligned_offset ను దాటలేదని నిర్ధారించుకోండి.
    // ఆఫ్‌సెట్ ఎల్లప్పుడూ సమలేఖనం చేయబడుతుంది, కాబట్టి `>` ను పరీక్షించడం సరిపోతుంది మరియు సాధ్యమయ్యే ఓవర్‌ఫ్లోను నివారిస్తుంది.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // భద్రత: ఆఫ్‌సెట్ లెన్, suffix.len() వద్ద మొదలవుతుంది
        // min_aligned_offset (prefix.len()) మిగిలిన దూరం కనీసం 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // మ్యాచింగ్ బైట్ ఉంటే బ్రేక్ చేయండి.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // బాడీ లూప్ ఆగిపోయే ముందు బైట్‌ను కనుగొనండి.
    text[..offset].iter().rposition(|elt| *elt == x)
}