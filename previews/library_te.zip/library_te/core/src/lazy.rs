//! సోమరితనం విలువలు మరియు స్టాటిక్ డేటా యొక్క ఒక-సమయం ప్రారంభించడం.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// ఒక్కసారి మాత్రమే వ్రాయగల సెల్.
///
/// `RefCell` కాకుండా, `OnceCell` దాని విలువకు భాగస్వామ్య `&T` సూచనలను మాత్రమే అందిస్తుంది.
/// `Cell` మాదిరిగా కాకుండా, `OnceCell` దానిని ప్రాప్యత చేయడానికి విలువను కాపీ చేయడం లేదా భర్తీ చేయడం అవసరం లేదు.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // మార్పులేనిది: ఒకేసారి వ్రాయబడింది.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// క్రొత్త ఖాళీ సెల్‌ను సృష్టిస్తుంది.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// అంతర్లీన విలువకు సూచనను పొందుతుంది.
    ///
    /// సెల్ ఖాళీగా ఉంటే `None` ని అందిస్తుంది.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // భద్రత: `అంతర్గత` మార్పు కారణంగా సురక్షితం
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// అంతర్లీన విలువకు మార్చగల సూచనను పొందుతుంది.
    ///
    /// సెల్ ఖాళీగా ఉంటే `None` ని అందిస్తుంది.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // భద్రత: మాకు ప్రత్యేకమైన ప్రాప్యత ఉన్నందున సురక్షితం
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// సెల్ యొక్క కంటెంట్లను `value` కు సెట్ చేస్తుంది.
    ///
    /// # Errors
    ///
    /// సెల్ ఖాళీగా ఉంటే ఈ పద్ధతి `Ok(())` మరియు నిండి ఉంటే `Err(value)` ను అందిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // భద్రత: సురక్షితమైనది ఎందుకంటే మేము మ్యూటబుల్ రుణాలను అతివ్యాప్తి చేయలేము
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // భద్రత: మేము స్లాట్‌ను సెట్ చేసిన ఏకైక ప్రదేశం, జాతులు లేవు
        // reentrancy/concurrency కారణంగా సాధ్యమే, మరియు స్లాట్ ప్రస్తుతం `None` అని మేము తనిఖీ చేసాము, కాబట్టి ఈ వ్రాత `అంతర్గత` యొక్క మార్పును నిర్వహిస్తుంది.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// సెల్ యొక్క కంటెంట్‌లను పొందుతుంది, సెల్ ఖాళీగా ఉంటే దాన్ని `f` తో ప్రారంభిస్తుంది.
    ///
    /// # Panics
    ///
    /// `f` panics అయితే, panic కాలర్‌కు ప్రచారం చేయబడుతుంది మరియు సెల్ ప్రారంభించబడదు.
    ///
    ///
    /// `f` నుండి సెల్‌ను తిరిగి ప్రారంభించడం లోపం.ఇలా చేయడం వల్ల panic వస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// సెల్ యొక్క కంటెంట్‌లను పొందుతుంది, సెల్ ఖాళీగా ఉంటే దాన్ని `f` తో ప్రారంభిస్తుంది.
    /// సెల్ ఖాళీగా ఉంటే మరియు `f` విఫలమైతే, లోపం తిరిగి వస్తుంది.
    ///
    /// # Panics
    ///
    /// `f` panics అయితే, panic కాలర్‌కు ప్రచారం చేయబడుతుంది మరియు సెల్ ప్రారంభించబడదు.
    ///
    ///
    /// `f` నుండి సెల్‌ను తిరిగి ప్రారంభించడం లోపం.ఇలా చేయడం వల్ల panic వస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // *కొన్ని* పున ent ప్రారంభ ప్రారంభాలు UB కి దారితీయవచ్చని గమనించండి (`reentrant_init` పరీక్ష చూడండి).
        // `set/get` ను ఉంచేటప్పుడు ఈ `assert` ను తీసివేయడం ధ్వనిస్తుందని నేను నమ్ముతున్నాను, కాని పాత విలువను నిశ్శబ్దంగా ఉపయోగించడం కంటే panic కి మంచిది.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// చుట్టిన విలువను తిరిగి ఇచ్చి, సెల్‌ను వినియోగిస్తుంది.
    ///
    /// సెల్ ఖాళీగా ఉంటే `None` ని అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // `into_inner` విలువ ప్రకారం `self` ను తీసుకుంటుంది కాబట్టి, కంపైలర్ ప్రస్తుతం రుణం తీసుకోలేదని ధృవీకరిస్తుంది.
        // కాబట్టి `Option<T>` ను బయటకు తరలించడం సురక్షితం.
        self.inner.into_inner()
    }

    /// ఈ `OnceCell` నుండి విలువను తీసుకుంటుంది, దానిని తిరిగి ప్రారంభించని స్థితికి మారుస్తుంది.
    ///
    /// `OnceCell` ప్రారంభించబడకపోతే ఎటువంటి ప్రభావం ఉండదు మరియు `None` ను తిరిగి ఇస్తుంది.
    ///
    /// మార్చగల సూచన అవసరం ద్వారా భద్రతకు హామీ ఇవ్వబడుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// మొదటి ప్రాప్యతపై ప్రారంభించబడిన విలువ.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   ప్రారంభించడానికి సిద్ధంగా ఉంది
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// ఇచ్చిన ప్రారంభ ఫంక్షన్‌తో కొత్త సోమరితనం విలువను సృష్టిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// ఈ సోమరితనం యొక్క మూల్యాంకనాన్ని బలవంతం చేస్తుంది మరియు ఫలితానికి సూచనను అందిస్తుంది.
    ///
    ///
    /// ఇది `Deref` impl కు సమానం, కానీ స్పష్టంగా ఉంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// ప్రారంభించే ఫంక్షన్‌గా `Default` ని ఉపయోగించి కొత్త సోమరితనం విలువను సృష్టిస్తుంది.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}