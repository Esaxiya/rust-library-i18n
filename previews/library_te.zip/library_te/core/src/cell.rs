//! భాగస్వామ్యం చేయగల మ్యూటబుల్ కంటైనర్లు.
//!
//! Rust మెమరీ భద్రత ఈ నియమం మీద ఆధారపడి ఉంటుంది: ఒక వస్తువు `T` ఇచ్చినట్లయితే, కిందివాటిలో ఒకదాన్ని కలిగి ఉండటం మాత్రమే సాధ్యమవుతుంది:
//!
//! - వస్తువుకు అనేక మార్పులేని సూచనలు (`&T`) కలిగి ఉండటం (దీనిని **అలియాసింగ్** అని కూడా పిలుస్తారు).
//! - వస్తువుకు ఒక మ్యూటబుల్ రిఫరెన్స్ (`&మ్యూట్ టి`) కలిగి ఉండటం (దీనిని **మ్యుటబిలిటీ** అని కూడా పిలుస్తారు).
//!
//! ఇది Rust కంపైలర్ చేత అమలు చేయబడుతుంది.ఏదేమైనా, ఈ నియమం తగినంత సరళంగా లేని పరిస్థితులు ఉన్నాయి.కొన్నిసార్లు ఇది ఒక వస్తువుకు బహుళ సూచనలు కలిగి ఉండాలి మరియు ఇంకా దానిని మార్చాలి.
//!
//! మారుపేరు సమక్షంలో కూడా, నియంత్రిత పద్ధతిలో మ్యుటబిలిటీని అనుమతించడానికి షేర్ చేయగల మ్యూటబుల్ కంటైనర్లు ఉన్నాయి.[`Cell<T>`] మరియు [`RefCell<T>`] రెండూ ఒకే-థ్రెడ్ పద్ధతిలో దీన్ని అనుమతిస్తాయి.
//! అయినప్పటికీ, `Cell<T>` లేదా `RefCell<T>` రెండూ థ్రెడ్ సురక్షితం కాదు (అవి [`Sync`] ను అమలు చేయవు).
//! మీరు బహుళ థ్రెడ్ల మధ్య మారుపేరు మరియు మ్యుటేషన్ చేయవలసి వస్తే [`Mutex<T>`], [`RwLock<T>`] లేదా [`atomic`] రకాలను ఉపయోగించడం సాధ్యపడుతుంది.
//!
//! `Cell<T>` మరియు `RefCell<T>` రకాల విలువలు భాగస్వామ్య సూచనల ద్వారా మార్చబడతాయి (అనగా
//! సాధారణ `&T` రకం), అయితే చాలా Rust రకాలను ప్రత్యేకమైన (`&మ్యూట్ T`) సూచనల ద్వారా మాత్రమే మార్చవచ్చు.
//! `Cell<T>` మరియు `RefCell<T>` 'ఇంటీరియర్ మ్యూటబిలిటీ'ని అందిస్తాయని మేము చెప్తాము, సాధారణ Rust రకాలు' వారసత్వంగా ఉత్పరివర్తన 'ని ప్రదర్శిస్తాయి.
//!
//! సెల్ రకాలు రెండు రుచులలో వస్తాయి: `Cell<T>` మరియు `RefCell<T>`.`Cell<T>` `Cell<T>` లో మరియు వెలుపల విలువలను తరలించడం ద్వారా అంతర్గత మ్యుటబిలిటీని అమలు చేస్తుంది.
//! విలువలకు బదులుగా రిఫరెన్స్‌లను ఉపయోగించడానికి, ఒకరు `RefCell<T>` రకాన్ని ఉపయోగించాలి, పరివర్తనం చెందడానికి ముందు వ్రాసే లాక్‌ని పొందాలి.`Cell<T>` ప్రస్తుత అంతర్గత విలువను తిరిగి పొందడానికి మరియు మార్చడానికి పద్ధతులను అందిస్తుంది:
//!
//!  - [`Copy`] ను అమలు చేసే రకాలు కోసం, [`get`](Cell::get) పద్ధతి ప్రస్తుత అంతర్గత విలువను తిరిగి పొందుతుంది.
//!  - [`Default`] ను అమలు చేసే రకాలు కోసం, [`take`](Cell::take) పద్ధతి ప్రస్తుత అంతర్గత విలువను [`Default::default()`] తో భర్తీ చేస్తుంది మరియు భర్తీ చేసిన విలువను తిరిగి ఇస్తుంది.
//!  - అన్ని రకాల కోసం, [`replace`](Cell::replace) పద్ధతి ప్రస్తుత అంతర్గత విలువను భర్తీ చేస్తుంది మరియు భర్తీ చేసిన విలువను తిరిగి ఇస్తుంది మరియు [`into_inner`](Cell::into_inner) పద్ధతి `Cell<T>` ను వినియోగిస్తుంది మరియు అంతర్గత విలువను అందిస్తుంది.
//!  అదనంగా, [`set`](Cell::set) పద్ధతి అంతర్గత విలువను భర్తీ చేస్తుంది, భర్తీ చేయబడిన విలువను వదిలివేస్తుంది.
//!
//! `RefCell<T>` 'డైనమిక్ రుణాలు' అమలు చేయడానికి Rust యొక్క జీవిత కాలాలను ఉపయోగిస్తుంది, ఈ ప్రక్రియ అంతర్గత విలువకు తాత్కాలిక, ప్రత్యేకమైన, మార్చగల ప్రాప్యతను క్లెయిమ్ చేయవచ్చు.
//! `RefCell కోసం రుణాలు<T>Rust యొక్క స్థానిక రిఫరెన్స్ రకాలు కాకుండా, కంపైల్ సమయంలో పూర్తిగా స్థిరంగా ట్రాక్ చేయబడిన 'రన్‌టైమ్‌లో' ట్రాక్ చేయబడతాయి.
//! `RefCell<T>` రుణాలు డైనమిక్ అయినందున, ఇప్పటికే పరస్పరం అరువు తెచ్చుకున్న విలువను రుణం తీసుకోవడానికి ప్రయత్నించవచ్చు;ఇది జరిగినప్పుడు అది panic థ్రెడ్‌కు దారితీస్తుంది.
//!
//! # ఇంటీరియర్ మ్యుటబిలిటీని ఎప్పుడు ఎంచుకోవాలి
//!
//! ఒక విలువను మార్చడానికి ప్రత్యేకమైన ప్రాప్యతను కలిగి ఉన్న మరింత సాధారణ వారసత్వ పరివర్తన, పాయింటర్ అలియాసింగ్ గురించి గట్టిగా వాదించడానికి Rust ను ఎనేబుల్ చేసే కీలక భాషా అంశాలలో ఒకటి, క్రాష్ బగ్‌లను స్థిరంగా నిరోధిస్తుంది.
//! ఆ కారణంగా, వారసత్వంగా ఉత్పరివర్తనానికి ప్రాధాన్యత ఇవ్వబడుతుంది మరియు అంతర్గత ఉత్పరివర్తన అనేది చివరి ప్రయత్నం.
//! సెల్ రకాలు మ్యుటేషన్‌ను అనుమతించని చోట ఎనేబుల్ చేసినందున, అంతర్గత ఉత్పరివర్తన తగిన సందర్భాలు ఉన్నాయి, లేదా *తప్పక* వాడాలి, ఉదా.
//!
//! * మార్పులేని ఏదో యొక్క మ్యుటబిలిటీ 'inside' ను పరిచయం చేస్తోంది
//! * తార్కికంగా-మార్పులేని పద్ధతుల అమలు వివరాలు.
//! * [`Clone`] యొక్క పరివర్తన అమలు.
//!
//! ## మార్పులేని ఏదో యొక్క మ్యుటబిలిటీ 'inside' ను పరిచయం చేస్తోంది
//!
//! [`Rc<T>`] మరియు [`Arc<T>`] తో సహా చాలా షేర్డ్ స్మార్ట్ పాయింటర్ రకాలు, బహుళ పార్టీల మధ్య క్లోన్ చేయగల మరియు పంచుకోగల కంటైనర్లను అందిస్తాయి.
//! కలిగి ఉన్న విలువలు గుణకారం-మారుపేరు కావచ్చు కాబట్టి, అవి `&mut` తో కాకుండా `&` తో మాత్రమే రుణం తీసుకోవచ్చు.
//! కణాలు లేకుండా ఈ స్మార్ట్ పాయింటర్ల లోపల డేటాను మార్చడం అసాధ్యం.
//!
//! మ్యుటబిలిటీని తిరిగి ప్రవేశపెట్టడానికి షేర్డ్ పాయింటర్ రకాల్లో `RefCell<T>` ఉంచడం చాలా సాధారణం:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // డైనమిక్ .ణం యొక్క పరిధిని పరిమితం చేయడానికి క్రొత్త బ్లాక్‌ను సృష్టించండి
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // కాష్ యొక్క మునుపటి రుణాన్ని మేము పరిధిలోకి రానివ్వకపోతే, తదుపరి రుణం డైనమిక్ థ్రెడ్ panic కు కారణమవుతుందని గమనించండి.
//!     //
//!     // `RefCell` ను ఉపయోగించడంలో ఇది ప్రధాన ప్రమాదం.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! ఈ ఉదాహరణ `Rc<T>` ను ఉపయోగిస్తుంది మరియు `Arc<T>` కాదు.`రిఫెల్<T>సింగిల్-థ్రెడ్ దృశ్యాల కోసం.బహుళ-థ్రెడ్ పరిస్థితిలో మీకు భాగస్వామ్య మ్యుటబిలిటీ అవసరమైతే [`RwLock<T>`] లేదా [`Mutex<T>`] ను ఉపయోగించడాన్ని పరిగణించండి.
//!
//! ## తార్కికంగా-మార్పులేని పద్ధతుల అమలు వివరాలు
//!
//! అప్పుడప్పుడు "under the hood" లో మ్యుటేషన్ జరుగుతోందని API లో బహిర్గతం చేయకపోవడం మంచిది.
//! దీనికి కారణం తార్కికంగా ఆపరేషన్ మార్పులేనిది, కానీ ఉదా., కాషింగ్ మ్యుటేషన్ చేయడానికి అమలును బలవంతం చేస్తుంది;లేదా `&self` తీసుకోవటానికి మొదట నిర్వచించిన trait పద్ధతిని అమలు చేయడానికి మీరు మ్యుటేషన్‌ను ఉపయోగించాలి.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // ఖరీదైన గణన ఇక్కడకు వెళుతుంది
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## `Clone` యొక్క పరివర్తన అమలు
//!
//! ఇది మునుపటి యొక్క ప్రత్యేకమైన, కాని సాధారణమైన కేసు: మార్పులేనిదిగా కనిపించే ఆపరేషన్ల కోసం మ్యూటబిలిటీని దాచడం.
//! [`clone`](Clone::clone) పద్ధతి మూలం విలువను మార్చదని భావిస్తున్నారు మరియు `&mut self` కాకుండా `&self` తీసుకుంటామని ప్రకటించబడింది.
//! అందువల్ల, `clone` పద్ధతిలో జరిగే ఏదైనా మ్యుటేషన్ తప్పనిసరిగా సెల్ రకాలను ఉపయోగించాలి.
//! ఉదాహరణకు, [`Rc<T>`] దాని సూచన గణనలను `Cell<T>` లో నిర్వహిస్తుంది.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// మార్చగల మెమరీ స్థానం.
///
/// # Examples
///
/// ఈ ఉదాహరణలో, `Cell<T>` మార్పులేని స్ట్రక్ట్ లోపల మ్యుటేషన్‌ను ప్రారంభిస్తుందని మీరు చూడవచ్చు.
/// మరో మాటలో చెప్పాలంటే, ఇది "interior mutability" ను ప్రారంభిస్తుంది.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // లోపం: `my_struct` మార్పులేనిది
/// // my_struct.regular_field =క్రొత్త_ విలువ;
///
/// // పనులు: `my_struct` మార్పులేనిది అయినప్పటికీ, `special_field` ఒక `Cell`,
/// // ఇది ఎల్లప్పుడూ పరివర్తనం చెందుతుంది
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// మరిన్ని కోసం [module-level documentation](self) చూడండి.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// T కోసం `Default` విలువతో `Cell<T>` ను సృష్టిస్తుంది.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// ఇచ్చిన విలువను కలిగి ఉన్న క్రొత్త `Cell` ను సృష్టిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// ఉన్న విలువను సెట్ చేస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// రెండు కణాల విలువలను మార్పిడి చేస్తుంది.
    /// `std::mem::swap` తో వ్యత్యాసం ఏమిటంటే, ఈ ఫంక్షన్‌కు `&mut` రిఫరెన్స్ అవసరం లేదు.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // భద్రత: ప్రత్యేక థ్రెడ్ల నుండి పిలిస్తే ఇది ప్రమాదకరంగా ఉంటుంది, కానీ `Cell`
        // `!Sync` కాబట్టి ఇది జరగదు.
        // `Cell` ఈ `సెల్'లలో దేనికీ సూచించబడదని నిర్ధారిస్తుంది కాబట్టి ఇది ఏ పాయింటర్లను కూడా చెల్లదు.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// ఉన్న విలువను `val` తో భర్తీ చేస్తుంది మరియు పాత కలిగి ఉన్న విలువను తిరిగి ఇస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // భద్రత: ప్రత్యేక థ్రెడ్ నుండి పిలిస్తే ఇది డేటా రేసులకు కారణమవుతుంది,
        // కానీ `Cell` `!Sync` కాబట్టి ఇది జరగదు.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// విలువను విప్పుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// ఉన్న విలువ యొక్క కాపీని అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // భద్రత: ప్రత్యేక థ్రెడ్ నుండి పిలిస్తే ఇది డేటా రేసులకు కారణమవుతుంది,
        // కానీ `Cell` `!Sync` కాబట్టి ఇది జరగదు.
        unsafe { *self.value.get() }
    }

    /// ఒక ఫంక్షన్‌ను ఉపయోగించి ఉన్న విలువను నవీకరిస్తుంది మరియు క్రొత్త విలువను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// ఈ సెల్‌లోని అంతర్లీన డేటాకు ముడి పాయింటర్‌ను చూపుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// అంతర్లీన డేటాకు మార్చగల సూచనను అందిస్తుంది.
    ///
    /// ఈ కాల్ `Cell` ను పరస్పరం తీసుకుంటుంది (కంపైల్ సమయంలో) ఇది మనకు మాత్రమే సూచన ఉందని హామీ ఇస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `&mut T` నుండి `&Cell<T>` ను అందిస్తుంది
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // భద్రత: `&mut` ప్రత్యేకమైన ప్రాప్యతను నిర్ధారిస్తుంది.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// సెల్ యొక్క విలువను తీసుకుంటుంది, `Default::default()` ను దాని స్థానంలో వదిలివేస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// `&Cell<[T]>` నుండి `&[Cell<T>]` ను అందిస్తుంది
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // భద్రత: `Cell<T>` లో `T` మాదిరిగానే మెమరీ లేఅవుట్ ఉంది.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// డైనమిక్‌గా తనిఖీ చేసిన రుణ నియమాలతో మ్యూటబుల్ మెమరీ స్థానం
///
/// మరిన్ని కోసం [module-level documentation](self) చూడండి.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`] ద్వారా లోపం తిరిగి వచ్చింది.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`] ద్వారా లోపం తిరిగి వచ్చింది.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// సానుకూల విలువలు `Ref` క్రియాశీల సంఖ్యను సూచిస్తాయి.ప్రతికూల విలువలు `RefMut` క్రియాశీల సంఖ్యను సూచిస్తాయి.
// `RefCell` (ఉదా., స్లైస్ యొక్క విభిన్న పరిధులు) యొక్క విభిన్నమైన, నాన్‌ఓవర్‌లాపింగ్ భాగాలను సూచిస్తేనే బహుళ `RefMut` లు ఒకేసారి చురుకుగా ఉంటాయి.
//
// `Ref` మరియు `RefMut` రెండూ పరిమాణంలో రెండు పదాలు, అందువల్ల `usize` పరిధిలో సగం పొంగిపొర్లుటకు తగినంత `Ref` లు లేదా`RefMut` ఉనికిలో ఉండదు.
// అందువల్ల, `BorrowFlag` బహుశా ఎప్పటికీ పొంగిపొర్లుతుంది లేదా పొంగిపోదు.
// అయినప్పటికీ, ఇది హామీ కాదు, ఎందుకంటే ఒక రోగలక్షణ ప్రోగ్రామ్ పదేపదే సృష్టించగలదు మరియు తరువాత mem::forget `Ref`s లేదా`RefMut`s.
// అందువల్ల, అన్ని కోడ్‌లు అసురక్షితతను నివారించడానికి ఓవర్‌ఫ్లో మరియు అండర్‌ఫ్లో కోసం స్పష్టంగా తనిఖీ చేయాలి లేదా ఓవర్‌ఫ్లో లేదా అండర్ ఫ్లో జరిగినప్పుడు కనీసం సరిగ్గా ప్రవర్తించాలి (ఉదా., BorrowRef::new చూడండి).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// `value` కలిగిన క్రొత్త `RefCell` ను సృష్టిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// చుట్టిన విలువను తిరిగి ఇచ్చి, `RefCell` ను వినియోగిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // ఈ ఫంక్షన్ విలువ ద్వారా `self` (`RefCell`) ను తీసుకుంటుంది కాబట్టి, కంపైలర్ అది ప్రస్తుతం రుణం తీసుకోలేదని ధృవీకరిస్తుంది.
        //
        self.value.into_inner()
    }

    /// చుట్టిన విలువను క్రొత్త దానితో భర్తీ చేస్తుంది, పాత విలువను తిరిగి ఇవ్వకుండా, ఒకదానిని నిర్వీర్యం చేయకుండా.
    ///
    ///
    /// ఈ ఫంక్షన్ [`std::mem::replace`](../mem/fn.replace.html) కి అనుగుణంగా ఉంటుంది.
    ///
    /// # Panics
    ///
    /// విలువ ప్రస్తుతం రుణం తీసుకుంటే Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// చుట్టిన విలువను `f` నుండి లెక్కించిన క్రొత్త దానితో భర్తీ చేస్తుంది, పాత విలువను తిరిగి ఇవ్వకుండా, ఒకదానిని నిర్వీర్యం చేయకుండా.
    ///
    ///
    /// # Panics
    ///
    /// విలువ ప్రస్తుతం రుణం తీసుకుంటే Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// `self` యొక్క చుట్టిన విలువను `other` యొక్క చుట్టిన విలువతో మార్పిడి చేస్తుంది.
    ///
    ///
    /// ఈ ఫంక్షన్ [`std::mem::swap`](../mem/fn.swap.html) కి అనుగుణంగా ఉంటుంది.
    ///
    /// # Panics
    ///
    /// `RefCell` లో విలువ ప్రస్తుతం రుణం తీసుకుంటే Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// చుట్టిన విలువను అస్థిరంగా తీసుకుంటుంది.
    ///
    /// తిరిగి వచ్చిన `Ref` పరిధి నుండి నిష్క్రమించే వరకు రుణం ఉంటుంది.
    /// బహుళ మార్పులేని రుణాలు ఒకే సమయంలో తీసుకోవచ్చు.
    ///
    /// # Panics
    ///
    /// విలువ ప్రస్తుతం పరస్పరం రుణం తీసుకుంటే Panics.
    /// భయాందోళన లేని వేరియంట్ కోసం, [`try_borrow`](#method.try_borrow) ఉపయోగించండి.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// panic యొక్క ఉదాహరణ:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// చుట్టిన విలువను మార్పులేని విధంగా రుణం తీసుకుంటుంది, విలువ ప్రస్తుతం పరస్పరం రుణం తీసుకుంటే లోపం తిరిగి వస్తుంది.
    ///
    ///
    /// తిరిగి వచ్చిన `Ref` పరిధి నుండి నిష్క్రమించే వరకు రుణం ఉంటుంది.
    /// బహుళ మార్పులేని రుణాలు ఒకే సమయంలో తీసుకోవచ్చు.
    ///
    /// ఇది [`borrow`](#method.borrow) యొక్క నాన్-పానిక్ వేరియంట్.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // భద్రత: మార్పులేని ప్రాప్యత మాత్రమే ఉందని `BorrowRef` నిర్ధారిస్తుంది
            // రుణం తీసుకున్నప్పుడు విలువకు.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// చుట్టిన విలువను పరస్పరం తీసుకుంటుంది.
    ///
    /// తిరిగి వచ్చిన `RefMut` లేదా దాని నుండి పొందిన అన్ని `RefMut` లు స్కోప్ నుండి నిష్క్రమించే వరకు రుణం ఉంటుంది.
    ///
    /// ఈ రుణం చురుకుగా ఉన్నప్పుడు విలువను తీసుకోలేము.
    ///
    /// # Panics
    ///
    /// విలువ ప్రస్తుతం రుణం తీసుకుంటే Panics.
    /// భయాందోళన లేని వేరియంట్ కోసం, [`try_borrow_mut`](#method.try_borrow_mut) ఉపయోగించండి.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// panic యొక్క ఉదాహరణ:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// చుట్టిన విలువను పరస్పరం తీసుకుంటుంది, విలువ ప్రస్తుతం అరువుగా ఉంటే లోపం తిరిగి వస్తుంది.
    ///
    ///
    /// తిరిగి వచ్చిన `RefMut` లేదా దాని నుండి పొందిన అన్ని `RefMut` లు స్కోప్ నుండి నిష్క్రమించే వరకు రుణం ఉంటుంది.
    /// ఈ రుణం చురుకుగా ఉన్నప్పుడు విలువను తీసుకోలేము.
    ///
    /// ఇది [`borrow_mut`](#method.borrow_mut) యొక్క నాన్-పానిక్ వేరియంట్.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // భద్రత: `BorrowRef` ప్రత్యేకమైన ప్రాప్యతకు హామీ ఇస్తుంది.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// ఈ సెల్‌లోని అంతర్లీన డేటాకు ముడి పాయింటర్‌ను చూపుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// అంతర్లీన డేటాకు మార్చగల సూచనను అందిస్తుంది.
    ///
    /// ఈ కాల్ `RefCell` ను పరస్పరం తీసుకుంటుంది (కంపైల్ సమయంలో) కాబట్టి డైనమిక్ తనిఖీల అవసరం లేదు.
    ///
    /// అయితే జాగ్రత్తగా ఉండండి: ఈ పద్ధతి `self` మార్చగలదని ఆశిస్తుంది, ఇది సాధారణంగా `RefCell` ను ఉపయోగించినప్పుడు కాదు.
    ///
    /// `self` మార్చలేనిది అయితే బదులుగా [`borrow_mut`] పద్ధతిని చూడండి.
    ///
    /// అలాగే, దయచేసి ఈ పద్ధతి ప్రత్యేక పరిస్థితులకు మాత్రమే అని తెలుసుకోండి మరియు సాధారణంగా మీకు కావలసినది కాదు.
    /// సందేహం ఉంటే, బదులుగా [`borrow_mut`] ఉపయోగించండి.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `RefCell` యొక్క రుణ స్థితిపై లీకైన కాపలాదారుల ప్రభావాన్ని రద్దు చేయండి.
    ///
    /// ఈ కాల్ [`get_mut`] ను పోలి ఉంటుంది కాని మరింత ప్రత్యేకమైనది.
    /// రుణాలు లేవని నిర్ధారించడానికి ఇది `RefCell` ను పరస్పరం తీసుకుంటుంది మరియు తరువాత స్టేట్ ట్రాకింగ్ షేర్డ్ రుణాలను రీసెట్ చేస్తుంది.
    /// కొన్ని `Ref` లేదా `RefMut` రుణాలు లీక్ అయినట్లయితే ఇది సంబంధితంగా ఉంటుంది.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// చుట్టిన విలువను మార్పులేని విధంగా రుణం తీసుకుంటుంది, విలువ ప్రస్తుతం పరస్పరం రుణం తీసుకుంటే లోపం తిరిగి వస్తుంది.
    ///
    /// # Safety
    ///
    /// `RefCell::borrow` మాదిరిగా కాకుండా, ఈ పద్ధతి సురక్షితం కాదు ఎందుకంటే ఇది `Ref` ను తిరిగి ఇవ్వదు, తద్వారా రుణ పతాకాన్ని తాకకుండా చేస్తుంది.
    /// ఈ పద్ధతి ద్వారా తిరిగి ఇవ్వబడిన సూచన సజీవంగా ఉన్నప్పుడు `RefCell` ను పరస్పరం రుణం తీసుకోవడం నిర్వచించబడని ప్రవర్తన.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // భద్రత: ఇప్పుడు ఎవరూ చురుకుగా వ్రాయడం లేదని మేము తనిఖీ చేస్తున్నాము, కానీ అది
            // తిరిగి వచ్చిన సూచన ఇకపై ఉపయోగంలోకి వచ్చే వరకు ఎవరూ వ్రాయకుండా చూసుకునేవారి బాధ్యత.
            // అలాగే, `self.value.get()` అనేది `self` యాజమాన్యంలోని విలువను సూచిస్తుంది మరియు తద్వారా `self` యొక్క జీవితకాలం చెల్లుబాటు అవుతుందని హామీ ఇవ్వబడుతుంది.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// చుట్టిన విలువను తీసుకుంటుంది, `Default::default()` ను దాని స్థానంలో వదిలివేస్తుంది.
    ///
    /// # Panics
    ///
    /// విలువ ప్రస్తుతం రుణం తీసుకుంటే Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// విలువ ప్రస్తుతం పరస్పరం రుణం తీసుకుంటే Panics.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// T కోసం `Default` విలువతో `RefCell<T>` ను సృష్టిస్తుంది.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// `RefCell` లో విలువ ప్రస్తుతం రుణం తీసుకుంటే Panics.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// `RefCell` లో విలువ ప్రస్తుతం రుణం తీసుకుంటే Panics.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// `RefCell` లో విలువ ప్రస్తుతం రుణం తీసుకుంటే Panics.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// `RefCell` లో విలువ ప్రస్తుతం రుణం తీసుకుంటే Panics.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// `RefCell` లో విలువ ప్రస్తుతం రుణం తీసుకుంటే Panics.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// `RefCell` లో విలువ ప్రస్తుతం రుణం తీసుకుంటే Panics.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// `RefCell` లో విలువ ప్రస్తుతం రుణం తీసుకుంటే Panics.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // రుణం పెంచడం వల్ల ఈ సందర్భాలలో చదవని విలువ (<=0) వస్తుంది:
            // 1. ఇది <0, అనగా వ్రాత రుణాలు ఉన్నాయి, కాబట్టి Rust యొక్క రిఫరెన్స్ అలియాసింగ్ నిబంధనల కారణంగా మేము చదవడానికి రుణం అనుమతించలేము.
            // 2.
            // ఇది isize::MAX (పఠనం అప్పుల గరిష్ట మొత్తం) మరియు ఇది isize::MIN (రాసే రుణాల గరిష్ట మొత్తం) లోకి పొంగిపోయింది కాబట్టి మేము అదనపు రీడ్ రుణాన్ని అనుమతించలేము ఎందుకంటే ఐసైజ్ చాలా చదివిన రుణాలను సూచించదు (ఇది జరిగితే మాత్రమే జరుగుతుంది మీరు మంచి రిఫరెన్స్ యొక్క చిన్న స్థిరమైన మొత్తం కంటే mem::forget ఎక్కువ, ఇది మంచి అభ్యాసం కాదు)
            //
            //
            //
            //
            None
        } else {
            // రుణం పెంచడం వల్ల ఈ సందర్భాలలో పఠన విలువ (> 0) వస్తుంది:
            // 1. ఇది=0, అనగా అది అరువు తీసుకోబడలేదు మరియు మేము మొదటి రీడ్ .ణం తీసుకుంటున్నాము
            // 2. ఇది> 0 మరియు <isize::MAX, అనగా
            // రీడ్ రుణాలు ఉన్నాయి, మరియు ఐసైజ్ ఇంకొక చదవడానికి రుణం కలిగి ఉండటానికి ప్రాతినిధ్యం వహిస్తుంది
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // ఈ Ref ఉనికిలో ఉన్నందున, borrow ణం జెండా ఒక పఠనం రుణం అని మాకు తెలుసు.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // రుణం కౌంటర్‌ను వ్రాసే రుణంలోకి పొంగిపోకుండా నిరోధించండి.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// `RefCell` పెట్టెలోని విలువకు అరువు తీసుకున్న సూచనను చుట్టేస్తుంది.
/// `RefCell<T>` నుండి అరువు తెచ్చుకున్న విలువ కోసం రేపర్ రకం.
///
/// మరిన్ని కోసం [module-level documentation](self) చూడండి.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// `Ref` ను కాపీ చేస్తుంది.
    ///
    /// `RefCell` ఇప్పటికే మార్పులేని విధంగా అరువు తెచ్చుకుంది, కాబట్టి ఇది విఫలం కాదు.
    ///
    /// ఇది `Ref::clone(...)` గా ఉపయోగించాల్సిన అనుబంధ ఫంక్షన్.
    /// X001 యొక్క విషయాలను క్లోన్ చేయడానికి `r.borrow().clone()` యొక్క విస్తృతమైన వాడకానికి `Clone` అమలు లేదా ఒక పద్ధతి జోక్యం చేసుకుంటుంది.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// అరువు తెచ్చుకున్న డేటా యొక్క భాగం కోసం కొత్త `Ref` చేస్తుంది.
    ///
    /// `RefCell` ఇప్పటికే మార్పులేని విధంగా అరువు తెచ్చుకుంది, కాబట్టి ఇది విఫలం కాదు.
    ///
    /// ఇది `Ref::map(...)` గా ఉపయోగించాల్సిన అనుబంధ ఫంక్షన్.
    /// `Deref` ద్వారా ఉపయోగించే `RefCell` యొక్క విషయాలపై అదే పేరు యొక్క పద్ధతులతో ఒక పద్ధతి జోక్యం చేసుకుంటుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// అరువు తెచ్చుకున్న డేటా యొక్క ఐచ్ఛిక భాగం కోసం కొత్త `Ref` చేస్తుంది.
    /// మూసివేత `None` ను తిరిగి ఇస్తే అసలు గార్డు `Err(..)` గా తిరిగి ఇవ్వబడుతుంది.
    ///
    /// `RefCell` ఇప్పటికే మార్పులేని విధంగా అరువు తెచ్చుకుంది, కాబట్టి ఇది విఫలం కాదు.
    ///
    /// ఇది `Ref::filter_map(...)` గా ఉపయోగించాల్సిన అనుబంధ ఫంక్షన్.
    /// `Deref` ద్వారా ఉపయోగించే `RefCell` యొక్క విషయాలపై అదే పేరు యొక్క పద్ధతులతో ఒక పద్ధతి జోక్యం చేసుకుంటుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// అరువు తెచ్చుకున్న డేటా యొక్క విభిన్న భాగాల కోసం ఒక `Ref` ను బహుళ `రెఫ్'లుగా విభజిస్తుంది.
    ///
    /// `RefCell` ఇప్పటికే మార్పులేని విధంగా అరువు తెచ్చుకుంది, కాబట్టి ఇది విఫలం కాదు.
    ///
    /// ఇది `Ref::map_split(...)` గా ఉపయోగించాల్సిన అనుబంధ ఫంక్షన్.
    /// `Deref` ద్వారా ఉపయోగించే `RefCell` యొక్క విషయాలపై అదే పేరు యొక్క పద్ధతులతో ఒక పద్ధతి జోక్యం చేసుకుంటుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// అంతర్లీన డేటాకు సూచనగా మార్చండి.
    ///
    /// అంతర్లీన `RefCell` మరలా మరలా పరస్పరం రుణం తీసుకోబడదు మరియు ఎల్లప్పుడూ అప్పటికే మార్పులేని అరువుగా కనిపిస్తుంది.
    ///
    /// స్థిరమైన సూచనల కంటే ఎక్కువ లీక్ చేయడం మంచిది కాదు.
    /// మొత్తంగా తక్కువ సంఖ్యలో లీక్‌లు సంభవించినట్లయితే `RefCell` ని మళ్లీ అరువుగా తీసుకోవచ్చు.
    ///
    /// ఇది `Ref::leak(...)` గా ఉపయోగించాల్సిన అనుబంధ ఫంక్షన్.
    /// `Deref` ద్వారా ఉపయోగించే `RefCell` యొక్క విషయాలపై అదే పేరు యొక్క పద్ధతులతో ఒక పద్ధతి జోక్యం చేసుకుంటుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // ఈ Ref ని మరచిపోవడం ద్వారా, RefCell లోని రుణ కౌంటర్ జీవితకాలం `'b` లోపు UNUSED కి తిరిగి వెళ్ళలేమని మేము నిర్ధారిస్తాము.
        // రిఫరెన్స్ ట్రాకింగ్ స్థితిని రీసెట్ చేయడానికి రుణం తీసుకున్న రిఫెల్‌కు ప్రత్యేకమైన సూచన అవసరం.
        // అసలు సెల్ నుండి మరింత మ్యుటబుల్ సూచనలు సృష్టించబడవు.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// అరువు తెచ్చుకున్న డేటా యొక్క భాగం కోసం క్రొత్త `RefMut` ను చేస్తుంది, ఉదా., ఎనుమ్ వేరియంట్.
    ///
    /// `RefCell` ఇప్పటికే పరస్పరం అరువు తెచ్చుకుంది, కాబట్టి ఇది విఫలం కాదు.
    ///
    /// ఇది `RefMut::map(...)` గా ఉపయోగించాల్సిన అనుబంధ ఫంక్షన్.
    /// `Deref` ద్వారా ఉపయోగించే `RefCell` యొక్క విషయాలపై అదే పేరు యొక్క పద్ధతులతో ఒక పద్ధతి జోక్యం చేసుకుంటుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): రుణాలు తనిఖీ చేయండి
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// అరువు తెచ్చుకున్న డేటా యొక్క ఐచ్ఛిక భాగం కోసం కొత్త `RefMut` చేస్తుంది.
    /// మూసివేత `None` ను తిరిగి ఇస్తే అసలు గార్డు `Err(..)` గా తిరిగి ఇవ్వబడుతుంది.
    ///
    /// `RefCell` ఇప్పటికే పరస్పరం అరువు తెచ్చుకుంది, కాబట్టి ఇది విఫలం కాదు.
    ///
    /// ఇది `RefMut::filter_map(...)` గా ఉపయోగించాల్సిన అనుబంధ ఫంక్షన్.
    /// `Deref` ద్వారా ఉపయోగించే `RefCell` యొక్క విషయాలపై అదే పేరు యొక్క పద్ధతులతో ఒక పద్ధతి జోక్యం చేసుకుంటుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): రుణాలు తనిఖీ చేయండి
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // భద్రత: వ్యవధి కోసం ఫంక్షన్ ప్రత్యేకమైన సూచనను కలిగి ఉంటుంది
        // `orig` ద్వారా దాని కాల్, మరియు పాయింటర్ ఫంక్షన్ కాల్ లోపల మాత్రమే ప్రస్తావించబడింది, ప్రత్యేకమైన సూచనను తప్పించుకోవడానికి ఎప్పుడూ అనుమతించదు.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // భద్రత: పైన చెప్పినట్లే.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// అరువు తీసుకున్న డేటా యొక్క విభిన్న భాగాల కోసం ఒక `RefMut` ను బహుళ `RefMut` లలో విభజిస్తుంది.
    ///
    /// తిరిగి వచ్చిన `రెఫ్‌మట్ 'రెండూ పరిధిలోకి వెళ్ళే వరకు అంతర్లీన `RefCell` పరస్పరం అరువుగా ఉంటుంది.
    ///
    /// `RefCell` ఇప్పటికే పరస్పరం అరువు తెచ్చుకుంది, కాబట్టి ఇది విఫలం కాదు.
    ///
    /// ఇది `RefMut::map_split(...)` గా ఉపయోగించాల్సిన అనుబంధ ఫంక్షన్.
    /// `Deref` ద్వారా ఉపయోగించే `RefCell` యొక్క విషయాలపై అదే పేరు యొక్క పద్ధతులతో ఒక పద్ధతి జోక్యం చేసుకుంటుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// అంతర్లీన డేటాకు మార్చగల సూచనగా మార్చండి.
    ///
    /// అంతర్లీన `RefCell` ను మళ్ళీ అరువు తీసుకోలేము మరియు ఎల్లప్పుడూ ఇప్పటికే పరస్పరం అరువు తెచ్చుకున్నట్లు కనిపిస్తుంది, తిరిగి వచ్చిన సూచన లోపలికి మాత్రమే అవుతుంది.
    ///
    ///
    /// ఇది `RefMut::leak(...)` గా ఉపయోగించాల్సిన అనుబంధ ఫంక్షన్.
    /// `Deref` ద్వారా ఉపయోగించే `RefCell` యొక్క విషయాలపై అదే పేరు యొక్క పద్ధతులతో ఒక పద్ధతి జోక్యం చేసుకుంటుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // ఈ BorrowRefMut ని మరచిపోవడం ద్వారా, RefCell లోని రుణ కౌంటర్ జీవితకాలం `'b` లోపు UNUSED కి తిరిగి వెళ్ళలేమని మేము నిర్ధారిస్తాము.
        // రిఫరెన్స్ ట్రాకింగ్ స్థితిని రీసెట్ చేయడానికి రుణం తీసుకున్న రిఫెల్‌కు ప్రత్యేకమైన సూచన అవసరం.
        // ఆ జీవితకాలంలో అసలు సెల్ నుండి మరిన్ని సూచనలు సృష్టించబడవు, ప్రస్తుత జీవితకాలం మిగిలిన జీవితకాలానికి మాత్రమే సూచనగా మారుతుంది.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: BorrowRefMut::clone కాకుండా, ప్రారంభాన్ని సృష్టించడానికి క్రొత్తదాన్ని పిలుస్తారు
        // మార్చగల సూచన, అందువల్ల ప్రస్తుతం ఉన్న సూచనలు ఉండకూడదు.
        // అందువల్ల, క్లోన్ మ్యూటబుల్ రిఫ్‌కౌంట్‌ను పెంచుతున్నప్పుడు, ఇక్కడ మేము స్పష్టంగా UNUSED నుండి UNUSED, 1 కి వెళ్లడానికి మాత్రమే అనుమతిస్తాము.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // `BorrowRefMut` క్లోన్ చేస్తుంది.
    //
    // ప్రతి `BorrowRefMut` అసలు వస్తువు యొక్క విభిన్నమైన, నాన్‌ఓవర్లాపింగ్ పరిధికి మార్చగల సూచనను ట్రాక్ చేయడానికి ఉపయోగించినట్లయితే మాత్రమే ఇది చెల్లుతుంది.
    //
    // ఇది క్లోన్ ఇంప్లో లేదు కాబట్టి కోడ్ దీనిని అవ్యక్తంగా పిలవదు.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // రుణ కౌంటర్ ప్రవాహం నుండి నిరోధించండి.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// `RefCell<T>` నుండి పరస్పరం అరువు తెచ్చుకున్న విలువ కోసం రేపర్ రకం.
///
/// మరిన్ని కోసం [module-level documentation](self) చూడండి.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Rust లో ఇంటీరియర్ మ్యుటబిలిటీ కోసం కోర్ ఆదిమ.
///
/// మీకు రిఫరెన్స్ `&T` ఉంటే, సాధారణంగా Rust లో కంపైలర్ `&T` మార్పులేని డేటాకు సూచించే జ్ఞానం ఆధారంగా ఆప్టిమైజేషన్లను చేస్తుంది.ఆ డేటాను మార్చడం, ఉదాహరణకు అలియాస్ ద్వారా లేదా `&T` ను `&mut T` గా మార్చడం ద్వారా, నిర్వచించబడని ప్రవర్తనగా పరిగణించబడుతుంది.
/// `UnsafeCell<T>` `&T` కోసం మార్పులేని హామీని నిలిపివేస్తుంది: భాగస్వామ్య సూచన `&UnsafeCell<T>` పరివర్తనం చెందుతున్న డేటాను సూచిస్తుంది.దీనిని "interior mutability" అంటారు.
///
/// `Cell<T>` మరియు `RefCell<T>` వంటి అంతర్గత మ్యుటబిలిటీని అనుమతించే అన్ని ఇతర రకాలు, అంతర్గతంగా వారి డేటాను చుట్టడానికి `UnsafeCell` ను ఉపయోగిస్తాయి.
///
/// భాగస్వామ్య సూచనల కోసం మార్పులేని హామీ మాత్రమే `UnsafeCell` చే ప్రభావితమవుతుందని గమనించండి.మ్యూటబుల్ రిఫరెన్స్‌ల యొక్క ప్రత్యేక హామీ ప్రభావితం కాదు.అలియాసింగ్ `&mut` ను పొందటానికి * చట్టపరమైన మార్గం లేదు, `UnsafeCell<T>` తో కూడా కాదు.
///
/// `UnsafeCell` API సాంకేతికంగా చాలా సులభం: [`.get()`] మీకు దాని విషయాలకు ముడి పాయింటర్ `*mut T` ఇస్తుంది.ఆ పాయింటర్‌ను సరిగ్గా ఉపయోగించడం సంగ్రహణ డిజైనర్‌గా _you_ వరకు ఉంటుంది.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// ఖచ్చితమైన Rust మారుపేరు నియమాలు కొంతవరకు ఫ్లక్స్‌లో ఉన్నాయి, కానీ ప్రధాన అంశాలు వివాదాస్పదంగా లేవు:
///
/// - మీరు సురక్షితమైన కోడ్ ద్వారా ప్రాప్యత చేయగల జీవితకాల `'a` (`&T` లేదా `&mut T` రిఫరెన్స్) తో సురక్షితమైన సూచనను సృష్టిస్తే (ఉదాహరణకు, మీరు దానిని తిరిగి ఇచ్చినందున), అప్పుడు మీరు డేటాను ఆ సూచనకు విరుద్ధంగా ఏ విధంగానైనా యాక్సెస్ చేయకూడదు `'a` యొక్క.
/// ఉదాహరణకు, మీరు `UnsafeCell<T>` నుండి `*mut T` ను తీసుకొని దానిని `&T` కి ప్రసారం చేస్తే, అప్పుడు `T` లోని డేటా మార్పులేనిదిగా ఉండాలి (`T` లో కనిపించే ఏదైనా `UnsafeCell` డేటాను మాడ్యులో చేయండి), ఆ సూచన జీవితకాలం ముగిసే వరకు.
/// అదేవిధంగా, మీరు సురక్షితమైన కోడ్‌కు విడుదల చేయబడిన `&mut T` రిఫరెన్స్‌ను సృష్టిస్తే, ఆ సూచన గడువు ముగిసే వరకు మీరు `UnsafeCell` లోని డేటాను యాక్సెస్ చేయకూడదు.
///
/// - అన్ని సమయాల్లో, మీరు డేటా రేసులను తప్పించాలి.బహుళ థ్రెడ్‌లు ఒకే `UnsafeCell` కి ప్రాప్యతను కలిగి ఉంటే, అప్పుడు ఏదైనా ఇతర రచనలకు సరైన సంఘటనలు ఉండాలి-అన్ని ఇతర ప్రాప్యతలకు ముందు (లేదా అణువులను వాడండి).
///
/// సరైన రూపకల్పనకు సహాయపడటానికి, కింది దృశ్యాలు సింగిల్-థ్రెడ్ కోడ్ కోసం చట్టబద్ధంగా స్పష్టంగా ప్రకటించబడ్డాయి:
///
/// 1. `&T` రిఫరెన్స్‌ను సురక్షిత కోడ్‌కు విడుదల చేయవచ్చు మరియు అక్కడ అది ఇతర `&T` రిఫరెన్స్‌లతో కలిసి ఉంటుంది, కానీ `&mut T` తో కాదు
///
/// 2. `&mut T` రిఫరెన్స్ సురక్షిత కోడ్‌కు విడుదల చేయబడవచ్చు, ఇతర `&mut T` లేదా `&T` దానితో సహజీవనం చేయవు.`&mut T` ఎల్లప్పుడూ ప్రత్యేకంగా ఉండాలి.
///
/// `&UnsafeCell<T>` యొక్క కంటెంట్లను మార్చడం (ఇతర `&UnsafeCell<T>` రిఫరెన్స్ అలియాస్ సెల్ అయినప్పటికీ) సరేనని గమనించండి (మీరు పైన పేర్కొన్న మార్పులను వేరే విధంగా అమలు చేస్తే), బహుళ `&mut UnsafeCell<T>` మారుపేర్లను కలిగి ఉండటం ఇప్పటికీ నిర్వచించబడని ప్రవర్తన.
/// అంటే, `UnsafeCell` అనేది _shared_ accesses (_i.e._ తో ప్రత్యేక పరస్పర చర్య కోసం రూపొందించబడిన ఒక రేపర్, `&UnsafeCell<_>` సూచన ద్వారా);_exclusive_ accesses (_e.g._ తో, `&mut UnsafeCell<_>` ద్వారా వ్యవహరించేటప్పుడు ఎటువంటి మాయాజాలం లేదు): ఆ `&mut` రుణం యొక్క కాలానికి సెల్ లేదా చుట్టిన విలువ కూడా మారుపేరు కావు.
///
/// ఇది [`.get_mut()`] యాక్సెసర్ చేత ప్రదర్శించబడుతుంది, ఇది _safe_ getter, ఇది `&mut T` ను ఇస్తుంది.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// కణాన్ని మారుపేరు చేసే బహుళ సూచనలు ఉన్నప్పటికీ, `UnsafeCell<_>` యొక్క విషయాలను ఎలా చక్కగా మార్చాలో చూపించే ఉదాహరణ ఇక్కడ ఉంది:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // ఒకే `x` కు బహుళ/ఏకకాలిక/భాగస్వామ్య సూచనలను పొందండి.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // భద్రత: ఈ పరిధిలో `x` యొక్క విషయాలకు ఇతర సూచనలు లేవు,
///     // కాబట్టి మాది సమర్థవంతంగా ప్రత్యేకమైనది.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- రుణం-+
///     *p1_exclusive += 27; // |
/// } // <---------- ఈ పాయింట్ దాటి వెళ్ళలేరు -------------------+
///
/// unsafe {
///     // భద్రత: ఈ పరిధిలో `x` యొక్క విషయాలకు ప్రత్యేకమైన ప్రాప్యత ఉంటుందని ఎవరూ ఆశించరు,
///     // కాబట్టి మేము ఏకకాలంలో బహుళ భాగస్వామ్య ప్రాప్యతలను కలిగి ఉండవచ్చు.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// `UnsafeCell<T>` కు ప్రత్యేకమైన ప్రాప్యత దాని `T` కు ప్రత్యేకమైన ప్రాప్యతను సూచిస్తుందనే వాస్తవాన్ని ఈ క్రింది ఉదాహరణ చూపిస్తుంది:
///
/// ```rust
/// #![forbid(unsafe_code)] // ప్రత్యేక ప్రాప్యతలతో,
///                         // `UnsafeCell` పారదర్శక నో-ఆప్ రేపర్, కాబట్టి ఇక్కడ `unsafe` అవసరం లేదు.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // `x` కు కంపైల్-టైమ్-చెక్డ్ ప్రత్యేక సూచనను పొందండి.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // ప్రత్యేకమైన సూచనతో, మేము విషయాలను ఉచితంగా మార్చవచ్చు.
/// *p_unique.get_mut() = 0;
/// // లేదా, సమానంగా:
/// x = UnsafeCell::new(0);
///
/// // మేము విలువను కలిగి ఉన్నప్పుడు, మేము ఉచితంగా విషయాలను సేకరించవచ్చు.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// `UnsafeCell` యొక్క క్రొత్త ఉదాహరణను నిర్మిస్తుంది, ఇది పేర్కొన్న విలువను చుట్టేస్తుంది.
    ///
    ///
    /// పద్ధతుల ద్వారా అంతర్గత విలువకు అన్ని యాక్సెస్ `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// విలువను విప్పుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// చుట్టిన విలువకు మార్చగల పాయింటర్‌ను పొందుతుంది.
    ///
    /// దీన్ని ఏ రకమైన పాయింటర్‌కు అయినా వేయవచ్చు.
    /// `&mut T` కు ప్రసారం చేసేటప్పుడు ప్రాప్యత ప్రత్యేకమైనదని (క్రియాశీల సూచనలు లేవు, మార్చగలవి కావు) మరియు `&T` కు ప్రసారం చేసేటప్పుడు ఉత్పరివర్తనలు లేదా మార్చగల మారుపేర్లు లేవని నిర్ధారించుకోండి.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // #[repr(transparent)] కారణంగా మనం పాయింటర్‌ను `UnsafeCell<T>` నుండి `T` కు ప్రసారం చేయవచ్చు.
        // ఇది libstd యొక్క ప్రత్యేక స్థితిని దోపిడీ చేస్తుంది, ఇది కంపైలర్ యొక్క future సంస్కరణల్లో పనిచేస్తుందని యూజర్ కోడ్‌కు ఎటువంటి హామీ లేదు!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// అంతర్లీన డేటాకు మార్చగల సూచనను అందిస్తుంది.
    ///
    /// ఈ కాల్ `UnsafeCell` ను పరస్పరం తీసుకుంటుంది (కంపైల్ సమయంలో) ఇది మనకు మాత్రమే సూచన ఉందని హామీ ఇస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// చుట్టిన విలువకు మార్చగల పాయింటర్‌ను పొందుతుంది.
    /// [`get`] కి ఉన్న వ్యత్యాసం ఏమిటంటే, ఈ ఫంక్షన్ ముడి పాయింటర్‌ను అంగీకరిస్తుంది, ఇది తాత్కాలిక సూచనల సృష్టిని నివారించడానికి ఉపయోగపడుతుంది.
    ///
    /// ఫలితాన్ని ఏ రకమైన పాయింటర్‌కు అయినా వేయవచ్చు.
    /// `&mut T` కు ప్రసారం చేసేటప్పుడు ప్రాప్యత ప్రత్యేకమైనదని నిర్ధారించుకోండి (క్రియాశీల సూచనలు లేవు, మార్చగలవి కావు) మరియు `&T` కు ప్రసారం చేసేటప్పుడు ఉత్పరివర్తనలు లేదా మార్చగల మారుపేర్లు జరగకుండా చూసుకోండి.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// `UnsafeCell` యొక్క క్రమంగా ప్రారంభించడానికి `raw_get` అవసరం, ఎందుకంటే `get` కి కాల్ చేయడం ప్రారంభించని డేటాకు సూచనను సృష్టించడం అవసరం:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // #[repr(transparent)] కారణంగా మనం పాయింటర్‌ను `UnsafeCell<T>` నుండి `T` కు ప్రసారం చేయవచ్చు.
        // ఇది libstd యొక్క ప్రత్యేక స్థితిని దోపిడీ చేస్తుంది, ఇది కంపైలర్ యొక్క future సంస్కరణల్లో పనిచేస్తుందని యూజర్ కోడ్‌కు ఎటువంటి హామీ లేదు!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// T కోసం `Default` విలువతో `UnsafeCell` ను సృష్టిస్తుంది.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}