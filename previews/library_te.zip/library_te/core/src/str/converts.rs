//! బైట్స్ స్లైస్ నుండి `str` ను సృష్టించే మార్గాలు.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// బైట్ల స్లైస్‌ని స్ట్రింగ్ స్లైస్‌గా మారుస్తుంది.
///
/// స్ట్రింగ్ స్లైస్ ([`&str`]) బైట్లు ([`u8`]) తో తయారు చేయబడింది, మరియు బైట్ స్లైస్ ([`&[u8]`][byteslice]) బైట్‌లతో తయారు చేయబడింది, కాబట్టి ఈ ఫంక్షన్ రెండింటి మధ్య మారుతుంది.
/// అన్ని బైట్ ముక్కలు చెల్లుబాటు అయ్యే స్ట్రింగ్ ముక్కలు కావు, అయితే: [`&str`] కి చెల్లుబాటు అయ్యే UTF-8 అవసరం.
/// `from_utf8()` బైట్లు చెల్లుబాటు అయ్యే UTF-8 అని నిర్ధారించడానికి తనిఖీ చేస్తుంది, ఆపై మార్పిడి చేస్తుంది.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// బైట్ స్లైస్ చెల్లుబాటు అయ్యే UTF-8 అని మీకు ఖచ్చితంగా తెలిస్తే, మరియు చెల్లుబాటు చెక్ యొక్క ఓవర్ హెడ్ ను మీరు పొందకూడదనుకుంటే, ఈ ఫంక్షన్ యొక్క అసురక్షిత వెర్షన్, [`from_utf8_unchecked`] ఉంది, ఇది అదే ప్రవర్తనను కలిగి ఉంది కాని చెక్కును దాటవేస్తుంది.
///
///
/// మీకు `&str` కు బదులుగా `String` అవసరమైతే, [`String::from_utf8`][string] ను పరిగణించండి.
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// ఎందుకంటే మీరు `[u8; N]` ను స్టాక్-కేటాయించవచ్చు మరియు మీరు దాని యొక్క [`&[u8]`][byteslice] తీసుకోవచ్చు, ఈ ఫంక్షన్ స్టాక్-కేటాయించిన స్ట్రింగ్ కలిగి ఉండటానికి ఒక మార్గం.దిగువ ఉదాహరణల విభాగంలో దీనికి ఉదాహరణ ఉంది.
///
/// [byteslice]: slice
///
/// # Errors
///
/// అందించిన స్లైస్ UTF-8 ఎందుకు కాదని వివరణతో స్లైస్ UTF-8 కాకపోతే `Err` ను అందిస్తుంది.
///
/// # Examples
///
/// ప్రాథమిక వినియోగం:
///
/// ```
/// use std::str;
///
/// // కొన్ని బైట్లు, vector లో
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // ఈ బైట్లు చెల్లుబాటు అవుతాయని మాకు తెలుసు, కాబట్టి `unwrap()` ను ఉపయోగించండి.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// తప్పు బైట్లు:
///
/// ```
/// use std::str;
///
/// // vector లో కొన్ని చెల్లని బైట్లు
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// తిరిగి ఇవ్వగల లోపాల గురించి మరిన్ని వివరాల కోసం [`Utf8Error`] కోసం డాక్స్ చూడండి.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // కొన్ని బైట్లు, స్టాక్-కేటాయించిన శ్రేణిలో
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // ఈ బైట్లు చెల్లుబాటు అవుతాయని మాకు తెలుసు, కాబట్టి `unwrap()` ను ఉపయోగించండి.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // భద్రత: ధ్రువీకరణ అమలులో ఉంది.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// మార్చగల స్లైస్ బైట్‌లను మ్యూటబుల్ స్ట్రింగ్ స్లైస్‌గా మారుస్తుంది.
///
/// # Examples
///
/// ప్రాథమిక వినియోగం:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" మార్చగల vector గా
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // ఈ బైట్లు చెల్లుబాటు అవుతాయని మాకు తెలుసు కాబట్టి, మేము `unwrap()` ను ఉపయోగించవచ్చు
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// తప్పు బైట్లు:
///
/// ```
/// use std::str;
///
/// // మార్చగల vector లో కొన్ని చెల్లని బైట్లు
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// తిరిగి ఇవ్వగల లోపాల గురించి మరిన్ని వివరాల కోసం [`Utf8Error`] కోసం డాక్స్ చూడండి.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // భద్రత: ధ్రువీకరణ అమలులో ఉంది.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// స్ట్రింగ్ చెల్లుబాటు అయ్యే UTF-8 కలిగి ఉందో లేదో తనిఖీ చేయకుండా బైట్ల స్లైస్‌ను స్ట్రింగ్ స్లైస్‌గా మారుస్తుంది.
///
/// మరింత సమాచారం కోసం [`from_utf8`] అనే సురక్షిత సంస్కరణ చూడండి.
///
/// # Safety
///
/// ఈ ఫంక్షన్ సురక్షితం కాదు ఎందుకంటే దీనికి పంపిన బైట్లు చెల్లుబాటు అయ్యే UTF-8 అని తనిఖీ చేయవు.
/// ఈ అడ్డంకి ఉల్లంఘించినట్లయితే, నిర్వచించబడని ప్రవర్తన ఫలితాలు, మిగిలిన Rust [`&str`] లు చెల్లుబాటు అయ్యే UTF-8 అని umes హిస్తాయి.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// ప్రాథమిక వినియోగం:
///
/// ```
/// use std::str;
///
/// // కొన్ని బైట్లు, vector లో
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // భద్రత: `v` బైట్లు చెల్లుబాటు అయ్యే UTF-8 అని కాలర్ హామీ ఇవ్వాలి.
    // ఒకే లేఅవుట్ ఉన్న `&str` మరియు `&[u8]` లపై కూడా ఆధారపడుతుంది.
    unsafe { mem::transmute(v) }
}

/// స్ట్రింగ్ చెల్లుబాటు అయ్యే UTF-8 కలిగి ఉందో లేదో తనిఖీ చేయకుండా బైట్ల స్లైస్‌ను స్ట్రింగ్ స్లైస్‌గా మారుస్తుంది;మార్చగల సంస్కరణ.
///
///
/// మరింత సమాచారం కోసం మార్పులేని వెర్షన్, [`from_utf8_unchecked()`] చూడండి.
///
/// # Examples
///
/// ప్రాథమిక వినియోగం:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // భద్రత: కాలర్ `v` బైట్లు అని హామీ ఇవ్వాలి
    // చెల్లుబాటు అయ్యే UTF-8, అందువల్ల `*mut str` కు ప్రసారం సురక్షితం.
    // అలాగే, పాయింటర్ డీరెఫరెన్స్ సురక్షితం ఎందుకంటే ఆ పాయింటర్ సూచనల నుండి వస్తుంది, ఇది వ్రాయడానికి చెల్లుబాటు అవుతుంది.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}