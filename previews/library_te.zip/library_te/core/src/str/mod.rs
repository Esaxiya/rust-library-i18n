//! స్ట్రింగ్ తారుమారు.
//!
//! మరిన్ని వివరాల కోసం, [`std::str`] మాడ్యూల్ చూడండి.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. హద్దులు దాటింది
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. ప్రారంభం <=ముగింపు
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. అక్షర సరిహద్దు
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // పాత్రను కనుగొనండి
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` లెన్ మరియు చార్ సరిహద్దు కంటే తక్కువగా ఉండాలి
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// `self` యొక్క పొడవును అందిస్తుంది.
    ///
    /// ఈ పొడవు బైట్‌లలో ఉంది, [`చార్`] లేదా గ్రాఫిమ్‌లు కాదు.
    /// మరో మాటలో చెప్పాలంటే, స్ట్రింగ్ యొక్క పొడవును మానవుడు భావించేది కాకపోవచ్చు.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // ఫాన్సీ ఎఫ్!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// `self` సున్నా బైట్ల పొడవు కలిగి ఉంటే `true` ని అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// `ఇండెక్స్`-వ బైట్ UTF-8 కోడ్ పాయింట్ సీక్వెన్స్ లేదా స్ట్రింగ్ ముగింపులో మొదటి బైట్ అని తనిఖీ చేస్తుంది.
    ///
    ///
    /// స్ట్రింగ్ యొక్క ప్రారంభ మరియు ముగింపు (`సూచిక== self.len()`) సరిహద్దులుగా పరిగణించబడినప్పుడు.
    ///
    /// `index` `self.len()` కన్నా ఎక్కువగా ఉంటే `false` ని అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // `老` ప్రారంభం
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // `ö` యొక్క రెండవ బైట్
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // `老` యొక్క మూడవ బైట్
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 మరియు లెన్ ఎల్లప్పుడూ సరే.
        // 0 కోసం స్పష్టంగా పరీక్షించండి, తద్వారా ఇది చెక్‌ను సులభంగా ఆప్టిమైజ్ చేస్తుంది మరియు ఆ సందర్భంలో స్ట్రింగ్ డేటాను చదవడం దాటవేయవచ్చు.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // ఇది దీనికి సమానమైన బిట్ మ్యాజిక్: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// స్ట్రింగ్ స్లైస్‌ను బైట్ స్లైస్‌గా మారుస్తుంది.
    /// బైట్ స్లైస్‌ను తిరిగి స్ట్రింగ్ స్లైస్‌గా మార్చడానికి, [`from_utf8`] ఫంక్షన్‌ను ఉపయోగించండి.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // భద్రత: స్థిరమైన ధ్వని ఎందుకంటే మేము ఒకే రకంతో రెండు రకాలను మారుస్తాము
        unsafe { mem::transmute(self) }
    }

    /// మ్యూటబుల్ స్ట్రింగ్ స్లైస్‌ను మ్యూటబుల్ బైట్ స్లైస్‌గా మారుస్తుంది.
    ///
    /// # Safety
    ///
    /// రుణం ముగిసే ముందు మరియు అంతర్లీన `str` ఉపయోగించబడటానికి ముందు స్లైస్ యొక్క కంటెంట్ చెల్లుబాటు అయ్యే UTF-8 అని కాలర్ నిర్ధారించాలి.
    ///
    ///
    /// `str` యొక్క ఉపయోగం చెల్లుబాటు కాని UTF-8 యొక్క ఉపయోగం నిర్వచించబడని ప్రవర్తన.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // భద్రత: `str` నుండి `&str` నుండి `&[u8]` వరకు ప్రసారం సురక్షితం
        // `&[u8]` వలె అదే లేఅవుట్ ఉంది (libstd మాత్రమే ఈ హామీని ఇవ్వగలదు).
        // పాయింటర్ డీరెఫరెన్స్ సురక్షితం ఎందుకంటే ఇది మ్యూటబుల్ రిఫరెన్స్ నుండి వస్తుంది, ఇది వ్రాయడానికి చెల్లుబాటు అవుతుంది.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// స్ట్రింగ్ స్లైస్‌ను ముడి పాయింటర్‌గా మారుస్తుంది.
    ///
    /// స్ట్రింగ్ ముక్కలు బైట్ల ముక్క కాబట్టి, ముడి పాయింటర్ [`u8`] కు సూచిస్తుంది.
    /// ఈ పాయింటర్ స్ట్రింగ్ స్లైస్ యొక్క మొదటి బైట్‌కు సూచించబడుతుంది.
    ///
    /// తిరిగి వచ్చిన పాయింటర్‌కు ఎప్పుడూ వ్రాయబడలేదని కాలర్ నిర్ధారించాలి.
    /// మీరు స్ట్రింగ్ స్లైస్ యొక్క విషయాలను మార్చాల్సిన అవసరం ఉంటే, [`as_mut_ptr`] ను ఉపయోగించండి.
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// మార్చగల స్ట్రింగ్ స్లైస్‌ను ముడి పాయింటర్‌గా మారుస్తుంది.
    ///
    /// స్ట్రింగ్ ముక్కలు బైట్ల ముక్క కాబట్టి, ముడి పాయింటర్ [`u8`] కు సూచిస్తుంది.
    /// ఈ పాయింటర్ స్ట్రింగ్ స్లైస్ యొక్క మొదటి బైట్‌కు సూచించబడుతుంది.
    ///
    /// స్ట్రింగ్ స్లైస్ చెల్లుబాటు అయ్యే UTF-8 గా ఉండే విధంగా మాత్రమే సవరించబడిందని నిర్ధారించుకోవడం మీ బాధ్యత.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// `str` యొక్క సబ్‌లైస్‌ను అందిస్తుంది.
    ///
    /// `str` ను ఇండెక్స్ చేయడానికి ఇది భయాందోళన లేని ప్రత్యామ్నాయం.
    /// సమానమైన ఇండెక్సింగ్ ఆపరేషన్ panic అయినప్పుడు [`None`] ను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // సూచికలు UTF-8 సీక్వెన్స్ సరిహద్దుల్లో లేవు
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // హద్దులు దాటింది
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// `str` యొక్క మార్చగల సబ్‌లైస్‌ను అందిస్తుంది.
    ///
    /// `str` ను ఇండెక్స్ చేయడానికి ఇది భయాందోళన లేని ప్రత్యామ్నాయం.
    /// సమానమైన ఇండెక్సింగ్ ఆపరేషన్ panic అయినప్పుడు [`None`] ను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // సరైన పొడవు
    /// assert!(v.get_mut(0..5).is_some());
    /// // హద్దులు దాటింది
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// `str` యొక్క తనిఖీ చేయని సబ్‌లైస్‌ను అందిస్తుంది.
    ///
    /// `str` ను ఇండెక్స్ చేయడానికి ఇది తనిఖీ చేయని ప్రత్యామ్నాయం.
    ///
    /// # Safety
    ///
    /// ఈ ముందస్తు షరతులు సంతృప్తి చెందడానికి ఈ ఫంక్షన్ యొక్క కాలర్లు బాధ్యత వహిస్తాయి:
    ///
    /// * ప్రారంభ సూచిక ముగింపు సూచికను మించకూడదు;
    /// * సూచికలు అసలు స్లైస్ యొక్క సరిహద్దులలో ఉండాలి;
    /// * సూచికలు తప్పనిసరిగా UTF-8 సీక్వెన్స్ సరిహద్దుల్లో ఉండాలి.
    ///
    /// విఫలమైతే, తిరిగి వచ్చిన స్ట్రింగ్ స్లైస్ చెల్లని మెమరీని సూచిస్తుంది లేదా `str` రకం ద్వారా కమ్యూనికేట్ చేయబడిన మార్పులను ఉల్లంఘించవచ్చు.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // భద్రత: కాలర్ `get_unchecked` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి;
        // స్లైస్ డీరెఫరెన్సబుల్ ఎందుకంటే `self` సురక్షితమైన సూచన.
        // తిరిగి వచ్చిన పాయింటర్ సురక్షితం ఎందుకంటే `SliceIndex` యొక్క ఇంప్ల్స్ అది అని హామీ ఇవ్వాలి.
        unsafe { &*i.get_unchecked(self) }
    }

    /// `str` యొక్క మార్చగల, తనిఖీ చేయని సబ్‌లైస్‌ను అందిస్తుంది.
    ///
    /// `str` ను ఇండెక్స్ చేయడానికి ఇది తనిఖీ చేయని ప్రత్యామ్నాయం.
    ///
    /// # Safety
    ///
    /// ఈ ముందస్తు షరతులు సంతృప్తి చెందడానికి ఈ ఫంక్షన్ యొక్క కాలర్లు బాధ్యత వహిస్తాయి:
    ///
    /// * ప్రారంభ సూచిక ముగింపు సూచికను మించకూడదు;
    /// * సూచికలు అసలు స్లైస్ యొక్క సరిహద్దులలో ఉండాలి;
    /// * సూచికలు తప్పనిసరిగా UTF-8 సీక్వెన్స్ సరిహద్దుల్లో ఉండాలి.
    ///
    /// విఫలమైతే, తిరిగి వచ్చిన స్ట్రింగ్ స్లైస్ చెల్లని మెమరీని సూచిస్తుంది లేదా `str` రకం ద్వారా కమ్యూనికేట్ చేయబడిన మార్పులను ఉల్లంఘించవచ్చు.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // భద్రత: కాలర్ `get_unchecked_mut` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి;
        // స్లైస్ డీరెఫరెన్సబుల్ ఎందుకంటే `self` సురక్షితమైన సూచన.
        // తిరిగి వచ్చిన పాయింటర్ సురక్షితం ఎందుకంటే `SliceIndex` యొక్క ఇంప్ల్స్ అది అని హామీ ఇవ్వాలి.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// భద్రతా తనిఖీలను దాటవేస్తూ, మరొక స్ట్రింగ్ స్లైస్ నుండి స్ట్రింగ్ స్లైస్‌ని సృష్టిస్తుంది.
    ///
    /// ఇది సాధారణంగా సిఫారసు చేయబడలేదు, జాగ్రత్తగా వాడండి!సురక్షితమైన ప్రత్యామ్నాయం కోసం [`str`] మరియు [`Index`] చూడండి.
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// ఈ క్రొత్త స్లైస్ `begin` నుండి `end` వరకు వెళుతుంది, వీటిలో `begin` తో సహా `end` మినహాయించబడుతుంది.
    ///
    /// బదులుగా మ్యూటబుల్ స్ట్రింగ్ స్లైస్ పొందడానికి, [`slice_mut_unchecked`] పద్ధతిని చూడండి.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// ఈ ఫంక్షన్ యొక్క కాలర్లు మూడు ముందస్తు షరతులు సంతృప్తి చెందడానికి బాధ్యత వహిస్తాయి:
    ///
    /// * `begin` `end` మించకూడదు.
    /// * `begin` మరియు `end` స్ట్రింగ్ స్లైస్‌లో బైట్ స్థానాలు ఉండాలి.
    /// * `begin` మరియు `end` తప్పనిసరిగా UTF-8 సీక్వెన్స్ సరిహద్దుల్లో ఉండాలి.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // భద్రత: కాలర్ `get_unchecked` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి;
        // స్లైస్ డీరెఫరెన్సబుల్ ఎందుకంటే `self` సురక్షితమైన సూచన.
        // తిరిగి వచ్చిన పాయింటర్ సురక్షితం ఎందుకంటే `SliceIndex` యొక్క ఇంప్ల్స్ అది అని హామీ ఇవ్వాలి.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// భద్రతా తనిఖీలను దాటవేస్తూ, మరొక స్ట్రింగ్ స్లైస్ నుండి స్ట్రింగ్ స్లైస్‌ని సృష్టిస్తుంది.
    /// ఇది సాధారణంగా సిఫారసు చేయబడలేదు, జాగ్రత్తగా వాడండి!సురక్షితమైన ప్రత్యామ్నాయం కోసం [`str`] మరియు [`IndexMut`] చూడండి.
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// ఈ క్రొత్త స్లైస్ `begin` నుండి `end` వరకు వెళుతుంది, వీటిలో `begin` తో సహా `end` మినహాయించబడుతుంది.
    ///
    /// బదులుగా మార్పులేని స్ట్రింగ్ స్లైస్ పొందడానికి, [`slice_unchecked`] పద్ధతిని చూడండి.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// ఈ ఫంక్షన్ యొక్క కాలర్లు మూడు ముందస్తు షరతులు సంతృప్తి చెందడానికి బాధ్యత వహిస్తాయి:
    ///
    /// * `begin` `end` మించకూడదు.
    /// * `begin` మరియు `end` స్ట్రింగ్ స్లైస్‌లో బైట్ స్థానాలు ఉండాలి.
    /// * `begin` మరియు `end` తప్పనిసరిగా UTF-8 సీక్వెన్స్ సరిహద్దుల్లో ఉండాలి.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // భద్రత: కాలర్ `get_unchecked_mut` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి;
        // స్లైస్ డీరెఫరెన్సబుల్ ఎందుకంటే `self` సురక్షితమైన సూచన.
        // తిరిగి వచ్చిన పాయింటర్ సురక్షితం ఎందుకంటే `SliceIndex` యొక్క ఇంప్ల్స్ అది అని హామీ ఇవ్వాలి.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// ఇండెక్స్ వద్ద ఒక స్ట్రింగ్ స్లైస్‌ని రెండుగా విభజించండి.
    ///
    /// `mid` అనే వాదన స్ట్రింగ్ ప్రారంభం నుండి బైట్ ఆఫ్‌సెట్ అయి ఉండాలి.
    /// ఇది UTF-8 కోడ్ పాయింట్ యొక్క సరిహద్దులో కూడా ఉండాలి.
    ///
    /// తిరిగి వచ్చిన రెండు ముక్కలు స్ట్రింగ్ స్లైస్ ప్రారంభం నుండి `mid` వరకు, మరియు `mid` నుండి స్ట్రింగ్ స్లైస్ చివరి వరకు వెళ్తాయి.
    ///
    /// బదులుగా మార్చగల స్ట్రింగ్ ముక్కలను పొందడానికి, [`split_at_mut`] పద్ధతిని చూడండి.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// `mid` UTF-8 కోడ్ పాయింట్ సరిహద్దులో లేకపోతే Panics, లేదా అది స్ట్రింగ్ స్లైస్ యొక్క చివరి కోడ్ పాయింట్ ముగింపులో ఉంటే.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary సూచిక [0, .len()]
        if self.is_char_boundary(mid) {
            // భద్రత: `mid` చార్ సరిహద్దులో ఉందని తనిఖీ చేసింది.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// ఇండెక్స్ వద్ద ఒక మార్చగల స్ట్రింగ్ స్లైస్‌ని రెండుగా విభజించండి.
    ///
    /// `mid` అనే వాదన స్ట్రింగ్ ప్రారంభం నుండి బైట్ ఆఫ్‌సెట్ అయి ఉండాలి.
    /// ఇది UTF-8 కోడ్ పాయింట్ యొక్క సరిహద్దులో కూడా ఉండాలి.
    ///
    /// తిరిగి వచ్చిన రెండు ముక్కలు స్ట్రింగ్ స్లైస్ ప్రారంభం నుండి `mid` వరకు, మరియు `mid` నుండి స్ట్రింగ్ స్లైస్ చివరి వరకు వెళ్తాయి.
    ///
    /// బదులుగా మార్పులేని స్ట్రింగ్ ముక్కలను పొందడానికి, [`split_at`] పద్ధతిని చూడండి.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// `mid` UTF-8 కోడ్ పాయింట్ సరిహద్దులో లేకపోతే Panics, లేదా అది స్ట్రింగ్ స్లైస్ యొక్క చివరి కోడ్ పాయింట్ ముగింపులో ఉంటే.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary సూచిక [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // భద్రత: `mid` చార్ సరిహద్దులో ఉందని తనిఖీ చేసింది.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// స్ట్రింగ్ స్లైస్ యొక్క [`చార్`] లపై ఇటరేటర్‌ను అందిస్తుంది.
    ///
    /// స్ట్రింగ్ స్లైస్ చెల్లుబాటు అయ్యే UTF-8 ను కలిగి ఉన్నందున, మేము [`char`] ద్వారా స్ట్రింగ్ స్లైస్ ద్వారా మళ్ళించవచ్చు.
    /// ఈ పద్ధతి అటువంటి ఇటరేటర్‌ను తిరిగి ఇస్తుంది.
    ///
    /// [`char`] యూనికోడ్ స్కేలార్ విలువను సూచిస్తుందని గుర్తుంచుకోవడం ముఖ్యం మరియు 'character' అంటే ఏమిటో మీ ఆలోచనతో సరిపోలకపోవచ్చు.
    ///
    /// గ్రాఫిమ్ క్లస్టర్లపై పునరావృతం మీరు నిజంగా కోరుకునేది కావచ్చు.
    /// ఈ కార్యాచరణను Rust యొక్క ప్రామాణిక లైబ్రరీ అందించలేదు, బదులుగా crates.io ని తనిఖీ చేయండి.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// గుర్తుంచుకోండి, [`చార్`] అక్షరాల గురించి మీ అంతర్ దృష్టితో సరిపోలకపోవచ్చు:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // 'y̆' కాదు
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// స్ట్రింగ్ స్లైస్ యొక్క [`చార్`] లు మరియు వాటి స్థానాలపై ఇటరేటర్‌ను అందిస్తుంది.
    ///
    /// స్ట్రింగ్ స్లైస్ చెల్లుబాటు అయ్యే UTF-8 ను కలిగి ఉన్నందున, మేము [`char`] ద్వారా స్ట్రింగ్ స్లైస్ ద్వారా మళ్ళించవచ్చు.
    /// ఈ పద్ధతి ఈ [చార్ '] ల యొక్క ఇటరేటర్‌ను, అలాగే వాటి బైట్ స్థానాలను అందిస్తుంది.
    ///
    /// ఇరేటర్ టుపుల్స్ ఇస్తుంది.స్థానం మొదటిది, [`char`] రెండవది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// గుర్తుంచుకోండి, [`చార్`] అక్షరాల గురించి మీ అంతర్ దృష్టితో సరిపోలకపోవచ్చు:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // కాదు (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // ఇక్కడ 3 ను గమనించండి, చివరి పాత్ర రెండు బైట్లు తీసుకుంది
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// స్ట్రింగ్ స్లైస్ యొక్క బైట్లపై ఇటరేటర్.
    ///
    /// స్ట్రింగ్ స్లైస్ బైట్ల క్రమాన్ని కలిగి ఉన్నందున, మేము స్ట్రింగ్ స్లైస్ ద్వారా బైట్ ద్వారా మళ్ళించవచ్చు.
    /// ఈ పద్ధతి అటువంటి ఇటరేటర్‌ను తిరిగి ఇస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// వైట్‌స్పేస్ ద్వారా స్ట్రింగ్ స్లైస్‌ని విభజిస్తుంది.
    ///
    /// తిరిగి వచ్చిన ఇరేటర్ అసలు స్ట్రింగ్ స్లైస్ యొక్క ఉప ముక్కలుగా ఉన్న స్ట్రింగ్ స్లైస్‌లను తిరిగి ఇస్తుంది, ఇది వైట్‌స్పేస్ మొత్తంతో వేరు చేయబడుతుంది.
    ///
    ///
    /// 'Whitespace' యూనికోడ్ డెరైవ్డ్ కోర్ ప్రాపర్టీ `White_Space` నిబంధనల ప్రకారం నిర్వచించబడింది.
    /// మీరు బదులుగా ASCII వైట్‌స్పేస్‌లో మాత్రమే విభజించాలనుకుంటే, [`split_ascii_whitespace`] ని ఉపయోగించండి.
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// అన్ని రకాల వైట్‌స్పేస్ పరిగణించబడుతుంది:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// ASCII వైట్‌స్పేస్ ద్వారా స్ట్రింగ్ స్లైస్‌ని విభజిస్తుంది.
    ///
    /// తిరిగి వచ్చిన ఇరేటర్ అసలు స్ట్రింగ్ స్లైస్ యొక్క ఉప-ముక్కలుగా ఉన్న స్ట్రింగ్ ముక్కలను తిరిగి ఇస్తుంది, ఇది ASCII వైట్‌స్పేస్ ద్వారా వేరు చేయబడుతుంది.
    ///
    ///
    /// బదులుగా యూనికోడ్ `Whitespace` ద్వారా విభజించడానికి, [`split_whitespace`] ఉపయోగించండి.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// అన్ని రకాల ASCII వైట్‌స్పేస్ పరిగణించబడుతుంది:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// స్ట్రింగ్ యొక్క పంక్తులపై స్ట్రింగ్ ముక్కలుగా ఒక ఇరేటర్.
    ///
    /// లైన్‌లు న్యూలైన్ (`\n`) లేదా లైన్ ఫీడ్ (`\r\n`) తో క్యారేజ్ రిటర్న్‌తో ముగుస్తాయి.
    ///
    /// చివరి పంక్తి ముగింపు ఐచ్ఛికం.
    /// తుది పంక్తి ముగింపుతో ముగిసే స్ట్రింగ్ తుది పంక్తి ముగింపు లేకుండా అదే పంక్తులను లేకపోతే ఒకేలాంటి స్ట్రింగ్ వలె అందిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// చివరి పంక్తి ముగింపు అవసరం లేదు:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// స్ట్రింగ్ యొక్క పంక్తులపై ఒక మళ్ళి.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// UTF-16 గా ఎన్కోడ్ చేయబడిన స్ట్రింగ్ పై `u16` యొక్క ఇరేటర్ను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// ఇచ్చిన నమూనా ఈ స్ట్రింగ్ స్లైస్ యొక్క ఉప-స్లైస్‌తో సరిపోలితే `true` ని అందిస్తుంది.
    ///
    /// `false` లేకపోతే తిరిగి ఇస్తుంది.
    ///
    /// [pattern] అనేది `&str`, [`char`], [`చార్`] యొక్క స్లైస్ లేదా ఒక పాత్ర సరిపోతుందో లేదో నిర్ణయించే ఫంక్షన్ లేదా మూసివేత కావచ్చు.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// ఇచ్చిన నమూనా ఈ స్ట్రింగ్ స్లైస్ యొక్క ఉపసర్గతో సరిపోలితే `true` ని అందిస్తుంది.
    ///
    /// `false` లేకపోతే తిరిగి ఇస్తుంది.
    ///
    /// [pattern] అనేది `&str`, [`char`], [`చార్`] యొక్క స్లైస్ లేదా ఒక పాత్ర సరిపోతుందో లేదో నిర్ణయించే ఫంక్షన్ లేదా మూసివేత కావచ్చు.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// ఇచ్చిన నమూనా ఈ స్ట్రింగ్ స్లైస్ యొక్క ప్రత్యయంతో సరిపోలితే `true` ని అందిస్తుంది.
    ///
    /// `false` లేకపోతే తిరిగి ఇస్తుంది.
    ///
    /// [pattern] అనేది `&str`, [`char`], [`చార్`] యొక్క స్లైస్ లేదా ఒక పాత్ర సరిపోతుందో లేదో నిర్ణయించే ఫంక్షన్ లేదా మూసివేత కావచ్చు.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// నమూనాతో సరిపోయే ఈ స్ట్రింగ్ స్లైస్ యొక్క మొదటి అక్షరం యొక్క బైట్ సూచికను అందిస్తుంది.
    ///
    /// నమూనా సరిపోలకపోతే [`None`] ని అందిస్తుంది.
    ///
    /// [pattern] అనేది `&str`, [`char`], [`చార్`] యొక్క స్లైస్ లేదా ఒక పాత్ర సరిపోతుందో లేదో నిర్ణయించే ఫంక్షన్ లేదా మూసివేత కావచ్చు.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// సాధారణ నమూనాలు:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// పాయింట్-రహిత శైలి మరియు మూసివేతలను ఉపయోగించి మరింత క్లిష్టమైన నమూనాలు:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// నమూనాను కనుగొనడం లేదు:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// ఈ స్ట్రింగ్ స్లైస్‌లోని నమూనా యొక్క కుడివైపు మ్యాచ్ యొక్క మొదటి అక్షరం కోసం బైట్ సూచికను అందిస్తుంది.
    ///
    /// నమూనా సరిపోలకపోతే [`None`] ని అందిస్తుంది.
    ///
    /// [pattern] అనేది `&str`, [`char`], [`చార్`] యొక్క స్లైస్ లేదా ఒక పాత్ర సరిపోతుందో లేదో నిర్ణయించే ఫంక్షన్ లేదా మూసివేత కావచ్చు.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// సాధారణ నమూనాలు:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// మూసివేతలతో మరింత క్లిష్టమైన నమూనాలు:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// నమూనాను కనుగొనడం లేదు:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// ఈ స్ట్రింగ్ స్లైస్ యొక్క సబ్‌స్ట్రింగ్‌లపై ఒక ఇరేటర్, ఒక నమూనాతో సరిపోలిన అక్షరాలతో వేరు చేయబడింది.
    ///
    /// [pattern] అనేది `&str`, [`char`], [`చార్`] యొక్క స్లైస్ లేదా ఒక పాత్ర సరిపోతుందో లేదో నిర్ణయించే ఫంక్షన్ లేదా మూసివేత కావచ్చు.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ఇటరేటర్ ప్రవర్తన
    ///
    /// నమూనా రివర్స్ శోధనను అనుమతించినట్లయితే తిరిగి వచ్చిన ఇరేటర్ [`DoubleEndedIterator`] అవుతుంది మరియు forward/reverse శోధన అదే అంశాలను ఇస్తుంది.
    /// ఇది నిజం, ఉదా., [`char`], కానీ `&str` కోసం కాదు.
    ///
    /// నమూనా రివర్స్ శోధనను అనుమతించినా, దాని ఫలితాలు ఫార్వర్డ్ సెర్చ్‌కు భిన్నంగా ఉండవచ్చు, [`rsplit`] పద్ధతిని ఉపయోగించవచ్చు.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// సాధారణ నమూనాలు:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// నమూనా అక్షరాల ముక్క అయితే, ఏదైనా అక్షరాల యొక్క ప్రతి సంఘటనపై విభజించండి:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// మూసివేతను ఉపయోగించి మరింత క్లిష్టమైన నమూనా:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// ఒక స్ట్రింగ్ బహుళ వరుస సెపరేటర్లను కలిగి ఉంటే, మీరు అవుట్పుట్లో ఖాళీ తీగలతో ముగుస్తుంది:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// వరుస సెపరేటర్లు ఖాళీ స్ట్రింగ్ ద్వారా వేరు చేయబడతాయి.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// స్ట్రింగ్ ప్రారంభంలో లేదా చివరిలో ఉన్న సెపరేటర్లు ఖాళీ తీగలతో పొరుగున ఉంటాయి.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// ఖాళీ స్ట్రింగ్‌ను సెపరేటర్‌గా ఉపయోగించినప్పుడు, ఇది స్ట్రింగ్‌లోని ప్రతి అక్షరాన్ని, స్ట్రింగ్ యొక్క ప్రారంభ మరియు ముగింపుతో పాటు వేరు చేస్తుంది.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// వైట్‌స్పేస్‌ను సెపరేటర్‌గా ఉపయోగించినప్పుడు వరుస సెపరేటర్లు బహుశా ఆశ్చర్యకరమైన ప్రవర్తనకు దారితీస్తాయి.ఈ కోడ్ సరైనది:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// ఇది _not_ మీకు ఇస్తుంది:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// ఈ ప్రవర్తన కోసం [`split_whitespace`] ఉపయోగించండి.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// ఈ స్ట్రింగ్ స్లైస్ యొక్క సబ్‌స్ట్రింగ్‌లపై ఒక ఇరేటర్, ఒక నమూనాతో సరిపోలిన అక్షరాలతో వేరు చేయబడింది.
    /// ఆ `split_inclusive` లో `split` చేత ఉత్పత్తి చేయబడిన ఇరేటర్ నుండి భిన్నంగా సరిపోలిన భాగాన్ని సబ్‌స్ట్రింగ్ యొక్క టెర్మినేటర్‌గా వదిలివేస్తుంది.
    ///
    ///
    /// [pattern] అనేది `&str`, [`char`], [`చార్`] యొక్క స్లైస్ లేదా ఒక పాత్ర సరిపోతుందో లేదో నిర్ణయించే ఫంక్షన్ లేదా మూసివేత కావచ్చు.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// స్ట్రింగ్ యొక్క చివరి మూలకం సరిపోలితే, ఆ మూలకం మునుపటి సబ్‌స్ట్రింగ్ యొక్క టెర్మినేటర్‌గా పరిగణించబడుతుంది.
    /// ఆ సబ్‌స్ట్రింగ్ ఇరేటర్ తిరిగి ఇచ్చిన చివరి అంశం అవుతుంది.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// ఇచ్చిన స్ట్రింగ్ స్లైస్ యొక్క సబ్‌స్ట్రింగ్‌లపై ఒక ఇరేటర్, ఒక నమూనాతో సరిపోలిన అక్షరాలతో వేరు చేయబడి రివర్స్ ఆర్డర్‌లో లభిస్తుంది.
    ///
    /// [pattern] అనేది `&str`, [`char`], [`చార్`] యొక్క స్లైస్ లేదా ఒక పాత్ర సరిపోతుందో లేదో నిర్ణయించే ఫంక్షన్ లేదా మూసివేత కావచ్చు.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ఇటరేటర్ ప్రవర్తన
    ///
    /// తిరిగి వచ్చిన ఇరేటర్‌కు నమూనా రివర్స్ శోధనకు మద్దతు ఇవ్వాలి మరియు forward/reverse శోధన అదే మూలకాలను ఇస్తే అది [`DoubleEndedIterator`] అవుతుంది.
    ///
    ///
    /// ముందు నుండి మళ్ళించడం కోసం, [`split`] పద్ధతిని ఉపయోగించవచ్చు.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// సాధారణ నమూనాలు:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// మూసివేతను ఉపయోగించి మరింత క్లిష్టమైన నమూనా:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// ఇచ్చిన స్ట్రింగ్ స్లైస్ యొక్క సబ్‌స్ట్రింగ్‌లపై ఇటరేటర్, నమూనాతో సరిపోలిన అక్షరాలతో వేరుచేయబడుతుంది.
    ///
    /// [pattern] అనేది `&str`, [`char`], [`చార్`] యొక్క స్లైస్ లేదా ఒక పాత్ర సరిపోతుందో లేదో నిర్ణయించే ఫంక్షన్ లేదా మూసివేత కావచ్చు.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] కి సమానం, ఖాళీగా ఉంటే వెనుకంజలో ఉన్న సబ్‌స్ట్రింగ్ దాటవేయబడుతుంది.
    ///
    /// [`split`]: str::split
    ///
    /// ఈ పద్ధతి ఒక నమూనా ద్వారా _separated_ కాకుండా _terminated_ అయిన స్ట్రింగ్ డేటా కోసం ఉపయోగించవచ్చు.
    ///
    /// # ఇటరేటర్ ప్రవర్తన
    ///
    /// నమూనా రివర్స్ శోధనను అనుమతించినట్లయితే తిరిగి వచ్చిన ఇరేటర్ [`DoubleEndedIterator`] అవుతుంది మరియు forward/reverse శోధన అదే అంశాలను ఇస్తుంది.
    /// ఇది నిజం, ఉదా., [`char`], కానీ `&str` కోసం కాదు.
    ///
    /// నమూనా రివర్స్ శోధనను అనుమతించినా, దాని ఫలితాలు ఫార్వర్డ్ సెర్చ్‌కు భిన్నంగా ఉండవచ్చు, [`rsplit_terminator`] పద్ధతిని ఉపయోగించవచ్చు.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// `self` యొక్క సబ్‌స్ట్రింగ్‌లపై ఒక ఇరేటర్, ఒక నమూనాతో సరిపోలిన అక్షరాలతో వేరు చేయబడి రివర్స్ క్రమంలో లభిస్తుంది.
    ///
    /// [pattern] అనేది `&str`, [`char`], [`చార్`] యొక్క స్లైస్ లేదా ఒక పాత్ర సరిపోతుందో లేదో నిర్ణయించే ఫంక్షన్ లేదా మూసివేత కావచ్చు.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] కి సమానం, ఖాళీగా ఉంటే వెనుకంజలో ఉన్న సబ్‌స్ట్రింగ్ దాటవేయబడుతుంది.
    ///
    /// [`split`]: str::split
    ///
    /// ఈ పద్ధతి ఒక నమూనా ద్వారా _separated_ కాకుండా _terminated_ అయిన స్ట్రింగ్ డేటా కోసం ఉపయోగించవచ్చు.
    ///
    /// # ఇటరేటర్ ప్రవర్తన
    ///
    /// తిరిగి వచ్చిన ఇరేటర్‌కు నమూనా రివర్స్ శోధనకు మద్దతు ఇవ్వాలి మరియు forward/reverse శోధన అదే మూలకాలను ఇస్తే అది డబుల్ ఎండ్ అవుతుంది.
    ///
    ///
    /// ముందు నుండి మళ్ళించడం కోసం, [`split_terminator`] పద్ధతిని ఉపయోగించవచ్చు.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// ఇచ్చిన స్ట్రింగ్ స్లైస్ యొక్క సబ్‌స్ట్రింగ్‌లపై ఒక ఇరేటర్, ఒక నమూనాతో వేరు చేయబడి, చాలా `n` ఐటెమ్‌ల వద్ద తిరిగి రావడానికి పరిమితం చేయబడింది.
    ///
    /// `n` సబ్‌స్ట్రింగ్‌లు తిరిగి ఇవ్వబడితే, చివరి సబ్‌స్ట్రింగ్ (`n` వ సబ్‌స్ట్రింగ్) స్ట్రింగ్ యొక్క మిగిలిన భాగాన్ని కలిగి ఉంటుంది.
    ///
    /// [pattern] అనేది `&str`, [`char`], [`చార్`] యొక్క స్లైస్ లేదా ఒక పాత్ర సరిపోతుందో లేదో నిర్ణయించే ఫంక్షన్ లేదా మూసివేత కావచ్చు.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ఇటరేటర్ ప్రవర్తన
    ///
    /// తిరిగి వచ్చిన ఇరేటర్ డబుల్ ఎండ్ కాదు, ఎందుకంటే ఇది మద్దతు ఇవ్వడానికి సమర్థవంతంగా లేదు.
    ///
    /// నమూనా రివర్స్ శోధనను అనుమతించినట్లయితే, [`rsplitn`] పద్ధతిని ఉపయోగించవచ్చు.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// సాధారణ నమూనాలు:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// మూసివేతను ఉపయోగించి మరింత క్లిష్టమైన నమూనా:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// ఈ స్ట్రింగ్ స్లైస్ యొక్క సబ్‌స్ట్రింగ్స్‌పై ఒక ఇరేటర్, ఒక నమూనాతో వేరు చేయబడి, స్ట్రింగ్ చివరి నుండి మొదలుకొని, చాలా `n` ఐటెమ్‌ల వద్ద తిరిగి రావడానికి పరిమితం చేయబడింది.
    ///
    ///
    /// `n` సబ్‌స్ట్రింగ్‌లు తిరిగి ఇవ్వబడితే, చివరి సబ్‌స్ట్రింగ్ (`n` వ సబ్‌స్ట్రింగ్) స్ట్రింగ్ యొక్క మిగిలిన భాగాన్ని కలిగి ఉంటుంది.
    ///
    /// [pattern] అనేది `&str`, [`char`], [`చార్`] యొక్క స్లైస్ లేదా ఒక పాత్ర సరిపోతుందో లేదో నిర్ణయించే ఫంక్షన్ లేదా మూసివేత కావచ్చు.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ఇటరేటర్ ప్రవర్తన
    ///
    /// తిరిగి వచ్చిన ఇరేటర్ డబుల్ ఎండ్ కాదు, ఎందుకంటే ఇది మద్దతు ఇవ్వడానికి సమర్థవంతంగా లేదు.
    ///
    /// ముందు నుండి విడిపోవడానికి, [`splitn`] పద్ధతిని ఉపయోగించవచ్చు.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// సాధారణ నమూనాలు:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// మూసివేతను ఉపయోగించి మరింత క్లిష్టమైన నమూనా:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// పేర్కొన్న డీలిమిటర్ యొక్క మొదటి సంఘటనపై స్ట్రింగ్‌ను విభజిస్తుంది మరియు డీలిమిటర్‌కు ముందు ఉపసర్గను మరియు డీలిమిటర్ తర్వాత ప్రత్యయాన్ని అందిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// పేర్కొన్న డీలిమిటర్ యొక్క చివరి సంఘటనపై స్ట్రింగ్‌ను విభజిస్తుంది మరియు డీలిమిటర్‌కు ముందు ఉపసర్గను మరియు డీలిమిటర్ తర్వాత ప్రత్యయాన్ని అందిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// ఇచ్చిన స్ట్రింగ్ స్లైస్‌లోని నమూనా యొక్క డిజాయింట్ మ్యాచ్‌లపై ఇటరేటర్.
    ///
    /// [pattern] అనేది `&str`, [`char`], [`చార్`] యొక్క స్లైస్ లేదా ఒక పాత్ర సరిపోతుందో లేదో నిర్ణయించే ఫంక్షన్ లేదా మూసివేత కావచ్చు.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ఇటరేటర్ ప్రవర్తన
    ///
    /// నమూనా రివర్స్ శోధనను అనుమతించినట్లయితే తిరిగి వచ్చిన ఇరేటర్ [`DoubleEndedIterator`] అవుతుంది మరియు forward/reverse శోధన అదే అంశాలను ఇస్తుంది.
    /// ఇది నిజం, ఉదా., [`char`], కానీ `&str` కోసం కాదు.
    ///
    /// నమూనా రివర్స్ శోధనను అనుమతించినా, దాని ఫలితాలు ఫార్వర్డ్ సెర్చ్‌కు భిన్నంగా ఉండవచ్చు, [`rmatches`] పద్ధతిని ఉపయోగించవచ్చు.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// ఈ స్ట్రింగ్ స్లైస్‌లోని ఒక నమూనా యొక్క డిజాయింట్ మ్యాచ్‌లపై ఇటరేటర్, రివర్స్ ఆర్డర్‌లో లభిస్తుంది.
    ///
    /// [pattern] అనేది `&str`, [`char`], [`చార్`] యొక్క స్లైస్ లేదా ఒక పాత్ర సరిపోతుందో లేదో నిర్ణయించే ఫంక్షన్ లేదా మూసివేత కావచ్చు.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ఇటరేటర్ ప్రవర్తన
    ///
    /// తిరిగి వచ్చిన ఇరేటర్‌కు నమూనా రివర్స్ శోధనకు మద్దతు ఇవ్వాలి మరియు forward/reverse శోధన అదే మూలకాలను ఇస్తే అది [`DoubleEndedIterator`] అవుతుంది.
    ///
    ///
    /// ముందు నుండి మళ్ళించడం కోసం, [`matches`] పద్ధతిని ఉపయోగించవచ్చు.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// ఈ స్ట్రింగ్ స్లైస్‌లోని ఒక నమూనా యొక్క వైరుధ్య మ్యాచ్‌లతో పాటు మ్యాచ్ ప్రారంభమయ్యే సూచికపై ఒక ఇరేటర్.
    ///
    /// అతివ్యాప్తి చెందుతున్న `self` లోని `pat` మ్యాచ్‌ల కోసం, మొదటి మ్యాచ్‌కు సంబంధించిన సూచికలు మాత్రమే తిరిగి ఇవ్వబడతాయి.
    ///
    /// [pattern] అనేది `&str`, [`char`], [`చార్`] యొక్క స్లైస్ లేదా ఒక పాత్ర సరిపోతుందో లేదో నిర్ణయించే ఫంక్షన్ లేదా మూసివేత కావచ్చు.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ఇటరేటర్ ప్రవర్తన
    ///
    /// నమూనా రివర్స్ శోధనను అనుమతించినట్లయితే తిరిగి వచ్చిన ఇరేటర్ [`DoubleEndedIterator`] అవుతుంది మరియు forward/reverse శోధన అదే అంశాలను ఇస్తుంది.
    /// ఇది నిజం, ఉదా., [`char`], కానీ `&str` కోసం కాదు.
    ///
    /// నమూనా రివర్స్ శోధనను అనుమతించినా, దాని ఫలితాలు ఫార్వర్డ్ సెర్చ్‌కు భిన్నంగా ఉండవచ్చు, [`rmatch_indices`] పద్ధతిని ఉపయోగించవచ్చు.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // మొదటి `aba` మాత్రమే
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// `self` లోని ఒక నమూనా యొక్క డిజాయింట్ మ్యాచ్‌లపై ఒక ఇరేటర్, మ్యాచ్ యొక్క సూచికతో పాటు రివర్స్ ఆర్డర్‌లో లభిస్తుంది.
    ///
    /// అతివ్యాప్తి చెందుతున్న `self` లోని `pat` మ్యాచ్‌ల కోసం, చివరి మ్యాచ్‌కు సంబంధించిన సూచికలు మాత్రమే తిరిగి ఇవ్వబడతాయి.
    ///
    /// [pattern] అనేది `&str`, [`char`], [`చార్`] యొక్క స్లైస్ లేదా ఒక పాత్ర సరిపోతుందో లేదో నిర్ణయించే ఫంక్షన్ లేదా మూసివేత కావచ్చు.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ఇటరేటర్ ప్రవర్తన
    ///
    /// తిరిగి వచ్చిన ఇరేటర్‌కు నమూనా రివర్స్ శోధనకు మద్దతు ఇవ్వాలి మరియు forward/reverse శోధన అదే మూలకాలను ఇస్తే అది [`DoubleEndedIterator`] అవుతుంది.
    ///
    ///
    /// ముందు నుండి మళ్ళించడం కోసం, [`match_indices`] పద్ధతిని ఉపయోగించవచ్చు.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // చివరి `aba` మాత్రమే
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// ప్రముఖ మరియు వెనుకంజలో ఉన్న వైట్‌స్పేస్‌తో తీసివేయబడిన స్ట్రింగ్ స్లైస్‌ని అందిస్తుంది.
    ///
    /// 'Whitespace' యూనికోడ్ డెరైవ్డ్ కోర్ ప్రాపర్టీ `White_Space` నిబంధనల ప్రకారం నిర్వచించబడింది.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// ప్రముఖ వైట్‌స్పేస్‌తో తొలగించబడిన స్ట్రింగ్ స్లైస్‌ని అందిస్తుంది.
    ///
    /// 'Whitespace' యూనికోడ్ డెరైవ్డ్ కోర్ ప్రాపర్టీ `White_Space` నిబంధనల ప్రకారం నిర్వచించబడింది.
    ///
    /// # వచన దిశ
    ///
    /// స్ట్రింగ్ బైట్ల క్రమం.
    /// `start` ఈ సందర్భంలో ఆ బైట్ స్ట్రింగ్ యొక్క మొదటి స్థానం;ఇంగ్లీష్ లేదా రష్యన్ వంటి ఎడమ నుండి కుడికి భాష కోసం, ఇది ఎడమ వైపు ఉంటుంది మరియు అరబిక్ లేదా హిబ్రూ వంటి కుడి నుండి ఎడమకు భాషలకు, ఇది కుడి వైపు ఉంటుంది.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// వెనుకంజలో ఉన్న వైట్‌స్పేస్‌తో స్ట్రింగ్ స్లైస్‌ని అందిస్తుంది.
    ///
    /// 'Whitespace' యూనికోడ్ డెరైవ్డ్ కోర్ ప్రాపర్టీ `White_Space` నిబంధనల ప్రకారం నిర్వచించబడింది.
    ///
    /// # వచన దిశ
    ///
    /// స్ట్రింగ్ బైట్ల క్రమం.
    /// `end` ఈ సందర్భంలో ఆ బైట్ స్ట్రింగ్ యొక్క చివరి స్థానం;ఇంగ్లీష్ లేదా రష్యన్ వంటి ఎడమ నుండి కుడికి భాష కోసం, ఇది కుడి వైపు ఉంటుంది మరియు అరబిక్ లేదా హిబ్రూ వంటి కుడి నుండి ఎడమకు భాషలకు, ఇది ఎడమ వైపు ఉంటుంది.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// ప్రముఖ వైట్‌స్పేస్‌తో తొలగించబడిన స్ట్రింగ్ స్లైస్‌ని అందిస్తుంది.
    ///
    /// 'Whitespace' యూనికోడ్ డెరైవ్డ్ కోర్ ప్రాపర్టీ `White_Space` నిబంధనల ప్రకారం నిర్వచించబడింది.
    ///
    /// # వచన దిశ
    ///
    /// స్ట్రింగ్ బైట్ల క్రమం.
    /// 'Left' ఈ సందర్భంలో ఆ బైట్ స్ట్రింగ్ యొక్క మొదటి స్థానం;అరబిక్ లేదా హిబ్రూ వంటి భాషకు 'ఎడమ నుండి కుడికి' కాకుండా 'కుడి నుండి ఎడమకు', ఇది _right_ వైపు ఉంటుంది, ఎడమవైపు కాదు.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// వెనుకంజలో ఉన్న వైట్‌స్పేస్‌తో స్ట్రింగ్ స్లైస్‌ని అందిస్తుంది.
    ///
    /// 'Whitespace' యూనికోడ్ డెరైవ్డ్ కోర్ ప్రాపర్టీ `White_Space` నిబంధనల ప్రకారం నిర్వచించబడింది.
    ///
    /// # వచన దిశ
    ///
    /// స్ట్రింగ్ బైట్ల క్రమం.
    /// 'Right' ఈ సందర్భంలో ఆ బైట్ స్ట్రింగ్ యొక్క చివరి స్థానం;అరబిక్ లేదా హిబ్రూ వంటి భాషకు 'ఎడమ నుండి కుడికి' కాకుండా 'కుడి నుండి ఎడమకు', ఇది _left_ వైపు ఉంటుంది, కుడి కాదు.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// పదేపదే తీసివేయబడిన నమూనాతో సరిపోయే అన్ని ఉపసర్గలు మరియు ప్రత్యయాలతో స్ట్రింగ్ స్లైస్‌ని అందిస్తుంది.
    ///
    /// [pattern] అనేది [`char`], [`చార్`] యొక్క స్లైస్ లేదా ఒక అక్షరం సరిపోతుందో లేదో నిర్ణయించే ఫంక్షన్ లేదా మూసివేత కావచ్చు.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// సాధారణ నమూనాలు:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// మూసివేతను ఉపయోగించి మరింత క్లిష్టమైన నమూనా:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // మొట్టమొదటిగా తెలిసిన మ్యాచ్‌ను గుర్తుంచుకోండి, ఉంటే దాన్ని సరిచేయండి
            // చివరి మ్యాచ్ భిన్నంగా ఉంటుంది
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // భద్రత: `Searcher` చెల్లుబాటు అయ్యే సూచికలను తిరిగి ఇస్తుంది.
        unsafe { self.get_unchecked(i..j) }
    }

    /// పదేపదే తీసివేయబడిన నమూనాతో సరిపోయే అన్ని ఉపసర్గలతో స్ట్రింగ్ స్లైస్‌ని అందిస్తుంది.
    ///
    /// [pattern] అనేది `&str`, [`char`], [`చార్`] యొక్క స్లైస్ లేదా ఒక పాత్ర సరిపోతుందో లేదో నిర్ణయించే ఫంక్షన్ లేదా మూసివేత కావచ్చు.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # వచన దిశ
    ///
    /// స్ట్రింగ్ బైట్ల క్రమం.
    /// `start` ఈ సందర్భంలో ఆ బైట్ స్ట్రింగ్ యొక్క మొదటి స్థానం;ఇంగ్లీష్ లేదా రష్యన్ వంటి ఎడమ నుండి కుడికి భాష కోసం, ఇది ఎడమ వైపు ఉంటుంది మరియు అరబిక్ లేదా హిబ్రూ వంటి కుడి నుండి ఎడమకు భాషలకు, ఇది కుడి వైపు ఉంటుంది.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // భద్రత: `Searcher` చెల్లుబాటు అయ్యే సూచికలను తిరిగి ఇస్తుంది.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// తీసివేసిన ఉపసర్గతో స్ట్రింగ్ స్లైస్‌ని అందిస్తుంది.
    ///
    /// స్ట్రింగ్ `prefix` నమూనాతో మొదలైతే, ఉపసర్గ తర్వాత సబ్‌స్ట్రింగ్‌ను తిరిగి ఇస్తుంది, `Some` లో చుట్టబడి ఉంటుంది.
    /// `trim_start_matches` కాకుండా, ఈ పద్ధతి సరిగ్గా ఒకసారి ఉపసర్గను తొలగిస్తుంది.
    ///
    /// స్ట్రింగ్ `prefix` తో ప్రారంభించకపోతే, `None` ను అందిస్తుంది.
    ///
    /// [pattern] అనేది `&str`, [`char`], [`చార్`] యొక్క స్లైస్ లేదా ఒక పాత్ర సరిపోతుందో లేదో నిర్ణయించే ఫంక్షన్ లేదా మూసివేత కావచ్చు.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// తీసివేసిన ప్రత్యయంతో స్ట్రింగ్ స్లైస్‌ని అందిస్తుంది.
    ///
    /// `suffix` నమూనాతో స్ట్రింగ్ ముగుస్తుంటే, `Some` లో చుట్టబడిన ప్రత్యయానికి ముందు సబ్‌స్ట్రింగ్‌ను తిరిగి ఇస్తుంది.
    /// `trim_end_matches` కాకుండా, ఈ పద్ధతి సరిగ్గా ఒకసారి ప్రత్యయాన్ని తొలగిస్తుంది.
    ///
    /// స్ట్రింగ్ `suffix` తో ముగియకపోతే, `None` ను అందిస్తుంది.
    ///
    /// [pattern] అనేది `&str`, [`char`], [`చార్`] యొక్క స్లైస్ లేదా ఒక పాత్ర సరిపోతుందో లేదో నిర్ణయించే ఫంక్షన్ లేదా మూసివేత కావచ్చు.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// పదేపదే తీసివేయబడిన నమూనాతో సరిపోయే అన్ని ప్రత్యయాలతో స్ట్రింగ్ స్లైస్‌ని అందిస్తుంది.
    ///
    /// [pattern] అనేది `&str`, [`char`], [`చార్`] యొక్క స్లైస్ లేదా ఒక పాత్ర సరిపోతుందో లేదో నిర్ణయించే ఫంక్షన్ లేదా మూసివేత కావచ్చు.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # వచన దిశ
    ///
    /// స్ట్రింగ్ బైట్ల క్రమం.
    /// `end` ఈ సందర్భంలో ఆ బైట్ స్ట్రింగ్ యొక్క చివరి స్థానం;ఇంగ్లీష్ లేదా రష్యన్ వంటి ఎడమ నుండి కుడికి భాష కోసం, ఇది కుడి వైపు ఉంటుంది మరియు అరబిక్ లేదా హిబ్రూ వంటి కుడి నుండి ఎడమకు భాషలకు, ఇది ఎడమ వైపు ఉంటుంది.
    ///
    ///
    /// # Examples
    ///
    /// సాధారణ నమూనాలు:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// మూసివేతను ఉపయోగించి మరింత క్లిష్టమైన నమూనా:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // భద్రత: `Searcher` చెల్లుబాటు అయ్యే సూచికలను తిరిగి ఇస్తుంది.
        unsafe { self.get_unchecked(0..j) }
    }

    /// పదేపదే తీసివేయబడిన నమూనాతో సరిపోయే అన్ని ఉపసర్గలతో స్ట్రింగ్ స్లైస్‌ని అందిస్తుంది.
    ///
    /// [pattern] అనేది `&str`, [`char`], [`చార్`] యొక్క స్లైస్ లేదా ఒక పాత్ర సరిపోతుందో లేదో నిర్ణయించే ఫంక్షన్ లేదా మూసివేత కావచ్చు.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # వచన దిశ
    ///
    /// స్ట్రింగ్ బైట్ల క్రమం.
    /// 'Left' ఈ సందర్భంలో ఆ బైట్ స్ట్రింగ్ యొక్క మొదటి స్థానం;అరబిక్ లేదా హిబ్రూ వంటి భాషకు 'ఎడమ నుండి కుడికి' కాకుండా 'కుడి నుండి ఎడమకు', ఇది _right_ వైపు ఉంటుంది, ఎడమవైపు కాదు.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// పదేపదే తీసివేయబడిన నమూనాతో సరిపోయే అన్ని ప్రత్యయాలతో స్ట్రింగ్ స్లైస్‌ని అందిస్తుంది.
    ///
    /// [pattern] అనేది `&str`, [`char`], [`చార్`] యొక్క స్లైస్ లేదా ఒక పాత్ర సరిపోతుందో లేదో నిర్ణయించే ఫంక్షన్ లేదా మూసివేత కావచ్చు.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # వచన దిశ
    ///
    /// స్ట్రింగ్ బైట్ల క్రమం.
    /// 'Right' ఈ సందర్భంలో ఆ బైట్ స్ట్రింగ్ యొక్క చివరి స్థానం;అరబిక్ లేదా హిబ్రూ వంటి భాషకు 'ఎడమ నుండి కుడికి' కాకుండా 'కుడి నుండి ఎడమకు', ఇది _left_ వైపు ఉంటుంది, కుడి కాదు.
    ///
    ///
    /// # Examples
    ///
    /// సాధారణ నమూనాలు:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// మూసివేతను ఉపయోగించి మరింత క్లిష్టమైన నమూనా:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// ఈ స్ట్రింగ్ స్లైస్‌ని మరొక రకంగా అన్వయించడం.
    ///
    /// `parse` చాలా సాధారణమైనందున, ఇది రకం అనుమితితో సమస్యలను కలిగిస్తుంది.
    /// అందుకని, 'turbofish' అని పిలువబడే సింటాక్స్ ను మీరు ప్రేమగా చూసే కొన్ని సార్లు `parse` ఒకటి: `::<>`.
    ///
    /// ఇది మీరు ఏ రకాన్ని అన్వయించడానికి ప్రయత్నిస్తున్నారో ప్రత్యేకంగా అర్థం చేసుకోవడానికి అనుమితి అల్గోరిథం సహాయపడుతుంది.
    ///
    /// `parse` [`FromStr`] trait ను అమలు చేసే ఏ రకానికి అయినా అన్వయించవచ్చు.
    ///

    /// # Errors
    ///
    /// ఈ స్ట్రింగ్ స్లైస్‌ను కావలసిన రకానికి అన్వయించడం సాధ్యం కాకపోతే [`Err`] ను తిరిగి ఇస్తుంది.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// `four` ను ఉల్లేఖించడానికి బదులుగా 'turbofish' ను ఉపయోగించడం:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// అన్వయించడంలో విఫలమైంది:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// ఈ స్ట్రింగ్‌లోని అన్ని అక్షరాలు ASCII పరిధిలో ఉన్నాయో లేదో తనిఖీ చేస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // మేము ప్రతి బైట్‌ను ఇక్కడ అక్షరంగా పరిగణించవచ్చు: అన్ని మల్టీబైట్ అక్షరాలు అస్సి పరిధిలో లేని బైట్‌తో ప్రారంభమవుతాయి, కాబట్టి మేము ఇప్పటికే అక్కడే ఆగిపోతాము.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// రెండు తీగలను ASCII కేస్-ఇన్సెన్సిటివ్ మ్యాచ్ అని తనిఖీ చేస్తుంది.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` వలె ఉంటుంది, కానీ తాత్కాలికాలను కేటాయించకుండా మరియు కాపీ చేయకుండా.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// ఈ స్ట్రింగ్‌ను దాని ASCII అప్పర్ కేస్ సమానమైన స్థలానికి మారుస్తుంది.
    ///
    /// ASCII అక్షరాలు 'a' నుండి 'z' వరకు 'A' నుండి 'Z' వరకు మ్యాప్ చేయబడతాయి, కాని ASCII కాని అక్షరాలు మారవు.
    ///
    /// ఇప్పటికే ఉన్నదాన్ని సవరించకుండా క్రొత్త పెద్ద విలువను తిరిగి ఇవ్వడానికి, [`to_ascii_uppercase()`] ని ఉపయోగించండి.
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // భద్రత: సురక్షితం ఎందుకంటే మేము ఒకే రకంతో రెండు రకాలను మారుస్తాము.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// ఈ స్ట్రింగ్‌ను దాని ASCII లోయర్ కేస్ సమానమైన స్థలానికి మారుస్తుంది.
    ///
    /// ASCII అక్షరాలు 'A' నుండి 'Z' వరకు 'a' నుండి 'z' వరకు మ్యాప్ చేయబడతాయి, కాని ASCII కాని అక్షరాలు మారవు.
    ///
    /// ఇప్పటికే ఉన్నదాన్ని సవరించకుండా క్రొత్త చిన్న విలువను తిరిగి ఇవ్వడానికి, [`to_ascii_lowercase()`] ని ఉపయోగించండి.
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // భద్రత: సురక్షితం ఎందుకంటే మేము ఒకే రకంతో రెండు రకాలను మారుస్తాము.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// `self` లోని ప్రతి చార్ నుండి [`char::escape_debug`] తో తప్పించుకునే ఇరేటర్‌ను తిరిగి ఇవ్వండి.
    ///
    ///
    /// Note: స్ట్రింగ్ ప్రారంభమయ్యే విస్తరించిన గ్రాఫిమ్ కోడ్‌పాయింట్లు మాత్రమే తప్పించుకోబడతాయి.
    ///
    /// # Examples
    ///
    /// మళ్ళిగా:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// నేరుగా `println!` ను ఉపయోగించడం:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// రెండూ దీనికి సమానం:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// `to_string` ఉపయోగించి:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// `self` లోని ప్రతి చార్ నుండి [`char::escape_default`] తో తప్పించుకునే ఇరేటర్‌ను తిరిగి ఇవ్వండి.
    ///
    ///
    /// # Examples
    ///
    /// మళ్ళిగా:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// నేరుగా `println!` ను ఉపయోగించడం:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// రెండూ దీనికి సమానం:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// `to_string` ఉపయోగించి:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// `self` లోని ప్రతి చార్ నుండి [`char::escape_unicode`] తో తప్పించుకునే ఇరేటర్‌ను తిరిగి ఇవ్వండి.
    ///
    ///
    /// # Examples
    ///
    /// మళ్ళిగా:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// నేరుగా `println!` ను ఉపయోగించడం:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// రెండూ దీనికి సమానం:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// `to_string` ఉపయోగించి:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// ఖాళీ str ను సృష్టిస్తుంది
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// ఖాళీ మ్యూటబుల్ str ను సృష్టిస్తుంది
    #[inline]
    fn default() -> Self {
        // భద్రత: ఖాళీ స్ట్రింగ్ చెల్లుబాటు అయ్యే UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// పేరు పెట్టగల, క్లోనబుల్ fn రకం
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // భద్రత: సురక్షితం కాదు
        unsafe { from_utf8_unchecked(bytes) }
    };
}