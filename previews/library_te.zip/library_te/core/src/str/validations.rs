//! UTF-8 ధ్రువీకరణకు సంబంధించిన ఆపరేషన్లు.

use crate::mem;

use super::Utf8Error;

/// మొదటి బైట్ కోసం ప్రారంభ కోడ్‌పాయింట్ అక్యుమ్యులేటర్‌ను అందిస్తుంది.
/// మొదటి బైట్ ప్రత్యేకమైనది, వెడల్పు 2 కి దిగువ 5 బిట్స్, వెడల్పు 3 కి 4 బిట్స్ మరియు వెడల్పు 4 కి 3 బిట్స్ మాత్రమే కావాలి.
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// కొనసాగింపు బైట్ `byte` తో నవీకరించబడిన `ch` విలువను చూపుతుంది.
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// బైట్ UTF-8 కొనసాగింపు బైట్ కాదా అని తనిఖీ చేస్తుంది (అనగా, బిట్స్ `10` తో మొదలవుతుంది).
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// బైట్ ఇరేటర్ (యుటిఎఫ్-8 లాంటి ఎన్‌కోడింగ్ uming హిస్తూ) నుండి తదుపరి కోడ్ పాయింట్‌ను చదువుతుంది.
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // UTF-8 డీకోడ్
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // మల్టీబైట్ కేసు బైట్ కలయిక నుండి డీకోడ్‌ను అనుసరిస్తుంది: [[[x y] z] w]
    //
    // NOTE: పనితీరు ఇక్కడ ఖచ్చితమైన సూత్రీకరణకు సున్నితంగా ఉంటుంది
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] w] కేసు
        // 0xE0 లో 5 వ బిట్ .. 0xEF ఎల్లప్పుడూ స్పష్టంగా ఉంటుంది, కాబట్టి `init` ఇప్పటికీ చెల్లుతుంది
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] కేసు `init` యొక్క తక్కువ 3 బిట్లను మాత్రమే ఉపయోగిస్తుంది
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// బైట్ ఇరేటర్ (యుటిఎఫ్-8 లాంటి ఎన్‌కోడింగ్ uming హిస్తూ) చివరి కోడ్ పాయింట్‌ను చదువుతుంది.
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // UTF-8 డీకోడ్
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // మల్టీబైట్ కేసు బైట్ కలయిక నుండి డీకోడ్‌ను అనుసరిస్తుంది: [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// u64 ను వినియోగించుకోవడానికి సరిపోయేలా కత్తిరించండి
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// `x` అనే పదంలోని ఏదైనా బైట్ nonascii (>=128) అయితే `true` ని అందిస్తుంది.
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// ఇది చెల్లుబాటు అయ్యే UTF-8 సీక్వెన్స్ అని `v` ద్వారా నడుస్తుంది, ఆ సందర్భంలో `Ok(())` ను తిరిగి ఇస్తుంది లేదా అది చెల్లకపోతే, `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // మాకు డేటా అవసరం, కానీ ఏదీ లేదు: లోపం!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // 2-బైట్ ఎన్కోడింగ్ కోడ్ పాయింట్ల కోసం\u {0080} నుండి\u {07ff} మొదటి C2 80 చివరి DF BF
            // 3-బైట్ ఎన్కోడింగ్ కోడ్ పాయింట్ల కోసం\u {0800} నుండి\u {ffff} మొదటి E0 A0 80 చివరి EF BF BF సర్రోగేట్స్ కోడ్‌పాయింట్‌లను మినహాయించి\u {d800} నుండి\u {dfff} ED A0 80 నుండి ED BF BF వరకు
            // 4-బైట్ ఎన్కోడింగ్ కోడ్ పాయింట్ల కోసం\u {1000} 0 నుండి\u {10ff} ff మొదటి F0 90 80 80 చివరి F4 8F BF BF
            //
            // RFC నుండి UTF-8 సింటాక్స్ ఉపయోగించండి
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=% x00-7F UTF8-2=% xC2-DF UTF8-తోక UTF8-3= %xE0% xA0-BF UTF8-తోక/% xE1-EC 2( UTF8-tail )/%xED% x80-9F UTF8-తోక/% xEE-EF 2( UTF8-tail ) UTF8-4= %xF0% x90-BF 2( UTF8-tail )/% xF1-F3 3( UTF8-tail )/%xF4% x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // Ascii కేసు, త్వరగా ముందుకు వెళ్ళడానికి ప్రయత్నించండి.
            // పాయింటర్ సమలేఖనం చేయబడినప్పుడు, నాన్-అస్సి బైట్ ఉన్న పదాన్ని కనుగొనే వరకు ప్రతి పునరావృతానికి 2 పదాల డేటాను చదవండి.
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // భద్రత: `align - index` మరియు `ascii_block_size` కాబట్టి
                    // `usize_bytes`, `block = ptr.add(index)` యొక్క గుణకాలు ఎల్లప్పుడూ `usize` తో సమలేఖనం చేయబడతాయి కాబట్టి `block` మరియు `block.offset(1)` రెండింటినీ డీరెఫరెన్స్ చేయడం సురక్షితం.
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // నోనాస్సీ బైట్ ఉంటే విచ్ఛిన్నం
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // వర్డ్‌వైస్ లూప్ ఆగిపోయిన స్థానం నుండి అడుగు
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// మొదటి బైట్ ఇచ్చినప్పుడు, ఈ UTF-8 అక్షరంలో ఎన్ని బైట్లు ఉన్నాయో నిర్ణయిస్తుంది.
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// కొనసాగింపు బైట్ యొక్క విలువ బిట్స్ యొక్క ముసుగు.
const CONT_MASK: u8 = 0b0011_1111;
/// కొనసాగింపు బైట్ యొక్క ట్యాగ్ బిట్ల విలువ (ట్యాగ్ మాస్క్ !CONT_MASK).
const TAG_CONT_U8: u8 = 0b1000_0000;

// `&str` ని కత్తిరించుకుంటే `max` రిటర్న్ `true` కు సమానమైన పొడవును కత్తిరించండి మరియు కొత్త str.
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}