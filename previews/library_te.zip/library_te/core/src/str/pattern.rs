//! స్ట్రింగ్ సరళి API.
//!
//! సరళి API స్ట్రింగ్ ద్వారా శోధిస్తున్నప్పుడు వేర్వేరు నమూనా రకాలను ఉపయోగించటానికి ఒక సాధారణ యంత్రాంగాన్ని అందిస్తుంది.
//!
//! మరిన్ని వివరాల కోసం, traits [`Pattern`], [`Searcher`], [`ReverseSearcher`] మరియు [`DoubleEndedSearcher`] చూడండి.
//!
//! ఈ API అస్థిరంగా ఉన్నప్పటికీ, ఇది [`str`] రకంపై స్థిరమైన API ల ద్వారా బహిర్గతమవుతుంది.
//!
//! # Examples
//!
//! [`Pattern`] [`&str`][`str`], [`char`], [`char`] ముక్కలు మరియు `FnMut(char) -> bool` ను అమలు చేసే విధులు మరియు మూసివేతలకు స్థిరమైన API లో [implemented][pattern-impls].
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // చార్ నమూనా
//! assert_eq!(s.find('n'), Some(2));
//! // అక్షరాల నమూనా ముక్క
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // మూసివేత నమూనా
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// స్ట్రింగ్ నమూనా.
///
/// X001 లో శోధించడానికి అమలు చేసే రకాన్ని స్ట్రింగ్ నమూనాగా ఉపయోగించవచ్చని `Pattern<'a>` వ్యక్తీకరిస్తుంది.
///
/// ఉదాహరణకు, `'a'` మరియు `"aa"` రెండూ `"baaaab"` స్ట్రింగ్‌లోని ఇండెక్స్ `1` వద్ద సరిపోయే నమూనాలు.
///
/// trait ఒక అనుబంధ [`Searcher`] రకానికి బిల్డర్‌గా పనిచేస్తుంది, ఇది స్ట్రింగ్‌లో నమూనా యొక్క సంఘటనలను కనుగొనడంలో వాస్తవమైన పనిని చేస్తుంది.
///
///
/// నమూనా రకాన్ని బట్టి, [`str::find`] మరియు [`str::contains`] వంటి పద్ధతుల ప్రవర్తన మారవచ్చు.
/// దిగువ పట్టిక అలాంటి కొన్ని ప్రవర్తనలను వివరిస్తుంది.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// ఈ నమూనా కోసం అసోసియేటెడ్ శోధకుడు
    type Searcher: Searcher<'a>;

    /// శోధించడానికి `self` మరియు `haystack` నుండి అనుబంధ శోధనను నిర్మిస్తుంది.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// గడ్డివాములో ఎక్కడైనా నమూనా సరిపోతుందో లేదో తనిఖీ చేస్తుంది
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// గడ్డివాము ముందు భాగంలో నమూనా సరిపోతుందో లేదో తనిఖీ చేస్తుంది
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// గడ్డివాము వెనుక భాగంలో నమూనా సరిపోతుందో లేదో తనిఖీ చేస్తుంది
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// సరిపోలితే, గడ్డివాము ముందు నుండి నమూనాను తొలగిస్తుంది.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // భద్రత: `Searcher` చెల్లుబాటు అయ్యే సూచికలను తిరిగి ఇస్తుంది.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// సరిపోలితే, గడ్డివాము వెనుక నుండి నమూనాను తొలగిస్తుంది.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // భద్రత: `Searcher` చెల్లుబాటు అయ్యే సూచికలను తిరిగి ఇస్తుంది.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// [`Searcher::next()`] లేదా [`ReverseSearcher::next_back()`] కి కాల్ చేసిన ఫలితం.
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// నమూనా యొక్క సరిపోలిక `haystack[a..b]` వద్ద కనుగొనబడిందని వ్యక్తీకరిస్తుంది.
    ///
    Match(usize, usize),
    /// `haystack[a..b]` నమూనా యొక్క సాధ్యమైన మ్యాచ్‌గా తిరస్కరించబడిందని వ్యక్తీకరిస్తుంది.
    ///
    /// రెండు `మ్యాచ్` ల మధ్య ఒకటి కంటే ఎక్కువ `Reject` ఉండవచ్చునని గమనించండి, వాటిని ఒకటిగా మిళితం చేయవలసిన అవసరం లేదు.
    ///
    ///
    Reject(usize, usize),
    /// గడ్డివాము యొక్క ప్రతి బైట్ సందర్శించబడిందని, పునరావృతం ముగుస్తుంది.
    ///
    Done,
}

/// స్ట్రింగ్ నమూనా కోసం ఒక శోధకుడు.
///
/// ఈ trait స్ట్రింగ్ యొక్క ముందు (left) నుండి ప్రారంభమయ్యే నమూనా యొక్క అతివ్యాప్తి చెందని మ్యాచ్‌ల కోసం శోధించే పద్ధతులను అందిస్తుంది.
///
/// ఇది [`Pattern`] trait యొక్క అనుబంధ `Searcher` రకాల ద్వారా అమలు చేయబడుతుంది.
///
/// trait అసురక్షితంగా గుర్తించబడింది ఎందుకంటే [`next()`][Searcher::next] పద్ధతుల ద్వారా తిరిగి వచ్చిన సూచికలు గడ్డివాములో చెల్లుబాటు అయ్యే utf8 సరిహద్దుల్లో ఉండాలి.
/// ఇది అదనపు రన్‌టైమ్ తనిఖీలు లేకుండా గడ్డివామును ముక్కలు చేయడానికి ఈ trait యొక్క వినియోగదారులను అనుమతిస్తుంది.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// శోధించాల్సిన అంతర్లీన స్ట్రింగ్ కోసం Getter
    ///
    /// ఎల్లప్పుడూ అదే [`&str`][str] ను తిరిగి ఇస్తుంది.
    fn haystack(&self) -> &'a str;

    /// ముందు నుండి ప్రారంభమయ్యే తదుపరి శోధన దశను చేస్తుంది.
    ///
    /// - `haystack[a..b]` నమూనాతో సరిపోలితే [`Match(a, b)`][SearchStep::Match] ని అందిస్తుంది.
    /// - `haystack[a..b]` పాక్షికంగా కూడా నమూనాతో సరిపోలకపోతే [`Reject(a, b)`][SearchStep::Reject] ని అందిస్తుంది.
    /// - గడ్డివాము యొక్క ప్రతి బైట్ సందర్శించినట్లయితే [`Done`][SearchStep::Done] ను అందిస్తుంది.
    ///
    /// [`Done`][SearchStep::Done] వరకు [`Match`][SearchStep::Match] మరియు [`Reject`][SearchStep::Reject] విలువల ప్రవాహం ప్రక్కనే ఉన్న, అతివ్యాప్తి చెందని, మొత్తం గడ్డివామును కప్పి ఉంచే మరియు utf8 సరిహద్దుల్లో ఉంచే సూచిక శ్రేణులను కలిగి ఉంటుంది.
    ///
    ///
    /// [`Match`][SearchStep::Match] ఫలితం మొత్తం సరిపోలిన నమూనాను కలిగి ఉండాలి, అయితే [`Reject`][SearchStep::Reject] ఫలితాలు ఏకపక్షంగా అనేక ప్రక్కనే ఉన్న శకలాలుగా విభజించబడవచ్చు.రెండు పరిధులు సున్నా పొడవు కలిగి ఉండవచ్చు.
    ///
    /// ఉదాహరణగా, నమూనా `"aaa"` మరియు గడ్డివాము `"cbaaaaab"` ప్రవాహాన్ని ఉత్పత్తి చేస్తాయి
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// తదుపరి [`Match`][SearchStep::Match] ఫలితాన్ని కనుగొంటుంది.[`next()`][Searcher::next] చూడండి.
    ///
    /// [`next()`][Searcher::next] మాదిరిగా కాకుండా, ఈ మరియు [`next_reject`][Searcher::next_reject] యొక్క తిరిగి వచ్చిన పరిధులు అతివ్యాప్తి చెందుతాయనే గ్యారంటీ లేదు.
    /// ఇది `(start_match, end_match)` ను తిరిగి ఇస్తుంది, ఇక్కడ స్టార్ట్_మ్యాచ్ మ్యాచ్ ప్రారంభమయ్యే సూచిక, మరియు ఎండ్_మ్యాచ్ మ్యాచ్ ముగిసిన తర్వాత సూచిక.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// తదుపరి [`Reject`][SearchStep::Reject] ఫలితాన్ని కనుగొంటుంది.[`next()`][Searcher::next] మరియు [`next_match()`][Searcher::next_match] చూడండి.
    ///
    /// [`next()`][Searcher::next] మాదిరిగా కాకుండా, ఈ మరియు [`next_match`][Searcher::next_match] యొక్క తిరిగి వచ్చిన పరిధులు అతివ్యాప్తి చెందుతాయనే గ్యారంటీ లేదు.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// స్ట్రింగ్ నమూనా కోసం రివర్స్ సెర్చర్.
///
/// ఈ trait స్ట్రింగ్ యొక్క వెనుక (right) నుండి ప్రారంభమయ్యే నమూనా యొక్క అతివ్యాప్తి చెందని మ్యాచ్‌ల కోసం శోధించే పద్ధతులను అందిస్తుంది.
///
/// వెనుక నుండి వెతకడానికి నమూనా మద్దతు ఇస్తే ఇది [`Pattern`] trait యొక్క అనుబంధ [`Searcher`] రకాల ద్వారా అమలు చేయబడుతుంది.
///
///
/// ఈ trait ద్వారా తిరిగి వచ్చిన సూచిక పరిధులు రివర్స్‌లో ఫార్వర్డ్ సెర్చ్‌తో సరిగ్గా సరిపోలడం అవసరం లేదు.
///
/// ఈ trait అసురక్షితంగా గుర్తించబడిన కారణంతో, వాటిని మాతృ trait [`Searcher`] చూడండి.
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// వెనుక నుండి ప్రారంభమయ్యే తదుపరి శోధన దశను చేస్తుంది.
    ///
    /// - `haystack[a..b]` నమూనాతో సరిపోలితే [`Match(a, b)`][SearchStep::Match] ని అందిస్తుంది.
    /// - `haystack[a..b]` పాక్షికంగా కూడా నమూనాతో సరిపోలకపోతే [`Reject(a, b)`][SearchStep::Reject] ని అందిస్తుంది.
    /// - గడ్డివాము యొక్క ప్రతి బైట్ సందర్శించినట్లయితే [`Done`][SearchStep::Done] ను అందిస్తుంది
    ///
    /// [`Done`][SearchStep::Done] వరకు [`Match`][SearchStep::Match] మరియు [`Reject`][SearchStep::Reject] విలువల ప్రవాహం ప్రక్కనే ఉన్న, అతివ్యాప్తి చెందని, మొత్తం గడ్డివామును కప్పి ఉంచే మరియు utf8 సరిహద్దుల్లో ఉంచే సూచిక శ్రేణులను కలిగి ఉంటుంది.
    ///
    ///
    /// [`Match`][SearchStep::Match] ఫలితం మొత్తం సరిపోలిన నమూనాను కలిగి ఉండాలి, అయితే [`Reject`][SearchStep::Reject] ఫలితాలు ఏకపక్షంగా అనేక ప్రక్కనే ఉన్న శకలాలుగా విభజించబడవచ్చు.రెండు పరిధులు సున్నా పొడవు కలిగి ఉండవచ్చు.
    ///
    /// ఉదాహరణగా, `"aaa"` మరియు గడ్డివాము `"cbaaaaab"` నమూనా `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// తదుపరి [`Match`][SearchStep::Match] ఫలితాన్ని కనుగొంటుంది.
    /// [`next_back()`][ReverseSearcher::next_back] చూడండి.
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// తదుపరి [`Reject`][SearchStep::Reject] ఫలితాన్ని కనుగొంటుంది.
    /// [`next_back()`][ReverseSearcher::next_back] చూడండి.
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// [`ReverseSearcher`] ను [`DoubleEndedIterator`] అమలు కోసం ఉపయోగించవచ్చని వ్యక్తీకరించడానికి trait మార్కర్.
///
/// దీని కోసం, [`Searcher`] మరియు [`ReverseSearcher`] యొక్క impl ఈ షరతులను అనుసరించాలి:
///
/// - `next()` యొక్క అన్ని ఫలితాలు రివర్స్ ఆర్డర్‌లో `next_back()` ఫలితాలకు సమానంగా ఉండాలి.
/// - `next()` మరియు `next_back()` విలువల శ్రేణి యొక్క రెండు చివరలుగా ప్రవర్తించాల్సిన అవసరం ఉంది, అంటే అవి "walk past each other" కాదు.
///
/// # Examples
///
/// `char::Searcher` ఇది `DoubleEndedSearcher` ఎందుకంటే [`char`] కోసం శోధించడానికి ఒక సమయంలో ఒకదాన్ని మాత్రమే చూడటం అవసరం, ఇది రెండు చివర్ల నుండి ఒకే విధంగా ప్రవర్తిస్తుంది.
///
/// `(&str)::Searcher` `DoubleEndedSearcher` కాదు ఎందుకంటే గడ్డివాము `"aaa"` లోని `"aa"` నమూనా `"[aa]a"` లేదా `"a[aa]"` గా సరిపోతుంది, ఇది ఏ వైపు నుండి శోధించబడిందో బట్టి.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// చార్ కోసం ఇంప్ల్
/////////////////////////////////////////////////////////////////////////////

/// `<char as Pattern<'a>>::Searcher` కోసం అనుబంధ రకం.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // భద్రతా మార్పు: `finger`/`finger_back` తప్పక `haystack` యొక్క చెల్లుబాటు అయ్యే utf8 బైట్ సూచికగా ఉండాలి.
    //
    //
    /// `finger` ఫార్వర్డ్ శోధన యొక్క ప్రస్తుత బైట్ సూచిక.
    /// దాని సూచిక వద్ద బైట్ ముందు ఇది ఉందని g హించుకోండి, అనగా
    /// `haystack[finger]` ఫార్వర్డ్ సెర్చ్ సమయంలో మనం తప్పక పరిశీలించాల్సిన స్లైస్ యొక్క మొదటి బైట్
    ///
    finger: usize,
    /// `finger_back` రివర్స్ శోధన యొక్క ప్రస్తుత బైట్ సూచిక.
    /// దాని సూచిక వద్ద బైట్ తర్వాత ఇది ఉందని g హించుకోండి, అనగా
    /// గడ్డివాము [ఫింగర్_బ్యాక్, 1] అనేది స్లైస్ యొక్క చివరి బైట్, ఇది ఫార్వర్డ్ సెర్చ్ సమయంలో మనం తనిఖీ చేయాలి (అందువల్ల next_back()) కి కాల్ చేసేటప్పుడు తనిఖీ చేయవలసిన మొదటి బైట్.
    ///
    finger_back: usize,
    /// పాత్ర కోసం శోధిస్తున్నారు
    needle: char,

    // భద్రతా మార్పు: `utf8_size` 5 కంటే తక్కువ ఉండాలి
    /// utf8 లో ఎన్కోడ్ చేసినప్పుడు `needle` బైట్ల సంఖ్య పడుతుంది.
    utf8_size: usize,
    /// `needle` యొక్క utf8 ఎన్కోడ్ చేసిన కాపీ
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // భద్రత: `get_unchecked` యొక్క 1-4 హామీ భద్రత
        // 1. `self.finger` మరియు `self.finger_back` యూనికోడ్ సరిహద్దుల్లో ఉంచబడతాయి (ఇది మార్పులేనిది)
        // 2. `self.finger >= 0` ఎందుకంటే ఇది 0 వద్ద మొదలై పెరుగుతుంది
        // 3. `self.finger < self.finger_back` ఎందుకంటే లేకపోతే చార్ `iter` `SearchStep::Done` ను తిరిగి ఇస్తుంది
        // 4.
        // `self.finger` గడ్డివాము ముగిసేలోపు వస్తుంది ఎందుకంటే `self.finger_back` చివరిలో మొదలై తగ్గుతుంది
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // utf-8 గా తిరిగి ఎన్కోడింగ్ చేయకుండా ప్రస్తుత అక్షరం యొక్క బైట్ ఆఫ్‌సెట్‌ను జోడించండి
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // చివరి పాత్ర దొరికిన తర్వాత గడ్డివాము పొందండి
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // utf8 ఎన్కోడ్ చేసిన సూది యొక్క చివరి బైట్ భద్రత: మాకు `utf8_size < 5` అనే మార్పు లేదు
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // క్రొత్త వేలు అనేది మేము కనుగొన్న బైట్ యొక్క సూచిక, ప్లస్ వన్, ఎందుకంటే మేము పాత్ర యొక్క చివరి బైట్ కోసం జ్ఞాపకం చేసుకున్నాము.
                //
                // ఇది ఎల్లప్పుడూ మాకు UTF8 సరిహద్దులో వేలు ఇవ్వదని గమనించండి.
                // మేము మా పాత్రను కనుగొనలేకపోతే, మేము 3-బైట్ లేదా 4-బైట్ అక్షరం యొక్క చివరి కాని బైట్‌కు సూచిక చేసి ఉండవచ్చు.
                // Valid (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` వంటి అక్షరం మూడవదాన్ని శోధించేటప్పుడు ఎల్లప్పుడూ రెండవ బైట్‌ను కనుగొంటుంది కాబట్టి మేము తదుపరి చెల్లుబాటు అయ్యే ప్రారంభ బైట్‌కు వెళ్ళలేము.
                //
                //
                // అయితే, ఇది పూర్తిగా సరే.
                // self.finger UTF8 సరిహద్దులో ఉందని మనకు మార్పు ఉన్నప్పటికీ, ఈ మార్పు ఈ పద్ధతిలో ఆధారపడదు (ఇది CharSearcher::next()) లో ఆధారపడుతుంది.
                //
                // మేము స్ట్రింగ్ చివరకి చేరుకున్నప్పుడు లేదా మనకు ఏదైనా దొరికినప్పుడు మాత్రమే ఈ పద్ధతి నుండి నిష్క్రమిస్తాము.మేము ఏదైనా కనుగొన్నప్పుడు `finger` UTF8 సరిహద్దుకు సెట్ చేయబడుతుంది.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // ఏమీ కనుగొనబడలేదు, నిష్క్రమించండి
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // శోధన trait నుండి డిఫాల్ట్ అమలును next_reject ఉపయోగించనివ్వండి
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // భద్రత: పై next() కోసం వ్యాఖ్య చూడండి
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // utf-8 గా తిరిగి ఎన్కోడింగ్ చేయకుండా ప్రస్తుత అక్షరం యొక్క బైట్ ఆఫ్‌సెట్‌ను తీసివేయండి
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // గడ్డివామును పొందండి కాని శోధించిన చివరి అక్షరంతో సహా
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // utf8 ఎన్కోడ్ చేసిన సూది యొక్క చివరి బైట్ భద్రత: మాకు `utf8_size < 5` అనే మార్పు లేదు
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // మేము self.finger చేత ఆఫ్‌సెట్ చేయబడిన స్లైస్‌ని శోధించాము, అసలు సూచికను తిరిగి పొందటానికి self.finger ని జోడించండి
                //
                let index = self.finger + index;
                // memrchr మేము కనుగొనాలనుకుంటున్న బైట్ యొక్క సూచికను తిరిగి ఇస్తుంది.
                // ASCII అక్షరం విషయంలో, ఇది మా క్రొత్త వేలు కావాలని మేము కోరుకుంటున్నాము (రివర్స్ మళ్ళా యొక్క ఉదాహరణలో "after" దొరికిన చార్).
                //
                // మల్టీబైట్ అక్షరాల కోసం, ASCII కన్నా ఎక్కువ బైట్ల సంఖ్యను మనం దాటవేయాలి
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // అక్షరం కనుగొనబడటానికి ముందు వేలును తరలించండి (అనగా, దాని ప్రారంభ సూచిక వద్ద)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // మేము ఇక్కడ ఫింగర్_బ్యాక్=ఇండెక్స్, సైజు + 1 ను ఉపయోగించలేము.
                // మేము వేరే-పరిమాణ అక్షరం యొక్క చివరి చార్‌ను కనుగొంటే (లేదా వేరే అక్షరం యొక్క మధ్య బైట్) మేము వేలు_బ్యాక్‌ను `index` కి తగ్గించాలి.
                // ఇది అదేవిధంగా `finger_back` ఇకపై సరిహద్దులో ఉండగల సామర్థ్యాన్ని కలిగి ఉంటుంది, కానీ మేము ఈ ఫంక్షన్‌ను సరిహద్దులో మాత్రమే నిష్క్రమించినందున లేదా గడ్డివాము పూర్తిగా శోధించినప్పుడు ఇది సరే.
                //
                //
                // నెక్స్ట్_మ్యాచ్ మాదిరిగా కాకుండా utf-8 లో పునరావృతమయ్యే బైట్ల సమస్య లేదు ఎందుకంటే మేము చివరి బైట్ కోసం శోధిస్తున్నాము మరియు రివర్స్‌లో శోధిస్తున్నప్పుడు మాత్రమే చివరి బైట్‌ను కనుగొనగలం.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // ఏమీ కనుగొనబడలేదు, నిష్క్రమించండి
                return None;
            }
        }
    }

    // శోధన trait నుండి డిఫాల్ట్ అమలును ఉపయోగించడానికి next_reject_back ని అనుమతించండి
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// ఇచ్చిన [`char`] కి సమానమైన అక్షరాల కోసం శోధనలు.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// మల్టీచార్ఎక్ రేపర్ కోసం ఇంప్ల్ చేయండి
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // ప్రస్తుత చార్ యొక్క పొడవును కనుగొనడానికి అంతర్గత బైట్ స్లైస్ ఇరేటర్ యొక్క పొడవులను సరిపోల్చండి
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // ప్రస్తుత చార్ యొక్క పొడవును కనుగొనడానికి అంతర్గత బైట్ స్లైస్ ఇరేటర్ యొక్క పొడవులను సరిపోల్చండి
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// &[చార్] కోసం ఇంప్ల్
/////////////////////////////////////////////////////////////////////////////

// Todo: అర్థంలో అస్పష్టత కారణంగా మార్చండి/తొలగించండి.

/// `<&[char] as Pattern<'a>>::Searcher` కోసం అనుబంధ రకం.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// స్లైస్‌లోని ఏదైనా [`చార్`] లకు సమానమైన అక్షరాల కోసం శోధనలు.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// F: FnMut(char)-> bool కోసం Impl
/////////////////////////////////////////////////////////////////////////////

/// `<F as Pattern<'a>>::Searcher` కోసం అనుబంధ రకం.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// ఇచ్చిన ప్రిడికేట్‌తో సరిపోయే [`చార్`] కోసం శోధనలు.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// &&str కోసం Impl
/////////////////////////////////////////////////////////////////////////////

/// `&str` impl కు ప్రతినిధులు.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// &str కోసం ఇంప్ల్
/////////////////////////////////////////////////////////////////////////////

/// కేటాయించని సబ్‌స్ట్రింగ్ శోధన.
///
/// ప్రతి అక్షర సరిహద్దు వద్ద ఖాళీ మ్యాచ్‌లను తిరిగి ఇచ్చే విధంగా `""` నమూనాను నిర్వహిస్తుంది.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// గడ్డివాము ముందు భాగంలో నమూనా సరిపోతుందో లేదో తనిఖీ చేస్తుంది.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// సరిపోలితే, గడ్డివాము ముందు నుండి నమూనాను తొలగిస్తుంది.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // భద్రత: ఉపసర్గ ఉనికిలో ఉందని ధృవీకరించబడింది.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// గడ్డివాము వెనుక భాగంలో నమూనా సరిపోతుందో లేదో తనిఖీ చేస్తుంది.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// సరిపోలితే, గడ్డివాము వెనుక నుండి నమూనాను తొలగిస్తుంది.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // భద్రత: ప్రత్యయం ఉనికిలో ఉందని ధృవీకరించబడింది.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// టూ వే సబ్‌స్ట్రింగ్ సెర్చర్
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// `<&str as Pattern<'a>>::Searcher` కోసం అనుబంధ రకం.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // ఖాళీ సూది ప్రతి చార్‌ను తిరస్కరిస్తుంది మరియు వాటి మధ్య ఉన్న ప్రతి ఖాళీ స్ట్రింగ్‌తో సరిపోతుంది
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // టూ వేసెర్చర్ చెల్లుబాటు అయ్యే *మ్యాచ్* సూచికలను ఉత్పత్తి చేస్తుంది, అది సరైన సరిపోలిక ఉన్నంత వరకు చార్ గడ్డల వద్ద విడిపోతుంది మరియు గడ్డివాము మరియు సూది చెల్లుబాటు అయ్యే UTF-8 *అల్గోరిథం నుండి తిరస్కరించడం* ఏదైనా సూచికలపై పడవచ్చు, కాని మేము వాటిని తదుపరి అక్షర సరిహద్దుకు మానవీయంగా నడిపిస్తాము, తద్వారా అవి utf-8 సురక్షితంగా ఉంటాయి.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // తదుపరి చార్ సరిహద్దుకు దాటవేయి
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // రెండు కేసులను విడిగా ప్రత్యేకపరచడానికి కంపైలర్‌ను ప్రోత్సహించడానికి `true` మరియు `false` కేసులను వ్రాయండి.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // తదుపరి చార్ సరిహద్దుకు దాటవేయి
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // `next_match` వంటి `true` మరియు `false` ను వ్రాయండి
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// రెండు-మార్గం సబ్‌స్ట్రింగ్ శోధన అల్గోరిథం యొక్క అంతర్గత స్థితి.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// క్లిష్టమైన కారకాల సూచిక
    crit_pos: usize,
    /// రివర్స్డ్ సూది కోసం క్లిష్టమైన కారకాల సూచిక
    crit_pos_back: usize,
    period: usize,
    /// `byteset` పొడిగింపు (రెండు మార్గం అల్గోరిథంలో భాగం కాదు);
    /// ఇది 64-బిట్ "fingerprint", ఇక్కడ ప్రతి సెట్ బిట్ `j` సూదిలో ఉన్న (బైట్&63)==j కు అనుగుణంగా ఉంటుంది.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// మేము ఇప్పటికే సరిపోలిన ముందు సూదిలోకి సూచిక
    memory: usize,
    /// మేము ఇప్పటికే సరిపోలిన సూదిలోకి సూచిక
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // ఇక్కడ ఏమి జరుగుతుందో ప్రత్యేకంగా చదవగలిగే వివరణ క్రోచెమోర్ మరియు రైటర్ యొక్క పుస్తకం "Text Algorithms", ch 13 లో చూడవచ్చు.
        // P లో "Algorithm CP" కోసం కోడ్‌ను ప్రత్యేకంగా చూడండి.
        // 323.
        //
        // ఏమి జరుగుతుందో మనకు సూది యొక్క కొన్ని క్లిష్టమైన కారకాలీకరణ (యు, వి) ఉంది, మరియు యు&వి [.. కాలం] యొక్క ప్రత్యయం కాదా అని మేము నిర్ణయించాలనుకుంటున్నాము.
        // అది ఉంటే, మేము "Algorithm CP1" ను ఉపయోగిస్తాము.
        // లేకపోతే మేము "Algorithm CP2" ను ఉపయోగిస్తాము, ఇది సూది కాలం పెద్దగా ఉన్నప్పుడు ఆప్టిమైజ్ చేయబడుతుంది.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // స్వల్పకాలిక కేసు-కాలం ఖచ్చితమైనది రివర్స్డ్ సూది x=u 'v' ఎక్కడ | v '|<period(x).
            //
            // ఇది ఇప్పటికే తెలిసిన కాలం ద్వారా వేగవంతం అవుతుంది.
            // X= "acba" వంటి కేసు రివర్స్ (క్రిట్_పోస్=2, పీరియడ్=2) లో సుమారుగా కాలంతో కారకం అవుతున్నప్పుడు ఖచ్చితంగా ముందుకు (క్రిట్_పోస్=1, పీరియడ్=3) కారకం కావచ్చు.
            // మేము ఇచ్చిన రివర్స్ కారకాన్ని ఉపయోగిస్తాము కాని ఖచ్చితమైన కాలాన్ని ఉంచుతాము.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // దీర్ఘకాలిక కేసు-మనకు వాస్తవ కాలానికి ఒక ఉజ్జాయింపు ఉంది మరియు జ్ఞాపకశక్తిని ఉపయోగించవద్దు.
            //
            //
            // తక్కువ బౌండ్ max(|u|, |v|) + 1 ద్వారా వ్యవధిని అంచనా వేయండి.
            // ఫార్వర్డ్ మరియు రివర్స్ సెర్చ్ రెండింటికీ ఉపయోగించడానికి క్లిష్టమైన కారకం సమర్థవంతంగా ఉంటుంది.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // కాలం పొడవుగా ఉందని సూచించడానికి డమ్మీ విలువ
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // టూ-వే యొక్క ప్రధాన ఆలోచనలలో ఒకటి, మేము సూదిని రెండు భాగాలుగా, (u, v) కారకం చేసి, ఎడమ నుండి కుడికి స్కాన్ చేయడం ద్వారా గడ్డివాములో v ని కనుగొనడానికి ప్రయత్నించడం.
    // V సరిపోలితే, కుడి నుండి ఎడమకు స్కాన్ చేయడం ద్వారా u తో సరిపోలడానికి ప్రయత్నిస్తాము.
    // అసమతుల్యతను ఎదుర్కొన్నప్పుడు మనం ఎంత దూరం దూకగలం అనేది (u, v) సూదికి కీలకమైన కారకం.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` `self.position` ను దాని కర్సర్‌గా ఉపయోగిస్తుంది
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // ముక్కలు ఐసైజ్ పరిధికి సరిహద్దులుగా ఉన్నాయని అనుకుంటే, స్థితిలో శోధించడానికి మాకు గది ఉందో లేదో తనిఖీ చేయండి + సూది_లాస్ట్ పొంగిపోదు.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // మా సబ్‌స్ట్రింగ్‌తో సంబంధం లేని పెద్ద భాగాలను త్వరగా దాటవేయండి
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // సూది యొక్క కుడి భాగం సరిపోతుందో లేదో చూడండి
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // సూది యొక్క ఎడమ భాగం సరిపోతుందో లేదో చూడండి
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // మేము ఒక మ్యాచ్ కనుగొన్నాము!
            let match_pos = self.position;

            // Note: అతివ్యాప్తి మ్యాచ్‌లను కలిగి ఉండటానికి needle.len() కు బదులుగా self.period ని జోడించండి
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // అతివ్యాప్తి మ్యాచ్‌ల కోసం needle.len(), self.period కు సెట్ చేయబడింది
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `next()` లోని ఆలోచనలను అనుసరిస్తుంది.
    //
    // నిర్వచనాలు సుష్ట, period(x) = period(reverse(x)) మరియు local_period(u, v) = local_period(reverse(v), reverse(u)), కాబట్టి (u, v) ఒక క్లిష్టమైన కారకం అయితే, (reverse(v), reverse(u)).
    //
    //
    // రివర్స్ కేసు కోసం మేము క్లిష్టమైన కారకం x=u 'v' (ఫీల్డ్ `crit_pos_back`) ను లెక్కించాము.మాకు అవసరం | u |ఫార్వర్డ్ కేసు కోసం <period(x) మరియు అందువలన | v '|రివర్స్ కోసం <period(x).
    //
    // గడ్డివాము ద్వారా రివర్స్‌లో శోధించడానికి, రివర్స్డ్ సూదితో రివర్స్డ్ గడ్డివాము ద్వారా ముందుకు వెతుకుతాము, మొదట u 'మరియు తరువాత v' కు సరిపోతుంది.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` `self.end` ను దాని కర్సర్‌గా ఉపయోగిస్తుంది-తద్వారా `next()` మరియు `next_back()` స్వతంత్రంగా ఉంటాయి.
        //
        let old_end = self.end;
        'search: loop {
            // చివరికి శోధించడానికి మాకు గది ఉందో లేదో తనిఖీ చేయండి, ఎక్కువ గది లేనప్పుడు needle.len() చుట్టుముడుతుంది, కానీ స్లైస్ పొడవు పరిమితుల కారణంగా ఇది ఎప్పటికీ గడ్డివాము యొక్క పొడవులోకి చుట్టబడదు.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // మా సబ్‌స్ట్రింగ్‌తో సంబంధం లేని పెద్ద భాగాలను త్వరగా దాటవేయండి
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // సూది యొక్క ఎడమ భాగం సరిపోతుందో లేదో చూడండి
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // సూది యొక్క కుడి భాగం సరిపోతుందో లేదో చూడండి
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // మేము ఒక మ్యాచ్ కనుగొన్నాము!
            let match_pos = self.end - needle.len();
            // Note: అతివ్యాప్తి మ్యాచ్‌లను కలిగి ఉండటానికి needle.len() కు బదులుగా ఉప self.period
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `arr` యొక్క గరిష్ట ప్రత్యయాన్ని లెక్కించండి.
    //
    // గరిష్ట ప్రత్యయం `arr` యొక్క క్లిష్టమైన కారకం (u, v).
    //
    // రిటర్న్స్ (`i`, `p`) ఇక్కడ `i` అనేది v యొక్క ప్రారంభ సూచిక మరియు `p` అనేది v యొక్క కాలం.
    //
    // `order_greater` లెక్సికల్ ఆర్డర్ `<` లేదా `>` అని నిర్ణయిస్తుంది.
    // రెండు ఆర్డర్‌లను తప్పనిసరిగా లెక్కించాలి-అతిపెద్ద `i` తో ఆర్డరింగ్ క్లిష్టమైన కారకాన్ని ఇస్తుంది.
    //
    //
    // దీర్ఘకాలిక కేసులకు, ఫలిత కాలం ఖచ్చితమైనది కాదు (ఇది చాలా చిన్నది).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // కాగితంలో i కి అనుగుణంగా ఉంటుంది
        let mut right = 1; // కాగితంలో j కి అనుగుణంగా ఉంటుంది
        let mut offset = 0; // కాగితంలో k కి అనుగుణంగా ఉంటుంది, కానీ 0 నుండి ప్రారంభమవుతుంది
        // 0-ఆధారిత సూచికతో సరిపోలడానికి.
        let mut period = 1; // కాగితంలో p కి అనుగుణంగా ఉంటుంది

        while let Some(&a) = arr.get(right + offset) {
            // `left` `right` ఉన్నప్పుడు ఇన్‌బౌండ్‌గా ఉంటుంది.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // ప్రత్యయం చిన్నది, కాలం ఇప్పటివరకు మొత్తం ఉపసర్గ.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // ప్రస్తుత కాలం పునరావృతం ద్వారా పురోగతి.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // ప్రత్యయం పెద్దది, ప్రస్తుత స్థానం నుండి ప్రారంభించండి.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // `arr` యొక్క రివర్స్ యొక్క గరిష్ట ప్రత్యయాన్ని లెక్కించండి.
    //
    // గరిష్ట ప్రత్యయం `arr` యొక్క క్లిష్టమైన కారకం (u ', v').
    //
    // `i` ను తిరిగి ఇస్తుంది, ఇక్కడ `i` అనేది వెనుక నుండి v 'యొక్క ప్రారంభ సూచిక;
    // `known_period` కాలం చేరుకున్నప్పుడు వెంటనే తిరిగి వస్తుంది.
    //
    // `order_greater` లెక్సికల్ ఆర్డర్ `<` లేదా `>` అని నిర్ణయిస్తుంది.
    // రెండు ఆర్డర్‌లను తప్పనిసరిగా లెక్కించాలి-అతిపెద్ద `i` తో ఆర్డరింగ్ క్లిష్టమైన కారకాన్ని ఇస్తుంది.
    //
    //
    // దీర్ఘకాలిక కేసులకు, ఫలిత కాలం ఖచ్చితమైనది కాదు (ఇది చాలా చిన్నది).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // కాగితంలో i కి అనుగుణంగా ఉంటుంది
        let mut right = 1; // కాగితంలో j కి అనుగుణంగా ఉంటుంది
        let mut offset = 0; // కాగితంలో k కి అనుగుణంగా ఉంటుంది, కానీ 0 నుండి ప్రారంభమవుతుంది
        // 0-ఆధారిత సూచికతో సరిపోలడానికి.
        let mut period = 1; // కాగితంలో p కి అనుగుణంగా ఉంటుంది
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // ప్రత్యయం చిన్నది, కాలం ఇప్పటివరకు మొత్తం ఉపసర్గ.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // ప్రస్తుత కాలం పునరావృతం ద్వారా పురోగతి.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // ప్రత్యయం పెద్దది, ప్రస్తుత స్థానం నుండి ప్రారంభించండి.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// టూ వేస్ట్రాటజీ అల్గోరిథం వీలైనంత త్వరగా సరిపోలని దాటవేయడానికి లేదా సాపేక్షంగా త్వరగా తిరస్కరణలను విడుదల చేసే మోడ్‌లో పనిచేయడానికి అనుమతిస్తుంది.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// వీలైనంత త్వరగా విరామాలను సరిపోల్చడానికి దాటవేయి
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// క్రమం తప్పకుండా తిరస్కరించండి
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}