//! utf8 లోపం రకాన్ని నిర్వచిస్తుంది.

use crate::fmt;

/// [`u8`] యొక్క క్రమాన్ని స్ట్రింగ్‌గా అర్థం చేసుకోవడానికి ప్రయత్నించినప్పుడు సంభవించే లోపాలు.
///
/// అందుకని, [`స్ట్రింగ్`] మరియు [`&str`] రెండింటి కోసం `from_utf8` ఫ్యామిలీ ఫంక్షన్లు మరియు పద్ధతులు ఈ లోపాన్ని ఉపయోగించుకుంటాయి, ఉదాహరణకు.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// కుప్ప మెమరీని కేటాయించకుండా `String::from_utf8_lossy` మాదిరిగానే కార్యాచరణను సృష్టించడానికి ఈ లోపం రకం యొక్క పద్ధతులు ఉపయోగించవచ్చు:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// చెల్లుబాటు అయ్యే UTF-8 ధృవీకరించబడిన ఇచ్చిన స్ట్రింగ్‌లోని సూచికను అందిస్తుంది.
    ///
    /// ఇది `from_utf8(&input[..index])` `Ok(_)` ను తిరిగి ఇచ్చే గరిష్ట సూచిక.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::str;
    ///
    /// // vector లో కొన్ని చెల్లని బైట్లు
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 Utf8Error ను అందిస్తుంది
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // రెండవ బైట్ ఇక్కడ చెల్లదు
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// వైఫల్యం గురించి మరింత సమాచారం అందిస్తుంది:
    ///
    /// * `None`: ఇన్పుట్ ముగింపు అనుకోకుండా చేరుకుంది.
    ///   `self.valid_up_to()` ఇన్పుట్ చివరి నుండి 1 నుండి 3 బైట్లు.
    ///   ఒక బైట్ స్ట్రీమ్ (ఫైల్ లేదా నెట్‌వర్క్ సాకెట్ వంటివి) పెరుగుతున్నప్పుడు డీకోడ్ అవుతుంటే, ఇది చెల్లుబాటు అయ్యే `char` కావచ్చు, దీని UTF-8 బైట్ సీక్వెన్స్ బహుళ భాగాలుగా విస్తరించి ఉంటుంది.
    ///
    ///
    /// * `Some(len)`: unexpected హించని బైట్ ఎదురైంది.
    ///   అందించిన పొడవు `valid_up_to()` ఇచ్చిన సూచిక వద్ద ప్రారంభమయ్యే చెల్లని బైట్ క్రమం.
    ///   నష్టపోయిన డీకోడింగ్ విషయంలో డీకోడింగ్ ఆ క్రమం తర్వాత ([`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] చొప్పించిన తర్వాత) తిరిగి ప్రారంభించాలి.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// [`from_str`] ఉపయోగించి `bool` ను అన్వయించినప్పుడు లోపం తిరిగి వచ్చింది
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}