//! `str` కోసం Trait అమలు.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// తీగలను క్రమం చేయడాన్ని అమలు చేస్తుంది.
///
/// తీగలను వాటి బైట్ విలువల ద్వారా [lexicographically](Ord#lexicographical-comparison) ఆర్డర్ చేస్తారు.
/// ఇది కోడ్ చార్టులలోని స్థానాల ఆధారంగా యూనికోడ్ కోడ్ పాయింట్లను ఆర్డర్ చేస్తుంది.
/// ఇది "alphabetical" ఆర్డర్‌కు సమానం కాదు, ఇది భాష మరియు లొకేల్ ఆధారంగా మారుతుంది.
/// సాంస్కృతికంగా ఆమోదించబడిన ప్రమాణాల ప్రకారం తీగలను క్రమబద్ధీకరించడానికి `str` రకం పరిధికి వెలుపల ఉన్న లొకేల్-నిర్దిష్ట డేటా అవసరం.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// తీగలపై పోలిక కార్యకలాపాలను అమలు చేస్తుంది.
///
/// తీగలను [lexicographically](Ord#lexicographical-comparison) ను వాటి బైట్ విలువలతో పోల్చారు.
/// ఇది కోడ్ చార్టులలోని స్థానాల ఆధారంగా యూనికోడ్ కోడ్ పాయింట్లను పోల్చి చూస్తుంది.
/// ఇది "alphabetical" ఆర్డర్‌కు సమానం కాదు, ఇది భాష మరియు లొకేల్ ఆధారంగా మారుతుంది.
/// సాంస్కృతికంగా ఆమోదించబడిన ప్రమాణాల ప్రకారం తీగలను పోల్చడానికి `str` రకం పరిధికి వెలుపల ఉన్న లొకేల్-నిర్దిష్ట డేటా అవసరం.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// సింటాక్స్ `&self[..]` లేదా `&mut self[..]` తో సబ్‌స్ట్రింగ్ స్లైసింగ్‌ను అమలు చేస్తుంది.
///
/// మొత్తం స్ట్రింగ్ యొక్క స్లైస్‌ని అందిస్తుంది, అనగా, `&self` లేదా `&mut self` ను అందిస్తుంది.`&స్వీయ [0 .. కు సమానం.
/// len] `లేదా`&మ్యూట్ సెల్ఫ్ [0 ..
/// len]`.
/// ఇతర ఇండెక్సింగ్ కార్యకలాపాల మాదిరిగా కాకుండా, ఇది ఎప్పటికీ panic కాదు.
///
/// ఈ ఆపరేషన్ *O*(1).
///
/// 1.20.0 కి ముందు, `Index` మరియు `IndexMut` యొక్క ప్రత్యక్ష అమలు ద్వారా ఈ ఇండెక్సింగ్ కార్యకలాపాలకు ఇప్పటికీ మద్దతు ఉంది.
///
/// `&self[0 .. len]` లేదా `&mut self[0 .. len]` కు సమానం.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// సింటాక్స్ `&self[begin .. end]` లేదా `&mut self[begin .. end]` తో సబ్‌స్ట్రింగ్ స్లైసింగ్‌ను అమలు చేస్తుంది.
///
/// బైట్ పరిధి [`ప్రారంభం`, `end`) నుండి ఇచ్చిన స్ట్రింగ్ యొక్క స్లైస్‌ని అందిస్తుంది.
///
/// ఈ ఆపరేషన్ *O*(1).
///
/// 1.20.0 కి ముందు, `Index` మరియు `IndexMut` యొక్క ప్రత్యక్ష అమలు ద్వారా ఈ ఇండెక్సింగ్ కార్యకలాపాలకు ఇప్పటికీ మద్దతు ఉంది.
///
/// # Panics
///
/// `begin` లేదా `end` ఒక అక్షరం యొక్క ప్రారంభ బైట్ ఆఫ్‌సెట్‌ను సూచించకపోతే Panics (`is_char_boundary` చేత నిర్వచించబడినది), `begin > end` అయితే, లేదా `end > len` అయితే.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // ఇవి panic అవుతుంది:
/// // బైట్ 2 `ö` లో ఉంది:
/// // &లు [2 ..3];
///
/// // బైట్ 8 `老`&s [1 ..
/// // 8];
///
/// // బైట్ 100 స్ట్రింగ్&s వెలుపల ఉంది [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // భద్రత: `start` మరియు `end` చార్ సరిహద్దులో ఉన్నాయని తనిఖీ చేసింది,
            // మరియు మేము సురక్షితమైన సూచనలో ప్రయాణిస్తున్నాము, కాబట్టి తిరిగి వచ్చే విలువ కూడా ఒకటి అవుతుంది.
            // మేము చార్ సరిహద్దులను కూడా తనిఖీ చేసాము, కాబట్టి ఇది చెల్లుబాటు అయ్యే UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // భద్రత: `start` మరియు `end` చార్ సరిహద్దులో ఉన్నాయని తనిఖీ చేసింది.
            // `slice` నుండి మాకు లభించినందున పాయింటర్ ప్రత్యేకమైనదని మాకు తెలుసు.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // భద్రత: `self` `slice` యొక్క సరిహద్దుల్లో ఉందని కాలర్ హామీ ఇస్తుంది
        // ఇది `add` కోసం అన్ని షరతులను సంతృప్తిపరుస్తుంది.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // భద్రత: `get_unchecked` కోసం వ్యాఖ్యలను చూడండి.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // సూచిక [0 లో ఉందని is_char_boundary తనిఖీ చేస్తుంది, NLL ఇబ్బంది కారణంగా .len()] పైన పేర్కొన్న విధంగా `get` ను తిరిగి ఉపయోగించదు.
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // భద్రత: `start` మరియు `end` చార్ సరిహద్దులో ఉన్నాయని తనిఖీ చేసింది,
            // మరియు మేము సురక్షితమైన సూచనలో ప్రయాణిస్తున్నాము, కాబట్టి తిరిగి వచ్చే విలువ కూడా ఒకటి అవుతుంది.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// సింటాక్స్ `&self[.. end]` లేదా `&mut self[.. end]` తో సబ్‌స్ట్రింగ్ స్లైసింగ్‌ను అమలు చేస్తుంది.
///
/// బైట్ పరిధి [`0`, `end`) నుండి ఇచ్చిన స్ట్రింగ్ యొక్క స్లైస్‌ని అందిస్తుంది.
/// `&self[0 .. end]` లేదా `&mut self[0 .. end]` కు సమానం.
///
/// ఈ ఆపరేషన్ *O*(1).
///
/// 1.20.0 కి ముందు, `Index` మరియు `IndexMut` యొక్క ప్రత్యక్ష అమలు ద్వారా ఈ ఇండెక్సింగ్ కార్యకలాపాలకు ఇప్పటికీ మద్దతు ఉంది.
///
/// # Panics
///
/// `end` అక్షరం యొక్క ప్రారంభ బైట్ ఆఫ్‌సెట్‌ను సూచించకపోతే Panics (`is_char_boundary` చే నిర్వచించబడినది), లేదా `end > len` అయితే.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // భద్రత: `end` చార్ సరిహద్దులో ఉందని తనిఖీ చేసింది,
            // మరియు మేము సురక్షితమైన సూచనలో ప్రయాణిస్తున్నాము, కాబట్టి తిరిగి వచ్చే విలువ కూడా ఒకటి అవుతుంది.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // భద్రత: `end` చార్ సరిహద్దులో ఉందని తనిఖీ చేసింది,
            // మరియు మేము సురక్షితమైన సూచనలో ప్రయాణిస్తున్నాము, కాబట్టి తిరిగి వచ్చే విలువ కూడా ఒకటి అవుతుంది.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // భద్రత: `end` చార్ సరిహద్దులో ఉందని తనిఖీ చేసింది,
            // మరియు మేము సురక్షితమైన సూచనలో ప్రయాణిస్తున్నాము, కాబట్టి తిరిగి వచ్చే విలువ కూడా ఒకటి అవుతుంది.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// సింటాక్స్ `&self[begin ..]` లేదా `&mut self[begin ..]` తో సబ్‌స్ట్రింగ్ స్లైసింగ్‌ను అమలు చేస్తుంది.
///
/// బైట్ పరిధి [`ప్రారంభం`, `len`) నుండి ఇచ్చిన స్ట్రింగ్ యొక్క స్లైస్‌ని అందిస్తుంది.`&స్వయంగా సమానం [ప్రారంభం ..
/// len] `లేదా`&మ్యూట్ సెల్ఫ్ [ప్రారంభం ..
/// len]`.
///
/// ఈ ఆపరేషన్ *O*(1).
///
/// 1.20.0 కి ముందు, `Index` మరియు `IndexMut` యొక్క ప్రత్యక్ష అమలు ద్వారా ఈ ఇండెక్సింగ్ కార్యకలాపాలకు ఇప్పటికీ మద్దతు ఉంది.
///
/// # Panics
///
/// `begin` అక్షరం యొక్క ప్రారంభ బైట్ ఆఫ్‌సెట్‌ను సూచించకపోతే Panics (`is_char_boundary` చే నిర్వచించబడినది), లేదా `begin > len` అయితే.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // భద్రత: `start` చార్ సరిహద్దులో ఉందని తనిఖీ చేసింది,
            // మరియు మేము సురక్షితమైన సూచనలో ప్రయాణిస్తున్నాము, కాబట్టి తిరిగి వచ్చే విలువ కూడా ఒకటి అవుతుంది.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // భద్రత: `start` చార్ సరిహద్దులో ఉందని తనిఖీ చేసింది,
            // మరియు మేము సురక్షితమైన సూచనలో ప్రయాణిస్తున్నాము, కాబట్టి తిరిగి వచ్చే విలువ కూడా ఒకటి అవుతుంది.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // భద్రత: `self` `slice` యొక్క సరిహద్దుల్లో ఉందని కాలర్ హామీ ఇస్తుంది
        // ఇది `add` కోసం అన్ని షరతులను సంతృప్తిపరుస్తుంది.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // భద్రత: `get_unchecked` కు సమానంగా ఉంటుంది.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // భద్రత: `start` చార్ సరిహద్దులో ఉందని తనిఖీ చేసింది,
            // మరియు మేము సురక్షితమైన సూచనలో ప్రయాణిస్తున్నాము, కాబట్టి తిరిగి వచ్చే విలువ కూడా ఒకటి అవుతుంది.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// సింటాక్స్ `&self[begin ..= end]` లేదా `&mut self[begin ..= end]` తో సబ్‌స్ట్రింగ్ స్లైసింగ్‌ను అమలు చేస్తుంది.
///
/// బైట్ పరిధి [`begin`, `end`] నుండి ఇచ్చిన స్ట్రింగ్ యొక్క స్లైస్‌ని అందిస్తుంది.`&self [begin .. end + 1]` లేదా `&mut self[begin .. end + 1]` కు సమానం, `end` `usize` కోసం గరిష్ట విలువను కలిగి ఉంటే తప్ప.
///
/// ఈ ఆపరేషన్ *O*(1).
///
/// # Panics
///
/// `begin` ఒక అక్షరం యొక్క ప్రారంభ బైట్ ఆఫ్‌సెట్‌ను సూచించకపోతే Panics, `end` ఒక అక్షరం యొక్క ముగింపు బైట్ ఆఫ్‌సెట్‌ను సూచించకపోతే (`end + 1` అనేది ప్రారంభ బైట్ ఆఫ్‌సెట్ లేదా `len` కి సమానం), `begin > end` ఉంటే, లేదా `end >= len` అయితే.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // భద్రత: కాలర్ `get_unchecked` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // భద్రత: కాలర్ `get_unchecked_mut` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// సింటాక్స్ `&self[..= end]` లేదా `&mut self[..= end]` తో సబ్‌స్ట్రింగ్ స్లైసింగ్‌ను అమలు చేస్తుంది.
///
/// బైట్ పరిధి [0, `end`] నుండి ఇచ్చిన స్ట్రింగ్ యొక్క స్లైస్‌ని అందిస్తుంది.
/// `&self [0 .. end + 1]` కి సమానం, `end` `usize` కోసం గరిష్ట విలువను కలిగి ఉంటే తప్ప.
///
/// ఈ ఆపరేషన్ *O*(1).
///
/// # Panics
///
/// `end` ఒక అక్షరం యొక్క ముగింపు బైట్ ఆఫ్‌సెట్‌ను సూచించకపోతే Panics (`end + 1` అనేది `is_char_boundary` చేత నిర్వచించబడిన ప్రారంభ బైట్ ఆఫ్‌సెట్, లేదా `len` కి సమానం), లేదా `end >= len` అయితే.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // భద్రత: కాలర్ `get_unchecked` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // భద్రత: కాలర్ `get_unchecked_mut` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// స్ట్రింగ్ నుండి విలువను అన్వయించండి
///
/// [FromStr`యొక్క [`from_str`] పద్ధతి తరచుగా [`str`] యొక్క [`parse`] పద్ధతి ద్వారా అవ్యక్తంగా ఉపయోగించబడుతుంది.
/// ఉదాహరణల కోసం [`పార్స్`] యొక్క డాక్యుమెంటేషన్ చూడండి.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` జీవితకాల పరామితి లేదు, కాబట్టి మీరు జీవితకాల పరామితిని కలిగి లేని రకాలను మాత్రమే అన్వయించవచ్చు.
///
/// మరో మాటలో చెప్పాలంటే, మీరు `i32` ను `FromStr` తో అన్వయించవచ్చు, కానీ `&i32` కాదు.
/// మీరు `i32` కలిగి ఉన్న ఒక struct ని అన్వయించవచ్చు, కానీ `&i32` కలిగి ఉన్నది కాదు.
///
/// # Examples
///
/// ఉదాహరణకి `FromStr` యొక్క ప్రాథమిక అమలు `Point` రకం:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// పార్సింగ్ నుండి తిరిగి ఇవ్వగల అనుబంధ లోపం.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// ఈ రకమైన విలువను తిరిగి ఇవ్వడానికి స్ట్రింగ్ `s` ను అన్వయించడం.
    ///
    /// పార్సింగ్ విజయవంతమైతే, [`Ok`] లోపల విలువను తిరిగి ఇవ్వండి, లేకపోతే స్ట్రింగ్ తప్పుగా ఆకృతీకరించినప్పుడు లోపలి [`Err`] కు ప్రత్యేకమైన లోపాన్ని తిరిగి ఇవ్వండి.
    /// లోపం రకం trait అమలుకు ప్రత్యేకమైనది.
    ///
    /// # Examples
    ///
    /// [`i32`] తో ప్రాథమిక వినియోగం, `FromStr` ను అమలు చేసే రకం:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// స్ట్రింగ్ నుండి `bool` ను అన్వయించండి.
    ///
    /// `Result<bool, ParseBoolError>` ను ఇస్తుంది, ఎందుకంటే `s` అన్వయించదగినది కాకపోవచ్చు.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// గమనిక, చాలా సందర్భాలలో, `str` లోని `.parse()` పద్ధతి మరింత సరైనది.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}