use crate::iter::FromIterator;

/// ఇరేటర్ నుండి అన్ని యూనిట్ అంశాలను ఒకటిగా కుదించేస్తుంది.
///
/// `Result<(), E>` కు సేకరించడం వంటి ఉన్నత-స్థాయి సంగ్రహణలతో కలిపినప్పుడు ఇది మరింత ఉపయోగకరంగా ఉంటుంది, ఇక్కడ మీరు లోపాలను మాత్రమే పట్టించుకుంటారు:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}