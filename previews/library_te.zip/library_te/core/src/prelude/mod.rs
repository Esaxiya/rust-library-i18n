//! లిబ్కోర్ prelude
//!
//! ఈ మాడ్యూల్ లిబ్‌కోర్ యొక్క వినియోగదారుల కోసం ఉద్దేశించబడింది, ఇవి లిబ్‌స్టాడ్‌కు కూడా లింక్ చేయవు.
//! ప్రామాణిక లైబ్రరీ యొక్క prelude మాదిరిగానే `#![no_std]` ఉపయోగించినప్పుడు ఈ మాడ్యూల్ అప్రమేయంగా దిగుమతి అవుతుంది.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// కోర్ prelude యొక్క 2015 వెర్షన్.
///
/// మరిన్ని కోసం [module-level documentation](self) చూడండి.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// కోర్ prelude యొక్క 2018 వెర్షన్.
///
/// మరిన్ని కోసం [module-level documentation](self) చూడండి.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// కోర్ prelude యొక్క 2021 వెర్షన్.
///
/// మరిన్ని కోసం [module-level documentation](self) చూడండి.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: మరిన్ని విషయాలు జోడించండి.
}