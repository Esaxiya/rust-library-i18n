#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! విదేశీ ఫంక్షన్ ఇంటర్ఫేస్ (FFI) బైండింగ్లకు సంబంధించిన యుటిలిటీస్.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// [pointer] గా ఉపయోగించినప్పుడు C యొక్క `void` రకానికి సమానం.
///
/// సారాంశంలో, `*const c_void` C యొక్క `const void*` కు సమానం మరియు `*mut c_void` C యొక్క `void*` కు సమానం.
/// ఇది C యొక్క `void` రిటర్న్ రకానికి సమానం కాదు, ఇది Rust యొక్క `()` రకం.
///
/// `extern type` స్థిరీకరించబడే వరకు, FFI లో అపారదర్శక రకాలుగా పాయింటర్లను మోడల్ చేయడానికి, ఖాళీ బైట్ శ్రేణి చుట్టూ newtype రేపర్ను ఉపయోగించమని సిఫార్సు చేయబడింది.
///
/// వివరాల కోసం [Nomicon] చూడండి.
///
/// వారు 1.1.0 వరకు పాత Rust కంపైలర్‌కు మద్దతు ఇవ్వాలనుకుంటే `std::os::raw::c_void` ను ఉపయోగించవచ్చు.
/// Rust 1.30.0 తరువాత, ఈ నిర్వచనం ద్వారా ఇది తిరిగి ఎగుమతి చేయబడింది.
/// మరింత సమాచారం కోసం, దయచేసి [RFC 2521] చదవండి.
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, LLVM శూన్య పాయింటర్ రకాన్ని గుర్తించడానికి మరియు malloc() వంటి పొడిగింపు ఫంక్షన్ల ద్వారా, LLVM బిట్‌కోడ్‌లో i8 * గా ప్రాతినిధ్యం వహించాలి.
// ఇక్కడ ఉపయోగించిన ఎనుమ్ దీనిని నిర్ధారిస్తుంది మరియు ప్రైవేట్ వేరియంట్‌లను మాత్రమే కలిగి ఉండటం ద్వారా "raw" రకాన్ని దుర్వినియోగం చేయడాన్ని నిరోధిస్తుంది.
// మాకు రెండు వేరియంట్లు కావాలి, ఎందుకంటే కంపైలర్ రిప్రర్ గుణం గురించి ఫిర్యాదు చేస్తుంది మరియు మనకు కనీసం ఒక వేరియంట్ కావాలి, లేకపోతే ఎనుమ్ జనావాసాలు లేకుండా ఉంటాయి మరియు కనీసం అలాంటి పాయింటర్లను డీఫరెన్సింగ్ చేయడం యుబి అవుతుంది.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// `va_list` యొక్క ప్రాథమిక అమలు.
// ప్రస్తుతానికి `VaListImpl` ను ఉపయోగించి పేరు WIP.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // `'f` కన్నా మార్పు లేదు, కాబట్టి ప్రతి `VaListImpl<'f>` ఆబ్జెక్ట్ అది నిర్వచించిన ఫంక్షన్ యొక్క ప్రాంతంతో ముడిపడి ఉంటుంది
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 `va_list` యొక్క ABI అమలు.
/// మరిన్ని వివరాల కోసం [AArch64 Procedure Call Standard] చూడండి.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC `va_list` యొక్క ABI అమలు.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 `va_list` యొక్క ABI అమలు.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// `va_list` కోసం ఒక రేపర్
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// C యొక్క `va_list` తో బైనరీ-అనుకూలమైన `VaListImpl` ను `VaList` గా మార్చండి.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// C యొక్క `va_list` తో బైనరీ-అనుకూలమైన `VaListImpl` ను `VaList` గా మార్చండి.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait ను పబ్లిక్ ఇంటర్‌ఫేస్‌లలో ఉపయోగించాల్సిన అవసరం ఉంది, అయితే, trait ను ఈ మాడ్యూల్ వెలుపల ఉపయోగించడానికి అనుమతించకూడదు.
// క్రొత్త రకం కోసం trait ను అమలు చేయడానికి వినియోగదారులను అనుమతించడం (తద్వారా va_arg అంతర్గతంగా కొత్త రకంలో ఉపయోగించడానికి అనుమతిస్తుంది) నిర్వచించబడని ప్రవర్తనకు కారణం కావచ్చు.
//
// FIXME(dlrobertson): పబ్లిక్ ఇంటర్‌ఫేస్‌లో VaArgSafe trait ను ఉపయోగించటానికి, అది మరెక్కడా ఉపయోగించబడదని నిర్ధారించుకోవడానికి, trait ఒక ప్రైవేట్ మాడ్యూల్‌లో పబ్లిక్‌గా ఉండాలి.
// ఆర్‌ఎఫ్‌సి 2145 అమలు చేయబడిన తర్వాత దీనిని మెరుగుపరచడం చూడండి.
//
//
//
//
mod sealed_trait {
    /// Trait ఇది అనుమతించబడిన రకాలను [super::VaListImpl::arg] తో ఉపయోగించడానికి అనుమతిస్తుంది.
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// తదుపరి ఆర్గ్‌కు అడ్వాన్స్.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // భద్రత: కాలర్ `va_arg` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి.
        unsafe { va_arg(self) }
    }

    /// ప్రస్తుత స్థానంలో `va_list` ను కాపీ చేస్తుంది.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // భద్రత: కాలర్ `va_end` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // భద్రత: మేము `MaybeUninit` కు వ్రాస్తాము, అందువలన ఇది ప్రారంభించబడింది మరియు `assume_init` చట్టబద్ధమైనది
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: ఇది `va_end` అని పిలవాలి, కానీ దీనికి శుభ్రమైన మార్గం లేదు
        // `drop` ఎల్లప్పుడూ దాని కాలర్‌లోకి ప్రవేశిస్తుందని హామీ ఇస్తుంది, కాబట్టి `va_end` నేరుగా సంబంధిత `va_copy` వలె అదే ఫంక్షన్ నుండి పిలువబడుతుంది.
        // `man va_end` C కి ఇది అవసరమని పేర్కొంది మరియు LLVM ప్రాథమికంగా C సెమాంటిక్స్ను అనుసరిస్తుంది, కాబట్టి `va_end` ఎల్లప్పుడూ `va_copy` వలె అదే ఫంక్షన్ నుండి పిలువబడుతుందని మేము నిర్ధారించుకోవాలి.
        //
        // మరిన్ని వివరాల కోసం, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // ప్రస్తుత ఎల్‌ఎల్‌విఎం లక్ష్యాలపై `va_end` నో-ఆప్ కాబట్టి ఇది ప్రస్తుతానికి పనిచేస్తుంది.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// `va_start` లేదా `va_copy` తో ప్రారంభించిన తర్వాత ఆర్గ్లిస్ట్ `ap` ను నాశనం చేయండి.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// అర్గ్లిస్ట్ `src` యొక్క ప్రస్తుత స్థానాన్ని అర్గ్లిస్ట్ `dst` కు కాపీ చేస్తుంది.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// `va_list` `ap` నుండి `T` రకం యొక్క ఆర్గ్యుమెంట్‌ను లోడ్ చేస్తుంది మరియు వాదన `ap` పాయింట్లకు పెంచండి.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}