use crate::future::Future;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future ను సృష్టిస్తుంది, అది వెంటనే విలువతో సిద్ధంగా ఉంటుంది.
///
/// ఈ `struct` [`ready()`] చే సృష్టించబడింది.
/// మరిన్ని కోసం దాని డాక్యుమెంటేషన్ చూడండి.
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
#[derive(Debug, Clone)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
pub struct Ready<T>(Option<T>);

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
impl<T> Unpin for Ready<T> {}

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
impl<T> Future for Ready<T> {
    type Output = T;

    #[inline]
    fn poll(mut self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<T> {
        Poll::Ready(self.0.take().expect("Ready polled after completion"))
    }
}

/// future ను సృష్టిస్తుంది, అది వెంటనే విలువతో సిద్ధంగా ఉంటుంది.
///
/// ఈ ఫంక్షన్ ద్వారా సృష్టించబడిన Futures క్రియాత్మకంగా `async {}` ద్వారా సృష్టించబడిన వాటికి సమానంగా ఉంటుంది.
/// ప్రధాన వ్యత్యాసం ఏమిటంటే, ఈ ఫంక్షన్ ద్వారా సృష్టించబడిన futures పేరు పెట్టబడింది మరియు `Unpin` ను అమలు చేస్తుంది.
///
/// # Examples
///
/// ```
/// use std::future;
///
/// # async fn run() {
/// let a = future::ready(1);
/// assert_eq!(a.await, 1);
/// # }
/// ```
///
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub fn ready<T>(t: T) -> Ready<T> {
    Ready(Some(t))
}