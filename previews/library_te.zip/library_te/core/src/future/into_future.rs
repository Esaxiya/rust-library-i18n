use crate::future::Future;

/// `Future` లోకి మార్చడం.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// future పూర్తయిన తర్వాత ఉత్పత్తి అవుతుంది.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// మేము దీన్ని ఏ రకమైన future గా మారుస్తున్నాము?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// విలువ నుండి future ను సృష్టిస్తుంది.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}