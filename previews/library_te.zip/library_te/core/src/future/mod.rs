#![stable(feature = "futures_api", since = "1.36.0")]

//! అసమకాలిక విలువలు.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// ఈ రకం అవసరం ఎందుకంటే:
///
/// a) జనరేటర్లు `for<'a, 'b> Generator<&'a mut Context<'b>>` ను అమలు చేయలేవు, కాబట్టి మనం ముడి పాయింటర్‌ను పాస్ చేయాలి (<https://github.com/rust-lang/rust/issues/68923> చూడండి).
///
/// బి) రా పాయింటర్లు మరియు `NonNull` `Send` లేదా `Sync` కాదు, తద్వారా ఇది ప్రతి future non-Send/Sync ను కూడా చేస్తుంది, మరియు మాకు అది అక్కరలేదు.
///
/// ఇది `.await` యొక్క HIR తగ్గించడాన్ని కూడా సులభతరం చేస్తుంది.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// ఒక జెనరేటర్‌ను future లో చుట్టండి.
///
/// ఈ ఫంక్షన్ కింద `GenFuture` ను తిరిగి ఇస్తుంది, కాని మంచి దోష సందేశాలను ఇవ్వడానికి `impl Trait` లో దాచిపెడుతుంది (`GenFuture<[closure.....]>` కాకుండా `impl Future`).
///
// మేము `const async fn` నుండి కోలుకున్న తర్వాత అదనపు లోపాలను నివారించడానికి ఇది `const`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // అంతర్లీన జనరేటర్‌లో స్వీయ-రిఫరెన్షియల్ రుణాలు సృష్టించడానికి async/await futures స్థిరంగా ఉందనే వాస్తవంపై మేము ఆధారపడతాము.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // భద్రత: సురక్షితం ఎందుకంటే మేము !Unpin + !Drop, మరియు ఇది కేవలం ఫీల్డ్ ప్రొజెక్షన్.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // జెనరేటర్‌ను తిరిగి ప్రారంభించండి, `&mut Context` ను `NonNull` ముడి పాయింటర్‌గా మారుస్తుంది.
            // `.await` తగ్గించడం సురక్షితంగా `&mut Context` కి ప్రసారం చేస్తుంది.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // భద్రత: `cx.0` చెల్లుబాటు అయ్యే పాయింటర్ అని కాలర్ హామీ ఇవ్వాలి
    // ఇది మార్చగల సూచన కోసం అన్ని అవసరాలను నెరవేరుస్తుంది.
    unsafe { &mut *cx.0.as_ptr().cast() }
}