#![stable(feature = "duration_core", since = "1.25.0")]

//! తాత్కాలిక పరిమాణం.
//!
//! Example:
//!
//! ```
//! use std::time::Duration;
//!
//! let five_seconds = Duration::new(5, 0);
//! // రెండు ప్రకటనలు సమానం
//! assert_eq!(Duration::new(5, 0), Duration::from_secs(5));
//! ```

use crate::fmt;
use crate::iter::Sum;
use crate::ops::{Add, AddAssign, Div, DivAssign, Mul, MulAssign, Sub, SubAssign};

const NANOS_PER_SEC: u32 = 1_000_000_000;
const NANOS_PER_MILLI: u32 = 1_000_000;
const NANOS_PER_MICRO: u32 = 1_000;
const MILLIS_PER_SEC: u64 = 1_000;
const MICROS_PER_SEC: u64 = 1_000_000;

/// సమయ వ్యవధిని సూచించడానికి `Duration` రకం, సాధారణంగా సిస్టమ్ సమయం ముగిసే సమయానికి ఉపయోగిస్తారు.
///
/// ప్రతి `Duration` మొత్తం సెకన్ల సంఖ్యతో మరియు నానోసెకన్లలో ప్రాతినిధ్యం వహించే పాక్షిక భాగాన్ని కలిగి ఉంటుంది.
/// అంతర్లీన వ్యవస్థ నానోసెకండ్-స్థాయి ఖచ్చితత్వానికి మద్దతు ఇవ్వకపోతే, సిస్టమ్ సమయం ముగిసే API లు సాధారణంగా నానోసెకన్ల సంఖ్యను చుట్టుముడుతుంది.
///
/// [`వ్యవధి] [`Add`], [`Sub`] మరియు ఇతర [`ops`] traits తో సహా అనేక సాధారణ traits ను అమలు చేస్తాయి.ఇది సున్నా-పొడవు `Duration` ను తిరిగి ఇవ్వడం ద్వారా [`Default`] ను అమలు చేస్తుంది.
///
/// [`ops`]: crate::ops
///
/// # Examples
///
/// ```
/// use std::time::Duration;
///
/// let five_seconds = Duration::new(5, 0);
/// let five_seconds_and_five_nanos = five_seconds + Duration::new(0, 5);
///
/// assert_eq!(five_seconds_and_five_nanos.as_secs(), 5);
/// assert_eq!(five_seconds_and_five_nanos.subsec_nanos(), 5);
///
/// let ten_millis = Duration::from_millis(10);
/// ```
///
/// # `Duration` విలువలను ఆకృతీకరిస్తోంది
///
/// `Duration` ఉద్దేశపూర్వకంగా `Display` ఇంప్ల్ లేదు, ఎందుకంటే మానవ రీడబిలిటీ కోసం సమయ వ్యవధిని ఫార్మాట్ చేయడానికి వివిధ మార్గాలు ఉన్నాయి.
/// `Duration` విలువ యొక్క పూర్తి ఖచ్చితత్వాన్ని చూపించే `Debug` impl ను అందిస్తుంది.
///
/// `Debug` అవుట్పుట్ మైక్రోసెకన్ల కొరకు ASCII కాని "µs" ప్రత్యయాన్ని ఉపయోగిస్తుంది.
/// మీ ప్రోగ్రామ్ అవుట్పుట్ పూర్తి యూనికోడ్ అనుకూలతపై ఆధారపడలేని సందర్భాలలో కనిపిస్తే, మీరు `Duration` వస్తువులను మీరే ఫార్మాట్ చేయాలనుకోవచ్చు లేదా అలా చేయడానికి crate ను ఉపయోగించవచ్చు.
///
///
///
///
///
///
///
#[stable(feature = "duration", since = "1.3.0")]
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Default)]
pub struct Duration {
    secs: u64,
    nanos: u32, // ఎల్లప్పుడూ 0 <=నానోలు <NANOS_PER_SEC
}

impl Duration {
    /// ఒక సెకను వ్యవధి.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::SECOND, Duration::from_secs(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const SECOND: Duration = Duration::from_secs(1);

    /// ఒక మిల్లీసెకన్ల వ్యవధి.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MILLISECOND, Duration::from_millis(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MILLISECOND: Duration = Duration::from_millis(1);

    /// ఒక మైక్రోసెకండ్ వ్యవధి.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MICROSECOND, Duration::from_micros(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MICROSECOND: Duration = Duration::from_micros(1);

    /// ఒక నానోసెకండ్ వ్యవధి.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::NANOSECOND, Duration::from_nanos(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const NANOSECOND: Duration = Duration::from_nanos(1);

    /// సున్నా సమయం యొక్క వ్యవధి.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// let duration = Duration::ZERO;
    /// assert!(duration.is_zero());
    /// assert_eq!(duration.as_nanos(), 0);
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    pub const ZERO: Duration = Duration::from_nanos(0);

    /// గరిష్ట వ్యవధి.
    ///
    /// ఇది సుమారు 584,942,417,355 సంవత్సరాల కాలానికి సమానం.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MAX, Duration::new(u64::MAX, 1_000_000_000 - 1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MAX: Duration = Duration::new(u64::MAX, NANOS_PER_SEC - 1);

    /// పేర్కొన్న మొత్తం సెకన్లు మరియు అదనపు నానోసెకన్ల నుండి క్రొత్త `Duration` ను సృష్టిస్తుంది.
    ///
    /// నానోసెకన్ల సంఖ్య 1 బిలియన్ కంటే ఎక్కువగా ఉంటే (సెకనులో నానోసెకన్ల సంఖ్య), అది అందించిన సెకన్లలోకి వెళుతుంది.
    ///
    ///
    /// # Panics
    ///
    /// నానోసెకన్ల నుండి క్యారీ సెకన్ల కౌంటర్లో పొంగిపోతే ఈ కన్స్ట్రక్టర్ panic అవుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let five_seconds = Duration::new(5, 0);
    /// ```
    ///
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn new(secs: u64, nanos: u32) -> Duration {
        let secs = match secs.checked_add((nanos / NANOS_PER_SEC) as u64) {
            Some(secs) => secs,
            None => panic!("overflow in Duration::new"),
        };
        let nanos = nanos % NANOS_PER_SEC;
        Duration { secs, nanos }
    }

    /// పేర్కొన్న మొత్తం సెకన్ల నుండి క్రొత్త `Duration` ను సృష్టిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_secs(5);
    ///
    /// assert_eq!(5, duration.as_secs());
    /// assert_eq!(0, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_secs(secs: u64) -> Duration {
        Duration { secs, nanos: 0 }
    }

    /// పేర్కొన్న మిల్లీసెకన్ల నుండి కొత్త `Duration` ను సృష్టిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(2569);
    ///
    /// assert_eq!(2, duration.as_secs());
    /// assert_eq!(569_000_000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_millis(millis: u64) -> Duration {
        Duration {
            secs: millis / MILLIS_PER_SEC,
            nanos: ((millis % MILLIS_PER_SEC) as u32) * NANOS_PER_MILLI,
        }
    }

    /// పేర్కొన్న మైక్రోసెకన్ల సంఖ్య నుండి కొత్త `Duration` ను సృష్టిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_000_002);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(2000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_from_micros", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_micros(micros: u64) -> Duration {
        Duration {
            secs: micros / MICROS_PER_SEC,
            nanos: ((micros % MICROS_PER_SEC) as u32) * NANOS_PER_MICRO,
        }
    }

    /// పేర్కొన్న నానోసెకన్ల నుండి క్రొత్త `Duration` ను సృష్టిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_nanos(1_000_000_123);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(123, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_nanos(nanos: u64) -> Duration {
        Duration {
            secs: nanos / (NANOS_PER_SEC as u64),
            nanos: (nanos % (NANOS_PER_SEC as u64)) as u32,
        }
    }

    /// ఈ `Duration` సమయం లేకపోతే నిజం అవుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert!(Duration::ZERO.is_zero());
    /// assert!(Duration::new(0, 0).is_zero());
    /// assert!(Duration::from_nanos(0).is_zero());
    /// assert!(Duration::from_secs(0).is_zero());
    ///
    /// assert!(!Duration::new(1, 1).is_zero());
    /// assert!(!Duration::from_nanos(1).is_zero());
    /// assert!(!Duration::from_secs(1).is_zero());
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    #[inline]
    pub const fn is_zero(&self) -> bool {
        self.secs == 0 && self.nanos == 0
    }

    /// ఈ `Duration` కలిగి ఉన్న _whole_ సెకన్ల సంఖ్యను అందిస్తుంది.
    ///
    /// తిరిగి వచ్చిన విలువ వ్యవధి యొక్క పాక్షిక (nanosecond) భాగాన్ని కలిగి ఉండదు, ఇది [`subsec_nanos`] ఉపయోగించి పొందవచ్చు.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_secs(), 5);
    /// ```
    ///
    /// `Duration` ప్రాతినిధ్యం వహిస్తున్న మొత్తం సెకన్ల సంఖ్యను నిర్ణయించడానికి, [`subsec_nanos`] తో కలిపి `as_secs` ని ఉపయోగించండి:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    ///
    /// assert_eq!(5.730023852,
    ///            duration.as_secs() as f64
    ///            + duration.subsec_nanos() as f64 * 1e-9);
    /// ```
    ///
    /// [`subsec_nanos`]: Duration::subsec_nanos
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn as_secs(&self) -> u64 {
        self.secs
    }

    /// ఈ `Duration` యొక్క పాక్షిక భాగాన్ని మొత్తం మిల్లీసెకన్లలో అందిస్తుంది.
    ///
    /// ఈ పద్ధతి మిల్లీసెకన్ల ద్వారా ప్రాతినిధ్యం వహించినప్పుడు వ్యవధి యొక్క పొడవును ** తిరిగి ఇవ్వదు.
    /// తిరిగి వచ్చిన సంఖ్య ఎల్లప్పుడూ సెకనులో పాక్షిక భాగాన్ని సూచిస్తుంది (అనగా ఇది వెయ్యి కన్నా తక్కువ).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5432);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_millis(), 432);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_millis(&self) -> u32 {
        self.nanos / NANOS_PER_MILLI
    }

    /// ఈ `Duration` యొక్క పాక్షిక భాగాన్ని మొత్తం మైక్రోసెకన్లలో అందిస్తుంది.
    ///
    /// ఈ పద్ధతి మైక్రోసెకన్ల ద్వారా ప్రాతినిధ్యం వహించినప్పుడు వ్యవధి యొక్క పొడవును ** తిరిగి ఇవ్వదు.
    /// తిరిగి వచ్చిన సంఖ్య ఎల్లప్పుడూ సెకనులో పాక్షిక భాగాన్ని సూచిస్తుంది (అనగా ఇది ఒక మిలియన్ కన్నా తక్కువ).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_234_567);
    /// assert_eq!(duration.as_secs(), 1);
    /// assert_eq!(duration.subsec_micros(), 234_567);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_micros(&self) -> u32 {
        self.nanos / NANOS_PER_MICRO
    }

    /// ఈ `Duration` యొక్క పాక్షిక భాగాన్ని నానోసెకన్లలో అందిస్తుంది.
    ///
    /// ఈ పద్ధతి నానోసెకన్ల ద్వారా ప్రాతినిధ్యం వహించినప్పుడు వ్యవధి యొక్క పొడవును ** తిరిగి ఇవ్వదు.
    /// తిరిగి వచ్చిన సంఖ్య ఎల్లప్పుడూ సెకనులో పాక్షిక భాగాన్ని సూచిస్తుంది (అనగా ఇది ఒక బిలియన్ కన్నా తక్కువ).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5010);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_nanos(), 10_000_000);
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn subsec_nanos(&self) -> u32 {
        self.nanos
    }

    /// ఈ `Duration` కలిగి ఉన్న మొత్తం మిల్లీసెకన్ల సంఖ్యను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_millis(), 5730);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_millis(&self) -> u128 {
        self.secs as u128 * MILLIS_PER_SEC as u128 + (self.nanos / NANOS_PER_MILLI) as u128
    }

    /// ఈ `Duration` కలిగి ఉన్న మొత్తం మైక్రోసెకన్ల సంఖ్యను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_micros(), 5730023);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_micros(&self) -> u128 {
        self.secs as u128 * MICROS_PER_SEC as u128 + (self.nanos / NANOS_PER_MICRO) as u128
    }

    /// ఈ `Duration` కలిగి ఉన్న మొత్తం నానోసెకన్ల సంఖ్యను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_nanos(), 5730023852);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_nanos(&self) -> u128 {
        self.secs as u128 * NANOS_PER_SEC as u128 + self.nanos as u128
    }

    /// `Duration` అదనంగా తనిఖీ చేయబడింది.
    /// `self + other` ను లెక్కిస్తుంది, ఓవర్ఫ్లో సంభవించినట్లయితే [`None`] ను తిరిగి ఇస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).checked_add(Duration::new(0, 1)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(1, 0).checked_add(Duration::new(u64::MAX, 0)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_add(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_add(rhs.secs) {
            let mut nanos = self.nanos + rhs.nanos;
            if nanos >= NANOS_PER_SEC {
                nanos -= NANOS_PER_SEC;
                if let Some(new_secs) = secs.checked_add(1) {
                    secs = new_secs;
                } else {
                    return None;
                }
            }
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// `Duration` అదనంగా సంతృప్తమవుతుంది.
    /// `self + other` ను లెక్కిస్తుంది, ఓవర్ఫ్లో సంభవించినట్లయితే [`Duration::MAX`] ను తిరిగి ఇస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).saturating_add(Duration::new(0, 1)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(1, 0).saturating_add(Duration::new(u64::MAX, 0)), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_add(self, rhs: Duration) -> Duration {
        match self.checked_add(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// `Duration` వ్యవకలనం తనిఖీ చేయబడింది.
    /// `self - other` ను లెక్కిస్తుంది, ఫలితం ప్రతికూలంగా ఉంటే లేదా ఓవర్ఫ్లో సంభవించినట్లయితే [`None`] ను తిరిగి ఇస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).checked_sub(Duration::new(0, 0)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(0, 0).checked_sub(Duration::new(0, 1)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_sub(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_sub(rhs.secs) {
            let nanos = if self.nanos >= rhs.nanos {
                self.nanos - rhs.nanos
            } else {
                if let Some(sub_secs) = secs.checked_sub(1) {
                    secs = sub_secs;
                    self.nanos + NANOS_PER_SEC - rhs.nanos
                } else {
                    return None;
                }
            };
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// సంతృప్త `Duration` వ్యవకలనం.
    /// `self - other` ను లెక్కిస్తుంది, ఫలితం ప్రతికూలంగా ఉంటే లేదా ఓవర్ఫ్లో సంభవించినట్లయితే [`Duration::ZERO`] ను తిరిగి ఇస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).saturating_sub(Duration::new(0, 0)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(0, 0).saturating_sub(Duration::new(0, 1)), Duration::ZERO);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_sub(self, rhs: Duration) -> Duration {
        match self.checked_sub(rhs) {
            Some(res) => res,
            None => Duration::ZERO,
        }
    }

    /// `Duration` గుణకారం తనిఖీ చేయబడింది.
    /// `self * other` ను లెక్కిస్తుంది, ఓవర్ఫ్లో సంభవించినట్లయితే [`None`] ను తిరిగి ఇస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).checked_mul(2), Some(Duration::new(1, 2)));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).checked_mul(2), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_mul(self, rhs: u32) -> Option<Duration> {
        // నానోసెకన్లను u64 గా గుణించండి, ఎందుకంటే అది ఆ విధంగా పొంగిపోదు.
        let total_nanos = self.nanos as u64 * rhs as u64;
        let extra_secs = total_nanos / (NANOS_PER_SEC as u64);
        let nanos = (total_nanos % (NANOS_PER_SEC as u64)) as u32;
        if let Some(s) = self.secs.checked_mul(rhs as u64) {
            if let Some(secs) = s.checked_add(extra_secs) {
                debug_assert!(nanos < NANOS_PER_SEC);
                return Some(Duration { secs, nanos });
            }
        }
        None
    }

    /// సంతృప్త `Duration` గుణకారం.
    /// `self * other` ను లెక్కిస్తుంది, ఓవర్ఫ్లో సంభవించినట్లయితే [`Duration::MAX`] ను తిరిగి ఇస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).saturating_mul(2), Duration::new(1, 2));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).saturating_mul(2), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_mul(self, rhs: u32) -> Duration {
        match self.checked_mul(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// `Duration` విభాగాన్ని తనిఖీ చేశారు.
    /// `self / other` ను లెక్కిస్తుంది, `other == 0` ఉంటే [`None`] ను తిరిగి ఇస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(2, 0).checked_div(2), Some(Duration::new(1, 0)));
    /// assert_eq!(Duration::new(1, 0).checked_div(2), Some(Duration::new(0, 500_000_000)));
    /// assert_eq!(Duration::new(2, 0).checked_div(0), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_div(self, rhs: u32) -> Option<Duration> {
        if rhs != 0 {
            let secs = self.secs / (rhs as u64);
            let carry = self.secs - secs * (rhs as u64);
            let extra_nanos = carry * (NANOS_PER_SEC as u64) / (rhs as u64);
            let nanos = self.nanos / rhs + (extra_nanos as u32);
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// ఈ `Duration` కలిగి ఉన్న సెకన్ల సంఖ్యను `f64` గా అందిస్తుంది.
    /// తిరిగి వచ్చిన విలువ వ్యవధి యొక్క పాక్షిక (nanosecond) భాగాన్ని కలిగి ఉంటుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f64(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f64(&self) -> f64 {
        (self.secs as f64) + (self.nanos as f64) / (NANOS_PER_SEC as f64)
    }

    /// ఈ `Duration` కలిగి ఉన్న సెకన్ల సంఖ్యను `f32` గా అందిస్తుంది.
    /// తిరిగి వచ్చిన విలువ వ్యవధి యొక్క పాక్షిక (nanosecond) భాగాన్ని కలిగి ఉంటుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f32(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f32(&self) -> f32 {
        (self.secs as f32) + (self.nanos as f32) / (NANOS_PER_SEC as f32)
    }

    /// `f64` గా సూచించబడిన నిర్దిష్ట సెకన్ల సంఖ్య నుండి క్రొత్త `Duration` ను సృష్టిస్తుంది.
    ///
    /// # Panics
    /// `secs` పరిమితంగా, ప్రతికూలంగా లేదా `Duration` పొంగిపొర్లుతున్నట్లయితే ఈ కన్స్ట్రక్టర్ panic అవుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f64(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f64(secs: f64) -> Duration {
        const MAX_NANOS_F64: f64 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f64;
        let nanos = secs * (NANOS_PER_SEC as f64);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F64 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// `f32` గా సూచించబడిన నిర్దిష్ట సెకన్ల సంఖ్య నుండి క్రొత్త `Duration` ను సృష్టిస్తుంది.
    ///
    /// # Panics
    /// `secs` పరిమితంగా, ప్రతికూలంగా లేదా `Duration` పొంగిపొర్లుతున్నట్లయితే ఈ కన్స్ట్రక్టర్ panic అవుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f32(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f32(secs: f32) -> Duration {
        const MAX_NANOS_F32: f32 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f32;
        let nanos = secs * (NANOS_PER_SEC as f32);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F32 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// `f64` ద్వారా `Duration` గుణించాలి.
    /// # Panics
    /// ఫలితం పరిమితంగా, ప్రతికూలంగా లేదా `Duration` పొంగిపొర్లుతున్నట్లయితే ఈ పద్ధతి panic అవుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.mul_f64(3.14), Duration::new(8, 478_000_000));
    /// assert_eq!(dur.mul_f64(3.14e5), Duration::new(847_800, 0));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(rhs * self.as_secs_f64())
    }

    /// `f32` ద్వారా `Duration` గుణించాలి.
    /// # Panics
    /// ఫలితం పరిమితంగా, ప్రతికూలంగా లేదా `Duration` పొంగిపొర్లుతున్నట్లయితే ఈ పద్ధతి panic అవుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // రౌండింగ్ లోపాల కారణంగా ఫలితం 8.478 మరియు 847800.0 నుండి కొద్దిగా భిన్నంగా ఉంటుందని గమనించండి
    /////
    /// assert_eq!(dur.mul_f32(3.14), Duration::new(8, 478_000_640));
    /// assert_eq!(dur.mul_f32(3.14e5), Duration::new(847799, 969_120_256));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(rhs * self.as_secs_f32())
    }

    /// `Duration` ను `f64` ద్వారా విభజించండి.
    /// # Panics
    /// ఫలితం పరిమితంగా, ప్రతికూలంగా లేదా `Duration` పొంగిపొర్లుతున్నట్లయితే ఈ పద్ధతి panic అవుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.div_f64(3.14), Duration::new(0, 859_872_611));
    /// // కత్తిరించడం ఉపయోగించబడుతుందని గమనించండి, చుట్టుముట్టడం కాదు
    /// assert_eq!(dur.div_f64(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(self.as_secs_f64() / rhs)
    }

    /// `Duration` ను `f32` ద్వారా విభజించండి.
    /// # Panics
    /// ఫలితం పరిమితంగా, ప్రతికూలంగా లేదా `Duration` పొంగిపొర్లుతున్నట్లయితే ఈ పద్ధతి panic అవుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // రౌండింగ్ లోపాల కారణంగా 0.859_872_611 నుండి కొద్దిగా భిన్నంగా ఉంటుందని గమనించండి
    /////
    /// assert_eq!(dur.div_f32(3.14), Duration::new(0, 859_872_576));
    /// // కత్తిరించడం ఉపయోగించబడుతుందని గమనించండి, చుట్టుముట్టడం కాదు
    /// assert_eq!(dur.div_f32(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(self.as_secs_f32() / rhs)
    }

    /// `Duration` ను `Duration` ద్వారా విభజించి, `f64` ను తిరిగి ఇవ్వండి.
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f64(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f64(self, rhs: Duration) -> f64 {
        self.as_secs_f64() / rhs.as_secs_f64()
    }

    /// `Duration` ను `Duration` ద్వారా విభజించి, `f32` ను తిరిగి ఇవ్వండి.
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f32(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f32(self, rhs: Duration) -> f32 {
        self.as_secs_f32() / rhs.as_secs_f32()
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Add for Duration {
    type Output = Duration;

    fn add(self, rhs: Duration) -> Duration {
        self.checked_add(rhs).expect("overflow when adding durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl AddAssign for Duration {
    fn add_assign(&mut self, rhs: Duration) {
        *self = *self + rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Sub for Duration {
    type Output = Duration;

    fn sub(self, rhs: Duration) -> Duration {
        self.checked_sub(rhs).expect("overflow when subtracting durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl SubAssign for Duration {
    fn sub_assign(&mut self, rhs: Duration) {
        *self = *self - rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Mul<u32> for Duration {
    type Output = Duration;

    fn mul(self, rhs: u32) -> Duration {
        self.checked_mul(rhs).expect("overflow when multiplying duration by scalar")
    }
}

#[stable(feature = "symmetric_u32_duration_mul", since = "1.31.0")]
impl Mul<Duration> for u32 {
    type Output = Duration;

    fn mul(self, rhs: Duration) -> Duration {
        rhs * self
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl MulAssign<u32> for Duration {
    fn mul_assign(&mut self, rhs: u32) {
        *self = *self * rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Div<u32> for Duration {
    type Output = Duration;

    fn div(self, rhs: u32) -> Duration {
        self.checked_div(rhs).expect("divide by zero error when dividing duration by scalar")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl DivAssign<u32> for Duration {
    fn div_assign(&mut self, rhs: u32) {
        *self = *self / rhs;
    }
}

macro_rules! sum_durations {
    ($iter:expr) => {{
        let mut total_secs: u64 = 0;
        let mut total_nanos: u64 = 0;

        for entry in $iter {
            total_secs =
                total_secs.checked_add(entry.secs).expect("overflow in iter::sum over durations");
            total_nanos = match total_nanos.checked_add(entry.nanos as u64) {
                Some(n) => n,
                None => {
                    total_secs = total_secs
                        .checked_add(total_nanos / NANOS_PER_SEC as u64)
                        .expect("overflow in iter::sum over durations");
                    (total_nanos % NANOS_PER_SEC as u64) + entry.nanos as u64
                }
            };
        }
        total_secs = total_secs
            .checked_add(total_nanos / NANOS_PER_SEC as u64)
            .expect("overflow in iter::sum over durations");
        total_nanos = total_nanos % NANOS_PER_SEC as u64;
        Duration { secs: total_secs, nanos: total_nanos as u32 }
    }};
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl Sum for Duration {
    fn sum<I: Iterator<Item = Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl<'a> Sum<&'a Duration> for Duration {
    fn sum<I: Iterator<Item = &'a Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_debug_impl", since = "1.27.0")]
impl fmt::Debug for Duration {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        /// దశాంశ సంజ్ఞామానంలో ఫ్లోటింగ్ పాయింట్ సంఖ్యను ఫార్మాట్ చేస్తుంది.
        ///
        /// సంఖ్య `integer_part` మరియు పాక్షిక భాగంగా ఇవ్వబడింది.
        /// పాక్షిక భాగం యొక్క విలువ `fractional_part / divisor`.
        /// కాబట్టి `integer_part` =3, `fractional_part` =12 మరియు `divisor` =100 `3.012` సంఖ్యను సూచిస్తాయి.
        /// వెనుకంజలో ఉన్న సున్నాలు తొలగించబడతాయి.
        ///
        /// `divisor` 100_000_000 పైన ఉండకూడదు.
        /// ఇది కూడా 10 యొక్క శక్తిగా ఉండాలి, మిగతా వాటికి అర్ధమే లేదు.
        /// `fractional_part` `10 * divisor` కన్నా తక్కువ ఉండాలి!
        fn fmt_decimal(
            f: &mut fmt::Formatter<'_>,
            mut integer_part: u64,
            mut fractional_part: u32,
            mut divisor: u32,
        ) -> fmt::Result {
            // పాక్షిక భాగాన్ని తాత్కాలిక బఫర్‌లోకి ఎన్కోడ్ చేయండి.
            // బఫర్ 9 మూలకాలను మాత్రమే కలిగి ఉండాలి, ఎందుకంటే `fractional_part` 10 ^ 9 కన్నా చిన్నదిగా ఉండాలి.
            //
            // దిగువ కోడ్‌ను సరళీకృతం చేయడానికి బఫర్ '0' అంకెలతో నింపబడి ఉంటుంది.
            let mut buf = [b'0'; 9];

            // తదుపరి అంకె ఈ స్థానంలో వ్రాయబడుతుంది
            let mut pos = 0;

            // సున్నా కాని అంకెలు మిగిలి ఉండగానే మేము బఫర్‌లో అంకెలు వ్రాస్తూనే ఉన్నాము మరియు మేము ఇంకా తగినంత అంకెలు వ్రాయలేదు.
            //
            while fractional_part > 0 && pos < f.precision().unwrap_or(9) {
                // బఫర్‌లో కొత్త అంకెను వ్రాయండి
                buf[pos] = b'0' + (fractional_part / divisor) as u8;

                fractional_part %= divisor;
                divisor /= 10;
                pos += 1;
            }

            // ఖచ్చితత్వం <9 పేర్కొనబడితే, బఫర్‌లో వ్రాయబడని కొన్ని సున్నా కాని అంకెలు మిగిలి ఉండవచ్చు.
            // అలాంటప్పుడు సాధారణ ఫ్లోటింగ్ పాయింట్ సంఖ్యలను ముద్రించే అర్థాలకు సరిపోయేలా మేము రౌండింగ్ చేయాలి.
            // అయితే, మేము చుట్టుముట్టేటప్పుడు మాత్రమే పని చేయాలి.
            // మిగిలిన వాటి యొక్క మొదటి అంకె>=5 అయితే ఇది జరుగుతుంది.
            //
            //
            if fractional_part > 0 && fractional_part >= divisor * 5 {
                // బఫర్‌లో ఉన్న సంఖ్యను రౌండ్ అప్ చేయండి.
                // మేము బఫర్ గుండా వెనుకకు వెళ్లి క్యారీని ట్రాక్ చేస్తాము.
                let mut rev_pos = pos;
                let mut carry = true;
                while carry && rev_pos > 0 {
                    rev_pos -= 1;

                    // బఫర్‌లోని అంకె '9' కాకపోతే, మేము దానిని పెంచాలి మరియు ఆగిపోవచ్చు (మనకు ఇకపై క్యారీ లేనందున).
                    // లేకపోతే, మేము దానిని '0' (overflow) కు సెట్ చేసి కొనసాగిస్తాము.
                    //
                    //
                    if buf[rev_pos] < b'9' {
                        buf[rev_pos] += 1;
                        carry = false;
                    } else {
                        buf[rev_pos] = b'0';
                    }
                }

                // మనకు ఇంకా క్యారీ బిట్ సెట్ ఉంటే, అంటే మేము మొత్తం బఫర్‌ను '0'లకు సెట్ చేసాము మరియు పూర్ణాంక భాగాన్ని పెంచాలి.
                //
                //
                if carry {
                    integer_part += 1;
                }
            }

            // బఫర్ ముగింపును నిర్ణయించండి: ఖచ్చితత్వం సెట్ చేయబడితే, మేము బఫర్ నుండి చాలా అంకెలను ఉపయోగిస్తాము (9 కి పరిమితం చేయబడింది).
            // ఇది సెట్ చేయకపోతే, చివరి సున్నా కానిది వరకు మేము అన్ని అంకెలను మాత్రమే ఉపయోగిస్తాము.
            //
            let end = f.precision().map(|p| crate::cmp::min(p, 9)).unwrap_or(pos);

            // మేము ఒక భిన్న అంకెను విడుదల చేయకపోతే మరియు ఖచ్చితత్వం సున్నా కాని విలువకు సెట్ చేయకపోతే, మేము దశాంశ బిందువును ముద్రించము.
            //
            if end == 0 {
                write!(f, "{}", integer_part)
            } else {
                // భద్రత: మేము ASCII అంకెలను మాత్రమే బఫర్‌లో వ్రాస్తున్నాము మరియు అది
                // '0 లతో ప్రారంభించబడింది, కాబట్టి ఇది చెల్లుబాటు అయ్యే UTF8 ను కలిగి ఉంటుంది.
                let s = unsafe { crate::str::from_utf8_unchecked(&buf[..end]) };

                // వినియోగదారు ఖచ్చితత్వం> 9 ని అభ్యర్థిస్తే, మేము చివరిలో ప్యాడ్ '0.
                let w = f.precision().unwrap_or(pos);
                write!(f, "{}.{:0<width$}", integer_part, s, width = w)
            }
        }

        // అభ్యర్థించినట్లయితే ప్రముఖ '+' గుర్తును ముద్రించండి
        if f.sign_plus() {
            write!(f, "+")?;
        }

        if self.secs > 0 {
            fmt_decimal(f, self.secs, self.nanos, NANOS_PER_SEC / 10)?;
            f.write_str("s")
        } else if self.nanos >= NANOS_PER_MILLI {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MILLI) as u64,
                self.nanos % NANOS_PER_MILLI,
                NANOS_PER_MILLI / 10,
            )?;
            f.write_str("ms")
        } else if self.nanos >= NANOS_PER_MICRO {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MICRO) as u64,
                self.nanos % NANOS_PER_MICRO,
                NANOS_PER_MICRO / 10,
            )?;
            f.write_str("µs")
        } else {
            fmt_decimal(f, self.nanos as u64, 0, 1)?;
            f.write_str("ns")
        }
    }
}