/// `?` ఆపరేటర్ యొక్క ప్రవర్తనను అనుకూలీకరించడానికి trait.
///
/// `Try` ను అమలు చేసే రకం success/failure డైకోటోమి పరంగా చూడటానికి కానానికల్ మార్గాన్ని కలిగి ఉంది.
/// ఈ trait ఇప్పటికే ఉన్న ఉదాహరణ నుండి ఆ విజయం లేదా వైఫల్య విలువలను సంగ్రహించడానికి మరియు విజయం లేదా వైఫల్య విలువ నుండి క్రొత్త ఉదాహరణను సృష్టించడానికి అనుమతిస్తుంది.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// విజయవంతంగా చూసినప్పుడు ఈ విలువ రకం.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// విఫలమైనప్పుడు చూసినప్పుడు ఈ విలువ రకం.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// "?" ఆపరేటర్‌ను వర్తింపజేస్తుంది.`Ok(t)` యొక్క తిరిగి రావడం అంటే అమలు సాధారణంగా కొనసాగాలి, మరియు `?` యొక్క ఫలితం `t` విలువ.
    /// `Err(e)` యొక్క తిరిగి రావడం అంటే అమలు branch ను లోపలి భాగంలో ఉన్న `catch` కి జతచేయాలి లేదా ఫంక్షన్ నుండి తిరిగి రావాలి.
    ///
    /// ఒక `Err(e)` ఫలితం తిరిగి ఇవ్వబడితే, పరివేష్టిత పరిధి యొక్క రిటర్న్ రకంలో `e` విలువ "wrapped" అవుతుంది (ఇది `Try` ను తప్పక అమలు చేయాలి).
    ///
    /// ప్రత్యేకంగా, `X::from_error(From::from(e))` విలువ తిరిగి ఇవ్వబడుతుంది, ఇక్కడ `X` అనేది ఎన్క్లోజింగ్ ఫంక్షన్ యొక్క రిటర్న్ రకం.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// మిశ్రమ ఫలితాన్ని నిర్మించడానికి లోపం విలువను చుట్టండి.
    /// ఉదాహరణకు, `Result::Err(x)` మరియు `Result::from_error(x)` సమానం.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// మిశ్రమ ఫలితాన్ని నిర్మించడానికి సరే విలువను చుట్టండి.
    /// ఉదాహరణకు, `Result::Ok(x)` మరియు `Result::from_ok(x)` సమానం.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}