use crate::marker::Unsize;

/// Trait ఇది ఒక పాయింటర్ లేదా ఒకదానికి రేపర్ అని సూచిస్తుంది, ఇక్కడ పాయింటీలో పరిమాణాన్ని తగ్గించవచ్చు.
///
/// మరిన్ని వివరాల కోసం [DST coercion RFC][dst-coerce] మరియు [the nomicon entry on coercion][nomicon-coerce] చూడండి.
///
/// అంతర్నిర్మిత పాయింటర్ రకాలు కోసం, సన్నని పాయింటర్ నుండి కొవ్వు పాయింటర్‌గా మార్చడం ద్వారా `T: Unsize<U>` ఉంటే `T` కు పాయింటర్లు `U` కు పాయింటర్లను బలవంతం చేస్తాయి.
///
/// అనుకూల రకాలు కోసం, ఇక్కడ బలవంతం `Foo<T>` ను `Foo<U>` కు బలవంతం చేయడం ద్వారా పనిచేస్తుంది.
/// `Foo<T>` లో `T` పాల్గొన్న ఒకే నాన్-ఫాంటమ్‌డేటా ఫీల్డ్ ఉంటే మాత్రమే ఇటువంటి impl వ్రాయబడుతుంది.
/// ఆ ఫీల్డ్ యొక్క రకం `Bar<T>` అయితే, `CoerceUnsized<Bar<U>> for Bar<T>` యొక్క అమలు తప్పనిసరిగా ఉండాలి.
/// `Bar<T>` ఫీల్డ్‌ను `Bar<U>` లోకి బలవంతం చేయడం ద్వారా మరియు `Foo<U>` ను సృష్టించడానికి `Foo<T>` నుండి మిగిలిన ఫీల్డ్‌లను నింపడం ద్వారా బలవంతం పనిచేస్తుంది.
/// ఇది పాయింటర్ ఫీల్డ్‌కు సమర్థవంతంగా క్రిందికి రంధ్రం చేస్తుంది మరియు దానిని బలవంతం చేస్తుంది.
///
/// సాధారణంగా, స్మార్ట్ పాయింటర్ల కోసం మీరు `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` ను అమలు చేస్తారు, ఐచ్ఛిక `?Sized` `T` లోనే ఉంటుంది.
/// `Cell<T>` మరియు `RefCell<T>` వంటి `T` ని నేరుగా పొందుపరిచే రేపర్ రకాల కోసం, మీరు నేరుగా `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` ను అమలు చేయవచ్చు.
///
/// ఇది `Cell<Box<T>>` వంటి రకాలను బలవంతం చేయడానికి అనుమతిస్తుంది.
///
/// [`Unsize`][unsize] పాయింటర్ల వెనుక ఉంటే DST లకు బలవంతం చేయగల రకాలను గుర్తించడానికి ఉపయోగిస్తారు.ఇది కంపైలర్ చేత స్వయంచాలకంగా అమలు చేయబడుతుంది.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut టి-> * మ్యూట్ యు
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *మ్యూట్ టి->* మ్యూట్ యు
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// ఒక పద్ధతి యొక్క రిసీవర్ రకాన్ని పంపించవచ్చో తనిఖీ చేయడానికి ఇది వస్తువు భద్రత కోసం ఉపయోగించబడుతుంది.
///
/// trait యొక్క ఉదాహరణ అమలు:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U.
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U.
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *మ్యూట్ టి->* మ్యూట్ యు
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}