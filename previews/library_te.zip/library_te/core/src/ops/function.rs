/// మార్పులేని రిసీవర్‌ను తీసుకునే కాల్ ఆపరేటర్ యొక్క సంస్కరణ.
///
/// స్థితిని మార్చకుండా `Fn` యొక్క సందర్భాలను పదేపదే పిలుస్తారు.
///
/// *ఈ trait (`Fn`) ను [function pointers] (`fn`) తో కంగారు పెట్టకూడదు.*
///
/// `Fn` మూసివేత ద్వారా స్వయంచాలకంగా అమలు చేయబడుతుంది, ఇది సంగ్రహించిన వేరియబుల్స్‌కు మాత్రమే మార్పులేని సూచనలు తీసుకుంటుంది లేదా ఏదైనా సంగ్రహించవద్దు, అలాగే (safe) [function pointers] (కొన్ని మినహాయింపులతో, మరిన్ని వివరాల కోసం వారి డాక్యుమెంటేషన్ చూడండి).
///
/// అదనంగా, `Fn` ను అమలు చేసే `F` రకం కోసం, `&F` కూడా `Fn` ను అమలు చేస్తుంది.
///
/// [`FnMut`] మరియు [`FnOnce`] రెండూ `Fn` యొక్క సూపర్‌ట్రైట్‌లు కాబట్టి, `Fn` యొక్క ఏదైనా ఉదాహరణను [`FnMut`] లేదా [`FnOnce`] is హించిన పారామితిగా ఉపయోగించవచ్చు.
///
/// మీరు ఫంక్షన్-లాంటి రకం యొక్క పరామితిని అంగీకరించాలనుకున్నప్పుడు మరియు దానిని పదేపదే మరియు పరివర్తన స్థితి లేకుండా పిలవవలసిన అవసరం వచ్చినప్పుడు `Fn` ను బౌండ్‌గా ఉపయోగించండి (ఉదా.
/// మీకు అలాంటి కఠినమైన అవసరాలు అవసరం లేకపోతే, [`FnMut`] లేదా [`FnOnce`] ను హద్దులుగా ఉపయోగించండి.
///
/// ఈ అంశంపై మరింత సమాచారం కోసం [chapter on closures in *The Rust Programming Language*][book] చూడండి.
///
/// `Fn` traits (ఉదా.) కోసం ప్రత్యేక వాక్యనిర్మాణం కూడా గమనించదగినది
/// `Fn(usize, bool) -> usize`).దీని సాంకేతిక వివరాలపై ఆసక్తి ఉన్నవారు [the relevant section in the *Rustonomicon*][nomicon] ని సూచించవచ్చు.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## మూసివేతకు పిలుస్తున్నారు
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## `Fn` పరామితిని ఉపయోగించడం
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // తద్వారా regex ఆ `&str: !FnMut` పై ఆధారపడగలదు
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// కాల్ ఆపరేషన్ చేస్తుంది.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// మార్చగల రిసీవర్‌ను తీసుకునే కాల్ ఆపరేటర్ యొక్క సంస్కరణ.
///
/// `FnMut` యొక్క సందర్భాలను పదేపదే పిలుస్తారు మరియు స్థితిని మార్చవచ్చు.
///
/// `FnMut` సంగ్రహించిన వేరియబుల్స్‌కు మార్చగల సూచనలు, అలాగే [`Fn`], ఉదా., (safe) [function pointers] (`FnMut` [`Fn`] యొక్క సూపర్‌ట్రైట్ కనుక) అమలు చేసే అన్ని రకాలైన మూసివేతల ద్వారా స్వయంచాలకంగా అమలు చేయబడుతుంది.
/// అదనంగా, `FnMut` ను అమలు చేసే `F` రకం కోసం, `&mut F` కూడా `FnMut` ను అమలు చేస్తుంది.
///
/// [`FnOnce`] అనేది `FnMut` యొక్క సూపర్ ట్రైట్ కనుక, [`FnOnce`] expected హించిన చోట `FnMut` యొక్క ఏదైనా ఉదాహరణను ఉపయోగించవచ్చు, మరియు [`Fn`] `FnMut` యొక్క సబ్‌ట్రైట్ కనుక, [`Fn`] యొక్క ఏదైనా ఉదాహరణ `FnMut` .హించిన చోట ఉపయోగించవచ్చు.
///
/// మీరు ఫంక్షన్-లాంటి రకం యొక్క పరామితిని అంగీకరించాలనుకున్నప్పుడు `FnMut` ను బౌండ్‌గా ఉపయోగించండి మరియు దానిని పదేపదే పిలవాలి, అదే సమయంలో స్థితిని మార్చడానికి అనుమతిస్తుంది.
/// పరామితి స్థితిని మార్చకూడదనుకుంటే, [`Fn`] ను బౌండ్‌గా ఉపయోగించండి;మీరు దీన్ని పదేపదే కాల్ చేయనవసరం లేకపోతే, [`FnOnce`] ని ఉపయోగించండి.
///
/// ఈ అంశంపై మరింత సమాచారం కోసం [chapter on closures in *The Rust Programming Language*][book] చూడండి.
///
/// `Fn` traits (ఉదా.) కోసం ప్రత్యేక వాక్యనిర్మాణం కూడా గమనించదగినది
/// `Fn(usize, bool) -> usize`).దీని సాంకేతిక వివరాలపై ఆసక్తి ఉన్నవారు [the relevant section in the *Rustonomicon*][nomicon] ని సూచించవచ్చు.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## పరస్పరం సంగ్రహించే మూసివేతను పిలుస్తుంది
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## `FnMut` పరామితిని ఉపయోగించడం
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // తద్వారా regex ఆ `&str: !FnMut` పై ఆధారపడగలదు
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// కాల్ ఆపరేషన్ చేస్తుంది.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// ఉప-విలువ రిసీవర్ తీసుకునే కాల్ ఆపరేటర్ యొక్క సంస్కరణ.
///
/// `FnOnce` యొక్క ఉదాహరణలను పిలుస్తారు, కానీ అనేకసార్లు పిలవలేరు.ఈ కారణంగా, ఒక రకం గురించి తెలిసిన ఏకైక విషయం ఏమిటంటే అది `FnOnce` ను అమలు చేస్తుంది, దానిని ఒక్కసారి మాత్రమే పిలుస్తారు.
///
/// `FnOnce` సంగ్రహించిన వేరియబుల్స్, అలాగే [`FnMut`], ఉదా., (safe) [function pointers] (`FnOnce` [`FnMut`] యొక్క సూపర్ ట్రైట్ కనుక) అమలు చేసే అన్ని రకాలైన మూసివేతల ద్వారా స్వయంచాలకంగా అమలు చేయబడుతుంది.
///
///
/// [`Fn`] మరియు [`FnMut`] రెండూ `FnOnce` యొక్క సబ్‌ట్రెయిట్‌లు కాబట్టి, [`Fn`] లేదా [`FnMut`] యొక్క ఏదైనా ఉదాహరణ `FnOnce` .హించిన చోట ఉపయోగించవచ్చు.
///
/// మీరు ఫంక్షన్ లాంటి రకం యొక్క పరామితిని అంగీకరించాలనుకున్నప్పుడు `FnOnce` ను బౌండ్‌గా ఉపయోగించండి మరియు ఒకసారి మాత్రమే కాల్ చేయాలి.
/// మీరు పరామితిని పదేపదే కాల్ చేయవలసి వస్తే, [`FnMut`] ను బౌండ్‌గా ఉపయోగించండి;స్థితిని మార్చకూడదని మీకు కూడా అవసరమైతే, [`Fn`] ను ఉపయోగించండి.
///
/// ఈ అంశంపై మరింత సమాచారం కోసం [chapter on closures in *The Rust Programming Language*][book] చూడండి.
///
/// `Fn` traits (ఉదా.) కోసం ప్రత్యేక వాక్యనిర్మాణం కూడా గమనించదగినది
/// `Fn(usize, bool) -> usize`).దీని సాంకేతిక వివరాలపై ఆసక్తి ఉన్నవారు [the relevant section in the *Rustonomicon*][nomicon] ని సూచించవచ్చు.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## `FnOnce` పరామితిని ఉపయోగించడం
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` దాని సంగ్రహించిన వేరియబుల్స్ను వినియోగిస్తుంది, కాబట్టి ఇది ఒకటి కంటే ఎక్కువసార్లు అమలు చేయబడదు.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // `func()` ను మళ్లీ ప్రారంభించడానికి ప్రయత్నిస్తే `func` కోసం `use of moved value` లోపం వస్తుంది.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` ఈ సమయంలో ఇకపై ప్రారంభించబడదు
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // తద్వారా regex ఆ `&str: !FnMut` పై ఆధారపడగలదు
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// కాల్ ఆపరేటర్ ఉపయోగించిన తర్వాత తిరిగి వచ్చిన రకం.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// కాల్ ఆపరేషన్ చేస్తుంది.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}