/// `*v` వంటి మార్పులేని డీఫరెన్సింగ్ ఆపరేషన్ల కోసం ఉపయోగిస్తారు.
///
/// మార్పులేని సందర్భాల్లో (unary) `*` ఆపరేటర్‌తో స్పష్టమైన డీరెఫరెన్సింగ్ ఆపరేషన్ల కోసం ఉపయోగించడంతో పాటు, `Deref` కూడా అనేక పరిస్థితులలో కంపైలర్ చేత అవ్యక్తంగా ఉపయోగించబడుతుంది.
/// ఈ యంత్రాంగాన్ని ['`Deref` coercion'][more] అంటారు.
/// మార్చగల సందర్భాలలో, [`DerefMut`] ఉపయోగించబడుతుంది.
///
/// స్మార్ట్ పాయింటర్ల కోసం `Deref` ను అమలు చేయడం వలన వాటి వెనుక ఉన్న డేటాను సౌకర్యవంతంగా యాక్సెస్ చేస్తుంది, అందుకే అవి `Deref` ను అమలు చేస్తాయి.
/// మరోవైపు, స్మార్ట్ పాయింటర్లకు అనుగుణంగా `Deref` మరియు [`DerefMut`] కు సంబంధించిన నియమాలు ప్రత్యేకంగా రూపొందించబడ్డాయి.
/// ఈ కారణంగా, గందరగోళాన్ని నివారించడానికి ** `డెరెఫ్` స్మార్ట్ పాయింటర్ల కోసం మాత్రమే అమలు చేయాలి.
///
/// ఇలాంటి కారణాల వల్ల,**ఈ trait ఎప్పుడూ విఫలం కాకూడదు**.`Deref` అవ్యక్తంగా ప్రారంభించినప్పుడు డీరెఫరెన్సింగ్ సమయంలో వైఫల్యం చాలా గందరగోళంగా ఉంటుంది.
///
/// # `Deref` బలవంతంపై మరిన్ని
///
/// `T` `Deref<Target = U>` ను అమలు చేస్తే, మరియు `x` అనేది `T` రకం విలువ, అప్పుడు:
///
/// * మార్పులేని సందర్భాల్లో, `*x` (ఇక్కడ `T` సూచన లేదా ముడి పాయింటర్ కాదు) `* Deref::deref(&x)` కు సమానం.
/// * రకం `&T` యొక్క విలువలు `&U` రకం విలువలకు బలవంతం చేయబడతాయి
/// * `T` `U` రకం యొక్క అన్ని (immutable) పద్ధతులను అవ్యక్తంగా అమలు చేస్తుంది.
///
/// మరిన్ని వివరాల కోసం, [the chapter in *The Rust Programming Language*][book] తో పాటు [the dereference operator][ref-deref-op], [method resolution] మరియు [type coercions] లోని రిఫరెన్స్ విభాగాలను సందర్శించండి.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// ఒకే ఫీల్డ్‌తో ఒక స్ట్రక్ట్, ఇది స్ట్రక్ట్‌ను డీఫరెన్సింగ్ చేయడం ద్వారా ప్రాప్తిస్తుంది.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// డీరెఫరెన్సింగ్ తర్వాత ఫలిత రకం.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// విలువను తగ్గిస్తుంది.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// `*v = 1;` లో వలె మార్చగల డీరెఫరెన్సింగ్ ఆపరేషన్ల కోసం ఉపయోగిస్తారు.
///
/// మ్యూటబుల్ సందర్భాల్లో (unary) `*` ఆపరేటర్‌తో స్పష్టమైన డీరెఫరెన్సింగ్ ఆపరేషన్ల కోసం ఉపయోగించడంతో పాటు, `DerefMut` కూడా అనేక పరిస్థితులలో కంపైలర్ చేత అవ్యక్తంగా ఉపయోగించబడుతుంది.
/// ఈ యంత్రాంగాన్ని ['`Deref` coercion'][more] అంటారు.
/// మార్పులేని సందర్భాల్లో, [`Deref`] ఉపయోగించబడుతుంది.
///
/// స్మార్ట్ పాయింటర్ల కోసం `DerefMut` ను అమలు చేయడం వారి వెనుక ఉన్న డేటాను మార్చడం సౌకర్యవంతంగా చేస్తుంది, అందుకే అవి `DerefMut` ను అమలు చేస్తాయి.
/// మరోవైపు, స్మార్ట్ పాయింటర్లకు అనుగుణంగా [`Deref`] మరియు `DerefMut` కు సంబంధించిన నియమాలు ప్రత్యేకంగా రూపొందించబడ్డాయి.
/// ఈ కారణంగా, గందరగోళాన్ని నివారించడానికి ** `డెరెఫ్‌మట్` స్మార్ట్ పాయింటర్ల కోసం మాత్రమే అమలు చేయాలి.
///
/// ఇలాంటి కారణాల వల్ల,**ఈ trait ఎప్పుడూ విఫలం కాకూడదు**.`DerefMut` అవ్యక్తంగా ప్రారంభించినప్పుడు డీరెఫరెన్సింగ్ సమయంలో వైఫల్యం చాలా గందరగోళంగా ఉంటుంది.
///
/// # `Deref` బలవంతంపై మరిన్ని
///
/// `T` `DerefMut<Target = U>` ను అమలు చేస్తే, మరియు `x` అనేది `T` రకం విలువ, అప్పుడు:
///
/// * మార్చగల సందర్భాల్లో, `*x` (ఇక్కడ `T` సూచన లేదా ముడి పాయింటర్ కాదు) `* DerefMut::deref_mut(&mut x)` కు సమానం.
/// * రకం `&mut T` యొక్క విలువలు `&mut U` రకం విలువలకు బలవంతం చేయబడతాయి
/// * `T` `U` రకం యొక్క అన్ని (mutable) పద్ధతులను అవ్యక్తంగా అమలు చేస్తుంది.
///
/// మరిన్ని వివరాల కోసం, [the chapter in *The Rust Programming Language*][book] తో పాటు [the dereference operator][ref-deref-op], [method resolution] మరియు [type coercions] లోని రిఫరెన్స్ విభాగాలను సందర్శించండి.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// ఒకే ఫీల్డ్‌తో ఒక స్ట్రక్ట్, ఇది స్ట్రక్ట్‌ను డీఫరెన్సింగ్ ద్వారా సవరించగలదు.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// విలువను పరస్పరం డీరెఫరెన్స్ చేస్తుంది.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// `arbitrary_self_types` లక్షణం లేకుండా, ఒక struct ను పద్ధతి రిసీవర్‌గా ఉపయోగించవచ్చని సూచిస్తుంది.
///
/// ఇది `Box<T>`, `Rc<T>`, `&T` మరియు `Pin<P>` వంటి stdlib పాయింటర్ రకాలు అమలు చేస్తుంది.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}