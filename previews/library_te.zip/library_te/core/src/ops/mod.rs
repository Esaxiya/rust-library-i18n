//! ఓవర్‌లోడ్ చేయగల ఆపరేటర్లు.
//!
//! ఈ traits ను అమలు చేయడం వలన మీరు కొన్ని ఆపరేటర్లను ఓవర్‌లోడ్ చేయడానికి అనుమతిస్తుంది.
//!
//! ఈ traits లో కొన్ని prelude చేత దిగుమతి చేయబడతాయి, కాబట్టి అవి ప్రతి Rust ప్రోగ్రామ్‌లో లభిస్తాయి.traits మద్దతు ఉన్న ఆపరేటర్లను మాత్రమే ఓవర్‌లోడ్ చేయవచ్చు.
//! ఉదాహరణకు, అదనంగా ఆపరేటర్ (`+`) ను [`Add`] trait ద్వారా ఓవర్‌లోడ్ చేయవచ్చు, కాని అసైన్‌మెంట్ ఆపరేటర్ (`=`) కి trait కి మద్దతు లేదు కాబట్టి, దాని సెమాంటిక్స్‌ను ఓవర్‌లోడ్ చేసే మార్గం లేదు.
//! అదనంగా, ఈ మాడ్యూల్ కొత్త ఆపరేటర్లను సృష్టించడానికి ఎటువంటి యంత్రాంగాన్ని అందించదు.
//! లక్షణం లేని ఓవర్‌లోడింగ్ లేదా కస్టమ్ ఆపరేటర్లు అవసరమైతే, మీరు Rust యొక్క వాక్యనిర్మాణాన్ని విస్తరించడానికి మాక్రోలు లేదా కంపైలర్ ప్లగిన్‌ల వైపు చూడాలి.
//!
//! ఆపరేటర్ traits యొక్క అమలులు వారి సాధారణ సందర్భాలలో మరియు వారి సాధారణ అర్ధాలను మరియు [operator precedence] ను దృష్టిలో ఉంచుకుని ఆశ్చర్యకరంగా ఉండాలి.
//! ఉదాహరణకు, [`Mul`] ను అమలు చేసేటప్పుడు, ఆపరేషన్ గుణకారానికి కొంత పోలికను కలిగి ఉండాలి (మరియు అసోసియేటివిటీ వంటి properties హించిన లక్షణాలను పంచుకోండి).
//!
//! `&&` మరియు `||` ఆపరేటర్లు షార్ట్-సర్క్యూట్ అని గమనించండి, అనగా, అవి ఫలితానికి దోహదం చేస్తే మాత్రమే వారి రెండవ ఆపరేషన్‌ను అంచనా వేస్తాయి.ఈ ప్రవర్తన traits చేత అమలు చేయబడనందున, `&&` మరియు `||` ఓవర్‌లోడ్ చేయగల ఆపరేటర్లుగా మద్దతు ఇవ్వవు.
//!
//! చాలా మంది ఆపరేటర్లు వారి కార్యకలాపాలను విలువ ప్రకారం తీసుకుంటారు.అంతర్నిర్మిత రకాలను కలిగి ఉన్న సాధారణం కాని సందర్భాలలో, ఇది సాధారణంగా సమస్య కాదు.
//! ఏదేమైనా, ఈ ఆపరేటర్లను జెనెరిక్ కోడ్‌లో ఉపయోగించడం, ఆపరేటర్లను వినియోగించటానికి అనుమతించకుండా విలువలను తిరిగి ఉపయోగించాల్సి వస్తే కొంత శ్రద్ధ అవసరం.అప్పుడప్పుడు [`clone`] ను ఉపయోగించడం ఒక ఎంపిక.
//! మరొక ఎంపిక ఏమిటంటే సూచనల కోసం అదనపు ఆపరేటర్ అమలులను అందించే రకాలుపై ఆధారపడటం.
//! ఉదాహరణకు, అదనంగా నిర్వచించబడే వినియోగదారు నిర్వచించిన రకం `T` కోసం, `T` మరియు `&T` రెండూ traits [`Add<T>`][`Add`] మరియు [`Add<&T>`][`Add`] ను అమలు చేయడం మంచిది, తద్వారా అనవసరమైన క్లోనింగ్ లేకుండా సాధారణ కోడ్ వ్రాయబడుతుంది.
//!
//!
//! # Examples
//!
//! ఈ ఉదాహరణ [`Add`] మరియు [`Sub`] ను అమలు చేసే `Point` స్ట్రక్ట్‌ను సృష్టిస్తుంది, ఆపై రెండు `పాయింట్'లను జోడించడం మరియు తీసివేయడం ప్రదర్శిస్తుంది.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! ఉదాహరణ అమలు కోసం ప్రతి trait కోసం డాక్యుమెంటేషన్ చూడండి.
//!
//! [`Fn`], [`FnMut`] మరియు [`FnOnce`] traits ఫంక్షన్‌ల వలె అమలు చేయగల రకాలు అమలు చేయబడతాయి.[`Fn`] `&self`, [`FnMut`] `&mut self` మరియు [`FnOnce`] `self` తీసుకుంటుందని గమనించండి.
//! ఇవి ఒక ఉదాహరణలో అమలు చేయగల మూడు రకాల పద్ధతులకు అనుగుణంగా ఉంటాయి: కాల్-బై-రిఫరెన్స్, కాల్-బై-మ్యూటబుల్-రిఫరెన్స్ మరియు కాల్-బై-వాల్యూ.
//! ఈ traits యొక్క అత్యంత సాధారణ ఉపయోగం ఫంక్షన్లు లేదా మూసివేతలను వాదనలుగా తీసుకునే ఉన్నత-స్థాయి ఫంక్షన్లకు హద్దులుగా పనిచేయడం.
//!
//! [`Fn`] ను పరామితిగా తీసుకోవడం:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! [`FnMut`] ను పరామితిగా తీసుకోవడం:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! [`FnOnce`] ను పరామితిగా తీసుకోవడం:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` దాని సంగ్రహించిన వేరియబుల్స్ను వినియోగిస్తుంది, కాబట్టి ఇది ఒకటి కంటే ఎక్కువసార్లు అమలు చేయబడదు
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // `func()` ను మళ్లీ ప్రారంభించడానికి ప్రయత్నిస్తే `func` కోసం `use of moved value` లోపం వస్తుంది
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` ఈ సమయంలో ఇకపై ప్రారంభించబడదు
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;