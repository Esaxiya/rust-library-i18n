//! రకాలు మధ్య మార్పిడుల కోసం Traits.
//!
//! ఈ మాడ్యూల్‌లోని traits ఒక రకం నుండి మరొక రకానికి మార్చడానికి ఒక మార్గాన్ని అందిస్తుంది.
//! ప్రతి trait వేరే ప్రయోజనాన్ని అందిస్తుంది:
//!
//! - చౌకైన రిఫరెన్స్-టు-రిఫరెన్స్ మార్పిడుల కోసం [`AsRef`] trait ను అమలు చేయండి
//! - చౌకగా మార్చగల-మార్చగల మార్పిడుల కోసం [`AsMut`] trait ను అమలు చేయండి
//! - విలువ-నుండి-విలువ మార్పిడులను తినడానికి [`From`] trait ను అమలు చేయండి
//! - ప్రస్తుత crate వెలుపల ఉన్న రకానికి విలువ-నుండి-విలువ మార్పిడులను వినియోగించడానికి [`Into`] trait ను అమలు చేయండి
//! - [`TryFrom`] మరియు [`TryInto`] traits [`From`] మరియు [`Into`] లాగా ప్రవర్తిస్తాయి, కాని మార్పిడి విఫలమైనప్పుడు అమలు చేయాలి.
//!
//! ఈ మాడ్యూల్‌లోని traits తరచూ జెనెరిక్ ఫంక్షన్ల కోసం trait bounds గా ఉపయోగించబడుతుంది, అంటే బహుళ రకాల వాదనలకు మద్దతు ఉంది.ఉదాహరణల కోసం ప్రతి trait యొక్క డాక్యుమెంటేషన్ చూడండి.
//!
//! లైబ్రరీ రచయితగా, మీరు ఎల్లప్పుడూ [`Into<U>`][`Into`] లేదా [`TryInto<U>`][`TryInto`] కంటే [`From<T>`][`From`] లేదా [`TryFrom<T>`][`TryFrom`] ను అమలు చేయడానికి ఇష్టపడాలి, ఎందుకంటే [`From`] మరియు [`TryFrom`] ఎక్కువ సౌలభ్యాన్ని అందిస్తాయి మరియు సమానమైన [`Into`] లేదా [`TryInto`] అమలులను ఉచితంగా అందిస్తాయి, ప్రామాణిక లైబ్రరీలో దుప్పటి అమలుకు ధన్యవాదాలు.
//! Rust 1.41 కి ముందు సంస్కరణను లక్ష్యంగా చేసుకున్నప్పుడు, ప్రస్తుత crate వెలుపల ఒక రకానికి మార్చినప్పుడు నేరుగా [`Into`] లేదా [`TryInto`] ను అమలు చేయడం అవసరం.
//!
//! # సాధారణ అమలులు
//!
//! - [`AsRef`] మరియు లోపలి రకం సూచన అయితే [`AsMut`] ఆటో-డీరెఫరెన్స్
//! - [`నుండి`]`<U>T` కోసం సూచిస్తుంది [`లోకి]]`</u><T><U>U` కోసం</u>
//! - [`ట్రైఫ్రోమ్`]`<U>కోసం టి` సూచిస్తుంది [`ట్రైఇంటో`]`</u><T><U>U` కోసం</u>
//! - [`From`] మరియు [`Into`] రిఫ్లెక్సివ్, అంటే అన్ని రకాలు తమను తాము `into` మరియు `from` తమను తాము చేయగలవు
//!
//! వినియోగ ఉదాహరణల కోసం ప్రతి trait చూడండి.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// గుర్తింపు ఫంక్షన్.
///
/// ఈ ఫంక్షన్ గురించి గమనించవలసిన రెండు విషయాలు ముఖ్యమైనవి:
///
/// - ఇది ఎల్లప్పుడూ `|x| x` వంటి మూసివేతకు సమానం కాదు, ఎందుకంటే మూసివేత `x` ను వేరే రకానికి బలవంతం చేస్తుంది.
///
/// - ఇది ఫంక్షన్కు పంపిన ఇన్పుట్ `x` ను కదిలిస్తుంది.
///
/// ఇన్‌పుట్‌ను తిరిగి ఇచ్చే ఫంక్షన్‌ను కలిగి ఉండటం వింతగా అనిపించినప్పటికీ, కొన్ని ఆసక్తికరమైన ఉపయోగాలు ఉన్నాయి.
///
///
/// # Examples
///
/// ఇతర, ఆసక్తికరమైన, ఫంక్షన్ల క్రమంలో ఏమీ చేయకుండా `identity` ను ఉపయోగించడం:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // ఒకదాన్ని జోడించడం ఒక ఆసక్తికరమైన పని అని నటిద్దాం.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// షరతులతో `identity` ను "do nothing" బేస్ కేసుగా ఉపయోగించడం:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // మరింత ఆసక్తికరమైన విషయాలు చేయండి ...
///
/// let _results = do_stuff(42);
/// ```
///
/// `Option<T>` యొక్క ఇరేటర్ యొక్క `Some` వేరియంట్‌లను ఉంచడానికి `identity` ని ఉపయోగించడం:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// చౌకైన రిఫరెన్స్-టు-రిఫరెన్స్ మార్పిడి చేయడానికి ఉపయోగిస్తారు.
///
/// ఈ trait [`AsMut`] ను పోలి ఉంటుంది, ఇది మార్చగల సూచనల మధ్య మార్చడానికి ఉపయోగించబడుతుంది.
/// మీరు ఖరీదైన మార్పిడి చేయవలసి వస్తే [`From`] ను `&T` రకంతో అమలు చేయడం లేదా కస్టమ్ ఫంక్షన్ రాయడం మంచిది.
///
/// `AsRef` [`Borrow`] వలె అదే సంతకాన్ని కలిగి ఉంది, కానీ [`Borrow`] కొన్ని అంశాలలో భిన్నంగా ఉంటుంది:
///
/// - `AsRef` మాదిరిగా కాకుండా, [`Borrow`] ఏదైనా `T` కోసం ఒక దుప్పటి ఇంప్ల్ కలిగి ఉంటుంది మరియు సూచన లేదా విలువను అంగీకరించడానికి ఉపయోగించవచ్చు.
/// - [`Borrow`] అరువు తీసుకున్న విలువ కోసం [`Hash`], [`Eq`] మరియు [`Ord`] యాజమాన్యంలోని విలువకు సమానం.
/// ఈ కారణంగా, మీరు స్ట్రక్ట్ యొక్క ఒకే ఒక క్షేత్రాన్ని మాత్రమే రుణం తీసుకోవాలనుకుంటే మీరు `AsRef` ను అమలు చేయవచ్చు, కానీ [`Borrow`] కాదు.
///
/// **Note: ఈ trait విఫలం కాకూడదు **.మార్పిడి విఫలమైతే, [`Option<T>`] లేదా [`Result<T, E>`] ను తిరిగి ఇచ్చే ప్రత్యేక పద్ధతిని ఉపయోగించండి.
///
/// # సాధారణ అమలులు
///
/// - `AsRef` లోపలి రకం సూచన లేదా మార్చగల సూచన అయితే ఆటో-డీరెఫరెన్సులు (ఉదా: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// trait bounds ను ఉపయోగించడం ద్వారా, వివిధ రకాలైన వాదనలను పేర్కొన్న రకం `T` కి మార్చగలిగినంత వరకు మేము అంగీకరించవచ్చు.
///
/// ఉదాహరణకు: `AsRef<str>` తీసుకునే సాధారణ ఫంక్షన్‌ను సృష్టించడం ద్వారా, [`&str`] కి వాదనగా మార్చగల అన్ని సూచనలను అంగీకరించాలని మేము కోరుకుంటున్నాము.
/// [`String`] మరియు [`&str`] రెండూ `AsRef<str>` ను అమలు చేస్తున్నందున మనం రెండింటినీ ఇన్‌పుట్ ఆర్గ్యుమెంట్‌గా అంగీకరించవచ్చు.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// మార్పిడిని చేస్తుంది.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// చౌకైన మ్యూటబుల్-టు-మ్యూటబుల్ రిఫరెన్స్ కన్వర్షన్ చేయడానికి ఉపయోగిస్తారు.
///
/// ఈ trait [`AsRef`] ను పోలి ఉంటుంది కాని మార్చగల సూచనల మధ్య మార్చడానికి ఉపయోగించబడుతుంది.
/// మీరు ఖరీదైన మార్పిడి చేయవలసి వస్తే [`From`] ను `&mut T` రకంతో అమలు చేయడం లేదా కస్టమ్ ఫంక్షన్ రాయడం మంచిది.
///
/// **Note: ఈ trait విఫలం కాకూడదు **.మార్పిడి విఫలమైతే, [`Option<T>`] లేదా [`Result<T, E>`] ను తిరిగి ఇచ్చే ప్రత్యేక పద్ధతిని ఉపయోగించండి.
///
/// # సాధారణ అమలులు
///
/// - `AsMut` లోపలి రకం మార్చగల సూచన అయితే ఆటో-డీరెఫరెన్స్‌లు (ఉదా: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// జెనరిక్ ఫంక్షన్ కోసం `AsMut` ను trait bound గా ఉపయోగించడం ద్వారా మేము `&mut T` టైప్ గా మార్చగల అన్ని మ్యూటబుల్ రిఫరెన్సులను అంగీకరించవచ్చు.
/// [`Box<T>`] `AsMut<T>` ను అమలు చేస్తున్నందున మేము `add_one` అనే ఫంక్షన్‌ను వ్రాయగలము, అది `&mut u64` గా మార్చగల అన్ని ఆర్గ్యుమెంట్‌లను తీసుకుంటుంది.
/// [`Box<T>`] `AsMut<T>` ను అమలు చేస్తున్నందున, `add_one` రకం `&mut Box<u64>` యొక్క వాదనలను కూడా అంగీకరిస్తుంది:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// మార్పిడిని చేస్తుంది.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// ఇన్పుట్ విలువను వినియోగించే విలువ-నుండి-విలువ మార్పిడి.[`From`] కి వ్యతిరేకం.
///
/// [`Into`] అమలు చేయకుండా ఉండాలి మరియు బదులుగా [`From`] ను అమలు చేయాలి.
/// [`From`] ను అమలు చేయడం ప్రామాణిక లైబ్రరీలో దుప్పటి అమలుకు [`Into`] కృతజ్ఞతలు అమలు చేస్తుంది.
///
/// [`Into`] ను మాత్రమే అమలు చేసే రకాలను కూడా ఉపయోగించవచ్చని నిర్ధారించడానికి జెనెరిక్ ఫంక్షన్‌పై trait bounds ను పేర్కొన్నప్పుడు [`From`] కంటే [`Into`] ను ఉపయోగించడం ఇష్టపడండి.
///
/// **Note: ఈ trait విఫలం కాకూడదు **.మార్పిడి విఫలమైతే, [`TryInto`] ఉపయోగించండి.
///
/// # సాధారణ అమలులు
///
/// - [`నుండి`]`<T>U` అంటే `Into<U> for T` ను సూచిస్తుంది
/// - [`Into`] రిఫ్లెక్సివ్, అంటే `Into<T> for T` అమలు చేయబడుతుంది
///
/// # Rust యొక్క పాత వెర్షన్లలో బాహ్య రకాలుగా మార్చడానికి [`Into`] ను అమలు చేస్తోంది
///
/// Rust 1.41 కి ముందు, గమ్యం రకం ప్రస్తుత crate లో భాగం కాకపోతే, మీరు [`From`] ను నేరుగా అమలు చేయలేరు.
/// ఉదాహరణకు, ఈ కోడ్‌ను తీసుకోండి:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// ఇది భాష యొక్క పాత సంస్కరణల్లో కంపైల్ చేయడంలో విఫలమవుతుంది ఎందుకంటే Rust యొక్క అనాధ నియమాలు కొంచెం కఠినంగా ఉంటాయి.
/// దీన్ని దాటవేయడానికి, మీరు నేరుగా [`Into`] ను అమలు చేయవచ్చు:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// [`Into`] [`From`] అమలును అందించదని అర్థం చేసుకోవాలి ([`From`] [`Into`] తో చేస్తుంది).
/// అందువల్ల, మీరు ఎప్పుడైనా [`From`] ను అమలు చేయడానికి ప్రయత్నించాలి మరియు [`From`] ను అమలు చేయలేకపోతే [`Into`] కు తిరిగి వస్తాయి.
///
/// # Examples
///
/// [`String`] అమలు చేస్తుంది [`లోకి]]` <`[` వెక్`]`<`[`u8`]` >> `:
///
/// పేర్కొన్న రకం `T` కు మార్చగల అన్ని ఆర్గ్యుమెంట్‌లను తీసుకోవటానికి జెనరిక్ ఫంక్షన్ కావాలని వ్యక్తపరచడానికి, మేము [`ఇంటు`] యొక్క trait bound ను ఉపయోగించవచ్చు.<T>`.
///
/// ఉదాహరణకు: `is_hello` ఫంక్షన్ [`Vec`]`<`[`u8`] `>` గా మార్చగల అన్ని ఆర్గ్యుమెంట్‌లను తీసుకుంటుంది.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// మార్పిడిని చేస్తుంది.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// ఇన్పుట్ విలువను వినియోగించేటప్పుడు విలువ నుండి విలువ మార్పిడులు చేయడానికి ఉపయోగిస్తారు.ఇది [`Into`] యొక్క పరస్పరం.
///
/// [`Into`] కంటే `From` ను అమలు చేయడానికి ఎల్లప్పుడూ ఇష్టపడాలి ఎందుకంటే `From` ను స్వయంచాలకంగా అమలు చేయడం వలన ప్రామాణిక లైబ్రరీలో దుప్పటి అమలుకు [`Into`] కృతజ్ఞతలు అమలు చేయబడతాయి.
///
///
/// Rust 1.41 కి ముందు సంస్కరణను లక్ష్యంగా చేసుకుని, ప్రస్తుత crate వెలుపల ఒక రకానికి మార్చినప్పుడు మాత్రమే [`Into`] ను అమలు చేయండి.
/// `From` Rust యొక్క అనాధ నియమాల కారణంగా మునుపటి సంస్కరణల్లో ఈ రకమైన మార్పిడులు చేయలేకపోయింది.
/// మరిన్ని వివరాల కోసం [`Into`] చూడండి.
///
/// జెనెరిక్ ఫంక్షన్‌లో trait bounds ను పేర్కొన్నప్పుడు `From` ను ఉపయోగించడం కంటే [`Into`] ను ఉపయోగించడం ఇష్టపడండి.
/// ఈ విధంగా, [`Into`] ను నేరుగా అమలు చేసే రకాలను వాదనలుగా కూడా ఉపయోగించవచ్చు.
///
/// లోపం నిర్వహణ చేసేటప్పుడు `From` కూడా చాలా ఉపయోగకరంగా ఉంటుంది.విఫలమయ్యే సామర్థ్యాన్ని కలిగి ఉన్న ఫంక్షన్‌ను నిర్మిస్తున్నప్పుడు, రిటర్న్ రకం సాధారణంగా `Result<T, E>` రూపంలో ఉంటుంది.
/// `From` trait బహుళ లోపం రకాలను కప్పి ఉంచే ఒకే లోపం రకాన్ని తిరిగి ఇవ్వడానికి ఒక ఫంక్షన్‌ను అనుమతించడం ద్వారా లోపం నిర్వహణను సులభతరం చేస్తుంది.మరిన్ని వివరాల కోసం "Examples" విభాగం మరియు [the book][book] చూడండి.
///
/// **Note: ఈ trait విఫలం కాకూడదు **.మార్పిడి విఫలమైతే, [`TryFrom`] ఉపయోగించండి.
///
/// # సాధారణ అమలులు
///
/// - `From<T> for U` T`<U>కోసం</u> [`లోకి]] సూచిస్తుంది
/// - `From` రిఫ్లెక్సివ్, అంటే `From<T> for T` అమలు చేయబడుతుంది
///
/// # Examples
///
/// [`String`] `From<&str>` ను అమలు చేస్తుంది:
///
/// `&str` నుండి స్ట్రింగ్‌కు స్పష్టమైన మార్పిడి క్రింది విధంగా జరుగుతుంది:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// లోపం నిర్వహణ చేసేటప్పుడు మీ స్వంత లోపం రకం కోసం `From` ను అమలు చేయడానికి ఇది తరచుగా ఉపయోగపడుతుంది.
/// అంతర్లీన లోపం రకాన్ని అంతర్లీన దోష రకాన్ని కప్పి ఉంచే మా స్వంత అనుకూల దోష రకానికి మార్చడం ద్వారా, అంతర్లీన కారణంపై సమాచారాన్ని కోల్పోకుండా ఒకే లోపం రకాన్ని తిరిగి ఇవ్వవచ్చు.
/// '?' ఆపరేటర్ స్వయంచాలకంగా `Into<CliError>::into` కి కాల్ చేయడం ద్వారా అంతర్లీన లోపం రకాన్ని మా అనుకూల దోష రకానికి మారుస్తుంది, ఇది `From` ను అమలు చేసేటప్పుడు స్వయంచాలకంగా అందించబడుతుంది.
/// కంపైలర్ అప్పుడు `Into` యొక్క ఏ అమలును ఉపయోగించాలో inf హించింది.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// మార్పిడిని చేస్తుంది.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// `self` ను వినియోగించే ప్రయత్నించిన మార్పిడి, ఇది ఖరీదైనది కావచ్చు లేదా కాకపోవచ్చు.
///
/// లైబ్రరీ రచయితలు సాధారణంగా ఈ trait ను నేరుగా అమలు చేయకూడదు, కానీ [`TryFrom`] trait ను అమలు చేయడానికి ఇష్టపడాలి, ఇది ఎక్కువ సౌలభ్యాన్ని అందిస్తుంది మరియు సమానమైన `TryInto` అమలును ఉచితంగా అందిస్తుంది, ప్రామాణిక లైబ్రరీలో దుప్పటి అమలుకు ధన్యవాదాలు.
/// దీనిపై మరింత సమాచారం కోసం, [`Into`] కోసం డాక్యుమెంటేషన్ చూడండి.
///
/// # `TryInto` అమలు చేస్తోంది
///
/// ఇది [`Into`] ను అమలు చేసేటప్పుడు అదే పరిమితులు మరియు తార్కికతను ఎదుర్కొంటుంది, వివరాల కోసం అక్కడ చూడండి.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// మార్పిడి లోపం సంభవించినప్పుడు రకం తిరిగి వచ్చింది.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// మార్పిడిని చేస్తుంది.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// కొన్ని పరిస్థితులలో నియంత్రిత మార్గంలో విఫలమయ్యే సాధారణ మరియు సురక్షితమైన రకం మార్పిడులు.ఇది [`TryInto`] యొక్క పరస్పరం.
///
/// మీరు టైప్ కన్వర్షన్ చేస్తున్నప్పుడు ఇది ఉపయోగపడుతుంది, ఇది చిన్నవిషయం విజయవంతం కావచ్చు కాని ప్రత్యేక నిర్వహణ అవసరం కావచ్చు.
/// ఉదాహరణకు, [`From`] trait ను ఉపయోగించి [`i64`] ను [`i32`] గా మార్చడానికి మార్గం లేదు, ఎందుకంటే [`i64`] లో [`i32`] ప్రాతినిధ్యం వహించలేని విలువను కలిగి ఉండవచ్చు మరియు మార్పిడి డేటాను కోల్పోతుంది.
///
/// [`i64`] ను [`i32`] కు కత్తిరించడం ద్వారా (ముఖ్యంగా [`i64`] యొక్క విలువ మాడ్యులో [`i32::MAX`] ఇవ్వడం ద్వారా) లేదా [`i32::MAX`] ను తిరిగి ఇవ్వడం ద్వారా లేదా ఇతర పద్ధతుల ద్వారా దీనిని నిర్వహించవచ్చు.
/// [`From`] trait పరిపూర్ణ మార్పిడుల కోసం ఉద్దేశించబడింది, కాబట్టి `TryFrom` trait ఒక రకం మార్పిడి చెడుగా ఉన్నప్పుడు ప్రోగ్రామర్‌కు తెలియజేస్తుంది మరియు దానిని ఎలా నిర్వహించాలో నిర్ణయించడానికి వీలు కల్పిస్తుంది.
///
/// # సాధారణ అమలులు
///
/// - `TryFrom<T> for U` T`<U>కోసం</u> [`tryInto`]` <U>ను సూచిస్తుంది</u>
/// - [`try_from`] రిఫ్లెక్సివ్, అంటే `TryFrom<T> for T` అమలు చేయబడింది మరియు విఫలం కాదు-`T` రకం `T` విలువపై `T::try_from()` కి కాల్ చేయడానికి అనుబంధిత `Error` రకం [`Infallible`].
/// [`!`] రకం స్థిరీకరించబడినప్పుడు [`Infallible`] మరియు [`!`] సమానంగా ఉంటాయి.
///
/// `TryFrom<T>` ఈ క్రింది విధంగా అమలు చేయవచ్చు:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// వివరించినట్లుగా, [`i32`] `ట్రైఫ్రామ్ <` [`i64`]`>`ను అమలు చేస్తుంది:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // `big_number` ని నిశ్శబ్దంగా కత్తిరించుకుంటుంది, వాస్తవం తర్వాత కత్తిరించడం గుర్తించడం మరియు నిర్వహించడం అవసరం.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // `big_number` `i32` లో సరిపోయేంత పెద్దదిగా ఉన్నందున లోపం తిరిగి వస్తుంది.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` ను అందిస్తుంది.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// మార్పిడి లోపం సంభవించినప్పుడు రకం తిరిగి వచ్చింది.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// మార్పిడిని చేస్తుంది.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// జెనెరిక్ IMPLS
////////////////////////////////////////////////////////////////////////////////

// లిఫ్ట్ ఓవర్&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// &mut కంటే ఎక్కువ లిఫ్ట్‌లుగా
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): &/&mut కోసం పై ఇంప్ల్స్‌ను ఈ క్రింది సాధారణ వాటితో భర్తీ చేయండి:
// // డెరెఫ్ మీద లిఫ్టులుగా
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U :? పరిమాణం> <U>D {fn as_ref(&self)-> &U</u> for <U>కోసం AsRef</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut &mut కంటే ఎక్కువ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): &mut కోసం పైన పేర్కొన్న impl ని ఈ క్రింది వాటితో భర్తీ చేయండి:
// // అస్మట్ డెరెఫ్ మట్ పైకి ఎత్తింది
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U :? పరిమాణం> <U>D {fn as_mut(&mut self) కోసం AsMut-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// నుండి సూచిస్తుంది
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// నుండి (అందువలన) రిఫ్లెక్సివ్
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **స్థిరత్వ గమనిక:** ఈ impl ఇంకా ఉనికిలో లేదు, కానీ మేము దానిని future లో జోడించడానికి "reserving space".
/// వివరాల కోసం [rust-lang/rust#64715][#64715] చూడండి.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): బదులుగా సూత్రప్రాయమైన పరిష్కారాన్ని చేయండి.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// ట్రైఫ్రోమ్ ట్రైఇంటోను సూచిస్తుంది
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// తప్పులేని మార్పిడులు జనావాసాలు లేని దోష రకంతో తప్పుగా మారడానికి అర్థవంతంగా సమానం.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS ని కాన్క్రేట్ చేయండి
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// నో-ఎర్రర్ ఎర్రర్ టైప్
////////////////////////////////////////////////////////////////////////////////

/// ఎప్పుడూ జరగని లోపాల కోసం లోపం రకం.
///
/// ఈ ఎనుమ్‌కు వేరియంట్ లేనందున, ఈ రకమైన విలువ వాస్తవానికి ఎప్పుడూ ఉండదు.
/// ఫలితం ఎల్లప్పుడూ [`Ok`] అని సూచించడానికి, [`Result`] ను ఉపయోగించే మరియు లోపం రకాన్ని పారామితి చేసే సాధారణ API లకు ఇది ఉపయోగపడుతుంది.
///
/// ఉదాహరణకు, [`TryFrom`] trait ([`Result`] ను తిరిగి ఇచ్చే మార్పిడి) రివర్స్ [`Into`] అమలు ఉన్న అన్ని రకాల కోసం దుప్పటి అమలును కలిగి ఉంటుంది.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future అనుకూలత
///
/// ఈ ఎనుమ్ [the `!`“never”type][never] వలె ఉంటుంది, ఇది Rust యొక్క ఈ సంస్కరణలో అస్థిరంగా ఉంటుంది.
/// `!` స్థిరీకరించబడినప్పుడు, మేము `Infallible` ను దానికి మారుపేరుగా మార్చాలని ప్లాన్ చేస్తున్నాము:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …మరియు చివరికి `Infallible` ను తీసివేస్తుంది.
///
/// అయినప్పటికీ, `!` పూర్తి స్థాయి రకంగా స్థిరీకరించబడటానికి ముందు `!` సింటాక్స్ ఉపయోగించబడే ఒక సందర్భం ఉంది: ఫంక్షన్ యొక్క రిటర్న్ రకం స్థానంలో.
/// ప్రత్యేకంగా, రెండు వేర్వేరు ఫంక్షన్ పాయింటర్ రకాలు సాధ్యమయ్యే అమలులు:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// `Infallible` ఒక ఎన్యూమ్ కావడంతో, ఈ కోడ్ చెల్లుతుంది.
/// అయినప్పటికీ, `Infallible` ever type కు మారుపేరుగా మారినప్పుడు, రెండు `impl` లు అతివ్యాప్తి చెందడం ప్రారంభమవుతాయి మరియు అందువల్ల భాష యొక్క trait పొందిక నియమాల ద్వారా అనుమతించబడదు.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}