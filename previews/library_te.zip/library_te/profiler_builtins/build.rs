//! `compiler-rt` లైబ్రరీ యొక్క ప్రొఫైలర్ భాగాన్ని కంపైల్ చేస్తుంది.
//!
//! వివరాల కోసం libcompiler_builtins crate కోసం build.rs చూడండి.

use std::env;
use std::path::Path;

fn main() {
    let target = env::var("TARGET").expect("TARGET was not set");
    let cfg = &mut cc::Build::new();

    // FIXME: `rerun-if-changed` ఆదేశాలు ప్రస్తుతం విడుదల చేయబడలేదు మరియు బిల్డ్ స్క్రిప్ట్
    // ఈ సోర్స్ ఫైళ్ళలో మార్పులు లేదా వాటిలో చేర్చబడిన శీర్షికలపై తిరిగి అమలు చేయదు.
    let mut profile_sources = vec![
        "GCDAProfiling.c",
        "InstrProfiling.c",
        "InstrProfilingBuffer.c",
        "InstrProfilingFile.c",
        "InstrProfilingMerge.c",
        "InstrProfilingMergeFile.c",
        "InstrProfilingNameVar.c",
        "InstrProfilingPlatformDarwin.c",
        "InstrProfilingPlatformFuchsia.c",
        "InstrProfilingPlatformLinux.c",
        "InstrProfilingPlatformOther.c",
        "InstrProfilingPlatformWindows.c",
        "InstrProfilingUtil.c",
        "InstrProfilingValue.c",
        "InstrProfilingVersionVar.c",
        "InstrProfilingWriter.c",
        // ఈ ఫైల్ పేరు LLVM 10 లో మార్చబడింది.
        "InstrProfilingRuntime.cc",
        "InstrProfilingRuntime.cpp",
        // ఈ ఫైళ్ళను LLVM 11 లో చేర్చారు.
        "InstrProfilingInternal.c",
        "InstrProfilingBiasVar.c",
    ];

    if target.contains("msvc") {
        // MSVC లో అదనపు లైబ్రరీలను లాగవద్దు
        cfg.flag("/Zl");
        profile_sources.push("WindowsMMap.c");
        cfg.define("strdup", Some("_strdup"));
        cfg.define("open", Some("_open"));
        cfg.define("fdopen", Some("_fdopen"));
        cfg.define("getpid", Some("_getpid"));
        cfg.define("fileno", Some("_fileno"));
    } else {
        // gcc యొక్క వివిధ లక్షణాలను ఆపివేయండి మరియు ఇప్పటికే కంపైలర్-rt యొక్క బిల్డ్ సిస్టమ్‌ను ఎక్కువగా కాపీ చేస్తుంది
        //
        cfg.flag("-fno-builtin");
        cfg.flag("-fomit-frame-pointer");
        cfg.define("VISIBILITY_HIDDEN", None);
        if !target.contains("windows") {
            cfg.flag("-fvisibility=hidden");
            cfg.define("COMPILER_RT_HAS_UNAME", Some("1"));
        } else {
            profile_sources.push("WindowsMMap.c");
        }
    }

    // fnctl() అందుబాటులో ఉన్నందున మేము దీనిని నిర్మిస్తున్న యునిక్స్
    if env::var_os("CARGO_CFG_UNIX").is_some() {
        cfg.define("COMPILER_RT_HAS_FCNTL_LCK", Some("1"));
    }

    // COMPILER_RT_HAS_ATOMICS ను ఎప్పుడు సెట్ చేయాలో ఇది చాలా మంచి హ్యూరిస్టిక్ అయి ఉండాలి
    //
    if env::var_os("CARGO_CFG_TARGET_HAS_ATOMIC")
        .map(|features| features.to_string_lossy().to_lowercase().contains("ptr"))
        .unwrap_or(false)
    {
        cfg.define("COMPILER_RT_HAS_ATOMICS", Some("1"));
    }

    // మేము అమలు చేయబోతున్నట్లయితే ఇది ఉనికిలో ఉందని గమనించండి (లేకపోతే మేము ప్రొఫైలర్ బిల్డిన్‌లను అస్సలు నిర్మించము).
    //
    let root = Path::new("../../src/llvm-project/compiler-rt");

    let src_root = root.join("lib").join("profile");
    for src in profile_sources {
        let path = src_root.join(src);
        if path.exists() {
            cfg.file(path);
        }
    }

    cfg.include(root.join("include"));
    cfg.warnings(false);
    cfg.compile("profiler-rt");
}