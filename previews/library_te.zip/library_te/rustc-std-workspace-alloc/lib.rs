#![feature(no_core)]
#![no_core]

// ఈ crate ఎందుకు అవసరమో rustc-std-వర్క్‌స్పేస్-కోర్ చూడండి.

// లిబాలోక్‌లోని కేటాయింపు మాడ్యూల్‌తో విభేదించకుండా ఉండటానికి crate పేరు మార్చండి.
extern crate alloc as foo;

pub use foo::*;