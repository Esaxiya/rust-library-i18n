use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // మూడవ పార్టీ కేటాయింపుదారులు మరియు `RawVec` ల మధ్య సమైక్యత పరీక్ష రాయడం కొంచెం గమ్మత్తైనది, ఎందుకంటే `RawVec` API తప్పుగా కేటాయించదగిన కేటాయింపు పద్ధతులను బహిర్గతం చేయదు, కాబట్టి కేటాయింపు అయిపోయినప్పుడు ఏమి జరుగుతుందో మేము తనిఖీ చేయలేము (panic ను గుర్తించకుండా).
    //
    //
    // బదులుగా, ఇది నిల్వను రిజర్వ్ చేసినప్పుడు `RawVec` పద్ధతులు కనీసం కేటాయింపు API ద్వారా వెళ్తాయో లేదో తనిఖీ చేస్తుంది.
    //
    //
    //
    //
    //

    // కేటాయింపు ప్రయత్నాలు విఫలమయ్యే ముందు నిర్ణీత మొత్తంలో ఇంధనాన్ని వినియోగించే మూగ కేటాయింపు.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (రీలాక్‌కు కారణమవుతుంది, తద్వారా 50 + 150=200 యూనిట్ల ఇంధనాన్ని ఉపయోగిస్తుంది)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // మొదట, `reserve` `reserve_exact` వంటి కేటాయింపులు.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 7 కంటే రెట్టింపు, కాబట్టి `reserve` `reserve_exact` లాగా పనిచేయాలి.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 12 లో సగం కంటే తక్కువ, కాబట్టి `reserve` విపరీతంగా పెరుగుతుంది.
        // ఈ టెస్ట్ గ్రో కారకం రాసే సమయంలో 2, కాబట్టి కొత్త సామర్థ్యం 24, అయితే, 1.5 యొక్క పెరుగుదల కారకం కూడా సరే.
        //
        // అందువల్ల `>= 18` నిశ్చయించుకోండి.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}