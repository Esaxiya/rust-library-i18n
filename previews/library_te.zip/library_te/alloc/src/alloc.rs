//! మెమరీ కేటాయింపు API లు

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // గ్లోబల్ కేటాయింపుదారుని పిలవడానికి ఇవి మేజిక్ చిహ్నాలు.rustc వాటిని `__rg_alloc` మొదలైన వాటికి కాల్ చేస్తుంది.
    // ఒక `#[global_allocator]` లక్షణం ఉంటే (ఆ లక్షణం స్థూల మాక్రో ఆ ఫంక్షన్లను ఉత్పత్తి చేస్తుంది), లేదా libstd (`__rdl_alloc` మొదలైనవి) లో డిఫాల్ట్ అమలులను పిలుస్తుంది.
    //
    // `library/std/src/alloc.rs` లో) లేకపోతే.
    // LLVM యొక్క rustc fork కూడా ప్రత్యేక సందర్భాలలో ఈ ఫంక్షన్ పేర్లు వరుసగా `malloc`, `realloc` మరియు `free` వంటి వాటిని ఆప్టిమైజ్ చేయగలవు.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// గ్లోబల్ మెమరీ కేటాయింపు.
///
/// ఈ రకం [`Allocator`] trait ను `#[global_allocator]` లక్షణంతో రిజిస్టర్ చేయబడిన కేటాయింపుకు ఒకటి లేదా `std` crate యొక్క డిఫాల్ట్ ఉంటే ఫార్వార్డ్ చేయడం ద్వారా అమలు చేస్తుంది.
///
///
/// Note: ఈ రకం అస్థిరంగా ఉన్నప్పటికీ, ఇది అందించే కార్యాచరణను [free functions in `alloc`](self#functions) ద్వారా యాక్సెస్ చేయవచ్చు.
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// గ్లోబల్ కేటాయింపుతో మెమరీని కేటాయించండి.
///
/// ఈ ఫంక్షన్ `#[global_allocator]` లక్షణంతో రిజిస్టర్ చేయబడిన కేటాయింపు యొక్క [`GlobalAlloc::alloc`] పద్ధతికి కాల్స్ ఒకటి లేదా `std` crate యొక్క డిఫాల్ట్కు కాల్ చేస్తుంది.
///
///
/// ఈ ఫంక్షన్ [`Global`] రకం మరియు [`Allocator`] trait స్థిరంగా మారినప్పుడు [`Global`] రకం యొక్క `alloc` పద్ధతికి అనుకూలంగా తీసివేయబడుతుంది.
///
/// # Safety
///
/// [`GlobalAlloc::alloc`] చూడండి.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// గ్లోబల్ కేటాయింపుతో మెమరీని కేటాయించండి.
///
/// ఈ ఫంక్షన్ `#[global_allocator]` లక్షణంతో రిజిస్టర్ చేయబడిన కేటాయింపు యొక్క [`GlobalAlloc::dealloc`] పద్ధతికి కాల్స్ ఒకటి లేదా `std` crate యొక్క డిఫాల్ట్కు కాల్ చేస్తుంది.
///
///
/// ఈ ఫంక్షన్ [`Global`] రకం మరియు [`Allocator`] trait స్థిరంగా మారినప్పుడు [`Global`] రకం యొక్క `dealloc` పద్ధతికి అనుకూలంగా తీసివేయబడుతుంది.
///
/// # Safety
///
/// [`GlobalAlloc::dealloc`] చూడండి.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// గ్లోబల్ కేటాయింపుతో మెమరీని తిరిగి కేటాయించండి.
///
/// ఈ ఫంక్షన్ `#[global_allocator]` లక్షణంతో రిజిస్టర్ చేయబడిన కేటాయింపు యొక్క [`GlobalAlloc::realloc`] పద్ధతికి కాల్స్ ఒకటి లేదా `std` crate యొక్క డిఫాల్ట్కు కాల్ చేస్తుంది.
///
///
/// ఈ ఫంక్షన్ [`Global`] రకం మరియు [`Allocator`] trait స్థిరంగా మారినప్పుడు [`Global`] రకం యొక్క `realloc` పద్ధతికి అనుకూలంగా తీసివేయబడుతుంది.
///
/// # Safety
///
/// [`GlobalAlloc::realloc`] చూడండి.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// గ్లోబల్ కేటాయింపుతో సున్నా-ప్రారంభ మెమరీని కేటాయించండి.
///
/// ఈ ఫంక్షన్ `#[global_allocator]` లక్షణంతో రిజిస్టర్ చేయబడిన కేటాయింపు యొక్క [`GlobalAlloc::alloc_zeroed`] పద్ధతికి కాల్స్ ఒకటి లేదా `std` crate యొక్క డిఫాల్ట్కు కాల్ చేస్తుంది.
///
///
/// ఈ ఫంక్షన్ [`Global`] రకం మరియు [`Allocator`] trait స్థిరంగా మారినప్పుడు [`Global`] రకం యొక్క `alloc_zeroed` పద్ధతికి అనుకూలంగా తీసివేయబడుతుంది.
///
/// # Safety
///
/// [`GlobalAlloc::alloc_zeroed`] చూడండి.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // భద్రత: `layout` పరిమాణం సున్నా కానిది,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // భద్రత: `Allocator::grow` వలె ఉంటుంది
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // భద్రత: `old_size` సున్నా కానిది, ఎందుకంటే `old_size` `new_size` కన్నా ఎక్కువ లేదా సమానంగా ఉంటుంది
            // భద్రతా పరిస్థితుల ప్రకారం అవసరం.ఇతర షరతులను తప్పనిసరిగా కాలర్ సమర్థించాలి
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` బహుశా `new_size >= old_layout.size()` లేదా ఇలాంటి వాటి కోసం తనిఖీ చేస్తుంది.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // భద్రత: ఎందుకంటే `new_layout.size()` తప్పనిసరిగా `old_size` కన్నా ఎక్కువ లేదా సమానంగా ఉండాలి,
            // పాత మరియు క్రొత్త మెమరీ కేటాయింపు రెండూ `old_size` బైట్‌ల కోసం చదవడానికి మరియు వ్రాయడానికి చెల్లుతాయి.
            // అలాగే, పాత కేటాయింపు ఇంకా విడదీయబడలేదు కాబట్టి, ఇది `new_ptr` ను అతివ్యాప్తి చేయదు.
            // అందువలన, `copy_nonoverlapping` కు కాల్ సురక్షితం.
            // `dealloc` కోసం భద్రతా ఒప్పందాన్ని కాలర్ సమర్థించాలి.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // భద్రత: `layout` పరిమాణం సున్నా కానిది,
            // ఇతర షరతులను కాలర్ సమర్థించాలి
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // భద్రత: అన్ని షరతులను కాలర్ సమర్థించాలి
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // భద్రత: అన్ని షరతులను కాలర్ సమర్థించాలి
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // భద్రత: షరతులను తప్పనిసరిగా కాలర్ సమర్థించాలి
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // భద్రత: `new_size` సున్నా కానిది.ఇతర షరతులను తప్పనిసరిగా కాలర్ సమర్థించాలి
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` బహుశా `new_size <= old_layout.size()` లేదా ఇలాంటి వాటి కోసం తనిఖీ చేస్తుంది.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // భద్రత: ఎందుకంటే `new_size` తప్పనిసరిగా `old_layout.size()` కన్నా చిన్నదిగా లేదా సమానంగా ఉండాలి,
            // పాత మరియు క్రొత్త మెమరీ కేటాయింపు రెండూ `new_size` బైట్‌ల కోసం చదవడానికి మరియు వ్రాయడానికి చెల్లుతాయి.
            // అలాగే, పాత కేటాయింపు ఇంకా విడదీయబడలేదు కాబట్టి, ఇది `new_ptr` ను అతివ్యాప్తి చేయదు.
            // అందువలన, `copy_nonoverlapping` కు కాల్ సురక్షితం.
            // `dealloc` కోసం భద్రతా ఒప్పందాన్ని కాలర్ సమర్థించాలి.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// ప్రత్యేకమైన పాయింటర్ల కోసం కేటాయింపు.
// ఈ ఫంక్షన్ నిలిపివేయకూడదు.అలా చేస్తే, MIR కోడజెన్ విఫలమవుతుంది.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// ఈ సంతకం `Box` లాగా ఉండాలి, లేకపోతే ICE జరుగుతుంది.
// `Box` కి అదనపు పరామితి జోడించబడినప్పుడు (`A: Allocator` వంటిది), ఇది ఇక్కడ కూడా జోడించబడాలి.
// ఉదాహరణకు, `Box` ను `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` గా మార్చినట్లయితే, ఈ ఫంక్షన్‌ను `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` కు కూడా మార్చాలి.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # కేటాయింపు లోపం హ్యాండ్లర్

extern "Rust" {
    // గ్లోబల్ కేటాయింపు లోపం హ్యాండ్లర్ అని పిలవడానికి ఇది మేజిక్ చిహ్నం.
    // `#[alloc_error_handler]` ఉంటే `__rg_oom` కి కాల్ చేయడానికి లేదా (`__rdl_oom`) క్రింద డిఫాల్ట్ అమలులను పిలవడానికి rustc ఉత్పత్తి చేస్తుంది.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// మెమరీ కేటాయింపు లోపం లేదా వైఫల్యాన్ని ఆపివేయండి.
///
/// కేటాయింపు లోపానికి ప్రతిస్పందనగా గణనను నిలిపివేయాలనుకునే మెమరీ కేటాయింపు API లను పిలిచేవారు ఈ ఫంక్షన్‌ను నేరుగా `panic!` లేదా ఇలాంటి వాటితో ప్రారంభించకుండా ప్రోత్సహించబడతారు.
///
///
/// ఈ ఫంక్షన్ యొక్క డిఫాల్ట్ ప్రవర్తన ఒక సందేశాన్ని ప్రామాణిక లోపానికి ముద్రించడం మరియు ప్రక్రియను నిలిపివేయడం.
/// దీనిని [`set_alloc_error_hook`] మరియు [`take_alloc_error_hook`] తో భర్తీ చేయవచ్చు.
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// కేటాయింపు పరీక్ష కోసం `std::alloc::handle_alloc_error` ను నేరుగా ఉపయోగించవచ్చు.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // ఉత్పత్తి చేయబడిన `__rust_alloc_error_handler` ద్వారా పిలుస్తారు

    // `#[alloc_error_handler]` లేకపోతే
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // `#[alloc_error_handler]` ఉంటే
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// ముందుగా కేటాయించిన, ప్రారంభించని మెమరీలో క్లోన్‌లను ప్రత్యేకపరచండి.
/// `Box::clone` మరియు `Rc`/`Arc::make_mut` ద్వారా ఉపయోగించబడుతుంది.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // *మొదట* కేటాయించిన తరువాత, ఆప్టిమైజర్ క్లోన్ చేసిన విలువను స్థలంలో సృష్టించడానికి, స్థానికంగా దాటవేయడానికి మరియు తరలించడానికి అనుమతిస్తుంది.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // స్థానిక విలువతో సంబంధం లేకుండా మేము ఎల్లప్పుడూ స్థలంలో కాపీ చేయవచ్చు.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}