// ఇది ఆదర్శాన్ని అనుసరించి అమలు చేసే ప్రయత్నం
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Rust కి వాస్తవానికి ఆధారిత రకాలు మరియు పాలిమార్ఫిక్ పునరావృతం లేనందున, మేము చాలా అసురక్షితతతో చేస్తాము.
//

// ఈ మాడ్యూల్ యొక్క ప్రధాన లక్ష్యం ఏమిటంటే, చెట్టును సాధారణ (విచిత్రమైన ఆకారంలో ఉంటే) కంటైనర్‌గా పరిగణించడం ద్వారా మరియు బి-ట్రీ మార్పులతో వ్యవహరించకుండా ఉండడం ద్వారా సంక్లిష్టతను నివారించడం.
//
// అందుకని, ఈ మాడ్యూల్ ఎంట్రీలు క్రమబద్ధీకరించబడిందా, ఏ నోడ్లు అండర్ ఫుల్ కావచ్చు లేదా అండర్ ఫుల్ అంటే ఏమిటో కూడా పట్టించుకోవు.అయితే, మేము కొన్ని మార్పులపై ఆధారపడతాము:
//
// - చెట్లు ఏకరీతి depth/height కలిగి ఉండాలి.దీని అర్థం, ఇచ్చిన నోడ్ నుండి ఆకుకు క్రిందికి వచ్చే ప్రతి మార్గం సరిగ్గా ఒకే పొడవు కలిగి ఉంటుంది.
// - `n` పొడవు యొక్క నోడ్‌లో `n` కీలు, `n` విలువలు మరియు `n + 1` అంచులు ఉన్నాయి.
//   ఖాళీ నోడ్‌లో కనీసం ఒక edge ఉందని ఇది సూచిస్తుంది.
//   ఆకు నోడ్ కోసం, "having an edge" అంటే మనం నోడ్‌లో ఒక స్థానాన్ని గుర్తించగలము, ఎందుకంటే ఆకు అంచులు ఖాళీగా ఉన్నాయి మరియు డేటా ప్రాతినిధ్యం అవసరం లేదు.
// అంతర్గత నోడ్‌లో, edge రెండూ ఒక స్థానాన్ని గుర్తిస్తాయి మరియు పిల్లల నోడ్‌కు పాయింటర్‌ను కలిగి ఉంటాయి.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// ఆకు నోడ్ల యొక్క అంతర్లీన ప్రాతినిధ్యం మరియు అంతర్గత నోడ్ల ప్రాతినిధ్యంలో భాగం.
struct LeafNode<K, V> {
    /// మేము `K` మరియు `V` లలో కోవియారిట్ అవ్వాలనుకుంటున్నాము.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// ఈ నోడ్ యొక్క సూచిక పేరెంట్ నోడ్ యొక్క `edges` శ్రేణిలోకి.
    /// `*node.parent.edges[node.parent_idx]` `node` వలె ఉండాలి.
    /// `parent` శూన్యంగా లేనప్పుడు మాత్రమే ఇది ప్రారంభించబడుతుందని హామీ ఇవ్వబడింది.
    parent_idx: MaybeUninit<u16>,

    /// ఈ నోడ్ నిల్వ చేసే కీలు మరియు విలువల సంఖ్య.
    len: u16,

    /// నోడ్ యొక్క వాస్తవ డేటాను నిల్వ చేసే శ్రేణులు.
    /// ప్రతి శ్రేణి యొక్క మొదటి `len` అంశాలు మాత్రమే ప్రారంభించబడ్డాయి మరియు చెల్లుతాయి.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// క్రొత్త `LeafNode` స్థానంలో ప్రారంభిస్తుంది.
    unsafe fn init(this: *mut Self) {
        // సాధారణ విధానంగా, మేము ఫీల్డ్‌లను ప్రారంభించగలిగితే వాటిని ప్రారంభించకుండా వదిలివేస్తాము, ఎందుకంటే ఇది వాల్‌గ్రైండ్‌లో ట్రాక్ చేయడం కొంచెం వేగంగా మరియు సులభంగా ఉండాలి.
        //
        unsafe {
            // పేరెంట్_ఐడిఎక్స్, కీలు మరియు వాల్స్ అన్నీ బహుశా యునినిట్
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// క్రొత్త బాక్స్డ్ `LeafNode` ను సృష్టిస్తుంది.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// అంతర్గత నోడ్ల యొక్క అంతర్లీన ప్రాతినిధ్యం.`లీఫ్‌నోడ్'ల మాదిరిగానే, ప్రారంభించని కీలు మరియు విలువలను వదలకుండా ఉండటానికి వీటిని` బాక్స్‌నోడ్'ల వెనుక దాచాలి.
/// `InternalNode` కు ఏదైనా పాయింటర్‌ను నోడ్ యొక్క అంతర్లీన `LeafNode` భాగానికి నేరుగా పాయింటర్‌కు ప్రసారం చేయవచ్చు, ఇది ఒక పాయింటర్ ఎత్తి చూపిన రెండింటిలో ఏది కూడా తనిఖీ చేయకుండా కోడ్ సాధారణంగా ఆకు మరియు అంతర్గత నోడ్‌లపై పనిచేయడానికి అనుమతిస్తుంది.
///
/// ఈ ఆస్తి `repr(C)` వాడకం ద్వారా ప్రారంభించబడుతుంది.
///
#[repr(C)]
// gdb_providers.py ఆత్మపరిశీలన కోసం ఈ రకం పేరును ఉపయోగిస్తుంది.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// ఈ నోడ్ యొక్క పిల్లలకు పాయింటర్లు.
    /// `len + 1` వీటిలో ప్రారంభ మరియు చెల్లుబాటు అయ్యేవిగా పరిగణించబడతాయి, చివరలో తప్ప, చెట్టు రుణ రకం `Dying` ద్వారా పట్టుకోగా, ఈ పాయింటర్లలో కొన్ని డాంగ్లింగ్.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// క్రొత్త బాక్స్డ్ `InternalNode` ను సృష్టిస్తుంది.
    ///
    /// # Safety
    /// అంతర్గత నోడ్‌ల యొక్క మార్పు ఏమిటంటే అవి కనీసం ఒక ప్రారంభ మరియు చెల్లుబాటు అయ్యే edge ను కలిగి ఉంటాయి.
    /// ఈ ఫంక్షన్ అటువంటి edge ని సెటప్ చేయదు.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // మేము డేటాను మాత్రమే ప్రారంభించాలి;అంచులు బహుశా యునినిట్.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// ఒక నోడ్‌కు నిర్వహించబడే, శూన్యమైన పాయింటర్.ఇది `LeafNode<K, V>` కు యాజమాన్యంలోని పాయింటర్ లేదా `InternalNode<K, V>` కు యాజమాన్యంలోని పాయింటర్.
///
/// ఏది ఏమయినప్పటికీ, `BoxedNode` లో రెండు రకాల నోడ్లలో ఏది వాస్తవంగా ఉందనే దానిపై ఎటువంటి సమాచారం లేదు, మరియు పాక్షికంగా ఈ సమాచారం లేకపోవడం వల్ల, ప్రత్యేక రకం కాదు మరియు డిస్ట్రక్టర్ లేదు.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// యాజమాన్యంలోని చెట్టు యొక్క మూల నోడ్.
///
/// దీనికి డిస్ట్రక్టర్ లేదని గమనించండి మరియు మానవీయంగా శుభ్రం చేయాలి.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// ప్రారంభంలో ఖాళీగా ఉన్న దాని స్వంత రూట్ నోడ్‌తో కొత్త యాజమాన్యంలోని చెట్టును అందిస్తుంది.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` సున్నాగా ఉండకూడదు.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// యాజమాన్యంలోని రూట్ నోడ్‌ను పరస్పరం తీసుకుంటుంది.
    /// `reborrow_mut` మాదిరిగా కాకుండా, ఇది సురక్షితం ఎందుకంటే రిటర్న్ విలువను రూట్‌ను నాశనం చేయడానికి ఉపయోగించలేము మరియు చెట్టుకు ఇతర సూచనలు ఉండకూడదు.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// యాజమాన్యంలోని రూట్ నోడ్‌ను కొద్దిగా మార్చవచ్చు.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ట్రావెర్సల్‌ను అనుమతించే మరియు విధ్వంసక పద్ధతులను అందించే సూచనకు తిరిగి మార్చలేని పరివర్తనాలు మరియు మరికొన్ని.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// మునుపటి రూట్ నోడ్‌కు సూచించే ఒకే edge తో కొత్త అంతర్గత నోడ్‌ను జోడిస్తుంది, ఆ కొత్త నోడ్‌ను రూట్ నోడ్‌గా చేసి, దాన్ని తిరిగి ఇవ్వండి.
    /// ఇది ఎత్తు 1 ని పెంచుతుంది మరియు ఇది `pop_internal_level` కి వ్యతిరేకం.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, మేము ఇప్పుడు అంతర్గతంగా మర్చిపోయాము తప్ప:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// అంతర్గత రూట్ నోడ్‌ను తొలగిస్తుంది, దాని మొదటి బిడ్డను కొత్త రూట్ నోడ్‌గా ఉపయోగిస్తుంది.
    /// రూట్ నోడ్‌కు ఒకే సంతానం ఉన్నప్పుడు మాత్రమే పిలవాలని ఉద్దేశించినందున, కీలు, విలువలు మరియు ఇతర పిల్లలలో దేనినైనా శుభ్రపరచడం జరుగుతుంది.
    ///
    /// ఇది ఎత్తు 1 తగ్గిస్తుంది మరియు ఇది `push_internal_level` కి వ్యతిరేకం.
    ///
    /// `Root` ఆబ్జెక్ట్‌కు ప్రత్యేక ప్రాప్యత అవసరం కాని రూట్ నోడ్‌కు కాదు;
    /// ఇది రూట్ నోడ్‌కు ఇతర హ్యాండిల్స్ లేదా రిఫరెన్స్‌లను చెల్లదు.
    ///
    /// అంతర్గత స్థాయి లేకపోతే Panics, అంటే, రూట్ నోడ్ ఒక ఆకు అయితే.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // భద్రత: మేము అంతర్గతంగా ఉన్నట్లు నొక్కిచెప్పాము.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // భద్రత: మేము ప్రత్యేకంగా `self` ను అరువుగా తీసుకున్నాము మరియు దాని రుణ రకం ప్రత్యేకమైనది.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // భద్రత: మొదటి edge ఎల్లప్పుడూ ప్రారంభించబడుతుంది.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `BorrowType` `K` మరియు `V` లలో ఎల్లప్పుడూ సమిష్టిగా ఉంటుంది, `BorrowType` `Mut` అయినప్పటికీ.
// ఇది సాంకేతికంగా తప్పు, కానీ `NodeRef` యొక్క అంతర్గత ఉపయోగం కారణంగా ఎటువంటి అసురక్షితత ఏర్పడదు ఎందుకంటే మేము `K` మరియు `V` కన్నా పూర్తిగా సాధారణం.
//
// ఏదేమైనా, పబ్లిక్ రకం `NodeRef` ను చుట్టేసినప్పుడు, దానికి సరైన వైవిధ్యం ఉందని నిర్ధారించుకోండి.
//
/// నోడ్‌కు సూచన.
///
/// ఈ రకంలో ఇది ఎలా పనిచేస్తుందో నియంత్రించే అనేక పారామితులు ఉన్నాయి:
/// - `BorrowType`: రుణాల రకాన్ని వివరించే మరియు జీవితకాలం తీసుకునే డమ్మీ రకం.
///    - ఇది `Immut<'a>` అయినప్పుడు, `NodeRef` సుమారుగా `&'a Node` లాగా పనిచేస్తుంది.
///    - ఇది `ValMut<'a>` అయినప్పుడు, `NodeRef` కీలు మరియు చెట్ల నిర్మాణానికి సంబంధించి `&'a Node` లాగా పనిచేస్తుంది, కానీ చెట్టు అంతటా ఉన్న విలువలకు అనేక పరివర్తన సూచనలను సహజీవనం చేయడానికి అనుమతిస్తుంది.
///    - ఇది `Mut<'a>` అయినప్పుడు, `NodeRef` సుమారుగా `&'a mut Node` లాగా పనిచేస్తుంది, అయినప్పటికీ చొప్పించే పద్ధతులు ఒక మ్యూటబుల్ పాయింటర్‌ను ఒక విలువకు సహజీవనం చేయడానికి అనుమతిస్తాయి.
///    - ఇది `Owned` అయినప్పుడు, `NodeRef` సుమారుగా `Box<Node>` లాగా పనిచేస్తుంది, కానీ డిస్ట్రక్టర్ లేదు మరియు మానవీయంగా శుభ్రం చేయాలి.
///    - ఇది `Dying` అయినప్పుడు, `NodeRef` ఇప్పటికీ సుమారుగా `Box<Node>` లాగా పనిచేస్తుంది, కానీ చెట్టును బిట్ ద్వారా నాశనం చేసే పద్ధతులను కలిగి ఉంది, మరియు సాధారణ పద్ధతులు, కాల్ చేయడం సురక్షితం కాదని గుర్తించబడనప్పటికీ, తప్పుగా పిలిస్తే UB ని ప్రారంభించవచ్చు.
///
///   ఏదైనా `NodeRef` చెట్టు ద్వారా నావిగేట్ చెయ్యడానికి అనుమతిస్తుంది కాబట్టి, `BorrowType` నోడ్‌కు మాత్రమే కాకుండా మొత్తం చెట్టుకు సమర్థవంతంగా వర్తిస్తుంది.
/// - `K` మరియు `V`: ఇవి నోడ్స్‌లో నిల్వ చేయబడిన కీలు మరియు విలువల రకాలు.
/// - `Type`: ఇది `Leaf`, `Internal` లేదా `LeafOrInternal` కావచ్చు.
/// ఇది `Leaf` అయినప్పుడు, `NodeRef` ఒక ఆకు నోడ్‌కు సూచిస్తుంది, ఇది `Internal` అయినప్పుడు `NodeRef` అంతర్గత నోడ్‌కు సూచిస్తుంది మరియు ఇది `LeafOrInternal` అయినప్పుడు `NodeRef` రెండు రకాల నోడ్‌లను సూచిస్తుంది.
///   `Type` `NodeRef` వెలుపల ఉపయోగించినప్పుడు `NodeType` అని పేరు పెట్టబడింది.
///
/// `BorrowType` మరియు `NodeType` రెండూ స్టాటిక్ రకం భద్రతను దోచుకోవడానికి మేము ఏ పద్ధతులను అమలు చేస్తాయో పరిమితం చేస్తాయి.మేము అలాంటి పరిమితులను వర్తించే విధంగా పరిమితులు ఉన్నాయి:
/// - ప్రతి రకం పరామితి కోసం, మేము ఒక పద్ధతిని సాధారణంగా లేదా ఒక నిర్దిష్ట రకానికి మాత్రమే నిర్వచించగలము.
/// ఉదాహరణకు, మేము అన్ని `BorrowType` కోసం `into_kv` వంటి పద్ధతిని సాధారణంగా నిర్వచించలేము, లేదా జీవితకాలం తీసుకునే అన్ని రకాల కోసం ఒకసారి, ఎందుకంటే ఇది `&'a` సూచనలను తిరిగి ఇవ్వాలనుకుంటున్నాము.
///   అందువల్ల, మేము దీన్ని తక్కువ శక్తివంతమైన రకం `Immut<'a>` కోసం మాత్రమే నిర్వచించాము.
/// - `Mut<'a>` నుండి `Immut<'a>` వరకు మేము అవ్యక్త బలవంతం పొందలేము.
///   అందువల్ల, `into_kv` వంటి పద్ధతిని చేరుకోవటానికి మేము `reborrow` ను మరింత శక్తివంతమైన `NodeRef` పై స్పష్టంగా కాల్ చేయాలి.
///
/// `NodeRef` లోని అన్ని పద్ధతులు కొన్ని రకాల సూచనలను ఇస్తాయి:
/// - విలువ ప్రకారం `self` తీసుకోండి మరియు `BorrowType` చేత జీవితకాలం తిరిగి ఇవ్వండి.
///   కొన్నిసార్లు, అటువంటి పద్ధతిని ప్రారంభించడానికి, మేము `reborrow_mut` కి కాల్ చేయాలి.
/// - రిఫరెన్స్ ద్వారా `self` తీసుకోండి మరియు (implicitly) ఆ రిఫరెన్స్ జీవితకాలం `BorrowType` చేత జీవితకాలానికి బదులుగా తిరిగి వస్తుంది.
/// ఆ విధంగా, రిటర్న్ రిఫరెన్స్ ఉపయోగించినంతవరకు `NodeRef` రుణం తీసుకున్నట్లు రుణాలు తనిఖీ చేసేవారు హామీ ఇస్తారు.
///   చొప్పించడానికి సహాయపడే పద్ధతులు ముడి పాయింటర్‌ను తిరిగి ఇవ్వడం ద్వారా ఈ నియమాన్ని వంగిస్తాయి, అనగా, జీవితకాలం లేకుండా సూచన.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// నోడ్ మరియు ఆకుల స్థాయి వేరుగా ఉన్న స్థాయిల సంఖ్య, `Type` చేత పూర్తిగా వర్ణించలేని నోడ్ యొక్క స్థిరాంకం మరియు నోడ్ కూడా నిల్వ చేయదు.
    /// మేము రూట్ నోడ్ యొక్క ఎత్తును మాత్రమే నిల్వ చేయాలి మరియు దాని నుండి ప్రతి ఇతర నోడ్ యొక్క ఎత్తును పొందాలి.
    /// `Type` `Leaf` అయితే సున్నా అయి ఉండాలి మరియు `Type` `Internal` అయితే సున్నా కానిది.
    ///
    ///
    height: usize,
    /// ఆకు లేదా అంతర్గత నోడ్‌కు పాయింటర్.
    /// `InternalNode` యొక్క నిర్వచనం పాయింటర్ ఏ విధంగానైనా చెల్లుబాటు అయ్యేలా చేస్తుంది.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// `NodeRef::parent` గా ప్యాక్ చేయబడిన నోడ్ రిఫరెన్స్‌ను అన్‌ప్యాక్ చేయండి.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// అంతర్గత నోడ్ యొక్క డేటాను బహిర్గతం చేస్తుంది.
    ///
    /// ఈ నోడ్‌కు ఇతర సూచనలను చెల్లకుండా ఉండటానికి ముడి ptr ని అందిస్తుంది.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // భద్రత: స్టాటిక్ నోడ్ రకం `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// అంతర్గత నోడ్ యొక్క డేటాకు ప్రత్యేక ప్రాప్యతను తీసుకుంటుంది.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// నోడ్ యొక్క పొడవును కనుగొంటుంది.ఇది కీలు లేదా విలువల సంఖ్య.
    /// అంచుల సంఖ్య `len() + 1`.
    /// సురక్షితంగా ఉన్నప్పటికీ, ఈ ఫంక్షన్‌ను పిలవడం అసురక్షిత కోడ్ సృష్టించిన మ్యూటబుల్ రిఫరెన్స్‌లను చెల్లని దుష్ప్రభావాన్ని కలిగిస్తుందని గమనించండి.
    ///
    pub fn len(&self) -> usize {
        // ముఖ్యంగా, మేము ఇక్కడ `len` ఫీల్డ్‌ను మాత్రమే యాక్సెస్ చేస్తాము.
        // బారోటైప్ marker::ValMut అయితే, మేము చెల్లని విలువలకు అసాధారణమైన మ్యూటబుల్ సూచనలు ఉండవచ్చు.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// నోడ్ మరియు ఆకులు వేరుగా ఉన్న స్థాయిల సంఖ్యను చూపుతుంది.
    /// సున్నా ఎత్తు అంటే నోడ్ ఒక ఆకు.
    /// మీరు పైన ఉన్న మూలంతో చెట్లను చిత్రించినట్లయితే, నోడ్ ఏ ఎత్తులో కనిపిస్తుంది అని సంఖ్య చెబుతుంది.
    /// మీరు పైన ఆకులు ఉన్న చెట్లను చిత్రించినట్లయితే, చెట్టు నోడ్ పైన ఎంత ఎత్తులో విస్తరించిందో సంఖ్య చెబుతుంది.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// అదే నోడ్‌కు తాత్కాలికంగా మరొక, మార్పులేని సూచనను తీసుకుంటుంది.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ఏదైనా ఆకు లేదా అంతర్గత నోడ్ యొక్క ఆకు భాగాన్ని బహిర్గతం చేస్తుంది.
    ///
    /// ఈ నోడ్‌కు ఇతర సూచనలను చెల్లకుండా ఉండటానికి ముడి ptr ని అందిస్తుంది.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // నోడ్ కనీసం లీఫ్నోడ్ భాగానికి చెల్లుతుంది.
        // ఇది నోడ్‌రిఫ్ రకంలో సూచన కాదు ఎందుకంటే ఇది ప్రత్యేకమైనదా లేదా భాగస్వామ్యం చేయబడిందో మాకు తెలియదు.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// ప్రస్తుత నోడ్ యొక్క పేరెంట్‌ను కనుగొంటుంది.
    /// ప్రస్తుత నోడ్‌లో వాస్తవానికి పేరెంట్ ఉంటే `Ok(handle)` ను అందిస్తుంది, ఇక్కడ `handle` ప్రస్తుత నోడ్‌కు సూచించే పేరెంట్ యొక్క edge కు సూచిస్తుంది.
    ///
    /// ప్రస్తుత నోడ్‌కు పేరెంట్ లేకపోతే `Err(self)` ని అందిస్తుంది, అసలు `NodeRef` ని తిరిగి ఇస్తుంది.
    ///
    /// పద్ధతి పేరు మీరు పైన ఉన్న రూట్ నోడ్‌తో చెట్లను చిత్రీకరిస్తుందని umes హిస్తుంది.
    ///
    /// `edge.descend().ascend().unwrap()` మరియు `node.ascend().unwrap().descend()` రెండూ విజయవంతం అయిన తర్వాత ఏమీ చేయకూడదు.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // మేము ముడి పాయింటర్లను నోడ్‌లకు ఉపయోగించాలి, ఎందుకంటే, బారోటైప్ marker::ValMut అయితే, మేము చెల్లని విలువలకు అసాధారణమైన మ్యూటబుల్ సూచనలు ఉండవచ్చు.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// `self` తప్పనిసరిగా నిరుపయోగంగా ఉండాలని గమనించండి.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// `self` తప్పనిసరిగా నిరుపయోగంగా ఉండాలని గమనించండి.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// మార్పులేని చెట్టులో ఏదైనా ఆకు లేదా అంతర్గత నోడ్ యొక్క ఆకు భాగాన్ని బహిర్గతం చేస్తుంది.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // భద్రత: `Immut` గా అరువు తెచ్చుకున్న ఈ చెట్టులోకి మార్చలేని సూచనలు ఉండవు.
        unsafe { &*ptr }
    }

    /// నోడ్‌లో నిల్వ చేసిన కీల్లోకి వీక్షణను తీసుకుంటుంది.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// `ascend` మాదిరిగానే, నోడ్ యొక్క మాతృ నోడ్‌కు సూచనను పొందుతుంది, కానీ ఈ ప్రక్రియలో ప్రస్తుత నోడ్‌ను కూడా తొలగిస్తుంది.
    /// ఇది సురక్షితం కాదు ఎందుకంటే డీలోకేట్ చేయబడినప్పటికీ ప్రస్తుత నోడ్ ఇప్పటికీ అందుబాటులో ఉంటుంది.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ఈ నోడ్ `Leaf` అని స్టాటిక్ సమాచారాన్ని కంపైలర్‌కు సురక్షితంగా నొక్కి చెబుతుంది.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ఈ నోడ్ ఒక `Internal` అని స్టాటిక్ సమాచారాన్ని కంపైలర్‌కు సురక్షితంగా నొక్కి చెబుతుంది.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// అదే నోడ్‌కు తాత్కాలికంగా మరొక, మార్చగల సూచనను తీసుకుంటుంది.జాగ్రత్త వహించండి, ఈ పద్ధతి చాలా ప్రమాదకరమైనది కాబట్టి, రెట్టింపు కాబట్టి ఇది వెంటనే ప్రమాదకరంగా కనిపించకపోవచ్చు.
    ///
    /// మార్చగల పాయింటర్లు చెట్టు చుట్టూ ఎక్కడైనా తిరుగుతాయి కాబట్టి, తిరిగి వచ్చిన పాయింటర్ అసలు పాయింటర్‌ను డాంగ్లింగ్ చేయడానికి, హద్దులు దాటి లేదా పేర్చబడిన రుణ నిబంధనల ప్రకారం చెల్లనిదిగా చేయడానికి సులభంగా ఉపయోగించవచ్చు.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) `NodeRef` కు మరో రకం పరామితిని జోడించడాన్ని పరిగణించండి, ఇది పునర్వినియోగ పాయింటర్లలో నావిగేషన్ పద్ధతుల వాడకాన్ని పరిమితం చేస్తుంది, ఈ అసురక్షితతను నివారిస్తుంది.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ఏదైనా ఆకు లేదా అంతర్గత నోడ్ యొక్క ఆకు భాగానికి ప్రత్యేకమైన ప్రాప్యతను తీసుకుంటుంది.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // భద్రత: మాకు మొత్తం నోడ్‌కు ప్రత్యేకమైన ప్రాప్యత ఉంది.
        unsafe { &mut *ptr }
    }

    /// ఏదైనా ఆకు లేదా అంతర్గత నోడ్ యొక్క ఆకు భాగానికి ప్రత్యేకమైన ప్రాప్యతను అందిస్తుంది.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // భద్రత: మాకు మొత్తం నోడ్‌కు ప్రత్యేకమైన ప్రాప్యత ఉంది.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// కీ నిల్వ ప్రాంతం యొక్క మూలకానికి ప్రత్యేక ప్రాప్యతను తీసుకుంటుంది.
    ///
    /// # Safety
    /// `index` 0. .CAPACITY యొక్క సరిహద్దులో ఉంది
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // భద్రత: కాలర్ స్వయంగా తదుపరి పద్ధతులను పిలవలేరు
        // కీ స్లైస్ రిఫరెన్స్ తొలగించబడే వరకు, రుణం యొక్క జీవితకాలం కోసం మాకు ప్రత్యేకమైన ప్రాప్యత ఉంది.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// నోడ్ యొక్క విలువ నిల్వ ప్రాంతం యొక్క మూలకం లేదా స్లైస్‌కు ప్రత్యేకమైన ప్రాప్యతను తీసుకుంటుంది.
    ///
    /// # Safety
    /// `index` 0. .CAPACITY యొక్క సరిహద్దులో ఉంది
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // భద్రత: కాలర్ స్వయంగా తదుపరి పద్ధతులను పిలవలేరు
        // రుణం యొక్క జీవితకాలం కోసం మాకు ప్రత్యేకమైన ప్రాప్యత ఉన్నందున, విలువ స్లైస్ రిఫరెన్స్ పడిపోయే వరకు.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// edge విషయాల కోసం నోడ్ యొక్క నిల్వ ప్రాంతం యొక్క మూలకం లేదా స్లైస్‌కు ప్రత్యేకమైన ప్రాప్యతను తీసుకుంటుంది.
    ///
    /// # Safety
    /// `index` 0. .CAPACITY + 1 యొక్క సరిహద్దులో ఉంది
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // భద్రత: కాలర్ స్వయంగా తదుపరి పద్ధతులను పిలవలేరు
        // edge స్లైస్ రిఫరెన్స్ తొలగించబడే వరకు, రుణం యొక్క జీవితకాలం కోసం మాకు ప్రత్యేకమైన ప్రాప్యత ఉంది.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - నోడ్‌లో `idx` కంటే ఎక్కువ ప్రారంభ అంశాలు ఉన్నాయి.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // ఇతర అంశాలపై అత్యుత్తమ సూచనలతో మారుపేరును నివారించడానికి, మనకు ఆసక్తి ఉన్న ఒక మూలకానికి మాత్రమే మేము ఒక సూచనను సృష్టిస్తాము, ప్రత్యేకించి, మునుపటి పునరావృతాలలో కాలర్‌కు తిరిగి వచ్చినవి.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Rust ఇష్యూ #74679 కారణంగా మేము పరిమాణం లేని శ్రేణి పాయింటర్లకు బలవంతం చేయాలి.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// నోడ్ యొక్క పొడవుకు ప్రత్యేకమైన ప్రాప్యతను తీసుకుంటుంది.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// నోడ్ యొక్క ఇతర సూచనలను చెల్లకుండా, నోడ్ యొక్క లింక్‌ను దాని మాతృ edge కు సెట్ చేస్తుంది.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// దాని మాతృ edge కు రూట్ యొక్క లింక్‌ను క్లియర్ చేస్తుంది.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// కీ-విలువ జతను నోడ్ చివరికి జోడిస్తుంది.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// `range` ద్వారా తిరిగి వచ్చిన ప్రతి అంశం నోడ్ కోసం చెల్లుబాటు అయ్యే edge సూచిక.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// కీ-విలువ జత మరియు ఆ జత యొక్క కుడి వైపుకు వెళ్ళడానికి edge ను నోడ్ చివర జోడిస్తుంది.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// నోడ్ `Internal` నోడ్ లేదా `Leaf` నోడ్ కాదా అని తనిఖీ చేస్తుంది.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// నిర్దిష్ట కీ-విలువ జత లేదా నోడ్‌లోని edge కు సూచన.
/// `Node` పరామితి తప్పనిసరిగా `NodeRef` అయి ఉండాలి, అయితే `Type` `KV` (కీ-విలువ జతపై హ్యాండిల్‌ను సూచిస్తుంది) లేదా `Edge` (edge లో హ్యాండిల్‌ను సూచిస్తుంది) కావచ్చు.
///
/// `Leaf` నోడ్లలో కూడా `Edge` హ్యాండిల్స్ ఉండవచ్చని గమనించండి.
/// చైల్డ్ నోడ్‌కు పాయింటర్‌ను సూచించే బదులు, ఇవి కీ-విలువ జతల మధ్య చైల్డ్ పాయింటర్లు వెళ్ళే ఖాళీలను సూచిస్తాయి.
/// ఉదాహరణకు, పొడవు 2 ఉన్న నోడ్‌లో, 3 సాధ్యమయ్యే edge స్థానాలు, నోడ్ యొక్క ఎడమ వైపున ఒకటి, రెండు జతల మధ్య ఒకటి మరియు నోడ్ యొక్క కుడి వైపున ఒకటి ఉంటుంది.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// మాకు `#[derive(Clone)]` యొక్క పూర్తి సాధారణత అవసరం లేదు, ఎందుకంటే `Node` మాత్రమే మార్పులేని సూచన అయినప్పుడు `క్లోన్` చేయగల ఏకైక సమయం మరియు అందువల్ల `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// ఈ హ్యాండిల్ సూచించే edge లేదా కీ-విలువ జతను కలిగి ఉన్న నోడ్‌ను తిరిగి పొందుతుంది.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// నోడ్‌లోని ఈ హ్యాండిల్ యొక్క స్థానాన్ని అందిస్తుంది.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// `node` లో కీ-విలువ జతకి కొత్త హ్యాండిల్‌ను సృష్టిస్తుంది.
    /// సురక్షితం కాదు ఎందుకంటే కాలర్ `idx < node.len()` అని నిర్ధారించుకోవాలి.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// పాక్షికఎక్ యొక్క బహిరంగ అమలు కావచ్చు, కానీ ఈ మాడ్యూల్‌లో మాత్రమే ఉపయోగించబడుతుంది.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// అదే ప్రదేశంలో తాత్కాలికంగా మరొక, మార్పులేని హ్యాండిల్‌ను తీసుకుంటుంది.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // మేము Handle::new_kv లేదా Handle::new_edge ను ఉపయోగించలేము ఎందుకంటే మన రకం మాకు తెలియదు
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// హ్యాండిల్ యొక్క నోడ్ `Leaf` అని స్టాటిక్ సమాచారాన్ని కంపైలర్‌కు సురక్షితంగా నొక్కి చెబుతుంది.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// అదే ప్రదేశంలో తాత్కాలికంగా మరొక, మార్చగల హ్యాండిల్‌ను తీసుకుంటుంది.
    /// జాగ్రత్త వహించండి, ఈ పద్ధతి చాలా ప్రమాదకరమైనది కాబట్టి, రెట్టింపు కాబట్టి ఇది వెంటనే ప్రమాదకరంగా కనిపించకపోవచ్చు.
    ///
    ///
    /// వివరాల కోసం, `NodeRef::reborrow_mut` చూడండి.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // మేము Handle::new_kv లేదా Handle::new_edge ను ఉపయోగించలేము ఎందుకంటే మన రకం మాకు తెలియదు
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// `node` లో edge కు కొత్త హ్యాండిల్‌ను సృష్టిస్తుంది.
    /// సురక్షితం కాదు ఎందుకంటే కాలర్ `idx <= node.len()` అని నిర్ధారించుకోవాలి.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// edge సూచిక ఇచ్చినట్లయితే, అక్కడ మేము సామర్థ్యంతో నిండిన నోడ్‌లోకి చొప్పించాలనుకుంటున్నాము, స్ప్లిట్ పాయింట్ యొక్క సున్నితమైన KV సూచికను లెక్కిస్తుంది మరియు చొప్పించడం ఎక్కడ చేయాలి.
///
/// స్ప్లిట్ పాయింట్ యొక్క లక్ష్యం దాని కీ మరియు విలువ పేరెంట్ నోడ్‌లో ముగుస్తుంది;
/// స్ప్లిట్ పాయింట్ యొక్క ఎడమ వైపున ఉన్న కీలు, విలువలు మరియు అంచులు ఎడమ బిడ్డగా మారతాయి;
/// స్ప్లిట్ పాయింట్ యొక్క కుడి వైపున ఉన్న కీలు, విలువలు మరియు అంచులు సరైన బిడ్డ అవుతాయి.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust ఇష్యూ #74834 ఈ సుష్ట నియమాలను వివరించడానికి ప్రయత్నిస్తుంది.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ఈ edge యొక్క కుడి మరియు ఎడమ వైపున కీ-విలువ జతల మధ్య కొత్త కీ-విలువ జతను చొప్పిస్తుంది.
    /// ఈ పద్ధతి కొత్త జతకి సరిపోయేలా నోడ్‌లో తగినంత స్థలం ఉందని umes హిస్తుంది.
    ///
    /// తిరిగి వచ్చిన పాయింటర్ చొప్పించిన విలువకు సూచిస్తుంది.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ఈ edge యొక్క కుడి మరియు ఎడమ వైపున కీ-విలువ జతల మధ్య కొత్త కీ-విలువ జతను చొప్పిస్తుంది.
    /// తగినంత గది లేకపోతే ఈ పద్ధతి నోడ్‌ను విభజిస్తుంది.
    ///
    /// తిరిగి వచ్చిన పాయింటర్ చొప్పించిన విలువకు సూచిస్తుంది.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// ఈ edge లింక్ చేసే చైల్డ్ నోడ్‌లోని పేరెంట్ పాయింటర్ మరియు సూచికను పరిష్కరిస్తుంది.
    /// అంచుల క్రమం మార్చబడినప్పుడు ఇది ఉపయోగపడుతుంది,
    fn correct_parent_link(self) {
        // నోడ్‌కు ఇతర సూచనలను చెల్లకుండా బ్యాక్‌పాయింటర్‌ను సృష్టించండి.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// ఈ edge మరియు ఈ edge యొక్క కుడి వైపున ఉన్న కీ-విలువ జత మధ్య కొత్త జత యొక్క కుడి వైపుకు వెళ్లే కొత్త కీ-విలువ జత మరియు edge ను చొప్పిస్తుంది.
    /// ఈ పద్ధతి కొత్త జతకి సరిపోయేలా నోడ్‌లో తగినంత స్థలం ఉందని umes హిస్తుంది.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// ఈ edge మరియు ఈ edge యొక్క కుడి వైపున ఉన్న కీ-విలువ జత మధ్య కొత్త జత యొక్క కుడి వైపుకు వెళ్లే కొత్త కీ-విలువ జత మరియు edge ను చొప్పిస్తుంది.
    /// తగినంత గది లేకపోతే ఈ పద్ధతి నోడ్‌ను విభజిస్తుంది.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ఈ edge యొక్క కుడి మరియు ఎడమ వైపున కీ-విలువ జతల మధ్య కొత్త కీ-విలువ జతను చొప్పిస్తుంది.
    /// తగినంత స్థలం లేకపోతే ఈ పద్ధతి నోడ్‌ను విభజిస్తుంది మరియు రూట్ చేరే వరకు స్ప్లిట్ ఆఫ్ భాగాన్ని పేరెంట్ నోడ్‌లోకి పునరావృతంగా చొప్పించడానికి ప్రయత్నిస్తుంది.
    ///
    ///
    /// తిరిగి వచ్చిన ఫలితం `Fit` అయితే, దాని హ్యాండిల్ నోడ్ ఈ edge యొక్క నోడ్ లేదా పూర్వీకుడు కావచ్చు.
    /// తిరిగి వచ్చిన ఫలితం `Split` అయితే, `left` ఫీల్డ్ రూట్ నోడ్ అవుతుంది.
    /// తిరిగి వచ్చిన పాయింటర్ చొప్పించిన విలువకు సూచిస్తుంది.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// ఈ edge సూచించిన నోడ్‌ను కనుగొంటుంది.
    ///
    /// పద్ధతి పేరు మీరు పైన ఉన్న రూట్ నోడ్‌తో చెట్లను చిత్రీకరిస్తుందని umes హిస్తుంది.
    ///
    /// `edge.descend().ascend().unwrap()` మరియు `node.ascend().unwrap().descend()` రెండూ విజయవంతం అయిన తర్వాత ఏమీ చేయకూడదు.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // మేము ముడి పాయింటర్లను నోడ్‌లకు ఉపయోగించాలి, ఎందుకంటే, బారోటైప్ marker::ValMut అయితే, మేము చెల్లని విలువలకు అసాధారణమైన మ్యూటబుల్ సూచనలు ఉండవచ్చు.
        // ఎత్తు ఫీల్డ్‌ను యాక్సెస్ చేయడంలో చింత లేదు ఎందుకంటే ఆ విలువ కాపీ చేయబడింది.
        // నోడ్ పాయింటర్ డీరెఫరెన్స్ అయిన తర్వాత, మేము అంచుల శ్రేణిని రిఫరెన్స్ (Rust ఇష్యూ #73987) తో యాక్సెస్ చేస్తాము మరియు శ్రేణికి లేదా లోపల ఏదైనా ఇతర సూచనలను చెల్లుబాటు చేస్తామని జాగ్రత్త వహించండి.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // మేము ప్రత్యేక కీ మరియు విలువ పద్ధతులను పిలవలేము, ఎందుకంటే రెండవదాన్ని పిలవడం మొదటిది ఇచ్చిన సూచనను చెల్లదు.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// KV హ్యాండిల్ సూచించే కీ మరియు విలువను భర్తీ చేయండి.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// ఆకు డేటాను జాగ్రత్తగా చూసుకోవడం ద్వారా, ఒక నిర్దిష్ట `NodeType` కోసం `split` అమలుకు సహాయపడుతుంది.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// అంతర్లీన నోడ్‌ను మూడు భాగాలుగా విభజిస్తుంది:
    ///
    /// - ఈ హ్యాండిల్ యొక్క ఎడమ వైపున ఉన్న కీ-విలువ జతలను మాత్రమే కలిగి ఉండటానికి నోడ్ కత్తిరించబడుతుంది.
    /// - ఈ హ్యాండిల్ సూచించిన కీ మరియు విలువ సంగ్రహించబడుతుంది.
    /// - ఈ హ్యాండిల్ యొక్క కుడి వైపున ఉన్న అన్ని కీ-విలువ జతలు కొత్తగా కేటాయించిన నోడ్‌లో ఉంచబడతాయి.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// ఈ హ్యాండిల్ సూచించిన కీ-విలువ జతను తీసివేసి, కీ-విలువ జత కూలిపోయిన edge తో పాటు దాన్ని తిరిగి ఇస్తుంది.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// అంతర్లీన నోడ్‌ను మూడు భాగాలుగా విభజిస్తుంది:
    ///
    /// - ఈ హ్యాండిల్ యొక్క ఎడమ వైపున అంచులు మరియు కీ-విలువ జతలను మాత్రమే కలిగి ఉండేలా నోడ్ కత్తిరించబడుతుంది.
    /// - ఈ హ్యాండిల్ సూచించిన కీ మరియు విలువ సంగ్రహించబడుతుంది.
    /// - ఈ హ్యాండిల్ యొక్క కుడి వైపున ఉన్న అన్ని అంచులు మరియు కీ-విలువ జతలు కొత్తగా కేటాయించిన నోడ్‌లో ఉంచబడతాయి.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// అంతర్గత కీ-విలువ జత చుట్టూ బ్యాలెన్సింగ్ ఆపరేషన్‌ను అంచనా వేయడానికి మరియు నిర్వహించడానికి సెషన్‌ను సూచిస్తుంది.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// చిన్నతనంలో నోడ్‌తో కూడిన బ్యాలెన్సింగ్ సందర్భాన్ని ఎంచుకుంటుంది, తద్వారా KV మధ్య వెంటనే ఎడమ వైపుకు లేదా పేరెంట్ నోడ్‌లో కుడి వైపున ఉంటుంది.
    /// పేరెంట్ లేకపోతే `Err` ని అందిస్తుంది.
    /// పేరెంట్ ఖాళీగా ఉంటే Panics.
    ///
    /// ఎడమ వైపు ఇష్టపడతారు, ఇచ్చిన నోడ్ ఏదో ఒకవిధంగా అండర్ఫుల్ గా ఉంటే సరైనది, ఇక్కడ అంటే దాని ఎడమ తోబుట్టువుల కన్నా తక్కువ మూలకాలు మరియు కుడి తోబుట్టువుల కన్నా తక్కువ మూలకాలు ఉన్నాయని మాత్రమే అర్థం.
    /// అలాంటప్పుడు, ఎడమ తోబుట్టువుతో విలీనం చేయడం వేగంగా ఉంటుంది, ఎందుకంటే మనం నోడ్ యొక్క N మూలకాలను మాత్రమే కుడి వైపుకు మార్చకుండా మరియు ముందు N మూలకాల కంటే ఎక్కువ కదలాలి.
    /// ఎడమ తోబుట్టువుల నుండి దొంగిలించడం కూడా సాధారణంగా వేగంగా ఉంటుంది, ఎందుకంటే మనం తోబుట్టువు యొక్క మూలకాలలో కనీసం N ని ఎడమ వైపుకు మార్చడానికి బదులుగా నోడ్ యొక్క N మూలకాలను కుడి వైపుకు మార్చాలి.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// విలీనం సాధ్యమేనా, అంటే, సెంట్రల్ కెవిని రెండు ప్రక్కనే ఉన్న పిల్లల నోడ్‌లతో కలపడానికి నోడ్‌లో తగినంత స్థలం ఉందా అని చూపుతుంది.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// విలీనం చేస్తుంది మరియు మూసివేత ఏమి తిరిగి ఇవ్వాలో నిర్ణయించడానికి అనుమతిస్తుంది.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // భద్రత: విలీనం చేయబడిన నోడ్‌ల ఎత్తు ఎత్తు కంటే ఒకటి
                // ఈ edge యొక్క నోడ్ యొక్క, తద్వారా సున్నా పైన ఉంటుంది, కాబట్టి అవి అంతర్గతంగా ఉంటాయి.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// తల్లిదండ్రుల కీ-విలువ జత మరియు ప్రక్కనే ఉన్న పిల్లల నోడ్‌లను ఎడమ పిల్లల నోడ్‌లో విలీనం చేస్తుంది మరియు కుంచించుకుపోయిన పేరెంట్ నోడ్‌ను తిరిగి ఇస్తుంది.
    ///
    ///
    /// మేము `.can_merge()` తప్ప Panics.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// తల్లిదండ్రుల కీ-విలువ జత మరియు ప్రక్కనే ఉన్న పిల్లల నోడ్‌లను ఎడమ చైల్డ్ నోడ్‌లో విలీనం చేసి, ఆ చైల్డ్ నోడ్‌ను తిరిగి ఇస్తుంది.
    ///
    ///
    /// మేము `.can_merge()` తప్ప Panics.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// తల్లిదండ్రుల కీ-విలువ జత మరియు ప్రక్కనే ఉన్న పిల్లల నోడ్‌లను ఎడమ పిల్లల నోడ్‌లో విలీనం చేస్తుంది మరియు ట్రాక్ చేయబడిన పిల్లవాడు edge ముగిసిన ఆ చైల్డ్ నోడ్‌లో edge హ్యాండిల్‌ను తిరిగి ఇస్తుంది,
    ///
    ///
    /// మేము `.can_merge()` తప్ప Panics.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// ఎడమ పిల్లల నుండి కీ-విలువ జతను తీసివేసి, తల్లిదండ్రుల కీ-విలువ నిల్వలో ఉంచుతుంది, అదే సమయంలో పాత పేరెంట్ కీ-విలువ జతను సరైన బిడ్డలోకి నెట్టేస్తుంది.
    ///
    /// `track_right_edge_idx` పేర్కొన్న అసలు edge ముగిసిన చోటికి అనుగుణంగా కుడి బిడ్డలోని edge కు హ్యాండిల్‌ను అందిస్తుంది.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// కుడి పిల్లల నుండి కీ-విలువ జతను తీసివేసి, తల్లిదండ్రుల కీ-విలువ నిల్వలో ఉంచుతుంది, అదే సమయంలో పాత పేరెంట్ కీ-విలువ జతను ఎడమ బిడ్డపైకి నెట్టేస్తుంది.
    ///
    /// `track_left_edge_idx` పేర్కొన్న ఎడమ బిడ్డలోని edge కు హ్యాండిల్‌ను అందిస్తుంది, అది కదలలేదు.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// ఇది `steal_left` మాదిరిగానే దొంగిలించగలదు కాని ఒకేసారి బహుళ అంశాలను దొంగిలిస్తుంది.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // మేము సురక్షితంగా దొంగిలించవచ్చని నిర్ధారించుకోండి.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // ఆకు డేటాను తరలించండి.
            {
                // సరైన పిల్లలలో దొంగిలించబడిన మూలకాలకు స్థలం చేయండి.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // అంశాలను ఎడమ పిల్లల నుండి కుడి వైపుకు తరలించండి.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // ఎడమవైపు ఎక్కువగా దొంగిలించబడిన జతను తల్లిదండ్రులకు తరలించండి.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // తల్లిదండ్రుల కీ-విలువ జతను సరైన బిడ్డకు తరలించండి.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // దొంగిలించబడిన అంచులకు స్థలం చేయండి.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // అంచులను దొంగిలించండి.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left` యొక్క సిమెట్రిక్ క్లోన్.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // మేము సురక్షితంగా దొంగిలించవచ్చని నిర్ధారించుకోండి.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // ఆకు డేటాను తరలించండి.
            {
                // కుడివైపు ఎక్కువగా దొంగిలించబడిన జతను తల్లిదండ్రులకు తరలించండి.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // తల్లిదండ్రుల కీ-విలువ జతను ఎడమ బిడ్డకు తరలించండి.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // మూలకాలను కుడి పిల్లల నుండి ఎడమ వైపుకు తరలించండి.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // దొంగిలించబడిన అంశాలు ఉన్న చోట ఖాళీని పూరించండి.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // అంచులను దొంగిలించండి.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // దొంగిలించబడిన అంచులు ఉండే ఖాళీని పూరించండి.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// ఈ నోడ్ `Leaf` నోడ్ అని నొక్కి చెప్పే ఏదైనా స్టాటిక్ సమాచారాన్ని తొలగిస్తుంది.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// ఈ నోడ్ `Internal` నోడ్ అని నొక్కి చెప్పే ఏదైనా స్టాటిక్ సమాచారాన్ని తొలగిస్తుంది.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// అంతర్లీన నోడ్ `Internal` నోడ్ లేదా `Leaf` నోడ్ కాదా అని తనిఖీ చేస్తుంది.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// `self` తరువాత ప్రత్యయాన్ని ఒక నోడ్ నుండి మరొకదానికి తరలించండి.`right` ఖాళీగా ఉండాలి.
    /// `right` యొక్క మొదటి edge మారదు.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// చొప్పించే ఫలితం, నోడ్ దాని సామర్థ్యానికి మించి విస్తరించడానికి అవసరమైనప్పుడు.
pub struct SplitResult<'a, K, V, NodeType> {
    // `kv` యొక్క ఎడమ వైపున ఉన్న మూలకాలు మరియు అంచులతో ఉన్న చెట్టులో మార్చబడిన నోడ్.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // కొన్ని కీ మరియు విలువ విభజించబడింది, మరెక్కడా చేర్చబడాలి.
    pub kv: (K, V),
    // `kv` యొక్క కుడి వైపున ఉన్న మూలకాలు మరియు అంచులతో స్వంతమైన, జోడించబడని, కొత్త నోడ్.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // ఈ రుణ రకం యొక్క నోడ్ సూచనలు చెట్టులోని ఇతర నోడ్‌లకు ప్రయాణించటానికి అనుమతిస్తాయా.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // ట్రావెర్సల్ అవసరం లేదు, ఇది `borrow_mut` ఫలితాన్ని ఉపయోగించి జరుగుతుంది.
        // ట్రావెర్సల్‌ను నిలిపివేయడం ద్వారా మరియు మూలాలకు క్రొత్త సూచనలను మాత్రమే సృష్టించడం ద్వారా, `Owned` రకం యొక్క ప్రతి సూచన రూట్ నోడ్‌కు ఉంటుందని మాకు తెలుసు.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// ప్రారంభించిన మూలకాల స్లైస్‌లో విలువను చొప్పించి, ఆపై ప్రారంభించని మూలకం.
///
/// # Safety
/// స్లైస్‌లో `idx` కంటే ఎక్కువ అంశాలు ఉన్నాయి.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// ప్రారంభించిన అన్ని మూలకాల స్లైస్ నుండి విలువను తీసివేస్తుంది మరియు తిరిగి ఇస్తుంది, ప్రారంభించని మూలకం వెనుకబడి ఉంటుంది.
///
///
/// # Safety
/// స్లైస్‌లో `idx` కంటే ఎక్కువ అంశాలు ఉన్నాయి.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// స్లైస్ `distance` స్థానాల్లోని మూలకాలను ఎడమ వైపుకు మారుస్తుంది.
///
/// # Safety
/// స్లైస్‌లో కనీసం `distance` అంశాలు ఉన్నాయి.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// స్లైస్ `distance` స్థానాల్లోని మూలకాలను కుడి వైపుకు మారుస్తుంది.
///
/// # Safety
/// స్లైస్‌లో కనీసం `distance` అంశాలు ఉన్నాయి.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// ప్రారంభించిన మూలకాల స్లైస్ నుండి ప్రారంభించని మూలకాల స్లైస్‌కు అన్ని విలువలను కదిలిస్తుంది, `src` ను అన్ని ప్రారంభించని విధంగా వదిలివేస్తుంది.
///
/// `dst.copy_from_slice(src)` లాగా పనిచేస్తుంది కాని `T` `Copy` గా అవసరం లేదు.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;