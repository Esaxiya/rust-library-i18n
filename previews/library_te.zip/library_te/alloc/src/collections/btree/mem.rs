use core::intrinsics;
use core::mem;
use core::ptr;

/// ఇది సంబంధిత ఫంక్షన్‌కు కాల్ చేయడం ద్వారా `v` ప్రత్యేక సూచన వెనుక ఉన్న విలువను భర్తీ చేస్తుంది.
///
///
/// `change` మూసివేతలో panic సంభవిస్తే, మొత్తం ప్రక్రియ నిలిపివేయబడుతుంది.
#[allow(dead_code)] // ఉదాహరణగా మరియు future ఉపయోగం కోసం ఉంచండి
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// ఇది సంబంధిత ఫంక్షన్‌కు కాల్ చేయడం ద్వారా `v` ప్రత్యేక సూచన వెనుక ఉన్న విలువను భర్తీ చేస్తుంది మరియు మార్గం వెంట పొందిన ఫలితాన్ని అందిస్తుంది.
///
///
/// `change` మూసివేతలో panic సంభవిస్తే, మొత్తం ప్రక్రియ నిలిపివేయబడుతుంది.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}