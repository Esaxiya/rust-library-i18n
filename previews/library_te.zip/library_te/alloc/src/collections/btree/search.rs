use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// `Bound::Included(T)` మాదిరిగానే చూడటానికి కలుపుకొని ఉంటుంది.
    Included(T),
    /// `Bound::Excluded(T)` మాదిరిగానే చూడటానికి ప్రత్యేకంగా కట్టుబడి ఉంటుంది.
    Excluded(T),
    /// `Bound::Unbounded` మాదిరిగానే షరతులు లేని కలుపుకొని ఉంటుంది.
    AllIncluded,
    /// షరతులు లేని ప్రత్యేకమైన బౌండ్.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// ఇచ్చిన కీని నోడ్ నేతృత్వంలోని (ఉప) చెట్టులో, పునరావృతంగా చూస్తుంది.
    /// సరిపోయే KV యొక్క హ్యాండిల్‌తో ఏదైనా ఉంటే `Found` ని అందిస్తుంది.
    /// లేకపోతే, కీ చెందిన edge ఆకు యొక్క హ్యాండిల్‌తో `GoDown` ను తిరిగి ఇస్తుంది.
    ///
    /// `BTreeMap` లోని చెట్టు వలె, చెట్టును కీ ద్వారా ఆర్డర్ చేస్తేనే ఫలితం అర్ధమవుతుంది.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// శ్రేణి యొక్క దిగువ సరిహద్దుతో సరిపోయే edge ఎగువ బౌండ్‌కు సరిపోయే edge నుండి భిన్నంగా ఉన్న సమీప నోడ్‌కు దిగుతుంది, అనగా, పరిధిలో కనీసం ఒక కీని కలిగి ఉన్న సమీప నోడ్.
    ///
    ///
    /// కనుగొనబడితే, ఆ నోడ్‌తో ఒక `Ok` ను తిరిగి ఇస్తుంది, దానిలోని edge సూచికలు పరిధిని డీలిమిట్ చేస్తాయి మరియు నోడ్ అంతర్గతంగా ఉంటే చైల్డ్ నోడ్స్‌లో శోధనను కొనసాగించడానికి సంబంధిత జత హద్దులు.
    ///
    /// కనుగొనబడకపోతే, మొత్తం శ్రేణికి సరిపోయే edge ఆకుతో `Err` ను తిరిగి ఇస్తుంది.
    ///
    /// చెట్టును కీ ద్వారా ఆదేశిస్తేనే ఫలితం అర్ధమవుతుంది.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // ఈ వేరియబుల్స్ ఇన్లైన్ చేయడం మానుకోవాలి.
        // `range` చే నివేదించబడిన హద్దులు అలాగే ఉన్నాయని మేము అనుకుంటాము, అయితే (#81138) కాల్స్ మధ్య విరోధి అమలు మారవచ్చు.
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// పరిధి యొక్క దిగువ సరిహద్దును డీలిమిట్ చేసే నోడ్‌లో edge ను కనుగొంటుంది.
    /// `self` అంతర్గత నోడ్ అయితే, మ్యాచింగ్ చైల్డ్ నోడ్‌లో శోధనను కొనసాగించడానికి ఉపయోగించాల్సిన తక్కువ బౌండ్‌ను కూడా అందిస్తుంది.
    ///
    ///
    /// చెట్టును కీ ద్వారా ఆదేశిస్తేనే ఫలితం అర్ధమవుతుంది.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// ఎగువ బౌండ్ కోసం `find_lower_bound_edge` యొక్క క్లోన్.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// పునరావృత లేకుండా నోడ్‌లో ఇచ్చిన కీని చూస్తుంది.
    /// సరిపోయే KV యొక్క హ్యాండిల్‌తో ఏదైనా ఉంటే `Found` ని అందిస్తుంది.
    /// లేకపోతే, edge యొక్క హ్యాండిల్‌తో `GoDown` ను తిరిగి ఇస్తుంది, ఇక్కడ కీ కనుగొనవచ్చు (నోడ్ అంతర్గతంగా ఉంటే) లేదా కీని ఎక్కడ చేర్చవచ్చు.
    ///
    ///
    /// `BTreeMap` లోని చెట్టు వలె, చెట్టును కీ ద్వారా ఆర్డర్ చేస్తేనే ఫలితం అర్ధమవుతుంది.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// కీ (లేదా సమానమైన) ఉన్న నోడ్‌లోని KV సూచికను లేదా కీ చెందిన edge సూచికను అందిస్తుంది.
    ///
    ///
    /// `BTreeMap` లోని చెట్టు వలె, చెట్టును కీ ద్వారా ఆర్డర్ చేస్తేనే ఫలితం అర్ధమవుతుంది.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// పరిధి యొక్క దిగువ సరిహద్దును డీలిమిట్ చేసే నోడ్‌లో edge సూచికను కనుగొంటుంది.
    /// `self` అంతర్గత నోడ్ అయితే, మ్యాచింగ్ చైల్డ్ నోడ్‌లో శోధనను కొనసాగించడానికి ఉపయోగించాల్సిన తక్కువ బౌండ్‌ను కూడా అందిస్తుంది.
    ///
    ///
    /// చెట్టును కీ ద్వారా ఆదేశిస్తేనే ఫలితం అర్ధమవుతుంది.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// ఎగువ బౌండ్ కోసం `find_lower_bound_index` యొక్క క్లోన్.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}