use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// తోబుట్టువుతో విలీనం చేయడం లేదా దొంగిలించడం ద్వారా అండర్ఫుల్ నోడ్‌ను నిల్వ చేస్తుంది.
    /// విజయవంతమైతే, పేరెంట్ నోడ్‌ను కుదించే ఖర్చుతో, తగ్గిపోయిన పేరెంట్ నోడ్‌ను తిరిగి ఇస్తుంది.
    /// నోడ్ ఖాళీ రూట్ అయితే `Err` ని అందిస్తుంది.
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// అండర్ఫుల్ నోడ్ను నిల్వ చేస్తుంది మరియు అది దాని పేరెంట్ నోడ్ కుదించడానికి కారణమైతే, పేరెంట్‌ను పునరావృతంగా నిల్వ చేస్తుంది.
    /// చెట్టును పరిష్కరించినట్లయితే `true`, రూట్ నోడ్ ఖాళీగా ఉన్నందున `false` చేయలేకపోతే తిరిగి ఇస్తుంది.
    ///
    /// ఈ పద్ధతి పూర్వీకులు ఇప్పటికే ప్రవేశించినప్పుడు మరియు panics ఖాళీగా ఉన్న పూర్వీకుడిని ఎదుర్కొంటుందని ఆశించదు.
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// పైన ఉన్న ఖాళీ స్థాయిలను తొలగిస్తుంది, కానీ చెట్టు మొత్తం ఖాళీగా ఉంటే ఖాళీ ఆకును ఉంచుతుంది.
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// చెట్టు యొక్క కుడి సరిహద్దులో ఏదైనా అండర్ ఫుల్ నోడ్లను నిల్వ చేస్తుంది లేదా విలీనం చేస్తుంది.
    /// ఇతర నోడ్లు, రూట్ లేదా కుడివైపున ఉన్న edge, ఇప్పటికే కనీసం MIN_LEN మూలకాలను కలిగి ఉండాలి.
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// `fix_right_border` యొక్క సిమెట్రిక్ క్లోన్.
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// చెట్టు యొక్క కుడి సరిహద్దులో ఏదైనా అండర్ ఫుల్ నోడ్లను నిల్వ చేయండి.
    /// ఇతర నోడ్లు, రూట్ లేదా కుడివైపున ఉన్న edge, MIN_LEN మూలకాలను దొంగిలించడానికి సిద్ధంగా ఉండాలి.
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // కుడివైపున ఉన్న పిల్లవాడు అండర్ ఫుల్ కాదా అని తనిఖీ చేయండి.
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // మనం దొంగిలించాలి.
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // మరింత క్రిందికి వెళ్ళండి.
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// కుడి బిడ్డ అండర్ ఫుల్ కాదని uming హిస్తూ, ఎడమ బిడ్డను నిల్వ చేస్తుంది మరియు దాని పిల్లలను అండర్ఫుల్ కాకుండా విలీనం చేయడానికి అనుమతించే అదనపు మూలకాన్ని అందిస్తుంది.
    ///
    /// ఎడమ బిడ్డను తిరిగి ఇస్తుంది.
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` తదుపరి స్థాయిలో విలీనం జరిగితే రీజస్ట్ చేయకుండా ఉండటానికి.
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// కుడి బిడ్డను నిల్వ చేస్తుంది, ఎడమ బిడ్డ అండర్ ఫుల్ కాదని uming హిస్తూ, దాని పిల్లలను అండర్ ఫుల్ గా మారకుండా విలీనం చేయడానికి అనుమతించే అదనపు మూలకాన్ని అందిస్తుంది.
    ///
    /// సరైన పిల్లవాడు ముగిసిన చోట తిరిగి వస్తుంది.
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` తదుపరి స్థాయిలో విలీనం జరిగితే రీజస్ట్ చేయకుండా ఉండటానికి.
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}