use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// రెండు ఆరోహణ ఇటరేటర్ల యూనియన్ నుండి అన్ని కీ-విలువ జతలను జతచేస్తుంది, మార్గం వెంట `length` వేరియబుల్‌ను పెంచుతుంది.డ్రాప్ హ్యాండ్లర్ భయాందోళనకు గురైనప్పుడు కాలర్ లీక్ అవ్వకుండా ఉండటాన్ని సులభం చేస్తుంది.
    ///
    /// రెండు ఇరేటర్లు ఒకే కీని ఉత్పత్తి చేస్తే, ఈ పద్ధతి ఎడమ ఇటరేటర్ నుండి జతని పడిపోతుంది మరియు కుడి ఇరేటర్ నుండి జతని జోడిస్తుంది.
    ///
    /// `BTreeMap` మాదిరిగా చెట్టు ఖచ్చితంగా ఆరోహణ క్రమంలో ముగుస్తుందని మీరు కోరుకుంటే, రెండు ఇరేటర్లు కీలను ఖచ్చితంగా ఆరోహణ క్రమంలో ఉత్పత్తి చేయాలి, ప్రతి ఒక్కటి చెట్టులోని అన్ని కీల కంటే పెద్దవి, ప్రవేశించిన తరువాత చెట్టులో ఇప్పటికే ఉన్న కీలతో సహా.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // మేము `left` మరియు `right` లను సరళ సమయంలో క్రమబద్ధీకరించిన క్రమంలో విలీనం చేయడానికి సిద్ధం చేస్తాము.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // ఇంతలో, మేము సరళ సమయంలో క్రమబద్ధీకరించబడిన క్రమం నుండి ఒక చెట్టును నిర్మిస్తాము.
        self.bulk_push(iter, length)
    }

    /// అన్ని కీ-విలువ జతలను చెట్టు చివరకి నెట్టివేసి, మార్గం వెంట `length` వేరియబుల్‌ను పెంచుతుంది.
    /// రెండోది ఇరేటర్ భయపడినప్పుడు కాల్ చేసేవారికి లీక్ రాకుండా చేస్తుంది.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // అన్ని కీ-విలువ జతల ద్వారా మళ్ళించండి, వాటిని సరైన స్థాయిలో నోడ్లలోకి నెట్టండి.
        for (key, value) in iter {
            // కీ-విలువ జతను ప్రస్తుత ఆకు నోడ్‌లోకి నెట్టడానికి ప్రయత్నించండి.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // స్థలం మిగిలి లేదు, పైకి వెళ్లి అక్కడకు నెట్టండి.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // స్థలం మిగిలి ఉన్న నోడ్ కనుగొనబడింది, ఇక్కడ నెట్టండి.
                                open_node = parent;
                                break;
                            } else {
                                // మళ్ళీ పైకి వెళ్ళండి.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // మేము ఎగువన ఉన్నాము, క్రొత్త రూట్ నోడ్ని సృష్టించి అక్కడకు నెట్టండి.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // కీ-విలువ జత మరియు క్రొత్త కుడి సబ్‌ట్రీని నొక్కండి.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // మళ్ళీ కుడి-ఎక్కువ ఆకుకు వెళ్ళండి.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // ప్రతి పునరావృతం యొక్క పొడవు పెంచండి, ఇరేటర్ భయాందోళనలకు గురైనప్పటికీ మ్యాప్ అనుబంధ మూలకాలను తగ్గిస్తుందని నిర్ధారించుకోండి.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// రెండు క్రమబద్ధీకరించిన సన్నివేశాలను ఒకటిగా విలీనం చేయడానికి ఒక మళ్ళి
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// రెండు కీలు సమానంగా ఉంటే, కీ-విలువ జతను సరైన మూలం నుండి తిరిగి ఇస్తుంది.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}