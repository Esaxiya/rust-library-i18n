use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef};

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    /// చెట్టు నుండి కీ-విలువ జతను తీసివేస్తుంది మరియు ఆ జతను తిరిగి ఇస్తుంది, అలాగే ఆ మాజీ జతకి అనుగుణమైన edge ఆకు.
    /// ఇది అంతర్గత రూట్ నోడ్‌ను ఖాళీ చేస్తుంది, ఇది చెట్టును పట్టుకున్న మ్యాప్ నుండి కాలర్ పాప్ చేయాలి.
    /// కాలర్ మ్యాప్ యొక్క పొడవును కూడా తగ్గించాలి.
    ///
    pub fn remove_kv_tracking<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        match self.force() {
            Leaf(node) => node.remove_leaf_kv(handle_emptied_internal_root),
            Internal(node) => node.remove_internal_kv(handle_emptied_internal_root),
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    fn remove_leaf_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let (old_kv, mut pos) = self.remove();
        let len = pos.reborrow().into_node().len();
        if len < MIN_LEN {
            let idx = pos.idx();
            // మేము పిల్లల రకాన్ని తాత్కాలికంగా మరచిపోవాలి, ఎందుకంటే ఆకు యొక్క తక్షణ తల్లిదండ్రులకు ప్రత్యేకమైన నోడ్ రకం లేదు.
            //
            let new_pos = match pos.into_node().forget_type().choose_parent_kv() {
                Ok(Left(left_parent_kv)) => {
                    debug_assert!(left_parent_kv.right_child_len() == MIN_LEN - 1);
                    if left_parent_kv.can_merge() {
                        left_parent_kv.merge_tracking_child_edge(Right(idx))
                    } else {
                        debug_assert!(left_parent_kv.left_child_len() > MIN_LEN);
                        left_parent_kv.steal_left(idx)
                    }
                }
                Ok(Right(right_parent_kv)) => {
                    debug_assert!(right_parent_kv.left_child_len() == MIN_LEN - 1);
                    if right_parent_kv.can_merge() {
                        right_parent_kv.merge_tracking_child_edge(Left(idx))
                    } else {
                        debug_assert!(right_parent_kv.right_child_len() > MIN_LEN);
                        right_parent_kv.steal_right(idx)
                    }
                }
                Err(pos) => unsafe { Handle::new_edge(pos, idx) },
            };
            // భద్రత: `new_pos` అనేది మేము ప్రారంభించిన ఆకు లేదా తోబుట్టువు.
            pos = unsafe { new_pos.cast_to_leaf_unchecked() };

            // మేము విలీనం చేస్తేనే, తల్లిదండ్రులు (ఏదైనా ఉంటే) తగ్గిపోయారు, కాని ఈ క్రింది దశను దాటవేయడం బెంచ్‌మార్క్‌లలో చెల్లించదు.
            //
            // భద్రత: మేము `pos` ఉన్న ఆకును నాశనం చేయము లేదా క్రమాన్ని మార్చము
            // దాని తల్లిదండ్రులను పునరావృతంగా నిర్వహించడం ద్వారా;చెత్తగా మేము తాత ద్వారా తల్లిదండ్రులను నాశనం చేస్తాము లేదా క్రమాన్ని మారుస్తాము, తద్వారా ఆకు లోపల ఉన్న తల్లిదండ్రులకు లింక్‌ను మారుస్తాము.
            //
            //
            //
            if let Ok(parent) = unsafe { pos.reborrow_mut() }.into_node().ascend() {
                if !parent.into_node().forget_type().fix_node_and_affected_ancestors() {
                    handle_emptied_internal_root();
                }
            }
        }
        (old_kv, pos)
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    fn remove_internal_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        // దాని ఆకు నుండి ప్రక్కనే ఉన్న కెవిని తీసివేసి, ఆపై తొలగించమని అడిగిన మూలకం స్థానంలో తిరిగి ఉంచండి.
        //
        // `choose_parent_kv` లో జాబితా చేయబడిన కారణాల కోసం, ఎడమ ప్రక్కనే ఉన్న KV కి ప్రాధాన్యత ఇవ్వండి.
        let left_leaf_kv = self.left_edge().descend().last_leaf_edge().left_kv();
        let left_leaf_kv = unsafe { left_leaf_kv.ok().unwrap_unchecked() };
        let (left_kv, left_hole) = left_leaf_kv.remove_leaf_kv(handle_emptied_internal_root);

        // అంతర్గత నోడ్ దొంగిలించబడి ఉండవచ్చు లేదా విలీనం అయి ఉండవచ్చు.
        // అసలు కెవి ఎక్కడ ముగిసిందో తెలుసుకోవడానికి కుడివైపుకి తిరిగి వెళ్ళు.
        let mut internal = unsafe { left_hole.next_kv().ok().unwrap_unchecked() };
        let old_kv = internal.replace_kv(left_kv.0, left_kv.1);
        let pos = internal.next_leaf_edge();
        (old_kv, pos)
    }
}