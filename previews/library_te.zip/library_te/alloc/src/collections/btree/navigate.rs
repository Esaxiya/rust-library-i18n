use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// అదే శ్రేణికి సమానమైన మరొక, మార్పులేని తాత్కాలికంగా తాత్కాలికంగా తీసుకుంటుంది.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// చెట్టులో పేర్కొన్న పరిధిని డీలిమిట్ చేసే విభిన్న ఆకు అంచులను కనుగొంటుంది.
    /// ఒకే చెట్టులోకి వేర్వేరు హ్యాండిల్స్‌ను లేదా ఖాళీ ఎంపికలను జత చేస్తుంది.
    ///
    /// # Safety
    ///
    /// `BorrowType` `Immut` తప్ప, ఒకే KV ని రెండుసార్లు సందర్శించడానికి డూప్లికేట్ హ్యాండిల్స్ ఉపయోగించవద్దు.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// `(root1.first_leaf_edge(), root2.last_leaf_edge())` కు సమానం కాని మరింత సమర్థవంతమైనది.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// చెట్టులో ఒక నిర్దిష్ట పరిధిని డీలిమిట్ చేసే ఆకు అంచుల జతని కనుగొంటుంది.
    ///
    /// `BTreeMap` లోని చెట్టు వలె, చెట్టును కీ ద్వారా ఆర్డర్ చేస్తేనే ఫలితం అర్ధమవుతుంది.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // భద్రత: మా borrow ణం రకం మార్పులేనిది.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// మొత్తం చెట్టును డీలిమిట్ చేసే ఆకు అంచుల జతని కనుగొంటుంది.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// ఒక నిర్దిష్ట పరిధిని డీలిమిట్ చేసే ఆకు అంచులలో ఒక ప్రత్యేకమైన సూచనను విభజిస్తుంది.
    /// ఫలితం (some) మ్యుటేషన్‌ను అనుమతించే ప్రత్యేకత లేని సూచనలు, వీటిని జాగ్రత్తగా ఉపయోగించాలి.
    ///
    /// `BTreeMap` లోని చెట్టు వలె, చెట్టును కీ ద్వారా ఆర్డర్ చేస్తేనే ఫలితం అర్ధమవుతుంది.
    ///
    ///
    /// # Safety
    /// ఒకే కెవిని రెండుసార్లు సందర్శించడానికి డూప్లికేట్ హ్యాండిల్స్ ఉపయోగించవద్దు.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// చెట్టు యొక్క పూర్తి స్థాయిని డీలిమిట్ చేసే ఆకు అంచులలో ఒక ప్రత్యేకమైన సూచనను విభజిస్తుంది.
    /// ఫలితాలు మ్యుటేషన్ (విలువలను మాత్రమే) అనుమతించే ప్రత్యేకత లేని సూచనలు, కాబట్టి జాగ్రత్తగా వాడాలి.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // మేము ఇక్కడ రూట్ నోడ్‌రిఫ్‌ను నకిలీ చేస్తాము-మేము ఒకే కెవిని రెండుసార్లు సందర్శించము మరియు అతివ్యాప్తి విలువ సూచనలతో ముగుస్తుంది.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// చెట్టు యొక్క పూర్తి స్థాయిని డీలిమిట్ చేసే ఆకు అంచులలో ఒక ప్రత్యేకమైన సూచనను విభజిస్తుంది.
    /// ఫలితాలు వినాశకరమైన మ్యుటేషన్‌ను అనుమతించే ప్రత్యేకత లేని సూచనలు, కాబట్టి చాలా జాగ్రత్తగా ఉపయోగించాలి.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // మేము ఇక్కడ రూట్ నోడ్‌రిఫ్‌ను నకిలీ చేస్తాము-రూట్ నుండి పొందిన రిఫరెన్స్‌లను అతివ్యాప్తి చేసే విధంగా మేము దీన్ని ఎప్పటికీ యాక్సెస్ చేయము.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// ఒక ఆకు edge హ్యాండిల్ ఇచ్చినప్పుడు, [`Result::Ok`] ను హ్యాండిల్‌తో కుడి వైపున ఉన్న పొరుగున ఉన్న KV కి తిరిగి ఇస్తుంది, ఇది ఒకే ఆకు నోడ్‌లో లేదా పూర్వీకుల నోడ్‌లో ఉంటుంది.
    ///
    /// edge ఆకు చెట్టులో చివరిది అయితే, రూట్ నోడ్‌తో [`Result::Err`] ను తిరిగి ఇస్తుంది.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// ఒక ఆకు edge హ్యాండిల్ ఇచ్చినప్పుడు, [`Result::Ok`] ను హ్యాండిల్‌తో ఎడమ వైపున ఉన్న పొరుగున ఉన్న KV కి తిరిగి ఇస్తుంది, ఇది ఒకే ఆకు నోడ్‌లో లేదా పూర్వీకుల నోడ్‌లో ఉంటుంది.
    ///
    /// చెట్టులో edge ఆకు మొదటిది అయితే, రూట్ నోడ్‌తో [`Result::Err`] ను తిరిగి ఇస్తుంది.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// అంతర్గత edge హ్యాండిల్ ఇచ్చినట్లయితే, [`Result::Ok`] ను హ్యాండిల్‌తో పొరుగున ఉన్న KV కి కుడి వైపున తిరిగి ఇస్తుంది, ఇది అదే అంతర్గత నోడ్‌లో లేదా పూర్వీకుల నోడ్‌లో ఉంటుంది.
    ///
    /// అంతర్గత edge చెట్టులో చివరిది అయితే, రూట్ నోడ్‌తో [`Result::Err`] ను తిరిగి ఇస్తుంది.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// ఒక ఆకు edge హ్యాండిల్‌ను చనిపోతున్న చెట్టులోకి ఇచ్చి, తదుపరి ఆకు edge ను కుడి వైపున తిరిగి ఇస్తుంది మరియు మధ్యలో ఉన్న కీ-విలువ జత, అదే ఆకు నోడ్‌లో, పూర్వీకుల నోడ్‌లో లేదా ఉనికిలో లేదు.
    ///
    ///
    /// ఈ పద్ధతి ఏదైనా node(s) చివరికి చేరుకుంటుంది.
    /// కీ-విలువ జత లేనట్లయితే, చెట్టు యొక్క మిగిలిన మొత్తం డీలోకేట్ చేయబడిందని మరియు తిరిగి రావడానికి ఏమీ లేదని ఇది సూచిస్తుంది.
    ///
    /// # Safety
    /// ఇచ్చిన edge గతంలో కౌంటర్ `deallocating_next_back` చేత తిరిగి ఇవ్వబడలేదు.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// ఒక ఆకు edge హ్యాండిల్‌ను చనిపోతున్న చెట్టులోకి ఇచ్చి, తదుపరి ఆకు edge ను ఎడమ వైపున తిరిగి ఇస్తుంది మరియు మధ్యలో ఉన్న కీ-విలువ జత, అదే ఆకు నోడ్‌లో, పూర్వీకుల నోడ్‌లో లేదా ఉనికిలో లేదు.
    ///
    ///
    /// ఈ పద్ధతి ఏదైనా node(s) చివరికి చేరుకుంటుంది.
    /// కీ-విలువ జత లేనట్లయితే, చెట్టు యొక్క మిగిలిన మొత్తం డీలోకేట్ చేయబడిందని మరియు తిరిగి రావడానికి ఏమీ లేదని ఇది సూచిస్తుంది.
    ///
    /// # Safety
    /// ఇచ్చిన edge గతంలో కౌంటర్ `deallocating_next` చేత తిరిగి ఇవ్వబడలేదు.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// ఆకు నుండి రూట్ వరకు నోడ్ల కుప్పను డీలోకేట్ చేస్తుంది.
    /// `deallocating_next` మరియు `deallocating_next_back` చెట్టు యొక్క రెండు వైపులా నిబ్బింగ్ చేయబడి, అదే edge ను తాకిన తరువాత మిగిలిన చెట్టును డీలోకేట్ చేయడానికి ఇదే మార్గం.
    /// అన్ని కీలు మరియు విలువలు తిరిగి ఇవ్వబడినప్పుడు మాత్రమే పిలవడానికి ఉద్దేశించినందున, కీలు లేదా విలువలలో దేనినీ శుభ్రపరచడం జరుగుతుంది.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ఆకు edge హ్యాండిల్‌ను తదుపరి ఆకు edge కి తరలించి, మధ్యలో ఉన్న కీ మరియు విలువకు సూచనలను అందిస్తుంది.
    ///
    ///
    /// # Safety
    /// ప్రయాణించిన దిశలో మరో కెవి ఉండాలి.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// ఆకు edge హ్యాండిల్‌ను మునుపటి ఆకు edge కి తరలిస్తుంది మరియు మధ్యలో ఉన్న కీ మరియు విలువకు సూచనలను అందిస్తుంది.
    ///
    ///
    /// # Safety
    /// ప్రయాణించిన దిశలో మరో కెవి ఉండాలి.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ఆకు edge హ్యాండిల్‌ను తదుపరి ఆకు edge కి తరలించి, మధ్యలో ఉన్న కీ మరియు విలువకు సూచనలను అందిస్తుంది.
    ///
    ///
    /// # Safety
    /// ప్రయాణించిన దిశలో మరో కెవి ఉండాలి.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // బెంచ్‌మార్క్‌ల ప్రకారం చివరిగా చేయడం వేగంగా జరుగుతుంది.
        kv.into_kv_valmut()
    }

    /// మునుపటి ఆకుకు edge హ్యాండిల్‌ను కదిలిస్తుంది మరియు మధ్యలో ఉన్న కీ మరియు విలువకు సూచనలను అందిస్తుంది.
    ///
    ///
    /// # Safety
    /// ప్రయాణించిన దిశలో మరో కెవి ఉండాలి.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // బెంచ్‌మార్క్‌ల ప్రకారం చివరిగా చేయడం వేగంగా జరుగుతుంది.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// ఆకు edge హ్యాండిల్‌ను తదుపరి ఆకు edge కి తరలించి, మధ్యలో ఉన్న కీ మరియు విలువను తిరిగి ఇస్తుంది, సంబంధిత edge ను దాని పేరెంట్ నోడ్ డాంగ్లింగ్‌లో వదిలివేసేటప్పుడు మిగిలి ఉన్న ఏదైనా నోడ్‌ను డీలోలోకేట్ చేస్తుంది.
    ///
    /// # Safety
    /// - ప్రయాణించిన దిశలో మరో కెవి ఉండాలి.
    /// - చెట్టును దాటడానికి ఉపయోగించే హ్యాండిల్స్ యొక్క ఏదైనా కాపీపై KV గతంలో కౌంటర్ `next_back_unchecked` ద్వారా తిరిగి ఇవ్వబడలేదు.
    ///
    /// నవీకరించబడిన హ్యాండిల్‌తో కొనసాగడానికి ఉన్న ఏకైక సురక్షితమైన మార్గం ఏమిటంటే, దాన్ని పోల్చడం, డ్రాప్ చేయడం, ఈ పద్ధతిని దాని భద్రతా పరిస్థితులకు లోబడి మళ్ళీ కాల్ చేయడం లేదా దాని భద్రతా పరిస్థితులకు లోబడి కౌంటర్పార్ట్ `next_back_unchecked` కి కాల్ చేయడం.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// ఆకు edge హ్యాండిల్‌ను మునుపటి ఆకు edge కి తరలించి, మధ్యలో ఉన్న కీ మరియు విలువను తిరిగి ఇస్తుంది, సంబంధిత edge ను దాని మాతృ నోడ్ డాంగ్లింగ్‌లో వదిలివేసేటప్పుడు మిగిలి ఉన్న ఏదైనా నోడ్‌ను డీలోలోకేట్ చేస్తుంది.
    ///
    /// # Safety
    /// - ప్రయాణించిన దిశలో మరో కెవి ఉండాలి.
    /// - ఆ ఆకు edge గతంలో చెట్టును దాటడానికి ఉపయోగించబడుతున్న హ్యాండిల్స్ యొక్క ఏదైనా కాపీపై కౌంటర్ `next_unchecked` ద్వారా తిరిగి ఇవ్వబడలేదు.
    ///
    /// నవీకరించబడిన హ్యాండిల్‌తో కొనసాగడానికి ఉన్న ఏకైక సురక్షితమైన మార్గం ఏమిటంటే, దాన్ని పోల్చడం, డ్రాప్ చేయడం, ఈ పద్ధతిని దాని భద్రతా పరిస్థితులకు లోబడి మళ్ళీ కాల్ చేయడం లేదా దాని భద్రతా పరిస్థితులకు లోబడి కౌంటర్పార్ట్ `next_unchecked` కి కాల్ చేయడం.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// ఎడమవైపున ఉన్న edge ను నోడ్‌లో లేదా కింద తిరిగి ఇస్తుంది, మరో మాటలో చెప్పాలంటే, ముందుకు నావిగేట్ చేసేటప్పుడు మీకు మొదట అవసరమైన edge (లేదా వెనుకకు నావిగేట్ చేసేటప్పుడు చివరిది).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// నోడ్‌లో లేదా కింద కుడివైపున ఉన్న edge ను తిరిగి ఇస్తుంది, మరో మాటలో చెప్పాలంటే, ముందుకు నావిగేట్ చేసేటప్పుడు మీకు చివరిగా అవసరమయ్యే edge (లేదా మొదట వెనుకకు నావిగేట్ చేసేటప్పుడు).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// ఆరోహణ కీల క్రమంలో ఆకు నోడ్లు మరియు అంతర్గత కెవిలను సందర్శిస్తుంది మరియు అంతర్గత నోడ్లను లోతుగా మొదటి క్రమంలో కూడా సందర్శిస్తుంది, అనగా అంతర్గత నోడ్లు వారి వ్యక్తిగత కెవిలు మరియు వారి పిల్లల నోడ్లకు ముందు ఉంటాయి.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// (ఉప) చెట్టులోని మూలకాల సంఖ్యను లెక్కిస్తుంది.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// ఫార్వర్డ్ నావిగేషన్ కోసం KV కి దగ్గరగా ఉన్న edge ఆకును అందిస్తుంది.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// వెనుకబడిన నావిగేషన్ కోసం KV కి దగ్గరగా ఉన్న edge ఆకును అందిస్తుంది.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}