//! బైనరీ కుప్పతో ప్రాధాన్యత క్యూ అమలు చేయబడింది.
//!
//! అతిపెద్ద మూలకాన్ని చొప్పించడం మరియు పాపింగ్ చేయడం *O*(log(*n*)) సమయ సంక్లిష్టతను కలిగి ఉంటుంది.
//! అతిపెద్ద మూలకాన్ని తనిఖీ చేయడం *O*(1).vector ను బైనరీ కుప్పగా మార్చడం స్థలంలోనే చేయవచ్చు మరియు *O*(*n*) సంక్లిష్టతను కలిగి ఉంటుంది.
//! బైనరీ కుప్పను ఒక క్రమబద్ధీకరించిన vector స్థానంలో మార్చవచ్చు, ఇది *O*(*n*\*log(* n*)) ఇన్-ప్లేస్ హీప్‌సోర్ట్ కోసం ఉపయోగించడానికి అనుమతిస్తుంది.
//!
//! # Examples
//!
//! [directed graph][dir_graph] లో [shortest path problem][sssp] ను పరిష్కరించడానికి [Dijkstra's algorithm][dijkstra] ను అమలు చేసే పెద్ద ఉదాహరణ ఇది.
//!
//! కస్టమ్ రకాలతో [`BinaryHeap`] ను ఎలా ఉపయోగించాలో ఇది చూపిస్తుంది.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // ప్రాధాన్యత క్యూ `Ord` పై ఆధారపడి ఉంటుంది.
//! // trait ను స్పష్టంగా అమలు చేయండి, కాబట్టి క్యూ గరిష్ట-కుప్పకు బదులుగా నిమిషం-కుప్పగా మారుతుంది.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // మేము ఖర్చులపై ఆర్డరింగ్ను తిప్పికొట్టడం గమనించండి.
//!         // టై విషయంలో మేము స్థానాలను పోల్చి చూస్తే, `PartialEq` మరియు `Ord` యొక్క అమలులను స్థిరంగా చేయడానికి ఈ దశ అవసరం.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` అలాగే అమలు చేయాలి.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // ప్రతి నోడ్ తక్కువ అమలు కోసం, `usize` గా సూచించబడుతుంది.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // డిజ్క్‌స్ట్రా యొక్క చిన్నదైన మార్గం అల్గోరిథం.
//!
//! // `start` వద్ద ప్రారంభించండి మరియు ప్రతి నోడ్‌కు ప్రస్తుత అతి తక్కువ దూరాన్ని ట్రాక్ చేయడానికి `dist` ని ఉపయోగించండి.ఈ అమలు మెమరీ-సమర్థవంతమైనది కాదు ఎందుకంటే ఇది నకిలీ నోడ్‌లను క్యూలో ఉంచవచ్చు.
//! //
//! // ఇది సరళమైన అమలు కోసం `usize::MAX` ను సెంటినెల్ విలువగా ఉపయోగిస్తుంది.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [నోడ్]= `start` నుండి `node` వరకు ప్రస్తుత అతి తక్కువ దూరం
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // మేము `start` వద్ద ఉన్నాము, సున్నా ఖర్చుతో
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // మొదటి (min-heap) తక్కువ ఖర్చు నోడ్‌లతో సరిహద్దును పరిశీలించండి
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // ప్రత్యామ్నాయంగా మేము అన్ని చిన్న మార్గాలను కనుగొనడం కొనసాగించవచ్చు
//!         if position == goal { return Some(cost); }
//!
//!         // మేము ఇప్పటికే మంచి మార్గాన్ని కనుగొన్నందున ముఖ్యమైనది
//!         if cost > dist[position] { continue; }
//!
//!         // మేము చేరుకోగల ప్రతి నోడ్ కోసం, ఈ నోడ్ ద్వారా తక్కువ ఖర్చుతో ఒక మార్గాన్ని కనుగొనగలమా అని చూడండి
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // అలా అయితే, దానిని సరిహద్దుకు జోడించి కొనసాగించండి
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // విశ్రాంతి, మేము ఇప్పుడు మంచి మార్గాన్ని కనుగొన్నాము
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // లక్ష్యాన్ని చేరుకోలేదు
//!     None
//! }
//!
//! fn main() {
//!     // ఇది మేము ఉపయోగించబోయే దర్శకత్వ గ్రాఫ్.
//!     // నోడ్ సంఖ్యలు వేర్వేరు రాష్ట్రాలకు అనుగుణంగా ఉంటాయి మరియు edge బరువులు ఒక నోడ్ నుండి మరొక నోడ్‌కు వెళ్ళే ఖర్చును సూచిస్తాయి.
//!     //
//!     // అంచులు వన్-వే అని గమనించండి.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // గ్రాఫ్ ఒక ప్రక్కనే ఉన్న జాబితాగా సూచించబడుతుంది, ఇక్కడ ప్రతి సూచిక, నోడ్ విలువకు అనుగుణంగా, అవుట్గోయింగ్ అంచుల జాబితాను కలిగి ఉంటుంది.
//!     // దాని సామర్థ్యం కోసం ఎంచుకోబడింది.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // నోడ్ 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // నోడ్ 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // నోడ్ 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // నోడ్ 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // నోడ్ 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// బైనరీ కుప్పతో ప్రాధాన్యత క్యూ అమలు చేయబడింది.
///
/// ఇది గరిష్ట కుప్ప అవుతుంది.
///
/// `Ord` trait చేత నిర్ణయించబడినట్లుగా, ఏ ఇతర వస్తువుతోనైనా వస్తువు యొక్క క్రమం కుప్పలో ఉన్నప్పుడు మారుతున్న విధంగా ఒక వస్తువు సవరించడం ఒక లాజిక్ లోపం.
///
/// ఇది సాధారణంగా `Cell`, `RefCell`, గ్లోబల్ స్టేట్, I/O లేదా అసురక్షిత కోడ్ ద్వారా మాత్రమే సాధ్యమవుతుంది.
/// అటువంటి లాజిక్ లోపం వల్ల కలిగే ప్రవర్తన పేర్కొనబడలేదు, కానీ నిర్వచించబడని ప్రవర్తనకు దారితీయదు.
/// ఇందులో panics, తప్పు ఫలితాలు, గర్భస్రావం, మెమరీ లీక్‌లు మరియు రద్దు చేయబడవు.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // టైప్ అనుమితి స్పష్టమైన రకం సంతకాన్ని వదిలివేయడానికి మాకు అనుమతిస్తుంది (ఇది ఈ ఉదాహరణలో `BinaryHeap<i32>` అవుతుంది).
/////
/// let mut heap = BinaryHeap::new();
///
/// // కుప్పలోని తదుపరి అంశాన్ని చూడటానికి మనం పీక్ ఉపయోగించవచ్చు.
/// // ఈ సందర్భంలో, అక్కడ ఇంకా అంశాలు లేవు కాబట్టి మనకు ఏదీ లభించదు.
/// assert_eq!(heap.peek(), None);
///
/// // కొన్ని స్కోర్‌లను చేర్చుదాం ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // ఇప్పుడు పీక్ కుప్పలోని అతి ముఖ్యమైన అంశాన్ని చూపిస్తుంది.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // మేము కుప్ప యొక్క పొడవును తనిఖీ చేయవచ్చు.
/// assert_eq!(heap.len(), 3);
///
/// // కుప్పలోని వస్తువులను యాదృచ్ఛిక క్రమంలో తిరిగి ఇచ్చినప్పటికీ, మేము వాటిని మళ్ళించగలము.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // మేము బదులుగా ఈ స్కోర్‌లను పాప్ చేస్తే, అవి తిరిగి రావాలి.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // మేము మిగిలిన వస్తువుల కుప్పను క్లియర్ చేయవచ్చు.
/// heap.clear();
///
/// // కుప్ప ఇప్పుడు ఖాళీగా ఉండాలి.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// `BinaryHeap` ను నిమిషం-కుప్పగా మార్చడానికి `std::cmp::Reverse` లేదా కస్టమ్ `Ord` అమలును ఉపయోగించవచ్చు.
/// ఇది `heap.pop()` గొప్పదానికి బదులుగా అతిచిన్న విలువను తిరిగి ఇస్తుంది.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // `Reverse` లో విలువలను చుట్టండి
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // మేము ఇప్పుడు ఈ స్కోర్‌లను పాప్ చేస్తే, అవి రివర్స్ క్రమంలో తిరిగి రావాలి.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # సమయం సంక్లిష్టత
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// `push` యొక్క విలువ cost హించిన ఖర్చు;పద్ధతి డాక్యుమెంటేషన్ మరింత వివరణాత్మక విశ్లేషణను ఇస్తుంది.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// `BinaryHeap` లో గొప్ప అంశానికి మార్చగల సూచనను చుట్టే నిర్మాణం.
///
///
/// ఈ `struct` [`BinaryHeap`] లో [`peek_mut`] పద్ధతి ద్వారా సృష్టించబడుతుంది.
/// మరిన్ని కోసం దాని డాక్యుమెంటేషన్ చూడండి.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // భద్రత: పీక్మట్ ఖాళీ కాని కుప్పల కోసం మాత్రమే తక్షణం ఇవ్వబడుతుంది.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // సేఫ్: పీక్మట్ ఖాళీ కాని కుప్పల కోసం మాత్రమే తక్షణం ఇవ్వబడుతుంది
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // సేఫ్: పీక్మట్ ఖాళీ కాని కుప్పల కోసం మాత్రమే తక్షణం ఇవ్వబడుతుంది
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// కుప్ప నుండి పీక్ చేసిన విలువను తీసివేసి తిరిగి ఇస్తుంది.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// ఖాళీ `BinaryHeap<T>` ను సృష్టిస్తుంది.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// ఖాళీ `BinaryHeap` ను గరిష్ట-కుప్పగా సృష్టిస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// నిర్దిష్ట సామర్థ్యంతో ఖాళీ `BinaryHeap` ను సృష్టిస్తుంది.
    /// ఇది `capacity` మూలకాలకు తగినంత మెమరీని ముందస్తుగా కేటాయిస్తుంది, తద్వారా `BinaryHeap` కనీసం ఎక్కువ విలువలను కలిగి ఉన్నంత వరకు తిరిగి కేటాయించాల్సిన అవసరం లేదు.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// బైనరీ కుప్పలోని గొప్ప వస్తువుకు మార్చగల సూచనను లేదా ఖాళీగా ఉంటే `None` ను అందిస్తుంది.
    ///
    /// Note: `PeekMut` విలువ లీక్ అయినట్లయితే, కుప్ప అస్థిరమైన స్థితిలో ఉండవచ్చు.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # సమయం సంక్లిష్టత
    ///
    /// అంశం సవరించబడితే చెత్త సమయ సంక్లిష్టత *O*(log(*n*)), లేకపోతే అది *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// బైనరీ కుప్ప నుండి గొప్ప వస్తువును తీసివేసి, దానిని తిరిగి ఇస్తుంది, లేదా అది ఖాళీగా ఉంటే `None`.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # సమయం సంక్లిష్టత
    ///
    /// *N* మూలకాలను కలిగి ఉన్న కుప్పపై `pop` యొక్క చెత్త కేసు *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // భద్రత: !self.is_empty() అంటే self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// ఒక వస్తువును బైనరీ కుప్పపైకి నెట్టేస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # సమయం సంక్లిష్టత
    ///
    /// `push` యొక్క cost హించిన వ్యయం, మూలకాల యొక్క ప్రతి క్రమం కంటే సగటున, మరియు తగినంత పెద్ద సంఖ్యలో నెట్టడం *O*(1).
    ///
    /// ఇప్పటికే ఏ విధమైన క్రమబద్ధీకరించిన నమూనాలో *లేని* మూలకాలను నెట్టేటప్పుడు ఇది చాలా అర్ధవంతమైన ఖర్చు మెట్రిక్.
    ///
    /// మూలకాలను ప్రధానంగా ఆరోహణ క్రమంలో నెట్టివేస్తే సమయ సంక్లిష్టత క్షీణిస్తుంది.
    /// చెత్త సందర్భంలో, మూలకాలు ఆరోహణ క్రమబద్ధీకరించబడిన క్రమంలో నెట్టబడతాయి మరియు *n* మూలకాలను కలిగి ఉన్న కుప్పకు వ్యతిరేకంగా ప్రతి పుష్కి రుణమాఫీ ఖర్చు *O*(log(*n*)).
    ///
    /// `push` కి *సింగిల్* కాల్ యొక్క చెత్త కేసు *O*(*n*).సామర్థ్యం అయిపోయినప్పుడు మరియు పున ize పరిమాణం అవసరమైనప్పుడు చెత్త సంభవిస్తుంది.
    /// పున ize పరిమాణం ఖర్చు మునుపటి గణాంకాలలో రుణమాఫీ చేయబడింది.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // భద్రత: మేము క్రొత్త వస్తువును నెట్టివేసినందున దాని అర్థం
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// `BinaryHeap` ను వినియోగిస్తుంది మరియు క్రమబద్ధీకరించిన (ascending) క్రమంలో vector ను అందిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // భద్రత: `end` `self.len() - 1` నుండి 1 కి వెళుతుంది (రెండూ కూడా ఉన్నాయి),
            //  కనుక ఇది ఎల్లప్పుడూ ప్రాప్యత చేయడానికి చెల్లుబాటు అయ్యే సూచిక.
            //  ఇండెక్స్ 0 (అంటే `ptr`) ను యాక్సెస్ చేయడం సురక్షితం, ఎందుకంటే
            //  1 <=ముగింపు <self.len(), అంటే self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // భద్రత: `end` `self.len() - 1` నుండి 1 కి వెళుతుంది (రెండూ కూడా ఉన్నాయి) కాబట్టి:
            //  0 <1 <=end <= self.len(), 1 <self.len() అంటే 0 <ముగింపు మరియు ముగింపు <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Sift_up మరియు sift_down యొక్క అమలులు vector (ఒక రంధ్రం వెనుక వదిలి) నుండి ఒక మూలకాన్ని తరలించడానికి, ఇతరులతో పాటు మారడానికి మరియు తొలగించిన మూలకాన్ని రంధ్రం యొక్క చివరి స్థానంలో vector లోకి తరలించడానికి అసురక్షిత బ్లాక్‌లను ఉపయోగిస్తాయి.
    //
    // `Hole` రకం దీనిని సూచించడానికి ఉపయోగించబడుతుంది మరియు panic లో కూడా రంధ్రం దాని పరిధి చివరిలో తిరిగి నింపబడిందని నిర్ధారించుకోండి.
    // మార్పిడులను ఉపయోగించడంతో పోలిస్తే రంధ్రం ఉపయోగించడం స్థిరమైన కారకాన్ని తగ్గిస్తుంది, ఇందులో రెండు రెట్లు ఎక్కువ కదలికలు ఉంటాయి.
    //
    //
    //
    //

    /// # Safety
    ///
    /// కాలర్ `pos < self.len()` అని హామీ ఇవ్వాలి.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // `pos` వద్ద విలువను తీసివేసి రంధ్రం సృష్టించండి.
        // భద్రత: పోస్ <self.len() అని కాలర్ హామీ ఇస్తుంది
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // భద్రత: hole.pos()> ప్రారంభం>=0, అంటే hole.pos()> 0
            //  కాబట్టి hole.pos(), 1 అండర్ ఫ్లో కాదు.
            //  ఇది పేరెంట్ <hole.pos() అని హామీ ఇస్తుంది కాబట్టి ఇది చెల్లుబాటు అయ్యే సూచిక మరియు!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // భద్రత: పైన చెప్పినట్లే
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// `pos` వద్ద ఒక మూలకాన్ని తీసుకొని దానిని కుప్ప క్రిందకు తరలించండి, దాని పిల్లలు పెద్దవిగా ఉంటాయి.
    ///
    ///
    /// # Safety
    ///
    /// కాలర్ `pos < end <= self.len()` అని హామీ ఇవ్వాలి.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // భద్రత: పోస్ <ముగింపు <= self.len() అని కాలర్ హామీ ఇస్తుంది.
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // లూప్ మార్పు: పిల్లవాడు==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // ఇద్దరు పిల్లలలో ఎక్కువ మందితో పోల్చండి భద్రత: పిల్లల <ముగింపు, 1 <self.len() మరియు పిల్లల + 1 <ముగింపు <= self.len(), కాబట్టి అవి చెల్లుబాటు అయ్యే సూచికలు.
            //
            //  child==2 *hole.pos() + 1!= hole.pos() మరియు పిల్లవాడు + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: T ఒక ZST అయితే 2 *hole.pos() + 1 లేదా 2* hole.pos() + 2 పొంగిపొర్లుతుంది
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // మేము ఇప్పటికే క్రమంలో ఉంటే, ఆపండి.
            // భద్రత: పిల్లవాడు ఇప్పుడు పాత పిల్లవాడు లేదా పాత పిల్లవాడు + 1
            //  రెండూ <self.len() మరియు!= hole.pos() అని మేము ఇప్పటికే నిరూపించాము
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // భద్రత: పైన చెప్పినట్లే.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // భద్రత: &&షార్ట్ సర్క్యూట్, అంటే
        //  రెండవ పరిస్థితి పిల్లల==ముగింపు, 1 <self.len() అని ఇప్పటికే నిజం.
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // భద్రత: పిల్లవాడు చెల్లుబాటు అయ్యే సూచికగా ఇప్పటికే నిరూపించబడింది మరియు
            //  పిల్లల==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// కాలర్ `pos < self.len()` అని హామీ ఇవ్వాలి.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // భద్రత: పోస్ <లెన్ కాలర్ ద్వారా హామీ ఇవ్వబడుతుంది మరియు
        //  స్పష్టంగా లెన్= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// `pos` వద్ద ఒక మూలకాన్ని తీసుకోండి మరియు దానిని కుప్ప క్రిందకు తరలించండి, తరువాత దానిని దాని స్థానానికి జల్లెడ.
    ///
    ///
    /// Note: మూలకం పెద్దదిగా తెలిసినప్పుడు/దిగువకు దగ్గరగా ఉండాలి.
    ///
    /// # Safety
    ///
    /// కాలర్ `pos < self.len()` అని హామీ ఇవ్వాలి.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // భద్రత: పోస్ <self.len() అని కాలర్ హామీ ఇస్తుంది.
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // లూప్ మార్పు: పిల్లవాడు==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // భద్రత: పిల్లల <ముగింపు, 1 <self.len() మరియు
            //  పిల్లల + 1 <ముగింపు <= self.len(), కాబట్టి అవి చెల్లుబాటు అయ్యే సూచికలు.
            //  child==2 *hole.pos() + 1!= hole.pos() మరియు పిల్లవాడు + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: T ఒక ZST అయితే 2 *hole.pos() + 1 లేదా 2* hole.pos() + 2 పొంగిపొర్లుతుంది
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // భద్రత: పైన చెప్పినట్లే
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // భద్రత: పిల్లల==ముగింపు, 1 <self.len(), కాబట్టి ఇది చెల్లుబాటు అయ్యే సూచిక
            //  మరియు పిల్లవాడు==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // భద్రత: పోస్ అనేది రంధ్రంలో ఉన్న స్థానం మరియు ఇదివరకే నిరూపించబడింది
        //  చెల్లుబాటు అయ్యే సూచిక.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // భద్రత: n self.len()/2 నుండి మొదలై 0 కి వెళుతుంది.
            //  (N <self.len()) అనేది self.len() ==0 అయితే, అయితే ఇది లూప్ కండిషన్ ద్వారా తోసిపుచ్చబడుతుంది.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// `other` యొక్క అన్ని మూలకాలను `self` లోకి కదిలిస్తుంది, `other` ఖాళీగా ఉంటుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` O(len1 + len2) ఆపరేషన్లు మరియు చెత్త సందర్భంలో సుమారు 2 *(len1 + len2) పోలికలను తీసుకుంటుంది, అయితే `extend` O(len2* log(len1)) ఆపరేషన్లను తీసుకుంటుంది మరియు చెత్త సందర్భంలో 1 *len2* log_2(len1) పోలికలను తీసుకుంటుంది, len1>= len2 అని uming హిస్తుంది.
        // పెద్ద కుప్పల కోసం, క్రాస్ఓవర్ పాయింట్ ఇకపై ఈ వాదనను అనుసరించదు మరియు అనుభవపూర్వకంగా నిర్ణయించబడుతుంది.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// కుప్ప క్రమంలో మూలకాలను తిరిగి పొందే ఇటరేటర్‌ను అందిస్తుంది.
    /// తిరిగి పొందిన అంశాలు అసలు కుప్ప నుండి తొలగించబడతాయి.
    /// కుప్ప క్రమంలో డ్రాప్‌లో మిగిలిన అంశాలు తొలగించబడతాయి.
    ///
    /// Note:
    /// * `.drain_sorted()` *O*(*n*\*log(* n*)); `.drain()` కన్నా చాలా నెమ్మదిగా ఉంటుంది.
    ///   మీరు చాలా సందర్భాలలో రెండోదాన్ని ఉపయోగించాలి.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // కుప్ప క్రమంలో అన్ని అంశాలను తొలగిస్తుంది
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// ప్రిడికేట్ పేర్కొన్న అంశాలను మాత్రమే కలిగి ఉంటుంది.
    ///
    /// మరో మాటలో చెప్పాలంటే, `e` అన్ని మూలకాలను తొలగించండి, అంటే `f(&e)` `false` ను తిరిగి ఇస్తుంది.
    /// మూలకాలను క్రమబద్ధీకరించని (మరియు పేర్కొనబడని) క్రమంలో సందర్శిస్తారు.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // సరి సంఖ్యలను మాత్రమే ఉంచండి
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// vector లోని అన్ని విలువలను ఏకపక్ష క్రమంలో సందర్శించే ఇరేటర్‌ను అందిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // 1, 2, 3, 4 ను ఏకపక్ష క్రమంలో ముద్రించండి
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// కుప్ప క్రమంలో మూలకాలను తిరిగి పొందే ఇటరేటర్‌ను అందిస్తుంది.
    /// ఈ పద్ధతి అసలు కుప్పను వినియోగిస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// బైనరీ కుప్పలోని గొప్ప వస్తువు లేదా `None` ఖాళీగా ఉంటే తిరిగి ఇస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # సమయం సంక్లిష్టత
    ///
    /// చెత్త సందర్భంలో ఖర్చు *O*(1).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// బైనరీ కుప్ప తిరిగి కేటాయించకుండా ఉంచగల మూలకాల సంఖ్యను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// ఇచ్చిన `BinaryHeap` లో ఖచ్చితంగా `additional` మరిన్ని మూలకాలను చేర్చడానికి కనీస సామర్థ్యాన్ని కలిగి ఉంది.
    /// సామర్థ్యం ఇప్పటికే సరిపోతుంటే ఏమీ చేయదు.
    ///
    /// కేటాయింపుదారుడు కోరిన దానికంటే ఎక్కువ స్థలాన్ని ఇవ్వవచ్చని గమనించండి.
    /// అందువల్ల సామర్థ్యం ఖచ్చితంగా తక్కువగా ఉండటానికి ఆధారపడదు.
    /// future చొప్పనలు if హించినట్లయితే [`reserve`] కి ప్రాధాన్యత ఇవ్వండి.
    ///
    /// # Panics
    ///
    /// కొత్త సామర్థ్యం `usize` ని పొంగిపోతే Panics.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// `BinaryHeap` లో చేర్చడానికి కనీసం `additional` మరిన్ని మూలకాలకు నిల్వ నిల్వ సామర్థ్యం.
    /// తరచుగా తిరిగి కేటాయించకుండా ఉండటానికి సేకరణ ఎక్కువ స్థలాన్ని కేటాయించవచ్చు.
    ///
    /// # Panics
    ///
    /// కొత్త సామర్థ్యం `usize` ని పొంగిపోతే Panics.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// సాధ్యమైనంత ఎక్కువ అదనపు సామర్థ్యాన్ని విస్మరిస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// తక్కువ బౌండ్‌తో సామర్థ్యాన్ని విస్మరిస్తుంది.
    ///
    /// సామర్థ్యం పొడవు మరియు సరఫరా విలువ రెండింటికీ కనీసం పెద్దదిగా ఉంటుంది.
    ///
    ///
    /// ప్రస్తుత సామర్థ్యం తక్కువ పరిమితి కంటే తక్కువగా ఉంటే, ఇది నో-ఆప్.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// `BinaryHeap` ను వినియోగిస్తుంది మరియు అంతర్లీన vector ను ఏకపక్ష క్రమంలో అందిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // కొన్ని క్రమంలో ముద్రించబడుతుంది
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// బైనరీ కుప్ప యొక్క పొడవును అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// బైనరీ కుప్ప ఖాళీగా ఉందో లేదో తనిఖీ చేస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// బైనరీ కుప్పను క్లియర్ చేస్తుంది, తీసివేసిన మూలకాలపై ఇరేటర్‌ను తిరిగి ఇస్తుంది.
    ///
    /// మూలకాలు ఏకపక్ష క్రమంలో తొలగించబడతాయి.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// బైనరీ కుప్ప నుండి అన్ని వస్తువులను పడేస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// రంధ్రం స్లైస్‌లోని రంధ్రంను సూచిస్తుంది, అనగా చెల్లుబాటు అయ్యే విలువ లేని సూచిక (ఎందుకంటే ఇది తరలించబడింది లేదా నకిలీ చేయబడింది).
///
/// డ్రాప్‌లో, `Hole` స్లైస్‌ను రంధ్రం స్థానాన్ని మొదట తొలగించిన విలువతో నింపడం ద్వారా పునరుద్ధరిస్తుంది.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// ఇండెక్స్ `pos` వద్ద కొత్త `Hole` ను సృష్టించండి.
    ///
    /// అసురక్షితమైనది ఎందుకంటే పోస్ తప్పనిసరిగా డేటా స్లైస్‌లో ఉండాలి.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // సేఫ్: పోస్ స్లైస్ లోపల ఉండాలి
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// తీసివేయబడిన మూలకానికి సూచనను అందిస్తుంది.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// `index` వద్ద మూలకానికి సూచనను అందిస్తుంది.
    ///
    /// సురక్షితం కాదు ఎందుకంటే ఇండెక్స్ డేటా స్లైస్‌లో ఉండాలి మరియు పోస్‌కు సమానం కాదు.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// రంధ్రం క్రొత్త స్థానానికి తరలించండి
    ///
    /// సురక్షితం కాదు ఎందుకంటే ఇండెక్స్ డేటా స్లైస్‌లో ఉండాలి మరియు పోస్‌కు సమానం కాదు.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // మళ్ళీ రంధ్రం నింపండి
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// `BinaryHeap` యొక్క అంశాలపై మళ్ళింపు.
///
/// ఈ `struct` [`BinaryHeap::iter()`] చే సృష్టించబడింది.
/// మరిన్ని కోసం దాని డాక్యుమెంటేషన్ చూడండి.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) `#[derive(Clone)]` కు అనుకూలంగా తొలగించండి
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// `BinaryHeap` యొక్క అంశాలపై స్వంత ఇరేటర్.
///
/// ఈ `struct` [`BinaryHeap::into_iter()`] చే సృష్టించబడింది (`IntoIterator` trait చే అందించబడింది).
/// మరిన్ని కోసం దాని డాక్యుమెంటేషన్ చూడండి.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// `BinaryHeap` యొక్క మూలకాలపై ఎండిపోయే ఇరేటర్.
///
/// ఈ `struct` [`BinaryHeap::drain()`] చే సృష్టించబడింది.
/// మరిన్ని కోసం దాని డాక్యుమెంటేషన్ చూడండి.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// `BinaryHeap` యొక్క మూలకాలపై ఎండిపోయే ఇరేటర్.
///
/// ఈ `struct` [`BinaryHeap::drain_sorted()`] చే సృష్టించబడింది.
/// మరిన్ని కోసం దాని డాక్యుమెంటేషన్ చూడండి.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// కుప్ప క్రమంలో కుప్ప మూలకాలను తొలగిస్తుంది.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// `Vec<T>` ను `BinaryHeap<T>` గా మారుస్తుంది.
    ///
    /// ఈ మార్పిడి స్థానంలో జరుగుతుంది మరియు *O*(*n*) సమయ సంక్లిష్టతను కలిగి ఉంటుంది.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// `BinaryHeap<T>` ను `Vec<T>` గా మారుస్తుంది.
    ///
    /// ఈ మార్పిడికి డేటా కదలిక లేదా కేటాయింపు అవసరం లేదు మరియు స్థిరమైన సమయ సంక్లిష్టతను కలిగి ఉంటుంది.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// వినియోగించే మళ్ళిని సృష్టిస్తుంది, అనగా, ప్రతి విలువను బైనరీ కుప్ప నుండి ఏకపక్ష క్రమంలో కదిలిస్తుంది.
    /// దీన్ని పిలిచిన తర్వాత బైనరీ కుప్పను ఉపయోగించలేరు.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // 1, 2, 3, 4 ను ఏకపక్ష క్రమంలో ముద్రించండి
    /// for x in heap.into_iter() {
    ///     // x రకం i32, &i32 కాదు
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}