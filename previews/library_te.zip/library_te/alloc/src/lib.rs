//! # Rust కోర్ కేటాయింపు మరియు సేకరణల లైబ్రరీ
//!
//! ఈ లైబ్రరీ కుప్ప-కేటాయించిన విలువలను నిర్వహించడానికి స్మార్ట్ పాయింటర్లు మరియు సేకరణలను అందిస్తుంది.
//!
//! ఈ లైబ్రరీ, లిబ్కోర్ లాగా, సాధారణంగా [`std` crate](../std/index.html) లో దాని విషయాలు తిరిగి ఎగుమతి చేయబడినందున నేరుగా ఉపయోగించాల్సిన అవసరం లేదు.
//! `#![no_std]` లక్షణాన్ని ఉపయోగించే Crates అయితే సాధారణంగా `std` పై ఆధారపడదు, కాబట్టి వారు బదులుగా ఈ crate ను ఉపయోగిస్తారు.
//!
//! ## బాక్స్డ్ విలువలు
//!
//! [`Box`] రకం స్మార్ట్ పాయింటర్ రకం.[`Box`] యొక్క ఒక యజమాని మాత్రమే ఉండవచ్చు, మరియు యజమాని విషయాలను మార్చాలని నిర్ణయించుకోవచ్చు, అవి కుప్ప మీద నివసిస్తాయి.
//!
//! `Box` విలువ యొక్క పరిమాణం పాయింటర్ మాదిరిగానే ఉన్నందున ఈ రకాన్ని థ్రెడ్ల మధ్య సమర్థవంతంగా పంపవచ్చు.
//! చెట్టు లాంటి డేటా నిర్మాణాలు తరచుగా బాక్సులతో నిర్మించబడతాయి ఎందుకంటే ప్రతి నోడ్‌లో తరచుగా ఒకే యజమాని, పేరెంట్ ఉంటారు.
//!
//! ## సూచన లెక్కించిన పాయింటర్లు
//!
//! [`Rc`] రకం థ్రెడ్‌లో మెమరీని భాగస్వామ్యం చేయడానికి ఉద్దేశించిన థ్రెడ్‌సేఫ్ కాని రిఫరెన్స్-కౌంటెడ్ పాయింటర్ రకం.
//! [`Rc`] పాయింటర్ `T` రకాన్ని చుట్టేస్తుంది మరియు భాగస్వామ్య సూచన అయిన `&T` కు మాత్రమే ప్రాప్యతను అనుమతిస్తుంది.
//!
//! వారసత్వంగా ఉత్పరివర్తన ([`Box`] ను ఉపయోగించడం వంటివి) అనువర్తనానికి చాలా నిర్బంధంగా ఉన్నప్పుడు ఈ రకం ఉపయోగపడుతుంది మరియు మ్యుటేషన్‌ను అనుమతించడానికి తరచుగా [`Cell`] లేదా [`RefCell`] రకాలతో జతచేయబడుతుంది.
//!
//!
//! ## పరమాణు సూచన లెక్కించిన పాయింటర్లు
//!
//! [`Arc`] రకం [`Rc`] రకానికి సమానమైన థ్రెడ్‌సేఫ్.ఇది [`Rc`] యొక్క ఒకే విధమైన కార్యాచరణను అందిస్తుంది, దీనికి కలిగి ఉన్న రకం `T` భాగస్వామ్యం చేయాల్సిన అవసరం ఉంది.
//! అదనంగా, [`Rc<T>`][`Rc`] లేనప్పుడు [`Arc<T>`][`Arc`] కూడా పంపబడుతుంది.
//!
//! ఈ రకం కలిగి ఉన్న డేటాకు భాగస్వామ్య ప్రాప్యతను అనుమతిస్తుంది, మరియు భాగస్వామ్య వనరుల మ్యుటేషన్‌ను అనుమతించడానికి మ్యూటెక్స్ వంటి సమకాలీకరణ ఆదిమలతో జతచేయబడుతుంది.
//!
//! ## Collections
//!
//! ఈ లైబ్రరీలో సర్వసాధారణమైన సాధారణ ప్రయోజన డేటా నిర్మాణాల అమలులు నిర్వచించబడ్డాయి.అవి [standard collections library](../std/collections/index.html) ద్వారా తిరిగి ఎగుమతి చేయబడతాయి.
//!
//! ## కుప్ప ఇంటర్ఫేస్లు
//!
//! [`alloc`](alloc/index.html) మాడ్యూల్ తక్కువ-స్థాయి ఇంటర్‌ఫేస్‌ను డిఫాల్ట్ గ్లోబల్ కేటాయింపుకు నిర్వచిస్తుంది.ఇది libc కేటాయింపు API కి అనుకూలంగా లేదు.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// సాంకేతికంగా, ఇది రస్ట్‌డాక్‌లోని బగ్: `#[lang = slice_alloc]` బ్లాక్‌లలోని డాక్యుమెంటేషన్ `&[T]` కోసం రస్ట్‌డాక్ చూస్తుంది, ఇది `core` లో ఈ లక్షణాన్ని ఉపయోగించి డాక్యుమెంటేషన్‌ను కలిగి ఉంది మరియు ఫీచర్-గేట్ ప్రారంభించబడలేదని పిచ్చి పడుతుంది.
// ఆదర్శవంతంగా, ఇది ఇతర crates నుండి డాక్స్ కోసం ఫీచర్ గేట్ కోసం తనిఖీ చేయదు, కానీ ఇది లాంగ్ ఐటెమ్‌ల కోసం మాత్రమే కనిపిస్తుంది కాబట్టి, ఇది ఫిక్సింగ్ విలువైనదిగా అనిపించదు.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// ఈ లైబ్రరీని పరీక్షించడానికి అనుమతించండి

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// ఇతర మాడ్యూల్స్ ఉపయోగించే అంతర్గత మాక్రోలతో మాడ్యూల్ (ఇతర మాడ్యూళ్ళకు ముందు చేర్చాల్సిన అవసరం ఉంది).
#[macro_use]
mod macros;

// తక్కువ-స్థాయి కేటాయింపు వ్యూహాల కోసం కుప్పలు అందించబడ్డాయి

pub mod alloc;

// పై కుప్పలను ఉపయోగించి ఆదిమ రకాలు

// పరీక్ష cfg లో నిర్మించేటప్పుడు లాంగ్-ఐటమ్‌లను నకిలీ చేయకుండా ఉండటానికి `boxed.rs` నుండి మోడ్‌ను షరతులతో నిర్వచించాల్సిన అవసరం ఉంది;కానీ `use boxed::Box;` డిక్లరేషన్లను కలిగి ఉండటానికి కోడ్‌ను అనుమతించాలి.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}