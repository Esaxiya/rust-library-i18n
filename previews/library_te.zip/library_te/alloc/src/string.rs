//! UTF-8-ఎన్కోడ్, పెరిగే స్ట్రింగ్.
//!
//! ఈ మాడ్యూల్ [`String`] రకం, తీగలుగా మార్చడానికి [`ToString`] trait మరియు [`స్ట్రింగ్`] లతో పనిచేయడం వల్ల సంభవించే అనేక దోష రకాలను కలిగి ఉంటుంది.
//!
//!
//! # Examples
//!
//! స్ట్రింగ్ అక్షరాలా నుండి కొత్త [`String`] ను సృష్టించడానికి బహుళ మార్గాలు ఉన్నాయి:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! మీరు ఇప్పటికే ఉన్న వాటి నుండి క్రొత్త [`String`] ను సృష్టించవచ్చు
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! మీకు చెల్లుబాటు అయ్యే UTF-8 బైట్ల vector ఉంటే, మీరు దాని నుండి [`String`] ను తయారు చేయవచ్చు.మీరు రివర్స్ కూడా చేయవచ్చు.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // ఈ బైట్లు చెల్లుబాటు అయ్యేవని మాకు తెలుసు, కాబట్టి మేము `unwrap()` ని ఉపయోగిస్తాము.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// UTF-8-ఎన్కోడ్, పెరిగే స్ట్రింగ్.
///
/// `String` రకం అనేది స్ట్రింగ్ యొక్క విషయాలపై యాజమాన్యాన్ని కలిగి ఉన్న అత్యంత సాధారణ స్ట్రింగ్ రకం.ఇది దాని అరువు తీసుకున్న కౌంటర్, ఆదిమ [`str`] తో సన్నిహిత సంబంధాన్ని కలిగి ఉంది.
///
/// # Examples
///
/// మీరు [`String::from`] తో [a literal string][`str`] నుండి `String` ను సృష్టించవచ్చు:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// మీరు [`push`] పద్ధతితో `String` కు [`char`] ను జోడించవచ్చు మరియు [`push_str`] పద్ధతిలో [`&str`] ను జోడించవచ్చు:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// మీకు UTF-8 బైట్ల vector ఉంటే, మీరు దాని నుండి [`from_utf8`] పద్ధతిలో [`from_utf8`] పద్ధతిని సృష్టించవచ్చు:
///
/// ```
/// // కొన్ని బైట్లు, vector లో
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // ఈ బైట్లు చెల్లుబాటు అయ్యేవని మాకు తెలుసు, కాబట్టి మేము `unwrap()` ని ఉపయోగిస్తాము.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `స్ట్రింగ్స్ ఎల్లప్పుడూ చెల్లుబాటు అయ్యే UTF-8.దీనికి కొన్ని చిక్కులు ఉన్నాయి, వాటిలో మొదటిది మీకు యుటిఎఫ్-8 కాని స్ట్రింగ్ అవసరమైతే, [`OsString`] ను పరిగణించండి.ఇది సారూప్యంగా ఉంటుంది, కానీ UTF-8 అడ్డంకి లేకుండా.రెండవ చిక్కు ఏమిటంటే, మీరు `String` లోకి ఇండెక్స్ చేయలేరు:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// ఇండెక్సింగ్ అనేది స్థిరమైన-సమయ ఆపరేషన్ అని ఉద్దేశించబడింది, కానీ UTF-8 ఎన్కోడింగ్ దీన్ని చేయడానికి మాకు అనుమతించదు.ఇంకా, ఇండెక్స్ ఏ విధమైన వస్తువును తిరిగి ఇవ్వాలో స్పష్టంగా లేదు: బైట్, కోడ్‌పాయింట్ లేదా గ్రాఫిమ్ క్లస్టర్.
/// [`bytes`] మరియు [`chars`] పద్ధతులు వరుసగా మొదటి రెండింటిలో ఇటరేటర్లను తిరిగి ఇస్తాయి.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `స్ట్రింగ్ అమలు [` డెరెఫ్`]`<Target=str>`, మరియు [` str`] యొక్క అన్ని పద్ధతులను వారసత్వంగా పొందండి.అదనంగా, మీరు ఒక ఆంపర్సండ్ (`&`) ను ఉపయోగించడం ద్వారా [`&str`] తీసుకునే ఫంక్షన్‌కు `String` ను పాస్ చేయవచ్చని దీని అర్థం:
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// ఇది `String` నుండి [`&str`] ను సృష్టిస్తుంది మరియు దానిని దాటిపోతుంది. ఈ మార్పిడి చాలా చవకైనది, మరియు సాధారణంగా, ఫంక్షన్లు కొన్ని నిర్దిష్ట కారణాల వల్ల `String` అవసరం తప్ప [`&str`] లను వాదనలుగా అంగీకరిస్తాయి.
///
/// కొన్ని సందర్భాల్లో, [`Deref`] బలవంతం అని పిలువబడే ఈ మార్పిడిని చేయడానికి Rust కి తగినంత సమాచారం లేదు.కింది ఉదాహరణలో, స్ట్రింగ్ స్లైస్ [`&'a str`][`&str`] trait `TraitExample` ను అమలు చేస్తుంది మరియు `example_func` ఫంక్షన్ trait ను అమలు చేసే ఏదైనా తీసుకుంటుంది.
/// ఈ సందర్భంలో Rust రెండు అవ్యక్త మార్పిడులు చేయవలసి ఉంటుంది, ఇది Rust కి మార్గాలు లేవు.
/// ఆ కారణంగా, కింది ఉదాహరణ కంపైల్ చేయదు.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// బదులుగా పనిచేసే రెండు ఎంపికలు ఉన్నాయి.మొదటిది `example_func(&example_string);` పంక్తిని `example_func(example_string.as_str());` కు మార్చడం, స్ట్రింగ్ కలిగి ఉన్న స్ట్రింగ్ స్లైస్‌ను స్పష్టంగా సేకరించేందుకు [`as_str()`] పద్ధతిని ఉపయోగించి.
/// రెండవ మార్గం `example_func(&example_string);` ను `example_func(&*example_string);` కి మారుస్తుంది.
/// ఈ సందర్భంలో మేము `String` ను [`str`][`&str`] కు డీఫరెన్సింగ్ చేస్తున్నాము, ఆపై [`str`][`&str`] ను [`&str`] కు తిరిగి సూచిస్తాము.
/// రెండవ మార్గం మరింత ఇడియొమాటిక్, అయినప్పటికీ రెండూ అవ్యక్త మార్పిడిపై ఆధారపడటం కంటే స్పష్టంగా మార్పిడిని చేయడానికి పనిచేస్తాయి.
///
/// # Representation
///
/// `String` మూడు భాగాలతో రూపొందించబడింది: కొన్ని బైట్‌లకు పాయింటర్, పొడవు మరియు సామర్థ్యం.పాయింటర్ దాని డేటాను నిల్వ చేయడానికి ఉపయోగించే అంతర్గత బఫర్ `String` ను సూచిస్తుంది.పొడవు ప్రస్తుతం బఫర్‌లో నిల్వ చేయబడిన బైట్ల సంఖ్య, మరియు సామర్థ్యం బైట్లలో బఫర్ యొక్క పరిమాణం.
///
/// అందుకని, పొడవు ఎల్లప్పుడూ సామర్థ్యం కంటే తక్కువగా లేదా సమానంగా ఉంటుంది.
///
/// ఈ బఫర్ ఎల్లప్పుడూ కుప్ప మీద నిల్వ చేయబడుతుంది.
///
/// మీరు వీటిని [`as_ptr`], [`len`] మరియు [`capacity`] పద్ధతులతో చూడవచ్చు:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME vec_into_raw_parts స్థిరీకరించబడినప్పుడు దీన్ని నవీకరించండి.
/// // స్ట్రింగ్ యొక్క డేటాను స్వయంచాలకంగా పడకుండా నిరోధించండి
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // కథలో పంతొమ్మిది బైట్లు ఉన్నాయి
/// assert_eq!(19, len);
///
/// // మేము పిటిఆర్, లెన్ మరియు సామర్థ్యం నుండి స్ట్రింగ్‌ను తిరిగి నిర్మించగలము.
/// // ఇదంతా సురక్షితం కాదు ఎందుకంటే భాగాలు చెల్లుబాటు అయ్యేలా చూసుకోవలసిన బాధ్యత మాపై ఉంది:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// ఒక `String` తగినంత సామర్థ్యాన్ని కలిగి ఉంటే, దానికి మూలకాలను జోడించడం తిరిగి కేటాయించబడదు.ఉదాహరణకు, ఈ ప్రోగ్రామ్‌ను పరిశీలించండి:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// ఇది కింది వాటిని అవుట్పుట్ చేస్తుంది:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// మొదట, మనకు జ్ఞాపకశక్తి కేటాయించబడలేదు, కాని మేము స్ట్రింగ్‌కు అనుబంధంగా, అది దాని సామర్థ్యాన్ని తగిన విధంగా పెంచుతుంది.ప్రారంభంలో సరైన సామర్థ్యాన్ని కేటాయించడానికి మేము బదులుగా [`with_capacity`] పద్ధతిని ఉపయోగిస్తే:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// మేము వేరే అవుట్‌పుట్‌తో ముగుస్తాము:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// ఇక్కడ, లూప్ లోపల ఎక్కువ మెమరీని కేటాయించాల్సిన అవసరం లేదు.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// UTF-8 బైట్ vector నుండి `String` ను మార్చేటప్పుడు సాధ్యమయ్యే లోపం విలువ.
///
/// ఈ రకం [`String`] లోని [`from_utf8`] పద్ధతికి లోపం రకం.
/// పునర్వ్యవస్థీకరణలను జాగ్రత్తగా నివారించడానికి ఇది రూపొందించబడింది: [`into_bytes`] పద్ధతి మార్పిడి ప్రయత్నంలో ఉపయోగించిన బైట్ vector ను తిరిగి ఇస్తుంది.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// [`std::str`] అందించిన [`Utf8Error`] రకం [`u8`] స్లైస్‌ని [`&str`] గా మార్చేటప్పుడు సంభవించే లోపాన్ని సూచిస్తుంది.
/// ఈ కోణంలో, ఇది `FromUtf8Error` కు అనలాగ్, మరియు మీరు `FromUtf8Error` నుండి [`utf8_error`] పద్ధతి ద్వారా ఒకదాన్ని పొందవచ్చు.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// ప్రాథమిక వినియోగం:
///
/// ```
/// // vector లో కొన్ని చెల్లని బైట్లు
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// UTF-16 బైట్ స్లైస్ నుండి `String` ను మార్చేటప్పుడు లోపం విలువ.
///
/// ఈ రకం [`String`] లోని [`from_utf16`] పద్ధతికి లోపం రకం.
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// ప్రాథమిక వినియోగం:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// క్రొత్త ఖాళీ `String` ను సృష్టిస్తుంది.
    ///
    /// `String` ఖాళీగా ఉన్నందున, ఇది ప్రారంభ బఫర్‌ను కేటాయించదు.ఈ ప్రారంభ ఆపరేషన్ చాలా చవకైనదని అర్థం అయితే, మీరు డేటాను జోడించినప్పుడు ఇది అధిక కేటాయింపుకు కారణం కావచ్చు.
    ///
    /// `String` ఎంత డేటాను కలిగి ఉంటుందో మీకు ఒక ఆలోచన ఉంటే, అధిక రీ-కేటాయింపును నిరోధించడానికి [`with_capacity`] పద్ధతిని పరిశీలించండి.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// నిర్దిష్ట సామర్థ్యంతో కొత్త ఖాళీ `String` ను సృష్టిస్తుంది.
    ///
    /// `స్ట్రింగ్'లకు వారి డేటాను ఉంచడానికి అంతర్గత బఫర్ ఉంది.
    /// సామర్థ్యం ఆ బఫర్ యొక్క పొడవు, మరియు [`capacity`] పద్ధతిలో ప్రశ్నించవచ్చు.
    /// ఈ పద్ధతి ఖాళీ `String` ను సృష్టిస్తుంది, కానీ `capacity` బైట్‌లను కలిగి ఉండే ప్రారంభ బఫర్‌తో ఒకటి.
    /// మీరు `String` కు కొంత డేటాను జతచేస్తున్నప్పుడు ఇది ఉపయోగపడుతుంది, ఇది చేయవలసిన పునర్వ్యవస్థీకరణల సంఖ్యను తగ్గిస్తుంది.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// ఇచ్చిన సామర్థ్యం `0` అయితే, కేటాయింపులు జరగవు మరియు ఈ పద్ధతి [`new`] పద్ధతికి సమానంగా ఉంటుంది.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // స్ట్రింగ్‌కు ఎక్కువ సామర్థ్యం ఉన్నప్పటికీ అక్షరాలు లేవు
    /// assert_eq!(s.len(), 0);
    ///
    /// // ఇవన్నీ తిరిగి కేటాయించకుండానే జరుగుతాయి ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... కానీ ఇది స్ట్రింగ్‌ను తిరిగి కేటాయించగలదు
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): cfg(test) తో ఈ పద్ధతి నిర్వచనానికి అవసరమైన స్వాభావిక `[T]::to_vec` పద్ధతి అందుబాటులో లేదు.
    // పరీక్షా ప్రయోజనాల కోసం మాకు ఈ పద్ధతి అవసరం లేదు కాబట్టి, నేను మరింత సమాచారం కోసం slice.rs లోని slice::hack మాడ్యూల్‌ను చూస్తాను
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// vector బైట్‌లను `String` గా మారుస్తుంది.
    ///
    /// ఒక స్ట్రింగ్ ([`String`]) బైట్లు ([`u8`]) తో తయారు చేయబడింది, మరియు vector బైట్లు ([`Vec<u8>`]) బైట్‌లతో తయారు చేయబడింది, కాబట్టి ఈ ఫంక్షన్ రెండింటి మధ్య మారుతుంది.
    /// అన్ని బైట్ ముక్కలు చెల్లుబాటు అయ్యే `స్ట్రింగ్` కాదు, అయితే: `String` కి చెల్లుబాటు అయ్యే UTF-8 అవసరం.
    /// `from_utf8()` బైట్లు చెల్లుబాటు అయ్యే UTF-8 అని నిర్ధారించడానికి తనిఖీ చేస్తుంది, ఆపై మార్పిడి చేస్తుంది.
    ///
    /// బైట్ స్లైస్ చెల్లుబాటు అయ్యే UTF-8 అని మీకు ఖచ్చితంగా తెలిస్తే, మరియు చెల్లుబాటు చెక్ యొక్క ఓవర్ హెడ్ ను మీరు పొందకూడదనుకుంటే, ఈ ఫంక్షన్ యొక్క అసురక్షిత వెర్షన్, [`from_utf8_unchecked`] ఉంది, ఇది అదే ప్రవర్తనను కలిగి ఉంది కాని చెక్కును దాటవేస్తుంది.
    ///
    ///
    /// ఈ పద్ధతి సమర్థత కొరకు, vector ను కాపీ చేయకుండా జాగ్రత్త తీసుకుంటుంది.
    ///
    /// మీకు `String` కు బదులుగా [`&str`] అవసరమైతే, [`str::from_utf8`] ను పరిగణించండి.
    ///
    /// ఈ పద్ధతి యొక్క విలోమం [`into_bytes`].
    ///
    /// # Errors
    ///
    /// స్లైస్ UTF-8 కాకపోతే [`Err`] ను అందిస్తుంది, అందించిన బైట్లు ఎందుకు UTF-8 కావు అనే వివరణతో.మీరు తరలించిన vector కూడా చేర్చబడింది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// // కొన్ని బైట్లు, vector లో
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // ఈ బైట్లు చెల్లుబాటు అయ్యేవని మాకు తెలుసు, కాబట్టి మేము `unwrap()` ని ఉపయోగిస్తాము.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// తప్పు బైట్లు:
    ///
    /// ```
    /// // vector లో కొన్ని చెల్లని బైట్లు
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// ఈ లోపంతో మీరు ఏమి చేయవచ్చనే దానిపై మరిన్ని వివరాల కోసం [`FromUtf8Error`] కోసం డాక్స్ చూడండి.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// బైట్‌ల స్లైస్‌ని చెల్లని అక్షరాలతో సహా స్ట్రింగ్‌గా మారుస్తుంది.
    ///
    /// తీగలను ([`u8`]) బైట్‌లతో తయారు చేస్తారు, మరియు ([`&[u8]`][byteslice]) బైట్ల స్లైస్ బైట్‌లతో తయారు చేయబడింది, కాబట్టి ఈ ఫంక్షన్ రెండింటి మధ్య మారుతుంది.అన్ని బైట్ ముక్కలు చెల్లుబాటు అయ్యే తీగలే కాదు, అయితే: తీగలు చెల్లుబాటు అయ్యే UTF-8 గా ఉండాలి.
    /// ఈ మార్పిడి సమయంలో, `from_utf8_lossy()` ఏదైనా చెల్లని UTF-8 సన్నివేశాలను [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] తో భర్తీ చేస్తుంది, ఇది ఇలా కనిపిస్తుంది:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// బైట్ స్లైస్ చెల్లుబాటు అయ్యే UTF-8 అని మీకు ఖచ్చితంగా తెలిస్తే, మరియు మీరు మార్పిడి యొక్క ఓవర్ హెడ్ భరించకూడదనుకుంటే, ఈ ఫంక్షన్ యొక్క అసురక్షిత వెర్షన్, [`from_utf8_unchecked`] ఉంది, ఇది అదే ప్రవర్తనను కలిగి ఉంది కాని తనిఖీలను దాటవేస్తుంది.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// ఈ ఫంక్షన్ [`Cow<'a, str>`] ను అందిస్తుంది.మా బైట్ స్లైస్ చెల్లని UTF-8 అయితే, అప్పుడు మేము ప్రత్యామ్నాయ అక్షరాలను చొప్పించాలి, ఇది స్ట్రింగ్ యొక్క పరిమాణాన్ని మారుస్తుంది మరియు అందువల్ల, `String` అవసరం.
    /// ఇది ఇప్పటికే చెల్లుబాటు అయ్యే UTF-8 అయితే, మాకు కొత్త కేటాయింపు అవసరం లేదు.
    /// ఈ రిటర్న్ రకం రెండు కేసులను నిర్వహించడానికి మాకు అనుమతిస్తుంది.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// // కొన్ని బైట్లు, vector లో
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// తప్పు బైట్లు:
    ///
    /// ```
    /// // కొన్ని చెల్లని బైట్లు
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// UTF-16-ఎన్కోడ్ చేసిన vector `v` ను `String` లోకి డీకోడ్ చేయండి, `v` ఏదైనా చెల్లని డేటాను కలిగి ఉంటే [`Err`] ను తిరిగి ఇస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // ఇది సేకరించడం ద్వారా చేయలేదు: : <Result<_, _>> () పనితీరు కారణాల వల్ల.
        // FIXME: #48994 మూసివేయబడినప్పుడు ఫంక్షన్‌ను మళ్ళీ సరళీకృతం చేయవచ్చు.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// UTF-16-ఎన్కోడ్ చేసిన స్లైస్ `v` ను `String` గా డీకోడ్ చేయండి, చెల్లని డేటాను [the replacement character (`U+FFFD`)][U+FFFD] తో భర్తీ చేస్తుంది.
    ///
    /// [`Cow<'a, str>`] ను తిరిగి ఇచ్చే [`from_utf8_lossy`] కాకుండా, `from_utf16_lossy` `String` ను తిరిగి ఇస్తుంది, ఎందుకంటే UTF-16 నుండి UTF-8 మార్పిడికి మెమరీ కేటాయింపు అవసరం.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// `String` ను దాని ముడి భాగాలుగా కుళ్ళిపోతుంది.
    ///
    /// ముడి పాయింటర్‌ను అంతర్లీన డేటాకు, స్ట్రింగ్ యొక్క పొడవు (బైట్‌లలో) మరియు డేటా యొక్క కేటాయించిన సామర్థ్యాన్ని (బైట్‌లలో) అందిస్తుంది.
    /// ఇవి [`from_raw_parts`] కు వాదనలు అదే క్రమంలో ఉంటాయి.
    ///
    /// ఈ ఫంక్షన్‌కు కాల్ చేసిన తరువాత, గతంలో `String` చేత నిర్వహించబడే మెమరీకి కాలర్ బాధ్యత వహిస్తాడు.
    /// ముడి పాయింటర్, పొడవు మరియు సామర్థ్యాన్ని [`from_raw_parts`] ఫంక్షన్‌తో తిరిగి `String` గా మార్చడం దీనికి ఏకైక మార్గం, ఇది డిస్ట్రక్టర్ శుభ్రపరిచే పనిని అనుమతిస్తుంది.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// పొడవు, సామర్థ్యం మరియు పాయింటర్ నుండి క్రొత్త `String` ను సృష్టిస్తుంది.
    ///
    /// # Safety
    ///
    /// తనిఖీ చేయని మార్పుల సంఖ్య కారణంగా ఇది చాలా సురక్షితం కాదు:
    ///
    /// * `buf` వద్ద ఉన్న మెమరీని ఇంతకుముందు ప్రామాణిక లైబ్రరీ ఉపయోగించే అదే కేటాయింపుదారుడు కేటాయించాల్సిన అవసరం ఉంది, అవసరమైన అమరికతో సరిగ్గా 1.
    /// * `length` `capacity` కన్నా తక్కువ లేదా సమానంగా ఉండాలి.
    /// * `capacity` సరైన విలువ కావాలి.
    /// * `buf` వద్ద మొదటి `length` బైట్లు చెల్లుబాటు అయ్యే UTF-8 ఉండాలి.
    ///
    /// వీటిని ఉల్లంఘించడం వల్ల కేటాయింపుదారు యొక్క అంతర్గత డేటా నిర్మాణాలను భ్రష్టుపట్టడం వంటి సమస్యలు వస్తాయి.
    ///
    /// `buf` యొక్క యాజమాన్యం `String` కి సమర్థవంతంగా బదిలీ చేయబడుతుంది, తరువాత అది ఇష్టానుసారం పాయింటర్ సూచించిన మెమరీ విషయాలను డీలోకేట్ చేయవచ్చు, తిరిగి కేటాయించవచ్చు లేదా మార్చవచ్చు.
    /// ఈ ఫంక్షన్‌ను పిలిచిన తర్వాత మరేదీ పాయింటర్‌ను ఉపయోగించదని నిర్ధారించుకోండి.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME vec_into_raw_parts స్థిరీకరించబడినప్పుడు దీన్ని నవీకరించండి.
    ///     // స్ట్రింగ్ యొక్క డేటాను స్వయంచాలకంగా పడకుండా నిరోధించండి
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// స్ట్రింగ్ చెల్లుబాటు అయ్యే UTF-8 కలిగి ఉందో లేదో తనిఖీ చేయకుండా vector బైట్లను `String` గా మారుస్తుంది.
    ///
    /// మరిన్ని వివరాల కోసం [`from_utf8`] అనే సురక్షిత సంస్కరణ చూడండి.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// ఈ ఫంక్షన్ సురక్షితం కాదు ఎందుకంటే దీనికి పంపిన బైట్లు చెల్లుబాటు అయ్యే UTF-8 అని తనిఖీ చేయవు.
    /// ఈ పరిమితి ఉల్లంఘించబడితే, ఇది `String` యొక్క future వినియోగదారులతో మెమరీ అసురక్షిత సమస్యలను కలిగిస్తుంది, ఎందుకంటే మిగిలిన ప్రామాణిక లైబ్రరీ `స్ట్రింగ్`లు చెల్లుబాటు అయ్యే UTF-8 అని umes హిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// // కొన్ని బైట్లు, vector లో
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// `String` ను బైట్ vector గా మారుస్తుంది.
    ///
    /// ఇది `String` ను వినియోగిస్తుంది, కాబట్టి మేము దాని విషయాలను కాపీ చేయవలసిన అవసరం లేదు.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// మొత్తం `String` కలిగి ఉన్న స్ట్రింగ్ స్లైస్‌ను సంగ్రహిస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// `String` ను మ్యూటబుల్ స్ట్రింగ్ స్లైస్‌గా మారుస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// ఈ `String` చివరలో ఇచ్చిన స్ట్రింగ్ స్లైస్‌ను జోడిస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// ఈ `స్ట్రింగ్` సామర్థ్యాన్ని బైట్‌లలో అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// ఈ `స్ట్రింగ్` సామర్థ్యం కనీసం `additional` బైట్లు దాని పొడవు కంటే పెద్దదని నిర్ధారిస్తుంది.
    ///
    /// తరచుగా తిరిగి కేటాయించడాన్ని నివారించడానికి, సామర్థ్యం ఎంచుకుంటే, `additional` బైట్ల కంటే ఎక్కువ పెంచవచ్చు.
    ///
    ///
    /// మీకు ఈ "at least" ప్రవర్తన వద్దు, [`reserve_exact`] పద్ధతిని చూడండి.
    ///
    /// # Panics
    ///
    /// కొత్త సామర్థ్యం [`usize`] ని పొంగిపోతే Panics.
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// ఇది వాస్తవానికి సామర్థ్యాన్ని పెంచకపోవచ్చు:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ఇప్పుడు 2 పొడవు మరియు 10 సామర్థ్యాన్ని కలిగి ఉంది
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // మనకు ఇప్పటికే అదనపు 8 సామర్థ్యం ఉన్నందున, దీనిని పిలుస్తున్నారు ...
    /// s.reserve(8);
    ///
    /// // ... వాస్తవానికి పెరగదు.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// ఈ `స్ట్రింగ్` సామర్థ్యం దాని పొడవు కంటే `additional` బైట్లు పెద్దదని నిర్ధారిస్తుంది.
    ///
    /// కేటాయింపుదారుడి కంటే మీకు బాగా తెలియకపోతే [`reserve`] పద్ధతిని ఉపయోగించడాన్ని పరిగణించండి.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// కొత్త సామర్థ్యం `usize` ని పొంగిపోతే Panics.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// ఇది వాస్తవానికి సామర్థ్యాన్ని పెంచకపోవచ్చు:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ఇప్పుడు 2 పొడవు మరియు 10 సామర్థ్యాన్ని కలిగి ఉంది
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // మనకు ఇప్పటికే అదనపు 8 సామర్థ్యం ఉన్నందున, దీనిని పిలుస్తున్నారు ...
    /// s.reserve_exact(8);
    ///
    /// // ... వాస్తవానికి పెరగదు.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// ఇచ్చిన `String` లో చేర్చడానికి కనీసం `additional` మరిన్ని మూలకాల కోసం సామర్థ్యాన్ని రిజర్వ్ చేయడానికి ప్రయత్నిస్తుంది.
    /// తరచుగా తిరిగి కేటాయించకుండా ఉండటానికి సేకరణ ఎక్కువ స్థలాన్ని కేటాయించవచ్చు.
    /// `reserve` కి కాల్ చేసిన తరువాత, సామర్థ్యం `self.len() + additional` కన్నా ఎక్కువ లేదా సమానంగా ఉంటుంది.
    /// సామర్థ్యం ఇప్పటికే సరిపోతుంటే ఏమీ చేయదు.
    ///
    /// # Errors
    ///
    /// సామర్థ్యం పొంగిపొర్లుతుంటే, లేదా కేటాయింపుదారుడు వైఫల్యాన్ని నివేదించినట్లయితే, లోపం తిరిగి వస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // జ్ఞాపకశక్తిని ముందుగా రిజర్వ్ చేయండి, మనం చేయలేకపోతే నిష్క్రమిస్తుంది
    ///     output.try_reserve(data.len())?;
    ///
    ///     // మా సంక్లిష్ట పని మధ్యలో ఇది OOM కాదని ఇప్పుడు మనకు తెలుసు
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// ఇచ్చిన `String` లో ఖచ్చితంగా `additional` మరిన్ని మూలకాలను చేర్చడానికి కనీస సామర్థ్యాన్ని రిజర్వ్ చేయడానికి ప్రయత్నిస్తుంది.
    ///
    /// `reserve_exact` కి కాల్ చేసిన తరువాత, సామర్థ్యం `self.len() + additional` కన్నా ఎక్కువ లేదా సమానంగా ఉంటుంది.
    /// సామర్థ్యం ఇప్పటికే సరిపోతుంటే ఏమీ చేయదు.
    ///
    /// కేటాయింపుదారుడు కోరిన దానికంటే ఎక్కువ స్థలాన్ని ఇవ్వవచ్చని గమనించండి.
    /// అందువల్ల, సామర్థ్యం ఖచ్చితంగా తక్కువగా ఉండటానికి ఆధారపడదు.
    /// future చొప్పనలు if హించినట్లయితే `reserve` కి ప్రాధాన్యత ఇవ్వండి.
    ///
    /// # Errors
    ///
    /// సామర్థ్యం పొంగిపొర్లుతుంటే, లేదా కేటాయింపుదారుడు వైఫల్యాన్ని నివేదించినట్లయితే, లోపం తిరిగి వస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // జ్ఞాపకశక్తిని ముందుగా రిజర్వ్ చేయండి, మనం చేయలేకపోతే నిష్క్రమిస్తుంది
    ///     output.try_reserve(data.len())?;
    ///
    ///     // మా సంక్లిష్ట పని మధ్యలో ఇది OOM కాదని ఇప్పుడు మనకు తెలుసు
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// ఈ `String` యొక్క పొడవును దాని పొడవుతో సరిపోయే సామర్థ్యాన్ని తగ్గిస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// ఈ `String` సామర్థ్యాన్ని తక్కువ బౌండ్‌తో తగ్గిస్తుంది.
    ///
    /// సామర్థ్యం పొడవు మరియు సరఫరా విలువ రెండింటికీ కనీసం పెద్దదిగా ఉంటుంది.
    ///
    ///
    /// ప్రస్తుత సామర్థ్యం తక్కువ పరిమితి కంటే తక్కువగా ఉంటే, ఇది నో-ఆప్.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// ఇచ్చిన [`char`] ను ఈ `String` చివరికి జతచేస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// ఈ `స్ట్రింగ్` విషయాల యొక్క బైట్ స్లైస్‌ని అందిస్తుంది.
    ///
    /// ఈ పద్ధతి యొక్క విలోమం [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// పేర్కొన్న పొడవుకు ఈ `String` ని తగ్గిస్తుంది.
    ///
    /// `new_len` స్ట్రింగ్ యొక్క ప్రస్తుత పొడవు కంటే ఎక్కువగా ఉంటే, ఇది ఎటువంటి ప్రభావాన్ని చూపదు.
    ///
    ///
    /// ఈ పద్ధతి స్ట్రింగ్ యొక్క కేటాయించిన సామర్థ్యంపై ప్రభావం చూపదని గమనించండి
    ///
    /// # Panics
    ///
    /// `new_len` [`char`] సరిహద్దులో ఉండకపోతే Panics.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// స్ట్రింగ్ బఫర్ నుండి చివరి అక్షరాన్ని తీసివేసి తిరిగి ఇస్తుంది.
    ///
    /// ఈ `String` ఖాళీగా ఉంటే [`None`] ని అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// ఈ `String` నుండి [`char`] ను బైట్ పొజిషన్ వద్ద తీసివేసి తిరిగి ఇస్తుంది.
    ///
    /// ఇది *O*(*n*) ఆపరేషన్, ఎందుకంటే దీనికి బఫర్‌లోని ప్రతి మూలకాన్ని కాపీ చేయడం అవసరం.
    ///
    /// # Panics
    ///
    /// `idx` `స్ట్రింగ్` యొక్క పొడవు కంటే పెద్దది లేదా సమానంగా ఉంటే లేదా అది [`char`] సరిహద్దులో ఉండకపోతే Panics.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// `String` లో నమూనా `pat` యొక్క అన్ని సరిపోలికలను తొలగించండి.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// సరిపోలికలు గుర్తించబడతాయి మరియు పునరావృతమవుతాయి, కాబట్టి నమూనాలు అతివ్యాప్తి చెందుతున్న సందర్భాల్లో, మొదటి నమూనా మాత్రమే తొలగించబడుతుంది:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // భద్రత: ప్రారంభ మరియు ముగింపు utf8 బైట్ సరిహద్దుల్లో ఉంటుంది
        // శోధన డాక్స్
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// ప్రిడికేట్ పేర్కొన్న అక్షరాలను మాత్రమే కలిగి ఉంటుంది.
    ///
    /// మరో మాటలో చెప్పాలంటే, `c` అన్ని అక్షరాలను తొలగించండి, అంటే `f(c)` `false` ను తిరిగి ఇస్తుంది.
    /// ఈ పద్ధతి స్థానంలో పనిచేస్తుంది, ప్రతి అక్షరాన్ని అసలు క్రమంలో సరిగ్గా ఒకసారి సందర్శిస్తుంది మరియు నిలుపుకున్న అక్షరాల క్రమాన్ని సంరక్షిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// ఇండెక్స్ వంటి బాహ్య స్థితిని ట్రాక్ చేయడానికి ఖచ్చితమైన క్రమం ఉపయోగపడుతుంది.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // తదుపరి చార్‌కు ఐడిక్స్ సూచించండి
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// ఈ `String` లోకి ఒక అక్షరాన్ని బైట్ స్థానంలో చొప్పిస్తుంది.
    ///
    /// ఇది బఫర్‌లోని ప్రతి మూలకాన్ని కాపీ చేయాల్సిన అవసరం ఉన్నందున ఇది *O*(*n*) ఆపరేషన్.
    ///
    /// # Panics
    ///
    /// `idx` `స్ట్రింగ్` పొడవు కంటే పెద్దదిగా ఉంటే లేదా అది [`char`] సరిహద్దులో ఉండకపోతే Panics.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// ఈ `String` లోకి బైట్ స్థానంలో స్ట్రింగ్ స్లైస్‌ని చొప్పిస్తుంది.
    ///
    /// ఇది బఫర్‌లోని ప్రతి మూలకాన్ని కాపీ చేయాల్సిన అవసరం ఉన్నందున ఇది *O*(*n*) ఆపరేషన్.
    ///
    /// # Panics
    ///
    /// `idx` `స్ట్రింగ్` పొడవు కంటే పెద్దదిగా ఉంటే లేదా అది [`char`] సరిహద్దులో ఉండకపోతే Panics.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// ఈ `String` యొక్క విషయాలకు మార్చగల సూచనను అందిస్తుంది.
    ///
    /// # Safety
    ///
    /// ఈ ఫంక్షన్ సురక్షితం కాదు ఎందుకంటే దీనికి పంపిన బైట్లు చెల్లుబాటు అయ్యే UTF-8 అని తనిఖీ చేయవు.
    /// ఈ పరిమితి ఉల్లంఘించబడితే, ఇది `String` యొక్క future వినియోగదారులతో మెమరీ అసురక్షిత సమస్యలను కలిగిస్తుంది, ఎందుకంటే మిగిలిన ప్రామాణిక లైబ్రరీ `స్ట్రింగ్`లు చెల్లుబాటు అయ్యే UTF-8 అని umes హిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// ఈ `String` యొక్క పొడవును బైట్‌లలో అందిస్తుంది, [`చార్`] లేదా గ్రాఫిమ్‌లు కాదు.
    /// మరో మాటలో చెప్పాలంటే, స్ట్రింగ్ యొక్క పొడవును మానవుడు భావించేది కాకపోవచ్చు.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// ఈ `String` సున్నా పొడవును కలిగి ఉంటే `true` మరియు లేకపోతే `false` ను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ఇచ్చిన బైట్ సూచిక వద్ద స్ట్రింగ్‌ను రెండుగా విభజిస్తుంది.
    ///
    /// కొత్తగా కేటాయించిన `String` ను అందిస్తుంది.
    /// `self` `[0, at)` బైట్లు ఉన్నాయి, మరియు తిరిగి వచ్చిన `String` లో బైట్లు `[at, len)` ఉంటుంది.
    /// `at` UTF-8 కోడ్ పాయింట్ యొక్క సరిహద్దులో ఉండాలి.
    ///
    /// `self` సామర్థ్యం మారదని గమనించండి.
    ///
    /// # Panics
    ///
    /// `at` `UTF-8` కోడ్ పాయింట్ సరిహద్దులో లేకపోతే Panics, లేదా అది స్ట్రింగ్ యొక్క చివరి కోడ్ పాయింట్‌కు మించి ఉంటే.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// ఈ `String` ను కత్తిరించుకుంటుంది, అన్ని విషయాలను తొలగిస్తుంది.
    ///
    /// దీని అర్థం `String` సున్నా పొడవును కలిగి ఉంటుంది, ఇది దాని సామర్థ్యాన్ని తాకదు.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// `String` లో పేర్కొన్న పరిధిని తీసివేసి, తీసివేసిన `chars` ను ఇచ్చే డ్రెయినింగ్ ఇరేటర్‌ను సృష్టిస్తుంది.
    ///
    ///
    /// Note: చివరి వరకు ఇరేటర్ వినియోగించకపోయినా మూలకం పరిధి తొలగించబడుతుంది.
    ///
    /// # Panics
    ///
    /// ప్రారంభ స్థానం లేదా ముగింపు స్థానం [`char`] సరిహద్దులో ఉండకపోతే లేదా అవి సరిహద్దులు లేనట్లయితే Panics.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // స్ట్రింగ్ నుండి until వరకు పరిధిని తొలగించండి
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // పూర్తి పరిధి స్ట్రింగ్‌ను క్లియర్ చేస్తుంది
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // మెమరీ భద్రత
        //
        // Drain యొక్క స్ట్రింగ్ వెర్షన్‌లో vector వెర్షన్ యొక్క మెమరీ భద్రతా సమస్యలు లేవు.
        // డేటా కేవలం సాదా బైట్లు.
        // డ్రాప్‌లో పరిధి తొలగింపు జరుగుతుంది కాబట్టి, Drain ఇరేటర్ లీక్ అయినట్లయితే, తొలగింపు జరగదు.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // ఒకేసారి రెండు రుణాలు తీసుకోండి.
        // డ్రాప్‌లో, మళ్ళా ముగిసే వరకు &mut స్ట్రింగ్ యాక్సెస్ చేయబడదు.
        let self_ptr = self as *mut _;
        // భద్రత: `slice::range` మరియు `is_char_boundary` తగిన హద్దులు తనిఖీ చేస్తాయి.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// స్ట్రింగ్‌లో పేర్కొన్న పరిధిని తీసివేసి, ఇచ్చిన స్ట్రింగ్‌తో భర్తీ చేస్తుంది.
    /// ఇచ్చిన స్ట్రింగ్ పరిధికి సమానమైన పొడవు అవసరం లేదు.
    ///
    /// # Panics
    ///
    /// ప్రారంభ స్థానం లేదా ముగింపు స్థానం [`char`] సరిహద్దులో ఉండకపోతే లేదా అవి సరిహద్దులు లేనట్లయితే Panics.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // స్ట్రింగ్ నుండి β వరకు పరిధిని మార్చండి
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // మెమరీ భద్రత
        //
        // పున lace స్థాపన_రేంజ్‌లో vector స్ప్లైస్ యొక్క మెమరీ భద్రతా సమస్యలు లేవు.
        // vector వెర్షన్ యొక్క.డేటా కేవలం సాదా బైట్లు.

        // హెచ్చరిక: ఈ వేరియబుల్‌ను ఇన్లైన్ చేయడం (#81138) అన్‌సౌండ్ అవుతుంది
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // హెచ్చరిక: ఈ వేరియబుల్‌ను ఇన్లైన్ చేయడం (#81138) అన్‌సౌండ్ అవుతుంది
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // `range` ను మళ్ళీ ఉపయోగించడం అసంబద్ధం అవుతుంది (#81138) `range` చే నివేదించబడిన హద్దులు ఒకే విధంగా ఉంటాయని మేము అనుకుంటాము, కాని కాల్స్ మధ్య విరోధి అమలు మారవచ్చు
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// ఈ `String` ను [`బాక్స్`]`<`[`str`] `>` గా మారుస్తుంది.
    ///
    /// ఇది ఏదైనా అదనపు సామర్థ్యాన్ని తగ్గిస్తుంది.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// `String` కి మార్చడానికి ప్రయత్నించిన [`u8`] బైట్ల స్లైస్‌ని అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// // vector లో కొన్ని చెల్లని బైట్లు
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// `String` కి మార్చడానికి ప్రయత్నించిన బైట్‌లను చూపుతుంది.
    ///
    /// కేటాయింపును నివారించడానికి ఈ పద్ధతి జాగ్రత్తగా నిర్మించబడింది.
    /// ఇది లోపాన్ని తినేస్తుంది, బైట్‌లను బయటకు కదిలిస్తుంది, తద్వారా బైట్‌ల కాపీని తయారు చేయవలసిన అవసరం లేదు.
    ///
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// // vector లో కొన్ని చెల్లని బైట్లు
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// మార్పిడి వైఫల్యం గురించి మరిన్ని వివరాలను పొందడానికి `Utf8Error` ను పొందండి.
    ///
    /// [`std::str`] అందించిన [`Utf8Error`] రకం [`u8`] స్లైస్‌ని [`&str`] గా మార్చేటప్పుడు సంభవించే లోపాన్ని సూచిస్తుంది.
    /// ఈ కోణంలో, ఇది `FromUtf8Error` కు అనలాగ్.
    /// దీన్ని ఉపయోగించడం గురించి మరిన్ని వివరాల కోసం దాని డాక్యుమెంటేషన్ చూడండి.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// // vector లో కొన్ని చెల్లని బైట్లు
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // మొదటి బైట్ ఇక్కడ చెల్లదు
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // మేము `స్ట్రింగ్'పై మళ్ళిస్తున్నందున, ఇటరేటర్ నుండి మొదటి స్ట్రింగ్ పొందడం ద్వారా మరియు తరువాత వచ్చే అన్ని తీగలను దానికి జోడించడం ద్వారా కనీసం ఒక కేటాయింపును కూడా నివారించవచ్చు.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // మేము CoW లపై మళ్ళిస్తున్నందున, మొదటి వస్తువును పొందడం ద్వారా మరియు తదుపరి అన్ని అంశాలకు జోడించడం ద్వారా (potentially) కనీసం ఒక కేటాయింపును నివారించవచ్చు.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// `&str` కోసం impl కు ప్రతినిధులను సూచించే సౌలభ్యం impl.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// ఖాళీ `String` ను సృష్టిస్తుంది.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// రెండు తీగలను కలిపేందుకు `+` ఆపరేటర్‌ను అమలు చేస్తుంది.
///
/// ఇది ఎడమ వైపు `String` ను వినియోగిస్తుంది మరియు దాని బఫర్‌ను తిరిగి ఉపయోగిస్తుంది (అవసరమైతే దాన్ని పెంచుతుంది).
/// క్రొత్త `String` ని కేటాయించకుండా మరియు ప్రతి ఆపరేషన్‌లోని మొత్తం విషయాలను కాపీ చేయకుండా ఉండటానికి ఇది జరుగుతుంది, ఇది *O*(*n*^ 2) నడుస్తున్న సమయానికి దారితీస్తుంది,*n*-బైట్ స్ట్రింగ్‌ను పదేపదే సంగ్రహించడం ద్వారా నిర్మించేటప్పుడు.
///
///
/// కుడి వైపున ఉన్న స్ట్రింగ్ అరువు మాత్రమే;దాని విషయాలు తిరిగి వచ్చిన `String` లోకి కాపీ చేయబడతాయి.
///
/// # Examples
///
/// రెండు `స్ట్రింగ్'లను సంగ్రహించడం మొదటిదాన్ని విలువ ద్వారా తీసుకుంటుంది మరియు రెండవదాన్ని తీసుకుంటుంది:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` తరలించబడింది మరియు ఇకపై ఇక్కడ ఉపయోగించబడదు.
/// ```
///
/// మీరు మొదటి `String` ను ఉపయోగించాలనుకుంటే, మీరు దాన్ని క్లోన్ చేయవచ్చు మరియు బదులుగా క్లోన్‌కు జోడించవచ్చు:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` ఇప్పటికీ ఇక్కడ చెల్లుతుంది.
/// ```
///
/// మొదటిదాన్ని `String` గా మార్చడం ద్వారా `&str` ముక్కలను సంగ్రహించడం చేయవచ్చు:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// `String` కు జోడించడానికి `+=` ఆపరేటర్‌ను అమలు చేస్తుంది.
///
/// ఇది [`push_str`][String::push_str] పద్ధతి వలె అదే ప్రవర్తనను కలిగి ఉంటుంది.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// [`Infallible`] కోసం ఒక రకం అలియాస్.
///
/// ఈ అలియాస్ వెనుకకు అనుకూలత కోసం ఉంది మరియు చివరికి తీసివేయబడుతుంది.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// విలువను `String` గా మార్చడానికి trait.
///
/// [`Display`] trait ను అమలు చేసే ఏ రకానికైనా ఈ trait స్వయంచాలకంగా అమలు చేయబడుతుంది.
/// అందుకని, `ToString` నేరుగా అమలు చేయకూడదు:
/// [`Display`] బదులుగా అమలు చేయాలి మరియు మీరు `ToString` అమలును ఉచితంగా పొందుతారు.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// ఇచ్చిన విలువను `String` గా మారుస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// ఈ అమలులో, `Display` అమలు లోపం ఇస్తే `to_string` పద్ధతి panics.
/// `fmt::Write for String` ఎప్పుడూ లోపం ఇవ్వదు కాబట్టి ఇది తప్పు `Display` అమలును సూచిస్తుంది.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // సాధారణ ఫంక్షన్లను ఇన్లైన్ చేయకూడదు.
    // ఏదేమైనా, ఈ పద్ధతి నుండి `#[inline]` ను తొలగించడం చాలా తక్కువ రిగ్రెషన్లకు కారణమవుతుంది.
    // దాన్ని తొలగించడానికి ప్రయత్నించే చివరి ప్రయత్నం <https://github.com/rust-lang/rust/pull/74852> చూడండి.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// `&mut str` ను `String` గా మారుస్తుంది.
    ///
    /// ఫలితం కుప్ప మీద కేటాయించబడుతుంది.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: పరీక్ష libstd లో లాగుతుంది, ఇది ఇక్కడ లోపాలను కలిగిస్తుంది
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// ఇచ్చిన బాక్స్డ్ `str` స్లైస్‌ను `String` గా మారుస్తుంది.
    /// `str` స్లైస్ యాజమాన్యంలో ఉండటం గమనార్హం.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// ఇచ్చిన `String` ను యాజమాన్యంలోని బాక్స్డ్ `str` స్లైస్‌గా మారుస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// స్ట్రింగ్ స్లైస్‌ను బారోడ్ వేరియంట్‌గా మారుస్తుంది.
    /// కుప్ప కేటాయింపులు నిర్వహించబడవు మరియు స్ట్రింగ్ కాపీ చేయబడదు.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// స్ట్రింగ్‌ను స్వంత వేరియంట్‌గా మారుస్తుంది.
    /// కుప్ప కేటాయింపులు నిర్వహించబడవు మరియు స్ట్రింగ్ కాపీ చేయబడదు.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// స్ట్రింగ్ రిఫరెన్స్‌ను బారోడ్ వేరియంట్‌గా మారుస్తుంది.
    /// కుప్ప కేటాయింపులు నిర్వహించబడవు మరియు స్ట్రింగ్ కాపీ చేయబడదు.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// ఇచ్చిన `String` ను `u8` రకం విలువలను కలిగి ఉన్న vector `Vec` గా మారుస్తుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// `String` కోసం ఎండిపోయే ఇటరేటర్.
///
/// ఈ స్ట్రక్ట్ [`String`] లో [`drain`] పద్ధతి ద్వారా సృష్టించబడుతుంది.
/// మరిన్ని కోసం దాని డాక్యుమెంటేషన్ చూడండి.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// డిస్ట్రక్టర్‌లో&'మ్యూట్ స్ట్రింగ్‌గా ఉపయోగించబడుతుంది
    string: *mut String,
    /// తొలగించడానికి కొంత భాగం ప్రారంభించండి
    start: usize,
    /// తొలగించడానికి భాగం ముగింపు
    end: usize,
    /// తొలగించడానికి ప్రస్తుత మిగిలిన పరిధి
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Vec::drain ఉపయోగించండి.
            // "Reaffirm" panic కోడ్ మళ్లీ చొప్పించకుండా ఉండటానికి హద్దులు తనిఖీ చేస్తాయి.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// ఈ ఇరేటర్ యొక్క మిగిలిన (ఉప) స్ట్రింగ్‌ను స్లైస్‌గా అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: స్థిరీకరించేటప్పుడు AsRef క్రింద ఇంపాల్స్.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// `string_drain_as_str` ని స్థిరీకరించేటప్పుడు అసౌకర్యం.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>Drain <'a> {fn as_ref(&self)-> &str for కోసం
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// Drain <'a> {fn as_ref(&self)->&[u8] for కోసం impl <' a> AsRef <[u8]>
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}