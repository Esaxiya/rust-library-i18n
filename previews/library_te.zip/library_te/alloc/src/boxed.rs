//! కుప్ప కేటాయింపు కోసం పాయింటర్ రకం.
//!
//! [`Box<T>`], సాధారణంగా 'box' గా సూచిస్తారు, Rust లో కుప్ప కేటాయింపు యొక్క సరళమైన రూపాన్ని అందిస్తుంది.పెట్టెలు ఈ కేటాయింపుకు యాజమాన్యాన్ని అందిస్తాయి మరియు అవి పరిధిలోకి వెళ్ళినప్పుడు వాటి విషయాలను వదిలివేస్తాయి.బాక్స్‌లు అవి ఎప్పుడూ `isize::MAX` బైట్‌ల కంటే ఎక్కువ కేటాయించవని నిర్ధారిస్తాయి.
//!
//! # Examples
//!
//! [`Box`] ను సృష్టించడం ద్వారా స్టాక్ నుండి కుప్పకు విలువను తరలించండి:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! [dereferencing] ద్వారా విలువను [`Box`] నుండి తిరిగి స్టాక్‌కు తరలించండి:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! పునరావృత డేటా నిర్మాణాన్ని సృష్టిస్తోంది:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! ఇది `Cons (1, Cons(2, Nil))`.
//!
//! పునరావృత నిర్మాణాలు తప్పనిసరిగా బాక్స్ చేయబడాలి, ఎందుకంటే `Cons` యొక్క నిర్వచనం ఇలా ఉంటే:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! ఇది పనిచేయదు.ఎందుకంటే `List` యొక్క పరిమాణం జాబితాలో ఎన్ని అంశాలు ఉన్నాయో దానిపై ఆధారపడి ఉంటుంది మరియు అందువల్ల `Cons` కోసం ఎంత మెమరీని కేటాయించాలో మాకు తెలియదు.నిర్వచించిన పరిమాణాన్ని కలిగి ఉన్న [`Box<T>`] ను పరిచయం చేయడం ద్వారా, `Cons` ఎంత పెద్దదిగా ఉండాలో మాకు తెలుసు.
//!
//! # మెమరీ లేఅవుట్
//!
//! సున్నా-పరిమాణ-విలువలకు, [`Box`] దాని కేటాయింపు కోసం [`Global`] కేటాయింపును ఉపయోగిస్తుంది.[`Box`] మరియు [`Global`] కేటాయింపుతో కేటాయించిన ముడి పాయింటర్ మధ్య రెండు మార్గాలను మార్చడం చెల్లుతుంది, ఎందుకంటే కేటాయింపుతో ఉపయోగించిన [`Layout`] రకానికి సరైనది.
//!
//! మరింత ఖచ్చితంగా, `Layout::for_value(&*value)` తో [`Global`] కేటాయింపుతో కేటాయించిన `value:* mut T` ను [`Box::<T>::from_raw(value)`] ఉపయోగించి పెట్టెగా మార్చవచ్చు.
//! దీనికి విరుద్ధంగా, [`Box::<T>::into_raw`] నుండి పొందిన `value:*mut T` కి మద్దతు ఇచ్చే మెమరీని [`Layout::for_value(&* value)`] తో [`Global`] కేటాయింపు ఉపయోగించి డీలోకేట్ చేయవచ్చు.
//!
//! సున్నా-పరిమాణ విలువల కోసం, చదవడానికి మరియు వ్రాయడానికి `Box` పాయింటర్ ఇప్పటికీ [valid] గా ఉండాలి మరియు తగినంతగా సమలేఖనం చేయబడింది.
//! ప్రత్యేకించి, ముడి పాయింటర్‌కు ఏ సమలేఖనం కాని సున్నా కాని పూర్ణాంక అక్షరాలా వేయడం చెల్లుబాటు అయ్యే పాయింటర్‌ను ఉత్పత్తి చేస్తుంది, కాని విముక్తి పొందినప్పటి నుండి గతంలో కేటాయించిన మెమరీని సూచించే పాయింటర్ చెల్లదు.
//! `Box::new` ఉపయోగించలేకపోతే ZST కి బాక్స్‌ను నిర్మించడానికి సిఫార్సు చేయబడిన మార్గం [`ptr::NonNull::dangling`] ను ఉపయోగించడం.
//!
//! `T: Sized` ఉన్నంతవరకు, ఒక `Box<T>` సింగిల్ పాయింటర్‌గా ప్రాతినిధ్యం వహిస్తుందని హామీ ఇవ్వబడింది మరియు సి పాయింటర్లతో (అంటే సి రకం `T*`) ABI-అనుకూలంగా ఉంటుంది.
//! దీని అర్థం మీరు C నుండి పిలువబడే బాహ్య "C" Rust ఫంక్షన్లను కలిగి ఉంటే, మీరు `Box<T>` రకాలను ఉపయోగించి ఆ Rust ఫంక్షన్లను నిర్వచించవచ్చు మరియు C వైపు `T*` ను సంబంధిత రకంగా ఉపయోగించవచ్చు.
//! ఉదాహరణగా, ఈ సి హెడర్‌ను పరిగణించండి, ఇది ఒక రకమైన `Foo` విలువను సృష్టించే మరియు నాశనం చేసే విధులను ప్రకటిస్తుంది:
//!
//! ```c
//! /* సి హెడర్ */
//!
//! /* కాలర్‌కు యాజమాన్యాన్ని అందిస్తుంది */
//! struct Foo* foo_new(void);
//!
//! /* కాలర్ నుండి యాజమాన్యాన్ని తీసుకుంటుంది;NULL తో ప్రారంభించినప్పుడు నో-ఆప్ */
//! void foo_delete(struct Foo*);
//! ```
//!
//! ఈ రెండు విధులు ఈ క్రింది విధంగా Rust లో అమలు చేయబడవచ్చు.ఇక్కడ, C నుండి `struct Foo*` రకం `Box<Foo>` కి అనువదించబడింది, ఇది యాజమాన్య అడ్డంకులను సంగ్రహిస్తుంది.
//! `foo_delete` కు శూన్యమైన వాదన Rust లో `Option<Box<Foo>>` గా సూచించబడుతుంది, ఎందుకంటే `Box<Foo>` శూన్యంగా ఉండదు.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! `Box<T>` కి సి పాయింటర్ వలె ఒకే ప్రాతినిధ్యం మరియు సి ఎబిఐ ఉన్నప్పటికీ, మీరు ఏకపక్ష `T*` ను `Box<T>` గా మార్చగలరని మరియు విషయాలు పని చేస్తాయని ఆశించవచ్చని దీని అర్థం కాదు.
//! `Box<T>` విలువలు ఎల్లప్పుడూ పూర్తిగా సమలేఖనం చేయబడతాయి, శూన్యత లేని పాయింటర్లు.అంతేకాకుండా, `Box<T>` కోసం డిస్ట్రక్టర్ గ్లోబల్ కేటాయింపుతో విలువను విడిపించేందుకు ప్రయత్నిస్తుంది.సాధారణంగా, గ్లోబల్ కేటాయింపు నుండి ఉద్భవించిన పాయింటర్ల కోసం మాత్రమే `Box<T>` ను ఉపయోగించడం ఉత్తమ పద్ధతి.
//!
//! **ముఖ్యమైనది.** కనీసం ప్రస్తుతం, మీరు C లో నిర్వచించిన కానీ Rust నుండి ప్రారంభించబడిన ఫంక్షన్ల కోసం `Box<T>` రకాలను ఉపయోగించకుండా ఉండాలి.ఆ సందర్భాలలో, మీరు నేరుగా సి రకాలను వీలైనంత దగ్గరగా ప్రతిబింబించాలి.
//! X నిర్వచనం `T*` ను ఉపయోగిస్తున్న `Box<T>` వంటి రకాలను ఉపయోగించడం [rust-lang/unsafe-code-guidelines#198][ucg#198] లో వివరించిన విధంగా నిర్వచించబడని ప్రవర్తనకు దారితీస్తుంది.
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// కుప్ప కేటాయింపు కోసం పాయింటర్ రకం.
///
/// మరిన్ని కోసం [module-level documentation](../../std/boxed/index.html) చూడండి.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// కుప్పపై మెమరీని కేటాయిస్తుంది మరియు తరువాత `x` ను ఉంచుతుంది.
    ///
    /// `T` సున్నా-పరిమాణంలో ఉంటే ఇది వాస్తవానికి కేటాయించదు.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// ప్రారంభించని విషయాలతో క్రొత్త పెట్టెను నిర్మిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // వాయిదా వేసిన ప్రారంభించడం:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// మెమరీని `0` బైట్‌లతో నింపడంతో, ప్రారంభించని విషయాలతో కొత్త `Box` ను నిర్మిస్తుంది.
    ///
    ///
    /// ఈ పద్ధతి యొక్క సరైన మరియు తప్పు వాడకానికి ఉదాహరణల కోసం [`MaybeUninit::zeroed`][zeroed] చూడండి.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// క్రొత్త `Pin<Box<T>>` ను నిర్మిస్తుంది.
    /// `T` `Unpin` ను అమలు చేయకపోతే, అప్పుడు `x` మెమరీలో పిన్ చేయబడుతుంది మరియు తరలించబడదు.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// కుప్పపై మెమరీని కేటాయిస్తుంది మరియు దానిలో `x` ను ఉంచుతుంది, కేటాయింపు విఫలమైతే లోపం తిరిగి వస్తుంది
    ///
    ///
    /// `T` సున్నా-పరిమాణంలో ఉంటే ఇది వాస్తవానికి కేటాయించదు.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// కుప్పపై ప్రారంభించని విషయాలతో క్రొత్త పెట్టెను నిర్మిస్తుంది, కేటాయింపు విఫలమైతే లోపం తిరిగి వస్తుంది
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // వాయిదా వేసిన ప్రారంభించడం:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// కుప్ప మీద `0` బైట్‌లతో మెమరీ నిండి ఉండటంతో, ప్రారంభించని విషయాలతో కొత్త `Box` ను నిర్మిస్తుంది
    ///
    ///
    /// ఈ పద్ధతి యొక్క సరైన మరియు తప్పు వాడకానికి ఉదాహరణల కోసం [`MaybeUninit::zeroed`][zeroed] చూడండి.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// ఇచ్చిన కేటాయింపులో మెమరీని కేటాయిస్తుంది, ఆపై `x` ను ఉంచుతుంది.
    ///
    /// `T` సున్నా-పరిమాణంలో ఉంటే ఇది వాస్తవానికి కేటాయించదు.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// ఇచ్చిన కేటాయింపులో మెమరీని కేటాయిస్తుంది, ఆపై `x` ను దానిలో ఉంచుతుంది, కేటాయింపు విఫలమైతే లోపం వస్తుంది
    ///
    ///
    /// `T` సున్నా-పరిమాణంలో ఉంటే ఇది వాస్తవానికి కేటాయించదు.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// అందించిన కేటాయింపులో ప్రారంభించని విషయాలతో క్రొత్త పెట్టెను నిర్మిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // వాయిదా వేసిన ప్రారంభించడం:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: మూసివేత కొన్నిసార్లు భరించలేనిది కనుక అన్‌వ్రాప్_ఆర్_ఎల్సే కంటే మ్యాచ్‌కు ప్రాధాన్యత ఇవ్వండి.
        // అది కోడ్ పరిమాణాన్ని పెద్దదిగా చేస్తుంది.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// అందించిన కేటాయింపులో ప్రారంభించని విషయాలతో క్రొత్త పెట్టెను నిర్మిస్తుంది, కేటాయింపు విఫలమైతే లోపం తిరిగి వస్తుంది
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // వాయిదా వేసిన ప్రారంభించడం:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// అందించిన కేటాయింపులో `0` బైట్‌లతో మెమరీ నిండి ఉండటంతో, ప్రారంభించని విషయాలతో కొత్త `Box` ను నిర్మిస్తుంది.
    ///
    ///
    /// ఈ పద్ధతి యొక్క సరైన మరియు తప్పు వాడకానికి ఉదాహరణల కోసం [`MaybeUninit::zeroed`][zeroed] చూడండి.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: మూసివేత కొన్నిసార్లు భరించలేనిది కనుక అన్‌వ్రాప్_ఆర్_ఎల్సే కంటే మ్యాచ్‌కు ప్రాధాన్యత ఇవ్వండి.
        // అది కోడ్ పరిమాణాన్ని పెద్దదిగా చేస్తుంది.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// ప్రారంభించని విషయాలతో క్రొత్త `Box` ను నిర్మిస్తుంది, అందించిన కేటాయింపులో మెమరీ `0` బైట్‌లతో నిండి ఉంటుంది, కేటాయింపు విఫలమైతే లోపం తిరిగి వస్తుంది,
    ///
    ///
    /// ఈ పద్ధతి యొక్క సరైన మరియు తప్పు వాడకానికి ఉదాహరణల కోసం [`MaybeUninit::zeroed`][zeroed] చూడండి.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// క్రొత్త `Pin<Box<T, A>>` ను నిర్మిస్తుంది.
    /// `T` `Unpin` ను అమలు చేయకపోతే, అప్పుడు `x` మెమరీలో పిన్ చేయబడుతుంది మరియు తరలించబడదు.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// `Box<T>` ను `Box<[T]>` గా మారుస్తుంది
    ///
    /// ఈ మార్పిడి కుప్ప మీద కేటాయించబడదు మరియు స్థానంలో జరుగుతుంది.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// చుట్టిన విలువను తిరిగి ఇచ్చి, `Box` ను వినియోగిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// ప్రారంభించని విషయాలతో క్రొత్త పెట్టె ముక్కను నిర్మిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // వాయిదా వేసిన ప్రారంభించడం:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// `0` బైట్‌లతో మెమరీ నిండిన, ప్రారంభించని విషయాలతో కొత్త బాక్స్డ్ స్లైస్‌ను నిర్మిస్తుంది.
    ///
    ///
    /// ఈ పద్ధతి యొక్క సరైన మరియు తప్పు వాడకానికి ఉదాహరణల కోసం [`MaybeUninit::zeroed`][zeroed] చూడండి.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// అందించిన కేటాయింపులో ప్రారంభించని విషయాలతో కొత్త పెట్టె ముక్కను నిర్మిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // వాయిదా వేసిన ప్రారంభించడం:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// అందించిన కేటాయింపులో ప్రారంభించని విషయాలతో కొత్త బాక్స్డ్ స్లైస్‌ను నిర్మిస్తుంది, మెమరీ `0` బైట్‌లతో నిండి ఉంటుంది.
    ///
    ///
    /// ఈ పద్ధతి యొక్క సరైన మరియు తప్పు వాడకానికి ఉదాహరణల కోసం [`MaybeUninit::zeroed`][zeroed] చూడండి.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// `Box<T, A>` కి మారుస్తుంది.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] మాదిరిగా, విలువ నిజంగా ప్రారంభ స్థితిలో ఉందని హామీ ఇవ్వడం కాలర్ వరకు ఉంటుంది.
    ///
    /// కంటెంట్ ఇంకా పూర్తిగా ప్రారంభించబడనప్పుడు దీన్ని పిలవడం తక్షణం నిర్వచించబడని ప్రవర్తనకు కారణమవుతుంది.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // వాయిదా వేసిన ప్రారంభించడం:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// `Box<[T], A>` కి మారుస్తుంది.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] మాదిరిగా, విలువలు నిజంగా ప్రారంభ స్థితిలో ఉన్నాయని హామీ ఇవ్వడం కాలర్ వరకు ఉంటుంది.
    ///
    /// కంటెంట్ ఇంకా పూర్తిగా ప్రారంభించబడనప్పుడు దీన్ని పిలవడం తక్షణం నిర్వచించబడని ప్రవర్తనకు కారణమవుతుంది.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // వాయిదా వేసిన ప్రారంభించడం:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// ముడి పాయింటర్ నుండి పెట్టెను నిర్మిస్తుంది.
    ///
    /// ఈ ఫంక్షన్‌ను పిలిచిన తరువాత, ముడి పాయింటర్ ఫలితంగా వచ్చే `Box` యాజమాన్యంలో ఉంటుంది.
    /// ప్రత్యేకంగా, `Box` డిస్ట్రక్టర్ `T` యొక్క డిస్ట్రక్టర్ను పిలుస్తుంది మరియు కేటాయించిన మెమరీని ఉచితం చేస్తుంది.
    /// ఇది సురక్షితంగా ఉండటానికి, `Box` ఉపయోగించే [memory layout] కి అనుగుణంగా మెమరీని కేటాయించాలి.
    ///
    ///
    /// # Safety
    ///
    /// ఈ ఫంక్షన్ సురక్షితం కాదు ఎందుకంటే సరికాని ఉపయోగం మెమరీ సమస్యలకు దారితీయవచ్చు.
    /// ఉదాహరణకు, ఒకే ముడి పాయింటర్‌లో ఫంక్షన్‌ను రెండుసార్లు పిలిస్తే డబుల్ ఫ్రీ సంభవించవచ్చు.
    ///
    /// భద్రతా పరిస్థితులు [memory layout] విభాగంలో వివరించబడ్డాయి.
    ///
    /// # Examples
    ///
    /// X001 ను ఉపయోగించి ముడి పాయింటర్‌గా మార్చబడిన `Box` ను పున reat సృష్టించండి:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// గ్లోబల్ కేటాయింపును ఉపయోగించడం ద్వారా మొదటి నుండి `Box` ను మాన్యువల్‌గా సృష్టించండి:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // `ptr` యొక్క (uninitialized) మునుపటి విషయాలను నాశనం చేయడానికి ప్రయత్నించకుండా ఉండటానికి సాధారణంగా .write అవసరం, అయితే ఈ సాధారణ ఉదాహరణ కోసం `*ptr = 5` కూడా పని చేస్తుంది.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// ఇచ్చిన కేటాయింపులో ముడి పాయింటర్ నుండి పెట్టెను నిర్మిస్తుంది.
    ///
    /// ఈ ఫంక్షన్‌ను పిలిచిన తరువాత, ముడి పాయింటర్ ఫలితంగా వచ్చే `Box` యాజమాన్యంలో ఉంటుంది.
    /// ప్రత్యేకంగా, `Box` డిస్ట్రక్టర్ `T` యొక్క డిస్ట్రక్టర్ను పిలుస్తుంది మరియు కేటాయించిన మెమరీని ఉచితం చేస్తుంది.
    /// ఇది సురక్షితంగా ఉండటానికి, `Box` ఉపయోగించే [memory layout] కి అనుగుణంగా మెమరీని కేటాయించాలి.
    ///
    ///
    /// # Safety
    ///
    /// ఈ ఫంక్షన్ సురక్షితం కాదు ఎందుకంటే సరికాని ఉపయోగం మెమరీ సమస్యలకు దారితీయవచ్చు.
    /// ఉదాహరణకు, ఒకే ముడి పాయింటర్‌లో ఫంక్షన్‌ను రెండుసార్లు పిలిస్తే డబుల్ ఫ్రీ సంభవించవచ్చు.
    ///
    /// # Examples
    ///
    /// X001 ను ఉపయోగించి ముడి పాయింటర్‌గా మార్చబడిన `Box` ను పున reat సృష్టించండి:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// సిస్టమ్ కేటాయింపును ఉపయోగించడం ద్వారా మొదటి నుండి `Box` ను మాన్యువల్‌గా సృష్టించండి:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // `ptr` యొక్క (uninitialized) మునుపటి విషయాలను నాశనం చేయడానికి ప్రయత్నించకుండా ఉండటానికి సాధారణంగా .write అవసరం, అయితే ఈ సాధారణ ఉదాహరణ కోసం `*ptr = 5` కూడా పని చేస్తుంది.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// `Box` ను వినియోగిస్తుంది, చుట్టిన ముడి పాయింటర్‌ను తిరిగి ఇస్తుంది.
    ///
    /// పాయింటర్ సరిగ్గా సమలేఖనం చేయబడుతుంది మరియు శూన్యమైనది కాదు.
    ///
    /// ఈ ఫంక్షన్‌కు కాల్ చేసిన తరువాత, గతంలో `Box` చేత నిర్వహించబడే మెమరీకి కాలర్ బాధ్యత వహిస్తాడు.
    /// ముఖ్యంగా, కాలర్ `T` ను సరిగ్గా నాశనం చేసి, మెమరీని విడుదల చేయాలి, `Box` ఉపయోగించే [memory layout] ను పరిగణనలోకి తీసుకోవాలి.
    /// దీన్ని చేయటానికి సులభమైన మార్గం ఏమిటంటే, ముడి పాయింటర్‌ను [`Box::from_raw`] ఫంక్షన్‌తో తిరిగి `Box` గా మార్చడం, `Box` డిస్ట్రక్టర్‌ను శుభ్రపరిచే పనిని అనుమతిస్తుంది.
    ///
    ///
    /// Note: ఇది అనుబంధిత ఫంక్షన్, అంటే మీరు దీన్ని `b.into_raw()` కు బదులుగా `Box::into_raw(b)` అని పిలవాలి.
    /// లోపలి రకంపై ఒక పద్ధతిలో విభేదాలు ఉండవు.
    ///
    /// # Examples
    /// ముడి పాయింటర్‌ను ఆటోమేటిక్ క్లీనప్ కోసం [`Box::from_raw`] తో `Box` గా మార్చడం:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// డిస్ట్రక్టర్‌ను స్పష్టంగా అమలు చేయడం ద్వారా మరియు మెమరీని డీలోకేట్ చేయడం ద్వారా మాన్యువల్ క్లీనప్:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// `Box` ను వినియోగిస్తుంది, చుట్టిన ముడి పాయింటర్ మరియు కేటాయింపును తిరిగి ఇస్తుంది.
    ///
    /// పాయింటర్ సరిగ్గా సమలేఖనం చేయబడుతుంది మరియు శూన్యమైనది కాదు.
    ///
    /// ఈ ఫంక్షన్‌కు కాల్ చేసిన తరువాత, గతంలో `Box` చేత నిర్వహించబడే మెమరీకి కాలర్ బాధ్యత వహిస్తాడు.
    /// ముఖ్యంగా, కాలర్ `T` ను సరిగ్గా నాశనం చేసి, మెమరీని విడుదల చేయాలి, `Box` ఉపయోగించే [memory layout] ను పరిగణనలోకి తీసుకోవాలి.
    /// దీన్ని చేయటానికి సులభమైన మార్గం ఏమిటంటే, ముడి పాయింటర్‌ను [`Box::from_raw_in`] ఫంక్షన్‌తో తిరిగి `Box` గా మార్చడం, `Box` డిస్ట్రక్టర్‌ను శుభ్రపరిచే పనిని అనుమతిస్తుంది.
    ///
    ///
    /// Note: ఇది అనుబంధిత ఫంక్షన్, అంటే మీరు దీన్ని `b.into_raw_with_allocator()` కు బదులుగా `Box::into_raw_with_allocator(b)` అని పిలవాలి.
    /// లోపలి రకంపై ఒక పద్ధతిలో విభేదాలు ఉండవు.
    ///
    /// # Examples
    /// ముడి పాయింటర్‌ను ఆటోమేటిక్ క్లీనప్ కోసం [`Box::from_raw_in`] తో `Box` గా మార్చడం:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// డిస్ట్రక్టర్‌ను స్పష్టంగా అమలు చేయడం ద్వారా మరియు మెమరీని డీలోకేట్ చేయడం ద్వారా మాన్యువల్ క్లీనప్:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // పెట్టెను స్టాక్డ్ బారోస్ చేత "unique pointer" గా గుర్తించబడింది, కాని అంతర్గతంగా ఇది టైప్ సిస్టమ్‌కు ముడి పాయింటర్.
        // ముడి పాయింటర్‌గా నేరుగా మార్చడం మారుపేరు ముడి ప్రాప్యతలను అనుమతించే ప్రత్యేకమైన పాయింటర్‌గా "releasing" గా గుర్తించబడదు, కాబట్టి అన్ని ముడి పాయింటర్ పద్ధతులు `Box::leak` ద్వారా వెళ్ళాలి.
        //
        // ముడి పాయింటర్‌కు *ఆ* ను మార్చడం సరిగ్గా ప్రవర్తిస్తుంది.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// అంతర్లీన కేటాయింపుకు సూచనను అందిస్తుంది.
    ///
    /// Note: ఇది అనుబంధిత ఫంక్షన్, అంటే మీరు దీన్ని `b.allocator()` కు బదులుగా `Box::allocator(&b)` అని పిలవాలి.
    /// లోపలి రకంపై ఒక పద్ధతిలో విభేదాలు ఉండవు.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// `Box` ను వినియోగిస్తుంది మరియు లీక్ చేస్తుంది, మార్చగల సూచనను తిరిగి ఇస్తుంది, `&'a mut T`.
    /// `T` రకం ఎంచుకున్న జీవితకాలం `'a` ను మించి ఉండాలి.
    /// రకానికి స్టాటిక్ రిఫరెన్సులు మాత్రమే ఉంటే, లేదా ఏదీ లేకపోతే, ఇది `'static` గా ఎంచుకోవచ్చు.
    ///
    /// ఈ ఫంక్షన్ ప్రధానంగా ప్రోగ్రామ్ యొక్క జీవితాంతం జీవించే డేటాకు ఉపయోగపడుతుంది.
    /// తిరిగి వచ్చిన సూచనను వదలడం వల్ల మెమరీ లీక్ అవుతుంది.
    /// ఇది ఆమోదయోగ్యం కాకపోతే, రిఫరెన్స్ మొదట X001 ను ఉత్పత్తి చేసే [`Box::from_raw`] ఫంక్షన్‌తో చుట్టాలి.
    ///
    /// ఈ `Box` ను వదిలివేయవచ్చు, ఇది `T` ను సరిగ్గా నాశనం చేస్తుంది మరియు కేటాయించిన మెమరీని విడుదల చేస్తుంది.
    ///
    /// Note: ఇది అనుబంధిత ఫంక్షన్, అంటే మీరు దీన్ని `b.leak()` కు బదులుగా `Box::leak(b)` అని పిలవాలి.
    /// లోపలి రకంపై ఒక పద్ధతిలో విభేదాలు ఉండవు.
    ///
    /// # Examples
    ///
    /// సాధారణ ఉపయోగం:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// పరిమాణం లేని డేటా:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// `Box<T>` ను `Pin<Box<T>>` గా మారుస్తుంది
    ///
    /// ఈ మార్పిడి కుప్ప మీద కేటాయించబడదు మరియు స్థానంలో జరుగుతుంది.
    ///
    /// ఇది [`From`] ద్వారా కూడా లభిస్తుంది.
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // `T: !Unpin` ఉన్నప్పుడు `Pin<Box<T>>` యొక్క ఇన్సైడ్లను తరలించడం లేదా మార్చడం సాధ్యం కాదు, కాబట్టి అదనపు అవసరాలు లేకుండా నేరుగా పిన్ చేయడం సురక్షితం.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: ఏమీ చేయవద్దు, డ్రాప్ ప్రస్తుతం కంపైలర్ చేత చేయబడుతుంది.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// T కోసం `Default` విలువతో `Box<T>` ను సృష్టిస్తుంది.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// ఈ పెట్టెలోని `clone()` విషయాలతో క్రొత్త పెట్టెను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // విలువ ఒకటే
    /// assert_eq!(x, y);
    ///
    /// // కానీ అవి ప్రత్యేకమైన వస్తువులు
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // క్లోన్ చేసిన విలువను నేరుగా వ్రాయడానికి అనుమతించడానికి మెమరీని ముందుగా కేటాయించండి.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// క్రొత్త కేటాయింపును సృష్టించకుండా `మూలం` యొక్క కంటెంట్లను `self` లోకి కాపీ చేస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // విలువ ఒకటే
    /// assert_eq!(x, y);
    ///
    /// // మరియు కేటాయింపులు జరగలేదు
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // ఇది డేటా యొక్క కాపీని చేస్తుంది
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// సాధారణ రకం `T` ను `Box<T>` గా మారుస్తుంది
    ///
    /// మార్పిడి కుప్ప మీద కేటాయిస్తుంది మరియు స్టాక్ నుండి `t` ను కదిలిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// `Box<T>` ను `Pin<Box<T>>` గా మారుస్తుంది
    ///
    /// ఈ మార్పిడి కుప్ప మీద కేటాయించబడదు మరియు స్థానంలో జరుగుతుంది.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// `&[T]` ను `Box<[T]>` గా మారుస్తుంది
    ///
    /// ఈ మార్పిడి కుప్ప మీద కేటాయిస్తుంది మరియు `slice` యొక్క కాపీని చేస్తుంది.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // &<u8] ను సృష్టించండి, ఇది బాక్స్ <[u8]> ను సృష్టించడానికి ఉపయోగించబడుతుంది
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// `&str` ను `Box<str>` గా మారుస్తుంది
    ///
    /// ఈ మార్పిడి కుప్ప మీద కేటాయిస్తుంది మరియు `s` యొక్క కాపీని చేస్తుంది.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// `Box<str>` ను `Box<[u8]>` గా మారుస్తుంది
    /// ఈ మార్పిడి కుప్ప మీద కేటాయించబడదు మరియు స్థానంలో జరుగుతుంది.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // బాక్స్ సృష్టించండి<str>ఇది బాక్స్ <[u8]> ను సృష్టించడానికి ఉపయోగించబడుతుంది
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // &<u8] ను సృష్టించండి, ఇది బాక్స్ <[u8]> ను సృష్టించడానికి ఉపయోగించబడుతుంది
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// `[T; N]` ను `Box<[T]>` గా మారుస్తుంది
    /// ఈ మార్పిడి శ్రేణిని కొత్తగా కుప్ప-కేటాయించిన మెమరీకి తరలిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// పెట్టెను కాంక్రీట్ రకానికి తగ్గించే ప్రయత్నం.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// పెట్టెను కాంక్రీట్ రకానికి తగ్గించే ప్రయత్నం.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// పెట్టెను కాంక్రీట్ రకానికి తగ్గించే ప్రయత్నం.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // లోపలి యునిక్‌ను బాక్స్ నుండి నేరుగా సంగ్రహించడం సాధ్యం కాదు, బదులుగా మేము దానిని * కాన్స్టాంట్‌కు ప్రసారం చేస్తాము, ఇది ప్రత్యేకతను మారుస్తుంది
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// డిఫాల్ట్‌కు బదులుగా `last()` యొక్క `I` అమలును ఉపయోగించే పరిమాణ`I` లకు ప్రత్యేకత.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}