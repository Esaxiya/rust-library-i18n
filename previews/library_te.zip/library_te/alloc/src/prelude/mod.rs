//! కేటాయింపు Prelude
//!
//! ఈ మాడ్యూల్ యొక్క ఉద్దేశ్యం `alloc` crate యొక్క సాధారణంగా ఉపయోగించే వస్తువుల దిగుమతులను మాడ్యూళ్ల పైభాగానికి గ్లోబ్ దిగుమతిని జోడించడం ద్వారా తగ్గించడం:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;