#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// క్రొత్త మెమరీలోని విషయాలు ప్రారంభించబడలేదు.
    Uninitialized,
    /// క్రొత్త మెమరీ సున్నా అవుతుందని హామీ ఇవ్వబడింది.
    Zeroed,
}

/// ప్రమేయం ఉన్న అన్ని మూలలో ఉన్న కేసుల గురించి ఆందోళన చెందకుండా కుప్పపై మెమరీ బఫర్‌ను మరింత ఎర్గోనామిక్‌గా కేటాయించడం, తిరిగి కేటాయించడం మరియు డీలోకేట్ చేయడం కోసం తక్కువ-స్థాయి యుటిలిటీ.
///
/// Vec మరియు VecDeque వంటి మీ స్వంత డేటా నిర్మాణాలను నిర్మించడానికి ఈ రకం అద్భుతమైనది.
/// ముఖ్యంగా:
///
/// * సున్నా-పరిమాణ రకాల్లో `Unique::dangling()` ను ఉత్పత్తి చేస్తుంది.
/// * సున్నా-పొడవు కేటాయింపులపై `Unique::dangling()` ను ఉత్పత్తి చేస్తుంది.
/// * `Unique::dangling()` ను విడిపించడాన్ని నివారిస్తుంది.
/// * సామర్థ్య గణనలలో అన్ని ఓవర్‌ఫ్లోలను పట్టుకుంటుంది (వాటిని "capacity overflow" panics కు ప్రోత్సహిస్తుంది).
/// * isize::MAX బైట్ల కంటే ఎక్కువ కేటాయించే 32-బిట్ వ్యవస్థలకు వ్యతిరేకంగా కాపలా.
/// * మీ పొడవు పొంగిపోకుండా కాపలా.
/// * తప్పు కేటాయింపుల కోసం `handle_alloc_error` ని కాల్ చేస్తుంది.
/// * `ptr::Unique` ను కలిగి ఉంటుంది మరియు తద్వారా వినియోగదారుకు అన్ని సంబంధిత ప్రయోజనాలను అందిస్తుంది.
/// * అందుబాటులో ఉన్న అతిపెద్ద సామర్థ్యాన్ని ఉపయోగించడానికి కేటాయింపుదారు నుండి తిరిగి వచ్చిన అదనపు మొత్తాన్ని ఉపయోగిస్తుంది.
///
/// ఈ రకం ఏమైనప్పటికీ అది నిర్వహించే మెమరీని పరిశీలించదు.పడిపోయినప్పుడు *దాని జ్ఞాపకశక్తిని విముక్తి చేస్తుంది, కానీ అది* దాని విషయాలను వదలడానికి ప్రయత్నించదు.
/// `RawVec` లోపల *నిల్వ చేయబడిన* వాస్తవ విషయాలను నిర్వహించడం `RawVec` యొక్క వినియోగదారుపై ఆధారపడి ఉంటుంది.
///
/// సున్నా-పరిమాణ రకాలు అధికంగా ఉండటం ఎల్లప్పుడూ అనంతం అని గమనించండి, కాబట్టి `capacity()` ఎల్లప్పుడూ `usize::MAX` ను అందిస్తుంది.
/// `capacity()` పొడవును ఇవ్వదు కాబట్టి, ఈ రకాన్ని `Box<[T]>` తో రౌండ్-ట్రిప్పింగ్ చేసేటప్పుడు మీరు జాగ్రత్తగా ఉండాలని దీని అర్థం.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): ఇది ఉనికిలో ఉంది ఎందుకంటే `#[unstable]` `const fn`s `min_const_fn` కి అనుగుణంగా ఉండనవసరం లేదు కాబట్టి వాటిని`min_const_fn` లలో పిలవలేము.
    ///
    /// మీరు `RawVec<T>::new` లేదా డిపెండెన్సీలను మార్చినట్లయితే, దయచేసి `min_const_fn` ని నిజంగా ఉల్లంఘించే ఏదైనా పరిచయం చేయకుండా జాగ్రత్త వహించండి.
    ///
    /// NOTE: మేము ఈ హాక్‌ను నివారించవచ్చు మరియు కొన్ని `#[rustc_force_min_const_fn]` లక్షణంతో కన్ఫర్మేషన్‌ను తనిఖీ చేయవచ్చు, దీనికి `min_const_fn` తో అనుగుణ్యత అవసరం కాని `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ఉన్నప్పుడు `foo` ను ఎనేబుల్ చేయని `stable(...) const fn`/యూజర్ కోడ్‌లో కాల్ చేయడానికి అనుమతించదు.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// కేటాయించకుండా సాధ్యమయ్యే అతిపెద్ద `RawVec` (సిస్టమ్ కుప్పలో) సృష్టిస్తుంది.
    /// `T` సానుకూల పరిమాణాన్ని కలిగి ఉంటే, ఇది `0` సామర్థ్యం కలిగిన `RawVec` ను చేస్తుంది.
    /// `T` సున్నా-పరిమాణమైతే, అది `usize::MAX` సామర్థ్యం కలిగిన `RawVec` ను చేస్తుంది.
    /// ఆలస్యం కేటాయింపును అమలు చేయడానికి ఉపయోగపడుతుంది.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// `[T; capacity]` కోసం ఖచ్చితంగా సామర్థ్యం మరియు అమరిక అవసరాలతో `RawVec` (సిస్టమ్ కుప్పలో) సృష్టిస్తుంది.
    /// `capacity` `0` లేదా `T` సున్నా-పరిమాణంలో ఉన్నప్పుడు ఇది `RawVec::new` కి కాల్ చేయడానికి సమానం.
    /// `T` సున్నా-పరిమాణంగా ఉంటే దీని అర్థం మీరు అభ్యర్థించిన సామర్థ్యంతో `RawVec` ను పొందలేరు.
    ///
    /// # Panics
    ///
    /// అభ్యర్థించిన సామర్థ్యం `isize::MAX` బైట్‌లను మించి ఉంటే Panics.
    ///
    /// # Aborts
    ///
    /// OOM లో ఆగిపోతుంది.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// `with_capacity` లాగా, కానీ బఫర్ సున్నా అవుతుందని హామీ ఇస్తుంది.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// పాయింటర్ మరియు సామర్థ్యం నుండి `RawVec` ను పునర్నిర్మిస్తుంది.
    ///
    /// # Safety
    ///
    /// `ptr` ని కేటాయించాలి (సిస్టమ్ కుప్పలో), మరియు ఇచ్చిన `capacity` తో.
    /// `capacity` పరిమాణ రకాల కోసం `isize::MAX` మించకూడదు.(32-బిట్ సిస్టమ్‌లపై మాత్రమే ఆందోళన).
    /// ZST vectors `usize::MAX` వరకు సామర్థ్యాన్ని కలిగి ఉండవచ్చు.
    /// `ptr` మరియు `capacity` ఒక `RawVec` నుండి వచ్చినట్లయితే, ఇది హామీ ఇవ్వబడుతుంది.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // చిన్న Vecs మూగవి.దీనికి దాటవేయి:
    // - మూలకం పరిమాణం 1 అయితే 8, ఎందుకంటే ఏదైనా కుప్ప కేటాయింపుదారులు 8 బైట్ల కన్నా తక్కువ 8 బైట్ల నుండి ఒక అభ్యర్థనను చుట్టుముట్టే అవకాశం ఉంది.
    //
    // - మూలకాలు మితమైన పరిమాణంలో ఉంటే (<=1 కిబి).
    // - 1 లేకపోతే, చాలా తక్కువ Vec లకు ఎక్కువ స్థలాన్ని వృథా చేయకుండా ఉండటానికి.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// `new` లాగా, కానీ తిరిగి వచ్చిన `RawVec` కోసం కేటాయింపు ఎంపికపై పారామీటర్ చేయబడింది.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` అంటే "unallocated".సున్నా-పరిమాణ రకాలు విస్మరించబడతాయి.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// `with_capacity` లాగా, కానీ తిరిగి వచ్చిన `RawVec` కోసం కేటాయింపు ఎంపికపై పారామీటర్ చేయబడింది.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// `with_capacity_zeroed` లాగా, కానీ తిరిగి వచ్చిన `RawVec` కోసం కేటాయింపు ఎంపికపై పారామీటర్ చేయబడింది.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>` ను `RawVec<T>` గా మారుస్తుంది.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// పేర్కొన్న `len` తో మొత్తం బఫర్‌ను `Box<[MaybeUninit<T>]>` గా మారుస్తుంది.
    ///
    /// ఇది ఏదైనా `cap` మార్పులను సరిగ్గా పునర్నిర్మిస్తుందని గమనించండి.(వివరాల కోసం రకం వివరణ చూడండి.)
    ///
    /// # Safety
    ///
    /// * `len` ఇటీవల అభ్యర్థించిన సామర్థ్యం కంటే ఎక్కువ లేదా సమానంగా ఉండాలి మరియు
    /// * `len` `self.capacity()` కన్నా తక్కువ లేదా సమానంగా ఉండాలి.
    ///
    /// గమనిక, అభ్యర్థించిన సామర్థ్యం మరియు `self.capacity()` విభిన్నంగా ఉండవచ్చని, ఎందుకంటే ఒక కేటాయింపు అధికంగా కేటాయించి, అభ్యర్థించిన దానికంటే ఎక్కువ మెమరీ బ్లాక్‌ను తిరిగి ఇవ్వగలదు.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // భద్రతా అవసరాలలో సగం తెలివిని తనిఖీ చేయండి (మిగిలిన సగం మేము తనిఖీ చేయలేము).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // మేము ఇక్కడ `unwrap_or_else` ను నివారించాము ఎందుకంటే ఇది ఉత్పత్తి చేయబడిన LLVM IR మొత్తాన్ని ఉబ్బుతుంది.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// పాయింటర్, సామర్థ్యం మరియు కేటాయింపు నుండి `RawVec` ను పునర్నిర్మిస్తుంది.
    ///
    /// # Safety
    ///
    /// `ptr` ని కేటాయించాలి (ఇచ్చిన కేటాయింపు `alloc` ద్వారా), మరియు ఇచ్చిన `capacity` తో.
    /// `capacity` పరిమాణ రకాల కోసం `isize::MAX` మించకూడదు.
    /// (32-బిట్ సిస్టమ్‌లపై మాత్రమే ఆందోళన).
    /// ZST vectors `usize::MAX` వరకు సామర్థ్యాన్ని కలిగి ఉండవచ్చు.
    /// `ptr` మరియు `capacity` `alloc` ద్వారా సృష్టించబడిన `RawVec` నుండి వచ్చినట్లయితే, ఇది హామీ ఇవ్వబడుతుంది.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// కేటాయింపు ప్రారంభానికి ముడి పాయింటర్ పొందుతుంది.
    /// `capacity == 0` లేదా `T` సున్నా-పరిమాణంలో ఉంటే ఇది `Unique::dangling()` అని గమనించండి.
    /// మునుపటి సందర్భంలో, మీరు జాగ్రత్తగా ఉండాలి.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// కేటాయింపు సామర్థ్యాన్ని పొందుతుంది.
    ///
    /// `T` సున్నా-పరిమాణంగా ఉంటే ఇది ఎల్లప్పుడూ `usize::MAX` అవుతుంది.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// ఈ `RawVec` కి మద్దతు ఇచ్చే కేటాయింపుకు భాగస్వామ్య సూచనను అందిస్తుంది.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // మనకు కేటాయించిన మెమరీ భాగం ఉంది, కాబట్టి మన ప్రస్తుత లేఅవుట్ పొందడానికి రన్‌టైమ్ తనిఖీలను దాటవేయవచ్చు.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// `len + additional` మూలకాలను ఉంచడానికి బఫర్ కనీసం తగినంత స్థలాన్ని కలిగి ఉందని నిర్ధారిస్తుంది.
    /// ఇది ఇప్పటికే తగినంత సామర్థ్యాన్ని కలిగి ఉండకపోతే, రుణమాఫీ *O*(1) ప్రవర్తనను పొందడానికి తగినంత స్థలం మరియు సౌకర్యవంతమైన స్లాక్ స్థలాన్ని తిరిగి కేటాయిస్తుంది.
    ///
    /// అనవసరంగా panic కు కారణమైతే ఈ ప్రవర్తనను పరిమితం చేస్తుంది.
    ///
    /// `len` `self.capacity()` ను మించి ఉంటే, ఇది అభ్యర్థించిన స్థలాన్ని కేటాయించడంలో విఫలమవుతుంది.
    /// ఇది నిజంగా సురక్షితం కాదు, కానీ ఈ ఫంక్షన్ యొక్క ప్రవర్తనపై ఆధారపడే అసురక్షిత కోడ్ *మీరు* వ్రాయవచ్చు.
    ///
    /// `extend` వంటి బల్క్-పుష్ ఆపరేషన్‌ను అమలు చేయడానికి ఇది అనువైనది.
    ///
    /// # Panics
    ///
    /// కొత్త సామర్థ్యం `isize::MAX` బైట్‌లను మించి ఉంటే Panics.
    ///
    /// # Aborts
    ///
    /// OOM లో ఆగిపోతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // లెన్ `isize::MAX` ను మించి ఉంటే రిజర్వ్ ఆగిపోతుంది లేదా భయపడవచ్చు, కాబట్టి ఇది ఇప్పుడు తనిఖీ చేయకుండా సురక్షితం.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// `reserve` వలె ఉంటుంది, కానీ భయాందోళనలకు లేదా రద్దు చేయడానికి బదులుగా లోపాలపై తిరిగి వస్తుంది.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// `len + additional` మూలకాలను ఉంచడానికి బఫర్ కనీసం తగినంత స్థలాన్ని కలిగి ఉందని నిర్ధారిస్తుంది.
    /// ఇది ఇప్పటికే కాకపోతే, అవసరమైన కనీస మెమరీని తిరిగి కేటాయిస్తుంది.
    /// సాధారణంగా ఇది ఖచ్చితంగా అవసరమైన మెమరీ మొత్తం అవుతుంది, కాని సూత్రప్రాయంగా మేము అడిగిన దానికంటే ఎక్కువ తిరిగి ఇవ్వడానికి కేటాయింపు ఉచితం.
    ///
    ///
    /// `len` `self.capacity()` ను మించి ఉంటే, ఇది అభ్యర్థించిన స్థలాన్ని కేటాయించడంలో విఫలమవుతుంది.
    /// ఇది నిజంగా సురక్షితం కాదు, కానీ ఈ ఫంక్షన్ యొక్క ప్రవర్తనపై ఆధారపడే అసురక్షిత కోడ్ *మీరు* వ్రాయవచ్చు.
    ///
    /// # Panics
    ///
    /// కొత్త సామర్థ్యం `isize::MAX` బైట్‌లను మించి ఉంటే Panics.
    ///
    /// # Aborts
    ///
    /// OOM లో ఆగిపోతుంది.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// `reserve_exact` వలె ఉంటుంది, కానీ భయాందోళనలకు లేదా రద్దు చేయడానికి బదులుగా లోపాలపై తిరిగి వస్తుంది.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// కేటాయింపును పేర్కొన్న మొత్తానికి తగ్గిస్తుంది.
    /// ఇచ్చిన మొత్తం 0 అయితే, వాస్తవానికి పూర్తిగా తొలగిపోతుంది.
    ///
    /// # Panics
    ///
    /// ఇచ్చిన మొత్తం ప్రస్తుత సామర్థ్యం కంటే * పెద్దది అయితే Panics.
    ///
    /// # Aborts
    ///
    /// OOM లో ఆగిపోతుంది.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// అవసరమైన అదనపు సామర్థ్యాన్ని నెరవేర్చడానికి బఫర్ పెరగాలంటే తిరిగి వస్తుంది.
    /// `grow` ఇన్లైన్ చేయకుండా ఇన్లైన్ రిజర్వ్-కాల్స్ సాధ్యం చేయడానికి ప్రధానంగా ఉపయోగిస్తారు.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // ఈ పద్ధతి సాధారణంగా చాలాసార్లు తక్షణం ఇవ్వబడుతుంది.కాబట్టి కంపైల్ సమయాన్ని మెరుగుపరచడానికి ఇది సాధ్యమైనంత చిన్నదిగా ఉండాలని మేము కోరుకుంటున్నాము.
    // కానీ ఉత్పత్తి చేయబడిన కోడ్ వేగంగా నడిచేలా, దానిలోని ఎక్కువ విషయాలు సాధ్యమైనంతవరకు స్థిరంగా లెక్కించబడాలని మేము కోరుకుంటున్నాము.
    // అందువల్ల, ఈ పద్ధతి జాగ్రత్తగా వ్రాయబడింది, తద్వారా `T` పై ఆధారపడే అన్ని కోడ్ దానిలో ఉంటుంది, అయితే `T` పై ఆధారపడని కోడ్ చాలావరకు `T` కంటే సాధారణం కాని ఫంక్షన్లలో ఉంటుంది.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // కాలింగ్ సందర్భాల ద్వారా ఇది నిర్ధారిస్తుంది.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // `elem_size` ఉన్నప్పుడు మేము `usize::MAX` సామర్థ్యాన్ని తిరిగి ఇస్తాము కాబట్టి
            // 0, ఇక్కడికి చేరుకోవడం అంటే `RawVec` ఓవర్ ఫుల్ అని అర్థం.
            return Err(CapacityOverflow);
        }

        // పాపం, ఈ తనిఖీల గురించి మనం నిజంగా ఏమీ చేయలేము.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // ఇది ఘాతాంక వృద్ధికి హామీ ఇస్తుంది.
        // `cap <= isize::MAX` మరియు `cap` రకం `usize` ఎందుకంటే రెట్టింపు పొంగిపోదు.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` కంటే సాధారణమైనది కాదు.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // ఈ పద్ధతిపై ఉన్న అడ్డంకులు `grow_amortized` లో ఉన్న వాటితో సమానంగా ఉంటాయి, కానీ ఈ పద్ధతి సాధారణంగా తక్కువ తరచుగా తక్షణం ఇవ్వబడుతుంది కాబట్టి ఇది తక్కువ క్లిష్టమైనది.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // రకం పరిమాణం ఉన్నప్పుడు మేము `usize::MAX` సామర్థ్యాన్ని తిరిగి ఇస్తాము కాబట్టి
            // 0, ఇక్కడికి చేరుకోవడం అంటే `RawVec` ఓవర్ ఫుల్ అని అర్థం.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` కంటే సాధారణమైనది కాదు.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// కంపైల్ సమయాన్ని తగ్గించడానికి ఈ ఫంక్షన్ `RawVec` వెలుపల ఉంది.వివరాల కోసం `RawVec::grow_amortized` పై వ్యాఖ్య చూడండి.
// (`A` పరామితి ముఖ్యమైనది కాదు, ఎందుకంటే ఆచరణలో కనిపించే వివిధ `A` రకాల సంఖ్య `T` రకాల సంఖ్య కంటే చాలా తక్కువగా ఉంటుంది.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // `RawVec::grow_*` పరిమాణాన్ని తగ్గించడానికి ఇక్కడ లోపం కోసం తనిఖీ చేయండి.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // కేటాయింపు సమానత్వం కోసం కేటాయింపు తనిఖీ చేస్తుంది
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// `RawVec` * యాజమాన్యంలోని మెమరీని దాని కంటెంట్లను వదలడానికి ప్రయత్నించకుండా ఫ్రీస్ చేస్తుంది.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// రిజర్వ్ లోపం నిర్వహణ కోసం కేంద్ర ఫంక్షన్.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// మేము ఈ క్రింది వాటికి హామీ ఇవ్వాలి:
// * మేము ఎప్పుడూ `> isize::MAX` బైట్-పరిమాణ వస్తువులను కేటాయించము.
// * మేము `usize::MAX` ని పొంగిపోము మరియు వాస్తవానికి చాలా తక్కువ కేటాయించము.
//
// 64-బిట్‌లో మనం ఓవర్‌ఫ్లో కోసం తనిఖీ చేయాలి ఎందుకంటే `> isize::MAX` బైట్‌లను కేటాయించడానికి ప్రయత్నించడం తప్పనిసరిగా విఫలమవుతుంది.
// 32-బిట్ మరియు 16-బిట్లలో, మేము ప్లాట్‌ఫామ్‌లో నడుస్తున్న సందర్భంలో దీనికి అదనపు గార్డును జోడించాలి, ఇది మొత్తం 4GB ని యూజర్-స్పేస్‌లో ఉపయోగించగలదు, ఉదా., PAE లేదా x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// సామర్థ్యం ఓవర్ఫ్లోలను నివేదించడానికి బాధ్యత వహించే ఒక కేంద్ర ఫంక్షన్.
// మాడ్యూల్ అంతటా బంచ్ కాకుండా panics ఉన్న ఒకే ఒక ప్రదేశం ఉన్నందున ఈ panics కి సంబంధించిన కోడ్ ఉత్పత్తి తక్కువగా ఉందని ఇది నిర్ధారిస్తుంది.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}