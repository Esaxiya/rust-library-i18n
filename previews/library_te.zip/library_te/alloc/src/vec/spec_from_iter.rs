use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Vec::from_iter కోసం స్పెషలైజేషన్ trait ఉపయోగించబడింది
///
/// ## ప్రతినిధి గ్రాఫ్:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // ఒక సాధారణ కేసు vector ను ఒక ఫంక్షన్ లోకి పంపుతుంది, అది వెంటనే vector లోకి తిరిగి సేకరిస్తుంది.
        // IntoIter అస్సలు అభివృద్ధి చెందకపోతే మేము దీన్ని షార్ట్ సర్క్యూట్ చేయవచ్చు.
        // ఇది అభివృద్ధి చెందినప్పుడు మనం మెమరీని తిరిగి ఉపయోగించుకోవచ్చు మరియు డేటాను ముందు వైపుకు తరలించవచ్చు.
        // సాధారణ ఫ్రమ్ఇటరేటర్ అమలు ద్వారా సృష్టించడం కంటే ఫలిత Vec కి ఎక్కువ ఉపయోగించని సామర్థ్యం లేనప్పుడు మాత్రమే మేము అలా చేస్తాము.
        //
        // Vec యొక్క కేటాయింపు ప్రవర్తన ఉద్దేశపూర్వకంగా పేర్కొనబడనందున ఆ పరిమితి ఖచ్చితంగా అవసరం లేదు.
        // కానీ ఇది సంప్రదాయవాద ఎంపిక.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // extend() ఖాళీ Vecs కోసం spec_from నుండి ప్రతినిధిగా ఉన్నందున spec_extend() కి తప్పక ప్రతినిధిగా ఉండాలి
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// ఇది `iterator.as_slice().to_vec()` ను ఉపయోగించుకుంటుంది, ఎందుకంటే స్పెక్_ఎక్స్‌టెండ్ తుది సామర్థ్యం + పొడవు గురించి వాదించడానికి మరిన్ని చర్యలు తీసుకోవాలి మరియు తద్వారా ఎక్కువ పని చేస్తుంది.
// `to_vec()` నేరుగా సరైన మొత్తాన్ని కేటాయిస్తుంది మరియు ఖచ్చితంగా నింపుతుంది.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cfg(test) తో ఈ పద్ధతి నిర్వచనానికి అవసరమైన స్వాభావిక `[T]::to_vec` పద్ధతి అందుబాటులో లేదు.
    // బదులుగా cfg(test) NB తో మాత్రమే అందుబాటులో ఉన్న `slice::to_vec` ఫంక్షన్‌ను ఉపయోగించండి మరింత సమాచారం కోసం slice.rs లోని slice::hack మాడ్యూల్ చూడండి
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}