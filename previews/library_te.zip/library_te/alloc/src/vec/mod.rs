//! కుప్ప-కేటాయించిన విషయాలతో వరుసగా వృద్ధి చెందగల శ్రేణి రకం, వ్రాసిన `Vec<T>`.
//!
//! Vectors లో `O(1)` ఇండెక్సింగ్, రుణ విమోచన `O(1)` పుష్ (చివరి వరకు) మరియు `O(1)` పాప్ (చివరి నుండి) ఉన్నాయి.
//!
//!
//! Vectors వారు `isize::MAX` బైట్ల కంటే ఎక్కువ కేటాయించలేదని నిర్ధారిస్తుంది.
//!
//! # Examples
//!
//! మీరు [`Vec::new`] తో [`Vec`] ను స్పష్టంగా సృష్టించవచ్చు:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... లేదా [`vec!`] స్థూలని ఉపయోగించడం ద్వారా:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // పది సున్నాలు
//! ```
//!
//! మీరు [`push`] విలువలను vector చివరలో చేయవచ్చు (ఇది vector ను అవసరమైన విధంగా పెంచుతుంది):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! పాపింగ్ విలువలు అదే విధంగా పనిచేస్తాయి:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors కూడా ఇండెక్సింగ్‌కు మద్దతు ఇస్తుంది ([`Index`] మరియు [`IndexMut`] traits ద్వారా):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// `Vec<T>` గా వ్రాయబడిన మరియు 'vector' గా ఉచ్ఛరించబడే ఒక పరస్పర పెరుగుతున్న శ్రేణి రకం.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// ప్రారంభించడం మరింత సౌకర్యవంతంగా చేయడానికి [`vec!`] స్థూల అందించబడింది:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// ఇది ఇచ్చిన విలువతో `Vec<T>` యొక్క ప్రతి మూలకాన్ని కూడా ప్రారంభించగలదు.
/// ప్రత్యేక దశలలో కేటాయింపు మరియు ప్రారంభించడం కంటే ఇది మరింత సమర్థవంతంగా ఉంటుంది, ప్రత్యేకించి సున్నాల యొక్క vector ను ప్రారంభించేటప్పుడు:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // కిందిది సమానం, కానీ నెమ్మదిగా ఉంటుంది:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// మరింత సమాచారం కోసం, [Capacity and Reallocation](#capacity-and-reallocation) చూడండి.
///
/// సమర్థవంతమైన స్టాక్‌గా `Vec<T>` ని ఉపయోగించండి:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // 3, 2, 1 ముద్రణలు
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// `Vec` రకం సూచిక ద్వారా విలువలను యాక్సెస్ చేయడానికి అనుమతిస్తుంది, ఎందుకంటే ఇది [`Index`] trait ను అమలు చేస్తుంది.ఉదాహరణ మరింత స్పష్టంగా ఉంటుంది:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // ఇది '2' ను ప్రదర్శిస్తుంది
/// ```
///
/// అయితే జాగ్రత్తగా ఉండండి: మీరు `Vec` లో లేని సూచికను యాక్సెస్ చేయడానికి ప్రయత్నిస్తే, మీ సాఫ్ట్‌వేర్ panic అవుతుంది!మీరు దీన్ని చేయలేరు:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// మీరు ఇండెక్స్ `Vec` లో ఉందో లేదో తనిఖీ చేయాలనుకుంటే [`get`] మరియు [`get_mut`] ఉపయోగించండి.
///
/// # Slicing
///
/// `Vec` మార్చగలది.మరోవైపు, ముక్కలు చదవడానికి మాత్రమే వస్తువులు.
/// [slice][prim@slice] పొందడానికి, [`&`] ఉపయోగించండి.ఉదాహరణ:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... మరియు అంతే!
/// // మీరు దీన్ని కూడా ఇలా చేయవచ్చు:
/// let u: &[usize] = &v;
/// // లేదా ఇలా:
/// let u: &[_] = &v;
/// ```
///
/// Rust లో, మీరు చదవడానికి ప్రాప్యతను అందించాలనుకున్నప్పుడు ముక్కలను vectors కాకుండా వాదనలుగా పంపడం సర్వసాధారణం.[`String`] మరియు [`&str`] లకు కూడా అదే జరుగుతుంది.
///
/// # సామర్థ్యం మరియు తిరిగి కేటాయించడం
///
/// vector యొక్క సామర్ధ్యం ఏదైనా future మూలకాల కోసం కేటాయించిన స్థలం, ఇది vector లో చేర్చబడుతుంది.ఇది vector యొక్క *పొడవు* తో గందరగోళం చెందకూడదు, ఇది vector లోని వాస్తవ మూలకాల సంఖ్యను నిర్దేశిస్తుంది.
/// vector యొక్క పొడవు దాని సామర్థ్యాన్ని మించి ఉంటే, దాని సామర్థ్యం స్వయంచాలకంగా పెరుగుతుంది, కానీ దాని మూలకాలను తిరిగి కేటాయించవలసి ఉంటుంది.
///
/// ఉదాహరణకు, సామర్థ్యం 10 మరియు పొడవు 0 కలిగిన vector మరో 10 మూలకాలకు ఖాళీతో ఖాళీ vector అవుతుంది.vector లోకి 10 లేదా అంతకంటే తక్కువ మూలకాలను నెట్టడం దాని సామర్థ్యాన్ని మార్చదు లేదా తిరిగి కేటాయించడం జరగదు.
/// అయినప్పటికీ, vector యొక్క పొడవు 11 కి పెరిగితే, అది తిరిగి కేటాయించవలసి ఉంటుంది, ఇది నెమ్మదిగా ఉంటుంది.ఈ కారణంగా, vector ఎంత పెద్దదిగా వస్తుందో పేర్కొనడానికి సాధ్యమైనప్పుడల్లా [`Vec::with_capacity`] ను ఉపయోగించమని సిఫార్సు చేయబడింది.
///
/// # Guarantees
///
/// దాని చాలా ప్రాథమిక స్వభావం కారణంగా, `Vec` దాని డిజైన్ గురించి చాలా హామీ ఇస్తుంది.ఇది సాధారణ సందర్భంలో సాధ్యమైనంత తక్కువ-ఓవర్ హెడ్ అని నిర్ధారిస్తుంది మరియు అసురక్షిత కోడ్ ద్వారా ఆదిమ మార్గాల్లో సరిగ్గా మార్చవచ్చు.ఈ హామీలు అర్హత లేని `Vec<T>` ని సూచిస్తాయని గమనించండి.
/// అదనపు రకం పారామితులు జోడించబడితే (ఉదా., కస్టమ్ కేటాయింపుదారులకు మద్దతు ఇవ్వడానికి), వారి డిఫాల్ట్‌లను భర్తీ చేయడం ప్రవర్తనను మార్చవచ్చు.
///
/// చాలా ప్రాథమికంగా, `Vec` మరియు ఎల్లప్పుడూ (పాయింటర్, సామర్థ్యం, పొడవు) త్రిపాది.ఇక లేదు, తక్కువ కాదు.ఈ ఫీల్డ్‌ల క్రమం పూర్తిగా పేర్కొనబడలేదు మరియు వీటిని సవరించడానికి మీరు తగిన పద్ధతులను ఉపయోగించాలి.
/// పాయింటర్ ఎప్పటికీ శూన్యంగా ఉండదు, కాబట్టి ఈ రకం శూన్య-పాయింటర్-ఆప్టిమైజ్ చేయబడింది.
///
/// అయినప్పటికీ, పాయింటర్ వాస్తవానికి కేటాయించిన మెమరీని సూచించకపోవచ్చు.
/// ప్రత్యేకంగా, మీరు [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`] ద్వారా సామర్థ్యం 0 తో `Vec` ను నిర్మిస్తే లేదా ఖాళీ Vec లో [`shrink_to_fit`] కి కాల్ చేయడం ద్వారా, అది మెమరీని కేటాయించదు.అదేవిధంగా, మీరు `Vec` లోపల సున్నా-పరిమాణ రకాలను నిల్వ చేస్తే, అది వారికి స్థలాన్ని కేటాయించదు.
/// * ఈ సందర్భంలో `Vec` 0 యొక్క [`capacity`] ను నివేదించకపోవచ్చు.
/// `Vec` [`mem: : size_of::ఉంటే మాత్రమే కేటాయిస్తుంది<T>`]`() * capacity()> 0`.
/// సాధారణంగా, `Vec` యొక్క కేటాయింపు వివరాలు చాలా సూక్ష్మమైనవి-మీరు `Vec` ని ఉపయోగించి మెమరీని కేటాయించి, దానిని వేరే దేనికోసం ఉపయోగించాలనుకుంటే (అసురక్షిత కోడ్‌కు పంపడం లేదా మీ స్వంత మెమరీ-ఆధారిత సేకరణను నిర్మించడం), ఖచ్చితంగా `Vec` ను తిరిగి పొందడానికి `from_raw_parts` ను ఉపయోగించడం ద్వారా ఈ మెమరీని డీలోకేట్ చేయడానికి మరియు దానిని వదలడానికి.
///
/// ఒక `Vec`*లో* కేటాయించిన మెమరీ ఉంటే, అది సూచించే మెమరీ కుప్పలో ఉంటుంది (కేటాయింపు Rust డిఫాల్ట్‌గా ఉపయోగించడానికి కాన్ఫిగర్ చేయబడింది), మరియు దాని పాయింటర్ [`len`] ప్రారంభించిన, వరుస మూలకాలకు సూచిస్తుంది (మీరు ఏమి చేస్తారు మీరు దానిని స్లైస్‌కు బలవంతం చేశారో లేదో చూడండి), తరువాత [`సామర్థ్యం`]`,`[`లెన్`] తార్కికంగా ప్రారంభించని, పరస్పర అంశాలు.
///
///
/// సామర్థ్యం 4 తో `'a'` మరియు `'b'` మూలకాలను కలిగి ఉన్న vector ను ఈ క్రింది విధంగా చూడవచ్చు.ఎగువ భాగం `Vec` struct, ఇది కుప్ప, పొడవు మరియు సామర్థ్యంలో కేటాయింపు యొక్క తలకు పాయింటర్ కలిగి ఉంటుంది.
/// దిగువ భాగం కుప్పపై కేటాయింపు, ఇది ఒక మెమరీ బ్లాక్.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** ప్రారంభించని మెమరీని సూచిస్తుంది, [`MaybeUninit`] చూడండి.
/// - Note: ABI స్థిరంగా లేదు మరియు `Vec` దాని మెమరీ లేఅవుట్ గురించి (ఫీల్డ్ల క్రమంతో సహా) ఎటువంటి హామీ ఇవ్వదు.
///
/// `Vec` రెండు కారణాల వల్ల మూలకాలు స్టాక్‌లో నిల్వ చేయబడిన "small optimization" ని ఎప్పుడూ చేయవు:
///
/// * అసురక్షిత కోడ్ `Vec` ను సరిగ్గా మార్చడం మరింత కష్టతరం చేస్తుంది.`Vec` యొక్క కంటెంట్లకు మాత్రమే తరలించబడితే అది స్థిరమైన చిరునామాను కలిగి ఉండదు మరియు `Vec` వాస్తవానికి మెమరీని కేటాయించిందో లేదో గుర్తించడం చాలా కష్టం.
///
/// * ఇది సాధారణ కేసును జరిమానా విధిస్తుంది, ప్రతి యాక్సెస్‌లో అదనపు branch ఉంటుంది.
///
/// `Vec` పూర్తిగా ఖాళీగా ఉన్నప్పటికీ, స్వయంచాలకంగా ఎప్పటికీ కుదించదు.ఇది అనవసరమైన కేటాయింపులు లేదా తొలగింపులు జరగకుండా చూస్తుంది.`Vec` ను ఖాళీ చేసి, ఆపై అదే [`len`] వరకు తిరిగి నింపడం వల్ల కేటాయింపుదారునికి కాల్స్ రాకూడదు.మీరు ఉపయోగించని మెమరీని ఖాళీ చేయాలనుకుంటే, [`shrink_to_fit`] లేదా [`shrink_to`] ఉపయోగించండి.
///
/// [`push`] మరియు నివేదించబడిన సామర్థ్యం తగినంతగా ఉంటే [`insert`] ఎప్పటికీ (తిరిగి) కేటాయించదు.[`లెన్`]`==`[`సామర్థ్యం`] ఉంటే [`push`] మరియు [`insert`] * కేటాయిస్తాయి.అంటే, నివేదించబడిన సామర్థ్యం పూర్తిగా ఖచ్చితమైనది మరియు దానిపై ఆధారపడవచ్చు.కావాలనుకుంటే `Vec` కేటాయించిన మెమరీని మాన్యువల్‌గా విడిపించడానికి కూడా దీనిని ఉపయోగించవచ్చు.
/// బల్క్ చొప్పించే పద్ధతులు * అవసరం లేనప్పుడు కూడా తిరిగి కేటాయించవచ్చు.
///
/// `Vec` పూర్తి అయినప్పుడు లేదా [`reserve`] అని పిలిచినప్పుడు తిరిగి కేటాయించేటప్పుడు ఏదైనా నిర్దిష్ట వృద్ధి వ్యూహానికి హామీ ఇవ్వదు.ప్రస్తుత వ్యూహం ప్రాథమికమైనది మరియు స్థిరమైన వృద్ధి కారకాన్ని ఉపయోగించడం కోరదగినది.ఏ వ్యూహాన్ని ఉపయోగించినా *O*(1) రుణ విమోచన [`push`] కు హామీ ఇస్తుంది.
///
/// `vec![x; n]`, `vec![a, b, c, d]`, మరియు [`Vec::with_capacity(n)`][`Vec::with_capacity`], అన్నీ ఖచ్చితంగా అభ్యర్థించిన సామర్థ్యంతో `Vec` ను ఉత్పత్తి చేస్తాయి.
/// [`లెన్`]`==`[`సామర్థ్యం`], ([`vec!`] స్థూల మాదిరిగానే), అప్పుడు `Vec<T>` ను మూలకాలను తిరిగి కేటాయించడం లేదా తరలించకుండా [`Box<[T]>`][owned slice] కి మార్చవచ్చు.
///
/// `Vec` దాని నుండి తీసివేయబడిన ఏ డేటాను ప్రత్యేకంగా ఓవర్రైట్ చేయదు, కానీ ప్రత్యేకంగా దాన్ని సంరక్షించదు.దాని ప్రారంభించని మెమరీ స్క్రాచ్ స్థలం, అది కోరుకున్నది ఉపయోగించుకోవచ్చు.ఇది సాధారణంగా అత్యంత సమర్థవంతమైనది లేదా అమలు చేయడం సులభం.భద్రతా ప్రయోజనాల కోసం తొలగించాల్సిన డేటాపై ఆధారపడవద్దు.
/// మీరు `Vec` ను డ్రాప్ చేసినా, దాని బఫర్ మరొక `Vec` ద్వారా తిరిగి ఉపయోగించబడుతుంది.
/// మీరు మొదట `Vec` జ్ఞాపకశక్తిని సున్నా చేసినా, అది వాస్తవానికి జరగకపోవచ్చు ఎందుకంటే ఆప్టిమైజర్ దీనిని తప్పక భద్రపరచవలసిన దుష్ప్రభావంగా పరిగణించదు.
/// మేము విచ్ఛిన్నం చేయని ఒక కేసు ఉంది, అయితే: అదనపు సామర్థ్యానికి వ్రాయడానికి `unsafe` కోడ్‌ను ఉపయోగించడం, ఆపై సరిపోయే పొడవును పెంచడం ఎల్లప్పుడూ చెల్లుతుంది.
///
/// ప్రస్తుతం, `Vec` మూలకాలను వదిలివేసిన క్రమాన్ని హామీ ఇవ్వదు.
/// ఆర్డర్ గతంలో మార్చబడింది మరియు మళ్లీ మారవచ్చు.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// స్వాభావిక పద్ధతులు
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// క్రొత్త, ఖాళీ `Vec<T>` ను నిర్మిస్తుంది.
    ///
    /// మూలకాలను దానిపైకి నెట్టే వరకు vector కేటాయించదు.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// పేర్కొన్న సామర్థ్యంతో కొత్త, ఖాళీ `Vec<T>` ను నిర్మిస్తుంది.
    ///
    /// vector తిరిగి కేటాయించకుండా సరిగ్గా `capacity` మూలకాలను పట్టుకోగలదు.
    /// `capacity` 0 అయితే, vector కేటాయించదు.
    ///
    /// తిరిగి వచ్చిన vector లో *సామర్థ్యం* పేర్కొన్నప్పటికీ, vector సున్నా *పొడవు* కలిగి ఉంటుంది.
    ///
    /// పొడవు మరియు సామర్థ్యం మధ్య వ్యత్యాసం యొక్క వివరణ కోసం,*[సామర్థ్యం మరియు తిరిగి కేటాయించడం]* చూడండి.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector లో ఎక్కువ సామర్థ్యం ఉన్నప్పటికీ ఏ అంశాలు లేవు
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ఇవన్నీ తిరిగి కేటాయించకుండానే జరుగుతాయి ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... కానీ ఇది vector తిరిగి కేటాయించగలదు
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// మరొక vector యొక్క ముడి భాగాల నుండి నేరుగా `Vec<T>` ను సృష్టిస్తుంది.
    ///
    /// # Safety
    ///
    /// తనిఖీ చేయని మార్పుల సంఖ్య కారణంగా ఇది చాలా సురక్షితం కాదు:
    ///
    /// * `ptr` గతంలో [`స్ట్రింగ్`]/`Vec ద్వారా కేటాయించాల్సిన అవసరం ఉంది<T>`(కనీసం, అది కాకపోతే అది తప్పుగా ఉండే అవకాశం ఉంది).
    /// * `T` `ptr` తో కేటాయించిన దానికి సమానమైన పరిమాణం మరియు అమరిక ఉండాలి.
    ///   (తక్కువ కఠినమైన అమరిక కలిగి ఉన్న `T` సరిపోదు, [`dealloc`] అవసరాన్ని తీర్చడానికి అమరిక నిజంగా సమానంగా ఉండాలి, అదే మెమరీని కేటాయించి, అదే లేఅవుట్‌తో డీలోకేట్ చేయాలి.)
    ///
    /// * `length` `capacity` కన్నా తక్కువ లేదా సమానంగా ఉండాలి.
    /// * `capacity` పాయింటర్ కేటాయించిన సామర్థ్యం ఉండాలి.
    ///
    /// వీటిని ఉల్లంఘించడం వల్ల కేటాయింపుదారు యొక్క అంతర్గత డేటా నిర్మాణాలను భ్రష్టుపట్టడం వంటి సమస్యలు వస్తాయి.ఉదాహరణకు, X001 పొడవుతో ఒక పాయింటర్ నుండి C `char` శ్రేణికి `Vec<u8>` ను నిర్మించడం ** సురక్షితం కాదు.
    /// `Vec<u16>` మరియు దాని పొడవు నుండి ఒకదాన్ని నిర్మించడం కూడా సురక్షితం కాదు, ఎందుకంటే కేటాయింపు అమరిక గురించి పట్టించుకుంటుంది మరియు ఈ రెండు రకాలు వేర్వేరు అమరికలను కలిగి ఉంటాయి.
    /// బఫర్ అమరిక 2 (`u16` కోసం) తో కేటాయించబడింది, కానీ దానిని `Vec<u8>` గా మార్చిన తరువాత అది అమరిక 1 తో డీలోకేట్ చేయబడుతుంది.
    ///
    /// `ptr` యొక్క యాజమాన్యం `Vec<T>` కి సమర్థవంతంగా బదిలీ చేయబడుతుంది, తరువాత అది ఇష్టానుసారం పాయింటర్ సూచించిన మెమరీ విషయాలను డీలోకేట్ చేయవచ్చు, తిరిగి కేటాయించవచ్చు లేదా మార్చవచ్చు.
    /// ఈ ఫంక్షన్‌ను పిలిచిన తర్వాత మరేదీ పాయింటర్‌ను ఉపయోగించదని నిర్ధారించుకోండి.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME vec_into_raw_parts స్థిరీకరించబడినప్పుడు దీన్ని నవీకరించండి.
    ///     // `V` యొక్క డిస్ట్రక్టర్‌ను అమలు చేయడాన్ని నిరోధించండి, అందువల్ల మేము కేటాయింపుపై పూర్తి నియంత్రణలో ఉన్నాము.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v` గురించి వివిధ ముఖ్యమైన సమాచారాన్ని బయటకు తీయండి
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // 4, 5, 6 తో మెమరీని ఓవర్రైట్ చేయండి
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // ప్రతిదీ తిరిగి Vec లోకి ఉంచండి
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// క్రొత్త, ఖాళీ `Vec<T, A>` ను నిర్మిస్తుంది.
    ///
    /// మూలకాలను దానిపైకి నెట్టే వరకు vector కేటాయించదు.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// అందించిన కేటాయింపుతో పేర్కొన్న సామర్థ్యంతో కొత్త, ఖాళీ `Vec<T, A>` ను నిర్మిస్తుంది.
    ///
    /// vector తిరిగి కేటాయించకుండా సరిగ్గా `capacity` మూలకాలను పట్టుకోగలదు.
    /// `capacity` 0 అయితే, vector కేటాయించదు.
    ///
    /// తిరిగి వచ్చిన vector లో *సామర్థ్యం* పేర్కొన్నప్పటికీ, vector సున్నా *పొడవు* కలిగి ఉంటుంది.
    ///
    /// పొడవు మరియు సామర్థ్యం మధ్య వ్యత్యాసం యొక్క వివరణ కోసం,*[సామర్థ్యం మరియు తిరిగి కేటాయించడం]* చూడండి.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector లో ఎక్కువ సామర్థ్యం ఉన్నప్పటికీ ఏ అంశాలు లేవు
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ఇవన్నీ తిరిగి కేటాయించకుండానే జరుగుతాయి ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... కానీ ఇది vector తిరిగి కేటాయించగలదు
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// మరొక vector యొక్క ముడి భాగాల నుండి నేరుగా `Vec<T, A>` ను సృష్టిస్తుంది.
    ///
    /// # Safety
    ///
    /// తనిఖీ చేయని మార్పుల సంఖ్య కారణంగా ఇది చాలా సురక్షితం కాదు:
    ///
    /// * `ptr` గతంలో [`స్ట్రింగ్`]/`Vec ద్వారా కేటాయించాల్సిన అవసరం ఉంది<T>`(కనీసం, అది కాకపోతే అది తప్పుగా ఉండే అవకాశం ఉంది).
    /// * `T` `ptr` తో కేటాయించిన దానికి సమానమైన పరిమాణం మరియు అమరిక ఉండాలి.
    ///   (తక్కువ కఠినమైన అమరిక కలిగి ఉన్న `T` సరిపోదు, [`dealloc`] అవసరాన్ని తీర్చడానికి అమరిక నిజంగా సమానంగా ఉండాలి, అదే మెమరీని కేటాయించి, అదే లేఅవుట్‌తో డీలోకేట్ చేయాలి.)
    ///
    /// * `length` `capacity` కన్నా తక్కువ లేదా సమానంగా ఉండాలి.
    /// * `capacity` పాయింటర్ కేటాయించిన సామర్థ్యం ఉండాలి.
    ///
    /// వీటిని ఉల్లంఘించడం వల్ల కేటాయింపుదారు యొక్క అంతర్గత డేటా నిర్మాణాలను భ్రష్టుపట్టడం వంటి సమస్యలు వస్తాయి.ఉదాహరణకు, X001 పొడవుతో ఒక పాయింటర్ నుండి C `char` శ్రేణికి `Vec<u8>` ను నిర్మించడం ** సురక్షితం కాదు.
    /// `Vec<u16>` మరియు దాని పొడవు నుండి ఒకదాన్ని నిర్మించడం కూడా సురక్షితం కాదు, ఎందుకంటే కేటాయింపు అమరిక గురించి పట్టించుకుంటుంది మరియు ఈ రెండు రకాలు వేర్వేరు అమరికలను కలిగి ఉంటాయి.
    /// బఫర్ అమరిక 2 (`u16` కోసం) తో కేటాయించబడింది, కానీ దానిని `Vec<u8>` గా మార్చిన తరువాత అది అమరిక 1 తో డీలోకేట్ చేయబడుతుంది.
    ///
    /// `ptr` యొక్క యాజమాన్యం `Vec<T>` కి సమర్థవంతంగా బదిలీ చేయబడుతుంది, తరువాత అది ఇష్టానుసారం పాయింటర్ సూచించిన మెమరీ విషయాలను డీలోకేట్ చేయవచ్చు, తిరిగి కేటాయించవచ్చు లేదా మార్చవచ్చు.
    /// ఈ ఫంక్షన్‌ను పిలిచిన తర్వాత మరేదీ పాయింటర్‌ను ఉపయోగించదని నిర్ధారించుకోండి.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME vec_into_raw_parts స్థిరీకరించబడినప్పుడు దీన్ని నవీకరించండి.
    ///     // `V` యొక్క డిస్ట్రక్టర్‌ను అమలు చేయడాన్ని నిరోధించండి, అందువల్ల మేము కేటాయింపుపై పూర్తి నియంత్రణలో ఉన్నాము.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v` గురించి వివిధ ముఖ్యమైన సమాచారాన్ని బయటకు తీయండి
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // 4, 5, 6 తో మెమరీని ఓవర్రైట్ చేయండి
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // ప్రతిదీ తిరిగి Vec లోకి ఉంచండి
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// `Vec<T>` ను దాని ముడి భాగాలుగా కుళ్ళిపోతుంది.
    ///
    /// ముడి పాయింటర్‌ను అంతర్లీన డేటాకు, vector యొక్క పొడవు (మూలకాలలో) మరియు డేటా యొక్క కేటాయించిన సామర్థ్యం (మూలకాలలో) అందిస్తుంది.
    /// ఇవి [`from_raw_parts`] కు వాదనలు అదే క్రమంలో ఉంటాయి.
    ///
    /// ఈ ఫంక్షన్‌కు కాల్ చేసిన తరువాత, గతంలో `Vec` చేత నిర్వహించబడే మెమరీకి కాలర్ బాధ్యత వహిస్తాడు.
    /// ముడి పాయింటర్, పొడవు మరియు సామర్థ్యాన్ని [`from_raw_parts`] ఫంక్షన్‌తో తిరిగి `Vec` గా మార్చడం దీనికి ఏకైక మార్గం, ఇది డిస్ట్రక్టర్ శుభ్రపరిచే పనిని అనుమతిస్తుంది.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // ముడి పాయింటర్‌ను అనుకూల రకానికి మార్చడం వంటి భాగాలకు మేము ఇప్పుడు మార్పులు చేయవచ్చు.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// `Vec<T>` ను దాని ముడి భాగాలుగా కుళ్ళిపోతుంది.
    ///
    /// ముడి పాయింటర్‌ను అంతర్లీన డేటాకు, vector (మూలకాలలో), డేటా యొక్క కేటాయించిన సామర్థ్యం (మూలకాలలో) మరియు కేటాయింపుకు తిరిగి ఇస్తుంది.
    /// ఇవి [`from_raw_parts_in`] కు వాదనలు అదే క్రమంలో ఉంటాయి.
    ///
    /// ఈ ఫంక్షన్‌కు కాల్ చేసిన తరువాత, గతంలో `Vec` చేత నిర్వహించబడే మెమరీకి కాలర్ బాధ్యత వహిస్తాడు.
    /// ముడి పాయింటర్, పొడవు మరియు సామర్థ్యాన్ని [`from_raw_parts_in`] ఫంక్షన్‌తో తిరిగి `Vec` గా మార్చడం దీనికి ఏకైక మార్గం, ఇది డిస్ట్రక్టర్ శుభ్రపరిచే పనిని అనుమతిస్తుంది.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // ముడి పాయింటర్‌ను అనుకూల రకానికి మార్చడం వంటి భాగాలకు మేము ఇప్పుడు మార్పులు చేయవచ్చు.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// తిరిగి కేటాయించకుండా vector పట్టుకోగల మూలకాల సంఖ్యను అందిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// ఇచ్చిన `Vec<T>` లో చేర్చడానికి కనీసం `additional` మరిన్ని మూలకాలకు నిల్వ నిల్వ సామర్థ్యం.
    /// తరచుగా తిరిగి కేటాయించకుండా ఉండటానికి సేకరణ ఎక్కువ స్థలాన్ని కేటాయించవచ్చు.
    /// `reserve` కి కాల్ చేసిన తరువాత, సామర్థ్యం `self.len() + additional` కన్నా ఎక్కువ లేదా సమానంగా ఉంటుంది.
    /// సామర్థ్యం ఇప్పటికే సరిపోతుంటే ఏమీ చేయదు.
    ///
    /// # Panics
    ///
    /// కొత్త సామర్థ్యం `isize::MAX` బైట్‌లను మించి ఉంటే Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// ఇచ్చిన `Vec<T>` లో ఖచ్చితంగా `additional` మరిన్ని మూలకాలను చేర్చడానికి కనీస సామర్థ్యాన్ని కలిగి ఉంది.
    ///
    /// `reserve_exact` కి కాల్ చేసిన తరువాత, సామర్థ్యం `self.len() + additional` కన్నా ఎక్కువ లేదా సమానంగా ఉంటుంది.
    /// సామర్థ్యం ఇప్పటికే సరిపోతుంటే ఏమీ చేయదు.
    ///
    /// కేటాయింపుదారుడు కోరిన దానికంటే ఎక్కువ స్థలాన్ని ఇవ్వవచ్చని గమనించండి.
    /// అందువల్ల, సామర్థ్యం ఖచ్చితంగా తక్కువగా ఉండటానికి ఆధారపడదు.
    /// future చొప్పనలు if హించినట్లయితే `reserve` కి ప్రాధాన్యత ఇవ్వండి.
    ///
    /// # Panics
    ///
    /// కొత్త సామర్థ్యం `usize` ని పొంగిపోతే Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// ఇచ్చిన `Vec<T>` లో చేర్చడానికి కనీసం `additional` మరిన్ని మూలకాల కోసం సామర్థ్యాన్ని రిజర్వ్ చేయడానికి ప్రయత్నిస్తుంది.
    /// తరచుగా తిరిగి కేటాయించకుండా ఉండటానికి సేకరణ ఎక్కువ స్థలాన్ని కేటాయించవచ్చు.
    /// `try_reserve` కి కాల్ చేసిన తరువాత, సామర్థ్యం `self.len() + additional` కన్నా ఎక్కువ లేదా సమానంగా ఉంటుంది.
    /// సామర్థ్యం ఇప్పటికే సరిపోతుంటే ఏమీ చేయదు.
    ///
    /// # Errors
    ///
    /// సామర్థ్యం పొంగిపొర్లుతుంటే, లేదా కేటాయింపుదారుడు వైఫల్యాన్ని నివేదించినట్లయితే, లోపం తిరిగి వస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // జ్ఞాపకశక్తిని ముందుగా రిజర్వ్ చేయండి, మనం చేయలేకపోతే నిష్క్రమిస్తుంది
    ///     output.try_reserve(data.len())?;
    ///
    ///     // మా సంక్లిష్ట పని మధ్యలో ఇది OOM కాదని ఇప్పుడు మనకు తెలుసు
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // చాలా క్లిష్టంగా ఉంటుంది
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// ఇచ్చిన `Vec<T>` లో ఖచ్చితంగా `additional` మూలకాలను చేర్చడానికి కనీస సామర్థ్యాన్ని కేటాయించడానికి ప్రయత్నిస్తుంది.
    /// `try_reserve_exact` కి కాల్ చేసిన తరువాత, `Ok(())` ను తిరిగి ఇస్తే సామర్థ్యం `self.len() + additional` కన్నా ఎక్కువ లేదా సమానంగా ఉంటుంది.
    ///
    /// సామర్థ్యం ఇప్పటికే సరిపోతుంటే ఏమీ చేయదు.
    ///
    /// కేటాయింపుదారుడు కోరిన దానికంటే ఎక్కువ స్థలాన్ని ఇవ్వవచ్చని గమనించండి.
    /// అందువల్ల, సామర్థ్యం ఖచ్చితంగా తక్కువగా ఉండటానికి ఆధారపడదు.
    /// future చొప్పనలు if హించినట్లయితే `reserve` కి ప్రాధాన్యత ఇవ్వండి.
    ///
    /// # Errors
    ///
    /// సామర్థ్యం పొంగిపొర్లుతుంటే, లేదా కేటాయింపుదారుడు వైఫల్యాన్ని నివేదించినట్లయితే, లోపం తిరిగి వస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // జ్ఞాపకశక్తిని ముందుగా రిజర్వ్ చేయండి, మనం చేయలేకపోతే నిష్క్రమిస్తుంది
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // మా సంక్లిష్ట పని మధ్యలో ఇది OOM కాదని ఇప్పుడు మనకు తెలుసు
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // చాలా క్లిష్టంగా ఉంటుంది
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// vector యొక్క సామర్థ్యాన్ని సాధ్యమైనంత తగ్గిస్తుంది.
    ///
    /// ఇది పొడవుకు సాధ్యమైనంత దగ్గరగా పడిపోతుంది, అయితే మరికొన్ని మూలకాలకు స్థలం ఉందని కేటాయింపుదారుడు ఇప్పటికీ vector కి తెలియజేయవచ్చు.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // సామర్థ్యం ఎప్పుడూ పొడవు కంటే తక్కువ కాదు, అవి సమానంగా ఉన్నప్పుడు ఏమీ చేయలేము, కాబట్టి `RawVec::shrink_to_fit` లో panic కేసును ఎక్కువ సామర్థ్యంతో మాత్రమే పిలవడం ద్వారా మనం నివారించవచ్చు.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// vector యొక్క సామర్థ్యాన్ని తక్కువ బౌండ్‌తో తగ్గిస్తుంది.
    ///
    /// సామర్థ్యం పొడవు మరియు సరఫరా విలువ రెండింటికీ కనీసం పెద్దదిగా ఉంటుంది.
    ///
    ///
    /// ప్రస్తుత సామర్థ్యం తక్కువ పరిమితి కంటే తక్కువగా ఉంటే, ఇది నో-ఆప్.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// vector ను [`Box<[T]>`][owned slice] గా మారుస్తుంది.
    ///
    /// ఇది ఏదైనా అదనపు సామర్థ్యాన్ని తగ్గిస్తుందని గమనించండి.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// ఏదైనా అదనపు సామర్థ్యం తొలగించబడుతుంది:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// vector ను తగ్గిస్తుంది, మొదటి `len` మూలకాలను ఉంచుతుంది మరియు మిగిలిన వాటిని వదిలివేస్తుంది.
    ///
    /// `len` vector యొక్క ప్రస్తుత పొడవు కంటే ఎక్కువగా ఉంటే, దీని ప్రభావం ఉండదు.
    ///
    /// [`drain`] పద్ధతి `truncate` ను అనుకరించగలదు, కాని పడిపోయిన బదులు అదనపు మూలకాలను తిరిగి ఇస్తుంది.
    ///
    ///
    /// ఈ పద్ధతి vector యొక్క కేటాయించిన సామర్థ్యంపై ప్రభావం చూపదని గమనించండి.
    ///
    /// # Examples
    ///
    /// ఐదు మూలకం vector ను రెండు మూలకాలకు కత్తిరించడం:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// 0vector యొక్క ప్రస్తుత పొడవు కంటే `len` ఎక్కువగా ఉన్నప్పుడు కత్తిరించడం జరగదు:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// `len == 0` [`clear`] పద్ధతిని పిలవడానికి సమానమైనప్పుడు కత్తిరించడం.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // ఇది సురక్షితం ఎందుకంటే:
        //
        // * `drop_in_place` కి పంపిన స్లైస్ చెల్లుతుంది;`len > self.len` కేసు చెల్లని స్లైస్‌ని సృష్టించడాన్ని నివారిస్తుంది మరియు
        // * `drop_in_place` కి కాల్ చేయడానికి ముందు vector యొక్క `len` కుదించబడుతుంది, అంటే `drop_in_place` ఒకసారి panic కు ఉంటే రెండుసార్లు విలువ పడిపోదు (ఇది panics రెండుసార్లు ఉంటే, ప్రోగ్రామ్ ఆగిపోతుంది).
        //
        //
        //
        unsafe {
            // Note: ఇది `>` మరియు `>=` కాదని ఉద్దేశపూర్వకంగా ఉంది.
            //       దీన్ని `>=` కి మార్చడం కొన్ని సందర్భాల్లో ప్రతికూల పనితీరు చిక్కులను కలిగి ఉంటుంది.
            //       మరిన్ని కోసం #78884 చూడండి.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// మొత్తం vector కలిగి ఉన్న స్లైస్‌ని సంగ్రహిస్తుంది.
    ///
    /// `&s[..]` కి సమానం.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// మొత్తం vector యొక్క మార్చగల స్లైస్‌ని సంగ్రహిస్తుంది.
    ///
    /// `&mut s[..]` కి సమానం.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// ముడి పాయింటర్‌ను vector యొక్క బఫర్‌కు అందిస్తుంది.
    ///
    /// ఈ ఫంక్షన్ తిరిగి ఇచ్చే పాయింటర్‌ను vector మించిపోతుందని కాలర్ నిర్ధారించాలి, లేకుంటే అది చెత్తకు గురి అవుతుంది.
    /// vector ను సవరించడం వలన దాని బఫర్ తిరిగి కేటాయించబడవచ్చు, దీనికి ఏదైనా పాయింటర్లు కూడా చెల్లవు.
    ///
    /// ఈ పాయింటర్ లేదా దాని నుండి పొందిన ఏదైనా పాయింటర్‌ను ఉపయోగించి పాయింటర్ (non-transitively) సూచించే మెమరీకి (`UnsafeCell` లోపల తప్ప) ఎప్పుడూ వ్రాయబడలేదని కాలర్ నిర్ధారించాలి.
    /// మీరు స్లైస్ యొక్క విషయాలను మార్చాల్సిన అవసరం ఉంటే, [`as_mut_ptr`] ను ఉపయోగించండి.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // `deref` ద్వారా వెళ్ళకుండా ఉండటానికి మేము అదే పేరుతో స్లైస్ పద్ధతిని నీడ చేస్తాము, ఇది ఇంటర్మీడియట్ సూచనను సృష్టిస్తుంది.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// vector యొక్క బఫర్‌కు అసురక్షిత మ్యూటబుల్ పాయింటర్‌ను చూపుతుంది.
    ///
    /// ఈ ఫంక్షన్ తిరిగి ఇచ్చే పాయింటర్‌ను vector మించిపోతుందని కాలర్ నిర్ధారించాలి, లేకుంటే అది చెత్తకు గురి అవుతుంది.
    ///
    /// vector ను సవరించడం వలన దాని బఫర్ తిరిగి కేటాయించబడవచ్చు, దీనికి ఏదైనా పాయింటర్లు కూడా చెల్లవు.
    ///
    /// # Examples
    ///
    /// ```
    /// // vector ను 4 మూలకాలకు పెద్దదిగా కేటాయించండి.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // ముడి పాయింటర్ రచనల ద్వారా మూలకాలను ప్రారంభించండి, ఆపై పొడవును సెట్ చేయండి.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // `deref_mut` ద్వారా వెళ్ళకుండా ఉండటానికి మేము అదే పేరుతో స్లైస్ పద్ధతిని నీడ చేస్తాము, ఇది ఇంటర్మీడియట్ సూచనను సృష్టిస్తుంది.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// అంతర్లీన కేటాయింపుకు సూచనను అందిస్తుంది.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// vector యొక్క పొడవును `new_len` కు బలవంతం చేస్తుంది.
    ///
    /// ఇది తక్కువ-స్థాయి ఆపరేషన్, ఇది రకం యొక్క సాధారణ మార్పులను ఏదీ నిర్వహించదు.
    /// సాధారణంగా vector యొక్క పొడవును మార్చడం బదులుగా [`truncate`], [`resize`], [`extend`] లేదా [`clear`] వంటి సురక్షితమైన ఆపరేషన్లలో ఒకదాన్ని ఉపయోగించి జరుగుతుంది.
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` [`capacity()`] కన్నా తక్కువ లేదా సమానంగా ఉండాలి.
    /// - `old_len..new_len` లోని మూలకాలను తప్పనిసరిగా ప్రారంభించాలి.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// vector ఇతర కోడ్‌లకు, ముఖ్యంగా FFI ద్వారా బఫర్‌గా పనిచేస్తున్న పరిస్థితులకు ఈ పద్ధతి ఉపయోగపడుతుంది:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // పత్రం ఉదాహరణకి ఇది కనీస అస్థిపంజరం;
    /// # // నిజమైన లైబ్రరీకి ప్రారంభ బిందువుగా దీన్ని ఉపయోగించవద్దు.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // FFI పద్ధతి యొక్క డాక్స్ ప్రకారం, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // భద్రత: `deflateGetDictionary` `Z_OK` ను తిరిగి ఇచ్చినప్పుడు, అది ఇలా ఉంటుంది:
    ///     // 1. `dict_length` అంశాలు ప్రారంభించబడ్డాయి.
    ///     // 2.
    ///     // `dict_length` <=సామర్థ్యం (32_768), ఇది `set_len` ని కాల్ చేయడానికి సురక్షితంగా చేస్తుంది.
    ///     unsafe {
    ///         // FFI కాల్ చేయండి ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... మరియు ప్రారంభించిన వాటికి పొడవును నవీకరించండి.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// కింది ఉదాహరణ ధ్వని అయితే, `set_len` కాల్‌కు ముందు లోపలి vectors విముక్తి పొందనందున మెమరీ లీక్ ఉంది:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` ఖాళీగా ఉంది కాబట్టి మూలకాలను ప్రారంభించాల్సిన అవసరం లేదు.
    /// // 2. `0 <= capacity` ఎల్లప్పుడూ `capacity` ఏమైనా కలిగి ఉంటుంది.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// సాధారణంగా, ఇక్కడ, విషయాలను సరిగ్గా వదలడానికి బదులుగా [`clear`] ను ఉపయోగిస్తుంది మరియు తద్వారా మెమరీ లీక్ అవ్వదు.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// vector నుండి ఒక మూలకాన్ని తీసివేసి దానిని తిరిగి ఇస్తుంది.
    ///
    /// తొలగించబడిన మూలకం vector యొక్క చివరి మూలకం ద్వారా భర్తీ చేయబడుతుంది.
    ///
    /// ఇది ఆర్డరింగ్‌ను సంరక్షించదు, కానీ O(1).
    ///
    /// # Panics
    ///
    /// `index` హద్దులు దాటితే Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // మేము స్వీయ [సూచిక] ను చివరి మూలకంతో భర్తీ చేస్తాము.
            // పైన ఉన్న హద్దుల తనిఖీ విజయవంతమైతే చివరి మూలకం ఉండాలి (ఇది స్వీయ [సూచిక] కావచ్చు).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// vector లోపల `index` స్థానంలో ఒక మూలకాన్ని చొప్పించి, దాని తర్వాత అన్ని మూలకాలను కుడి వైపుకు మారుస్తుంది.
    ///
    ///
    /// # Panics
    ///
    /// `index > len` ఉంటే Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // క్రొత్త మూలకం కోసం స్థలం
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // తప్పులేనిది క్రొత్త విలువను ఉంచే ప్రదేశం
            //
            {
                let p = self.as_mut_ptr().add(index);
                // స్థలం చేయడానికి ప్రతిదీ మార్చండి.
                // (`ఇండెక్స్` మూలకాన్ని వరుసగా రెండు ప్రదేశాలకు నకిలీ చేస్తుంది.)
                ptr::copy(p, p.offset(1), len - index);
                // `ఇండెక్స్` మూలకం యొక్క మొదటి కాపీని తిరిగి రాస్తూ, దీన్ని వ్రాయండి.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// vector లోపల `index` స్థానంలో ఉన్న మూలకాన్ని తీసివేస్తుంది మరియు తిరిగి ఇస్తుంది, దాని తర్వాత అన్ని మూలకాలను ఎడమ వైపుకు మారుస్తుంది.
    ///
    ///
    /// # Panics
    ///
    /// `index` హద్దులు దాటితే Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // మేము తీసుకుంటున్న స్థలం.
                let ptr = self.as_mut_ptr().add(index);
                // స్టాక్‌పై మరియు అదే సమయంలో vector లో విలువ యొక్క కాపీని సురక్షితంగా కలిగి ఉండండి.
                //
                ret = ptr::read(ptr);

                // ఆ స్థలాన్ని పూరించడానికి ప్రతిదీ క్రిందికి మార్చండి.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// ప్రిడికేట్ పేర్కొన్న అంశాలను మాత్రమే కలిగి ఉంటుంది.
    ///
    /// మరో మాటలో చెప్పాలంటే, `e` అన్ని మూలకాలను తొలగించండి, అంటే `f(&e)` `false` ను తిరిగి ఇస్తుంది.
    /// ఈ పద్ధతి స్థలంలో పనిచేస్తుంది, ప్రతి మూలకాన్ని అసలు క్రమంలో ఒకసారి సందర్శిస్తుంది మరియు నిలుపుకున్న మూలకాల క్రమాన్ని సంరక్షిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// మూలకాలను అసలు క్రమంలో సరిగ్గా ఒకసారి సందర్శించినందున, ఏ అంశాలను ఉంచాలో నిర్ణయించడానికి బాహ్య స్థితిని ఉపయోగించవచ్చు.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // డ్రాప్ గార్డ్ అమలు చేయకపోతే డబుల్ డ్రాప్ మానుకోండి, ఎందుకంటే ఈ ప్రక్రియలో మేము కొన్ని రంధ్రాలు చేయవచ్చు.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-ప్రాసెస్ చేసిన లెన్-> |^-తనిఖీ చేయడానికి పక్కన
        //                  | <-తొలగించబడింది cnt-> |
        //      | <-ఒరిజినల్_లెన్-> |ఉంచారు: రిటర్న్‌లను నిజమైనదిగా అంచనా వేసే అంశాలు.
        //
        // రంధ్రం: మూలకం స్లాట్ తరలించబడింది లేదా పడిపోయింది.
        // ఎంపిక చేయబడలేదు: చెక్ చేయని చెల్లుబాటు అయ్యే అంశాలు.
        //
        // మూలకం యొక్క icate హించినప్పుడు లేదా `drop` భయపడినప్పుడు ఈ డ్రాప్ గార్డ్ ప్రారంభించబడుతుంది.
        // ఇది రంధ్రాలను కవర్ చేయడానికి తనిఖీ చేయని అంశాలను మరియు సరైన పొడవుకు `set_len` ని మారుస్తుంది.
        // ప్రిడికేట్ మరియు `drop` ఎప్పుడూ భయపడనప్పుడు, ఇది ఆప్టిమైజ్ అవుతుంది.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // భద్రత: తనిఖీ చేయని వస్తువులను వెనుకంజలో ఉంచడం వల్ల మేము వాటిని ఎప్పుడూ తాకకూడదు.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // భద్రత: రంధ్రాలను నింపిన తరువాత, అన్ని అంశాలు పరస్పర జ్ఞాపకశక్తిలో ఉంటాయి.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // భద్రత: తనిఖీ చేయని మూలకం తప్పనిసరిగా చెల్లుబాటులో ఉండాలి.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // `drop_in_place` భయపడితే డబుల్ డ్రాప్ నివారించడానికి ముందుగానే ముందుకు సాగండి.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // భద్రత: పడిపోయిన తర్వాత మేము ఈ మూలకాన్ని మళ్లీ తాకము.
                unsafe { ptr::drop_in_place(cur) };
                // మేము ఇప్పటికే కౌంటర్ను ముందుకు తీసుకువెళ్ళాము.
                continue;
            }
            if g.deleted_cnt > 0 {
                // భద్రత: `deleted_cnt`> 0, కాబట్టి రంధ్రం స్లాట్ ప్రస్తుత మూలకంతో అతివ్యాప్తి చెందకూడదు.
                // మేము కదలిక కోసం కాపీని ఉపయోగిస్తాము మరియు ఈ మూలకాన్ని మళ్లీ తాకవద్దు.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // అన్ని అంశం ప్రాసెస్ చేయబడింది.దీన్ని LLVM ద్వారా `set_len` కు ఆప్టిమైజ్ చేయవచ్చు.
        drop(g);
    }

    /// ఒకే కీకి పరిష్కరించే vector లోని వరుస మూలకాలలో మొదటిది తప్ప అన్నింటినీ తొలగిస్తుంది.
    ///
    ///
    /// vector క్రమబద్ధీకరించబడితే, ఇది అన్ని నకిలీలను తొలగిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// ఇచ్చిన సమానత్వ సంబంధాన్ని సంతృప్తిపరిచే vector లోని వరుస మూలకాలలో మొదటిది తప్ప అన్నింటినీ తొలగిస్తుంది.
    ///
    /// `same_bucket` ఫంక్షన్ vector నుండి రెండు మూలకాలకు సూచనలు ఇవ్వబడుతుంది మరియు మూలకాలు సమానంగా ఉన్నాయో లేదో నిర్ణయించాలి.
    /// స్లైస్‌లో వాటి క్రమం నుండి మూలకాలు వ్యతిరేక క్రమంలో పంపబడతాయి, కాబట్టి `same_bucket(a, b)` `true` ను తిరిగి ఇస్తే, `a` తొలగించబడుతుంది.
    ///
    ///
    /// vector క్రమబద్ధీకరించబడితే, ఇది అన్ని నకిలీలను తొలగిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// సేకరణ వెనుక భాగంలో ఒక మూలకాన్ని జోడిస్తుంది.
    ///
    /// # Panics
    ///
    /// కొత్త సామర్థ్యం `isize::MAX` బైట్‌లను మించి ఉంటే Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // మేము> isize::MAX బైట్‌లను కేటాయిస్తే లేదా సున్నా-పరిమాణ రకాల కోసం పొడవు పెరుగుదల పొంగిపొర్లుతుంటే ఇది panic లేదా ఆగిపోతుంది.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// vector నుండి చివరి మూలకాన్ని తీసివేసి, దానిని తిరిగి ఇస్తుంది, లేదా [`None`] ఖాళీగా ఉంటే.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// `other` యొక్క అన్ని మూలకాలను `Self` లోకి కదిలిస్తుంది, `other` ఖాళీగా ఉంటుంది.
    ///
    /// # Panics
    ///
    /// vector లోని మూలకాల సంఖ్య `usize` ని పొంగిపోతే Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// ఇతర బఫర్ నుండి `Self` కు మూలకాలను జోడిస్తుంది.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// vector లో పేర్కొన్న పరిధిని తీసివేసి, తీసివేసిన వస్తువులను ఇస్తుంది.
    ///
    /// ఇరేటర్ ** పడిపోయినప్పుడు, పరిధిలోని అన్ని అంశాలు vector నుండి తొలగించబడతాయి, ఇరేటర్ పూర్తిగా వినియోగించబడకపోయినా.
    /// ఇటేరేటర్ **పడిపోకపోతే**(ఉదాహరణకు [`mem::forget`] తో), ఎన్ని అంశాలు తొలగించబడతాయో పేర్కొనబడలేదు.
    ///
    /// # Panics
    ///
    /// ప్రారంభ స్థానం ముగింపు బిందువు కంటే ఎక్కువగా ఉంటే లేదా ముగింపు స్థానం vector పొడవు కంటే ఎక్కువగా ఉంటే Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // పూర్తి శ్రేణి vector ని క్లియర్ చేస్తుంది
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // మెమరీ భద్రత
        //
        // Drain మొదట సృష్టించబడినప్పుడు, Drain యొక్క డిస్ట్రక్టర్ ఎప్పటికీ అమలు చేయకపోతే, ప్రారంభించని లేదా తరలించబడిన మూలకాలు ఏవీ అందుబాటులో ఉండవని నిర్ధారించడానికి ఇది మూలం vector యొక్క పొడవును తగ్గిస్తుంది.
        //
        //
        // Drain తొలగించడానికి విలువలను ptr::read చేస్తుంది.
        // పూర్తయినప్పుడు, రంధ్రం కవర్ చేయడానికి వెక్ యొక్క మిగిలిన తోక తిరిగి కాపీ చేయబడుతుంది మరియు vector పొడవు కొత్త పొడవుకు పునరుద్ధరించబడుతుంది.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // Drain లీక్ అయినప్పుడు సురక్షితంగా ఉండటానికి self.vec పొడవును ప్రారంభించండి
            self.set_len(start);
            // మొత్తం Drain ఇటరేటర్ (&mut T వంటి) యొక్క రుణాలు తీసుకునే ప్రవర్తనను సూచించడానికి ఐటర్‌మట్‌లోని రుణాన్ని ఉపయోగించండి.
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// vector ని క్లియర్ చేస్తుంది, అన్ని విలువలను తొలగిస్తుంది.
    ///
    /// ఈ పద్ధతి vector యొక్క కేటాయించిన సామర్థ్యంపై ప్రభావం చూపదని గమనించండి.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// vector లోని మూలకాల సంఖ్యను దాని 'length' గా కూడా సూచిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// vector లో ఎలిమెంట్స్ లేకపోతే `true` ని అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ఇచ్చిన సూచిక వద్ద సేకరణను రెండుగా విభజిస్తుంది.
    ///
    /// `[at, len)` పరిధిలోని మూలకాలను కలిగి ఉన్న కొత్తగా కేటాయించిన vector ను అందిస్తుంది.
    /// కాల్ తరువాత, అసలు vector దాని మునుపటి సామర్థ్యంతో మారకుండా `[0, at)` మూలకాలను కలిగి ఉంటుంది.
    ///
    ///
    /// # Panics
    ///
    /// `at > len` ఉంటే Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // క్రొత్త vector అసలు బఫర్‌ను స్వాధీనం చేసుకోవచ్చు మరియు కాపీని నివారించవచ్చు
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // సురక్షితంగా `set_len` మరియు `other` కు అంశాలను కాపీ చేయండి.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// `Vec` స్థానంలో పున izes పరిమాణం చేస్తుంది, తద్వారా `len` `new_len` కి సమానం.
    ///
    /// `new_len` `len` కన్నా ఎక్కువగా ఉంటే, `Vec` వ్యత్యాసం ద్వారా విస్తరించబడుతుంది, ప్రతి అదనపు స్లాట్ మూసివేత `f` అని పిలిచే ఫలితంతో నిండి ఉంటుంది.
    ///
    /// `f` నుండి తిరిగి వచ్చే విలువలు అవి ఉత్పత్తి చేయబడిన క్రమంలో `Vec` లో ముగుస్తాయి.
    ///
    /// `new_len` `len` కన్నా తక్కువగా ఉంటే, `Vec` కేవలం కత్తిరించబడుతుంది.
    ///
    /// ఈ పద్ధతి ప్రతి పుష్లో క్రొత్త విలువలను సృష్టించడానికి మూసివేతను ఉపయోగిస్తుంది.మీరు ఇచ్చిన విలువను [`Clone`] కాకుండా, [`Vec::resize`] ఉపయోగించండి.
    /// విలువలను ఉత్పత్తి చేయడానికి మీరు [`Default`] trait ను ఉపయోగించాలనుకుంటే, మీరు [`Default::default`] ను రెండవ ఆర్గ్యుమెంట్‌గా పాస్ చేయవచ్చు.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// `Vec` ను వినియోగిస్తుంది మరియు లీక్ చేస్తుంది, విషయాలకు మార్చగల సూచనను తిరిగి ఇస్తుంది, `&'a mut [T]`.
    /// `T` రకం ఎంచుకున్న జీవితకాలం `'a` ను మించి ఉండాలి.
    /// రకానికి స్టాటిక్ రిఫరెన్సులు మాత్రమే ఉంటే, లేదా ఏదీ లేకపోతే, ఇది `'static` గా ఎంచుకోవచ్చు.
    ///
    /// ఈ ఫంక్షన్ [`Box`] లోని [`leak`][Box::leak] ఫంక్షన్‌తో సమానంగా ఉంటుంది తప్ప లీక్ అయిన మెమరీని తిరిగి పొందటానికి మార్గం లేదు.
    ///
    ///
    /// ఈ ఫంక్షన్ ప్రధానంగా ప్రోగ్రామ్ యొక్క జీవితాంతం జీవించే డేటాకు ఉపయోగపడుతుంది.
    /// తిరిగి వచ్చిన సూచనను వదలడం వల్ల మెమరీ లీక్ అవుతుంది.
    ///
    /// # Examples
    ///
    /// సాధారణ ఉపయోగం:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// vector యొక్క మిగిలిన విడి సామర్థ్యాన్ని `MaybeUninit<T>` స్లైస్‌గా అందిస్తుంది.
    ///
    /// తిరిగి వచ్చిన స్లైస్‌ను vector ని డేటాతో నింపడానికి ఉపయోగించవచ్చు (ఉదా
    /// [`set_len`] పద్ధతిని ఉపయోగించి డేటాను ప్రారంభించినట్లు గుర్తించే ముందు).
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // 10 మూలకాలకు తగినంత పెద్ద vector ని కేటాయించండి.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // మొదటి 3 అంశాలను పూరించండి.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // vector యొక్క మొదటి 3 మూలకాలను ప్రారంభించినట్లు గుర్తించండి.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // బఫర్‌కు పాయింటర్లను చెల్లకుండా నిరోధించడానికి, `split_at_spare_mut` పరంగా ఈ పద్ధతి అమలు చేయబడలేదు.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// vector కంటెంట్‌ను `T` స్లైస్‌గా, vector యొక్క మిగిలిన విడి సామర్థ్యంతో పాటు `MaybeUninit<T>` స్లైస్‌గా అందిస్తుంది.
    ///
    /// [`set_len`] పద్ధతిని ఉపయోగించి డేటాను ప్రారంభించినట్లుగా గుర్తించడానికి ముందు తిరిగి వచ్చిన విడి సామర్థ్య స్లైస్‌ను డేటాతో (ఉదా. ఫైల్ నుండి చదవడం ద్వారా) నింపడానికి ఉపయోగించవచ్చు.
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// ఇది తక్కువ-స్థాయి API అని గమనించండి, ఇది ఆప్టిమైజేషన్ ప్రయోజనాల కోసం జాగ్రత్తగా ఉపయోగించాలి.
    /// మీరు `Vec` కు డేటాను జోడించాల్సిన అవసరం ఉంటే, మీ ఖచ్చితమైన అవసరాలను బట్టి మీరు [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] లేదా [`resize_with`] ను ఉపయోగించవచ్చు.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // 10 మూలకాలకు తగినంత అదనపు స్థలాన్ని రిజర్వ్ చేయండి.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // తదుపరి 4 అంశాలను పూరించండి.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // vector యొక్క 4 మూలకాలను ప్రారంభించినట్లు గుర్తించండి.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - లెన్ విస్మరించబడింది మరియు మార్చబడలేదు
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// భద్రత: తిరిగి రావడం .2 (&mut usize) ను `.set_len(_)` కి కాల్ చేసినట్లే పరిగణించబడుతుంది.
    ///
    /// `extend_from_within` లో ఒకేసారి అన్ని వెక్ భాగాలకు ప్రత్యేకమైన ప్రాప్యతను కలిగి ఉండటానికి ఈ పద్ధతి ఉపయోగించబడుతుంది.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` `len` మూలకాలకు చెల్లుబాటు అవుతుందని హామీ ఇవ్వబడింది
        // - `spare_ptr` బఫర్‌ను దాటి ఒక మూలకాన్ని సూచిస్తుంది, కాబట్టి ఇది `initialized` తో అతివ్యాప్తి చెందదు
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// `Vec` స్థానంలో పున izes పరిమాణం చేస్తుంది, తద్వారా `len` `new_len` కి సమానం.
    ///
    /// `new_len` `len` కన్నా ఎక్కువగా ఉంటే, `Vec` వ్యత్యాసం ద్వారా విస్తరించబడుతుంది, ప్రతి అదనపు స్లాట్ `value` తో నిండి ఉంటుంది.
    ///
    /// `new_len` `len` కన్నా తక్కువగా ఉంటే, `Vec` కేవలం కత్తిరించబడుతుంది.
    ///
    /// ఆమోదించిన విలువను క్లోన్ చేయగలిగేలా చేయడానికి, ఈ పద్ధతికి [`Clone`] ను అమలు చేయడానికి `T` అవసరం.
    /// మీకు మరింత సౌలభ్యం అవసరమైతే (లేదా [`Clone`] కు బదులుగా [`Default`] పై ఆధారపడాలనుకుంటే), [`Vec::resize_with`] ని ఉపయోగించండి.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// స్లైస్‌లోని అన్ని మూలకాలను `Vec` కు క్లోన్ చేస్తుంది మరియు జోడిస్తుంది.
    ///
    /// `other` స్లైస్‌పై మళ్ళిస్తుంది, ప్రతి మూలకాన్ని క్లోన్ చేస్తుంది, ఆపై దానిని ఈ `Vec` కు జోడిస్తుంది.
    /// `other` vector క్రమంలో ప్రయాణిస్తుంది.
    ///
    /// ఈ ఫంక్షన్ [`extend`] వలె ఉంటుందని గమనించండి, బదులుగా ముక్కలతో పనిచేయడం ప్రత్యేకమైనది.
    ///
    /// Rust స్పెషలైజేషన్ పొందినప్పుడు మరియు ఈ ఫంక్షన్ నిలిపివేయబడుతుంది (కానీ ఇప్పటికీ అందుబాటులో ఉంది).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// `src` పరిధి నుండి vector చివరి వరకు మూలకాలను కాపీ చేస్తుంది.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` స్వీయ సూచిక కోసం ఇచ్చిన పరిధి చెల్లుతుందని హామీ ఇస్తుంది
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// ఈ కోడ్ `extend_with_{element,default}` ను సాధారణీకరిస్తుంది.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// ఇచ్చిన జెనరేటర్ ఉపయోగించి, 0vector ను `n` విలువల ద్వారా విస్తరించండి.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // బగ్ చుట్టూ పనిచేయడానికి సెట్‌లెన్ఆన్‌డ్రాప్‌ను ఉపయోగించండి, ఇక్కడ కంపైలర్ `ptr` ద్వారా self.set_len() ద్వారా స్టోర్‌ను గ్రహించకపోవచ్చు.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // చివరిది మినహా అన్ని అంశాలను వ్రాయండి
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // next() panics విషయంలో ప్రతి దశలో పొడవును పెంచండి
                local_len.increment_len(1);
            }

            if n > 0 {
                // అనవసరంగా క్లోనింగ్ చేయకుండా మనం చివరి మూలకాన్ని నేరుగా వ్రాయవచ్చు
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // స్కోప్ గార్డ్ చేత లెన్ సెట్ చేయబడింది
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// [`PartialEq`] trait అమలు ప్రకారం vector లో వరుసగా పునరావృతమయ్యే అంశాలను తొలగిస్తుంది.
    ///
    ///
    /// vector క్రమబద్ధీకరించబడితే, ఇది అన్ని నకిలీలను తొలగిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// అంతర్గత పద్ధతులు మరియు విధులు
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` చెల్లుబాటు అయ్యే సూచిక కావాలి
    /// - `self.capacity() - self.len()` `>= src.len()` ఉండాలి
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - మూలకాలను ప్రారంభించిన తర్వాతే లెన్ పెరుగుతుంది
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - src చెల్లుబాటు అయ్యే సూచిక అని కాలర్ హామీ ఇస్తుంది
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - ఎలిమెంట్ కేవలం `MaybeUninit::write` తో ప్రారంభించబడింది, కాబట్టి లెన్ పెంచడం సరే
            // - లీక్‌లను నివారించడానికి ప్రతి మూలకం తర్వాత లెన్ పెరుగుతుంది (ఇష్యూ #82533 చూడండి)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - `src` చెల్లుబాటు అయ్యే సూచిక అని కాలర్ హామీ ఇస్తుంది
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - రెండు పాయింటర్లు ప్రత్యేకమైన స్లైస్ రిఫరెన్సుల నుండి సృష్టించబడతాయి (`&మ్యూట్ [_]`) కాబట్టి అవి చెల్లుతాయి మరియు అతివ్యాప్తి చెందవు.
            //
            // - అంశాలు: కాపీ చేయండి కాబట్టి అసలు విలువలతో ఏమీ చేయకుండా వాటిని కాపీ చేయడం సరే
            // - `count` `source` యొక్క లెన్‌తో సమానం, కాబట్టి మూలం `count` రీడ్‌లకు చెల్లుతుంది
            // - `.reserve(count)` `spare.len() >= count` కాబట్టి విడి `count` వ్రాయడానికి చెల్లుతుందని హామీ ఇస్తుంది
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - మూలకాలు `copy_nonoverlapping` ద్వారా ప్రారంభించబడ్డాయి
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Vec కోసం సాధారణ trait అమలులు
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): cfg(test) తో ఈ పద్ధతి నిర్వచనానికి అవసరమైన స్వాభావిక `[T]::to_vec` పద్ధతి అందుబాటులో లేదు.
    // బదులుగా cfg(test) NB తో మాత్రమే అందుబాటులో ఉన్న `slice::to_vec` ఫంక్షన్‌ను ఉపయోగించండి మరింత సమాచారం కోసం slice.rs లోని slice::hack మాడ్యూల్ చూడండి
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // తిరిగి వ్రాయబడని ఏదైనా వదలండి
        self.truncate(other.len());

        // self.len <= other.len పైన కత్తిరించబడిన కారణంగా, ఇక్కడ ముక్కలు ఎల్లప్పుడూ సరిహద్దులో ఉంటాయి.
        //
        let (init, tail) = other.split_at(self.len());

        // ఉన్న విలువలు allocations/resources ను తిరిగి ఉపయోగించుకోండి.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// వినియోగించే ఇటరేటర్‌ను సృష్టిస్తుంది, అనగా, ప్రతి విలువను vector (ప్రారంభం నుండి చివరి వరకు) నుండి కదిలిస్తుంది.
    /// దీన్ని పిలిచిన తర్వాత vector ఉపయోగించబడదు.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s రకం స్ట్రింగ్ కలిగి ఉంది, &String కాదు
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // వివిధ SpecFrom/SpecExtend అమలులు దరఖాస్తు చేయడానికి తదుపరి ఆప్టిమైజేషన్లు లేనప్పుడు ప్రతినిధిగా ఉండే ఆకు పద్ధతి
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // సాధారణ ఇటరేటర్‌కు ఇదే పరిస్థితి.
        //
        // ఈ ఫంక్షన్ నైతిక సమానమైనదిగా ఉండాలి:
        //
        //      మళ్ళిలోని అంశం కోసం {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // మేము చిరునామా స్థలాన్ని కేటాయించవలసి ఉన్నందున NB పొంగిపొర్లుతుంది
                self.set_len(len + 1);
            }
        }
    }

    /// vector లో పేర్కొన్న పరిధిని ఇచ్చిన `replace_with` ఇరేటర్‌తో భర్తీ చేసి, తొలగించిన వస్తువులను ఇస్తుంది.
    ///
    /// `replace_with` `range` వలె అదే పొడవు ఉండవలసిన అవసరం లేదు.
    ///
    /// `range` చివరి వరకు ఇటరేటర్ వినియోగించకపోయినా తొలగించబడుతుంది.
    ///
    /// `Splice` విలువ లీక్ అయినట్లయితే vector నుండి ఎన్ని మూలకాలు తొలగించబడతాయో పేర్కొనబడలేదు.
    ///
    /// `Splice` విలువ పడిపోయినప్పుడు మాత్రమే ఇన్పుట్ ఇరేటర్ `replace_with` వినియోగించబడుతుంది.
    ///
    /// ఇది సరైనది అయితే:
    ///
    /// * తోక (`range` తరువాత vector లోని అంశాలు) ఖాళీగా ఉన్నాయి,
    /// * లేదా `replace_with` `పరిధి` యొక్క పొడవు కంటే తక్కువ లేదా సమానమైన మూలకాలను ఇస్తుంది
    /// * లేదా దాని `size_hint()` యొక్క దిగువ పరిమితి ఖచ్చితమైనది.
    ///
    /// లేకపోతే, తాత్కాలిక vector కేటాయించబడుతుంది మరియు తోక రెండుసార్లు కదులుతుంది.
    ///
    /// # Panics
    ///
    /// ప్రారంభ స్థానం ముగింపు బిందువు కంటే ఎక్కువగా ఉంటే లేదా ముగింపు స్థానం vector పొడవు కంటే ఎక్కువగా ఉంటే Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// ఒక మూలకాన్ని తీసివేయాలా వద్దా అని నిర్ణయించడానికి మూసివేతను ఉపయోగించే ఇటరేటర్‌ను సృష్టిస్తుంది.
    ///
    /// మూసివేత నిజమైనది అయితే, మూలకం తీసివేయబడుతుంది మరియు దిగుబడి వస్తుంది.
    /// మూసివేత తప్పుగా తిరిగి వస్తే, మూలకం vector లో ఉంటుంది మరియు ఇరేటర్ ద్వారా ఇవ్వబడదు.
    ///
    /// ఈ పద్ధతిని ఉపయోగించడం క్రింది కోడ్‌కు సమానం:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // మీ కోడ్ ఇక్కడ
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// కానీ `drain_filter` ఉపయోగించడం సులభం.
    /// `drain_filter` ఇది మరింత సమర్థవంతంగా ఉంటుంది, ఎందుకంటే ఇది శ్రేణి యొక్క మూలకాలను పెద్దమొత్తంలో బ్యాక్‌షిఫ్ట్ చేయగలదు.
    ///
    /// వడపోత మూసివేతలోని ప్రతి మూలకాన్ని మార్చడానికి లేదా తీసివేయడానికి మీరు ఎంచుకున్నా, దాన్ని మార్చడానికి `drain_filter` మిమ్మల్ని అనుమతిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// శ్రేణిని సాయంత్రం మరియు అసమానంగా విభజించడం, అసలు కేటాయింపును తిరిగి ఉపయోగించడం:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // లీక్ అవ్వకుండా మాకు రక్షణ కల్పించండి (లీక్ యాంప్లిఫికేషన్)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// మూలకాలను Vec లోకి నెట్టే ముందు వాటిని సూచనల నుండి కాపీ చేసే అమలును విస్తరించండి.
///
/// ఈ అమలు స్లైస్ ఇరేటర్స్ కోసం ప్రత్యేకమైనది, ఇక్కడ ఇది మొత్తం స్లైస్‌ను ఒకేసారి జోడించడానికి [`copy_from_slice`] ని ఉపయోగిస్తుంది.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// vectors యొక్క పోలికను అమలు చేస్తుంది, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// vectors యొక్క ఆర్డరింగ్‌ను అమలు చేస్తుంది, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // [T] కోసం డ్రాప్ వాడండి vector యొక్క మూలకాలను బలహీనమైన అవసరమైన రకంగా సూచించడానికి ముడి స్లైస్‌ని ఉపయోగించండి;
            //
            // కొన్ని సందర్భాల్లో చెల్లుబాటు అయ్యే ప్రశ్నలను నివారించవచ్చు
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // రావెక్ డీలోకేషన్‌ను నిర్వహిస్తుంది
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// ఖాళీ `Vec<T>` ను సృష్టిస్తుంది.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: పరీక్ష libstd లో లాగుతుంది, ఇది ఇక్కడ లోపాలను కలిగిస్తుంది
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: పరీక్ష libstd లో లాగుతుంది, ఇది ఇక్కడ లోపాలను కలిగిస్తుంది
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// `Vec<T>` యొక్క మొత్తం విషయాలను అర్రేగా పొందుతుంది, దాని పరిమాణం అభ్యర్థించిన శ్రేణికి సరిగ్గా సరిపోలితే.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// పొడవు సరిపోలకపోతే, ఇన్పుట్ `Err` లో తిరిగి వస్తుంది:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// మీరు `Vec<T>` యొక్క ఉపసర్గను పొందడం మంచిది అయితే, మీరు మొదట [`.truncate(N)`](Vec::truncate) కు కాల్ చేయవచ్చు.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // భద్రత: `.set_len(0)` ఎల్లప్పుడూ ధ్వనిగా ఉంటుంది.
        unsafe { vec.set_len(0) };

        // భద్రత: `Vec` యొక్క పాయింటర్ ఎల్లప్పుడూ సరిగ్గా సమలేఖనం చేయబడుతుంది మరియు
        // శ్రేణికి అవసరమైన అమరిక అంశాల మాదిరిగానే ఉంటుంది.
        // మాకు తగినంత అంశాలు ఉన్నాయని మేము ముందే తనిఖీ చేసాము.
        // `set_len` `Vec` ను కూడా డ్రాప్ చేయవద్దని చెబుతున్నందున అంశాలు డబుల్ డ్రాప్ చేయవు.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}