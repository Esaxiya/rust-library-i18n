use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// సోర్స్ కేటాయింపును తిరిగి ఉపయోగించుకునేటప్పుడు ఒక వెక్‌లోకి ఇటెరేటర్ పైప్‌లైన్‌ను సేకరించడానికి స్పెషలైజేషన్ మార్కర్, అనగా
/// పైప్లైన్ స్థానంలో అమలు.
///
/// పునర్వినియోగం చేయవలసిన కేటాయింపును ప్రాప్యత చేయడానికి ప్రత్యేకమైన ఫంక్షన్ కోసం సోర్స్‌ఇటర్ పేరెంట్ trait అవసరం.
/// కానీ స్పెషలైజేషన్ చెల్లుబాటు కావడానికి ఇది సరిపోదు.
/// Impl లో అదనపు హద్దులు చూడండి.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-అంతర్గత SourceIter/InPlaceIterable traits అడాప్టర్ గొలుసుల ద్వారా మాత్రమే అమలు చేయబడుతుంది <Adapter<Adapter<IntoIter>>> (అన్నీ core/std యాజమాన్యంలో ఉన్నాయి).
// అడాప్టర్ అమలుపై అదనపు హద్దులు (`impl<I: Trait> Trait for Adapter<I>` కి మించి) ఇప్పటికే స్పెషలైజేషన్ traits (కాపీ, ట్రస్టెడ్ రాండమ్ యాక్సెస్, ఫ్యూజ్డ్ఇటరేటర్) గా గుర్తించబడిన ఇతర traits పై మాత్రమే ఆధారపడి ఉంటాయి.
//
// I.e. మార్కర్ వినియోగదారు సరఫరా చేసే రకాల జీవితకాలాలపై ఆధారపడి ఉండదు.మాడ్యులో కాపీ రంధ్రం, ఇది ఇప్పటికే అనేక ఇతర ప్రత్యేకతలు ఆధారపడి ఉంటుంది.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // trait bounds ద్వారా వ్యక్తీకరించలేని అదనపు అవసరాలు.మేము బదులుగా const eval పై ఆధారపడతాము:
        // ఎ) పునర్వినియోగం మరియు పాయింటర్ అంకగణితం కోసం కేటాయింపులు లేనందున ZST లు లేవు panic బి) అలోక్ కాంట్రాక్ట్ ప్రకారం పరిమాణం సరిపోతుంది సి) అలోక్ కాంట్రాక్ట్ ప్రకారం అమరికలు సరిపోతాయి
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // మరింత సాధారణ అమలులకు తిరిగి
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // అప్పటి నుండి ప్రయత్నించండి-రెట్లు ఉపయోగించండి
        // - ఇది కొన్ని ఇటరేటర్ ఎడాప్టర్లకు వెక్టరైజ్ చేస్తుంది
        // - చాలా అంతర్గత పునరుక్తి పద్ధతుల మాదిరిగా కాకుండా, ఇది &mut సెల్ఫ్ మాత్రమే తీసుకుంటుంది
        // - ఇది రైట్ పాయింటర్‌ను దాని ఇన్నార్డ్‌ల ద్వారా థ్రెడ్ చేసి, చివరికి తిరిగి పొందటానికి అనుమతిస్తుంది
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // పునరావృతం విజయవంతమైంది, తల వదలవద్దు
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // సోర్స్‌ఇటర్ కాంట్రాక్ట్ మినహాయింపు ఉందో లేదో తనిఖీ చేయండి: అవి కాకపోతే మేము ఈ దశకు కూడా చేయకపోవచ్చు
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // InPlaceIterable ఒప్పందాన్ని తనిఖీ చేయండి.ఇటరేటర్ సోర్స్ పాయింటర్‌ను అస్సలు అభివృద్ధి చేస్తేనే ఇది సాధ్యమవుతుంది.
        // ఇది ట్రస్టెడ్ రాండమ్ యాక్సెస్ ద్వారా అన్‌చెక్ చేయబడిన యాక్సెస్‌ను ఉపయోగిస్తే, అప్పుడు సోర్స్ పాయింటర్ దాని ప్రారంభ స్థితిలో ఉంటుంది మరియు మేము దానిని సూచనగా ఉపయోగించలేము
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // మూలం యొక్క తోక వద్ద మిగిలిన విలువలను వదలండి, కానీ panics డ్రాప్ చేస్తే ఇంటూఇటర్ పరిధిలోకి వెళ్ళిన తర్వాత కేటాయింపును పడిపోకుండా నిరోధించండి, అప్పుడు మేము dst_buf లోకి సేకరించిన ఏదైనా మూలకాలను కూడా లీక్ చేస్తాము
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // InPlaceIterable ఒప్పందాన్ని ఇక్కడ ఖచ్చితంగా ధృవీకరించలేము ఎందుకంటే try_fold కి సోర్స్ పాయింటర్‌కు ప్రత్యేకమైన సూచన ఉంది, మనం చేయగలిగేది అది ఇంకా పరిధిలో ఉందో లేదో తనిఖీ చేయండి
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}