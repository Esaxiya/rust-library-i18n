// `SetLenOnDrop` విలువ పరిధిలో లేనప్పుడు వెక్ యొక్క పొడవును సెట్ చేయండి.
//
// ఆలోచన: సెట్‌లెన్ఆన్‌డ్రాప్‌లోని పొడవు ఫీల్డ్ స్థానిక వేరియబుల్, ఇది ఆప్టిమైజర్ చూసేది Vec యొక్క డేటా పాయింటర్ ద్వారా ఏ దుకాణాలతోనూ మారుపేరు ఉండదు.
// అలియాస్ అనాలిసిస్ ఇష్యూ #32155 కోసం ఇది ఒక ప్రత్యామ్నాయం
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}