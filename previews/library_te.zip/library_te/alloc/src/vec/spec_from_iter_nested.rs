use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// అతివ్యాప్తి స్పెషలైజేషన్లను మాన్యువల్‌గా ప్రాధాన్యత ఇవ్వడానికి అవసరమైన Vec::from_iter కోసం మరొక స్పెషలైజేషన్ trait వివరాల కోసం [`SpecFromIter`](super::SpecFromIter) చూడండి.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // మొదటి పునరుక్తిని అన్‌రోల్ చేయండి, ఎందుకంటే ప్రతి సందర్భంలోనూ మళ్ళా ఖాళీగా లేనప్పుడు vector విస్తరించబడుతుంది, అయితే extend_desugared() లోని లూప్ కొన్ని తరువాతి లూప్ పునరావృతాలలో vector నిండినట్లు చూడటం లేదు.
        //
        // కాబట్టి మేము మంచి branch అంచనాను పొందుతాము.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // extend() ఖాళీ Vecs కోసం spec_from నుండి ప్రతినిధిగా ఉన్నందున spec_extend() కి తప్పక ప్రతినిధిగా ఉండాలి
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // extend() ఖాళీ Vecs కోసం spec_from నుండి ప్రతినిధిగా ఉన్నందున spec_extend() కి తప్పక ప్రతినిధిగా ఉండాలి
        //
        vector.spec_extend(iterator);
        vector
    }
}