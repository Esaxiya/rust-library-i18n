#![stable(feature = "wake_trait", since = "1.51.0")]
//! అసమకాలిక పనులతో పనిచేయడానికి రకాలు మరియు Traits.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// ఒక కార్యనిర్వాహకుడిపై ఒక పనిని మేల్కొనే అమలు.
///
/// ఈ trait ను [`Waker`] సృష్టించడానికి ఉపయోగించవచ్చు.
/// ఒక ఎగ్జిక్యూటర్ ఈ trait యొక్క అమలును నిర్వచించగలడు మరియు ఆ ఎగ్జిక్యూటర్‌పై అమలు చేయబడిన పనులకు వెళ్ళడానికి వాకర్‌ను నిర్మించడానికి దాన్ని ఉపయోగించవచ్చు.
///
/// ఈ trait అనేది [`RawWaker`] ను నిర్మించడానికి మెమరీ-సురక్షితమైన మరియు సమర్థతా ప్రత్యామ్నాయం.
/// ఇది సాధారణ కార్యనిర్వాహక రూపకల్పనకు మద్దతు ఇస్తుంది, దీనిలో ఒక పనిని మేల్కొలపడానికి ఉపయోగించే డేటా [`Arc`] లో నిల్వ చేయబడుతుంది.
/// కొంతమంది ఎగ్జిక్యూటర్లు (ముఖ్యంగా ఎంబెడెడ్ సిస్టమ్స్ కోసం) ఈ API ని ఉపయోగించలేరు, అందుకే [`RawWaker`] ఆ వ్యవస్థలకు ప్రత్యామ్నాయంగా ఉంది.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// ఒక ప్రాథమిక `block_on` ఫంక్షన్ future ను తీసుకుంటుంది మరియు ప్రస్తుత థ్రెడ్‌లో దాన్ని పూర్తి చేస్తుంది.
///
/// **Note:** ఈ ఉదాహరణ సరళత కోసం సరైనదాన్ని వర్తకం చేస్తుంది.
/// డెడ్‌లాక్‌లను నివారించడానికి, ప్రొడక్షన్-గ్రేడ్ ఇంప్లిమెంటేషన్‌లు `thread::unpark` కు ఇంటర్మీడియట్ కాల్‌లతో పాటు సమూహ ఆహ్వానాలను కూడా నిర్వహించాల్సి ఉంటుంది.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// పిలిచినప్పుడు ప్రస్తుత థ్రెడ్‌ను మేల్కొనే వేకర్.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// ప్రస్తుత థ్రెడ్‌లో పూర్తి చేయడానికి future ను అమలు చేయండి.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // future ను పిన్ చేయండి కాబట్టి దానిని పోల్ చేయవచ్చు.
///     let mut fut = Box::pin(fut);
///
///     // future కు పంపించటానికి క్రొత్త సందర్భాన్ని సృష్టించండి.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // పూర్తి చేయడానికి future ను అమలు చేయండి.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// ఈ పనిని మేల్కొలపండి.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// వాకర్ తినకుండా ఈ పనిని మేల్కొలపండి.
    ///
    /// ఒక కార్యనిర్వాహకుడు వాకర్‌ను తినకుండా మేల్కొలపడానికి చౌకైన మార్గాన్ని సమర్ధిస్తే, అది ఈ పద్ధతిని భర్తీ చేయాలి.
    /// అప్రమేయంగా, ఇది [`Arc`] ను క్లోన్ చేస్తుంది మరియు క్లోన్‌లో [`wake`] ని పిలుస్తుంది.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // భద్రత: ముడి_వాకర్ సురక్షితంగా నిర్మిస్తున్నందున ఇది సురక్షితం
        // ఆర్క్ నుండి రావాకర్<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: రావాకర్ నిర్మాణానికి ఈ ప్రైవేట్ ఫంక్షన్ కాకుండా ఉపయోగించబడుతుంది
// `From<Arc<W>> for Waker` యొక్క భద్రత సరైన trait పంపకంపై ఆధారపడదని నిర్ధారించడానికి, దీనిని `From<Arc<W>> for RawWaker` impl లోకి ఇన్లైన్ చేయడం, బదులుగా రెండు impls ఈ ఫంక్షన్‌ను ప్రత్యక్షంగా మరియు స్పష్టంగా పిలుస్తాయి.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // ఆర్క్ క్లోన్ చేయడానికి రిఫరెన్స్ కౌంట్ పెంచండి.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // విలువ ద్వారా మేల్కొలపండి, ఆర్క్‌ను Wake::wake ఫంక్షన్‌లోకి తరలించండి
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // రిఫరెన్స్ ద్వారా మేల్కొలపండి, వేకర్‌ను డ్రాప్ చేయకుండా ఉండటానికి మాన్యువల్‌డ్రాప్‌లో చుట్టండి
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // ఆర్క్ ఆన్ డ్రాప్ యొక్క సూచన గణనను తగ్గించండి
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}