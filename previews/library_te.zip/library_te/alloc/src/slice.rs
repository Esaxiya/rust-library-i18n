//! ఒక పరస్పర శ్రేణిలో డైనమిక్-పరిమాణ వీక్షణ, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! ముక్కలు ఒక పాయింటర్ మరియు పొడవుగా సూచించబడే మెమరీ బ్లాక్‌లోకి వీక్షణ.
//!
//! ```
//! // ఒక Vec ను ముక్కలు చేయడం
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // స్లైస్‌కు శ్రేణిని బలవంతం చేస్తుంది
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! ముక్కలు మార్చగలవి లేదా భాగస్వామ్యం చేయబడతాయి.
//! షేర్డ్ స్లైస్ రకం `&[T]`, మ్యూటబుల్ స్లైస్ రకం `&mut [T]`, ఇక్కడ `T` మూలకం రకాన్ని సూచిస్తుంది.
//! ఉదాహరణకు, మ్యూటబుల్ స్లైస్ సూచించే మెమరీ బ్లాక్‌ను మీరు మార్చవచ్చు:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! ఈ మాడ్యూల్ కలిగి ఉన్న కొన్ని విషయాలు ఇక్కడ ఉన్నాయి:
//!
//! ## Structs
//!
//! ముక్కల కోసం ఉపయోగపడే అనేక నిర్మాణాలు ఉన్నాయి, అవి [`Iter`] వంటివి, ఇది స్లైస్‌పై పునరుక్తిని సూచిస్తుంది.
//!
//! ## Trait అమలు
//!
//! ముక్కల కోసం సాధారణ traits యొక్క అనేక అమలులు ఉన్నాయి.కొన్ని ఉదాహరణలు:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], మూలకం రకం [`Eq`] లేదా [`Ord`] ముక్కల కోసం.
//! * [`Hash`] - మూలకాల రకం [`Hash`] ముక్కల కోసం.
//!
//! ## Iteration
//!
//! ముక్కలు `IntoIterator` ను అమలు చేస్తాయి.ఇరేటర్ స్లైస్ ఎలిమెంట్స్‌కు సూచనలను ఇస్తుంది.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! మార్చగల స్లైస్ మూలకాలకు మార్చగల సూచనలను ఇస్తుంది:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! ఈ ఇరేటర్ స్లైస్ యొక్క మూలకాలకు మార్చగల సూచనలను ఇస్తుంది, కాబట్టి స్లైస్ యొక్క మూలకం రకం `i32` అయితే, ఇరేటర్ యొక్క మూలకం రకం `&mut i32`.
//!
//!
//! * [`.iter`] మరియు [`.iter_mut`] అనేది డిఫాల్ట్ ఇరేటర్లను తిరిగి ఇవ్వడానికి స్పష్టమైన పద్ధతులు.
//! * ఇటరేటర్లను తిరిగి ఇచ్చే మరిన్ని పద్ధతులు [`.split`], [`.splitn`], [`.chunks`], [`.windows`] మరియు మరిన్ని.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// ఈ మాడ్యూల్‌లోని చాలా ఉపయోగాలు పరీక్ష కాన్ఫిగరేషన్‌లో మాత్రమే ఉపయోగించబడతాయి.
// వాటిని పరిష్కరించడం కంటే ఉపయోగించని_ దిగుమతుల హెచ్చరికను ఆపివేయడం క్లీనర్.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// ప్రాథమిక స్లైస్ పొడిగింపు పద్ధతులు
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) NB ను పరీక్షించేటప్పుడు `vec!` స్థూల అమలుకు అవసరం, మరిన్ని వివరాల కోసం ఈ ఫైల్‌లోని `hack` మాడ్యూల్ చూడండి.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) NB ను పరీక్షించేటప్పుడు `Vec::clone` అమలు కోసం అవసరం, మరిన్ని వివరాల కోసం ఈ ఫైల్‌లోని `hack` మాడ్యూల్ చూడండి.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): cfg(test) `impl [T]` అందుబాటులో లేనందున, ఈ మూడు విధులు వాస్తవానికి `impl [T]` లో ఉన్న పద్ధతులు కాని `core::slice::SliceExt` లో కాదు, మేము `test_permutations` పరీక్ష కోసం ఈ ఫంక్షన్లను సరఫరా చేయాలి
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // ఇది `vec!` స్థూలంలో ఎక్కువగా ఉపయోగించబడుతున్నందున మేము దీనికి ఇన్లైన్ లక్షణాన్ని జోడించకూడదు మరియు పెర్ఫ్ రిగ్రెషన్కు కారణమవుతుంది.
    // చర్చ మరియు పరిపూర్ణ ఫలితాల కోసం #71204 చూడండి.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // దిగువ లూప్‌లో అంశాలు ప్రారంభించబడ్డాయి
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) హద్దుల తనిఖీలను తొలగించడానికి LLVM కి అవసరం మరియు జిప్ కంటే మెరుగైన కోడజన్ ఉంది.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // వెక్ కేటాయించబడింది మరియు కనీసం ఈ పొడవు వరకు ప్రారంభించబడింది.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // `s` సామర్థ్యంతో పైన కేటాయించబడింది మరియు దిగువ ptr::copy_to_non_overlapping లో `s.len()` కు ప్రారంభించండి.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// స్లైస్ క్రమబద్ధీకరిస్తుంది.
    ///
    /// ఈ విధమైన స్థిరంగా ఉంటుంది (అనగా, సమాన మూలకాలను క్రమాన్ని మార్చదు) మరియు *O*(*n*\*log(* n*)) చెత్త కేసు.
    ///
    /// వర్తించేటప్పుడు, అస్థిర సార్టింగ్‌కు ప్రాధాన్యత ఇవ్వబడుతుంది ఎందుకంటే ఇది సాధారణంగా స్థిరమైన సార్టింగ్ కంటే వేగంగా ఉంటుంది మరియు ఇది సహాయక మెమరీని కేటాయించదు.
    /// [`sort_unstable`](slice::sort_unstable) చూడండి.
    ///
    /// # ప్రస్తుత అమలు
    ///
    /// ప్రస్తుత అల్గోరిథం [timsort](https://en.wikipedia.org/wiki/Timsort) చేత ప్రేరణ పొందిన అనుకూల, పునరుత్పత్తి విలీనం.
    /// స్లైస్ దాదాపుగా క్రమబద్ధీకరించబడిన సందర్భాల్లో ఇది చాలా వేగంగా రూపొందించబడింది లేదా రెండు లేదా అంతకంటే ఎక్కువ క్రమబద్ధీకరించబడిన సన్నివేశాలను ఒకదాని తరువాత ఒకటిగా కలుపుతారు.
    ///
    ///
    /// అలాగే, ఇది `self` యొక్క సగం పరిమాణంలో తాత్కాలిక నిల్వను కేటాయిస్తుంది, కాని చిన్న ముక్కల కోసం బదులుగా కేటాయించని చొప్పించే విధానాన్ని ఉపయోగిస్తారు.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// స్లైస్‌ను కంపారిటర్ ఫంక్షన్‌తో క్రమబద్ధీకరిస్తుంది.
    ///
    /// ఈ విధమైన స్థిరంగా ఉంటుంది (అనగా, సమాన మూలకాలను క్రమాన్ని మార్చదు) మరియు *O*(*n*\*log(* n*)) చెత్త కేసు.
    ///
    /// పోలిక ఫంక్షన్ స్లైస్‌లోని మూలకాల కోసం మొత్తం క్రమాన్ని నిర్వచించాలి.ఆర్డరింగ్ మొత్తం కాకపోతే, మూలకాల క్రమం పేర్కొనబడలేదు.
    /// ఆర్డర్ ఉంటే మొత్తం ఆర్డర్ (అన్ని `a`, `b` మరియు `c` లకు):
    ///
    /// * మొత్తం మరియు యాంటిసిమెట్రిక్: సరిగ్గా `a < b`, `a == b` లేదా `a > b` లో ఒకటి నిజం, మరియు
    /// * ట్రాన్సిటివ్, `a < b` మరియు `b < c` `a < c` ను సూచిస్తుంది.`==` మరియు `>` రెండింటికీ అదే ఉండాలి.
    ///
    /// ఉదాహరణకు, [`f64`] [`Ord`] ను అమలు చేయనందున `NaN != NaN`, స్లైస్‌లో `NaN` లేదని మనకు తెలిసినప్పుడు `partial_cmp` ను మా సార్టింగ్ ఫంక్షన్‌గా ఉపయోగించవచ్చు.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// వర్తించేటప్పుడు, అస్థిర సార్టింగ్‌కు ప్రాధాన్యత ఇవ్వబడుతుంది ఎందుకంటే ఇది సాధారణంగా స్థిరమైన సార్టింగ్ కంటే వేగంగా ఉంటుంది మరియు ఇది సహాయక మెమరీని కేటాయించదు.
    /// [`sort_unstable_by`](slice::sort_unstable_by) చూడండి.
    ///
    /// # ప్రస్తుత అమలు
    ///
    /// ప్రస్తుత అల్గోరిథం [timsort](https://en.wikipedia.org/wiki/Timsort) చేత ప్రేరణ పొందిన అనుకూల, పునరుత్పత్తి విలీనం.
    /// స్లైస్ దాదాపుగా క్రమబద్ధీకరించబడిన సందర్భాల్లో ఇది చాలా వేగంగా రూపొందించబడింది లేదా రెండు లేదా అంతకంటే ఎక్కువ క్రమబద్ధీకరించబడిన సన్నివేశాలను ఒకదాని తరువాత ఒకటిగా కలుపుతారు.
    ///
    /// అలాగే, ఇది `self` యొక్క సగం పరిమాణంలో తాత్కాలిక నిల్వను కేటాయిస్తుంది, కాని చిన్న ముక్కల కోసం బదులుగా కేటాయించని చొప్పించే విధానాన్ని ఉపయోగిస్తారు.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // రివర్స్ సార్టింగ్
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// కీ వెలికితీత ఫంక్షన్‌తో స్లైస్‌ని క్రమబద్ధీకరిస్తుంది.
    ///
    /// ఈ విధమైన స్థిరంగా ఉంటుంది (అనగా, సమాన మూలకాలను క్రమాన్ని మార్చదు) మరియు *O*(*m*\* * n *\* log(*n*)) చెత్త-కేసు, ఇక్కడ కీ ఫంక్షన్ *O*(*m*).
    ///
    /// ఖరీదైన కీ ఫంక్షన్ల కోసం (ఉదా
    /// సాధారణ ఆస్తి ప్రాప్యత లేదా ప్రాథమిక కార్యకలాపాలు కాని విధులు), మూలకం కీలను తిరిగి కంప్యూట్ చేయనందున, [`sort_by_cached_key`](slice::sort_by_cached_key) గణనీయంగా వేగంగా ఉంటుంది.
    ///
    ///
    /// వర్తించేటప్పుడు, అస్థిర సార్టింగ్‌కు ప్రాధాన్యత ఇవ్వబడుతుంది ఎందుకంటే ఇది సాధారణంగా స్థిరమైన సార్టింగ్ కంటే వేగంగా ఉంటుంది మరియు ఇది సహాయక మెమరీని కేటాయించదు.
    /// [`sort_unstable_by_key`](slice::sort_unstable_by_key) చూడండి.
    ///
    /// # ప్రస్తుత అమలు
    ///
    /// ప్రస్తుత అల్గోరిథం [timsort](https://en.wikipedia.org/wiki/Timsort) చేత ప్రేరణ పొందిన అనుకూల, పునరుత్పత్తి విలీనం.
    /// స్లైస్ దాదాపుగా క్రమబద్ధీకరించబడిన సందర్భాల్లో ఇది చాలా వేగంగా రూపొందించబడింది లేదా రెండు లేదా అంతకంటే ఎక్కువ క్రమబద్ధీకరించబడిన సన్నివేశాలను ఒకదాని తరువాత ఒకటిగా కలుపుతారు.
    ///
    /// అలాగే, ఇది `self` యొక్క సగం పరిమాణంలో తాత్కాలిక నిల్వను కేటాయిస్తుంది, కాని చిన్న ముక్కల కోసం బదులుగా కేటాయించని చొప్పించే విధానాన్ని ఉపయోగిస్తారు.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// కీ వెలికితీత ఫంక్షన్‌తో స్లైస్‌ని క్రమబద్ధీకరిస్తుంది.
    ///
    /// సార్టింగ్ సమయంలో, కీ ఫంక్షన్ మూలకానికి ఒకసారి మాత్రమే అంటారు.
    ///
    /// ఈ విధమైన స్థిరంగా ఉంటుంది (అనగా, సమాన మూలకాలను క్రమాన్ని మార్చదు) మరియు *O*(*m*\* * n *+* n *\* log(*n*)) చెత్త కేసు, ఇక్కడ కీ ఫంక్షన్ *O*(*m*) .
    ///
    /// సాధారణ కీ ఫంక్షన్ల కోసం (ఉదా., ఆస్తి ప్రాప్యత లేదా ప్రాథమిక కార్యకలాపాలు), [`sort_by_key`](slice::sort_by_key) వేగంగా ఉంటుంది.
    ///
    /// # ప్రస్తుత అమలు
    ///
    /// ప్రస్తుత అల్గోరిథం ఓర్సన్ పీటర్స్ చేత [pattern-defeating quicksort][pdqsort] పై ఆధారపడింది, ఇది యాదృచ్ఛిక క్విక్‌సోర్ట్ యొక్క వేగవంతమైన సగటు కేసును హీప్‌పోర్ట్ యొక్క వేగవంతమైన చెత్త కేసుతో మిళితం చేస్తుంది, అయితే కొన్ని నమూనాలతో ముక్కలపై సరళ సమయాన్ని సాధిస్తుంది.
    /// క్షీణించిన కేసులను నివారించడానికి ఇది కొన్ని రాండమైజేషన్‌ను ఉపయోగిస్తుంది, కానీ నిర్ణయాత్మక ప్రవర్తనను అందించడానికి స్థిరమైన seed తో.
    ///
    /// చెత్త సందర్భంలో, అల్గోరిథం స్లైస్ యొక్క పొడవును `Vec<(K, usize)>` లో తాత్కాలిక నిల్వను కేటాయిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // కేటాయింపులను తగ్గించడానికి, మా vector ను సాధ్యమైనంత చిన్న రకం ద్వారా ఇండెక్స్ చేయడానికి సహాయక స్థూల.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // `indices` యొక్క అంశాలు ప్రత్యేకమైనవి, అవి సూచిక చేయబడినందున, అసలు స్లైస్‌కు సంబంధించి ఏ విధమైన స్థిరంగా ఉంటుంది.
                // మేము ఇక్కడ `sort_unstable` ను ఉపయోగిస్తాము ఎందుకంటే దీనికి తక్కువ మెమరీ కేటాయింపు అవసరం.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// `self` ను కొత్త `Vec` లోకి కాపీ చేస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // ఇక్కడ, `s` మరియు `x` ను స్వతంత్రంగా సవరించవచ్చు.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// `self` ను కొత్త `Vec` లోకి కేటాయింపుతో కాపీ చేస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // ఇక్కడ, `s` మరియు `x` ను స్వతంత్రంగా సవరించవచ్చు.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, మరిన్ని వివరాల కోసం ఈ ఫైల్‌లోని `hack` మాడ్యూల్ చూడండి.
        hack::to_vec(self, alloc)
    }

    /// క్లోన్ లేదా కేటాయింపు లేకుండా `self` ను vector గా మారుస్తుంది.
    ///
    /// ఫలితంగా వచ్చే vector ను `Vec ద్వారా తిరిగి పెట్టెగా మార్చవచ్చు<T>యొక్క `into_boxed_slice` పద్ధతి.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` ఇది `x` గా మార్చబడినందున ఇకపై ఉపయోగించబడదు.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, మరిన్ని వివరాల కోసం ఈ ఫైల్‌లోని `hack` మాడ్యూల్ చూడండి.
        hack::into_vec(self)
    }

    /// స్లైస్ `n` సార్లు పునరావృతం చేయడం ద్వారా vector ను సృష్టిస్తుంది.
    ///
    /// # Panics
    ///
    /// సామర్థ్యం పొంగిపొర్లుతుంటే ఈ ఫంక్షన్ panic అవుతుంది.
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// ఓవర్ఫ్లో మీద panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // `n` సున్నా కంటే పెద్దది అయితే, దానిని `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` గా విభజించవచ్చు.
        // `2^expn` `n` యొక్క ఎడమవైపు '1' బిట్ ద్వారా సూచించబడే సంఖ్య, మరియు `rem` అనేది `n` యొక్క మిగిలిన భాగం.
        //
        //

        // `set_len()` ని యాక్సెస్ చేయడానికి `Vec` ని ఉపయోగిస్తోంది.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` `buf` `expn`-సార్లు రెట్టింపు చేయడం ద్వారా పునరావృతం జరుగుతుంది.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // `m > 0` అయితే, ఎడమవైపు '1' వరకు మిగిలిన బిట్స్ ఉన్నాయి.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` `self.len() * n` సామర్థ్యాన్ని కలిగి ఉంది.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) మొదటి `rem` పునరావృతాలను `buf` నుండి కాపీ చేయడం ద్వారా పునరావృతం జరుగుతుంది.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // ఇది `2^expn > rem` నుండి అతివ్యాప్తి చెందదు.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` `buf.capacity()` (`= self.len() * n`) కు సమానం.
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// `T` యొక్క స్లైస్‌ను ఒకే విలువ `Self::Output` లోకి చదును చేస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// `T` యొక్క స్లైస్‌ను ఒకే విలువ `Self::Output` లోకి చదును చేస్తుంది, ప్రతి మధ్య ఇచ్చిన విభజనను ఉంచుతుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// `T` యొక్క స్లైస్‌ను ఒకే విలువ `Self::Output` లోకి చదును చేస్తుంది, ప్రతి మధ్య ఇచ్చిన విభజనను ఉంచుతుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// ఈ స్లైస్ యొక్క కాపీని కలిగి ఉన్న vector ను అందిస్తుంది, ఇక్కడ ప్రతి బైట్ దాని ASCII అప్పర్ కేస్ సమానమైన వాటికి మ్యాప్ చేయబడుతుంది.
    ///
    ///
    /// ASCII అక్షరాలు 'a' నుండి 'z' వరకు 'A' నుండి 'Z' వరకు మ్యాప్ చేయబడతాయి, కాని ASCII కాని అక్షరాలు మారవు.
    ///
    /// స్థానంలో ఉన్న విలువను పెద్దదిగా చేయడానికి, [`make_ascii_uppercase`] ని ఉపయోగించండి.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// ఈ స్లైస్ యొక్క కాపీని కలిగి ఉన్న vector ను అందిస్తుంది, ఇక్కడ ప్రతి బైట్ దాని ASCII లోయర్ కేస్ సమానమైన వాటికి మ్యాప్ చేయబడుతుంది.
    ///
    ///
    /// ASCII అక్షరాలు 'A' నుండి 'Z' వరకు 'a' నుండి 'z' వరకు మ్యాప్ చేయబడతాయి, కాని ASCII కాని అక్షరాలు మారవు.
    ///
    /// స్థానంలో ఉన్న విలువను తగ్గించడానికి, [`make_ascii_lowercase`] ఉపయోగించండి.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// నిర్దిష్ట రకాల డేటాపై ముక్కల కోసం పొడిగింపు traits
////////////////////////////////////////////////////////////////////////////////

/// [`[T]: : concat`](స్లైస్::concat) కోసం trait సహాయకుడు.
///
/// Note: ఈ trait లో `Item` రకం పరామితి ఉపయోగించబడదు, కాని ఇది ఇంప్ల్స్ మరింత సాధారణం కావడానికి అనుమతిస్తుంది.
/// అది లేకుండా, మేము ఈ లోపాన్ని పొందుతాము:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// బహుళ `Borrow<[_]>` ఇంప్ల్స్‌తో `V` రకాలు ఉండవచ్చు, ఎందుకంటే బహుళ `T` రకాలు వర్తిస్తాయి:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// సంయోగం తరువాత ఫలిత రకం
    type Output;

    /// [`[T]: : concat`](స్లైస్::concat) అమలు
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// [`[T]: : join`](స్లైస్::చేరండి) కోసం trait సహాయకుడు
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// సంయోగం తరువాత ఫలిత రకం
    type Output;

    /// [`[T]: : join`](స్లైస్::చేరండి) అమలు
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// ముక్కల కోసం ప్రామాణిక trait అమలు
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // తిరిగి వ్రాయబడని లక్ష్యాన్ని ఏదైనా వదలండి
        target.truncate(self.len());

        // target.len <= self.len పైన కత్తిరించబడిన కారణంగా, ఇక్కడ ముక్కలు ఎల్లప్పుడూ సరిహద్దులో ఉంటాయి.
        //
        let (init, tail) = self.split_at(target.len());

        // ఉన్న విలువలు allocations/resources ను తిరిగి ఉపయోగించుకోండి.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// `v[0]` ను ప్రీ-సార్టెడ్ సీక్వెన్స్ `v[1..]` లోకి చొప్పిస్తుంది, తద్వారా మొత్తం `v[..]` క్రమబద్ధీకరించబడుతుంది.
///
/// ఇది చొప్పించే విధమైన సమగ్ర సబ్‌ట్రౌటిన్.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // ఇక్కడ చొప్పించడం అమలు చేయడానికి మూడు మార్గాలు ఉన్నాయి:
            //
            // 1. మొదటిది దాని తుది గమ్యస్థానానికి వచ్చే వరకు ప్రక్కనే ఉన్న అంశాలను మార్చుకోండి.
            //    అయితే, ఈ విధంగా మేము అవసరమైన దానికంటే ఎక్కువ డేటాను కాపీ చేస్తాము.
            //    అంశాలు పెద్ద నిర్మాణాలు అయితే (కాపీ చేయడానికి ఖరీదైనవి), ఈ పద్ధతి నెమ్మదిగా ఉంటుంది.
            //
            // 2. మొదటి మూలకానికి సరైన స్థలం దొరికే వరకు మళ్ళించండి.
            // దాని తరువాత వచ్చే అంశాలను దాని కోసం స్థలం చేయడానికి మార్చండి మరియు చివరికి మిగిలిన రంధ్రంలో ఉంచండి.
            // ఇది మంచి పద్ధతి.
            //
            // 3. మొదటి మూలకాన్ని తాత్కాలిక వేరియబుల్‌లోకి కాపీ చేయండి.దానికి సరైన స్థలం దొరికే వరకు మళ్ళించండి.
            // మేము వెళ్ళేటప్పుడు, ప్రయాణించిన ప్రతి మూలకాన్ని దాని ముందు ఉన్న స్లాట్‌లోకి కాపీ చేయండి.
            // చివరగా, తాత్కాలిక వేరియబుల్ నుండి డేటాను మిగిలిన రంధ్రంలోకి కాపీ చేయండి.
            // ఈ పద్ధతి చాలా మంచిది.
            // 2 వ పద్ధతి కంటే బెంచ్‌మార్క్‌లు కొంచెం మెరుగైన పనితీరును ప్రదర్శించాయి.
            //
            // అన్ని పద్ధతులు బెంచ్ మార్క్ చేయబడ్డాయి మరియు 3 వ ఉత్తమ ఫలితాలను చూపించింది.కాబట్టి మేము దానిని ఎంచుకున్నాము.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // చొప్పించే ప్రక్రియ యొక్క ఇంటర్మీడియట్ స్థితి ఎల్లప్పుడూ `hole` చేత ట్రాక్ చేయబడుతుంది, ఇది రెండు ప్రయోజనాలకు ఉపయోగపడుతుంది:
            // 1. `is_less` లోని panics నుండి `v` యొక్క సమగ్రతను రక్షిస్తుంది.
            // 2. చివరికి `v` లో మిగిలిన రంధ్రం నింపుతుంది.
            //
            // Panic భద్రత:
            //
            // ఈ ప్రక్రియలో ఏ సమయంలోనైనా `is_less` panics ఉంటే, `hole` పడిపోతుంది మరియు `v` లోని రంధ్రాన్ని `tmp` తో నింపుతుంది, తద్వారా `v` ప్రారంభంలో సరిగ్గా ఒకసారి కలిగి ఉన్న ప్రతి వస్తువును కలిగి ఉందని నిర్ధారిస్తుంది.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` పడిపోతుంది మరియు తద్వారా `tmp` ను `v` లోని మిగిలిన రంధ్రంలోకి కాపీ చేస్తుంది.
        }
    }

    // పడిపోయినప్పుడు, `src` నుండి `dest` లోకి కాపీలు.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// తగ్గని పరుగులను `v[..mid]` మరియు `v[mid..]` ను `buf` ను తాత్కాలిక నిల్వగా విలీనం చేస్తుంది మరియు ఫలితాన్ని `v[..]` లో నిల్వ చేస్తుంది.
///
/// # Safety
///
/// రెండు ముక్కలు ఖాళీగా ఉండాలి మరియు `mid` హద్దులు ఉండాలి.
/// చిన్న స్లైస్ కాపీని పట్టుకోవటానికి బఫర్ `buf` పొడవుగా ఉండాలి.
/// అలాగే, `T` తప్పనిసరిగా సున్నా-పరిమాణ రకం కాకూడదు.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // విలీన ప్రక్రియ మొదట తక్కువ పరుగును `buf` లోకి కాపీ చేస్తుంది.
    // అప్పుడు ఇది కొత్తగా కాపీ చేసిన రన్ మరియు ఎక్కువసేపు ఫార్వర్డ్ (లేదా వెనుకకు) ను కనుగొంటుంది, వాటి తదుపరి అసంకల్పిత అంశాలను పోల్చి, తక్కువ (లేదా అంతకంటే ఎక్కువ) ను `v` లోకి కాపీ చేస్తుంది.
    //
    // తక్కువ పరుగు పూర్తిగా వినియోగించిన వెంటనే, ప్రక్రియ జరుగుతుంది.ఎక్కువసేపు మొదట వినియోగిస్తే, తక్కువ పరుగులో మిగిలి ఉన్నదాన్ని `v` లోని మిగిలిన రంధ్రంలోకి కాపీ చేయాలి.
    //
    // ప్రక్రియ యొక్క ఇంటర్మీడియట్ స్థితి ఎల్లప్పుడూ `hole` చేత ట్రాక్ చేయబడుతుంది, ఇది రెండు ప్రయోజనాలకు ఉపయోగపడుతుంది:
    // 1. `is_less` లోని panics నుండి `v` యొక్క సమగ్రతను రక్షిస్తుంది.
    // 2. ఎక్కువసేపు మొదట వినియోగిస్తే `v` లో మిగిలిన రంధ్రం నింపుతుంది.
    //
    // Panic భద్రత:
    //
    // ఈ ప్రక్రియలో ఏ సమయంలోనైనా `is_less` panics ఉంటే, `hole` పడిపోతుంది మరియు X003 లోని రంధ్రం `buf` లో అసంకల్పిత పరిధితో నింపుతుంది, తద్వారా `v` ప్రారంభంలో సరిగ్గా ఒకసారి కలిగి ఉన్న ప్రతి వస్తువును కలిగి ఉందని నిర్ధారిస్తుంది.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // ఎడమ పరుగు తక్కువ.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // ప్రారంభంలో, ఈ గమనికలు వారి శ్రేణుల ప్రారంభాన్ని సూచిస్తాయి.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // తక్కువ వైపు తినండి.
            // సమానంగా ఉంటే, స్థిరత్వాన్ని కొనసాగించడానికి ఎడమ పరుగును ఇష్టపడండి.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // సరైన పరుగు తక్కువ.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // ప్రారంభంలో, ఈ పాయింటర్లు వారి శ్రేణుల చివరలను సూచిస్తాయి.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // ఎక్కువ వైపు తినండి.
            // సమానంగా ఉంటే, స్థిరత్వాన్ని కొనసాగించడానికి సరైన పరుగును ఇష్టపడండి.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // చివరగా, `hole` పడిపోతుంది.
    // తక్కువ పరుగును పూర్తిగా వినియోగించకపోతే, దానిలో మిగిలి ఉన్నవి ఇప్పుడు `v` లోని రంధ్రంలోకి కాపీ చేయబడతాయి.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // పడిపోయినప్పుడు, `start..end` పరిధిని `dest..` లోకి కాపీ చేస్తుంది.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` సున్నా-పరిమాణ రకం కాదు, కాబట్టి దాని పరిమాణంతో విభజించడం సరైందే.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// ఈ విలీన విధమైన టిమ్‌సోర్ట్ నుండి కొన్ని (కాని అన్నీ కాదు) ఆలోచనలను తీసుకుంటుంది, ఇది వివరంగా [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) లో వివరించబడింది.
///
///
/// అల్గోరిథం ఖచ్చితంగా అవరోహణ మరియు అవరోహణ కాని పరిణామాలను గుర్తిస్తుంది, వీటిని సహజ పరుగులు అంటారు.విలీనం చేయడానికి ఇంకా పెండింగ్‌లో ఉన్న పరుగుల స్టాక్ ఉంది.
/// కొత్తగా దొరికిన ప్రతి పరుగును స్టాక్‌పైకి నెట్టివేస్తారు, ఆపై ఈ రెండు మార్పులను సంతృప్తిపరిచే వరకు కొన్ని జతల ప్రక్కన ఉన్న పరుగులు విలీనం చేయబడతాయి:
///
/// 1. `1..runs.len()` లోని ప్రతి `i` కోసం: `runs[i - 1].len > runs[i].len`
/// 2. `2..runs.len()` లోని ప్రతి `i` కోసం: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// మొత్తం నడుస్తున్న సమయం *O*(*n*\*log(* n*)) చెత్త కేసు అని మార్పుదారులు నిర్ధారిస్తారు.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // ఈ పొడవు వరకు ముక్కలు చొప్పించే క్రమాన్ని ఉపయోగించి క్రమబద్ధీకరించబడతాయి.
    const MAX_INSERTION: usize = 20;
    // కనీసం చాలా ఎక్కువ అంశాలను విస్తరించడానికి చొప్పించే విధానాన్ని ఉపయోగించి చాలా తక్కువ పరుగులు విస్తరించబడతాయి.
    const MIN_RUN: usize = 10;

    // క్రమబద్ధీకరణకు సున్నా-పరిమాణ రకాలపై అర్ధవంతమైన ప్రవర్తన లేదు.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // కేటాయింపులను నివారించడానికి చిన్న శ్రేణులు చొప్పించడం ద్వారా స్థలంలో క్రమబద్ధీకరించబడతాయి.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // స్క్రాచ్ మెమరీగా ఉపయోగించడానికి బఫర్‌ను కేటాయించండి.మేము పొడవు 0 ను ఉంచుతాము, కాబట్టి `is_less` panics ఉంటే కాపీలలో నడుస్తున్న dtors ను రిస్క్ చేయకుండా `v` యొక్క విషయాల యొక్క నిస్సార కాపీలను ఉంచవచ్చు.
    //
    // రెండు క్రమబద్ధీకరించిన పరుగులను విలీనం చేసేటప్పుడు, ఈ బఫర్ తక్కువ పరుగుల కాపీని కలిగి ఉంటుంది, ఇది ఎల్లప్పుడూ ఎక్కువ `len / 2` వద్ద పొడవు కలిగి ఉంటుంది.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // `v` లో సహజ పరుగులను గుర్తించడానికి, మేము దానిని వెనుకకు ప్రయాణిస్తాము.
    // ఇది ఒక వింత నిర్ణయంలా అనిపించవచ్చు, కానీ విలీనాలు ఎక్కువగా (forwards) వ్యతిరేక దిశలో వెళ్తాయి అనే వాస్తవాన్ని పరిగణించండి.
    // బెంచ్‌మార్క్‌ల ప్రకారం, వెనుకకు విలీనం చేయడం కంటే ముందుకు విలీనం కాస్త వేగంగా ఉంటుంది.
    // ముగించడానికి, వెనుకకు ప్రయాణించడం ద్వారా పరుగులను గుర్తించడం పనితీరును మెరుగుపరుస్తుంది.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // తదుపరి సహజ పరుగును కనుగొని, అది ఖచ్చితంగా అవరోహణ అయితే దాన్ని రివర్స్ చేయండి.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // ఇది చాలా తక్కువగా ఉంటే మరికొన్ని అంశాలను పరుగులో చేర్చండి.
        // చిన్న సన్నివేశాలలో విలీనం క్రమబద్ధీకరణ కంటే చొప్పించడం క్రమంగా ఉంటుంది, కాబట్టి ఇది పనితీరును గణనీయంగా మెరుగుపరుస్తుంది.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // ఈ పరుగును స్టాక్‌లోకి నెట్టండి.
        runs.push(Run { start, len: end - start });
        end = start;

        // మార్పులను సంతృప్తి పరచడానికి కొన్ని జతల ప్రక్కన ఉన్న పరుగులను విలీనం చేయండి.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // చివరగా, సరిగ్గా ఒక పరుగు స్టాక్‌లో ఉండాలి.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // పరుగుల స్టాక్‌ను పరిశీలిస్తుంది మరియు విలీనం చేయడానికి తదుపరి జత పరుగులను గుర్తిస్తుంది.
    // మరింత ప్రత్యేకంగా, `Some(r)` తిరిగి ఇవ్వబడితే, అంటే `runs[r]` మరియు `runs[r + 1]` తప్పక విలీనం కావాలి.
    // అల్గోరిథం బదులుగా కొత్త పరుగును నిర్మించడాన్ని కొనసాగిస్తే, `None` తిరిగి వస్తుంది.
    //
    // ఇక్కడ వివరించిన విధంగా టిమ్‌సోర్ట్ దాని బగ్గీ అమలుకు అపఖ్యాతి పాలైంది:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // కథ యొక్క సారాంశం ఏమిటంటే: స్టాక్‌లోని మొదటి నాలుగు పరుగులపై మార్పులను మేము అమలు చేయాలి.
    // స్టాక్‌లోని *అన్ని* పరుగుల కోసం అస్థిరతలు ఇప్పటికీ ఉన్నాయని నిర్ధారించడానికి వాటిని కేవలం మొదటి మూడు స్థానాల్లో అమలు చేయడం సరిపోదు.
    //
    // ఈ ఫంక్షన్ మొదటి నాలుగు పరుగుల కోసం మార్పులను సరిగ్గా తనిఖీ చేస్తుంది.
    // అదనంగా, టాప్ రన్ ఇండెక్స్ 0 వద్ద ప్రారంభమైతే, క్రమబద్ధీకరణను పూర్తి చేయడానికి, స్టాక్ పూర్తిగా కూలిపోయే వరకు ఇది ఎల్లప్పుడూ విలీన ఆపరేషన్‌ను కోరుతుంది.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}