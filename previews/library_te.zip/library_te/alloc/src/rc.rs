//! సింగిల్-థ్రెడ్ రిఫరెన్స్-కౌంటింగ్ పాయింటర్లు.'Rc' అంటే 'రిఫరెన్స్
//! Counted'.
//!
//! [`Rc<T>`][`Rc`] రకం కుప్పలో కేటాయించిన `T` రకం విలువ యొక్క భాగస్వామ్య యాజమాన్యాన్ని అందిస్తుంది.
//! [`Rc`] లో [`clone`][clone] ను ప్రారంభించడం కుప్పలో అదే కేటాయింపుకు కొత్త పాయింటర్‌ను ఉత్పత్తి చేస్తుంది.
//! ఇచ్చిన కేటాయింపుకు చివరి [`Rc`] పాయింటర్ నాశనం అయినప్పుడు, ఆ కేటాయింపులో నిల్వ చేయబడిన విలువ (తరచుగా "inner value" గా సూచిస్తారు) కూడా పడిపోతుంది.
//!
//! Rust లో భాగస్వామ్య సూచనలు డిఫాల్ట్‌గా మ్యుటేషన్‌ను అనుమతించవు, మరియు [`Rc`] దీనికి మినహాయింపు కాదు: మీరు సాధారణంగా [`Rc`] లోపల దేనినైనా మార్చగల సూచనను పొందలేరు.
//! మీకు మ్యుటబిలిటీ అవసరమైతే, [`Rc`] లోపల [`Cell`] లేదా [`RefCell`] ఉంచండి;[an example of mutability inside an `Rc`][mutability] చూడండి.
//!
//! [`Rc`] అణు రహిత సూచన లెక్కింపును ఉపయోగిస్తుంది.
//! దీని అర్థం ఓవర్ హెడ్ చాలా తక్కువ, కానీ థ్రెడ్ల మధ్య [`Rc`] పంపబడదు మరియు తత్ఫలితంగా [`Rc`] [`Send`][send] ను అమలు చేయదు.
//! ఫలితంగా, Rust కంపైలర్ మీరు థ్రెడ్ల మధ్య [`Rc`] లను పంపడం లేదని కంపైల్ సమయంలో * తనిఖీ చేస్తుంది.
//! మీకు బహుళ-థ్రెడ్, అణు సూచన లెక్కింపు అవసరమైతే, [`sync::Arc`][arc] ఉపయోగించండి.
//!
//! [`downgrade`][downgrade] పద్ధతిని స్వంతం కాని [`Weak`] పాయింటర్‌ను సృష్టించడానికి ఉపయోగించవచ్చు.
//! [`Weak`] పాయింటర్ ఒక [`Rc`] కి [`అప్‌గ్రేడ్`][అప్‌గ్రేడ్] d కావచ్చు, అయితే కేటాయింపులో నిల్వ చేసిన విలువ ఇప్పటికే పడిపోతే ఇది [`None`] ను తిరిగి ఇస్తుంది.
//! మరో మాటలో చెప్పాలంటే, `Weak` పాయింటర్లు కేటాయింపు లోపల విలువను సజీవంగా ఉంచవు;అయినప్పటికీ, వారు కేటాయింపులను (అంతర్గత విలువకు బ్యాకింగ్ స్టోర్) సజీవంగా ఉంచుతారు.
//!
//! [`Rc`] పాయింటర్ల మధ్య చక్రం ఎప్పటికీ డీలోకేట్ చేయబడదు.
//! ఈ కారణంగా, [`Weak`] చక్రాలను విచ్ఛిన్నం చేయడానికి ఉపయోగించబడుతుంది.
//! ఉదాహరణకు, ఒక చెట్టుకు పేరెంట్ నోడ్స్ నుండి పిల్లలకు బలమైన [`Rc`] పాయింటర్లు ఉండవచ్చు మరియు పిల్లల నుండి వారి తల్లిదండ్రులకు [`Weak`] పాయింటర్లు ఉండవచ్చు.
//!
//! `Rc<T>` స్వయంచాలకంగా `T` ([`Deref`] trait ద్వారా) కు డీరెఫరెన్స్‌లు, కాబట్టి మీరు [`Rc<T>`][`Rc`] రకం విలువపై `T` యొక్క పద్ధతులను పిలుస్తారు.
//! `T` యొక్క పద్ధతులతో పేరు ఘర్షణలను నివారించడానికి, [`Rc<T>`][`Rc`] యొక్క పద్ధతులు అనుబంధిత విధులు, వీటిని [fully qualified syntax] ఉపయోగించి పిలుస్తారు:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `ఆర్.సి.<T>`Clone` వంటి traits యొక్క అమలులను కూడా పూర్తి అర్హత గల వాక్యనిర్మాణాన్ని ఉపయోగించి పిలుస్తారు.
//! కొంతమంది పూర్తి అర్హత గల వాక్యనిర్మాణాన్ని ఉపయోగించటానికి ఇష్టపడతారు, మరికొందరు పద్ధతి-కాల్ వాక్యనిర్మాణాన్ని ఉపయోగించడాన్ని ఇష్టపడతారు.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // విధానం-కాల్ వాక్యనిర్మాణం
//! let rc2 = rc.clone();
//! // పూర్తిగా అర్హత కలిగిన వాక్యనిర్మాణం
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] `T` కు స్వయంచాలకంగా డీరెఫరెన్స్ చేయదు, ఎందుకంటే లోపలి విలువ ఇప్పటికే తొలగించబడి ఉండవచ్చు.
//!
//! # క్లోనింగ్ సూచనలు
//!
//! ఇప్పటికే ఉన్న రిఫరెన్స్ కౌంట్ పాయింటర్ వలె అదే కేటాయింపుకు క్రొత్త సూచనను సృష్టించడం [`Rc<T>`][`Rc`] మరియు [`Weak<T>`][`Weak`] కొరకు అమలు చేయబడిన `Clone` trait ను ఉపయోగించి జరుగుతుంది.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // క్రింద ఉన్న రెండు వాక్యనిర్మాణాలు సమానం.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a మరియు b రెండూ foo వలె ఒకే మెమరీ స్థానాన్ని సూచిస్తాయి.
//! ```
//!
//! `Rc::clone(&from)` సింటాక్స్ చాలా ఇడియొమాటిక్ ఎందుకంటే ఇది కోడ్ యొక్క అర్ధాన్ని మరింత స్పష్టంగా తెలియజేస్తుంది.
//! పై ఉదాహరణలో, ఈ సింటాక్స్ ఈ కోడ్ foo యొక్క మొత్తం కంటెంట్‌ను కాపీ చేయకుండా క్రొత్త సూచనను సృష్టిస్తుందని చూడటం సులభం చేస్తుంది.
//!
//! # Examples
//!
//! ఇచ్చిన `Owner` చేత `గాడ్జెట్'ల సమితి ఉన్న దృష్టాంతాన్ని పరిగణించండి.
//! మేము మా `గాడ్జెట్` యొక్క పాయింట్‌ను వారి `Owner` కి కలిగి ఉండాలనుకుంటున్నాము.ప్రత్యేకమైన యాజమాన్యంతో మేము దీన్ని చేయలేము, ఎందుకంటే ఒకటి కంటే ఎక్కువ గాడ్జెట్‌లు ఒకే `Owner` కి చెందినవి కావచ్చు.
//! [`Rc`] బహుళ `గాడ్జెట్'ల మధ్య `Owner` ను పంచుకోవడానికి మాకు అనుమతిస్తుంది, మరియు `Owner` దాని వద్ద ఏదైనా `Gadget` పాయింట్లు ఉన్నంతవరకు కేటాయించబడి ఉంటుంది.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... ఇతర రంగాలు
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... ఇతర రంగాలు
//! }
//!
//! fn main() {
//!     // సూచన-లెక్కించిన `Owner` ను సృష్టించండి.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // `gadget_owner` కి చెందిన `గాడ్జెట్'లను సృష్టించండి.
//!     // `Rc<Owner>` ను క్లోనింగ్ చేయడం వలన అదే `Owner` కేటాయింపుకు కొత్త పాయింటర్ ఇస్తుంది, ఈ ప్రక్రియలో రిఫరెన్స్ కౌంట్ పెరుగుతుంది.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // మా స్థానిక వేరియబుల్ `gadget_owner` ను పారవేయండి.
//!     drop(gadget_owner);
//!
//!     // `gadget_owner` ను వదిలివేసినప్పటికీ, మేము ఇప్పటికీ `గాడ్జెట్` యొక్క `Owner` పేరును ముద్రించగలుగుతున్నాము.
//!     // దీనికి కారణం మనం సూచించిన `Owner` కాకుండా ఒకే `Rc<Owner>` ను మాత్రమే వదిలివేసాము.
//!     // అదే `Owner` కేటాయింపు వద్ద ఇతర `Rc<Owner>` పాయింటింగ్ ఉన్నంత వరకు, అది ప్రత్యక్షంగా ఉంటుంది.
//!     // ఫీల్డ్ ప్రొజెక్షన్ `gadget1.owner.name` పనిచేస్తుంది ఎందుకంటే `Rc<Owner>` స్వయంచాలకంగా `Owner` కు క్షీణిస్తుంది.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // ఫంక్షన్ చివరిలో, `gadget1` మరియు `gadget2` నాశనం చేయబడతాయి మరియు వాటితో మా `Owner` కు చివరిగా లెక్కించబడిన సూచనలు.
//!     // గాడ్జెట్ మ్యాన్ ఇప్పుడు కూడా నాశనం అవుతుంది.
//!     //
//! }
//! ```
//!
//! మా అవసరాలు మారితే, మరియు మేము కూడా `Owner` నుండి `Gadget` వరకు ప్రయాణించగలగాలి, మేము సమస్యల్లో పడ్డాము.
//! `Owner` నుండి `Gadget` వరకు [`Rc`] పాయింటర్ ఒక చక్రాన్ని పరిచయం చేస్తుంది.
//! దీని అర్థం వారి సూచన గణనలు 0 కి ఎప్పటికీ చేరలేవు మరియు కేటాయింపు ఎప్పటికీ నాశనం చేయబడదు:
//! మెమరీ లీక్.దీన్ని చుట్టుముట్టడానికి, మేము [`Weak`] పాయింటర్లను ఉపయోగించవచ్చు.
//!
//! Rust వాస్తవానికి ఈ లూప్‌ను మొదటి స్థానంలో ఉత్పత్తి చేయడం కొంత కష్టతరం చేస్తుంది.ఒకదానికొకటి సూచించే రెండు విలువలతో ముగించడానికి, వాటిలో ఒకటి మార్చగలగాలి.
//! ఇది కష్టం ఎందుకంటే [`Rc`] మెమరీ భద్రతను అమలు చేస్తుంది, అది మూటగట్టుకున్న విలువకు భాగస్వామ్య సూచనలు ఇవ్వడం ద్వారా మరియు ఇవి ప్రత్యక్ష మ్యుటేషన్‌ను అనుమతించవు.
//! మేము [`RefCell`] లో పరివర్తనం చెందాలనుకునే విలువలో కొంత భాగాన్ని చుట్టాలి, ఇది *ఇంటీరియర్ మ్యూటబిలిటీ* ను అందిస్తుంది: షేర్డ్ రిఫరెన్స్ ద్వారా మ్యుటబిలిటీని సాధించే పద్ధతి.
//! [`RefCell`] రన్‌టైమ్‌లో Rust యొక్క రుణాలు నియమాలను అమలు చేస్తుంది.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... ఇతర రంగాలు
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... ఇతర రంగాలు
//! }
//!
//! fn main() {
//!     // సూచన-లెక్కించిన `Owner` ను సృష్టించండి.
//!     // `గాడ్జెట్` యొక్క`యజమాని` యొక్క vector ను `RefCell` లోపల ఉంచామని గమనించండి, తద్వారా దీన్ని భాగస్వామ్య సూచన ద్వారా మార్చవచ్చు.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // మునుపటిలాగే `gadget_owner` కి చెందిన `గాడ్జెట్'లను సృష్టించండి.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // వారి `Owner` కు `గాడ్జెట్'లను జోడించండి.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` డైనమిక్ రుణం ఇక్కడ ముగుస్తుంది.
//!     }
//!
//!     // మా `గాడ్జెట్'లపై వారి వివరాలను ముద్రించండి.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` ఇది `Weak<Gadget>`.
//!         // `Weak` పాయింటర్లు కేటాయింపు ఇప్పటికీ ఉందని హామీ ఇవ్వలేనందున, మేము `upgrade` కి కాల్ చేయాలి, ఇది `Option<Rc<Gadget>>` ను అందిస్తుంది.
//!         //
//!         //
//!         // ఈ సందర్భంలో కేటాయింపు ఇప్పటికీ ఉందని మాకు తెలుసు, కాబట్టి మేము కేవలం `unwrap` `Option`.
//!         // మరింత క్లిష్టమైన ప్రోగ్రామ్‌లో, మీకు `None` ఫలితం కోసం అందమైన లోపం నిర్వహణ అవసరం కావచ్చు.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // ఫంక్షన్ చివరిలో, `gadget_owner`, `gadget1` మరియు `gadget2` నాశనం చేయబడతాయి.
//!     // గాడ్జెట్‌లకు ఇప్పుడు బలమైన (`Rc`) పాయింటర్లు లేవు, కాబట్టి అవి నాశనం అవుతాయి.
//!     // ఇది గాడ్జెట్ మ్యాన్‌పై సూచనల సంఖ్యను సున్నా చేస్తుంది, కాబట్టి అతను కూడా నాశనం అవుతాడు.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// క్షేత్ర-క్రమాన్ని మార్చడానికి వ్యతిరేకంగా ఇది repr(C) నుండి future-రుజువు, ఇది పరివర్తన చెందగల అంతర్గత రకాల సురక్షితమైన [into|from]_raw() తో జోక్యం చేసుకుంటుంది.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// సింగిల్-థ్రెడ్ రిఫరెన్స్-కౌంటింగ్ పాయింటర్.'Rc' అంటే 'రిఫరెన్స్
/// Counted'.
///
/// మరిన్ని వివరాల కోసం [module-level documentation](./index.html) చూడండి.
///
/// `Rc` యొక్క స్వాభావిక పద్ధతులు అన్నీ అనుబంధిత విధులు, అంటే మీరు వాటిని ఉదా, `value.get_mut()` కు బదులుగా [`Rc::get_mut(&mut value)`][get_mut] అని పిలవాలి.
/// ఇది అంతర్గత రకం `T` యొక్క పద్ధతులతో విభేదాలను నివారిస్తుంది.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // ఈ అసురక్షితత సరే ఎందుకంటే ఈ Rc సజీవంగా ఉన్నప్పుడు లోపలి పాయింటర్ చెల్లుబాటు అవుతుందని మేము హామీ ఇస్తున్నాము.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// క్రొత్త `Rc<T>` ను నిర్మిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // అన్ని బలమైన పాయింటర్ల యాజమాన్యంలోని అవ్యక్త బలహీనమైన పాయింటర్ ఉంది, ఇది బలహీనమైన పాయింటర్ బలమైన వాటిలో నిల్వ చేసినప్పటికీ, బలమైన డిస్ట్రక్టర్ నడుస్తున్నప్పుడు బలహీనమైన డిస్ట్రక్టర్ ఎప్పుడూ కేటాయింపును విముక్తి పొందలేదని నిర్ధారిస్తుంది.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// తనకు బలహీనమైన సూచనను ఉపయోగించి కొత్త `Rc<T>` ను నిర్మిస్తుంది.
    /// ఈ ఫంక్షన్ తిరిగి రాకముందే బలహీనమైన సూచనను అప్‌గ్రేడ్ చేయడానికి ప్రయత్నిస్తే `None` విలువ వస్తుంది.
    ///
    /// అయినప్పటికీ, బలహీనమైన సూచన స్వేచ్ఛగా క్లోన్ చేయబడి, తరువాత సమయంలో ఉపయోగం కోసం నిల్వ చేయబడుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... మరిన్ని ఫీల్డ్‌లు
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // "uninitialized" స్థితిలో లోపలి భాగాన్ని ఒకే బలహీన సూచనతో నిర్మించండి.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // బలహీనమైన పాయింటర్ యొక్క యాజమాన్యాన్ని మేము వదులుకోకపోవడం చాలా ముఖ్యం, లేకపోతే `data_fn` తిరిగి వచ్చే సమయానికి మెమరీ విముక్తి పొందవచ్చు.
        // మేము నిజంగా యాజమాన్యాన్ని పాస్ చేయాలనుకుంటే, మనకోసం అదనపు బలహీనమైన పాయింటర్‌ను సృష్టించవచ్చు, కాని ఇది బలహీనమైన రిఫరెన్స్ కౌంట్‌కు అదనపు నవీకరణలకు దారి తీస్తుంది, లేకపోతే అవసరం లేదు.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // బలమైన సూచనలు సమిష్టిగా భాగస్వామ్య బలహీనమైన సూచనను కలిగి ఉండాలి, కాబట్టి మా పాత బలహీనమైన సూచన కోసం డిస్ట్రక్టర్‌ను అమలు చేయవద్దు.
        //
        mem::forget(weak);
        strong
    }

    /// ప్రారంభించని విషయాలతో కొత్త `Rc` ను నిర్మిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // వాయిదా వేసిన ప్రారంభించడం:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// మెమరీని `0` బైట్‌లతో నింపడంతో, ప్రారంభించని విషయాలతో కొత్త `Rc` ను నిర్మిస్తుంది.
    ///
    ///
    /// ఈ పద్ధతి యొక్క సరైన మరియు తప్పు వాడకానికి ఉదాహరణల కోసం [`MaybeUninit::zeroed`][zeroed] చూడండి.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// క్రొత్త `Rc<T>` ను నిర్మిస్తుంది, కేటాయింపు విఫలమైతే లోపం తిరిగి వస్తుంది
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // అన్ని బలమైన పాయింటర్ల యాజమాన్యంలోని అవ్యక్త బలహీనమైన పాయింటర్ ఉంది, ఇది బలహీనమైన పాయింటర్ బలమైన వాటిలో నిల్వ చేసినప్పటికీ, బలమైన డిస్ట్రక్టర్ నడుస్తున్నప్పుడు బలహీనమైన డిస్ట్రక్టర్ ఎప్పుడూ కేటాయింపును విముక్తి పొందలేదని నిర్ధారిస్తుంది.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// ప్రారంభించని విషయాలతో క్రొత్త `Rc` ను నిర్మిస్తుంది, కేటాయింపు విఫలమైతే లోపం తిరిగి వస్తుంది
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // వాయిదా వేసిన ప్రారంభించడం:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// మెమరీని `0` బైట్‌లతో నింపడంతో, ప్రారంభించని విషయాలతో కొత్త `Rc` ను నిర్మిస్తుంది, కేటాయింపు విఫలమైతే లోపం తిరిగి వస్తుంది
    ///
    ///
    /// ఈ పద్ధతి యొక్క సరైన మరియు తప్పు వాడకానికి ఉదాహరణల కోసం [`MaybeUninit::zeroed`][zeroed] చూడండి.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// క్రొత్త `Pin<Rc<T>>` ను నిర్మిస్తుంది.
    /// `T` `Unpin` ను అమలు చేయకపోతే, అప్పుడు `value` మెమరీలో పిన్ చేయబడుతుంది మరియు తరలించబడదు.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// `Rc` ఖచ్చితంగా ఒక బలమైన సూచనను కలిగి ఉంటే, అంతర్గత విలువను చూపుతుంది.
    ///
    /// లేకపోతే, ఒక [`Err`] అదే `Rc` తో తిరిగి ఇవ్వబడుతుంది.
    ///
    ///
    /// అసాధారణమైన బలహీనమైన సూచనలు ఉన్నప్పటికీ ఇది విజయవంతమవుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // ఉన్న వస్తువును కాపీ చేయండి

                // బలమైన గణనను తగ్గించడం ద్వారా వాటిని ప్రోత్సహించలేమని బలహీనతలకు సూచించండి, ఆపై నకిలీ బలహీనతను రూపొందించడం ద్వారా డ్రాప్ లాజిక్‌ని కూడా నిర్వహించేటప్పుడు అవ్యక్త "strong weak" పాయింటర్‌ను తొలగించండి.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// ప్రారంభించని విషయాలతో క్రొత్త సూచన-లెక్కించిన స్లైస్‌ని నిర్మిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // వాయిదా వేసిన ప్రారంభించడం:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// `0` బైట్‌లతో మెమరీ నిండిన, ప్రారంభించని విషయాలతో కొత్త రిఫరెన్స్-కౌంటెడ్ స్లైస్‌ను నిర్మిస్తుంది.
    ///
    ///
    /// ఈ పద్ధతి యొక్క సరైన మరియు తప్పు వాడకానికి ఉదాహరణల కోసం [`MaybeUninit::zeroed`][zeroed] చూడండి.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// `Rc<T>` కి మారుస్తుంది.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] మాదిరిగా, అంతర్గత విలువ నిజంగా ప్రారంభ స్థితిలో ఉందని హామీ ఇవ్వడం కాలర్ వరకు ఉంటుంది.
    ///
    /// కంటెంట్ ఇంకా పూర్తిగా ప్రారంభించబడనప్పుడు దీన్ని పిలవడం తక్షణం నిర్వచించబడని ప్రవర్తనకు కారణమవుతుంది.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // వాయిదా వేసిన ప్రారంభించడం:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// `Rc<[T]>` కి మారుస్తుంది.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] మాదిరిగా, అంతర్గత విలువ నిజంగా ప్రారంభ స్థితిలో ఉందని హామీ ఇవ్వడం కాలర్ వరకు ఉంటుంది.
    ///
    /// కంటెంట్ ఇంకా పూర్తిగా ప్రారంభించబడనప్పుడు దీన్ని పిలవడం తక్షణం నిర్వచించబడని ప్రవర్తనకు కారణమవుతుంది.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // వాయిదా వేసిన ప్రారంభించడం:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// చుట్టిన పాయింటర్‌ను తిరిగి ఇచ్చి, `Rc` ను వినియోగిస్తుంది.
    ///
    /// మెమరీ లీక్‌ను నివారించడానికి పాయింటర్‌ను [`Rc::from_raw`][from_raw] ఉపయోగించి తిరిగి `Rc` గా మార్చాలి.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// డేటాకు ముడి పాయింటర్‌ను అందిస్తుంది.
    ///
    /// గణనలు ఏ విధంగానూ ప్రభావితం కావు మరియు `Rc` వినియోగించబడదు.
    /// `Rc` లో బలమైన గణనలు ఉన్నంత వరకు పాయింటర్ చెల్లుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // భద్రత: ఇది Deref::deref లేదా Rc::inner ద్వారా వెళ్ళదు ఎందుకంటే
        // ఉదా. raw/mut రుజువును నిలుపుకోవటానికి ఇది అవసరం
        // `get_mut` `from_raw` ద్వారా Rc కోలుకున్న తర్వాత పాయింటర్ ద్వారా వ్రాయవచ్చు.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// ముడి పాయింటర్ నుండి `Rc<T>` ను నిర్మిస్తుంది.
    ///
    /// ముడి పాయింటర్ గతంలో [`Rc<U>::into_raw`][into_raw] కు కాల్ ద్వారా తిరిగి ఇవ్వబడి ఉండాలి, ఇక్కడ `U` కి `T` వలె అదే పరిమాణం మరియు అమరిక ఉండాలి.
    /// `U` `T` అయితే ఇది చాలా తక్కువ నిజం.
    /// `U` `T` కాకపోయినా ఒకే పరిమాణం మరియు అమరిక కలిగి ఉంటే, ఇది ప్రాథమికంగా వివిధ రకాల సూచనలను ప్రసారం చేయడం లాంటిదని గమనించండి.
    /// ఈ సందర్భంలో ఏ పరిమితులు వర్తిస్తాయో మరింత సమాచారం కోసం [`mem::transmute`][transmute] చూడండి.
    ///
    /// `from_raw` యొక్క వినియోగదారు `T` యొక్క నిర్దిష్ట విలువ ఒక్కసారి మాత్రమే పడిపోతుందని నిర్ధారించుకోవాలి.
    ///
    /// ఈ ఫంక్షన్ సురక్షితం కాదు ఎందుకంటే తిరిగి వచ్చిన `Rc<T>` ఎప్పుడూ యాక్సెస్ చేయకపోయినా, సరికాని ఉపయోగం మెమరీ అసురక్షితతకు దారితీస్తుంది.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // లీక్‌ను నివారించడానికి `Rc` కి తిరిగి మార్చండి.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Rc::from_raw(x_ptr)` కి మరింత కాల్స్ మెమరీ-అసురక్షితమైనవి.
    /// }
    ///
    /// // `x` పై పరిధి నుండి బయటకు వెళ్ళినప్పుడు మెమరీ విముక్తి పొందింది, కాబట్టి `x_ptr` ఇప్పుడు డాంగ్లింగ్ అవుతోంది!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // అసలు RcBox ను కనుగొనడానికి ఆఫ్‌సెట్‌ను రివర్స్ చేయండి.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// ఈ కేటాయింపుకు కొత్త [`Weak`] పాయింటర్‌ను సృష్టిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // మేము డాంగ్లింగ్ బలహీనతను సృష్టించలేదని నిర్ధారించుకోండి
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// ఈ కేటాయింపుకు [`Weak`] పాయింటర్ల సంఖ్యను పొందుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// ఈ కేటాయింపుకు బలమైన (`Rc`) పాయింటర్ల సంఖ్యను పొందుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// ఈ కేటాయింపుకు ఇతర `Rc` లేదా [`Weak`] పాయింటర్లు లేకపోతే `true` ను అందిస్తుంది.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// ఒకే కేటాయింపుకు ఇతర `Rc` లేదా [`Weak`] పాయింటర్లు లేనట్లయితే, ఇచ్చిన `Rc` లోకి మార్చగల సూచనను అందిస్తుంది.
    ///
    ///
    /// [`None`] లేకపోతే తిరిగి ఇస్తుంది, ఎందుకంటే భాగస్వామ్య విలువను మార్చడం సురక్షితం కాదు.
    ///
    /// [`make_mut`][make_mut] కూడా చూడండి, ఇది ఇతర పాయింటర్లు ఉన్నప్పుడు అంతర్గత విలువను [`clone`][clone] చేస్తుంది.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// ఎటువంటి తనిఖీ లేకుండా, ఇచ్చిన `Rc` లోకి మార్చగల సూచనను అందిస్తుంది.
    ///
    /// [`get_mut`] కూడా చూడండి, ఇది సురక్షితమైనది మరియు తగిన తనిఖీలు చేస్తుంది.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// ఒకే కేటాయింపుకు మరే ఇతర `Rc` లేదా [`Weak`] పాయింటర్లు తిరిగి వచ్చిన రుణం యొక్క వ్యవధికి సూచించబడకూడదు.
    ///
    /// అటువంటి పాయింటర్లు ఏవీ లేనట్లయితే ఇది చాలా చిన్నది, ఉదాహరణకు `Rc::new` తర్వాత వెంటనే.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // "count" ఫీల్డ్‌లను కవర్ చేసే సూచనను * సృష్టించకుండా ఉండటానికి మేము జాగ్రత్తగా ఉన్నాము, ఎందుకంటే ఇది రిఫరెన్స్ గణనలకు ప్రాప్యతతో విభేదిస్తుంది (ఉదా.
        // `Weak` ద్వారా).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// రెండు `Rc` లు ఒకే కేటాయింపును సూచిస్తే ([`ptr::eq`] కు సమానమైన సిరలో) `true` ను అందిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// ఇచ్చిన `Rc` లోకి మార్చగల సూచన చేస్తుంది.
    ///
    /// అదే కేటాయింపుకు ఇతర `Rc` పాయింటర్లు ఉంటే, ప్రత్యేకమైన యాజమాన్యాన్ని నిర్ధారించడానికి `make_mut` క్రొత్త కేటాయింపుకు అంతర్గత విలువను [`clone`] చేస్తుంది.
    /// దీనిని క్లోన్-ఆన్-రైట్ అని కూడా పిలుస్తారు.
    ///
    /// ఈ కేటాయింపుకు ఇతర `Rc` పాయింటర్లు లేకపోతే, అప్పుడు ఈ కేటాయింపుకు [`Weak`] పాయింటర్లు విడదీయబడతాయి.
    ///
    /// [`get_mut`] కూడా చూడండి, ఇది క్లోనింగ్ కాకుండా విఫలమవుతుంది.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // దేనినీ క్లోన్ చేయరు
    /// let mut other_data = Rc::clone(&data);    // అంతర్గత డేటాను క్లోన్ చేయదు
    /// *Rc::make_mut(&mut data) += 1;        // అంతర్గత డేటాను క్లోన్ చేస్తుంది
    /// *Rc::make_mut(&mut data) += 1;        // దేనినీ క్లోన్ చేయరు
    /// *Rc::make_mut(&mut other_data) *= 2;  // దేనినీ క్లోన్ చేయరు
    ///
    /// // ఇప్పుడు `data` మరియు `other_data` వేర్వేరు కేటాయింపులను సూచిస్తాయి.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] పాయింటర్లు వేరు చేయబడతాయి:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // డేటాను క్లోన్ చేయాలి, ఇతర Rc లు ఉన్నాయి.
            // క్లోన్ చేసిన విలువను నేరుగా వ్రాయడానికి అనుమతించడానికి మెమరీని ముందుగా కేటాయించండి.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // డేటాను దొంగిలించగలదు, మిగిలి ఉన్నది బలహీనమైనది
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // అవ్యక్త బలమైన-బలహీనమైన రెఫ్‌ను తొలగించండి (ఇక్కడ నకిలీ బలహీనతను రూపొందించాల్సిన అవసరం లేదు-ఇతర బలహీనతలు మన కోసం శుభ్రం చేయగలవని మాకు తెలుసు)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // ఈ అసురక్షితత సరే, ఎందుకంటే తిరిగి వచ్చిన పాయింటర్ *మాత్రమే* పాయింటర్ అని టికి తిరిగి ఇవ్వబడుతుంది.
        // మా రిఫరెన్స్ కౌంట్ ఈ సమయంలో 1 గా ఉంటుందని హామీ ఇవ్వబడింది, మరియు మాకు `Rc<T>` ను `mut` గా ఉండాల్సిన అవసరం ఉంది, కాబట్టి మేము కేటాయింపుకు సాధ్యమయ్యే ఏకైక సూచనను తిరిగి ఇస్తున్నాము.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Rc<dyn Any>` ను కాంక్రీట్ రకానికి తగ్గించే ప్రయత్నం.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// విలువ లేఅవుట్‌ను అందించిన చోట, పరిమాణం లేని అంతర్గత విలువకు తగిన స్థలంతో `RcBox<T>` ని కేటాయిస్తుంది.
    ///
    /// `mem_to_rcbox` ఫంక్షన్‌ను డేటా పాయింటర్‌తో పిలుస్తారు మరియు `RcBox<T>` కోసం ఒక (సంభావ్య కొవ్వు)-పాయింటర్‌ను తిరిగి ఇవ్వాలి.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // ఇచ్చిన విలువ లేఅవుట్ ఉపయోగించి లేఅవుట్ను లెక్కించండి.
        // గతంలో, లేఅవుట్ `&*(ptr as* const RcBox<T>)` వ్యక్తీకరణపై లెక్కించబడింది, కానీ ఇది తప్పుగా రూపొందించిన సూచనను సృష్టించింది (#54908 చూడండి).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// విలువ లేఅవుట్‌ను అందించిన చోట, పరిమాణం లేని అంతర్గత విలువకు తగిన స్థలంతో `RcBox<T>` ని కేటాయిస్తుంది, కేటాయింపు విఫలమైతే లోపం తిరిగి వస్తుంది.
    ///
    ///
    /// `mem_to_rcbox` ఫంక్షన్‌ను డేటా పాయింటర్‌తో పిలుస్తారు మరియు `RcBox<T>` కోసం ఒక (సంభావ్య కొవ్వు)-పాయింటర్‌ను తిరిగి ఇవ్వాలి.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // ఇచ్చిన విలువ లేఅవుట్ ఉపయోగించి లేఅవుట్ను లెక్కించండి.
        // గతంలో, లేఅవుట్ `&*(ptr as* const RcBox<T>)` వ్యక్తీకరణపై లెక్కించబడింది, కానీ ఇది తప్పుగా రూపొందించిన సూచనను సృష్టించింది (#54908 చూడండి).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // లేఅవుట్ కోసం కేటాయించండి.
        let ptr = allocate(layout)?;

        // RcBox ను ప్రారంభించండి
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// పరిమాణం లేని అంతర్గత విలువకు తగిన స్థలంతో `RcBox<T>` ని కేటాయిస్తుంది
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // ఇచ్చిన విలువను ఉపయోగించి `RcBox<T>` కోసం కేటాయించండి.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // విలువను బైట్‌లుగా కాపీ చేయండి
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // కేటాయింపులను దాని విషయాలను వదలకుండా ఉచితం
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// ఇచ్చిన పొడవుతో `RcBox<[T]>` ని కేటాయిస్తుంది.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// స్లైస్ నుండి కొత్తగా కేటాయించిన Rc <\[T\]> లోకి మూలకాలను కాపీ చేయండి
    ///
    /// సురక్షితం కాదు ఎందుకంటే కాలర్ తప్పనిసరిగా యాజమాన్యాన్ని తీసుకోవాలి లేదా `T: Copy` ను బంధించాలి
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// ఒక నిర్దిష్ట పరిమాణంలో ఉన్న ఇటరేటర్ నుండి `Rc<[T]>` ను నిర్మిస్తుంది.
    ///
    /// పరిమాణం తప్పుగా ఉండాలంటే ప్రవర్తన నిర్వచించబడలేదు.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // T మూలకాలను క్లోనింగ్ చేసేటప్పుడు Panic గార్డు.
        // panic సందర్భంలో, క్రొత్త RcBox లో వ్రాయబడిన అంశాలు తొలగించబడతాయి, తరువాత మెమరీ విముక్తి పొందుతుంది.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // మొదటి మూలకానికి పాయింటర్
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // అంతా సవ్యం.గార్డును మరచిపోండి, కనుక ఇది కొత్త RcBox ను విడిపించదు.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` కోసం స్పెషలైజేషన్ trait ఉపయోగించబడింది.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// `Rc` ను తగ్గిస్తుంది.
    ///
    /// ఇది బలమైన సూచనల సంఖ్యను తగ్గిస్తుంది.
    /// బలమైన రిఫరెన్స్ కౌంట్ సున్నాకి చేరుకున్నట్లయితే, ఇతర సూచనలు (ఏదైనా ఉంటే) [`Weak`] మాత్రమే, కాబట్టి మేము అంతర్గత విలువను `drop` చేస్తాము.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // దేనినీ ముద్రించదు
    /// drop(foo2);   // "dropped!" ప్రింట్లు
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // ఉన్న వస్తువును నాశనం చేయండి
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // మేము విషయాలను నాశనం చేసిన అవ్యక్త "strong weak" పాయింటర్‌ను తొలగించండి.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// `Rc` పాయింటర్ యొక్క క్లోన్ చేస్తుంది.
    ///
    /// ఇది అదే కేటాయింపుకు మరొక పాయింటర్‌ను సృష్టిస్తుంది, బలమైన సూచనల సంఖ్యను పెంచుతుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// `T` కోసం `Default` విలువతో కొత్త `Rc<T>` ను సృష్టిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// `Eq` కి ఒక పద్ధతి ఉన్నప్పటికీ `Eq` లో ప్రత్యేకతను అనుమతించడానికి హాక్.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// మేము ఈ స్పెషలైజేషన్‌ను ఇక్కడ చేస్తున్నాము, మరియు `&T` లో మరింత సాధారణ ఆప్టిమైజేషన్ వలె కాదు, ఎందుకంటే ఇది రెఫ్స్‌లో అన్ని సమానత్వ తనిఖీలకు ఖర్చును జోడిస్తుంది.
/// పెద్ద విలువలను నిల్వ చేయడానికి `Rc` లు ఉపయోగించబడుతున్నాయని మేము అనుకుంటాము, అవి క్లోన్ చేయడానికి నెమ్మదిగా ఉంటాయి, కానీ సమానత్వం కోసం తనిఖీ చేయడానికి కూడా భారీగా ఉంటాయి, దీనివల్ల ఈ ఖర్చు మరింత తేలికగా చెల్లించబడుతుంది.
///
/// ఇది రెండు `&T` ల కంటే రెండు `Rc` క్లోన్‌లను కలిగి ఉండే అవకాశం ఉంది.
///
/// `PartialEq` గా `T: Eq` ఉద్దేశపూర్వకంగా అసంకల్పితంగా ఉన్నప్పుడు మాత్రమే మేము దీన్ని చేయగలం.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// రెండు `Rc` లకు సమానత్వం.
    ///
    /// వేర్వేరు కేటాయింపులలో నిల్వ చేసినప్పటికీ, వాటి అంతర్గత విలువలు సమానంగా ఉంటే రెండు `Rc` లు సమానంగా ఉంటాయి.
    ///
    /// `T` కూడా `Eq` ను అమలు చేస్తే (సమానత్వం యొక్క రిఫ్లెక్సివిటీని సూచిస్తుంది), ఒకే కేటాయింపును సూచించే రెండు `Rc` లు ఎల్లప్పుడూ సమానంగా ఉంటాయి.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// రెండు `Rc` లకు అసమానత.
    ///
    /// వారి అంతర్గత విలువలు అసమానంగా ఉంటే రెండు `Rc` లు అసమానంగా ఉంటాయి.
    ///
    /// `T` కూడా `Eq` ను అమలు చేస్తే (సమానత్వం యొక్క రిఫ్లెక్సివిటీని సూచిస్తుంది), ఒకే కేటాయింపును సూచించే రెండు `Rc` లు ఎప్పుడూ అసమానమైనవి కావు.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// రెండు `Rc` లకు పాక్షిక పోలిక.
    ///
    /// రెండింటినీ వారి అంతర్గత విలువలపై `partial_cmp()` కి కాల్ చేయడం ద్వారా పోల్చారు.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// రెండు `Rc` లతో పోలిక కంటే తక్కువ.
    ///
    /// రెండింటినీ వారి అంతర్గత విలువలపై `<` కి కాల్ చేయడం ద్వారా పోల్చారు.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// రెండు `Rc` లతో పోలిక 'కన్నా తక్కువ లేదా సమానం'.
    ///
    /// రెండింటినీ వారి అంతర్గత విలువలపై `<=` కి కాల్ చేయడం ద్వారా పోల్చారు.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// రెండు `Rc` లకు పోలిక కంటే గొప్పది.
    ///
    /// రెండింటినీ వారి అంతర్గత విలువలపై `>` కి కాల్ చేయడం ద్వారా పోల్చారు.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// రెండు `Rc` లతో పోలిక 'కంటే గొప్పది లేదా సమానం'.
    ///
    /// రెండింటినీ వారి అంతర్గత విలువలపై `>=` కి కాల్ చేయడం ద్వారా పోల్చారు.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// రెండు `Rc` లకు పోలిక.
    ///
    /// రెండింటినీ వారి అంతర్గత విలువలపై `cmp()` కి కాల్ చేయడం ద్వారా పోల్చారు.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// రిఫరెన్స్-కౌంటెడ్ స్లైస్‌ని కేటాయించి, `v` యొక్క వస్తువులను క్లోనింగ్ చేయడం ద్వారా నింపండి.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// రిఫరెన్స్-కౌంటెడ్ స్ట్రింగ్ స్లైస్‌ని కేటాయించి, దానికి `v` కాపీ చేయండి.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// రిఫరెన్స్-కౌంటెడ్ స్ట్రింగ్ స్లైస్‌ని కేటాయించి, దానికి `v` కాపీ చేయండి.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// బాక్స్డ్ వస్తువును క్రొత్త, సూచన లెక్కించబడిన, కేటాయింపుకు తరలించండి.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// రిఫరెన్స్-కౌంటెడ్ స్లైస్‌ని కేటాయించి, `v` యొక్క అంశాలను దానిలోకి తరలించండి.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Vec దాని జ్ఞాపకశక్తిని విడిపించుకోవడానికి అనుమతించండి, కానీ దాని విషయాలను నాశనం చేయవద్దు
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// `Iterator` లోని ప్రతి మూలకాన్ని తీసుకొని దానిని `Rc<[T]>` లోకి సేకరిస్తుంది.
    ///
    /// # పనితీరు లక్షణాలు
    ///
    /// ## సాధారణ కేసు
    ///
    /// సాధారణ సందర్భంలో, `Rc<[T]>` లోకి సేకరించడం మొదట `Vec<T>` లోకి సేకరించడం ద్వారా జరుగుతుంది.అంటే, ఈ క్రింది వాటిని వ్రాసేటప్పుడు:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ఇది మేము వ్రాసినట్లుగా ప్రవర్తిస్తుంది:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // మొదటి కేటాయింపులు ఇక్కడ జరుగుతాయి.
    ///     .into(); // `Rc<[T]>` కోసం రెండవ కేటాయింపు ఇక్కడ జరుగుతుంది.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ఇది `Vec<T>` ను నిర్మించడానికి అవసరమైనన్ని రెట్లు కేటాయిస్తుంది మరియు తరువాత `Vec<T>` ను `Rc<[T]>` గా మార్చడానికి ఒకసారి కేటాయించబడుతుంది.
    ///
    ///
    /// ## తెలిసిన పొడవు యొక్క ఇటరేటర్లు
    ///
    /// మీ `Iterator` `TrustedLen` ను అమలు చేసినప్పుడు మరియు ఖచ్చితమైన పరిమాణంలో ఉన్నప్పుడు, `Rc<[T]>` కోసం ఒకే కేటాయింపు చేయబడుతుంది.ఉదాహరణకి:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // ఒకే కేటాయింపు ఇక్కడ జరుగుతుంది.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// `Rc<[T]>` లోకి సేకరించడానికి స్పెషలైజేషన్ trait ఉపయోగించబడుతుంది.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // `TrustedLen` ఇటరేటర్ కోసం ఇదే పరిస్థితి.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // భద్రత: ఇటరేటర్‌కు ఖచ్చితమైన పొడవు ఉందని మరియు మన దగ్గర ఉందని నిర్ధారించుకోవాలి.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // సాధారణ అమలుకు తిరిగి వస్తాయి.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` [`Rc`] యొక్క సంస్కరణ, ఇది నిర్వహించబడే కేటాయింపుకు స్వంతం కాని సూచనను కలిగి ఉంటుంది.`Weak` పాయింటర్‌లో [`upgrade`] కి కాల్ చేయడం ద్వారా కేటాయింపు ప్రాప్తి చేయబడుతుంది, ఇది [`ఎంపిక`]`<`[`Rc`] `<T>>`.
///
/// `Weak` రిఫరెన్స్ యాజమాన్యం వైపు లెక్కించనందున, కేటాయింపులో నిల్వ చేయబడిన విలువను వదిలివేయకుండా నిరోధించదు మరియు `Weak` కూడా ఇప్పటికీ ఉన్న విలువ గురించి ఎటువంటి హామీ ఇవ్వదు.
/// [`అప్‌గ్రేడ్`] d అయినప్పుడు ఇది [`None`] ను తిరిగి ఇవ్వవచ్చు.
/// అయితే, `Weak` రిఫరెన్స్ * కేటాయింపును (బ్యాకింగ్ స్టోర్) డీలోకేట్ చేయకుండా నిరోధిస్తుందని గమనించండి.
///
/// `Weak` పాయింటర్ దాని అంతర్గత విలువను వదలకుండా నిరోధించకుండా [`Rc`] చేత నిర్వహించబడే కేటాయింపులకు తాత్కాలిక సూచనను ఉంచడానికి ఉపయోగపడుతుంది.
/// [`Rc`] పాయింటర్ల మధ్య వృత్తాకార సూచనలను నివారించడానికి కూడా ఇది ఉపయోగించబడుతుంది, ఎందుకంటే పరస్పర యాజమాన్య సూచనలు [`Rc`] ను వదలడానికి ఎప్పటికీ అనుమతించవు.
/// ఉదాహరణకు, ఒక చెట్టుకు పేరెంట్ నోడ్స్ నుండి పిల్లలకు బలమైన [`Rc`] పాయింటర్లు ఉండవచ్చు మరియు పిల్లల నుండి వారి తల్లిదండ్రులకు `Weak` పాయింటర్లు ఉండవచ్చు.
///
/// `Weak` పాయింటర్ పొందటానికి సాధారణ మార్గం [`Rc::downgrade`] కి కాల్ చేయడం.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // ఎనుమ్స్‌లో ఈ రకమైన పరిమాణాన్ని ఆప్టిమైజ్ చేయడానికి ఇది `NonNull`, కానీ ఇది తప్పనిసరిగా చెల్లుబాటు అయ్యే పాయింటర్ కాదు.
    //
    // `Weak::new` దీన్ని `usize::MAX` కు సెట్ చేస్తుంది, తద్వారా కుప్పపై స్థలాన్ని కేటాయించాల్సిన అవసరం లేదు.
    // RcBox కనీసం 2 అమరికను కలిగి ఉన్నందున అది నిజమైన పాయింటర్ కలిగి ఉన్న విలువ కాదు.
    // ఇది `T: Sized` ఉన్నప్పుడు మాత్రమే సాధ్యమవుతుంది;పరిమాణం లేని `T` ఎప్పుడూ డాంగిల్ చేయదు.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// మెమరీని కేటాయించకుండా, కొత్త `Weak<T>` ను నిర్మిస్తుంది.
    /// రిటర్న్ విలువపై [`upgrade`] కి కాల్ చేస్తే ఎల్లప్పుడూ [`None`] ఇస్తుంది.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// డేటా ఫీల్డ్ గురించి ఎటువంటి వాదనలు చేయకుండా రిఫరెన్స్ గణనలను యాక్సెస్ చేయడానికి అనుమతించే సహాయక రకం.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// ఈ `Weak<T>` సూచించిన `T` ఆబ్జెక్ట్‌కు ముడి పాయింటర్‌ను అందిస్తుంది.
    ///
    /// కొన్ని బలమైన సూచనలు ఉంటేనే పాయింటర్ చెల్లుతుంది.
    /// పాయింటర్ డాంగ్లింగ్, అలైన్‌డ్ లేదా [`null`] లేకపోతే ఉండవచ్చు.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // రెండూ ఒకే వస్తువును సూచిస్తాయి
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // ఇక్కడ ఉన్నవారు దానిని సజీవంగా ఉంచుతారు, కాబట్టి మనం ఇంకా వస్తువును యాక్సెస్ చేయవచ్చు.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // కానీ ఇక లేదు.
    /// // మేము weak.as_ptr() చేయవచ్చు, కానీ పాయింటర్‌ను యాక్సెస్ చేయడం నిర్వచించబడని ప్రవర్తనకు దారి తీస్తుంది.
    /// // assert_eq! ("హలో", అసురక్షిత {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // పాయింటర్ డాంగ్లింగ్ చేస్తుంటే, మేము నేరుగా సెంటినెల్ను తిరిగి ఇస్తాము.
            // పేలోడ్ కనీసం RcBox (usize) వలె సమలేఖనం చేయబడినందున ఇది చెల్లుబాటు అయ్యే పేలోడ్ చిరునామా కాదు.
            ptr as *const T
        } else {
            // భద్రత: is_dangling తప్పుడు తిరిగి ఇస్తే, అప్పుడు పాయింటర్ నిర్మూలించదగినది.
            // ఈ సమయంలో పేలోడ్ పడిపోవచ్చు మరియు మేము నిరూపణను కొనసాగించాలి, కాబట్టి ముడి పాయింటర్ మానిప్యులేషన్ ఉపయోగించండి.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// `Weak<T>` ను వినియోగిస్తుంది మరియు దానిని పాయింటర్గా మారుస్తుంది.
    ///
    /// ఇది బలహీనమైన పాయింటర్‌ను ముడి పాయింటర్‌గా మారుస్తుంది, అదే సమయంలో ఒక బలహీనమైన సూచన యొక్క యాజమాన్యాన్ని కాపాడుతుంది (ఈ ఆపరేషన్ ద్వారా బలహీనమైన సంఖ్య సవరించబడదు).
    /// దీన్ని [`from_raw`] తో తిరిగి `Weak<T>` గా మార్చవచ్చు.
    ///
    /// [`as_ptr`] మాదిరిగానే పాయింటర్ లక్ష్యాన్ని యాక్సెస్ చేయడానికి అదే పరిమితులు వర్తిస్తాయి.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// గతంలో [`into_raw`] చే సృష్టించబడిన ముడి పాయింటర్‌ను తిరిగి `Weak<T>` గా మారుస్తుంది.
    ///
    /// సురక్షితంగా బలమైన సూచనను పొందడానికి (తరువాత [`upgrade`] కి కాల్ చేయడం ద్వారా) లేదా `Weak<T>` ను వదలడం ద్వారా బలహీనమైన గణనను తొలగించడానికి ఇది ఉపయోగపడుతుంది.
    ///
    /// ఇది ఒక బలహీనమైన సూచన యొక్క యాజమాన్యాన్ని తీసుకుంటుంది ([`new`] చే సృష్టించబడిన పాయింటర్లను మినహాయించి, ఇవి దేనినీ కలిగి ఉండవు; పద్ధతి ఇప్పటికీ వాటిపై పనిచేస్తుంది).
    ///
    /// # Safety
    ///
    /// పాయింటర్ [`into_raw`] నుండి ఉద్భవించి ఉండాలి మరియు దాని సంభావ్య బలహీనమైన సూచనను కలిగి ఉండాలి.
    ///
    /// దీన్ని పిలిచే సమయంలో బలమైన గణన 0 గా ఉండటానికి ఇది అనుమతించబడుతుంది.
    /// ఏదేమైనా, ఇది ప్రస్తుతం ముడి పాయింటర్‌గా ప్రాతినిధ్యం వహిస్తున్న ఒక బలహీనమైన సూచన యొక్క యాజమాన్యాన్ని తీసుకుంటుంది (ఈ ఆపరేషన్ ద్వారా బలహీనమైన గణన సవరించబడలేదు) మరియు కనుక ఇది [`into_raw`] కి మునుపటి కాల్‌తో జత చేయాలి.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // చివరి బలహీనమైన గణనను తగ్గించండి.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // ఇన్పుట్ పాయింటర్ ఎలా ఉద్భవించిందో సందర్భం కోసం Weak::as_ptr చూడండి.

        let ptr = if is_dangling(ptr as *mut T) {
            // ఇది బలహీనమైన బలహీనమైనది.
            ptr as *mut RcBox<T>
        } else {
            // లేకపోతే, పాయింటర్ బలహీనమైన బలహీనమైన నుండి వచ్చిందని మేము హామీ ఇస్తున్నాము.
            // భద్రత: డేటా_ఆఫ్‌సెట్ కాల్ చేయడం సురక్షితం, ఎందుకంటే పిటిఆర్ నిజమైన (సంభావ్యంగా పడిపోయిన) టి.
            let offset = unsafe { data_offset(ptr) };
            // ఈ విధంగా, మేము మొత్తం RcBox ను పొందడానికి ఆఫ్‌సెట్‌ను రివర్స్ చేస్తాము.
            // భద్రత: పాయింటర్ బలహీనమైన నుండి ఉద్భవించింది, కాబట్టి ఈ ఆఫ్‌సెట్ సురక్షితం.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // భద్రత: మేము ఇప్పుడు అసలు బలహీనమైన పాయింటర్‌ను తిరిగి పొందాము, కాబట్టి బలహీనతను సృష్టించవచ్చు.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// `Weak` పాయింటర్‌ను [`Rc`] కి అప్‌గ్రేడ్ చేయడానికి ప్రయత్నిస్తుంది, విజయవంతమైతే లోపలి విలువను వదలడం ఆలస్యం అవుతుంది.
    ///
    ///
    /// అంతర్గత విలువ అప్పటి నుండి తొలగించబడితే [`None`] ని అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // అన్ని బలమైన పాయింటర్లను నాశనం చేయండి.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// ఈ కేటాయింపును సూచించే బలమైన (`Rc`) పాయింటర్ల సంఖ్యను పొందుతుంది.
    ///
    /// [`Weak::new`] ఉపయోగించి `self` సృష్టించబడితే, ఇది 0 తిరిగి వస్తుంది.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// ఈ కేటాయింపును సూచించే `Weak` పాయింటర్ల సంఖ్యను పొందుతుంది.
    ///
    /// బలమైన పాయింటర్లు లేకపోతే, ఇది సున్నాకి తిరిగి వస్తుంది.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // అవ్యక్త బలహీనమైన ptr ను తీసివేయండి
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// పాయింటర్ డాంగ్లింగ్ చేస్తున్నప్పుడు మరియు కేటాయించిన `RcBox` లేనప్పుడు `None` ను అందిస్తుంది, (అనగా, ఈ `Weak` `Weak::new` చే సృష్టించబడినప్పుడు).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // ఫీల్డ్ ఏకకాలంలో పరివర్తనం చెందవచ్చు కాబట్టి, "data" ఫీల్డ్‌ను కవర్ చేసే సూచనను * సృష్టించకుండా ఉండటానికి మేము జాగ్రత్తగా ఉన్నాము (ఉదాహరణకు, చివరి `Rc` పడిపోతే, డేటా ఫీల్డ్ స్థానంలో పడిపోతుంది).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// రెండు `బలహీనాలు 'ఒకే కేటాయింపుకు ([`ptr::eq`] మాదిరిగానే) సూచించినట్లయితే లేదా రెండూ ఏ కేటాయింపును సూచించకపోతే (అవి `Weak::new()`) తో సృష్టించబడినందున) `true` ను అందిస్తుంది.
    ///
    ///
    /// # Notes
    ///
    /// ఇది పాయింటర్లను పోల్చినందున, `Weak::new()` ఒకదానికొకటి సమానంగా ఉంటుందని అర్థం, అవి ఏ కేటాయింపును సూచించనప్పటికీ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` ను పోల్చడం.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` పాయింటర్‌ను వదులుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // దేనినీ ముద్రించదు
    /// drop(foo);        // "dropped!" ప్రింట్లు
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // బలహీనమైన సంఖ్య 1 నుండి మొదలవుతుంది మరియు అన్ని బలమైన పాయింటర్లు అదృశ్యమైతే మాత్రమే సున్నాకి వెళ్తుంది.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// అదే కేటాయింపును సూచించే `Weak` పాయింటర్ యొక్క క్లోన్ చేస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// క్రొత్త `Weak<T>` ను నిర్మిస్తుంది, `T` కోసం మెమరీని ప్రారంభించకుండా కేటాయించింది.
    /// రిటర్న్ విలువపై [`upgrade`] కి కాల్ చేస్తే ఎల్లప్పుడూ [`None`] ఇస్తుంది.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: mem::forget తో సురక్షితంగా వ్యవహరించడానికి మేము ఇక్కడ తనిఖీ చేసాము.ముఖ్యంగా
// మీరు mem::forget Rcs (లేదా బలహీనంగా) ఉంటే, ref-కౌంట్ పొంగిపోతుంది, ఆపై అత్యుత్తమ Rc లు (లేదా బలహీనమైనవి) ఉన్నప్పుడే మీరు కేటాయింపును విడిపించవచ్చు.
//
// మేము ఆగిపోతున్నాము ఎందుకంటే ఇది క్షీణించిన దృశ్యం, ఏమి జరుగుతుందో మేము పట్టించుకోము-నిజమైన ప్రోగ్రామ్ ఎప్పుడూ దీనిని అనుభవించకూడదు.
//
// యాజమాన్యం మరియు మూవ్-సెమాంటిక్స్కు ధన్యవాదాలు Rust లో మీరు నిజంగా వీటిని క్లోన్ చేయనవసరం లేదు కాబట్టి ఇది చాలా తక్కువ ఓవర్ హెడ్ కలిగి ఉండాలి.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // మేము విలువను వదలడానికి బదులు ఓవర్‌ఫ్లో ఆపివేయాలనుకుంటున్నాము.
        // దీనిని పిలిచినప్పుడు సూచనల సంఖ్య సున్నా కాదు;
        // ఏదేమైనా, ఎల్‌ఎల్‌విఎమ్‌ను తప్పిపోయిన ఆప్టిమైజేషన్ వద్ద సూచించడానికి మేము ఇక్కడ అబార్ట్ చేర్చుతాము.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // మేము విలువను వదలడానికి బదులు ఓవర్‌ఫ్లో ఆపివేయాలనుకుంటున్నాము.
        // దీనిని పిలిచినప్పుడు సూచనల సంఖ్య సున్నా కాదు;
        // ఏదేమైనా, ఎల్‌ఎల్‌విఎమ్‌ను తప్పిపోయిన ఆప్టిమైజేషన్ వద్ద సూచించడానికి మేము ఇక్కడ అబార్ట్ చేర్చుతాము.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// పాయింటర్ వెనుక ఉన్న పేలోడ్ కోసం `RcBox` లో ఆఫ్‌సెట్ పొందండి.
///
/// # Safety
///
/// పాయింటర్ T యొక్క గతంలో చెల్లుబాటు అయ్యే ఉదాహరణను సూచించాలి (మరియు చెల్లుబాటు అయ్యే మెటాడేటాను కలిగి ఉండాలి), కానీ T ను వదిలివేయడానికి అనుమతించబడుతుంది.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // పరిమాణం లేని విలువను RcBox చివరికి సమలేఖనం చేయండి.
    // RcBox repr(C) కాబట్టి, ఇది ఎల్లప్పుడూ మెమరీలో చివరి ఫీల్డ్ అవుతుంది.
    // భద్రత: ముక్కలు, trait వస్తువులు,
    // మరియు బాహ్య రకాలు, align_of_val_raw యొక్క అవసరాలను తీర్చడానికి ఇన్పుట్ భద్రతా అవసరం ప్రస్తుతం సరిపోతుంది;ఇది std వెలుపల ఆధారపడని భాష యొక్క అమలు వివరాలు.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}