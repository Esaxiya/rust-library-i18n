// rsbegin.o మరియు rsend.o అని పిలవబడే "compiler runtime startup objects".
// కంపైలర్ రన్‌టైమ్‌ను సరిగ్గా ప్రారంభించడానికి అవసరమైన కోడ్‌ను అవి కలిగి ఉంటాయి.
//
// ఎక్జిక్యూటబుల్ లేదా డైలిబ్ ఇమేజ్ లింక్ చేయబడినప్పుడు, అన్ని యూజర్ కోడ్ మరియు లైబ్రరీలు ఈ రెండు ఆబ్జెక్ట్ ఫైళ్ళ మధ్య "sandwiched", కాబట్టి rsbegin.o నుండి కోడ్ లేదా డేటా చిత్రం యొక్క సంబంధిత విభాగాలలో మొదటిది, అయితే rsend.o నుండి కోడ్ మరియు డేటా చివరివిగా మారతాయి.
// ఈ ప్రభావం చిహ్నాలను ప్రారంభంలో లేదా చివరిలో ఉంచడానికి, అలాగే అవసరమైన శీర్షికలు లేదా ఫుటర్లను చొప్పించడానికి ఉపయోగించవచ్చు.
//
// వాస్తవ మాడ్యూల్ ఎంట్రీ పాయింట్ సి రన్‌టైమ్ స్టార్టప్ ఆబ్జెక్ట్ (సాధారణంగా `crtX.o` అని పిలుస్తారు) లో ఉందని గమనించండి, ఇది ఇతర రన్‌టైమ్ భాగాల ప్రారంభ కాల్‌బ్యాక్‌లను ప్రారంభిస్తుంది (మరో ప్రత్యేక ఇమేజ్ విభాగం ద్వారా నమోదు చేయబడింది).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // స్టాక్ ఫ్రేమ్ ప్రారంభ మార్కులు సమాచారం విభాగాన్ని నిలిపివేయండి
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // అన్‌వైండర్ యొక్క అంతర్గత పుస్తక కీపింగ్ కోసం స్క్రాచ్ స్థలం.
    // ఇది 00 GCC/untind-dw2-fde.h లో `struct object` గా నిర్వచించబడింది.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // సమాచారం registration/deregistration నిత్యకృత్యాలను నిలిపివేయండి.
    // Libpanic_unwind యొక్క డాక్స్ చూడండి.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // మాడ్యూల్ ప్రారంభంలో సమాచారాన్ని నిలిపివేయండి
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // షట్డౌన్లో నమోదు చేయవద్దు
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-నిర్దిష్ట init/uninit రొటీన్ రిజిస్ట్రేషన్
    pub mod mingw_init {
        // MinGW యొక్క ప్రారంభ వస్తువులు (crt0.o/dllcrt0.o) స్టార్టప్ మరియు నిష్క్రమణపై .ctors మరియు .dtors విభాగాలలో గ్లోబల్ కన్స్ట్రక్టర్లను పిలుస్తాయి.
        // DLL ల విషయంలో, DLL లోడ్ మరియు అన్‌లోడ్ చేయబడినప్పుడు ఇది జరుగుతుంది.
        //
        // లింకర్ విభాగాలను క్రమబద్ధీకరిస్తుంది, ఇది మా కాల్‌బ్యాక్‌లు జాబితా చివరిలో ఉన్నాయని నిర్ధారిస్తుంది.
        // కన్స్ట్రక్టర్లు రివర్స్ ఆర్డర్‌లో నడుస్తున్నందున, ఇది మా కాల్‌బ్యాక్‌లు అమలు చేయబడిన మొదటి మరియు చివరివి అని నిర్ధారిస్తుంది.
        //
        //

        #[link_section = ".ctors.65535"] // .క్టర్స్. *: సి ప్రారంభ కాల్‌బ్యాక్‌లు
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: సి టెర్మినేషన్ కాల్‌బ్యాక్‌లు
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}