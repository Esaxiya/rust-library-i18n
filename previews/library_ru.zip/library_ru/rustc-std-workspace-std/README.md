# `rustc-std-workspace-std` crate

См. Документацию для `rustc-std-workspace-core` crate.