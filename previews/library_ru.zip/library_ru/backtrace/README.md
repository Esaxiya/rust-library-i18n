# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Библиотека для получения трассировок во время выполнения для Rust.
Эта библиотека направлена на усиление поддержки стандартной библиотеки, предоставляя программный интерфейс для работы, но она также поддерживает простую печать текущей трассировки, например panics в libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Чтобы просто захватить обратную трассировку и отложить работу с ней на более позднее время, вы можете использовать тип `Backtrace` верхнего уровня.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Если, однако, вам нужен более прямой доступ к фактическим функциям трассировки, вы можете напрямую использовать функции `trace` и `resolve`.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Преобразуйте этот указатель инструкции в имя символа
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // продолжай переходить к следующему кадру
    });
}
```

# License

Этот проект находится под одной из следующих лицензий:

 * Лицензия Apache, версия 2.0, ([LICENSE-APACHE](LICENSE-APACHE) или http://www.apache.org/licenses/LICENSE-2.0)
 * Лицензия MIT ([LICENSE-MIT](LICENSE-MIT) или http://opensource.org/licenses/MIT)

на ваше усмотрение.

### Contribution

Если вы явно не указали иное, любой вклад, намеренно представленный вами для включения в backtrace-rs, как определено в лицензии Apache-2.0, должен иметь двойную лицензию, как указано выше, без каких-либо дополнительных условий.







