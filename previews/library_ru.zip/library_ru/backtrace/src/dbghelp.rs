//! Модуль для помощи в управлении привязками dbghelp на Windows
//!
//! Обратные трассировки на Windows (по крайней мере, для MSVC) в основном работают через `dbghelp.dll` и различные функции, которые он содержит.
//! Эти функции в настоящее время загружаются *динамически*, а не статически связаны с `dbghelp.dll`.
//! В настоящее время это делается стандартной библиотекой (и теоретически там требуется), но это попытка помочь уменьшить статические зависимости библиотеки dll, поскольку обратные трассировки обычно не являются обязательными.
//!
//! При этом `dbghelp.dll` почти всегда успешно загружается на Windows.
//!
//! Однако обратите внимание, что, поскольку мы загружаем всю эту поддержку динамически, мы не можем фактически использовать необработанные определения в `winapi`, а нам нужно самостоятельно определить типы указателей функций и использовать их.
//! Мы действительно не хотим дублировать winapi, поэтому у нас есть функция Cargo `verify-winapi`, которая утверждает, что все привязки соответствуют привязкам в winapi, и эта функция включена в CI.
//!
//! Наконец, вы заметите, что dll для `dbghelp.dll` никогда не выгружается, и в настоящее время это сделано намеренно.
//! Идея состоит в том, что мы можем глобально кэшировать его и использовать между вызовами API, избегая дорогостоящего loads/unloads.
//! Если это проблема для детекторов утечки или что-то в этом роде, мы можем пересечь мост, когда доберемся туда.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Работайте с `SymGetOptions` и `SymSetOptions`, которых нет в самой winapi.
// В противном случае это используется только тогда, когда мы дважды проверяем типы по winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Еще не определено в winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Это определено в winapi, но неверно (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Еще не определено в winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Этот макрос используется для определения структуры `Dbghelp`, которая внутри содержит все указатели функций, которые мы можем загрузить.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Загруженная DLL для `dbghelp.dll`
            dll: HMODULE,

            // Каждый указатель на функцию для каждой функции, которую мы можем использовать
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Изначально мы не загрузили DLL
            dll: 0 as *mut _,
            // По умолчанию все функции установлены в ноль, чтобы сказать, что они должны быть загружены динамически.
            //
            $($name: 0,)*
        };

        // Удобный typedef для каждого типа функции.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Попытки открыть `dbghelp.dll`.
            /// Возвращает успех, если работает, или ошибку, если `LoadLibraryW` не работает.
            ///
            /// Panics, если библиотека уже загружена.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Функция для каждого метода, который мы хотели бы использовать.
            // При вызове он либо считывает кешированный указатель функции, либо загружает его и возвращает загруженное значение.
            // Утверждается, что нагрузки будут успешными.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Удобный прокси для использования блокировок очистки для ссылки на функции dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Инициализируйте всю поддержку, необходимую для доступа к функциям API `dbghelp` из этого crate.
///
///
/// Обратите внимание, что эта функция **безопасна**, у нее есть внутренняя синхронизация.
/// Также обратите внимание, что эту функцию можно вызывать рекурсивно несколько раз.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Первое, что нам нужно сделать, это синхронизировать эту функцию.Это может быть вызвано одновременно из других потоков или рекурсивно внутри одного потока.
        // Обратите внимание, что это сложнее, чем это, потому что то, что мы здесь используем, `dbghelp`,*также* необходимо синхронизировать со всеми другими вызывающими абонентами `dbghelp` в этом процессе.
        //
        // Обычно на самом деле не так много вызовов `dbghelp` в рамках одного процесса, и мы, вероятно, можем с уверенностью предположить, что мы единственные, кто обращается к нему.
        // Однако есть еще один основной пользователь, о котором мы должны беспокоиться, и это, по иронии судьбы, мы сами, но в стандартной библиотеке.
        // Стандартная библиотека Rust зависит от этого crate для поддержки обратной трассировки, и этот crate также существует на crates.io.
        // Это означает, что если стандартная библиотека печатает обратную трассировку panic, она может конкурировать с этим crate, исходящим от crates.io, вызывая сбои.
        //
        // Чтобы решить эту проблему с синхронизацией, мы используем здесь специфический для Windows трюк (в конце концов, это специфичное для Windows ограничение на синхронизацию).
        // Мы создаем мьютекс с именем *session-local* для защиты этого вызова.
        // Здесь предполагается, что стандартная библиотека и этот crate не должны совместно использовать API уровня Rust для синхронизации здесь, а вместо этого могут работать за кулисами, чтобы убедиться, что они синхронизируются друг с другом.
        //
        // Таким образом, когда эта функция вызывается через стандартную библиотеку или через crates.io, мы можем быть уверены, что будет получен тот же мьютекс.
        //
        // Таким образом, все это означает, что первое, что мы делаем здесь, мы атомарно создаем `HANDLE`, который является именованным мьютексом на Windows.
        // Мы немного синхронизируемся с другими потоками, совместно использующими эту функцию, и гарантируем, что для каждого экземпляра этой функции создается только один дескриптор.
        // Обратите внимание, что дескриптор никогда не закрывается, если он хранится в глобальном.
        //
        // После того, как мы действительно взяли блокировку, мы просто получаем ее, и наша ручка `Init`, которую мы передаем, в конечном итоге будет отвечать за ее сброс.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Хорошо, уф!Теперь, когда мы все безопасно синхронизированы, давайте начнем обрабатывать все.
        // Прежде всего, нам нужно убедиться, что `dbghelp.dll` действительно загружен в этот процесс.
        // Мы делаем это динамически, чтобы избежать статической зависимости.
        // Исторически это делалось для решения странных проблем связывания и предназначено для того, чтобы сделать двоичные файлы более переносимыми, поскольку это в основном просто отладочная утилита.
        //
        //
        // После того, как мы открыли `dbghelp.dll`, нам нужно вызвать в нем некоторые функции инициализации, подробнее об этом ниже.
        // Однако мы делаем это только один раз, поэтому у нас есть глобальное логическое значение, указывающее, закончили мы еще или нет.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Убедитесь, что флаг `SYMOPT_DEFERRED_LOADS` установлен, потому что, согласно собственным документам MSVC об этом: "This is the fastest, most efficient way to use the symbol handler.", так что давайте сделаем это!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Фактически инициализируйте символы с помощью MSVC.Обратите внимание, что это может привести к сбою, но мы игнорируем это.
        // Для этого не существует тонны предшествующего уровня техники, но LLVM внутренне, кажется, игнорирует возвращаемое здесь значение, и одна из библиотек дезинфицирующих средств в LLVM выдает страшное предупреждение, если это не удается, но в основном игнорирует его в долгосрочной перспективе.
        //
        //
        // Один случай, когда это очень важно для Rust, заключается в том, что стандартная библиотека и этот crate на crates.io оба хотят конкурировать за `SymInitializeW`.
        // Стандартная библиотека исторически хотела инициализировать, а затем очищать большую часть времени, но теперь, когда она использует этот crate, это означает, что кто-то сначала доберется до инициализации, а другой подберет эту инициализацию.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}