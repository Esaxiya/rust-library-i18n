#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Форматер для трассировки.
///
/// Этот тип может использоваться для печати обратной трассировки независимо от того, откуда происходит сама трассировка.
/// Если у вас есть тип `Backtrace`, то его реализация `Debug` уже использует этот формат печати.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Стили печати, которые мы можем распечатать
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Печатает более краткую обратную трассировку, которая в идеале содержит только релевантную информацию
    Short,
    /// Печатает обратную трассировку, содержащую всю возможную информацию
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Создайте новый `BacktraceFmt`, который будет записывать вывод в предоставленный `fmt`.
    ///
    /// Аргумент `format` будет управлять стилем, в котором печатается обратная трассировка, а аргумент `print_path` будет использоваться для печати экземпляров `BytesOrWideString` имен файлов.
    /// Сам по себе этот тип не печатает имена файлов, но для этого необходим обратный вызов.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Печатает преамбулу трассировки, которая будет напечатана.
    ///
    /// Это требуется на некоторых платформах для того, чтобы обратная трассировка была полностью символизирована позже, а в противном случае это должен быть только первый метод, который вы вызываете после создания `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Добавляет кадр к выходным данным обратной трассировки.
    ///
    /// Эта фиксация возвращает RAII-экземпляр `BacktraceFrameFmt`, который можно использовать для фактической печати кадра, и при уничтожении он увеличит счетчик кадров.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Завершает вывод обратной трассировки.
    ///
    /// В настоящее время это не работает, но добавлено для совместимости future с форматами обратной трассировки.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // В настоящее время не работает-включая этот hook, чтобы разрешить дополнения future.
        Ok(())
    }
}

/// Средство форматирования всего для одного кадра трассировки.
///
/// Этот тип создается функцией `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Печатает `BacktraceFrame` с помощью этого средства форматирования кадров.
    ///
    /// Это рекурсивно распечатает все экземпляры `BacktraceSymbol` в `BacktraceFrame`.
    ///
    /// # Обязательные особенности
    ///
    /// Эта функция требует, чтобы функция `std` в `backtrace` crate была включена, а функция `std` включена по умолчанию.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Печатает `BacktraceSymbol` в `BacktraceFrame`.
    ///
    /// # Обязательные особенности
    ///
    /// Эта функция требует, чтобы функция `std` в `backtrace` crate была включена, а функция `std` включена по умолчанию.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: это не здорово, что мы ничего не печатаем
            // с именами файлов, отличными от utf8.
            // К счастью, почти все-utf8, так что это не должно быть так уж плохо.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Печатает необработанные трассированные `Frame` и `Symbol`, обычно из необработанных обратных вызовов этого crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Добавляет необработанный кадр к выходным данным обратной трассировки.
    ///
    /// Этот метод, в отличие от предыдущего, принимает необработанные аргументы, если они исходят из разных мест.
    /// Обратите внимание, что это может быть вызвано несколько раз для одного кадра.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Добавляет необработанный кадр к выходным данным обратной трассировки, включая информацию о столбцах.
    ///
    /// Этот метод, как и предыдущий, принимает необработанные аргументы, если они исходят из разных мест.
    /// Обратите внимание, что это может быть вызвано несколько раз для одного кадра.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Фуксия не может символизировать внутри процесса, поэтому у нее есть специальный формат, который можно использовать для обозначения позже.
        // Напечатайте это вместо того, чтобы печатать адреса в нашем собственном формате здесь.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Нет необходимости печатать кадры "null", это в основном означает, что система обратного отслеживания немного стремилась проследить очень далеко.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Чтобы уменьшить размер TCB в анклаве Sgx, мы не хотим реализовывать функциональность разрешения символов.
        // Скорее, мы можем напечатать здесь смещение адреса, которое позже может быть сопоставлено с правильной функцией.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Напечатайте индекс кадра, а также необязательный указатель инструкции кадра.
        // Если мы вышли за пределы первого символа этого кадра, мы просто печатаем соответствующие пробелы.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Затем напишите имя символа, используя альтернативное форматирование для получения дополнительной информации, если мы ведем полную обратную трассировку.
        // Здесь мы также обрабатываем символы, у которых нет имени,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // И наконец, распечатайте номер filename/line, если он доступен.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line печатаются в строках под именем символа, поэтому выведите несколько подходящих пробелов, чтобы выровнять себя по правому краю.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Поручите нашему внутреннему обратному вызову распечатать имя файла, а затем распечатать номер строки.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Добавьте номер столбца, если он доступен.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Мы заботимся только о первом символе кадра
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}