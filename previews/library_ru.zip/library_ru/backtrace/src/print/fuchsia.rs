use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr принимает обратный вызов, который получит указатель dl_phdr_info для каждого DSO, связанного с процессом.
    // dl_iterate_phdr также гарантирует, что динамический компоновщик заблокирован от начала до конца итерации.
    // Если обратный вызов возвращает ненулевое значение, итерация завершается досрочно.
    // 'data' будет передаваться в качестве третьего аргумента обратного вызова при каждом вызове.
    // 'size' дает размер dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Нам нужно проанализировать идентификатор сборки и некоторые базовые данные заголовка программы, что означает, что нам также нужно немного материала из спецификации ELF.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Теперь нам нужно воспроизвести, бит за битом, структуру типа dl_phdr_info, используемую текущим динамическим компоновщиком fuchsia.
// Chromium также имеет эту границу ABI, а также аварийную панель.
// В конце концов, мы хотели бы перенести эти кейсы на использование elf-search, но нам нужно будет предоставить это в SDK, а это еще не сделано.
//
// Таким образом, мы (и они) застряли, вынуждены использовать этот метод, который влечет за собой тесную связь с fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // У нас нет возможности узнать, действительны ли e_phoff и e_phnum.
    // Однако libc должна гарантировать это для нас, так что здесь можно безопасно сформировать срез.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr представляет собой 64-битный заголовок программы ELF в порядке байтов целевой архитектуры.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr представляет собой действительный заголовок программы ELF и его содержимое.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // У нас нет возможности проверить, действительны ли p_addr или p_memsz.
    // Однако библиотека Fuchsia libc сначала анализирует заметки, поэтому, поскольку они находятся здесь, эти заголовки должны быть действительными.
    //
    // NoteIter не требует, чтобы базовые данные были действительными, но требует, чтобы границы были действительными.
    // Мы верим, что libc позаботилась о том, чтобы здесь именно так и было.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Тип примечания для идентификаторов сборки.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr представляет заголовок примечания ELF в порядке байтов цели.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Примечание представляет собой заметку в формате ELF (заголовок + содержимое).
// Имя остается как фрагмент u8, потому что он не всегда заканчивается нулем, а rust позволяет достаточно легко проверить соответствие байтов в любом случае.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter позволяет безопасно перебирать сегмент заметки.
// Он прекращается, как только возникает ошибка или больше нет заметок.
// Если вы перебираете недопустимые данные, он будет работать так, как будто заметок не найдено.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Инвариант функции заключается в том, что указанный указатель и размер обозначают допустимый диапазон байтов, которые могут быть прочитаны.
    // Содержимое этих байтов может быть любым, но для безопасности диапазон должен быть допустимым.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to выравнивает 'x' по байтовому выравниванию, предполагая, что 'to' является степенью 2.
// Это соответствует стандартному шаблону в коде синтаксического анализа C/C ++ ELF, где используются (x + to, 1)&-to.
// Rust не позволяет вам отрицать usize, поэтому я использую
// Преобразование с дополнением до 2, чтобы воссоздать это.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 потребляет количество байтов из слайса (если он есть) и дополнительно гарантирует, что последний слайс правильно выровнен.
// Если либо количество запрошенных байтов слишком велико, либо срез не может быть повторно выровнен впоследствии из-за недостаточного количества оставшихся байтов, возвращается None и срез не изменяется.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Эта функция не имеет реальных инвариантов, которые вызывающий должен поддерживать, кроме, возможно, того, что 'bytes' должен быть выровнен для обеспечения производительности (и для правильности некоторых архитектур).
// Значения в полях Elf_Nhdr могут быть бессмысленными, но эта функция не гарантирует ничего подобного.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Это безопасно, пока есть достаточно места, и мы только что подтвердили это в приведенном выше выражении if, так что это не должно быть небезопасным.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Обратите внимание, что sice_of: :<Elf_Nhdr>() всегда выравнивается по 4 байта.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Проверьте, дошли ли мы до конца.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Мы преобразовываем nhdr, но тщательно рассматриваем полученную структуру.
        // Мы не доверяем namez или descsz и не принимаем небезопасных решений в зависимости от типа.
        //
        // Так что даже если мы выберем полный мусор, мы все равно будем в безопасности.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Указывает, что сегмент исполняемый.
const PERM_X: u32 = 0b00000001;
/// Указывает, что сегмент доступен для записи.
const PERM_W: u32 = 0b00000010;
/// Указывает, что сегмент доступен для чтения.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Представляет сегмент ELF во время выполнения.
struct Segment {
    /// Предоставляет виртуальный адрес времени выполнения для содержимого этого сегмента.
    addr: usize,
    /// Указывает размер памяти для содержимого этого сегмента.
    size: usize,
    /// Предоставляет модулю виртуальный адрес этого сегмента с файлом ELF.
    mod_rel_addr: usize,
    /// Предоставляет разрешения, найденные в файле ELF.
    /// Однако эти разрешения не обязательно являются разрешениями, присутствующими во время выполнения.
    flags: Perm,
}

/// Позволяет перебирать сегменты из DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Представляет ELF DSO (динамический общий объект).
/// Этот тип ссылается на данные, хранящиеся в реальном DSO, а не на свою собственную копию.
struct Dso<'a> {
    /// Динамический компоновщик всегда дает нам имя, даже если имя пустое.
    /// В случае основного исполняемого файла это имя будет пустым.
    /// В случае общего объекта это будет soname (см. DT_SONAME).
    name: &'a str,
    /// В Fuchsia практически все двоичные файлы имеют идентификаторы сборки, но это не строгое требование.
    /// Невозможно впоследствии сопоставить информацию DSO с реальным файлом ELF, если нет build_id, поэтому мы требуем, чтобы у каждого DSO был один здесь.
    ///
    /// DSO без build_id игнорируются.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Возвращает итератор по сегментам в этом DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Эти ошибки кодируют проблемы, возникающие при анализе информации о каждом DSO.
///
enum Error {
    /// NameError означает, что произошла ошибка при преобразовании строки стиля C в строку rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError означает, что мы не нашли идентификатор сборки.
    /// Это могло быть связано либо с тем, что у DSO не было идентификатора сборки, либо потому, что сегмент, содержащий идентификатор сборки, был искажен.
    ///
    BuildIDError,
}

/// Вызывает 'dso' или 'error' для каждого DSO, связанного с процессом динамическим компоновщиком.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter, у которого будет один из методов eats, называемый foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr гарантирует, что info.name укажет на допустимое местоположение.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Эта функция печатает разметку символизатора Fuchsia для всей информации, содержащейся в DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}