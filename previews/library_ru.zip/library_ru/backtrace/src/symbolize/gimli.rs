//! Поддержка символики с помощью `gimli` crate на crates.io
//!
//! Это реализация символизации по умолчанию для Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // статическое время жизни-это ложь, которую можно обойти вокруг отсутствия поддержки самореферентных структур.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Преобразуйте в статическое время жизни, поскольку символы должны заимствовать только `map` и `stash`, и мы сохраняем их ниже.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Для загрузки собственных библиотек на Windows см. Обсуждение различных стратегий на rust-lang/rust#71060 здесь.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Библиотеки MinGW в настоящее время не поддерживают ASLR (rust-lang/rust#16514), но библиотеки DLL все еще можно перемещать в адресном пространстве.
            // Похоже, что адреса в отладочной информации-это все, как если бы эта библиотека была загружена в ее "image base", что является полем в ее заголовках файла COFF.
            // Поскольку это то, что, кажется, перечисляет debuginfo, мы анализируем таблицу символов и сохраняем адреса, как если бы библиотека также была загружена на "image base".
            //
            // Однако библиотека может не загружаться на "image base".
            // (предположительно, там может быть загружено что-то еще?) Здесь в игру вступает поле `bias`, и здесь нам нужно выяснить значение `bias`.К сожалению, неясно, как получить это из загруженного модуля.
            // Однако у нас есть фактический адрес загрузки (`modBaseAddr`).
            //
            // В качестве небольшой отговорки мы сейчас отображаем файл mmap, читаем информацию из заголовка файла, а затем отбрасываем mmap.Это расточительно, потому что мы, вероятно, снова откроем mmap позже, но пока это должно работать достаточно хорошо.
            //
            // Как только у нас есть `image_base` (желаемое местоположение загрузки) и `base_addr` (фактическое местоположение загрузки), мы можем заполнить `bias` (разница между фактическим и желаемым), а затем заявленный адрес каждого сегмента-`image_base`, поскольку это то, что говорится в файле.
            //
            //
            // На данный момент кажется, что в отличие от ELF/MachO, мы можем обойтись одним сегментом на библиотеку, используя `modBaseSize` как весь размер.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS использует формат файла Mach-O и использует специфичные для DYLD API-интерфейсы для загрузки списка собственных библиотек, которые являются частью приложения.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Получите имя этой библиотеки, которое также соответствует пути ее загрузки.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Загрузите заголовок изображения этой библиотеки и делегируйте `object` для анализа всех команд загрузки, чтобы мы могли выяснить все задействованные здесь сегменты.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Перебираем сегменты и регистрируем известные регионы для найденных нами сегментов.
            // Дополнительно запишите информацию о текстовых сегментах для дальнейшей обработки, см. Комментарии ниже.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Определите "slide" для этой библиотеки, что в конечном итоге является смещением, которое мы используем, чтобы выяснить, где в памяти загружаются объекты.
            // Это немного странное вычисление, и оно является результатом того, что мы попробовали несколько вещей в дикой природе и увидели, что прижилось.
            //
            // Общая идея состоит в том, что `bias` плюс `stated_virtual_memory_address` сегмента будут там, где в фактическом адресном пространстве находится сегмент.
            // Еще мы полагаемся на то, что реальный адрес без `bias`-это индекс для поиска в таблице символов и debuginfo.
            //
            // Однако оказывается, что для библиотек, загруженных системой, эти вычисления некорректны.Однако для собственных исполняемых файлов это кажется правильным.
            // Подняв некоторую логику из источника LLDB, он имеет специальный корпус для первой секции `__TEXT`, загруженной из файла смещения 0 с ненулевым размером.
            // По какой-то причине, когда это присутствует, это означает, что таблица символов относится только к слайду vmaddr для библиотеки.
            // Если он *отсутствует*, то таблица символов относится к слайду vmaddr плюс заявленный адрес сегмента.
            //
            // Чтобы справиться с этой ситуацией, если мы *не* находим текстовый раздел при нулевом смещении файла, мы увеличиваем смещение на указанный адрес первого текстового раздела и уменьшаем все указанные адреса на эту величину.
            //
            // Таким образом, таблица символов всегда отображается относительно величины смещения библиотеки.
            // Похоже, это дает правильные результаты для обозначения через таблицу символов.
            //
            // Честно говоря, я не совсем уверен, правильно ли это или есть что-то еще, что должно указать, как это сделать.
            // На данный момент, хотя это, похоже, работает достаточно хорошо, (?), и мы всегда должны иметь возможность настроить это с течением времени, если это необходимо.
            //
            // Для получения дополнительной информации см. #318.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Другой Unix (например,
        // Linux) используют ELF в качестве формата объектного файла и обычно реализуют API под названием `dl_iterate_phdr` для загрузки собственных библиотек.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` должны быть действительные указатели.
        // `vec` должен быть действительным указателем на `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 изначально не поддерживает отладочную информацию, но система сборки поместит отладочную информацию по пути `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Все остальное должно использовать ELF, но не умеет загружать собственные библиотеки.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Все известные общие библиотеки, которые были загружены.
    libraries: Vec<Library>,

    /// Кэш сопоставлений, в котором мы храним проанализированную информацию о карликах.
    ///
    /// Этот список имеет фиксированную емкость на весь срок службы, которая никогда не увеличивается.
    /// Элемент `usize` каждой пары является индексом в `libraries` выше, где `usize::max_value()` представляет текущий исполняемый файл.
    ///
    /// `Mapping`-это соответствующая проанализированная информация о карликах.
    ///
    /// Обратите внимание, что это, по сути, кеш LRU, и мы будем перемещать здесь вещи, символизируя адреса.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Сегменты этой библиотеки загружаются в память и куда они загружаются.
    segments: Vec<LibrarySegment>,
    /// "bias" этой библиотеки, обычно там, где она загружается в память.
    /// Это значение добавляется к указанному адресу каждого сегмента, чтобы получить фактический адрес виртуальной памяти, в которую этот сегмент загружен.
    /// Кроме того, это смещение вычитается из реальных адресов виртуальной памяти для индексации в debuginfo и таблице символов.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Заявленный адрес этого сегмента в объектном файле.
    /// На самом деле не здесь загружается сегмент, а скорее этот адрес плюс `bias` содержащей его библиотеки-это место, где его найти.
    ///
    stated_virtual_memory_address: usize,
    /// Размер ths сегмента в памяти.
    len: usize,
}

// небезопасно, потому что это требуется для внешней синхронизации
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // небезопасно, потому что это требуется для внешней синхронизации
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Очень маленький, очень простой кэш LRU для отображения отладочной информации.
        //
        // Частота совпадений должна быть очень высокой, поскольку типичный стек не пересекается между многими разделяемыми библиотеками.
        //
        // Создавать структуры `addr2line::Context` довольно дорого.
        // Ожидается, что его стоимость будет амортизироваться последующими запросами `locate`, которые используют структуры, построенные при построении `addr2line: : Context`s, для получения хорошего ускорения.
        //
        // Если бы у нас не было этого кеша, такой амортизации никогда бы не произошло, и символические трассировки были бы ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Сначала проверьте, есть ли у этого `lib` какой-либо сегмент, содержащий `addr` (обработка перемещения).Если эта проверка пройдена, мы можем продолжить выполнение ниже и фактически перевести адрес.
                //
                // Обратите внимание, что здесь мы используем `wrapping_add`, чтобы избежать проверки переполнения.Было замечено в дикой природе, что вычисление смещения SVMA + переполняется.
                // Это может показаться немного странным, но мы мало что можем с этим поделать, кроме как, вероятно, просто игнорировать эти сегменты, поскольку они, вероятно, направлены в космос.
                //
                // Первоначально это появилось в rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Теперь, когда мы знаем, что `lib` содержит `addr`, мы можем компенсировать смещение, чтобы найти заявленный адрес виртуальной памяти.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Инвариант: после того, как это условие завершится без досрочного возврата
        // из-за ошибки запись в кеше для этого пути имеет индекс 0.

        if let Some(idx) = idx {
            // Когда отображение уже находится в кеше, переместите его на передний план.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Если отображение отсутствует в кэше, создайте новое отображение, вставьте его в начало кэша и при необходимости удалите самую старую запись кэша.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // не допускайте утечки срока службы `'static`, убедитесь, что это касается только нас самих
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Продлите срок службы `sym` до `'static`, поскольку мы, к сожалению, обязаны здесь, но он никогда не будет использоваться как ссылка, поэтому никакие ссылки на него в любом случае не должны сохраняться за пределами этого кадра.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Наконец, получите кэшированное сопоставление или создайте новое сопоставление для этого файла и оцените информацию DWARF, чтобы найти file/line/name для этого адреса.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Мы смогли найти информацию о кадре для этого символа, и внутри фрейма addr2line есть все мелкие детали.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Не удалось найти отладочную информацию, но мы нашли ее в таблице символов исполняемого файла elf.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}