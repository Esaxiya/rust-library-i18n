//! Стратегия символизации с использованием кода DWARF-анализа в libbacktrace.
//!
//! Библиотека libbacktrace C, обычно распространяемая с gcc, поддерживает не только создание обратной трассировки (которую мы фактически не используем), но также символизирующую обратную трассировку и обработку отладочной информации карликов о таких вещах, как встроенные фреймы и тому подобное.
//!
//!
//! Это относительно сложно из-за множества различных проблем, но основная идея такова:
//!
//! * Сначала мы вызываем `backtrace_syminfo`.Он получает информацию о символах из таблицы динамических символов, если мы можем.
//! * Затем мы вызываем `backtrace_pcinfo`.Это проанализирует таблицы debuginfo, если они доступны, и позволит нам восстановить информацию о встроенных фреймах, именах файлов, номерах строк и т. Д.
//!
//! Есть много хитростей, связанных с включением таблиц-гномов в libbacktrace, но, надеюсь, это не конец света, и это достаточно ясно при чтении ниже.
//!
//! Это стратегия символизации по умолчанию для платформ, отличных от MSVC и OSX.В libstd это стратегия по умолчанию для OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Если возможно, предпочитайте имя `function`, которое берется из debuginfo и обычно может быть более точным, например, для встроенных фреймов.
                // Если его нет, вернитесь к имени таблицы символов, указанному в `symname`.
                //
                // Обратите внимание, что иногда `function` может казаться несколько менее точным, например, если он указан как `try<i32,closure>` вместо `std::panicking::try::do_call`.
                //
                // Не совсем понятно почему, но в целом название `function` кажется более точным.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // пока ничего не делай
}

/// Тип указателя `data`, переданного в `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Как только этот обратный вызов вызывается из `backtrace_syminfo`, когда мы начинаем разрешать, мы идем дальше и вызываем `backtrace_pcinfo`.
    // Функция `backtrace_pcinfo` будет обращаться к отладочной информации и пытаться делать такие вещи, как восстановление информации file/line, а также встроенных кадров.
    // Однако обратите внимание, что `backtrace_pcinfo` может выйти из строя или ничего не сделать, если нет отладочной информации, поэтому, если это произойдет, мы обязательно вызовем обратный вызов с хотя бы одним символом из `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Тип указателя `data`, переданного в `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// API libbacktrace поддерживает создание состояния, но не поддерживает уничтожение состояния.
// Я лично считаю, что это означает, что государство должно быть создано, а затем жить вечно.
//
// Я хотел бы зарегистрировать обработчик at_exit(), который очищает это состояние, но libbacktrace не предоставляет возможности сделать это.
//
// С этими ограничениями эта функция имеет статически кэшированное состояние, которое вычисляется при первом запросе.
//
// Помните, что обратная трассировка происходит последовательно (одна глобальная блокировка).
//
// Обратите внимание, что отсутствие синхронизации здесь связано с требованием внешней синхронизации `resolve`.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Не применяйте потокобезопасные возможности libbacktrace, поскольку мы всегда вызываем его синхронно.
        //
        0,
        error_cb,
        ptr::null_mut(), // без дополнительных данных
    );

    return STATE;

    // Обратите внимание, что для работы libbacktrace необходимо найти отладочную информацию DWARF для текущего исполняемого файла.Обычно это делается с помощью ряда механизмов, включая, но не ограничиваясь:
    //
    // * /proc/self/exe на поддерживаемых платформах
    // * Имя файла, переданное явно при создании состояния
    //
    // Библиотека libbacktrace-это большой кусок кода C.Это, естественно, означает, что у него есть уязвимости, связанные с безопасностью памяти, особенно при обработке искаженной отладочной информации.
    // Libstd исторически сталкивался с множеством подобных ситуаций.
    //
    // Если используется /proc/self/exe, мы обычно можем игнорировать их, поскольку мы предполагаем, что libbacktrace-это "mostly correct", а в противном случае не делает странных вещей с информацией об отладке карликов "attempted to be correct".
    //
    //
    // Однако, если мы передадим имя файла, то это возможно на некоторых платформах (например, BSD), где злоумышленник может вызвать размещение произвольного файла в этом месте.
    // Это означает, что если мы сообщаем libbacktrace имя файла, он может использовать произвольный файл, что может вызвать сбои в сегменте.
    // Если мы ничего не сообщаем libbacktrace, тогда он ничего не будет делать на платформах, не поддерживающих такие пути, как /proc/self/exe!
    //
    // Учитывая все это, мы изо всех сил стараемся *не* передавать имя файла, но мы должны это делать на платформах, которые вообще не поддерживают /proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Обратите внимание, что в идеале мы бы использовали `std::env::current_exe`, но нам не может понадобиться `std` здесь.
            //
            // Используйте `_NSGetExecutablePath` для загрузки текущего пути к исполняемому файлу в статическую область (если она слишком мала, просто откажитесь от нее).
            //
            //
            // Обратите внимание, что мы серьезно доверяем libbacktrace, чтобы не умереть от поврежденных исполняемых файлов, но это точно ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows имеет режим открытия файлов, при котором после открытия его нельзя удалить.
            // В общем, это то, что мы хотим здесь, потому что мы хотим гарантировать, что наш исполняемый файл не изменится из-под нас после того, как мы передадим его libbacktrace, что, надеюсь, снижает возможность передачи произвольных данных в libbacktrace (что может быть неправильно обработано).
            //
            //
            // Учитывая, что здесь мы немного потанцуем, чтобы попытаться заблокировать наше собственное изображение:
            //
            // * Получите дескриптор текущего процесса, загрузите его имя файла.
            // * Откройте файл с этим именем файла с правильными флагами.
            // * Перезагрузите имя файла текущего процесса, убедившись, что оно то же самое
            //
            // Если все это пройдет, мы теоретически действительно открыли файл нашего процесса, и мы гарантируем, что он не изменится.FWIW-часть этого исторически скопирована из libstd, так что это моя лучшая интерпретация того, что происходило.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Он живет в статической памяти, поэтому мы можем его вернуть.
                static mut BUF: [i8; N] = [0; N];
                // ... и это живет в стеке, так как это временное
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // намеренно утечка `handle` здесь, потому что открытие этого файла должно сохранить нашу блокировку для этого имени файла.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Мы хотим вернуть фрагмент с нулевым завершением, поэтому, если все было заполнено и оно равняется общей длине, приравняйте это к ошибке.
                //
                //
                // В противном случае при возврате успеха убедитесь, что в срез включен нулевой байт.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // Ошибки обратной трассировки в настоящее время скрыты
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Вызвать `backtrace_syminfo` API, который (после чтения кода) должен вызвать `syminfo_cb` ровно один раз (или предположительно с ошибкой).
    // Затем мы обрабатываем больше в `syminfo_cb`.
    //
    // Обратите внимание, что мы делаем это, поскольку `syminfo` будет обращаться к таблице символов, находя имена символов, даже если в двоичном файле нет отладочной информации.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}