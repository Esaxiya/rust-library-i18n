use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Разрешить адрес к символу, передав символ в указанное замыкание.
///
/// Эта функция будет искать заданный адрес в таких областях, как локальная таблица символов, динамическая таблица символов или отладочная информация DWARF (в зависимости от активированной реализации), чтобы найти символы для получения.
///
///
/// Закрытие не может быть вызвано, если разрешение не может быть выполнено, а также может быть вызвано более одного раза в случае встроенных функций.
///
/// Полученные символы представляют выполнение на указанном `addr`, возвращая пары file/line для этого адреса (если они доступны).
///
/// Обратите внимание: если у вас есть `Frame`, рекомендуется использовать функцию `resolve_frame` вместо этой.
///
/// # Обязательные особенности
///
/// Эта функция требует, чтобы функция `std` в `backtrace` crate была включена, а функция `std` включена по умолчанию.
///
/// # Panics
///
/// Эта функция стремится никогда не использовать panic, но если `cb` предоставил panics, то некоторые платформы заставят двойной panic прервать процесс.
/// Некоторые платформы используют библиотеку C, которая внутренне использует обратные вызовы, которые нельзя отменить, поэтому паника от `cb` может вызвать прерывание процесса.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // смотрите только на верхнюю рамку
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Преобразуйте ранее захваченный кадр в символ, передав символ в указанное замыкание.
///
/// Эта функция выполняет ту же функцию, что и `resolve`, за исключением того, что она принимает `Frame` в качестве аргумента вместо адреса.
/// Это может позволить реализации обратной трассировки на некоторых платформах предоставлять более точную символьную информацию или, например, информацию о встроенных фреймах.
///
/// По возможности рекомендуется использовать это.
///
/// # Обязательные особенности
///
/// Эта функция требует, чтобы функция `std` в `backtrace` crate была включена, а функция `std` включена по умолчанию.
///
/// # Panics
///
/// Эта функция стремится никогда не использовать panic, но если `cb` предоставил panics, то некоторые платформы заставят двойной panic прервать процесс.
/// Некоторые платформы используют библиотеку C, которая внутренне использует обратные вызовы, которые нельзя отменить, поэтому паника от `cb` может вызвать прерывание процесса.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // смотрите только на верхнюю рамку
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Значения IP из кадров стека обычно представляют собой (always?) инструкции *после* вызова, которая является фактической трассировкой стека.
// Обозначение этого на заставляет число filename/line быть на один впереди и, возможно, в пустоту, если оно ближе к концу функции.
//
// Похоже, что в основном это всегда так на всех платформах, поэтому мы всегда вычитаем единицу из разрешенного ip, чтобы преобразовать его в предыдущую инструкцию вызова вместо возвращаемой инструкции.
//
//
// В идеале мы бы этого не делали.
// В идеале мы бы потребовали, чтобы вызывающие здесь API-интерфейсы `resolve` вручную выполняли -1 и учли, что им нужна информация о местоположении для *предыдущей* инструкции, а не для текущей.
// В идеале мы бы также выставили на `Frame`, действительно ли мы адрес следующей инструкции или текущий.
//
// На данный момент, хотя это довольно нишевый вопрос, мы просто внутренне всегда вычитаем один.
// Потребители должны продолжать работать и получать довольно хорошие результаты, поэтому мы должны быть достаточно хорошими.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// То же, что и `resolve`, только небезопасно, поскольку не синхронизировано.
///
/// Эта функция не имеет гарантий синхронизации, но доступна, когда функция `std` этого crate не скомпилирована.
/// См. Дополнительную документацию и примеры в функции `resolve`.
///
/// # Panics
///
/// См. Информацию о `resolve` для предупреждений о панике `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// То же, что и `resolve_frame`, только небезопасно, поскольку не синхронизировано.
///
/// Эта функция не имеет гарантий синхронизации, но доступна, когда функция `std` этого crate не скомпилирована.
/// См. Дополнительную документацию и примеры в функции `resolve_frame`.
///
/// # Panics
///
/// См. Информацию о `resolve_frame` для предупреждений о панике `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait, представляющий разрешение символа в файле.
///
/// Этот trait передается как объект trait для закрытия, заданного функции `backtrace::resolve`, и виртуально отправляется, поскольку неизвестно, какая реализация стоит за ним.
///
///
/// Символ может предоставлять контекстную информацию о функции, например имя, имя файла, номер строки, точный адрес и т. Д.
/// Однако не вся информация всегда доступна в символе, поэтому все методы возвращают `Option`.
///
///
pub struct Symbol {
    // TODO: это ограничение времени жизни должно быть сохранено в конечном итоге до `Symbol`,
    // но в настоящее время это критическое изменение.
    // На данный момент это безопасно, поскольку `Symbol` распространяется только по ссылке и не может быть клонирован.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Возвращает имя этой функции.
    ///
    /// Возвращенная структура может использоваться для запроса различных свойств имени символа:
    ///
    ///
    /// * Реализация `Display` распечатает разобранный символ.
    /// * Можно получить доступ к необработанному значению `str` символа (если оно действительно utf-8).
    /// * Доступны необработанные байты для имени символа.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Возвращает начальный адрес этой функции.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Возвращает необработанное имя файла в виде фрагмента.
    /// Это в основном полезно для сред `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Возвращает номер столбца, в котором в настоящее время выполняется этот символ.
    ///
    /// Только gimli в настоящее время предоставляет здесь значение, и даже тогда только в том случае, если `filename` возвращает `Some`, и поэтому он, следовательно, подвергается аналогичным оговоркам.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Возвращает номер строки, в которой в настоящее время выполняется этот символ.
    ///
    /// Это возвращаемое значение обычно равно `Some`, если `filename` возвращает `Some`, и, следовательно, на него распространяются аналогичные предостережения.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Возвращает имя файла, в котором была определена эта функция.
    ///
    /// В настоящее время это доступно только при использовании libbacktrace или gimli (например,
    /// unix платформы другие) и когда двоичный файл скомпилирован с помощью debuginfo.
    /// Если ни одно из этих условий не выполняется, скорее всего, будет возвращено `None`.
    ///
    /// # Обязательные особенности
    ///
    /// Эта функция требует, чтобы функция `std` в `backtrace` crate была включена, а функция `std` включена по умолчанию.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Может быть, это проанализированный символ C++ , если синтаксический анализ искаженного символа как Rust завершился неудачно.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Обязательно сохраните этот размер нулевого размера, чтобы функция `cpp_demangle` не требовала затрат при отключении.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Обертка вокруг имени символа для обеспечения эргономичных средств доступа к разобранному имени, необработанным байтам, необработанной строке и т. Д.
///
// Разрешить мертвый код, когда функция `cpp_demangle` не включена.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Создает новое имя символа из необработанных базовых байтов.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Возвращает необработанное имя символа (mangled) как `str`, если символ является допустимым utf-8.
    ///
    /// Используйте реализацию `Display`, если вам нужна версия без запутывания.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Возвращает необработанное имя символа в виде списка байтов.
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Это может быть напечатано, если разобранный символ на самом деле недействителен, поэтому обработайте ошибку здесь аккуратно, не распространяя ее наружу.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Попытка вернуть ту кэшированную память, которая использовалась для обозначения адресов.
///
/// Этот метод попытается освободить любые глобальные структуры данных, которые в противном случае были бы кэшированы глобально или в потоке, которые обычно представляют проанализированную информацию DWARF или аналогичную.
///
///
/// # Caveats
///
/// Хотя эта функция всегда доступна, в большинстве реализаций она на самом деле ничего не делает.
/// Такие библиотеки, как dbghelp или libbacktrace, не предоставляют средств для освобождения состояния и управления выделенной памятью.
/// На данный момент функция `gimli-symbolize` этого crate-единственная функция, на которую эта функция имеет какое-либо влияние.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}