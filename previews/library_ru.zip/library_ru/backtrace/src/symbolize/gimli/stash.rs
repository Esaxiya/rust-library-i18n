// используется только на Linux прямо сейчас, поэтому разрешите мертвый код в другом месте
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Простой распределитель для байтовых буферов.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Выделяет буфер указанного размера и возвращает изменяемую ссылку на него.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // БЕЗОПАСНОСТЬ: это единственная функция, которая когда-либо конструирует изменяемый
        // ссылка на `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // БЕЗОПАСНОСТЬ: мы никогда не удаляем элементы из `self.buffers`, поэтому ссылка
        // данные внутри любого буфера будут жить столько же, сколько и `self`.
        &mut buffers[i]
    }
}