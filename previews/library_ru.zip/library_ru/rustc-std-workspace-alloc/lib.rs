#![feature(no_core)]
#![no_core]

// См. rustc-std-workspace-core, чтобы узнать, зачем нужен этот crate.

// Переименуйте crate, чтобы избежать конфликта с модулем выделения в liballoc.
extern crate alloc as foo;

pub use foo::*;