//! Примитивный traits и типы, представляющие основные свойства типов.
//!
//! Типы Rust можно классифицировать различными полезными способами в соответствии с их внутренними свойствами.
//! Эти классификации представлены как traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Типы, которые могут передаваться через границы потоков.
///
/// Этот trait реализуется автоматически, когда компилятор определяет это подходящим.
///
/// Примером типа, отличного от `Send`, является указатель подсчета ссылок [`rc::Rc`][`Rc`].
/// Если два потока попытаются клонировать [`Rc`], которые указывают на одно и то же значение счетчика ссылок, они могут попытаться обновить счетчик ссылок одновременно, что составляет [undefined behavior][ub], поскольку [`Rc`] не использует атомарные операции.
///
/// Его двоюродный брат [`sync::Arc`][arc] действительно использует атомарные операции (с некоторыми накладными расходами) и, следовательно, является `Send`.
///
/// Подробнее см. [the Nomicon](../../nomicon/send-and-sync.html).
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Типы с постоянным размером, известным во время компиляции.
///
/// Все параметры типа имеют неявную границу `Sized`.Для удаления этой границы можно использовать специальный синтаксис `?Sized`, если он не подходит.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//ошибка: размер не реализован для [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Единственным исключением является неявный тип `Self` для trait.
/// trait не имеет неявной привязки `Sized`, поскольку это несовместимо с [trait object] s, где, по определению, trait должен работать со всеми возможными разработчиками и, следовательно, может иметь любой размер.
///
///
/// Хотя Rust позволит вам привязать `Sized` к trait, вы не сможете использовать его для формирования объекта trait позже:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // пусть y: &dyn Bar= &Impl;//ошибка: trait `Bar` не может быть превращен в объект
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // для Default, например, который требует, чтобы `[T]: !Default` был оцениваемым
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Типы, которые могут быть от "unsized" до типа с динамическим размером.
///
/// Например, размерный массив типа `[i8; 2]` реализует `Unsize<[i8]>` и `Unsize<dyn fmt::Debug>`.
///
/// Все реализации `Unsize` предоставляются компилятором автоматически.
///
/// `Unsize` реализован для:
///
/// - `[T; N]` это `Unsize<[T]>`
/// - `T` это `Unsize<dyn Trait>`, когда `T: Trait`
/// - `Foo<..., T, ...>` будет `Unsize<Foo<..., U, ...>>`, если:
///   - `T: Unsize<U>`
///   - Foo-это структура
///   - Только последнее поле `Foo` имеет тип, связанный с `T`
///   - `T` не относится к типу других полей
///   - `Bar<T>: Unsize<Bar<U>>`, если последнее поле `Foo` имеет тип `Bar<T>`
///
/// `Unsize` используется вместе с [`ops::CoerceUnsized`], чтобы позволить контейнерам "user-defined", таким как [`Rc`], содержать типы с динамическим размером.
/// См. [DST coercion RFC][RFC982] и [the nomicon entry on coercion][nomicon-coerce] для получения более подробной информации.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Обязательный trait для констант, используемых в сопоставлении с образцом.
///
/// Любой тип, производный от `PartialEq`, автоматически реализует этот trait,*независимо* от того, реализуют ли его параметры типа `Eq`.
///
/// Если элемент `const` содержит какой-либо тип, который не реализует этот trait, то этот тип либо (1.) не реализует `PartialEq` (что означает, что константа не будет предоставлять тот метод сравнения, который предполагает создание кода), либо (2.) реализует *свой собственный* версия `PartialEq` (которая, как мы предполагаем, не соответствует сравнению структурного равенства).
///
///
/// В любом из двух описанных выше сценариев мы отказываемся от использования такой константы в сопоставлении с шаблоном.
///
/// См. Также [structural match RFC][RFC1445] и [issue 63438], которые побудили перейти от дизайна на основе атрибутов к этому trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Обязательный trait для констант, используемых в сопоставлении с образцом.
///
/// Любой тип, производный от `Eq`, автоматически реализует этот trait,*независимо* от того, реализуют ли его параметры типа `Eq`.
///
/// Это прием, позволяющий обойти ограничение в нашей системе типов.
///
/// # Background
///
/// Мы хотим потребовать, чтобы типы констант, используемых в сопоставлении с образцом, имели атрибут `#[derive(PartialEq, Eq)]`.
///
/// В более идеальном мире мы могли бы проверить это требование, просто проверив, что данный тип реализует как `StructuralPartialEq` trait *, так*`Eq` trait.
/// Однако у вас могут быть ADT, которые *делают*`derive(PartialEq, Eq)`, и мы хотим, чтобы компилятор принимал их, и все же тип константы не может реализовать `Eq`.
///
/// А именно такой случай:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Проблема в приведенном выше коде заключается в том, что `Wrap<fn(&())>` не реализует ни `PartialEq`, ни `Eq`, потому что `for <'a> fn(&'a _)` does not implement those traits.)
///
/// Поэтому полагаться на наивную проверку `StructuralPartialEq` и просто `Eq` нельзя.
///
/// Чтобы обойти это, мы используем два отдельных traits, вводимых каждым из двух производных (`#[derive(PartialEq)]` и `#[derive(Eq)]`), и проверяем, что оба они присутствуют, как часть проверки структурного соответствия.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Типы, значения которых можно дублировать, просто копируя биты.
///
/// По умолчанию привязки переменных имеют «семантику перемещения».Другими словами:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` переехал в `y`, поэтому не может быть использован
///
/// // println! ("{: ?}", х);//ошибка: использование перемещенного значения
/// ```
///
/// Однако, если тип реализует `Copy`, вместо этого он имеет «семантику копирования»:
///
/// ```
/// // Мы можем получить реализацию `Copy`.
/// // `Clone` также требуется, так как это супертрена `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` это копия `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Важно отметить, что в этих двух примерах единственная разница заключается в том, разрешен ли вам доступ к `x` после назначения.
/// Под капотом и копирование, и перемещение могут привести к тому, что биты будут скопированы в память, хотя иногда это оптимизируется.
///
/// ## Как я могу реализовать `Copy`?
///
/// Есть два способа реализовать `Copy` на вашем типе.Самый простой-использовать `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Вы также можете реализовать `Copy` и `Clone` вручную:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Между ними есть небольшая разница: стратегия `derive` также помещает `Copy`, привязанный к параметрам типа, что не всегда желательно.
///
/// ## В чем разница между `Copy` и `Clone`?
///
/// Копии происходят неявно, например как часть назначения `y = x`.Поведение `Copy` не перегружено;это всегда простая побитовая копия.
///
/// Клонирование-это явное действие, `x.clone()`.Реализация [`Clone`] может обеспечивать любое зависящее от типа поведение, необходимое для безопасного дублирования значений.
/// Например, при реализации [`Clone`] для [`String`] необходимо скопировать указанный строковый буфер в кучу.
/// Простая побитовая копия значений [`String`] просто скопирует указатель, что приведет к двойному освобождению строки.
/// По этой причине [`String`]-это [`Clone`], но не `Copy`.
///
/// [`Clone`] является надстройкой `Copy`, поэтому все, что является `Copy`, также должно реализовывать [`Clone`].
/// Если типом является `Copy`, тогда его реализация [`Clone`] должна возвращать только `*self` (см. Пример выше).
///
/// ## Когда мой тип может быть `Copy`?
///
/// Тип может реализовать `Copy`, если все его компоненты реализуют `Copy`.Например, эта структура может быть `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Структура может быть `Copy`, а [`i32`]-`Copy`, поэтому `Point` может быть `Copy`.
/// Напротив, рассмотрим
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Структура `PointList` не может реализовать `Copy`, потому что [`Vec<T>`] не является `Copy`.Если мы попытаемся получить реализацию `Copy`, мы получим ошибку:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Общие ссылки (`&T`) также являются `Copy`, поэтому типом может быть `Copy`, даже если он содержит общие ссылки типов `T`, которые *не*`Copy`.
/// Рассмотрим следующую структуру, которая может реализовать `Copy`, потому что она содержит только *общую ссылку* на наш не-копирующий тип `PointList`, указанный выше:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Когда *не* может * мой тип быть `Copy`?
///
/// Некоторые типы нельзя безопасно скопировать.Например, копирование `&mut T` приведет к созданию изменяемой ссылки с псевдонимом.
/// Копирование [`String`] дублирует ответственность за управление буфером [`String`], что приводит к двойному освобождению.
///
/// Обобщая последний случай, любой тип, реализующий [`Drop`], не может быть `Copy`, потому что он управляет некоторым ресурсом, помимо своих собственных байтов [`size_of::<T>`].
///
/// Если вы попытаетесь реализовать `Copy` в структуре или перечислении, содержащем данные, отличные от `Copy`, вы получите ошибку [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Когда *должен* мой тип быть `Copy`?
///
/// Вообще говоря, если ваш тип _can_ реализует `Copy`, он должен.
/// Однако имейте в виду, что реализация `Copy` является частью общедоступного API вашего типа.
/// Если в future тип может стать не-Copy, было бы благоразумно опустить реализацию `Copy` сейчас, чтобы избежать критического изменения API.
///
/// ## Дополнительные разработчики
///
/// Помимо [implementors listed below][impls], `Copy` реализуют также следующие типы:
///
/// * Типы функциональных элементов (т. Е. Отдельные типы, определенные для каждой функции)
/// * Типы указателей функций (например, `fn() -> i32`)
/// * Типы массивов для всех размеров, если тип элемента также реализует `Copy` (например, `[i32; 123456]`)
/// * Типы кортежей, если каждый компонент также реализует `Copy` (например, `()`, `(i32, bool)`)
/// * Типы замыкания, если они не захватывают значение из среды или если все такие захваченные значения реализуют `Copy` сами.
///   Обратите внимание, что переменные, захваченные общей ссылкой, всегда реализуют `Copy` (даже если референт этого не делает), тогда как переменные, захваченные изменяемой ссылкой, никогда не реализуют `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Это позволяет копировать тип, который не реализует `Copy` из-за неудовлетворенных границ времени жизни (копирование `A<'_>`, когда только `A<'static>: Copy` и `A<'_>: Clone`).
// У нас есть этот атрибут на данный момент только потому, что существует довольно много специализаций на `Copy`, которые уже существуют в стандартной библиотеке, и нет никакого способа безопасно иметь такое поведение прямо сейчас.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Макрос Derive, генерирующий имплантацию trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Типы, для которых безопасно делиться ссылками между потоками.
///
/// Этот trait реализуется автоматически, когда компилятор определяет это подходящим.
///
/// Точное определение таково: тип `T` является [`Sync`] тогда и только тогда, когда `&T` равен [`Send`].
/// Другими словами, если нет возможности [undefined behavior][ub] (включая гонки данных) при передаче ссылок `&T` между потоками.
///
/// Как и следовало ожидать, все примитивные типы, такие как [`u8`] и [`f64`], являются [`Sync`], как и простые агрегатные типы, содержащие их, такие как кортежи, структуры и перечисления.
/// Дополнительные примеры базовых типов [`Sync`] включают типы "immutable", такие как `&T`, и типы с простой наследуемой изменчивостью, такие как [`Box<T>`][box], [`Vec<T>`][vec] и большинство других типов коллекций.
///
/// (Общие параметры должны быть [`Sync`], чтобы их контейнер был [`Sync`].)
///
/// Несколько неожиданным следствием определения является то, что `&mut T`-это `Sync` (если `T`-это `Sync`), хотя кажется, что это может обеспечить несинхронизированную мутацию.
/// Хитрость заключается в том, что изменяемая ссылка за общей ссылкой (то есть `& &mut T`) становится доступной только для чтения, как если бы это был `& &T`.
/// Следовательно, нет риска гонки данных.
///
/// Типы, которые не являются `Sync`,-это те, которые имеют "interior mutability" в небезопасной форме, например [`Cell`][cell] и [`RefCell`][refcell].
/// Эти типы допускают изменение своего содержимого даже с помощью неизменяемой общей ссылки.
/// Например, метод `set` на [`Cell<T>`][cell] принимает `&self`, поэтому для него требуется только общая ссылка [`&Cell<T>`][cell].
/// Метод не выполняет синхронизацию, поэтому [`Cell`][cell] не может быть `Sync`.
///
/// Другим примером типа, отличного от `Sync`, является указатель подсчета ссылок [`Rc`][rc].
/// Учитывая любую ссылку [`&Rc<T>`][rc], вы можете клонировать новый [`Rc<T>`][rc], изменяя счетчики ссылок неатомарным способом.
///
/// Для случаев, когда требуется внутренняя изменчивость с поддержкой потоков, Rust предоставляет [atomic data types], а также явную блокировку через [`sync::Mutex`][mutex] и [`sync::RwLock`][rwlock].
/// Эти типы гарантируют, что любая мутация не может вызвать гонку данных, следовательно, это типы `Sync`.
/// Точно так же [`sync::Arc`][arc] представляет собой поточно-ориентированный аналог [`Rc`][rc].
///
/// Любые типы с внутренней изменчивостью должны также использовать оболочку [`cell::UnsafeCell`][unsafecell] вокруг value(s), которая может быть изменена с помощью общей ссылки.
/// В противном случае это [undefined behavior][ub].
/// Например, преобразование [`transmute`][преобразование] из `&T` в `&mut T` недопустимо.
///
/// См. [the Nomicon][nomicon-send-and-sync] для получения более подробной информации о `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): после того, как поддержка добавления примечаний в `rustc_on_unimplemented` появится в бета-версии, и она была расширена, чтобы проверить, есть ли закрытие где-либо в цепочке требований, расширите ее как таковую (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Шрифт нулевого размера используется для обозначения вещей, которые "act like" принадлежат им, `T`.
///
/// Добавление поля `PhantomData<T>` к вашему типу сообщает компилятору, что ваш тип действует так, как если бы он хранит значение типа `T`, хотя на самом деле это не так.
/// Эта информация используется при вычислении определенных характеристик безопасности.
///
/// Для более подробного объяснения того, как использовать `PhantomData<T>`, см. [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Ужасная записка
///
/// Хотя у них обоих страшные имена, `PhantomData` и «фантомные типы» связаны, но не идентичны.Параметр фантомного типа-это просто параметр типа, который никогда не используется.
/// В Rust это часто вызывает жалобы компилятора, и решение состоит в том, чтобы добавить использование "dummy" посредством `PhantomData`.
///
/// # Examples
///
/// ## Неиспользуемые параметры времени жизни
///
/// Возможно, наиболее распространенным вариантом использования `PhantomData` является структура с неиспользуемым параметром времени жизни, обычно как часть небезопасного кода.
/// Например, вот структура `Slice`, которая имеет два указателя типа `*const T`, предположительно указывающих где-то в массиве:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Предполагается, что базовые данные действительны только в течение срока службы `'a`, поэтому `Slice` не должен пережить `'a`.
/// Однако это намерение не выражено в коде, поскольку время жизни `'a` не используется, и, следовательно, неясно, к каким данным оно применяется.
/// Мы можем исправить это, указав компилятору действовать *как если бы* структура `Slice` содержала ссылку `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Это также, в свою очередь, требует аннотации `T: 'a`, указывающей, что любые ссылки в `T` действительны в течение срока службы `'a`.
///
/// При инициализации `Slice` вы просто указываете значение `PhantomData` для поля `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Неиспользуемые параметры типа
///
/// Иногда случается, что у вас есть неиспользуемые параметры типа, которые указывают, к какому типу данных относится структура "tied", даже если эти данные фактически не находятся в самой структуре.
/// Вот пример, когда это происходит с [FFI].
/// Внешний интерфейс использует дескрипторы типа `*mut ()` для ссылки на значения Rust разных типов.
/// Мы отслеживаем тип Rust с помощью параметра фантомного типа в структуре `ExternalResource`, которая обертывает дескриптор.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Право собственности и дроп-чек
///
/// Добавление поля типа `PhantomData<T>` означает, что вашему типу принадлежат данные типа `T`.Это, в свою очередь, означает, что когда ваш тип отбрасывается, он может отбросить один или несколько экземпляров типа `T`.
/// Это имеет отношение к анализу [drop check] компилятора Rust.
///
/// Если ваша структура на самом деле *не владеет* данными типа `T`, лучше использовать ссылочный тип, например `PhantomData<&'a T>` (ideally) или `PhantomData<*const T>` (если время жизни не применяется), чтобы не указывать владение.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Внутренний trait компилятора, используемый для указания типа дискриминантов перечисления.
///
/// Этот trait автоматически реализуется для каждого типа и не добавляет никаких гарантий к [`mem::Discriminant`].
/// Это **неопределенное поведение** для преобразования между `DiscriminantKind::Discriminant` и `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Тип дискриминанта, который должен удовлетворять trait bounds, требуемому `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// trait внутри компилятора, используемый для определения, содержит ли тип какой-либо `UnsafeCell` внутри, но не через косвенное обращение.
///
/// Это влияет, например, на то, помещается ли `static` этого типа в статическую память только для чтения или статическую память с возможностью записи.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Типы, которые можно безопасно перемещать после закрепления.
///
/// Сам Rust не имеет понятия о неподвижных типах и считает ходы (например, посредством присваивания или [`mem::replace`]) всегда безопасными.
///
/// Вместо этого используется тип [`Pin`][Pin] для предотвращения перемещений по системе типов.Указатели `P<T>`, заключенные в оболочку [`Pin<P<T>>`][Pin], не могут быть перемещены.
/// См. Документацию [`pin` module] для получения дополнительной информации о закреплении.
///
/// Реализация `Unpin` trait для `T` снимает ограничения привязки типа, что затем позволяет перемещать `T` из [`Pin<P<T>>`][Pin] с помощью таких функций, как [`mem::replace`].
///
///
/// `Unpin` не имеет никаких последствий для незакрепленных данных.
/// В частности, [`mem::replace`] успешно перемещает данные `!Unpin` (он работает для любого `&mut T`, а не только для `T: Unpin`).
/// Однако вы не можете использовать [`mem::replace`] для данных, упакованных внутри [`Pin<P<T>>`][Pin], потому что вы не можете получить `&mut T`, который вам нужен для этого, и *это*-то, что заставляет эту систему работать.
///
/// Так, например, это можно сделать только для типов, реализующих `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Нам нужна изменяемая ссылка для вызова `mem::replace`.
/// // Мы можем получить такую ссылку, вызвав (implicitly) `Pin::deref_mut`, но это возможно только потому, что `String` реализует `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Этот trait автоматически реализуется почти для каждого типа.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Тип маркера, который не реализует `Unpin`.
///
/// Если тип содержит `PhantomPinned`, он не будет реализовывать `Unpin` по умолчанию.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Реализации `Copy` для примитивных типов.
///
/// Реализации, которые не могут быть описаны в Rust, реализованы в `traits::SelectionContext::copy_clone_conditions()` в `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Общие ссылки можно копировать, но изменяемые ссылки *не могут*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}