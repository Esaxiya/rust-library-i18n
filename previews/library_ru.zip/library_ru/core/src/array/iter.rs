//! Определяет итератор, принадлежащий `IntoIter` для массивов.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Итератор [array] по значению.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Это массив, который мы повторяем.
    ///
    /// Элементы с индексом `i`, где `alive.start <= i < alive.end` еще не выданы и являются допустимыми записями массива.
    /// Элементы с индексами `i < alive.start` или `i >= alive.end` уже выданы и больше не должны быть доступны!Эти мертвые элементы могут быть даже в полностью неинициализированном состоянии!
    ///
    ///
    /// Итак, инварианты:
    /// - `data[alive]` жив (т.е. содержит допустимые элементы)
    /// - `data[..alive.start]` и `data[alive.end..]` мертвы (т. е. элементы уже были прочитаны и их больше нельзя трогать!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Элементы в `data`, которые еще не сданы.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Создает новый итератор для данного `array`.
    ///
    /// *Примечание*: этот метод может быть устаревшим в future после [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Тип `value` здесь-`i32`, а не `&i32`.
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // БЕЗОПАСНОСТЬ: Трансмутация здесь действительно безопасна.Документы `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` гарантированно будет иметь одинаковый размер и выравнивание
        // > как `T`.
        //
        // Документы даже показывают преобразование из массива `MaybeUninit<T>` в массив `T`.
        //
        //
        // При этом эта инициализация удовлетворяет инвариантам.

        // FIXME(LukasKalbertodt): на самом деле здесь используется `mem::transmute`, если он работает с константными дженериками:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // А пока мы можем использовать `mem::transmute_copy` для создания побитовой копии как другого типа, а затем забыть `array`, чтобы он не был удален.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Возвращает неизменяемый фрагмент всех элементов, которые еще не были получены.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // БЕЗОПАСНОСТЬ: Мы знаем, что все элементы в `alive` правильно инициализированы.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Возвращает изменяемый фрагмент всех элементов, которые еще не были получены.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // БЕЗОПАСНОСТЬ: Мы знаем, что все элементы в `alive` правильно инициализированы.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Получите следующий указатель спереди.
        //
        // Увеличение `alive.start` на 1 сохраняет инвариант относительно `alive`.
        // Однако из-за этого изменения на короткое время живая зона больше не `data[alive]`, а `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Считайте элемент из массива.
            // БЕЗОПАСНОСТЬ: `idx`-это индекс бывшего региона "alive"
            // множество.Чтение этого элемента означает, что `data[idx]` сейчас считается мертвым (т.е. не трогать).
            // Поскольку `idx` был началом активной зоны, активная зона теперь снова `data[alive]`, восстанавливая все инварианты.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Получите следующий индекс с обратной стороны.
        //
        // Уменьшение `alive.end` на 1 сохраняет инвариант относительно `alive`.
        // Однако из-за этого изменения на короткое время живая зона больше не `data[alive]`, а `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Считайте элемент из массива.
            // БЕЗОПАСНОСТЬ: `idx`-это индекс бывшего региона "alive"
            // множество.Чтение этого элемента означает, что `data[idx]` сейчас считается мертвым (т.е. не трогать).
            // Поскольку `idx` был концом активной зоны, активная зона теперь снова `data[alive]`, восстанавливая все инварианты.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // БЕЗОПАСНОСТЬ: Это безопасно: `as_mut_slice` возвращает именно суб-срез
        // элементов, которые еще не были перемещены и которые еще предстоит удалить.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Никогда не будет переполнения из-за инварианта `alive.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Итератор действительно сообщает правильную длину.
// Количество элементов "alive" (которые все равно будут выданы)-это длина диапазона `alive`.
// Длина этого диапазона уменьшается либо в `next`, либо в `next_back`.
// В этих методах он всегда уменьшается на 1, но только если возвращается `Some(_)`.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Обратите внимание: нам действительно не нужно соответствовать одному и тому же живому диапазону, поэтому мы можем просто клонировать со смещением 0 независимо от того, где находится `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Клонируйте все живые элементы.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Запишите клон в новый массив, затем обновите его активный диапазон.
            // Если клонировать panics, мы правильно удалим предыдущие элементы.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Распечатайте только те элементы, которые еще не были получены: мы больше не можем получить доступ к полученным элементам.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}