use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Обертка, запрещающая компилятору автоматически вызывать деструктор T.
/// Эта обертка имеет нулевую стоимость.
///
/// `ManuallyDrop<T>` подлежит той же оптимизации компоновки, что и `T`.
/// Как следствие, он *не влияет* на предположения, которые компилятор делает о его содержимом.
/// Например, инициализация `ManuallyDrop<&mut T>` с помощью [`mem::zeroed`] является неопределенным поведением.
/// Если вам нужно обрабатывать неинициализированные данные, используйте вместо этого [`MaybeUninit<T>`].
///
/// Обратите внимание, что доступ к значению внутри `ManuallyDrop<T>` безопасен.
/// Это означает, что `ManuallyDrop<T>`, контент которого был удален, не должен быть доступен через общедоступный безопасный API.
/// Соответственно, `ManuallyDrop::drop` небезопасен.
///
/// # `ManuallyDrop` и оставьте заказ.
///
/// Rust имеет четко определенный [drop order] значений.
/// Чтобы убедиться, что поля или локальные переменные удаляются в определенном порядке, измените порядок объявлений так, чтобы неявный порядок удаления был правильным.
///
/// Можно использовать `ManuallyDrop` для управления порядком вывода, но для этого требуется небезопасный код, и его трудно сделать правильно при наличии разматывания.
///
///
/// Например, если вы хотите убедиться, что определенное поле удаляется после других, сделайте его последним полем структуры:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` будет сброшен после `children`.
///     // Rust гарантирует, что поля удаляются в порядке объявления.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Оберните значение, которое нужно отбросить вручную.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Вы по-прежнему можете спокойно оперировать значением
    /// assert_eq!(*x, "Hello");
    /// // Но `Drop` здесь работать не будет
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Извлекает значение из контейнера `ManuallyDrop`.
    ///
    /// Это позволяет снова сбросить значение.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Это понижает `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Извлекает значение из контейнера `ManuallyDrop<T>`.
    ///
    /// Этот метод в первую очередь предназначен для удаления значений по каплям.
    /// Вместо того, чтобы использовать [`ManuallyDrop::drop`] для ручного удаления значения, вы можете использовать этот метод, чтобы взять значение и использовать его по своему усмотрению.
    ///
    /// По возможности предпочтительно использовать вместо него [`into_inner`][`ManuallyDrop::into_inner`], что предотвращает дублирование содержимого `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Эта функция семантически перемещает содержащееся значение, не препятствуя дальнейшему использованию, оставляя состояние этого контейнера неизменным.
    /// Вы несете ответственность за то, чтобы `ManuallyDrop` больше не использовался.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // БЕЗОПАСНОСТЬ: мы читаем по ссылке, которая гарантирована
        // быть действительным для чтения.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Вручную удаляет содержащееся значение.Это в точности эквивалентно вызову [`ptr::drop_in_place`] с указателем на содержащееся значение.
    /// Таким образом, если содержащееся значение не является упакованной структурой, деструктор будет вызываться на месте без перемещения значения и, таким образом, может использоваться для безопасного удаления данных [pinned].
    ///
    /// Если вы владеете ценностью, вы можете вместо этого использовать [`ManuallyDrop::into_inner`].
    ///
    /// # Safety
    ///
    /// Эта функция запускает деструктор содержащегося значения.
    /// Помимо изменений, сделанных самим деструктором, память остается неизменной, и, поскольку компилятор заинтересован, все еще хранит битовый шаблон, который действителен для типа `T`.
    ///
    ///
    /// Однако это значение "zombie" не должно подвергаться безопасному коду, и эта функция не должна вызываться более одного раза.
    /// Использование значения после того, как оно было отброшено, или удаление значения несколько раз может вызвать неопределенное поведение (в зависимости от того, что делает `drop`).
    /// Обычно это предотвращается системой типов, но пользователи `ManuallyDrop` должны соблюдать эти гарантии без помощи компилятора.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // БЕЗОПАСНОСТЬ: мы удаляем значение, на которое указывает изменяемая ссылка
        // который гарантированно будет действителен для записи.
        // Вызывающий абонент должен убедиться, что `slot` больше не сбрасывается.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}