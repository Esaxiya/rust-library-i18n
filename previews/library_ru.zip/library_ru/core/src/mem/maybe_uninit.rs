use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Тип оболочки для создания неинициализированных экземпляров `T`.
///
/// # Инвариант инициализации
///
/// Компилятор, как правило, предполагает, что переменная правильно инициализирована в соответствии с требованиями типа переменной.Например, переменная ссылочного типа должна быть выровнена и отличаться от NULL.
/// Это инвариант, который должен *всегда* соблюдаться, даже в небезопасном коде.
/// Как следствие, инициализация нуля переменной ссылочного типа вызывает мгновенное [undefined behavior][ub], независимо от того, используется ли эта ссылка когда-либо для доступа к памяти:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // неопределенное поведение!⚠️
/// // Эквивалентный код с `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // неопределенное поведение!⚠️
/// ```
///
/// Это используется компилятором для различных оптимизаций, таких как исключение проверок времени выполнения и оптимизация макета `enum`.
///
/// Точно так же полностью неинициализированная память может иметь любое содержимое, в то время как `bool` всегда должен быть `true` или `false`.Следовательно, создание неинициализированного `bool` является неопределенным поведением:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // неопределенное поведение!⚠️
/// // Эквивалентный код с `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // неопределенное поведение!⚠️
/// ```
///
/// Более того, неинициализированная память отличается тем, что у нее нет фиксированного значения ("fixed" означает "it won't change without being written to").Чтение одного и того же неинициализированного байта несколько раз может дать разные результаты.
/// Это заставляет неопределенное поведение иметь неинициализированные данные в переменной, даже если эта переменная имеет целочисленный тип, который в противном случае может содержать любой *фиксированный* битовый шаблон:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // неопределенное поведение!⚠️
/// // Эквивалентный код с `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // неопределенное поведение!⚠️
/// ```
/// (Обратите внимание, что правила для неинициализированных целых чисел еще не окончательно утверждены, но пока они не будут завершены, рекомендуется их избегать.)
///
/// Кроме того, помните, что у большинства типов есть дополнительные инварианты, помимо того, что они просто считаются инициализированными на уровне типа.
/// Например, инициализированный «1» [`Vec<T>`] считается инициализированным (в текущей реализации; это не является стабильной гарантией), потому что единственное требование, которое компилятор знает о нем,-это то, что указатель данных не должен быть нулевым.
/// Создание такого `Vec<T>` не вызывает *немедленного* неопределенного поведения, но вызовет неопределенное поведение при большинстве безопасных операций (включая его удаление).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` служит для того, чтобы небезопасный код обрабатывал неинициализированные данные.
/// Это сигнал компилятору, указывающий, что данные здесь могут *не* быть инициализированы:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Создайте явно неинициализированную ссылку.
/// // Компилятор знает, что данные внутри `MaybeUninit<T>` могут быть недопустимыми, и, следовательно, это не UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Установите допустимое значение.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Извлеките инициализированные данные-это разрешено *только после* правильной инициализации `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Тогда компилятор знает, что нельзя делать никаких неверных предположений или оптимизаций в этом коде.
///
/// Вы можете думать о `MaybeUninit<T>` как о чем-то вроде `Option<T>`, но без какого-либо отслеживания времени выполнения и без каких-либо проверок безопасности.
///
/// ## out-pointers
///
/// Вы можете использовать `MaybeUninit<T>` для реализации "out-pointers": вместо того, чтобы возвращать данные из функции, передайте ей указатель на некоторую память (uninitialized), в которую можно поместить результат.
/// Это может быть полезно, когда для вызывающей стороны важно контролировать, как выделяется память, в которой сохраняется результат, и вы хотите избежать ненужных перемещений.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` не сбрасывает старое содержимое, что немаловажно.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Теперь мы знаем, что `v` инициализирован!Это также гарантирует правильное падение vector.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Инициализация массива поэлементно
///
/// `MaybeUninit<T>` может использоваться для поэлементной инициализации большого массива:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Создайте неинициализированный массив `MaybeUninit`.
///     // `assume_init` безопасен, потому что тип, который, как мы утверждаем, инициализирован, представляет собой набор «MaybeUninit`s», которые не требуют инициализации.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Отказ от `MaybeUninit` ничего не делает.
///     // Таким образом, использование присваивания необработанного указателя вместо `ptr::write` не приводит к удалению старого неинициализированного значения.
/////
///     // Также, если во время этого цикла возникает panic, у нас есть утечка памяти, но нет проблем с безопасностью памяти.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Все инициализировано.
///     // Преобразуйте массив в инициализированный тип.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Вы также можете работать с частично инициализированными массивами, которые можно найти в низкоуровневых структурах данных.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Создайте неинициализированный массив `MaybeUninit`.
/// // `assume_init` безопасен, потому что тип, который, как мы утверждаем, инициализирован, представляет собой набор «MaybeUninit`s», которые не требуют инициализации.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Подсчитайте количество элементов, которые мы назначили.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Для каждого элемента в массиве отбрасываем, если мы его выделили.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Инициализация структуры поле за полем
///
/// Вы можете использовать `MaybeUninit<T>` и макрос [`std::ptr::addr_of_mut`] для инициализации структур поле за полем:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Инициализация поля `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Инициализация поля `list`. Если здесь есть panic, значит, происходит утечка `String` в поле `name`.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Все поля инициализированы, поэтому мы вызываем `assume_init`, чтобы получить инициализированный Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` гарантированно имеет тот же размер, выравнивание и ABI, что и `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Однако помните, что тип,*содержащий*`MaybeUninit<T>`, не обязательно имеет тот же макет;Rust в целом не гарантирует, что поля `Foo<T>` имеют тот же порядок, что и `Foo<U>`, даже если `T` и `U` имеют одинаковый размер и выравнивание.
///
/// Кроме того, поскольку для `MaybeUninit<T>` допустимо любое битовое значение, компилятор не может применить оптимизацию non-zero/niche-filling, что может привести к большему размеру:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Если `T` безопасен для FFI, то `MaybeUninit<T>` тоже.
///
/// Хотя `MaybeUninit`-это `#[repr(transparent)]` (что означает, что он гарантирует тот же размер, выравнивание и ABI, что и `T`), это *не* меняет никаких из предыдущих предупреждений.
/// `Option<T>` и `Option<MaybeUninit<T>>` могут по-прежнему иметь разные размеры, а типы, содержащие поле типа `T`, могут располагаться (и иметь размер) иначе, чем если бы это поле было `MaybeUninit<T>`.
/// `MaybeUninit` - это тип объединения, а `#[repr(transparent)]` для объединений нестабилен (см. [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Со временем точные гарантии `#[repr(transparent)]` для профсоюзов могут измениться, и `MaybeUninit` может остаться, а может и не остаться `#[repr(transparent)]`.
/// Тем не менее, `MaybeUninit<T>`*всегда* будет гарантировать, что он имеет тот же размер, выравнивание и ABI, что и `T`;просто способ, которым `MaybeUninit` реализует эту гарантию, может развиваться.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang, чтобы мы могли обернуть в него другие типы.Это полезно для генераторов.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Не вызывая `T::clone()`, мы не можем знать, достаточно ли инициализированы для этого.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Создает новый `MaybeUninit<T>`, инициализированный заданным значением.
    /// Можно безопасно вызывать [`assume_init`] для возвращаемого значения этой функции.
    ///
    /// Обратите внимание, что при удалении `MaybeUninit<T>` никогда не будет вызван код отбрасывания T.
    /// Вы несете ответственность за то, чтобы `T` отключился, если он был инициализирован.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Создает новый `MaybeUninit<T>` в неинициализированном состоянии.
    ///
    /// Обратите внимание, что при удалении `MaybeUninit<T>` никогда не будет вызван код отбрасывания T.
    /// Вы несете ответственность за то, чтобы `T` отключился, если он был инициализирован.
    ///
    /// См. Примеры [type-level documentation][MaybeUninit].
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Создайте новый массив элементов `MaybeUninit<T>` в неинициализированном состоянии.
    ///
    /// Note: в версии future Rust этот метод может стать ненужным, если синтаксис литерала массива позволяет [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// В приведенном ниже примере можно использовать `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Возвращает (возможно, меньший) фрагмент данных, который был фактически прочитан
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // БЕЗОПАСНОСТЬ: Действует неинициализированный `[MaybeUninit<_>; LEN]`.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Создает новый `MaybeUninit<T>` в неинициализированном состоянии с заполнением памяти байтами `0`.От `T` зависит, будет ли это уже сделано для правильной инициализации.
    ///
    /// Например, `MaybeUninit<usize>::zeroed()` инициализируется, а `MaybeUninit<&'static i32>::zeroed()` нет, потому что ссылки не должны быть нулевыми.
    ///
    /// Обратите внимание, что при удалении `MaybeUninit<T>` никогда не будет вызван код отбрасывания T.
    /// Вы несете ответственность за то, чтобы `T` отключился, если он был инициализирован.
    ///
    /// # Example
    ///
    /// Правильное использование этой функции: инициализация структуры нулем, где все поля структуры могут содержать битовый шаблон 0 как допустимое значение.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Неправильное* использование этой функции: вызов `x.zeroed().assume_init()`, когда `0` не является допустимым битовым шаблоном для типа:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Внутри пары мы создаем `NotZero`, у которого нет допустимого дискриминанта.
    /// // Это неопределенное поведение.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // БЕЗОПАСНОСТЬ: `u.as_mut_ptr()` указывает на выделенную память.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Устанавливает значение `MaybeUninit<T>`.
    /// Это перезаписывает любое предыдущее значение, не отбрасывая его, поэтому будьте осторожны, не используйте это дважды, если вы не хотите пропустить запуск деструктора.
    ///
    /// Для вашего удобства это также возвращает изменяемую ссылку на (теперь безопасно инициализированное) содержимое `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // БЕЗОПАСНОСТЬ: мы только что инициализировали это значение.
        unsafe { self.assume_init_mut() }
    }

    /// Получает указатель на содержащееся значение.
    /// Чтение из этого указателя или превращение его в ссылку является неопределенным поведением, если `MaybeUninit<T>` не инициализирован.
    /// Запись в память, на которую указывает этот указатель (non-transitively), является неопределенным поведением (кроме `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Правильное использование этого метода:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Создайте ссылку на `MaybeUninit<T>`.Это нормально, потому что мы его инициализировали.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Неправильное* использование этого метода:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Мы создали ссылку на неинициализированный vector!Это неопределенное поведение.⚠️
    /// ```
    ///
    /// (Обратите внимание, что правила, касающиеся ссылок на неинициализированные данные, еще не окончательно утверждены, но пока они не будут завершены, рекомендуется их избегать.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` и `ManuallyDrop` оба являются `repr(transparent)`, поэтому мы можем преобразовать указатель.
        self as *const _ as *const T
    }

    /// Получает изменяемый указатель на содержащееся значение.
    /// Чтение из этого указателя или превращение его в ссылку является неопределенным поведением, если `MaybeUninit<T>` не инициализирован.
    ///
    /// # Examples
    ///
    /// Правильное использование этого метода:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Создайте ссылку на `MaybeUninit<Vec<u32>>`.
    /// // Это нормально, потому что мы его инициализировали.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Неправильное* использование этого метода:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Мы создали ссылку на неинициализированный vector!Это неопределенное поведение.⚠️
    /// ```
    ///
    /// (Обратите внимание, что правила, касающиеся ссылок на неинициализированные данные, еще не окончательно утверждены, но пока они не будут завершены, рекомендуется их избегать.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` и `ManuallyDrop` оба являются `repr(transparent)`, поэтому мы можем преобразовать указатель.
        self as *mut _ as *mut T
    }

    /// Извлекает значение из контейнера `MaybeUninit<T>`.Это отличный способ гарантировать, что данные будут отброшены, потому что полученный `T` подвергается обычной обработке отбрасывания.
    ///
    /// # Safety
    ///
    /// Вызывающий абонент должен гарантировать, что `MaybeUninit<T>` действительно находится в инициализированном состоянии.Вызов этого, когда содержимое еще не полностью инициализировано, вызывает немедленное неопределенное поведение.
    /// [type-level documentation][inv] содержит дополнительную информацию об этом инварианте инициализации.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Кроме того, помните, что у большинства типов есть дополнительные инварианты, помимо того, что они просто считаются инициализированными на уровне типа.
    /// Например, инициализированный «1» [`Vec<T>`] считается инициализированным (в текущей реализации; это не является стабильной гарантией), потому что единственное требование, которое компилятор знает о нем,-это то, что указатель данных не должен быть нулевым.
    ///
    /// Создание такого `Vec<T>` не вызывает *немедленного* неопределенного поведения, но вызовет неопределенное поведение при большинстве безопасных операций (включая его удаление).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Правильное использование этого метода:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Неправильное* использование этого метода:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` еще не был инициализирован, поэтому последняя строка вызвала неопределенное поведение.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // БЕЗОПАСНОСТЬ: вызывающий должен гарантировать, что `self` инициализирован.
        // Это также означает, что `self` должен быть вариантом `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Считывает значение из контейнера `MaybeUninit<T>`.Результирующий `T` подвергается обычной обработке сброса.
    ///
    /// По возможности предпочтительно использовать вместо него [`assume_init`], что предотвращает дублирование содержимого `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Вызывающий абонент должен гарантировать, что `MaybeUninit<T>` действительно находится в инициализированном состоянии.Вызов этого, когда содержимое еще не полностью инициализировано, вызывает неопределенное поведение.
    /// [type-level documentation][inv] содержит дополнительную информацию об этом инварианте инициализации.
    ///
    /// Более того, это оставляет копию тех же данных в `MaybeUninit<T>`.
    /// При использовании нескольких копий данных (многократно вызывая `assume_init_read` или сначала вызывая `assume_init_read`, а затем [`assume_init`]), вы несете ответственность за то, чтобы эти данные действительно могли быть дублированы.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Правильное использование этого метода:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` это `Copy`, поэтому мы можем читать несколько раз.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Дублирование значения `None`-это нормально, поэтому мы можем читать несколько раз.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Неправильное* использование этого метода:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Теперь мы создали две копии одного и того же vector, что привело к двойному освобождению ⚠️, когда они оба упали!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // БЕЗОПАСНОСТЬ: вызывающий должен гарантировать, что `self` инициализирован.
        // Чтение с `self.as_ptr()` безопасно, так как `self` должен быть инициализирован.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Помещает содержащееся значение на место.
    ///
    /// Если у вас есть `MaybeUninit`, вы можете использовать [`assume_init`].
    ///
    /// # Safety
    ///
    /// Вызывающий абонент должен гарантировать, что `MaybeUninit<T>` действительно находится в инициализированном состоянии.Вызов этого, когда содержимое еще не полностью инициализировано, вызывает неопределенное поведение.
    ///
    /// Вдобавок к этому должны быть выполнены все дополнительные инварианты типа `T`, поскольку реализация `Drop` `T` (или его членов) может полагаться на это.
    /// Например, инициализированный «1» [`Vec<T>`] считается инициализированным (в текущей реализации; это не является стабильной гарантией), потому что единственное требование, которое компилятор знает о нем,-это то, что указатель данных не должен быть нулевым.
    ///
    /// Однако отказ от такого `Vec<T>` приведет к неопределенному поведению.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // БЕЗОПАСНОСТЬ: вызывающий должен гарантировать, что `self` инициализирован и
        // удовлетворяет всем инвариантам `T`.
        // В этом случае размещение значения на месте безопасно.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Получает общую ссылку на содержащееся значение.
    ///
    /// Это может быть полезно, когда мы хотим получить доступ к `MaybeUninit`, который был инициализирован, но не владеет `MaybeUninit` (предотвращая использование `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Вызов этого, когда содержимое еще не полностью инициализировано, вызывает неопределенное поведение: вызывающая сторона должна гарантировать, что `MaybeUninit<T>` действительно находится в инициализированном состоянии.
    ///
    ///
    /// # Examples
    ///
    /// ### Правильное использование этого метода:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Инициализировать `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Теперь, когда известно, что наш `MaybeUninit<_>` инициализирован, можно создать общую ссылку на него:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // БЕЗОПАСНОСТЬ: `x` был инициализирован.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Неправильное* использование этого метода:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Мы создали ссылку на неинициализированный vector!Это неопределенное поведение.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Инициализируйте `MaybeUninit` с помощью `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Ссылка на неинициализированный `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // БЕЗОПАСНОСТЬ: вызывающий должен гарантировать, что `self` инициализирован.
        // Это также означает, что `self` должен быть вариантом `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Получает изменяемую ссылку (unique) на содержащееся значение.
    ///
    /// Это может быть полезно, когда мы хотим получить доступ к `MaybeUninit`, который был инициализирован, но не владеет `MaybeUninit` (предотвращая использование `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Вызов этого, когда содержимое еще не полностью инициализировано, вызывает неопределенное поведение: вызывающая сторона должна гарантировать, что `MaybeUninit<T>` действительно находится в инициализированном состоянии.
    /// Например, `.assume_init_mut()` нельзя использовать для инициализации `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Правильное использование этого метода:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Инициализирует *все* байты входного буфера.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Инициализировать `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Теперь мы знаем, что `buf` был инициализирован, поэтому мы можем его `.assume_init()`.
    /// // Однако использование `.assume_init()` может вызвать `memcpy` из 2048 байтов.
    /// // Чтобы убедиться, что наш буфер инициализирован без его копирования, мы обновляем `&mut MaybeUninit<[u8; 2048]>` до `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // БЕЗОПАСНОСТЬ: `buf` был инициализирован.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Теперь мы можем использовать `buf` как обычный срез:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Неправильное* использование этого метода:
    ///
    /// Вы не можете использовать `.assume_init_mut()` для инициализации значения:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Мы создали ссылку (mutable) на неинициализированный `bool`!
    ///     // Это неопределенное поведение.⚠️
    /// }
    /// ```
    ///
    /// Например, вы не можете поместить [`Read`] в неинициализированный буфер:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) ссылка на неинициализированную память!
    ///                             // Это неопределенное поведение.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Вы также не можете использовать прямой доступ к полю для постепенной инициализации от поля к полю:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ссылка на неинициализированную память!
    ///                  // Это неопределенное поведение.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ссылка на неинициализированную память!
    ///                  // Это неопределенное поведение.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): В настоящее время мы полагаем, что вышесказанное неверно, т.е. у нас есть ссылки на неинициализированные данные (например, в `libcore/fmt/float.rs`).
    // Мы должны принять окончательное решение о правилах до стабилизации.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // БЕЗОПАСНОСТЬ: вызывающий должен гарантировать, что `self` инициализирован.
        // Это также означает, что `self` должен быть вариантом `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Извлекает значения из массива контейнеров `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Вызывающий объект должен гарантировать, что все элементы массива находятся в инициализированном состоянии.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // БЕЗОПАСНОСТЬ: Теперь безопасно, поскольку мы инициализировали все элементы
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Вызывающий гарантирует, что все элементы массива инициализированы.
        // * `MaybeUninit<T>` и T гарантированно имеют одинаковый макет
        // * MaybeUnint не падает, поэтому нет двойного освобождения, поэтому преобразование безопасно
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Предполагая, что все элементы инициализированы, выделите для них фрагмент.
    ///
    /// # Safety
    ///
    /// Вызывающая сторона должна гарантировать, что элементы `MaybeUninit<T>` действительно находятся в инициализированном состоянии.
    ///
    /// Вызов этого, когда содержимое еще не полностью инициализировано, вызывает неопределенное поведение.
    ///
    /// См. [`assume_init_ref`] для получения более подробной информации и примеров.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // БЕЗОПАСНОСТЬ: приведение среза к `*const [T]` безопасно, поскольку вызывающий гарантирует, что
        // `slice` инициализируется, и "MaybeUninit" гарантированно будет иметь тот же макет, что и `T`.
        // Полученный указатель действителен, поскольку он относится к памяти, принадлежащей `slice`, которая является ссылкой и, таким образом, гарантированно действительна для чтения.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Предполагая, что все элементы инициализированы, получите для них изменяемый фрагмент.
    ///
    /// # Safety
    ///
    /// Вызывающая сторона должна гарантировать, что элементы `MaybeUninit<T>` действительно находятся в инициализированном состоянии.
    ///
    /// Вызов этого, когда содержимое еще не полностью инициализировано, вызывает неопределенное поведение.
    ///
    /// См. [`assume_init_mut`] для получения более подробной информации и примеров.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // БЕЗОПАСНОСТЬ: аналогично указаниям по безопасности для `slice_get_ref`, но у нас есть
        // изменяемая ссылка, которая также гарантированно действительна для записи.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Получает указатель на первый элемент массива.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Получает изменяемый указатель на первый элемент массива.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Копирует элементы из `src` в `this`, возвращая изменяемую ссылку на теперь инициализированное содержимое `this`.
    ///
    /// Если `T` не реализует `Copy`, используйте [`write_slice_cloned`]
    ///
    /// Это похоже на [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Эта функция будет panic, если два среза имеют разную длину.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // БЕЗОПАСНОСТЬ: мы только что скопировали все элементы линзы в запасную емкость.
    /// // первые элементы src.len() vec действительны сейчас.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // БЕЗОПАСНОСТЬ: &[T] и&[MaybeUninit<T>] имеют тот же макет
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // БЕЗОПАСНОСТЬ: Действительные элементы только что скопированы в `this`, поэтому он инициализирован.
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Клонирует элементы из `src` в `this`, возвращая изменяемую ссылку на теперь инициализированное содержимое `this`.
    /// Любые уже инициализированные элементы не будут отброшены.
    ///
    /// Если `T` реализует `Copy`, используйте [`write_slice`]
    ///
    /// Это похоже на [`slice::clone_from_slice`], но не удаляет существующие элементы.
    ///
    /// # Panics
    ///
    /// Эта функция будет panic, если два среза имеют разную длину, или если реализация `Clone` panics.
    ///
    /// Если есть panic, уже клонированные элементы будут отброшены.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // БЕЗОПАСНОСТЬ: мы только что клонировали все элементы len в резервную емкость
    /// // первые элементы src.len() vec действительны сейчас.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // в отличие от copy_from_slice, это не вызывает clone_from_slice на срезе, потому что `MaybeUninit<T: Clone>` не реализует Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // БЕЗОПАСНОСТЬ: этот необработанный срез будет содержать только инициализированные объекты
                // поэтому его можно бросить.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Нам нужно явно разрезать их на одинаковую длину
        // для исключения проверки границ, и оптимизатор сгенерирует memcpy для простых случаев (например, T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // требуется охрана b/c panic может произойти во время клона
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // БЕЗОПАСНОСТЬ: В `this` только что записаны действительные элементы, поэтому он инициализирован.
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}