#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Расширяется до `$crate::panic::panic_2015` или `$crate::panic::panic_2021` в зависимости от версии вызывающего абонента.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Утверждает, что два выражения равны друг другу (с использованием [`PartialEq`]).
///
/// В panic этот макрос будет печатать значения выражений с их отладочными представлениями.
///
///
/// Как и [`assert!`], этот макрос имеет вторую форму, в которой может быть предоставлено настраиваемое сообщение panic.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Приведенные ниже повторные заимствования являются преднамеренными.
                    // Без них слот стека для заимствования инициализируется еще до сравнения значений, что приводит к заметному замедлению.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Приведенные ниже повторные заимствования являются преднамеренными.
                    // Без них слот стека для заимствования инициализируется еще до сравнения значений, что приводит к заметному замедлению.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Утверждает, что два выражения не равны друг другу (с использованием [`PartialEq`]).
///
/// В panic этот макрос будет печатать значения выражений с их отладочными представлениями.
///
///
/// Как и [`assert!`], этот макрос имеет вторую форму, в которой может быть предоставлено настраиваемое сообщение panic.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Приведенные ниже повторные заимствования являются преднамеренными.
                    // Без них слот стека для заимствования инициализируется еще до сравнения значений, что приводит к заметному замедлению.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Приведенные ниже повторные заимствования являются преднамеренными.
                    // Без них слот стека для заимствования инициализируется еще до сравнения значений, что приводит к заметному замедлению.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Утверждает, что логическое выражение-`true` во время выполнения.
///
/// Это вызовет макрос [`panic!`], если предоставленное выражение не может быть оценено как `true` во время выполнения.
///
/// Как и [`assert!`], этот макрос также имеет вторую версию, в которой может быть предоставлено настраиваемое сообщение panic.
///
/// # Uses
///
/// В отличие от [`assert!`], операторы `debug_assert!` по умолчанию включены только в неоптимизированных сборках.
/// Оптимизированная сборка не будет выполнять операторы `debug_assert!`, если `-C debug-assertions` не будет передан компилятору.
/// Это делает `debug_assert!` полезным для проверок, которые слишком дороги для присутствия в сборке релиза, но могут быть полезны во время разработки.
/// Результат расширения `debug_assert!` всегда проверяется на тип.
///
/// Непроверенное утверждение позволяет программе в несогласованном состоянии продолжать работу, что может иметь неожиданные последствия, но не создает небезопасности, если это происходит только в безопасном коде.
///
/// Однако стоимость утверждений в целом не поддается измерению.
/// Таким образом, замена [`assert!`] на `debug_assert!` рекомендуется только после тщательного профилирования и, что более важно, только в безопасном коде!
///
/// # Examples
///
/// ```
/// // сообщение panic для этих утверждений является строковым значением данного выражения.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // очень простая функция
/// debug_assert!(some_expensive_computation());
///
/// // утверждать с настраиваемым сообщением
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Утверждает, что два выражения равны друг другу.
///
/// В panic этот макрос будет печатать значения выражений с их отладочными представлениями.
///
/// В отличие от [`assert_eq!`], операторы `debug_assert_eq!` по умолчанию включены только в неоптимизированных сборках.
/// Оптимизированная сборка не будет выполнять операторы `debug_assert_eq!`, если `-C debug-assertions` не будет передан компилятору.
/// Это делает `debug_assert_eq!` полезным для проверок, которые слишком дороги для присутствия в сборке релиза, но могут быть полезны во время разработки.
///
/// Результат расширения `debug_assert_eq!` всегда проверяется на тип.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Утверждает, что два выражения не равны друг другу.
///
/// В panic этот макрос будет печатать значения выражений с их отладочными представлениями.
///
/// В отличие от [`assert_ne!`], операторы `debug_assert_ne!` по умолчанию включены только в неоптимизированных сборках.
/// Оптимизированная сборка не будет выполнять операторы `debug_assert_ne!`, если `-C debug-assertions` не будет передан компилятору.
/// Это делает `debug_assert_ne!` полезным для проверок, которые слишком дороги для присутствия в сборке релиза, но могут быть полезны во время разработки.
///
/// Результат расширения `debug_assert_ne!` всегда проверяется на тип.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Возвращает, соответствует ли данное выражение какому-либо из заданных шаблонов.
///
/// Как и в выражении `match`, за шаблоном необязательно может следовать `if` и защитное выражение, которое имеет доступ к именам, связанным шаблоном.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Разворачивает результат или распространяет его ошибку.
///
/// Оператор `?` был добавлен вместо `try!` и должен использоваться вместо него.
/// Кроме того, `try` является зарезервированным словом в Rust 2018, поэтому, если вы должны его использовать, вам нужно будет использовать [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` соответствует заданному [`Result`].В случае варианта `Ok` выражение имеет значение упакованного значения.
///
/// В случае варианта `Err` он извлекает внутреннюю ошибку.Затем `try!` выполняет преобразование с помощью `From`.
/// Это обеспечивает автоматическое преобразование между специализированными ошибками и более общими.
/// Полученная ошибка немедленно возвращается.
///
/// Из-за досрочного возврата `try!` можно использовать только в функциях, возвращающих [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Предпочтительный метод быстрого возврата ошибок
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Предыдущий метод быстрого возврата ошибок
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Это эквивалентно:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Записывает отформатированные данные в буфер.
///
/// Этот макрос принимает 'writer', строку формата и список аргументов.
/// Аргументы будут отформатированы в соответствии с указанной строкой формата, и результат будет передан автору записи.
/// Писателем может быть любое значение с методом `write_fmt`;обычно это происходит от реализации [`fmt::Write`] или [`io::Write`] trait.
/// Макрос возвращает все, что возвращает метод `write_fmt`;обычно [`fmt::Result`] или [`io::Result`].
///
/// См. [`std::fmt`] для получения дополнительной информации о синтаксисе строки формата.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Модуль может импортировать как `std::fmt::Write`, так и `std::io::Write` и вызывать `write!` для объектов, реализующих любой из них, поскольку объекты обычно не реализуют оба.
///
/// Однако модуль должен импортировать traits с квалификацией, чтобы их имена не конфликтовали:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // использует fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // использует io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Этот макрос также можно использовать в настройках `no_std`.
/// В установке `no_std` вы несете ответственность за детали реализации компонентов.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Записать отформатированные данные в буфер с добавлением новой строки.
///
/// На всех платформах новой строкой является только символ LINE FEED (`\n`/`U+000A`) (без дополнительных CARRIAGE RETURN (`\r`/`U+000D`).
///
/// Для получения дополнительной информации см. [`write!`].Для получения информации о синтаксисе строки формата см. [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Модуль может импортировать как `std::fmt::Write`, так и `std::io::Write` и вызывать `write!` для объектов, реализующих любой из них, поскольку объекты обычно не реализуют оба.
/// Однако модуль должен импортировать traits с квалификацией, чтобы их имена не конфликтовали:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // использует fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // использует io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Указывает на недостижимый код.
///
/// Это полезно в любое время, когда компилятор не может определить, что какой-то код недоступен.Например:
///
/// * Сопоставьте оружие с условиями охраны.
/// * Циклы с динамическим завершением.
/// * Итераторы с динамическим завершением.
///
/// Если определение, что код недоступен, оказывается неверным, программа немедленно завершается с сообщением [`panic!`].
///
/// Небезопасным аналогом этого макроса является функция [`unreachable_unchecked`], которая вызовет неопределенное поведение при достижении кода.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Это всегда будет [`panic!`].
///
/// # Examples
///
/// Матч оружия:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // ошибка компиляции, если закомментировано
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // одна из самых бедных реализаций x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Указывает на нереализованный код, вызывая панику с сообщением "not implemented".
///
/// Это позволяет вашему коду выполнять проверку типов, что полезно, если вы создаете прототип или реализуете trait, для которого требуется несколько методов, которые вы не планируете использовать все.
///
/// Разница между `unimplemented!` и [`todo!`] заключается в том, что, хотя `todo!` передает намерение реализовать функциональность позже, а сообщение-"not yet implemented", `unimplemented!` не делает таких заявлений.
/// Его сообщение-"not implemented".
/// Также некоторые IDE помечают `todo!` S.
///
/// # Panics
///
/// Это всегда будет [`panic!`], потому что `unimplemented!`-это просто сокращение от `panic!` с фиксированным, конкретным сообщением.
///
/// Как и `panic!`, этот макрос имеет вторую форму для отображения пользовательских значений.
///
/// # Examples
///
/// Допустим, у нас есть trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Мы хотим реализовать `Foo` для 'MyStruct', но по какой-то причине имеет смысл реализовать только функцию `bar()`.
/// `baz()` и `qux()` по-прежнему необходимо будет определить в нашей реализации `Foo`, но мы можем использовать `unimplemented!` в их определениях, чтобы наш код компилировался.
///
/// Мы по-прежнему хотим, чтобы наша программа останавливалась, если достигаются нереализованные методы.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Нет смысла использовать `baz` в `MyStruct`, поэтому здесь нет никакой логики.
/////
///         // Это отобразит "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // У нас тут есть логика, мы можем добавить сообщение к нереализованному!чтобы показать наше упущение.
///         // Это отобразит: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Указывает на незавершенный код.
///
/// Это может быть полезно, если вы создаете прототип и просто хотите проверить тип кода.
///
/// Разница между [`unimplemented!`] и `todo!` заключается в том, что, хотя `todo!` передает намерение реализовать функциональность позже, а сообщение-"not yet implemented", `unimplemented!` не делает таких заявлений.
/// Его сообщение-"not implemented".
/// Также некоторые IDE помечают `todo!` S.
///
/// # Panics
///
/// Это всегда будет [`panic!`].
///
/// # Examples
///
/// Вот пример некоторого незавершенного кода.У нас есть trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Мы хотим реализовать `Foo` на одном из наших типов, но мы также хотим сначала поработать только над `bar()`.Чтобы наш код компилировался, нам нужно реализовать `baz()`, поэтому мы можем использовать `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // реализация идет здесь
///     }
///
///     fn baz(&self) {
///         // давайте пока не будем беспокоиться о внедрении baz()
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // мы даже не используем baz(), так что это нормально.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Определения встроенных макросов.
///
/// Большинство свойств макроса (стабильность, видимость и т. Д.) Здесь взяты из исходного кода, за исключением функций раскрытия, преобразующих входные данные макроса в выходы, эти функции предоставляются компилятором.
///
///
pub(crate) mod builtin {

    /// При обнаружении вызывает сбой компиляции с указанным сообщением об ошибке.
    ///
    /// Этот макрос следует использовать, когда crate использует стратегию условной компиляции, чтобы предоставлять более точные сообщения об ошибках для ошибочных условий.
    ///
    /// Это форма [`panic!`] на уровне компилятора, но выдает ошибку во время *компиляции*, а не *во время выполнения*.
    ///
    /// # Examples
    ///
    /// Двумя такими примерами являются макросы и среды `#[cfg]`.
    ///
    /// Выдавать ошибку компилятора лучше, если макросу переданы недопустимые значения.
    /// Без последнего branch компилятор все равно выдаст ошибку, но в сообщении об ошибке не будут указаны два действительных значения.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Выдает ошибку компилятора, если одна из нескольких функций недоступна.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Создает параметры для других макросов форматирования строк.
    ///
    /// Этот макрос работает, принимая строковый литерал форматирования, содержащий `{}`, для каждого переданного дополнительного аргумента.
    /// `format_args!` подготавливает дополнительные параметры, чтобы выходные данные можно было интерпретировать как строку, и преобразует аргументы в один тип.
    /// Любое значение, реализующее [`Display`] trait, может быть передано в `format_args!`, как и любая реализация [`Debug`] может быть передана в `{:?}` в строке форматирования.
    ///
    ///
    /// Этот макрос создает значение типа [`fmt::Arguments`].Это значение можно передать макросам в [`std::fmt`] для выполнения полезного перенаправления.
    /// Все остальные макросы форматирования ([`format!`], [`write!`], [`println!`] и т. Д.) Проксируются через этот макрос.
    /// `format_args!`, в отличие от его производных макросов, избегает выделения кучи.
    ///
    /// Вы можете использовать значение [`fmt::Arguments`], которое `format_args!` возвращает в контекстах `Debug` и `Display`, как показано ниже.
    /// Пример также показывает, что `Debug` и `Display` форматируют одно и то же: строку интерполированного формата в `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Для получения дополнительной информации см. Документацию [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// То же, что `format_args`, но в конце добавляет новую строку.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Проверяет переменную среды во время компиляции.
    ///
    /// Этот макрос будет расширяться до значения названной переменной среды во время компиляции, давая выражение типа `&'static str`.
    ///
    ///
    /// Если переменная среды не определена, будет выдана ошибка компиляции.
    /// Чтобы не выдавать ошибку компиляции, используйте вместо этого макрос [`option_env!`].
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Вы можете настроить сообщение об ошибке, передав строку в качестве второго параметра:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Если переменная среды `documentation` не определена, вы получите следующую ошибку:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// При желании проверяет переменную среды во время компиляции.
    ///
    /// Если указанная переменная среды присутствует во время компиляции, она будет расширена в выражение типа `Option<&'static str>`, значение которого равно `Some` значения переменной среды.
    /// Если переменная среды отсутствует, она будет расширена до `None`.
    /// См. [`Option<T>`][Option] для получения дополнительной информации об этом типе.
    ///
    /// При использовании этого макроса никогда не возникает ошибка времени компиляции, независимо от того, присутствует ли переменная среды или нет.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Объединяет идентификаторы в один идентификатор.
    ///
    /// Этот макрос принимает любое количество идентификаторов, разделенных запятыми, и объединяет их все в один, получая выражение, которое является новым идентификатором.
    /// Обратите внимание, что гигиена делает так, что этот макрос не может захватывать локальные переменные.
    /// Кроме того, как правило, макросы разрешены только в позиции элемента, оператора или выражения.
    /// Это означает, что, хотя вы можете использовать этот макрос для ссылки на существующие переменные, функции или модули и т. Д., Вы не можете определить с его помощью новый.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (new, fun, name) { }//таким образом нельзя использовать!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Объединяет литералы в статический строковый фрагмент.
    ///
    /// Этот макрос принимает любое количество литералов, разделенных запятыми, что дает выражение типа `&'static str`, которое представляет все литералы, объединенные слева направо.
    ///
    ///
    /// Целочисленные литералы и литералы с плавающей запятой преобразованы в строку для объединения.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Расширяется до номера строки, в которой он был вызван.
    ///
    /// В [`column!`] и [`file!`] эти макросы предоставляют разработчикам отладочную информацию о местоположении в источнике.
    ///
    /// Расширенное выражение имеет тип `u32` и начинается с 1, поэтому первая строка в каждом файле оценивается как 1, вторая-как 2 и т. Д.
    /// Это согласуется с сообщениями об ошибках распространенных компиляторов или популярных редакторов.
    /// Возвращенная строка *не обязательно* является строкой самого вызова `line!`, а скорее является первым вызовом макроса, ведущим к вызову макроса `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Расширяется до номера столбца, в котором он был вызван.
    ///
    /// В [`line!`] и [`file!`] эти макросы предоставляют разработчикам отладочную информацию о местоположении в источнике.
    ///
    /// Расширенное выражение имеет тип `u32` и начинается с 1, поэтому первый столбец в каждой строке оценивается как 1, второй-как 2 и т. Д.
    /// Это согласуется с сообщениями об ошибках распространенных компиляторов или популярных редакторов.
    /// Возвращаемый столбец *не обязательно* является строкой самого вызова `column!`, а скорее первым вызовом макроса, ведущим к вызову макроса `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Заменяется на имя файла, в котором он был вызван.
    ///
    /// В [`line!`] и [`column!`] эти макросы предоставляют разработчикам отладочную информацию о местоположении в источнике.
    ///
    /// Расширенное выражение имеет тип `&'static str`, и возвращаемый файл не является вызовом самого макроса `file!`, а скорее первым вызовом макроса, ведущим к вызову макроса `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Стренирует свои аргументы.
    ///
    /// Этот макрос приведет к выражению типа `&'static str`, которое является преобразованием всех tokens, переданных в макрос.
    /// Никаких ограничений на синтаксис самого вызова макроса не накладывается.
    ///
    /// Обратите внимание, что расширенные результаты ввода tokens могут измениться в future.Будьте осторожны, если полагаетесь на результат.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Включает файл в кодировке UTF-8 в виде строки.
    ///
    /// Файл расположен относительно текущего файла (аналогично тому, как находятся модули).
    /// Предоставленный путь интерпретируется в зависимости от платформы во время компиляции.
    /// Так, например, вызов с путем Windows, содержащим обратную косую черту, `\` не будет правильно компилироваться на Unix.
    ///
    ///
    /// Этот макрос даст выражение типа `&'static str`, которое является содержимым файла.
    ///
    /// # Examples
    ///
    /// Предположим, что в одном каталоге есть два файла со следующим содержимым:
    ///
    /// Файл 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Файл 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Компиляция 'main.rs' и запуск полученного двоичного файла напечатают "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Включает файл как ссылку на массив байтов.
    ///
    /// Файл расположен относительно текущего файла (аналогично тому, как находятся модули).
    /// Предоставленный путь интерпретируется в зависимости от платформы во время компиляции.
    /// Так, например, вызов с путем Windows, содержащим обратную косую черту, `\` не будет правильно компилироваться на Unix.
    ///
    ///
    /// Этот макрос даст выражение типа `&'static [u8; N]`, которое является содержимым файла.
    ///
    /// # Examples
    ///
    /// Предположим, что в одном каталоге есть два файла со следующим содержимым:
    ///
    /// Файл 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Файл 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Компиляция 'main.rs' и запуск полученного двоичного файла напечатают "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Расширяется до строки, представляющей текущий путь к модулю.
    ///
    /// Текущий путь к модулю можно рассматривать как иерархию модулей, ведущих назад к crate root.
    /// Первый компонент возвращаемого пути-это имя компилируемого в данный момент crate.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Оценивает логические комбинации флагов конфигурации во время компиляции.
    ///
    /// В дополнение к атрибуту `#[cfg]`, этот макрос предназначен для оценки логических выражений флагов конфигурации.
    /// Это часто приводит к уменьшению дублирования кода.
    ///
    /// Синтаксис этого макроса совпадает с синтаксисом атрибута [`cfg`].
    ///
    /// `cfg!`, в отличие от `#[cfg]`, не удаляет код и оценивает только как истинное или ложное.
    /// Например, все блоки в выражении if/else должны быть действительными, когда `cfg!` используется для условия, независимо от того, что `cfg!` оценивает.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Анализирует файл как выражение или элемент в соответствии с контекстом.
    ///
    /// Файл расположен относительно текущего файла (аналогично тому, как находятся модули).Предоставленный путь интерпретируется в зависимости от платформы во время компиляции.
    /// Так, например, вызов с путем Windows, содержащим обратную косую черту, `\` не будет правильно компилироваться на Unix.
    ///
    /// Использование этого макроса часто является плохой идеей, потому что, если файл анализируется как выражение, он будет помещен в окружающий код негигиенично.
    /// Это может привести к тому, что переменные или функции будут отличаться от ожидаемых в файле, если в текущем файле есть переменные или функции с одинаковыми именами.
    ///
    ///
    /// # Examples
    ///
    /// Предположим, что в одном каталоге есть два файла со следующим содержимым:
    ///
    /// Файл 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Файл 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Компиляция 'main.rs' и запуск полученного двоичного файла напечатают "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Утверждает, что логическое выражение-`true` во время выполнения.
    ///
    /// Это вызовет макрос [`panic!`], если предоставленное выражение не может быть оценено как `true` во время выполнения.
    ///
    /// # Uses
    ///
    /// Утверждения всегда проверяются как в отладочной, так и в выпускной сборках и не могут быть отключены.
    /// См. [`debug_assert!`] для утверждений, которые не включены в сборках выпуска по умолчанию.
    ///
    /// Небезопасный код может полагаться на `assert!` для обеспечения соблюдения инвариантов времени выполнения, нарушение которых может привести к небезопасности.
    ///
    /// Другие варианты использования `assert!` включают тестирование и обеспечение соблюдения инвариантов времени выполнения в безопасном коде (нарушение которого не может привести к небезопасности).
    ///
    ///
    /// # Пользовательские сообщения
    ///
    /// Этот макрос имеет вторую форму, в которой пользовательское сообщение panic может быть предоставлено с аргументами для форматирования или без них.
    /// См. Синтаксис этой формы в [`std::fmt`].
    /// Выражения, используемые в качестве аргументов формата, будут оцениваться только в случае сбоя утверждения.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // сообщение panic для этих утверждений является строковым значением данного выражения.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // очень простая функция
    ///
    /// assert!(some_computation());
    ///
    /// // утверждать с настраиваемым сообщением
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Встроенная сборка.
    ///
    /// Прочтите [unstable book] для использования.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Встроенная сборка в стиле LLVM.
    ///
    /// Прочтите [unstable book] для использования.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Встроенная сборка на уровне модуля.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Отпечатки передали tokens на стандартный вывод.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Включает или отключает функцию трассировки, используемую для отладки других макросов.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Макрос атрибута, используемый для применения производных макросов.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Макрос атрибута, применяемый к функции, чтобы превратить ее в модульный тест.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Макрос атрибута, применяемый к функции, чтобы превратить ее в эталонный тест.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Деталь реализации макросов `#[test]` и `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Макрос атрибута, применяемый к статическому объекту, чтобы зарегистрировать его как глобальный распределитель.
    ///
    /// См. Также [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Сохраняет элемент, к которому он применяется, если переданный путь доступен, и удаляет его в противном случае.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Расширяет все атрибуты `#[cfg]` и `#[cfg_attr]` в фрагменте кода, к которому они применяются.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Детали нестабильной реализации компилятора `rustc`, не используйте.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Детали нестабильной реализации компилятора `rustc`, не используйте.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}