//! `Clone` trait для типов, которые нельзя «неявно скопировать».
//!
//! В Rust некоторыми простыми типами являются "implicitly copyable", и когда вы их назначаете или передаете в качестве аргументов, получатель получает копию, оставляя исходное значение на месте.
//! Эти типы не требуют выделения для копирования и не имеют финализаторов (т. Е. Они не содержат собственных блоков и не реализуют [`Drop`]), поэтому компилятор считает их дешевыми и безопасными для копирования.
//!
//! Для других типов копии должны быть сделаны явно, по соглашению с реализацией [`Clone`] trait и вызовом метода [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Базовый пример использования:
//!
//! ```
//! let s = String::new(); // Тип String реализует Clone
//! let copy = s.clone(); // чтобы мы могли его клонировать
//! ```
//!
//! Чтобы легко реализовать Clone trait, вы также можете использовать `#[derive(Clone)]`.Пример:
//!
//! ```
//! #[derive(Clone)] // мы добавляем Clone trait в структуру Morpheus
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // и теперь мы можем его клонировать!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Обычный trait для возможности явно дублировать объект.
///
/// Отличается от [`Copy`] тем, что [`Copy`] является неявным и чрезвычайно недорогим, в то время как `Clone` всегда явным и может быть или не быть дорогим.
/// Чтобы обеспечить эти характеристики, Rust не позволяет вам повторно реализовать [`Copy`], но вы можете повторно реализовать `Clone` и запустить произвольный код.
///
/// Поскольку `Clone` является более общим, чем [`Copy`], вы также можете автоматически сделать все, что [`Copy`], `Clone`.
///
/// ## Derivable
///
/// Этот trait можно использовать с `#[derive]`, если все поля-`Clone`.Реализация [`Clone`] `derive`d вызывает [`clone`] для каждого поля.
///
/// [`clone`]: Clone::clone
///
/// Для универсальной структуры `#[derive]` реализует `Clone` условно, добавляя привязанный `Clone` к универсальным параметрам.
///
/// ```
/// // `derive` реализует клонирование для чтения<T>когда T-клон.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Как я могу реализовать `Clone`?
///
/// Типы [`Copy`] должны иметь тривиальную реализацию `Clone`.Более формально:
/// если `T: Copy`, `x: T` и `y: &T`, то `let x = y.clone();` эквивалентен `let x = *y;`.
/// При реализации вручную следует соблюдать осторожность, чтобы поддерживать этот инвариант;однако небезопасный код не должен полагаться на него для обеспечения безопасности памяти.
///
/// Примером является универсальная структура, содержащая указатель на функцию.В этом случае реализация `Clone` не может быть `derive`d, но может быть реализована как:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Дополнительные разработчики
///
/// Помимо [implementors listed below][impls], `Clone` реализуют также следующие типы:
///
/// * Типы функциональных элементов (т. Е. Отдельные типы, определенные для каждой функции)
/// * Типы указателей функций (например, `fn() -> i32`)
/// * Типы массивов для всех размеров, если тип элемента также реализует `Clone` (например, `[i32; 123456]`)
/// * Типы кортежей, если каждый компонент также реализует `Clone` (например, `()`, `(i32, bool)`)
/// * Типы замыкания, если они не захватывают значение из среды или если все такие захваченные значения реализуют `Clone` сами.
///   Обратите внимание, что переменные, захваченные общей ссылкой, всегда реализуют `Clone` (даже если референт этого не делает), тогда как переменные, захваченные изменяемой ссылкой, никогда не реализуют `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Возвращает копию значения.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str реализует клон
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Выполняет копирование-присваивание с `source`.
    ///
    /// `a.clone_from(&b)` эквивалентен `a = b.clone()` по функциональности, но может быть переопределен для повторного использования ресурсов `a`, чтобы избежать ненужного выделения.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Макрос Derive, генерирующий имплантацию trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): эти структуры используются исключительно#[derive], чтобы утверждать, что каждый компонент типа реализует клонирование или копирование.
//
//
// Эти структуры никогда не должны появляться в пользовательском коде.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Реализации `Clone` для примитивных типов.
///
/// Реализации, которые не могут быть описаны в Rust, реализованы в `traits::SelectionContext::copy_clone_conditions()` в `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Общие ссылки могут быть клонированы, но изменяемые ссылки *не могут*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Общие ссылки могут быть клонированы, но изменяемые ссылки *не могут*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}