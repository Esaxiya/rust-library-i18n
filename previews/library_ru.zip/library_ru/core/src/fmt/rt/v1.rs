//! Это внутренний модуль, используемый ifmt!время выполнения.Эти структуры передаются в статические массивы для предварительной компиляции форматных строк.
//!
//! Эти определения похожи на их эквиваленты `ct`, но отличаются тем, что они могут быть размещены статически и немного оптимизированы для среды выполнения.
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Возможные выравнивания, которые могут быть запрошены как часть директивы форматирования.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Указание на то, что содержимое должно быть выровнено по левому краю.
    Left,
    /// Указание на то, что содержимое должно быть выровнено по правому краю.
    Right,
    /// Указание на то, что содержимое должно быть выровнено по центру.
    Center,
    /// Выравнивание не запрашивалось.
    Unknown,
}

/// Используется спецификаторами [width](https://doc.rust-lang.org/std/fmt/#width) и [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Задается буквальным числом, сохраняет значение
    Is(usize),
    /// Указанный с использованием синтаксисов `$` и `*`, сохраняет индекс в `args`.
    Param(usize),
    /// Не указан
    Implied,
}