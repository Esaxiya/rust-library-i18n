//! Определяет тип ошибки utf8.

use crate::fmt;

/// Ошибки, которые могут возникнуть при попытке интерпретировать последовательность [`u8`] как строку.
///
/// Таким образом, семейство функций и методов `from_utf8` для [`String`] и [`&str`] использует, например, эту ошибку.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Методы этого типа ошибки можно использовать для создания функциональности, аналогичной `String::from_utf8_lossy`, без выделения памяти кучи:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Возвращает индекс в данной строке, до которого был проверен действительный UTF-8.
    ///
    /// Это максимальный индекс, при котором `from_utf8(&input[..index])` вернет `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// use std::str;
    ///
    /// // некоторые недопустимые байты в vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 возвращает Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // второй байт здесь недействителен
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Предоставляет дополнительную информацию об ошибке:
    ///
    /// * `None`: конец ввода был достигнут неожиданно.
    ///   `self.valid_up_to()` составляет от 1 до 3 байтов от конца ввода.
    ///   Если поток байтов (например, файл или сетевой сокет) декодируется постепенно, это может быть действительный `char`, чья последовательность байтов UTF-8 охватывает несколько фрагментов.
    ///
    ///
    /// * `Some(len)`: обнаружен неожиданный байт.
    ///   Предоставленная длина-это длина недопустимой последовательности байтов, которая начинается с индекса, заданного `valid_up_to()`.
    ///   Декодирование должно возобновиться после этой последовательности (после вставки [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) в случае декодирования с потерями.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Ошибка возвращается при сбое синтаксического анализа `bool` с использованием [`from_str`]
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}