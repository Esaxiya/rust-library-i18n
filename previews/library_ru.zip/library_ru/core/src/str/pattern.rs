//! API строкового шаблона.
//!
//! API шаблонов предоставляет общий механизм для использования различных типов шаблонов при поиске в строке.
//!
//! Для получения дополнительной информации см. traits [`Pattern`], [`Searcher`], [`ReverseSearcher`] и [`DoubleEndedSearcher`].
//!
//! Хотя этот API нестабилен, он предоставляется через стабильные API на типе [`str`].
//!
//! # Examples
//!
//! [`Pattern`] - это [implemented][pattern-impls] в стабильном API для [`&str`][`str`], [`char`], фрагментов [`char`], а также функций и замыканий, реализующих `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // образец символа
//! assert_eq!(s.find('n'), Some(2));
//! // кусочек рисунка символов
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // образец закрытия
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Строчный узор.
///
/// `Pattern<'a>` указывает, что тип реализации может использоваться как строковый шаблон для поиска в [`&'a str`][str].
///
/// Например, и `'a'`, и `"aa"`-это шаблоны, которые будут соответствовать по индексу `1` в строке `"baaaab"`.
///
/// Сам trait действует как построитель для связанного типа [`Searcher`], который выполняет фактическую работу по поиску вхождений шаблона в строку.
///
///
/// В зависимости от типа шаблона поведение таких методов, как [`str::find`] и [`str::contains`], может меняться.
/// В таблице ниже описаны некоторые из этих вариантов поведения.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Связанный поисковик для этого шаблона
    type Searcher: Searcher<'a>;

    /// Создает связанный поисковик из `self` и `haystack` для поиска.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Проверяет, совпадает ли узор где-нибудь в стоге сена
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Проверяет соответствие рисунка передней части стога сена
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Проверяет соответствие рисунка на задней части стога сена
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Удаляет узор спереди стога сена, если он совпадает.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // БЕЗОПАСНОСТЬ: известно, что `Searcher` возвращает допустимые индексы.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Удаляет узор с обратной стороны стога сена, если он совпадает.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // БЕЗОПАСНОСТЬ: известно, что `Searcher` возвращает допустимые индексы.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Результат вызова [`Searcher::next()`] или [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Указывает, что совпадение с шаблоном было найдено в `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Указывает, что `haystack[a..b]` был отклонен как возможное совпадение с шаблоном.
    ///
    /// Обратите внимание, что между двумя `Match` может быть более одного `Reject`, нет необходимости объединять их в один.
    ///
    ///
    Reject(usize, usize),
    /// Указывает, что был посещен каждый байт стога сена, завершая итерацию.
    ///
    Done,
}

/// Поисковик строкового шаблона.
///
/// Этот trait предоставляет методы для поиска неперекрывающихся совпадений шаблона, начиная с переднего (left) строки.
///
/// Он будет реализован соответствующими типами `Searcher` [`Pattern`] trait.
///
/// trait помечен как небезопасный, потому что индексы, возвращаемые методами [`next()`][Searcher::next], должны лежать на допустимых границах utf8 в стоге сена.
/// Это позволяет потребителям этого trait разрезать стог сена без дополнительных проверок во время выполнения.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter для базовой строки для поиска в
    ///
    /// Всегда будет возвращать один и тот же [`&str`][str].
    fn haystack(&self) -> &'a str;

    /// Выполняет следующий шаг поиска, начиная с лицевой стороны.
    ///
    /// - Возвращает [`Match(a, b)`][SearchStep::Match], если `haystack[a..b]` соответствует шаблону.
    /// - Возвращает [`Reject(a, b)`][SearchStep::Reject], если `haystack[a..b]` не может соответствовать шаблону даже частично.
    /// - Возвращает [`Done`][SearchStep::Done], если был посещен каждый байт стога сена.
    ///
    /// Поток значений [`Match`][SearchStep::Match] и [`Reject`][SearchStep::Reject] до [`Done`][SearchStep::Done] будет содержать диапазоны индексов, которые являются смежными, не перекрываются, покрывают весь стог сена и лежат на границах utf8.
    ///
    ///
    /// Результат [`Match`][SearchStep::Match] должен содержать весь согласованный шаблон, однако результаты [`Reject`][SearchStep::Reject] могут быть разбиты на произвольное количество смежных фрагментов.Оба диапазона могут иметь нулевую длину.
    ///
    /// Например, шаблон `"aaa"` и стог сена `"cbaaaaab"` могут создавать поток
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Находит следующий результат [`Match`][SearchStep::Match].См. [`next()`][Searcher::next].
    ///
    /// В отличие от [`next()`][Searcher::next], нет гарантии, что возвращаемые диапазоны этого и [`next_reject`][Searcher::next_reject] будут перекрываться.
    /// Это вернет `(start_match, end_match)`, где start_match-это индекс начала совпадения, а end_match-это индекс после окончания совпадения.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Находит следующий результат [`Reject`][SearchStep::Reject].См. [`next()`][Searcher::next] и [`next_match()`][Searcher::next_match].
    ///
    /// В отличие от [`next()`][Searcher::next], нет гарантии, что возвращаемые диапазоны этого и [`next_match`][Searcher::next_match] будут перекрываться.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Обратный поиск образца строки.
///
/// Этот trait предоставляет методы для поиска неперекрывающихся совпадений шаблона, начиная с конца (right) строки.
///
/// Он будет реализован соответствующими типами [`Searcher`] [`Pattern`] trait, если шаблон поддерживает поиск его сзади.
///
///
/// Диапазоны индексов, возвращаемые этим trait, не обязательно должны точно соответствовать диапазонам прямого поиска в обратном направлении.
///
/// По причине того, что этот trait помечен как небезопасный, см. Их родительский trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Выполняет следующий шаг поиска, начиная с обратной стороны.
    ///
    /// - Возвращает [`Match(a, b)`][SearchStep::Match], если `haystack[a..b]` соответствует шаблону.
    /// - Возвращает [`Reject(a, b)`][SearchStep::Reject], если `haystack[a..b]` не может соответствовать шаблону даже частично.
    /// - Возвращает [`Done`][SearchStep::Done], если был посещен каждый байт стога сена.
    ///
    /// Поток значений [`Match`][SearchStep::Match] и [`Reject`][SearchStep::Reject] до [`Done`][SearchStep::Done] будет содержать диапазоны индексов, которые являются смежными, не перекрываются, покрывают весь стог сена и лежат на границах utf8.
    ///
    ///
    /// Результат [`Match`][SearchStep::Match] должен содержать весь согласованный шаблон, однако результаты [`Reject`][SearchStep::Reject] могут быть разбиты на произвольное количество смежных фрагментов.Оба диапазона могут иметь нулевую длину.
    ///
    /// Например, шаблон `"aaa"` и стог сена `"cbaaaaab"` могут создавать поток `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Находит следующий результат [`Match`][SearchStep::Match].
    /// См. [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Находит следующий результат [`Reject`][SearchStep::Reject].
    /// См. [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Маркер trait для обозначения того, что [`ReverseSearcher`] можно использовать для реализации [`DoubleEndedIterator`].
///
/// Для этого при внедрении [`Searcher`] и [`ReverseSearcher`] необходимо соблюдать следующие условия:
///
/// - Все результаты `next()` должны быть идентичны результатам `next_back()` в обратном порядке.
/// - `next()` и `next_back()` должны вести себя как два конца диапазона значений, то есть они не могут "walk past each other".
///
/// # Examples
///
/// `char::Searcher` - это `DoubleEndedSearcher`, потому что для поиска [`char`] нужно смотреть только по одному, что ведет себя одинаково с обоих концов.
///
/// `(&str)::Searcher` не является `DoubleEndedSearcher`, потому что шаблон `"aa"` в стоге сена `"aaa"` соответствует либо `"[aa]a"`, либо `"a[aa]"`, в зависимости от того, с какой стороны выполняется поиск.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl для char
/////////////////////////////////////////////////////////////////////////////

/// Ассоциированный тип для `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // инвариант безопасности: `finger`/`finger_back` должен быть допустимым байтовым индексом utf8 для `haystack`. Этот инвариант может быть нарушен *в пределах* next_match и next_match_back, однако они должны выходить пальцами на допустимые границы кодовой точки.
    //
    //
    /// `finger` это текущий байтовый индекс прямого поиска.
    /// Представьте, что он существует перед байтом по его индексу, т. Е.
    /// `haystack[finger]` это первый байт среза, который мы должны проверить во время прямого поиска
    ///
    finger: usize,
    /// `finger_back` - текущий байтовый индекс обратного поиска.
    /// Представьте, что он существует после байта по его индексу, т. Е.
    /// haystack [finger_back, 1]-последний байт среза, который мы должны проверить во время прямого поиска (и, следовательно, первый байт, который нужно проверить при вызове next_back()).
    ///
    finger_back: usize,
    /// Разыскиваемый персонаж
    needle: char,

    // инвариант безопасности: `utf8_size` должно быть меньше 5
    /// Количество байтов, которое занимает `needle` при кодировании в utf8.
    utf8_size: usize,
    /// Копия `needle` в кодировке utf8
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // БЕЗОПАСНОСТЬ: 1-4 гарантии сохранности `get_unchecked`
        // 1. `self.finger` и `self.finger_back` хранятся на границах Unicode (это инвариантно)
        // 2. `self.finger >= 0` так как он начинается с 0 и только увеличивается
        // 3. `self.finger < self.finger_back` потому что иначе char `iter` вернет `SearchStep::Done`
        // 4.
        // `self.finger` приходит до конца стога сена, потому что `self.finger_back` начинается в конце и только уменьшается
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // добавить байтовое смещение текущего символа без перекодирования как utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // получить стог сена после последнего найденного символа
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // последний байт закодированной стрелки utf8 БЕЗОПАСНОСТЬ: у нас есть инвариант, что `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Новый палец-это индекс найденного байта плюс один, поскольку мы запомнили последний байт символа.
                //
                // Обратите внимание, что это не всегда дает нам указание на границу UTF8.
                // Если мы *не* нашли наш символ, возможно, мы проиндексировали не последний байт 3-байтового или 4-байтового символа.
                // Мы не можем просто перейти к следующему действительному начальному байту, потому что такой символ, как ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81`, заставит нас всегда находить второй байт при поиске третьего.
                //
                //
                // Однако это совершенно нормально.
                // Хотя у нас есть инвариант, что self.finger находится на границе UTF8, этот инвариант не используется в этом методе (он используется в CharSearcher::next()).
                //
                // Мы выходим из этого метода только тогда, когда дойдем до конца строки или если что-то найдем.Когда мы что-то находим, `finger` будет установлен на границу UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // ничего не нашел, выход
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // пусть next_reject использует реализацию по умолчанию из Searcher trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // БЕЗОПАСНОСТЬ: см. Комментарий для next() выше
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // вычесть байтовое смещение текущего символа без перекодирования в utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // поднять стог сена до последнего искомого символа, но не включая его
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // последний байт закодированной стрелки utf8 БЕЗОПАСНОСТЬ: у нас есть инвариант, что `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // мы искали фрагмент, который был смещен на self.finger, добавляем self.finger, чтобы восстановить исходный индекс
                //
                let index = self.finger + index;
                // memrchr вернет индекс байта, который мы хотим найти.
                // В случае символа ASCII это действительно то, чем мы хотели бы видеть наш новый палец ("after"-символ, найденный в парадигме обратной итерации).
                //
                // Для многобайтовых символов нам нужно пропустить на количество байтов больше, чем в ASCII.
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // переместите палец до найденного символа (т. е. до его начального индекса)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Мы не можем использовать здесь finger_back=index, size + 1.
                // Если мы нашли последний символ другого размера (или средний байт другого символа), нам нужно поднять finger_back до `index`.
                // Это аналогичным образом дает возможность `finger_back` больше не находиться на границе, но это нормально, поскольку мы выходим из этой функции только на границе или когда стог сена был полностью обыскан.
                //
                //
                // В отличие от next_match, здесь нет проблемы с повторением байтов в utf-8, потому что мы ищем последний байт, и мы можем найти только последний байт при поиске в обратном направлении.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // ничего не нашел, выход
                return None;
            }
        }
    }

    // пусть next_reject_back использует реализацию по умолчанию из Searcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Ищет символы, которые равны заданному [`char`].
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Impl для оболочки MultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Сравните длины внутреннего итератора байтового среза, чтобы найти длину текущего символа
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Сравните длины внутреннего итератора байтового среза, чтобы найти длину текущего символа
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl для&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Изменить/Удалить из-за двусмысленности.

/// Ассоциированный тип для `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Ищет символы, которые равны любому из [`char`] в срезе.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl для F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Ассоциированный тип для `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Ищет [`char`], которые соответствуют заданному предикату.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl для&&str
/////////////////////////////////////////////////////////////////////////////

/// Делегаты на `&str` impl.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl для &str
/////////////////////////////////////////////////////////////////////////////

/// Поиск подстроки без выделения памяти.
///
/// Будет обрабатывать шаблон `""` как возвращающий пустые совпадения на каждой границе символа.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Проверяет соответствие рисунка передней части стога сена.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Удаляет узор спереди стога сена, если он совпадает.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // БЕЗОПАСНОСТЬ: существование префикса было подтверждено.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Проверяет, совпадает ли узор на задней части стога сена.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Удаляет узор с обратной стороны стога сена, если он совпадает.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // БЕЗОПАСНОСТЬ: суффикс только что подтвержден на существование.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Двусторонний поиск подстроки
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Ассоциированный тип для `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // пустая игла отклоняет каждый символ и соответствует каждой пустой строке между ними
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher выдает допустимые индексы *Match*, которые разделяются на границах символов, если они правильно сопоставлены и что стог сена и игла действительны. UTF-8 *Отклонения* из алгоритма могут попадать на любые индексы, но мы пройдем их вручную до границы следующего символа, так что они utf-8 безопасны.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // перейти к следующей границе символа
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // выпишите кейсы `true` и `false`, чтобы компилятор выделил эти два случая по отдельности.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // перейти к следующей границе символа
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // выпишите `true` и `false`, например `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Внутреннее состояние алгоритма двустороннего поиска подстроки.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// критический индекс факторизации
    crit_pos: usize,
    /// критический индекс факторизации для перевернутой иглы
    crit_pos_back: usize,
    period: usize,
    /// `byteset` является расширением (не является частью двустороннего алгоритма);
    /// это 64-битный "fingerprint", где каждый установленный бит `j` соответствует (byte&63)==j, присутствующему в игле.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// индекс в иглу, перед которой мы уже сопоставили
    memory: usize,
    /// индекс в иглу, после чего мы уже сопоставили
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Особенно удобочитаемое объяснение того, что здесь происходит, можно найти в книге Крочемора и Риттера "Text Algorithms", глава 13.
        // В частности, смотрите код для "Algorithm CP" на стр.
        // 323.
        //
        // Что происходит, так это то, что у нас есть критическая факторизация (u, v) стрелки, и мы хотим определить, является ли u суффиксом&v [.. period].
        // Если это так, мы используем "Algorithm CP1".
        // В противном случае мы используем "Algorithm CP2", который оптимизирован для случаев, когда период иглы большой.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // случай короткого периода-период является точным вычислить отдельную критическую факторизацию для перевернутой стрелки x=u 'v', где | v '|<period(x).
            //
            // Это ускоряется уже известным периодом.
            // Обратите внимание, что такой случай, как x= "acba", может быть разложен точно вперед (crit_pos=1, period=3), при этом факторизован с приблизительным периодом в обратном порядке (crit_pos=2, period=2).
            // Мы используем данную обратную факторизацию, но сохраняем точный период.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // case long period-у нас есть приближение к фактическому периоду, и мы не используем запоминание.
            //
            //
            // Приблизительно период по нижней границе max(|u|, |v|) + 1.
            // Критическая факторизация эффективна как для прямого, так и для обратного поиска.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Фиктивное значение, указывающее на то, что период длинный.
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Одна из основных идей двусторонней игры состоит в том, что мы делим иглу на две половины (u, v) и начинаем пытаться найти v в стоге сена, просматривая слева направо.
    // Если v совпадает, мы пытаемся сопоставить u, просматривая справа налево.
    // Насколько далеко мы можем прыгнуть при обнаружении несоответствия, все основано на том факте, что (u, v) является критической факторизацией для иглы.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` использует `self.position` в качестве курсора
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Убедитесь, что у нас есть место для поиска в позиции + Need_last не может переполниться, если мы предполагаем, что срезы ограничены диапазоном isize.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Быстро пропускать большими частями, не связанными с нашей подстрокой
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Посмотрите, совпадает ли правая часть иглы
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Посмотрите, совпадает ли левая часть иглы
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Мы нашли совпадение!
            let match_pos = self.position;

            // Note: добавьте self.period вместо needle.len(), чтобы совпадения совпадали
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // установить на needle.len(), self.period для перекрывающихся совпадений
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Следует идеям `next()`.
    //
    // Определения симметричны, с period(x) = period(reverse(x)) и local_period(u, v) = local_period(reverse(v), reverse(u)), поэтому, если (u, v) является критической факторизацией, то (reverse(v) тоже, reverse(u)).
    //
    //
    // Для обратного случая мы вычислили критическую факторизацию x=u 'v' (поле `crit_pos_back`).Нам нужно | u |<period(x) для прямого случая и, следовательно, | v '|<period(x) для реверса.
    //
    // Чтобы искать в стоге сена в обратном направлении, мы ищем вперед через перевернутый стог с перевернутой иглой, сопоставляя сначала u ', а затем v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` использует `self.end` в качестве курсора, поэтому `next()` и `next_back()` независимы.
        //
        let old_end = self.end;
        'search: loop {
            // Убедитесь, что у нас есть место для поиска, в конце концов, needle.len() будет оборачиваться, когда места больше нет, но из-за ограничений длины среза он никогда не сможет полностью вернуться в длину стога сена.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Быстро пропускать большими частями, не связанными с нашей подстрокой
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Посмотрите, совпадает ли левая часть иглы
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Посмотрите, совпадает ли правая часть иглы
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Мы нашли совпадение!
            let match_pos = self.end - needle.len();
            // Note: sub self.period вместо needle.len(), чтобы совпадения совпадали
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Вычислите максимальный суффикс `arr`.
    //
    // Максимальный суффикс-это возможная критическая факторизация (u, v) `arr`.
    //
    // Возвращает (`i`, `p`), где `i`-начальный индекс v, а `p`-период v.
    //
    // `order_greater` определяет, какой лексический порядок-`<` или `>`.
    // Оба заказа должны быть вычислены-заказ с самым большим `i` дает критическую факторизацию.
    //
    //
    // Для случаев с длительным периодом результирующий период неточный (слишком короткий).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Соответствует i в статье
        let mut right = 1; // Соответствует j в статье
        let mut offset = 0; // Соответствует k в статье, но начиная с 0
        // для соответствия индексированию на основе 0.
        let mut period = 1; // Соответствует p в статье

        while let Some(&a) = arr.get(right + offset) {
            // `left` будет в зоне, когда будет `right`.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Суффикс меньше, точка пока целиком.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Продвижение через повторение текущего периода.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Суффикс больше, начать заново с текущего местоположения.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Вычислите максимальный суффикс реверса `arr`.
    //
    // Максимальный суффикс-это возможная критическая факторизация (u ', v') `arr`.
    //
    // Возвращает `i`, где `i`-начальный индекс v 'сзади;
    // возвращается сразу после достижения периода `known_period`.
    //
    // `order_greater` определяет, какой лексический порядок-`<` или `>`.
    // Оба заказа должны быть вычислены-заказ с самым большим `i` дает критическую факторизацию.
    //
    //
    // Для случаев с длительным периодом результирующий период неточный (слишком короткий).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Соответствует i в статье
        let mut right = 1; // Соответствует j в статье
        let mut offset = 0; // Соответствует k в статье, но начиная с 0
        // для соответствия индексированию на основе 0.
        let mut period = 1; // Соответствует p в статье
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Суффикс меньше, точка пока целиком.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Продвижение через повторение текущего периода.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Суффикс больше, начать заново с текущего местоположения.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy позволяет алгоритму либо пропускать несоответствия как можно быстрее, либо работать в режиме, в котором он относительно быстро генерирует отклонения.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Переходите к нужным интервалам как можно быстрее
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Регулярно выдавать бракованные
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}