use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Обертка вокруг необработанного ненулевого `*mut T`, который указывает, что владелец этой оболочки владеет референтом.
/// Полезно для создания абстракций, таких как `Box<T>`, `Vec<T>`, `String` и `HashMap<K, V>`.
///
/// В отличие от `*mut T`, `Unique<T>` ведет себя как "as if", будучи экземпляром `T`.
/// Он реализует `Send`/`Sync`, если `T` равен `Send`/`Sync`.
/// Это также подразумевает надежные гарантии псевдонима, которые может ожидать экземпляр `T`:
/// референт указателя не должен изменяться без уникального пути к его уникальному объекту.
///
/// Если вы не уверены, правильно ли использовать `Unique` для ваших целей, подумайте об использовании `NonNull`, который имеет более слабую семантику.
///
///
/// В отличие от `*mut T`, указатель всегда должен быть ненулевым, даже если указатель никогда не разыменовывается.
/// Это сделано для того, чтобы перечисления могли использовать это запрещенное значение в качестве дискриминанта-`Option<Unique<T>>` имеет тот же размер, что и `Unique<T>`.
/// Однако указатель может по-прежнему болтаться, если он не разыменован.
///
/// В отличие от `*mut T`, `Unique<T>` ковариантен над `T`.
/// Это всегда должно быть правильным для любого типа, который соответствует требованиям Unique по псевдониму.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: этот маркер не влияет на дисперсию, но необходим
    // для dropck, чтобы понять, что мы логически владеем `T`.
    //
    // Подробнее см .:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` указатели-это `Send`, если `T`-`Send`, потому что данные, на которые они ссылаются, не являются элиализованными.
/// Обратите внимание, что этот инвариант псевдонима не поддерживается системой типов;абстракция, использующая `Unique`, должна обеспечить это.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` указатели-это `Sync`, если `T`-`Sync`, потому что данные, на которые они ссылаются, не являются элиализованными.
/// Обратите внимание, что этот инвариант псевдонима не поддерживается системой типов;абстракция, использующая `Unique`, должна обеспечить это.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Создает новый `Unique`, который болтается, но хорошо выровнен.
    ///
    /// Это полезно для инициализации типов, которые лениво распределяются, как это делает `Vec::new`.
    ///
    /// Обратите внимание, что значение указателя потенциально может представлять действительный указатель на `T`, что означает, что его нельзя использовать в качестве контрольного значения "not yet initialized".
    /// Типы, которые распределяются лениво, должны отслеживать инициализацию другими способами.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // БЕЗОПАСНОСТЬ: mem::align_of() возвращает действительный ненулевой указатель.В
        // Таким образом, соблюдаются условия для вызова new_unchecked().
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Создает новый `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` не должно быть нулевым.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // БЕЗОПАСНОСТЬ: вызывающий должен гарантировать, что `ptr` не равно нулю.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Создает новый `Unique`, если `ptr` не равно нулю.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // БЕЗОПАСНОСТЬ: указатель уже проверен и не является нулевым.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Получает базовый указатель `*mut`.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Разыменовывает контент.
    ///
    /// Результирующее время жизни привязано к self, поэтому он ведет себя "as if", это был фактически заимствованный экземпляр T.
    /// Если требуется более длительный срок службы (unbound), используйте `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // БЕЗОПАСНОСТЬ: вызывающий абонент должен гарантировать, что `self` соответствует всем
        // требования к ссылке.
        unsafe { &*self.as_ptr() }
    }

    /// Взаимно разыменовывает контент.
    ///
    /// Результирующее время жизни привязано к self, поэтому он ведет себя "as if", это был фактически заимствованный экземпляр T.
    /// Если требуется более длительный срок службы (unbound), используйте `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // БЕЗОПАСНОСТЬ: вызывающий абонент должен гарантировать, что `self` соответствует всем
        // требования для изменяемой ссылки.
        unsafe { &mut *self.as_ptr() }
    }

    /// Приводится к указателю другого типа.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // БЕЗОПАСНОСТЬ: Unique::new_unchecked() создает новые уникальные вещи и потребности
        // данный указатель не должен быть нулевым.
        // Поскольку мы передаем self как указатель, он не может быть нулевым.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // БЕЗОПАСНОСТЬ: изменяемая ссылка не может быть нулевой
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}