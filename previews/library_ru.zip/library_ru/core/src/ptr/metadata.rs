#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Предоставляет тип метаданных указателя любого указанного типа.
///
/// # Метаданные указателя
///
/// Типы необработанных указателей и ссылочные типы в Rust можно рассматривать как состоящие из двух частей:
/// указатель данных, который содержит адрес в памяти значения и некоторые метаданные.
///
/// Для типов со статическим размером (которые реализуют `Sized` traits), а также для типов `extern`, указатели называются «тонкими»: метаданные имеют нулевой размер, а их тип-`()`.
///
///
/// Указатели на [dynamically-sized types][dst] называются «широкими» или «толстыми», они имеют метаданные ненулевого размера:
///
/// * Для структур, последнее поле которых является DST, метаданные-это метаданные для последнего поля.
/// * Для типа `str` метаданные-это длина в байтах как `usize`.
/// * Для таких типов срезов, как `[T]`, метаданные-это длина в элементах как `usize`.
/// * Для объектов trait, таких как `dyn SomeTrait`, метаданные-[`DynMetadata<Self>`][DynMetadata] (например, `DynMetadata<dyn SomeTrait>`).
///
/// В future язык Rust может получить новые типы типов, которые имеют другие метаданные указателя.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # Модель `Pointee` trait
///
/// Смысл этого trait-связанный с ним тип `Metadata`, которым является `()`, `usize` или `DynMetadata<_>`, как описано выше.
/// Реализуется автоматически для каждого типа.
/// Можно предположить, что он реализован в общем контексте, даже без соответствующей границы.
///
/// # Usage
///
/// Необработанные указатели можно разложить на компоненты адреса данных и метаданных с помощью их метода [`to_raw_parts`].
///
/// В качестве альтернативы, только метаданные могут быть извлечены с помощью функции [`metadata`].
/// Ссылка может быть передана в [`metadata`] и неявно приведена.
///
/// Указатель (possibly-wide) можно собрать вместе из его адреса и метаданных с помощью [`from_raw_parts`] или [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Тип метаданных в указателях и ссылках на `Self`.
    #[lang = "metadata_type"]
    // NOTE: Сохранить trait bounds в `static_assert_expected_bounds_for_metadata`
    //
    // в `library/core/src/ptr/metadata.rs` синхронно с приведенными здесь:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Указатели на типы, реализующие этот псевдоним trait, «тонкие».
///
/// Сюда входят типы со статическим размером и типы `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: не стабилизировать это до того, как псевдонимы trait станут стабильными в языке?
pub trait Thin = Pointee<Metadata = ()>;

/// Извлеките компонент метаданных указателя.
///
/// Значения типа `*mut T`, `&T` или `&mut T` могут быть переданы непосредственно в эту функцию, поскольку они неявно приводят к `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // БЕЗОПАСНОСТЬ: доступ к значению из объединения `PtrRepr` безопасен, поскольку * const T
    // и PtrComponents<T>имеют одинаковые схемы памяти.
    // Только std может дать эту гарантию.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Формирует необработанный указатель (possibly-wide) из адреса данных и метаданных.
///
/// Эта функция безопасна, но возвращаемый указатель не обязательно безопасен для разыменования.
/// Для срезов см. Документацию [`slice::from_raw_parts`] о требованиях безопасности.
/// Для объектов trait метаданные должны поступать от указателя на тот же базовый расширенный тип.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // БЕЗОПАСНОСТЬ: доступ к значению из объединения `PtrRepr` безопасен, поскольку * const T
    // и PtrComponents<T>имеют одинаковые схемы памяти.
    // Только std может дать эту гарантию.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Выполняет те же функции, что и [`from_raw_parts`], за исключением того, что возвращается необработанный указатель `*mut`, в отличие от необработанного указателя `* const`.
///
///
/// См. Документацию [`from_raw_parts`] для более подробной информации.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // БЕЗОПАСНОСТЬ: доступ к значению из объединения `PtrRepr` безопасен, поскольку * const T
    // и PtrComponents<T>имеют одинаковые схемы памяти.
    // Только std может дать эту гарантию.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Чтобы избежать привязки к `T: Copy`, необходимо вручную имплантировать.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Чтобы избежать привязки к `T: Clone`, необходимо вручную выполнить имп.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Метаданные для типа объекта `Dyn = dyn SomeTrait` trait.
///
/// Это указатель на vtable (виртуальную таблицу вызовов), которая представляет всю необходимую информацию для управления конкретным типом, хранящимся внутри объекта trait.
/// В vtable, в частности, содержится:
///
/// * размер шрифта
/// * выравнивание типов
/// * указатель на тип `drop_in_place` impl (может быть нерабочим для простых-старых данных)
/// * указатели на все методы для реализации типа trait
///
/// Обратите внимание, что первые три являются особенными, потому что они необходимы для выделения, удаления и освобождения любого объекта trait.
///
/// Этой структуре можно присвоить имя с параметром типа, который не является объектом `dyn` trait (например, `DynMetadata<u64>`), но не для получения значимого значения этой структуры.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Общий префикс всех vtables.За ним следуют указатели на функции для методов trait.
///
/// Детали частной реализации `DynMetadata::size_of` и т. Д.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Возвращает размер типа, связанного с этой виртуальной таблицей.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Возвращает выравнивание типа, связанного с этой vtable.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Возвращает размер и выравнивание вместе как `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // БЕЗОПАСНОСТЬ: компилятор выдал эту vtable для конкретного типа Rust, который
        // как известно, имеет действующий макет.Обоснование такое же, как и в `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Чтобы избежать пределов `Dyn: $Trait`, необходимы ручные импы.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}