use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` но ненулевой и ковариантный.
///
/// Часто это правильный вариант при построении структур данных с использованием необработанных указателей, но, в конечном итоге, его использование более опасно из-за его дополнительных свойств.Если вы не уверены, следует ли вам использовать `NonNull<T>`, просто используйте `*mut T`!
///
/// В отличие от `*mut T`, указатель всегда должен быть ненулевым, даже если указатель никогда не разыменовывается.Это сделано для того, чтобы перечисления могли использовать это запрещенное значение в качестве дискриминанта-`Option<NonNull<T>>` имеет тот же размер, что и `* mut T`.
/// Однако указатель может по-прежнему болтаться, если он не разыменован.
///
/// В отличие от `*mut T`, `NonNull<T>` был выбран как ковариантный над `T`.Это позволяет использовать `NonNull<T>` при построении ковариантных типов, но вводит риск несостоятельности при использовании в типе, который на самом деле не должен быть ковариантным.
/// (Противоположный выбор был сделан для `*mut T`, хотя технически неисправность могла быть вызвана только вызовом небезопасных функций.)
///
/// Ковариация верна для большинства безопасных абстракций, таких как `Box`, `Rc`, `Arc`, `Vec` и `LinkedList`.Это так, потому что они предоставляют общедоступный API, который следует обычным изменяемым правилам общего XOR Rust.
///
/// Если ваш тип не может быть безопасно ковариантным, вы должны убедиться, что он содержит дополнительное поле для обеспечения инвариантности.Часто это поле будет типа [`PhantomData`], например `PhantomData<Cell<T>>` или `PhantomData<&'a mut T>`.
///
/// Обратите внимание, что `NonNull<T>` имеет экземпляр `From` для `&T`.Однако это не меняет того факта, что изменение с помощью (указателя, полученного из) общей ссылки является неопределенным поведением, если только изменение не происходит внутри [`UnsafeCell<T>`].То же самое касается создания изменяемой ссылки из общей ссылки.
///
/// При использовании этого экземпляра `From` без `UnsafeCell<T>` вы несете ответственность за то, чтобы `as_mut` никогда не вызывался, а `as_ptr` никогда не использовался для мутации.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` указатели не являются `Send`, потому что данные, на которые они ссылаются, могут иметь псевдоним.
// NB, в этом нет необходимости, но он должен предоставлять более точные сообщения об ошибках.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` указатели не являются `Sync`, потому что данные, на которые они ссылаются, могут иметь псевдоним.
// NB, в этом нет необходимости, но он должен предоставлять более точные сообщения об ошибках.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Создает новый `NonNull`, который болтается, но хорошо выровнен.
    ///
    /// Это полезно для инициализации типов, которые лениво распределяются, как это делает `Vec::new`.
    ///
    /// Обратите внимание, что значение указателя потенциально может представлять действительный указатель на `T`, что означает, что его нельзя использовать в качестве контрольного значения "not yet initialized".
    /// Типы, которые распределяются лениво, должны отслеживать инициализацию другими способами.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // БЕЗОПАСНОСТЬ: mem::align_of() возвращает ненулевое значение usize, которое затем передается
        // к a * mut T.
        // Следовательно, `ptr` не равен нулю, и условия для вызова new_unchecked() соблюдаются.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Возвращает общие ссылки на значение.В отличие от [`as_ref`], здесь не требуется инициализировать значение.
    ///
    /// Для изменяемого аналога см. [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// При вызове этого метода вы должны убедиться, что все следующее:
    ///
    /// * Указатель должен быть правильно выровнен.
    ///
    /// * Это должно быть "dereferencable" в смысле, определенном в [the module documentation].
    ///
    /// * Вы должны обеспечить соблюдение правил псевдонима Rust, поскольку возвращаемое время жизни `'a` выбирается произвольно и не обязательно отражает фактическое время жизни данных.
    ///
    ///   В частности, в течение этого времени жизни память, на которую указывает указатель, не должна изменяться (кроме `UnsafeCell`).
    ///
    /// Это применимо, даже если результат этого метода не используется!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // БЕЗОПАСНОСТЬ: вызывающий абонент должен гарантировать, что `self` соответствует всем
        // требования к ссылке.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Возвращает уникальную ссылку на значение.В отличие от [`as_mut`], здесь не требуется инициализировать значение.
    ///
    /// Для общего аналога см. [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// При вызове этого метода вы должны убедиться, что все следующее:
    ///
    /// * Указатель должен быть правильно выровнен.
    ///
    /// * Это должно быть "dereferencable" в смысле, определенном в [the module documentation].
    ///
    /// * Вы должны обеспечить соблюдение правил псевдонима Rust, поскольку возвращаемое время жизни `'a` выбирается произвольно и не обязательно отражает фактическое время жизни данных.
    ///
    ///   В частности, в течение этого времени жизни память, на которую указывает указатель, не должна получать доступ (чтение или запись) через какой-либо другой указатель.
    ///
    /// Это применимо, даже если результат этого метода не используется!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // БЕЗОПАСНОСТЬ: вызывающий абонент должен гарантировать, что `self` соответствует всем
        // требования к ссылке.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Создает новый `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` не должно быть нулевым.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // БЕЗОПАСНОСТЬ: вызывающий должен гарантировать, что `ptr` не равно нулю.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Создает новый `NonNull`, если `ptr` не равно нулю.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // БЕЗОПАСНОСТЬ: указатель уже проверен и не равен нулю
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Выполняет те же функции, что и [`std::ptr::from_raw_parts`], за исключением того, что возвращается указатель `NonNull`, в отличие от необработанного указателя `*const`.
    ///
    ///
    /// См. Документацию [`std::ptr::from_raw_parts`] для более подробной информации.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // БЕЗОПАСНОСТЬ: результат `ptr::from::raw_parts_mut` не равен нулю, потому что `data_address` имеет значение.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Разложите (возможно, широкий) указатель на компоненты адреса и метаданных.
    ///
    /// Указатель может быть позже реконструирован с помощью [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Получает базовый указатель `*mut`.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Возвращает общую ссылку на значение.Если значение может быть неинициализированным, следует использовать [`as_uninit_ref`].
    ///
    /// Для изменяемого аналога см. [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// При вызове этого метода вы должны убедиться, что все следующее:
    ///
    /// * Указатель должен быть правильно выровнен.
    ///
    /// * Это должно быть "dereferencable" в смысле, определенном в [the module documentation].
    ///
    /// * Указатель должен указывать на инициализированный экземпляр `T`.
    ///
    /// * Вы должны обеспечить соблюдение правил псевдонима Rust, поскольку возвращаемое время жизни `'a` выбирается произвольно и не обязательно отражает фактическое время жизни данных.
    ///
    ///   В частности, в течение этого времени жизни память, на которую указывает указатель, не должна изменяться (кроме `UnsafeCell`).
    ///
    /// Это применимо, даже если результат этого метода не используется!
    /// (Часть, касающаяся инициализации, еще не окончательно решена, но пока это не произойдет, единственный безопасный подход-убедиться, что они действительно инициализированы.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // БЕЗОПАСНОСТЬ: вызывающий абонент должен гарантировать, что `self` соответствует всем
        // требования к ссылке.
        unsafe { &*self.as_ptr() }
    }

    /// Возвращает уникальную ссылку на значение.Если значение может быть неинициализированным, следует использовать [`as_uninit_mut`].
    ///
    /// Для общего аналога см. [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// При вызове этого метода вы должны убедиться, что все следующее:
    ///
    /// * Указатель должен быть правильно выровнен.
    ///
    /// * Это должно быть "dereferencable" в смысле, определенном в [the module documentation].
    ///
    /// * Указатель должен указывать на инициализированный экземпляр `T`.
    ///
    /// * Вы должны обеспечить соблюдение правил псевдонима Rust, поскольку возвращаемое время жизни `'a` выбирается произвольно и не обязательно отражает фактическое время жизни данных.
    ///
    ///   В частности, в течение этого времени жизни память, на которую указывает указатель, не должна получать доступ (чтение или запись) через какой-либо другой указатель.
    ///
    /// Это применимо, даже если результат этого метода не используется!
    /// (Часть, касающаяся инициализации, еще не окончательно решена, но пока это не произойдет, единственный безопасный подход-убедиться, что они действительно инициализированы.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // БЕЗОПАСНОСТЬ: вызывающий абонент должен гарантировать, что `self` соответствует всем
        // требования для изменяемой ссылки.
        unsafe { &mut *self.as_ptr() }
    }

    /// Приводится к указателю другого типа.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // БЕЗОПАСНОСТЬ: `self`-это указатель `NonNull`, который обязательно не равен нулю.
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Создает ненулевой необработанный срез из тонкого указателя и длины.
    ///
    /// Аргумент `len`-это количество **элементов**, а не количество байтов.
    ///
    /// Эта функция безопасна, но разыменование возвращаемого значения небезопасно.
    /// См. Документацию [`slice::from_raw_parts`] для получения информации о требованиях к безопасности срезов.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // создать указатель среза при запуске с указателем на первый элемент
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Обратите внимание, что этот пример искусственно демонстрирует использование этого метода, но `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // БЕЗОПАСНОСТЬ: `data`-это указатель `NonNull`, который обязательно не равен нулю.
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Возвращает длину ненулевого необработанного фрагмента.
    ///
    /// Возвращаемое значение-это количество **элементов**, а не количество байтов.
    ///
    /// Эта функция безопасна, даже если ненулевой необработанный слайс не может быть разыменован на слайс, потому что указатель не имеет действительного адреса.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Возвращает ненулевой указатель на буфер среза.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // БЕЗОПАСНОСТЬ: Мы знаем, что `self` не равен нулю.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Возвращает необработанный указатель на буфер среза.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Возвращает общую ссылку на часть возможно неинициализированных значений.В отличие от [`as_ref`], здесь не требуется инициализировать значение.
    ///
    /// Для изменяемого аналога см. [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// При вызове этого метода вы должны убедиться, что все следующее:
    ///
    /// * Указатель должен быть [valid] для чтения для `ptr.len() * mem::size_of::<T>()` многих байтов, и он должен быть правильно выровнен.В частности, это означает:
    ///
    ///     * Весь диапазон памяти этого среза должен содержаться в одном выделенном объекте!
    ///       Срезы никогда не могут охватывать несколько выделенных объектов.
    ///
    ///     * Указатель должен быть выровнен даже для срезов нулевой длины.
    ///     Одна из причин этого заключается в том, что оптимизация компоновки перечисления может полагаться на ссылки (включая срезы любой длины), которые выровнены и не равны нулю, чтобы отличить их от других данных.
    ///
    ///     Вы можете получить указатель, который можно использовать как `data` для срезов нулевой длины, используя [`NonNull::dangling()`].
    ///
    /// * Общий размер `ptr.len() * mem::size_of::<T>()` среза не должен превышать `isize::MAX`.
    ///   См. Документацию по безопасности [`pointer::offset`].
    ///
    /// * Вы должны обеспечить соблюдение правил псевдонима Rust, поскольку возвращаемое время жизни `'a` выбирается произвольно и не обязательно отражает фактическое время жизни данных.
    ///   В частности, в течение этого времени жизни память, на которую указывает указатель, не должна изменяться (кроме `UnsafeCell`).
    ///
    /// Это применимо, даже если результат этого метода не используется!
    ///
    /// См. Также [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // БЕЗОПАСНОСТЬ: вызывающий абонент должен соблюдать договор безопасности для `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Возвращает уникальную ссылку на часть возможно неинициализированных значений.В отличие от [`as_mut`], здесь не требуется инициализировать значение.
    ///
    /// Для общего аналога см. [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// При вызове этого метода вы должны убедиться, что все следующее:
    ///
    /// * Указатель должен быть [valid] для чтения и записи для `ptr.len() * mem::size_of::<T>()` многих байтов, и он должен быть правильно выровнен.В частности, это означает:
    ///
    ///     * Весь диапазон памяти этого среза должен содержаться в одном выделенном объекте!
    ///       Срезы никогда не могут охватывать несколько выделенных объектов.
    ///
    ///     * Указатель должен быть выровнен даже для срезов нулевой длины.
    ///     Одна из причин этого заключается в том, что оптимизация компоновки перечисления может полагаться на ссылки (включая срезы любой длины), которые выровнены и не равны нулю, чтобы отличить их от других данных.
    ///
    ///     Вы можете получить указатель, который можно использовать как `data` для срезов нулевой длины, используя [`NonNull::dangling()`].
    ///
    /// * Общий размер `ptr.len() * mem::size_of::<T>()` среза не должен превышать `isize::MAX`.
    ///   См. Документацию по безопасности [`pointer::offset`].
    ///
    /// * Вы должны обеспечить соблюдение правил псевдонима Rust, поскольку возвращаемое время жизни `'a` выбирается произвольно и не обязательно отражает фактическое время жизни данных.
    ///   В частности, в течение этого времени жизни память, на которую указывает указатель, не должна получать доступ (чтение или запись) через какой-либо другой указатель.
    ///
    /// Это применимо, даже если результат этого метода не используется!
    ///
    /// См. Также [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Это безопасно, поскольку `memory` действителен для чтения и записи для многих байтов `memory.len()`.
    /// // Обратите внимание, что вызов `memory.as_mut()` здесь не разрешен, так как содержимое может быть неинициализированным.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // БЕЗОПАСНОСТЬ: вызывающий абонент должен соблюдать договор безопасности для `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Возвращает необработанный указатель на элемент или подсрез без проверки границ.
    ///
    /// Вызов этого метода с индексом за пределами границ или когда `self` не разыменовывается-это *[неопределенное поведение]*, даже если результирующий указатель не используется.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // БЕЗОПАСНОСТЬ: вызывающая сторона гарантирует, что `self` может быть разыменован, а `index` находится в пределах границ.
        // Как следствие, результирующий указатель не может быть NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // БЕЗОПАСНОСТЬ: Уникальный указатель не может быть нулевым, поэтому условия для
        // new_unchecked() уважают.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // БЕЗОПАСНОСТЬ: изменяемая ссылка не может быть нулевой.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // БЕЗОПАСНОСТЬ: ссылка не может быть нулевой, поэтому условия для
        // new_unchecked() уважают.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}