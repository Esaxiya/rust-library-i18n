//! Перегружаемые операторы.
//!
//! Реализация этих traits позволяет вам перегружать определенные операторы.
//!
//! Некоторые из этих traits импортируются программой prelude, поэтому они доступны в каждой программе Rust.Только операторы, поддерживаемые traits, могут быть перегружены.
//! Например, оператор сложения (`+`) может быть перегружен через [`Add`] trait, но поскольку оператор присваивания (`=`) не имеет поддержки trait, нет способа перегрузить его семантику.
//! Кроме того, этот модуль не предоставляет никакого механизма для создания новых операторов.
//! Если требуется перегрузка без признаков или пользовательские операторы, вам следует обратить внимание на макросы или плагины компилятора для расширения синтаксиса Rust.
//!
//! Реализации оператора traits не должны вызывать удивления в их соответствующих контекстах, учитывая их обычные значения и [operator precedence].
//! Например, при реализации [`Mul`] операция должна иметь некоторое сходство с умножением (и иметь ожидаемые свойства, такие как ассоциативность).
//!
//! Обратите внимание, что операторы `&&` и `||` осуществляют короткое замыкание, т. Е. Они оценивают свой второй операнд только в том случае, если он влияет на результат.Поскольку traits не поддерживает это поведение, `&&` и `||` не поддерживаются как перегружаемые операторы.
//!
//! Многие операторы принимают свои операнды по значению.В неуниверсальных контекстах, включающих встроенные типы, это обычно не проблема.
//! Однако использование этих операторов в универсальном коде требует некоторого внимания, если значения должны использоваться повторно, в отличие от того, чтобы позволять операторам использовать их.Один из вариантов-время от времени использовать [`clone`].
//! Другой вариант-полагаться на задействованные типы, предоставляя дополнительные реализации операторов для ссылок.
//! Например, для определяемого пользователем типа `T`, который должен поддерживать добавление, вероятно, неплохо было бы, чтобы и `T`, и `&T` реализовали traits [`Add<T>`][`Add`] и [`Add<&T>`][`Add`], чтобы можно было писать общий код без ненужного клонирования.
//!
//!
//! # Examples
//!
//! В этом примере создается структура `Point`, которая реализует [`Add`] и [`Sub`], а затем демонстрируется добавление и вычитание двух `Point`s.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! См. Документацию для каждого trait для примера реализации.
//!
//! [`Fn`], [`FnMut`] и [`FnOnce`] traits реализуются с помощью типов, которые можно вызывать как функции.Обратите внимание, что [`Fn`] принимает `&self`, [`FnMut`] принимает `&mut self`, а [`FnOnce`] принимает `self`.
//! Они соответствуют трем типам методов, которые могут быть вызваны в экземпляре: вызов по ссылке, вызов по изменяемой ссылке и вызов по значению.
//! Чаще всего эти traits используются в качестве границ для функций более высокого уровня, которые принимают функции или замыкания в качестве аргументов.
//!
//! Принимая [`Fn`] в качестве параметра:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Принимая [`FnMut`] в качестве параметра:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Принимая [`FnOnce`] в качестве параметра:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` потребляет свои захваченные переменные, поэтому его нельзя запускать более одного раза
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Попытка снова вызвать `func()` вызовет ошибку `use of moved value` для `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` больше не может быть вызвано в этот момент
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;