/// Используется для неизменяемых операций разыменования, таких как `*v`.
///
/// Помимо использования для явных операций разыменования с оператором (unary) `*` в неизменяемых контекстах, `Deref` также неявно используется компилятором во многих случаях.
/// Этот механизм получил название ['`Deref` coercion'][more].
/// В изменяемых контекстах используется [`DerefMut`].
///
/// Внедрение `Deref` для интеллектуальных указателей упрощает доступ к данным, стоящим за ними, поэтому они реализуют `Deref`.
/// С другой стороны, правила, касающиеся `Deref` и [`DerefMut`], были разработаны специально для поддержки интеллектуальных указателей.
/// По этой причине **`Deref` следует применять только для интеллектуальных указателей**, чтобы избежать путаницы.
///
/// По тем же причинам **этот trait никогда не должен выходить из строя**.Сбой во время разыменования может сильно сбивать с толку, когда `Deref` вызывается неявно.
///
/// # Подробнее о принуждении `Deref`
///
/// Если `T` реализует `Deref<Target = U>`, а `x` является значением типа `T`, то:
///
/// * В неизменяемых контекстах `*x` (где `T` не является ни ссылкой, ни необработанным указателем) эквивалентен `* Deref::deref(&x)`.
/// * Значения типа `&T` приводятся к значениям типа `&U`.
/// * `T` неявно реализует все методы (immutable) типа `U`.
///
/// Для получения более подробной информации посетите [the chapter in *The Rust Programming Language*][book], а также справочные разделы по [the dereference operator][ref-deref-op], [method resolution] и [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Структура с одним полем, доступная при разыменовании структуры.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Результирующий тип после разыменования.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Разыменяет значение.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Используется для изменяемых операций разыменования, как в `*v = 1;`.
///
/// Помимо использования для явных операций разыменования с оператором (unary) `*` в изменяемых контекстах, `DerefMut` также неявно используется компилятором во многих случаях.
/// Этот механизм получил название ['`Deref` coercion'][more].
/// В неизменяемых контекстах используется [`Deref`].
///
/// Внедрение `DerefMut` для интеллектуальных указателей делает удобным изменение данных, стоящих за ними, поэтому они реализуют `DerefMut`.
/// С другой стороны, правила, касающиеся [`Deref`] и `DerefMut`, были разработаны специально для поддержки интеллектуальных указателей.
/// Из-за этого **`DerefMut` следует реализовывать только для интеллектуальных указателей**, чтобы избежать путаницы.
///
/// По тем же причинам **этот trait никогда не должен выходить из строя**.Сбой во время разыменования может сильно сбивать с толку, когда `DerefMut` вызывается неявно.
///
/// # Подробнее о принуждении `Deref`
///
/// Если `T` реализует `DerefMut<Target = U>`, а `x` является значением типа `T`, то:
///
/// * В изменяемых контекстах `*x` (где `T` не является ни ссылкой, ни необработанным указателем) эквивалентен `* DerefMut::deref_mut(&mut x)`.
/// * Значения типа `&mut T` приводятся к значениям типа `&mut U`.
/// * `T` неявно реализует все методы (mutable) типа `U`.
///
/// Для получения более подробной информации посетите [the chapter in *The Rust Programming Language*][book], а также справочные разделы по [the dereference operator][ref-deref-op], [method resolution] и [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Структура с одним полем, которую можно изменить путем разыменования структуры.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Взаимно разыменовывает значение.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Указывает, что структуру можно использовать в качестве приемника метода без функции `arbitrary_self_types`.
///
/// Это реализуется такими типами указателей stdlib, как `Box<T>`, `Rc<T>`, `&T` и `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}