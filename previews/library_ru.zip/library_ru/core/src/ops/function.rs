/// Версия оператора вызова, которая принимает неизменяемый получатель.
///
/// Экземпляры `Fn` можно вызывать повторно без изменения состояния.
///
/// *Этот trait (`Fn`) не следует путать с [function pointers] (`fn`).*
///
/// `Fn` реализуется автоматически с помощью замыканий, которые принимают только неизменяемые ссылки на захваченные переменные или вообще ничего не захватывают, а также (safe) [function pointers] (с некоторыми оговорками, см. их документацию для более подробной информации).
///
/// Кроме того, для любого типа `F`, который реализует `Fn`, `&F` также реализует `Fn`.
///
/// Поскольку и [`FnMut`], и [`FnOnce`] являются надстройками `Fn`, любой экземпляр `Fn` может использоваться в качестве параметра, где ожидается [`FnMut`] или [`FnOnce`].
///
/// Используйте `Fn` в качестве привязки, если вы хотите принять параметр функционально-подобного типа и вам нужно вызывать его многократно и без изменения состояния (например, при одновременном вызове).
/// Если вам не нужны такие строгие требования, используйте [`FnMut`] или [`FnOnce`] в качестве границ.
///
/// См. [chapter on closures in *The Rust Programming Language*][book] для получения дополнительной информации по этой теме.
///
/// Также следует отметить специальный синтаксис для `Fn` traits (например,
/// `Fn(usize, bool) -> usize`).Те, кто интересуется техническими подробностями этого, могут обратиться к [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Вызов закрытия
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Использование параметра `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // так что regex может полагаться, что `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Выполняет операцию вызова.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Версия оператора вызова, которая принимает изменяемый получатель.
///
/// Экземпляры `FnMut` могут вызываться повторно и могут изменять состояние.
///
/// `FnMut` реализуется автоматически замыканиями, которые принимают изменяемые ссылки на захваченные переменные, а также все типы, реализующие [`Fn`], например, (safe) [function pointers] (поскольку `FnMut` является надстройкой [`Fn`]).
/// Кроме того, для любого типа `F`, который реализует `FnMut`, `&mut F` также реализует `FnMut`.
///
/// Так как [`FnOnce`] является надстройкой `FnMut`, любой экземпляр `FnMut` может использоваться там, где ожидается [`FnOnce`], а поскольку [`Fn`] является субстратом `FnMut`, любой экземпляр [`Fn`] может использоваться там, где ожидается `FnMut`.
///
/// Используйте `FnMut` как привязку, если вы хотите принять параметр функционально-подобного типа и вам нужно вызывать его несколько раз, позволяя ему изменять состояние.
/// Если вы не хотите, чтобы параметр изменял состояние, используйте [`Fn`] в качестве привязки;если вам не нужно вызывать его повторно, используйте [`FnOnce`].
///
/// См. [chapter on closures in *The Rust Programming Language*][book] для получения дополнительной информации по этой теме.
///
/// Также следует отметить специальный синтаксис для `Fn` traits (например,
/// `Fn(usize, bool) -> usize`).Те, кто интересуется техническими подробностями этого, могут обратиться к [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Вызов взаимно захватывающего закрытия
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Использование параметра `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // так что regex может полагаться, что `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Выполняет операцию вызова.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Версия оператора вызова, принимающая получатель по значению.
///
/// Экземпляры `FnOnce` могут быть вызваны, но не могут быть вызваны несколько раз.Из-за этого, если о типе известно только то, что он реализует `FnOnce`, его можно вызвать только один раз.
///
/// `FnOnce` реализуется автоматически замыканиями, которые могут использовать захваченные переменные, а также всеми типами, реализующими [`FnMut`], например, (safe) [function pointers] (поскольку `FnOnce` является надстройкой [`FnMut`]).
///
///
/// Поскольку и [`Fn`], и [`FnMut`] являются субтитрами `FnOnce`, любой экземпляр [`Fn`] или [`FnMut`] может использоваться там, где ожидается `FnOnce`.
///
/// Используйте `FnOnce` как привязку, если вы хотите принять параметр функционально-подобного типа и вам нужно вызвать его только один раз.
/// Если вам нужно повторно вызывать параметр, используйте [`FnMut`] в качестве привязки;если вам также нужно, чтобы он не изменял состояние, используйте [`Fn`].
///
/// См. [chapter on closures in *The Rust Programming Language*][book] для получения дополнительной информации по этой теме.
///
/// Также следует отметить специальный синтаксис для `Fn` traits (например,
/// `Fn(usize, bool) -> usize`).Те, кто интересуется техническими подробностями этого, могут обратиться к [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Использование параметра `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` потребляет свои захваченные переменные, поэтому его нельзя запускать более одного раза.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Попытка снова вызвать `func()` вызовет ошибку `use of moved value` для `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` больше не может быть вызвано в этот момент
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // так что regex может полагаться, что `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Тип, возвращаемый после использования оператора вызова.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Выполняет операцию вызова.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}