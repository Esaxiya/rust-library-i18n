/// trait для настройки поведения оператора `?`.
///
/// Тип, реализующий `Try`,-это тот, который имеет канонический способ рассматривать его с точки зрения дихотомии success/failure.
/// Этот trait позволяет как извлекать эти значения успеха или неудачи из существующего экземпляра, так и создавать новый экземпляр из значения успеха или неудачи.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Тип этого значения, рассматриваемого как успешное.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Тип этого значения, рассматриваемого как сбойный.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Применяет оператор "?".Возврат `Ok(t)` означает, что выполнение должно продолжаться в обычном режиме, а результатом `?` является значение `t`.
    /// Возврат `Err(e)` означает, что выполнение должно branch перейти к самому внутреннему охватывающему `catch` или вернуться из функции.
    ///
    /// Если возвращается результат `Err(e)`, значение `e` будет "wrapped" в типе возвращаемого значения охватывающей области (которая сама должна реализовывать `Try`).
    ///
    /// В частности, возвращается значение `X::from_error(From::from(e))`, где `X`-тип возвращаемого значения включающей функции.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Оберните значение ошибки, чтобы построить составной результат.
    /// Например, `Result::Err(x)` и `Result::from_error(x)` эквивалентны.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Оберните значение ОК, чтобы построить составной результат.
    /// Например, `Result::Ok(x)` и `Result::from_ok(x)` эквивалентны.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}