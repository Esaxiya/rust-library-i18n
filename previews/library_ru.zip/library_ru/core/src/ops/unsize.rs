use crate::marker::Unsize;

/// Trait, который указывает, что это указатель или оболочка для одного, где изменение размера может быть выполнено на указателе.
///
/// См. [DST coercion RFC][dst-coerce] и [the nomicon entry on coercion][nomicon-coerce] для получения более подробной информации.
///
/// Для типов встроенных указателей указатели на `T` будут приводить к указателям на `U`, если `T: Unsize<U>`, путем преобразования из тонкого указателя в толстый указатель.
///
/// Для настраиваемых типов приведение здесь работает путем принуждения `Foo<T>` к `Foo<U>` при наличии импликации `CoerceUnsized<Foo<U>> for Foo<T>`.
/// Такой impl может быть записан только в том случае, если `Foo<T>` имеет только одно поле нефантомных данных, включающее `T`.
/// Если тип этого поля-`Bar<T>`, должна существовать реализация `CoerceUnsized<Bar<U>> for Bar<T>`.
/// Принуждение будет работать путем принуждения поля `Bar<T>` к `Bar<U>` и заполнения остальных полей из `Foo<T>` для создания `Foo<U>`.
/// Это позволит эффективно перейти к полю указателя и принудить его.
///
/// Как правило, для интеллектуальных указателей вы реализуете `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` с дополнительным `?Sized`, привязанным к самому `T`.
/// Для типов оболочки, которые напрямую встраивают `T`, например `Cell<T>` и `RefCell<T>`, вы можете напрямую реализовать `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Это позволит работать приведениям типа `Cell<Box<T>>`.
///
/// [`Unsize`][unsize] используется для обозначения типов, которые могут быть приведены к DST, если они находятся за указателями.Это реализуется компилятором автоматически.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut Т-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut Т-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut Т-> * мут U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut Т-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Это используется для обеспечения безопасности объекта, чтобы проверить возможность отправки типа получателя метода.
///
/// Пример реализации trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut Т-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}