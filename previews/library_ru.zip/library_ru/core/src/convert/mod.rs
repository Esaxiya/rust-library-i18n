//! Traits для преобразований между типами.
//!
//! traits в этом модуле обеспечивает способ преобразования из одного типа в другой.
//! Каждый trait служит своей цели:
//!
//! - Внедрите [`AsRef`] trait для дешевого преобразования ссылки в ссылку
//! - Внедрите [`AsMut`] trait для дешевых преобразований из изменяемого в изменяемое.
//! - Внедрите [`From`] trait для преобразования ценности в ценность
//! - Реализуйте [`Into`] trait для использования преобразований значений в значения за пределами текущего crate.
//! - [`TryFrom`] и [`TryInto`] traits ведут себя как [`From`] и [`Into`], но должны быть реализованы, когда преобразование может завершиться ошибкой.
//!
//! traits в этом модуле часто используется как trait bounds для общих функций, таких, что поддерживаются аргументы нескольких типов.Примеры см. В документации к каждому trait.
//!
//! Как автор библиотеки, вы всегда должны предпочесть реализацию [`From<T>`][`From`] или [`TryFrom<T>`][`TryFrom`], а не [`Into<U>`][`Into`] или [`TryInto<U>`][`TryInto`], поскольку [`From`] и [`TryFrom`] обеспечивают большую гибкость и предлагают эквивалентные реализации [`Into`] или [`TryInto`] бесплатно благодаря полной реализации в стандартной библиотеке.
//! При нацеливании на версию до Rust 1.41 может потребоваться реализовать [`Into`] или [`TryInto`] напрямую при преобразовании в тип, отличный от текущего crate.
//!
//! # Общие реализации
//!
//! - [`AsRef`] и автоматическое разыменование [`AsMut`], если внутренний тип является ссылкой
//! - [`From`]`<U>для T` подразумевает [`Into`]`</u><T><U>для U`</u>
//! - [`TryFrom`]`<U>для T` подразумевает [`TryInto`]`</u><T><U>для U`</u>
//! - [`From`] и [`Into`] являются рефлексивными, что означает, что все типы могут сами `into` и `from`
//!
//! См. Каждый trait для примеров использования.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Функция идентичности.
///
/// Об этой функции важно отметить две вещи:
///
/// - Это не всегда эквивалентно закрытию, подобному `|x| x`, поскольку закрытие может принудить `x` к другому типу.
///
/// - Он перемещает вход `x`, переданный функции.
///
/// Хотя может показаться странным иметь функцию, которая просто возвращает ввод, есть несколько интересных применений.
///
///
/// # Examples
///
/// Использование `identity` для бездействия в последовательности других интересных функций:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Представим, что добавление единицы-интересная функция.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Использование `identity` в качестве базового случая "do nothing" в условном:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Делай еще что-нибудь интересное ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Использование `identity` для сохранения вариантов `Some` итератора `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Используется для дешевого преобразования ссылки в ссылку.
///
/// Этот trait похож на [`AsMut`], который используется для преобразования между изменяемыми ссылками.
/// Если вам нужно выполнить дорогостоящее преобразование, лучше реализовать [`From`] с типом `&T` или написать собственную функцию.
///
/// `AsRef` имеет ту же сигнатуру, что и [`Borrow`], но [`Borrow`] отличается в нескольких аспектах:
///
/// - В отличие от `AsRef`, [`Borrow`] имеет имплантацию для любого `T` и может использоваться для приема ссылки или значения.
/// - [`Borrow`] также требует, чтобы [`Hash`], [`Eq`] и [`Ord`] для заемной стоимости были эквивалентны таковым из собственной стоимости.
/// По этой причине, если вы хотите заимствовать только одно поле структуры, вы можете реализовать `AsRef`, но не [`Borrow`].
///
/// **Note: Этот trait не должен выходить из строя **.Если преобразование не удалось, используйте специальный метод, который возвращает [`Option<T>`] или [`Result<T, E>`].
///
/// # Общие реализации
///
/// - `AsRef` автоматическое разыменование, если внутренний тип является ссылкой или изменяемой ссылкой (например: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Используя trait bounds, мы можем принимать аргументы разных типов, если они могут быть преобразованы в указанный тип `T`.
///
/// Например: создавая универсальную функцию, которая принимает `AsRef<str>`, мы выражаем желание принять все ссылки, которые могут быть преобразованы в [`&str`], в качестве аргумента.
/// Поскольку и [`String`], и [`&str`] реализуют `AsRef<str>`, мы можем принять оба в качестве входных аргументов.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Выполняет преобразование.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Используется для дешевого преобразования изменяемых ссылок в изменяемые.
///
/// Этот trait похож на [`AsRef`], но используется для преобразования между изменяемыми ссылками.
/// Если вам нужно выполнить дорогостоящее преобразование, лучше реализовать [`From`] с типом `&mut T` или написать собственную функцию.
///
/// **Note: Этот trait не должен выходить из строя **.Если преобразование не удалось, используйте специальный метод, который возвращает [`Option<T>`] или [`Result<T, E>`].
///
/// # Общие реализации
///
/// - `AsMut` автоматическое разыменование, если внутренний тип является изменяемой ссылкой (например: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Используя `AsMut` как trait bound для общей функции, мы можем принять все изменяемые ссылки, которые могут быть преобразованы в тип `&mut T`.
/// Поскольку [`Box<T>`] реализует `AsMut<T>`, мы можем написать функцию `add_one`, которая принимает все аргументы, которые могут быть преобразованы в `&mut u64`.
/// Поскольку [`Box<T>`] реализует `AsMut<T>`, `add_one` также принимает аргументы типа `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Выполняет преобразование.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Преобразование значения в значение, которое потребляет входное значение.Противоположность [`From`].
///
/// Следует избегать реализации [`Into`] и вместо этого внедрять [`From`].
/// Внедрение [`From`] автоматически обеспечивает реализацию [`Into`] благодаря полной реализации в стандартной библиотеке.
///
/// При указании trait bounds для универсальной функции предпочтительнее использовать [`Into`], а не [`From`], чтобы также можно было использовать типы, реализующие только [`Into`].
///
/// **Note: Этот trait не должен выходить из строя **.Если преобразование не удалось, используйте [`TryInto`].
///
/// # Общие реализации
///
/// - [`From`]`<T>для U` подразумевает `Into<U> for T`
/// - [`Into`] рефлексивно, что означает, что `Into<T> for T` реализован
///
/// # Реализация [`Into`] для преобразований во внешние типы в старых версиях Rust
///
/// До Rust 1.41, если тип назначения не был частью текущего crate, вы не могли реализовать [`From`] напрямую.
/// Например, возьмите этот код:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Это не будет скомпилировано в более старых версиях языка, потому что правила сиротства Rust были немного более строгими.
/// Чтобы обойти это, вы можете напрямую реализовать [`Into`]:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Важно понимать, что [`Into`] не обеспечивает реализацию [`From`] (как [`From`] делает с [`Into`]).
/// Следовательно, вы всегда должны пытаться реализовать [`From`], а затем вернуться к [`Into`], если [`From`] не может быть реализован.
///
/// # Examples
///
/// [`String`] реализует [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Чтобы выразить, что мы хотим, чтобы универсальная функция принимала все аргументы, которые могут быть преобразованы в указанный тип `T`, мы можем использовать trait bound of [`Into`]`<T>`.
///
/// Например: функция `is_hello` принимает все аргументы, которые могут быть преобразованы в [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Выполняет преобразование.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Используется для преобразования значения в значение при использовании входного значения.Это аналог [`Into`].
///
/// Всегда следует предпочесть реализацию `From`, а не [`Into`], потому что реализация `From` автоматически обеспечивает реализацию [`Into`] благодаря полной реализации в стандартной библиотеке.
///
///
/// Реализуйте [`Into`] только при нацеливании на версию до Rust 1.41 и преобразовании в тип, отличный от текущего crate.
/// `From` не мог выполнять эти типы преобразований в более ранних версиях из-за правил сиротства Rust.
/// Подробнее см. [`Into`].
///
/// При указании trait bounds для общей функции предпочтительнее использовать [`Into`], а не `From`.
/// Таким образом, типы, которые напрямую реализуют [`Into`], также могут использоваться в качестве аргументов.
///
/// `From` также очень полезен при обработке ошибок.При построении функции, которая может дать сбой, тип возвращаемого значения обычно имеет вид `Result<T, E>`.
/// `From` trait упрощает обработку ошибок, позволяя функции возвращать один тип ошибки, который инкапсулирует несколько типов ошибок.См. Раздел "Examples" и [the book][book] для получения более подробной информации.
///
/// **Note: Этот trait не должен выходить из строя **.Если преобразование не удалось, используйте [`TryFrom`].
///
/// # Общие реализации
///
/// - `From<T> for U` следует [`Into`]`<U>для T`</u>
/// - `From` рефлексивно, что означает, что `From<T> for T` реализован
///
/// # Examples
///
/// [`String`] реализует `From<&str>`:
///
/// Явное преобразование `&str` в String выполняется следующим образом:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// При выполнении обработки ошибок часто бывает полезно реализовать `From` для вашего собственного типа ошибки.
/// Преобразуя базовые типы ошибок в наш собственный настраиваемый тип ошибки, который инкапсулирует базовый тип ошибки, мы можем вернуть один тип ошибки без потери информации об основной причине.
/// Оператор '?' автоматически преобразует базовый тип ошибки в наш настраиваемый тип ошибки, вызывая `Into<CliError>::into`, который автоматически предоставляется при реализации `From`.
/// Затем компилятор определяет, какую реализацию `Into` следует использовать.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Выполняет преобразование.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Попытка преобразования, которая потребляет `self`, что может быть дорогостоящим, а может и не стоить.
///
/// Авторы библиотеки обычно не должны напрямую реализовывать этот trait, но должны предпочесть реализацию [`TryFrom`] trait, которая предлагает большую гибкость и бесплатно предоставляет эквивалентную реализацию `TryInto` благодаря полной реализации в стандартной библиотеке.
/// Дополнительные сведения об этом см. В документации по [`Into`].
///
/// # Внедрение `TryInto`
///
/// Это имеет те же ограничения и рассуждения, что и реализация [`Into`], подробности см. Там.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Тип, возвращаемый в случае ошибки преобразования.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Выполняет преобразование.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Простое и безопасное преобразование типов, которое при некоторых обстоятельствах может не выполняться контролируемым образом.Это аналог [`TryInto`].
///
/// Это полезно, когда вы выполняете преобразование типа, которое может быть тривиально успешным, но также может потребовать особой обработки.
/// Например, невозможно преобразовать [`i64`] в [`i32`] с помощью [`From`] trait, потому что [`i64`] может содержать значение, которое [`i32`] не может представлять, и поэтому преобразование приведет к потере данных.
///
/// Это может быть обработано путем усечения [`i64`] до [`i32`] (по сути, с присвоением значения [`i64`] по модулю [`i32::MAX`]) или простым возвратом [`i32::MAX`], или каким-либо другим методом.
/// [`From`] trait предназначен для идеального преобразования, поэтому `TryFrom` trait информирует программиста, когда преобразование типа может быть неудачным, и позволяет им решать, как с этим справиться.
///
/// # Общие реализации
///
/// - `TryFrom<T> for U` подразумевает [`TryInto`]`<U>для T`</u>
/// - [`try_from`] является рефлексивным, что означает, что `TryFrom<T> for T` реализован и не может потерпеть неудачу-связанный тип `Error` для вызова `T::try_from()` для значения типа `T`-[`Infallible`].
/// Когда тип [`!`] стабилизирован, [`Infallible`] и [`!`] будут эквивалентны.
///
/// `TryFrom<T>` может быть реализовано следующим образом:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Как описано, [`i32`] реализует `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Беззвучно обрезает `big_number`, требует обнаружения и обработки усечения постфактум.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Возвращает ошибку, потому что `big_number` слишком велик для `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Возвращает `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Тип, возвращаемый в случае ошибки преобразования.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Выполняет преобразование.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// ОБЩИЕ ПОСЛЕДСТВИЯ
////////////////////////////////////////////////////////////////////////////////

// Как поднимается над&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Как поднимает над &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): замените приведенные выше импликации для&/&mut следующим более общим:
// // Как поднимается над Дерефом
// имп <D: ?Sized + Deref<Target: AsRef<U>>, U:? Размер> AsRef <U>для D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut поднимает над &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): замените приведенный выше вариант для &mut следующим более общим:
// // AsMut поднимается над DerefMut
// имп <D: ?Sized + Deref<Target: AsMut<U>>, U:? Размер> AsMut <U>для D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Из подразумевает В
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// From (и, следовательно, Into) рефлексивно
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Замечание по стабильности:** Этот импл еще не существует, но мы "reserving space", чтобы добавить его в future.
/// Подробнее см. [rust-lang/rust#64715][#64715].
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): вместо этого сделайте принципиальное исправление.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom подразумевает TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Безошибочные преобразования семантически эквивалентны ошибочным преобразованиям с необитаемым типом ошибки.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// БЕТОННЫЕ IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// ТИП БЕЗ ОШИБОК
////////////////////////////////////////////////////////////////////////////////

/// Тип ошибки для ошибок, которые никогда не могут произойти.
///
/// Поскольку это перечисление не имеет варианта, значение этого типа никогда не может существовать.
/// Это может быть полезно для общих API-интерфейсов, которые используют [`Result`] и параметризуют тип ошибки, чтобы указать, что результатом всегда будет [`Ok`].
///
/// Например, [`TryFrom`] trait (преобразование, возвращающее [`Result`]) имеет общую реализацию для всех типов, где существует обратная реализация [`Into`].
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future совместимость
///
/// Это перечисление имеет ту же роль, что и [the `!`“never”type][never], которая нестабильна в этой версии Rust.
/// Когда `!` стабилизируется, мы планируем сделать `Infallible` псевдонимом типа для него:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …И в конечном итоге отказаться от `Infallible`.
///
/// Однако есть один случай, когда синтаксис `!` может использоваться до того, как `!` будет стабилизирован как полноценный тип: в позиции типа возвращаемого значения функции.
/// В частности, возможны реализации для двух разных типов указателей на функции:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Поскольку `Infallible` является перечислением, этот код действителен.
/// Однако когда `Infallible` становится псевдонимом для Never type, два `impl 'начнут перекрываться и, следовательно, будут запрещены правилами согласованности trait языка.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}