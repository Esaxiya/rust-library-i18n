use crate::iter::{FusedIterator, TrustedLen};

/// Создает итератор, который лениво генерирует значение ровно один раз, вызывая предоставленное закрытие.
///
/// Это обычно используется для адаптации одного генератора значений к [`chain()`] других видов итераций.
/// Может быть, у вас есть итератор, который охватывает почти все, но вам нужен особый случай.
/// Возможно, у вас есть функция, которая работает с итераторами, но вам нужно обработать только одно значение.
///
/// В отличие от [`once()`], эта функция лениво генерирует значение по запросу.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Основное использование:
///
/// ```
/// use std::iter;
///
/// // один-самый одинокий номер
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // только один, это все, что мы получаем
/// assert_eq!(None, one.next());
/// ```
///
/// Связь с другим итератором.
/// Допустим, мы хотим перебрать каждый файл каталога `.foo`, а также файл конфигурации,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // нам нужно преобразовать из итератора DirEntry-s в итератор PathBufs, поэтому мы используем map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // теперь наш итератор только для нашего файла конфигурации
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // объедините два итератора вместе в один большой итератор
/// let files = dirs.chain(config);
///
/// // это даст нам все файлы в .foo, а также .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Итератор, который возвращает единственный элемент типа `A`, применяя предоставленное замыкание `F: FnOnce() -> A`.
///
///
/// Этот `struct` создается функцией [`once_with()`].
/// См. Его документацию для получения дополнительной информации.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}