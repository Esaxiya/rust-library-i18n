use crate::iter::{FusedIterator, TrustedLen};

/// Создает новый итератор, который бесконечно повторяет элементы типа `A`, применяя предоставленное замыкание, повторитель, `F: FnMut() -> A`.
///
/// Функция `repeat_with()` вызывает ретранслятор снова и снова.
///
/// Бесконечные итераторы, такие как `repeat_with()`, часто используются с адаптерами, такими как [`Iterator::take()`], чтобы сделать их конечными.
///
/// Если тип элемента итератора, который вам нужен, реализует [`Clone`], и можно сохранить исходный элемент в памяти, вам следует вместо этого использовать функцию [`repeat()`].
///
///
/// Итератор, созданный `repeat_with()`, не является [`DoubleEndedIterator`].
/// Если вам нужен `repeat_with()` для возврата [`DoubleEndedIterator`], откройте проблему GitHub с объяснением вашего варианта использования.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Основное использование:
///
/// ```
/// use std::iter;
///
/// // предположим, что у нас есть какое-то значение типа, которое не является `Clone` или которое пока не хочет иметь в памяти, потому что это дорого:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // определенное значение навсегда:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Использование мутации и переход к конечному результату:
///
/// ```rust
/// use std::iter;
///
/// // От нуля до третьей степени двойки:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... и теперь мы закончили
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Итератор, который бесконечно повторяет элементы типа `A`, применяя предоставленное замыкание `F: FnMut() -> A`.
///
///
/// Этот `struct` создается функцией [`repeat_with()`].
/// См. Его документацию для получения дополнительной информации.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}