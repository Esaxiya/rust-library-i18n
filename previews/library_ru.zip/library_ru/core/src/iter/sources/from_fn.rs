use crate::fmt;

/// Создает новый итератор, в котором каждая итерация вызывает предоставленное закрытие `F: FnMut() -> Option<T>`.
///
/// Это позволяет создать собственный итератор с любым поведением без использования более подробного синтаксиса создания выделенного типа и реализации для него [`Iterator`] trait.
///
/// Обратите внимание, что итератор `FromFn` не делает предположений о поведении замыкания и поэтому консервативно не реализует [`FusedIterator`] и не заменяет [`Iterator::size_hint()`] его `(0, None)` по умолчанию.
///
///
/// Замыкание может использовать захваты и свою среду для отслеживания состояния в итерациях.В зависимости от того, как используется итератор, для этого может потребоваться указать ключевое слово [`move`] в закрытии.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Давайте повторно реализуем итератор счетчика из [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Увеличьте наш счет.Вот почему мы начали с нуля.
///     count += 1;
///
///     // Проверьте, закончили ли мы считать.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Итератор, в котором каждая итерация вызывает предоставленное закрытие `F: FnMut() -> Option<T>`.
///
/// Этот `struct` создается функцией [`iter::from_fn()`].
/// См. Его документацию для получения дополнительной информации.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}