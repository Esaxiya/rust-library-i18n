use crate::iter::{FusedIterator, TrustedLen};

/// Создает новый итератор, который бесконечно повторяет один элемент.
///
/// Функция `repeat()` повторяет одно значение снова и снова.
///
/// Бесконечные итераторы, такие как `repeat()`, часто используются с адаптерами, такими как [`Iterator::take()`], чтобы сделать их конечными.
///
/// Если тип элемента итератора, который вам нужен, не реализует `Clone`, или если вы не хотите сохранять повторяющийся элемент в памяти, вы можете вместо этого использовать функцию [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Основное использование:
///
/// ```
/// use std::iter;
///
/// // номер четыре 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // да, еще четыре
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Конечная работа с [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // в последнем примере было слишком много четверок.Давайте только четыре четверки.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... и теперь мы закончили
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Итератор, бесконечно повторяющий элемент.
///
/// Этот `struct` создается функцией [`repeat()`].Смотрите его документацию для получения дополнительной информации.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}