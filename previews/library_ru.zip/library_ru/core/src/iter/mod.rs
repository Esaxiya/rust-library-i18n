//! Составная внешняя итерация.
//!
//! Если вы обнаружили какую-то коллекцию и вам нужно было выполнить операцию с элементами этой коллекции, вы быстро столкнетесь с 'iterators'.
//! Итераторы широко используются в идиоматическом коде Rust, поэтому стоит с ними познакомиться.
//!
//! Прежде чем объяснять больше, давайте поговорим о том, как устроен этот модуль:
//!
//! # Organization
//!
//! Этот модуль в основном организован по типам:
//!
//! * [Traits] являются основной частью: эти traits определяют, какие итераторы существуют и что вы можете с ними делать.Методы traits заслуживают дополнительного времени для изучения.
//! * [Functions] предоставить несколько полезных способов создания базовых итераторов.
//! * [Structs] часто являются типами возврата различных методов в traits этого модуля.Обычно вы хотите посмотреть на метод, который создает `struct`, а не на сам `struct`.
//! Подробнее о том, почему, см. «[Реализация итератора](#реализация-итератор)».
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Это оно!Давайте углубимся в итераторы.
//!
//! # Iterator
//!
//! Сердце и душа этого модуля-[`Iterator`] trait.Ядро [`Iterator`] выглядит так:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! У итератора есть метод [`next`], который при вызове возвращает [`Option`]`<Item>`.
//! [`next`] вернет [`Some(Item)`], пока есть элементы, и как только они все будут исчерпаны, вернет `None`, чтобы указать, что итерация завершена.
//! Отдельные итераторы могут решить возобновить итерацию, и поэтому повторный вызов [`next`] может или не может в конечном итоге начать возвращать [`Some(Item)`] снова в какой-то момент (например, см. [`TryIter`]).
//!
//!
//! Полное определение [`Iterator`] включает также ряд других методов, но они являются методами по умолчанию, построенными на основе [`next`], и поэтому вы получаете их бесплатно.
//!
//! Итераторы также можно компоновать, и их обычно объединяют в цепочки для выполнения более сложных форм обработки.См. Раздел [Adapters](#adapters) ниже для получения более подробной информации.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Три формы итерации
//!
//! Есть три распространенных метода, с помощью которых можно создавать итераторы из коллекции:
//!
//! * `iter()`, который повторяется по `&T`.
//! * `iter_mut()`, который повторяется по `&mut T`.
//! * `into_iter()`, который повторяется по `T`.
//!
//! Различные вещи в стандартной библиотеке могут реализовывать один или несколько из трех, где это необходимо.
//!
//! # Реализация итератора
//!
//! Создание собственного итератора включает два шага: создание `struct` для хранения состояния итератора, а затем реализация [`Iterator`] для этого `struct`.
//! Вот почему в этом модуле так много структур: по одной для каждого итератора и адаптера итератора.
//!
//! Давайте создадим итератор с именем `Counter`, который считает от `1` до `5`:
//!
//! ```
//! // Во-первых, структура:
//!
//! /// Итератор, который считает от одного до пяти.
//! struct Counter {
//!     count: usize,
//! }
//!
//! // мы хотим, чтобы наш счет начинался с единицы, поэтому давайте добавим в помощь метод new().
//! // Это не обязательно, но удобно.
//! // Обратите внимание, что мы начинаем `count` с нуля, мы увидим, почему в реализации `next()`'s ниже.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Затем мы реализуем `Iterator` для нашего `Counter`:
//!
//! impl Iterator for Counter {
//!     // мы будем считать с usize
//!     type Item = usize;
//!
//!     // next() единственный требуемый метод
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Увеличьте наш счет.Вот почему мы начали с нуля.
//!         self.count += 1;
//!
//!         // Проверьте, закончили ли мы считать.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // И теперь мы можем это использовать!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Вызов [`next`] таким образом становится повторяющимся.Rust имеет конструкцию, которая может вызывать [`next`] на вашем итераторе, пока не достигнет `None`.Давайте рассмотрим это дальше.
//!
//! Также обратите внимание, что `Iterator` предоставляет реализацию по умолчанию таких методов, как `nth` и `fold`, которые вызывают `next` изнутри.
//! Однако также можно написать собственную реализацию методов, таких как `nth` и `fold`, если итератор может вычислить их более эффективно, не вызывая `next`.
//!
//! # `for` петли и `IntoIterator`
//!
//! Синтаксис цикла `for` Rust на самом деле сахар для итераторов.Вот базовый пример `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Это напечатает числа от одного до пяти, каждое в отдельной строке.Но вы здесь кое-что заметите: мы никогда ничего не вызывали в нашем vector для создания итератора.Что дает?
//!
//! В стандартной библиотеке есть trait для преобразования чего-либо в итератор: [`IntoIterator`].
//! У этого trait есть один метод, [`into_iter`], который преобразует объект, реализующий [`IntoIterator`], в итератор.
//! Давайте еще раз посмотрим на этот цикл `for` и на то, во что его преобразует компилятор:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust расщепляет сахар в:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Сначала мы вызываем значение `into_iter()`.Затем мы сопоставляем итератор, который возвращается, снова и снова вызывая [`next`], пока не увидим `None`.
//! В этот момент мы `break` выходим из цикла, и мы завершаем итерацию.
//!
//! Здесь есть еще один тонкий момент: стандартная библиотека содержит интересную реализацию [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Другими словами, все [`Iterator`] реализуют [`IntoIterator`], просто возвращая себя.Это означает две вещи:
//!
//! 1. Если вы пишете [`Iterator`], вы можете использовать его с петлей `for`.
//! 2. Если вы создаете коллекцию, реализация [`IntoIterator`] для нее позволит использовать вашу коллекцию с циклом `for`.
//!
//! # Итерация по ссылке
//!
//! Поскольку [`into_iter()`] принимает `self` по значению, использование цикла `for` для итерации по коллекции потребляет эту коллекцию.Часто вы можете захотеть перебрать коллекцию, не потребляя ее.
//! Многие коллекции предлагают методы, которые предоставляют итераторы по ссылкам, обычно называемые `iter()` и `iter_mut()` соответственно:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` по-прежнему принадлежит этой функции.
//! ```
//!
//! Если тип коллекции `C` предоставляет `iter()`, он обычно также реализует `IntoIterator` для `&C` с реализацией, которая просто вызывает `iter()`.
//! Аналогично, коллекция `C`, которая предоставляет `iter_mut()`, обычно реализует `IntoIterator` для `&mut C`, делегируя `iter_mut()`.Это позволяет использовать удобное сокращение:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // такой же, как `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // такой же, как `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Хотя многие коллекции предлагают `iter()`, не все предлагают `iter_mut()`.
//! Например, изменение ключей [`HashSet<T>`] или [`HashMap<K, V>`] может привести коллекцию в несогласованное состояние, если хэши ключей изменятся, поэтому эти коллекции предлагают только `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Функции, которые принимают [`Iterator`] и возвращают другой [`Iterator`], часто называют адаптерами итератора, поскольку они являются формой адаптера
//! pattern'.
//!
//! К распространенным адаптерам итератора относятся [`map`], [`take`] и [`filter`].
//! Для получения дополнительной информации см. Их документацию.
//!
//! Если адаптер итератора panics, итератор будет в неопределенном (но безопасном для памяти) состоянии.
//! Также не гарантируется, что это состояние останется неизменным в разных версиях Rust, поэтому вам следует избегать точных значений, возвращаемых итератором, который запаниковал.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Итераторы (и итератор [adapters](#adapters))*ленивы*. Это означает, что простое создание итератора не сильно влияет на _do_. На самом деле ничего не происходит, пока вы не вызовете [`next`].
//! Иногда это вызывает путаницу при создании итератора исключительно из-за его побочных эффектов.
//! Например, метод [`map`] вызывает замыкание для каждого элемента, который он перебирает:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Это не будет печатать никаких значений, поскольку мы только создали итератор, а не использовали его.Компилятор предупредит нас о таком поведении:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Идиоматический способ написать [`map`] для его побочных эффектов-использовать цикл `for` или вызвать метод [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Другой распространенный способ оценки итератора-использование метода [`collect`] для создания новой коллекции.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Итераторы не обязательно должны быть конечными.Например, открытый диапазон-это бесконечный итератор:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Адаптер итератора [`take`] обычно используется для превращения бесконечного итератора в конечный:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Это напечатает числа от `0` до `4`, каждое в отдельной строке.
//!
//! Имейте в виду, что методы на бесконечных итераторах, даже те, для которых результат может быть определен математически за конечное время, могут не завершаться.
//! В частности, такие методы, как [`min`], которые в общем случае требуют обхода каждого элемента в итераторе, скорее всего, не вернутся успешно для любых бесконечных итераторов.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // о нет!Бесконечный цикл!
//! // `ones.min()` вызывает бесконечный цикл, поэтому мы не дойдем до этой точки!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;