/// Итератор, который знает его точную длину.
///
/// Многие [`Iterator`] не знают, сколько раз они будут повторяться, но некоторые знают.
/// Если итератор знает, сколько раз он может выполнять итерацию, предоставление доступа к этой информации может быть полезным.
/// Например, если вы хотите выполнить итерацию в обратном направлении, хорошим началом будет знать, где находится конец.
///
/// При реализации `ExactSizeIterator` необходимо также реализовать [`Iterator`].
/// При этом реализация [`Iterator::size_hint`]*должна* возвращать точный размер итератора.
///
/// Метод [`len`] имеет реализацию по умолчанию, поэтому обычно вам не следует его реализовывать.
/// Однако вы можете предоставить более производительную реализацию, чем стандартная, поэтому в этом случае имеет смысл переопределить ее.
///
///
/// Обратите внимание, что этот trait является безопасным trait и как таковой *не* и *не может* гарантировать, что возвращаемая длина верна.
/// Это означает, что код `unsafe`**не должен** полагаться на правильность [`Iterator::size_hint`].
/// Эту дополнительную гарантию дает нестабильный и небезопасный [`TrustedLen`](super::marker::TrustedLen) trait.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Основное использование:
///
/// ```
/// // конечный диапазон точно знает, сколько раз он будет повторяться
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// В [module-level docs] мы реализовали [`Iterator`], `Counter`.
/// Реализуем и для него `ExactSizeIterator`:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Мы можем легко подсчитать оставшееся количество итераций.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // И теперь мы можем это использовать!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Возвращает точную длину итератора.
    ///
    /// Реализация гарантирует, что итератор вернет ровно `len()` раз больше значения [`Some(T)`], прежде чем вернет [`None`].
    ///
    /// Этот метод имеет реализацию по умолчанию, поэтому обычно не следует реализовывать его напрямую.
    /// Однако, если вы можете обеспечить более эффективную реализацию, вы сможете это сделать.
    /// См. Пример в документации [trait-level].
    ///
    /// Эта функция имеет те же гарантии безопасности, что и функция [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// // конечный диапазон точно знает, сколько раз он будет повторяться
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Это утверждение является чрезмерно защитным, но оно проверяет инвариант
        // гарантируется trait.
        // Если бы этот trait был внутренним rust, мы могли бы использовать debug_assert !;assert_eq!также проверит все пользовательские реализации Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Возвращает `true`, если итератор пуст.
    ///
    /// Этот метод имеет реализацию по умолчанию с использованием [`ExactSizeIterator::len()`], поэтому вам не нужно реализовывать его самостоятельно.
    ///
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}