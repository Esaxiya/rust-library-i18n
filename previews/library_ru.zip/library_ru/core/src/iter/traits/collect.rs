/// Конверсия из [`Iterator`].
///
/// Реализуя `FromIterator` для типа, вы определяете, как он будет создаваться из итератора.
/// Это типично для типов, описывающих какую-либо коллекцию.
///
/// [`FromIterator::from_iter()`] редко вызывается явно, вместо этого используется метод [`Iterator::collect()`].
///
/// Дополнительные примеры см. В документации [`Iterator::collect()`]'s.
///
/// Смотрите также: [`IntoIterator`].
///
/// # Examples
///
/// Основное использование:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Использование [`Iterator::collect()`] для неявного использования `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Реализация `FromIterator` для вашего типа:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Коллекция сэмплов, это просто оболочка над Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Давайте дадим ему несколько методов, чтобы мы могли создать его и добавить к нему вещи.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // и мы реализуем FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Теперь мы можем создать новый итератор ...
/// let iter = (0..5).into_iter();
///
/// // ... и сделать из него MyCollection
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // собирать тоже работы!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Создает значение из итератора.
    ///
    /// См. [module-level documentation] для получения дополнительной информации.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Преобразование в [`Iterator`].
///
/// Реализуя `IntoIterator` для типа, вы определяете, как он будет преобразован в итератор.
/// Это типично для типов, описывающих какую-либо коллекцию.
///
/// Одним из преимуществ реализации `IntoIterator` является то, что ваш тип будет [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Смотрите также: [`FromIterator`].
///
/// # Examples
///
/// Основное использование:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Реализация `IntoIterator` для вашего типа:
///
/// ```
/// // Коллекция сэмплов, это просто оболочка над Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Давайте дадим ему несколько методов, чтобы мы могли создать его и добавить к нему вещи.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // и мы реализуем IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Теперь мы можем создать новую коллекцию ...
/// let mut c = MyCollection::new();
///
/// // ... добавить что-нибудь к этому ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... а затем превратить его в итератор:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Обычно `IntoIterator` используется как trait bound.Это позволяет изменять тип входной коллекции, если он все еще является итератором.
/// Дополнительные границы могут быть указаны путем ограничения на
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Тип повторяемых элементов.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// В какой итератор мы это превращаем?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Создает итератор из значения.
    ///
    /// См. [module-level documentation] для получения дополнительной информации.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Расширьте коллекцию содержимым итератора.
///
/// Итераторы производят серию значений, и коллекции также можно рассматривать как серию значений.
/// `Extend` trait устраняет этот пробел, позволяя расширять коллекцию, включая содержимое этого итератора.
/// При расширении коллекции с помощью уже существующего ключа эта запись обновляется или, в случае коллекций, допускающих несколько записей с одинаковыми ключами, эта запись вставляется.
///
///
/// # Examples
///
/// Основное использование:
///
/// ```
/// // Вы можете расширить строку с помощью некоторых символов:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Реализация `Extend`:
///
/// ```
/// // Коллекция сэмплов, это просто оболочка над Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Давайте дадим ему несколько методов, чтобы мы могли создать его и добавить к нему вещи.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // поскольку в MyCollection есть список i32, мы реализуем Extend для i32
/// impl Extend<i32> for MyCollection {
///
///     // С конкретной сигнатурой типа это немного проще: мы можем вызвать extension для всего, что можно превратить в Iterator, который дает нам i32s.
///     // Потому что нам нужно поместить i32 в MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Реализация очень проста: цикл через итератор и add() каждый элемент себе.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // давайте расширим нашу коллекцию еще тремя числами
/// c.extend(vec![1, 2, 3]);
///
/// // мы добавили эти элементы в конец
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Расширяет коллекцию содержимым итератора.
    ///
    /// Поскольку это единственный требуемый метод для этого trait, документы [trait-level] содержат более подробную информацию.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// // Вы можете расширить строку с помощью некоторых символов:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Расширяет коллекцию ровно одним элементом.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Резервирует емкость в коллекции для заданного количества дополнительных элементов.
    ///
    /// Реализация по умолчанию ничего не делает.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}