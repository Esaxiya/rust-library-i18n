// ignore-tidy-filelength Этот файл почти полностью состоит из определения `Iterator`.
// Мы не можем разбить это на несколько файлов.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Интерфейс для работы с итераторами.
///
/// Это главный итератор trait.
/// Дополнительные сведения о концепции итераторов в целом см. В документе [module-level documentation].
/// В частности, вы можете узнать, как работать с [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Тип повторяемых элементов.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Перемещает итератор вперед и возвращает следующее значение.
    ///
    /// По завершении итерации возвращает [`None`].
    /// Отдельные реализации итератора могут решить возобновить итерацию, и поэтому повторный вызов `next()` может в какой-то момент снова начать возвращать [`Some(Item)`], а может и не начать.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Вызов next() возвращает следующее значение ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... а затем None, когда все закончится.
    /// assert_eq!(None, iter.next());
    ///
    /// // Дополнительные вызовы могут вернуть или не вернуть `None`.Здесь они всегда будут.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Возвращает границы оставшейся длины итератора.
    ///
    /// В частности, `size_hint()` возвращает кортеж, в котором первый элемент является нижней границей, а второй элемент-верхней границей.
    ///
    /// Вторая половина возвращаемого кортежа-это [`Option`]`<`[`usize`] `>`.
    /// [`None`] здесь означает, что либо нет известной верхней границы, либо верхняя граница больше, чем [`usize`].
    ///
    /// # Замечания по реализации
    ///
    /// Не требуется, чтобы реализация итератора давала заявленное количество элементов.Неисправный итератор может давать меньше, чем нижняя граница, или больше, чем верхняя граница элементов.
    ///
    /// `size_hint()` в первую очередь предназначен для использования для оптимизации, такой как резервирование места для элементов итератора, но не следует доверять, например, для исключения проверки границ в небезопасном коде.
    /// Некорректная реализация `size_hint()` не должна приводить к нарушениям безопасности памяти.
    ///
    /// Тем не менее, реализация должна обеспечивать правильную оценку, поскольку в противном случае это было бы нарушением протокола trait.
    ///
    /// Реализация по умолчанию возвращает `(0,` [`None`]`)`, что верно для любого итератора.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Более сложный пример:
    ///
    /// ```
    /// // Четные числа от нуля до десяти.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Мы можем повторять от нуля до десяти раз.
    /// // Знать, что их ровно пять, было бы невозможно без выполнения filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Добавим еще пять чисел с chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // теперь обе границы увеличены на пять
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Возвращение `None` для верхней границы:
    ///
    /// ```
    /// // бесконечный итератор не имеет верхней границы и максимально возможной нижней границы
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Использует итератор, считает количество итераций и возвращает его.
    ///
    /// Этот метод будет вызывать [`next`] несколько раз, пока не встретится [`None`], возвращая количество раз, когда он видел [`Some`].
    /// Обратите внимание, что [`next`] должен быть вызван хотя бы один раз, даже если итератор не имеет никаких элементов.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Поведение при переполнении
    ///
    /// Этот метод не защищает от переполнения, поэтому подсчет элементов итератора с более чем [`usize::MAX`] элементами либо дает неправильный результат, либо panics.
    ///
    /// Если отладочные утверждения включены, гарантируется panic.
    ///
    /// # Panics
    ///
    /// Эта функция может panic, если итератор имеет более [`usize::MAX`] элементов.
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Использует итератор, возвращая последний элемент.
    ///
    /// Этот метод будет оценивать итератор до тех пор, пока он не вернет [`None`].
    /// При этом он отслеживает текущий элемент.
    /// После возврата [`None`] `last()` вернет последний увиденный элемент.
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Продвигает итератор на `n` элементов.
    ///
    /// Этот метод будет охотно пропускать элементы `n`, вызывая [`next`] до `n` раз, пока не встретится [`None`].
    ///
    /// `advance_by(n)` вернет [`Ok(())`][Ok], если итератор успешно продвинется на `n` элементов, или [`Err(k)`][Err], если встречается [`None`], где `k`-это количество элементов, на которые итератор продвигается до того, как закончились элементы (т. е.
    /// длина итератора).
    /// Обратите внимание, что `k` всегда меньше `n`.
    ///
    /// Вызов `advance_by(0)` не потребляет никаких элементов и всегда возвращает [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // только `&4` был пропущен
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Возвращает n-й элемент итератора.
    ///
    /// Как и в большинстве операций индексации, счет начинается с нуля, поэтому `nth(0)` возвращает первое значение, `nth(1)`-второе и т. Д.
    ///
    /// Обратите внимание, что все предыдущие элементы, а также возвращаемый элемент будут использованы итератором.
    /// Это означает, что предыдущие элементы будут отброшены, а также что вызов `nth(0)` несколько раз на одном и том же итераторе вернет разные элементы.
    ///
    ///
    /// `nth()` вернет [`None`], если `n` больше или равно длине итератора.
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Многократный вызов `nth()` не приводит к перемотке итератора:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Возврат `None`, если элементов меньше `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Создает итератор, начиная с той же точки, но шагая на заданную величину на каждой итерации.
    ///
    /// Примечание 1. Первый элемент итератора будет возвращаться всегда, независимо от заданного шага.
    ///
    /// Примечание 2: время вытягивания игнорируемых элементов не фиксировано.
    /// `StepBy` ведет себя как последовательность `next(), nth(step-1), nth(step-1),…`, но также может вести себя как последовательность
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Используемый способ может измениться для некоторых итераторов по соображениям производительности.
    /// Второй способ продвинет итератор раньше и может потреблять больше элементов.
    ///
    /// `advance_n_and_return_first` эквивалент:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Метод будет panic, если заданный шаг-`0`.
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Принимает два итератора и последовательно создает новый итератор для обоих.
    ///
    /// `chain()` вернет новый итератор, который сначала будет перебирать значения из первого итератора, а затем значения из второго итератора.
    ///
    /// Другими словами, он связывает два итератора в цепочку.🔗
    ///
    /// [`once`] обычно используется для адаптации одного значения к цепочке других видов итераций.
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Поскольку аргумент `chain()` использует [`IntoIterator`], мы можем передать все, что можно преобразовать в [`Iterator`], а не только сам [`Iterator`].
    /// Например, срезы (`&[T]`) реализуют [`IntoIterator`], поэтому их можно напрямую передать в `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Если вы работаете с Windows API, вы можете преобразовать [`OsStr`] в `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// «Застегивает» два итератора в один итератор пар.
    ///
    /// `zip()` возвращает новый итератор, который будет перебирать два других итератора, возвращая кортеж, в котором первый элемент поступает от первого итератора, а второй элемент-от второго итератора.
    ///
    ///
    /// Другими словами, он объединяет два итератора в один.
    ///
    /// Если любой итератор возвращает [`None`], [`next`] из заархивированного итератора вернет [`None`].
    /// Если первый итератор возвращает [`None`], `zip` выполнит короткое замыкание, и `next` не будет вызываться на втором итераторе.
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Поскольку аргумент `zip()` использует [`IntoIterator`], мы можем передать все, что можно преобразовать в [`Iterator`], а не только сам [`Iterator`].
    /// Например, срезы (`&[T]`) реализуют [`IntoIterator`], поэтому их можно напрямую передать в `zip()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` часто используется для привязки бесконечного итератора к конечному.
    /// Это работает, потому что конечный итератор в конечном итоге вернет [`None`], завершив застежку-молнию.Архивирование с помощью `(0..)` может во многом выглядеть как [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Создает новый итератор, который помещает копию `separator` между соседними элементами исходного итератора.
    ///
    /// В случае, если `separator` не реализует [`Clone`] или его необходимо вычислять каждый раз, используйте [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Первый элемент от `a`.
    /// assert_eq!(a.next(), Some(&100)); // Разделитель.
    /// assert_eq!(a.next(), Some(&1));   // Очередной элемент от `a`.
    /// assert_eq!(a.next(), Some(&100)); // Разделитель.
    /// assert_eq!(a.next(), Some(&2));   // Последний элемент от `a`.
    /// assert_eq!(a.next(), None);       // Итератор готов.
    /// ```
    ///
    /// `intersperse` может быть очень полезным для объединения элементов итератора с помощью общего элемента:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Создает новый итератор, который помещает элемент, сгенерированный `separator`, между соседними элементами исходного итератора.
    ///
    /// Замыкание будет вызываться ровно один раз каждый раз, когда элемент помещается между двумя соседними элементами из нижележащего итератора;
    /// в частности, закрытие не вызывается, если базовый итератор выдает менее двух элементов и после того, как выдается последний элемент.
    ///
    ///
    /// Если элемент итератора реализует [`Clone`], может быть проще использовать [`intersperse`].
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Первый элемент от `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Разделитель.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Очередной элемент от `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Разделитель.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Последний элемент от `v`.
    /// assert_eq!(it.next(), None);               // Итератор готов.
    /// ```
    ///
    /// `intersperse_with` может использоваться в ситуациях, когда необходимо вычислить разделитель:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Замыкание взаимно заимствует свой контекст для создания элемента.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Принимает закрытие и создает итератор, который вызывает это закрытие для каждого элемента.
    ///
    /// `map()` преобразует один итератор в другой с помощью своего аргумента:
    /// то, что реализует [`FnMut`].Он создает новый итератор, который вызывает это закрытие для каждого элемента исходного итератора.
    ///
    /// Если вы умеете мыслить типами, вы можете думать о `map()` так:
    /// Если у вас есть итератор, который предоставляет вам элементы некоторого типа `A`, и вам нужен итератор другого типа `B`, вы можете использовать `map()`, передав замыкание, которое принимает `A` и возвращает `B`.
    ///
    ///
    /// `map()` концептуально аналогичен петле [`for`].Однако, поскольку `map()` ленив, его лучше всего использовать, когда вы уже работаете с другими итераторами.
    /// Если вы делаете какой-то цикл для побочного эффекта, считается более идиоматичным использовать [`for`], чем `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Если у вас есть какой-то побочный эффект, предпочтите [`for`], а не `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // не делай этого:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // он даже не выполнится, так как он ленив.Rust предупредит вас об этом.
    ///
    /// // Вместо этого используйте для:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Вызывает замыкание для каждого элемента итератора.
    ///
    /// Это эквивалентно использованию цикла [`for`] на итераторе, хотя `break` и `continue` невозможны из замыкания.
    /// Как правило, более идиоматично использовать цикл `for`, но `for_each` может быть более разборчивым при обработке элементов в конце более длинных цепочек итераторов.
    ///
    /// В некоторых случаях `for_each` также может быть быстрее цикла, потому что он будет использовать внутреннюю итерацию на таких адаптерах, как `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Для такого небольшого примера цикл `for` может быть чище, но `for_each` может быть предпочтительнее, чтобы сохранить функциональный стиль с более длинными итераторами:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Создает итератор, который использует замыкание, чтобы определить, должен ли элемент быть возвращен.
    ///
    /// Для данного элемента замыкание должно возвращать `true` или `false`.Возвращенный итератор выдаст только те элементы, для которых замыкание возвращает true.
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Поскольку замыкание, переданное в `filter()`, принимает ссылку, а многие итераторы перебирают ссылки, это приводит к, возможно, запутанной ситуации, когда тип замыкания является двойной ссылкой:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // нужно два * с!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Вместо этого обычно используют деструктуризацию аргумента, чтобы убрать его:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // оба и *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// или оба:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // два &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// этих слоев.
    ///
    /// Обратите внимание, что `iter.filter(f).next()` эквивалентен `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Создает итератор, который фильтрует и сопоставляет.
    ///
    /// Возвращенный итератор возвращает только те значения, для которых предоставленное замыкание возвращает `Some(value)`.
    ///
    /// `filter_map` можно использовать, чтобы сделать цепочки [`filter`] и [`map`] более лаконичными.
    /// В приведенном ниже примере показано, как `map().filter().map()` можно сократить до одного вызова `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Вот тот же пример, но с [`filter`] и [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Создает итератор, который дает текущее количество итераций, а также следующее значение.
    ///
    /// Возвращенный итератором дает пары `(i, val)`, где `i`-текущий индекс итерации, а `val`-значение, возвращаемое итератором.
    ///
    ///
    /// `enumerate()` ведет счет как [`usize`].
    /// Если вы хотите считать с помощью целого числа другого размера, функция [`zip`] предоставляет аналогичные функции.
    ///
    /// # Поведение при переполнении
    ///
    /// Этот метод не защищает от переполнения, поэтому перечисление более чем [`usize::MAX`] элементов либо дает неправильный результат, либо panics.
    /// Если отладочные утверждения включены, гарантируется panic.
    ///
    /// # Panics
    ///
    /// Возвращенный итератор может быть panic, если подлежащий возврату индекс переполняет [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Создает итератор, который может использовать [`peek`] для просмотра следующего элемента итератора, не потребляя его.
    ///
    /// Добавляет метод [`peek`] в итератор.См. Его документацию для получения дополнительной информации.
    ///
    /// Обратите внимание, что базовый итератор все еще расширяется, когда [`peek`] вызывается в первый раз: чтобы получить следующий элемент, [`next`] вызывается на базовом итераторе, следовательно, любые побочные эффекты (т. Е.
    ///
    /// произойдет что-либо, кроме получения следующего значения) метода [`next`].
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() позволяет нам заглянуть в future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // мы можем peek() несколько раз, итератор не продвинется
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // после завершения итератора, peek() тоже
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Создает итератор, который [`пропускает`] элементы на основе предиката.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` принимает закрытие как аргумент.Он будет вызывать это замыкание для каждого элемента итератора и игнорировать элементы, пока не вернет `false`.
    ///
    /// После возврата `false` задание `skip_while()`'s завершается, а остальные элементы сдаются.
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Поскольку закрытие, переданное в `skip_while()`, принимает ссылку, а многие итераторы перебирают ссылки, это приводит к, возможно, запутанной ситуации, когда тип аргумента закрытия является двойной ссылкой:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // нужно два * с!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Остановка после первоначального `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // хотя это было бы ложью, поскольку мы уже получили ложь, skip_while() больше не используется
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Создает итератор, который выдает элементы на основе предиката.
    ///
    /// `take_while()` принимает закрытие как аргумент.Он будет вызывать это замыкание для каждого элемента итератора и выдавать элементы, пока он возвращает `true`.
    ///
    /// После возврата `false` задание `take_while()`'s завершается, а остальные элементы игнорируются.
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Поскольку замыкание, переданное в `take_while()`, принимает ссылку, а многие итераторы перебирают ссылки, это приводит к, возможно, запутанной ситуации, когда тип замыкания является двойной ссылкой:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // нужно два * с!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Остановка после первоначального `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // У нас есть больше элементов, которые меньше нуля, но поскольку мы уже получили ложь, take_while() больше не используется
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Поскольку `take_while()` необходимо посмотреть на значение, чтобы увидеть, следует ли его включать или нет, потребляющие итераторы увидят, что оно удалено:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` больше нет, потому что он использовался, чтобы увидеть, следует ли остановить итерацию, но не был возвращен в итератор.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Создает итератор, который выдает элементы на основе предиката и сопоставляет.
    ///
    /// `map_while()` принимает закрытие как аргумент.
    /// Он будет вызывать это замыкание для каждого элемента итератора и выдавать элементы, пока он возвращает [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Вот тот же пример, но с [`take_while`] и [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Остановка после первоначального [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // У нас есть больше элементов, которые могут поместиться в u32 (4, 5), но `map_while` вернул `None` для `-3` (поскольку `predicate` вернул `None`), а `collect` остановился на первом обнаруженном `None`.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Поскольку `map_while()` необходимо посмотреть на значение, чтобы увидеть, должно ли оно быть включено или нет, потребляющие итераторы увидят, что оно удалено:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` больше нет, потому что он использовался, чтобы увидеть, следует ли остановить итерацию, но не был возвращен в итератор.
    ///
    /// Обратите внимание, что в отличие от [`take_while`] этот итератор **не** объединен.
    /// Также не указано, что этот итератор возвращает после возврата первого [`None`].
    /// Если вам нужен объединенный итератор, используйте [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Создает итератор, пропускающий первые элементы `n`.
    ///
    /// После того, как они были израсходованы, остальные элементы сдаются.
    /// Вместо того, чтобы напрямую переопределять этот метод, вместо этого переопределите метод `nth`.
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Создает итератор, который возвращает свои первые элементы `n`.
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` часто используется с бесконечным итератором, чтобы сделать его конечным:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Если доступно менее `n` элементов, `take` ограничит себя размером базового итератора:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Адаптер итератора, похожий на [`fold`], который хранит внутреннее состояние и создает новый итератор.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` принимает два аргумента: начальное значение, которое заполняет внутреннее состояние, и закрытие с двумя аргументами, первый из которых является изменяемой ссылкой на внутреннее состояние, а второй-элементом итератора.
    ///
    /// Замыкание может быть присвоено внутреннему состоянию для разделения состояния между итерациями.
    ///
    /// При итерации замыкание будет применено к каждому элементу итератора, и итератор выдаст значение, возвращаемое замыканием, [`Option`].
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // на каждой итерации мы будем умножать состояние на элемент
    ///     *state = *state * x;
    ///
    ///     // тогда мы получим отрицание состояния
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Создает итератор, который работает как карта, но сглаживает вложенную структуру.
    ///
    /// Адаптер [`map`] очень полезен, но только тогда, когда аргумент закрытия выдает значения.
    /// Если вместо этого он создает итератор, возникает дополнительный уровень косвенности.
    /// `flat_map()` удалит этот лишний слой самостоятельно.
    ///
    /// Вы можете думать о `flat_map(f)` как о семантическом эквиваленте [`map`] ping, а затем [`flatten`] ing, как в `map(f).flatten()`.
    ///
    /// Другой способ мышления о `flat_map()`: замыкание [`map`] возвращает по одному элементу для каждого элемента, а замыкание `flat_map()`'s возвращает итератор для каждого элемента.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() возвращает итератор
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Создает итератор, выравнивающий вложенную структуру.
    ///
    /// Это полезно, когда у вас есть итератор итераторов или итератор вещей, которые можно превратить в итераторы, и вы хотите удалить один уровень косвенности.
    ///
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Отображение, а затем сглаживание:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() возвращает итератор
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Вы также можете переписать это в терминах [`flat_map()`], что в данном случае предпочтительнее, поскольку оно более четко передает намерение:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() возвращает итератор
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Сглаживание удаляет только один уровень вложенности за раз:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Здесь мы видим, что `flatten()` не выполняет выравнивание "deep".
    /// Вместо этого удаляется только один уровень вложенности.То есть, если вы `flatten()` трехмерный массив, результат будет двухмерным, а не одномерным.
    /// Чтобы получить одномерную структуру, вам нужно снова `flatten()`.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Создает итератор, который заканчивается после первого [`None`].
    ///
    /// После того, как итератор вернет [`None`], вызовы future могут снова дать, а могут и не дать [`Some(T)`].
    /// `fuse()` адаптирует итератор, гарантируя, что после того, как задано [`None`], он всегда будет возвращать [`None`] навсегда.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// // итератор, который чередуется между Some и None
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // если четный, Some(i32), иначе нет
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // мы можем видеть, как наш итератор движется вперед и назад
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // однако, как только мы его объединим ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // он всегда будет возвращать `None` после первого раза.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Что-то делает с каждым элементом итератора, передавая значение.
    ///
    /// При использовании итераторов вы часто объединяете несколько из них.
    /// Во время работы над таким кодом вы можете захотеть проверить, что происходит в различных частях конвейера.Для этого вставьте вызов `inspect()`.
    ///
    /// `inspect()` чаще используется в качестве инструмента отладки, чем присутствует в вашем окончательном коде, но приложения могут счесть его полезным в определенных ситуациях, когда ошибки необходимо регистрировать перед тем, как их выбросить.
    ///
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // эта последовательность итератора сложна.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // давайте добавим несколько вызовов inspect(), чтобы разобраться, что происходит
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Это напечатает:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Регистрация ошибок перед их удалением:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Это напечатает:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Заимствует итератор, а не использует его.
    ///
    /// Это полезно, чтобы разрешить применение адаптеров итератора, сохраняя при этом право собственности на исходный итератор.
    ///
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // если мы попробуем снова использовать iter, это не сработает.
    /// // Следующая строка выдает ошибку: использование перемещенного значения: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // давай попробуем еще раз
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // вместо этого мы добавляем .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // теперь это нормально:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Преобразует итератор в коллекцию.
    ///
    /// `collect()` может взять что угодно итеративно и превратить его в релевантную коллекцию.
    /// Это один из наиболее мощных методов стандартной библиотеки, который используется в различных контекстах.
    ///
    /// Самый простой шаблон, в котором используется `collect()`,-это превращение одной коллекции в другую.
    /// Вы берете коллекцию, вызываете для нее [`iter`], выполняете кучу преобразований, а затем в конце `collect()`.
    ///
    /// `collect()` также могут создавать экземпляры типов, не являющихся типичными коллекциями.
    /// Например, [`String`] может быть построен из [`char`] s, а итератор элементов [`Result<T, E>`][`Result`] может быть собран в `Result<Collection<T>, E>`.
    ///
    /// См. Примеры ниже, чтобы узнать больше.
    ///
    /// Поскольку `collect()` настолько универсален, он может вызвать проблемы с выводом типа.
    /// Таким образом, `collect()`-один из немногих случаев, когда вы увидите синтаксис, ласково известный как 'turbofish': `::<>`.
    /// Это помогает алгоритму вывода конкретно понять, в какую коллекцию вы пытаетесь собрать.
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Обратите внимание, что нам нужен `: Vec<i32>` с левой стороны.Это потому, что вместо этого мы могли бы собрать, например, [`VecDeque<T>`]:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Использование 'turbofish' вместо аннотации `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Поскольку `collect()` заботится только о том, что вы собираете, вы все равно можете использовать подсказку частичного типа, `_`, с turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Использование `collect()` для создания [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Если у вас есть список [`Результат<T, E>`][`Result`] s, вы можете использовать `collect()`, чтобы увидеть, не сработал ли один из них:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // дает нам первую ошибку
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // дает нам список ответов
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Использует итератор, создавая из него две коллекции.
    ///
    /// Предикат, переданный в `partition()`, может возвращать `true` или `false`.
    /// `partition()` возвращает пару, все элементы, для которых он вернул `true`, и все элементы, для которых он вернул `false`.
    ///
    ///
    /// См. Также [`is_partitioned()`] и [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Переупорядочивает элементы этого итератора *на месте* в соответствии с заданным предикатом, так что все те, которые возвращают `true`, предшествуют всем тем, которые возвращают `false`.
    ///
    /// Возвращает количество найденных элементов `true`.
    ///
    /// Относительный порядок разделенных элементов не сохраняется.
    ///
    /// См. Также [`is_partitioned()`] и [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Разделение на место между событиями и шансами
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: стоит ли беспокоиться о переполнении счетчика?Единственный способ иметь больше, чем
        // `usize::MAX` изменяемые ссылки связаны с ZST, которые бесполезны для разделения ...

        // Эти закрывающие функции "factory" существуют, чтобы избежать универсальности в `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Несколько раз найдите первый `false` и замените его последним `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Проверяет, разделены ли элементы этого итератора в соответствии с заданным предикатом, так что все те, которые возвращают `true`, предшествуют всем тем, которые возвращают `false`.
    ///
    ///
    /// См. Также [`partition()`] и [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Либо все элементы проверяют `true`, либо первое предложение заканчивается на `false`, и мы проверяем, что после этого больше нет элементов `true`.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Метод итератора, который применяет функцию до тех пор, пока она успешно возвращается, создавая единственное окончательное значение.
    ///
    /// `try_fold()` принимает два аргумента: начальное значение и закрытие с двумя аргументами: 'accumulator' и элементом.
    /// Замыкание либо возвращается успешно со значением, которое аккумулятор должен иметь для следующей итерации, либо возвращает ошибку со значением ошибки, которое немедленно передается обратно вызывающей стороне (short-circuiting).
    ///
    ///
    /// Начальное значение-это значение, которое аккумулятор будет иметь при первом вызове.Если применение замыкания было успешным для каждого элемента итератора, `try_fold()` возвращает последний аккумулятор как успешный.
    ///
    /// Сворачивание полезно, когда у вас есть коллекция чего-либо и вы хотите получить из нее одно значение.
    ///
    /// # Примечание для разработчиков
    ///
    /// Некоторые из других методов (forward) имеют реализации по умолчанию в терминах этого метода, поэтому попробуйте реализовать это явно, если он может сделать что-то лучше, чем реализация цикла `for` по умолчанию.
    ///
    /// В частности, попробуйте сделать этот вызов `try_fold()` на внутренних частях, из которых состоит этот итератор.
    /// Если требуется несколько вызовов, оператор `?` может быть удобен для связывания значения аккумулятора, но будьте осторожны с любыми инвариантами, которые необходимо поддерживать до этих ранних возвратов.
    /// Это метод `&mut self`, поэтому итерация должна быть возобновлена после появления здесь ошибки.
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // проверенная сумма всех элементов массива
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Эта сумма переполняется при добавлении элемента 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Из-за короткого замыкания остальные элементы все еще доступны через итератор.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Метод итератора, который применяет ошибочную функцию к каждому элементу в итераторе, останавливаясь при первой ошибке и возвращая эту ошибку.
    ///
    ///
    /// Это также можно рассматривать как ошибочную форму [`for_each()`] или как версию [`try_fold()`] без сохранения состояния.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Он замкнулся накоротко, поэтому оставшиеся элементы все еще находятся в итераторе:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Сворачивает каждый элемент в аккумулятор, применяя операцию, возвращая окончательный результат.
    ///
    /// `fold()` принимает два аргумента: начальное значение и закрытие с двумя аргументами: 'accumulator' и элементом.
    /// Замыкание возвращает значение, которое аккумулятор должен иметь для следующей итерации.
    ///
    /// Начальное значение-это значение, которое аккумулятор будет иметь при первом вызове.
    ///
    /// После применения этого замыкания к каждому элементу итератора `fold()` возвращает аккумулятор.
    ///
    /// Эта операция иногда называется 'reduce' или 'inject'.
    ///
    /// Сворачивание полезно, когда у вас есть коллекция чего-либо и вы хотите получить из нее одно значение.
    ///
    /// Note: `fold()` и аналогичные методы, которые проходят через весь итератор, могут не завершаться для бесконечных итераторов, даже на traits, для которого результат можно определить за конечное время.
    ///
    /// Note: [`reduce()`] можно использовать для использования первого элемента в качестве начального значения, если тип аккумулятора и тип элемента совпадают.
    ///
    /// # Примечание для разработчиков
    ///
    /// Некоторые из других методов (forward) имеют реализации по умолчанию в терминах этого метода, поэтому попробуйте реализовать это явно, если он может сделать что-то лучше, чем реализация цикла `for` по умолчанию.
    ///
    ///
    /// В частности, попробуйте сделать этот вызов `fold()` на внутренних частях, из которых состоит этот итератор.
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // сумма всех элементов массива
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Давайте пройдемся по каждому этапу итерации здесь:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Итак, наш окончательный результат, `6`.
    ///
    /// Люди, которые мало использовали итераторы, часто используют цикл `for` со списком вещей для получения результата.Их можно превратить в `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // для цикла:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // они такие же
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Уменьшает элементы до одного, многократно применяя операцию уменьшения.
    ///
    /// Если итератор пуст, возвращает [`None`];в противном случае возвращает результат уменьшения.
    ///
    /// Для итераторов по крайней мере с одним элементом это то же самое, что и [`fold()`] с первым элементом итератора в качестве начального значения, складывая в него каждый последующий элемент.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Найдите максимальное значение:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Проверяет, соответствует ли каждый элемент итератора предикату.
    ///
    /// `all()` принимает замыкание, которое возвращает `true` или `false`.Он применяет это замыкание к каждому элементу итератора, и если все они возвращают `true`, то `all()` тоже.
    /// Если какой-либо из них возвращает `false`, он возвращает `false`.
    ///
    /// `all()` происходит короткое замыкание;другими словами, он прекратит обработку, как только найдет `false`, учитывая, что что бы ни случилось, результатом также будет `false`.
    ///
    ///
    /// Пустой итератор возвращает `true`.
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Остановка на первом `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // мы все еще можем использовать `iter`, так как есть больше элементов.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Проверяет, соответствует ли какой-либо элемент итератора предикату.
    ///
    /// `any()` принимает замыкание, которое возвращает `true` или `false`.Он применяет это замыкание к каждому элементу итератора, и если какой-либо из них возвращает `true`, то `any()` тоже.
    /// Если все они возвращают `false`, возвращается `false`.
    ///
    /// `any()` происходит короткое замыкание;другими словами, он прекратит обработку, как только найдет `true`, учитывая, что что бы ни случилось, результатом также будет `true`.
    ///
    ///
    /// Пустой итератор возвращает `false`.
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Остановка на первом `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // мы все еще можем использовать `iter`, так как есть больше элементов.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Ищет элемент итератора, удовлетворяющий предикату.
    ///
    /// `find()` принимает замыкание, которое возвращает `true` или `false`.
    /// Он применяет это замыкание к каждому элементу итератора, и если какой-либо из них возвращает `true`, то `find()` возвращает [`Some(element)`].
    /// Если все они возвращают `false`, возвращается [`None`].
    ///
    /// `find()` происходит короткое замыкание;другими словами, он прекратит обработку, как только замыкание вернет `true`.
    ///
    /// Поскольку `find()` принимает ссылку, а многие итераторы перебирают ссылки, это может привести к запутанной ситуации, когда аргумент является двойной ссылкой.
    ///
    /// Вы можете увидеть этот эффект в приведенных ниже примерах с `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Остановка на первом `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // мы все еще можем использовать `iter`, так как есть больше элементов.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Обратите внимание, что `iter.find(f)` эквивалентен `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Применяет функцию к элементам итератора и возвращает первый результат, отличный от нуля.
    ///
    ///
    /// `iter.find_map(f)` эквивалентно `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Применяет функцию к элементам итератора и возвращает первый истинный результат или первую ошибку.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Ищет элемент в итераторе, возвращая его индекс.
    ///
    /// `position()` принимает замыкание, которое возвращает `true` или `false`.
    /// Он применяет это замыкание к каждому элементу итератора, и если один из них возвращает `true`, то `position()` возвращает [`Some(index)`].
    /// Если все они возвращают `false`, возвращается [`None`].
    ///
    /// `position()` происходит короткое замыкание;другими словами, он прекратит обработку, как только найдет `true`.
    ///
    /// # Поведение при переполнении
    ///
    /// Этот метод не защищает от переполнения, поэтому, если имеется более [`usize::MAX`] несовпадающих элементов, он либо дает неправильный результат, либо panics.
    ///
    /// Если отладочные утверждения включены, гарантируется panic.
    ///
    /// # Panics
    ///
    /// Эта функция может panic, если итератор имеет более `usize::MAX` несовпадающих элементов.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Остановка на первом `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // мы все еще можем использовать `iter`, так как есть больше элементов.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Возвращаемый индекс зависит от состояния итератора
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Ищет элемент в итераторе справа, возвращая его индекс.
    ///
    /// `rposition()` принимает замыкание, которое возвращает `true` или `false`.
    /// Он применяет это замыкание к каждому элементу итератора, начиная с конца, и если один из них возвращает `true`, то `rposition()` возвращает [`Some(index)`].
    ///
    /// Если все они возвращают `false`, возвращается [`None`].
    ///
    /// `rposition()` происходит короткое замыкание;другими словами, он прекратит обработку, как только найдет `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Остановка на первом `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // мы все еще можем использовать `iter`, так как есть больше элементов.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Здесь нет необходимости в проверке переполнения, потому что `ExactSizeIterator` подразумевает, что количество элементов умещается в `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Возвращает максимальный элемент итератора.
    ///
    /// Если несколько элементов одинаково максимальны, возвращается последний элемент.
    /// Если итератор пуст, возвращается [`None`].
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Возвращает минимальный элемент итератора.
    ///
    /// Если несколько элементов одинаково минимальны, возвращается первый элемент.
    /// Если итератор пуст, возвращается [`None`].
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Возвращает элемент, который дает максимальное значение из указанной функции.
    ///
    ///
    /// Если несколько элементов одинаково максимальны, возвращается последний элемент.
    /// Если итератор пуст, возвращается [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Возвращает элемент, который дает максимальное значение по отношению к указанной функции сравнения.
    ///
    ///
    /// Если несколько элементов одинаково максимальны, возвращается последний элемент.
    /// Если итератор пуст, возвращается [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Возвращает элемент, который дает минимальное значение из указанной функции.
    ///
    ///
    /// Если несколько элементов одинаково минимальны, возвращается первый элемент.
    /// Если итератор пуст, возвращается [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Возвращает элемент, который дает минимальное значение по отношению к указанной функции сравнения.
    ///
    ///
    /// Если несколько элементов одинаково минимальны, возвращается первый элемент.
    /// Если итератор пуст, возвращается [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Меняет направление итератора на противоположное.
    ///
    /// Обычно итераторы повторяются слева направо.
    /// После использования `rev()` итератор будет выполнять итерацию справа налево.
    ///
    /// Это возможно только в том случае, если итератор имеет конец, поэтому `rev()` работает только с [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Преобразует итератор пар в пару контейнеров.
    ///
    /// `unzip()` потребляет весь итератор пар, создавая две коллекции: одну из левых элементов пар и одну из правых элементов.
    ///
    ///
    /// Эта функция в некотором смысле противоположна [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Создает итератор, который копирует все его элементы.
    ///
    /// Это полезно, когда у вас есть итератор над `&T`, но вам нужен итератор над `T`.
    ///
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // скопировано такое же, как .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Создает итератор, который [`clone`] содержит все его элементы.
    ///
    /// Это полезно, когда у вас есть итератор над `&T`, но вам нужен итератор над `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // cloned совпадает с .map(|&x| x), для целых чисел
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Бесконечно повторяет итератор.
    ///
    /// Вместо того, чтобы останавливаться на [`None`], итератор запускается заново, с самого начала.После повторной итерации он снова начнется с самого начала.И опять.
    /// И опять.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Суммирует элементы итератора.
    ///
    /// Берет каждый элемент, складывает их и возвращает результат.
    ///
    /// Пустой итератор возвращает нулевое значение типа.
    ///
    /// # Panics
    ///
    /// При вызове `sum()` и возвращении примитивного целочисленного типа этот метод будет panic, если включены вычисления переполнения и отладочные утверждения.
    ///
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Обходит весь итератор, умножая все элементы
    ///
    /// Пустой итератор возвращает одно значение типа.
    ///
    /// # Panics
    ///
    /// При вызове `product()` и возвращении примитивного целочисленного типа метод будет panic, если вычисление переполнения и утверждения отладки включены.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) сравнивает элементы этого [`Iterator`] с элементами другого.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) сравнивает элементы этого [`Iterator`] с элементами другого в соответствии с указанной функцией сравнения.
    ///
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) сравнивает элементы этого [`Iterator`] с элементами другого.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) сравнивает элементы этого [`Iterator`] с элементами другого в соответствии с указанной функцией сравнения.
    ///
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Определяет, равны ли элементы этого [`Iterator`] элементам другого.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Определяет, равны ли элементы этого [`Iterator`] элементам другого по отношению к указанной функции равенства.
    ///
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Определяет, не равны ли элементы этого [`Iterator`] элементам другого.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Определяет, являются ли элементы этого [`Iterator`] на [lexicographically](Ord#lexicographical-comparison) меньше, чем у другого.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Определяет, являются ли элементы этого [`Iterator`] на [lexicographically](Ord#lexicographical-comparison) меньше или равны элементам другого.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Определяет, являются ли элементы этого [`Iterator`] на [lexicographically](Ord#lexicographical-comparison) больше, чем у другого.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Определяет, являются ли элементы этого [`Iterator`] на [lexicographically](Ord#lexicographical-comparison) больше или равны элементам другого.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Проверяет, отсортированы ли элементы этого итератора.
    ///
    /// То есть для каждого элемента `a` и следующего за ним элемента `b` должно выполняться `a <= b`.Если итератор дает ровно ноль или один элемент, возвращается `true`.
    ///
    /// Обратите внимание, что если `Self::Item`-это только `PartialOrd`, но не `Ord`, приведенное выше определение подразумевает, что эта функция возвращает `false`, если любые два последовательных элемента не сопоставимы.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Проверяет, сортируются ли элементы этого итератора с использованием заданной функции компаратора.
    ///
    /// Вместо использования `PartialOrd::partial_cmp` эта функция использует данную функцию `compare` для определения порядка двух элементов.
    /// Кроме того, это эквивалент [`is_sorted`];см. его документацию для получения дополнительной информации.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Проверяет, отсортированы ли элементы этого итератора с использованием заданной функции извлечения ключа.
    ///
    /// Вместо того, чтобы напрямую сравнивать элементы итератора, эта функция сравнивает ключи элементов, как определено `f`.
    /// Кроме того, это эквивалент [`is_sorted`];см. его документацию для получения дополнительной информации.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// См. [TrustedRandomAccess]
    // Необычное имя, чтобы избежать конфликтов имен при разрешении метода, см. #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}