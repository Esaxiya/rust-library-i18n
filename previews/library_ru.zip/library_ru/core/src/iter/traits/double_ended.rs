use crate::ops::{ControlFlow, Try};

/// Итератор, способный получать элементы с обоих концов.
///
/// Что-то, что реализует `DoubleEndedIterator`, имеет одну дополнительную возможность по сравнению с чем-то, что реализует [`Iterator`]: возможность также брать `Предметы сзади, а также спереди.
///
///
/// Важно отметить, что оба направления работают в одном и том же диапазоне и не пересекаются: итерация завершается, когда они встречаются в середине.
///
/// Подобно протоколу [`Iterator`], как только `DoubleEndedIterator` возвращает [`None`] от [`next_back()`], его повторный вызов может или не может когда-либо вернуть [`Some`] снова.
/// [`next()`] и [`next_back()`] для этой цели являются взаимозаменяемыми.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Основное использование:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Удаляет и возвращает элемент из конца итератора.
    ///
    /// Возвращает `None`, если элементов больше нет.
    ///
    /// Документы [trait-level] содержат более подробную информацию.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Элементы, полученные методами `DoubleEndedIterator`, могут отличаться от элементов, полученных методами [`Iterator`]:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Перемещает итератор сзади на `n` элементов.
    ///
    /// `advance_back_by` это обратная версия [`advance_by`].Этот метод будет охотно пропускать элементы `n`, начиная с задней части, вызывая [`next_back`] до `n` раз, пока не встретится [`None`].
    ///
    /// `advance_back_by(n)` вернет [`Ok(())`], если итератор успешно продвинется на `n` элементов, или [`Err(k)`], если встречается [`None`], где `k`-это количество элементов, на которые итератор продвигается до того, как исчерпаются элементы (т. е.
    /// длина итератора).
    /// Обратите внимание, что `k` всегда меньше `n`.
    ///
    /// Вызов `advance_back_by(0)` не потребляет никаких элементов и всегда возвращает [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // только `&3` был пропущен
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Возвращает n-й элемент с конца итератора.
    ///
    /// По сути, это перевернутая версия [`Iterator::nth()`].
    /// Хотя, как и в большинстве операций индексации, счет начинается с нуля, поэтому `nth_back(0)` возвращает первое значение с конца, `nth_back(1)`-второе и т. Д.
    ///
    ///
    /// Обратите внимание, что все элементы между концом и возвращаемым элементом будут использованы, включая возвращенный элемент.
    /// Это также означает, что многократный вызов `nth_back(0)` на одном и том же итераторе вернет разные элементы.
    ///
    /// `nth_back()` вернет [`None`], если `n` больше или равно длине итератора.
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Многократный вызов `nth_back()` не приводит к перемотке итератора:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Возврат `None`, если элементов меньше `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Это обратная версия [`Iterator::try_fold()`]: она принимает элементы, начиная с задней части итератора.
    ///
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Из-за короткого замыкания остальные элементы все еще доступны через итератор.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Метод итератора, который уменьшает элементы итератора до одного конечного значения, начиная с задней части.
    ///
    /// Это обратная версия [`Iterator::fold()`]: она принимает элементы, начиная с задней части итератора.
    ///
    /// `rfold()` принимает два аргумента: начальное значение и закрытие с двумя аргументами: 'accumulator' и элементом.
    /// Замыкание возвращает значение, которое аккумулятор должен иметь для следующей итерации.
    ///
    /// Начальное значение-это значение, которое аккумулятор будет иметь при первом вызове.
    ///
    /// После применения этого замыкания к каждому элементу итератора `rfold()` возвращает аккумулятор.
    ///
    /// Эта операция иногда называется 'reduce' или 'inject'.
    ///
    /// Сворачивание полезно, когда у вас есть коллекция чего-либо и вы хотите получить из нее одно значение.
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // сумма всех элементов
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// В этом примере строится строка, начиная с начального значения и продолжаясь каждым элементом от задней части до передней:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Ищет элемент итератора сзади, удовлетворяющий предикату.
    ///
    /// `rfind()` принимает замыкание, которое возвращает `true` или `false`.
    /// Он применяет это замыкание к каждому элементу итератора, начиная с конца, и если какой-либо из них возвращает `true`, то `rfind()` возвращает [`Some(element)`].
    /// Если все они возвращают `false`, возвращается [`None`].
    ///
    /// `rfind()` происходит короткое замыкание;другими словами, он прекратит обработку, как только замыкание вернет `true`.
    ///
    /// Поскольку `rfind()` принимает ссылку, а многие итераторы перебирают ссылки, это может привести к запутанной ситуации, когда аргумент является двойной ссылкой.
    ///
    /// Вы можете увидеть этот эффект в приведенных ниже примерах с `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Остановка на первом `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // мы все еще можем использовать `iter`, так как есть больше элементов.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}