#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` позволяет разработчику исполнителя задачи создать [`Waker`], который обеспечивает настраиваемое поведение при пробуждении.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Он состоит из указателя данных и [virtual function pointer table (vtable)][vtable], который настраивает поведение `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Указатель данных, который может использоваться для хранения произвольных данных по требованию исполнителя.
    /// Это может быть, например,
    /// указатель со стиранием типа на `Arc`, связанный с задачей.
    /// Значение этого поля передается всем функциям, которые являются частью vtable, в качестве первого параметра.
    ///
    data: *const (),
    /// Таблица указателей виртуальных функций, которая настраивает поведение этого будильника.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Создает новый `RawWaker` из предоставленного указателя `data` и `vtable`.
    ///
    /// Указатель `data` может использоваться для хранения произвольных данных по требованию исполнителя.Это может быть, например,
    /// указатель со стиранием типа на `Arc`, связанный с задачей.
    /// Значение этого указателя будет передано всем функциям, которые являются частью `vtable`, в качестве первого параметра.
    ///
    /// `vtable` настраивает поведение `Waker`, созданного из `RawWaker`.
    /// Для каждой операции на `Waker` будет вызываться соответствующая функция в `vtable` базового `RawWaker`.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Таблица указателей виртуальных функций (vtable), которая определяет поведение [`RawWaker`].
///
/// Указатель, переданный всем функциям внутри vtable, является указателем `data` из окружающего объекта [`RawWaker`].
///
/// Функции внутри этой структуры предназначены только для вызова указателя `data` правильно сконструированного объекта [`RawWaker`] изнутри реализации [`RawWaker`].
/// Вызов одной из содержащихся функций с использованием любого другого указателя `data` приведет к неопределенному поведению.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Эта функция будет вызываться при клонировании [`RawWaker`], например, при клонировании [`Waker`], в котором хранится [`RawWaker`].
    ///
    /// Реализация этой функции должна сохранять все ресурсы, которые требуются для этого дополнительного экземпляра [`RawWaker`] и связанной задачи.
    /// Вызов `wake` на получившемся [`RawWaker`] должен привести к пробуждению той же задачи, которая была бы разбужена исходным [`RawWaker`].
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Эта функция будет вызываться при вызове `wake` на [`Waker`].
    /// Он должен пробудить задачу, связанную с этим [`RawWaker`].
    ///
    /// Реализация этой функции должна гарантировать высвобождение всех ресурсов, связанных с этим экземпляром [`RawWaker`] и связанной задачей.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Эта функция будет вызываться при вызове `wake_by_ref` на [`Waker`].
    /// Он должен пробудить задачу, связанную с этим [`RawWaker`].
    ///
    /// Эта функция аналогична `wake`, но не должна использовать указанный указатель данных.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Эта функция вызывается при падении [`RawWaker`].
    ///
    /// Реализация этой функции должна гарантировать высвобождение всех ресурсов, связанных с этим экземпляром [`RawWaker`] и связанной задачей.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Создает новый `RawWakerVTable` из предоставленных функций `clone`, `wake`, `wake_by_ref` и `drop`.
    ///
    /// # `clone`
    ///
    /// Эта функция будет вызываться при клонировании [`RawWaker`], например, при клонировании [`Waker`], в котором хранится [`RawWaker`].
    ///
    /// Реализация этой функции должна сохранять все ресурсы, которые требуются для этого дополнительного экземпляра [`RawWaker`] и связанной задачи.
    /// Вызов `wake` на получившемся [`RawWaker`] должен привести к пробуждению той же задачи, которая была бы разбужена исходным [`RawWaker`].
    ///
    /// # `wake`
    ///
    /// Эта функция будет вызываться при вызове `wake` на [`Waker`].
    /// Он должен пробудить задачу, связанную с этим [`RawWaker`].
    ///
    /// Реализация этой функции должна гарантировать высвобождение всех ресурсов, связанных с этим экземпляром [`RawWaker`] и связанной задачей.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Эта функция будет вызываться при вызове `wake_by_ref` на [`Waker`].
    /// Он должен пробудить задачу, связанную с этим [`RawWaker`].
    ///
    /// Эта функция аналогична `wake`, но не должна использовать указанный указатель данных.
    ///
    /// # `drop`
    ///
    /// Эта функция вызывается при падении [`RawWaker`].
    ///
    /// Реализация этой функции должна гарантировать высвобождение всех ресурсов, связанных с этим экземпляром [`RawWaker`] и связанной задачей.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` асинхронной задачи.
///
/// В настоящее время `Context` служит только для предоставления доступа к `&Waker`, который можно использовать для пробуждения текущей задачи.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Обеспечьте защиту future от изменений дисперсии, заставив время жизни быть инвариантным (время жизни позиции аргумента контравариантно, а время жизни позиции возврата ковариантно).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Создайте новый `Context` из `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Возвращает ссылку на `Waker` для текущей задачи.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker`-это дескриптор для пробуждения задачи путем уведомления ее исполнителя о том, что она готова к запуску.
///
/// Этот дескриптор инкапсулирует экземпляр [`RawWaker`], который определяет поведение пробуждения, зависящее от исполнителя.
///
///
/// Реализует [`Clone`], [`Send`] и [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Разбудите задачу, связанную с этим `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Фактический вызов пробуждения делегируется через вызов виртуальной функции реализации, которая определяется исполнителем.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Не звоните `drop`-будильник будет поглощен `wake`.
        crate::mem::forget(self);

        // БЕЗОПАСНОСТЬ: это безопасно, потому что `Waker::from_raw`-единственный способ
        // для инициализации `wake` и `data`, требующих от пользователя подтверждения того, что контракт `RawWaker` выполняется.
        //
        unsafe { (wake)(data) };
    }

    /// Разбудите задачу, связанную с этим `Waker`, не используя `Waker`.
    ///
    /// Это похоже на `wake`, но может быть немного менее эффективным в случае, если доступен собственный `Waker`.
    /// Этот метод следует предпочесть вызову `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Фактический вызов пробуждения делегируется через вызов виртуальной функции реализации, которая определяется исполнителем.
        //

        // БЕЗОПАСНОСТЬ: см. `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Возвращает `true`, если этот `Waker` и другой `Waker` пробудили одну и ту же задачу.
    ///
    /// Эта функция работает по принципу «максимальных усилий» и может возвращать false, даже если «Waker`s» пробудит ту же задачу.
    /// Однако, если эта функция возвращает `true`, гарантируется, что `Waker`s пробудит ту же задачу.
    ///
    /// Эта функция в основном используется в целях оптимизации.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Создает новый `Waker` из [`RawWaker`].
    ///
    /// Поведение возвращенного `Waker` не определено, если контракт, определенный в документации [`RawWaker`] и [`RawWakerVTable`], не поддерживается.
    ///
    /// Поэтому этот метод небезопасен.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // БЕЗОПАСНОСТЬ: это безопасно, потому что `Waker::from_raw`-единственный способ
            // для инициализации `clone` и `data`, требующих от пользователя подтверждения того, что контракт [`RawWaker`] выполняется.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // БЕЗОПАСНОСТЬ: это безопасно, потому что `Waker::from_raw`-единственный способ
        // для инициализации `drop` и `data`, требующих от пользователя подтверждения того, что контракт `RawWaker` выполняется.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}