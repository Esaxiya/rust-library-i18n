//! Макросы, используемые итераторами среза.

// Встраивание is_empty и len имеет огромное значение в производительности
macro_rules! is_empty {
    // То, как мы кодируем длину итератора ZST, работает как для ZST, так и не для ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Чтобы избавиться от некоторых проверок границ (см. `position`), мы вычисляем длину несколько неожиданным способом.
// (Проверено `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // нас иногда используют в небезопасном блоке

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Этот _cannot_ использует `unchecked_sub`, потому что мы зависим от переноса для представления длины длинных итераторов среза ZST.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Мы знаем, что `start <= end` может работать лучше, чем `offset_from`, который должен иметь дело с подписью.
            // Установив здесь соответствующие флаги, мы можем сообщить об этом LLVM, что поможет ему удалить проверки границ.
            // БЕЗОПАСНОСТЬ: По инварианту типа, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Также сообщая LLVM, что указатели разнесены на точное кратное размеру типа, он может оптимизировать `len() == 0` до `start == end` вместо `(end - start) < size`.
            //
            // БЕЗОПАСНОСТЬ: По инварианту типа указатели выровнены так, чтобы
            //         расстояние между ними должно быть кратно размеру указателя
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Общее определение итераторов `Iter` и `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Возвращает первый элемент и перемещает начало итератора вперед на 1.
        // Значительно повышает производительность по сравнению с встроенной функцией.
        // Итератор не должен быть пустым.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Возвращает последний элемент и перемещает конец итератора назад на 1.
        // Значительно повышает производительность по сравнению с встроенной функцией.
        // Итератор не должен быть пустым.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Уменьшает итератор, когда T является ZST, перемещая конец итератора назад на `n`.
        // `n` не должен превышать `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Вспомогательная функция для создания среза из итератора.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // БЕЗОПАСНОСТЬ: итератор был создан из среза с указателем
                // `self.ptr` и длиной `len!(self)`.
                // Это гарантирует выполнение всех предварительных условий для `from_raw_parts`.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Вспомогательная функция для перемещения начала итератора вперед на элементы `offset`, возвращая старое начало.
            //
            // Небезопасно, потому что смещение не должно превышать `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // БЕЗОПАСНОСТЬ: вызывающий абонент гарантирует, что `offset` не превышает `self.len()`,
                    // поэтому этот новый указатель находится внутри `self` и, следовательно, гарантированно не равен нулю.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Вспомогательная функция для перемещения конца итератора назад на элементы `offset`, возвращая новый конец.
            //
            // Небезопасно, потому что смещение не должно превышать `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // БЕЗОПАСНОСТЬ: вызывающий абонент гарантирует, что `offset` не превышает `self.len()`,
                    // который гарантированно не переполнит `isize`.
                    // Кроме того, результирующий указатель находится в границах `slice`, что удовлетворяет другим требованиям для `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // можно реализовать с помощью срезов, но это позволяет избежать проверки границ

                // БЕЗОПАСНОСТЬ: вызовы `assume` безопасны, поскольку указатель начала среза
                // должен быть ненулевым, и срезы поверх не-ZST также должны иметь ненулевой конечный указатель.
                // Вызов `next_unchecked!` безопасен, поскольку мы сначала проверяем, пуст ли итератор.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Этот итератор теперь пуст.
                    if mem::size_of::<T>() == 0 {
                        // Мы должны сделать это таким образом, поскольку `ptr` может никогда не быть 0, но `end` может быть (из-за упаковки).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // БЕЗОПАСНОСТЬ: конец не может быть 0, если T не ZST, потому что ptr не 0 и end>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // БЕЗОПАСНОСТЬ: Мы находимся в рамках.`post_inc_start` подходит даже для ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Мы переопределяем реализацию по умолчанию, которая использует `try_fold`, потому что эта простая реализация генерирует меньше IR LLVM и быстрее компилируется.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Мы переопределяем реализацию по умолчанию, которая использует `try_fold`, потому что эта простая реализация генерирует меньше IR LLVM и быстрее компилируется.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Мы переопределяем реализацию по умолчанию, которая использует `try_fold`, потому что эта простая реализация генерирует меньше IR LLVM и быстрее компилируется.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Мы переопределяем реализацию по умолчанию, которая использует `try_fold`, потому что эта простая реализация генерирует меньше IR LLVM и быстрее компилируется.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Мы переопределяем реализацию по умолчанию, которая использует `try_fold`, потому что эта простая реализация генерирует меньше IR LLVM и быстрее компилируется.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Мы переопределяем реализацию по умолчанию, которая использует `try_fold`, потому что эта простая реализация генерирует меньше IR LLVM и быстрее компилируется.
            // Кроме того, `assume` избегает проверки границ.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // БЕЗОПАСНОСТЬ: мы гарантированно находимся в рамках инварианта цикла:
                        // когда `i >= n`, `self.next()` возвращает `None`, и цикл прерывается.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Мы переопределяем реализацию по умолчанию, которая использует `try_fold`, потому что эта простая реализация генерирует меньше IR LLVM и быстрее компилируется.
            // Кроме того, `assume` избегает проверки границ.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // БЕЗОПАСНОСТЬ: `i` должен быть ниже, чем `n`, поскольку он начинается с `n`.
                        // и только уменьшается.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // БЕЗОПАСНОСТЬ: вызывающий должен гарантировать, что `i` находится в пределах
                // лежащий в основе слайс, поэтому `i` не может переполнять `isize`, а возвращаемые ссылки гарантированно ссылаются на элемент слайса и, таким образом, гарантированно являются действительными.
                //
                // Также обратите внимание, что вызывающая сторона также гарантирует, что мы больше никогда не вызываемся с тем же индексом и что никакие другие методы, которые будут обращаться к этому подслою, не будут вызваны, поэтому возвращенная ссылка может быть изменяемой в случае
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // можно реализовать с помощью срезов, но это позволяет избежать проверки границ

                // БЕЗОПАСНОСТЬ: вызовы `assume` безопасны, поскольку указатель начала среза не должен быть нулевым,
                // и срезы поверх не-ZST также должны иметь ненулевой конечный указатель.
                // Вызов `next_back_unchecked!` безопасен, поскольку мы сначала проверяем, пуст ли итератор.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Этот итератор теперь пуст.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // БЕЗОПАСНОСТЬ: Мы находимся в рамках.`pre_dec_end` подходит даже для ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}