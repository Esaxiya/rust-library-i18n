// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Поворачивает диапазон `[mid-left, mid+right)` таким образом, что элемент в `mid` становится первым элементом.Эквивалентно вращает элементы диапазона `left` влево или элементы `right` вправо.
///
/// # Safety
///
/// Указанный диапазон должен быть допустимым для чтения и записи.
///
/// # Algorithm
///
/// Алгоритм 1 используется для малых значений `left + right` или для больших `T`.
/// Элементы перемещаются в свои конечные позиции по одному, начиная с `mid - left` и продвигаясь на `right` шагов по модулю `left + right`, так что требуется только одно временное.
/// В конце концов, мы вернулись к `mid - left`.
/// Однако, если `gcd(left + right, right)` не 1, вышеуказанные шаги пропускают элементы.
/// Например:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// К счастью, количество пропущенных элементов между завершенными элементами всегда равно, поэтому мы можем просто сместить нашу начальную позицию и сделать больше раундов (общее количество раундов равно `gcd(left + right, right)` value).
///
/// Конечным результатом является то, что все элементы дорабатываются один раз и только один раз.
///
/// Алгоритм 2 используется, если `left + right` большой, но `min(left, right)` достаточно мал, чтобы поместиться в буфер стека.
/// Элементы `min(left, right)` копируются в буфер, `memmove` применяется к другим, а элементы в буфере перемещаются обратно в отверстие на противоположной стороне от того места, где они возникли.
///
/// Алгоритмы, которые можно векторизовать, превосходят вышеперечисленные, когда `left + right` становится достаточно большим.
/// Алгоритм 1 может быть векторизован путем разбиения на части и выполнения множества раундов одновременно, но в среднем слишком мало раундов, пока `left + right` не станет огромным, а наихудший случай одного раунда всегда присутствует.
/// Вместо этого алгоритм 3 использует повторяющуюся замену элементов `min(left, right)` до тех пор, пока не останется меньшая проблема поворота.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// когда `left < right`, замена происходит слева.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. приведенные ниже алгоритмы могут потерпеть неудачу, если эти случаи не проверены
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Тесты микробенчмарков Алгоритма 1 показывают, что средняя производительность для случайных сдвигов лучше примерно до `left + right == 32`, но в худшем случае производительность падает даже на отметке 16.
            // 24 был выбран как золотая середина.
            // Если размер `T` больше 4 `usize`s, этот алгоритм также превосходит другие алгоритмы.
            //
            //
            let x = unsafe { mid.sub(left) };
            // начало первого раунда
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` можно найти заранее, вычислив `gcd(left + right, right)`, но быстрее выполнить один цикл, который вычисляет gcd как побочный эффект, а затем выполнить остальную часть фрагмента
            //
            //
            let mut gcd = right;
            // тесты показывают, что быстрее полностью поменять местами временные вместо того, чтобы читать один временный файл один раз, копировать в обратном направлении, а затем записывать временное в самом конце.
            // Возможно, это связано с тем, что при подкачке или замене временных файлов в цикле используется только один адрес памяти вместо необходимости управлять двумя.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // вместо того, чтобы увеличивать `i` и затем проверять, выходит ли он за границы, мы проверяем, выйдет ли `i` за границы при следующем приращении.
                // Это предотвращает любой перенос указателей или `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // конец первого раунда
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // это условие должно быть здесь, если `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // закончить кусок большим количеством раундов
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` не является типом нулевого размера, поэтому можно делить на его размер.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Алгоритм 2 `[T; 0]` здесь должен гарантировать, что это правильно выровнено для T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Алгоритм 3 Существует альтернативный способ подкачки, который включает поиск, где будет последний своп этого алгоритма, и подкачку с использованием этого последнего фрагмента вместо перестановки соседних фрагментов, как это делает этот алгоритм, но этот способ все еще быстрее.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Алгоритм 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}