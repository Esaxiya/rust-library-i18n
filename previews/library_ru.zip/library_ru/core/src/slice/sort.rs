//! Сортировка срезов
//!
//! Этот модуль содержит алгоритм сортировки, основанный на быстрой сортировке Орсона Петерса по уничтожению шаблонов, опубликованной по адресу: <https://github.com/orlp/pdqsort>
//!
//!
//! Нестабильная сортировка совместима с libcore, потому что она не выделяет память, в отличие от нашей стабильной реализации сортировки.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// При сбросе копирует из `src` в `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // БЕЗОПАСНОСТЬ: Это вспомогательный класс.
        //          Пожалуйста, обратитесь к его использованию для правильности.
        //          А именно, нужно быть уверенным, что `src` и `dst` не перекрываются, как того требует `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Сдвигает первый элемент вправо, пока не встретит больший или равный элемент.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // БЕЗОПАСНОСТЬ: Описанные ниже небезопасные операции включают индексацию без проверки привязки (`get_unchecked` и `get_unchecked_mut`)
    // и копирование памяти (`ptr::copy_nonoverlapping`).
    //
    // а.Индексирование:
    //  1. Мы проверили размер массива на>=2.
    //  2. Вся индексация, которую мы будем делать, всегда будет между {0 <= index < len} максимум.
    //
    // б.Копирование памяти
    //  1. Мы получаем указатели на ссылки, которые гарантированно действительны.
    //  2. Они не могут перекрываться, потому что мы получаем указатели на разностные индексы среза.
    //     А именно `i` и `i-1`.
    //  3. Если срез выровнен правильно, элементы выровнены правильно.
    //     Ответственность за правильное выравнивание среза лежит на вызывающей стороне.
    //
    // См. Комментарии ниже для более подробной информации.
    unsafe {
        // Если первые два элемента вышли из строя ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Считайте первый элемент в переменную, размещенную в стеке.
            // Если следующая операция сравнения panics, `hole` будет отброшена и автоматически запишет элемент обратно в срез.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Переместите i-й элемент на одну позицию влево, сместив, таким образом, отверстие вправо.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` сбрасывается и, таким образом, копирует `tmp` в оставшееся отверстие в `v`.
        }
    }
}

/// Сдвигает последний элемент влево, пока не встретит меньший или равный элемент.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // БЕЗОПАСНОСТЬ: Описанные ниже небезопасные операции включают индексацию без проверки привязки (`get_unchecked` и `get_unchecked_mut`)
    // и копирование памяти (`ptr::copy_nonoverlapping`).
    //
    // а.Индексирование:
    //  1. Мы проверили размер массива на>=2.
    //  2. Вся индексация, которую мы будем делать, всегда будет между `0 <= index < len-1` максимум.
    //
    // б.Копирование памяти
    //  1. Мы получаем указатели на ссылки, которые гарантированно действительны.
    //  2. Они не могут перекрываться, потому что мы получаем указатели на разностные индексы среза.
    //     А именно `i` и `i+1`.
    //  3. Если срез выровнен правильно, элементы выровнены правильно.
    //     Ответственность за правильное выравнивание среза лежит на вызывающей стороне.
    //
    // См. Комментарии ниже для более подробной информации.
    unsafe {
        // Если последние два элемента вышли из строя ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Прочтите последний элемент в переменную, выделенную стеком.
            // Если следующая операция сравнения panics, `hole` будет отброшена и автоматически запишет элемент обратно в срез.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Переместите i-й элемент на одну позицию вправо, таким образом сместив отверстие влево.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` сбрасывается и, таким образом, копирует `tmp` в оставшееся отверстие в `v`.
        }
    }
}

/// Частично сортирует срез, перемещая несколько неупорядоченных элементов.
///
/// Возвращает `true`, если фрагмент отсортирован в конце.Эта функция-*O*(*n*) наихудший случай.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Максимальное количество смежных пар не по порядку, которые будут сдвинуты.
    const MAX_STEPS: usize = 5;
    // Если фрагмент короче этого, не сдвигайте никакие элементы.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // БЕЗОПАСНОСТЬ: Мы уже явно выполнили проверку привязки с `i < len`.
        // Вся наша последующая индексация только в диапазоне `0 <= index < len`
        unsafe {
            // Найдите следующую пару соседних вышедших из строя элементов.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Мы все?
        if i == len {
            return true;
        }

        // Не перемещайте элементы на короткие массивы, это снижает производительность.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Поменяйте местами найденную пару элементов.Это расставит их в правильном порядке.
        v.swap(i - 1, i);

        // Сдвиньте меньший элемент влево.
        shift_tail(&mut v[..i], is_less);
        // Сдвиньте больший элемент вправо.
        shift_head(&mut v[i..], is_less);
    }

    // Не удалось отсортировать срез за ограниченное количество шагов.
    false
}

/// Сортирует фрагмент с использованием сортировки вставкой, что является наихудшим случаем *O*(*n*^ 2).
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Сортировка `v` с использованием heapsort, что гарантирует наихудший случай *O*(*n*\*log(* n*)).
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Эта двоичная куча соблюдает инвариант `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Дети `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Выберите старшего ребенка.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Остановитесь, если инвариант сохраняется на `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Поменяйте местами `node` с большим потомком, переместитесь на одну ступень вниз и продолжайте просеивание.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Постройте кучу за линейное время.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Извлекать максимальные элементы из кучи.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Разбиение `v` на элементы, меньшие, чем `pivot`, за которыми следуют элементы, большие или равные `pivot`.
///
///
/// Возвращает количество элементов меньше `pivot`.
///
/// Разделение выполняется поблочно, чтобы минимизировать затраты на операции ветвления.
/// Эта идея представлена в статье [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Количество элементов в типичном блоке.
    const BLOCK: usize = 128;

    // Алгоритм разделения повторяет следующие шаги до завершения:
    //
    // 1. Обведите блок с левой стороны, чтобы определить элементы, которые больше или равны оси поворота.
    // 2. Обведите блок с правой стороны, чтобы определить элементы, меньшие, чем точка поворота.
    // 3. Поменяйте идентифицированные элементы между левой и правой стороной.
    //
    // Мы сохраняем следующие переменные для блока элементов:
    //
    // 1. `block` - Количество элементов в блоке.
    // 2. `start` - Указатель запуска в массив `offsets`.
    // 3. `end` - Конечный указатель в массив `offsets`.
    // 4. `offsets, индексы вышедших из строя элементов внутри блока.

    // Текущий блок слева (от `l` до `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Текущий блок справа (от `r.sub(block_r)` to `r`).
    // БЕЗОПАСНОСТЬ: В документации на .add() прямо упоминается, что `vec.as_ptr().add(vec.len())` всегда безопасен.
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Когда мы получим VLA, попробуйте создать один массив длиной `min(v.len(), 2 * BLOCK) `скорее
    // чем два массива фиксированного размера длиной `BLOCK`.VLA могут быть более эффективными с точки зрения кеширования.

    // Возвращает количество элементов между указателями `l` (inclusive) и `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Мы закончили с разбиением по блокам, когда `l` и `r` подойдут очень близко.
        // Затем мы выполняем некоторые работы по ремонту, чтобы разделить оставшиеся элементы между ними.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Количество оставшихся элементов (все еще не в сравнении с осью).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Отрегулируйте размеры блоков так, чтобы левый и правый блоки не перекрывали друг друга, а идеально выравнивались, чтобы покрыть весь оставшийся зазор.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Проследите элементы `block_l` с левой стороны.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // БЕЗОПАСНОСТЬ: Приведенные ниже небезопасные операции связаны с использованием `offset`.
                //         Согласно условиям, требуемым функцией, мы выполняем их, потому что:
                //         1. `offsets_l` выделяется стеком и поэтому считается отдельным выделенным объектом.
                //         2. Функция `is_less` возвращает `bool`.
                //            Кастинг `bool` никогда не переполнит `isize`.
                //         3. Мы гарантировали, что `block_l` будет `<= BLOCK`.
                //            Кроме того, `end_l` изначально был установлен на указатель начала `offsets_`, который был объявлен в стеке.
                //            Таким образом, мы знаем, что даже в худшем случае (все вызовы `is_less` возвращают false) мы пройдем не более 1 байта до конца.
                //        Еще одна небезопасная операция-разыменование `elem`.
                //        Однако изначально `elem` был начальным указателем на слайс, который всегда действителен.
                unsafe {
                    // Безответственное сравнение.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Проследите элементы `block_r` с правой стороны.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // БЕЗОПАСНОСТЬ: Приведенные ниже небезопасные операции связаны с использованием `offset`.
                //         Согласно условиям, требуемым функцией, мы выполняем их, потому что:
                //         1. `offsets_r` выделяется стеком и поэтому считается отдельным выделенным объектом.
                //         2. Функция `is_less` возвращает `bool`.
                //            Кастинг `bool` никогда не переполнит `isize`.
                //         3. Мы гарантировали, что `block_r` будет `<= BLOCK`.
                //            Кроме того, `end_r` изначально был установлен на указатель начала `offsets_`, который был объявлен в стеке.
                //            Таким образом, мы знаем, что даже в худшем случае (все вызовы `is_less` возвращают истину) мы пройдем не более 1 байта до конца.
                //        Еще одна небезопасная операция-разыменование `elem`.
                //        Однако `elem` изначально был `1 *sizeof(T)` за концом, и мы уменьшаем его на `1* sizeof(T)`, прежде чем обращаться к нему.
                //        Кроме того, было заявлено, что `block_r` меньше, чем `BLOCK`, и поэтому `elem` будет указывать максимум на начало среза.
                unsafe {
                    // Безответственное сравнение.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Количество неупорядоченных элементов для переключения между левой и правой стороной.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Вместо того, чтобы менять местами по одной паре за раз, более эффективно выполнять циклическую перестановку.
            // Это не строго эквивалентно замене местами, но дает аналогичный результат с меньшим количеством операций с памятью.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Все вышедшие из строя элементы в левом блоке были перемещены.Перейти к следующему блоку.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Все вышедшие из строя элементы в правом блоке были перемещены.Перейти к предыдущему блоку.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Все, что осталось,-это не более одного блока (правого или левого) с вышедшими из строя элементами, которые необходимо переместить.
    // Такие оставшиеся элементы можно просто сдвинуть до конца в пределах своего блока.
    //

    if start_l < end_l {
        // Остается левый блок.
        // Переместите оставшиеся не по порядку элементы в крайнее правое положение.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Правый блок остается.
        // Переместите оставшиеся не по порядку элементы в крайнее левое положение.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Больше нечего делать, мы закончили.
        width(v.as_mut_ptr(), l)
    }
}

/// Разбиение `v` на элементы, меньшие, чем `v[pivot]`, за которыми следуют элементы, большие или равные `v[pivot]`.
///
///
/// Возвращает кортеж из:
///
/// 1. Количество элементов меньше `v[pivot]`.
/// 2. Истинно, если `v` уже был разделен.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Поместите стержень в начало среза.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Считайте сводку в переменную, выделенную стеком, для повышения эффективности.
        // Если следующая операция сравнения panics, точка поворота будет автоматически записана обратно в срез.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Найдите первую пару вышедших из строя элементов.
        let mut l = 0;
        let mut r = v.len();

        // БЕЗОПАСНОСТЬ. Приведенная ниже информация о небезопасности связана с индексацией массива.
        // Для первого: мы уже проверяем границы здесь с `l < r`.
        // Для второго: изначально у нас есть `l == 0` и `r == v.len()`, и мы проверяли это `l < r` при каждой операции индексации.
        //                     Отсюда мы знаем, что `r` должен быть не ниже `r == l`, который, как было показано, действителен с первого раза.
        unsafe {
            // Найдите первый элемент, больший или равный оси поворота.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Найдите последний элемент, меньший, чем точка поворота.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` выходит за пределы области видимости и записывает сводную точку (которая представляет собой переменную, выделенную в стеке) обратно в срез, где она была изначально.
        // Этот шаг очень важен для обеспечения безопасности!
        //
    };

    // Поместите стержень между двумя перегородками.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Разбивает `v` на элементы, равные `v[pivot]`, за которыми следуют элементы больше `v[pivot]`.
///
/// Возвращает количество элементов, равное оси поворота.
/// Предполагается, что `v` не содержит элементов меньше стержня.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Поместите стержень в начало среза.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Считайте сводку в переменную, выделенную стеком, для повышения эффективности.
    // Если следующая операция сравнения panics, точка поворота будет автоматически записана обратно в срез.
    // БЕЗОПАСНОСТЬ: указатель здесь действителен, потому что он получен из ссылки на срез.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Теперь разделите кусок.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // БЕЗОПАСНОСТЬ. Приведенная ниже информация о небезопасности связана с индексацией массива.
        // Для первого: мы уже проверяем границы здесь с `l < r`.
        // Для второго: изначально у нас есть `l == 0` и `r == v.len()`, и мы проверяли это `l < r` при каждой операции индексации.
        //                     Отсюда мы знаем, что `r` должен быть не ниже `r == l`, который, как было показано, действителен с первого раза.
        unsafe {
            // Найдите первый элемент больше оси поворота.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Найдите последний элемент, равный оси поворота.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Мы все?
            if l >= r {
                break;
            }

            // Поменять местами найденную пару вышедших из строя элементов.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Мы нашли элементы `l`, равные оси поворота.Добавьте 1, чтобы учесть сам поворот.
    l + 1

    // `_pivot_guard` выходит за пределы области видимости и записывает сводную точку (которая представляет собой переменную, выделенную в стеке) обратно в срез, где она была изначально.
    // Этот шаг очень важен для обеспечения безопасности!
}

/// Разбрасывает некоторые элементы, пытаясь сломать шаблоны, которые могут вызвать несбалансированные разделы в быстрой сортировке.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Генератор псевдослучайных чисел из статьи "Xorshift RNGs" Джорджа Марсальи.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Возьмите случайные числа по модулю этого числа.
        // Номер подходит к `usize`, потому что `len` не больше `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Некоторые кандидаты на разворот будут рядом с этим индексом.Давайте рандомизируем их.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Сгенерируйте случайное число по модулю `len`.
            // Однако, чтобы избежать дорогостоящих операций, мы сначала берем его по модулю двойки, а затем уменьшаем на `len`, пока он не попадет в диапазон `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` гарантированно будет меньше `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Выбирает точку поворота в `v` и возвращает индекс и `true`, если срез, вероятно, уже отсортирован.
///
/// Элементы в `v` могут быть переупорядочены в процессе.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Минимальная длина для выбора метода медианы медиан.
    // Для более коротких срезов используется простой метод медианы трех.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Максимальное количество свопов, которое может быть выполнено в этой функции.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Три индекса, возле которых мы будем выбирать точку разворота.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Подсчитывает общее количество свопов, которые мы собираемся выполнить при сортировке индексов.
    let mut swaps = 0;

    if len >= 8 {
        // Поменять местами индексы так, чтобы `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Поменять местами индексы так, чтобы `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Находит медиану `v[a - 1], v[a], v[a + 1]` и сохраняет индекс в `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Найдите медианы в окрестностях `a`, `b` и `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Найдите медиану между `a`, `b` и `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Произведено максимальное количество свопов.
        // Скорее всего, срез нисходящий или в основном нисходящий, поэтому реверсирование, вероятно, поможет отсортировать его быстрее.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Рекурсивно сортирует `v`.
///
/// Если у среза был предшественник в исходном массиве, он указывается как `pred`.
///
/// `limit` - количество допустимых несбалансированных разделов до переключения на `heapsort`.
/// Если ноль, эта функция немедленно переключится на heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Срезы до этой длины сортируются с помощью сортировки вставкой.
    const MAX_INSERTION: usize = 20;

    // Верно, если последнее разбиение было разумно сбалансированным.
    let mut was_balanced = true;
    // Истинно, если при последнем разбиении элементы не перемешивались (срез уже был разбит на разделы).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Очень короткие фрагменты сортируются с помощью сортировки вставкой.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Если было сделано слишком много неправильных опорных точек, просто вернитесь к heapsort, чтобы гарантировать `O(n * log(n))` наихудший случай.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Если последнее разделение было несбалансированным, попробуйте разбить шаблоны в срезе, перетасовывая некоторые элементы.
        // Надеюсь, на этот раз мы выберем более удачный поворот.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Выберите точку поворота и попробуйте угадать, отсортирован ли уже фрагмент.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Если последнее разбиение было прилично сбалансировано и элементы не перемешивались, и если выбор сводной таблицы предсказывает, срез, вероятно, уже отсортирован ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Попробуйте определить несколько вышедших из строя элементов и переставить их на правильные позиции.
            // Если срез оказывается полностью отсортированным, все готово.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Если выбранная точка поворота равна предыдущей, то это наименьший элемент в срезе.
        // Разделите срез на элементы, равные и более крупные, чем точка поворота.
        // Этот случай обычно возникает, когда срез содержит много повторяющихся элементов.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Продолжайте сортировать элементы больше точки поворота.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Разделите ломтик.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Разделите срез на `left`, `pivot` и `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Выполняйте рекурсию на более короткую сторону только для того, чтобы минимизировать общее количество рекурсивных вызовов и потреблять меньше места в стеке.
        // Затем просто продолжайте с более длинной стороны (это похоже на хвостовую рекурсию).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Сортировка `v` с использованием быстрой сортировки с устранением шаблонов, что соответствует *O*(*n*\*log(* n*)) в худшем случае.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Сортировка не имеет значимого поведения для типов нулевого размера.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Ограничьте количество несбалансированных разделов до `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Для фрагментов до этой длины, вероятно, быстрее просто их отсортировать.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Выберите точку опоры
        let (pivot, _) = choose_pivot(v, is_less);

        // Если выбранная точка поворота равна предыдущей, то это наименьший элемент в срезе.
        // Разделите срез на элементы, равные и более крупные, чем точка поворота.
        // Этот случай обычно возникает, когда срез содержит много повторяющихся элементов.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Если мы прошли наш индекс, значит, все в порядке.
                if mid > index {
                    return;
                }

                // В противном случае продолжайте сортировку элементов больше, чем точка поворота.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Разделите срез на `left`, `pivot` и `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Если mid==index, то все готово, поскольку partition() гарантирует, что все элементы после mid больше или равны mid.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Сортировка не имеет значимого поведения для типов нулевого размера.Ничего не делать.
    } else if index == v.len() - 1 {
        // Найдите максимальный элемент и поместите его в последнюю позицию массива.
        // Здесь мы можем использовать `unwrap()`, потому что знаем, что v не должно быть пустым.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Найдите элемент min и поместите его в первую позицию массива.
        // Здесь мы можем использовать `unwrap()`, потому что знаем, что v не должно быть пустым.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}