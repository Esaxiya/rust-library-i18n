//! Операции с ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Проверяет, все ли байты в этом фрагменте находятся в диапазоне ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Проверяет, совпадают ли два фрагмента без учета регистра в кодировке ASCII.
    ///
    /// То же, что `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, но без выделения и копирования временных файлов.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Преобразует этот фрагмент в его эквивалент в верхнем регистре ASCII на месте.
    ///
    /// Буквы ASCII с 'a' по 'z' отображаются в 'A' в 'Z', но не-ASCII буквы не меняются.
    ///
    /// Чтобы вернуть новое значение в верхнем регистре без изменения существующего, используйте [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Преобразует этот фрагмент в его эквивалент в нижнем регистре ASCII на месте.
    ///
    /// Буквы ASCII с 'A' по 'Z' отображаются в 'a' в 'z', но не-ASCII буквы не меняются.
    ///
    /// Чтобы вернуть новое значение в нижнем регистре без изменения существующего, используйте [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Возвращает `true`, если какой-либо байт в слове `v` является nonascii (>=128).
/// Снарфирован от `../str/mod.rs`, который делает нечто подобное для проверки utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Оптимизированный тест ASCII, который будет использовать операции использования за раз вместо операций побайтно (когда это возможно).
///
/// Алгоритм, который мы здесь используем, довольно прост.Если `s` слишком короткий, мы просто проверяем каждый байт и покончим с этим.Иначе:
///
/// - Прочтите первое слово с невыровненной нагрузкой.
/// - Выровняйте указатель, прочитайте последующие слова до конца с выровненными нагрузками.
/// - Считайте последний `usize` из `s` с невыровненной нагрузкой.
///
/// Если какая-либо из этих нагрузок производит что-то, для чего `contains_nonascii` (above) возвращает истину, то мы знаем, что ответ ложный.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Если мы ничего не выиграем от поэтапной реализации, вернитесь к скалярному циклу.
    //
    // Мы также делаем это для архитектур, где `size_of::<usize>()` недостаточно согласован с `usize`, потому что это странный случай edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Мы всегда читаем первое слово без выравнивания, что означает, что `align_offset`
    // 0, мы снова прочитаем то же значение для выровненного чтения.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // БЕЗОПАСНОСТЬ: Мы проверяем `len < USIZE_SIZE` выше.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Мы проверили это выше, хотя и неявно.
    // Обратите внимание, что `offset_to_aligned`-это либо `align_offset`, либо `USIZE_SIZE`, оба из которых явно отмечены выше.
    //
    debug_assert!(offset_to_aligned <= len);

    // БЕЗОПАСНОСТЬ: word_ptr-это (правильно выровненный) usize ptr, который мы используем для чтения
    // средний кусок ломтика.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` - это байтовый индекс `word_ptr`, используемый для проверок конца цикла.
    let mut byte_pos = offset_to_aligned;

    // Паранойя проверка выравнивания, так как мы собираемся выполнить кучу невыровненных нагрузок.
    // На практике это должно быть невозможно, если не считать ошибки в `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Прочтите последующие слова до последнего выровненного слова, исключая последнее выровненное слово, которое будет выполнено позже при проверке хвоста, чтобы убедиться, что хвост всегда равен максимум от одного `usize` до дополнительного branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Проверка работоспособности, что чтение находится в пределах
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // И что наши предположения относительно `byte_pos` остаются в силе.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // БЕЗОПАСНОСТЬ: Мы знаем, что `word_ptr` правильно выровнен (из-за
        // `align_offset`), и мы знаем, что у нас достаточно байтов между `word_ptr` и концом
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // БЕЗОПАСНОСТЬ: Мы знаем, что `byte_pos <= len - USIZE_SIZE`, а это значит, что
        // после этого `add`, `word_ptr` будет не более чем один за концом.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Проверка работоспособности, чтобы убедиться, что действительно остался только один `usize`.
    // Это должно быть гарантировано нашим условием цикла.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // БЕЗОПАСНОСТЬ: это зависит от `len >= USIZE_SIZE`, который мы проверяем с самого начала.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}