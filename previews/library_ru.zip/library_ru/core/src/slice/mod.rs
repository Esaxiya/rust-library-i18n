// ignore-tidy-filelength

//! Управление срезами и манипуляции с ними.
//!
//! Подробнее см. [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Чистая реализация memchr rust, взятая из rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Эта функция является общедоступной только потому, что нет другого способа динамической сортировки модульного теста.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Возвращает количество элементов в срезе.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // БЕЗОПАСНОСТЬ: звук const, потому что мы преобразуем поле длины как значение usize (которое должно быть)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // БЕЗОПАСНОСТЬ: это безопасно, потому что `&[T]` и `FatPtr<T>` имеют одинаковую компоновку.
            // Только `std` может дать эту гарантию.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Замените на `crate::ptr::metadata(self)`, когда он станет стабильным.
            // На момент написания этой статьи это вызывает ошибку "Const-stable functions can only call other const-stable functions".
            //

            // БЕЗОПАСНОСТЬ: доступ к значению из объединения `PtrRepr` безопасен, поскольку * const T
            // и PtrComponents<T>имеют одинаковые схемы памяти.
            // Только std может дать эту гарантию.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Возвращает `true`, если длина среза равна 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Возвращает первый элемент среза или `None`, если он пуст.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Возвращает изменяемый указатель на первый элемент среза или `None`, если он пуст.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Возвращает первый и все остальные элементы среза или `None`, если он пуст.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Возвращает первый и все остальные элементы среза или `None`, если он пуст.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Возвращает последний и все остальные элементы среза или `None`, если он пуст.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Возвращает последний и все остальные элементы среза или `None`, если он пуст.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Возвращает последний элемент среза или `None`, если он пуст.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Возвращает изменяемый указатель на последний элемент в срезе.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Возвращает ссылку на элемент или подсрез в зависимости от типа индекса.
    ///
    /// - Если задана позиция, возвращает ссылку на элемент в этой позиции или `None`, если она выходит за пределы.
    ///
    /// - Если задан диапазон, возвращает подсрез, соответствующий этому диапазону, или `None`, если он выходит за границы.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Возвращает изменяемую ссылку на элемент или подсрез в зависимости от типа индекса (см. [`get`]) или `None`, если индекс выходит за границы.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Возвращает ссылку на элемент или подсрез без проверки границ.
    ///
    /// Для безопасной альтернативы см. [`get`].
    ///
    /// # Safety
    ///
    /// Вызов этого метода с индексом за пределами диапазона-это *[неопределенное поведение]*, даже если результирующая ссылка не используется.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // БЕЗОПАСНОСТЬ: вызывающий абонент должен соблюдать большинство требований безопасности для `get_unchecked`;
        // срез можно разыменовать, потому что `self` является безопасным эталоном.
        // Возвращаемый указатель безопасен, потому что имплицитные `SliceIndex` должны гарантировать, что это так.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Возвращает изменяемую ссылку на элемент или подсрез без проверки границ.
    ///
    /// Для безопасной альтернативы см. [`get_mut`].
    ///
    /// # Safety
    ///
    /// Вызов этого метода с индексом за пределами диапазона-это *[неопределенное поведение]*, даже если результирующая ссылка не используется.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // БЕЗОПАСНОСТЬ: вызывающий абонент должен соблюдать требования безопасности для `get_unchecked_mut`;
        // срез можно разыменовать, потому что `self` является безопасным эталоном.
        // Возвращаемый указатель безопасен, потому что имплицитные `SliceIndex` должны гарантировать, что это так.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Возвращает необработанный указатель на буфер среза.
    ///
    /// Вызывающий должен убедиться, что срез пережил указатель, возвращаемый этой функцией, иначе он в конечном итоге укажет на мусор.
    ///
    /// Вызывающий должен также гарантировать, что память, на которую указывает указатель (non-transitively), никогда не записывается (кроме как внутри `UnsafeCell`) с использованием этого указателя или любого указателя, производного от него.
    /// Если вам нужно изменить содержимое фрагмента, используйте [`as_mut_ptr`].
    ///
    /// Изменение контейнера, на который ссылается этот фрагмент, может привести к перераспределению его буфера, что также сделает любые указатели на него недействительными.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Возвращает небезопасный изменяемый указатель на буфер фрагмента.
    ///
    /// Вызывающий должен убедиться, что срез пережил указатель, возвращаемый этой функцией, иначе он в конечном итоге укажет на мусор.
    ///
    /// Изменение контейнера, на который ссылается этот фрагмент, может привести к перераспределению его буфера, что также сделает любые указатели на него недействительными.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Возвращает два необработанных указателя, охватывающих срез.
    ///
    /// Возвращаемый диапазон является полуоткрытым, что означает, что конечный указатель указывает на *один за* последний элемент среза.
    /// Таким образом, пустой срез представлен двумя равными указателями, а разница между двумя указателями представляет размер среза.
    ///
    /// См. Предупреждения об использовании этих указателей на [`as_ptr`].Конечный указатель требует особой осторожности, поскольку он не указывает на допустимый элемент в срезе.
    ///
    /// Эта функция полезна для взаимодействия с внешними интерфейсами, которые используют два указателя для ссылки на диапазон элементов в памяти, как это часто бывает в C++ .
    ///
    ///
    /// Также может быть полезно проверить, ссылается ли указатель на элемент на элемент этого среза:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // БЕЗОПАСНОСТЬ: `add` здесь безопасен, потому что:
        //
        //   - Оба указателя являются частью одного и того же объекта, так как указание непосредственно мимо объекта также считается.
        //
        //   - Размер среза никогда не превышает isize::MAX байтов, как указано здесь:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Обертывания не требуется, так как срезы не охватывают конец адресного пространства.
        //
        // См. Документацию pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Возвращает два небезопасных изменяемых указателя, охватывающих срез.
    ///
    /// Возвращаемый диапазон является полуоткрытым, что означает, что конечный указатель указывает на *один за* последний элемент среза.
    /// Таким образом, пустой срез представлен двумя равными указателями, а разница между двумя указателями представляет размер среза.
    ///
    /// См. Предупреждения об использовании этих указателей на [`as_mut_ptr`].
    /// Конечный указатель требует особой осторожности, поскольку он не указывает на допустимый элемент в срезе.
    ///
    /// Эта функция полезна для взаимодействия с внешними интерфейсами, которые используют два указателя для ссылки на диапазон элементов в памяти, как это часто бывает в C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // БЕЗОПАСНОСТЬ: См. as_ptr_range() выше, чтобы узнать, почему `add` здесь безопасен.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Меняет местами два элемента в срезе.
    ///
    /// # Arguments
    ///
    /// * a, индекс первого элемента
    /// * b, индекс второго элемента
    ///
    /// # Panics
    ///
    /// Panics, если `a` или `b` находятся за пределами поля.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Невозможно взять два изменяемых займа от одного vector, поэтому вместо этого используйте необработанные указатели.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // БЕЗОПАСНОСТЬ: `pa` и `pb` были созданы из безопасных изменяемых ссылок и относятся к
        // элементам в срезе и поэтому гарантированно действительны и выровнены.
        // Обратите внимание, что доступ к элементам за `a` и `b` отмечен и будет panic при выходе за границы.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Изменяет порядок элементов в срезе на место.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Для очень маленьких типов все отдельные операции чтения в обычном пути выполняются плохо.
        // Мы можем добиться большего, учитывая эффективный невыровненный load/store, загрузив кусок большего размера и изменив регистр.
        //

        // В идеале LLVM сделает это за нас, поскольку он лучше нас знает, эффективны ли невыровненные операции чтения (например, поскольку это меняется между разными версиями ARM) и каков будет наилучший размер блока.
        // К сожалению, в LLVM 4.0 (2017-05) он только разворачивает цикл, поэтому нам нужно сделать это самим.
        // (Гипотеза: обратное вызывает проблемы, потому что стороны могут быть выровнены по-разному-будет, когда длина нечетная-поэтому нет способа испускать пре-и постлюдии для использования полностью выровненного SIMD в середине.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Используйте внутреннюю функцию llvm.bswap, чтобы перевернуть u8s в usize
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // БЕЗОПАСНОСТЬ: Здесь необходимо проверить несколько вещей:
                //
                // - Обратите внимание, что `chunk` равен 4 или 8 из-за проверки cfg выше.Значит, `chunk - 1` положительный.
                // - Индексирование с индексом `i` в порядке, поскольку проверка цикла гарантирует
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Индексирование с индексом `ln - i - chunk = ln - (i + chunk)` в порядке:
                //   - `i + chunk > 0` тривиально верно.
                //   - Проверка цикла гарантирует:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, поэтому при вычитании не происходит потери значимости.
                // - Звонки `read_unaligned` и `write_unaligned` в порядке:
                //   - `pa` указывает на индекс `i`, где `i < ln / 2 - (chunk - 1)` (см. выше) и `pb` указывает на индекс `ln - i - chunk`, так что оба находятся на расстоянии не менее `chunk` на много байтов от конца `self`.
                //
                //   - Любая инициализированная память допустима `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Используйте поворот на 16, чтобы перевернуть u16 в u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // БЕЗОПАСНОСТЬ: невыровненный u32 может быть прочитан из `i`, если `i + 1 < ln`
                // (и, очевидно, `i < ln`), потому что каждый элемент составляет 2 байта, а мы читаем 4.
                //
                // `i + chunk - 1 < ln / 2` # в то время как условие
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Поскольку он меньше длины, деленной на 2, значит, он должен быть в пределах.
                //
                // Это также означает, что условие `0 < i + chunk <= ln` всегда соблюдается, обеспечивая безопасное использование указателя `pb`.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // БЕЗОПАСНОСТЬ: `i` меньше половины длины ломтика, поэтому
            // доступ к `i` и `ln - i - 1` безопасен (`i` начинается с 0 и не идет дальше `ln / 2 - 1`).
            // Таким образом, результирующие указатели `pa` и `pb` действительны и выровнены, и их можно читать и записывать.
            //
            //
            unsafe {
                // Небезопасный своп, чтобы избежать проверки границ в безопасном свопе.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Возвращает итератор по срезу.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Возвращает итератор, позволяющий изменять каждое значение.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Возвращает итератор по всем непрерывным windows длины `size`.
    /// windows перекрываются.
    /// Если срез короче `size`, итератор не возвращает значений.
    ///
    /// # Panics
    ///
    /// Panics, если `size` равен 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Если срез короче `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Возвращает итератор по `chunk_size` элементам среза за раз, начиная с начала среза.
    ///
    /// Куски представляют собой кусочки и не перекрываются.Если `chunk_size` не делит длину фрагмента, то последний фрагмент не будет иметь длины `chunk_size`.
    ///
    /// См. В [`chunks_exact`] вариант этого итератора, который всегда возвращает фрагменты, состоящие из ровно `chunk_size` элементов, и [`rchunks`] для того же итератора, но начиная с конца среза.
    ///
    ///
    /// # Panics
    ///
    /// Panics, если `chunk_size` равен 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Возвращает итератор по `chunk_size` элементам среза за раз, начиная с начала среза.
    ///
    /// Эти фрагменты являются изменяемыми фрагментами и не перекрываются.Если `chunk_size` не делит длину фрагмента, то последний фрагмент не будет иметь длины `chunk_size`.
    ///
    /// См. В [`chunks_exact_mut`] вариант этого итератора, который всегда возвращает фрагменты, состоящие из ровно `chunk_size` элементов, и [`rchunks_mut`] для того же итератора, но начиная с конца среза.
    ///
    ///
    /// # Panics
    ///
    /// Panics, если `chunk_size` равен 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Возвращает итератор по `chunk_size` элементам среза за раз, начиная с начала среза.
    ///
    /// Куски представляют собой кусочки и не перекрываются.
    /// Если `chunk_size` не делит длину среза, то последние элементы до `chunk_size-1` будут опущены и могут быть получены из функции `remainder` итератора.
    ///
    ///
    /// Поскольку каждый фрагмент содержит ровно `chunk_size` элементов, компилятор часто может оптимизировать результирующий код лучше, чем в случае [`chunks`].
    ///
    /// См. [`chunks`] для варианта этого итератора, который также возвращает остаток в виде меньшего фрагмента, и [`rchunks_exact`] для того же итератора, но начиная с конца фрагмента.
    ///
    /// # Panics
    ///
    /// Panics, если `chunk_size` равен 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Возвращает итератор по `chunk_size` элементам среза за раз, начиная с начала среза.
    ///
    /// Эти фрагменты являются изменяемыми фрагментами и не перекрываются.
    /// Если `chunk_size` не делит длину среза, то последние элементы до `chunk_size-1` будут опущены и могут быть получены из функции `into_remainder` итератора.
    ///
    ///
    /// Поскольку каждый фрагмент содержит ровно `chunk_size` элементов, компилятор часто может оптимизировать результирующий код лучше, чем в случае [`chunks_mut`].
    ///
    /// См. [`chunks_mut`] для варианта этого итератора, который также возвращает остаток в виде меньшего фрагмента, и [`rchunks_exact_mut`] для того же итератора, но начиная с конца фрагмента.
    ///
    /// # Panics
    ///
    /// Panics, если `chunk_size` равен 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Разделяет срез на срез массивов из N элементов, предполагая, что остатка нет.
    ///
    ///
    /// # Safety
    ///
    /// Это может быть вызвано только тогда, когда
    /// - Срез точно разделяется на блоки из N элементов (также известные как `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // БЕЗОПАСНОСТЬ: куски из 1 элемента никогда не имеют остатка
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // БЕЗОПАСНОСТЬ: длина среза (6) кратна 3.
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Это было бы неправильно:
    /// // пусть куски: &[[_;5]]= slice.as_chunks_unchecked()//Длина среза не кратна 5 let chunks:&[[_;0]]= slice.as_chunks_unchecked()//Чанки нулевой длины запрещены
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // БЕЗОПАСНОСТЬ: Нашим предварительным условием является именно то, что нужно, чтобы назвать это
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // БЕЗОПАСНОСТЬ: Мы вставляем часть элементов `new_len * N` в
        // фрагмент `new_len`, множество фрагментов элементов `N`.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Разделяет срез на срез массивов из N элементов, начиная с начала среза, и оставшийся срез с длиной строго меньше `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, если `N` равен 0. Эта проверка, скорее всего, будет заменена ошибкой времени компиляции до того, как этот метод стабилизируется.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // БЕЗОПАСНОСТЬ: Мы уже запаниковали до нуля и обеспечены строительством
        // что длина подсреза кратна N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Разделяет срез на срез массивов `N` элементов, начиная с конца среза, и оставшийся срез с длиной строго меньше `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, если `N` равен 0. Эта проверка, скорее всего, будет заменена ошибкой времени компиляции до того, как этот метод стабилизируется.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // БЕЗОПАСНОСТЬ: Мы уже запаниковали до нуля и обеспечены строительством
        // что длина подсреза кратна N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Возвращает итератор по `N` элементам среза за раз, начиная с начала среза.
    ///
    /// Чанки являются ссылками на массивы и не перекрываются.
    /// Если `N` не делит длину среза, то последние элементы до `N-1` будут опущены и могут быть получены из функции `remainder` итератора.
    ///
    ///
    /// Этот метод является универсальным эквивалентом [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics, если `N` равен 0. Эта проверка, скорее всего, будет заменена ошибкой времени компиляции до того, как этот метод стабилизируется.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Разделяет срез на срез массивов из N элементов, предполагая, что остатка нет.
    ///
    ///
    /// # Safety
    ///
    /// Это может быть вызвано только тогда, когда
    /// - Срез точно разделяется на блоки из N элементов (также известные как `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // БЕЗОПАСНОСТЬ: куски из 1 элемента никогда не имеют остатка
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // БЕЗОПАСНОСТЬ: длина среза (6) кратна 3.
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Это было бы неправильно:
    /// // пусть куски: &[[_;5]]= slice.as_chunks_unchecked_mut()//Длина среза не кратна 5 let chunks:&[[_;0]]= slice.as_chunks_unchecked_mut()//Чанки нулевой длины запрещены
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // БЕЗОПАСНОСТЬ: Нашим предварительным условием является именно то, что нужно, чтобы назвать это
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // БЕЗОПАСНОСТЬ: Мы вставляем часть элементов `new_len * N` в
        // фрагмент `new_len`, множество фрагментов элементов `N`.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Разделяет срез на срез массивов из N элементов, начиная с начала среза, и оставшийся срез с длиной строго меньше `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, если `N` равен 0. Эта проверка, скорее всего, будет заменена ошибкой времени компиляции до того, как этот метод стабилизируется.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // БЕЗОПАСНОСТЬ: Мы уже запаниковали до нуля и обеспечены строительством
        // что длина подсреза кратна N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Разделяет срез на срез массивов `N` элементов, начиная с конца среза, и оставшийся срез с длиной строго меньше `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, если `N` равен 0. Эта проверка, скорее всего, будет заменена ошибкой времени компиляции до того, как этот метод стабилизируется.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // БЕЗОПАСНОСТЬ: Мы уже запаниковали до нуля и обеспечены строительством
        // что длина подсреза кратна N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Возвращает итератор по `N` элементам среза за раз, начиная с начала среза.
    ///
    /// Чанки являются изменяемыми ссылками на массивы и не перекрываются.
    /// Если `N` не делит длину среза, то последние элементы до `N-1` будут опущены и могут быть получены из функции `into_remainder` итератора.
    ///
    ///
    /// Этот метод является универсальным эквивалентом [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics, если `N` равен 0. Эта проверка, скорее всего, будет заменена ошибкой времени компиляции до того, как этот метод стабилизируется.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Возвращает итератор поверх перекрывающихся windows элементов `N` фрагмента, начиная с начала фрагмента.
    ///
    ///
    /// Это общий эквивалент константы [`windows`].
    ///
    /// Если `N` больше размера среза, он не вернет windows.
    ///
    /// # Panics
    ///
    /// Panics, если `N` равен 0.
    /// Эта проверка, скорее всего, будет заменена ошибкой времени компиляции до того, как этот метод стабилизируется.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Возвращает итератор по `chunk_size` элементам среза за раз, начиная с конца среза.
    ///
    /// Куски представляют собой кусочки и не перекрываются.Если `chunk_size` не делит длину фрагмента, то последний фрагмент не будет иметь длины `chunk_size`.
    ///
    /// См. В [`rchunks_exact`] вариант этого итератора, который всегда возвращает фрагменты, состоящие из ровно `chunk_size` элементов, и [`chunks`] для того же итератора, но начиная с начала среза.
    ///
    ///
    /// # Panics
    ///
    /// Panics, если `chunk_size` равен 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Возвращает итератор по `chunk_size` элементам среза за раз, начиная с конца среза.
    ///
    /// Эти фрагменты являются изменяемыми фрагментами и не перекрываются.Если `chunk_size` не делит длину фрагмента, то последний фрагмент не будет иметь длины `chunk_size`.
    ///
    /// См. В [`rchunks_exact_mut`] вариант этого итератора, который всегда возвращает фрагменты, состоящие из ровно `chunk_size` элементов, и [`chunks_mut`] для того же итератора, но начиная с начала среза.
    ///
    ///
    /// # Panics
    ///
    /// Panics, если `chunk_size` равен 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Возвращает итератор по `chunk_size` элементам среза за раз, начиная с конца среза.
    ///
    /// Куски представляют собой кусочки и не перекрываются.
    /// Если `chunk_size` не делит длину среза, то последние элементы до `chunk_size-1` будут опущены и могут быть получены из функции `remainder` итератора.
    ///
    /// Поскольку каждый фрагмент содержит ровно `chunk_size` элементов, компилятор часто может оптимизировать результирующий код лучше, чем в случае [`chunks`].
    ///
    /// См. [`rchunks`] для варианта этого итератора, который также возвращает остаток в виде меньшего фрагмента, и [`chunks_exact`] для того же итератора, но начиная с начала фрагмента.
    ///
    ///
    /// # Panics
    ///
    /// Panics, если `chunk_size` равен 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Возвращает итератор по `chunk_size` элементам среза за раз, начиная с конца среза.
    ///
    /// Эти фрагменты являются изменяемыми фрагментами и не перекрываются.
    /// Если `chunk_size` не делит длину среза, то последние элементы до `chunk_size-1` будут опущены и могут быть получены из функции `into_remainder` итератора.
    ///
    /// Поскольку каждый фрагмент содержит ровно `chunk_size` элементов, компилятор часто может оптимизировать результирующий код лучше, чем в случае [`chunks_mut`].
    ///
    /// См. [`rchunks_mut`] для варианта этого итератора, который также возвращает остаток в виде меньшего фрагмента, и [`chunks_exact_mut`] для того же итератора, но начиная с начала фрагмента.
    ///
    ///
    /// # Panics
    ///
    /// Panics, если `chunk_size` равен 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Возвращает итератор по срезу, создавая неперекрывающиеся серии элементов, используя предикат для их разделения.
    ///
    /// Предикат вызывается для двух следующих за собой элементов, это означает, что предикат вызывается на `slice[0]` и `slice[1]`, затем на `slice[1]`, `slice[2]` и так далее.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Этот метод можно использовать для извлечения отсортированных фрагментов:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Возвращает итератор по срезу, создавая неперекрывающиеся изменяемые серии элементов, используя предикат для их разделения.
    ///
    /// Предикат вызывается для двух следующих за собой элементов, это означает, что предикат вызывается на `slice[0]` и `slice[1]`, затем на `slice[1]`, `slice[2]` и так далее.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Этот метод можно использовать для извлечения отсортированных фрагментов:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Делит один фрагмент на два по индексу.
    ///
    /// Первый будет содержать все индексы из `[0, mid)` (за исключением самого индекса `mid`), а второй будет содержать все индексы из `[mid, len)` (за исключением самого индекса `len`).
    ///
    ///
    /// # Panics
    ///
    /// Panics, если `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // БЕЗОПАСНОСТЬ: `[ptr; mid]` и `[mid; len]` находятся внутри `self`, что
        // соответствует требованиям `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Делит один изменяемый фрагмент на два по индексу.
    ///
    /// Первый будет содержать все индексы из `[0, mid)` (за исключением самого индекса `mid`), а второй будет содержать все индексы из `[mid, len)` (за исключением самого индекса `len`).
    ///
    ///
    /// # Panics
    ///
    /// Panics, если `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // БЕЗОПАСНОСТЬ: `[ptr; mid]` и `[mid; len]` находятся внутри `self`, что
        // соответствует требованиям `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Делит один фрагмент на два по индексу без проверки границ.
    ///
    /// Первый будет содержать все индексы из `[0, mid)` (за исключением самого индекса `mid`), а второй будет содержать все индексы из `[mid, len)` (за исключением самого индекса `len`).
    ///
    ///
    /// Для безопасной альтернативы см. [`split_at`].
    ///
    /// # Safety
    ///
    /// Вызов этого метода с индексом за пределами диапазона-это *[неопределенное поведение]*, даже если результирующая ссылка не используется.Вызывающий должен убедиться, что `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // БЕЗОПАСНОСТЬ: вызывающий абонент должен проверить, что `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Делит один изменяемый фрагмент на два по индексу без проверки границ.
    ///
    /// Первый будет содержать все индексы из `[0, mid)` (за исключением самого индекса `mid`), а второй будет содержать все индексы из `[mid, len)` (за исключением самого индекса `len`).
    ///
    ///
    /// Для безопасной альтернативы см. [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Вызов этого метода с индексом за пределами диапазона-это *[неопределенное поведение]*, даже если результирующая ссылка не используется.Вызывающий должен убедиться, что `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // БЕЗОПАСНОСТЬ: вызывающий абонент должен проверить, что `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` и `[mid; len]` не перекрываются, поэтому возвращать изменяемую ссылку можно.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Возвращает итератор для фрагментов, разделенных элементами, соответствующими `pred`.
    /// Соответствующий элемент не содержится в фрагментах.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Если первый элемент совпадает, пустой срез будет первым элементом, возвращаемым итератором.
    /// Точно так же, если последний элемент в срезе совпадает, пустой срез будет последним элементом, возвращаемым итератором:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Если два совпадающих элемента непосредственно смежны, между ними будет пустой срез:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Возвращает итератор по изменяемым фрагментам, разделенным элементами, соответствующими `pred`.
    /// Соответствующий элемент не содержится в фрагментах.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Возвращает итератор для фрагментов, разделенных элементами, соответствующими `pred`.
    /// Соответствующий элемент содержится в конце предыдущего фрагмента как терминатор.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Если последний элемент среза совпадает, этот элемент будет считаться ограничителем предыдущего среза.
    ///
    /// Этот фрагмент будет последним элементом, возвращаемым итератором.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Возвращает итератор по изменяемым фрагментам, разделенным элементами, соответствующими `pred`.
    /// Соответствующий элемент содержится в предыдущем фрагменте как терминатор.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Возвращает итератор для фрагментов, разделенных элементами, соответствующими `pred`, начиная с конца фрагмента и работая в обратном направлении.
    /// Соответствующий элемент не содержится в фрагментах.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Как и в случае с `split()`, если совпадают первый или последний элемент, пустой срез будет первым (или последним) элементом, возвращаемым итератором.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Возвращает итератор по изменяемым фрагментам, разделенным элементами, соответствующими `pred`, начиная с конца фрагмента и работая в обратном направлении.
    /// Соответствующий элемент не содержится в фрагментах.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Возвращает итератор по фрагментам, разделенным элементами, соответствующими `pred`, с ограничением возврата не более `n` элементов.
    /// Соответствующий элемент не содержится в фрагментах.
    ///
    /// Последний возвращенный элемент, если таковой имеется, будет содержать оставшуюся часть среза.
    ///
    /// # Examples
    ///
    /// Выведите срез, разделенный один раз на числа, делящиеся на 3 (например, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Возвращает итератор по фрагментам, разделенным элементами, соответствующими `pred`, с ограничением возврата не более `n` элементов.
    /// Соответствующий элемент не содержится в фрагментах.
    ///
    /// Последний возвращенный элемент, если таковой имеется, будет содержать оставшуюся часть среза.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Возвращает итератор по фрагментам, разделенным элементами, соответствующими `pred`, с ограничением возврата не более `n` элементов.
    /// Это начинается в конце среза и работает в обратном направлении.
    /// Соответствующий элемент не содержится в фрагментах.
    ///
    /// Последний возвращенный элемент, если таковой имеется, будет содержать оставшуюся часть среза.
    ///
    /// # Examples
    ///
    /// Выведите разделенный срез один раз, начиная с конца, на числа, делящиеся на 3 (т. Е. `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Возвращает итератор по фрагментам, разделенным элементами, соответствующими `pred`, с ограничением возврата не более `n` элементов.
    /// Это начинается в конце среза и работает в обратном направлении.
    /// Соответствующий элемент не содержится в фрагментах.
    ///
    /// Последний возвращенный элемент, если таковой имеется, будет содержать оставшуюся часть среза.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Возвращает `true`, если срез содержит элемент с заданным значением.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Если у вас нет `&T`, а просто `&U`, такой, что `T: Borrow<U>` (например,
    /// `Строка: Заимствовать<str>`), вы можете использовать `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // кусок `String`
    /// assert!(v.iter().any(|e| e == "hello")); // поиск с `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Возвращает `true`, если `needle` является префиксом среза.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Всегда возвращает `true`, если `needle`-пустой срез:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Возвращает `true`, если `needle` является суффиксом фрагмента.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Всегда возвращает `true`, если `needle`-пустой срез:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Возвращает фрагмент с удаленным префиксом.
    ///
    /// Если срез начинается с `prefix`, возвращает подслой после префикса, заключенный в `Some`.
    /// Если `prefix` пуст, просто возвращает исходный фрагмент.
    ///
    /// Если слайс не начинается с `prefix`, возвращает `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Эту функцию нужно будет переписать, если и когда SlicePattern станет более сложным.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Возвращает фрагмент с удаленным суффиксом.
    ///
    /// Если срез заканчивается на `suffix`, возвращает подсрез перед суффиксом, заключенный в `Some`.
    /// Если `suffix` пуст, просто возвращает исходный фрагмент.
    ///
    /// Если срез не заканчивается на `suffix`, возвращает `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Эту функцию нужно будет переписать, если и когда SlicePattern станет более сложным.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Двоичный поиск в отсортированном срезе данного элемента.
    ///
    /// Если значение найдено, возвращается [`Result::Ok`], содержащий индекс соответствующего элемента.
    /// Если есть несколько совпадений, то может быть возвращено любое из совпадений.
    /// Если значение не найдено, возвращается [`Result::Err`], содержащий индекс, в который можно вставить соответствующий элемент, сохраняя при этом порядок сортировки.
    ///
    ///
    /// См. Также [`binary_search_by`], [`binary_search_by_key`] и [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Ищет серию из четырех элементов.
    /// Первый найден с однозначно определенной позицией;второй и третий не обнаружены;четвертый может соответствовать любой позиции в `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Если вы хотите вставить элемент в отсортированный vector, сохраняя порядок сортировки:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Двоичный поиск в этом отсортированном срезе выполняется с помощью функции компаратора.
    ///
    /// Функция компаратора должна реализовывать порядок, соответствующий порядку сортировки нижележащего слайса, возвращая код заказа, который указывает, является ли его аргумент `Less`, `Equal` или `Greater` желаемой целью.
    ///
    ///
    /// Если значение найдено, возвращается [`Result::Ok`], содержащий индекс соответствующего элемента.Если есть несколько совпадений, то может быть возвращено любое из совпадений.
    /// Если значение не найдено, возвращается [`Result::Err`], содержащий индекс, в который можно вставить соответствующий элемент, сохраняя при этом порядок сортировки.
    ///
    /// См. Также [`binary_search`], [`binary_search_by_key`] и [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Ищет серию из четырех элементов.Первый найден с однозначно определенной позицией;второй и третий не обнаружены;четвертый может соответствовать любой позиции в `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // БЕЗОПАСНОСТЬ: вызов обеспечивается следующими инвариантами:
            // - `mid >= 0`
            // - `mid < size`: `mid` ограничен `[left; right)`.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Причина, по которой мы используем поток управления if/else, а не сопоставление, заключается в том, что сопоставление переупорядочивает операции сравнения, которые чувствительны к производительности.
            //
            // Это асм x86 для u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Двоичный поиск в этом отсортированном фрагменте с помощью функции извлечения ключа.
    ///
    /// Предполагается, что фрагмент отсортирован по ключу, например, с [`sort_by_key`], использующим ту же функцию извлечения ключа.
    ///
    /// Если значение найдено, возвращается [`Result::Ok`], содержащий индекс соответствующего элемента.
    /// Если есть несколько совпадений, то может быть возвращено любое из совпадений.
    /// Если значение не найдено, возвращается [`Result::Err`], содержащий индекс, в который можно вставить соответствующий элемент, сохраняя при этом порядок сортировки.
    ///
    ///
    /// См. Также [`binary_search`], [`binary_search_by`] и [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Ищет серию из четырех элементов в срезе пар, отсортированных по вторым элементам.
    /// Первый найден с однозначно определенной позицией;второй и третий не обнаружены;четвертый может соответствовать любой позиции в `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links разрешен, поскольку `slice::sort_by_key` находится в crate `alloc` и как таковой еще не существует при сборке `core`.
    //
    // ссылки на нисходящий crate: #74481.Поскольку примитивы документируются только в libstd (#73423), на практике это никогда не приводит к неработающим ссылкам.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Сортирует фрагмент, но не может сохранять порядок равных элементов.
    ///
    /// Эта сортировка нестабильна (т. Е. Может переупорядочивать одинаковые элементы), по месту (т. Е. Не выделяется) и *O*(*n*\*log(* n*)) в худшем случае.
    ///
    /// # Текущая реализация
    ///
    /// Текущий алгоритм основан на [pattern-defeating quicksort][pdqsort] от Орсона Петерса, который сочетает в себе быстрый средний случай рандомизированной быстрой сортировки с быстрым наихудшим случаем heapsort, обеспечивая при этом линейное время на срезах с определенными шаблонами.
    /// Он использует некоторую рандомизацию, чтобы избежать вырожденных случаев, но с фиксированным seed, чтобы всегда обеспечивать детерминированное поведение.
    ///
    /// Обычно это быстрее, чем стабильная сортировка, за исключением нескольких особых случаев, например, когда срез состоит из нескольких сцепленных отсортированных последовательностей.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Сортирует фрагмент с помощью функции компаратора, но может не сохранять порядок равных элементов.
    ///
    /// Эта сортировка нестабильна (т. Е. Может переупорядочивать одинаковые элементы), по месту (т. Е. Не выделяется) и *O*(*n*\*log(* n*)) в худшем случае.
    ///
    /// Функция компаратора должна определять общий порядок элементов в срезе.Если порядок не является полным, порядок элементов не указан.Заказ является общим заказом, если он (для всех `a`, `b` и `c`):
    ///
    /// * тотальный и антисимметричный: верно только одно из `a < b`, `a == b` или `a > b`, и
    /// * транзитивный, `a < b` и `b < c` влечет `a < c`.То же самое должно выполняться как для `==`, так и для `>`.
    ///
    /// Например, хотя [`f64`] не реализует [`Ord`] из-за `NaN != NaN`, мы можем использовать `partial_cmp` в качестве нашей функции сортировки, когда мы знаем, что срез не содержит `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Текущая реализация
    ///
    /// Текущий алгоритм основан на [pattern-defeating quicksort][pdqsort] от Орсона Петерса, который сочетает в себе быстрый средний случай рандомизированной быстрой сортировки с быстрым наихудшим случаем heapsort, обеспечивая при этом линейное время на срезах с определенными шаблонами.
    /// Он использует некоторую рандомизацию, чтобы избежать вырожденных случаев, но с фиксированным seed, чтобы всегда обеспечивать детерминированное поведение.
    ///
    /// Обычно это быстрее, чем стабильная сортировка, за исключением нескольких особых случаев, например, когда срез состоит из нескольких сцепленных отсортированных последовательностей.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // обратная сортировка
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Сортирует фрагмент с помощью функции извлечения ключа, но может не сохранять порядок равных элементов.
    ///
    /// Эта сортировка нестабильна (т. Е. Может переупорядочивать одинаковые элементы), на месте (т. Е. Не выделяет) и *O*(m\* * n *\* log(*n*)) в худшем случае, где ключевой функцией является *O*(*м*).
    ///
    /// # Текущая реализация
    ///
    /// Текущий алгоритм основан на [pattern-defeating quicksort][pdqsort] от Орсона Петерса, который сочетает в себе быстрый средний случай рандомизированной быстрой сортировки с быстрым наихудшим случаем heapsort, обеспечивая при этом линейное время на срезах с определенными шаблонами.
    /// Он использует некоторую рандомизацию, чтобы избежать вырожденных случаев, но с фиксированным seed, чтобы всегда обеспечивать детерминированное поведение.
    ///
    /// Из-за своей ключевой стратегии вызова [`sort_unstable_by_key`](#method.sort_unstable_by_key), вероятно, будет медленнее, чем [`sort_by_cached_key`](#method.sort_by_cached_key), в тех случаях, когда ключевые функции дороги.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Измените порядок среза так, чтобы элемент в `index` находился в своей окончательной отсортированной позиции.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Измените порядок среза с помощью функции компаратора так, чтобы элемент в `index` находился в своей окончательной отсортированной позиции.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Измените порядок среза с помощью функции извлечения ключа так, чтобы элемент в `index` находился в своей окончательной отсортированной позиции.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Измените порядок среза так, чтобы элемент в `index` находился в своей окончательной отсортированной позиции.
    ///
    /// Это переупорядочение имеет дополнительное свойство, заключающееся в том, что любое значение в позиции `i < index` будет меньше или равно любому значению в позиции `j > index`.
    /// Кроме того, это изменение порядка нестабильно (т. Е.
    /// любое количество одинаковых элементов может оказаться в позиции `index`) на месте (т. е.
    /// не выделяет) и *O*(*n*) в худшем случае.
    /// Эта функция также известна как "kth element" в других библиотеках.
    /// Он возвращает триплет из следующих значений: все элементы, меньшие, чем один в данном индексе, значение в данном индексе и все элементы, большие, чем один в данном индексе.
    ///
    ///
    /// # Текущая реализация
    ///
    /// Текущий алгоритм основан на части быстрого выбора того же алгоритма быстрой сортировки, который используется для [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics при `index >= len()`, то есть всегда panics на пустых срезах.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Найдите медиану
    /// v.select_nth_unstable(2);
    ///
    /// // Нам гарантируется только то, что срез будет одним из следующих, в зависимости от способа сортировки по указанному индексу.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Измените порядок среза с помощью функции компаратора так, чтобы элемент в `index` находился в своей окончательной отсортированной позиции.
    ///
    /// Это переупорядочение имеет дополнительное свойство, заключающееся в том, что любое значение в позиции `i < index` будет меньше или равно любому значению в позиции `j > index` с использованием функции компаратора.
    /// Кроме того, это переупорядочение является нестабильным (т.е. любое количество одинаковых элементов может оказаться в позиции `index`), на месте (т.е. не выделяется) и *O*(*n*) в худшем случае.
    /// Эта функция также известна как "kth element" в других библиотеках.
    /// Он возвращает тройку следующих значений: все элементы, меньшие, чем один в данном индексе, значение в данном индексе и все элементы, большие, чем один в данном индексе, с использованием предоставленной функции компаратора.
    ///
    ///
    /// # Текущая реализация
    ///
    /// Текущий алгоритм основан на части быстрого выбора того же алгоритма быстрой сортировки, который используется для [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics при `index >= len()`, то есть всегда panics на пустых срезах.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Найдите медиану, как если бы срез был отсортирован в порядке убывания.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Нам гарантируется только то, что срез будет одним из следующих, в зависимости от способа сортировки по указанному индексу.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Измените порядок среза с помощью функции извлечения ключа так, чтобы элемент в `index` находился в своей окончательной отсортированной позиции.
    ///
    /// Это переупорядочение имеет дополнительное свойство, заключающееся в том, что любое значение в позиции `i < index` будет меньше или равно любому значению в позиции `j > index` с использованием функции извлечения ключа.
    /// Кроме того, это переупорядочение является нестабильным (т.е. любое количество одинаковых элементов может оказаться в позиции `index`), на месте (т.е. не выделяется) и *O*(*n*) в худшем случае.
    /// Эта функция также известна как "kth element" в других библиотеках.
    /// Он возвращает тройку следующих значений: все элементы, меньшие, чем один в данном индексе, значение в данном индексе и все элементы, большие, чем один в данном индексе, с использованием предоставленной функции извлечения ключа.
    ///
    ///
    /// # Текущая реализация
    ///
    /// Текущий алгоритм основан на части быстрого выбора того же алгоритма быстрой сортировки, который используется для [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics при `index >= len()`, то есть всегда panics на пустых срезах.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Возвращает медиану, как если бы массив был отсортирован по абсолютному значению.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Нам гарантируется только то, что срез будет одним из следующих, в зависимости от способа сортировки по указанному индексу.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Перемещает все последовательные повторяющиеся элементы в конец среза в соответствии с реализацией [`PartialEq`] trait.
    ///
    ///
    /// Возвращает два фрагмента.Первый не содержит последовательных повторяющихся элементов.
    /// Второй содержит все дубликаты в произвольном порядке.
    ///
    /// Если фрагмент отсортирован, первый возвращенный фрагмент не содержит дубликатов.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Перемещает все последовательные элементы, кроме первого, в конец среза, удовлетворяющего заданному отношению равенства.
    ///
    /// Возвращает два фрагмента.Первый не содержит последовательных повторяющихся элементов.
    /// Второй содержит все дубликаты в произвольном порядке.
    ///
    /// В функцию `same_bucket` передаются ссылки на два элемента из среза, и она должна определить, равны ли элементы при сравнении.
    /// Элементы передаются в порядке, обратном их порядку в срезе, поэтому, если `same_bucket(a, b)` возвращает `true`, `a` перемещается в конец среза.
    ///
    ///
    /// Если фрагмент отсортирован, первый возвращенный фрагмент не содержит дубликатов.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Хотя у нас есть изменяемая ссылка на `self`, мы не можем вносить *произвольные* изменения.`same_bucket` может вызывать panic, поэтому мы должны убедиться, что срез всегда находится в допустимом состоянии.
        //
        // Мы справляемся с этим путем использования свопов;мы перебираем все элементы, меняя местами по ходу, так что в конце элементы, которые мы хотим сохранить, оказались впереди, а те, которые мы хотим отклонить,-сзади.
        // Затем мы можем разделить кусок.
        // Эта операция по-прежнему `O(n)`.
        //
        // Пример: мы начинаем с этого состояния, где `r` представляет "следующий
        // read ", а `w` представляет" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Сравнивая self[r] с self [w-1], это не дубликат, поэтому мы меняем местами self[r] и self[w] (без эффекта, поскольку r==w), а затем увеличиваем оба значения r и w, оставляя нас с:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Сравнивая self[r] с self [w-1], это значение дублируется, поэтому мы увеличиваем `r`, но все остальное оставляем без изменений:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Сравнивая self[r] с самим собой [w-1], это не дубликат, поэтому поменяйте местами self[r] и self[w] и продвиньте r и w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Не дубликат, повторяю:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Дубликат, advance r. End фрагмента.Разделить на ш.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // БЕЗОПАСНОСТЬ: условие `while` гарантирует `next_read` и `next_write`
        // меньше `len`, следовательно, находятся внутри `self`.
        // `prev_ptr_write` указывает на один элемент перед `ptr_write`, но `next_write` начинается с 1, поэтому `prev_ptr_write` никогда не меньше 0 и находится внутри среза.
        // Это соответствует требованиям для разыменования `ptr_read`, `prev_ptr_write` и `ptr_write`, а также для использования `ptr.add(next_read)`, `ptr.add(next_write - 1)` и `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` также увеличивается не более одного раза за цикл, что означает, что ни один элемент не пропускается, когда может потребоваться его замена.
        //
        // `ptr_read` и `prev_ptr_write` никогда не указывают на один и тот же элемент.Это необходимо для безопасности `&mut *ptr_read`, `&mut* prev_ptr_write`.
        // Объяснение простое: `next_read >= next_write` всегда верно, следовательно, `next_read > next_write - 1` тоже.
        //
        //
        //
        //
        //
        unsafe {
            // Избегайте проверки границ с помощью необработанных указателей.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Перемещает все последовательные элементы, кроме первого, в конец фрагмента, который соответствует одному и тому же ключу.
    ///
    ///
    /// Возвращает два фрагмента.Первый не содержит последовательных повторяющихся элементов.
    /// Второй содержит все дубликаты в произвольном порядке.
    ///
    /// Если фрагмент отсортирован, первый возвращенный фрагмент не содержит дубликатов.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Поворачивает срез на месте таким образом, что первые элементы `mid` среза перемещаются в конец, а последние элементы `self.len() - mid` перемещаются вперед.
    /// После вызова `rotate_left` элемент, ранее имевший индекс `mid`, станет первым элементом в срезе.
    ///
    /// # Panics
    ///
    /// Эта функция будет panic, если `mid` больше, чем длина среза.Обратите внимание, что `mid == self.len()` выполняет _not_ panic и не выполняет вращение.
    ///
    /// # Complexity
    ///
    /// Принимает линейно (в `self.len()`) раз.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Вращение подсреза:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // БЕЗОПАСНОСТЬ: Диапазон `[p.add(mid) - mid, p.add(mid) + k)` очевиден.
        // действительно для чтения и записи в соответствии с требованиями `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Поворачивает срез на месте таким образом, что первые элементы `self.len() - k` среза перемещаются в конец, а последние элементы `k` перемещаются вперед.
    /// После вызова `rotate_right` элемент, ранее имевший индекс `self.len() - k`, станет первым элементом в срезе.
    ///
    /// # Panics
    ///
    /// Эта функция будет panic, если `k` больше, чем длина среза.Обратите внимание, что `k == self.len()` выполняет _not_ panic и не выполняет вращение.
    ///
    /// # Complexity
    ///
    /// Принимает линейно (в `self.len()`) раз.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Повернуть подсрез:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // БЕЗОПАСНОСТЬ: Диапазон `[p.add(mid) - mid, p.add(mid) + k)` очевиден.
        // действительно для чтения и записи в соответствии с требованиями `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Заполняет `self` элементами путем клонирования `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Заполняет `self` элементами, возвращаемыми путем многократного вызова закрытия.
    ///
    /// Этот метод использует закрытие для создания новых значений.Если вы предпочитаете [`Clone`] заданное значение, используйте [`fill`].
    /// Если вы хотите использовать [`Default`] trait для генерации значений, вы можете передать [`Default::default`] в качестве аргумента.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Копирует элементы из `src` в `self`.
    ///
    /// Длина `src` должна быть такой же, как `self`.
    ///
    /// Если `T` реализует `Copy`, использование [`copy_from_slice`] может быть более производительным.
    ///
    /// # Panics
    ///
    /// Эта функция будет panic, если два среза имеют разную длину.
    ///
    /// # Examples
    ///
    /// Клонирование двух элементов из одного фрагмента в другой:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Поскольку срезы должны быть одинаковой длины, мы разрезаем исходный срез с четырех элементов на два.
    /// // Если мы этого не сделаем, это будет panic.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust предписывает, что может быть только одна изменяемая ссылка без неизменных ссылок на конкретный фрагмент данных в определенной области.
    /// Из-за этого попытка использовать `clone_from_slice` на одном срезе приведет к сбою компиляции:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Чтобы обойти это, мы можем использовать [`split_at_mut`] для создания двух отдельных суб-срезов из среза:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Копирует все элементы из `src` в `self`, используя memcpy.
    ///
    /// Длина `src` должна быть такой же, как `self`.
    ///
    /// Если `T` не реализует `Copy`, используйте [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Эта функция будет panic, если два среза имеют разную длину.
    ///
    /// # Examples
    ///
    /// Копирование двух элементов из одного среза в другой:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Поскольку срезы должны быть одинаковой длины, мы разрезаем исходный срез с четырех элементов на два.
    /// // Если мы этого не сделаем, это будет panic.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust предписывает, что может быть только одна изменяемая ссылка без неизменных ссылок на конкретный фрагмент данных в определенной области.
    /// Из-за этого попытка использовать `copy_from_slice` на одном срезе приведет к сбою компиляции:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Чтобы обойти это, мы можем использовать [`split_at_mut`] для создания двух отдельных суб-срезов из среза:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Путь кода panic был помещен в холодную функцию, чтобы не раздувать сайт вызова.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // БЕЗОПАСНОСТЬ: `self` действителен для элементов `self.len()` по определению, а `src` был
        // проверено, чтобы они были одинаковой длины.
        // Срезы не могут перекрываться, потому что изменяемые ссылки исключают друг друга.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Копирует элементы из одной части среза в другую часть самого себя, используя memmove.
    ///
    /// `src` это диапазон в пределах `self`, из которого выполняется копирование.
    /// `dest` - это начальный индекс диапазона в пределах `self` для копирования, который будет иметь ту же длину, что и `src`.
    /// Эти два диапазона могут перекрываться.
    /// Концы двух диапазонов должны быть меньше или равны `self.len()`.
    ///
    /// # Panics
    ///
    /// Эта функция будет panic, если какой-либо диапазон превышает конец среза или если конец `src` находится до начала.
    ///
    ///
    /// # Examples
    ///
    /// Копирование четырех байтов внутри среза:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // БЕЗОПАСНОСТЬ: все условия для `ptr::copy` были проверены выше,
        // как и для `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Меняет местами все элементы в `self` с элементами в `other`.
    ///
    /// Длина `other` должна быть такой же, как `self`.
    ///
    /// # Panics
    ///
    /// Эта функция будет panic, если два среза имеют разную длину.
    ///
    /// # Example
    ///
    /// Поменять местами два элемента между срезами:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust предписывает, что может быть только одна изменяемая ссылка на конкретный фрагмент данных в определенной области.
    ///
    /// Из-за этого попытка использовать `swap_with_slice` на одном срезе приведет к сбою компиляции:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Чтобы обойти это, мы можем использовать [`split_at_mut`] для создания двух различных изменяемых суб-срезов из среза:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // БЕЗОПАСНОСТЬ: `self` действителен для элементов `self.len()` по определению, а `src` был
        // проверено, чтобы они были одинаковой длины.
        // Срезы не могут перекрываться, потому что изменяемые ссылки исключают друг друга.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Функция для вычисления длины среднего и конечного срезов для `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Что мы собираемся сделать с `rest`, так это выяснить, какое кратное U мы можем вставить в наименьшее количество T.
        //
        // А сколько нужно на каждый такой "multiple".
        //
        // Рассмотрим, например, T=u8 U=u16.Тогда мы можем поместить 1 U в 2 Ts.Простой.
        // Теперь рассмотрим, например, случай, когда size_of: :<T>=16, размер_::<U>=24.</u>
        // Мы можем поставить 2 Us вместо каждых 3 Ts в срезе `rest`.
        // Немного сложнее.
        //
        // Формула для его расчета:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Расширенное и упрощенное:
        //
        // Us=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=размер_изображения::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // К счастью, поскольку все это постоянно оценивается ... производительность здесь не имеет значения!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // итеративный алгоритм Штейна. Мы все равно должны сделать этот `const fn` (и вернуться к рекурсивному алгоритму, если мы это сделаем), потому что полагаться на llvm на consteval все это…ну, это доставляет мне дискомфорт.
            //
            //

            // БЕЗОПАСНОСТЬ: `a` и `b` проверяются на ненулевые значения.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // удалите все множители 2 из b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // БЕЗОПАСНОСТЬ: `b` проверяется на ненулевое значение.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Вооружившись этими знаниями, мы сможем найти, сколько «U» мы сможем уместить!
        let us_len = self.len() / ts * us;
        // А сколько T будет в завершающем срезе!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Преобразуйте срез в срез другого типа, сохраняя выравнивание типов.
    ///
    /// Этот метод разбивает фрагмент на три отдельных фрагмента: префикс, правильно выровненный средний фрагмент нового типа и фрагмент суффикса.
    /// Метод может сделать средний срез максимально возможной длины для данного типа и входного среза, но от этого должна зависеть только производительность вашего алгоритма, а не его правильность.
    ///
    /// Допускается возвращение всех входных данных в виде префикса или суффикса.
    ///
    /// Этот метод не имеет смысла, если входной элемент `T` или выходной элемент `U` имеют нулевой размер и возвращают исходный срез, ничего не разделяя.
    ///
    /// # Safety
    ///
    /// По сути, этот метод является `transmute` по отношению к элементам в возвращаемом среднем срезе, поэтому здесь также применимы все обычные предостережения, относящиеся к `transmute::<T, U>`.
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Обратите внимание, что большая часть этой функции будет оцениваться константами,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // обрабатывать ZST специально, то есть вообще не обрабатывать их.
            return (self, &[], &[]);
        }

        // Во-первых, найдите, в какой точке мы разделяем первый и второй срез.
        // Легко с ptr.align_offset.
        let ptr = self.as_ptr();
        // БЕЗОПАСНОСТЬ: подробный комментарий по безопасности см. В методе `align_to_mut`.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // БЕЗОПАСНОСТЬ: теперь `rest` определенно выровнен, поэтому `from_raw_parts` ниже в порядке,
            // поскольку вызывающий гарантирует, что мы можем безопасно преобразовать `T` в `U`.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Преобразуйте срез в срез другого типа, сохраняя выравнивание типов.
    ///
    /// Этот метод разбивает фрагмент на три отдельных фрагмента: префикс, правильно выровненный средний фрагмент нового типа и фрагмент суффикса.
    /// Метод может сделать средний срез максимально возможной длины для данного типа и входного среза, но от этого должна зависеть только производительность вашего алгоритма, а не его правильность.
    ///
    /// Допускается возвращение всех входных данных в виде префикса или суффикса.
    ///
    /// Этот метод не имеет смысла, если входной элемент `T` или выходной элемент `U` имеют нулевой размер и возвращают исходный срез, ничего не разделяя.
    ///
    /// # Safety
    ///
    /// По сути, этот метод является `transmute` по отношению к элементам в возвращаемом среднем срезе, поэтому здесь также применимы все обычные предостережения, относящиеся к `transmute::<T, U>`.
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Обратите внимание, что большая часть этой функции будет оцениваться константами,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // обрабатывать ZST специально, то есть вообще не обрабатывать их.
            return (self, &mut [], &mut []);
        }

        // Во-первых, найдите, в какой точке мы разделяем первый и второй срез.
        // Легко с ptr.align_offset.
        let ptr = self.as_ptr();
        // БЕЗОПАСНОСТЬ: Здесь мы гарантируем, что будем использовать выровненные указатели для U для
        // остальная часть метода.Это делается путем передачи указателя на&[T] с выравниванием по U.
        // `crate::ptr::align_offset` вызывается с правильно выровненным и действительным указателем `ptr` (он происходит из ссылки на `self`) и размером, равным степени двойки (поскольку он происходит из выравнивания для U), удовлетворяя ограничениям безопасности.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // После этого мы не сможем снова использовать `rest`, это сделает его псевдоним `mut_ptr` недействительным!БЕЗОПАСНОСТЬ: см. Комментарии к `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Проверяет, отсортированы ли элементы этого фрагмента.
    ///
    /// То есть для каждого элемента `a` и следующего за ним элемента `b` должно выполняться `a <= b`.Если срез дает ровно ноль или один элемент, возвращается `true`.
    ///
    /// Обратите внимание, что если `Self::Item`-это только `PartialOrd`, но не `Ord`, приведенное выше определение подразумевает, что эта функция возвращает `false`, если любые два последовательных элемента не сопоставимы.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Проверяет, отсортированы ли элементы этого среза с использованием заданной функции компаратора.
    ///
    /// Вместо использования `PartialOrd::partial_cmp` эта функция использует данную функцию `compare` для определения порядка двух элементов.
    /// Кроме того, это эквивалент [`is_sorted`];см. его документацию для получения дополнительной информации.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Проверяет, отсортированы ли элементы этого фрагмента с использованием заданной функции извлечения ключа.
    ///
    /// Вместо того, чтобы напрямую сравнивать элементы среза, эта функция сравнивает ключи элементов, как определено `f`.
    /// Кроме того, это эквивалент [`is_sorted`];см. его документацию для получения дополнительной информации.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Возвращает индекс точки раздела в соответствии с заданным предикатом (индекс первого элемента второго раздела).
    ///
    /// Предполагается, что срез разделен в соответствии с заданным предикатом.
    /// Это означает, что все элементы, для которых предикат возвращает true, находятся в начале среза, а все элементы, для которых предикат возвращает false, находятся в конце.
    ///
    /// Например, [7, 15, 3, 5, 4, 12, 6] разделен под предикатом x% 2!=0 (все нечетные числа находятся в начале, все четные-в конце).
    ///
    /// Если этот фрагмент не разделен, возвращаемый результат не определен и не имеет смысла, поскольку этот метод выполняет своего рода двоичный поиск.
    ///
    /// См. Также [`binary_search`], [`binary_search_by`] и [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // БЕЗОПАСНОСТЬ: Когда `left < right`, `left <= mid < right`.
            // Следовательно, `left` всегда увеличивается, а `right` всегда уменьшается, и выбирается любой из них.В обоих случаях `left <= right` устраивает.Следовательно, если `left < right` на шаге, `left <= right` удовлетворяется на следующем шаге.
            //
            // Следовательно, пока `left != right`, `0 <= left < right <= len` удовлетворяется, а в этом случае `0 <= mid < len` тоже удовлетворяется.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Нам нужно явно разрезать их на одинаковую длину
        // чтобы оптимизатору было проще исключить проверку границ.
        // Но поскольку на него нельзя положиться, у нас также есть явная специализация для T: Copy.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Создает пустой фрагмент.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Создает изменяемый пустой фрагмент.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Паттерны в срезах в настоящее время используются только `strip_prefix` и `strip_suffix`.
/// В точке future мы надеемся обобщить `core::str::Pattern` (который на момент написания ограничен `str`) на срезы, а затем этот trait будет заменен или упразднен.
///
pub trait SlicePattern {
    /// Тип элемента сопоставляемого среза.
    type Item;

    /// В настоящее время потребителям `SlicePattern` нужен срез.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}