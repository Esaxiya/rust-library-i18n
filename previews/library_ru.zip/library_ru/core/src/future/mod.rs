#![stable(feature = "futures_api", since = "1.36.0")]

//! Асинхронные значения.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Этот тип нужен, потому что:
///
/// a) Генераторы не могут реализовать `for<'a, 'b> Generator<&'a mut Context<'b>>`, поэтому нам нужно передать необработанный указатель (см. <https://github.com/rust-lang/rust/issues/68923>).
///
/// б) Необработанные указатели и `NonNull` не являются `Send` или `Sync`, поэтому каждый future также будет non-Send/Sync, а мы этого не хотим.
///
/// Это также упрощает снижение HIR `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Оберните генератор в future.
///
/// Эта функция возвращает `GenFuture` внизу, но скрывает его в `impl Trait`, чтобы лучше отображать сообщения об ошибках (`impl Future`, а не `GenFuture<[closure.....]>`).
///
// Это `const`, чтобы избежать лишних ошибок после восстановления после `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Мы полагаемся на тот факт, что async/await futures неподвижны, чтобы создавать самореферентные заимствования в базовом генераторе.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // БЕЗОПАСНОСТЬ: Безопасно, потому что мы !Unpin + !Drop, и это просто проекция поля.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Возобновите работу генератора, превратив `&mut Context` в необработанный указатель `NonNull`.
            // Понижение `.await` безопасно вернет это обратно к `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // БЕЗОПАСНОСТЬ: вызывающий должен гарантировать, что `cx.0` является действительным указателем.
    // который удовлетворяет всем требованиям для изменяемой ссылки.
    unsafe { &mut *cx.0.as_ptr().cast() }
}