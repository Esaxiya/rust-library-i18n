use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Хотя эта функция используется в одном месте и ее реализация может быть встроена, предыдущие попытки сделать это замедлили работу rustc:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Разметка блока памяти.
///
/// Экземпляр `Layout` описывает конкретную схему памяти.
/// Вы создаете `Layout` как вход для распределителя.
///
/// Все макеты имеют соответствующий размер и выравнивание по степени двойки.
///
/// (Обратите внимание, что макеты *не* должны иметь ненулевой размер, хотя `GlobalAlloc` требует, чтобы все запросы к памяти имели ненулевой размер.
/// Вызывающий должен либо обеспечить выполнение подобных условий, либо использовать специальные распределители с более свободными требованиями, либо использовать более мягкий интерфейс `Allocator`.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // размер запрошенного блока памяти, измеряемый в байтах.
    size_: usize,

    // выравнивание запрошенного блока памяти, измеряемое в байтах.
    // мы гарантируем, что это всегда степень двойки, потому что API, такие как `posix_memalign`, требуют этого, и это разумное ограничение, накладываемое на конструкторы макета.
    //
    //
    // (Однако аналогично мы не требуем `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Создает `Layout` из заданных `size` и `align` или возвращает `LayoutError`, если любое из следующих условий не выполняется:
    ///
    /// * `align` не должно быть нулевым,
    ///
    /// * `align` должно быть степень двойки,
    ///
    /// * `size`, при округлении до ближайшего кратного `align` значение не должно переполняться (т. е. округленное значение должно быть меньше или равно `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (степень двойки подразумевает выравнивание!=0.)

        // Округленный размер:
        //   size_ounded_up=(размер + выравнивание, 1)&! (выравнивание, 1);
        //
        // Сверху мы знаем, что align!=0.
        // Если при добавлении (align, 1) не происходит переполнения, тогда можно будет округлить в большую сторону.
        //
        // И наоборот,&-masking с! (Align, 1) вычитает только младшие биты.
        // Таким образом, если происходит переполнение суммы,&-маска не может вычесть достаточно, чтобы отменить это переполнение.
        //
        //
        // Из вышесказанного следует, что проверка переполнения суммирования необходима и достаточна.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // БЕЗОПАСНОСТЬ: условия для `from_size_align_unchecked` были
        // проверил выше.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Создает макет, минуя все проверки.
    ///
    /// # Safety
    ///
    /// Эта функция небезопасна, поскольку она не проверяет предварительные условия от [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // БЕЗОПАСНОСТЬ: вызывающий должен убедиться, что `align` больше нуля.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Минимальный размер в байтах для блока памяти этого макета.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Минимальное выравнивание байтов для блока памяти этого макета.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Создает `Layout`, подходящий для хранения значения типа `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // БЕЗОПАСНОСТЬ: Rust гарантирует выравнивание как степень двойки и
        // Комбинация size + align гарантированно умещается в нашем адресном пространстве.
        // В результате используйте здесь непроверенный конструктор, чтобы не вставлять код panics, если он недостаточно хорошо оптимизирован.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Создает макет, описывающий запись, которую можно использовать для выделения структуры поддержки для `T` (которая может быть trait или другим типом без размера, например срезом).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // БЕЗОПАСНОСТЬ: см. Обоснование в `new`, почему здесь используется небезопасный вариант
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Создает макет, описывающий запись, которую можно использовать для выделения структуры поддержки для `T` (которая может быть trait или другим типом без размера, например срезом).
    ///
    /// # Safety
    ///
    /// Эту функцию можно безопасно вызывать, только если выполняются следующие условия:
    ///
    /// - Если `T` равен `Sized`, эту функцию всегда можно безопасно вызывать.
    /// - Если безразмерный хвост `T`:
    ///     - a [slice], тогда длина хвоста среза должна быть инициализированным целым числом, а размер *всего значения*(динамическая длина хвоста + префикс статического размера) должен соответствовать `isize`.
    ///     - a [trait object], то часть указателя vtable должна указывать на допустимую vtable для типа `T`, полученную при изменении размера, а размер *всего значения*(динамическая длина хвоста + префикс статического размера) должен соответствовать `isize`.
    ///
    ///     - (unstable) [extern type], то эту функцию всегда можно безопасно вызывать, но panic или иным образом может вернуть неправильное значение, поскольку макет внешнего типа неизвестен.
    ///     Это то же поведение, что и [`Layout::for_value`] при ссылке на хвост внешнего типа.
    ///     - в противном случае консервативно не разрешается вызывать эту функцию.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // БЕЗОПАСНОСТЬ: мы передаем необходимые условия для этих функций вызывающему абоненту.
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // БЕЗОПАСНОСТЬ: см. Обоснование в `new`, почему здесь используется небезопасный вариант
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Создает болтающийся `NonNull`, но хорошо выровненный для этого макета.
    ///
    /// Обратите внимание, что значение указателя потенциально может представлять действительный указатель, что означает, что его нельзя использовать в качестве контрольного значения "not yet initialized".
    /// Типы, которые распределяются лениво, должны отслеживать инициализацию другими способами.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // БЕЗОПАСНОСТЬ: значение align гарантированно ненулевое
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Создает макет, описывающий запись, которая может содержать значение того же макета, что и `self`, но также выровнена по выравниванию `align` (измеряется в байтах).
    ///
    ///
    /// Если `self` уже соответствует предписанному выравниванию, то возвращает `self`.
    ///
    /// Обратите внимание, что этот метод не добавляет никаких отступов к общему размеру, независимо от того, имеет ли возвращаемый макет другое выравнивание.
    /// Другими словами, если `K` имеет размер 16, `K.align_to(32)` будет *по-прежнему* иметь размер 16.
    ///
    /// Возвращает ошибку, если комбинация `self.size()` и данного `align` нарушает условия, перечисленные в [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Возвращает величину заполнения, которую мы должны вставить после `self`, чтобы гарантировать, что следующий адрес будет удовлетворять `align` (измеряется в байтах).
    ///
    /// например, если `self.size()` равно 9, то `self.padding_needed_for(4)` возвращает 3, потому что это минимальное количество байтов заполнения, необходимое для получения адреса с выравниванием по 4 (при условии, что соответствующий блок памяти начинается с адреса с выравниванием по 4).
    ///
    ///
    /// Возвращаемое значение этой функции не имеет значения, если `align` не является степенью двойки.
    ///
    /// Обратите внимание, что полезность возвращаемого значения требует, чтобы `align` был меньше или равен выравниванию начального адреса для всего выделенного блока памяти.Один из способов удовлетворить это ограничение-обеспечить `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Округленное значение:
        //   len_ounded_up=(len + выровнять, 1)&! (выровнять, 1);
        // а затем возвращаем разницу заполнения: `len_rounded_up - len`.
        //
        // Мы используем модульную арифметику повсюду:
        //
        // 1. align гарантированно будет> 0, поэтому align, 1 всегда действителен.
        //
        // 2.
        // `len + align - 1` может переполниться не более чем на `align - 1`, поэтому&-маска с `!(align - 1)` гарантирует, что в случае переполнения `len_rounded_up` сам будет равен 0.
        //
        //    Таким образом, возвращенное заполнение при добавлении к `len` дает 0, что тривиально удовлетворяет выравниванию `align`.
        //
        // (Конечно, попытки выделить блоки памяти, размер и переполнение которых вышеупомянутым способом должны привести к тому, что распределитель все равно выдаст ошибку.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Создает макет путем округления размера этого макета до кратного значения выравнивания макета.
    ///
    ///
    /// Это эквивалентно добавлению результата `padding_needed_for` к текущему размеру макета.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Это не может быть переполнено.Цитата из инварианта Layout:
        // > `size`, при округлении до ближайшего кратного `align`,
        // > не должно переполняться (т. е. округленное значение должно быть меньше, чем
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Создает макет, описывающий запись для экземпляров `n` экземпляра `self`, с подходящим количеством отступов между каждым экземпляром, чтобы гарантировать, что каждому экземпляру задан требуемый размер и выравнивание.
    /// В случае успеха возвращает `(k, offs)`, где `k`-это макет массива, а `offs`-расстояние между началом каждого элемента в массиве.
    ///
    /// При арифметическом переполнении возвращает `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Это не может быть переполнено.Цитата из инварианта Layout:
        // > `size`, при округлении до ближайшего кратного `align`,
        // > не должно переполняться (т. е. округленное значение должно быть меньше, чем
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // БЕЗОПАСНОСТЬ: известно, что self.align действителен, а размер alloc_size был
        // подбитый уже.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Создает макет, описывающий запись для `self`, за которым следует `next`, включая любые необходимые отступы, чтобы гарантировать, что `next` будет правильно выровнен, но *без завершающих отступов*.
    ///
    /// Чтобы соответствовать макету представления C `repr(C)`, вы должны вызвать `pad_to_align` после расширения макета со всеми полями.
    /// (Невозможно сопоставить макет представления Rust по умолчанию `repr(Rust)`, as it is unspecified.)
    ///
    /// Обратите внимание, что выравнивание полученного макета будет максимальным по сравнению с `self` и `next`, чтобы обеспечить выравнивание обеих частей.
    ///
    /// Возвращает `Ok((k, offset))`, где `k`-это макет объединенной записи, а `offset`-относительное положение в байтах начала `next`, встроенного в объединенную запись (при условии, что сама запись начинается со смещения 0).
    ///
    ///
    /// При арифметическом переполнении возвращает `LayoutError`.
    ///
    /// # Examples
    ///
    /// Чтобы рассчитать макет структуры `#[repr(C)]` и смещения полей из макетов ее полей:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Не забудьте завершить с `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // проверьте, что это работает
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Создает макет, описывающий запись для `n` экземпляров `self`, без отступов между каждым экземпляром.
    ///
    /// Обратите внимание, что, в отличие от `repeat`, `repeat_packed` не гарантирует, что повторяющиеся экземпляры `self` будут правильно выровнены, даже если данный экземпляр `self` выровнен должным образом.
    /// Другими словами, если макет, возвращаемый `repeat_packed`, используется для выделения массива, не гарантируется, что все элементы в массиве будут правильно выровнены.
    ///
    /// При арифметическом переполнении возвращает `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Создает макет, описывающий запись для `self`, за которым следует `next`, без дополнительных отступов между ними.
    /// Поскольку отступы не вставлены, выравнивание `next` не имеет значения и не включается *вообще* в результирующий макет.
    ///
    ///
    /// При арифметическом переполнении возвращает `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Создает макет, описывающий запись для `[T; n]`.
    ///
    /// При арифметическом переполнении возвращает `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Параметры, передаваемые `Layout::from_size_align` или другому конструктору `Layout`, не удовлетворяют его задокументированным ограничениям.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (нам это нужно для последующего внедрения ошибки trait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}