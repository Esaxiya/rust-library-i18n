//! Этот модуль реализует `Any` trait, который обеспечивает динамическую типизацию любого типа `'static` посредством отражения во время выполнения.
//!
//! `Any` сам по себе может использоваться для получения `TypeId` и имеет больше возможностей при использовании в качестве объекта trait.
//! Как `&dyn Any` (заимствованный объект trait), он имеет методы `is` и `downcast_ref`, чтобы проверить, принадлежит ли содержащееся значение заданному типу, и получить ссылку на внутреннее значение как на тип.
//! Как и `&mut dyn Any`, существует также метод `downcast_mut` для получения изменяемой ссылки на внутреннее значение.
//! `Box<dyn Any>` добавляет метод `downcast`, который пытается преобразовать в `Box<T>`.
//! Подробную информацию см. В документации [`Box`].
//!
//! Обратите внимание, что `&dyn Any` ограничен проверкой того, принадлежит ли значение указанному конкретному типу, и не может использоваться для проверки того, реализует ли тип trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Умные указатели и `dyn Any`
//!
//! При использовании `Any` в качестве объекта trait, особенно с такими типами, как `Box<dyn Any>` или `Arc<dyn Any>`, следует помнить о том, что простой вызов `.type_id()` для значения приведет к созданию `TypeId`*контейнера*, а не базового объекта trait.
//!
//! Этого можно избежать, вместо этого преобразовав интеллектуальный указатель в `&dyn Any`, который вернет `TypeId` объекта.
//! Например:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Вы, скорее всего, захотите этого:
//! let actual_id = (&*boxed).type_id();
//! // ... чем это:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Рассмотрим ситуацию, когда мы хотим вывести значение, переданное функции.
//! Нам известно значение, над которым мы работаем, реализует Debug, но мы не знаем его конкретного типа.Мы хотим уделить особое внимание определенным типам: в этом случае выводим длину строковых значений перед их значением.
//! Мы не знаем конкретный тип нашего значения во время компиляции, поэтому нам нужно вместо этого использовать отражение во время выполнения.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Функция регистратора для любого типа, реализующего отладку.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Попробуйте преобразовать нашу ценность в `String`.
//!     // В случае успеха мы хотим вывести длину строки, а также ее значение.
//!     // Если нет, то это другой тип: просто распечатайте его без украшений.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Эта функция хочет зарегистрировать свой параметр, прежде чем работать с ним.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... займись другой работой
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Любой trait
///////////////////////////////////////////////////////////////////////////////

/// trait для имитации динамического набора текста.
///
/// Большинство типов реализуют `Any`.Однако любой тип, содержащий нестатическую ссылку, этого не делает.
/// Подробнее см. [module-level documentation][mod].
///
/// [mod]: crate::any
// Этот trait небезопасен, хотя мы полагаемся на специфику его единственной функции `type_id` impl в небезопасном коде (например, `downcast`).Обычно это было бы проблемой, но поскольку единственная реализация `Any`-это сплошная реализация, никакой другой код не может реализовать `Any`.
//
// Мы могли бы правдоподобно сделать этот trait небезопасным-это не привело бы к поломке, так как мы контролируем все реализации,-но мы решили не делать этого, поскольку это и не является действительно необходимым, и может запутать пользователей различием небезопасных traits и небезопасных методов (т. По-прежнему можно будет позвонить в `type_id`, но мы, вероятно, захотим указать это в документации).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Получает `TypeId` от `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Методы расширения для любых объектов trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Убедитесь, что результат, например, присоединения к потоку можно распечатать и, следовательно, использовать с `unwrap`.
// В конечном итоге может больше не понадобиться, если отправка работает с повышением качества.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Возвращает `true`, если тип в штучной упаковке такой же, как `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Получите `TypeId` того типа, с которым создана эта функция.
        let t = TypeId::of::<T>();

        // Получите `TypeId` типа в объекте trait (`self`).
        let concrete = self.type_id();

        // Сравните оба типа TypeId на равенство.
        t == concrete
    }

    /// Возвращает некоторую ссылку на упакованное значение, если оно имеет тип `T`, или `None`, если это не так.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // БЕЗОПАСНОСТЬ: только что проверили, указываем ли мы на правильный тип, и мы можем положиться на
            // эта проверка на безопасность памяти, потому что мы реализовали Any для всех типов;никакие другие импы не могут существовать, поскольку они будут конфликтовать с нашим имплементом.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Возвращает некоторую изменяемую ссылку на упакованное значение, если оно имеет тип `T`, или `None`, если это не так.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // БЕЗОПАСНОСТЬ: только что проверили, указываем ли мы на правильный тип, и мы можем положиться на
            // эта проверка на безопасность памяти, потому что мы реализовали Any для всех типов;никакие другие импы не могут существовать, поскольку они будут конфликтовать с нашим имплементом.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Перенаправляет к методу, определенному для типа `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Перенаправляет к методу, определенному для типа `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Перенаправляет к методу, определенному для типа `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Перенаправляет к методу, определенному для типа `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Перенаправляет к методу, определенному для типа `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Перенаправляет к методу, определенному для типа `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID и его методы
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` представляет собой глобальный уникальный идентификатор типа.
///
/// Каждый `TypeId`-это непрозрачный объект, который не позволяет осматривать то, что находится внутри, но позволяет выполнять основные операции, такие как клонирование, сравнение, печать и отображение.
///
///
/// `TypeId` в настоящее время доступен только для типов, которые приписываются `'static`, но это ограничение может быть снято в future.
///
/// Хотя `TypeId` реализует `Hash`, `PartialOrd` и `Ord`, стоит отметить, что хэши и порядок будут различаться между выпусками Rust.
/// Остерегайтесь полагаться на них в своем коде!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Возвращает `TypeId` типа, с которым была создана эта универсальная функция.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Возвращает имя типа в виде строкового фрагмента.
///
/// # Note
///
/// Это предназначено для диагностического использования.
/// Точное содержимое и формат возвращаемой строки не указаны, за исключением описания типа максимально возможного.
/// Например, среди строк, которые может вернуть `type_name::<Option<String>>()`, есть `"Option<String>"` и `"std::option::Option<std::string::String>"`.
///
///
/// Возвращенная строка не должна рассматриваться как уникальный идентификатор типа, поскольку несколько типов могут отображаться на одно и то же имя типа.
/// Точно так же нет гарантии, что все части типа появятся в возвращаемой строке: например, спецификаторы времени жизни в настоящее время не включены.
/// Кроме того, вывод может изменяться между версиями компилятора.
///
/// Текущая реализация использует ту же инфраструктуру, что и диагностика компилятора и отладочная информация, но это не гарантируется.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Возвращает имя типа указанного значения в виде строкового фрагмента.
/// Это то же самое, что и `type_name::<T>()`, но может использоваться там, где тип переменной недоступен.
///
/// # Note
///
/// Это предназначено для диагностического использования.Точное содержимое и формат строки не указываются, за исключением описания типа максимально возможного.
/// Например, `type_name_of_val::<Option<String>>(None)` может вернуть `"Option<String>"` или `"std::option::Option<std::string::String>"`, но не `"foobar"`.
///
/// Кроме того, вывод может изменяться между версиями компилятора.
///
/// Эта функция не разрешает объекты trait, что означает, что `type_name_of_val(&7u32 as &dyn Debug)` может возвращать `"dyn Debug"`, но не `"u32"`.
///
/// Имя типа не следует рассматривать как уникальный идентификатор типа;
/// несколько типов могут иметь одно и то же имя типа.
///
/// Текущая реализация использует ту же инфраструктуру, что и диагностика компилятора и отладочная информация, но это не гарантируется.
///
/// # Examples
///
/// Печатает целочисленный и плавающий типы по умолчанию.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}