//! Совместно изменяемые контейнеры.
//!
//! Безопасность памяти Rust основана на этом правиле: для объекта `T` возможно только одно из следующего:
//!
//! - Наличие нескольких неизменяемых ссылок (`&T`) на объект (также известных как **псевдонимы**).
//! - Наличие одной изменяемой ссылки (`&mut T`) на объект (также известной как **изменяемость**).
//!
//! Это обеспечивается компилятором Rust.Однако бывают ситуации, когда это правило недостаточно гибкое.Иногда требуется иметь несколько ссылок на объект и при этом изменять его.
//!
//! Совместно используемые изменяемые контейнеры существуют, чтобы разрешить изменяемость контролируемым образом, даже при наличии алиасинга.И [`Cell<T>`], и [`RefCell<T>`] позволяют делать это в однопоточном режиме.
//! Однако ни `Cell<T>`, ни `RefCell<T>` не являются потокобезопасными (они не реализуют [`Sync`]).
//! Если вам нужно выполнить наложение и мутацию между несколькими потоками, можно использовать типы [`Mutex<T>`], [`RwLock<T>`] или [`atomic`].
//!
//! Значения типов `Cell<T>` и `RefCell<T>` могут быть изменены с помощью общих ссылок (т. Е.
//! общий тип `&T`), тогда как большинство типов Rust можно изменять только с помощью уникальных (&mut T`) ссылок.
//! Мы говорим, что `Cell<T>` и `RefCell<T>` обеспечивают «внутреннюю изменчивость», в отличие от типичных типов Rust, которые демонстрируют «наследуемую изменчивость».
//!
//! Типы клеток бывают двух видов: `Cell<T>` и `RefCell<T>`.`Cell<T>` реализует внутреннюю изменчивость, перемещая значения в `Cell<T>` и из него.
//! Чтобы использовать ссылки вместо значений, необходимо использовать тип `RefCell<T>`, получив блокировку записи перед изменением.`Cell<T>` предоставляет методы для получения и изменения текущего внутреннего значения:
//!
//!  - Для типов, реализующих [`Copy`], метод [`get`](Cell::get) извлекает текущее внутреннее значение.
//!  - Для типов, реализующих [`Default`], метод [`take`](Cell::take) заменяет текущее внутреннее значение на [`Default::default()`] и возвращает замененное значение.
//!  - Для всех типов метод [`replace`](Cell::replace) заменяет текущее внутреннее значение и возвращает замененное значение, а метод [`into_inner`](Cell::into_inner) использует `Cell<T>` и возвращает внутреннее значение.
//!  Кроме того, метод [`set`](Cell::set) заменяет внутреннее значение, удаляя замененное значение.
//!
//! `RefCell<T>` использует время жизни Rust для реализации «динамического заимствования», процесса, посредством которого можно требовать временного, исключительного, изменяемого доступа к внутреннему значению.
//! Заимствования для `RefCell<T>`s отслеживаются 'во время выполнения', в отличие от собственных ссылочных типов Rust, которые полностью отслеживаются статически во время компиляции.
//! Поскольку заимствования `RefCell<T>` являются динамическими, можно попытаться заимствовать значение, которое уже взаимно заимствовано;когда это происходит, возникает поток panic.
//!
//! # Когда выбирать внутреннюю изменчивость
//!
//! Более распространенная унаследованная изменчивость, при которой необходимо иметь уникальный доступ для изменения значения, является одним из ключевых элементов языка, который позволяет Rust серьезно рассуждать о псевдониме указателя, статически предотвращая ошибки сбоя.
//! Из-за этого предпочтительна унаследованная изменчивость, а внутренняя изменчивость-это последнее средство.
//! Поскольку типы клеток допускают мутацию там, где в противном случае она была бы запрещена, бывают случаи, когда внутренняя изменчивость может быть подходящей или даже *должна* использоваться, например
//!
//! * Представляем изменчивость 'inside' чего-то неизменного
//! * Детали реализации логически неизменяемых методов.
//! * Мутирующие реализации [`Clone`].
//!
//! ## Представляем изменчивость 'inside' чего-то неизменного
//!
//! Многие общие типы интеллектуальных указателей, включая [`Rc<T>`] и [`Arc<T>`], предоставляют контейнеры, которые можно клонировать и совместно использовать между несколькими сторонами.
//! Поскольку содержащиеся значения могут иметь несколько псевдонимов, их можно заимствовать только с `&`, но не с `&mut`.
//! Без ячеек было бы вообще невозможно изменить данные внутри этих интеллектуальных указателей.
//!
//! Тогда очень часто помещают `RefCell<T>` в типы общих указателей, чтобы вновь ввести изменчивость:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Создайте новый блок, чтобы ограничить объем динамического заимствования
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Обратите внимание: если бы мы не позволили предыдущему заимствованию кэша выпасть из области видимости, то последующее заимствование вызвало бы динамический поток panic.
//!     //
//!     // Это основная опасность использования `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Обратите внимание, что в этом примере используется `Rc<T>`, а не `Arc<T>`.`RefCell<T>`s предназначены для однопоточных сценариев.Рассмотрите возможность использования [`RwLock<T>`] или [`Mutex<T>`], если вам нужна общая изменчивость в многопоточной ситуации.
//!
//! ## Детали реализации логически неизменяемых методов
//!
//! Иногда может быть желательно не раскрывать в API, что происходит мутация "under the hood".
//! Это может быть связано с тем, что логически операция неизменна, но, например, кеширование заставляет реализацию выполнять мутацию;или потому что вы должны использовать мутацию для реализации метода trait, который изначально был определен как принимающий `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Здесь идут дорогие вычисления
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Мутирующие реализации `Clone`
//!
//! Это просто особый, но распространенный случай предыдущего: сокрытие изменчивости для операций, которые кажутся неизменными.
//! Ожидается, что метод [`clone`](Clone::clone) не изменит исходное значение и объявлен как принимающий `&self`, а не `&mut self`.
//! Следовательно, любая мутация, которая происходит в методе `clone`, должна использовать типы ячеек.
//! Например, [`Rc<T>`] поддерживает счетчики ссылок в `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Изменяемая ячейка памяти.
///
/// # Examples
///
/// В этом примере вы можете видеть, что `Cell<T>` разрешает мутацию внутри неизменяемой структуры.
/// Другими словами, он включает "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ОШИБКА: `my_struct` неизменяемый
/// // my_struct.regular_field =новое_значение;
///
/// // РАБОТАЕТ: хотя `my_struct` неизменен, `special_field`-это `Cell`,
/// // который всегда можно видоизменить
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// См. [module-level documentation](self) для получения дополнительной информации.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Создает `Cell<T>` со значением `Default` для T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Создает новый `Cell`, содержащий заданное значение.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Устанавливает содержащееся значение.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Меняет местами значения двух ячеек.
    /// Отличие от `std::mem::swap` в том, что эта функция не требует ссылки на `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // БЕЗОПАСНОСТЬ: это может быть рискованно, если вызывается из разных потоков, но `Cell`
        // это `!Sync`, поэтому этого не произойдет.
        // Это также не приведет к аннулированию каких-либо указателей, поскольку `Cell` гарантирует, что ничто другое не будет указывать ни на один из этих `Cell`s.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Заменяет содержащееся значение на `val` и возвращает старое содержащееся значение.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // БЕЗОПАСНОСТЬ: это может вызвать гонку данных при вызове из отдельного потока,
        // но `Cell`-это `!Sync`, поэтому этого не произойдет.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Разворачивает значение.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Возвращает копию содержащегося значения.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // БЕЗОПАСНОСТЬ: это может вызвать гонку данных при вызове из отдельного потока,
        // но `Cell`-это `!Sync`, поэтому этого не произойдет.
        unsafe { *self.value.get() }
    }

    /// Обновляет содержащееся значение с помощью функции и возвращает новое значение.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Возвращает необработанный указатель на базовые данные в этой ячейке.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Возвращает изменяемую ссылку на базовые данные.
    ///
    /// Этот вызов заимствует `Cell` изменчиво (во время компиляции), что гарантирует, что у нас есть единственная ссылка.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Возвращает `&Cell<T>` из `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // БЕЗОПАСНОСТЬ: `&mut` обеспечивает уникальный доступ.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Принимает значение ячейки, оставляя `Default::default()` на своем месте.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Возвращает `&[Cell<T>]` из `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // БЕЗОПАСНОСТЬ: `Cell<T>` имеет такое же расположение памяти, что и `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Изменяемая область памяти с динамически проверяемыми правилами заимствования
///
/// См. [module-level documentation](self) для получения дополнительной информации.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Ошибка, возвращенная [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Ошибка, возвращенная [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Положительные значения представляют количество активных `Ref`.Отрицательные значения представляют количество активных `RefMut`.
// Несколько `RefMut`s могут быть активны одновременно, только если они относятся к отдельным, неперекрывающимся компонентам `RefCell` (например, различным диапазонам среза).
//
// `Ref` и `RefMut` имеют размер в два слова, и поэтому, вероятно, никогда не будет достаточно существующих `Ref`s или`RefMut`s, чтобы выйти за пределы половины диапазона `usize`.
// Таким образом, `BorrowFlag`, вероятно, никогда не будет переполнен или опустошен.
// Однако это не является гарантией, так как патологическая программа может многократно создавать, а затем mem::forget `Ref`s или`RefMut`s.
// Таким образом, весь код должен явно проверять переполнение и недостаточное заполнение, чтобы избежать небезопасности, или, по крайней мере, вести себя правильно в случае переполнения или недостаточного заполнения (например, см. BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Создает новый `RefCell`, содержащий `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Потребляет `RefCell`, возвращая обернутое значение.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Поскольку эта функция принимает `self` (`RefCell`) по значению, компилятор статически проверяет, не заимствован ли он в данный момент.
        //
        self.value.into_inner()
    }

    /// Заменяет обернутое значение новым, возвращая старое значение без деинициализации ни одного из них.
    ///
    ///
    /// Эта функция соответствует [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics, если значение в настоящее время заимствовано.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Заменяет обернутое значение новым, вычисленным из `f`, возвращая старое значение без деинициализации ни одного из них.
    ///
    ///
    /// # Panics
    ///
    /// Panics, если значение в настоящее время заимствовано.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Меняет местами обернутое значение `self` с обернутым значением `other` без деинициализации ни одного из них.
    ///
    ///
    /// Эта функция соответствует [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics, если значение в любом из `RefCell` в настоящее время заимствовано.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Неизменно заимствует обернутую стоимость.
    ///
    /// Заимствование длится до тех пор, пока возвращенный `Ref` не выйдет из области видимости.
    /// Одновременно можно получить несколько неизменных заимствований.
    ///
    /// # Panics
    ///
    /// Panics, если значение в настоящее время взаимно заимствовано.
    /// Для варианта без паники используйте [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Пример panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Неизменно заимствует обернутое значение, возвращая ошибку, если значение в настоящее время заимствовано взаимно.
    ///
    ///
    /// Заимствование длится до тех пор, пока возвращенный `Ref` не выйдет из области видимости.
    /// Одновременно можно получить несколько неизменных заимствований.
    ///
    /// Это вариант [`borrow`](#method.borrow) без паники.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // БЕЗОПАСНОСТЬ: `BorrowRef` гарантирует, что существует только неизменный доступ
            // к стоимости при заимствовании.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Взаимно заимствует обернутую стоимость.
    ///
    /// Заимствование продолжается до тех пор, пока возвращенный `RefMut` или все производные от него `RefMut 'не выйдут из области видимости.
    ///
    /// Стоимость не может быть заимствована, пока этот заем активен.
    ///
    /// # Panics
    ///
    /// Panics, если значение в настоящее время заимствовано.
    /// Для варианта без паники используйте [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Пример panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Взаимно заимствует обернутое значение, возвращая ошибку, если значение в настоящее время заимствовано.
    ///
    ///
    /// Заимствование продолжается до тех пор, пока возвращенный `RefMut` или все производные от него `RefMut 'не выйдут из области видимости.
    /// Стоимость не может быть заимствована, пока этот заем активен.
    ///
    /// Это вариант [`borrow_mut`](#method.borrow_mut) без паники.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // БЕЗОПАСНОСТЬ: `BorrowRef` гарантирует уникальный доступ.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Возвращает необработанный указатель на базовые данные в этой ячейке.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Возвращает изменяемую ссылку на базовые данные.
    ///
    /// Этот вызов заимствует `RefCell` изменчиво (во время компиляции), поэтому нет необходимости в динамических проверках.
    ///
    /// Однако будьте осторожны: этот метод предполагает, что `self` будет изменяемым, что обычно не происходит при использовании `RefCell`.
    ///
    /// Взгляните на метод [`borrow_mut`] вместо этого, если `self` не изменяемый.
    ///
    /// Кроме того, имейте в виду, что этот метод предназначен только для особых обстоятельств и обычно не то, что вам нужно.
    /// В случае сомнений используйте [`borrow_mut`].
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Устраните влияние утечки средств защиты на состояние заимствования `RefCell`.
    ///
    /// Этот вызов аналогичен вызову [`get_mut`], но более специализирован.
    /// Он взаимно заимствует `RefCell`, чтобы гарантировать отсутствие заимствований, а затем сбрасывает общие заимствования для отслеживания состояния.
    /// Это актуально, если произошла утечка некоторых займов `Ref` или `RefMut`.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Неизменно заимствует обернутое значение, возвращая ошибку, если значение в настоящее время заимствовано взаимно.
    ///
    /// # Safety
    ///
    /// В отличие от `RefCell::borrow`, этот метод небезопасен, поскольку он не возвращает `Ref`, поэтому флаг заимствования остается нетронутым.
    /// Взаимное заимствование `RefCell` при активной ссылке, возвращаемой этим методом, является неопределенным поведением.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // БЕЗОПАСНОСТЬ: Мы проверяем, что сейчас никто не пишет активно, но это
            // ответственность вызывающей стороны за то, чтобы никто не записывал, пока возвращенная ссылка не перестанет использоваться.
            // Кроме того, `self.value.get()` относится к значению, принадлежащему `self`, и, таким образом, гарантированно действует в течение всего срока службы `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Принимает обернутое значение, оставляя `Default::default()` на своем месте.
    ///
    /// # Panics
    ///
    /// Panics, если значение в настоящее время заимствовано.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics, если значение в настоящее время взаимно заимствовано.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Создает `RefCell<T>` со значением `Default` для T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics, если значение в любом из `RefCell` в настоящее время заимствовано.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics, если значение в любом из `RefCell` в настоящее время заимствовано.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics, если значение в любом из `RefCell` в настоящее время заимствовано.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, если значение в любом из `RefCell` в настоящее время заимствовано.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, если значение в любом из `RefCell` в настоящее время заимствовано.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, если значение в любом из `RefCell` в настоящее время заимствовано.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics, если значение в любом из `RefCell` в настоящее время заимствовано.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Увеличение заимствования может привести к нечитаемому значению (<=0) в следующих случаях:
            // 1. Было <0, то есть есть заимствования для записи, поэтому мы не можем разрешить заимствование для чтения из-за правил псевдонима ссылок Rust
            // 2.
            // Это было isize::MAX (максимальное количество заимствований для чтения), и оно переполнилось в isize::MIN (максимальное количество заимствований для записи), поэтому мы не можем разрешить дополнительное заимствование для чтения, потому что isize не может представлять такое количество заимствований для чтения (это может произойти только в вы на mem::forget больше, чем небольшое постоянное количество `Ref`s, что не является хорошей практикой)
            //
            //
            //
            //
            None
        } else {
            // Увеличение заимствования может привести к считыванию значения (> 0) в следующих случаях:
            // 1. Было=0, т.е. не было заимствовано, и мы берем первое чтение заимствования
            // 2. Было> 0 и <isize::MAX, т.е.
            // были заимствования для чтения, а isize достаточно велик, чтобы представить еще одно заимствование для чтения
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Поскольку эта ссылка существует, мы знаем, что флаг заимствования является заимствованием для чтения.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Не допускайте переполнения счетчика займов в письменный заем.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Оборачивает заимствованную ссылку на значение в поле `RefCell`.
/// Тип оболочки для неизменяемого значения, заимствованного у `RefCell<T>`.
///
/// См. [module-level documentation](self) для получения дополнительной информации.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Копирует `Ref`.
    ///
    /// `RefCell` уже безоговорочно заимствован, так что это не может быть ошибкой.
    ///
    /// Это связанная функция, которую нужно использовать как `Ref::clone(...)`.
    /// Реализация `Clone` или метод могут помешать широкому использованию `r.borrow().clone()` для клонирования содержимого `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Делает новый `Ref` для компонента заимствованных данных.
    ///
    /// `RefCell` уже безоговорочно заимствован, так что это не может быть ошибкой.
    ///
    /// Это связанная функция, которую нужно использовать как `Ref::map(...)`.
    /// Метод будет мешать одноименным методам содержимого `RefCell`, используемого через `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Делает новый `Ref` для дополнительного компонента заимствованных данных.
    /// Исходная защита возвращается как `Err(..)`, если закрытие возвращает `None`.
    ///
    /// `RefCell` уже безоговорочно заимствован, так что это не может быть ошибкой.
    ///
    /// Это связанная функция, которую нужно использовать как `Ref::filter_map(...)`.
    /// Метод будет мешать одноименным методам содержимого `RefCell`, используемого через `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Разбивает `Ref` на несколько ссылок для разных компонентов заимствованных данных.
    ///
    /// `RefCell` уже безоговорочно заимствован, так что это не может быть ошибкой.
    ///
    /// Это связанная функция, которую нужно использовать как `Ref::map_split(...)`.
    /// Метод будет мешать одноименным методам содержимого `RefCell`, используемого через `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Преобразуйте в ссылку на базовые данные.
    ///
    /// Базовый `RefCell` никогда не может быть взаимно заимствован снова и всегда будет казаться уже неизменным заимствованным.
    ///
    /// Не рекомендуется допускать утечку большего количества ссылок, чем постоянное.
    /// `RefCell` можно безоговорочно одолжить снова, если в целом произошло лишь меньшее количество утечек.
    ///
    /// Это связанная функция, которую нужно использовать как `Ref::leak(...)`.
    /// Метод будет мешать одноименным методам содержимого `RefCell`, используемого через `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Забыв об этом RefCell, мы гарантируем, что счетчик займов в RefCell не сможет вернуться в состояние НЕИСПОЛЬЗОВАНИЕ в течение срока службы `'b`.
        // Для сброса состояния отслеживания ссылок потребуется уникальная ссылка на заимствованную RefCell.
        // Из исходной ячейки невозможно создать дальнейшие изменяемые ссылки.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Создает новый `RefMut` для компонента заимствованных данных, например, вариант перечисления.
    ///
    /// `RefCell` уже взаимно заимствован, так что это не может потерпеть неудачу.
    ///
    /// Это связанная функция, которую нужно использовать как `RefMut::map(...)`.
    /// Метод будет мешать одноименным методам содержимого `RefCell`, используемого через `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): исправить заем-чек
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Делает новый `RefMut` для дополнительного компонента заимствованных данных.
    /// Исходная защита возвращается как `Err(..)`, если закрытие возвращает `None`.
    ///
    /// `RefCell` уже взаимно заимствован, так что это не может потерпеть неудачу.
    ///
    /// Это связанная функция, которую нужно использовать как `RefMut::filter_map(...)`.
    /// Метод будет мешать одноименным методам содержимого `RefCell`, используемого через `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): исправить заем-чек
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // БЕЗОПАСНОСТЬ: функция удерживает исключительную ссылку на время
        // его вызова через `orig`, и указатель отменяется только внутри вызова функции, никогда не позволяя исключительной ссылке уйти.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // БЕЗОПАСНОСТЬ: как указано выше.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Разбивает `RefMut` на несколько RefMut для разных компонентов заимствованных данных.
    ///
    /// Базовый `RefCell` останется взаимно заимствованным до тех пор, пока оба возвращенных `RefMut`s не выйдут из области видимости.
    ///
    /// `RefCell` уже взаимно заимствован, так что это не может потерпеть неудачу.
    ///
    /// Это связанная функция, которую нужно использовать как `RefMut::map_split(...)`.
    /// Метод будет мешать одноименным методам содержимого `RefCell`, используемого через `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Преобразуйте в изменяемую ссылку на базовые данные.
    ///
    /// Базовый `RefCell` не может быть заимствован снова и всегда будет казаться уже взаимно заимствованным, что делает возвращенную ссылку только на внутреннюю часть.
    ///
    ///
    /// Это связанная функция, которую нужно использовать как `RefMut::leak(...)`.
    /// Метод будет мешать одноименным методам содержимого `RefCell`, используемого через `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Забывая об этом BorrowRefMut, мы гарантируем, что счетчик займов в RefCell не сможет вернуться в состояние НЕИСПОЛЬЗУЕМЫЙ в течение срока жизни `'b`.
        // Для сброса состояния отслеживания ссылок потребуется уникальная ссылка на заимствованную RefCell.
        // Никакие дополнительные ссылки не могут быть созданы из исходной ячейки в течение этого времени жизни, что делает текущую заимствованную ссылку единственной ссылкой на оставшееся время жизни.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: В отличие от BorrowRefMut::clone, new вызывается для создания начального
        // изменяемая ссылка, поэтому в настоящее время не должно быть существующих ссылок.
        // Таким образом, хотя clone увеличивает изменяемый счетчик ссылок, здесь мы явно разрешаем только переход от UNUSED к UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Клонирует `BorrowRefMut`.
    //
    // Это действительно только в том случае, если каждый `BorrowRefMut` используется для отслеживания изменяемой ссылки на отдельный неперекрывающийся диапазон исходного объекта.
    //
    // Это не подразумевается в клонировании, поэтому код не вызывает это неявно.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Не допускайте переполнения счетчика займов.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Тип оболочки для взаимно заимствованного значения из `RefCell<T>`.
///
/// См. [module-level documentation](self) для получения дополнительной информации.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Основной примитив для внутренней изменчивости в Rust.
///
/// Если у вас есть эталонный `&T`, то обычно в Rust компилятор выполняет оптимизацию, основываясь на знании того, что `&T` указывает на неизменяемые данные.Изменение этих данных, например, через псевдоним или преобразование `&T` в `&mut T`, считается неопределенным поведением.
/// `UnsafeCell<T>` отказывается от гарантии неизменности для `&T`: общая ссылка `&UnsafeCell<T>` может указывать на изменяемые данные.Это называется "interior mutability".
///
/// Все другие типы, допускающие внутреннюю изменчивость, такие как `Cell<T>` и `RefCell<T>`, внутренне используют `UnsafeCell` для обертывания своих данных.
///
/// Обратите внимание, что `UnsafeCell` влияет только на гарантию неизменности общих ссылок.Гарантия уникальности изменяемых ссылок не затрагивается.*Нет* легального способа получить псевдоним `&mut`, даже с `UnsafeCell<T>`.
///
/// Сам API `UnsafeCell` технически очень прост: [`.get()`] дает вам необработанный указатель `*mut T` на его содержимое._you_ как разработчик абстракции должен правильно использовать этот необработанный указатель.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Точные правила алиасинга Rust несколько изменяются, но основные моменты не вызывают споров:
///
/// - Если вы создаете безопасную ссылку с временем жизни `'a` (ссылка `&T` или `&mut T`), доступная по безопасному коду (например, потому что вы ее вернули), то вы не должны обращаться к данным каким-либо образом, который противоречит этой ссылке для оставшейся части. из `'a`.
/// Например, это означает, что если вы берете `*mut T` из `UnsafeCell<T>` и преобразуете его в `&T`, то данные в `T` должны оставаться неизменными (конечно, по модулю любых данных `UnsafeCell`, найденных в `T`) до тех пор, пока не истечет время жизни этой ссылки.
/// Точно так же, если вы создаете ссылку `&mut T`, которая выпущена для безопасного кода, вы не должны обращаться к данным в `UnsafeCell`, пока эта ссылка не истечет.
///
/// - Всегда следует избегать гонок за данные.Если несколько потоков имеют доступ к одному и тому же `UnsafeCell`, тогда любая запись должна иметь правильное отношение «произошло до» ко всем другим доступам (или использовать атомику).
///
/// Чтобы помочь с правильным проектированием, следующие сценарии явно объявлены допустимыми для однопоточного кода:
///
/// 1. Ссылка `&T` может быть выпущена для безопасного кода, и там она может сосуществовать с другими ссылками `&T`, но не с `&mut T`.
///
/// 2. Ссылка `&mut T` может быть выпущена для безопасного кода при условии, что с ней не сосуществуют ни другие `&mut T`, ни `&T`.`&mut T` всегда должен быть уникальным.
///
/// Обратите внимание, что при изменении содержимого `&UnsafeCell<T>` (даже если другие `&UnsafeCell<T>` ссылаются на псевдоним ячейки) все в порядке (при условии, что вы принудительно применяете вышеуказанные инварианты каким-либо другим способом), наличие нескольких псевдонимов `&mut UnsafeCell<T>` по-прежнему является неопределенным поведением.
/// То есть `UnsafeCell`-это оболочка, предназначенная для особого взаимодействия с _shared_ accesses (_i.e._ через ссылку `&UnsafeCell<_>`);нет никакого волшебства при работе с _exclusive_ accesses (_e.g._ через `&mut UnsafeCell<_>`): ни ячейка, ни обернутое значение не могут иметь псевдонима на время этого заимствования `&mut`.
///
/// Это демонстрируется аксессуаром [`.get_mut()`], который представляет собой _safe_ getter, который дает `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Вот пример, демонстрирующий, как правильно изменить содержимое `UnsafeCell<_>`, несмотря на то, что имеется несколько ссылок с псевдонимом ячейки:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Получите несколько/одновременных/общих ссылок на один и тот же `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // БЕЗОПАСНОСТЬ: в этой области нет других ссылок на содержимое `x`,
///     // так что наш действительно уникален.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- брать взаймы-+
///     *p1_exclusive += 27; // |
/// } // <---------- не может выйти за пределы этой точки -------------------+
///
/// unsafe {
///     // БЕЗОПАСНОСТЬ: в этой области никто не ожидает эксклюзивного доступа к содержимому `x`,
///     // так что мы можем иметь несколько общих доступов одновременно.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Следующий пример демонстрирует тот факт, что эксклюзивный доступ к `UnsafeCell<T>` подразумевает эксклюзивный доступ к его `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // с эксклюзивным доступом,
///                         // `UnsafeCell` - это прозрачная обертка без операций, поэтому здесь нет необходимости в `unsafe`.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Получите уникальную ссылку на `x`, проверенную во время компиляции.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Имея эксклюзивную ссылку, мы можем бесплатно изменять содержимое.
/// *p_unique.get_mut() = 0;
/// // Или, что то же самое:
/// x = UnsafeCell::new(0);
///
/// // Когда мы владеем ценностью, мы можем извлекать содержимое бесплатно.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Создает новый экземпляр `UnsafeCell`, который будет заключать указанное значение в оболочку.
    ///
    ///
    /// Все методы доступа к внутреннему значению-`unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Разворачивает значение.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Получает изменяемый указатель на заключенное в оболочку значение.
    ///
    /// Это может быть приведено к указателю любого типа.
    /// Убедитесь, что доступ является уникальным (нет активных ссылок, изменяемых или нет) при преобразовании в `&mut T`, и убедитесь, что нет никаких мутаций или изменяемых псевдонимов, происходящих при преобразовании в `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Мы можем просто преобразовать указатель с `UnsafeCell<T>` на `T` из-за #[repr(transparent)].
        // Это использует особый статус libstd, для пользовательского кода нет гарантии, что это будет работать в версиях компилятора future!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Возвращает изменяемую ссылку на базовые данные.
    ///
    /// Этот вызов заимствует `UnsafeCell` изменчиво (во время компиляции), что гарантирует, что у нас есть единственная ссылка.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Получает изменяемый указатель на заключенное в оболочку значение.
    /// Отличие от [`get`] в том, что эта функция принимает необработанный указатель, что позволяет избежать создания временных ссылок.
    ///
    /// Результат может быть приведен к указателю любого типа.
    /// Убедитесь, что доступ является уникальным (нет активных ссылок, изменяемых или нет) при преобразовании в `&mut T`, и убедитесь, что при преобразовании в `&T` не происходит никаких мутаций или изменяемых псевдонимов.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Для постепенной инициализации `UnsafeCell` требуется `raw_get`, так как для вызова `get` потребуется создать ссылку на неинициализированные данные:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Мы можем просто преобразовать указатель с `UnsafeCell<T>` на `T` из-за #[repr(transparent)].
        // Это использует особый статус libstd, для пользовательского кода нет гарантии, что это будет работать в версиях компилятора future!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Создает `UnsafeCell` со значением `Default` для T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}