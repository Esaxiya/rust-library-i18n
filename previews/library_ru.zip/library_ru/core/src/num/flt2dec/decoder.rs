//! Расшифровывает значение с плавающей запятой на отдельные части и диапазоны ошибок.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Декодированное беззнаковое конечное значение, такое что:
///
/// - Исходное значение равно `mant * 2^exp`.
///
/// - Любое число от `(mant - minus)*2^exp` до `(mant + plus)* 2^exp` будет округлено до исходного значения.
/// Диапазон является включительным, только когда `inclusive` равен `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Чешуйчатая мантисса.
    pub mant: u64,
    /// Нижний диапазон ошибок.
    pub minus: u64,
    /// Верхний диапазон ошибок.
    pub plus: u64,
    /// Общий показатель степени в базе 2.
    pub exp: i16,
    /// Верно, если диапазон ошибок включен.
    ///
    /// В IEEE 754 это верно, когда исходная мантисса была четной.
    pub inclusive: bool,
}

/// Декодированное беззнаковое значение.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Бесконечности, положительные или отрицательные.
    Infinite,
    /// Ноль, либо положительный, либо отрицательный.
    Zero,
    /// Конечные числа с дополнительными декодированными полями.
    Finite(Decoded),
}

/// Тип с плавающей запятой, который можно декодировать.
pub trait DecodableFloat: RawFloat + Copy {
    /// Минимальное положительное нормализованное значение.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Возвращает знак (истина при отрицательном значении) и значение `FullDecoded` из заданного числа с плавающей запятой.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // соседи: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode всегда сохраняет показатель степени, поэтому мантисса масштабируется для субнормальных величин.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // соседи: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // где maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // соседи: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}