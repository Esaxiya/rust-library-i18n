//! Почти прямой (но немного оптимизированный) перевод Rust рисунка 3 из «Быстрая и точная печать чисел с плавающей запятой» [^ 1].
//!
//!
//! [^1]: Burger, Р.Г. и Дибвиг, Р.К. 1996. Печать чисел с плавающей запятой.
//!   быстро и точно.СИГПЛАН Нет.31, 5 (май 1996 г.), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// предварительно вычисленные массивы `Digit`s для 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// можно использовать только с `x < 16 * scale`;`scaleN` должно быть `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Самая короткая реализация режима для Дракона.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // известное число `v` для форматирования:
    // - равно `mant * 2^exp`;
    // - предшествует `(mant - 2 *minus)* 2^exp` в исходном виде;а также
    // - за которым следует `(mant + 2 *plus)* 2^exp` в исходном виде.
    //
    // очевидно, что `minus` и `plus` не могут быть равны нулю.(для бесконечностей мы используем значения, выходящие за пределы допустимого диапазона.) Также мы предполагаем, что генерируется хотя бы одна цифра, т.е. `mant` тоже не может быть нулевым.
    //
    // это также означает, что любое число от `low = (mant - minus)*2^exp` до `high = (mant + plus)* 2^exp` будет отображаться на это точное число с плавающей запятой, с включенными границами, когда исходная мантисса была четной (т. е. `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` это `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // оценить `k_0` из исходных входных данных, удовлетворяющих `10^(k_0-1) < high <= 10^(k_0+1)`.
    // жесткая граница `k`, удовлетворяющая `10^(k-1) < high <= 10^k`, рассчитывается позже.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // преобразовать `{mant, plus, minus} * 2^exp` в дробную форму так, чтобы:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // разделите `mant` на `10^k`.теперь `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // исправление, когда `mant + plus > scale` (или `>=`).
    // мы фактически не модифицируем `scale`, так как вместо этого мы можем пропустить начальное умножение.
    // теперь `scale < mant + plus <= scale * 10`, и мы готовы генерировать цифры.
    //
    // обратите внимание, что `d[0]`*может* быть нулевым, когда `scale - plus < mant < scale`.
    // в этом случае немедленно срабатывает условие округления (`up` ниже).
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // эквивалент масштабирования `scale` на 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // кеш `(2, 4, 8) * scale` для генерации цифр.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // инварианты, где `d[0..n-1]`-цифры, сгенерированные на данный момент:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (таким образом, `mant / scale < 10`), где `d[i..j]`-это сокращение от `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // генерировать одну цифру: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // это упрощенное описание модифицированного алгоритма Дракона.
        // многие промежуточные выводы и аргументы полноты опущены для удобства.
        //
        // начнем с модифицированных инвариантов, поскольку мы обновили `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // Предположим, что `d[0..n-1]` является кратчайшим представлением между `low` и `high`, т. е. `d[0..n-1]` удовлетворяет обоим из следующих условий, а `d[0..n-2]`-нет:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (биективность: цифры округляются до `v`);а также
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (последняя цифра правильная).
        //
        // второе условие упрощается до `2 * mant <= scale`.
        // решение инвариантов в терминах `mant`, `low` и `high` дает более простую версию первого условия: `-plus < mant < minus`.
        // начиная с `-plus < 0 <= mant`, у нас есть правильное кратчайшее представление, когда `mant < minus` и `2 * mant <= scale`.
        // (первый становится `mant <= minus`, когда исходная мантисса четная.)
        //
        // когда вторая не удерживается (`2 * mant> scale`), нам нужно увеличить последнюю цифру.
        // этого достаточно для восстановления этого состояния: мы уже знаем, что генерация цифр гарантирует `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // в этом случае первое условие становится `-plus < mant - scale < minus`.
        // так как `mant < scale` после поколения, у нас есть `scale < mant + plus`.
        // (опять же, это становится `scale <= mant + plus`, когда исходная мантисса четная.)
        //
        // коротко:
        // - остановить и округлить `down` (оставить цифры как есть), когда `mant < minus` (или `<=`).
        // - остановитесь и округлите `up` (увеличьте последнюю цифру), когда `scale < mant + plus` (или `<=`).
        // - в противном случае продолжайте генерировать.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // имеем кратчайшее представление, приступаем к округлению

        // восстановить инварианты.
        // это приводит к тому, что алгоритм всегда завершается: `minus` и `plus` всегда увеличиваются, но `mant` обрезается по модулю `scale`, а `scale` фиксируется.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // Округление в большую сторону происходит, когда i) было запущено только условие округления, или ii) оба условия были запущены, и при равенстве голосов предпочтительнее округление в большую сторону.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // если округление изменяет длину, показатель степени также должен измениться.
        // кажется, что это условие очень трудно выполнить (возможно, невозможно), но здесь мы просто осторожны и последовательны.
        //
        // БЕЗОПАСНОСТЬ: мы инициализировали эту память выше.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // БЕЗОПАСНОСТЬ: мы инициализировали эту память выше.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Реализация точного и фиксированного режима для Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // оценить `k_0` из исходных входных данных, удовлетворяющих `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // разделите `mant` на `10^k`.теперь `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // fixup при `mant + plus >= scale`, где `plus / scale = 10^-buf.len() / 2`.
    // чтобы сохранить фиксированный размер, мы фактически используем `mant + floor(plus) >= scale`.
    // мы фактически не модифицируем `scale`, так как вместо этого мы можем пропустить начальное умножение.
    // опять же, при использовании кратчайшего алгоритма `d[0]` может быть равен нулю, но в конечном итоге будет округлен.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // эквивалент масштабирования `scale` на 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // если мы работаем с ограничением последней цифры, нам нужно сократить буфер перед фактическим рендерингом, чтобы избежать двойного округления.
    //
    // обратите внимание, что мы должны снова увеличить буфер, когда происходит округление!
    let mut len = if k < limit {
        // ой, мы не можем даже вывести *одну* цифру.
        // это возможно, когда, скажем, у нас есть что-то вроде 9.5, и оно округляется до 10.
        // мы возвращаем пустой буфер, за исключением более позднего случая округления, который происходит, когда `k == limit` и должен выдать ровно одну цифру.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // кеш `(2, 4, 8) * scale` для генерации цифр.
        // (это может быть дорого, поэтому не рассчитывайте их, когда буфер пуст.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // следующие цифры-все нули, мы останавливаемся на этом *не* пытаемся выполнить округление!вместо этого заполните оставшиеся цифры.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // БЕЗОПАСНОСТЬ: мы инициализировали эту память выше.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // округление в большую сторону, если мы остановимся на середине цифр, если следующие цифры равны точно 5000 ..., проверьте предыдущую цифру и попытайтесь округлить до четного (т. е. избегать округления в большую сторону, если предыдущая цифра четная).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // БЕЗОПАСНОСТЬ: `buf[len-1]` инициализирован.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // если округление изменяет длину, показатель степени также должен измениться.
        // но нам было запрошено фиксированное количество цифр, поэтому не меняйте буфер ...
        // БЕЗОПАСНОСТЬ: мы инициализировали эту память выше.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... если вместо этого нам была предложена фиксированная точность.
            // нам также необходимо проверить, что, если исходный буфер был пуст, дополнительная цифра может быть добавлена только при `k == limit` (случай edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // БЕЗОПАСНОСТЬ: мы инициализировали эту память выше.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}