//! Оценка экспоненты.

/// Находит `k_0` такой, что `10^(k_0-1) < mant * 2^exp <= 10^(k_0+1)`.
///
/// Используется для приблизительного расчета `k = ceil(log_10 (mant * 2^exp))`;
/// настоящий `k`-это либо `k_0`, либо `k_0+1`.
#[doc(hidden)]
pub fn estimate_scaling_factor(mant: u64, exp: i16) -> i16 {
    // 2 ^ (nbits-1) <mant <=2 ^ nbits, если mant> 0
    let nbits = 64 - (mant - 1).leading_zeros() as i64;
    // 1292913986= floor(2^32 * log_10 2), поэтому это всегда занижает (или точно), но не намного.
    //
    (((nbits + exp as i64) * 1292913986) >> 32) as i16
}