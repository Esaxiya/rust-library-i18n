//! Константы для целочисленного типа без знака размером с указатель.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! Новый код должен использовать связанные константы непосредственно в примитивном типе.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }