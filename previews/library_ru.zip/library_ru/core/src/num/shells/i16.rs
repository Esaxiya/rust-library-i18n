//! Константы для 16-битного целочисленного типа со знаком.
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! Новый код должен использовать связанные константы непосредственно в примитивном типе.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }