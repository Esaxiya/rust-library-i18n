//! Константы для 8-битного целочисленного типа без знака.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! Новый код должен использовать связанные константы непосредственно в примитивном типе.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }