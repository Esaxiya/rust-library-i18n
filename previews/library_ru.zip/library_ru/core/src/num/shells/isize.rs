//! Константы для целочисленного типа со знаком размером с указатель.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! Новый код должен использовать связанные константы непосредственно в примитивном типе.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }