//! Служебные функции для бигнумов, которые не имеют особого смысла превращать в методы.

// FIXME Название этого модуля несколько неудачное, так как другие модули также импортируют `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Проверьте, приводит ли усечение всех битов, менее значимых, чем `ones_place`, относительную ошибку, меньшую, равную или большую, чем 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Если все оставшиеся биты равны нулю, это= 0.5 ULP, в противном случае> 0.5 Если битов больше нет (half_bit==0), то приведенное ниже также правильно возвращает Equal.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Преобразует строку ASCII, содержащую только десятичные цифры, в `u64`.
///
/// Не выполняет проверки на переполнение или недопустимые символы, поэтому, если вызывающий абонент не будет осторожен, результат будет фиктивным и может panic (хотя это не будет `unsafe`).
/// Кроме того, пустые строки считаются нулевыми.
/// Эта функция существует, потому что
///
/// 1. использование `FromStr` на `&[u8]` требует `from_utf8_unchecked`, что плохо, и
/// 2. собрать вместе результаты `integral.parse()` и `fractional.parse()` сложнее, чем вся эта функция.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Преобразует строку цифр ASCII в bignum.
///
/// Как и `from_str_unchecked`, эта функция полагается на анализатор для отсеивания нецифровых символов.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Преобразует bignum в 64-битное целое число.Panics, если число слишком велико.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Извлекает ряд битов.

/// Индекс 0-это младший бит, и диапазон, как обычно, наполовину открыт.
/// Panics, если его попросят извлечь больше битов, чем помещается в возвращаемый тип.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}