//! Проверка и разложение десятичной строки вида:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Другими словами, стандартный синтаксис с плавающей запятой с двумя исключениями: без знака и без обработки "inf" и "NaN".Они обрабатываются функцией драйвера (super::dec2flt).
//!
//! Хотя распознать действительные входные данные относительно просто, этот модуль также должен отклонять бесчисленные недопустимые варианты, никогда не panic, и выполнять многочисленные проверки, которые другие модули, в свою очередь, полагаются на panic (или переполнение).
//!
//! Что еще хуже, все это происходит за один проход над входом.
//! Так что будьте осторожны при изменении чего-либо и перепроверьте с другими модулями.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Интересные части десятичной строки.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Десятичный показатель степени, который гарантированно состоит менее чем из 18 десятичных цифр.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Проверяет, является ли входная строка допустимым числом с плавающей запятой, и если да, найдите в ней целую часть, дробную часть и показатель степени.
/// Не обрабатывает вывески.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Без цифр перед 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Нам нужна как минимум одна цифра до или после точки.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Конечный мусор после дробной части
            }
        }
        _ => Invalid, // Конечный мусор после первой строки цифр
    }
}

/// Удаляет десятичные цифры до первого нецифрового символа.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Извлечение экспоненты и проверка ошибок.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Конечный мусор после экспоненты
    }
    if number.is_empty() {
        return Invalid; // Пустая экспонента
    }
    // На данный момент у нас определенно есть действительная строка цифр.Это может быть слишком долго, чтобы помещать его в `i64`, но если он такой большой, вход, безусловно, равен нулю или бесконечности.
    // Поскольку каждый ноль в десятичных разрядах регулирует экспоненту только на +/-1, при exp=10 ^ 18 ввод должен быть 17 эксабайт (!) нулей, чтобы даже отдаленно приблизиться к конечному значению.
    //
    // Это не совсем тот вариант использования, который нам нужен.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}