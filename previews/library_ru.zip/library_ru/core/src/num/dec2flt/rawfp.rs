//! Попытка исправить положительные значения IEEE 754 с плавающей запятой.Отрицательные числа не обрабатываются и не должны обрабатываться.
//! Нормальные числа с плавающей запятой имеют каноническое представление как (frac, exp), так что значение равно 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)), где N-количество бит.
//!
//! Субнормальные существа немного разные и странные, но действует тот же принцип.
//!
//! Здесь, однако, мы представляем их как (sig, k) с положительным f, так что значение равно f *
//! 2 <sup>е</sup> .Это не только делает "hidden bit" явным, но и изменяет показатель степени за счет так называемого сдвига мантиссы.
//!
//! Другими словами, обычно числа с плавающей запятой записываются как (1), но здесь они записываются как (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Мы называем (1)**дробным представлением** и (2)**интегральным представлением**.
//!
//! Многие функции в этом модуле обрабатывают только обычные числа.Подпрограммы dec2flt консервативно выбирают универсально правильный медленный путь (алгоритм M) для очень маленьких и очень больших чисел.
//! Этому алгоритму нужен только next_float(), который обрабатывает субнормальные значения и нули.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Помощник trait, чтобы избежать дублирования в основном всего кода преобразования для `f32` и `f64`.
///
/// См. Комментарий к документации родительского модуля, чтобы узнать, почему это необходимо.
///
/// **никогда** никогда не должно реализовываться для других типов или использоваться вне модуля dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Тип, используемый `to_bits` и `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Выполняет необработанное преобразование в целое число.
    fn to_bits(self) -> Self::Bits;

    /// Выполняет необработанное преобразование из целого числа.
    fn from_bits(v: Self::Bits) -> Self;

    /// Возвращает категорию, в которую попадает это число.
    fn classify(self) -> FpCategory;

    /// Возвращает мантиссу, показатель степени и знак как целые числа.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Расшифровывает поплавок.
    fn unpack(self) -> Unpacked;

    /// Приведение к небольшому целому числу, которое может быть представлено точно.
    /// Panic, если целое число не может быть представлено, другой код в этом модуле никогда не допустит этого.
    fn from_int(x: u64) -> Self;

    /// Получает значение 10 <sup>e</sup> из предварительно вычисленной таблицы.
    /// Panics для `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Что говорит название.
    /// Проще написать жесткий код, чем манипулировать встроенными функциями и надеяться, что константа LLVM сворачивает их.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Консервативная граница десятичных цифр входных данных, которая не может привести к переполнению или нулю или
    /// субнормальные.Вероятно, десятичный показатель максимального нормального значения, отсюда и название.
    const MAX_NORMAL_DIGITS: usize;

    /// Когда самая значимая десятичная цифра имеет разрядное значение больше, чем это, число обязательно округляется до бесконечности.
    ///
    const INF_CUTOFF: i64;

    /// Когда самая значимая десятичная цифра имеет разрядное значение меньше этого, число обязательно округляется до нуля.
    ///
    const ZERO_CUTOFF: i64;

    /// Количество бит в экспоненте.
    const EXP_BITS: u8;

    /// Количество бит в мантиссе, включая * скрытый бит.
    const SIG_BITS: u8;

    /// Количество бит в мантиссе,*исключая* скрытый бит.
    const EXPLICIT_SIG_BITS: u8;

    /// Максимальный показатель степени в дробном представлении.
    const MAX_EXP: i16;

    /// Минимальный допустимый показатель степени в дробном представлении, исключая субнормальные числа.
    const MIN_EXP: i16;

    /// `MAX_EXP` для интегрального представления, т. е. с примененным сдвигом.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` закодированные (т. е. со смещением смещения)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` для интегрального представления, т. е. с примененным сдвигом.
    const MIN_EXP_INT: i16;

    /// Максимальная нормированная манга в интегральном представлении.
    const MAX_SIG: u64;

    /// Минимальная нормализованная манга в интегральном представлении.
    const MIN_SIG: u64;
}

// В основном это обходной путь для #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Возвращает мантиссу, показатель степени и знак как целые числа.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Смещение экспоненты + сдвиг мантиссы
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe не уверена, правильно ли `as` выполняет округление на всех платформах.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Возвращает мантиссу, показатель степени и знак как целые числа.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Смещение экспоненты + сдвиг мантиссы
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe не уверена, правильно ли `as` выполняет округление на всех платформах.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Преобразует `Fp` в ближайший к машине плавающий тип.
/// Не справляется с ненормальными результатами.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 бит, поэтому xe имеет сдвиг мантиссы 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Округлите 64-битное значение до T::SIG_BITS разрядов с точностью до половины.
/// Не обрабатывает переполнение экспоненты.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Отрегулируйте сдвиг мантиссы
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Инверсия `RawFloat::unpack()` для нормализованных чисел.
/// Panics, если мантисса или показатель недействительны для нормализованных чисел.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Удалите скрытый бит
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Отрегулируйте экспоненту для смещения экспоненты и сдвига мантиссы
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Оставьте знаковый бит на 0 ("+"), все наши числа положительны
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Постройте субнормальное.Допускается мантисса 0, равная нулю.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Кодированная экспонента равна 0, бит знака равен 0, поэтому нам просто нужно заново интерпретировать биты.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Приблизьте бигнум с Fp.Раунды в пределах 0.5 ULP с точностью до половины.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Мы отсекаем все биты перед индексом `start`, т. Е. Мы фактически сдвигаем вправо на величину `start`, так что это тоже показатель степени, который нам нужен.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Округлить (half-to-even) в зависимости от усеченных битов.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Находит наибольшее число с плавающей запятой, строго меньшее, чем аргумент.
/// Не обрабатывает субнормальные, нулевые или экспоненциальные потери.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Найдите наименьшее число с плавающей запятой, строго превышающее аргумент.
// Это операция насыщения, т.е. next_float(inf) ==inf.
// В отличие от большей части кода в этом модуле, эта функция обрабатывает ноль, субнормальные значения и бесконечности.
// Однако, как и весь другой код здесь, он не имеет дело с NaN и отрицательными числами.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Это кажется слишком хорошим, чтобы быть правдой, но это работает.
        // 0.0 кодируется как слово "все нули".Субнормальные значения-это 0x000m ... m, где m-мантисса.
        // В частности, наименьшее субнормальное значение-0x0 ... 01, а наибольшее-0x000F ... F.
        // Наименьшее нормальное число-0x0010 ... 0, поэтому этот угловой случай тоже работает.
        // Если приращение превышает мантиссу, бит переноса увеличивает экспоненту так, как мы хотим, и биты мантиссы становятся равными нулю.
        // Из-за соглашения о скрытых битах это тоже именно то, что нам нужно!
        // Наконец, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}