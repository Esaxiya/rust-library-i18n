//! Типы ошибок для преобразования в целые типы.

use crate::convert::Infallible;
use crate::fmt;

/// Тип ошибки, возвращаемый в случае сбоя проверенного преобразования целочисленного типа.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Сопоставление, а не принуждение, чтобы гарантировать, что код, подобный `From<Infallible> for TryFromIntError` выше, будет продолжать работать, когда `Infallible` станет псевдонимом `!`.
        //
        //
        match never {}
    }
}

/// Ошибка, которая может быть возвращена при разборе целого числа.
///
/// Эта ошибка используется в качестве типа ошибки для функций `from_str_radix()` для примитивных целочисленных типов, таких как [`i8::from_str_radix`].
///
/// # Возможные причины
///
/// Среди других причин, `ParseIntError` может быть брошен из-за начальных или конечных пробелов в строке, например, когда он получен из стандартного ввода.
///
/// Использование метода [`str::trim()`] гарантирует, что перед синтаксическим анализом не останется пробелов.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum для хранения различных типов ошибок, которые могут привести к сбою синтаксического анализа целого числа.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Анализируемое значение пусто.
    ///
    /// Среди прочего, этот вариант будет построен при разборе пустой строки.
    Empty,
    /// Содержит недопустимую цифру в своем контексте.
    ///
    /// Среди прочего, этот вариант будет создан при синтаксическом анализе строки, содержащей не-ASCII char.
    ///
    /// Этот вариант также создается, когда `+` или `-` неуместны в строке либо сами по себе, либо в середине числа.
    ///
    ///
    InvalidDigit,
    /// Целое число слишком велико для хранения в целевом целочисленном типе.
    PosOverflow,
    /// Целое число слишком мало для хранения в целевом целочисленном типе.
    NegOverflow,
    /// Значение было нулевым
    ///
    /// Этот вариант будет выдан, когда строка синтаксического анализа имеет нулевое значение, что было бы недопустимо для ненулевых типов.
    ///
    Zero,
}

impl ParseIntError {
    /// Выводит подробную причину сбоя анализа целого числа.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}