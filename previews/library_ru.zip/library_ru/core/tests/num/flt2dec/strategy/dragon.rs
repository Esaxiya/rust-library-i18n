use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Мири слишком медленная
fn exact_sanity_test() {
    // В конце этого теста выполняется то, что я могу только предположить, это некий угловатый вариант функции библиотеки `exp2`, определенной в любой используемой среде выполнения C.
    // В VS 2013 эта функция, по-видимому, имела ошибку, поскольку этот тест не удался при связывании, но в VS 2015 ошибка кажется исправленной, поскольку тест проходит нормально.
    //
    // Похоже, что ошибка заключается в разнице в возвращаемом значении `exp2(-1057)`, где в VS 2013 он возвращает двойное значение с битовым шаблоном 0x2, а в VS 2015 возвращает 0x20000.
    //
    //
    // На данный момент просто полностью игнорируйте этот тест на MSVC, поскольку он в любом случае тестировался в другом месте, и мы не очень заинтересованы в тестировании реализации exp2 каждой платформы.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}