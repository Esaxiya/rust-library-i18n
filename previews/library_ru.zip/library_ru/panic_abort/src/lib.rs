//! Реализация Rust panics через прерывание процесса
//!
//! По сравнению с реализацией через размотку, этот crate *намного* проще!При этом он не такой универсальный, но вот он!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" полезную нагрузку и регулировочную шайбу к соответствующему прерыванию на рассматриваемой платформе.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // позвонить в std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // На Windows используйте специфичный для процессора механизм __fastfail.В Windows 8 и более поздних версиях это приведет к немедленному завершению процесса без запуска каких-либо внутрипроцессных обработчиков исключений.
            // В более ранних версиях Windows эта последовательность инструкций будет рассматриваться как нарушение прав доступа, завершение процесса, но без обязательного обхода всех обработчиков исключений.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: это та же реализация, что и в libstd `abort_internal`
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Это ... немного странно.Tl; dr;в том, что это требуется для правильной ссылки, более подробное объяснение приведено ниже.
//
// Сейчас все поставляемые нами двоичные файлы libcore/libstd скомпилированы с `-C panic=unwind`.Это сделано для того, чтобы бинарные файлы были максимально совместимы с как можно большим количеством ситуаций.
// Однако компилятору требуется "personality function" для всех функций, скомпилированных с `-C panic=unwind`.Эта индивидуальная функция жестко запрограммирована на символ `rust_eh_personality` и определяется элементом языка `eh_personality`.
//
// So...
// почему бы просто не определить этот элемент языка здесь?Хороший вопрос!Способ, которым связаны среды выполнения panic, на самом деле немного тонок в том смысле, что они "sort of" в хранилище crate компилятора, но фактически связаны только в том случае, если другой фактически не связан.
//
// Это означает, что и этот crate, и panic_unwind crate могут появиться в хранилище crate компилятора, и если оба определяют элемент языка `eh_personality`, это приведет к ошибке.
//
// Чтобы справиться с этим, компилятор требует, чтобы `eh_personality` был определен только в том случае, если связываемая среда выполнения panic является средой выполнения раскрутки, и в противном случае ее не требуется определять (по праву).
// В этом случае, однако, эта библиотека просто определяет этот символ, поэтому где-то есть хоть какая-то личность.
//
// По сути, этот символ просто определен для подключения к двоичным файлам libcore/libstd, но он никогда не должен вызываться, так как мы вообще не связываемся во время выполнения раскрутки.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // В x86_64-pc-windows-gnu мы используем нашу собственную индивидуальную функцию, которая должна возвращать `ExceptionContinueSearch`, когда мы передаем все наши фреймы.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Как и выше, это соответствует элементу `eh_catch_typeinfo` lang, который в настоящее время используется только в Emscripten.
    //
    // Поскольку panics не генерирует исключения, а внешние исключения в настоящее время являются UB с -C panic=abort (хотя это может быть изменено), любые вызовы catch_unwind никогда не будут использовать эту информацию о типе.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Эти два вызываются нашими объектами запуска на i686-pc-windows-gnu, но им не нужно ничего делать, поэтому тела-nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}