use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Используется, чтобы сообщить нашим аннотациям `#[assert_instr]`, что все встроенные функции simd доступны для тестирования их кодогенерации, поскольку некоторые из них находятся за дополнительным `-Ctarget-feature=+unimplemented-simd128`, у которого сейчас нет эквивалента в `#[target_feature]`.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}