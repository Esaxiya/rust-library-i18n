`core::arch` - Архитектурно-зависимые особенности основной библиотеки Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

В модуле `core::arch` реализованы архитектурно-зависимые встроенные функции (например, SIMD).

# Usage 

`core::arch` доступен как часть `libcore` и реэкспортируется `libstd`.Лучше использовать его через `core::arch` или `std::arch`, чем через crate.
Нестабильные функции часто доступны в ночном Rust через `feature(stdsimd)`.

Для использования `core::arch` через этот crate требуется ночной Rust, и он может (и действительно) часто ломается.Единственные случаи, в которых вам следует рассмотреть возможность использования его через этот crate:

* если вам нужно перекомпилировать `core::arch` самостоятельно, например, с включенными определенными целевыми функциями, которые не включены для `libcore`/`libstd`.
Note: если вам нужно перекомпилировать его для нестандартной цели, пожалуйста, предпочтите использовать `xargo` и перекомпилировать `libcore`/`libstd` по мере необходимости вместо использования этого crate.
  
* использование некоторых функций, которые могут быть недоступны даже за нестабильными функциями Rust.Мы стараемся свести их к минимуму.
Если вам нужно использовать некоторые из этих функций, пожалуйста, откройте проблему, чтобы мы могли раскрыть их в ночном Rust, и вы могли использовать их оттуда.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` в основном распространяется на условиях лицензии MIT и лицензии Apache (версия 2.0), причем на части распространяются различные лицензии, подобные BSD.

Подробности см. В LICENSE-APACHE и LICENSE-MIT.

# Contribution

Если вы явно не указали иное, любой вклад, намеренно представленный вами для включения в `core_arch`, как определено в лицензии Apache-2.0, должен иметь двойную лицензию, как указано выше, без каких-либо дополнительных условий.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












