// rsbegin.o и rsend.o-это так называемые "compiler runtime startup objects".
// Они содержат код, необходимый для правильной инициализации среды выполнения компилятора.
//
// Когда выполняется ссылка на исполняемый файл или образ dylib, весь пользовательский код и библиотеки находятся в "sandwiched" между этими двумя объектными файлами, поэтому код или данные из rsbegin.o становятся первыми в соответствующих разделах изображения, тогда как код и данные из rsend.o становятся последними.
// Этот эффект можно использовать для размещения символов в начале или в конце раздела, а также для вставки любых необходимых верхних или нижних колонтитулов.
//
// Обратите внимание, что фактическая точка входа модуля находится в объекте запуска среды выполнения C (обычно называемом `crtX.o`), который затем вызывает обратные вызовы инициализации других компонентов среды выполнения (зарегистрированные через еще один специальный раздел изображения).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Отмечает начало раздела информации о размотке кадра стека
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Пространство для внутренней бухгалтерии размотчика.
    // Это определено как `struct object` в $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Расслабьтесь info registration/deregistration рутины.
    // См. Документацию libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // регистрировать раскрутку информации при запуске модуля
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // отменить регистрацию при выключении
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Стандартная регистрация init/uninit, специфичная для MinGW
    pub mod mingw_init {
        // Объекты запуска MinGW (crt0.o/dllcrt0.o) будут вызывать глобальные конструкторы в разделах .ctors и .dtors при запуске и выходе.
        // В случае с библиотеками DLL это происходит при загрузке и выгрузке библиотеки DLL.
        //
        // Компоновщик отсортирует разделы, чтобы наши обратные вызовы были расположены в конце списка.
        // Поскольку конструкторы запускаются в обратном порядке, это гарантирует, что наши обратные вызовы будут выполнены первым и последним.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: обратные вызовы инициализации C
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: обратные вызовы завершения C
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}