//! Раскрутка panics для Мири.
use alloc::boxed::Box;
use core::any::Any;

// Тип полезной нагрузки, которую двигатель Miri разматывает для нас.
// Должен быть размером с указатель.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Мири предоставила внешнюю функцию для начала раскрутки.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Полезная нагрузка, которую мы передаем `miri_start_panic`, будет в точности аргументом, который мы получаем в `cleanup` ниже.
    // Поэтому мы просто упаковываем его один раз, чтобы получить что-то размером с указатель.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Восстановите базовый `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}