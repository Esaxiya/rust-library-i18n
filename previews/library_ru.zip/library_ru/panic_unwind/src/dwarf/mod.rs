//! Утилиты для разбора потоков данных в DWARF-кодировке.
//! См. Стандарт <http://www.dwarfstd.org>, DWARF-4, раздел 7, "Data Representation"
//!

// Этот модуль пока используется только x86_64-pc-windows-gnu, но мы компилируем его везде, чтобы избежать регрессов.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // Потоки DWARF упакованы, поэтому, например, u32 не обязательно будет выровнен по 4-байтовой границе.
    // Это может вызвать проблемы на платформах со строгими требованиями к выравниванию.
    // Оборачивая данные в структуру "packed", мы говорим бэкэнд сгенерировать код "misalignment-safe".
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // Кодировки ULEB128 и SLEB128 определены в Разделах 7.6, "Variable Length Data".
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}