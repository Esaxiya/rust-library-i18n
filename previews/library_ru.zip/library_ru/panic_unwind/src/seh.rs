//! Windows SEH
//!
//! В Windows (в настоящее время только в MSVC) механизм обработки исключений по умолчанию-это структурированная обработка исключений (SEH).
//! Это сильно отличается от обработки исключений на основе Dwarf (например, той, что используют другие платформы unix) с точки зрения внутренних компонентов компилятора, поэтому LLVM должен иметь значительную дополнительную поддержку SEH.
//!
//! Вкратце, вот что происходит:
//!
//! 1. Функция `panic` вызывает стандартную функцию Windows `_CxxThrowException`, чтобы генерировать исключение, подобное C++ , запускающее процесс раскрутки.
//! 2.
//! Все посадочные площадки, сгенерированные компилятором, используют индивидуальную функцию `__CxxFrameHandler3`, функцию в CRT, а код раскрутки в Windows будет использовать эту индивидуальную функцию для выполнения всего кода очистки в стеке.
//!
//! 3. Все вызовы `invoke`, сгенерированные компилятором, имеют посадочную площадку, установленную как инструкцию `cleanuppad` LLVM, которая указывает на начало процедуры очистки.
//! Личность (на шаге 2, определенная в CRT) отвечает за выполнение процедур очистки.
//! 4. В конце концов код "catch" во встроенной функции `try` (сгенерированной компилятором) выполняется и указывает, что управление должно вернуться к Rust.
//! Это делается с помощью команды `catchswitch` плюс `catchpad` в терминах LLVM IR, наконец, возвращая нормальное управление программе с помощью инструкции `catchret`.
//!
//! Некоторые конкретные отличия от обработки исключений на основе gcc:
//!
//! * Rust не имеет настраиваемой индивидуальной функции, вместо этого *всегда*`__CxxFrameHandler3`.Кроме того, дополнительная фильтрация не выполняется, поэтому мы перехватываем любые исключения C++ , которые выглядят так же, как выбрасываемые нами.
//! Обратите внимание, что выброс исключения в Rust в любом случае является неопределенным поведением, так что это должно быть нормально.
//! * У нас есть данные для передачи через границу разматывания, в частности `Box<dyn Any + Send>`.Как и в случае с исключениями Dwarf, эти два указателя хранятся как полезная нагрузка в самом исключении.
//! Однако в MSVC нет необходимости в дополнительном распределении кучи, поскольку стек вызовов сохраняется во время выполнения функций фильтрации.
//! Это означает, что указатели передаются непосредственно в `_CxxThrowException`, которые затем восстанавливаются в функции фильтрации для записи в кадр стека встроенной функции `try`.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Это должен быть параметр, потому что мы перехватываем исключение по ссылке, а его деструктор выполняется средой выполнения C++ .
    // Когда мы вынимаем Box из исключения, нам нужно оставить исключение в допустимом состоянии, чтобы его деструктор работал без двойного сброса Box.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Во-первых, целый набор определений типов.Здесь есть несколько специфических для платформы странностей, а многие из них явно скопированы с LLVM.Цель всего этого-реализовать функцию `panic`, указанную ниже, посредством вызова `_CxxThrowException`.
//
// Эта функция принимает два аргумента.Первый-это указатель на данные, которые мы передаем, в данном случае это наш объект trait.Довольно легко найти!Следующий, однако, более сложный.
// Это указатель на структуру `_ThrowInfo`, и обычно он предназначен только для описания генерируемого исключения.
//
// В настоящее время определение этого типа [1] немного запутанно, и основная странность (и отличие от онлайн-статьи) заключается в том, что в 32-битной версии указатели являются указателями, но в 64-битной версии указатели выражаются как 32-битные смещения от `__ImageBase` символ.
//
// Макросы `ptr_t` и `ptr!` в модулях ниже используются, чтобы выразить это.
//
// Лабиринт определений типов также внимательно следует за тем, что LLVM испускает для такого рода операций.Например, если вы скомпилируете этот код C++ на MSVC и передадите LLVM IR:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      void foo() { rust_panic a = {0, 1};
//          бросить;}
//
// По сути, это то, чему мы пытаемся подражать.Большинство приведенных ниже значений констант просто скопировано из LLVM,
//
// В любом случае, все эти структуры построены одинаково, и для нас это несколько многословно.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Обратите внимание, что здесь мы намеренно игнорируем правила изменения имен: мы не хотим, чтобы C++ мог перехватывать Rust panics, просто объявляя `struct rust_panic`.
//
//
// При изменении убедитесь, что строка имени типа точно совпадает со строкой, используемой в `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Начальный байт `\x01` здесь на самом деле является волшебным сигналом для LLVM *не* применять какие-либо другие манипуляции, такие как префикс с символом `_`.
    //
    //
    // Этот символ-vtable, используемый C++ `std::type_info`.
    // Объекты типа `std::type_info`, дескрипторы типа, имеют указатель на эту таблицу.
    // На дескрипторы типов ссылаются структуры C++ EH, определенные выше и которые мы создаем ниже.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Этот дескриптор типа используется только при создании исключения.
// Часть catch обрабатывается встроенной функцией try, которая генерирует свой собственный дескриптор TypeDescriptor.
//
// Это нормально, поскольку среда выполнения MSVC использует сравнение строк в имени типа для соответствия TypeDescriptors, а не равенство указателей.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Деструктор используется, если код C++ решает перехватить исключение и отбросить его без его распространения.
// Часть catch внутренней функции try установит первое слово объекта исключения равным 0, чтобы деструктор пропустил его.
//
// Обратите внимание, что x86 Windows использует соглашение о вызовах "thiscall" для функций-членов C++ вместо соглашения о вызовах "C" по умолчанию.
//
// Функция exception_copy здесь немного особенная: она вызывается средой выполнения MSVC под блоком try/catch, и panic, который мы здесь генерируем, будет использоваться как результат копии исключения.
//
// Это используется средой выполнения C++ для поддержки захвата исключений с помощью std::exception_ptr, что мы не можем поддерживать, потому что Box<dyn Any>не клонируемый.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException полностью выполняется в этом кадре стека, поэтому в противном случае нет необходимости передавать `data` в кучу.
    // Мы просто передаем этой функции указатель стека.
    //
    // ManuallyDrop здесь необходим, поскольку мы не хотим, чтобы исключение сбрасывалось при раскручивании.
    // Вместо этого он будет удален с помощью exception_cleanup, который вызывается средой выполнения C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Это ... может показаться удивительным, и это вполне оправданно.В 32-битном MSVC указатели между этими структурами являются просто указателями.
    // Однако в 64-битном MSVC указатели между структурами скорее выражаются как 32-битные смещения от `__ImageBase`.
    //
    // Следовательно, в 32-битном MSVC мы можем объявить все эти указатели в статике выше.
    // В 64-битном MSVC нам пришлось бы выражать вычитание указателей в статике, что в настоящее время Rust не позволяет, поэтому мы не можем этого сделать.
    //
    // Следующее, что лучше всего,-это заполнить эти структуры во время выполнения (в любом случае паника-это уже "slow path").
    // Итак, здесь мы интерпретируем все эти поля указателей как 32-битные целые числа, а затем сохраняем в них соответствующее значение (атомарно, поскольку может происходить одновременное panics).
    //
    // Технически среда выполнения, вероятно, будет выполнять неатомарное чтение этих полей, но теоретически они никогда не читают *неправильное* значение, так что это не должно быть так уж плохо ...
    //
    // В любом случае нам в основном нужно делать что-то подобное, пока мы не сможем выразить больше операций в статике (а мы, возможно, никогда не сможем).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Значение NULL здесь означает, что мы попали сюда из улова (...) __rust_try.
    // Это происходит, когда обнаруживается внешнее исключение, отличное от Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Это требуется компилятору для существования (например, это элемент lang), но на самом деле он никогда не вызывается компилятором, потому что __C_specific_handler или _except_handler3-это индивидуальная функция, которая всегда используется.
//
// Значит, это просто прерывающаяся заглушка.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}