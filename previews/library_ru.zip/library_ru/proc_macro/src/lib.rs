//! Библиотека поддержки для авторов макросов при определении новых макросов.
//!
//! Эта библиотека, предоставляемая стандартным дистрибутивом, предоставляет типы, используемые в интерфейсах процедурно определенных макроопределений, таких как функционально-подобные макросы `#[proc_macro]`, атрибуты макросов `#[proc_macro_attribute]` и настраиваемые производные атрибуты `#[proc_macro_derive]`.
//!
//!
//! Подробнее см. [the book].
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Определяет, стал ли proc_macro доступным для текущей запущенной программы.
///
/// Proc_macro crate предназначен только для использования внутри реализации процедурных макросов.Все функции в этом crate panic, если они вызываются извне процедурного макроса, например, из сценария сборки, модульного теста или обычного двоичного файла Rust.
///
/// Принимая во внимание библиотеки Rust, которые предназначены для поддержки как макросов, так и немакросценажей, `proc_macro::is_available()` обеспечивает без паники способ определения того, доступна ли в настоящее время инфраструктура, необходимая для использования API proc_macro.
/// Возвращает истину, если вызывается изнутри процедурного макроса, и ложь, если вызывается из любого другого двоичного файла.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Основной тип, предоставляемый этим crate, представляющий абстрактный поток tokens или, более конкретно, последовательность деревьев token.
/// Тип предоставляет интерфейсы для перебора этих деревьев token и, наоборот, сбора нескольких деревьев token в один поток.
///
///
/// Это вход и выход определений `#[proc_macro]`, `#[proc_macro_attribute]` и `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Ошибка возвращается от `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Возвращает пустой `TokenStream`, не содержащий деревьев token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Проверяет, пуст ли этот `TokenStream`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Пытается разбить строку на tokens и проанализировать эти tokens в потоке token.
/// Может завершиться ошибкой по ряду причин, например, если строка содержит несбалансированные разделители или символы, которых нет в языке.
///
/// Все tokens в проанализированном потоке получают интервалы `Span::call_site()`.
///
/// NOTE: некоторые ошибки могут вызвать panics вместо возврата `LexError`.Мы оставляем за собой право изменить эти ошибки на `LexError`s позже.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, мост предоставляет только `to_string`, реализуйте `fmt::Display` на его основе (обратное обычным отношениям между ними).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Печатает поток token как строку, которая должна быть преобразована без потерь обратно в тот же поток token (интервалы по модулю), за исключением, возможно, `TokenTree: : Group`s с разделителями `Delimiter::None` и отрицательными числовыми литералами.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Печатает token в удобном для отладки виде.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Создает поток token, содержащий одно дерево token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Собирает несколько деревьев token в один поток.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Операция "flattening" с потоками token собирает деревья token из нескольких потоков token в один поток.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Возможно использование оптимизированной реализации if/when.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Подробности общедоступной реализации для типа `TokenStream`, например итераторы.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Итератор над объектом TokenStream из объекта TokenTree`s.
    /// Итерация-"shallow", например, итератор не рекурсивно разбивается на группы с разделителями, а возвращает целые группы в виде деревьев token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` принимает произвольные tokens и расширяется до `TokenStream`, описывающего ввод.
/// Например, `quote!(a + b)` создаст выражение, которое при вычислении образует `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Удаление кавычек выполняется с помощью `$` и работает, принимая один следующий идентификатор в качестве термина без кавычек.
/// Чтобы процитировать сам `$`, используйте `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Область исходного кода вместе с информацией о расширении макроса.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Создает новый `Diagnostic` с заданным `message` на участке `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Диапазон, который разрешается на сайте определения макроса.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Интервал вызова текущего процедурного макроса.
    /// Идентификаторы, созданные с помощью этого диапазона, будут разрешены, как если бы они были написаны непосредственно в месте вызова макроса (гигиена места вызова), и другой код на сайте вызова макроса также сможет ссылаться на них.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Диапазон, который представляет гигиену `macro_rules` и иногда разрешается на сайте определения макроса (локальные переменные, метки, `$crate`), а иногда и на сайте вызова макроса (все остальное).
    ///
    /// Местоположение пролета взято из call-site.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Исходный исходный файл, на который указывает этот диапазон.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` для tokens в предыдущем расширении макросов, из которого был сгенерирован `self`, если таковые имеются.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Диапазон исходного исходного кода, из которого был сгенерирован `self`.
    /// Если этот `Span` не был сгенерирован из других расширений макросов, возвращаемое значение такое же, как `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Получает начальный line/column в исходном файле для этого диапазона.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Получает окончание line/column в исходном файле для этого диапазона.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Создает новый промежуток, охватывающий `self` и `other`.
    ///
    /// Возвращает `None`, если `self` и `other` из разных файлов.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Создает новый диапазон с той же информацией line/column, что и `self`, но разрешает символы, как если бы они находились в `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Создает новый диапазон с тем же поведением разрешения имен, что и `self`, но с информацией line/column для `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Сравнивает с промежутками, чтобы узнать, равны ли они.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Возвращает исходный текст за диапазоном.
    /// Это сохраняет исходный исходный код, включая пробелы и комментарии.
    /// Он возвращает результат только в том случае, если диапазон соответствует реальному исходному коду.
    ///
    /// Note: Наблюдаемый результат макроса должен полагаться только на tokens, а не на этот исходный текст.
    ///
    /// Результат этой функции лучше всего использовать только для диагностики.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Печатает диапазон в форме, удобной для отладки.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Пара строка-столбец, представляющая начало или конец `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Строка с индексом 1 в исходном файле, в которой диапазон начинается или заканчивается (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Столбец с индексом 0 (в символах UTF-8) в исходном файле, в котором диапазон начинается или заканчивается (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Исходный файл данного `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Получает путь к этому исходному файлу.
    ///
    /// ### Note
    /// Если диапазон кода, связанный с этим `SourceFile`, был сгенерирован внешним макросом, этим макросом, это может не быть фактическим путем в файловой системе.
    /// Используйте [`is_real`] для проверки.
    ///
    /// Также обратите внимание, что даже если `is_real` возвращает `true`, если `--remap-path-prefix` был передан в командной строке, указанный путь может фактически быть недействительным.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Возвращает `true`, если этот исходный файл является реальным исходным файлом, а не сгенерирован расширением внешнего макроса.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Это хитрость до тех пор, пока не будут реализованы межкрейтовые интервалы, и у нас не будет реальных исходных файлов для интервалов, созданных во внешних макросах.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Один token или последовательность деревьев token с разделителями (например, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Поток token, окруженный скобками-разделителями.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Идентификатор.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Одиночный символ пунктуации (`+`, `,`, `$` и т. Д.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Буквальный символ (`'a'`), строка (`"hello"`), число (`2.3`) и т. Д.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Возвращает диапазон этого дерева, делегируя методу `span` содержащегося в нем token или ограниченного потока.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Настраивает диапазон *только для этого token*.
    ///
    /// Обратите внимание, что если этот token является `Group`, этот метод не будет настраивать диапазон каждого из внутренних tokens, он просто делегирует метод `set_span` каждого варианта.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Печатает дерево token в удобном для отладки виде.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Каждый из них имеет имя в типе структуры в производной отладке, поэтому не беспокойтесь о дополнительном уровне косвенного обращения
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, мост предоставляет только `to_string`, реализуйте `fmt::Display` на его основе (обратное обычным отношениям между ними).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Печатает дерево token как строку, которая должна быть преобразована без потерь обратно в то же дерево token (интервалы по модулю), за исключением, возможно, `TokenTree: : Group`s с разделителями `Delimiter::None` и отрицательными числовыми литералами.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Поток token с разделителями.
///
/// `Group` внутри содержит `TokenStream`, окруженный `Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Описывает, как разграничивается последовательность деревьев token.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Неявный разделитель, который может, например, появляться вокруг tokens, исходящий от "macro variable" `$var`.
    /// Важно сохранить приоритеты операторов в таких случаях, как `$var * 3`, где `$var`-это `1 + 2`.
    /// Неявные разделители могут не выдерживать двустороннего обхода потока token через строку.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Создает новый `Group` с заданным разделителем и потоком token.
    ///
    /// Этот конструктор установит диапазон для этой группы на `Span::call_site()`.
    /// Чтобы изменить диапазон, вы можете использовать метод `set_span` ниже.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Возвращает разделитель этого `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Возвращает `TokenStream` из tokens, разделенных в этом `Group`.
    ///
    /// Обратите внимание, что возвращенный поток token не включает разделитель, возвращенный выше.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Возвращает диапазон разделителей этого потока token, охватывающий весь `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Возвращает диапазон, указывающий на открывающий разделитель этой группы.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Возвращает диапазон, указывающий на закрывающий разделитель этой группы.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Настраивает диапазон для разделителей этой группы, но не ее внутреннего tokens.
    ///
    /// Этот метод **не** устанавливает диапазон всех внутренних tokens, охватываемых этой группой, а только устанавливает диапазон разделителя tokens на уровне `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, мост предоставляет только `to_string`, реализуйте `fmt::Display` на его основе (обратное обычным отношениям между ними).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Печатает группу в виде строки, которая должна быть преобразована без потерь обратно в ту же группу (по модулю), за исключением, возможно, `TokenTree: : Group`s с разделителями `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct`-это одиночный символ пунктуации, например `+`, `-` или `#`.
///
/// Многосимвольные операторы, такие как `+=`, представлены как два экземпляра `Punct` с возвращаемыми разными формами `Spacing`.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// За `Punct` следует сразу другой `Punct` или за ним следует еще один token или пробел.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// например, `+`-это `Alone` в `+ =`, `+ident` или `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// например, `+`-это `Joint` в `+=` или `'#`.
    /// Кроме того, одинарная кавычка `'` может объединяться с идентификаторами для формирования времени жизни `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Создает новый `Punct` из заданного символа и интервала.
    /// Аргумент `ch` должен быть допустимым символом пунктуации, разрешенным языком, в противном случае функция будет panic.
    ///
    /// Возвращенный `Punct` будет иметь диапазон по умолчанию `Span::call_site()`, который можно дополнительно настроить с помощью метода `set_span` ниже.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Возвращает значение этого символа пунктуации как `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Возвращает интервал между этим символом пунктуации, указывая, следует ли сразу за ним другой `Punct` в потоке token, чтобы они потенциально могли быть объединены в многосимвольный оператор (`Joint`), или за ним следует какой-либо другой token или пробел (`Alone`), чтобы оператор обязательно закончился.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Возвращает диапазон для этого символа пунктуации.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Настройте диапазон для этого символа пунктуации.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, мост предоставляет только `to_string`, реализуйте `fmt::Display` на его основе (обратное обычным отношениям между ними).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Печатает символ пунктуации в виде строки, которая должна быть преобразована без потерь обратно в тот же символ.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Идентификатор (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Создает новый `Ident` с данным `string`, а также с указанным `span`.
    /// Аргумент `string` должен быть допустимым идентификатором, разрешенным языком (включая ключевые слова, например `self` или `fn`).В противном случае функция будет panic.
    ///
    /// Обратите внимание, что `span`, в настоящее время находящийся в rustc, настраивает гигиеническую информацию для этого идентификатора.
    ///
    /// На данный момент `Span::call_site()` явно поддерживает гигиену "call-site", что означает, что идентификаторы, созданные с этим диапазоном, будут разрешены, как если бы они были написаны непосредственно в месте вызова макроса, а другой код на сайте вызова макроса сможет ссылаться на их тоже.
    ///
    ///
    /// Более поздние диапазоны, такие как `Span::def_site()`, позволят выбрать гигиену "definition-site", что означает, что идентификаторы, созданные с помощью этого диапазона, будут разрешены в месте определения макроса, а другой код на сайте вызова макроса не сможет ссылаться на них.
    ///
    /// Из-за текущей важности гигиены этот конструктор, в отличие от других tokens, требует, чтобы при строительстве был указан `Span`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// То же, что `Ident::new`, но создает необработанный идентификатор (`r#ident`).
    /// Аргумент `string`-допустимый идентификатор, разрешенный языком (включая ключевые слова, например `fn`).
    /// Ключевые слова, которые можно использовать в сегментах пути (например,
    /// `self`, `super`) не поддерживаются и вызовут panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Возвращает диапазон этого `Ident`, охватывающий всю строку, возвращаемую [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Настраивает диапазон этого `Ident`, возможно, изменяя его гигиенический контекст.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, мост предоставляет только `to_string`, реализуйте `fmt::Display` на его основе (обратное обычным отношениям между ними).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Печатает идентификатор в виде строки, которая должна быть преобразована без потерь обратно в тот же идентификатор.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Литеральная строка (`"hello"`), байтовая строка (`b"hello"`), символ (`'a'`), байтовый символ (`b'a'`), целое число или число с плавающей запятой с суффиксом или без него (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Логические литералы, такие как `true` и `false`, здесь не используются, они `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Создает новый суффиксированный целочисленный литерал с указанным значением.
        ///
        /// Эта функция создаст целое число, такое как `1u32`, где указанное целочисленное значение является первой частью token, а интеграл также имеет суффикс в конце.
        /// Литералы, созданные из отрицательных чисел, могут не выдерживать циклов передачи через `TokenStream` или строки и могут быть разбиты на два tokens (`-` и положительный литерал).
        ///
        ///
        /// Литералы, созданные с помощью этого метода, по умолчанию имеют диапазон `Span::call_site()`, который можно настроить с помощью метода `set_span` ниже.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Создает новый целочисленный литерал без суффиксов с указанным значением.
        ///
        /// Эта функция создаст целое число, такое как `1`, где указанное целочисленное значение является первой частью token.
        /// Для этого token не указан суффикс, что означает, что такие вызовы, как `Literal::i8_unsuffixed(1)`, эквивалентны `Literal::u32_unsuffixed(1)`.
        /// Литералы, созданные из отрицательных чисел, могут не пройти через `TokenStream` или строки и могут быть разбиты на два tokens (`-` и положительный литерал).
        ///
        ///
        /// Литералы, созданные с помощью этого метода, по умолчанию имеют диапазон `Span::call_site()`, который можно настроить с помощью метода `set_span` ниже.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Создает новый литерал с плавающей запятой без суффиксов.
    ///
    /// Этот конструктор аналогичен конструктору типа `Literal::i8_unsuffixed`, где значение с плавающей запятой передается непосредственно в token, но не используется суффикс, поэтому позже в компиляторе можно сделать вывод, что он является `f64`.
    ///
    /// Литералы, созданные из отрицательных чисел, могут не пройти через `TokenStream` или строки и могут быть разбиты на два tokens (`-` и положительный литерал).
    ///
    /// # Panics
    ///
    /// Эта функция требует, чтобы указанное число с плавающей запятой было конечным, например, если оно равно бесконечности или NaN, эта функция будет panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Создает новый суффиксированный литерал с плавающей запятой.
    ///
    /// Этот конструктор создаст литерал наподобие `1.0f32`, где указанное значение является предшествующей частью token, а `f32`-суффиксом token.
    /// Этот token всегда будет считаться `f32` в компиляторе.
    /// Литералы, созданные из отрицательных чисел, могут не пройти через `TokenStream` или строки и могут быть разбиты на два tokens (`-` и положительный литерал).
    ///
    ///
    /// # Panics
    ///
    /// Эта функция требует, чтобы указанное число с плавающей запятой было конечным, например, если оно равно бесконечности или NaN, эта функция будет panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Создает новый литерал с плавающей запятой без суффиксов.
    ///
    /// Этот конструктор аналогичен конструктору типа `Literal::i8_unsuffixed`, где значение с плавающей запятой передается непосредственно в token, но не используется суффикс, поэтому позже в компиляторе можно сделать вывод, что он является `f64`.
    ///
    /// Литералы, созданные из отрицательных чисел, могут не пройти через `TokenStream` или строки и могут быть разбиты на два tokens (`-` и положительный литерал).
    ///
    /// # Panics
    ///
    /// Эта функция требует, чтобы указанное число с плавающей запятой было конечным, например, если оно равно бесконечности или NaN, эта функция будет panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Создает новый суффиксированный литерал с плавающей запятой.
    ///
    /// Этот конструктор создаст литерал наподобие `1.0f64`, где указанное значение является предшествующей частью token, а `f64`-суффиксом token.
    /// Этот token всегда будет считаться `f64` в компиляторе.
    /// Литералы, созданные из отрицательных чисел, могут не пройти через `TokenStream` или строки и могут быть разбиты на два tokens (`-` и положительный литерал).
    ///
    ///
    /// # Panics
    ///
    /// Эта функция требует, чтобы указанное число с плавающей запятой было конечным, например, если оно равно бесконечности или NaN, эта функция будет panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Строковый литерал.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Символьный литерал.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Литерал байтовой строки.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Возвращает диапазон, охватывающий этот литерал.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Настраивает диапазон, связанный с этим литералом.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Возвращает `Span`, который является подмножеством `self.span()`, содержащим только исходные байты в диапазоне `range`.
    /// Возвращает `None`, если предполагаемый обрезанный диапазон выходит за пределы `self`.
    ///
    // FIXME(SergioBenitez): убедитесь, что диапазон байтов начинается и заканчивается на границе UTF-8 источника.
    // в противном случае, вероятно, что panic произойдет где-то еще при печати исходного текста.
    // FIXME(SergioBenitez): у пользователя нет возможности узнать, на что на самом деле отображается `self.span()`, поэтому в настоящее время этот метод можно вызывать только вслепую.
    // Например, `to_string()` для символа 'c' возвращает "'\u{63}'";у пользователя нет возможности узнать, был ли исходный текст 'c' или '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) что-то вроде `Option::cloned`, но для `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, мост предоставляет только `to_string`, реализуйте `fmt::Display` на его основе (обратное обычным отношениям между ними).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Печатает литерал как строку, которая должна быть преобразована без потерь обратно в тот же литерал (за исключением возможного округления для литералов с плавающей запятой).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Отслеживаемый доступ к переменным среды.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Получите переменную среды и добавьте ее для построения информации о зависимости.
    /// Система сборки, выполняющая компилятор, будет знать, что к переменной обращались во время компиляции, и сможет повторно запустить сборку, когда значение этой переменной изменится.
    ///
    /// Помимо отслеживания зависимостей, эта функция должна быть эквивалентна `env::var` из стандартной библиотеки, за исключением того, что аргумент должен быть UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}