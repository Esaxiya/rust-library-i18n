#![stable(feature = "rust1", since = "1.0.0")]

//! Поточно-ориентированные указатели подсчета ссылок.
//!
//! См. Документацию [`Arc<T>`][Arc] для более подробной информации.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Мягкое ограничение на количество ссылок, которые могут быть сделаны на `Arc`.
///
/// Превышение этого предела приведет к прерыванию вашей программы (хотя и не обязательно) при обращениях _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer не поддерживает ограничения памяти.
// Чтобы избежать ложных срабатываний в реализации Arc/Weak, вместо этого используйте атомарные нагрузки для синхронизации.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Поточно-безопасный указатель подсчета ссылок.'Arc' расшифровывается как «Счетчик атомных ссылок».
///
/// Тип `Arc<T>` обеспечивает совместное владение значением типа `T`, размещенным в куче.Вызов [`clone`][clone] на `Arc` создает новый экземпляр `Arc`, который указывает на то же распределение в куче, что и исходный `Arc`, при увеличении счетчика ссылок.
/// Когда последний указатель `Arc` на данное выделение уничтожается, значение, хранящееся в этом распределении (часто называемое "inner value"), также удаляется.
///
/// Общие ссылки в Rust по умолчанию запрещают мутацию, и `Arc` не является исключением: обычно вы не можете получить изменяемую ссылку на что-то внутри `Arc`.Если вам нужно изменить через `Arc`, используйте [`Mutex`][mutex], [`RwLock`][rwlock] или один из типов [`Atomic`][atomic].
///
/// ## Безопасность потоков
///
/// В отличие от [`Rc<T>`], `Arc<T>` использует атомарные операции для подсчета ссылок.Это означает, что он ориентирован на многопоточность.Недостатком является то, что атомарные операции дороже обычных обращений к памяти.Если вы не разделяете выделения с подсчетом ссылок между потоками, рассмотрите возможность использования [`Rc<T>`] для снижения накладных расходов.
/// [`Rc<T>`] является безопасным значением по умолчанию, потому что компилятор перехватит любую попытку отправить [`Rc<T>`] между потоками.
/// Однако библиотека может выбрать `Arc<T>`, чтобы предоставить потребителям библиотеки большую гибкость.
///
/// `Arc<T>` будет реализовывать [`Send`] и [`Sync`], пока `T` реализует [`Send`] и [`Sync`].
/// Почему вы не можете поместить небезопасный тип `T` в `Arc<T>`, чтобы сделать его поточно-ориентированным?Поначалу это может показаться немного противоречащим интуиции: в конце концов, разве не суть в безопасности потоков `Arc<T>`?Ключ заключается в следующем: `Arc<T>` делает потокобезопасным иметь несколько владельцев одних и тех же данных, но не добавляет потокобезопасность к своим данным.
///
/// Рассмотрим `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] не [`Sync`], и если `Arc<T>` всегда был [`Send`], `Arc <` [`RefCell<T>`]`>`тоже будет.
/// Но тогда у нас была бы проблема:
/// [`RefCell<T>`] не является потокобезопасным;он отслеживает количество заимствований, используя неатомарные операции.
///
/// В конце концов, это означает, что вам может потребоваться сопряжение `Arc<T>` с каким-либо типом [`std::sync`], обычно с [`Mutex<T>`][mutex].
///
/// ## Циклы прерывания с `Weak`
///
/// Метод [`downgrade`][downgrade] можно использовать для создания указателя [`Weak`], не являющегося владельцем.Указатель [`Weak`] может быть [`upgrade`][upgrade] d до `Arc`, но это вернет [`None`], если значение, сохраненное в распределении, уже было отброшено.
/// Другими словами, указатели `Weak` не сохраняют значение внутри выделения;однако они *действительно* поддерживают выделение (резервное хранилище для значения) живым.
///
/// Цикл между указателями `Arc` никогда не будет освобожден.
/// По этой причине [`Weak`] используется для прерывания циклов.Например, дерево может иметь сильные указатели `Arc` от родительских узлов к дочерним элементам и указатели [`Weak`] от дочерних узлов к их родителям.
///
/// # Клонирование ссылок
///
/// Создание новой ссылки из существующего указателя со счетчиком ссылок выполняется с помощью `Clone` trait, реализованного для [`Arc<T>`][Arc] и [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Два приведенных ниже синтаксиса эквивалентны.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b и foo-все дуги, указывающие на одну и ту же ячейку памяти.
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` автоматически разыменовывается на `T` (через [`Deref`][deref] trait), поэтому вы можете вызывать методы `T` для значения типа `Arc<T>`.Чтобы избежать конфликтов имен с методами `T`, методы самого `Arc<T>` являются связанными функциями, вызываемыми с помощью [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Дуга<T>Реализации traits, такие как `Clone`, также могут быть вызваны с использованием полностью определенного синтаксиса.
/// Некоторые люди предпочитают использовать полностью определенный синтаксис, в то время как другие предпочитают синтаксис вызова методов.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Синтаксис вызова метода
/// let arc2 = arc.clone();
/// // Полностью квалифицированный синтаксис
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] не выполняет автоматическое разыменование `T`, потому что внутреннее значение, возможно, уже было отброшено.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Совместное использование неизменяемых данных между потоками:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Обратите внимание, что мы **не** запускаем эти тесты здесь.
// Строители windows очень недовольны, если поток переживает основной поток и одновременно завершается (что-то заходит в тупик), поэтому мы просто полностью избегаем этого, не выполняя эти тесты.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Совместное использование изменяемого [`AtomicUsize`]:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// См. [`rc` documentation][rc_examples] для получения дополнительных примеров подсчета ссылок в целом.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` - это версия [`Arc`], которая содержит ссылку на управляемое выделение, не являющуюся владельцем.
/// Доступ к выделению осуществляется путем вызова [`upgrade`] на указателе `Weak`, который возвращает [`Option`]`<`[`Arc`] `<T>>`.
///
/// Поскольку ссылка `Weak` не засчитывается в счет владения, она не препятствует удалению значения, хранящегося в распределении, а сам `Weak` не дает никаких гарантий относительно того, что значение все еще присутствует.
///
/// Таким образом, он может вернуть [`None`] при [`upgrade`] d.
/// Однако обратите внимание, что ссылка `Weak`*действительно* предотвращает освобождение самого выделения (резервного хранилища).
///
/// Указатель `Weak` полезен для хранения временной ссылки на выделение, управляемое [`Arc`], без предотвращения удаления его внутреннего значения.
/// Он также используется для предотвращения циклических ссылок между указателями [`Arc`], поскольку ссылки взаимного владения никогда не позволят отбросить ни один из [`Arc`].
/// Например, дерево может иметь сильные указатели [`Arc`] от родительских узлов к дочерним элементам и указатели `Weak` от дочерних узлов к их родителям.
///
/// Типичный способ получить указатель `Weak`-вызвать [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Это `NonNull`, позволяющий оптимизировать размер этого типа в перечислениях, но это не обязательно действительный указатель.
    //
    // `Weak::new` устанавливает значение `usize::MAX`, чтобы не выделять место в куче.
    // Это не то значение, которое когда-либо будет иметь настоящий указатель, потому что RcBox имеет выравнивание не менее 2.
    // Это возможно только при `T: Sized`;безразмерный `T` никогда не болтается.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Это repr(C)-future-защита от возможного переупорядочивания полей, которое может помешать в противном случае безопасному [into|from]_raw() трансмутируемых внутренних типов.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // значение usize::MAX действует как дозорный для временной "locking" способности обновлять слабые указатели или понижать рейтинг сильных;это используется, чтобы избежать гонок в `make_mut` и `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Создает новый `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Начните отсчет слабого указателя с 1, который является слабым указателем, который удерживается всеми сильными указателями (kinda), см. std/rc.rs для получения дополнительной информации.
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Создает новый `Arc<T>`, используя слабую ссылку на себя.
    /// Попытка обновить слабую ссылку до того, как эта функция вернется, приведет к значению `None`.
    /// Однако слабая ссылка может быть свободно клонирована и сохранена для использования в более позднее время.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Создайте внутреннее состояние в состоянии "uninitialized" с помощью единственной слабой ссылки.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Важно, чтобы мы не отказывались от владения слабым указателем, иначе к моменту возврата `data_fn` память может освободиться.
        // Если бы мы действительно хотели передать право собственности, мы могли бы создать для себя дополнительный слабый указатель, но это привело бы к дополнительным обновлениям счетчика слабых ссылок, которые в противном случае могли бы не понадобиться.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Теперь мы можем правильно инициализировать внутреннее значение и превратить нашу слабую ссылку в сильную.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Вышеупомянутая запись в поле данных должна быть видима для любых потоков, которые наблюдают ненулевое сильное число.
            // Следовательно, для синхронизации с `compare_exchange_weak` в `Weak::upgrade` нам нужен заказ как минимум "Release".
            //
            // "Acquire" заказ не требуется.
            // При рассмотрении возможного поведения `data_fn` нам нужно только посмотреть, что он может делать со ссылкой на `Weak` без возможности обновления:
            //
            // - Он может *клонировать*`Weak`, увеличивая количество слабых ссылок.
            // - Он может отбросить эти клоны, уменьшив счетчик слабых ссылок (но никогда до нуля).
            //
            // Эти побочные эффекты никоим образом не влияют на нас, и никакие другие побочные эффекты невозможны только с помощью безопасного кода.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Сильные ссылки должны совместно владеть общей слабой ссылкой, поэтому не запускайте деструктор для нашей старой слабой ссылки.
        //
        mem::forget(weak);
        strong
    }

    /// Создает новый `Arc` с неинициализированным содержимым.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Отложенная инициализация:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Создает новый `Arc` с неинициализированным содержимым, при этом память заполняется байтами `0`.
    ///
    ///
    /// См. Примеры правильного и неправильного использования этого метода в [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Создает новый `Pin<Arc<T>>`.
    /// Если `T` не реализует `Unpin`, то `data` будет закреплен в памяти и не сможет быть перемещен.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Создает новый `Arc<T>`, возвращая ошибку в случае сбоя выделения.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Начните отсчет слабого указателя с 1, который является слабым указателем, который удерживается всеми сильными указателями (kinda), см. std/rc.rs для получения дополнительной информации.
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Создает новый `Arc` с неинициализированным содержимым, возвращая ошибку в случае сбоя выделения.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Отложенная инициализация:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Создает новый `Arc` с неинициализированным содержимым, при этом память заполняется байтами `0`, возвращая ошибку в случае сбоя выделения.
    ///
    ///
    /// См. Примеры правильного и неправильного использования этого метода в [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Возвращает внутреннее значение, если `Arc` имеет ровно одну сильную ссылку.
    ///
    /// В противном случае возвращается [`Err`] с тем же `Arc`, что был передан.
    ///
    ///
    /// Это будет успешным, даже если есть выдающиеся слабые ссылки.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Сделайте слабый указатель для очистки неявной сильной-слабой ссылки
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Создает новый фрагмент с атомарным подсчетом ссылок с неинициализированным содержимым.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Отложенная инициализация:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Создает новый срез с атомарным подсчетом ссылок с неинициализированным содержимым, при этом память заполняется байтами `0`.
    ///
    ///
    /// См. Примеры правильного и неправильного использования этого метода в [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Конвертируется в `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Как и в случае с [`MaybeUninit::assume_init`], вызывающая сторона должна гарантировать, что внутреннее значение действительно находится в инициализированном состоянии.
    ///
    /// Вызов этого, когда содержимое еще не полностью инициализировано, вызывает немедленное неопределенное поведение.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Отложенная инициализация:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Конвертируется в `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Как и в случае с [`MaybeUninit::assume_init`], вызывающая сторона должна гарантировать, что внутреннее значение действительно находится в инициализированном состоянии.
    ///
    /// Вызов этого, когда содержимое еще не полностью инициализировано, вызывает немедленное неопределенное поведение.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Отложенная инициализация:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Потребляет `Arc`, возвращая обернутый указатель.
    ///
    /// Чтобы избежать утечки памяти, указатель необходимо преобразовать обратно в `Arc` с помощью [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Предоставляет необработанный указатель на данные.
    ///
    /// На счетчики никоим образом не влияют, и `Arc` не потребляется.
    /// Указатель действителен до тех пор, пока в `Arc` есть сильные счетчики.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // БЕЗОПАСНОСТЬ: это не может пройти через Deref::deref или RcBoxPtr::inner, потому что
        // это необходимо для сохранения происхождения raw/mut, чтобы, например,
        // `get_mut` может писать через указатель после восстановления Rc через `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Создает `Arc<T>` из необработанного указателя.
    ///
    /// Необработанный указатель должен быть ранее возвращен вызовом [`Arc<U>::into_raw`][into_raw], где `U` должен иметь тот же размер и выравнивание, что и `T`.
    /// Это тривиально верно, если `U`-это `T`.
    /// Обратите внимание, что если `U` не является `T`, но имеет тот же размер и выравнивание, это в основном похоже на преобразование ссылок разных типов.
    /// См. [`mem::transmute`][transmute] для получения дополнительной информации о том, какие ограничения применяются в этом случае.
    ///
    /// Пользователь `from_raw` должен убедиться, что определенное значение `T` сбрасывается только один раз.
    ///
    /// Эта функция небезопасна, потому что неправильное использование может привести к небезопасности памяти, даже если возвращенный `Arc<T>` никогда не будет доступен.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Вернитесь к `Arc`, чтобы предотвратить утечку.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Дальнейшие вызовы `Arc::from_raw(x_ptr)` будут небезопасными для памяти.
    /// }
    ///
    /// // Память была освобождена, когда `x` вышел за рамки описанного выше, поэтому теперь `x_ptr` болтается!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Обратите смещение, чтобы найти исходный ArcInner.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Создает новый указатель [`Weak`] на это выделение.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Это расслабленное-это нормально, потому что мы проверяем значение в CAS ниже.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // проверьте, является ли в настоящий момент слабым счетчиком "locked";если да, то крутите.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: этот код в настоящее время игнорирует возможность переполнения
            // в usize::MAX;в общем, как Rc, так и Arc необходимо отрегулировать, чтобы справиться с переполнением.
            //

            // В отличие от Clone(), нам нужно, чтобы это было чтение Acquire для синхронизации с записью, исходящей от `is_unique`, чтобы события, предшествующие этой записи, происходили до этого чтения.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Убедитесь, что мы не создаем болтающиеся слабые места.
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Получает количество указателей [`Weak`] на это выделение.
    ///
    /// # Safety
    ///
    /// Сам по себе этот метод безопасен, но его правильное использование требует особой осторожности.
    /// Другой поток может изменить слабый счетчик в любое время, в том числе потенциально между вызовом этого метода и действием на результат.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Это утверждение детерминировано, потому что мы не разделили `Arc` или `Weak` между потоками.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Если слабый счетчик в настоящее время заблокирован, значение счетчика было 0 непосредственно перед взятием блокировки.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Получает количество сильных указателей (`Arc`) на это выделение.
    ///
    /// # Safety
    ///
    /// Сам по себе этот метод безопасен, но его правильное использование требует особой осторожности.
    /// Другой поток может изменить строгий счетчик в любое время, в том числе потенциально между вызовом этого метода и действием на результат.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Это утверждение детерминировано, потому что мы не распределяли `Arc` между потоками.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Увеличивает счетчик сильных ссылок на `Arc<T>`, связанный с предоставленным указателем, на единицу.
    ///
    /// # Safety
    ///
    /// Указатель должен быть получен через `Arc::into_raw`, и связанный с ним экземпляр `Arc` должен быть действительным (т. Е.
    /// сильный счет должен быть не менее 1) на время действия этого метода.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Это утверждение детерминировано, потому что мы не распределяли `Arc` между потоками.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Сохраните Arc, но не трогайте refcount, заключив в ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Теперь увеличьте счетчик ссылок, но не сбрасывайте и новый счетчик ссылок.
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Уменьшает на единицу счетчик сильных ссылок на `Arc<T>`, связанных с предоставленным указателем.
    ///
    /// # Safety
    ///
    /// Указатель должен быть получен через `Arc::into_raw`, и связанный с ним экземпляр `Arc` должен быть действительным (т. Е.
    /// при вызове этого метода сильное число должно быть не менее 1).
    /// Этот метод можно использовать для освобождения окончательного `Arc` и резервного хранилища, но **не следует** вызывать после того, как был выпущен последний `Arc`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Эти утверждения детерминированы, потому что мы не разделяем `Arc` между потоками.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Это небезопасно, потому что пока эта дуга жива, мы гарантируем, что внутренний указатель действителен.
        // Кроме того, мы знаем, что сама структура `ArcInner`-это `Sync`, потому что внутренние данные также являются `Sync`, поэтому мы можем предоставить неизменный указатель на это содержимое.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Не встроенная часть `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Уничтожьте данные в это время, даже если мы не можем освободить само выделение бокса (могут все еще лежать слабые указатели).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Отбросьте слабого рефери, которого удерживают все сильные рефери
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Возвращает `true`, если две `Arc`s указывают на одно и то же размещение (аналогично [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Выделяет `ArcInner<T>` с достаточным пространством для, возможно, не имеющего размера внутреннего значения, где для значения предоставлен макет.
    ///
    /// Функция `mem_to_arcinner` вызывается с указателем данных и должна возвращать (потенциально жирный) указатель для `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Рассчитайте макет, используя макет заданного значения.
        // Ранее макет вычислялся по выражению `&*(ptr as* const ArcInner<T>)`, но это создавало смещенную ссылку (см. #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Выделяет `ArcInner<T>` с достаточным пространством для, возможно, безразмерного внутреннего значения, в котором значение имеет предоставленный макет, возвращая ошибку в случае сбоя выделения.
    ///
    ///
    /// Функция `mem_to_arcinner` вызывается с указателем данных и должна возвращать (потенциально жирный) указатель для `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Рассчитайте макет, используя макет заданного значения.
        // Ранее макет вычислялся по выражению `&*(ptr as* const ArcInner<T>)`, но это создавало смещенную ссылку (см. #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Инициализировать ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Выделяет `ArcInner<T>` достаточным пространством для внутреннего значения без размера.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Выделите для `ArcInner<T>` с использованием заданного значения.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Копировать значение в байтах
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Освободите выделение без потери его содержимого
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Выделяет `ArcInner<[T]>` заданной длины.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Скопируйте элементы из среза во вновь выделенную дугу <\[T\]>
    ///
    /// Небезопасно, потому что вызывающий должен либо взять на себя ответственность, либо связать `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Создает `Arc<[T]>` из итератора определенного размера.
    ///
    /// Поведение не определено, если размер неправильный.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic охраняет при клонировании Т-элементов.
        // В случае panic элементы, которые были записаны в новый ArcInner, будут отброшены, а затем память будет освобождена.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Указатель на первый элемент
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Все чисто.Забудьте о страже, чтобы он не освободил новый ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Специализация trait используется для `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Создает клон указателя `Arc`.
    ///
    /// Это создает еще один указатель на то же выделение, увеличивая счетчик сильных ссылок.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Здесь можно использовать ослабленный порядок, поскольку знание исходной ссылки предотвращает ошибочное удаление объекта другими потоками.
        //
        // Как объясняется в [Boost documentation][1], увеличение счетчика ссылок всегда можно выполнить с помощью memory_order_relaxed: новые ссылки на объект могут быть сформированы только из существующей ссылки, а передача существующей ссылки из одного потока в другой уже должна обеспечивать любую требуемую синхронизацию.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Однако нам нужно остерегаться массового пересчета на случай, если кто-то `mem: : Забывает` Arcs.
        // Если мы этого не сделаем, счетчик может переполниться, и пользователи будут использовать бесплатно.
        // Мы быстро приближаемся к `isize::MAX`, исходя из предположения, что нет ~2 миллиардов потоков, увеличивающих счетчик ссылок за один раз.
        //
        // Этот branch никогда не будет использован ни в одной реалистичной программе.
        //
        // Мы прерываем работу, потому что такая программа невероятно дегенеративна, и мы не заботимся о ее поддержке.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Делает изменяемую ссылку на данный `Arc`.
    ///
    /// Если есть другие указатели `Arc` или [`Weak`] для того же распределения, то `make_mut` создаст новое распределение и вызовет [`clone`][clone] для внутреннего значения, чтобы гарантировать уникальное владение.
    /// Это также называется клонированием при записи.
    ///
    /// Обратите внимание, что это отличается от поведения [`Rc::make_mut`], которое разъединяет любые оставшиеся указатели `Weak`.
    ///
    /// См. Также [`get_mut`][get_mut], который завершится ошибкой, а не клонированием.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Не буду ничего клонировать
    /// let mut other_data = Arc::clone(&data); // Не клонирует внутренние данные
    /// *Arc::make_mut(&mut data) += 1;         // Клонирует внутренние данные
    /// *Arc::make_mut(&mut data) += 1;         // Не буду ничего клонировать
    /// *Arc::make_mut(&mut other_data) *= 2;   // Не буду ничего клонировать
    ///
    /// // Теперь `data` и `other_data` указывают на разные распределения.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Обратите внимание, что у нас есть как сильная, так и слабая ссылка.
        // Таким образом, освобождение только нашей сильной ссылки само по себе не приведет к освобождению памяти.
        //
        // Используйте Acquire, чтобы убедиться, что мы видим любые записи в `weak`, которые происходят до записи выпуска (т. Е. Уменьшаются) в `strong`.
        // Поскольку у нас слабый счетчик, нет никаких шансов, что сам ArcInner может быть освобожден.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Существует еще один сильный указатель, поэтому мы должны клонировать.
            // Предварительно выделите память, чтобы можно было напрямую записать клонированное значение.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Изложенного выше достаточно расслабленного, потому что это, по сути, оптимизация: мы всегда гоняемся, когда отбрасываются слабые указатели.
            // В худшем случае мы без надобности выделяем новую дугу.
            //

            // Мы удалили последнего сильного рефери, но остались дополнительные слабые рефери.
            // Мы переместим содержимое в новую дугу и сделаем недействительными другие слабые ссылки.
            //

            // Обратите внимание, что чтение `weak` не может дать usize::MAX (т. Е. Заблокировано), поскольку слабый счетчик может быть заблокирован только потоком с сильной ссылкой.
            //
            //

            // Материализуйте наш собственный неявный слабый указатель, чтобы он мог очистить ArcInner по мере необходимости.
            //
            let _weak = Weak { ptr: this.ptr };

            // Могу просто украсть данные, все, что осталось, это слабые стороны
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Мы были единственным представителем любого рода;увеличьте количество сильных ссылок.
            //
            this.inner().strong.store(1, Release);
        }

        // Как и в случае с `get_mut()`, небезопасность в порядке, потому что наша ссылка была либо уникальной с самого начала, либо стала таковой после клонирования содержимого.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Возвращает изменяемую ссылку на данный `Arc`, если нет других указателей `Arc` или [`Weak`] на то же выделение.
    ///
    ///
    /// В противном случае возвращает [`None`], поскольку изменение общего значения небезопасно.
    ///
    /// См. Также [`make_mut`][make_mut], который будет [`clone`][clone] внутренним значением при наличии других указателей.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Это небезопасно, потому что мы гарантируем, что возвращаемый указатель является *единственным* указателем, который когда-либо будет возвращен в T.
            // В этот момент наш счетчик ссылок гарантированно равен 1, и мы требовали, чтобы сама Arc была `mut`, поэтому мы возвращаем единственную возможную ссылку на внутренние данные.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Возвращает изменяемую ссылку на данный `Arc` без какой-либо проверки.
    ///
    /// См. Также [`get_mut`], который безопасен и выполняет соответствующие проверки.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Любые другие указатели `Arc` или [`Weak`] на то же выделение не должны разыменовываться на время возвращенного заимствования.
    ///
    /// Это тривиально, если таких указателей не существует, например, сразу после `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Мы стараемся *не* создавать ссылку, охватывающую поля "count", поскольку это будет псевдонимом с одновременным доступом к счетчикам ссылок (например,
        // пользователя `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Определите, является ли это уникальной ссылкой (включая слабые ссылки) на базовые данные.
    ///
    ///
    /// Обратите внимание, что для этого требуется заблокировать счетчик слабых ссылок.
    fn is_unique(&mut self) -> bool {
        // заблокируйте счетчик слабых указателей, если мы кажемся единственным держателем слабых указателей.
        //
        // Метка получения здесь обеспечивает связь «происходит раньше» с любыми записями в `strong` (в частности, в `Weak::upgrade`) до уменьшения счетчика `weak` (через `Weak::drop`, который использует освобождение).
        // Если обновленное слабое задание никогда не сбрасывалось, здесь CAS откажет, поэтому синхронизация не требуется.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Это должен быть `Acquire` для синхронизации с уменьшением счетчика `strong` в `drop`-единственный доступ, который происходит, когда отбрасывается любая, кроме последней ссылки.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Запись при освобождении синхронизируется с чтением в `downgrade`, эффективно предотвращая выполнение вышеупомянутого чтения `strong` после записи.
            //
            //
            self.inner().weak.store(1, Release); // отпустить замок
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Сбрасывает `Arc`.
    ///
    /// Это уменьшит количество сильных ссылок.
    /// Если счетчик сильных ссылок достигает нуля, тогда единственными другими ссылками (если есть) являются [`Weak`], поэтому мы `drop` внутреннее значение.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Ничего не печатает
    /// drop(foo2);   // Печать "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Поскольку `fetch_sub` уже является атомарным, нам не нужно синхронизироваться с другими потоками, если мы не собираемся удалять объект.
        // Та же самая логика применяется к нижнему `fetch_sub` к счетчику `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Этот забор необходим для предотвращения изменения порядка использования данных и удаления данных.
        // Поскольку он отмечен как `Release`, уменьшение счетчика ссылок синхронизируется с этим ограничением `Acquire`.
        // Это означает, что использование данных происходит до уменьшения счетчика ссылок, что происходит перед этим ограничителем, что происходит до удаления данных.
        //
        // Как объясняется в [Boost documentation][1],
        //
        // > Важно обеспечить любой возможный доступ к объекту в одном
        // > поток (через существующую ссылку), чтобы *происходить перед* удалением
        // > объект в другом потоке.Это достигается с помощью "release"
        // > операция после удаления ссылки (любой доступ к объекту
        // > через эту ссылку, очевидно, должно было произойти раньше), и
        // > "acquire" перед удалением объекта.
        //
        // В частности, хотя содержимое Arc обычно неизменяемо, возможно внутренняя запись в нечто вроде Mutex.<T>.
        // Поскольку при удалении мьютекс не создается, мы не можем полагаться на его логику синхронизации, чтобы сделать запись в потоке A видимой для деструктора, работающего в потоке B.
        //
        //
        // Также обратите внимание, что ограничение Acquire здесь, вероятно, можно было бы заменить загрузкой Acquire, что могло бы улучшить производительность в очень конфликтных ситуациях.См. [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Попытка свести `Arc<dyn Any + Send + Sync>` к конкретному типу.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Создает новый `Weak<T>` без выделения памяти.
    /// Вызов [`upgrade`] по возвращаемому значению всегда дает [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Тип помощника, позволяющий получить доступ к счетчикам ссылок без каких-либо утверждений о поле данных.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Возвращает необработанный указатель на объект `T`, на который указывает этот `Weak<T>`.
    ///
    /// Указатель действителен только при наличии сильных ссылок.
    /// Указатель может быть висящим, невыровненным или даже [`null`] в противном случае.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Оба указывают на один и тот же объект
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Сильный здесь поддерживает его, поэтому мы все еще можем получить доступ к объекту.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Но не больше.
    /// // Мы можем сделать weak.as_ptr(), но доступ к указателю приведет к неопределенному поведению.
    /// // assert_eq! ("привет", небезопасно {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Если указатель болтается, мы возвращаем дозор напрямую.
            // Это не может быть действительным адресом полезной нагрузки, так как полезная нагрузка, по крайней мере, выровнена так же, как и ArcInner (usize).
            ptr as *const T
        } else {
            // БЕЗОПАСНОСТЬ: если is_dangling возвращает false, то указатель может быть разыменован.
            // На этом этапе полезная нагрузка может быть отброшена, и мы должны поддерживать происхождение, поэтому используйте манипуляции с необработанными указателями.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Использует `Weak<T>` и превращает его в необработанный указатель.
    ///
    /// Это преобразует слабый указатель в необработанный указатель, сохраняя при этом право собственности на одну слабую ссылку (слабый счетчик не изменяется этой операцией).
    /// Его можно снова превратить в `Weak<T>` с помощью [`from_raw`].
    ///
    /// Применяются те же ограничения доступа к цели указателя, что и для [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Преобразует необработанный указатель, ранее созданный [`into_raw`], обратно в `Weak<T>`.
    ///
    /// Это можно использовать для безопасного получения сильной ссылки (путем вызова [`upgrade`] позже) или для освобождения слабого счетчика путем отбрасывания `Weak<T>`.
    ///
    /// Ему принадлежит одна слабая ссылка (за исключением указателей, созданных [`new`], поскольку они ничего не владеют; метод по-прежнему работает с ними).
    ///
    /// # Safety
    ///
    /// Указатель должен исходить от [`into_raw`] и все еще иметь потенциально слабую ссылку.
    ///
    /// Допускается, чтобы сильный счетчик был равен 0 во время вызова этого.
    /// Тем не менее, он становится владельцем одной слабой ссылки, представленной в настоящее время как необработанный указатель (слабый счетчик не изменяется этой операцией), и поэтому он должен быть связан с предыдущим вызовом [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Уменьшить последний слабый счетчик.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // См. В Weak::as_ptr контекст получения входного указателя.

        let ptr = if is_dangling(ptr as *mut T) {
            // Это висящая слабость.
            ptr as *mut ArcInner<T>
        } else {
            // В противном случае мы гарантируем, что указатель был получен из-за не запутанного слабого места.
            // БЕЗОПАСНОСТЬ: вызов data_offset безопасен, поскольку ptr ссылается на реальный (потенциально сброшенный) T.
            let offset = unsafe { data_offset(ptr) };
            // Таким образом, мы меняем смещение, чтобы получить весь RcBox.
            // БЕЗОПАСНОСТЬ: указатель произошел от слабого, поэтому это смещение безопасно.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // БЕЗОПАСНОСТЬ: теперь мы восстановили исходный слабый указатель, поэтому можем создать слабый.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Пытается обновить указатель `Weak` до [`Arc`], задерживая сброс внутреннего значения в случае успеха.
    ///
    ///
    /// Возвращает [`None`], если внутреннее значение с тех пор было отброшено.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Уничтожьте все сильные указатели.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Мы используем цикл CAS для увеличения сильного счетчика вместо fetch_add, поскольку эта функция никогда не должна переводить счетчик ссылок с нуля до единицы.
        //
        //
        let inner = self.inner()?;

        // Ослабленная нагрузка, потому что любая запись 0, которую мы можем наблюдать, оставляет поле в постоянно нулевом состоянии (так что чтение 0 "stale" нормально), а любое другое значение подтверждается через CAS ниже.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // См. Комментарии в `Arc::clone` о том, почему мы это делаем (для `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relaxed подходит для случая сбоя, потому что у нас нет никаких ожиданий по поводу нового состояния.
            // Получение необходимо для успешной синхронизации с `Arc::new_cyclic`, когда внутреннее значение может быть инициализировано после того, как ссылки `Weak` уже созданы.
            // В этом случае мы ожидаем увидеть полностью инициализированное значение.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null отмечен выше
                Err(old) => n = old,
            }
        }
    }

    /// Получает количество сильных указателей (`Arc`), указывающих на это выделение.
    ///
    /// Если `self` был создан с использованием [`Weak::new`], это вернет 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Получает приблизительное количество указателей `Weak`, указывающих на это выделение.
    ///
    /// Если `self` был создан с использованием [`Weak::new`] или если не осталось сильных указателей, это вернет 0.
    ///
    /// # Accuracy
    ///
    /// Из-за деталей реализации возвращаемое значение может отличаться на 1 в любом направлении, когда другие потоки манипулируют любыми `Arc`s или`Weak`s, указывающими на одно и то же выделение.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Поскольку мы заметили, что после чтения слабого счетчика имелся по крайней мере один сильный указатель, мы знаем, что неявная слабая ссылка (присутствует, когда есть какие-либо сильные ссылки) все еще присутствовала, когда мы наблюдали слабый счет, и поэтому можем безопасно вычесть ее.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Возвращает `None`, когда указатель болтается и нет выделенного `ArcInner` (то есть, когда этот `Weak` был создан `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Мы стараемся *не* создавать ссылку, покрывающую поле "data", поскольку поле может быть изменено одновременно (например, если последний `Arc` будет удален, поле данных будет удалено на месте).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Возвращает `true`, если два `Weak`s указывают на одно и то же выделение (аналогично [`ptr::eq`]), или если оба не указывают ни на какое выделение (потому что они были созданы с помощью `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Поскольку это сравнивает указатели, это означает, что `Weak::new()` будут равны друг другу, даже если они не указывают на какое-либо выделение.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Сравнение `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Создает клон указателя `Weak`, который указывает на то же выделение.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // См. Комментарии в Arc::clone(), чтобы узнать, почему это смягчено.
        // Это может использовать fetch_add (игнорируя блокировку), потому что слабый счетчик заблокирован только там, где *нет других* слабых указателей.
        //
        // (Значит, в этом случае мы не сможем запустить этот код).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // См. Комментарии в Arc::clone() о том, почему мы это делаем (для mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Создает новый `Weak<T>` без выделения памяти.
    /// Вызов [`upgrade`] по возвращаемому значению всегда дает [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Отбрасывает указатель `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ничего не печатает
    /// drop(foo);        // Печать "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Если мы обнаружим, что мы были последним слабым указателем, то пора полностью освободить данные.См. Обсуждение порядка памяти в Arc::drop().
        //
        // Здесь нет необходимости проверять заблокированное состояние, потому что счетчик слабых данных может быть заблокирован только в том случае, если существует ровно одна слабая ссылка, а это означает, что отбрасывание может впоследствии запускаться только на этой оставшейся слабой ссылке, что может произойти только после снятия блокировки.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Мы делаем эту специализацию здесь, а не как более общую оптимизацию на `&T`, потому что в противном случае это увеличило бы стоимость всех проверок равенства для ссылок.
/// Мы предполагаем, что `Arc`s используются для хранения больших значений, которые медленно клонируются, но также сложно проверять на равенство, в результате чего эти затраты легче окупаются.
///
/// Также более вероятно наличие двух клонов `Arc`, указывающих на одно и то же значение, чем двух `&T.
///
/// Мы можем сделать это только тогда, когда `T: Eq` как `PartialEq` может быть намеренно нерефлексивным.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Равенство для двух `Arc`s.
    ///
    /// Две дуги равны, если их внутренние значения равны, даже если они хранятся в разных местах.
    ///
    /// Если `T` также реализует `Eq` (подразумевая рефлексивность равенства), два `Arc ', которые указывают на одно и то же распределение, всегда равны.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Неравенство для двух Arc`s.
    ///
    /// Две дуги не равны, если их внутренние значения не равны.
    ///
    /// Если `T` также реализует `Eq` (подразумевая рефлексивность равенства), две `Arc ', указывающие на одно и то же значение, никогда не будут неравными.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Частичное сравнение двух Arc`s.
    ///
    /// Эти два сравниваются путем вызова `partial_cmp()` по их внутренним значениям.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Менее чем сравнение для двух Arc`s.
    ///
    /// Эти два сравниваются путем вызова `<` по их внутренним значениям.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Сравнение «Меньше или равно» для двух «Arc`s.
    ///
    /// Эти два сравниваются путем вызова `<=` по их внутренним значениям.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Больше чем сравнение для двух `Arc`s.
    ///
    /// Эти два сравниваются путем вызова `>` по их внутренним значениям.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Сравнение "Больше или равно" для двух Arc`s.
    ///
    /// Эти два сравниваются путем вызова `>=` по их внутренним значениям.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Сравнение двух файлов Arc`s.
    ///
    /// Эти два сравниваются путем вызова `cmp()` по их внутренним значениям.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Создает новый `Arc<T>` со значением `Default` для `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Выделите срез с подсчетом ссылок и заполните его, клонируя элементы `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Выделите `str` со счетчиком ссылок и скопируйте в него `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Выделите `str` со счетчиком ссылок и скопируйте в него `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Переместите упакованный объект в новое выделение с подсчетом ссылок.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Выделите срез с подсчетом ссылок и переместите в него элементы `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Разрешить Vec освободить память, но не уничтожить ее содержимое
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Берет каждый элемент в `Iterator` и собирает его в `Arc<[T]>`.
    ///
    /// # Тактико-технические характеристики
    ///
    /// ## Общий случай
    ///
    /// В общем случае сбор в `Arc<[T]>` выполняется сначала в `Vec<T>`.То есть при написании следующего:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// это ведет себя так, как если бы мы написали:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Здесь происходит первый набор распределений.
    ///     .into(); // Здесь происходит второе выделение для `Arc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// При этом будет выделено столько раз, сколько необходимо для построения `Vec<T>`, а затем будет выделено один раз для превращения `Vec<T>` в `Arc<[T]>`.
    ///
    ///
    /// ## Итераторы известной длины
    ///
    /// Когда ваш `Iterator` реализует `TrustedLen` и имеет точный размер, для `Arc<[T]>` будет сделано одно выделение.Например:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Здесь происходит всего одно выделение.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Специализация trait используется для сбора в `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Это случай итератора `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // БЕЗОПАСНОСТЬ: нам нужно убедиться, что итератор имеет точную длину, а у нас есть.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Вернитесь к нормальной реализации.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Получите смещение в `ArcInner` для полезной нагрузки за указателем.
///
/// # Safety
///
/// Указатель должен указывать на (и иметь допустимые метаданные для) ранее действующий экземпляр T, но T можно отбросить.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Совместите безразмерное значение с концом ArcInner.
    // Поскольку RcBox-repr(C), он всегда будет последним полем в памяти.
    // БЕЗОПАСНОСТЬ: поскольку единственными возможными типами без размера являются срезы, объекты trait,
    // и типов extern, требования безопасности ввода в настоящее время достаточно для удовлетворения требований align_of_val_raw;это деталь реализации языка, на которую нельзя полагаться вне std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}