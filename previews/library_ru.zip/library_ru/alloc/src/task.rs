#![stable(feature = "wake_trait", since = "1.51.0")]
//! Типы и Traits для работы с асинхронными задачами.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Реализация пробуждения задачи по исполнителю.
///
/// Этот trait можно использовать для создания [`Waker`].
/// Исполнитель может определить реализацию этого trait и использовать это для создания Waker для перехода к задачам, которые выполняются на этом исполнителе.
///
/// trait-безопасная для памяти и эргономичная альтернатива конструкции [`RawWaker`].
/// Он поддерживает общий дизайн исполнителя, в котором данные, используемые для пробуждения задачи, хранятся в [`Arc`].
/// Некоторые исполнители (особенно для встроенных систем) не могут использовать этот API, поэтому [`RawWaker`] существует как альтернатива для этих систем.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Базовая функция `block_on`, которая берет future и запускает его до завершения в текущем потоке.
///
/// **Note:** Этот пример торгует правильностью для простоты.
/// Чтобы предотвратить взаимоблокировки, реализации производственного уровня также должны будут обрабатывать промежуточные вызовы `thread::unpark`, а также вложенные вызовы.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Waker, который будит текущий поток при вызове.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Запустить future до завершения в текущем потоке.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Закрепите future, чтобы его можно было опросить.
///     let mut fut = Box::pin(fut);
///
///     // Создайте новый контекст для передачи в future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Запустите future до завершения.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Разбуди эту задачу.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Разбудите эту задачу, не поглощая будильника.
    ///
    /// Если исполнитель поддерживает более дешевый способ пробуждения без использования пробуждения, он должен переопределить этот метод.
    /// По умолчанию он клонирует [`Arc`] и вызывает [`wake`] на клоне.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // БЕЗОПАСНОСТЬ: это безопасно, потому что raw_waker безопасно создает
        // RawWaker от Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Эта закрытая функция для создания RawWaker используется, а не
// вставка этого в `From<Arc<W>> for RawWaker` impl, чтобы гарантировать, что безопасность `From<Arc<W>> for Waker` не зависит от правильной отправки trait, вместо этого оба impls вызывают эту функцию напрямую и явно.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Увеличьте счетчик ссылок дуги, чтобы клонировать ее.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Пробуждение по значению, перемещение дуги в функцию Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Пробуждение по ссылке, оберните пробуждение в ManuallyDrop, чтобы не уронить его
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Уменьшить счетчик ссылок дуги при падении
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}