//! Распределение Prelude
//!
//! Цель этого модуля-облегчить импорт часто используемых элементов `alloc` crate путем добавления импорта глобуса в верхнюю часть модулей:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;