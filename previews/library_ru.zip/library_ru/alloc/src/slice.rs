//! Вид непрерывной последовательности с динамическим размером, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Срезы-это представление блока памяти, представленного в виде указателя и длины.
//!
//! ```
//! // нарезка Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // принуждение массива к срезу
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Срезы могут быть изменяемыми или совместно используемыми.
//! Тип общего среза-`&[T]`, а изменяемый тип среза-`&mut [T]`, где `T` представляет тип элемента.
//! Например, вы можете изменить блок памяти, на который указывает изменяемый фрагмент:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Вот некоторые вещи, которые содержит этот модуль:
//!
//! ## Structs
//!
//! Есть несколько структур, которые полезны для срезов, например [`Iter`], который представляет итерацию по срезу.
//!
//! ## Trait Реализации
//!
//! Существует несколько реализаций обычного traits для срезов.Вот некоторые примеры:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`] для срезов с типом элемента [`Eq`] или [`Ord`].
//! * [`Hash`] - для срезов с типом элемента [`Hash`].
//!
//! ## Iteration
//!
//! Срезы реализуют `IntoIterator`.Итератор выдает ссылки на элементы среза.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Изменяемый срез дает изменяемые ссылки на элементы:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Этот итератор дает изменяемые ссылки на элементы среза, поэтому, хотя тип элемента среза-`i32`, тип элемента итератора-`&mut i32`.
//!
//!
//! * [`.iter`] и [`.iter_mut`]-явные методы для возврата итераторов по умолчанию.
//! * Другие методы, возвращающие итераторы,-это [`.split`], [`.splitn`], [`.chunks`], [`.windows`] и другие.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Многие варианты использования этого модуля используются только в тестовой конфигурации.
// Чище просто отключить предупреждение unused_imports, чем исправлять их.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Основные методы расширения среза
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) необходим для реализации макроса `vec!` во время тестирования NB, см. модуль `hack` в этом файле для более подробной информации.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) необходим для реализации `Vec::clone` во время тестирования NB, см. модуль `hack` в этом файле для более подробной информации.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): С cfg(test) `impl [T]` недоступен, эти три функции на самом деле являются методами, которые есть в `impl [T]`, но не в `core::slice::SliceExt`, нам необходимо предоставить эти функции для теста `test_permutations`.
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Мы не должны добавлять к нему встроенный атрибут, поскольку он в основном используется в макросе `vec!` и вызывает регрессию производительности.
    // См. #71204 для обсуждения и результатов производительности.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // элементы были помечены как инициализированные в цикле ниже
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) необходим для LLVM для удаления проверок границ и имеет лучший кодогенератор, чем zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec был выделен и инициализирован выше, по крайней мере, этой длины.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // выделенный выше с емкостью `s`, и инициализировать `s.len()` в ptr::copy_to_non_overlapping ниже.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Сортирует ломтик.
    ///
    /// Эта сортировка является стабильной (т. Е. Не переупорядочивает одинаковые элементы) и *O*(*n*\*log(* n*)) в худшем случае.
    ///
    /// Если применимо, предпочтительна нестабильная сортировка, поскольку она обычно быстрее, чем стабильная сортировка, и не выделяет вспомогательную память.
    /// См. [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Текущая реализация
    ///
    /// Текущий алгоритм представляет собой адаптивную итеративную сортировку слиянием, вдохновленную [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Он разработан, чтобы быть очень быстрым в случаях, когда фрагмент почти отсортирован или состоит из двух или более отсортированных последовательностей, соединенных друг за другом.
    ///
    ///
    /// Кроме того, он выделяет временное хранилище в два раза меньше размера `self`, но для коротких фрагментов вместо этого используется сортировка вставкой без выделения памяти.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Сортирует фрагмент с помощью функции компаратора.
    ///
    /// Эта сортировка является стабильной (т. Е. Не переупорядочивает одинаковые элементы) и *O*(*n*\*log(* n*)) в худшем случае.
    ///
    /// Функция компаратора должна определять общий порядок элементов в срезе.Если порядок не является полным, порядок элементов не указан.
    /// Заказ является общим заказом, если он (для всех `a`, `b` и `c`):
    ///
    /// * тотальный и антисимметричный: верно только одно из `a < b`, `a == b` или `a > b`, и
    /// * транзитивный, `a < b` и `b < c` влечет `a < c`.То же самое должно выполняться как для `==`, так и для `>`.
    ///
    /// Например, хотя [`f64`] не реализует [`Ord`] из-за `NaN != NaN`, мы можем использовать `partial_cmp` в качестве нашей функции сортировки, когда мы знаем, что срез не содержит `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Если применимо, предпочтительна нестабильная сортировка, поскольку она обычно быстрее, чем стабильная сортировка, и не выделяет вспомогательную память.
    /// См. [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Текущая реализация
    ///
    /// Текущий алгоритм представляет собой адаптивную итеративную сортировку слиянием, вдохновленную [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Он разработан, чтобы быть очень быстрым в случаях, когда фрагмент почти отсортирован или состоит из двух или более отсортированных последовательностей, соединенных друг за другом.
    ///
    /// Кроме того, он выделяет временное хранилище в два раза меньше размера `self`, но для коротких фрагментов вместо этого используется сортировка вставкой без выделения памяти.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // обратная сортировка
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Сортирует фрагмент с функцией извлечения ключа.
    ///
    /// Эта сортировка является стабильной (т. Е. Не переупорядочивает одинаковые элементы) и *O*(*m*\* * n *\* log(*n*)) в худшем случае, когда ключевой функцией является *O*(*m*).
    ///
    /// Для дорогих ключевых функций (например,
    /// функции, которые не являются простым доступом к свойствам или базовыми операциями), [`sort_by_cached_key`](slice::sort_by_cached_key), вероятно, будет значительно быстрее, поскольку он не пересчитывает ключи элементов.
    ///
    ///
    /// Если применимо, предпочтительна нестабильная сортировка, поскольку она обычно быстрее, чем стабильная сортировка, и не выделяет вспомогательную память.
    /// См. [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Текущая реализация
    ///
    /// Текущий алгоритм представляет собой адаптивную итеративную сортировку слиянием, вдохновленную [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Он разработан, чтобы быть очень быстрым в случаях, когда фрагмент почти отсортирован или состоит из двух или более отсортированных последовательностей, соединенных друг за другом.
    ///
    /// Кроме того, он выделяет временное хранилище в два раза меньше размера `self`, но для коротких фрагментов вместо этого используется сортировка вставкой без выделения памяти.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Сортирует фрагмент с функцией извлечения ключа.
    ///
    /// Во время сортировки ключевая функция вызывается только один раз для каждого элемента.
    ///
    /// Эта сортировка стабильна (т. Е. Не переупорядочивает одинаковые элементы) и *O*(*m*\* * n *+* n *\* log(*n*)) в худшем случае, где ключевой функцией является *O*(*m*) .
    ///
    /// Для простых ключевых функций (например, функций, которые являются доступом к свойствам или базовыми операциями) [`sort_by_key`](slice::sort_by_key), вероятно, будет быстрее.
    ///
    /// # Текущая реализация
    ///
    /// Текущий алгоритм основан на [pattern-defeating quicksort][pdqsort] от Орсона Петерса, который сочетает в себе быстрый средний случай рандомизированной быстрой сортировки с быстрым наихудшим случаем heapsort, обеспечивая при этом линейное время на срезах с определенными шаблонами.
    /// Он использует некоторую рандомизацию, чтобы избежать вырожденных случаев, но с фиксированным seed, чтобы всегда обеспечивать детерминированное поведение.
    ///
    /// В худшем случае алгоритм выделяет временное хранилище в размере `Vec<(K, usize)>` длины слайса.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Вспомогательный макрос для индексации нашего vector наименьшим возможным типом, чтобы уменьшить выделение.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Элементы `indices` уникальны, поскольку они индексированы, поэтому любая сортировка будет стабильной по отношению к исходному срезу.
                // Здесь мы используем `sort_unstable`, потому что он требует меньше памяти.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Копирует `self` в новый `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Здесь `s` и `x` могут быть изменены независимо.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Копирует `self` в новый `Vec` с распределителем.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Здесь `s` и `x` могут быть изменены независимо.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, для получения более подробной информации см. Модуль `hack` в этом файле.
        hack::to_vec(self, alloc)
    }

    /// Преобразует `self` в vector без клонов или выделения.
    ///
    /// Полученный vector может быть преобразован обратно в коробку с помощью `Vec<T>метод `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` больше не может использоваться, потому что он был преобразован в `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, для получения более подробной информации см. Модуль `hack` в этом файле.
        hack::into_vec(self)
    }

    /// Создает vector, повторяя срез `n` раз.
    ///
    /// # Panics
    ///
    /// Эта функция будет panic, если емкость переполнится.
    ///
    /// # Examples
    ///
    /// Основное использование:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic при переполнении:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Если `n` больше нуля, его можно разделить как `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` - это число, представленное крайним левым битом '1' `n`, а `rem`-оставшаяся часть `n`.
        //
        //

        // Использование `Vec` для доступа к `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` повторение выполняется удвоением `buf` `expn`-раз.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Если `m > 0`, есть оставшиеся биты до самого левого '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` имеет емкость `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) повторение выполняется путем копирования первых повторений `rem` из самого `buf`.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Это не перекрывается с `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` равно `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Сглаживает фрагмент `T` в одно значение `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Сглаживает фрагмент `T` в одно значение `Self::Output`, помещая между ними заданный разделитель.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Сглаживает фрагмент `T` в одно значение `Self::Output`, помещая между ними заданный разделитель.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Возвращает vector, содержащий копию этого фрагмента, где каждый байт сопоставлен с его эквивалентом в верхнем регистре ASCII.
    ///
    ///
    /// Буквы ASCII с 'a' по 'z' отображаются в 'A' в 'Z', но не-ASCII буквы не меняются.
    ///
    /// Чтобы прописать значение на месте, используйте [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Возвращает vector, содержащий копию этого фрагмента, где каждый байт сопоставлен с его эквивалентом в нижнем регистре ASCII.
    ///
    ///
    /// Буквы ASCII с 'A' по 'Z' отображаются в 'a' в 'z', но не-ASCII буквы не меняются.
    ///
    /// Чтобы ввести значение в нижнем регистре на месте, используйте [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Расширение traits для срезов определенных типов данных
////////////////////////////////////////////////////////////////////////////////

/// Помощник trait для [`[T]: : concat`](slice::concat).
///
/// Note: параметр типа `Item` не используется в этом trait, но он позволяет имплицитам быть более универсальными.
/// Без него мы получим такую ошибку:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Это связано с тем, что могут существовать типы `V` с несколькими имплементами `Borrow<[_]>`, так что будут применяться несколько типов `T`:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Результирующий тип после конкатенации
    type Output;

    /// Реализация [`[T]: : concat`](slice::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Помощник trait для [`[T]: : join`](slice::join)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Результирующий тип после конкатенации
    type Output;

    /// Реализация [`[T]: : join`](slice::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Стандартные реализации trait для срезов
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // бросьте в цель что-нибудь, что не будет перезаписано
        target.truncate(self.len());

        // target.len <= self.len из-за усечения выше, поэтому срезы здесь всегда находятся в границах.
        //
        let (init, tail) = self.split_at(target.len());

        // повторно использовать содержащиеся значения allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Вставляет `v[0]` в предварительно отсортированную последовательность `v[1..]`, так что весь `v[..]` становится отсортированным.
///
/// Это неотъемлемая подпрограмма сортировки вставкой.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Здесь есть три способа реализовать вставку:
            //
            // 1. Меняйте местами соседние элементы, пока первый не достигнет своего конечного пункта назначения.
            //    Однако таким образом мы копируем данные больше, чем необходимо.
            //    Если элементы представляют собой большие структуры (копирование дорогостоящее), этот метод будет медленным.
            //
            // 2. Итерируйте, пока не найдете нужное место для первого элемента.
            // Затем переместите следующие элементы, чтобы освободить место для него, и, наконец, поместите его в оставшееся отверстие.
            // Это хороший метод.
            //
            // 3. Скопируйте первый элемент во временную переменную.Итерируйте, пока не найдете нужное место.
            // По мере продвижения копируйте каждый пройденный элемент в предшествующий ему слот.
            // Наконец, скопируйте данные из временной переменной в оставшееся отверстие.
            // Этот метод очень хорош.
            // Тесты показали чуть лучшую производительность, чем при 2-м методе.
            //
            // Все методы были протестированы, и третий показал лучшие результаты.Итак, мы выбрали это.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Промежуточное состояние процесса вставки всегда отслеживается `hole`, что служит двум целям:
            // 1. Защищает целостность `v` от panics в `is_less`.
            // 2. В конце заполняет оставшуюся дыру в `v`.
            //
            // Panic безопасность:
            //
            // Если `is_less` panics в любой момент во время процесса, `hole` будет отброшен и заполнит дыру в `v` с помощью `tmp`, тем самым гарантируя, что `v` по-прежнему удерживает каждый объект, который он изначально удерживал, ровно один раз.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` сбрасывается и, таким образом, копирует `tmp` в оставшееся отверстие в `v`.
        }
    }

    // При сбросе копирует из `src` в `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Объединяет неубывающие прогоны `v[..mid]` и `v[mid..]`, используя `buf` в качестве временного хранилища, и сохраняет результат в `v[..]`.
///
/// # Safety
///
/// Два среза не должны быть пустыми, а `mid` должен находиться в границах.
/// Буфер `buf` должен быть достаточно длинным, чтобы вместить копию более короткого среза.
/// Кроме того, `T` не должен быть нулевым.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Процесс слияния сначала копирует более короткий прогон в `buf`.
    // Затем он отслеживает вновь скопированный прогон и более длинный прогон вперед (или назад), сравнивая их следующие неиспользованные элементы и копируя меньший (или больший) элемент в `v`.
    //
    // Как только более короткий цикл полностью израсходован, процесс завершен.Если в первую очередь расходуется более длинный цикл, то мы должны скопировать все, что осталось от более короткого цикла, в оставшееся отверстие в `v`.
    //
    // Промежуточное состояние процесса всегда отслеживается `hole`, который служит двум целям:
    // 1. Защищает целостность `v` от panics в `is_less`.
    // 2. Заполняет оставшуюся дыру в `v`, если сначала израсходуется более длительный пробег.
    //
    // Panic безопасность:
    //
    // Если `is_less` panics в любой момент во время процесса, `hole` будет отброшен и заполнит дыру в `v` неиспользованным диапазоном в `buf`, тем самым гарантируя, что `v` по-прежнему удерживает каждый объект, который он изначально удерживал ровно один раз.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Левый пробег короче.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Изначально эти указатели указывают на начало своих массивов.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Потребляйте меньшую сторону.
            // При равенстве, предпочитайте левый ход для сохранения устойчивости.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Правый пробег короче.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Первоначально эти указатели указывают на концы своих массивов.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Потребляйте большую сторону.
            // Если они равны, предпочитайте правильный ход для сохранения устойчивости.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Наконец, `hole` упал.
    // Если более короткий цикл не был полностью израсходован, все, что от него осталось, теперь будет скопировано в отверстие в `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // При сбросе копирует диапазон `start..end` в `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` не является типом нулевого размера, поэтому можно делить на его размер.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Эта сортировка слиянием заимствует некоторые (но не все) идеи из TimSort, который подробно описан [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Алгоритм определяет строго убывающие и неубывающие подпоследовательности, которые называются естественными последовательностями.Есть стопка ожидающих выполнения, которую еще предстоит объединить.
/// Каждый вновь найденный прогон помещается в стек, а затем несколько пар соседних прогонов объединяются до тех пор, пока эти два инварианта не будут удовлетворены:
///
/// 1. для каждого `i` в `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. для каждого `i` в `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Инварианты гарантируют, что общее время работы будет *O*(*n*\*log(* n*)) в худшем случае.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Срезы до этой длины сортируются с помощью сортировки вставкой.
    const MAX_INSERTION: usize = 20;
    // Очень короткие серии расширяются с помощью сортировки вставкой, чтобы охватить как минимум такое количество элементов.
    const MIN_RUN: usize = 10;

    // Сортировка не имеет значимого поведения для типов нулевого размера.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Короткие массивы сортируются на месте с помощью сортировки вставкой, чтобы избежать выделения.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Выделите буфер для использования в качестве оперативной памяти.Мы сохраняем длину 0, чтобы мы могли хранить в ней неглубокие копии содержимого `v`, не рискуя запускать dtors на копиях, если `is_less` panics.
    //
    // При объединении двух отсортированных прогонов этот буфер содержит копию более короткой серии, которая всегда будет иметь длину не более `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Чтобы определить естественные пробеги в `v`, мы пересекаем его в обратном направлении.
    // Это может показаться странным решением, но учтите тот факт, что слияния чаще всего идут в противоположном направлении (forwards).
    // Согласно тестам, слияние вперед происходит немного быстрее, чем слияние назад.
    // В заключение отметим, что определение прогонов обратным ходом улучшает производительность.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Найдите следующий естественный спуск и поверните его вспять, если он строго нисходящий.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Вставьте еще несколько элементов в бег, если он слишком короткий.
        // Сортировка вставкой выполняется быстрее, чем сортировка слиянием для коротких последовательностей, поэтому это значительно повышает производительность.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Поместите этот пробег в стек.
        runs.push(Run { start, len: end - start });
        end = start;

        // Объедините несколько пар смежных пробегов, чтобы удовлетворить инвариантам.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Наконец, в стеке должен остаться ровно один прогон.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Исследует стек прогонов и определяет следующую пару прогонов для слияния.
    // Более конкретно, если возвращается `Some(r)`, это означает, что `runs[r]` и `runs[r + 1]` должны быть объединены следующим образом.
    // Если вместо этого алгоритм должен продолжить построение нового прогона, возвращается `None`.
    //
    // TimSort печально известен своими ошибочными реализациями, как описано здесь:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Суть истории такова: мы должны обеспечить соблюдение инвариантов в четырех верхних прогонах стека.
    // Принуждения их только к трем первым недостаточно, чтобы гарантировать, что инварианты будут по-прежнему сохраняться для *всех* запусков в стеке.
    //
    // Эта функция правильно проверяет инварианты для четырех верхних прогонов.
    // Кроме того, если верхний прогон начинается с индекса 0, для завершения сортировки всегда будет требоваться операция слияния, пока стек не будет полностью свернут.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}