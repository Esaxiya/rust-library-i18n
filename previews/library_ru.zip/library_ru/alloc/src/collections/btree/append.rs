use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Добавляет все пары ключ-значение из объединения двух восходящих итераторов, увеличивая переменную `length` на этом пути.Последнее позволяет вызывающему абоненту избежать утечки при панике обработчика перетаскивания.
    ///
    /// Если оба итератора производят один и тот же ключ, этот метод удаляет пару из левого итератора и добавляет пару из правого итератора.
    ///
    /// Если вы хотите, чтобы дерево заканчивалось в строго возрастающем порядке, как для `BTreeMap`, оба итератора должны создавать ключи в строго возрастающем порядке, каждый из которых превышает все ключи в дереве, включая любые ключи, уже находящиеся в дереве при входе.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Мы готовимся объединить `left` и `right` в отсортированную последовательность за линейное время.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Тем временем мы строим дерево из отсортированной последовательности за линейное время.
        self.bulk_push(iter, length)
    }

    /// Помещает все пары ключ-значение в конец дерева, попутно увеличивая значение переменной `length`.
    /// Последнее позволяет вызывающей стороне избежать утечки при панике итератора.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Перебирайте все пары ключ-значение, помещая их в узлы на нужном уровне.
        for (key, value) in iter {
            // Попробуйте вставить пару ключ-значение в текущий листовой узел.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Нет места, поднимайтесь и толкайте туда.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Найден узел с оставшимся пространством, нажмите сюда.
                                open_node = parent;
                                break;
                            } else {
                                // Поднимись снова.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Мы наверху, создаем новый корневой узел и нажимаем туда.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Нажмите пару ключ-значение и новое правое поддерево.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Снова спуститесь к самому правому листу.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Увеличивайте длину на каждой итерации, чтобы карта удаляла добавленные элементы, даже если продвижение итератора паникует.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Итератор для объединения двух отсортированных последовательностей в одну
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Если два ключа равны, возвращает пару "ключ-значение" из правого источника.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}