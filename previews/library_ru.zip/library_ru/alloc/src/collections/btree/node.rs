// Это попытка реализации идеального
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Поскольку Rust на самом деле не имеет зависимых типов и полиморфной рекурсии, мы обходимся с большим количеством небезопасности.
//

// Основная цель этого модуля-избежать сложности, рассматривая дерево как общий (если он имеет странную форму) контейнер и избегая работы с большинством инвариантов B-дерева.
//
// Таким образом, этот модуль не заботится о том, отсортированы ли записи, какие узлы могут быть неполными или даже что означает неполное заполнение.Однако мы полагаемся на несколько инвариантов:
//
// - Деревья должны иметь единый depth/height.Это означает, что каждый путь вниз к листу от данного узла имеет одинаковую длину.
// - Узел длиной `n` имеет ключи `n`, значения `n` и ребра `n + 1`.
//   Это означает, что даже у пустого узла есть хотя бы один edge.
//   Для конечного узла "having an edge" означает только то, что мы можем идентифицировать позицию в узле, поскольку концевые ребра пусты и не нуждаются в представлении данных.
// Во внутреннем узле edge идентифицирует позицию и содержит указатель на дочерний узел.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Базовое представление листовых узлов и часть представления внутренних узлов.
struct LeafNode<K, V> {
    /// Мы хотим быть ковариантными в `K` и `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Индекс этого узла в массиве `edges` родительского узла.
    /// `*node.parent.edges[node.parent_idx]` должно быть то же самое, что и `node`.
    /// Инициализация гарантируется только тогда, когда `parent` не равно нулю.
    parent_idx: MaybeUninit<u16>,

    /// Количество ключей и значений, которые хранит этот узел.
    len: u16,

    /// Массивы, хранящие фактические данные узла.
    /// Инициализируются и действительны только первые элементы `len` каждого массива.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Инициализирует новый `LeafNode` на месте.
    unsafe fn init(this: *mut Self) {
        // Как правило, мы оставляем поля неинициализированными, если это возможно, так как это должно быть немного быстрее и легче отслеживается в Valgrind.
        //
        unsafe {
            // parent_idx, keys и vals-это MaybeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Создает новый `LeafNode` в штучной упаковке.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Базовое представление внутренних узлов.Как и в случае с `LeafNode`s, они должны быть скрыты за`BoxedNode`s, чтобы предотвратить удаление неинициализированных ключей и значений.
/// Любой указатель на `InternalNode` может быть напрямую преобразован в указатель на нижележащую часть `LeafNode` узла, что позволяет коду воздействовать на листовые и внутренние узлы в целом без необходимости даже проверять, на какой из двух указывает указатель.
///
/// Это свойство активируется при использовании `repr(C)`.
///
#[repr(C)]
// gdb_providers.py использует это имя типа для самоанализа.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Указатели на дочерние элементы этого узла.
    /// `len + 1` из них считаются инициализированными и действительными, за исключением того, что ближе к концу, когда дерево удерживается с помощью типа заимствования `Dying`, некоторые из этих указателей болтаются.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Создает новый `InternalNode` в штучной упаковке.
    ///
    /// # Safety
    /// Инвариант внутренних узлов заключается в том, что у них есть хотя бы один инициализированный и действительный edge.
    /// Эта функция не устанавливает такой edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Нам нужно только инициализировать данные;края-MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Управляемый ненулевой указатель на узел.Это либо принадлежащий указатель на `LeafNode<K, V>`, либо принадлежащий указатель на `InternalNode<K, V>`.
///
/// Однако `BoxedNode` не содержит информации о том, какой из двух типов узлов он фактически содержит, и, частично из-за этого недостатка информации, не является отдельным типом и не имеет деструктора.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Корневой узел собственного дерева.
///
/// Обратите внимание, что у него нет деструктора, и его нужно очищать вручную.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Возвращает новое собственное дерево с собственным корневым узлом, изначально пустым.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` не должно быть равно нулю.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Взаимно заимствует принадлежащий корневой узел.
    /// В отличие от `reborrow_mut`, это безопасно, потому что возвращаемое значение не может использоваться для уничтожения корня, и не может быть других ссылок на дерево.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Слегка взаимно заимствует принадлежащий корневой узел.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Необратимо переходит к ссылке, которая разрешает обход и предлагает деструктивные методы и многое другое.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Добавляет новый внутренний узел с единственным edge, указывающим на предыдущий корневой узел, делает этот новый узел корневым и возвращает его.
    /// Это увеличивает высоту на 1 и является противоположностью `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, за исключением того, что мы просто забыли, что теперь мы внутренние:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Удаляет внутренний корневой узел, используя его первого дочернего элемента в качестве нового корневого узла.
    /// Поскольку он предназначен для вызова только тогда, когда у корневого узла есть только один дочерний элемент, очистка не выполняется ни для одного из ключей, значений и других дочерних узлов.
    ///
    /// Это уменьшает высоту на 1 и является противоположностью `push_internal_level`.
    ///
    /// Требуется монопольный доступ к объекту `Root`, но не к корневому узлу;
    /// это не сделает недействительными другие дескрипторы или ссылки на корневой узел.
    ///
    /// Panics, если нет внутреннего уровня, т. Е. Если корневой узел является листом.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // БЕЗОПАСНОСТЬ: мы утверждали, что она внутренняя.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // БЕЗОПАСНОСТЬ: мы исключительно заимствовали `self`, и его тип заимствования является эксклюзивным.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // БЕЗОПАСНОСТЬ: всегда инициализируется первый edge.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` всегда ковариантен в `K` и `V`, даже если `BorrowType` равен `Mut`.
// Это технически неправильно, но не может привести к какой-либо небезопасности из-за внутреннего использования `NodeRef`, потому что мы остаемся полностью универсальными по сравнению с `K` и `V`.
//
// Однако всякий раз, когда публичный тип является оболочкой `NodeRef`, убедитесь, что он имеет правильную дисперсию.
//
/// Ссылка на узел.
///
/// Этот тип имеет ряд параметров, которые контролируют его действия:
/// - `BorrowType`: Фиктивный тип, описывающий вид заимствования и имеющий пожизненное значение.
///    - Когда это `Immut<'a>`, `NodeRef` действует примерно как `&'a Node`.
///    - Когда это `ValMut<'a>`, `NodeRef` действует примерно так же, как `&'a Node` в отношении ключей и древовидной структуры, но также позволяет сосуществовать многим изменяемым ссылкам на значения по всему дереву.
///    - Когда это `Mut<'a>`, `NodeRef` действует примерно как `&'a mut Node`, хотя методы вставки позволяют сосуществовать изменяемому указателю на значение.
///    - Когда это `Owned`, `NodeRef` действует примерно как `Box<Node>`, но не имеет деструктора и должен быть очищен вручную.
///    - Когда это `Dying`, `NodeRef` по-прежнему действует примерно так же, как `Box<Node>`, но имеет методы для побитового уничтожения дерева, а обычные методы, хотя и не помечены как небезопасные для вызова, могут вызывать UB при неправильном вызове.
///
///   Поскольку любой `NodeRef` позволяет перемещаться по дереву, `BorrowType` эффективно применяется ко всему дереву, а не только к самому узлу.
/// - `K` и `V`: это типы ключей и значений, хранящихся в узлах.
/// - `Type`: Это может быть `Leaf`, `Internal` или `LeafOrInternal`.
/// Когда это `Leaf`, `NodeRef` указывает на листовой узел, когда это `Internal`, `NodeRef` указывает на внутренний узел, а когда это `LeafOrInternal`, `NodeRef` может указывать на любой тип узла.
///   `Type` называется `NodeType` при использовании вне `NodeRef`.
///
/// И `BorrowType`, и `NodeType` ограничивают то, какие методы мы реализуем, чтобы использовать безопасность статического типа.Существуют ограничения в том, как мы можем применять такие ограничения:
/// - Для каждого параметра типа мы можем определить метод только в общем или для одного конкретного типа.
/// Например, мы не можем определить такой метод, как `into_kv`, в общем для всех `BorrowType` или один раз для всех типов, имеющих время жизни, потому что мы хотим, чтобы он возвращал ссылки `&'a`.
///   Поэтому мы определяем его только для наименее мощного типа `Immut<'a>`.
/// - Мы не можем получить неявное принуждение, скажем, от `Mut<'a>` к `Immut<'a>`.
///   Следовательно, мы должны явно вызвать `reborrow` на более мощном `NodeRef`, чтобы получить доступ к такому методу, как `into_kv`.
///
/// Все методы на `NodeRef`, которые возвращают какую-то ссылку, либо:
/// - Возьмите `self` по значению и верните время жизни, которое несет `BorrowType`.
///   Иногда, чтобы вызвать такой метод, нам нужно вызвать `reborrow_mut`.
/// - Возьмите `self` по ссылке, и (implicitly) вернет время жизни этой ссылки, а не время жизни, которое несет `BorrowType`.
/// Таким образом, программа проверки заимствований гарантирует, что `NodeRef` остается заимствованным, пока используется возвращенная ссылка.
///   Методы, поддерживающие вставку, изменяют это правило, возвращая необработанный указатель, то есть ссылку без какого-либо времени жизни.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Число уровней, на которые разделены узел и уровень листьев, константа узла, которая не может быть полностью описана `Type`, и которую сам узел не хранит.
    /// Нам нужно только сохранить высоту корневого узла и получить из него высоту всех остальных узлов.
    /// Должно быть нулевым, если `Type` равно `Leaf`, и ненулевым, если `Type` равно `Internal`.
    ///
    ///
    height: usize,
    /// Указатель на листовой или внутренний узел.
    /// Определение `InternalNode` гарантирует, что указатель действителен в любом случае.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Распакуйте ссылку на узел, которая была упакована как `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Предоставляет данные внутреннего узла.
    ///
    /// Возвращает необработанный ptr, чтобы избежать недействительности других ссылок на этот узел.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // БЕЗОПАСНОСТЬ: статический тип узла-`Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Заимствует монопольный доступ к данным внутреннего узла.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Находит длину узла.Это количество ключей или значений.
    /// Количество ребер-`len() + 1`.
    /// Обратите внимание, что, несмотря на безопасность, вызов этой функции может иметь побочный эффект в виде недействительности изменяемых ссылок, созданных небезопасным кодом.
    ///
    pub fn len(&self) -> usize {
        // Важно отметить, что здесь мы получаем доступ только к полю `len`.
        // Если BorrowType-marker::ValMut, могут существовать непостоянные изменяемые ссылки на значения, которые мы не должны аннулировать.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Возвращает количество уровней, на которых узел и выходы отделены друг от друга.
    /// Нулевая высота означает, что узел сам является листом.
    /// Если вы изобразите деревья с корнем наверху, число говорит, на какой высоте появляется узел.
    /// Если вы изобразите деревья с листьями наверху, число говорит о том, насколько высоко дерево простирается над узлом.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Временно удаляет другую неизменяемую ссылку на тот же узел.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Открывает листовую часть любого листового или внутреннего узла.
    ///
    /// Возвращает необработанный ptr, чтобы избежать недействительности других ссылок на этот узел.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Узел должен быть действительным по крайней мере для части LeafNode.
        // Это не ссылка в типе NodeRef, потому что мы не знаем, должна ли она быть уникальной или общей.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Находит родителя текущего узла.
    /// Возвращает `Ok(handle)`, если у текущего узла действительно есть родительский узел, где `handle` указывает на edge родительского узла, который указывает на текущий узел.
    ///
    /// Возвращает `Err(self)`, если текущий узел не имеет родителя, возвращая исходный `NodeRef`.
    ///
    /// Название метода предполагает, что вы изображаете деревья с корневым узлом наверху.
    ///
    /// `edge.descend().ascend().unwrap()` и `node.ascend().unwrap().descend()` должны оба в случае успеха ничего не делать.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Нам нужно использовать необработанные указатели на узлы, потому что, если BorrowType-marker::ValMut, могут существовать необработанные изменяемые ссылки на значения, которые мы не должны аннулировать.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Обратите внимание, что `self` не должен быть пустым.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Обратите внимание, что `self` не должен быть пустым.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Предоставляет листовую часть любого листового или внутреннего узла неизменяемого дерева.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // БЕЗОПАСНОСТЬ: в этом дереве, заимствованном как `Immut`, не может быть изменяемых ссылок.
        unsafe { &*ptr }
    }

    /// Заимствует представление о ключах, хранящихся в узле.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Подобно `ascend`, получает ссылку на родительский узел узла, но также освобождает текущий узел в процессе.
    /// Это небезопасно, потому что текущий узел все еще будет доступен, несмотря на то, что он освобожден.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Небезопасно сообщает компилятору статическую информацию о том, что этот узел является `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Небезопасно сообщает компилятору статическую информацию о том, что этот узел является `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Временно удаляет другую изменяемую ссылку на тот же узел.Остерегайтесь, так как этот метод очень опасен, вдвойне, поскольку он не может сразу показаться опасным.
    ///
    /// Поскольку изменяемые указатели могут перемещаться где угодно по дереву, возвращаемый указатель можно легко использовать, чтобы сделать исходный указатель висящим, выходящим за границы или недействительным в соответствии с правилами заимствования со стеком.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) рассмотрите возможность добавления еще одного параметра типа в `NodeRef`, который ограничивает использование методов навигации для повторно заимствованных указателей, предотвращая эту небезопасность.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Заимствует монопольный доступ к конечной части любого конечного или внутреннего узла.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // БЕЗОПАСНОСТЬ: у нас есть эксклюзивный доступ ко всему узлу.
        unsafe { &mut *ptr }
    }

    /// Предлагает эксклюзивный доступ к конечной части любого конечного или внутреннего узла.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // БЕЗОПАСНОСТЬ: у нас есть эксклюзивный доступ ко всему узлу.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Заимствует монопольный доступ к элементу области хранения ключей.
    ///
    /// # Safety
    /// `index` находится в пределах 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // БЕЗОПАСНОСТЬ: вызывающий не сможет вызывать дальнейшие методы на себе
        // пока ссылка на ключевой фрагмент не будет отброшена, поскольку у нас есть уникальный доступ на время жизни заимствования.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Заимствует монопольный доступ к элементу или фрагменту области хранения значений узла.
    ///
    /// # Safety
    /// `index` находится в пределах 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // БЕЗОПАСНОСТЬ: вызывающий не сможет вызывать дальнейшие методы на себе
        // пока ссылка на срез значения не будет отброшена, поскольку у нас есть уникальный доступ на время существования заимствования.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Заимствует монопольный доступ к элементу или части области хранения узла для содержимого edge.
    ///
    /// # Safety
    /// `index` находится в пределах 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // БЕЗОПАСНОСТЬ: вызывающий не сможет вызывать дальнейшие методы на себе
        // пока ссылка на срез edge не будет отброшена, поскольку у нас есть уникальный доступ на время жизни заимствования.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Узел содержит более `idx` инициализированных элементов.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Мы создаем ссылку только на один интересующий нас элемент, чтобы избежать наложения имен с невыполненными ссылками на другие элементы, в частности, те, которые были возвращены вызывающей стороне на более ранних итерациях.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Мы должны принудительно использовать указатели на массивы без размера из-за проблемы #74679 в Rust.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Заимствует монопольный доступ к длине узла.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Устанавливает ссылку узла на его родительский edge, не делая недействительными другие ссылки на узел.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Удаляет ссылку корня на его родительский edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Добавляет пару "ключ-значение" в конец узла.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Каждый элемент, возвращаемый `range`, является допустимым индексом edge для узла.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Добавляет пару ключ-значение и edge, чтобы перейти справа от этой пары, в конец узла.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Проверяет, является ли узел узлом `Internal` или узлом `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Ссылка на конкретную пару "ключ-значение" или edge в узле.
/// Параметр `Node` должен быть `NodeRef`, в то время как `Type` может быть либо `KV` (обозначающий дескриптор пары ключ-значение), либо `Edge` (обозначающий дескриптор edge).
///
/// Обратите внимание, что даже узлы `Leaf` могут иметь дескрипторы `Edge`.
/// Вместо того, чтобы представлять указатель на дочерний узел, они представляют собой пространства, в которых дочерние указатели будут располагаться между парами ключ-значение.
/// Например, в узле длиной 2 может быть 3 возможных местоположения edge: одно слева от узла, одно между двумя парами и одно справа от узла.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Нам не нужна полная универсальность `#[derive(Clone)]`, поскольку `Node` может быть `Clone` только когда это неизменяемая ссылка и, следовательно, `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Извлекает узел, содержащий edge или пару "ключ-значение", на которую указывает этот дескриптор.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Возвращает положение этого дескриптора в узле.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Создает новый дескриптор пары ключ-значение в `node`.
    /// Небезопасно, потому что вызывающий должен убедиться, что `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Может быть публичной реализацией PartialEq, но используется только в этом модуле.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Временно удаляет другой неизменяемый дескриптор в том же месте.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Мы не можем использовать Handle::new_kv или Handle::new_edge, потому что не знаем своего типа
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Небезопасно сообщает компилятору статическую информацию о том, что узел дескриптора является `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Временно извлекает другой изменяемый дескриптор в том же месте.
    /// Остерегайтесь, так как этот метод очень опасен, вдвойне, поскольку он не может сразу показаться опасным.
    ///
    ///
    /// Подробнее см. `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Мы не можем использовать Handle::new_kv или Handle::new_edge, потому что не знаем своего типа
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Создает новый дескриптор edge в `node`.
    /// Небезопасно, потому что вызывающий должен убедиться, что `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Учитывая индекс edge, в который мы хотим вставить узел, заполненный до предела, вычисляет разумный индекс KV точки разделения и место для выполнения вставки.
///
/// Цель точки разделения состоит в том, чтобы ее ключ и значение попали в родительский узел;
/// ключи, значения и края слева от точки разделения становятся левыми дочерними элементами;
/// ключи, значения и края справа от точки разделения становятся правыми дочерними элементами.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Проблема Rust #74834 пытается объяснить эти симметричные правила.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Вставляет новую пару "ключ-значение" между парами "ключ-значение" справа и слева от этого edge.
    /// Этот метод предполагает, что в узле достаточно места для размещения новой пары.
    ///
    /// Возвращенный указатель указывает на вставленное значение.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Вставляет новую пару "ключ-значение" между парами "ключ-значение" справа и слева от этого edge.
    /// Этот метод разбивает узел, если места недостаточно.
    ///
    /// Возвращенный указатель указывает на вставленное значение.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Исправляет родительский указатель и индекс в дочернем узле, на который ссылается этот edge.
    /// Это полезно, когда порядок ребер был изменен,
    fn correct_parent_link(self) {
        // Создайте обратный указатель, не делая недействительными другие ссылки на узел.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Вставляет новую пару "ключ-значение" и edge, который будет справа от этой новой пары между этим edge и парой "ключ-значение" справа от этого edge.
    /// Этот метод предполагает, что в узле достаточно места для размещения новой пары.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Вставляет новую пару "ключ-значение" и edge, который будет справа от этой новой пары между этим edge и парой "ключ-значение" справа от этого edge.
    /// Этот метод разбивает узел, если места недостаточно.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Вставляет новую пару "ключ-значение" между парами "ключ-значение" справа и слева от этого edge.
    /// Этот метод разбивает узел, если недостаточно места, и пытается рекурсивно вставить отделенную часть в родительский узел, пока не будет достигнут корень.
    ///
    ///
    /// Если возвращенный результат-`Fit`, узел его дескриптора может быть узлом edge или его предком.
    /// Если возвращенный результат-`Split`, поле `left` будет корневым узлом.
    /// Возвращенный указатель указывает на вставленное значение.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Находит узел, на который указывает этот edge.
    ///
    /// Название метода предполагает, что вы изображаете деревья с корневым узлом наверху.
    ///
    /// `edge.descend().ascend().unwrap()` и `node.ascend().unwrap().descend()` должны оба в случае успеха ничего не делать.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Нам нужно использовать необработанные указатели на узлы, потому что, если BorrowType-marker::ValMut, могут существовать необработанные изменяемые ссылки на значения, которые мы не должны аннулировать.
        // Не беспокойтесь о доступе к полю высоты, потому что это значение скопировано.
        // Помните, что после разыменования указателя узла мы обращаемся к массиву ребер со ссылкой (Rust issue #73987) и аннулируем любые другие ссылки на массив или внутри него, если они есть.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Мы не можем вызывать отдельные методы ключа и значения, потому что вызов второго делает недействительной ссылку, возвращаемую первым.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Замените ключ и значение, к которым относится дескриптор KV.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Помогает реализации `split` для конкретного `NodeType`, заботясь о конечных данных.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Разбивает базовый узел на три части:
    ///
    /// - Узел усечен, чтобы содержать только пары ключ-значение слева от этого дескриптора.
    /// - Ключ и значение, на которые указывает этот дескриптор, извлекаются.
    /// - Все пары "ключ-значение" справа от этого дескриптора помещаются во вновь выделенный узел.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Удаляет пару "ключ-значение", на которую указывает этот дескриптор, и возвращает ее вместе с edge, в которое свернута пара "ключ-значение".
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Разбивает базовый узел на три части:
    ///
    /// - Узел усечен, чтобы содержать только ребра и пары "ключ-значение" слева от этого дескриптора.
    /// - Ключ и значение, на которые указывает этот дескриптор, извлекаются.
    /// - Все ребра и пары "ключ-значение" справа от этого дескриптора помещаются в новый выделенный узел.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Представляет сеанс для оценки и выполнения операции балансировки вокруг внутренней пары "ключ-значение".
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Выбирает контекст балансировки, включающий узел как дочерний, то есть между KV непосредственно слева или справа в родительском узле.
    /// Возвращает `Err`, если родителя нет.
    /// Panics, если родительский элемент пуст.
    ///
    /// Предпочитает левую сторону, чтобы быть оптимальной, если данный узел каким-то образом неполон, имея в виду только то, что у него меньше элементов, чем у его левого брата и чем у его правого брата, если они существуют.
    /// В этом случае слияние с левым братом происходит быстрее, так как нам нужно только переместить N элементов узла, вместо того, чтобы сдвигать их вправо и перемещать более N элементов впереди.
    /// Воровство у левого брата также обычно происходит быстрее, поскольку нам нужно только сдвинуть N элементов узла вправо, вместо того, чтобы сдвигать по крайней мере N элементов родственного брата влево.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Возвращает, возможно ли слияние, т. Е. Достаточно ли места в узле для объединения центрального KV с обоими соседними дочерними узлами.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Выполняет слияние и позволяет замыканию решить, что вернуть.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // БЕЗОПАСНОСТЬ: высота объединяемых узлов на единицу ниже высоты
                // узла этого edge, таким образом, выше нуля, поэтому они внутренние.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Объединяет родительскую пару «ключ-значение» и оба соседних дочерних узла в левый дочерний узел и возвращает сжатый родительский узел.
    ///
    ///
    /// Panics, если только мы не `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Объединяет родительскую пару «ключ-значение» и оба соседних дочерних узла в левый дочерний узел и возвращает этот дочерний узел.
    ///
    ///
    /// Panics, если только мы не `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Объединяет родительскую пару ключ-значение и оба соседних дочерних узла в левый дочерний узел и возвращает дескриптор edge в том дочернем узле, где оказался отслеживаемый дочерний edge,
    ///
    ///
    /// Panics, если только мы не `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Удаляет пару "ключ-значение" из левого дочернего элемента и помещает ее в хранилище "ключ-значение" родительского элемента, одновременно проталкивая старую родительскую пару "ключ-значение" в правый дочерний элемент.
    ///
    /// Возвращает дескриптор edge в правом дочернем элементе, соответствующий тому, где закончился исходный edge, указанный `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Удаляет пару "ключ-значение" из правого дочернего элемента и помещает ее в хранилище "ключ-значение" родительского элемента, одновременно передавая старую родительскую пару "ключ-значение" левому дочернему элементу.
    ///
    /// Возвращает дескриптор edge в левом дочернем элементе, заданном `track_left_edge_idx`, который не перемещался.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Это кража похожа на `steal_left`, но крадет сразу несколько элементов.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Убедитесь, что мы можем безопасно украсть.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Переместите листовые данные.
            {
                // Освободите место для украденных элементов в правильном ребенке.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Переместите элементы из левого дочернего элемента в правый.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Переместите крайнюю левую украденную пару к родителю.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Переместите родительскую пару "ключ-значение" к правому дочернему элементу.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Освободите место для украденных краев.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Украсть края.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Симметричный клон `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Убедитесь, что мы можем безопасно украсть.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Переместите листовые данные.
            {
                // Переместите крайнюю правую украденную пару к родителю.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Переместите родительскую пару "ключ-значение" к левому дочернему элементу.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Переместите элементы из правого дочернего элемента в левый.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Заполните пробел там, где раньше были украденные элементы.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Украсть края.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Заполните зазор там, где раньше были украденные края.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Удаляет любую статическую информацию, утверждающую, что этот узел является узлом `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Удаляет любую статическую информацию, утверждающую, что этот узел является узлом `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Проверяет, является ли базовый узел узлом `Internal` или узлом `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Переместите суффикс после `self` с одного узла на другой.`right` должен быть пустым.
    /// Первый edge `right` остался без изменений.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Результат вставки, когда узел должен был выйти за пределы своей емкости.
pub struct SplitResult<'a, K, V, NodeType> {
    // Измененный узел в существующем дереве с элементами и ребрами, которые принадлежат слева от `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Некоторые ключ и значение отделяются, чтобы их можно было вставить в другое место.
    pub kv: (K, V),
    // Собственный, неподключенный, новый узел с элементами и ребрами, которые принадлежат справа от `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Позволяют ли ссылки на узлы этого типа заимствования переходить к другим узлам в дереве.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Обход не нужен, он происходит с использованием результата `borrow_mut`.
        // Отключив обход и создав новые ссылки только на корни, мы знаем, что каждая ссылка типа `Owned` относится к корневому узлу.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Вставляет значение в фрагмент инициализированных элементов, за которым следует один неинициализированный элемент.
///
/// # Safety
/// Срез содержит более `idx` элементов.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Удаляет и возвращает значение из среза всех инициализированных элементов, оставляя один конечный неинициализированный элемент.
///
///
/// # Safety
/// Срез содержит более `idx` элементов.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Сдвигает элементы в срезе на позиции `distance` влево.
///
/// # Safety
/// Срез содержит не менее `distance` элементов.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Сдвигает элементы в срезе на позиции `distance` вправо.
///
/// # Safety
/// Срез содержит не менее `distance` элементов.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Перемещает все значения из сегмента инициализированных элементов в сегмент неинициализированных элементов, оставляя `src` как все неинициализированные.
///
/// Работает как `dst.copy_from_slice(src)`, но не требует, чтобы `T` был `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;