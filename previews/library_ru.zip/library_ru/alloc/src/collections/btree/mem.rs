use core::intrinsics;
use core::mem;
use core::ptr;

/// Это заменяет значение уникальной ссылки `v` путем вызова соответствующей функции.
///
///
/// Если panic происходит при закрытии `change`, весь процесс будет прерван.
#[allow(dead_code)] // сохраните как иллюстрацию и для использования future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Это заменяет значение за уникальной ссылкой `v`, вызывая соответствующую функцию, и возвращает результат, полученный в процессе.
///
///
/// Если panic происходит при закрытии `change`, весь процесс будет прерван.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}