#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Содержимое новой памяти не инициализировано.
    Uninitialized,
    /// Обнуление новой памяти гарантировано.
    Zeroed,
}

/// Утилита низкого уровня для более эргономичного распределения, перераспределения и освобождения буфера памяти в куче, не беспокоясь о всех вовлеченных угловых случаях.
///
/// Этот тип отлично подходит для создания ваших собственных структур данных, таких как Vec и VecDeque.
/// В частности:
///
/// * Производит `Unique::dangling()` на типах нулевого размера.
/// * Производит `Unique::dangling()` на выделениях нулевой длины.
/// * Избегает освобождения `Unique::dangling()`.
/// * Улавливает все переполнения при вычислениях емкости (повышает их до "capacity overflow" panics).
/// * Защищает от 32-битных систем, выделяющих более isize::MAX байт.
/// * Защищает от выхода за пределы вашей длины.
/// * Вызывает `handle_alloc_error` для ошибочного распределения.
/// * Содержит `ptr::Unique` и, таким образом, дает пользователю все связанные с этим преимущества.
/// * Использует излишек, возвращенный распределителем, для использования наибольшей доступной емкости.
///
/// Этот тип никоим образом не проверяет память, которой он управляет.При падении он *освобождает* свою память, но *не* пытается * сбросить свое содержимое.
/// Пользователь `RawVec` должен обрабатывать фактические вещи,*хранящиеся* внутри `RawVec`.
///
/// Обратите внимание, что избыток типов нулевого размера всегда бесконечен, поэтому `capacity()` всегда возвращает `usize::MAX`.
/// Это означает, что вам нужно быть осторожным при переключении этого типа с `Box<[T]>`, поскольку `capacity()` не даст длины.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Это существует потому, что `#[unstable]` `const fn`s не обязательно должны соответствовать `min_const_fn`, и поэтому они также не могут быть вызваны в`min_const_fn`s.
    ///
    /// Если вы измените `RawVec<T>::new` или зависимости, пожалуйста, будьте осторожны, чтобы не вводить ничего, что действительно нарушало бы `min_const_fn`.
    ///
    /// NOTE: Мы могли бы избежать этого взлома и проверить соответствие некоторому атрибуту `#[rustc_force_min_const_fn]`, который требует соответствия `min_const_fn`, но не обязательно позволяет вызывать его в коде `stable(...) const fn`/пользователя, не активируя `foo` при наличии `#[rustc_const_unstable(feature = "foo", issue = "01234")]`.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Создает максимально возможный `RawVec` (в системной куче) без выделения.
    /// Если `T` имеет положительный размер, то получается `RawVec` с емкостью `0`.
    /// Если `T` имеет нулевой размер, то получается `RawVec` с емкостью `usize::MAX`.
    /// Полезно для реализации отложенного выделения.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Создает `RawVec` (в системной куче) с точно такой же емкостью и требованиями к выравниванию, как `[T; capacity]`.
    /// Это эквивалентно вызову `RawVec::new`, когда `capacity` равен `0` или `T` имеет нулевой размер.
    /// Обратите внимание, что если `T` имеет нулевой размер, это означает, что вы *не* получите `RawVec` с запрошенной емкостью.
    ///
    /// # Panics
    ///
    /// Panics, если запрошенная емкость превышает `isize::MAX` байт.
    ///
    /// # Aborts
    ///
    /// Прерывание при OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Как `with_capacity`, но гарантирует, что буфер обнулен.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Восстанавливает `RawVec` по указателю и емкости.
    ///
    /// # Safety
    ///
    /// `ptr` должен быть выделен (в системной куче) и с заданным `capacity`.
    /// `capacity` не может превышать `isize::MAX` для типоразмеров.(проблема только в 32-битных системах).
    /// ZST vectors может иметь емкость до `usize::MAX`.
    /// Если `ptr` и `capacity` поступают от `RawVec`, то это гарантировано.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Крошечные Веки глупы.Пропустить:
    // - 8, если размер элемента равен 1, потому что любые распределители кучи могут округлить запрос размером менее 8 байтов как минимум до 8 байтов.
    //
    // - 4, если элементы среднего размера (<=1 КБ).
    // - 1 в противном случае, чтобы не тратить слишком много места для очень коротких Vecs.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Подобно `new`, но параметризовано выбором распределителя для возвращаемого `RawVec`.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` означает "unallocated".типы нулевого размера игнорируются.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Подобно `with_capacity`, но параметризовано выбором распределителя для возвращаемого `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Подобно `with_capacity_zeroed`, но параметризовано выбором распределителя для возвращаемого `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Преобразует `Box<[T]>` в `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Преобразует весь буфер в `Box<[MaybeUninit<T>]>` с указанным `len`.
    ///
    /// Обратите внимание, что при этом будут правильно воссозданы все изменения `cap`, которые могли быть выполнены.(Подробности см. В описании типа.)
    ///
    /// # Safety
    ///
    /// * `len` должен быть больше или равен последней запрошенной емкости, и
    /// * `len` должно быть меньше или равно `self.capacity()`.
    ///
    /// Обратите внимание, что запрошенная емкость и `self.capacity()` могут отличаться, поскольку распределитель может перераспределить ресурсы и вернуть больший блок памяти, чем запрошенный.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Вменяемость-проверьте одну половину требования безопасности (мы не можем проверить вторую половину).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Здесь мы избегаем `unwrap_or_else`, потому что он увеличивает количество генерируемых LLVM IR.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Восстанавливает `RawVec` из указателя, емкости и распределителя.
    ///
    /// # Safety
    ///
    /// `ptr` должен быть выделен (через данный распределитель `alloc`) и с данным `capacity`.
    /// `capacity` не может превышать `isize::MAX` для типоразмеров.
    /// (проблема только в 32-битных системах).
    /// ZST vectors может иметь емкость до `usize::MAX`.
    /// Если `ptr` и `capacity` поступают из `RawVec`, созданного через `alloc`, то это гарантировано.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Получает необработанный указатель на начало выделения.
    /// Обратите внимание, что это `Unique::dangling()`, если `capacity == 0` или `T` нулевого размера.
    /// В первом случае нужно быть осторожным.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Получает емкость выделения.
    ///
    /// Это всегда будет `usize::MAX`, если `T` имеет нулевой размер.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Возвращает общую ссылку на распределитель, поддерживающий этот `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // У нас есть выделенный кусок памяти, поэтому мы можем обойти проверки времени выполнения, чтобы получить текущий макет.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Гарантирует, что буфер содержит как минимум достаточно места для хранения элементов `len + additional`.
    /// Если у него еще недостаточно емкости, будет перераспределено достаточно места плюс удобное свободное пространство для амортизации поведения *O*(1).
    ///
    /// Ограничит это поведение, если оно без нужды вызовет panic.
    ///
    /// Если `len` превышает `self.capacity()`, это может фактически не выделить запрошенное пространство.
    /// Это на самом деле небезопасно, но небезопасный код, который вы * пишете, который зависит от поведения этой функции, может сломаться.
    ///
    /// Это идеально подходит для реализации операции массовой отправки, такой как `extend`.
    ///
    /// # Panics
    ///
    /// Panics, если новая емкость превышает `isize::MAX` байт.
    ///
    /// # Aborts
    ///
    /// Прерывание при OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // Резервное копирование было бы прервано или запаниковало бы, если бы len превысило `isize::MAX`, поэтому сейчас это можно сделать без проверки.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// То же, что и `reserve`, но возвращает ошибку вместо паники или прерывания.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Гарантирует, что буфер содержит как минимум достаточно места для хранения элементов `len + additional`.
    /// Если этого еще не произошло, будет перераспределен минимально возможный объем необходимой памяти.
    /// Обычно это именно то количество памяти, которое необходимо, но в принципе распределитель может вернуть больше, чем мы просили.
    ///
    ///
    /// Если `len` превышает `self.capacity()`, это может фактически не выделить запрошенное пространство.
    /// Это на самом деле небезопасно, но небезопасный код, который вы * пишете, который зависит от поведения этой функции, может сломаться.
    ///
    /// # Panics
    ///
    /// Panics, если новая емкость превышает `isize::MAX` байт.
    ///
    /// # Aborts
    ///
    /// Прерывание при OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// То же, что и `reserve_exact`, но возвращает ошибку вместо паники или прерывания.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Уменьшает выделение до указанной суммы.
    /// Если заданная сумма равна 0, фактически полностью освобождается.
    ///
    /// # Panics
    ///
    /// Panics, если указанная сумма *больше*, чем текущая емкость.
    ///
    /// # Aborts
    ///
    /// Прерывание при OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Возвращает, если буфер должен увеличиться для заполнения необходимой дополнительной емкости.
    /// В основном используется для того, чтобы сделать возможными встраиваемые резервные вызовы без встраивания `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Этот метод обычно создается много раз.Поэтому мы хотим, чтобы он был как можно меньше, чтобы сократить время компиляции.
    // Но мы также хотим, чтобы как можно больше его содержимого было статически вычислимым, чтобы сгенерированный код работал быстрее.
    // Следовательно, этот метод тщательно написан так, чтобы весь код, зависящий от `T`, находился внутри него, в то время как как можно больше кода, который не зависит от `T`, находится в функциях, которые не являются универсальными по сравнению с `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Это обеспечивается контекстами вызова.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Поскольку мы возвращаем емкость `usize::MAX`, когда `elem_size`
            // 0, попадание сюда обязательно означает, что `RawVec` переполнен.
            return Err(CapacityOverflow);
        }

        // К сожалению, мы ничего не можем поделать с этими проверками.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Это гарантирует экспоненциальный рост.
        // Удвоение не может переполниться, потому что `cap <= isize::MAX` и тип `cap`-`usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` не является универсальным по сравнению с `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Ограничения для этого метода во многом такие же, как и для `grow_amortized`, но этот метод обычно создается реже, поэтому он менее критичен.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Поскольку мы возвращаем емкость `usize::MAX`, когда размер шрифта равен
            // 0, попадание сюда обязательно означает, что `RawVec` переполнен.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` не является универсальным по сравнению с `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Эта функция находится за пределами `RawVec`, чтобы минимизировать время компиляции.См. Комментарий выше `RawVec::grow_amortized` для подробностей.
// (Параметр `A` не имеет значения, поскольку количество различных типов `A`, наблюдаемых на практике, намного меньше, чем количество типов `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Проверьте наличие ошибки здесь, чтобы минимизировать размер `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Распределитель проверяет равенство выравнивания
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Освобождает память, принадлежащую `RawVec`*, без попытки* сбросить ее содержимое.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Центральная функция для обработки резервных ошибок.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Нам необходимо гарантировать следующее:
// * Мы никогда не выделяем объекты размером `> isize::MAX` в байтах.
// * Мы не переполняем `usize::MAX` и фактически выделяем слишком мало.
//
// В 64-битной версии нам просто нужно проверить переполнение, поскольку попытка выделить байты `> isize::MAX` наверняка не удастся.
// На 32-битных и 16-битных нам нужно добавить дополнительную защиту на случай, если мы работаем на платформе, которая может использовать все 4 ГБ в пользовательском пространстве, например, PAE или x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Одна центральная функция, отвечающая за сообщение о переполнении мощностей.
// Это гарантирует, что генерация кода, связанного с этими panics, будет минимальной, поскольку есть только одно местоположение, которое panics, а не группа по всему модулю.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}