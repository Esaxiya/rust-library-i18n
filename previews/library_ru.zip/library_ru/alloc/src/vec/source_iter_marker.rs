use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Маркер специализации для сбора конвейера итератора в Vec при повторном использовании выделения источника, т. Е.
/// выполнение конвейера на месте.
///
/// Родитель SourceIter trait необходим для специализированной функции для доступа к распределению, которое будет использоваться повторно.
/// Но этого недостаточно, чтобы специализация была действительной.
/// См. Дополнительные ограничения на имп.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-внутренний SourceIter/InPlaceIterable traits реализуется только цепочками адаптера <Adapter<Adapter<IntoIter>>> (все принадлежит core/std).
// Дополнительные ограничения для реализаций адаптера (помимо `impl<I: Trait> Trait for Adapter<I>`) зависят только от других traits, уже отмеченных как специализация traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. маркер не зависит от времени жизни пользовательских типов.По модулю дыры копирования, от которой уже зависят несколько других специализаций.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Дополнительные требования, которые нельзя выразить через trait bounds.Вместо этого мы полагаемся на const eval:
        // a) нет ZST, поскольку не будет выделения для повторного использования, а арифметика указателя будет panic b) размер соответствует требованиям контракта Alloc c) выравнивания соответствуют требованиям контракта Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // возврат к более общим реализациям
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // используйте try-fold, так как
        // - он векторизуется лучше для некоторых адаптеров итераторов
        // - в отличие от большинства методов внутренней итерации, требуется только сам &mut.
        // - он позволяет нам пропустить указатель записи через его внутренности и вернуть его в конце
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // итерация прошла успешно, не роняйте голову
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // проверьте, был ли соблюден контракт SourceIter, оговорка: если бы они не были выполнены, мы можем даже не дойти до этого момента
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // проверьте контракт InPlaceIterable.Это возможно только в том случае, если итератор вообще продвинул указатель источника.
        // Если он использует неконтролируемый доступ через TrustedRandomAccess, тогда указатель источника останется в исходной позиции, и мы не сможем использовать его в качестве ссылки.
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // отбросить все оставшиеся значения в конце источника, но предотвратить сброс самого выделения, как только IntoIter выходит за пределы области действия, если drop panics, тогда мы также пропускаем любые элементы, собранные в dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // контракт InPlaceIterable не может быть точно проверен здесь, поскольку try_fold имеет исключительную ссылку на указатель источника, все, что мы можем сделать, это проверить, находится ли он по-прежнему в диапазоне
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}