use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Специализация trait используется для Vec::from_iter
///
/// ## График делегирования:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Обычный случай-передача vector в функцию, которая немедленно повторно собирает в vector.
        // Мы можем замкнуть это, если IntoIter вообще не был продвинут.
        // Когда он будет расширен, мы также можем повторно использовать память и переместить данные на передний план.
        // Но мы делаем это только тогда, когда у результирующего Vec не будет больше неиспользуемой емкости, чем было бы при ее создании с помощью общей реализации FromIterator.
        //
        // Это ограничение не является строго необходимым, поскольку поведение распределения Vec намеренно не указано.
        // Но это консервативный выбор.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // должен делегировать spec_extend(), поскольку extend() сам делегирует spec_from для пустых Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Это использует `iterator.as_slice().to_vec()`, поскольку spec_extend должен предпринять больше шагов, чтобы определить окончательную емкость + длину и, таким образом, выполнить больше работы.
// `to_vec()` напрямую выделяет нужную сумму и точно ее заполняет.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): с cfg(test) неотъемлемый метод `[T]::to_vec`, который требуется для этого определения метода, недоступен.
    // Вместо этого используйте функцию `slice::to_vec`, которая доступна только с cfg(test) NB, см. Модуль slice::hack в slice.rs для получения дополнительной информации
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}