//! ไลบรารีสนับสนุนสำหรับผู้เขียนแมโครเมื่อกำหนดมาโครใหม่
//!
//! ไลบรารีนี้จัดเตรียมโดยการแจกแจงมาตรฐานจัดเตรียมประเภทที่ใช้ในอินเทอร์เฟซของนิยามมาโครที่กำหนดตามขั้นตอนเช่นมาโครที่เหมือนฟังก์ชัน `#[proc_macro]` มาโครแอตทริบิวต์ `#[proc_macro_attribute]` และแอตทริบิวต์ที่ได้มาที่กำหนดเอง "#[proc_macro_derive]
//!
//!
//! ดู [the book] สำหรับข้อมูลเพิ่มเติม
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// กำหนดว่า proc_macro สามารถเข้าถึงโปรแกรมที่กำลังทำงานอยู่หรือไม่
///
/// proc_macro crate มีไว้สำหรับใช้ภายในการใช้งานมาโครขั้นตอนเท่านั้นฟังก์ชันทั้งหมดใน crate panic นี้หากเรียกใช้จากภายนอกมาโครขั้นตอนเช่นจากบิลด์สคริปต์หรือการทดสอบหน่วยหรือไบนารี Rust ธรรมดา
///
/// ด้วยการพิจารณาสำหรับไลบรารี Rust ที่ออกแบบมาเพื่อรองรับทั้งกรณีการใช้งานมาโครและที่ไม่ใช่มาโคร `proc_macro::is_available()` จึงมีวิธีที่ไม่ต้องตื่นตระหนกในการตรวจสอบว่าโครงสร้างพื้นฐานที่จำเป็นในการใช้ API ของ proc_macro นั้นพร้อมใช้งานหรือไม่
/// ส่งคืนค่าจริงหากเรียกจากภายในแมโครขั้นตอนเท็จหากเรียกจากไบนารีอื่น ๆ
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// ประเภทหลักที่จัดทำโดย crate นี้แสดงถึงกระแสนามธรรมของ tokens หรือโดยเฉพาะอย่างยิ่งลำดับของต้นไม้ token
/// ประเภทมีอินเทอร์เฟซสำหรับการวนซ้ำบนต้นไม้ token เหล่านั้นและในทางกลับกันการรวบรวมต้นไม้ token จำนวนหนึ่งไว้ในสตรีมเดียว
///
///
/// นี่คือทั้งอินพุตและเอาต์พุตของนิยาม `#[proc_macro]`, `#[proc_macro_attribute]` และ `#[proc_macro_derive]`
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// ข้อผิดพลาดกลับมาจาก `TokenStream::from_str`
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// ส่งคืน `TokenStream` ว่างเปล่าที่ไม่มีทรี token
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// ตรวจสอบว่า `TokenStream` นี้ว่างหรือไม่
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// พยายามแยกสตริงออกเป็น tokens และแยกวิเคราะห์ tokens เหล่านั้นเป็นสตรีม token
/// อาจล้มเหลวด้วยสาเหตุหลายประการตัวอย่างเช่นหากสตริงมีตัวคั่นที่ไม่สมดุลหรืออักขระที่ไม่มีอยู่ในภาษา
///
/// tokens ทั้งหมดในสตรีมที่แยกวิเคราะห์จะได้รับช่วง `Span::call_site()`
///
/// NOTE: ข้อผิดพลาดบางอย่างอาจทำให้ panics แทนที่จะส่งคืน `LexError` เราขอสงวนสิทธิ์ในการเปลี่ยนแปลงข้อผิดพลาดเหล่านี้เป็น "LexError" ในภายหลัง
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB สะพานให้เฉพาะ `to_string` ใช้ `fmt::Display` ตามนั้น (การย้อนกลับของความสัมพันธ์ตามปกติระหว่างทั้งสอง)
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// พิมพ์สตรีม token เป็นสตริงที่ควรแปลงแบบสูญเสียกลับไปเป็นสตรีม token เดียวกัน (ช่วงโมดูโล) ยกเว้น "TokenTree: : Group" ที่มีตัวคั่น `Delimiter::None` และตัวอักษรตัวเลขเชิงลบ
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// พิมพ์ token ในรูปแบบที่สะดวกสำหรับการดีบัก
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// สร้างสตรีม token ที่มีทรี token เดียว
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// รวบรวมต้นไม้ token จำนวนหนึ่งไว้ในสตรีมเดียว
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// การดำเนินการ "flattening" บนสตรีม token รวบรวมทรี token จากสตรีม token หลายสตรีมเป็นสตรีมเดียว
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) ใช้ if/when การใช้งานที่เหมาะสมที่สุดเท่าที่จะเป็นไปได้
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// รายละเอียดการใช้งานสาธารณะสำหรับประเภท `TokenStream` เช่นตัวทำซ้ำ
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// ตัววนซ้ำบน TokenTree ของ `TokenStream`
    /// การวนซ้ำคือ "shallow" เช่นตัววนซ้ำจะไม่บันทึกซ้ำในกลุ่มที่คั่นและส่งคืนทั้งกลุ่มเป็นทรี token
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` ยอมรับ tokens โดยพลการและขยายเป็น `TokenStream` ที่อธิบายอินพุต
/// ตัวอย่างเช่น `quote!(a + b)` จะสร้างนิพจน์ที่เมื่อประเมินแล้วจะสร้าง `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// การยกเลิกการอ้างสิทธิ์ทำได้ด้วย `$` และทำงานโดยใช้ตัวระบุเดียวถัดไปเป็นคำที่ไม่ได้ใส่เครื่องหมาย
/// หากต้องการอ้างอิง `$` ให้ใช้ `$$`
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// ขอบเขตของซอร์สโค้ดพร้อมกับข้อมูลการขยายมาโคร
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// สร้าง `Diagnostic` ใหม่ด้วย `message` ที่กำหนดที่ช่วง `self`
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// ช่วงที่แก้ไขที่ไซต์ข้อกำหนดแมโคร
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// ช่วงของการเรียกใช้แมโครขั้นตอนปัจจุบัน
    /// ตัวระบุที่สร้างด้วยช่วงนี้จะได้รับการแก้ไขราวกับว่ามีการเขียนโดยตรงที่ตำแหน่งการเรียกมาโคร (สุขอนามัยของไซต์การโทร) และรหัสอื่น ๆ ที่ไซต์การเรียกมาโครจะสามารถอ้างถึงได้เช่นกัน
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// ช่วงที่แสดงถึงสุขอนามัย `macro_rules` และบางครั้งแก้ไขได้ที่ไซต์ข้อกำหนดมาโคร (ตัวแปรโลคัลป้ายกำกับ `$crate`) และบางครั้งที่ไซต์การเรียกมาโคร (อย่างอื่น)
    ///
    /// ตำแหน่งสแปนนำมาจากไซต์การโทร
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// ไฟล์ต้นฉบับต้นฉบับที่ช่วงนี้ชี้ไป
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` สำหรับ tokens ในการขยายมาโครก่อนหน้าซึ่ง `self` ถูกสร้างขึ้นจากถ้ามี
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// สแปนสำหรับซอร์สโค้ดต้นทางที่ `self` ถูกสร้างขึ้น
    /// หาก `Span` นี้ไม่ได้สร้างขึ้นจากการขยายมาโครอื่น ๆ ค่าที่ส่งคืนจะเหมือนกับ `*self`
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// รับ line/column เริ่มต้นในซอร์สไฟล์สำหรับช่วงนี้
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// รับ line/column ที่สิ้นสุดในซอร์สไฟล์สำหรับช่วงนี้
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// สร้างช่วงใหม่ที่ครอบคลุม `self` และ `other`
    ///
    /// ส่งคืน `None` หาก `self` และ `other` มาจากไฟล์อื่น
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// สร้างช่วงใหม่ด้วยข้อมูล line/column เดียวกันกับ `self` แต่จะแก้ไขสัญลักษณ์เหมือนกับที่ `other`
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// สร้างช่วงใหม่ที่มีลักษณะการแก้ปัญหาชื่อเดียวกับ `self` แต่มีข้อมูล line/column ของ `other`
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// เปรียบเทียบระยะห่างเพื่อดูว่าเท่ากันหรือไม่
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// ส่งคืนข้อความต้นฉบับหลังช่วง
    /// ซึ่งจะเก็บรักษาซอร์สโค้ดเดิมรวมถึงช่องว่างและความคิดเห็น
    /// จะส่งคืนผลลัพธ์ก็ต่อเมื่อสแปนตรงกับซอร์สโค้ดจริง
    ///
    /// Note: ผลลัพธ์ที่สังเกตได้ของมาโครควรอาศัย tokens เท่านั้นไม่ใช่ในข้อความต้นฉบับนี้
    ///
    /// ผลลัพธ์ของฟังก์ชั่นนี้เป็นความพยายามอย่างดีที่สุดที่จะใช้สำหรับการวินิจฉัยเท่านั้น
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// พิมพ์ช่วงในรูปแบบที่สะดวกสำหรับการดีบัก
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// คู่บรรทัด-คอลัมน์ที่แสดงจุดเริ่มต้นหรือจุดสิ้นสุดของ `Span`
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// บรรทัดที่จัดทำดัชนี 1 รายการในไฟล์ต้นฉบับที่ช่วงเริ่มต้นหรือสิ้นสุด (inclusive)
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// คอลัมน์ 0 ดัชนี (ในอักขระ UTF-8) ในไฟล์ต้นฉบับที่ช่วงเริ่มต้นหรือสิ้นสุด (inclusive)
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// ไฟล์ต้นฉบับของ `Span` ที่ระบุ
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// รับเส้นทางไปยังไฟล์ต้นฉบับนี้
    ///
    /// ### Note
    /// หากช่วงรหัสที่เชื่อมโยงกับ `SourceFile` นี้สร้างขึ้นโดยมาโครภายนอกมาโครนี้อาจไม่ใช่เส้นทางจริงบนระบบไฟล์
    /// ใช้ [`is_real`] เพื่อตรวจสอบ
    ///
    /// โปรดทราบว่าแม้ว่า `is_real` จะส่งคืน `true` แต่ถ้า `--remap-path-prefix` ถูกส่งผ่านในบรรทัดคำสั่งเส้นทางตามที่ระบุอาจไม่ถูกต้อง
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// ส่งคืน `true` หากไฟล์ต้นฉบับนี้เป็นไฟล์ต้นฉบับจริงและไม่ได้สร้างขึ้นโดยการขยายของมาโครภายนอก
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // นี่คือการแฮ็กจนกว่าจะมีการใช้งานช่วงเวลาระหว่างกันและเราสามารถมีไฟล์ต้นฉบับจริงสำหรับช่วงที่สร้างในมาโครภายนอก
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// token เดี่ยวหรือลำดับที่คั่นด้วยต้นไม้ token (เช่น `[1, (), ..]`)
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// สตรีม token ที่ล้อมรอบด้วยตัวคั่นวงเล็บ
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// ตัวระบุ
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// อักขระเครื่องหมายวรรคตอนเดียว (`+`, `,`, `$` ฯลฯ)
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// อักขระตามตัวอักษร (`'a'`) สตริง (`"hello"`) หมายเลข (`2.3`) เป็นต้น
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// ส่งคืนค่าช่วงของโครงสร้างนี้โดยมอบหมายให้เป็นวิธี `span` ของ token ที่มีอยู่หรือสตรีมที่คั่น
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// กำหนดค่าช่วงสำหรับ *เฉพาะ token* นี้
    ///
    /// โปรดทราบว่าหาก token นี้เป็น `Group` วิธีนี้จะไม่กำหนดค่าช่วงของ tokens ภายในแต่ละตัวสิ่งนี้จะมอบสิทธิ์ให้กับวิธี `set_span` ของแต่ละตัวแปร
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// พิมพ์ทรี token ในรูปแบบที่สะดวกสำหรับการดีบัก
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // แต่ละตัวมีชื่อในประเภท struct ในการดีบักที่ได้รับดังนั้นอย่ากังวลกับเลเยอร์พิเศษของ indirection
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB สะพานให้เฉพาะ `to_string` ใช้ `fmt::Display` ตามนั้น (การย้อนกลับของความสัมพันธ์ตามปกติระหว่างทั้งสอง)
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// พิมพ์ทรี token เป็นสตริงที่ควรจะแปลงแบบไม่สูญเสียกลับไปเป็นทรี token เดียวกัน (ช่วงโมดูโล) ยกเว้นอาจเป็น "TokenTree: : Group" ที่มีตัวคั่น `Delimiter::None` และตัวอักษรตัวเลขเชิงลบ
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// สตรีม token แบบคั่น
///
/// `Group` ภายในประกอบด้วย `TokenStream` ซึ่งล้อมรอบด้วย "ตัวคั่น"
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// อธิบายวิธีการคั่นลำดับของต้นไม้ token
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// ตัวคั่นโดยปริยายตัวอย่างเช่นอาจปรากฏรอบ ๆ tokens ที่มาจาก "macro variable" `$var`
    /// สิ่งสำคัญคือต้องรักษาลำดับความสำคัญของตัวดำเนินการไว้ในกรณีเช่น `$var * 3` โดยที่ `$var` คือ `1 + 2`
    /// ตัวคั่นโดยปริยายอาจไม่อยู่รอดไปกลับของสตรีม token ผ่านสตริง
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// สร้าง `Group` ใหม่ด้วยตัวคั่นที่กำหนดและสตรีม token
    ///
    /// ตัวสร้างนี้จะตั้งค่าช่วงสำหรับกลุ่มนี้เป็น `Span::call_site()`
    /// ในการเปลี่ยนช่วงคุณสามารถใช้วิธี `set_span` ด้านล่าง
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// ส่งกลับตัวคั่นของ `Group` นี้
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// ส่งคืน `TokenStream` ของ tokens ที่คั่นใน `Group` นี้
    ///
    /// โปรดทราบว่าสตรีม token ที่ส่งคืนไม่มีตัวคั่นที่ส่งคืนด้านบน
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// ส่งคืนช่วงสำหรับตัวคั่นของสตรีม token นี้ซึ่งครอบคลุม `Group` ทั้งหมด
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ส่งคืนสแปนที่ชี้ไปยังตัวคั่นเปิดของกลุ่มนี้
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// ส่งคืนช่วงที่ชี้ไปยังตัวคั่นปิดของกลุ่มนี้
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// กำหนดค่าช่วงสำหรับตัวคั่นของ "กลุ่ม" นี้ แต่ไม่ใช่ tokens ภายใน
    ///
    /// วิธีนี้จะ **ไม่** ตั้งค่าช่วงของ tokens ภายในทั้งหมดที่ขยายโดยกลุ่มนี้ แต่จะกำหนดเฉพาะช่วงของตัวคั่น tokens ที่ระดับ `Group`
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB สะพานให้เฉพาะ `to_string` ใช้ `fmt::Display` ตามนั้น (การย้อนกลับของความสัมพันธ์ตามปกติระหว่างทั้งสอง)
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// พิมพ์กลุ่มเป็นสตริงที่ควรแปลงกลับมาเป็นกลุ่มเดียวกันโดยไม่สูญเสีย (ช่วงโมดูโล) ยกเว้น "TokenTree: : Group`s ที่มีตัวคั่น `Delimiter::None`
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` เป็นอักขระเครื่องหมายวรรคตอนเดียวเช่น `+`, `-` หรือ `#`
///
/// ตัวดำเนินการหลายอักขระเช่น `+=` จะแสดงเป็น `Punct` สองอินสแตนซ์พร้อมกับส่งคืน `Spacing` ในรูปแบบที่แตกต่างกัน
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// ไม่ว่า `Punct` จะตามด้วย `Punct` อื่นทันทีหรือตามด้วย token หรือช่องว่างอื่น
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// เช่น `+` คือ `Alone` ใน `+ =`, `+ident` หรือ `+()`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// เช่น `+` คือ `Joint` ใน `+=` หรือ `'#`
    /// นอกจากนี้ใบเสนอราคาเดียว `'` สามารถรวมกับตัวระบุเพื่อสร้างช่วงชีวิต `'ident`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// สร้าง `Punct` ใหม่จากอักขระที่กำหนดและระยะห่าง
    /// อาร์กิวเมนต์ `ch` ต้องเป็นอักขระเครื่องหมายวรรคตอนที่ถูกต้องที่อนุญาตโดยภาษามิฉะนั้นฟังก์ชันจะเป็น panic
    ///
    /// `Punct` ที่ส่งคืนจะมีช่วงเริ่มต้นของ `Span::call_site()` ซึ่งสามารถกำหนดค่าเพิ่มเติมได้ด้วยวิธี `set_span` ด้านล่าง
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// ส่งคืนค่าของอักขระเครื่องหมายวรรคตอนนี้เป็น `char`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// ส่งคืนระยะห่างของอักขระเครื่องหมายวรรคตอนนี้โดยระบุว่าตามด้วย `Punct` อื่นในสตรีม token ทันทีหรือไม่ดังนั้นจึงสามารถรวมกันเป็นตัวดำเนินการแบบหลายอักขระ (`Joint`) หรือตามด้วย token อื่น ๆ หรือช่องว่าง (`Alone`) ดังนั้นตัวดำเนินการจึงมี สิ้นสุดแล้ว
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// ส่งคืนช่วงสำหรับอักขระเครื่องหมายวรรคตอนนี้
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// กำหนดค่าช่วงสำหรับอักขระเครื่องหมายวรรคตอนนี้
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB สะพานให้เฉพาะ `to_string` ใช้ `fmt::Display` ตามนั้น (การย้อนกลับของความสัมพันธ์ตามปกติระหว่างทั้งสอง)
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// พิมพ์อักขระเครื่องหมายวรรคตอนเป็นสตริงที่ควรแปลงกลับเป็นอักขระเดียวกันโดยไม่สูญเสีย
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// ตัวระบุ (`ident`)
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// สร้าง `Ident` ใหม่ด้วย `string` ที่กำหนดเช่นเดียวกับ `span` ที่ระบุ
    /// อาร์กิวเมนต์ `string` ต้องเป็นตัวระบุที่ถูกต้องที่อนุญาตโดยภาษา (รวมถึงคีย์เวิร์ดเช่น `self` หรือ `fn`)มิฉะนั้นฟังก์ชันจะ panic
    ///
    /// โปรดทราบว่า `span` ปัจจุบันอยู่ใน rustc กำหนดค่าข้อมูลสุขอนามัยสำหรับตัวระบุนี้
    ///
    /// ณ เวลานี้ `Span::call_site()` เลือกใช้สุขอนามัย "call-site" อย่างชัดเจนหมายความว่าตัวระบุที่สร้างขึ้นด้วยช่วงนี้จะได้รับการแก้ไขราวกับว่าถูกเขียนโดยตรงที่ตำแหน่งของการเรียกมาโครและโค้ดอื่น ๆ ที่ไซต์การเรียกมาโครจะสามารถอ้างถึงได้ พวกเขาเช่นกัน
    ///
    ///
    /// ช่วงเวลาต่อมาเช่น `Span::def_site()` จะอนุญาตให้เลือกใช้สุขอนามัย "definition-site" หมายความว่าตัวระบุที่สร้างขึ้นด้วยช่วงนี้จะได้รับการแก้ไขที่ตำแหน่งของข้อกำหนดมาโครและโค้ดอื่น ๆ ที่ไซต์การเรียกมาโครจะไม่สามารถอ้างถึงได้
    ///
    /// เนื่องจากความสำคัญของสุขอนามัยในปัจจุบันตัวสร้างนี้ซึ่งแตกต่างจาก tokens อื่น ๆ จึงต้องมีการระบุ `Span` ในการก่อสร้าง
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// เหมือนกับ `Ident::new` แต่สร้างตัวระบุดิบ (`r#ident`)
    /// อาร์กิวเมนต์ `string` เป็นตัวระบุที่ถูกต้องที่อนุญาตโดยภาษา (รวมถึงคีย์เวิร์ดเช่น `fn`)
    /// คำหลักที่ใช้งานได้ในกลุ่มเส้นทาง (เช่น
    /// `self`, ไม่รองรับ "super`) และจะทำให้เกิด panic
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// ส่งคืนช่วงของ `Ident` นี้โดยรวมสตริงทั้งหมดที่ส่งคืนโดย [`to_string`](Self::to_string)
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// กำหนดค่าช่วงของ `Ident` นี้อาจเปลี่ยนบริบทด้านสุขอนามัย
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB สะพานให้เฉพาะ `to_string` ใช้ `fmt::Display` ตามนั้น (การย้อนกลับของความสัมพันธ์ตามปกติระหว่างทั้งสอง)
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// พิมพ์ตัวระบุเป็นสตริงที่ควรแปลงกลับมาเป็นตัวระบุเดียวกันโดยไม่สูญเสีย
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// สตริงลิเทอรัล (`"hello"`) สตริงไบต์ (`b"hello"`) อักขระ (`'a'`) อักขระไบต์ (`b'a'`) เลขจำนวนเต็มหรือทศนิยมที่มีหรือไม่มีคำต่อท้าย ("1`, `1u8`, `2.3`, `2.3f32`)
///
/// ลิเทอรัลบูลีนเช่น `true` และ `false` ไม่ได้อยู่ที่นี่ แต่เป็นตัวระบุ
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// สร้างลิเทอรัลจำนวนเต็มต่อท้ายใหม่ด้วยค่าที่ระบุ
        ///
        /// ฟังก์ชันนี้จะสร้างจำนวนเต็มเช่น `1u32` โดยที่ค่าจำนวนเต็มที่ระบุเป็นส่วนแรกของ token และอินทิกรัลจะต่อท้ายด้วย
        /// ตัวอักษรที่สร้างจากจำนวนลบอาจไม่สามารถใช้งานแบบไปกลับผ่าน `TokenStream` หรือสตริงและอาจแบ่งออกเป็นสอง tokens (`-` และลิเทอรัลบวก)
        ///
        ///
        /// ตัวอักษรที่สร้างด้วยวิธีนี้จะมีช่วง `Span::call_site()` ตามค่าเริ่มต้นซึ่งสามารถกำหนดค่าได้ด้วยวิธี `set_span` ด้านล่าง
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// สร้างลิเทอรัลจำนวนเต็มใหม่ที่ไม่ได้กำหนดค่าด้วยค่าที่ระบุ
        ///
        /// ฟังก์ชันนี้จะสร้างจำนวนเต็มเช่น `1` โดยที่ค่าจำนวนเต็มที่ระบุเป็นส่วนแรกของ token
        /// ไม่มีการระบุคำต่อท้ายบน token ซึ่งหมายความว่าการเรียกใช้เช่น `Literal::i8_unsuffixed(1)` จะเทียบเท่ากับ `Literal::u32_unsuffixed(1)`
        /// ตัวอักษรที่สร้างจากตัวเลขที่เป็นค่าลบอาจไม่สามารถใช้งานรูนทริปผ่าน `TokenStream` หรือสตริงและอาจแบ่งออกเป็นสอง tokens (`-` และลิเทอรัลบวก)
        ///
        ///
        /// ตัวอักษรที่สร้างด้วยวิธีนี้จะมีช่วง `Span::call_site()` ตามค่าเริ่มต้นซึ่งสามารถกำหนดค่าได้ด้วยวิธี `set_span` ด้านล่าง
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// สร้างลิเทอรัลทศนิยมที่ไม่ได้ติดตั้งใหม่
    ///
    /// คอนสตรัคเตอร์นี้คล้ายกับ `Literal::i8_unsuffixed` ที่ค่าของ float ถูกส่งออกไปยัง token โดยตรง แต่ไม่มีการใช้คำต่อท้ายดังนั้นจึงอาจอนุมานได้ว่าเป็น `f64` ในภายหลังในคอมไพเลอร์
    ///
    /// ตัวอักษรที่สร้างจากตัวเลขที่เป็นค่าลบอาจไม่สามารถใช้งานรูนทริปผ่าน `TokenStream` หรือสตริงและอาจแบ่งออกเป็นสอง tokens (`-` และลิเทอรัลบวก)
    ///
    /// # Panics
    ///
    /// ฟังก์ชันนี้ต้องการให้ float ที่ระบุเป็นจำนวน จำกัด ตัวอย่างเช่นถ้าเป็น infinity หรือ NaN ฟังก์ชันนี้จะเป็น panic
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// สร้างลิเทอรัลทศนิยมที่ต่อท้ายใหม่
    ///
    /// ตัวสร้างนี้จะสร้างลิเทอรัลเช่น `1.0f32` โดยที่ค่าที่ระบุคือส่วนก่อนหน้าของ token และ `f32` คือส่วนต่อท้ายของ token
    /// token นี้จะอนุมานได้ว่าเป็น `f32` ในคอมไพเลอร์เสมอ
    /// ตัวอักษรที่สร้างจากตัวเลขที่เป็นค่าลบอาจไม่สามารถใช้งานรูนทริปผ่าน `TokenStream` หรือสตริงและอาจแบ่งออกเป็นสอง tokens (`-` และลิเทอรัลบวก)
    ///
    ///
    /// # Panics
    ///
    /// ฟังก์ชันนี้ต้องการให้ float ที่ระบุเป็นจำนวน จำกัด ตัวอย่างเช่นถ้าเป็น infinity หรือ NaN ฟังก์ชันนี้จะเป็น panic
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// สร้างลิเทอรัลทศนิยมที่ไม่ได้ติดตั้งใหม่
    ///
    /// คอนสตรัคเตอร์นี้คล้ายกับ `Literal::i8_unsuffixed` ที่ค่าของ float ถูกส่งออกไปยัง token โดยตรง แต่ไม่มีการใช้คำต่อท้ายดังนั้นจึงอาจอนุมานได้ว่าเป็น `f64` ในภายหลังในคอมไพเลอร์
    ///
    /// ตัวอักษรที่สร้างจากตัวเลขที่เป็นค่าลบอาจไม่สามารถใช้งานรูนทริปผ่าน `TokenStream` หรือสตริงและอาจแบ่งออกเป็นสอง tokens (`-` และลิเทอรัลบวก)
    ///
    /// # Panics
    ///
    /// ฟังก์ชันนี้ต้องการให้ float ที่ระบุเป็นจำนวน จำกัด ตัวอย่างเช่นถ้าเป็น infinity หรือ NaN ฟังก์ชันนี้จะเป็น panic
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// สร้างลิเทอรัลทศนิยมที่ต่อท้ายใหม่
    ///
    /// ตัวสร้างนี้จะสร้างลิเทอรัลเช่น `1.0f64` โดยที่ค่าที่ระบุคือส่วนก่อนหน้าของ token และ `f64` คือส่วนต่อท้ายของ token
    /// token นี้จะอนุมานได้ว่าเป็น `f64` ในคอมไพเลอร์เสมอ
    /// ตัวอักษรที่สร้างจากตัวเลขที่เป็นค่าลบอาจไม่สามารถใช้งานรูนทริปผ่าน `TokenStream` หรือสตริงและอาจแบ่งออกเป็นสอง tokens (`-` และลิเทอรัลบวก)
    ///
    ///
    /// # Panics
    ///
    /// ฟังก์ชันนี้ต้องการให้ float ที่ระบุเป็นจำนวน จำกัด ตัวอย่างเช่นถ้าเป็น infinity หรือ NaN ฟังก์ชันนี้จะเป็น panic
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// สตริงลิเทอรัล
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// อักขระตามตัวอักษร
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// ไบต์สตริงลิเทอรัล
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// ส่งคืนช่วงที่ครอบคลุมลิเทอรัลนี้
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// กำหนดค่าช่วงที่เชื่อมโยงสำหรับลิเทอรัลนี้
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// ส่งคืน `Span` ที่เป็นส่วนย่อยของ `self.span()` ที่มีเฉพาะไบต์ต้นทางในช่วง `range`
    /// ส่งคืน `None` หากช่วงที่ถูกตัดแต่งอยู่นอกขอบเขตของ `self`
    ///
    // FIXME(SergioBenitez): ตรวจสอบว่าช่วงไบต์เริ่มต้นและสิ้นสุดที่ขอบเขต UTF-8 ของแหล่งที่มา
    // มิฉะนั้นอาจเป็นไปได้ว่า panic จะเกิดขึ้นที่อื่นเมื่อพิมพ์ข้อความต้นฉบับ
    // FIXME(SergioBenitez): ไม่มีทางที่ผู้ใช้จะรู้ว่า `self.span()` จับคู่กับอะไรดังนั้นในปัจจุบันวิธีนี้สามารถเรียกได้เพียงสุ่มสี่สุ่มห้าเท่านั้น
    // ตัวอย่างเช่น `to_string()` สำหรับอักขระ 'c' ส่งคืน "'\u{63}'" ไม่มีทางที่ผู้ใช้จะทราบได้ว่าข้อความต้นฉบับคือ 'c' หรือว่าเป็น '\u{63}'
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) บางอย่างคล้ายกับ `Option::cloned` แต่สำหรับ `Bound<&T>`
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB สะพานให้เฉพาะ `to_string` ใช้ `fmt::Display` ตามนั้น (การย้อนกลับของความสัมพันธ์ตามปกติระหว่างทั้งสอง)
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// พิมพ์ลิเทอรัลเป็นสตริงที่ควรแปลงกลับเป็นลิเทอรัลเดียวกันโดยไม่สูญเสีย (ยกเว้นการปัดเศษที่เป็นไปได้สำหรับลิเทอรัลจุดลอยตัว)
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// ติดตามการเข้าถึงตัวแปรสภาพแวดล้อม
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// ดึงตัวแปรสภาพแวดล้อมและเพิ่มเพื่อสร้างข้อมูลการอ้างอิง
    /// ระบบบิวด์ที่รันคอมไพเลอร์จะทราบว่ามีการเข้าถึงตัวแปรในระหว่างการคอมไพล์และจะสามารถรันบิลด์ใหม่ได้เมื่อค่าของตัวแปรนั้นเปลี่ยนไป
    ///
    /// นอกเหนือจากการติดตามการอ้างอิงฟังก์ชันนี้ควรเทียบเท่ากับ `env::var` จากไลบรารีมาตรฐานยกเว้นว่าอาร์กิวเมนต์ต้องเป็น UTF-8
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}