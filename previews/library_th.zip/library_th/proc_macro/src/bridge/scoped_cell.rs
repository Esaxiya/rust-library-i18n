//! `Cell` ตัวแปรสำหรับ (scoped) อายุการใช้งานที่มีอยู่จริง

use std::cell::Cell;
use std::mem;
use std::ops::{Deref, DerefMut};

/// พิมพ์แลมด้าแอปพลิเคชันอายุการใช้งาน
#[allow(unused_lifetimes)]
pub trait ApplyL<'a> {
    type Out;
}

/// พิมพ์แลมด้าที่มีอายุการใช้งานกล่าวคือ `Lifetime -> Type`.
pub trait LambdaL: for<'a> ApplyL<'a> {}

impl<T: for<'a> ApplyL<'a>> LambdaL for T {}

// HACK(eddyb) หลีกเลี่ยงข้อ จำกัด ในการฉายภาพด้วย newtype FIXME(#52812) แทนที่ด้วย `&'a mut <T as ApplyL<'b>>::Out`
//
pub struct RefMutL<'a, 'b, T: LambdaL>(&'a mut <T as ApplyL<'b>>::Out);

impl<'a, 'b, T: LambdaL> Deref for RefMutL<'a, 'b, T> {
    type Target = <T as ApplyL<'b>>::Out;
    fn deref(&self) -> &Self::Target {
        self.0
    }
}

impl<'a, 'b, T: LambdaL> DerefMut for RefMutL<'a, 'b, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.0
    }
}

pub struct ScopedCell<T: LambdaL>(Cell<<T as ApplyL<'static>>::Out>);

impl<T: LambdaL> ScopedCell<T> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new(value: <T as ApplyL<'static>>::Out) -> Self {
        ScopedCell(Cell::new(value))
    }

    /// ตั้งค่าใน `self` เป็น `replacement` ในขณะที่รัน `f` ซึ่งจะได้รับค่าเก่าโดยแปรผัน
    /// ค่าเก่าจะถูกเรียกคืนหลังจาก `f` ออกแม้โดย panic รวมถึงการแก้ไขที่ทำโดย `f`
    ///
    ///
    pub fn replace<'a, R>(
        &self,
        replacement: <T as ApplyL<'a>>::Out,
        f: impl for<'b, 'c> FnOnce(RefMutL<'b, 'c, T>) -> R,
    ) -> R {
        /// Wrapper ที่ช่วยให้มั่นใจได้ว่าเซลล์จะเต็มไปด้วยเสมอ (ด้วยสถานะดั้งเดิมซึ่งอาจเปลี่ยนแปลงได้โดย `f`) แม้ว่า `f` จะตื่นตระหนกก็ตาม
        ///
        ///
        struct PutBackOnDrop<'a, T: LambdaL> {
            cell: &'a ScopedCell<T>,
            value: Option<<T as ApplyL<'static>>::Out>,
        }

        impl<'a, T: LambdaL> Drop for PutBackOnDrop<'a, T> {
            fn drop(&mut self) {
                self.cell.0.set(self.value.take().unwrap());
            }
        }

        let mut put_back_on_drop = PutBackOnDrop {
            cell: self,
            value: Some(self.0.replace(unsafe {
                let erased = mem::transmute_copy(&replacement);
                mem::forget(replacement);
                erased
            })),
        };

        f(RefMutL(put_back_on_drop.value.as_mut().unwrap()))
    }

    /// ตั้งค่าใน `self` เป็น `value` ขณะรัน `f`
    pub fn set<R>(&self, value: <T as ApplyL<'_>>::Out, f: impl FnOnce() -> R) -> R {
        self.replace(value, |_| f())
    }
}