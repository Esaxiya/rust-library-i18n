#![feature(no_core)]
#![no_core]

// ดู rustc-std-workspace-core สำหรับสาเหตุที่ต้องใช้ crate

// เปลี่ยนชื่อ crate เพื่อหลีกเลี่ยงความขัดแย้งกับโมดูลการจัดสรรใน liballoc
extern crate alloc as foo;

pub use foo::*;