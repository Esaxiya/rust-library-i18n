`core::arch` - โครงสร้างภายในเฉพาะสถาปัตยกรรมไลบรารีหลักของ Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

โมดูล `core::arch` ใช้โครงสร้างภายในที่ขึ้นกับสถาปัตยกรรม (เช่น SIMD)

# Usage 

`core::arch` มีให้เป็นส่วนหนึ่งของ `libcore` และส่งออกใหม่โดย `libstd` ชอบใช้ผ่าน `core::arch` หรือ `std::arch` มากกว่าผ่าน crate นี้
คุณสมบัติที่ไม่เสถียรมักมีให้ใน Rust ทุกคืนผ่าน `feature(stdsimd)`

การใช้ `core::arch` ผ่าน crate นี้ต้องใช้ Rust ทุกคืนและมันสามารถ (และไม่) พังได้บ่อยครั้งกรณีเดียวที่คุณควรพิจารณาใช้ผ่าน crate คือ:

* หากคุณต้องการคอมไพล์ `core::arch` ด้วยตัวคุณเองอีกครั้งเช่นด้วยคุณสมบัติเป้าหมายเฉพาะที่เปิดใช้งานซึ่งไม่ได้เปิดใช้งานสำหรับ `libcore`/`libstd`
Note: หากคุณต้องการคอมไพล์ใหม่สำหรับเป้าหมายที่ไม่ได้มาตรฐานโปรดเลือกใช้ `xargo` และคอมไพล์ `libcore`/`libstd` ใหม่ตามความเหมาะสมแทนที่จะใช้ crate นี้
  
* โดยใช้คุณสมบัติบางอย่างที่อาจใช้ไม่ได้แม้จะอยู่เบื้องหลังคุณสมบัติ Rust ที่ไม่เสถียรเราพยายามรักษาสิ่งเหล่านี้ให้น้อยที่สุด
หากคุณจำเป็นต้องใช้คุณสมบัติบางอย่างเหล่านี้โปรดเปิดปัญหาเพื่อให้เราสามารถเปิดเผยใน Rust ทุกคืนและคุณสามารถใช้งานได้จากที่นั่น

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` มีการแจกจ่ายเป็นหลักภายใต้เงื่อนไขของทั้งสิทธิ์การใช้งาน MIT และใบอนุญาต Apache (เวอร์ชัน 2.0) โดยมีส่วนที่ครอบคลุมโดยใบอนุญาตคล้าย BSD ต่างๆ

ดู LICENSE-APACHE และ LICENSE-MIT สำหรับรายละเอียด

# Contribution

เว้นแต่คุณจะระบุไว้เป็นอย่างอื่นอย่างชัดเจนผลงานใด ๆ ที่คุณส่งมาเพื่อรวมไว้ใน `core_arch` โดยเจตนาตามที่กำหนดไว้ในใบอนุญาต Apache-2.0 จะต้องได้รับใบอนุญาตเป็นคู่ตามข้างต้นโดยไม่มีข้อกำหนดหรือเงื่อนไขเพิ่มเติมใด ๆ


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












