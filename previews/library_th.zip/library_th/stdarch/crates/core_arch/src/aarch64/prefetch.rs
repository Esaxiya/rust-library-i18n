#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// ดู [`prefetch`](fn._prefetch.html)
pub const _PREFETCH_READ: i32 = 0;

/// ดู [`prefetch`](fn._prefetch.html)
pub const _PREFETCH_WRITE: i32 = 1;

/// ดู [`prefetch`](fn._prefetch.html)
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// ดู [`prefetch`](fn._prefetch.html)
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// ดู [`prefetch`](fn._prefetch.html)
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// ดู [`prefetch`](fn._prefetch.html)
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// ดึงบรรทัดแคชที่มีแอดเดรส `p` โดยใช้ `rw` และ `locality` ที่กำหนด
///
/// `rw` ต้องเป็นหนึ่งใน:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): การดึงข้อมูลล่วงหน้ากำลังเตรียมพร้อมสำหรับการอ่าน
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): การดึงข้อมูลล่วงหน้ากำลังเตรียมสำหรับการเขียน
///
/// `locality` ต้องเป็นหนึ่งใน:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): การดึงข้อมูลล่วงหน้าแบบสตรีมหรือแบบไม่ชั่วคราวสำหรับข้อมูลที่ใช้เพียงครั้งเดียว
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): ดึงเข้าสู่แคชระดับ 3
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): ดึงเข้าสู่แคชระดับ 2
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): ดึงข้อมูลเข้าสู่แคชระดับ 1
///
/// สัญญาณคำแนะนำหน่วยความจำ prefetch ไปยังระบบหน่วยความจำที่หน่วยความจำเข้าถึงจากที่อยู่ที่ระบุมีแนวโน้มที่จะเกิดขึ้นใน future ที่อยู่ใกล้
/// ระบบหน่วยความจำสามารถตอบสนองโดยดำเนินการที่คาดว่าจะเพิ่มความเร็วในการเข้าถึงหน่วยความจำเมื่อเกิดขึ้นเช่นการโหลดแอดเดรสที่ระบุไว้ล่วงหน้าในแคชหนึ่งแคชหรือมากกว่านั้น
///
/// เนื่องจากสัญญาณเหล่านี้เป็นเพียงคำแนะนำจึงใช้ได้สำหรับ CPU บางตัวที่จะปฏิบัติต่อคำแนะนำในการดึงข้อมูลล่วงหน้าใด ๆ หรือทั้งหมดเป็น NOP
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // เราใช้โปรแกรม `llvm.prefetch` กับ `cache type` =1 (แคชข้อมูล)
    // `rw` และ `strategy` ขึ้นอยู่กับพารามิเตอร์ของฟังก์ชัน
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}