use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // ใช้เพื่อบอกคำอธิบายประกอบ `#[assert_instr]` ของเราว่าซิมด์อินทรินนิกส์ทั้งหมดพร้อมใช้งานเพื่อทดสอบโค้ดเจนของพวกเขาเนื่องจากบางส่วนอยู่ด้านหลัง `-Ctarget-feature=+unimplemented-simd128` พิเศษที่ไม่มีสิ่งใดเทียบเท่าใน `#[target_feature]` ในตอนนี้
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}