# มีส่วนร่วมใน stdarch

`stdarch` crate เป็นมากกว่ายินดีที่จะรับเงินบริจาค!ก่อนอื่นคุณอาจต้องการตรวจสอบที่เก็บข้อมูลและตรวจสอบให้แน่ใจว่าการทดสอบผ่านสำหรับคุณ:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

โดยที่ `<your-target-arch>` คือเป้าหมายสามเท่าที่ใช้โดย `rustup` เช่น `x86_x64-unknown-linux-gnu` (ไม่มี `nightly-` นำหน้าหรือคล้ายกัน)
โปรดจำไว้ว่าที่เก็บนี้ต้องใช้ช่อง Rust ทุกคืน!
การทดสอบข้างต้นจำเป็นต้องใช้ rust ทุกคืนเพื่อเป็นค่าเริ่มต้นในระบบของคุณเพื่อตั้งค่าให้ใช้ `rustup default nightly` (และ `rustup default stable` เพื่อย้อนกลับ)

หากขั้นตอนข้างต้นไม่ได้ผล [please let us know][new]!

ถัดไปคุณสามารถ [find an issue][issues] เพื่อช่วยได้เราได้เลือกแท็ก [`help wanted`][help] และ [`impl-period`][impl] ซึ่งสามารถใช้ความช่วยเหลือได้โดยเฉพาะ 
คุณอาจสนใจ [#40][vendor] มากที่สุดโดยใช้ Intrinsics ของผู้ขายทั้งหมดบน x86 ปัญหานั้นมีคำแนะนำที่ดีเกี่ยวกับจุดเริ่มต้น!

หากคุณมีคำถามทั่วไปอย่าลังเลที่จะ [join us on gitter][gitter] และถามรอบ ๆ !อย่าลังเลที่จะส่งคำถามไปที่@BurntSushi หรือ@alexcrichton

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# วิธีการเขียนตัวอย่างสำหรับ stdarch intrinsics

มีคุณลักษณะบางอย่างที่ต้องเปิดใช้งานเพื่อให้ภายในที่กำหนดทำงานได้อย่างถูกต้องและตัวอย่างจะต้องถูกเรียกใช้โดย `cargo test --doc` เมื่อคุณลักษณะนี้ได้รับการสนับสนุนโดย CPU

ด้วยเหตุนี้ `fn main` เริ่มต้นที่สร้างโดย `rustdoc` จะไม่ทำงาน (ในกรณีส่วนใหญ่)
ลองใช้สิ่งต่อไปนี้เป็นแนวทางเพื่อให้แน่ใจว่าตัวอย่างของคุณทำงานได้ตามที่คาดไว้

```rust
/// # // เราต้องการ cfg_target_feature เพื่อให้แน่ใจว่าเป็นตัวอย่างเท่านั้น
/// # // ทำงานโดย `cargo test --doc` เมื่อ CPU รองรับคุณสมบัติ
/// # #![feature(cfg_target_feature)]
/// # // เราต้องการ target_feature เพื่อให้เนื้อแท้ทำงานได้
/// # #![feature(target_feature)]
/// #
/// # // rustdoc โดยค่าเริ่มต้นใช้ `extern crate stdarch` แต่เราต้องการไฟล์
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // ฟังก์ชั่นหลักที่แท้จริง
/// # fn main() {
/// #     // เรียกใช้สิ่งนี้หากรองรับ `<target feature>` เท่านั้น
/// #     ถ้า cfg_feature_enabled! ("<target feature>"){
/// #         // สร้างฟังก์ชัน `worker` ที่จะทำงานต่อเมื่อคุณลักษณะเป้าหมาย
/// #         // ได้รับการสนับสนุนและตรวจสอบให้แน่ใจว่า `target_feature` เปิดใช้งานสำหรับพนักงานของคุณ
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         ไม่ปลอดภัย fn worker() {
/// // เขียนตัวอย่างของคุณที่นี่คุณลักษณะเฉพาะที่อยู่ภายในจะทำงานที่นี่!ดุเดือด!
///
/// #         }
///
/// #         { worker(); } ที่ไม่ปลอดภัย
/// #     }
/// # }
```

หากไวยากรณ์ข้างต้นบางส่วนดูไม่คุ้นเคยส่วน [Documentation as tests] ของ [Rust Book] จะอธิบายไวยากรณ์ `rustdoc` ได้ค่อนข้างดี
เช่นเคยโปรดอย่าลังเลที่จะ [join us on gitter][gitter] และถามเราว่าคุณประสบปัญหาใด ๆ หรือไม่และขอขอบคุณที่ช่วยปรับปรุงเอกสารของ `stdarch`!

# คำแนะนำในการทดสอบทางเลือก

โดยทั่วไปขอแนะนำให้คุณใช้ `ci/run.sh` เพื่อเรียกใช้การทดสอบ
อย่างไรก็ตามสิ่งนี้อาจไม่ได้ผลสำหรับคุณเช่นหากคุณใช้ Windows

ในกรณีนี้คุณสามารถกลับไปใช้ `cargo +nightly test` และ `cargo +nightly test --release -p core_arch` เพื่อทดสอบการสร้างโค้ดได้
โปรดทราบว่าสิ่งเหล่านี้จำเป็นต้องติดตั้ง toolchain ทุกคืนและเพื่อให้ `rustc` รู้เกี่ยวกับสามเป้าหมายและ CPU ของคุณ
โดยเฉพาะอย่างยิ่งคุณต้องตั้งค่าตัวแปรสภาพแวดล้อม `TARGET` ตามที่คุณต้องการสำหรับ `ci/run.sh`
นอกจากนี้คุณต้องตั้งค่า `RUSTCFLAGS` (ต้องใช้ `C`) เพื่อระบุคุณสมบัติเป้าหมายเช่น `RUSTCFLAGS="-C -target-features=+avx2"`.
คุณยังสามารถตั้งค่า `-C -target-cpu=native` ได้หากคุณกำลังพัฒนา "just" เทียบกับ CPU ปัจจุบันของคุณ

ขอเตือนว่าเมื่อคุณใช้คำแนะนำทางเลือกเหล่านี้ [things may go less smoothly than they would with `ci/run.sh`][ci-run-good] เช่น
การทดสอบการสร้างคำสั่งอาจล้มเหลวเนื่องจากตัวแยกชิ้นส่วนตั้งชื่อต่างกันเช่น
มันอาจสร้าง `vaesenc` แทนคำสั่ง `aesenc` แม้ว่าจะมีพฤติกรรมเหมือนกันก็ตาม
นอกจากนี้คำแนะนำเหล่านี้ยังทำการทดสอบน้อยกว่าที่จะทำตามปกติดังนั้นอย่าแปลกใจที่ในที่สุดเมื่อคุณดึงคำขอข้อผิดพลาดบางอย่างอาจปรากฏขึ้นสำหรับการทดสอบที่ไม่ได้กล่าวถึงในที่นี้

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






