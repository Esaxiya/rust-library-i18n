# `rustc-std-workspace-core` crate

crate นี้คือ shim และ crate ที่ว่างเปล่าซึ่งขึ้นอยู่กับ `libcore` และทำการเอ็กซ์พอร์ตเนื้อหาทั้งหมดอีกครั้ง
crate เป็นหัวใจสำคัญของการเพิ่มขีดความสามารถให้ไลบรารีมาตรฐานขึ้นอยู่กับ crates จาก crates.io

Crates บน crates.io ที่ไลบรารีมาตรฐานขึ้นอยู่กับความต้องการขึ้นอยู่กับ `rustc-std-workspace-core` crate จาก crates.io ซึ่งว่างเปล่า

เราใช้ `[patch]` เพื่อแทนที่มันเป็น crate นี้ในที่เก็บนี้
ด้วยเหตุนี้ crates บน crates.io จะดึงการอ้างอิง edge ไปยัง `libcore` ซึ่งเป็นเวอร์ชันที่กำหนดไว้ในที่เก็บนี้
นั่นควรวาดขอบการพึ่งพาทั้งหมดเพื่อให้แน่ใจว่า Cargo สร้าง crates สำเร็จ!

โปรดทราบว่า crates บน crates.io จำเป็นต้องขึ้นอยู่กับ crate ที่มีชื่อ `core` เพื่อให้ทุกอย่างทำงานได้อย่างถูกต้องในการทำเช่นนั้นพวกเขาสามารถใช้:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

ด้วยการใช้คีย์ `package` crate จะถูกเปลี่ยนชื่อเป็น `core` ซึ่งหมายความว่า

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

เมื่อ Cargo เรียกใช้คอมไพเลอร์ซึ่งเป็นไปตามคำสั่ง `extern crate core` โดยนัยที่คอมไพเลอร์ฉีด




