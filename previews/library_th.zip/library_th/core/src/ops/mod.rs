//! ตัวดำเนินการที่เกินพิกัด
//!
//! การใช้ traits เหล่านี้ช่วยให้คุณสามารถโอเวอร์โหลดตัวดำเนินการบางตัวได้
//!
//! traits เหล่านี้บางส่วนถูกนำเข้าโดย prelude ดังนั้นจึงมีอยู่ในทุกโปรแกรม Rust เฉพาะโอเปอเรเตอร์ที่ได้รับการสนับสนุนโดย traits เท่านั้นที่สามารถโอเวอร์โหลดได้
//! ตัวอย่างเช่นตัวดำเนินการเพิ่มเติม (`+`) สามารถโอเวอร์โหลดผ่าน [`Add`] trait ได้ แต่เนื่องจากตัวดำเนินการกำหนด (`=`) ไม่มีการสำรอง trait จึงไม่มีทางที่จะโอเวอร์โหลดความหมายได้
//! นอกจากนี้โมดูลนี้ไม่มีกลไกใด ๆ ในการสร้างตัวดำเนินการใหม่
//! หากจำเป็นต้องใช้ตัวดำเนินการมากเกินไปหรือตัวดำเนินการแบบกำหนดเองคุณควรมองหามาโครหรือปลั๊กอินคอมไพเลอร์เพื่อขยายไวยากรณ์ของ Rust
//!
//! การใช้งานตัวดำเนินการ traits ควรไม่น่าแปลกใจในบริบทที่เกี่ยวข้องโดยคำนึงถึงความหมายตามปกติและ [operator precedence]
//! ตัวอย่างเช่นเมื่อใช้ [`Mul`] การดำเนินการควรมีความคล้ายคลึงกับการคูณ (และแบ่งปันคุณสมบัติที่คาดหวังเช่นการเชื่อมโยง)
//!
//! โปรดทราบว่าตัวดำเนินการ `&&` และ `||` ลัดวงจรกล่าวคือพวกเขาจะประเมินตัวถูกดำเนินการที่สองเท่านั้นหากมีส่วนทำให้เกิดผลลัพธ์เนื่องจากพฤติกรรมนี้ไม่สามารถบังคับใช้ได้โดย traits จึงไม่รองรับ `&&` และ `||` เป็นตัวดำเนินการที่โอเวอร์โหลดได้
//!
//! ตัวดำเนินการหลายตัวใช้ตัวถูกดำเนินการตามค่าในบริบทที่ไม่ใช่ทั่วไปที่เกี่ยวข้องกับประเภทบิวท์อินโดยปกติจะไม่เป็นปัญหา
//! อย่างไรก็ตามการใช้โอเปอเรเตอร์เหล่านี้ในโค้ดทั่วไปต้องให้ความสนใจหากต้องนำค่ามาใช้ซ้ำแทนที่จะปล่อยให้ตัวดำเนินการใช้ค่าเหล่านี้ทางเลือกหนึ่งคือใช้ [`clone`] เป็นครั้งคราว
//! อีกทางเลือกหนึ่งคือการพึ่งพาประเภทที่เกี่ยวข้องกับการให้การใช้งานตัวดำเนินการเพิ่มเติมสำหรับการอ้างอิง
//! ตัวอย่างเช่นสำหรับ `T` ประเภทที่ผู้ใช้กำหนดซึ่งควรจะรองรับการเพิ่มอาจเป็นความคิดที่ดีที่จะให้ทั้ง `T` และ `&T` ใช้ traits [`Add<T>`][`Add`] และ [`Add<&T>`][`Add`] เพื่อให้สามารถเขียนโค้ดทั่วไปได้โดยไม่ต้องทำการโคลนนิ่งโดยไม่จำเป็น
//!
//!
//! # Examples
//!
//! ตัวอย่างนี้สร้างโครงสร้าง `Point` ที่ใช้ [`Add`] และ [`Sub`] จากนั้นสาธิตการเพิ่มและลบสอง "จุด"
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! ดูเอกสารประกอบสำหรับแต่ละ trait สำหรับตัวอย่างการนำไปใช้งาน
//!
//! [`Fn`], [`FnMut`] และ [`FnOnce`] traits ถูกนำไปใช้งานตามประเภทที่สามารถเรียกใช้เช่นฟังก์ชันโปรดทราบว่า [`Fn`] ใช้ `&self`, [`FnMut`] ใช้ `&mut self` และ [`FnOnce`] ใช้ `self`
//! สิ่งเหล่านี้สอดคล้องกับวิธีการสามประเภทที่สามารถเรียกใช้บนอินสแตนซ์ ได้แก่ การเรียกตามการอ้างอิงการเรียกโดยการเปลี่ยนแปลงการอ้างอิงและการเรียกตามค่า
//! การใช้ traits เหล่านี้โดยทั่วไปคือการทำหน้าที่เป็นขอบเขตกับฟังก์ชันระดับสูงกว่าที่ใช้ฟังก์ชันหรือการปิดเป็นอาร์กิวเมนต์
//!
//! การใช้ [`Fn`] เป็นพารามิเตอร์:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! การใช้ [`FnMut`] เป็นพารามิเตอร์:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! การใช้ [`FnOnce`] เป็นพารามิเตอร์:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` ใช้ตัวแปรที่จับได้ดังนั้นจึงไม่สามารถรันได้มากกว่าหนึ่งครั้ง
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // การพยายามเรียกใช้ `func()` อีกครั้งจะทำให้เกิดข้อผิดพลาด `use of moved value` สำหรับ `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` ไม่สามารถเรียกใช้ ณ จุดนี้ได้อีกต่อไป
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;