/// trait สำหรับปรับแต่งลักษณะการทำงานของตัวดำเนินการ `?`
///
/// ประเภทที่ใช้ `Try` คือประเภทที่มีวิธีที่ยอมรับได้ในการดูในรูปแบบของการแยกขั้ว success/failure
/// trait นี้ช่วยให้ทั้งการแยกค่าความสำเร็จหรือความล้มเหลวจากอินสแตนซ์ที่มีอยู่และสร้างอินสแตนซ์ใหม่จากค่าความสำเร็จหรือความล้มเหลว
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// ประเภทของค่านี้เมื่อถูกมองว่าสำเร็จ
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// ประเภทของค่านี้เมื่อถูกมองว่าล้มเหลว
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// ใช้ตัวดำเนินการ "?" ผลตอบแทนของ `Ok(t)` หมายความว่าการดำเนินการควรดำเนินต่อไปตามปกติและผลลัพธ์ของ `?` คือค่า `t`
    /// การส่งคืน `Err(e)` หมายความว่าการดำเนินการควร branch ไปที่ด้านในสุดที่ล้อมรอบ `catch` หรือกลับจากฟังก์ชัน
    ///
    /// หากส่งคืนผลลัพธ์ `Err(e)` ค่า `e` จะเป็น "wrapped" ในประเภทการส่งคืนของขอบเขตการปิดล้อม (ซึ่งต้องใช้ `Try` เอง)
    ///
    /// โดยเฉพาะค่า `X::from_error(From::from(e))` จะถูกส่งกลับโดยที่ `X` เป็นชนิดการส่งคืนของฟังก์ชันการปิดล้อม
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// ตัดค่าความผิดพลาดเพื่อสร้างผลลัพธ์แบบผสม
    /// ตัวอย่างเช่น `Result::Err(x)` และ `Result::from_error(x)` เทียบเท่ากัน
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// ตัดค่า OK เพื่อสร้างผลลัพธ์แบบผสม
    /// ตัวอย่างเช่น `Result::Ok(x)` และ `Result::from_ok(x)` เทียบเท่ากัน
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}