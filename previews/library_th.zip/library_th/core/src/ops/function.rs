/// เวอร์ชันของตัวดำเนินการโทรที่รับเครื่องรับที่ไม่เปลี่ยนรูป
///
/// สามารถเรียกอินสแตนซ์ของ `Fn` ซ้ำ ๆ ได้โดยไม่ต้องเปลี่ยนสถานะ
///
/// *trait (`Fn`) นี้ไม่ต้องวุ่นวายกับ [function pointers] (`fn`)*
///
/// `Fn` จะดำเนินการโดยอัตโนมัติโดยการปิดซึ่งใช้เฉพาะการอ้างอิงที่ไม่เปลี่ยนรูปไปยังตัวแปรที่จับหรือไม่จับอะไรเลยเช่นเดียวกับ (safe) [function pointers] (มีข้อแม้บางประการโปรดดูเอกสารประกอบสำหรับรายละเอียดเพิ่มเติม)
///
/// นอกจากนี้สำหรับ `F` ประเภทใด ๆ ที่ใช้ `Fn`, `&F` ก็ใช้ `Fn` เช่นกัน
///
/// เนื่องจากทั้ง [`FnMut`] และ [`FnOnce`] เป็น supertraits ของ `Fn` อินสแตนซ์ใด ๆ ของ `Fn` จึงสามารถใช้เป็นพารามิเตอร์ที่คาดว่า [`FnMut`] หรือ [`FnOnce`]
///
/// ใช้ `Fn` เป็นขอบเขตเมื่อคุณต้องการยอมรับพารามิเตอร์ประเภทฟังก์ชันเหมือนและจำเป็นต้องเรียกมันซ้ำ ๆ และไม่มีสถานะกลายพันธุ์ (เช่นเมื่อเรียกมันพร้อมกัน)
/// หากคุณไม่ต้องการข้อกำหนดที่เข้มงวดเช่นนั้นให้ใช้ [`FnMut`] หรือ [`FnOnce`] เป็นขอบเขต
///
/// ดู [chapter on closures in *The Rust Programming Language*][book] สำหรับข้อมูลเพิ่มเติมเกี่ยวกับหัวข้อนี้
///
/// นอกจากนี้ที่ทราบคือไวยากรณ์พิเศษสำหรับ `Fn` traits (เช่น
/// `Fn(usize, bool) -> usize`).ผู้ที่สนใจรายละเอียดทางเทคนิคนี้สามารถอ้างถึง [the relevant section in the *Rustonomicon*][nomicon]
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## เรียกการปิด
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## ใช้พารามิเตอร์ `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // เพื่อให้ regex สามารถพึ่งพา `&str: !FnMut` ได้
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// ดำเนินการโทร
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// เวอร์ชันของตัวดำเนินการโทรที่รับตัวรับที่ไม่แน่นอน
///
/// สามารถเรียกอินสแตนซ์ของ `FnMut` ซ้ำ ๆ กันและอาจกลายสภาพ
///
/// `FnMut` จะดำเนินการโดยอัตโนมัติโดยการปิดซึ่งใช้การอ้างอิงที่เปลี่ยนแปลงได้กับตัวแปรที่จับรวมทั้งทุกประเภทที่ใช้ [`Fn`] เช่น (safe) [function pointers] (เนื่องจาก `FnMut` เป็น supertrait ของ [`Fn`])
/// นอกจากนี้สำหรับ `F` ประเภทใด ๆ ที่ใช้ `FnMut`, `&mut F` ก็ใช้ `FnMut` เช่นกัน
///
/// เนื่องจาก [`FnOnce`] เป็น supertrait ของ `FnMut` จึงสามารถใช้อินสแตนซ์ของ `FnMut` ในกรณีที่คาดว่า [`FnOnce`] ได้และเนื่องจาก [`Fn`] เป็นส่วนย่อยของ `FnMut` จึงสามารถใช้อินสแตนซ์ของ [`Fn`] ในกรณีที่คาดว่า `FnMut` ได้
///
/// ใช้ `FnMut` เป็นขอบเขตเมื่อคุณต้องการยอมรับพารามิเตอร์ประเภทฟังก์ชันเหมือนและจำเป็นต้องเรียกมันซ้ำ ๆ ในขณะที่ปล่อยให้สถานะกลายพันธุ์
/// หากคุณไม่ต้องการให้พารามิเตอร์กลายสภาพให้ใช้ [`Fn`] เป็นขอบเขตหากคุณไม่จำเป็นต้องเรียกมันซ้ำ ๆ ให้ใช้ [`FnOnce`]
///
/// ดู [chapter on closures in *The Rust Programming Language*][book] สำหรับข้อมูลเพิ่มเติมเกี่ยวกับหัวข้อนี้
///
/// นอกจากนี้ที่ทราบคือไวยากรณ์พิเศษสำหรับ `Fn` traits (เช่น
/// `Fn(usize, bool) -> usize`).ผู้ที่สนใจรายละเอียดทางเทคนิคนี้สามารถอ้างถึง [the relevant section in the *Rustonomicon*][nomicon]
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## เรียกการปิดที่จับกันไม่ได้
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## ใช้พารามิเตอร์ `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // เพื่อให้ regex สามารถพึ่งพา `&str: !FnMut` ได้
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// ดำเนินการโทร
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// เวอร์ชันของตัวดำเนินการโทรที่รับตัวรับตามค่า
///
/// สามารถเรียกอินสแตนซ์ของ `FnOnce` ได้ แต่อาจไม่สามารถโทรได้หลายครั้งด้วยเหตุนี้หากสิ่งเดียวที่ทราบเกี่ยวกับประเภทคือการใช้ `FnOnce` จึงสามารถเรียกได้เพียงครั้งเดียว
///
/// `FnOnce` จะดำเนินการโดยอัตโนมัติโดยการปิดที่อาจใช้ตัวแปรที่จับได้เช่นเดียวกับทุกประเภทที่ใช้ [`FnMut`] เช่น (safe) [function pointers] (เนื่องจาก `FnOnce` เป็น supertrait ของ [`FnMut`])
///
///
/// เนื่องจากทั้ง [`Fn`] และ [`FnMut`] เป็นหน่วยย่อยของ `FnOnce` จึงสามารถใช้อินสแตนซ์ของ [`Fn`] หรือ [`FnMut`] ในกรณีที่คาดว่า `FnOnce` ได้
///
/// ใช้ `FnOnce` เป็นขอบเขตเมื่อคุณต้องการยอมรับพารามิเตอร์ประเภทฟังก์ชันเหมือนและต้องเรียกใช้เพียงครั้งเดียว
/// หากคุณต้องการเรียกพารามิเตอร์ซ้ำ ๆ ให้ใช้ [`FnMut`] เป็นขอบเขตหากคุณต้องการเพื่อไม่ให้สถานะกลายพันธุ์ให้ใช้ [`Fn`]
///
/// ดู [chapter on closures in *The Rust Programming Language*][book] สำหรับข้อมูลเพิ่มเติมเกี่ยวกับหัวข้อนี้
///
/// นอกจากนี้ที่ทราบคือไวยากรณ์พิเศษสำหรับ `Fn` traits (เช่น
/// `Fn(usize, bool) -> usize`).ผู้ที่สนใจรายละเอียดทางเทคนิคนี้สามารถอ้างถึง [the relevant section in the *Rustonomicon*][nomicon]
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## ใช้พารามิเตอร์ `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` ใช้ตัวแปรที่จับได้ดังนั้นจึงไม่สามารถรันได้มากกว่าหนึ่งครั้ง
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // การพยายามเรียกใช้ `func()` อีกครั้งจะทำให้เกิดข้อผิดพลาด `use of moved value` สำหรับ `func`
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` ไม่สามารถเรียกใช้ ณ จุดนี้ได้อีกต่อไป
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // เพื่อให้ regex สามารถพึ่งพา `&str: !FnMut` ได้
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// ชนิดที่ส่งคืนหลังจากใช้ตัวดำเนินการโทร
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// ดำเนินการโทร
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}