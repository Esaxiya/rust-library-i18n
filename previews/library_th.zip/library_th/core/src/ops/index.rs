/// ใช้สำหรับการทำดัชนีการดำเนินการ (`container[index]`) ในบริบทที่ไม่เปลี่ยนรูป
///
/// `container[index]` จริง ๆ แล้วคือน้ำตาลในรูปแบบของ `*container.index(index)` แต่เมื่อใช้เป็นค่าที่ไม่เปลี่ยนรูปเท่านั้น
/// หากมีการร้องขอค่าที่ไม่แน่นอนจะใช้ [`IndexMut`] แทน
/// สิ่งนี้ช่วยให้ได้สิ่งที่ดีเช่น `let value = v[index]` หากประเภทของ `value` ใช้ [`Copy`]
///
/// # Examples
///
/// ตัวอย่างต่อไปนี้ใช้ `Index` บนคอนเทนเนอร์ `NucleotideCount` แบบอ่านอย่างเดียวทำให้สามารถเรียกข้อมูลการนับแต่ละรายการด้วยไวยากรณ์ดัชนี
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// ประเภทที่ส่งคืนหลังจากการสร้างดัชนี
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// ดำเนินการจัดทำดัชนี (`container[index]`)
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// ใช้สำหรับการทำดัชนีการดำเนินการ (`container[index]`) ในบริบทที่เปลี่ยนแปลงได้
///
/// `container[index]` จริง ๆ แล้วคือน้ำตาลที่เป็นประโยคสำหรับ `*container.index_mut(index)` แต่เมื่อใช้เป็นค่าที่เปลี่ยนแปลงได้เท่านั้น
/// หากมีการร้องขอค่าที่ไม่เปลี่ยนรูปจะใช้ [`Index`] trait แทน
/// สิ่งนี้ช่วยให้ได้สิ่งที่ดีเช่น `v[index] = value`
///
/// # Examples
///
/// การใช้งานโครงสร้าง `Balance` ที่ง่ายมากที่มีสองด้านซึ่งแต่ละด้านสามารถจัดทำดัชนีได้อย่างไม่เปลี่ยนแปลงและไม่เปลี่ยนแปลง
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // ในกรณีนี้ `balance[Side::Right]` เป็นน้ำตาลสำหรับ `*balance.index(Side::Right)` เนื่องจากเราอ่าน*`balance[Side::Right]` เท่านั้นไม่ได้เขียน
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // อย่างไรก็ตามในกรณีนี้ `balance[Side::Left]` คือน้ำตาลสำหรับ `*balance.index_mut(Side::Left)` เนื่องจากเรากำลังเขียน `balance[Side::Left]`
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// ดำเนินการ (`container[index]`) การทำดัชนีที่ไม่แน่นอน
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}