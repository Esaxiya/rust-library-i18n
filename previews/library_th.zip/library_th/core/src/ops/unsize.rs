use crate::marker::Unsize;

/// Trait ที่บ่งชี้ว่านี่คือตัวชี้หรือกระดาษห่อหุ้มสำหรับตัวหนึ่งซึ่งสามารถทำการยกเลิกการปรับขนาดบนพอยน์เตอร์ได้
///
/// ดู [DST coercion RFC][dst-coerce] และ [the nomicon entry on coercion][nomicon-coerce] สำหรับรายละเอียดเพิ่มเติม
///
/// สำหรับชนิดตัวชี้ในตัวตัวชี้ไปที่ `T` จะบังคับให้พอยน์เตอร์เป็น `U` ถ้า `T: Unsize<U>` โดยการแปลงจากตัวชี้แบบบางไปเป็นตัวชี้แบบอ้วน
///
/// สำหรับประเภทที่กำหนดเองการบีบบังคับในที่นี้จะทำงานโดยการบังคับ `Foo<T>` ถึง `Foo<U>` โดยมีส่วนของ `CoerceUnsized<Foo<U>> for Foo<T>` อยู่
/// คุณสามารถเขียน im ดังกล่าวได้ก็ต่อเมื่อ `Foo<T>` มีฟิลด์ที่ไม่ใช่ phantomdata เพียงช่องเดียวที่เกี่ยวข้องกับ `T`
/// หากประเภทของฟิลด์นั้นคือ `Bar<T>` ต้องมีการนำ `CoerceUnsized<Bar<U>> for Bar<T>` ไปใช้งาน
/// การบีบบังคับจะทำงานโดยการบังคับฟิลด์ `Bar<T>` ลงใน `Bar<U>` และกรอกข้อมูลในฟิลด์ที่เหลือจาก `Foo<T>` เพื่อสร้าง `Foo<U>`
/// สิ่งนี้จะเจาะลึกลงไปยังฟิลด์ตัวชี้อย่างมีประสิทธิภาพและบังคับใช้
///
/// โดยทั่วไปสำหรับพอยน์เตอร์อัจฉริยะคุณจะใช้ `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` โดยมี `?Sized` ซึ่งเป็นอุปกรณ์เสริมที่ผูกไว้กับ `T` นั้นเอง
/// สำหรับประเภท wrapper ที่ฝัง `T` โดยตรงเช่น `Cell<T>` และ `RefCell<T>` คุณสามารถใช้ `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` ได้โดยตรง
///
/// สิ่งนี้จะช่วยให้การบีบบังคับประเภทต่างๆเช่น `Cell<Box<T>>` ทำงานได้
///
/// [`Unsize`][unsize] ใช้เพื่อทำเครื่องหมายประเภทที่สามารถบีบบังคับ DST ได้หากอยู่หลังพอยน์เตอร์คอมไพเลอร์จะดำเนินการโดยอัตโนมัติ
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * มุด U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* มุด U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// ใช้เพื่อความปลอดภัยของวัตถุเพื่อตรวจสอบว่าสามารถส่งชนิดตัวรับของเมธอดได้
///
/// ตัวอย่างการใช้งาน trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* มุด U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}