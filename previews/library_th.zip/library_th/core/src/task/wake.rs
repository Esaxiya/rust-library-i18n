#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` อนุญาตให้ตัวดำเนินการของตัวดำเนินการงานสร้าง [`Waker`] ซึ่งจัดเตรียมลักษณะการทำงานที่กำหนดเอง
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// ประกอบด้วยตัวชี้ข้อมูลและ [virtual function pointer table (vtable)][vtable] ที่ปรับแต่งลักษณะการทำงานของ `RawWaker`
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// ตัวชี้ข้อมูลซึ่งสามารถใช้เพื่อจัดเก็บข้อมูลตามอำเภอใจตามที่ผู้ปฏิบัติการต้องการ
    /// ซึ่งอาจเป็นเช่น
    /// ตัวชี้ชนิดลบไปยัง `Arc` ที่เชื่อมโยงกับงาน
    /// ค่าของฟิลด์นี้จะถูกส่งผ่านไปยังฟังก์ชันทั้งหมดที่เป็นส่วนหนึ่งของ vtable เป็นพารามิเตอร์แรก
    ///
    data: *const (),
    /// ตารางตัวชี้ฟังก์ชันเสมือนที่กำหนดลักษณะการทำงานของ waker นี้เอง
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// สร้าง `RawWaker` ใหม่จากตัวชี้ `data` และ `vtable` ที่ให้มา
    ///
    /// ตัวชี้ `data` สามารถใช้เพื่อจัดเก็บข้อมูลโดยพลการตามที่ผู้ปฏิบัติการต้องการซึ่งอาจเป็นเช่น
    /// ตัวชี้ชนิดลบไปยัง `Arc` ที่เชื่อมโยงกับงาน
    /// ค่าของตัวชี้นี้จะถูกส่งผ่านไปยังฟังก์ชันทั้งหมดที่เป็นส่วนหนึ่งของ `vtable` เป็นพารามิเตอร์แรก
    ///
    /// `vtable` กำหนดลักษณะการทำงานของ `Waker` ซึ่งสร้างขึ้นจาก `RawWaker`
    /// สำหรับแต่ละการดำเนินการบน `Waker` ฟังก์ชันที่เกี่ยวข้องใน `vtable` ของ `RawWaker` ที่อยู่ภายใต้จะถูกเรียกใช้
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// ตารางตัวชี้ฟังก์ชันเสมือน (vtable) ที่ระบุลักษณะการทำงานของ [`RawWaker`]
///
/// ตัวชี้ที่ส่งผ่านไปยังฟังก์ชันทั้งหมดภายใน vtable คือตัวชี้ `data` จากวัตถุ [`RawWaker`] ที่ล้อมรอบ
///
/// ฟังก์ชันภายในโครงสร้างนี้มีไว้เพื่อเรียกใช้บนพอยน์เตอร์ `data` ของอ็อบเจ็กต์ [`RawWaker`] ที่สร้างอย่างถูกต้องจากภายในการใช้งาน [`RawWaker`]
/// การเรียกใช้ฟังก์ชันที่มีอยู่อย่างใดอย่างหนึ่งโดยใช้ตัวชี้ `data` อื่น ๆ จะทำให้เกิดพฤติกรรมที่ไม่ได้กำหนดไว้
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// ฟังก์ชันนี้จะถูกเรียกใช้เมื่อ [`RawWaker`] ถูกโคลนเช่นเมื่อ [`Waker`] ที่เก็บ [`RawWaker`] ถูกโคลน
    ///
    /// การใช้ฟังก์ชันนี้จะต้องคงไว้ซึ่งทรัพยากรทั้งหมดที่จำเป็นสำหรับอินสแตนซ์เพิ่มเติมของ [`RawWaker`] และงานที่เกี่ยวข้อง
    /// การเรียกใช้ `wake` บน [`RawWaker`] ที่เป็นผลลัพธ์ควรทำให้เกิดการปลุกของงานเดียวกันกับที่ [`RawWaker`] ดั้งเดิมจะถูกปลุกขึ้นมา
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// ฟังก์ชันนี้จะถูกเรียกใช้เมื่อ `wake` ถูกเรียกบน [`Waker`]
    /// มันต้องปลุกงานที่เกี่ยวข้องกับ [`RawWaker`] นี้
    ///
    /// การนำฟังก์ชันนี้ไปใช้ต้องแน่ใจว่าได้ปล่อยทรัพยากรใด ๆ ที่เกี่ยวข้องกับอินสแตนซ์ของ [`RawWaker`] และงานที่เกี่ยวข้อง
    ///
    ///
    wake: unsafe fn(*const ()),

    /// ฟังก์ชันนี้จะถูกเรียกใช้เมื่อ `wake_by_ref` ถูกเรียกบน [`Waker`]
    /// มันต้องปลุกงานที่เกี่ยวข้องกับ [`RawWaker`] นี้
    ///
    /// ฟังก์ชันนี้คล้ายกับ `wake` แต่ต้องไม่ใช้ตัวชี้ข้อมูลที่ให้มา
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// ฟังก์ชันนี้จะถูกเรียกเมื่อ [`RawWaker`] หลุด
    ///
    /// การนำฟังก์ชันนี้ไปใช้ต้องแน่ใจว่าได้ปล่อยทรัพยากรใด ๆ ที่เกี่ยวข้องกับอินสแตนซ์ของ [`RawWaker`] และงานที่เกี่ยวข้อง
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// สร้าง `RawWakerVTable` ใหม่จากฟังก์ชัน `clone`, `wake`, `wake_by_ref` และ `drop` ที่ให้มา
    ///
    /// # `clone`
    ///
    /// ฟังก์ชันนี้จะถูกเรียกใช้เมื่อ [`RawWaker`] ถูกโคลนเช่นเมื่อ [`Waker`] ที่เก็บ [`RawWaker`] ถูกโคลน
    ///
    /// การใช้ฟังก์ชันนี้จะต้องคงไว้ซึ่งทรัพยากรทั้งหมดที่จำเป็นสำหรับอินสแตนซ์เพิ่มเติมของ [`RawWaker`] และงานที่เกี่ยวข้อง
    /// การเรียกใช้ `wake` บน [`RawWaker`] ที่เป็นผลลัพธ์ควรทำให้เกิดการปลุกของงานเดียวกันกับที่ [`RawWaker`] ดั้งเดิมจะถูกปลุกขึ้นมา
    ///
    /// # `wake`
    ///
    /// ฟังก์ชันนี้จะถูกเรียกใช้เมื่อ `wake` ถูกเรียกบน [`Waker`]
    /// มันต้องปลุกงานที่เกี่ยวข้องกับ [`RawWaker`] นี้
    ///
    /// การนำฟังก์ชันนี้ไปใช้ต้องแน่ใจว่าได้ปล่อยทรัพยากรใด ๆ ที่เกี่ยวข้องกับอินสแตนซ์ของ [`RawWaker`] และงานที่เกี่ยวข้อง
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// ฟังก์ชันนี้จะถูกเรียกใช้เมื่อ `wake_by_ref` ถูกเรียกบน [`Waker`]
    /// มันต้องปลุกงานที่เกี่ยวข้องกับ [`RawWaker`] นี้
    ///
    /// ฟังก์ชันนี้คล้ายกับ `wake` แต่ต้องไม่ใช้ตัวชี้ข้อมูลที่ให้มา
    ///
    /// # `drop`
    ///
    /// ฟังก์ชันนี้จะถูกเรียกเมื่อ [`RawWaker`] หลุด
    ///
    /// การนำฟังก์ชันนี้ไปใช้ต้องแน่ใจว่าได้ปล่อยทรัพยากรใด ๆ ที่เกี่ยวข้องกับอินสแตนซ์ของ [`RawWaker`] และงานที่เกี่ยวข้อง
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` ของงานอะซิงโครนัส
///
/// ปัจจุบัน `Context` ทำหน้าที่ให้การเข้าถึง `&Waker` เท่านั้นซึ่งสามารถใช้เพื่อปลุกงานปัจจุบันได้
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // ตรวจสอบให้แน่ใจว่าเราพิสูจน์ future ต่อการเปลี่ยนแปลงความแปรปรวนโดยการบังคับให้อายุการใช้งานไม่แปรผัน (อายุการใช้งานตำแหน่งอาร์กิวเมนต์ไม่แน่นอนในขณะที่อายุการใช้งานของตำแหน่งผลตอบแทนจะแปรปรวน)
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// สร้าง `Context` ใหม่จาก `&Waker`
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// ส่งคืนการอ้างอิงไปยัง `Waker` สำหรับงานปัจจุบัน
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` เป็นตัวจัดการสำหรับการปลุกงานโดยแจ้งให้ผู้ปฏิบัติการทราบว่าพร้อมที่จะรัน
///
/// หมายเลขอ้างอิงนี้ห่อหุ้มอินสแตนซ์ [`RawWaker`] ซึ่งกำหนดพฤติกรรมการปลุกเฉพาะผู้ดำเนินการ
///
///
/// ใช้ [`Clone`], [`Send`] และ [`Sync`]
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// ปลุกงานที่เกี่ยวข้องกับ `Waker` นี้
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // การโทรปลุกจริงถูกมอบหมายผ่านการเรียกใช้ฟังก์ชันเสมือนไปยังการนำไปใช้งานซึ่งกำหนดโดยตัวดำเนินการ
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // อย่าเรียก `drop`-Waker จะถูกใช้โดย `wake`
        crate::mem::forget(self);

        // ความปลอดภัย: ปลอดภัยเพราะ `Waker::from_raw` เป็นวิธีเดียว
        // เพื่อเริ่มต้น `wake` และ `data` โดยต้องให้ผู้ใช้รับทราบว่าสัญญาของ `RawWaker` ถูกยึดไว้
        //
        unsafe { (wake)(data) };
    }

    /// ปลุกงานที่เกี่ยวข้องกับ `Waker` นี้โดยไม่ต้องใช้ `Waker`
    ///
    /// สิ่งนี้คล้ายกับ `wake` แต่อาจมีประสิทธิภาพน้อยกว่าเล็กน้อยในกรณีที่มี `Waker` ที่เป็นเจ้าของอยู่
    /// วิธีนี้ควรใช้ในการเรียก `waker.clone().wake()`
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // การโทรปลุกจริงถูกมอบหมายผ่านการเรียกใช้ฟังก์ชันเสมือนไปยังการนำไปใช้งานซึ่งกำหนดโดยตัวดำเนินการ
        //

        // ความปลอดภัย: ดู `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// ส่งคืน `true` หาก `Waker` นี้และ `Waker` อื่นปลุกงานเดียวกัน
    ///
    /// ฟังก์ชั่นนี้ทำงานบนพื้นฐานความพยายามอย่างเต็มที่และอาจส่งคืนเท็จแม้ว่า Waker จะปลุกงานเดียวกันก็ตาม
    /// อย่างไรก็ตามหากฟังก์ชันนี้คืนค่า `true` รับรองว่า "Waker" จะปลุกงานเดียวกัน
    ///
    /// ฟังก์ชันนี้ใช้เพื่อวัตถุประสงค์ในการเพิ่มประสิทธิภาพเป็นหลัก
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// สร้าง `Waker` ใหม่จาก [`RawWaker`]
    ///
    /// ลักษณะการทำงานของ `Waker` ที่ส่งคืนจะไม่ได้รับการกำหนดหากสัญญาที่กำหนดไว้ในเอกสารของ [`RawWaker`] และ [`RawWakerVTable`]
    ///
    /// ดังนั้นวิธีนี้จึงไม่ปลอดภัย
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // ความปลอดภัย: ปลอดภัยเพราะ `Waker::from_raw` เป็นวิธีเดียว
            // เพื่อเริ่มต้น `clone` และ `data` โดยต้องให้ผู้ใช้รับทราบว่าสัญญาของ [`RawWaker`] ถูกยึดไว้
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // ความปลอดภัย: ปลอดภัยเพราะ `Waker::from_raw` เป็นวิธีเดียว
        // เพื่อเริ่มต้น `drop` และ `data` โดยต้องให้ผู้ใช้รับทราบว่าสัญญาของ `RawWaker` ถูกยึดไว้
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}