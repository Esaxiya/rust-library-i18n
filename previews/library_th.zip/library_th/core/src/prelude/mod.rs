//! libcore prelude
//!
//! โมดูลนี้มีไว้สำหรับผู้ใช้ libcore ที่ไม่เชื่อมโยงกับ libstd ด้วย
//! โมดูลนี้จะนำเข้าโดยค่าเริ่มต้นเมื่อใช้ `#![no_std]` ในลักษณะเดียวกับ prelude ของไลบรารีมาตรฐาน
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// รุ่นปี 2015 ของแกน prelude
///
/// ดู [module-level documentation](self) เพิ่มเติม
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// รุ่น 2018 ของแกน prelude
///
/// ดู [module-level documentation](self) เพิ่มเติม
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// รุ่น 2021 ของแกน prelude
///
/// ดู [module-level documentation](self) เพิ่มเติม
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: เพิ่มสิ่งอื่น ๆ
}