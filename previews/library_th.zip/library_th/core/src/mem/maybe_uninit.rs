use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// ประเภท Wrapper เพื่อสร้างอินสแตนซ์ `T` ที่ไม่ได้กำหนดค่าเริ่มต้น
///
/// # ค่าเริ่มต้นไม่แปรผัน
///
/// โดยทั่วไปคอมไพเลอร์จะถือว่าตัวแปรได้รับการเตรียมใช้งานอย่างถูกต้องตามข้อกำหนดของชนิดของตัวแปรตัวอย่างเช่นตัวแปรประเภทการอ้างอิงต้องอยู่ในแนวเดียวกันและไม่ใช่ NULL
/// นี่คือค่าคงที่ที่ต้อง *เสมอ* ได้รับการรักษาแม้ว่าจะอยู่ในรหัสที่ไม่ปลอดภัยก็ตาม
/// ด้วยเหตุนี้การเริ่มต้นตัวแปรประเภทการอ้างอิงเป็นศูนย์ทำให้ [undefined behavior][ub] ทันทีไม่ว่าการอ้างอิงนั้นจะเคยใช้เพื่อเข้าถึงหน่วยความจำ:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // พฤติกรรมที่ไม่ได้กำหนด!⚠️
/// // รหัสเทียบเท่ากับ `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // พฤติกรรมที่ไม่ได้กำหนด!⚠️
/// ```
///
/// สิ่งนี้ถูกใช้โดยคอมไพลเลอร์สำหรับการเพิ่มประสิทธิภาพต่างๆเช่นการหลีกเลี่ยงการตรวจสอบเวลาทำงานและการปรับรูปแบบ `enum`
///
/// ในทำนองเดียวกันหน่วยความจำที่ไม่ได้เริ่มต้นทั้งหมดอาจมีเนื้อหาใด ๆ ในขณะที่ `bool` ต้องเป็น `true` หรือ `false` เสมอดังนั้นการสร้าง `bool` ที่ไม่ได้กำหนดค่าเริ่มต้นจึงเป็นพฤติกรรมที่ไม่ได้กำหนดไว้:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // พฤติกรรมที่ไม่ได้กำหนด!⚠️
/// // รหัสเทียบเท่ากับ `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // พฤติกรรมที่ไม่ได้กำหนด!⚠️
/// ```
///
/// ยิ่งไปกว่านั้นหน่วยความจำที่ไม่ได้กำหนดค่าเริ่มต้นยังมีความพิเศษตรงที่ไม่มีค่าคงที่ ("fixed" หมายถึง "it won't change without being written to")การอ่านไบต์ที่ไม่ได้เริ่มต้นเดียวกันหลาย ๆ ครั้งสามารถให้ผลลัพธ์ที่แตกต่างกันได้
/// สิ่งนี้ทำให้พฤติกรรมที่ไม่ได้กำหนดให้มีข้อมูลที่ไม่ได้กำหนดค่าเริ่มต้นในตัวแปรแม้ว่าตัวแปรนั้นจะมีประเภทจำนวนเต็มซึ่งมิฉะนั้นจะสามารถเก็บรูปแบบบิต * คงที่ได้:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // พฤติกรรมที่ไม่ได้กำหนด!⚠️
/// // รหัสเทียบเท่ากับ `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // พฤติกรรมที่ไม่ได้กำหนด!⚠️
/// ```
/// (โปรดสังเกตว่ากฎเกี่ยวกับจำนวนเต็มที่ไม่ได้เริ่มต้นยังไม่ได้รับการสรุป แต่ขอแนะนำให้หลีกเลี่ยงจนกว่าจะถึงเวลานั้น)
///
/// ยิ่งไปกว่านั้นโปรดจำไว้ว่าประเภทส่วนใหญ่มีค่าคงที่เพิ่มเติมนอกเหนือจากการพิจารณาเริ่มต้นในระดับประเภทเท่านั้น
/// ตัวอย่างเช่น [`Vec<T>`] ที่กำหนดค่าเริ่มต้น "1" ถือเป็นการเริ่มต้น (ภายใต้การนำไปใช้งานในปัจจุบันสิ่งนี้ไม่ถือเป็นการรับประกันความเสถียร) เนื่องจากข้อกำหนดเดียวที่คอมไพลเลอร์ทราบคือตัวชี้ข้อมูลต้องไม่เป็นค่าว่าง
/// การสร้าง `Vec<T>` ดังกล่าวไม่ก่อให้เกิดพฤติกรรมที่ไม่ได้กำหนด *ทันที* แต่จะทำให้เกิดพฤติกรรมที่ไม่ได้กำหนดด้วยการดำเนินการที่ปลอดภัยที่สุด (รวมถึงการทิ้ง)
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` ทำหน้าที่เปิดใช้งานรหัสที่ไม่ปลอดภัยเพื่อจัดการกับข้อมูลที่ไม่ได้กำหนดค่าเริ่มต้น
/// เป็นสัญญาณไปยังคอมไพเลอร์ที่ระบุว่าข้อมูลที่นี่อาจ *ไม่* ถูกเตรียมใช้งาน:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // สร้างข้อมูลอ้างอิงที่ไม่ได้กำหนดค่าเริ่มต้นอย่างชัดเจน
/// // คอมไพเลอร์รู้ว่าข้อมูลภายใน `MaybeUninit<T>` อาจไม่ถูกต้องและด้วยเหตุนี้จึงไม่ใช่ UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // ตั้งเป็นค่าที่ถูกต้อง
/// unsafe { x.as_mut_ptr().write(&0); }
/// // แยกข้อมูลเริ่มต้น-อนุญาตเฉพาะ *หลังจาก* เริ่มต้น `x` อย่างถูกต้อง!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// จากนั้นคอมไพเลอร์จะรู้ที่จะไม่ตั้งสมมติฐานที่ไม่ถูกต้องหรือการปรับให้เหมาะสมกับโค้ดนี้
///
/// คุณสามารถคิดว่า `MaybeUninit<T>` เหมือนกับ `Option<T>` แต่ไม่มีการติดตามเวลาทำงานใด ๆ และไม่มีการตรวจสอบความปลอดภัยใด ๆ
///
/// ## out-pointers
///
/// คุณสามารถใช้ `MaybeUninit<T>` เพื่อใช้ "out-pointers": แทนที่จะส่งคืนข้อมูลจากฟังก์ชันให้ส่งตัวชี้ไปยังหน่วยความจำ (uninitialized) บางส่วนเพื่อใส่ผลลัพธ์ลงไป
/// สิ่งนี้จะมีประโยชน์เมื่อเป็นสิ่งสำคัญสำหรับผู้โทรในการควบคุมวิธีการจัดเก็บผลลัพธ์ของหน่วยความจำในการจัดสรรและคุณต้องการหลีกเลี่ยงการเคลื่อนไหวที่ไม่จำเป็น
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` ไม่ทิ้งเนื้อหาเก่าซึ่งเป็นสิ่งสำคัญ
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // ตอนนี้เรารู้แล้วว่า `v` เริ่มต้นแล้ว!นอกจากนี้ยังช่วยให้แน่ใจว่า vector หลุดอย่างถูกต้อง
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## การเริ่มต้นองค์ประกอบอาร์เรย์โดยองค์ประกอบ
///
/// `MaybeUninit<T>` สามารถใช้เพื่อเริ่มต้นองค์ประกอบอาร์เรย์ขนาดใหญ่โดยองค์ประกอบ:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // สร้างอาร์เรย์ที่ไม่ได้กำหนดค่าเริ่มต้นของ `MaybeUninit`
///     // `assume_init` ปลอดภัยเนื่องจากประเภทที่เราอ้างว่าได้เริ่มต้นที่นี่คือกลุ่มของ `MaybeUninit 'ซึ่งไม่จำเป็นต้องมีการเริ่มต้น
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // การทิ้ง `MaybeUninit` ไม่ได้ทำอะไรเลย
///     // ดังนั้นการใช้การกำหนดตัวชี้ดิบแทน `ptr::write` จึงไม่ทำให้ค่าที่ยังไม่ได้กำหนดค่าเริ่มต้นเก่าหลุดออกไป
/////
///     // นอกจากนี้หากมี panic ในระหว่างลูปนี้แสดงว่าเรามีหน่วยความจำรั่ว แต่ไม่มีปัญหาด้านความปลอดภัยของหน่วยความจำ
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // ทุกอย่างเริ่มต้น
///     // แปลงอาร์เรย์เป็นชนิดเริ่มต้น
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// คุณยังสามารถทำงานกับอาร์เรย์เริ่มต้นบางส่วนซึ่งพบได้ในโครงสร้างข้อมูลระดับต่ำ
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // สร้างอาร์เรย์ที่ไม่ได้กำหนดค่าเริ่มต้นของ `MaybeUninit`
/// // `assume_init` ปลอดภัยเนื่องจากประเภทที่เราอ้างว่าได้เริ่มต้นที่นี่คือกลุ่มของ `MaybeUninit 'ซึ่งไม่จำเป็นต้องมีการเริ่มต้น
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // นับจำนวนองค์ประกอบที่เรากำหนด
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // สำหรับแต่ละรายการในอาร์เรย์ให้ดรอปหากเราจัดสรรไว้
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## การเริ่มต้นโครงสร้างแบบฟิลด์ต่อฟิลด์
///
/// คุณสามารถใช้ `MaybeUninit<T>` และมาโคร [`std::ptr::addr_of_mut`] เพื่อเริ่มต้นฟิลด์โครงสร้างตามฟิลด์:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // การเริ่มต้นฟิลด์ `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // การเริ่มต้นฟิลด์ `list` หากมี panic ที่นี่แสดงว่า `String` ในฟิลด์ `name` รั่วไหล
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // ฟิลด์ทั้งหมดเริ่มต้นแล้วดังนั้นเราจึงเรียก `assume_init` เพื่อเริ่มต้น Foo
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` รับประกันว่าจะมีขนาดการจัดตำแหน่งและ ABI เท่ากันกับ `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// อย่างไรก็ตามโปรดจำไว้ว่าประเภท *ที่มี* a `MaybeUninit<T>` ไม่จำเป็นต้องเป็นเลย์เอาต์เดียวกัน Rust ไม่รับประกันโดยทั่วไปว่าฟิลด์ของ `Foo<T>` มีลำดับเดียวกันกับ `Foo<U>` แม้ว่า `T` และ `U` จะมีขนาดและการจัดตำแหน่งเดียวกันก็ตาม
///
/// นอกจากนี้เนื่องจากค่าบิตใด ๆ ถูกต้องสำหรับ `MaybeUninit<T>` คอมไพเลอร์จึงไม่สามารถใช้การเพิ่มประสิทธิภาพ non-zero/niche-filling ได้ซึ่งอาจส่งผลให้มีขนาดใหญ่ขึ้น:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// ถ้า `T` เป็น FFI-safe ดังนั้น `MaybeUninit<T>` ก็เช่นกัน
///
/// ในขณะที่ `MaybeUninit` คือ `#[repr(transparent)]` (ระบุว่ารับประกันขนาดการจัดตำแหน่งและ ABI เดียวกันกับ `T`) สิ่งนี้จะ *ไม่* เปลี่ยนแปลงคำเตือนใด ๆ ก่อนหน้านี้
/// `Option<T>` และ `Option<MaybeUninit<T>>` อาจยังคงมีขนาดแตกต่างกันและประเภทที่มีฟิลด์ประเภท `T` อาจถูกจัดวาง (และขนาด) แตกต่างจากกรณีที่ฟิลด์นั้นเป็น `MaybeUninit<T>`
/// `MaybeUninit` เป็นประเภทสหภาพและ `#[repr(transparent)]` บนสหภาพแรงงานไม่เสถียร (ดู [the tracking issue](https://github.com/rust-lang/rust/issues/60405))
/// เมื่อเวลาผ่านไปการรับประกันที่แน่นอนของ `#[repr(transparent)]` สำหรับสหภาพแรงงานอาจมีการพัฒนาและ `MaybeUninit` อาจยังคงเป็น `#[repr(transparent)]` หรือไม่ก็ได้
/// ที่กล่าวว่า `MaybeUninit<T>` จะ *รับประกัน* เสมอ * ว่ามีขนาดการจัดตำแหน่งและ ABI เท่ากันกับ `T` เป็นเพียงวิธีที่ `MaybeUninit` ใช้ซึ่งรับประกันว่าอาจมีการพัฒนาขึ้น
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// แลงไอเทมเพื่อให้เราสามารถห่อแบบอื่น ๆ ได้สิ่งนี้มีประโยชน์สำหรับเครื่องกำเนิดไฟฟ้า
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // ไม่เรียก `T::clone()` เราไม่สามารถรู้ได้ว่าเราได้รับการเตรียมใช้งานเพียงพอสำหรับสิ่งนั้นหรือไม่
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// สร้าง `MaybeUninit<T>` ใหม่ที่เริ่มต้นด้วยค่าที่กำหนด
    /// ปลอดภัยที่จะเรียก [`assume_init`] ตามค่าส่งคืนของฟังก์ชันนี้
    ///
    /// โปรดทราบว่าการวาง `MaybeUninit<T>` จะไม่เรียกดรอปโค้ดของ "T"
    /// เป็นความรับผิดชอบของคุณที่จะต้องตรวจสอบให้แน่ใจว่า `T` หลุดหากมีการเริ่มต้น
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// สร้าง `MaybeUninit<T>` ใหม่ในสถานะที่ไม่ได้กำหนดค่าเริ่มต้น
    ///
    /// โปรดทราบว่าการวาง `MaybeUninit<T>` จะไม่เรียกดรอปโค้ดของ "T"
    /// เป็นความรับผิดชอบของคุณที่จะต้องตรวจสอบให้แน่ใจว่า `T` หลุดหากมีการเริ่มต้น
    ///
    /// ดู [type-level documentation][MaybeUninit] สำหรับตัวอย่างบางส่วน
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// สร้างอาร์เรย์ของรายการ `MaybeUninit<T>` ใหม่ในสถานะที่ไม่ได้กำหนดค่าเริ่มต้น
    ///
    /// Note: ในเวอร์ชัน future Rust วิธีนี้อาจไม่จำเป็นเมื่อไวยากรณ์ตัวอักษรอาร์เรย์อนุญาต [repeating const expressions](https://github.com/rust-lang/rust/issues/49147)
    ///
    /// ตัวอย่างด้านล่างสามารถใช้ `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` ได้
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// ส่งคืนชิ้นข้อมูล (อาจเล็กกว่า) ที่อ่านจริง
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // ความปลอดภัย: `[MaybeUninit<_>; LEN]` ที่ไม่ได้เริ่มต้นใช้งานได้
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// สร้าง `MaybeUninit<T>` ใหม่ในสถานะที่ไม่ได้กำหนดค่าเริ่มต้นโดยที่หน่วยความจำเต็มไปด้วย `0` ไบต์ขึ้นอยู่กับ `T` ว่าได้ทำการเริ่มต้นที่เหมาะสมแล้วหรือยัง
    ///
    /// ตัวอย่างเช่น `MaybeUninit<usize>::zeroed()` ถูกเตรียมใช้งาน แต่ `MaybeUninit<&'static i32>::zeroed()` ไม่ใช่เพราะการอ้างอิงต้องไม่เป็นโมฆะ
    ///
    /// โปรดทราบว่าการวาง `MaybeUninit<T>` จะไม่เรียกดรอปโค้ดของ "T"
    /// เป็นความรับผิดชอบของคุณที่จะต้องตรวจสอบให้แน่ใจว่า `T` หลุดหากมีการเริ่มต้น
    ///
    /// # Example
    ///
    /// การใช้ฟังก์ชันนี้อย่างถูกต้อง: การเริ่มต้นโครงสร้างด้วยศูนย์โดยที่เขตข้อมูลทั้งหมดของโครงสร้างสามารถถือรูปแบบบิต 0 เป็นค่าที่ถูกต้องได้
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *ไม่ถูกต้อง* การใช้ฟังก์ชันนี้: เรียก `x.zeroed().assume_init()` เมื่อ `0` ไม่ใช่รูปแบบบิตที่ถูกต้องสำหรับประเภท:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // ภายในคู่เราสร้าง `NotZero` ที่ไม่มีการเลือกปฏิบัติที่ถูกต้อง
    /// // นี่คือพฤติกรรมที่ไม่ได้กำหนด⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // ความปลอดภัย: `u.as_mut_ptr()` ชี้ไปยังหน่วยความจำที่จัดสรร
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// ตั้งค่าของ `MaybeUninit<T>`
    /// สิ่งนี้จะเขียนทับค่าก่อนหน้านี้โดยไม่ทิ้งดังนั้นระวังอย่าใช้ค่านี้ซ้ำสองครั้งเว้นแต่คุณต้องการข้ามการรันตัวทำลาย
    ///
    /// เพื่อความสะดวกของคุณสิ่งนี้จะส่งคืนการอ้างอิงที่ไม่แน่นอนไปยังเนื้อหา (เริ่มต้นอย่างปลอดภัยแล้ว) ของ `self`
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // ความปลอดภัย: เราเพิ่งเริ่มต้นค่านี้
        unsafe { self.assume_init_mut() }
    }

    /// รับตัวชี้ไปยังค่าที่มีอยู่
    /// การอ่านจากตัวชี้นี้หรือเปลี่ยนเป็นการอ้างอิงเป็นพฤติกรรมที่ไม่ได้กำหนดเว้นแต่ `MaybeUninit<T>` จะเริ่มต้น
    /// การเขียนลงในหน่วยความจำที่ตัวชี้ (non-transitively) ชี้ไปนั้นเป็นพฤติกรรมที่ไม่ได้กำหนดไว้ (ยกเว้นภายใน `UnsafeCell<T>`)
    ///
    /// # Examples
    ///
    /// การใช้วิธีนี้อย่างถูกต้อง:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // สร้างการอ้างอิงลงใน `MaybeUninit<T>` ไม่เป็นไรเพราะเรากำหนดค่าเริ่มต้น
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *ไม่ถูกต้อง* การใช้วิธีนี้:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // เราได้สร้างการอ้างอิงถึง vector ที่ไม่ได้เริ่มต้น!นี่คือพฤติกรรมที่ไม่ได้กำหนด⚠️
    /// ```
    ///
    /// (โปรดสังเกตว่ากฎเกี่ยวกับการอ้างอิงถึงข้อมูลที่ไม่ได้กำหนดค่าเริ่มต้นยังไม่ได้รับการสรุป แต่ขอแนะนำให้หลีกเลี่ยงจนกว่าจะถึงเวลาดังกล่าว)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` และ `ManuallyDrop` เป็น `repr(transparent)` ทั้งคู่เพื่อให้เราสามารถส่งตัวชี้ได้
        self as *const _ as *const T
    }

    /// รับตัวชี้ที่ไม่แน่นอนของค่าที่มีอยู่
    /// การอ่านจากตัวชี้นี้หรือเปลี่ยนเป็นการอ้างอิงเป็นพฤติกรรมที่ไม่ได้กำหนดเว้นแต่ `MaybeUninit<T>` จะเริ่มต้น
    ///
    /// # Examples
    ///
    /// การใช้วิธีนี้อย่างถูกต้อง:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // สร้างการอ้างอิงลงใน `MaybeUninit<Vec<u32>>`
    /// // ไม่เป็นไรเพราะเรากำหนดค่าเริ่มต้น
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *ไม่ถูกต้อง* การใช้วิธีนี้:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // เราได้สร้างการอ้างอิงถึง vector ที่ไม่ได้เริ่มต้น!นี่คือพฤติกรรมที่ไม่ได้กำหนด⚠️
    /// ```
    ///
    /// (โปรดสังเกตว่ากฎเกี่ยวกับการอ้างอิงถึงข้อมูลที่ไม่ได้กำหนดค่าเริ่มต้นยังไม่ได้รับการสรุป แต่ขอแนะนำให้หลีกเลี่ยงจนกว่าจะถึงเวลาดังกล่าว)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` และ `ManuallyDrop` เป็น `repr(transparent)` ทั้งคู่เพื่อให้เราสามารถส่งตัวชี้ได้
        self as *mut _ as *mut T
    }

    /// แยกค่าจากคอนเทนเนอร์ `MaybeUninit<T>` นี่เป็นวิธีที่ยอดเยี่ยมในการตรวจสอบให้แน่ใจว่าข้อมูลจะตกหล่นเนื่องจาก `T` ที่ได้นั้นขึ้นอยู่กับการจัดการการดร็อปตามปกติ
    ///
    /// # Safety
    ///
    /// ขึ้นอยู่กับผู้เรียกที่จะรับประกันว่า `MaybeUninit<T>` อยู่ในสถานะเริ่มต้นจริงๆการเรียกสิ่งนี้เมื่อเนื้อหายังไม่ได้เริ่มต้นอย่างสมบูรณ์จะทำให้เกิดพฤติกรรมที่ไม่ได้กำหนดในทันที
    /// [type-level documentation][inv] มีข้อมูลเพิ่มเติมเกี่ยวกับค่าคงที่ในการเริ่มต้นนี้
    ///
    /// [inv]: #initialization-invariant
    ///
    /// ยิ่งไปกว่านั้นโปรดจำไว้ว่าประเภทส่วนใหญ่มีค่าคงที่เพิ่มเติมนอกเหนือจากการพิจารณาเริ่มต้นในระดับประเภทเท่านั้น
    /// ตัวอย่างเช่น [`Vec<T>`] ที่กำหนดค่าเริ่มต้น "1" ถือเป็นการเริ่มต้น (ภายใต้การนำไปใช้งานในปัจจุบันสิ่งนี้ไม่ถือเป็นการรับประกันความเสถียร) เนื่องจากข้อกำหนดเดียวที่คอมไพลเลอร์ทราบคือตัวชี้ข้อมูลต้องไม่เป็นค่าว่าง
    ///
    /// การสร้าง `Vec<T>` ดังกล่าวไม่ก่อให้เกิดพฤติกรรมที่ไม่ได้กำหนด *ทันที* แต่จะทำให้เกิดพฤติกรรมที่ไม่ได้กำหนดด้วยการดำเนินการที่ปลอดภัยที่สุด (รวมถึงการทิ้ง)
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// การใช้วิธีนี้อย่างถูกต้อง:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *ไม่ถูกต้อง* การใช้วิธีนี้:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` ยังไม่ได้เริ่มต้นดังนั้นบรรทัดสุดท้ายนี้จึงทำให้เกิดพฤติกรรมที่ไม่ได้กำหนด⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // ความปลอดภัย: ผู้โทรต้องรับประกันว่า `self` เริ่มต้นแล้ว
        // นอกจากนี้ยังหมายความว่า `self` ต้องเป็นตัวแปร `value`
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// อ่านค่าจากคอนเทนเนอร์ `MaybeUninit<T>` `T` ที่ได้จะขึ้นอยู่กับการจัดการการหล่นตามปกติ
    ///
    /// เมื่อใดก็ตามที่เป็นไปได้ควรใช้ [`assume_init`] แทนซึ่งจะป้องกันการทำซ้ำเนื้อหาของ `MaybeUninit<T>`
    ///
    /// # Safety
    ///
    /// ขึ้นอยู่กับผู้เรียกที่จะรับประกันว่า `MaybeUninit<T>` อยู่ในสถานะเริ่มต้นจริงๆการเรียกสิ่งนี้เมื่อเนื้อหายังไม่ได้เริ่มต้นอย่างสมบูรณ์ทำให้เกิดพฤติกรรมที่ไม่ได้กำหนด
    /// [type-level documentation][inv] มีข้อมูลเพิ่มเติมเกี่ยวกับค่าคงที่ในการเริ่มต้นนี้
    ///
    /// ยิ่งไปกว่านั้นสิ่งนี้จะทิ้งสำเนาของข้อมูลเดียวกันไว้เบื้องหลังใน `MaybeUninit<T>`
    /// เมื่อใช้สำเนาข้อมูลหลายชุด (โดยเรียก `assume_init_read` หลายครั้งหรือเรียกครั้งแรก `assume_init_read` แล้ว [`assume_init`]) เป็นความรับผิดชอบของคุณที่จะต้องตรวจสอบให้แน่ใจว่าข้อมูลนั้นอาจซ้ำกัน
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// การใช้วิธีนี้อย่างถูกต้อง:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` คือ `Copy` ดังนั้นเราอาจอ่านหลายครั้ง
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // การทำสำเนาค่า `None` เป็นเรื่องปกติดังนั้นเราอาจอ่านหลายครั้ง
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *ไม่ถูกต้อง* การใช้วิธีนี้:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // ตอนนี้เราได้สร้าง vector ตัวเดียวกันสองชุดซึ่งนำไปสู่การดับเบิ้ลฟรีfree️เมื่อทั้งคู่หลุด!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // ความปลอดภัย: ผู้โทรต้องรับประกันว่า `self` เริ่มต้นแล้ว
        // การอ่านจาก `self.as_ptr()` นั้นปลอดภัยเนื่องจากควรเริ่มต้น `self`
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// วางค่าที่มีอยู่ลงไป
    ///
    /// หากคุณเป็นเจ้าของ `MaybeUninit` คุณสามารถใช้ [`assume_init`] แทนได้
    ///
    /// # Safety
    ///
    /// ขึ้นอยู่กับผู้เรียกที่จะรับประกันว่า `MaybeUninit<T>` อยู่ในสถานะเริ่มต้นจริงๆการเรียกสิ่งนี้เมื่อเนื้อหายังไม่ได้เริ่มต้นอย่างสมบูรณ์ทำให้เกิดพฤติกรรมที่ไม่ได้กำหนด
    ///
    /// ยิ่งไปกว่านั้นต้องเป็นไปตามค่าคงที่เพิ่มเติมทั้งหมดของประเภท `T` เนื่องจากการใช้งาน `Drop` ของ `T` (หรือสมาชิก) อาจขึ้นอยู่กับสิ่งนี้
    /// ตัวอย่างเช่น [`Vec<T>`] ที่กำหนดค่าเริ่มต้น "1" ถือเป็นการเริ่มต้น (ภายใต้การนำไปใช้งานในปัจจุบันสิ่งนี้ไม่ถือเป็นการรับประกันความเสถียร) เนื่องจากข้อกำหนดเดียวที่คอมไพลเลอร์ทราบคือตัวชี้ข้อมูลต้องไม่เป็นค่าว่าง
    ///
    /// การทิ้ง `Vec<T>` ดังกล่าวจะทำให้เกิดพฤติกรรมที่ไม่ได้กำหนด
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // ความปลอดภัย: ผู้โทรจะต้องรับประกันว่า `self` ได้รับการเตรียมใช้งานแล้วและ
        // ตรงตามค่าคงที่ทั้งหมดของ `T`
        // การลดค่าลงในตำแหน่งนั้นปลอดภัยหากเป็นเช่นนั้น
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// รับการอ้างอิงที่ใช้ร่วมกันไปยังค่าที่มีอยู่
    ///
    /// สิ่งนี้จะมีประโยชน์เมื่อเราต้องการเข้าถึง `MaybeUninit` ที่เริ่มต้นแล้ว แต่ไม่มีความเป็นเจ้าของ `MaybeUninit` (ป้องกันการใช้ `.assume_init()`)
    ///
    /// # Safety
    ///
    /// การเรียกสิ่งนี้เมื่อเนื้อหายังไม่ได้เริ่มต้นอย่างสมบูรณ์ทำให้เกิดพฤติกรรมที่ไม่ได้กำหนด: ขึ้นอยู่กับผู้เรียกที่จะรับประกันว่า `MaybeUninit<T>` อยู่ในสถานะเริ่มต้นจริงๆ
    ///
    ///
    /// # Examples
    ///
    /// ### การใช้วิธีนี้อย่างถูกต้อง:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // เริ่มต้น `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // ตอนนี้ทราบว่า `MaybeUninit<_>` ของเราได้รับการเตรียมใช้งานแล้วคุณสามารถสร้างการอ้างอิงที่ใช้ร่วมกันได้:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // ความปลอดภัย: `x` ได้รับการเริ่มต้นแล้ว
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *ไม่ถูกต้อง* การใช้งานของวิธีนี้:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // เราได้สร้างการอ้างอิงถึง vector ที่ไม่ได้เริ่มต้น!นี่คือพฤติกรรมที่ไม่ได้กำหนด⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // เริ่มต้น `MaybeUninit` โดยใช้ `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // การอ้างอิงถึง `Cell<bool>` ที่ไม่ได้เริ่มต้น: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // ความปลอดภัย: ผู้โทรต้องรับประกันว่า `self` เริ่มต้นแล้ว
        // นอกจากนี้ยังหมายความว่า `self` ต้องเป็นตัวแปร `value`
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// รับการอ้างอิง (unique) ที่เปลี่ยนแปลงได้กับค่าที่มีอยู่
    ///
    /// สิ่งนี้จะมีประโยชน์เมื่อเราต้องการเข้าถึง `MaybeUninit` ที่เริ่มต้นแล้ว แต่ไม่มีความเป็นเจ้าของ `MaybeUninit` (ป้องกันการใช้ `.assume_init()`)
    ///
    /// # Safety
    ///
    /// การเรียกสิ่งนี้เมื่อเนื้อหายังไม่ได้เริ่มต้นอย่างสมบูรณ์ทำให้เกิดพฤติกรรมที่ไม่ได้กำหนด: ขึ้นอยู่กับผู้เรียกที่จะรับประกันว่า `MaybeUninit<T>` อยู่ในสถานะเริ่มต้นจริงๆ
    /// ตัวอย่างเช่น `.assume_init_mut()` ไม่สามารถใช้เพื่อเริ่มต้น `MaybeUninit`
    ///
    /// # Examples
    ///
    /// ### การใช้วิธีนี้อย่างถูกต้อง:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// เริ่มต้น *all* ไบต์ของบัฟเฟอร์อินพุต
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // เริ่มต้น `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // ตอนนี้เรารู้แล้วว่า `buf` ถูกเริ่มต้นแล้วดังนั้นเราจึงสามารถ `.assume_init()` ได้
    /// // อย่างไรก็ตามการใช้ `.assume_init()` อาจทริกเกอร์ `memcpy` ของ 2048 ไบต์
    /// // เพื่อยืนยันว่าบัฟเฟอร์ของเราได้รับการเริ่มต้นโดยไม่ต้องคัดลอกเราอัปเกรด `&mut MaybeUninit<[u8; 2048]>` เป็น `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // ความปลอดภัย: `buf` ได้รับการเริ่มต้นแล้ว
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // ตอนนี้เราสามารถใช้ `buf` เป็นสไลซ์ปกติได้แล้ว:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *ไม่ถูกต้อง* การใช้งานของวิธีนี้:
    ///
    /// คุณไม่สามารถใช้ `.assume_init_mut()` เพื่อเริ่มต้นค่า:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // เราได้สร้างการอ้างอิง (mutable) สำหรับ `bool` ที่ไม่ได้เริ่มต้น!
    ///     // นี่คือพฤติกรรมที่ไม่ได้กำหนด⚠️
    /// }
    /// ```
    ///
    /// ตัวอย่างเช่นคุณไม่สามารถ [`Read`] ในบัฟเฟอร์ที่ไม่ได้กำหนดค่าเริ่มต้น:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) อ้างอิงถึงหน่วยความจำที่ไม่ได้เริ่มต้น!
    ///                             // นี่คือพฤติกรรมที่ไม่ได้กำหนด
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// และคุณไม่สามารถใช้การเข้าถึงฟิลด์โดยตรงเพื่อทำการเริ่มต้นทีละฟิลด์ทีละฟิลด์:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) อ้างอิงถึงหน่วยความจำที่ไม่ได้เริ่มต้น!
    ///                  // นี่คือพฤติกรรมที่ไม่ได้กำหนด
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) อ้างอิงถึงหน่วยความจำที่ไม่ได้เริ่มต้น!
    ///                  // นี่คือพฤติกรรมที่ไม่ได้กำหนด
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): ขณะนี้เราอาศัยความไม่ถูกต้องข้างต้นกล่าวคือเรามีการอ้างอิงถึงข้อมูลที่ไม่ได้กำหนดค่าเริ่มต้น (เช่นใน `libcore/fmt/float.rs`)
    // เราควรตัดสินใจขั้นสุดท้ายเกี่ยวกับกฎก่อนการทำให้เสถียร
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // ความปลอดภัย: ผู้โทรต้องรับประกันว่า `self` เริ่มต้นแล้ว
        // นอกจากนี้ยังหมายความว่า `self` ต้องเป็นตัวแปร `value`
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// แยกค่าจากอาร์เรย์ของคอนเทนเนอร์ `MaybeUninit`
    ///
    /// # Safety
    ///
    /// ขึ้นอยู่กับผู้เรียกที่จะรับประกันว่าองค์ประกอบทั้งหมดของอาร์เรย์อยู่ในสถานะเริ่มต้น
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // ความปลอดภัย: ตอนนี้ปลอดภัยเมื่อเราเริ่มต้นองค์ประกอบทั้งหมด
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * ผู้เรียกรับประกันว่าองค์ประกอบทั้งหมดของอาร์เรย์ได้รับการเตรียมใช้งานแล้ว
        // * `MaybeUninit<T>` และ T รับประกันว่าจะมีเค้าโครงเดียวกัน
        // * MaybeUnint ไม่ลดลงดังนั้นจึงไม่มีการดับเบิ้ลฟรีดังนั้นการแปลงจึงปลอดภัย
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// สมมติว่าองค์ประกอบทั้งหมดได้รับการเตรียมใช้งานแล้วให้แยกชิ้นส่วนไป
    ///
    /// # Safety
    ///
    /// ขึ้นอยู่กับผู้เรียกที่จะรับประกันว่าองค์ประกอบ `MaybeUninit<T>` อยู่ในสถานะเริ่มต้นจริงๆ
    ///
    /// การเรียกสิ่งนี้เมื่อเนื้อหายังไม่ได้เริ่มต้นอย่างสมบูรณ์ทำให้เกิดพฤติกรรมที่ไม่ได้กำหนด
    ///
    /// ดู [`assume_init_ref`] สำหรับรายละเอียดและตัวอย่างเพิ่มเติม
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // ความปลอดภัย: การหล่อชิ้นส่วนไปยัง `*const [T]` นั้นปลอดภัยเนื่องจากผู้โทรรับประกันว่า
        // `slice` เริ่มต้นแล้วและ "MaybeUninit" จะมีรูปแบบเดียวกับ `T`
        // ตัวชี้ที่ได้รับนั้นถูกต้องเนื่องจากอ้างถึงหน่วยความจำของ `slice` ซึ่งเป็นข้อมูลอ้างอิงและรับประกันได้ว่าจะถูกต้องสำหรับการอ่าน
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// สมมติว่าองค์ประกอบทั้งหมดได้รับการเตรียมใช้งานแล้วให้ทำการแบ่งส่วนที่เปลี่ยนแปลงได้ให้กับพวกเขา
    ///
    /// # Safety
    ///
    /// ขึ้นอยู่กับผู้เรียกที่จะรับประกันว่าองค์ประกอบ `MaybeUninit<T>` อยู่ในสถานะเริ่มต้นจริงๆ
    ///
    /// การเรียกสิ่งนี้เมื่อเนื้อหายังไม่ได้เริ่มต้นอย่างสมบูรณ์ทำให้เกิดพฤติกรรมที่ไม่ได้กำหนด
    ///
    /// ดู [`assume_init_mut`] สำหรับรายละเอียดและตัวอย่างเพิ่มเติม
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // ความปลอดภัย: คล้ายกับบันทึกความปลอดภัยสำหรับ `slice_get_ref` แต่เรามีไฟล์
        // การอ้างอิงที่ไม่แน่นอนซึ่งรับประกันว่าถูกต้องสำหรับการเขียน
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// รับตัวชี้ไปยังองค์ประกอบแรกของอาร์เรย์
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// รับตัวชี้ที่ไม่สามารถเปลี่ยนแปลงได้ให้กับองค์ประกอบแรกของอาร์เรย์
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// คัดลอกองค์ประกอบจาก `src` ถึง `this` ส่งคืนการอ้างอิงที่ไม่แน่นอนไปยังเนื้อหาที่มีการกำหนดค่าในปัจจุบันของ `this`
    ///
    /// หาก `T` ไม่ใช้ `Copy` ให้ใช้ [`write_slice_cloned`]
    ///
    /// ซึ่งคล้ายกับ [`slice::copy_from_slice`]
    ///
    /// # Panics
    ///
    /// ฟังก์ชันนี้จะเป็น panic หากทั้งสองชิ้นมีความยาวต่างกัน
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // ความปลอดภัย: เราเพิ่งคัดลอกองค์ประกอบของเลนส์ทั้งหมดไปไว้ในความจุสำรอง
    /// // องค์ประกอบ src.len() แรกของ vec ใช้ได้แล้ว
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // ความปลอดภัย: &[T] และ&[MaybeUninit<T>] มีเค้าโครงเดียวกัน
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // ความปลอดภัย: องค์ประกอบที่ถูกต้องเพิ่งถูกคัดลอกไปยัง `this` ดังนั้นจึงถูกทำให้เป็นค่าเริ่มต้น
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// โคลนองค์ประกอบจาก `src` เป็น `this` โดยส่งคืนการอ้างอิงที่ไม่แน่นอนไปยังเนื้อหาที่ไม่ได้กำหนดไว้ในตอนนี้ของ `this`
    /// องค์ประกอบใด ๆ ที่เริ่มต้นแล้วจะไม่ถูกทิ้ง
    ///
    /// หาก `T` ใช้ `Copy` ให้ใช้ [`write_slice`]
    ///
    /// สิ่งนี้คล้ายกับ [`slice::clone_from_slice`] แต่ไม่ทิ้งองค์ประกอบที่มีอยู่
    ///
    /// # Panics
    ///
    /// ฟังก์ชันนี้จะ panic หากทั้งสองชิ้นมีความยาวต่างกันหรือหากใช้ `Clone` panics
    ///
    /// หากมี panic องค์ประกอบที่โคลนแล้วจะถูกทิ้ง
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // ความปลอดภัย: เราเพิ่งโคลนองค์ประกอบทั้งหมดของเลนส์เข้ากับกำลังการผลิตสำรอง
    /// // องค์ประกอบ src.len() แรกของ vec ใช้ได้แล้ว
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // ซึ่งแตกต่างจาก copy_from_slice สิ่งนี้ไม่เรียก clone_from_slice บนชิ้นเนื่องจาก `MaybeUninit<T: Clone>` ไม่ได้ใช้ Clone
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // ความปลอดภัย: ชิ้นส่วนดิบนี้จะมีเฉพาะออบเจ็กต์เริ่มต้นเท่านั้น
                // นั่นเป็นเหตุผลว่าทำไมจึงได้รับอนุญาตให้ทิ้ง
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: เราจำเป็นต้องหั่นให้มีความยาวเท่ากันอย่างชัดเจน
        // สำหรับการตรวจสอบขอบเขตที่จะถูกกำจัดออกไปและเครื่องมือเพิ่มประสิทธิภาพจะสร้าง memcpy สำหรับกรณีง่ายๆ (เช่น T= u8)
        //
        let len = this.len();
        let src = &src[..len];

        // จำเป็นต้องมียาม b/c panic อาจเกิดขึ้นระหว่างการโคลน
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // ความปลอดภัย: องค์ประกอบที่ถูกต้องเพิ่งถูกเขียนลงใน `this` ดังนั้นจึงมีการกำหนดค่าเริ่มต้น
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}