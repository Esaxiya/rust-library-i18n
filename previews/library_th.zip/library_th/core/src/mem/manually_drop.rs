use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// เครื่องห่อหุ้มเพื่อยับยั้งคอมไพเลอร์ไม่ให้เรียกตัวทำลายของ "T" โดยอัตโนมัติ
/// กระดาษห่อนี้มีค่าใช้จ่าย 0
///
/// `ManuallyDrop<T>` ขึ้นอยู่กับการปรับรูปแบบเช่นเดียวกับ `T`
/// ด้วยเหตุนี้จึงไม่มีผล * ต่อสมมติฐานที่คอมไพเลอร์ทำเกี่ยวกับเนื้อหา
/// ตัวอย่างเช่นการเริ่มต้น `ManuallyDrop<&mut T>` ด้วย [`mem::zeroed`] เป็นพฤติกรรมที่ไม่ได้กำหนดไว้
/// หากคุณต้องการจัดการข้อมูลที่ไม่ได้กำหนดค่าเริ่มต้นให้ใช้ [`MaybeUninit<T>`] แทน
///
/// โปรดทราบว่าการเข้าถึงค่าภายใน `ManuallyDrop<T>` นั้นปลอดภัย
/// ซึ่งหมายความว่า `ManuallyDrop<T>` ที่มีเนื้อหาถูกทิ้งจะต้องไม่ถูกเปิดเผยผ่าน API ที่ปลอดภัยสาธารณะ
/// ดังนั้น `ManuallyDrop::drop` จึงไม่ปลอดภัย
///
/// # `ManuallyDrop` และวางคำสั่งซื้อ
///
/// Rust มีค่า [drop order] ที่กำหนดไว้อย่างดี
/// เพื่อให้แน่ใจว่าเขตข้อมูลหรือภาษาท้องถิ่นถูกทิ้งตามลำดับที่กำหนดให้จัดลำดับการประกาศใหม่เพื่อให้ลำดับการส่งโดยนัยเป็นลำดับที่ถูกต้อง
///
/// เป็นไปได้ที่จะใช้ `ManuallyDrop` เพื่อควบคุมลำดับการวาง แต่ต้องใช้รหัสที่ไม่ปลอดภัยและยากที่จะทำอย่างถูกต้องเมื่อมีการคลายตัว
///
///
/// ตัวอย่างเช่นหากคุณต้องการตรวจสอบให้แน่ใจว่าฟิลด์ใดฟิลด์หนึ่งถูกทิ้งหลังจากฟิลด์อื่น ๆ ให้กำหนดฟิลด์สุดท้ายของโครงสร้าง:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` จะถูกทิ้งหลังจาก `children`
///     // Rust รับประกันว่าฟิลด์จะหลุดตามลำดับการประกาศ
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// ตัดค่าที่จะทิ้งด้วยตนเอง
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // คุณยังคงสามารถดำเนินการกับค่านี้ได้อย่างปลอดภัย
    /// assert_eq!(*x, "Hello");
    /// // แต่ `Drop` จะไม่ทำงานที่นี่
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// แยกค่าจากคอนเทนเนอร์ `ManuallyDrop`
    ///
    /// ซึ่งจะช่วยให้ค่าถูกทิ้งอีกครั้ง
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // สิ่งนี้จะลดลง `Box`
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// นำค่าจากคอนเทนเนอร์ `ManuallyDrop<T>` ออก
    ///
    /// วิธีนี้มีไว้สำหรับการย้ายค่าที่ลดลงเป็นหลัก
    /// แทนที่จะใช้ [`ManuallyDrop::drop`] เพื่อวางค่าด้วยตนเองคุณสามารถใช้วิธีนี้เพื่อรับค่าและใช้ตามที่ต้องการได้
    ///
    /// เมื่อใดก็ตามที่เป็นไปได้ควรใช้ [`into_inner`][`ManuallyDrop::into_inner`] แทนซึ่งจะป้องกันการทำซ้ำเนื้อหาของ `ManuallyDrop<T>`
    ///
    ///
    /// # Safety
    ///
    /// ฟังก์ชันนี้จะย้ายค่าที่มีอยู่ออกไปตามความหมายโดยไม่ป้องกันการใช้งานเพิ่มเติมทำให้สถานะของคอนเทนเนอร์นี้ไม่เปลี่ยนแปลง
    /// เป็นความรับผิดชอบของคุณที่จะต้องตรวจสอบให้แน่ใจว่าไม่ได้ใช้ `ManuallyDrop` นี้อีก
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // ความปลอดภัย: เรากำลังอ่านจากข้อมูลอ้างอิงซึ่งรับประกันได้
        // เพื่อให้ถูกต้องสำหรับการอ่าน
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// ลดค่าที่มีอยู่ด้วยตนเองสิ่งนี้เทียบเท่ากับการเรียก [`ptr::drop_in_place`] ด้วยตัวชี้ไปยังค่าที่มีอยู่
    /// ด้วยเหตุนี้เว้นแต่ค่าที่มีอยู่จะเป็นโครงสร้างที่บรรจุแล้วตัวทำลายจะถูกเรียกในตำแหน่งโดยไม่ต้องย้ายค่าดังนั้นจึงสามารถใช้เพื่อดร็อปข้อมูล [pinned] ได้อย่างปลอดภัย
    ///
    /// หากคุณเป็นเจ้าของค่าคุณสามารถใช้ [`ManuallyDrop::into_inner`] แทนได้
    ///
    /// # Safety
    ///
    /// ฟังก์ชันนี้รันตัวทำลายของค่าที่มีอยู่
    /// นอกเหนือจากการเปลี่ยนแปลงที่ทำโดย destructor เองหน่วยความจำจะไม่เปลี่ยนแปลงและตราบเท่าที่คอมไพเลอร์เกี่ยวข้องยังคงมีรูปแบบบิตซึ่งใช้ได้สำหรับประเภท `T`
    ///
    ///
    /// อย่างไรก็ตามค่า "zombie" นี้ไม่ควรสัมผัสกับรหัสปลอดภัยและไม่ควรเรียกใช้ฟังก์ชันนี้มากกว่าหนึ่งครั้ง
    /// หากต้องการใช้ค่าหลังจากทิ้งหรือปล่อยค่าหลายครั้งอาจทำให้เกิดพฤติกรรมที่ไม่ได้กำหนด (ขึ้นอยู่กับสิ่งที่ `drop` ทำ)
    /// โดยปกติระบบประเภทนี้จะถูกป้องกัน แต่ผู้ใช้ `ManuallyDrop` ต้องสนับสนุนการรับประกันเหล่านั้นโดยไม่ได้รับความช่วยเหลือจากคอมไพเลอร์
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // ความปลอดภัย: เราลดค่าที่ชี้ไปโดยการอ้างอิงที่ไม่แน่นอน
        // ซึ่งรับประกันว่าถูกต้องสำหรับการเขียน
        // ขึ้นอยู่กับผู้โทรที่จะตรวจสอบให้แน่ใจว่า `slot` จะไม่หลุดอีก
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}