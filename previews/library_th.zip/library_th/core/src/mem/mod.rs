//! ฟังก์ชั่นพื้นฐานสำหรับจัดการกับหน่วยความจำ
//!
//! โมดูลนี้มีฟังก์ชันสำหรับการสืบค้นขนาดและการจัดตำแหน่งของประเภทการกำหนดค่าเริ่มต้นและการจัดการหน่วยความจำ
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// รับความเป็นเจ้าของและ "forgets" เกี่ยวกับค่า **โดยไม่ต้องเรียกใช้ตัวทำลาย**
///
/// ทรัพยากรใด ๆ ที่ค่าจัดการเช่นหน่วยความจำฮีปหรือที่จับไฟล์จะคงอยู่ตลอดไปในสถานะที่ไม่สามารถเข้าถึงได้อย่างไรก็ตามไม่รับประกันว่าพอยน์เตอร์ไปยังหน่วยความจำนี้จะยังคงใช้ได้
///
/// * หากคุณต้องการให้หน่วยความจำรั่วโปรดดู [`Box::leak`]
/// * หากคุณต้องการรับตัวชี้ดิบไปยังหน่วยความจำโปรดดู [`Box::into_raw`]
/// * หากคุณต้องการกำจัดค่าอย่างถูกต้องให้เรียกใช้ตัวทำลายของมันโปรดดู [`mem::drop`]
///
/// # Safety
///
/// `forget` ไม่ได้ระบุว่าเป็น `unsafe` เนื่องจากการรับประกันความปลอดภัยของ Rust ไม่รวมถึงการรับประกันว่าผู้ทำลายจะทำงานตลอดเวลา
/// ตัวอย่างเช่นโปรแกรมสามารถสร้างวงจรอ้างอิงโดยใช้ [`Rc`][rc] หรือเรียก [`process::exit`][exit] เพื่อออกโดยไม่ต้องเรียกใช้ตัวทำลาย
/// ดังนั้นการอนุญาต `mem::forget` จากรหัสปลอดภัยจึงไม่ได้เปลี่ยนการรับประกันความปลอดภัยของ Rust โดยพื้นฐาน
///
/// กล่าวได้ว่าการรั่วไหลของทรัพยากรเช่นหน่วยความจำหรือวัตถุ I/O มักไม่เป็นที่พึงปรารถนา
/// ความจำเป็นเกิดขึ้นในบางกรณีการใช้งานเฉพาะสำหรับ FFI หรือรหัสที่ไม่ปลอดภัย แต่ถึงอย่างนั้นโดยทั่วไปแล้ว [`ManuallyDrop`] ก็เป็นที่ต้องการ
///
/// เนื่องจากอนุญาตให้ลืมค่าได้โค้ด `unsafe` ใด ๆ ที่คุณเขียนจะต้องอนุญาตสำหรับความเป็นไปได้นี้คุณไม่สามารถส่งคืนค่าและคาดว่าผู้เรียกจำเป็นต้องเรียกใช้ตัวทำลายของค่า
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// การใช้ `mem::forget` อย่างปลอดภัยตามมาตรฐานคือการหลีกเลี่ยงตัวทำลายของค่าที่นำมาใช้โดย `Drop` trait ตัวอย่างเช่นสิ่งนี้จะทำให้ `File` รั่วไหลเช่น
/// เรียกคืนพื้นที่ที่ใช้โดยตัวแปร แต่อย่าปิดรีซอร์สระบบพื้นฐาน:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// สิ่งนี้มีประโยชน์เมื่อก่อนหน้านี้ความเป็นเจ้าของทรัพยากรที่เกี่ยวข้องถูกโอนไปยังรหัสภายนอก Rust ตัวอย่างเช่นการส่งไฟล์ตัวอธิบายไฟล์ดิบไปยังรหัส C
///
/// # ความสัมพันธ์กับ `ManuallyDrop`
///
/// ในขณะที่ `mem::forget` สามารถใช้ในการถ่ายโอนความเป็นเจ้าของ *หน่วยความจำ* ได้เช่นกันการทำเช่นนั้นมีโอกาสเกิดข้อผิดพลาดได้ง่าย
/// [`ManuallyDrop`] ควรใช้แทนตัวอย่างเช่นพิจารณารหัสนี้:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // สร้าง `String` โดยใช้เนื้อหาของ `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // รั่ว `v` เนื่องจากขณะนี้หน่วยความจำได้รับการจัดการโดย `s`
/// mem::forget(v);  // ข้อผิดพลาด v ไม่ถูกต้องและต้องไม่ถูกส่งผ่านไปยังฟังก์ชัน
/// assert_eq!(s, "Az");
/// // `s` ถูกทิ้งโดยปริยายและยกเลิกการจัดสรรหน่วยความจำ
/// ```
///
/// มีสองประเด็นในตัวอย่างข้างต้น:
///
/// * หากมีการเพิ่มรหัสเพิ่มเติมระหว่างโครงสร้างของ `String` และการเรียกใช้ `mem::forget()` panic ภายในจะทำให้เกิดการว่างสองครั้งเนื่องจากหน่วยความจำเดียวกันได้รับการจัดการโดยทั้ง `v` และ `s`
/// * หลังจากเรียก `v.as_mut_ptr()` และส่งการเป็นเจ้าของข้อมูลไปยัง `s` ค่า `v` ไม่ถูกต้อง
/// แม้ว่าค่าจะถูกย้ายไปที่ `mem::forget` (ซึ่งจะไม่ตรวจสอบ) แต่บางประเภทก็มีข้อกำหนดที่เข้มงวดเกี่ยวกับค่าที่ทำให้ค่าเหล่านี้ไม่ถูกต้องเมื่อมีการห้อยหรือไม่มีเจ้าของอีกต่อไป
/// การใช้ค่าที่ไม่ถูกต้องในทางใดทางหนึ่งรวมถึงการส่งต่อหรือส่งคืนค่าจากฟังก์ชันถือเป็นการทำงานที่ไม่ได้กำหนดไว้และอาจทำลายสมมติฐานของคอมไพลเลอร์
///
/// การเปลี่ยนไปใช้ `ManuallyDrop` ช่วยหลีกเลี่ยงปัญหาทั้งสอง:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // ก่อนที่เราจะแยกชิ้นส่วน `v` ออกเป็นชิ้นส่วนดิบตรวจสอบให้แน่ใจว่าไม่มีการตกหล่น!
/////
/// let mut v = ManuallyDrop::new(v);
/// // ตอนนี้ถอด `v` การดำเนินการเหล่านี้ไม่สามารถ panic ได้ดังนั้นจึงไม่มีการรั่วไหล
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // สุดท้ายสร้าง `String`
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` ถูกทิ้งโดยปริยายและยกเลิกการจัดสรรหน่วยความจำ
/// ```
///
/// `ManuallyDrop` ป้องกันการดับเบิ้ลฟรีอย่างมีประสิทธิภาพเนื่องจากเราปิดการใช้งานตัวทำลายของ "v" ก่อนที่จะทำสิ่งอื่นใด
/// `mem::forget()` ไม่อนุญาตให้ทำเช่นนี้เนื่องจากใช้อาร์กิวเมนต์บังคับให้เราเรียกใช้หลังจากแยกสิ่งที่เราต้องการจาก `v` แล้วเท่านั้น
/// แม้ว่า panic จะถูกนำมาใช้ระหว่างการสร้าง `ManuallyDrop` และการสร้างสตริง (ซึ่งไม่สามารถเกิดขึ้นได้ในโค้ดดังที่แสดง) แต่ก็ส่งผลให้เกิดการรั่วไหลและไม่ใช่การเพิ่มขึ้นสองเท่า
/// กล่าวอีกนัยหนึ่ง `ManuallyDrop` ทำผิดพลาดที่ด้านข้างของการรั่วไหลแทนที่จะทำผิดพลาดที่ด้านข้างของการหล่น (สองครั้ง)
///
/// นอกจากนี้ `ManuallyDrop` ยังป้องกันไม่ให้เราต้องใช้ "touch" `v` หลังจากโอนความเป็นเจ้าของไปยัง `s`-ขั้นตอนสุดท้ายของการโต้ตอบกับ `v` เพื่อกำจัดทิ้งโดยไม่เรียกใช้ตัวทำลายล้างนั้นหลีกเลี่ยงได้โดยสิ้นเชิง
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// เช่นเดียวกับ [`forget`] แต่ยังยอมรับค่าที่ไม่ได้กำหนด
///
/// ฟังก์ชั่นนี้เป็นเพียง shim ที่ตั้งใจจะลบออกเมื่อคุณสมบัติ `unsized_locals` ได้รับความเสถียร
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// ส่งคืนขนาดของชนิดเป็นไบต์
///
/// โดยเฉพาะอย่างยิ่งนี่คือการชดเชยเป็นไบต์ระหว่างองค์ประกอบที่ต่อเนื่องกันในอาร์เรย์ที่มีประเภทรายการนั้นรวมถึงช่องว่างการจัดตำแหน่ง
///
/// ดังนั้นสำหรับ `T` ทุกประเภทและความยาว `n` `[T; n]` จึงมีขนาด `n * size_of::<T>()`
///
/// โดยทั่วไปขนาดของประเภทจะไม่คงที่ในการคอมไพล์ แต่ประเภทที่เฉพาะเจาะจงเช่น primitives คือ
///
/// ตารางต่อไปนี้ระบุขนาดสำหรับดั้งเดิม
///
/// พิมพ์ |ขนาดของ: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 ถ่าน |4
///
/// นอกจากนี้ `usize` และ `isize` ยังมีขนาดเท่ากัน
///
/// ประเภท `*const T`, `&T`, `Box<T>`, `Option<&T>` และ `Option<Box<T>>` มีขนาดเท่ากัน
/// หาก `T` เป็น Sized ประเภททั้งหมดเหล่านั้นจะมีขนาดเท่ากับ `usize`
///
/// ความไม่แน่นอนของตัวชี้จะไม่เปลี่ยนขนาดดังนั้น `&T` และ `&mut T` จึงมีขนาดเท่ากัน
/// เช่นเดียวกันสำหรับ `*const T` และ `* mut T`
///
/// # ขนาด `#[repr(C)]` รายการ
///
/// การแทนค่า `C` สำหรับไอเท็มมีเค้าโครงที่กำหนดไว้
/// ด้วยรูปแบบนี้ขนาดของรายการจะคงที่เช่นกันตราบเท่าที่ทุกช่องมีขนาดคงที่
///
/// ## ขนาดของโครงสร้าง
///
/// สำหรับ `structs` ขนาดจะถูกกำหนดโดยอัลกอริทึมต่อไปนี้
///
/// สำหรับแต่ละฟิลด์ในโครงสร้างที่เรียงลำดับตามลำดับการประกาศ:
///
/// 1. เพิ่มขนาดของฟิลด์
/// 2. ปัดเศษขนาดปัจจุบันให้เป็นผลคูณที่ใกล้เคียงที่สุดของ [alignment] ของฟิลด์ถัดไป
///
/// สุดท้ายปัดเศษขนาดของโครงสร้างเป็นตัวคูณที่ใกล้ที่สุดของ [alignment]
/// การจัดตำแหน่งของโครงสร้างมักจะเป็นการจัดตำแหน่งที่ใหญ่ที่สุดในทุกฟิลด์สิ่งนี้สามารถเปลี่ยนแปลงได้ด้วยการใช้ `repr(align(N))`
///
/// ซึ่งแตกต่างจาก `C` โครงสร้างที่มีขนาดศูนย์จะไม่ปัดเศษเป็นขนาดหนึ่งไบต์
///
/// ## ขนาดของ Enums
///
/// Enums ที่ไม่มีข้อมูลใด ๆ นอกเหนือจากการจำแนกมีขนาดเท่ากับ C enums บนแพลตฟอร์มที่รวบรวมไว้
///
/// ## ขนาดของสหภาพแรงงาน
///
/// ขนาดของสหภาพคือขนาดของสนามที่ใหญ่ที่สุด
///
/// ไม่เหมือนกับ `C` สหภาพแรงงานที่มีขนาดศูนย์จะไม่ถูกปัดเศษเป็นขนาดหนึ่งไบต์
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // ดึกดำบรรพ์บางอย่าง
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // อาร์เรย์บางตัว
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // ความเท่าเทียมกันของขนาดตัวชี้
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// ใช้ `#[repr(C)]`
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // ขนาดของช่องแรกคือ 1 ดังนั้นให้เพิ่ม 1 เข้าไปในขนาดขนาดคือ 1.
/// // การจัดแนวของฟิลด์ที่สองคือ 2 ดังนั้นให้เพิ่ม 1 เข้าไปในขนาดสำหรับช่องว่างภายในขนาดคือ 2
/// // ขนาดของฟิลด์ที่สองคือ 2 ดังนั้นให้เพิ่ม 2 เข้าไปในขนาดขนาดคือ 4
/// // การจัดแนวของช่องที่สามคือ 1 ดังนั้นให้เพิ่ม 0 ลงในขนาดสำหรับช่องว่างภายในขนาดคือ 4
/// // ขนาดของช่องที่สามคือ 1 ดังนั้นให้เพิ่ม 1 เข้าไปในขนาดขนาดคือ 5
/// // สุดท้ายการจัดตำแหน่งของโครงสร้างคือ 2 (เนื่องจากการจัดตำแหน่งที่ใหญ่ที่สุดระหว่างฟิลด์คือ 2) ดังนั้นให้เพิ่ม 1 ลงในขนาดสำหรับช่องว่างภายใน
/// // ขนาด 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // โครงสร้างทูเพิลเป็นไปตามกฎเดียวกัน
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // โปรดทราบว่าการจัดลำดับฟิลด์ใหม่สามารถลดขนาดได้
/// // เราสามารถลบไบต์ของช่องว่างภายในทั้งสองได้โดยใส่ `third` ก่อน `second`
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // ขนาดสหภาพคือขนาดของสนามที่ใหญ่ที่สุด
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// ส่งคืนขนาดของค่าที่ชี้ไปเป็นไบต์
///
/// โดยปกติจะเหมือนกับ `size_of::<T>()`
/// อย่างไรก็ตามเมื่อ `T` * ไม่มีขนาดที่รู้จักแบบคงที่เช่นชิ้น [`[T]`][slice] หรือ [trait object] สามารถใช้ `size_of_val` เพื่อให้ได้ขนาดที่ทราบแบบไดนามิก
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // ความปลอดภัย: `val` เป็นข้อมูลอ้างอิงดังนั้นจึงเป็นตัวชี้ดิบที่ถูกต้อง
    unsafe { intrinsics::size_of_val(val) }
}

/// ส่งคืนขนาดของค่าที่ชี้ไปเป็นไบต์
///
/// โดยปกติจะเหมือนกับ `size_of::<T>()` อย่างไรก็ตามเมื่อ `T` * ไม่มีขนาดที่รู้จักแบบคงที่เช่นชิ้น [`[T]`][slice] หรือ [trait object] สามารถใช้ `size_of_val_raw` เพื่อให้ได้ขนาดที่ทราบแบบไดนามิก
///
/// # Safety
///
/// ฟังก์ชั่นนี้จะเรียกใช้ได้อย่างปลอดภัยหากมีเงื่อนไขต่อไปนี้:
///
/// - ถ้า `T` คือ `Sized` ฟังก์ชันนี้จะปลอดภัยในการโทรเสมอ
/// - หากหางที่ไม่ได้ปรับขนาดของ `T` คือ:
///     - [slice] ดังนั้นความยาวของหางชิ้นจะต้องเป็นจำนวนเต็มเริ่มต้นและขนาดของ *ค่าทั้งหมด*(ความยาวหางแบบไดนามิก + คำนำหน้าขนาดคงที่) ต้องพอดีกับ `isize`
///     - [trait object] จากนั้นส่วน vtable ของตัวชี้จะต้องชี้ไปที่ vtable ที่ถูกต้องซึ่งได้มาจากการบีบบังคับที่ไม่ได้ขนาดและขนาดของ *ค่าทั้งหมด*(ความยาวหางแบบไดนามิก + คำนำหน้าขนาดคงที่) ต้องพอดีกับ `isize`
///
///     - (unstable) [extern type] ดังนั้นฟังก์ชันนี้จึงปลอดภัยในการเรียกใช้เสมอ แต่อาจ panic หรือส่งคืนค่าที่ไม่ถูกต้องเนื่องจากไม่ทราบเค้าโครงของประเภทภายนอก
///     นี่เป็นลักษณะการทำงานเดียวกันกับ [`size_of_val`] ในการอ้างอิงถึงประเภทที่มีหางประเภทภายนอก
///     - มิฉะนั้นจะไม่อนุญาตให้เรียกใช้ฟังก์ชันนี้อย่างระมัดระวัง
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // ความปลอดภัย: ผู้โทรต้องระบุตัวชี้ดิบที่ถูกต้อง
    unsafe { intrinsics::size_of_val(val) }
}

/// ส่งกลับการจัดตำแหน่งขั้นต่ำที่ต้องการ [ABI] ของชนิด
///
/// ทุกการอ้างอิงถึงค่าของประเภท `T` ต้องเป็นผลคูณของจำนวนนี้
///
/// นี่คือการจัดตำแหน่งที่ใช้สำหรับฟิลด์โครงสร้างอาจมีขนาดเล็กกว่าการจัดตำแหน่งที่ต้องการ
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// ส่งกลับการจัดตำแหน่งขั้นต่ำที่จำเป็น [ABI] ของชนิดของค่าที่ `val` ชี้ไป
///
/// ทุกการอ้างอิงถึงค่าของประเภท `T` ต้องเป็นผลคูณของจำนวนนี้
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // ความปลอดภัย: val เป็นข้อมูลอ้างอิงดังนั้นจึงเป็นตัวชี้ดิบที่ถูกต้อง
    unsafe { intrinsics::min_align_of_val(val) }
}

/// ส่งกลับการจัดตำแหน่งขั้นต่ำที่ต้องการ [ABI] ของชนิด
///
/// ทุกการอ้างอิงถึงค่าของประเภท `T` ต้องเป็นผลคูณของจำนวนนี้
///
/// นี่คือการจัดตำแหน่งที่ใช้สำหรับฟิลด์โครงสร้างอาจมีขนาดเล็กกว่าการจัดตำแหน่งที่ต้องการ
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// ส่งกลับการจัดตำแหน่งขั้นต่ำที่จำเป็น [ABI] ของชนิดของค่าที่ `val` ชี้ไป
///
/// ทุกการอ้างอิงถึงค่าของประเภท `T` ต้องเป็นผลคูณของจำนวนนี้
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // ความปลอดภัย: val เป็นข้อมูลอ้างอิงดังนั้นจึงเป็นตัวชี้ดิบที่ถูกต้อง
    unsafe { intrinsics::min_align_of_val(val) }
}

/// ส่งกลับการจัดตำแหน่งขั้นต่ำที่จำเป็น [ABI] ของชนิดของค่าที่ `val` ชี้ไป
///
/// ทุกการอ้างอิงถึงค่าของประเภท `T` ต้องเป็นผลคูณของจำนวนนี้
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// ฟังก์ชั่นนี้จะเรียกใช้ได้อย่างปลอดภัยหากมีเงื่อนไขต่อไปนี้:
///
/// - ถ้า `T` คือ `Sized` ฟังก์ชันนี้จะปลอดภัยในการโทรเสมอ
/// - หากหางที่ไม่ได้ปรับขนาดของ `T` คือ:
///     - [slice] ดังนั้นความยาวของหางชิ้นจะต้องเป็นจำนวนเต็มเริ่มต้นและขนาดของ *ค่าทั้งหมด*(ความยาวหางแบบไดนามิก + คำนำหน้าขนาดคงที่) ต้องพอดีกับ `isize`
///     - [trait object] จากนั้นส่วน vtable ของตัวชี้จะต้องชี้ไปที่ vtable ที่ถูกต้องซึ่งได้มาจากการบีบบังคับที่ไม่ได้ขนาดและขนาดของ *ค่าทั้งหมด*(ความยาวหางแบบไดนามิก + คำนำหน้าขนาดคงที่) ต้องพอดีกับ `isize`
///
///     - (unstable) [extern type] ดังนั้นฟังก์ชันนี้จึงปลอดภัยในการเรียกใช้เสมอ แต่อาจ panic หรือส่งคืนค่าที่ไม่ถูกต้องเนื่องจากไม่ทราบเค้าโครงของประเภทภายนอก
///     นี่เป็นลักษณะการทำงานเดียวกันกับ [`align_of_val`] ในการอ้างอิงถึงประเภทที่มีหางประเภทภายนอก
///     - มิฉะนั้นจะไม่อนุญาตให้เรียกใช้ฟังก์ชันนี้อย่างระมัดระวัง
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // ความปลอดภัย: ผู้โทรต้องระบุตัวชี้ดิบที่ถูกต้อง
    unsafe { intrinsics::min_align_of_val(val) }
}

/// ส่งคืน `true` หากการลดค่าของประเภท `T` มีความสำคัญ
///
/// นี่เป็นเพียงคำแนะนำในการเพิ่มประสิทธิภาพเท่านั้นและอาจนำไปใช้อย่างระมัดระวัง:
/// มันอาจส่งคืน `true` สำหรับประเภทที่ไม่จำเป็นต้องลดลงจริงๆ
/// ดังนั้นการส่งคืน `true` เสมอจึงเป็นการใช้ฟังก์ชันนี้ที่ถูกต้องอย่างไรก็ตามหากฟังก์ชันนี้คืนค่า `false` จริงคุณสามารถมั่นใจได้ว่าการทิ้ง `T` จะไม่มีผลข้างเคียง
///
/// การใช้งานสิ่งต่างๆในระดับต่ำเช่นคอลเลกชันซึ่งจำเป็นต้องทิ้งข้อมูลด้วยตนเองควรใช้ฟังก์ชันนี้เพื่อหลีกเลี่ยงการพยายามทิ้งเนื้อหาทั้งหมดโดยไม่จำเป็นเมื่อถูกทำลาย
///
/// สิ่งนี้อาจไม่สร้างความแตกต่างในการสร้างรุ่น (ซึ่งตรวจพบและกำจัดลูปที่ไม่มีผลข้างเคียงได้ง่าย) แต่มักจะเป็นชัยชนะครั้งใหญ่สำหรับการสร้างการแก้ปัญหา
///
/// โปรดทราบว่า [`drop_in_place`] ทำการตรวจสอบนี้แล้วดังนั้นหากปริมาณงานของคุณสามารถลดลงเหลือการโทร [`drop_in_place`] จำนวนเล็กน้อยการใช้สิ่งนี้ก็ไม่จำเป็น
/// โดยเฉพาะอย่างยิ่งโปรดทราบว่าคุณสามารถ [`drop_in_place`] ชิ้นและจะทำการตรวจสอบ need_drop เพียงครั้งเดียวสำหรับค่าทั้งหมด
///
/// ประเภทเช่น Vec จึงเป็นเพียง `drop_in_place(&mut self[..])` โดยไม่ต้องใช้ `needs_drop` อย่างชัดเจน
/// ในทางกลับกันประเภทเช่น [`HashMap`] ต้องปล่อยค่าทีละรายการและควรใช้ API นี้
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// นี่คือตัวอย่างวิธีที่คอลเลกชันอาจใช้ประโยชน์จาก `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // วางข้อมูล
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// ส่งกลับค่าของชนิด `T` ที่แสดงโดยรูปแบบไบต์ศูนย์ทั้งหมด
///
/// ซึ่งหมายความว่าตัวอย่างเช่น padding byte ใน `(u8, u16)` ไม่จำเป็นต้องเป็นศูนย์
///
/// ไม่มีการรับประกันว่ารูปแบบไบต์ที่เป็นศูนย์ทั้งหมดแสดงถึงค่าที่ถูกต้องของ `T` บางประเภท
/// ตัวอย่างเช่นรูปแบบไบต์ศูนย์ทั้งหมดไม่ใช่ค่าที่ถูกต้องสำหรับชนิดอ้างอิง ("&T`, `&mut T`) และตัวชี้ฟังก์ชัน
/// การใช้ `zeroed` ในประเภทดังกล่าวทำให้เกิด [undefined behavior][ub] ทันทีเนื่องจาก [the Rust compiler assumes][inv] มีค่าที่ถูกต้องอยู่เสมอในตัวแปรจึงถือว่าเริ่มต้น
///
///
/// สิ่งนี้มีผลเช่นเดียวกับ [`MaybeUninit::zeroed().assume_init()`][zeroed]
/// บางครั้งมีประโยชน์สำหรับ FFI แต่โดยทั่วไปควรหลีกเลี่ยง
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// การใช้ฟังก์ชันนี้อย่างถูกต้อง: เริ่มต้นจำนวนเต็มด้วยศูนย์
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// * การใช้ฟังก์ชันนี้ไม่ถูกต้อง: การเริ่มต้นการอ้างอิงด้วยศูนย์
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // พฤติกรรมไม่ได้กำหนด!
/// let _y: fn() = unsafe { mem::zeroed() }; // และอีกครั้ง!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // ความปลอดภัย: ผู้โทรต้องรับประกันว่าค่าศูนย์ทั้งหมดนั้นใช้ได้สำหรับ `T`
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// ข้ามการตรวจสอบการเริ่มต้นหน่วยความจำปกติของ Rust โดยแสร้งทำเป็นว่าสร้างค่าประเภท `T` โดยที่ไม่ทำอะไรเลย
///
/// **ฟังก์ชันนี้เลิกใช้งานแล้ว** ใช้ [`MaybeUninit<T>`] แทน
///
/// สาเหตุของการเลิกใช้งานคือฟังก์ชันโดยทั่วไปไม่สามารถใช้งานได้อย่างถูกต้อง: มีผลเช่นเดียวกับ [`MaybeUninit::uninit().assume_init()`][uninit]
///
/// ตามที่ [`assume_init` documentation][assume_init] อธิบาย [the Rust compiler assumes][inv] ที่ค่าเริ่มต้นอย่างถูกต้อง
/// ด้วยเหตุนี้การเรียกเช่น
/// `mem::uninitialized::<bool>()` ทำให้เกิดพฤติกรรมที่ไม่ได้กำหนดในทันทีสำหรับการส่งคืน `bool` ที่ไม่ใช่ `true` หรือ `false` อย่างแน่นอน
/// ที่แย่กว่านั้นคือหน่วยความจำที่ไม่ได้กำหนดค่าเริ่มต้นอย่างแท้จริงเช่นสิ่งที่ได้รับกลับมาที่นี่มีความพิเศษตรงที่คอมไพเลอร์รู้ว่าไม่มีค่าคงที่
/// สิ่งนี้ทำให้พฤติกรรมที่ไม่ได้กำหนดมีข้อมูลที่ไม่ได้กำหนดค่าเริ่มต้นในตัวแปรแม้ว่าตัวแปรนั้นจะมีประเภทจำนวนเต็มก็ตาม
/// (โปรดสังเกตว่ากฎเกี่ยวกับจำนวนเต็มที่ไม่ได้เริ่มต้นยังไม่ได้รับการสรุป แต่ขอแนะนำให้หลีกเลี่ยงจนกว่าจะถึงเวลานั้น)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // ความปลอดภัย: ผู้โทรต้องรับประกันว่าค่าที่แปลงเป็นหน่วยเป็นค่า `T` ได้
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// สลับค่าที่ตำแหน่งที่เปลี่ยนแปลงได้สองตำแหน่งโดยไม่ต้องยกเลิกการกำหนดค่าเริ่มต้นอย่างใดอย่างหนึ่ง
///
/// * หากคุณต้องการเปลี่ยนเป็นค่าเริ่มต้นหรือค่าดัมมี่โปรดดู [`take`]
/// * หากคุณต้องการสลับด้วยค่าที่ผ่านการส่งคืนค่าเก่าโปรดดู [`replace`]
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // ความปลอดภัย: ตัวชี้ดิบถูกสร้างขึ้นจากการอ้างอิงที่ไม่แน่นอนที่ปลอดภัยซึ่งเป็นที่พอใจของไฟล์
    // ข้อ จำกัด ของ `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// แทนที่ `dest` ด้วยค่าเริ่มต้นของ `T` โดยส่งคืนค่า `dest` ก่อนหน้า
///
/// * หากคุณต้องการแทนที่ค่าของสองตัวแปรโปรดดู [`swap`]
/// * หากคุณต้องการแทนที่ด้วยค่าที่ผ่านแทนค่าเริ่มต้นโปรดดู [`replace`]
///
/// # Examples
///
/// ตัวอย่างง่ายๆ:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` อนุญาตให้เป็นเจ้าของฟิลด์โครงสร้างโดยแทนที่ด้วยค่า "empty"
/// หากไม่มี `take` คุณสามารถพบปัญหาเช่นนี้:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// โปรดทราบว่า `T` ไม่จำเป็นต้องใช้ [`Clone`] ดังนั้นจึงไม่สามารถโคลนและรีเซ็ต `self.buf` ได้
/// แต่ `take` สามารถใช้เพื่อแยกค่าดั้งเดิมของ `self.buf` ออกจาก `self` ทำให้สามารถส่งคืนได้:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// ย้าย `src` ไปยัง `dest` ที่อ้างถึงโดยส่งคืนค่า `dest` ก่อนหน้า
///
/// ไม่มีการทิ้งค่าใด ๆ
///
/// * หากคุณต้องการแทนที่ค่าของสองตัวแปรโปรดดู [`swap`]
/// * หากคุณต้องการแทนที่ด้วยค่าเริ่มต้นโปรดดู [`take`]
///
/// # Examples
///
/// ตัวอย่างง่ายๆ:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` อนุญาตให้ใช้ฟิลด์โครงสร้างโดยแทนที่ด้วยค่าอื่น
/// หากไม่มี `replace` คุณสามารถพบปัญหาเช่นนี้:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// โปรดทราบว่า `T` ไม่จำเป็นต้องใช้ [`Clone`] ดังนั้นเราจึงไม่สามารถโคลน `self.buf[i]` เพื่อหลีกเลี่ยงการเคลื่อนย้ายได้
/// แต่ `replace` สามารถใช้เพื่อแยกค่าดั้งเดิมที่ดัชนีนั้นออกจาก `self` ทำให้สามารถส่งคืนได้:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // ความปลอดภัย: เราอ่านจาก `dest` แต่เขียน `src` ลงไปโดยตรงในภายหลัง
    // เพื่อให้ค่าเก่าไม่ซ้ำกัน
    // ไม่มีอะไรตกหล่นและไม่มีอะไรที่ panic ได้
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// จำหน่ายมูลค่า
///
/// สิ่งนี้ทำได้โดยการเรียกใช้อาร์กิวเมนต์ของ [`Drop`][drop]
///
/// สิ่งนี้ไม่ได้มีประสิทธิภาพสำหรับประเภทที่ใช้ `Copy` เช่น
/// integers.
/// ค่าดังกล่าวจะถูกคัดลอกและ _then_ ย้ายเข้าไปในฟังก์ชันดังนั้นค่าจะยังคงอยู่หลังจากการเรียกใช้ฟังก์ชันนี้
///
///
/// ฟังก์ชั่นนี้ไม่ใช่เวทมนตร์มันถูกกำหนดตามตัวอักษรว่า
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// เนื่องจาก `_x` ถูกย้ายเข้าไปในฟังก์ชันฟังก์ชันจะถูกทิ้งโดยอัตโนมัติก่อนที่ฟังก์ชันจะกลับมา
///
/// [drop]: Drop
///
/// # Examples
///
/// การใช้งานพื้นฐาน:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // วาง vector อย่างชัดเจน
/// ```
///
/// เนื่องจาก [`RefCell`] บังคับใช้กฎการยืมที่รันไทม์ `drop` สามารถปล่อยยืม [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // ยกเลิกการยืมที่ไม่แน่นอนในช่องนี้
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// จำนวนเต็มและประเภทอื่น ๆ ที่ใช้ [`Copy`] จะไม่ได้รับผลกระทบจาก `drop`
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // สำเนาของ `x` ถูกย้ายและถูกทิ้ง
/// drop(y); // สำเนาของ `y` ถูกย้ายและถูกทิ้ง
///
/// println!("x: {}, y: {}", x, y.0); // ยังคงมีอยู่
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// ตีความ `src` เป็นประเภท `&U` จากนั้นอ่าน `src` โดยไม่ต้องย้ายค่าที่มีอยู่
///
/// ฟังก์ชันนี้จะถือว่าตัวชี้ `src` ถูกต้องสำหรับ [`size_of::<U>`][size_of] ไบต์อย่างไม่ปลอดภัยโดยการส่งสัญญาณ `&T` เป็น `&U` จากนั้นอ่าน `&U` (ยกเว้นว่าจะดำเนินการในลักษณะที่ถูกต้องแม้ว่า `&U` จะกำหนดข้อกำหนดการจัดตำแหน่งที่เข้มงวดกว่า `&T` ก็ตาม)
/// นอกจากนี้ยังจะสร้างสำเนาของค่าที่มีอยู่อย่างไม่ปลอดภัยแทนที่จะย้ายออกจาก `src`
///
/// ไม่ใช่ข้อผิดพลาดเวลาคอมไพล์หาก `T` และ `U` มีขนาดต่างกัน แต่ขอแนะนำอย่างยิ่งให้เรียกใช้ฟังก์ชันนี้โดยที่ `T` และ `U` มีขนาดเท่ากันฟังก์ชันนี้จะทริกเกอร์ [undefined behavior][ub] หาก `U` มีขนาดใหญ่กว่า `T`
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // คัดลอกข้อมูลจาก 'foo_array' และถือว่าเป็น 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // แก้ไขข้อมูลที่คัดลอก
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // เนื้อหาของ 'foo_array' ไม่ควรเปลี่ยนแปลง
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // หาก U มีข้อกำหนดในการจัดตำแหน่งที่สูงกว่า src อาจไม่ได้รับการจัดตำแหน่งอย่างเหมาะสม
    if align_of::<U>() > align_of::<T>() {
        // ความปลอดภัย: `src` เป็นข้อมูลอ้างอิงที่รับประกันว่าใช้ได้สำหรับการอ่าน
        // ผู้โทรจะต้องรับประกันว่าการแปลงสัญญาณที่แท้จริงนั้นปลอดภัย
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // ความปลอดภัย: `src` เป็นข้อมูลอ้างอิงที่รับประกันว่าใช้ได้สำหรับการอ่าน
        // เราเพิ่งตรวจสอบว่า `src as *const U` ได้รับการจัดวางอย่างถูกต้อง
        // ผู้โทรจะต้องรับประกันว่าการแปลงสัญญาณที่แท้จริงนั้นปลอดภัย
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// ชนิดทึบแสงที่แสดงถึงการแบ่งแยกของ enum
///
/// ดูฟังก์ชัน [`discriminant`] ในโมดูลนี้สำหรับข้อมูลเพิ่มเติม
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. ไม่สามารถรับการใช้งาน trait เหล่านี้ได้เนื่องจากเราไม่ต้องการขอบเขตใด ๆ กับ T

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// ส่งคืนค่าที่ระบุตัวแปร enum ใน `v` โดยไม่ซ้ำกัน
///
/// ถ้า `T` ไม่ใช่ enum การเรียกใช้ฟังก์ชันนี้จะไม่ส่งผลให้เกิดพฤติกรรมที่ไม่ได้กำหนด แต่ค่าที่ส่งคืนจะไม่ระบุ
///
///
/// # Stability
///
/// การเลือกปฏิบัติของตัวแปร enum อาจเปลี่ยนแปลงได้หากนิยาม enum เปลี่ยนไป
/// การเลือกปฏิบัติของตัวแปรบางอย่างจะไม่เปลี่ยนแปลงระหว่างการคอมไพล์กับคอมไพเลอร์เดียวกัน
///
/// # Examples
///
/// สามารถใช้เพื่อเปรียบเทียบ enums ที่มีข้อมูลในขณะที่ไม่คำนึงถึงข้อมูลจริง:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// ส่งคืนจำนวนตัวแปรในประเภท enum `T`
///
/// ถ้า `T` ไม่ใช่ enum การเรียกใช้ฟังก์ชันนี้จะไม่ส่งผลให้เกิดพฤติกรรมที่ไม่ได้กำหนด แต่ค่าที่ส่งคืนจะไม่ระบุ
/// ในทางเดียวกันถ้า `T` เป็น enum ที่มีตัวแปรมากกว่า `usize::MAX` ค่าที่ส่งคืนจะไม่ระบุ
/// ระบบจะนับรูปแบบที่ไม่มีใครอยู่
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}