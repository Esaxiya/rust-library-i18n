//! มาโครที่ใช้โดยผู้ทำซ้ำของชิ้น

// Inlining is_empty และ len ทำให้ประสิทธิภาพแตกต่างกันมาก
macro_rules! is_empty {
    // วิธีที่เราเข้ารหัสความยาวของตัววนซ้ำ ZST วิธีนี้ใช้ได้ทั้งกับ ZST และไม่ใช่ ZST
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// เพื่อกำจัดการตรวจสอบขอบเขตบางอย่าง (ดู `position`) เราคำนวณความยาวด้วยวิธีที่ไม่คาดคิด
// (ทดสอบโดย `codegen/slice-position-bounds-check`)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // บางครั้งเราใช้ภายในบล็อกที่ไม่ปลอดภัย

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // _cannot_ นี้ใช้ `unchecked_sub` เนื่องจากเราขึ้นอยู่กับการตัดเพื่อแสดงความยาวของตัวทำซ้ำชิ้น ZST ที่ยาว
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // เรารู้ว่า `start <= end` จึงทำได้ดีกว่า `offset_from` ซึ่งจำเป็นต้องจัดการในการลงนาม
            // โดยการตั้งค่าแฟล็กที่เหมาะสมที่นี่เราสามารถบอก LLVM ได้ซึ่งจะช่วยลบการตรวจสอบขอบเขต
            // ความปลอดภัย: ตามประเภทคงที่ `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // นอกจากนี้การบอก LLVM ด้วยว่าพอยน์เตอร์อยู่ห่างกันด้วยจำนวนทวีคูณที่แน่นอนของขนาดชนิดก็สามารถปรับ `len() == 0` ลงไปที่ `start == end` แทน `(end - start) < size` ได้
            //
            // ความปลอดภัย: ตามประเภทคงที่พอยน์เตอร์จะถูกจัดแนวเพื่อให้
            //         ระยะห่างระหว่างพวกเขาจะต้องมีขนาดหลายจุด
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// คำจำกัดความที่ใช้ร่วมกันของตัวทำซ้ำ `Iter` และ `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // ส่งคืนองค์ประกอบแรกและย้ายจุดเริ่มต้นของตัววนซ้ำไปข้างหน้าด้วย 1
        // ปรับปรุงประสิทธิภาพอย่างมากเมื่อเทียบกับฟังก์ชันแบบอินไลน์
        // ตัววนซ้ำต้องไม่ว่างเปล่า
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // ส่งคืนองค์ประกอบสุดท้ายและย้ายจุดสิ้นสุดของตัววนซ้ำไปข้างหลัง 1
        // ปรับปรุงประสิทธิภาพอย่างมากเมื่อเทียบกับฟังก์ชันแบบอินไลน์
        // ตัววนซ้ำต้องไม่ว่างเปล่า
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // หดตัววนซ้ำเมื่อ T เป็น ZST โดยเลื่อนส่วนท้ายของตัววนซ้ำไปข้างหลังด้วย `n`
        // `n` ต้องไม่เกิน `self.len()`
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // ฟังก์ชันตัวช่วยสำหรับการสร้างชิ้นส่วนจากตัววนซ้ำ
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // ความปลอดภัย: ตัววนซ้ำถูกสร้างขึ้นจากชิ้นส่วนที่มีตัวชี้
                // `self.ptr` และความยาว `len!(self)`
                // สิ่งนี้รับประกันได้ว่าข้อกำหนดเบื้องต้นทั้งหมดสำหรับ `from_raw_parts` เป็นไปตามข้อกำหนด
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // ฟังก์ชันตัวช่วยสำหรับการย้ายจุดเริ่มต้นของตัววนซ้ำไปข้างหน้าด้วยองค์ประกอบ `offset` คืนค่าเริ่มต้นเดิม
            //
            // ไม่ปลอดภัยเนื่องจากออฟเซ็ตต้องไม่เกิน `self.len()`
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // ความปลอดภัย: ผู้โทรรับประกันว่า `offset` ไม่เกิน `self.len()`
                    // ดังนั้นตัวชี้ใหม่นี้จึงอยู่ใน `self` ดังนั้นจึงรับประกันได้ว่าจะไม่เป็นโมฆะ
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // ฟังก์ชั่นตัวช่วยสำหรับการย้ายส่วนท้ายของตัววนซ้ำไปข้างหลังด้วยองค์ประกอบ `offset` โดยส่งกลับจุดสิ้นสุดใหม่
            //
            // ไม่ปลอดภัยเนื่องจากออฟเซ็ตต้องไม่เกิน `self.len()`
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // ความปลอดภัย: ผู้โทรรับประกันว่า `offset` ไม่เกิน `self.len()`
                    // ซึ่งรับประกันว่าจะไม่ล้น `isize`
                    // นอกจากนี้ตัวชี้ผลลัพธ์ยังอยู่ในขอบเขต `slice` ซึ่งเป็นไปตามข้อกำหนดอื่น ๆ สำหรับ `offset`
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // สามารถนำไปใช้กับชิ้นส่วนได้ แต่จะหลีกเลี่ยงการตรวจสอบขอบเขต

                // ความปลอดภัย: การโทร `assume` ปลอดภัยเนื่องจากตัวชี้เริ่มต้นของชิ้นส่วน
                // ต้องไม่เป็นค่าว่างและส่วนที่ไม่ใช่ ZST จะต้องมีตัวชี้สิ้นสุดที่ไม่ใช่ค่าว่างด้วย
                // การเรียก `next_unchecked!` นั้นปลอดภัยเนื่องจากเราตรวจสอบว่าตัววนซ้ำว่างเปล่าก่อนหรือไม่
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // ตัววนซ้ำนี้ว่างเปล่า
                    if mem::size_of::<T>() == 0 {
                        // เราต้องทำแบบนี้เนื่องจาก `ptr` อาจไม่เคยเป็น 0 แต่ `end` อาจเป็น (เนื่องจากการห่อ)
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // ความปลอดภัย: สิ้นสุดไม่สามารถเป็น 0 ถ้า T ไม่ใช่ ZST เนื่องจาก ptr ไม่ใช่ 0 และสิ้นสุด>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // ความปลอดภัย: เราอยู่ในขอบเขต `post_inc_start` ทำสิ่งที่ถูกต้องแม้กระทั่งกับ ZST
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // เราลบล้างการใช้งานเริ่มต้นซึ่งใช้ `try_fold` เนื่องจากการใช้งานแบบธรรมดานี้สร้าง LLVM IR น้อยกว่าและรวบรวมได้เร็วกว่า
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // เราลบล้างการใช้งานเริ่มต้นซึ่งใช้ `try_fold` เนื่องจากการใช้งานแบบธรรมดานี้สร้าง LLVM IR น้อยกว่าและรวบรวมได้เร็วกว่า
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // เราลบล้างการใช้งานเริ่มต้นซึ่งใช้ `try_fold` เนื่องจากการใช้งานแบบธรรมดานี้สร้าง LLVM IR น้อยกว่าและรวบรวมได้เร็วกว่า
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // เราลบล้างการใช้งานเริ่มต้นซึ่งใช้ `try_fold` เนื่องจากการใช้งานแบบธรรมดานี้สร้าง LLVM IR น้อยกว่าและรวบรวมได้เร็วกว่า
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // เราลบล้างการใช้งานเริ่มต้นซึ่งใช้ `try_fold` เนื่องจากการใช้งานแบบธรรมดานี้สร้าง LLVM IR น้อยกว่าและรวบรวมได้เร็วกว่า
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // เราลบล้างการใช้งานเริ่มต้นซึ่งใช้ `try_fold` เนื่องจากการใช้งานแบบธรรมดานี้สร้าง LLVM IR น้อยกว่าและรวบรวมได้เร็วกว่า
            // นอกจากนี้ `assume` ยังหลีกเลี่ยงการตรวจสอบขอบเขต
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // ความปลอดภัย: เรารับประกันว่าจะอยู่ในขอบเขตของค่าคงที่ของลูป:
                        // เมื่อ `i >= n`, `self.next()` ส่งคืน `None` และลูปหยุดทำงาน
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // เราลบล้างการใช้งานเริ่มต้นซึ่งใช้ `try_fold` เนื่องจากการใช้งานแบบธรรมดานี้สร้าง LLVM IR น้อยกว่าและรวบรวมได้เร็วกว่า
            // นอกจากนี้ `assume` ยังหลีกเลี่ยงการตรวจสอบขอบเขต
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // ความปลอดภัย: `i` ต้องต่ำกว่า `n` เนื่องจากเริ่มต้นที่ `n`
                        // และกำลังลดลงเท่านั้น
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // ความปลอดภัย: ผู้โทรต้องรับประกันว่า `i` อยู่ในขอบเขตของ
                // ชิ้นส่วนที่อยู่เบื้องหลังดังนั้น `i` จึงไม่สามารถล้น `isize` ได้และการอ้างอิงที่ส่งคืนจะได้รับการรับรองว่าอ้างถึงองค์ประกอบของชิ้นส่วนดังนั้นจึงรับประกันได้ว่าถูกต้อง
                //
                // โปรดทราบว่าผู้โทรยังรับประกันว่าเราจะไม่ถูกเรียกด้วยดัชนีเดียวกันอีกและจะไม่มีการเรียกวิธีการอื่นที่จะเข้าถึงส่วนย่อยนี้ดังนั้นจึงเป็นเรื่องที่ถูกต้องสำหรับการอ้างอิงที่ส่งคืนจะไม่แน่นอนในกรณีของ
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // สามารถนำไปใช้กับชิ้นส่วนได้ แต่จะหลีกเลี่ยงการตรวจสอบขอบเขต

                // ความปลอดภัย: การโทร `assume` ปลอดภัยเนื่องจากตัวชี้เริ่มต้นของชิ้นส่วนต้องเป็นค่าว่าง
                // และการแบ่งส่วนที่ไม่ใช่ ZST จะต้องมีตัวชี้สิ้นสุดที่ไม่ใช่ค่าว่างด้วย
                // การเรียก `next_back_unchecked!` นั้นปลอดภัยเนื่องจากเราตรวจสอบว่าตัววนซ้ำว่างเปล่าก่อนหรือไม่
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // ตัววนซ้ำนี้ว่างเปล่า
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // ความปลอดภัย: เราอยู่ในขอบเขต `pre_dec_end` ทำสิ่งที่ถูกต้องแม้กระทั่งกับ ZST
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}