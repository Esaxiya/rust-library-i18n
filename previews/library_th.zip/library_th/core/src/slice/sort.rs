//! การเรียงลำดับชิ้น
//!
//! โมดูลนี้ประกอบด้วยอัลกอริธึมการเรียงลำดับตามรูปแบบการเอาชนะ Quicksort ของ Orson Peters เผยแพร่ที่: <https://github.com/orlp/pdqsort>
//!
//!
//! การเรียงลำดับที่ไม่เสถียรเข้ากันได้กับ libcore เนื่องจากไม่ได้จัดสรรหน่วยความจำซึ่งแตกต่างจากการใช้การเรียงลำดับที่เสถียรของเรา
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// เมื่อตกหล่นให้คัดลอกจาก `src` เป็น `dest`
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // ความปลอดภัย: นี่คือระดับตัวช่วย
        //          โปรดดูการใช้งานเพื่อความถูกต้อง
        //          กล่าวคือต้องแน่ใจว่า `src` และ `dst` ไม่ทับซ้อนกันตามที่ `ptr::copy_nonoverlapping` ต้องการ
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// เลื่อนองค์ประกอบแรกไปทางขวาจนกว่าจะพบองค์ประกอบที่มากกว่าหรือเท่ากัน
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // ความปลอดภัย: การดำเนินการที่ไม่ปลอดภัยด้านล่างเกี่ยวข้องกับการจัดทำดัชนีโดยไม่มีการตรวจสอบแบบผูกมัด (`get_unchecked` และ `get_unchecked_mut`)
    // และคัดลอกหน่วยความจำ (`ptr::copy_nonoverlapping`)
    //
    // ก.การจัดทำดัชนี:
    //  1. เราตรวจสอบขนาดของอาร์เรย์เป็น>=2
    //  2. ดัชนีทั้งหมดที่เราจะทำจะอยู่ระหว่าง {0 <= index < len} มากที่สุดเสมอ
    //
    // ข.การคัดลอกหน่วยความจำ
    //  1. เรากำลังได้รับคำแนะนำสำหรับการอ้างอิงซึ่งรับประกันว่าถูกต้อง
    //  2. ไม่สามารถทับซ้อนกันได้เนื่องจากเราได้รับตัวชี้ถึงดัชนีความแตกต่างของชิ้นส่วน
    //     ได้แก่ `i` และ `i-1`
    //  3. หากจัดเรียงชิ้นส่วนอย่างถูกต้ององค์ประกอบต่างๆจะได้รับการจัดแนวอย่างเหมาะสม
    //     เป็นความรับผิดชอบของผู้โทรในการตรวจสอบให้แน่ใจว่าชิ้นส่วนได้รับการจัดแนวอย่างเหมาะสม
    //
    // ดูความคิดเห็นด้านล่างสำหรับรายละเอียดเพิ่มเติม
    unsafe {
        // หากสององค์ประกอบแรกไม่เป็นไปตามลำดับ ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // อ่านองค์ประกอบแรกในตัวแปรที่จัดสรรสแตก
            // หากการดำเนินการเปรียบเทียบ panics ต่อไปนี้ `hole` จะหลุดและเขียนองค์ประกอบกลับเข้าไปในชิ้นงานโดยอัตโนมัติ
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // ย้ายองค์ประกอบ "i`-th ไปทางซ้ายหนึ่งที่จากนั้นจึงเลื่อนรูไปทางขวา
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` หลุดออกจึงคัดลอก `tmp` ลงในรูที่เหลือใน `v`
        }
    }
}

/// เลื่อนองค์ประกอบสุดท้ายไปทางซ้ายจนกว่าจะพบองค์ประกอบที่เล็กกว่าหรือเท่ากัน
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // ความปลอดภัย: การดำเนินการที่ไม่ปลอดภัยด้านล่างเกี่ยวข้องกับการจัดทำดัชนีโดยไม่มีการตรวจสอบแบบผูกมัด (`get_unchecked` และ `get_unchecked_mut`)
    // และคัดลอกหน่วยความจำ (`ptr::copy_nonoverlapping`)
    //
    // ก.การจัดทำดัชนี:
    //  1. เราตรวจสอบขนาดของอาร์เรย์เป็น>=2
    //  2. ดัชนีทั้งหมดที่เราจะทำจะอยู่ระหว่าง `0 <= index < len-1` มากที่สุดเสมอ
    //
    // ข.การคัดลอกหน่วยความจำ
    //  1. เรากำลังได้รับคำแนะนำสำหรับการอ้างอิงซึ่งรับประกันว่าถูกต้อง
    //  2. ไม่สามารถทับซ้อนกันได้เนื่องจากเราได้รับตัวชี้ถึงดัชนีความแตกต่างของชิ้นส่วน
    //     ได้แก่ `i` และ `i+1`
    //  3. หากจัดเรียงชิ้นส่วนอย่างถูกต้ององค์ประกอบต่างๆจะได้รับการจัดแนวอย่างเหมาะสม
    //     เป็นความรับผิดชอบของผู้โทรในการตรวจสอบให้แน่ใจว่าชิ้นส่วนได้รับการจัดแนวอย่างเหมาะสม
    //
    // ดูความคิดเห็นด้านล่างสำหรับรายละเอียดเพิ่มเติม
    unsafe {
        // หากสององค์ประกอบสุดท้ายไม่เป็นไปตามลำดับ ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // อ่านองค์ประกอบสุดท้ายในตัวแปรที่จัดสรรสแต็ก
            // หากการดำเนินการเปรียบเทียบ panics ต่อไปนี้ `hole` จะหลุดและเขียนองค์ประกอบกลับเข้าไปในชิ้นงานโดยอัตโนมัติ
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // ย้ายองค์ประกอบ "i`-th ไปทางขวาหนึ่งที่จากนั้นจึงเลื่อนรูไปทางซ้าย
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` หลุดออกจึงคัดลอก `tmp` ลงในรูที่เหลือใน `v`
        }
    }
}

/// จัดเรียงชิ้นส่วนบางส่วนโดยเปลี่ยนองค์ประกอบที่ไม่อยู่ในลำดับหลาย ๆ อย่างไปรอบ ๆ
///
/// ส่งคืน `true` หากชิ้นส่วนถูกเรียงลำดับในตอนท้ายฟังก์ชันนี้เป็นกรณีที่เลวร้ายที่สุด *O*(*n*)
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // จำนวนสูงสุดของคู่ที่ไม่อยู่ในลำดับที่อยู่ติดกันซึ่งจะถูกเลื่อนออกไป
    const MAX_STEPS: usize = 5;
    // หากสไลซ์สั้นกว่านี้อย่าเลื่อนองค์ประกอบใด ๆ
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // ความปลอดภัย: เราได้ทำการตรวจสอบข้อผูกมัดกับ `i < len` อย่างชัดเจนแล้ว
        // การจัดทำดัชนีที่ตามมาทั้งหมดของเราอยู่ในช่วง `0 <= index < len` เท่านั้น
        unsafe {
            // ค้นหาคู่ถัดไปขององค์ประกอบที่ไม่อยู่ในลำดับที่อยู่ติดกัน
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // เราทำเสร็จแล้วหรือยัง?
        if i == len {
            return true;
        }

        // อย่าเปลี่ยนองค์ประกอบในอาร์เรย์สั้น ๆ ซึ่งมีต้นทุนด้านประสิทธิภาพ
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // สลับคู่ขององค์ประกอบที่พบสิ่งนี้ทำให้ลำดับที่ถูกต้อง
        v.swap(i - 1, i);

        // เลื่อนองค์ประกอบที่เล็กกว่าไปทางซ้าย
        shift_tail(&mut v[..i], is_less);
        // เลื่อนองค์ประกอบที่ใหญ่กว่าไปทางขวา
        shift_head(&mut v[i..], is_less);
    }

    // ไม่สามารถจัดเรียงชิ้นส่วนได้ในจำนวนขั้นตอนที่ จำกัด
    false
}

/// จัดเรียงชิ้นส่วนโดยใช้การเรียงลำดับการแทรกซึ่งเป็นกรณีที่เลวร้ายที่สุด *O*(*n*^ 2)
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// จัดเรียง `v` โดยใช้ heapsort ซึ่งรับประกันกรณีที่เลวร้ายที่สุด *O*(*n*\*log(* n*))
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // ไบนารีฮีปนี้เคารพ `parent >= child` ที่ไม่เปลี่ยนแปลง
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // เด็ก `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // เลือกเด็กที่ยิ่งใหญ่กว่า
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // หยุดหากค่าคงที่ถือที่ `node`
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // สลับ `node` กับลูกที่ใหญ่กว่าเลื่อนลงมาหนึ่งขั้นแล้วกรองต่อ
            v.swap(node, greater);
            node = greater;
        }
    };

    // สร้างฮีปในเวลาเชิงเส้น
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // ป๊อปองค์ประกอบสูงสุดจากฮีป
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// พาร์ติชัน `v` เป็นองค์ประกอบที่เล็กกว่า `pivot` ตามด้วยองค์ประกอบที่มากกว่าหรือเท่ากับ `pivot`
///
///
/// ส่งคืนจำนวนองค์ประกอบที่เล็กกว่า `pivot`
///
/// การแบ่งพาร์ติชันจะดำเนินการแบบบล็อกต่อบล็อกเพื่อลดต้นทุนในการแยกสาขา
/// แนวคิดนี้นำเสนอในกระดาษ [BlockQuicksort][pdf]
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // จำนวนองค์ประกอบในบล็อกทั่วไป
    const BLOCK: usize = 128;

    // อัลกอริทึมการแบ่งพาร์ติชันจะทำซ้ำขั้นตอนต่อไปนี้จนกว่าจะเสร็จสิ้น:
    //
    // 1. ติดตามบล็อกจากด้านซ้ายเพื่อระบุองค์ประกอบที่มากกว่าหรือเท่ากับเดือย
    // 2. ติดตามบล็อกจากด้านขวาเพื่อระบุองค์ประกอบที่เล็กกว่าเดือย
    // 3. แลกเปลี่ยนองค์ประกอบที่ระบุระหว่างด้านซ้ายและด้านขวา
    //
    // เราเก็บตัวแปรต่อไปนี้ไว้สำหรับบล็อกองค์ประกอบ:
    //
    // 1. `block` - จำนวนองค์ประกอบในบล็อก
    // 2. `start` - เริ่มตัวชี้ในอาร์เรย์ `offsets`
    // 3. `end` - ตัวชี้สิ้นสุดในอาร์เรย์ `offsets`
    // 4. `การชดเชยดัชนีขององค์ประกอบที่ไม่อยู่ในลำดับภายในบล็อก

    // บล็อกปัจจุบันทางด้านซ้าย (จาก `l` ถึง `l.add(block_l)`)
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // บล็อกปัจจุบันทางด้านขวา (จาก `r.sub(block_r)` to `r`).
    // ความปลอดภัย: เอกสารสำหรับ .add() กล่าวถึงโดยเฉพาะว่า `vec.as_ptr().add(vec.len())` ปลอดภัยเสมอ "
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: เมื่อเราได้รับ VLAs ให้ลองสร้างอาร์เรย์หนึ่งความยาว `min(v.len(), 2 * BLOCK) แทน
    // อาร์เรย์ขนาดคงที่มากกว่าสองอาร์เรย์ที่มีความยาว `BLOCK` VLAs อาจมีประสิทธิภาพในการแคชมากกว่า

    // ส่งคืนจำนวนองค์ประกอบระหว่างพอยน์เตอร์ `l` (inclusive) และ `r` (exclusive)
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // เราทำด้วยการแบ่งพาร์ติชันทีละบล็อกเมื่อ `l` และ `r` เข้าใกล้มาก
        // จากนั้นเราจะทำการแก้ไขบางอย่างเพื่อแบ่งองค์ประกอบที่เหลืออยู่ระหว่างนั้น
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // จำนวนองค์ประกอบที่เหลือ (ยังไม่เทียบกับเดือย)
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // ปรับขนาดบล็อกเพื่อไม่ให้บล็อกด้านซ้ายและด้านขวาทับซ้อนกัน แต่จัดแนวให้พอดีเพื่อให้ครอบคลุมช่องว่างที่เหลือทั้งหมด
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // ติดตามองค์ประกอบ `block_l` จากด้านซ้าย
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // ความปลอดภัย: การดำเนินการที่ไม่ปลอดภัยด้านล่างเกี่ยวข้องกับการใช้งาน `offset`
                //         ตามเงื่อนไขที่ฟังก์ชันต้องการเราปฏิบัติตามเงื่อนไขเหล่านี้เนื่องจาก:
                //         1. `offsets_l` มีการจัดสรรสแต็กดังนั้นจึงถือว่าเป็นวัตถุที่จัดสรรแยกต่างหาก
                //         2. ฟังก์ชัน `is_less` ส่งคืน `bool`
                //            การแคสต์ `bool` จะไม่มีวันล้น `isize`
                //         3. เรารับประกันว่า `block_l` จะเป็น `<= BLOCK`
                //            นอกจากนี้ `end_l` ยังถูกตั้งค่าเป็นตัวชี้เริ่มต้นของ `offsets_` ซึ่งประกาศไว้ในสแต็ก
                //            ดังนั้นเราจึงรู้ว่าแม้ในกรณีที่เลวร้ายที่สุด (การเรียกใช้ `is_less` ทั้งหมดจะคืนค่าเป็นเท็จ) เราจะผ่านจุดสิ้นสุดได้มากที่สุดเพียง 1 ไบต์เท่านั้น
                //        การดำเนินการที่ไม่ปลอดภัยอีกประการหนึ่งในที่นี้คือการยกเลิกการอ้างอิง `elem`
                //        อย่างไรก็ตาม `elem` เป็นตัวชี้เริ่มต้นไปยังชิ้นส่วนซึ่งใช้ได้เสมอ
                unsafe {
                    // การเปรียบเทียบแบบไม่มีสาขา
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // ติดตามองค์ประกอบ `block_r` จากด้านขวา
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // ความปลอดภัย: การดำเนินการที่ไม่ปลอดภัยด้านล่างเกี่ยวข้องกับการใช้งาน `offset`
                //         ตามเงื่อนไขที่ฟังก์ชันต้องการเราปฏิบัติตามเงื่อนไขเหล่านี้เนื่องจาก:
                //         1. `offsets_r` มีการจัดสรรสแต็กดังนั้นจึงถือว่าเป็นวัตถุที่จัดสรรแยกต่างหาก
                //         2. ฟังก์ชัน `is_less` ส่งคืน `bool`
                //            การแคสต์ `bool` จะไม่มีวันล้น `isize`
                //         3. เรารับประกันว่า `block_r` จะเป็น `<= BLOCK`
                //            นอกจากนี้ `end_r` ยังถูกตั้งค่าเป็นตัวชี้เริ่มต้นของ `offsets_` ซึ่งประกาศไว้ในสแต็ก
                //            ดังนั้นเราจึงรู้ว่าแม้ในกรณีที่เลวร้ายที่สุด (การเรียกใช้ `is_less` ทั้งหมดจะคืนค่าจริง) เราจะผ่านจุดสิ้นสุดได้สูงสุด 1 ไบต์เท่านั้น
                //        การดำเนินการที่ไม่ปลอดภัยอีกประการหนึ่งในที่นี้คือการยกเลิกการอ้างอิง `elem`
                //        อย่างไรก็ตาม `elem` ในตอนแรกคือ `1 *sizeof(T)` ที่ผ่านจุดสิ้นสุดและเราลดลง `1* sizeof(T)` ก่อนที่จะเข้าถึง
                //        นอกจากนี้ `block_r` ได้รับการยืนยันว่าน้อยกว่า `BLOCK` และ `elem` ส่วนใหญ่จะชี้ไปที่จุดเริ่มต้นของชิ้นส่วน
                unsafe {
                    // การเปรียบเทียบแบบไม่มีสาขา
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // จำนวนองค์ประกอบที่ไม่อยู่ในลำดับที่จะสลับระหว่างด้านซ้ายและด้านขวา
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // แทนที่จะสลับคู่หนึ่งคู่ในเวลานั้นการเรียงสับเปลี่ยนแบบวนจะมีประสิทธิภาพมากกว่า
            // สิ่งนี้ไม่เทียบเท่ากับการแลกเปลี่ยนอย่างเคร่งครัด แต่ให้ผลลัพธ์ที่คล้ายกันโดยใช้การทำงานของหน่วยความจำน้อยลง
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // องค์ประกอบที่ไม่อยู่ในลำดับทั้งหมดในบล็อกด้านซ้ายถูกย้ายย้ายไปที่บล็อกถัดไป
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // องค์ประกอบที่ไม่อยู่ในลำดับทั้งหมดในบล็อกด้านขวาถูกย้ายย้ายไปที่บล็อกก่อนหน้า
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // สิ่งที่เหลืออยู่ในตอนนี้คือไม่เกินหนึ่งช่วงตึก (ทางซ้ายหรือทางขวา) พร้อมด้วยองค์ประกอบที่ไม่อยู่ในลำดับที่ต้องย้าย
    // องค์ประกอบที่เหลือดังกล่าวสามารถเลื่อนไปยังจุดสิ้นสุดภายในบล็อกได้
    //

    if start_l < end_l {
        // บล็อกด้านซ้ายยังคงอยู่
        // ย้ายองค์ประกอบที่ไม่อยู่ในลำดับที่เหลือไปทางขวาสุด
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // บล็อกด้านขวายังคงอยู่
        // ย้ายองค์ประกอบที่ไม่อยู่ในลำดับที่เหลือไปทางซ้ายสุด
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // ไม่มีอะไรต้องทำอีกแล้วเราทำเสร็จแล้ว
        width(v.as_mut_ptr(), l)
    }
}

/// พาร์ติชัน `v` เป็นองค์ประกอบที่เล็กกว่า `v[pivot]` ตามด้วยองค์ประกอบที่มากกว่าหรือเท่ากับ `v[pivot]`
///
///
/// ส่งคืนทูเปิลของ:
///
/// 1. จำนวนองค์ประกอบที่เล็กกว่า `v[pivot]`
/// 2. เป็นจริงถ้า `v` ถูกแบ่งพาร์ติชันแล้ว
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // วางเดือยที่จุดเริ่มต้นของชิ้น
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // อ่านเดือยในตัวแปรที่จัดสรรสแต็กเพื่อประสิทธิภาพ
        // หากการดำเนินการเปรียบเทียบ panics ต่อไปนี้เดือยจะถูกเขียนกลับเข้าไปในชิ้นส่วนโดยอัตโนมัติ
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // ค้นหาคู่แรกขององค์ประกอบที่ไม่อยู่ในลำดับ
        let mut l = 0;
        let mut r = v.len();

        // ความปลอดภัย: ความไม่ปลอดภัยด้านล่างเกี่ยวข้องกับการสร้างดัชนีอาร์เรย์
        // สำหรับข้อแรก: เราได้ทำการตรวจสอบขอบเขตที่นี่ด้วย `l < r` แล้ว
        // สำหรับอันที่สอง: ตอนแรกเรามี `l == 0` และ `r == v.len()` และเราตรวจสอบ `l < r` นั้นในทุกการดำเนินการจัดทำดัชนี
        //                     จากที่นี่เรารู้ว่า `r` ต้องมีค่าอย่างน้อย `r == l` ซึ่งแสดงว่าใช้ได้ตั้งแต่แรก
        unsafe {
            // ค้นหาองค์ประกอบแรกที่มากกว่าหรือเท่ากับเดือย
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // ค้นหาองค์ประกอบสุดท้ายที่มีขนาดเล็กกว่าเดือย
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` ออกไปนอกขอบเขตและเขียน pivot (ซึ่งเป็นตัวแปรที่จัดสรรสแต็ก) กลับเข้าไปในสไลซ์ที่เดิมเป็นอยู่
        // ขั้นตอนนี้สำคัญมากในการดูแลความปลอดภัย!
        //
    };

    // วางเดือยระหว่างสองพาร์ติชั่น
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// พาร์ติชัน `v` เป็นองค์ประกอบเท่ากับ `v[pivot]` ตามด้วยองค์ประกอบที่มากกว่า `v[pivot]`
///
/// ส่งคืนจำนวนองค์ประกอบที่เท่ากับเดือย
/// สันนิษฐานว่า `v` ไม่มีองค์ประกอบที่เล็กกว่าเดือย
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // วางเดือยที่จุดเริ่มต้นของชิ้น
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // อ่านเดือยในตัวแปรที่จัดสรรสแต็กเพื่อประสิทธิภาพ
    // หากการดำเนินการเปรียบเทียบ panics ต่อไปนี้เดือยจะถูกเขียนกลับเข้าไปในชิ้นส่วนโดยอัตโนมัติ
    // ความปลอดภัย: ตัวชี้ที่นี่ถูกต้องเนื่องจากได้มาจากการอ้างอิงถึงชิ้นส่วน
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // ตอนนี้แบ่งชิ้นส่วน
    let mut l = 0;
    let mut r = v.len();
    loop {
        // ความปลอดภัย: ความไม่ปลอดภัยด้านล่างเกี่ยวข้องกับการสร้างดัชนีอาร์เรย์
        // สำหรับข้อแรก: เราได้ทำการตรวจสอบขอบเขตที่นี่ด้วย `l < r` แล้ว
        // สำหรับอันที่สอง: ตอนแรกเรามี `l == 0` และ `r == v.len()` และเราตรวจสอบ `l < r` นั้นในทุกการดำเนินการจัดทำดัชนี
        //                     จากที่นี่เรารู้ว่า `r` ต้องมีค่าอย่างน้อย `r == l` ซึ่งแสดงว่าใช้ได้ตั้งแต่แรก
        unsafe {
            // ค้นหาองค์ประกอบแรกที่มากกว่าเดือย
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // ค้นหาองค์ประกอบสุดท้ายที่เท่ากับเดือย
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // เราทำเสร็จแล้วหรือยัง?
            if l >= r {
                break;
            }

            // สลับคู่ขององค์ประกอบที่ไม่อยู่ในลำดับที่พบ
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // เราพบองค์ประกอบ `l` เท่ากับเดือยเพิ่ม 1 ในบัญชีสำหรับ Pivot เอง
    l + 1

    // `_pivot_guard` ออกไปนอกขอบเขตและเขียน pivot (ซึ่งเป็นตัวแปรที่จัดสรรสแต็ก) กลับเข้าไปในสไลซ์ที่เดิมเป็นอยู่
    // ขั้นตอนนี้สำคัญมากในการดูแลความปลอดภัย!
}

/// กระจายองค์ประกอบบางส่วนไปรอบ ๆ เพื่อพยายามทำลายรูปแบบที่อาจทำให้พาร์ติชันไม่สมดุลใน Quicksort
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // ตัวสร้างหมายเลข Pseudorandom จากกระดาษ "Xorshift RNGs" โดย George Marsaglia
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // ใช้ตัวเลขสุ่มโมดูโลหมายเลขนี้
        // ตัวเลขพอดีกับ `usize` เนื่องจาก `len` ไม่เกิน `isize::MAX`
        let modulus = len.next_power_of_two();

        // ตัวเลือก Pivot บางตัวจะอยู่ใกล้ดัชนีนี้มาสุ่มกันเลย
        let pos = len / 4 * 2;

        for i in 0..3 {
            // สร้างตัวเลขสุ่ม modulo `len`
            // อย่างไรก็ตามเพื่อหลีกเลี่ยงการดำเนินการที่มีค่าใช้จ่ายสูงอันดับแรกเราจะใช้โมดูโลเป็นกำลังสองจากนั้นลดลง `len` จนกว่าจะพอดีกับช่วง `[0, len - 1]`
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` รับประกันว่าจะน้อยกว่า `2 * len`
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// เลือกเดือยใน `v` และส่งคืนดัชนีและ `true` หากชิ้นส่วนมีแนวโน้มที่จะเรียงลำดับแล้ว
///
/// องค์ประกอบใน `v` อาจถูกจัดลำดับใหม่ในกระบวนการ
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // ความยาวขั้นต่ำในการเลือกวิธีค่ามัธยฐานของค่ามัธยฐาน
    // ชิ้นที่สั้นกว่าใช้วิธีมัธยฐานสามอย่างง่ายๆ
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // จำนวนสว็อปสูงสุดที่สามารถทำได้ในฟังก์ชันนี้
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // ดัชนีสามตัวที่อยู่ใกล้กับที่เราจะเลือกเดือย
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // นับจำนวนสว็อปทั้งหมดที่เรากำลังจะดำเนินการในขณะที่จัดเรียงดัชนี
    let mut swaps = 0;

    if len >= 8 {
        // สลับดัชนีเพื่อให้ `v[a] <= v[b]`
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // สลับดัชนีเพื่อให้ `v[a] <= v[b] <= v[c]`
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // ค้นหาค่ามัธยฐานของ `v[a - 1], v[a], v[a + 1]` และจัดเก็บดัชนีเป็น `a`
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // ค้นหาค่ามัธยฐานในละแวกใกล้เคียงของ `a`, `b` และ `c`
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // หาค่ามัธยฐานระหว่าง `a`, `b` และ `c`
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // จำนวนสูงสุดของการแลกเปลี่ยนถูกดำเนินการ
        // โอกาสที่ชิ้นจะลดลงหรือมากไปหาน้อยดังนั้นการย้อนกลับอาจช่วยให้เรียงลำดับได้เร็วขึ้น
        v.reverse();
        (len - 1 - b, true)
    }
}

/// จัดเรียง `v` ซ้ำ
///
/// หากสไลซ์มีบรรพบุรุษในอาร์เรย์ดั้งเดิมจะระบุเป็น `pred`
///
/// `limit` คือจำนวนพาร์ติชันที่ไม่สมดุลที่อนุญาตก่อนเปลี่ยนเป็น `heapsort`
/// ถ้าเป็นศูนย์ฟังก์ชันนี้จะเปลี่ยนเป็นฮีปพอร์ตทันที
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // ชิ้นส่วนที่มีความยาวไม่เกินนี้จะถูกจัดเรียงโดยใช้การเรียงลำดับการแทรก
    const MAX_INSERTION: usize = 20;

    // เป็นจริงหากการแบ่งพาร์ติชันล่าสุดมีความสมดุลอย่างสมเหตุสมผล
    let mut was_balanced = true;
    // เป็นจริงหากการแบ่งพาร์ติชันครั้งล่าสุดไม่ได้สับเปลี่ยนองค์ประกอบ (ชิ้นส่วนถูกแบ่งพาร์ติชันแล้ว)
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // ชิ้นส่วนที่สั้นมากจะถูกจัดเรียงโดยใช้การเรียงลำดับการแทรก
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // หากมีการเลือก pivot ที่ไม่ดีมากเกินไปให้ถอยกลับไปที่ heapsort เพื่อรับประกันกรณีที่เลวร้ายที่สุดของ `O(n * log(n))`
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // หากการแบ่งพาร์ติชันครั้งล่าสุดไม่สมดุลให้ลองทำลายรูปแบบในชิ้นโดยการสับองค์ประกอบบางส่วนรอบ ๆ
        // หวังว่าคราวนี้เราจะเลือกเดือยที่ดีกว่านี้
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // เลือกเดือยและลองเดาว่าเรียงลำดับแล้วหรือยัง
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // หากการแบ่งพาร์ติชันครั้งสุดท้ายมีความสมดุลอย่างเหมาะสมและไม่ได้สับเปลี่ยนองค์ประกอบและหากการเลือกเดือยคาดการณ์ว่าชิ้นส่วนนั้นมีแนวโน้มที่จะเรียงลำดับแล้ว ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // ลองระบุองค์ประกอบที่ไม่อยู่ในลำดับหลาย ๆ รายการและเลื่อนไปยังตำแหน่งที่ถูกต้อง
            // หากชิ้นส่วนถูกจัดเรียงอย่างสมบูรณ์เราก็ทำเสร็จแล้ว
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // หากเดือยที่เลือกเท่ากับรุ่นก่อนแสดงว่าเป็นองค์ประกอบที่เล็กที่สุดในสไลซ์
        // แบ่งชิ้นส่วนออกเป็นองค์ประกอบที่เท่ากับและองค์ประกอบที่มากกว่าเดือย
        // กรณีนี้มักเกิดขึ้นเมื่อชิ้นงานมีองค์ประกอบที่ซ้ำกันจำนวนมาก
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // จัดเรียงองค์ประกอบที่มากกว่าเดือยต่อไป
                v = &mut { v }[mid..];
                continue;
            }
        }

        // แบ่งชิ้นส่วน
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // แบ่งชิ้นส่วนออกเป็น `left`, `pivot` และ `right`
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // เรียกซ้ำในด้านที่สั้นกว่าเท่านั้นเพื่อลดจำนวนการเรียกซ้ำทั้งหมดและใช้พื้นที่สแต็กน้อยลง
        // จากนั้นดำเนินการต่อด้วยด้านที่ยาวขึ้น (คล้ายกับการเรียกซ้ำหาง)
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// จัดเรียง `v` โดยใช้ Quicksort ที่เอาชนะรูปแบบซึ่งเป็น *O*(*n*\*log(* n*)) กรณีที่เลวร้ายที่สุด
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // การเรียงลำดับไม่มีพฤติกรรมที่มีความหมายสำหรับประเภทที่มีขนาดศูนย์
    if mem::size_of::<T>() == 0 {
        return;
    }

    // จำกัด จำนวนพาร์ติชันที่ไม่สมดุลไว้ที่ `floor(log2(len)) + 1`
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // สำหรับชิ้นที่มีความยาวไม่เกินนี้การเรียงลำดับมันอาจจะเร็วกว่า
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // เลือกเดือย
        let (pivot, _) = choose_pivot(v, is_less);

        // หากเดือยที่เลือกเท่ากับรุ่นก่อนแสดงว่าเป็นองค์ประกอบที่เล็กที่สุดในสไลซ์
        // แบ่งชิ้นส่วนออกเป็นองค์ประกอบที่เท่ากับและองค์ประกอบที่มากกว่าเดือย
        // กรณีนี้มักเกิดขึ้นเมื่อชิ้นงานมีองค์ประกอบที่ซ้ำกันจำนวนมาก
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // ถ้าเราผ่านดัชนีของเราแสดงว่าเราดี
                if mid > index {
                    return;
                }

                // มิฉะนั้นให้จัดเรียงองค์ประกอบที่มากกว่า Pivot ต่อไป
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // แบ่งชิ้นส่วนออกเป็น `left`, `pivot` และ `right`
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // หากดัชนีกลาง==แสดงว่าเราทำเสร็จแล้วเนื่องจาก partition() รับประกันว่าองค์ประกอบทั้งหมดหลังค่ากลางมีค่ามากกว่าหรือเท่ากับกลาง
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // การเรียงลำดับไม่มีพฤติกรรมที่มีความหมายสำหรับประเภทที่มีขนาดศูนย์ไม่ทำอะไร.
    } else if index == v.len() - 1 {
        // ค้นหาองค์ประกอบสูงสุดและวางไว้ในตำแหน่งสุดท้ายของอาร์เรย์
        // เราสามารถใช้ `unwrap()` ได้ฟรีที่นี่เพราะเรารู้ว่า v ต้องไม่ว่างเปล่า
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // ค้นหาองค์ประกอบขั้นต่ำและวางไว้ในตำแหน่งแรกของอาร์เรย์
        // เราสามารถใช้ `unwrap()` ได้ฟรีที่นี่เพราะเรารู้ว่า v ต้องไม่ว่างเปล่า
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}