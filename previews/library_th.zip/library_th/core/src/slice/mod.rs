// ignore-tidy-filelength

//! การจัดการและการจัดการชิ้นส่วน
//!
//! สำหรับรายละเอียดเพิ่มเติมโปรดดู [`std::slice`]
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// การใช้งาน rust memchr ที่บริสุทธิ์นำมาจาก rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// ฟังก์ชันนี้เป็นแบบสาธารณะเท่านั้นเนื่องจากไม่มีวิธีอื่นในการทดสอบหน่วยฮีปพอร์ต
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// ส่งคืนจำนวนองค์ประกอบในสไลซ์
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // ความปลอดภัย: const เสียงเพราะเราถ่ายทอดฟิลด์ความยาวออกมาเป็น usize (ซึ่งต้องเป็น)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // ความปลอดภัย: ปลอดภัยเนื่องจาก `&[T]` และ `FatPtr<T>` มีรูปแบบเดียวกัน
            // `std` เท่านั้นที่สามารถรับประกันได้
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: แทนที่ด้วย `crate::ptr::metadata(self)` เมื่อมีเสถียรภาพ
            // จากการเขียนนี้ทำให้เกิดข้อผิดพลาด "Const-stable functions can only call other const-stable functions"
            //

            // ความปลอดภัย: การเข้าถึงค่าจากสหภาพ `PtrRepr` นั้นปลอดภัยตั้งแต่ * const T
            // และ PtrComponents<T>มีเค้าโครงหน่วยความจำเหมือนกัน
            // มีเพียง std เท่านั้นที่สามารถรับประกันได้
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// ส่งคืนค่า `true` หากสไลซ์มีความยาวเป็น 0
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ส่งคืนองค์ประกอบแรกของชิ้นส่วนหรือ `None` หากว่างเปล่า
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// ส่งคืนตัวชี้ที่ไม่สามารถเปลี่ยนแปลงได้ไปยังองค์ประกอบแรกของชิ้นส่วนหรือ `None` หากว่างเปล่า
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// ส่งคืนองค์ประกอบแรกและส่วนที่เหลือทั้งหมดของชิ้นส่วนหรือ `None` หากว่างเปล่า
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// ส่งคืนองค์ประกอบแรกและส่วนที่เหลือทั้งหมดของชิ้นส่วนหรือ `None` หากว่างเปล่า
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// ส่งคืนองค์ประกอบสุดท้ายและส่วนที่เหลือทั้งหมดของชิ้นส่วนหรือ `None` หากว่างเปล่า
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// ส่งคืนองค์ประกอบสุดท้ายและส่วนที่เหลือทั้งหมดของชิ้นส่วนหรือ `None` หากว่างเปล่า
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// ส่งคืนองค์ประกอบสุดท้ายของชิ้นส่วนหรือ `None` หากว่างเปล่า
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// ส่งกลับตัวชี้ที่ไม่สามารถเปลี่ยนแปลงได้ไปยังรายการสุดท้ายในชิ้น
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// ส่งกลับการอ้างอิงไปยังองค์ประกอบหรือส่วนย่อยโดยขึ้นอยู่กับประเภทของดัชนี
    ///
    /// - หากกำหนดตำแหน่งให้ส่งกลับการอ้างอิงไปยังองค์ประกอบที่ตำแหน่งนั้นหรือ `None` หากอยู่นอกขอบเขต
    ///
    /// - หากกำหนดช่วงให้ส่งคืนส่วนย่อยที่ตรงกับช่วงนั้นหรือ `None` หากอยู่นอกขอบเขต
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// ส่งคืนการอ้างอิงที่เปลี่ยนแปลงได้ไปยังองค์ประกอบหรือส่วนย่อยโดยขึ้นอยู่กับชนิดของดัชนี (ดู [`get`]) หรือ `None` หากดัชนีอยู่นอกขอบเขต
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// ส่งคืนการอ้างอิงไปยังองค์ประกอบหรือส่วนย่อยโดยไม่ต้องทำการตรวจสอบขอบเขต
    ///
    /// สำหรับทางเลือกที่ปลอดภัยโปรดดู [`get`]
    ///
    /// # Safety
    ///
    /// การเรียกเมธอดนี้ด้วยดัชนีนอกขอบเขตคือ *[undefined behavior]* แม้ว่าจะไม่ได้ใช้การอ้างอิงที่เป็นผลลัพธ์ก็ตาม
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามข้อกำหนดด้านความปลอดภัยส่วนใหญ่สำหรับ `get_unchecked`
        // ชิ้นส่วนไม่สามารถถอดรหัสได้เนื่องจาก `self` เป็นข้อมูลอ้างอิงที่ปลอดภัย
        // ตัวชี้ที่ส่งกลับมีความปลอดภัยเนื่องจากนัยของ `SliceIndex` ต้องรับประกันว่าเป็น
        unsafe { &*index.get_unchecked(self) }
    }

    /// ส่งคืนการอ้างอิงที่เปลี่ยนแปลงได้ไปยังองค์ประกอบหรือส่วนย่อยโดยไม่ต้องทำการตรวจสอบขอบเขต
    ///
    /// สำหรับทางเลือกที่ปลอดภัยโปรดดู [`get_mut`]
    ///
    /// # Safety
    ///
    /// การเรียกเมธอดนี้ด้วยดัชนีนอกขอบเขตคือ *[undefined behavior]* แม้ว่าจะไม่ได้ใช้การอ้างอิงที่เป็นผลลัพธ์ก็ตาม
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามข้อกำหนดด้านความปลอดภัยสำหรับ `get_unchecked_mut`
        // ชิ้นส่วนไม่สามารถถอดรหัสได้เนื่องจาก `self` เป็นข้อมูลอ้างอิงที่ปลอดภัย
        // ตัวชี้ที่ส่งกลับมีความปลอดภัยเนื่องจากนัยของ `SliceIndex` ต้องรับประกันว่าเป็น
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// ส่งกลับตัวชี้ดิบไปยังบัฟเฟอร์ของชิ้นส่วน
    ///
    /// ผู้เรียกต้องตรวจสอบให้แน่ใจว่าสไลซ์มีอายุยืนยาวกว่าตัวชี้ที่ฟังก์ชันนี้ส่งกลับไม่เช่นนั้นจะชี้ไปที่ขยะ
    ///
    /// ผู้โทรต้องตรวจสอบให้แน่ใจว่าหน่วยความจำที่ตัวชี้ (non-transitively) ชี้ไปนั้นไม่เคยเขียนถึง (ยกเว้นภายใน `UnsafeCell`) โดยใช้ตัวชี้นี้หรือตัวชี้ใด ๆ ที่ได้มาจากตัวชี้นั้น
    /// หากคุณต้องการเปลี่ยนเนื้อหาของชิ้นส่วนให้ใช้ [`as_mut_ptr`]
    ///
    /// การแก้ไขคอนเทนเนอร์ที่อ้างถึงโดยสไลซ์นี้อาจทำให้บัฟเฟอร์ถูกจัดสรรใหม่ซึ่งจะทำให้พอยน์เตอร์ไปยังคอนเทนเนอร์นั้นไม่ถูกต้อง
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// ส่งกลับตัวชี้ที่ผันแปรที่ไม่ปลอดภัยไปยังบัฟเฟอร์ของชิ้นส่วน
    ///
    /// ผู้เรียกต้องตรวจสอบให้แน่ใจว่าสไลซ์มีอายุยืนยาวกว่าตัวชี้ที่ฟังก์ชันนี้ส่งกลับไม่เช่นนั้นจะชี้ไปที่ขยะ
    ///
    /// การแก้ไขคอนเทนเนอร์ที่อ้างถึงโดยสไลซ์นี้อาจทำให้บัฟเฟอร์ถูกจัดสรรใหม่ซึ่งจะทำให้พอยน์เตอร์ไปยังคอนเทนเนอร์นั้นไม่ถูกต้อง
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// ส่งคืนตัวชี้ดิบสองตัวที่ครอบคลุมชิ้นส่วน
    ///
    /// ช่วงที่ส่งคืนคือครึ่งเปิดซึ่งหมายความว่าตัวชี้ท้ายชี้ *หนึ่งที่ผ่านมา* องค์ประกอบสุดท้ายของชิ้นส่วน
    /// ด้วยวิธีนี้สไลซ์ว่างจะแสดงด้วยพอยน์เตอร์สองตัวที่เท่ากันและความแตกต่างระหว่างพอยน์เตอร์ทั้งสองแสดงถึงขนาดของสไลซ์
    ///
    /// ดู [`as_ptr`] สำหรับคำเตือนเกี่ยวกับการใช้พอยน์เตอร์เหล่านี้ตัวชี้สิ้นสุดต้องใช้ความระมัดระวังเป็นพิเศษเนื่องจากไม่ได้ชี้ไปที่องค์ประกอบที่ถูกต้องในชิ้นส่วน
    ///
    /// ฟังก์ชันนี้มีประโยชน์สำหรับการโต้ตอบกับอินเทอร์เฟซต่างประเทศซึ่งใช้พอยน์เตอร์สองตัวเพื่ออ้างถึงช่วงขององค์ประกอบในหน่วยความจำเช่นเดียวกับที่ใช้กันทั่วไปใน C++
    ///
    ///
    /// นอกจากนี้ยังมีประโยชน์ในการตรวจสอบว่าตัวชี้ไปยังองค์ประกอบนั้นอ้างถึงองค์ประกอบของชิ้นส่วนนี้หรือไม่:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // ความปลอดภัย: `add` ที่นี่ปลอดภัยเนื่องจาก:
        //
        //   - พอยน์เตอร์ทั้งสองเป็นส่วนหนึ่งของออบเจ็กต์เดียวกันเนื่องจากการชี้ผ่านวัตถุโดยตรงก็จะนับเช่นกัน
        //
        //   - ขนาดของชิ้นส่วนจะต้องไม่ใหญ่กว่า isize::MAX ไบต์ดังที่ระบุไว้ที่นี่:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - ไม่มีการพันรอบที่เกี่ยวข้องเนื่องจากชิ้นส่วนจะไม่ห่อผ่านส่วนท้ายของช่องที่อยู่
        //
        // ดูเอกสารของ pointer::add
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// ส่งคืนตัวชี้ที่ผันแปรที่ไม่ปลอดภัยสองตัวที่ทอดผ่านชิ้นส่วน
    ///
    /// ช่วงที่ส่งคืนคือครึ่งเปิดซึ่งหมายความว่าตัวชี้ท้ายชี้ *หนึ่งที่ผ่านมา* องค์ประกอบสุดท้ายของชิ้นส่วน
    /// ด้วยวิธีนี้สไลซ์ว่างจะแสดงด้วยพอยน์เตอร์สองตัวที่เท่ากันและความแตกต่างระหว่างพอยน์เตอร์ทั้งสองแสดงถึงขนาดของสไลซ์
    ///
    /// ดู [`as_mut_ptr`] สำหรับคำเตือนเกี่ยวกับการใช้พอยน์เตอร์เหล่านี้
    /// ตัวชี้สิ้นสุดต้องใช้ความระมัดระวังเป็นพิเศษเนื่องจากไม่ได้ชี้ไปที่องค์ประกอบที่ถูกต้องในชิ้นส่วน
    ///
    /// ฟังก์ชันนี้มีประโยชน์สำหรับการโต้ตอบกับอินเทอร์เฟซต่างประเทศซึ่งใช้พอยน์เตอร์สองตัวเพื่ออ้างถึงช่วงขององค์ประกอบในหน่วยความจำเช่นเดียวกับที่ใช้กันทั่วไปใน C++
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // ความปลอดภัย: ดู as_ptr_range() ด้านบนว่าทำไม `add` ที่นี่จึงปลอดภัย
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// สลับสององค์ประกอบในชิ้น
    ///
    /// # Arguments
    ///
    /// * a, ดัชนีขององค์ประกอบแรก
    /// * b, ดัชนีขององค์ประกอบที่สอง
    ///
    /// # Panics
    ///
    /// Panics ถ้า `a` หรือ `b` อยู่นอกขอบเขต
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // ไม่สามารถรับเงินกู้ที่ไม่แน่นอนสองรายการจาก vector หนึ่งได้ดังนั้นให้ใช้ตัวชี้ดิบแทน
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // ความปลอดภัย: `pa` และ `pb` ถูกสร้างขึ้นจากการอ้างอิงและการอ้างอิงที่ไม่แน่นอนที่ปลอดภัย
        // กับองค์ประกอบในสไลซ์ดังนั้นจึงรับประกันได้ว่าถูกต้องและสอดคล้องกัน
        // โปรดทราบว่าการเข้าถึงองค์ประกอบที่อยู่เบื้องหลัง `a` และ `b` จะถูกตรวจสอบและจะ panic เมื่ออยู่นอกขอบเขต
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// กลับลำดับขององค์ประกอบในสไลซ์ในสถานที่
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // สำหรับประเภทที่เล็กมากบุคคลทั้งหมดที่อ่านในเส้นทางปกติจะทำงานได้ไม่ดี
        // เราสามารถทำได้ดีขึ้นโดยให้ load/store ที่ไม่ตรงแนวที่มีประสิทธิภาพโดยการโหลดส่วนที่ใหญ่ขึ้นและย้อนกลับการลงทะเบียน
        //

        // ตามหลักการแล้ว LLVM จะทำสิ่งนี้ให้เราเนื่องจากรู้ดีกว่าที่เราทำว่าการอ่านที่ไม่ตรงแนวนั้นมีประสิทธิภาพหรือไม่ (เนื่องจากการเปลี่ยนแปลงระหว่างเวอร์ชัน ARM ที่แตกต่างกันเป็นต้น) และขนาดของชิ้นส่วนที่ดีที่สุดจะเป็นเท่าใด
        // น่าเสียดายที่ LLVM 4.0 (2017-05) มันคลายการวนซ้ำเท่านั้นดังนั้นเราจึงต้องทำสิ่งนี้ด้วยตัวเอง
        // (สมมติฐาน: การย้อนกลับเป็นเรื่องยากเนื่องจากสามารถจัดแนวด้านข้างได้แตกต่างกัน-จะเป็นเมื่อความยาวเป็นเลขคี่-ดังนั้นจึงไม่มีทางที่จะเปล่งเสียงก่อนและหลังเพื่อใช้ SIMD ที่จัดชิดตรงกลางอย่างสมบูรณ์)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // ใช้ llvm.bswap intrinsic เพื่อย้อนกลับ u8s ใน usize
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // ความปลอดภัย: มีหลายสิ่งที่ต้องตรวจสอบที่นี่:
                //
                // - โปรดทราบว่า `chunk` เป็น 4 หรือ 8 เนื่องจากการตรวจสอบ cfg ด้านบน `chunk - 1` จึงเป็นบวก
                // - การจัดทำดัชนีด้วยดัชนี `i` ทำได้ดีเนื่องจากการรับประกันการตรวจสอบลูป
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`
                // - การจัดทำดัชนีด้วยดัชนี `ln - i - chunk = ln - (i + chunk)` ทำได้ดี:
                //   - `i + chunk > 0` เป็นเรื่องจริงเล็กน้อย
                //   - การตรวจสอบลูปรับประกัน:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln` ดังนั้นการลบจึงไม่มากเกินไป
                // - การโทร `read_unaligned` และ `write_unaligned` ใช้ได้ดี:
                //   - `pa` ชี้ไปที่ดัชนี `i` โดยที่ `i < ln / 2 - (chunk - 1)` (ดูด้านบน) และ `pb` ชี้ไปที่ดัชนี `ln - i - chunk` ดังนั้นทั้งสองจึงอยู่ห่างจากจุดสิ้นสุดของ `self` อย่างน้อย `chunk` หลายไบต์
                //
                //   - หน่วยความจำเริ่มต้นใด ๆ คือ `usize` ที่ถูกต้อง
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // ใช้ rot-by-16 เพื่อย้อนกลับ u16s ใน u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // ความปลอดภัย: u32 ที่ไม่ตรงแนวสามารถอ่านได้จาก `i` ถ้า `i + 1 < ln`
                // (และเห็นได้ชัดว่า `i < ln`) เนื่องจากแต่ละองค์ประกอบมีขนาด 2 ไบต์และเรากำลังอ่าน 4
                //
                // `i + chunk - 1 < ln / 2` # ในขณะที่สภาพ
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // เนื่องจากมันน้อยกว่าความยาวหารด้วย 2 จึงต้องอยู่ในขอบเขต
                //
                // นอกจากนี้ยังหมายความว่าจะปฏิบัติตามเงื่อนไข `0 < i + chunk <= ln` เสมอเพื่อให้มั่นใจว่าตัวชี้ `pb` สามารถใช้งานได้อย่างปลอดภัย
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // ความปลอดภัย: `i` นั้นด้อยกว่าความยาวครึ่งหนึ่งของชิ้นส่วนดังนั้น
            // การเข้าถึง `i` และ `ln - i - 1` นั้นปลอดภัย (`i` เริ่มต้นที่ 0 และจะไม่ไปไกลกว่า `ln / 2 - 1`)
            // พอยน์เตอร์ผลลัพธ์ `pa` และ `pb` จึงถูกต้องและสอดคล้องกันและสามารถอ่านและเขียนถึงได้
            //
            //
            unsafe {
                // การแลกเปลี่ยนที่ไม่ปลอดภัยเพื่อหลีกเลี่ยงขอบเขตการเช็คอินที่ปลอดภัย
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// ส่งคืนตัววนซ้ำบนชิ้น
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// ส่งคืนตัววนซ้ำที่อนุญาตให้แก้ไขค่าแต่ละค่า
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// ส่งคืนตัววนซ้ำใน windows ที่ต่อเนื่องกันของความยาว `size`
    /// windows ทับซ้อนกัน
    /// ถ้าสไลซ์สั้นกว่า `size` ตัววนซ้ำจะไม่ส่งคืนค่าใด ๆ
    ///
    /// # Panics
    ///
    /// Panics ถ้า `size` เป็น 0
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// หากชิ้นส่วนสั้นกว่า `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// ส่งคืนตัววนซ้ำบนองค์ประกอบ `chunk_size` ของสไลซ์ในแต่ละครั้งโดยเริ่มที่จุดเริ่มต้นของสไลซ์
    ///
    /// ชิ้นเป็นชิ้น ๆ และไม่ทับซ้อนกันหาก `chunk_size` ไม่แบ่งความยาวของชิ้นส่วนชิ้นสุดท้ายจะไม่มีความยาว `chunk_size`
    ///
    /// ดู [`chunks_exact`] สำหรับตัวแปรของตัววนซ้ำนี้ที่ส่งคืนชิ้นส่วนขององค์ประกอบ `chunk_size` ทุกประการและ [`rchunks`] สำหรับตัววนซ้ำเดียวกัน แต่เริ่มต้นที่ส่วนท้ายของชิ้นส่วน
    ///
    ///
    /// # Panics
    ///
    /// Panics ถ้า `chunk_size` เป็น 0
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// ส่งคืนตัววนซ้ำบนองค์ประกอบ `chunk_size` ของสไลซ์ในแต่ละครั้งโดยเริ่มที่จุดเริ่มต้นของสไลซ์
    ///
    /// ชิ้นส่วนเป็นชิ้นที่ไม่แน่นอนและไม่ทับซ้อนกันหาก `chunk_size` ไม่แบ่งความยาวของชิ้นส่วนชิ้นสุดท้ายจะไม่มีความยาว `chunk_size`
    ///
    /// ดู [`chunks_exact_mut`] สำหรับตัวแปรของตัววนซ้ำนี้ที่ส่งคืนชิ้นส่วนขององค์ประกอบ `chunk_size` ทุกประการและ [`rchunks_mut`] สำหรับตัววนซ้ำเดียวกัน แต่เริ่มต้นที่ส่วนท้ายของชิ้นส่วน
    ///
    ///
    /// # Panics
    ///
    /// Panics ถ้า `chunk_size` เป็น 0
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// ส่งคืนตัววนซ้ำบนองค์ประกอบ `chunk_size` ของสไลซ์ในแต่ละครั้งโดยเริ่มที่จุดเริ่มต้นของสไลซ์
    ///
    /// ชิ้นเป็นชิ้น ๆ และไม่ทับซ้อนกัน
    /// หาก `chunk_size` ไม่แบ่งความยาวของชิ้นส่วนองค์ประกอบสุดท้ายไม่เกิน `chunk_size-1` จะถูกละเว้นและสามารถดึงข้อมูลได้จากฟังก์ชัน `remainder` ของตัววนซ้ำ
    ///
    ///
    /// เนื่องจากแต่ละชิ้นมีองค์ประกอบ `chunk_size` ที่ตรงกันคอมไพเลอร์มักจะสามารถปรับแต่งโค้ดผลลัพธ์ได้ดีกว่าในกรณีของ [`chunks`]
    ///
    /// โปรดดู [`chunks`] สำหรับตัวแปรของตัววนซ้ำนี้ซึ่งจะคืนค่าส่วนที่เหลือเป็นชิ้นส่วนที่เล็กกว่าและ [`rchunks_exact`] สำหรับตัววนซ้ำเดียวกัน แต่เริ่มต้นที่ส่วนท้ายของสไลซ์
    ///
    /// # Panics
    ///
    /// Panics ถ้า `chunk_size` เป็น 0
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// ส่งคืนตัววนซ้ำบนองค์ประกอบ `chunk_size` ของสไลซ์ในแต่ละครั้งโดยเริ่มที่จุดเริ่มต้นของสไลซ์
    ///
    /// ชิ้นส่วนเป็นชิ้นที่ไม่แน่นอนและไม่ทับซ้อนกัน
    /// หาก `chunk_size` ไม่แบ่งความยาวของชิ้นส่วนองค์ประกอบสุดท้ายไม่เกิน `chunk_size-1` จะถูกละเว้นและสามารถดึงข้อมูลได้จากฟังก์ชัน `into_remainder` ของตัววนซ้ำ
    ///
    ///
    /// เนื่องจากแต่ละชิ้นมีองค์ประกอบ `chunk_size` ที่ตรงกันคอมไพเลอร์มักจะสามารถปรับแต่งโค้ดผลลัพธ์ได้ดีกว่าในกรณีของ [`chunks_mut`]
    ///
    /// โปรดดู [`chunks_mut`] สำหรับตัวแปรของตัววนซ้ำนี้ซึ่งจะคืนค่าส่วนที่เหลือเป็นชิ้นส่วนที่เล็กกว่าและ [`rchunks_exact_mut`] สำหรับตัววนซ้ำเดียวกัน แต่เริ่มต้นที่ส่วนท้ายของสไลซ์
    ///
    /// # Panics
    ///
    /// Panics ถ้า `chunk_size` เป็น 0
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// แยกชิ้นส่วนออกเป็นอาร์เรย์ขององค์ประกอบ "N" โดยสมมติว่าไม่มีเศษเหลืออยู่
    ///
    ///
    /// # Safety
    ///
    /// สิ่งนี้อาจเรียกได้ก็ต่อเมื่อ
    /// - ชิ้นส่วนแบ่งออกเป็นชิ้นส่วน "N` อย่างแน่นอน (aka `self.len() % N == 0`)
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // ความปลอดภัย: ชิ้นส่วน 1 องค์ประกอบไม่เคยมีเหลือ
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // ความปลอดภัย: ความยาวชิ้น (6) เป็นผลคูณของ 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // สิ่งเหล่านี้จะไม่เป็นสาระ:
    /// // ให้ชิ้น: &[[_;5]]= slice.as_chunks_unchecked()//ความยาวสไลซ์ไม่ใช่ผลคูณของ 5 ให้ชิ้น:&[[_;0]]= slice.as_chunks_unchecked()//ไม่อนุญาตให้ใช้ชิ้นส่วนที่มีความยาวเป็นศูนย์
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // ความปลอดภัย: เงื่อนไขเบื้องต้นของเราคือสิ่งที่จำเป็นในการเรียกสิ่งนี้
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // ความปลอดภัย: เราโยนองค์ประกอบ `new_len * N` เข้าไป
        // ชิ้น `new_len` ชิ้นส่วน `N` จำนวนมาก
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// แยกชิ้นส่วนออกเป็นชิ้นส่วนของอาร์เรย์องค์ประกอบ "N" โดยเริ่มจากจุดเริ่มต้นของชิ้นส่วนและชิ้นส่วนที่เหลือที่มีความยาวน้อยกว่า `N` อย่างเคร่งครัด
    ///
    ///
    /// # Panics
    ///
    /// Panics ถ้า `N` เป็น 0 การตรวจสอบนี้ส่วนใหญ่อาจถูกเปลี่ยนเป็นข้อผิดพลาดเวลาคอมไพล์ก่อนที่วิธีนี้จะเสถียร
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // ความปลอดภัย: เราตื่นตระหนกเป็นศูนย์แล้วและมั่นใจได้ด้วยการก่อสร้าง
        // ว่าความยาวของส่วนย่อยเป็นผลคูณของ N
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// แยกชิ้นส่วนออกเป็นชิ้นส่วนของอาร์เรย์องค์ประกอบ "N" โดยเริ่มจากจุดสิ้นสุดของชิ้นส่วนและชิ้นส่วนที่เหลือที่มีความยาวน้อยกว่า `N` อย่างเคร่งครัด
    ///
    ///
    /// # Panics
    ///
    /// Panics ถ้า `N` เป็น 0 การตรวจสอบนี้ส่วนใหญ่อาจถูกเปลี่ยนเป็นข้อผิดพลาดเวลาคอมไพล์ก่อนที่วิธีนี้จะเสถียร
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // ความปลอดภัย: เราตื่นตระหนกเป็นศูนย์แล้วและมั่นใจได้ด้วยการก่อสร้าง
        // ว่าความยาวของส่วนย่อยเป็นผลคูณของ N
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// ส่งคืนตัววนซ้ำบนองค์ประกอบ `N` ของสไลซ์ในแต่ละครั้งโดยเริ่มที่จุดเริ่มต้นของสไลซ์
    ///
    /// ส่วนนี้เป็นการอ้างอิงอาร์เรย์และไม่ทับซ้อนกัน
    /// หาก `N` ไม่แบ่งความยาวของชิ้นส่วนองค์ประกอบสุดท้ายไม่เกิน `N-1` จะถูกละเว้นและสามารถดึงข้อมูลได้จากฟังก์ชัน `remainder` ของตัววนซ้ำ
    ///
    ///
    /// วิธีนี้เท่ากับ const ทั่วไปของ [`chunks_exact`]
    ///
    /// # Panics
    ///
    /// Panics ถ้า `N` เป็น 0 การตรวจสอบนี้ส่วนใหญ่อาจถูกเปลี่ยนเป็นข้อผิดพลาดเวลาคอมไพล์ก่อนที่วิธีนี้จะเสถียร
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// แยกชิ้นส่วนออกเป็นอาร์เรย์ขององค์ประกอบ "N" โดยสมมติว่าไม่มีเศษเหลืออยู่
    ///
    ///
    /// # Safety
    ///
    /// สิ่งนี้อาจเรียกได้ก็ต่อเมื่อ
    /// - ชิ้นส่วนแบ่งออกเป็นชิ้นส่วน "N` อย่างแน่นอน (aka `self.len() % N == 0`)
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // ความปลอดภัย: ชิ้นส่วน 1 องค์ประกอบไม่เคยมีเหลือ
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // ความปลอดภัย: ความยาวชิ้น (6) เป็นผลคูณของ 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // สิ่งเหล่านี้จะไม่เป็นสาระ:
    /// // ให้ชิ้น: &[[_;5]]= slice.as_chunks_unchecked_mut()//ความยาวสไลซ์ไม่ใช่ผลคูณของ 5 ให้ชิ้น:&[[_;0]]= slice.as_chunks_unchecked_mut()//ไม่อนุญาตให้ใช้ชิ้นส่วนที่มีความยาวเป็นศูนย์
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // ความปลอดภัย: เงื่อนไขเบื้องต้นของเราคือสิ่งที่จำเป็นในการเรียกสิ่งนี้
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // ความปลอดภัย: เราโยนองค์ประกอบ `new_len * N` เข้าไป
        // ชิ้น `new_len` ชิ้นส่วน `N` จำนวนมาก
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// แยกชิ้นส่วนออกเป็นชิ้นส่วนของอาร์เรย์องค์ประกอบ "N" โดยเริ่มจากจุดเริ่มต้นของชิ้นส่วนและชิ้นส่วนที่เหลือที่มีความยาวน้อยกว่า `N` อย่างเคร่งครัด
    ///
    ///
    /// # Panics
    ///
    /// Panics ถ้า `N` เป็น 0 การตรวจสอบนี้ส่วนใหญ่อาจถูกเปลี่ยนเป็นข้อผิดพลาดเวลาคอมไพล์ก่อนที่วิธีนี้จะเสถียร
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // ความปลอดภัย: เราตื่นตระหนกเป็นศูนย์แล้วและมั่นใจได้ด้วยการก่อสร้าง
        // ว่าความยาวของส่วนย่อยเป็นผลคูณของ N
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// แยกชิ้นส่วนออกเป็นชิ้นส่วนของอาร์เรย์องค์ประกอบ "N" โดยเริ่มจากจุดสิ้นสุดของชิ้นส่วนและชิ้นส่วนที่เหลือที่มีความยาวน้อยกว่า `N` อย่างเคร่งครัด
    ///
    ///
    /// # Panics
    ///
    /// Panics ถ้า `N` เป็น 0 การตรวจสอบนี้ส่วนใหญ่อาจถูกเปลี่ยนเป็นข้อผิดพลาดเวลาคอมไพล์ก่อนที่วิธีนี้จะเสถียร
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // ความปลอดภัย: เราตื่นตระหนกเป็นศูนย์แล้วและมั่นใจได้ด้วยการก่อสร้าง
        // ว่าความยาวของส่วนย่อยเป็นผลคูณของ N
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// ส่งคืนตัววนซ้ำบนองค์ประกอบ `N` ของสไลซ์ในแต่ละครั้งโดยเริ่มที่จุดเริ่มต้นของสไลซ์
    ///
    /// ชิ้นส่วนเป็นการอ้างอิงอาร์เรย์ที่ไม่แน่นอนและไม่ทับซ้อนกัน
    /// หาก `N` ไม่แบ่งความยาวของชิ้นส่วนองค์ประกอบสุดท้ายไม่เกิน `N-1` จะถูกละเว้นและสามารถดึงข้อมูลได้จากฟังก์ชัน `into_remainder` ของตัววนซ้ำ
    ///
    ///
    /// วิธีนี้เท่ากับ const ทั่วไปของ [`chunks_exact_mut`]
    ///
    /// # Panics
    ///
    /// Panics ถ้า `N` เป็น 0 การตรวจสอบนี้ส่วนใหญ่อาจถูกเปลี่ยนเป็นข้อผิดพลาดเวลาคอมไพล์ก่อนที่วิธีนี้จะเสถียร
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// ส่งคืนตัววนซ้ำบนองค์ประกอบ windows ของ `N` ที่ทับซ้อนกันของชิ้นงานโดยเริ่มที่จุดเริ่มต้นของชิ้นส่วน
    ///
    ///
    /// นี่คือค่าทั่วไปที่เทียบเท่ากับ [`windows`]
    ///
    /// ถ้า `N` มากกว่าขนาดของชิ้นส่วนจะไม่ส่งคืน windows
    ///
    /// # Panics
    ///
    /// Panics ถ้า `N` เป็น 0
    /// การตรวจสอบนี้มักจะเปลี่ยนเป็นข้อผิดพลาดเวลาคอมไพล์ก่อนที่วิธีนี้จะเสถียร
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// ส่งคืนตัววนซ้ำบนองค์ประกอบ `chunk_size` ของสไลซ์ในแต่ละครั้งโดยเริ่มจากจุดสิ้นสุดของสไลซ์
    ///
    /// ชิ้นเป็นชิ้น ๆ และไม่ทับซ้อนกันหาก `chunk_size` ไม่แบ่งความยาวของชิ้นส่วนชิ้นสุดท้ายจะไม่มีความยาว `chunk_size`
    ///
    /// ดู [`rchunks_exact`] สำหรับตัวแปรของตัววนซ้ำนี้ที่ส่งคืนชิ้นส่วนขององค์ประกอบ `chunk_size` เสมอและ [`chunks`] สำหรับตัววนซ้ำเดียวกัน แต่เริ่มต้นที่จุดเริ่มต้นของชิ้นส่วน
    ///
    ///
    /// # Panics
    ///
    /// Panics ถ้า `chunk_size` เป็น 0
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// ส่งคืนตัววนซ้ำบนองค์ประกอบ `chunk_size` ของสไลซ์ในแต่ละครั้งโดยเริ่มจากจุดสิ้นสุดของสไลซ์
    ///
    /// ชิ้นส่วนเป็นชิ้นที่ไม่แน่นอนและไม่ทับซ้อนกันหาก `chunk_size` ไม่แบ่งความยาวของชิ้นส่วนชิ้นสุดท้ายจะไม่มีความยาว `chunk_size`
    ///
    /// ดู [`rchunks_exact_mut`] สำหรับตัวแปรของตัววนซ้ำนี้ที่ส่งคืนชิ้นส่วนขององค์ประกอบ `chunk_size` เสมอและ [`chunks_mut`] สำหรับตัววนซ้ำเดียวกัน แต่เริ่มต้นที่จุดเริ่มต้นของชิ้นส่วน
    ///
    ///
    /// # Panics
    ///
    /// Panics ถ้า `chunk_size` เป็น 0
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// ส่งคืนตัววนซ้ำบนองค์ประกอบ `chunk_size` ของสไลซ์ในแต่ละครั้งโดยเริ่มจากจุดสิ้นสุดของสไลซ์
    ///
    /// ชิ้นเป็นชิ้น ๆ และไม่ทับซ้อนกัน
    /// หาก `chunk_size` ไม่แบ่งความยาวของชิ้นส่วนองค์ประกอบสุดท้ายไม่เกิน `chunk_size-1` จะถูกละเว้นและสามารถดึงข้อมูลได้จากฟังก์ชัน `remainder` ของตัววนซ้ำ
    ///
    /// เนื่องจากแต่ละชิ้นมีองค์ประกอบ `chunk_size` ที่ตรงกันคอมไพเลอร์มักจะสามารถปรับแต่งโค้ดผลลัพธ์ได้ดีกว่าในกรณีของ [`chunks`]
    ///
    /// โปรดดู [`rchunks`] สำหรับตัวแปรของตัววนซ้ำนี้ซึ่งจะคืนค่าส่วนที่เหลือเป็นชิ้นส่วนที่เล็กกว่าและ [`chunks_exact`] สำหรับตัววนซ้ำเดียวกัน แต่เริ่มต้นที่จุดเริ่มต้นของชิ้นส่วน
    ///
    ///
    /// # Panics
    ///
    /// Panics ถ้า `chunk_size` เป็น 0
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// ส่งคืนตัววนซ้ำบนองค์ประกอบ `chunk_size` ของสไลซ์ในแต่ละครั้งโดยเริ่มจากจุดสิ้นสุดของสไลซ์
    ///
    /// ชิ้นส่วนเป็นชิ้นที่ไม่แน่นอนและไม่ทับซ้อนกัน
    /// หาก `chunk_size` ไม่แบ่งความยาวของชิ้นส่วนองค์ประกอบสุดท้ายไม่เกิน `chunk_size-1` จะถูกละเว้นและสามารถดึงข้อมูลได้จากฟังก์ชัน `into_remainder` ของตัววนซ้ำ
    ///
    /// เนื่องจากแต่ละชิ้นมีองค์ประกอบ `chunk_size` ที่ตรงกันคอมไพเลอร์มักจะสามารถปรับแต่งโค้ดผลลัพธ์ได้ดีกว่าในกรณีของ [`chunks_mut`]
    ///
    /// โปรดดู [`rchunks_mut`] สำหรับตัวแปรของตัววนซ้ำนี้ซึ่งจะคืนค่าส่วนที่เหลือเป็นชิ้นส่วนที่เล็กกว่าและ [`chunks_exact_mut`] สำหรับตัววนซ้ำเดียวกัน แต่เริ่มต้นที่จุดเริ่มต้นของชิ้นส่วน
    ///
    ///
    /// # Panics
    ///
    /// Panics ถ้า `chunk_size` เป็น 0
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// ส่งคืนตัววนซ้ำบนชิ้นส่วนที่สร้างการรันองค์ประกอบที่ไม่ทับซ้อนกันโดยใช้เพรดิเคตเพื่อแยกองค์ประกอบ
    ///
    /// เพรดิเคตถูกเรียกบนสององค์ประกอบตามหลังตัวมันเองหมายความว่าเพรดิเคตถูกเรียกบน `slice[0]` และ `slice[1]` จากนั้นบน `slice[1]` และ `slice[2]` และอื่น ๆ
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// วิธีนี้สามารถใช้เพื่อแยกส่วนย่อยที่เรียงลำดับ:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// ส่งคืนตัววนซ้ำบนชิ้นส่วนที่สร้างการรันองค์ประกอบที่ไม่ทับซ้อนกันโดยใช้เพรดิเคตเพื่อแยกองค์ประกอบ
    ///
    /// เพรดิเคตถูกเรียกบนสององค์ประกอบตามหลังตัวมันเองหมายความว่าเพรดิเคตถูกเรียกบน `slice[0]` และ `slice[1]` จากนั้นบน `slice[1]` และ `slice[2]` และอื่น ๆ
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// วิธีนี้สามารถใช้เพื่อแยกส่วนย่อยที่เรียงลำดับ:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// แบ่งหนึ่งชิ้นออกเป็นสองชิ้นที่ดัชนี
    ///
    /// ดัชนีแรกจะประกอบด้วยดัชนีทั้งหมดจาก `[0, mid)` (ไม่รวมดัชนี `mid` เอง) และดัชนีที่สองจะมีดัชนีทั้งหมดจาก `[mid, len)` (ไม่รวมดัชนี `len` เอง)
    ///
    ///
    /// # Panics
    ///
    /// Panics ถ้า `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // ความปลอดภัย: `[ptr; mid]` และ `[mid; len]` อยู่ภายใน `self` ซึ่ง
        // ตอบสนองความต้องการของ `from_raw_parts_mut`
        unsafe { self.split_at_unchecked(mid) }
    }

    /// แบ่งชิ้นส่วนที่เปลี่ยนแปลงได้หนึ่งชิ้นออกเป็นสองชิ้นที่ดัชนี
    ///
    /// ดัชนีแรกจะประกอบด้วยดัชนีทั้งหมดจาก `[0, mid)` (ไม่รวมดัชนี `mid` เอง) และดัชนีที่สองจะมีดัชนีทั้งหมดจาก `[mid, len)` (ไม่รวมดัชนี `len` เอง)
    ///
    ///
    /// # Panics
    ///
    /// Panics ถ้า `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // ความปลอดภัย: `[ptr; mid]` และ `[mid; len]` อยู่ภายใน `self` ซึ่ง
        // ตอบสนองความต้องการของ `from_raw_parts_mut`
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// แบ่งชิ้นส่วนหนึ่งออกเป็นสองชิ้นที่ดัชนีโดยไม่ต้องทำการตรวจสอบขอบเขต
    ///
    /// ดัชนีแรกจะประกอบด้วยดัชนีทั้งหมดจาก `[0, mid)` (ไม่รวมดัชนี `mid` เอง) และดัชนีที่สองจะมีดัชนีทั้งหมดจาก `[mid, len)` (ไม่รวมดัชนี `len` เอง)
    ///
    ///
    /// สำหรับทางเลือกที่ปลอดภัยโปรดดู [`split_at`]
    ///
    /// # Safety
    ///
    /// การเรียกเมธอดนี้ด้วยดัชนีนอกขอบเขตคือ *[undefined behavior]* แม้ว่าจะไม่ได้ใช้การอ้างอิงที่เป็นผลลัพธ์ก็ตามผู้โทรต้องแน่ใจว่า `0 <= mid <= self.len()`
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // ความปลอดภัย: ผู้โทรต้องตรวจสอบว่า `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// แบ่งชิ้นส่วนที่เปลี่ยนแปลงได้หนึ่งชิ้นออกเป็นสองชิ้นที่ดัชนีโดยไม่ต้องทำการตรวจสอบขอบเขต
    ///
    /// ดัชนีแรกจะประกอบด้วยดัชนีทั้งหมดจาก `[0, mid)` (ไม่รวมดัชนี `mid` เอง) และดัชนีที่สองจะมีดัชนีทั้งหมดจาก `[mid, len)` (ไม่รวมดัชนี `len` เอง)
    ///
    ///
    /// สำหรับทางเลือกที่ปลอดภัยโปรดดู [`split_at_mut`]
    ///
    /// # Safety
    ///
    /// การเรียกเมธอดนี้ด้วยดัชนีนอกขอบเขตคือ *[undefined behavior]* แม้ว่าจะไม่ได้ใช้การอ้างอิงที่เป็นผลลัพธ์ก็ตามผู้โทรต้องแน่ใจว่า `0 <= mid <= self.len()`
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // ความปลอดภัย: ผู้โทรต้องตรวจสอบว่า `0 <= mid <= self.len()`
        //
        // `[ptr; mid]` และ `[mid; len]` ไม่ทับซ้อนกันดังนั้นการส่งคืนข้อมูลอ้างอิงที่ไม่แน่นอนจึงใช้ได้
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// ส่งคืนตัววนซ้ำบนส่วนย่อยที่คั่นด้วยองค์ประกอบที่ตรงกับ `pred`
    /// องค์ประกอบที่ตรงกันไม่มีอยู่ในส่วนย่อย
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// หากองค์ประกอบแรกตรงกันชิ้นส่วนว่างจะเป็นรายการแรกที่ส่งคืนโดยตัววนซ้ำ
    /// ในทำนองเดียวกันถ้าองค์ประกอบสุดท้ายในชิ้นตรงกันชิ้นที่ว่างเปล่าจะเป็นรายการสุดท้ายที่ส่งคืนโดยตัววนซ้ำ:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// หากองค์ประกอบที่ตรงกันสององค์ประกอบอยู่ติดกันโดยตรงจะมีสไลซ์ว่างอยู่ระหว่างองค์ประกอบเหล่านี้:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// ส่งคืนตัววนซ้ำบนส่วนย่อยที่ผันแปรได้โดยคั่นด้วยองค์ประกอบที่ตรงกับ `pred`
    /// องค์ประกอบที่ตรงกันไม่มีอยู่ในส่วนย่อย
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// ส่งคืนตัววนซ้ำบนส่วนย่อยที่คั่นด้วยองค์ประกอบที่ตรงกับ `pred`
    /// องค์ประกอบที่ตรงกันจะอยู่ในส่วนท้ายของส่วนย่อยก่อนหน้านี้ในฐานะเทอร์มิเนเตอร์
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// หากจับคู่องค์ประกอบสุดท้ายของชิ้นส่วนองค์ประกอบนั้นจะถือว่าเป็นตัวยุติของชิ้นส่วนก่อนหน้า
    ///
    /// ชิ้นส่วนนั้นจะเป็นรายการสุดท้ายที่ส่งคืนโดยตัววนซ้ำ
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// ส่งคืนตัววนซ้ำบนส่วนย่อยที่ผันแปรได้โดยคั่นด้วยองค์ประกอบที่ตรงกับ `pred`
    /// องค์ประกอบที่ตรงกันมีอยู่ในส่วนย่อยก่อนหน้านี้เป็นเทอร์มิเนเตอร์
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// ส่งคืนตัววนซ้ำบนส่วนย่อยที่คั่นด้วยองค์ประกอบที่ตรงกับ `pred` เริ่มต้นที่จุดสิ้นสุดของชิ้นส่วนและทำงานย้อนกลับ
    /// องค์ประกอบที่ตรงกันไม่มีอยู่ในส่วนย่อย
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// เช่นเดียวกับ `split()` หากมีการจับคู่องค์ประกอบแรกหรือองค์ประกอบสุดท้ายสไลซ์ว่างจะเป็นรายการแรก (หรือรายการสุดท้าย) ที่ส่งคืนโดยตัววนซ้ำ
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// ส่งคืนตัววนซ้ำบนส่วนย่อยที่ผันแปรได้โดยคั่นด้วยองค์ประกอบที่ตรงกับ `pred` เริ่มต้นที่ส่วนท้ายของชิ้นส่วนและทำงานย้อนกลับ
    /// องค์ประกอบที่ตรงกันไม่มีอยู่ในส่วนย่อย
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// ส่งคืนตัววนซ้ำบนส่วนย่อยที่คั่นด้วยองค์ประกอบที่ตรงกับ `pred` โดย จำกัด ให้ส่งคืนรายการ `n` มากที่สุด
    /// องค์ประกอบที่ตรงกันไม่มีอยู่ในส่วนย่อย
    ///
    /// องค์ประกอบสุดท้ายที่ส่งคืนถ้ามีจะมีส่วนที่เหลือของชิ้นส่วน
    ///
    /// # Examples
    ///
    /// พิมพ์สไลซ์แยกหนึ่งครั้งโดยตัวเลขหารด้วย 3 (เช่น `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// ส่งคืนตัววนซ้ำบนส่วนย่อยที่คั่นด้วยองค์ประกอบที่ตรงกับ `pred` โดย จำกัด ให้ส่งคืนรายการ `n` มากที่สุด
    /// องค์ประกอบที่ตรงกันไม่มีอยู่ในส่วนย่อย
    ///
    /// องค์ประกอบสุดท้ายที่ส่งคืนถ้ามีจะมีส่วนที่เหลือของชิ้นส่วน
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// ส่งคืนตัววนซ้ำบนส่วนย่อยที่คั่นด้วยองค์ประกอบที่ตรงกับ `pred` จำกัด เพื่อส่งคืนรายการ `n` ส่วนใหญ่
    /// สิ่งนี้เริ่มต้นที่ส่วนท้ายของชิ้นส่วนและทำงานย้อนกลับ
    /// องค์ประกอบที่ตรงกันไม่มีอยู่ในส่วนย่อย
    ///
    /// องค์ประกอบสุดท้ายที่ส่งคืนถ้ามีจะมีส่วนที่เหลือของชิ้นส่วน
    ///
    /// # Examples
    ///
    /// พิมพ์สไลซ์แยกหนึ่งครั้งโดยเริ่มจากจุดสิ้นสุดโดยตัวเลขหารด้วย 3 (เช่น `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// ส่งคืนตัววนซ้ำบนส่วนย่อยที่คั่นด้วยองค์ประกอบที่ตรงกับ `pred` จำกัด เพื่อส่งคืนรายการ `n` ส่วนใหญ่
    /// สิ่งนี้เริ่มต้นที่ส่วนท้ายของชิ้นส่วนและทำงานย้อนกลับ
    /// องค์ประกอบที่ตรงกันไม่มีอยู่ในส่วนย่อย
    ///
    /// องค์ประกอบสุดท้ายที่ส่งคืนถ้ามีจะมีส่วนที่เหลือของชิ้นส่วน
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// ส่งคืน `true` หากสไลซ์มีองค์ประกอบที่มีค่าที่กำหนด
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// หากคุณไม่มี `&T` แต่มีเพียง `&U` เช่นนั้น `T: Borrow<U>` (เช่น
    /// `สตริง: ยืม<str>`) คุณสามารถใช้ `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // ชิ้น `String`
    /// assert!(v.iter().any(|e| e == "hello")); // ค้นหาด้วย `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// ส่งคืน `true` หาก `needle` เป็นคำนำหน้าของชิ้นส่วน
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// ส่งคืน `true` เสมอหาก `needle` เป็นสไลซ์ว่าง:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// ส่งคืน `true` หาก `needle` เป็นส่วนต่อท้ายของชิ้นส่วน
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// ส่งคืน `true` เสมอหาก `needle` เป็นสไลซ์ว่าง:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// ส่งคืนส่วนย่อยโดยลบคำนำหน้าออก
    ///
    /// หากสไลซ์เริ่มต้นด้วย `prefix` ให้ส่งกลับส่วนย่อยหลังส่วนนำหน้าโดยรวมด้วย `Some`
    /// หาก `prefix` ว่างเปล่าเพียงแค่ส่งคืนชิ้นส่วนเดิม
    ///
    /// หากสไลซ์ไม่ได้ขึ้นต้นด้วย `prefix` ให้ส่งคืน `None`
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // ฟังก์ชันนี้จะต้องเขียนใหม่ถ้าและเมื่อใดที่ SlicePattern มีความซับซ้อนมากขึ้น
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// ส่งคืนส่วนย่อยโดยลบคำต่อท้ายออก
    ///
    /// หากสไลซ์ลงท้ายด้วย `suffix` ให้ส่งกลับส่วนย่อยก่อนส่วนต่อท้ายโดยรวม `Some`
    /// หาก `suffix` ว่างเปล่าเพียงแค่ส่งคืนชิ้นส่วนเดิม
    ///
    /// หากสไลซ์ไม่ได้ลงท้ายด้วย `suffix` ให้ส่งคืน `None`
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // ฟังก์ชันนี้จะต้องเขียนใหม่ถ้าและเมื่อใดที่ SlicePattern มีความซับซ้อนมากขึ้น
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// ไบนารีค้นหาชิ้นส่วนที่จัดเรียงนี้สำหรับองค์ประกอบที่กำหนด
    ///
    /// หากพบค่า [`Result::Ok`] จะถูกส่งกลับโดยมีดัชนีขององค์ประกอบที่ตรงกัน
    /// หากมีการแข่งขันหลายรายการอาจมีการส่งคืนรายการใดรายการหนึ่ง
    /// หากไม่พบค่าจะส่งคืน [`Result::Err`] ซึ่งมีดัชนีที่สามารถแทรกองค์ประกอบที่ตรงกันได้ในขณะที่รักษาลำดับที่เรียงไว้
    ///
    ///
    /// ดู [`binary_search_by`], [`binary_search_by_key`] และ [`partition_point`] ด้วย
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// ค้นหาชุดของสี่องค์ประกอบ
    /// พบครั้งแรกด้วยตำแหน่งที่กำหนดโดยเฉพาะไม่พบที่สองและสามที่สี่สามารถจับคู่ตำแหน่งใดก็ได้ใน `[1, 4]`
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// หากคุณต้องการแทรกรายการไปยัง vector ที่เรียงลำดับในขณะที่รักษาลำดับการจัดเรียง:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// ไบนารีค้นหาชิ้นส่วนที่เรียงลำดับนี้ด้วยฟังก์ชันเปรียบเทียบ
    ///
    /// ฟังก์ชันตัวเปรียบเทียบควรใช้คำสั่งที่สอดคล้องกับลำดับการจัดเรียงของชิ้นส่วนที่อยู่เบื้องหลังโดยส่งคืนรหัสคำสั่งที่ระบุว่าอาร์กิวเมนต์คือ `Less`, `Equal` หรือ `Greater` เป็นเป้าหมายที่ต้องการหรือไม่
    ///
    ///
    /// หากพบค่า [`Result::Ok`] จะถูกส่งกลับโดยมีดัชนีขององค์ประกอบที่ตรงกันหากมีการแข่งขันหลายรายการอาจมีการส่งคืนรายการใดรายการหนึ่ง
    /// หากไม่พบค่าจะส่งคืน [`Result::Err`] ซึ่งมีดัชนีที่สามารถแทรกองค์ประกอบที่ตรงกันได้ในขณะที่รักษาลำดับที่เรียงไว้
    ///
    /// ดู [`binary_search`], [`binary_search_by_key`] และ [`partition_point`] ด้วย
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// ค้นหาชุดของสี่องค์ประกอบพบครั้งแรกด้วยตำแหน่งที่กำหนดโดยเฉพาะไม่พบที่สองและสามที่สี่สามารถจับคู่ตำแหน่งใดก็ได้ใน `[1, 4]`
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // ความปลอดภัย: การโทรจะปลอดภัยโดยค่าคงที่ต่อไปนี้:
            // - `mid >= 0`
            // - `mid < size`: `mid` ถูก จำกัด โดย `[left; right)` ที่ผูกไว้
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // สาเหตุที่เราใช้โฟลว์การควบคุม if/else แทนที่จะใช้การจับคู่เนื่องจากการจับคู่เรียงลำดับการดำเนินการเปรียบเทียบซึ่งมีความละเอียดอ่อน
            //
            // นี่คือ x86 asm สำหรับ u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// ไบนารีค้นหาชิ้นส่วนที่เรียงลำดับนี้ด้วยฟังก์ชันการแยกคีย์
    ///
    /// สมมติว่าชิ้นส่วนเรียงตามคีย์เช่น [`sort_by_key`] โดยใช้ฟังก์ชันการแยกคีย์เดียวกัน
    ///
    /// หากพบค่า [`Result::Ok`] จะถูกส่งกลับโดยมีดัชนีขององค์ประกอบที่ตรงกัน
    /// หากมีการแข่งขันหลายรายการอาจมีการส่งคืนรายการใดรายการหนึ่ง
    /// หากไม่พบค่าจะส่งคืน [`Result::Err`] ซึ่งมีดัชนีที่สามารถแทรกองค์ประกอบที่ตรงกันได้ในขณะที่รักษาลำดับที่เรียงไว้
    ///
    ///
    /// ดู [`binary_search`], [`binary_search_by`] และ [`partition_point`] ด้วย
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// ค้นหาชุดของสี่องค์ประกอบในส่วนของคู่ที่เรียงตามองค์ประกอบที่สอง
    /// พบครั้งแรกด้วยตำแหน่งที่กำหนดโดยเฉพาะไม่พบที่สองและสามที่สี่สามารถจับคู่ตำแหน่งใดก็ได้ใน `[1, 4]`
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links ได้รับอนุญาตเนื่องจาก `slice::sort_by_key` อยู่ใน crate `alloc` และยังไม่มีอยู่เมื่อสร้าง `core`
    //
    // ลิงก์ไปยังดาวน์สตรีม crate: #74481 เนื่องจาก primitives ได้รับการบันทึกไว้ใน libstd (#73423) เท่านั้นจึงไม่นำไปสู่การเชื่อมโยงที่เสียในทางปฏิบัติ
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// จัดเรียงชิ้นส่วน แต่อาจไม่รักษาลำดับขององค์ประกอบที่เท่ากัน
    ///
    /// การเรียงลำดับนี้ไม่เสถียร (กล่าวคืออาจเรียงลำดับองค์ประกอบที่เท่ากันใหม่) ในตำแหน่ง (เช่นไม่จัดสรร) และ *O*(*n*\*log(* n*)) กรณีที่เลวร้ายที่สุด
    ///
    /// # การใช้งานปัจจุบัน
    ///
    /// อัลกอริทึมปัจจุบันอยู่บนพื้นฐานของ [pattern-defeating quicksort][pdqsort] โดย Orson Peters ซึ่งรวมกรณีค่าเฉลี่ยที่รวดเร็วของ Quicksort แบบสุ่มกับกรณีที่เลวร้ายที่สุดของ heapsort อย่างรวดเร็วในขณะที่บรรลุเวลาเชิงเส้นบนชิ้นงานที่มีรูปแบบบางอย่าง
    /// มันใช้การสุ่มบางอย่างเพื่อหลีกเลี่ยงกรณีที่เสื่อมสภาพ แต่ด้วย seed คงที่เพื่อให้พฤติกรรมที่กำหนดไว้เสมอ
    ///
    /// โดยทั่วไปแล้วจะเร็วกว่าการเรียงลำดับแบบคงที่ยกเว้นในกรณีพิเศษบางประการเช่นเมื่อชิ้นส่วนประกอบด้วยลำดับที่เรียงต่อกันหลาย ๆ
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// จัดเรียงชิ้นส่วนด้วยฟังก์ชันเปรียบเทียบ แต่อาจไม่รักษาลำดับขององค์ประกอบที่เท่ากัน
    ///
    /// การเรียงลำดับนี้ไม่เสถียร (กล่าวคืออาจเรียงลำดับองค์ประกอบที่เท่ากันใหม่) ในตำแหน่ง (เช่นไม่จัดสรร) และ *O*(*n*\*log(* n*)) กรณีที่เลวร้ายที่สุด
    ///
    /// ฟังก์ชันตัวเปรียบเทียบต้องกำหนดการจัดลำดับทั้งหมดสำหรับองค์ประกอบในสไลซ์หากการสั่งซื้อไม่รวมลำดับขององค์ประกอบจะไม่ระบุคำสั่งซื้อคือคำสั่งซื้อทั้งหมดหากเป็น (สำหรับ `a`, `b` และ `c` ทั้งหมด):
    ///
    /// * รวมและ antisymmetric: หนึ่งใน `a < b`, `a == b` หรือ `a > b` เป็นจริงและ
    /// * สกรรมกริยา `a < b` และ `b < c` หมายถึง `a < c` สิ่งเดียวกันจะต้องมีไว้สำหรับทั้ง `==` และ `>`
    ///
    /// ตัวอย่างเช่นในขณะที่ [`f64`] ไม่ใช้ [`Ord`] เนื่องจาก `NaN != NaN` เราสามารถใช้ `partial_cmp` เป็นฟังก์ชันการจัดเรียงของเราเมื่อเรารู้ว่าชิ้นส่วนไม่มี `NaN`
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # การใช้งานปัจจุบัน
    ///
    /// อัลกอริทึมปัจจุบันอยู่บนพื้นฐานของ [pattern-defeating quicksort][pdqsort] โดย Orson Peters ซึ่งรวมกรณีค่าเฉลี่ยที่รวดเร็วของ Quicksort แบบสุ่มกับกรณีที่เลวร้ายที่สุดของ heapsort อย่างรวดเร็วในขณะที่บรรลุเวลาเชิงเส้นบนชิ้นงานที่มีรูปแบบบางอย่าง
    /// มันใช้การสุ่มบางอย่างเพื่อหลีกเลี่ยงกรณีที่เสื่อมสภาพ แต่ด้วย seed คงที่เพื่อให้พฤติกรรมที่กำหนดไว้เสมอ
    ///
    /// โดยทั่วไปแล้วจะเร็วกว่าการเรียงลำดับแบบคงที่ยกเว้นในกรณีพิเศษบางประการเช่นเมื่อชิ้นส่วนประกอบด้วยลำดับที่เรียงต่อกันหลาย ๆ
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // การเรียงลำดับย้อนกลับ
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// จัดเรียงชิ้นส่วนด้วยฟังก์ชันการแยกคีย์ แต่อาจไม่รักษาลำดับขององค์ประกอบที่เท่ากัน
    ///
    /// การเรียงลำดับนี้ไม่เสถียร (กล่าวคืออาจเรียงลำดับองค์ประกอบที่เท่ากันใหม่) ในตำแหน่ง (เช่นไม่จัดสรร) และ *O*(m\* * n *\* log(*n*)) กรณีที่แย่ที่สุดโดยที่ฟังก์ชันคีย์คือ *O*(*ม.*).
    ///
    /// # การใช้งานปัจจุบัน
    ///
    /// อัลกอริทึมปัจจุบันอยู่บนพื้นฐานของ [pattern-defeating quicksort][pdqsort] โดย Orson Peters ซึ่งรวมกรณีค่าเฉลี่ยที่รวดเร็วของ Quicksort แบบสุ่มกับกรณีที่เลวร้ายที่สุดของ heapsort อย่างรวดเร็วในขณะที่บรรลุเวลาเชิงเส้นบนชิ้นงานที่มีรูปแบบบางอย่าง
    /// มันใช้การสุ่มบางอย่างเพื่อหลีกเลี่ยงกรณีที่เสื่อมสภาพ แต่ด้วย seed คงที่เพื่อให้พฤติกรรมที่กำหนดไว้เสมอ
    ///
    /// เนื่องจากกลยุทธ์การโทรที่สำคัญ [`sort_unstable_by_key`](#method.sort_unstable_by_key) จึงมีแนวโน้มที่จะช้ากว่า [`sort_by_cached_key`](#method.sort_by_cached_key) ในกรณีที่ฟังก์ชันคีย์มีราคาแพง
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// จัดเรียงชิ้นส่วนใหม่เพื่อให้องค์ประกอบที่ `index` อยู่ในตำแหน่งที่เรียงลำดับสุดท้าย
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// จัดเรียงชิ้นส่วนใหม่ด้วยฟังก์ชันเปรียบเทียบเพื่อให้องค์ประกอบที่ `index` อยู่ในตำแหน่งที่เรียงลำดับสุดท้าย
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// จัดเรียงชิ้นส่วนใหม่ด้วยฟังก์ชันการแยกคีย์เพื่อให้องค์ประกอบที่ `index` อยู่ในตำแหน่งที่เรียงลำดับสุดท้าย
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// จัดเรียงชิ้นส่วนใหม่เพื่อให้องค์ประกอบที่ `index` อยู่ในตำแหน่งที่เรียงลำดับสุดท้าย
    ///
    /// การจัดลำดับใหม่นี้มีคุณสมบัติเพิ่มเติมที่ค่าใด ๆ ที่ตำแหน่ง `i < index` จะน้อยกว่าหรือเท่ากับค่าใด ๆ ที่ตำแหน่ง `j > index`
    /// นอกจากนี้การจัดลำดับใหม่นี้ไม่เสถียร (เช่น
    /// จำนวนขององค์ประกอบที่เท่ากันอาจลงเอยที่ตำแหน่ง `index`) ในตำแหน่ง (เช่น
    /// ไม่จัดสรร) และ *O*(*n*) กรณีที่เลวร้ายที่สุด
    /// ฟังก์ชันนี้เรียกอีกอย่างว่า "kth element" ในไลบรารีอื่น ๆ
    /// จะส่งคืนค่าสามเท่าของค่าต่อไปนี้: องค์ประกอบทั้งหมดน้อยกว่าค่าหนึ่งในดัชนีที่กำหนดค่าที่ดัชนีที่กำหนดและองค์ประกอบทั้งหมดที่มากกว่าค่าหนึ่งในดัชนีที่กำหนด
    ///
    ///
    /// # การใช้งานปัจจุบัน
    ///
    /// อัลกอริทึมปัจจุบันขึ้นอยู่กับส่วนการเลือกอย่างรวดเร็วของอัลกอริทึม Quicksort เดียวกับที่ใช้สำหรับ [`sort_unstable`]
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics เมื่อ `index >= len()` หมายถึง panics เสมอบนชิ้นงานที่ว่างเปล่า
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // หาค่ามัธยฐาน
    /// v.select_nth_unstable(2);
    ///
    /// // เรารับประกันเฉพาะชิ้นส่วนจะเป็นหนึ่งในสิ่งต่อไปนี้ตามวิธีที่เราจัดเรียงเกี่ยวกับดัชนีที่ระบุ
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// จัดเรียงชิ้นส่วนใหม่ด้วยฟังก์ชันเปรียบเทียบเพื่อให้องค์ประกอบที่ `index` อยู่ในตำแหน่งที่เรียงลำดับสุดท้าย
    ///
    /// การจัดลำดับใหม่นี้มีคุณสมบัติเพิ่มเติมที่ค่าใด ๆ ที่ตำแหน่ง `i < index` จะน้อยกว่าหรือเท่ากับค่าใด ๆ ที่ตำแหน่ง `j > index` โดยใช้ฟังก์ชันตัวเปรียบเทียบ
    /// นอกจากนี้การจัดลำดับใหม่นี้ไม่เสถียร (กล่าวคือจำนวนองค์ประกอบที่เท่ากันอาจลงเอยที่ตำแหน่ง `index`) ในตำแหน่ง (เช่นไม่จัดสรร) และกรณีที่เลวร้ายที่สุด *O*(*n*)
    /// ฟังก์ชันนี้เรียกอีกอย่างว่า "kth element" ในไลบรารีอื่น ๆ
    /// จะส่งคืนค่าสามเท่าของค่าต่อไปนี้: องค์ประกอบทั้งหมดน้อยกว่าค่าหนึ่งในดัชนีที่กำหนดค่าที่ดัชนีที่กำหนดและองค์ประกอบทั้งหมดที่มากกว่าค่าหนึ่งในดัชนีที่กำหนดโดยใช้ฟังก์ชันตัวเปรียบเทียบที่ให้มา
    ///
    ///
    /// # การใช้งานปัจจุบัน
    ///
    /// อัลกอริทึมปัจจุบันขึ้นอยู่กับส่วนการเลือกอย่างรวดเร็วของอัลกอริทึม Quicksort เดียวกับที่ใช้สำหรับ [`sort_unstable`]
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics เมื่อ `index >= len()` หมายถึง panics เสมอบนชิ้นงานที่ว่างเปล่า
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // ค้นหาค่ามัธยฐานราวกับว่าชิ้นส่วนถูกเรียงลำดับจากมากไปหาน้อย
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // เรารับประกันเฉพาะชิ้นส่วนจะเป็นหนึ่งในสิ่งต่อไปนี้ตามวิธีที่เราจัดเรียงเกี่ยวกับดัชนีที่ระบุ
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// จัดเรียงชิ้นส่วนใหม่ด้วยฟังก์ชันการแยกคีย์เพื่อให้องค์ประกอบที่ `index` อยู่ในตำแหน่งที่เรียงลำดับสุดท้าย
    ///
    /// การจัดลำดับใหม่นี้มีคุณสมบัติเพิ่มเติมที่ค่าใด ๆ ที่ตำแหน่ง `i < index` จะน้อยกว่าหรือเท่ากับค่าใด ๆ ที่ตำแหน่ง `j > index` โดยใช้ฟังก์ชันการแยกคีย์
    /// นอกจากนี้การจัดลำดับใหม่นี้ไม่เสถียร (กล่าวคือจำนวนองค์ประกอบที่เท่ากันอาจลงเอยที่ตำแหน่ง `index`) ในตำแหน่ง (เช่นไม่จัดสรร) และกรณีที่เลวร้ายที่สุด *O*(*n*)
    /// ฟังก์ชันนี้เรียกอีกอย่างว่า "kth element" ในไลบรารีอื่น ๆ
    /// จะส่งคืนค่าสามเท่าของค่าต่อไปนี้: องค์ประกอบทั้งหมดน้อยกว่าค่าหนึ่งในดัชนีที่กำหนดค่าที่ดัชนีที่กำหนดและองค์ประกอบทั้งหมดที่มากกว่าค่าหนึ่งในดัชนีที่กำหนดโดยใช้ฟังก์ชันการแยกคีย์ที่มีให้
    ///
    ///
    /// # การใช้งานปัจจุบัน
    ///
    /// อัลกอริทึมปัจจุบันขึ้นอยู่กับส่วนการเลือกอย่างรวดเร็วของอัลกอริทึม Quicksort เดียวกับที่ใช้สำหรับ [`sort_unstable`]
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics เมื่อ `index >= len()` หมายถึง panics เสมอบนชิ้นงานที่ว่างเปล่า
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // ส่งกลับค่ามัธยฐานราวกับว่าอาร์เรย์ถูกจัดเรียงตามค่าสัมบูรณ์
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // เรารับประกันเฉพาะชิ้นส่วนจะเป็นหนึ่งในสิ่งต่อไปนี้ตามวิธีที่เราจัดเรียงเกี่ยวกับดัชนีที่ระบุ
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// ย้ายองค์ประกอบที่ทำซ้ำติดต่อกันทั้งหมดไปยังจุดสิ้นสุดของสไลซ์ตามการใช้งาน [`PartialEq`] trait
    ///
    ///
    /// ส่งคืนสองชิ้นรายการแรกไม่มีองค์ประกอบที่ซ้ำกันอย่างต่อเนื่อง
    /// รายการที่สองประกอบด้วยรายการที่ซ้ำกันทั้งหมดในลำดับที่ไม่ได้ระบุ
    ///
    /// หากจัดเรียงชิ้นส่วนชิ้นส่วนที่ส่งคืนแรกจะไม่มีรายการที่ซ้ำกัน
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// ย้ายองค์ประกอบทั้งหมดยกเว้นองค์ประกอบแรกที่ต่อเนื่องกันไปยังจุดสิ้นสุดของชิ้นส่วนเพื่อให้ได้ความสัมพันธ์ที่เท่าเทียมกัน
    ///
    /// ส่งคืนสองชิ้นรายการแรกไม่มีองค์ประกอบที่ซ้ำกันอย่างต่อเนื่อง
    /// รายการที่สองประกอบด้วยรายการที่ซ้ำกันทั้งหมดในลำดับที่ไม่ได้ระบุ
    ///
    /// ฟังก์ชัน `same_bucket` ถูกส่งต่อการอ้างอิงไปยังสององค์ประกอบจากชิ้นส่วนและต้องพิจารณาว่าองค์ประกอบเปรียบเทียบเท่ากันหรือไม่
    /// องค์ประกอบจะถูกส่งต่อในลำดับที่ตรงกันข้ามจากลำดับของพวกมันในชิ้นดังนั้นหาก `same_bucket(a, b)` ส่งคืน `true` `a` จะถูกย้ายไปที่ส่วนท้ายของชิ้น
    ///
    ///
    /// หากจัดเรียงชิ้นส่วนชิ้นส่วนที่ส่งคืนแรกจะไม่มีรายการที่ซ้ำกัน
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // แม้ว่าเราจะมีการอ้างอิงที่ไม่แน่นอนถึง `self` แต่เราไม่สามารถทำการเปลี่ยนแปลง *โดยพลการ* ได้การเรียก `same_bucket` สามารถ panic ดังนั้นเราต้องตรวจสอบให้แน่ใจว่าชิ้นส่วนอยู่ในสถานะที่ถูกต้องตลอดเวลา
        //
        // วิธีที่เราจัดการกับสิ่งนี้คือการใช้การแลกเปลี่ยนเราวนซ้ำองค์ประกอบทั้งหมดสลับไปมาเพื่อให้ในตอนท้ายองค์ประกอบที่เราต้องการจะเก็บไว้ด้านหน้าและสิ่งที่เราต้องการปฏิเสธจะอยู่ด้านหลัง
        // จากนั้นเราสามารถแบ่งชิ้น
        // การดำเนินการนี้ยังคงเป็น `O(n)`
        //
        // ตัวอย่าง: เราเริ่มต้นในสถานะนี้โดยที่ `r` แสดงถึง "next
        // อ่าน "และ `w` แทน" next_write "
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // การเปรียบเทียบ self[r] กับ self [w-1] นี่ไม่ใช่รายการที่ซ้ำกันดังนั้นเราจึงสลับ self[r] และ self[w] (ไม่มีผลเป็น r==w) จากนั้นเพิ่มทั้ง r และ w โดยปล่อยให้เรา:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // การเปรียบเทียบ self[r] กับ self [w-1] ค่านี้ซ้ำกันดังนั้นเราจึงเพิ่ม `r` แต่ปล่อยให้ทุกอย่างไม่เปลี่ยนแปลง:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // การเปรียบเทียบ self[r] กับ self [w-1] นี่ไม่ใช่รายการที่ซ้ำกันดังนั้นให้สลับ self[r] และ self[w] และเลื่อน r และ w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // ไม่ซ้ำกันทำซ้ำ:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // ซ้ำ advance r. End ของชิ้นแยกที่ w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // ความปลอดภัย: เงื่อนไข `while` รับประกัน `next_read` และ `next_write`
        // น้อยกว่า `len` ดังนั้นจึงอยู่ภายใน `self`
        // `prev_ptr_write` ชี้ไปที่องค์ประกอบหนึ่งก่อน `ptr_write` แต่ `next_write` เริ่มต้นที่ 1 ดังนั้น `prev_ptr_write` จึงไม่น้อยกว่า 0 และอยู่ในชิ้นส่วน
        // สิ่งนี้เป็นไปตามข้อกำหนดสำหรับการอ้างอิง `ptr_read`, `prev_ptr_write` และ `ptr_write` และสำหรับการใช้ `ptr.add(next_read)`, `ptr.add(next_write - 1)` และ `prev_ptr_write.offset(1)`
        //
        //
        // `next_write` นอกจากนี้ยังเพิ่มขึ้นไม่เกินหนึ่งครั้งต่อลูปโดยมากที่สุดหมายความว่าจะไม่มีการข้ามองค์ประกอบเมื่ออาจจำเป็นต้องสลับ
        //
        // `ptr_read` และ `prev_ptr_write` ไม่เคยชี้ไปที่องค์ประกอบเดียวกันสิ่งนี้จำเป็นสำหรับ `&mut *ptr_read`, `&mut* prev_ptr_write` เพื่อความปลอดภัย
        // คำอธิบายก็คือ `next_read >= next_write` เป็นจริงเสมอดังนั้น `next_read > next_write - 1` ก็เช่นกัน
        //
        //
        //
        //
        //
        unsafe {
            // หลีกเลี่ยงการตรวจสอบขอบเขตโดยใช้ตัวชี้ดิบ
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// ย้ายองค์ประกอบทั้งหมดยกเว้นองค์ประกอบแรกที่ต่อเนื่องกันไปยังจุดสิ้นสุดของสไลซ์ที่แก้ไขเป็นคีย์เดียวกัน
    ///
    ///
    /// ส่งคืนสองชิ้นรายการแรกไม่มีองค์ประกอบที่ซ้ำกันอย่างต่อเนื่อง
    /// รายการที่สองประกอบด้วยรายการที่ซ้ำกันทั้งหมดในลำดับที่ไม่ได้ระบุ
    ///
    /// หากจัดเรียงชิ้นส่วนชิ้นส่วนที่ส่งคืนแรกจะไม่มีรายการที่ซ้ำกัน
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// หมุนชิ้นส่วนในตำแหน่งเพื่อให้องค์ประกอบ `mid` แรกของชิ้นส่วนเลื่อนไปจนสุดในขณะที่องค์ประกอบ `self.len() - mid` สุดท้ายเคลื่อนไปด้านหน้า
    /// หลังจากเรียก `rotate_left` องค์ประกอบก่อนหน้านี้ที่ดัชนี `mid` จะกลายเป็นองค์ประกอบแรกในสไลซ์
    ///
    /// # Panics
    ///
    /// ฟังก์ชันนี้จะเป็น panic ถ้า `mid` มากกว่าความยาวของชิ้นส่วนโปรดทราบว่า `mid == self.len()` ทำ _not_ panic และเป็นการหมุนแบบไม่ต้องหมุน
    ///
    /// # Complexity
    ///
    /// ใช้เวลาเชิงเส้น (ในเวลา `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// การหมุน subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // ความปลอดภัย: ช่วง `[p.add(mid) - mid, p.add(mid) + k)` นั้นไม่สำคัญ
        // ใช้ได้กับการอ่านและเขียนตามที่ `ptr_rotate` กำหนด
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// หมุนชิ้นส่วนในตำแหน่งเพื่อให้องค์ประกอบ `self.len() - k` แรกของชิ้นส่วนเลื่อนไปจนสุดในขณะที่องค์ประกอบ `k` สุดท้ายเคลื่อนไปด้านหน้า
    /// หลังจากเรียก `rotate_right` องค์ประกอบก่อนหน้านี้ที่ดัชนี `self.len() - k` จะกลายเป็นองค์ประกอบแรกในสไลซ์
    ///
    /// # Panics
    ///
    /// ฟังก์ชันนี้จะเป็น panic ถ้า `k` มากกว่าความยาวของชิ้นส่วนโปรดทราบว่า `k == self.len()` ทำ _not_ panic และเป็นการหมุนแบบไม่ต้องหมุน
    ///
    /// # Complexity
    ///
    /// ใช้เวลาเชิงเส้น (ในเวลา `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// หมุน subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // ความปลอดภัย: ช่วง `[p.add(mid) - mid, p.add(mid) + k)` นั้นไม่สำคัญ
        // ใช้ได้กับการอ่านและเขียนตามที่ `ptr_rotate` กำหนด
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// เติม `self` ด้วยองค์ประกอบโดยการโคลน `value`
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// เติม `self` ด้วยองค์ประกอบที่ส่งคืนโดยการเรียกการปิดซ้ำ ๆ
    ///
    /// วิธีนี้ใช้การปิดเพื่อสร้างค่านิยมใหม่หากคุณต้องการ [`Clone`] เป็นค่าที่กำหนดให้ใช้ [`fill`]
    /// หากคุณต้องการใช้ [`Default`] trait เพื่อสร้างค่าคุณสามารถส่ง [`Default::default`] เป็นอาร์กิวเมนต์ได้
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// คัดลอกองค์ประกอบจาก `src` เป็น `self`
    ///
    /// ความยาวของ `src` ต้องเท่ากับ `self`
    ///
    /// หาก `T` ใช้ `Copy` จะมีประสิทธิภาพมากกว่าที่จะใช้ [`copy_from_slice`]
    ///
    /// # Panics
    ///
    /// ฟังก์ชันนี้จะเป็น panic หากทั้งสองชิ้นมีความยาวต่างกัน
    ///
    /// # Examples
    ///
    /// การโคลนสององค์ประกอบจากชิ้นส่วนไปเป็นอีกชิ้นหนึ่ง:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // เนื่องจากชิ้นส่วนต้องมีความยาวเท่ากันเราจึงฝานชิ้นส่วนต้นทางจากสี่องค์ประกอบเป็นสองชิ้น
    /// // มันจะเป็น panic ถ้าเราไม่ทำเช่นนี้
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust บังคับว่าสามารถมีการอ้างอิงที่เปลี่ยนแปลงได้เพียงรายการเดียวโดยไม่มีการอ้างอิงที่ไม่เปลี่ยนรูปไปยังชิ้นส่วนข้อมูลเฉพาะในขอบเขตเฉพาะ
    /// ด้วยเหตุนี้การพยายามใช้ `clone_from_slice` ในสไลซ์เดียวจะทำให้คอมไพล์ล้มเหลว:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// ในการแก้ไขปัญหานี้เราสามารถใช้ [`split_at_mut`] เพื่อสร้างชิ้นส่วนย่อยที่แตกต่างกันสองชิ้นจากชิ้น:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// คัดลอกองค์ประกอบทั้งหมดจาก `src` ไปยัง `self` โดยใช้ memcpy
    ///
    /// ความยาวของ `src` ต้องเท่ากับ `self`
    ///
    /// หาก `T` ไม่ใช้ `Copy` ให้ใช้ [`clone_from_slice`]
    ///
    /// # Panics
    ///
    /// ฟังก์ชันนี้จะเป็น panic หากทั้งสองชิ้นมีความยาวต่างกัน
    ///
    /// # Examples
    ///
    /// การคัดลอกสององค์ประกอบจากชิ้นส่วนไปยังอีกชิ้นหนึ่ง:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // เนื่องจากชิ้นส่วนต้องมีความยาวเท่ากันเราจึงฝานชิ้นส่วนต้นทางจากสี่องค์ประกอบเป็นสองชิ้น
    /// // มันจะเป็น panic ถ้าเราไม่ทำเช่นนี้
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust บังคับว่าสามารถมีการอ้างอิงที่เปลี่ยนแปลงได้เพียงรายการเดียวโดยไม่มีการอ้างอิงที่ไม่เปลี่ยนรูปไปยังชิ้นส่วนข้อมูลเฉพาะในขอบเขตเฉพาะ
    /// ด้วยเหตุนี้การพยายามใช้ `copy_from_slice` ในสไลซ์เดียวจะทำให้คอมไพล์ล้มเหลว:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// ในการแก้ไขปัญหานี้เราสามารถใช้ [`split_at_mut`] เพื่อสร้างชิ้นส่วนย่อยที่แตกต่างกันสองชิ้นจากชิ้น:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // เส้นทางรหัส panic ถูกใส่ลงในฟังก์ชันเย็นเพื่อไม่ให้ไซต์การโทรขยายตัว
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // ความปลอดภัย: `self` ใช้ได้กับองค์ประกอบ `self.len()` ตามความหมายและ `src` คือ
        // ตรวจสอบว่ามีความยาวเท่ากัน
        // ชิ้นส่วนไม่สามารถทับซ้อนกันได้เนื่องจากการอ้างอิงที่เปลี่ยนแปลงไม่ได้เป็นเอกสิทธิ์
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// คัดลอกองค์ประกอบจากส่วนหนึ่งของชิ้นส่วนไปยังอีกส่วนหนึ่งของตัวมันเองโดยใช้ memmove
    ///
    /// `src` คือช่วงภายใน `self` ที่จะคัดลอก
    /// `dest` คือดัชนีเริ่มต้นของช่วงภายใน `self` ที่จะคัดลอกซึ่งจะมีความยาวเท่ากับ `src`
    /// สองช่วงอาจทับซ้อนกัน
    /// จุดสิ้นสุดของสองช่วงต้องน้อยกว่าหรือเท่ากับ `self.len()`
    ///
    /// # Panics
    ///
    /// ฟังก์ชันนี้จะ panic หากช่วงใดช่วงหนึ่งเกินจุดสิ้นสุดของชิ้นส่วนหรือถ้าจุดสิ้นสุดของ `src` อยู่ก่อนเริ่มต้น
    ///
    ///
    /// # Examples
    ///
    /// การคัดลอกสี่ไบต์ภายในชิ้น:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // ความปลอดภัย: เงื่อนไขของ `ptr::copy` ได้รับการตรวจสอบข้างต้นแล้ว
        // เช่นเดียวกับที่มีสำหรับ `ptr::add`
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// สลับองค์ประกอบทั้งหมดใน `self` กับองค์ประกอบใน `other`
    ///
    /// ความยาวของ `other` ต้องเท่ากับ `self`
    ///
    /// # Panics
    ///
    /// ฟังก์ชันนี้จะเป็น panic หากทั้งสองชิ้นมีความยาวต่างกัน
    ///
    /// # Example
    ///
    /// การสลับสององค์ประกอบในส่วนต่างๆ:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust บังคับว่าสามารถมีการอ้างอิงที่เปลี่ยนแปลงได้เพียงรายการเดียวสำหรับข้อมูลส่วนหนึ่งในขอบเขตเฉพาะ
    ///
    /// ด้วยเหตุนี้การพยายามใช้ `swap_with_slice` ในสไลซ์เดียวจะทำให้คอมไพล์ล้มเหลว:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// ในการแก้ไขปัญหานี้เราสามารถใช้ [`split_at_mut`] เพื่อสร้างชิ้นส่วนย่อยที่ไม่ซ้ำกันสองชิ้นจากชิ้น:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // ความปลอดภัย: `self` ใช้ได้กับองค์ประกอบ `self.len()` ตามความหมายและ `src` คือ
        // ตรวจสอบว่ามีความยาวเท่ากัน
        // ชิ้นส่วนไม่สามารถทับซ้อนกันได้เนื่องจากการอ้างอิงที่เปลี่ยนแปลงไม่ได้เป็นเอกสิทธิ์
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// ฟังก์ชันคำนวณความยาวของชิ้นส่วนตรงกลางและส่วนท้ายสำหรับ `align_to{,_mut}`
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // สิ่งที่เราจะทำเกี่ยวกับ `rest` คือการหาจำนวนคูณของ "U" ที่เราสามารถใส่ "T" ต่ำสุดได้
        //
        // และเราต้องการกี่ตัวสำหรับ "multiple" แต่ละตัว
        //
        // ลองพิจารณาตัวอย่างเช่น T=u8 U=u16จากนั้นเราสามารถใส่ 1 U ใน 2 Tsเรียบง่าย
        // ลองพิจารณาตัวอย่างกรณีที่ size_of: :<T>=16, size_of::<U>=24.</u>
        // เราสามารถใส่ 2 Us แทนทุกๆ 3 Ts ในชิ้น `rest` ได้
        // ซับซ้อนขึ้นเล็กน้อย
        //
        // สูตรในการคำนวณคือ:
        //
        // เรา= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // ขยายและทำให้ง่ายขึ้น:
        //
        // เรา=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // โชคดีเนื่องจากทั้งหมดนี้ได้รับการประเมินอย่างต่อเนื่อง ... ประสิทธิภาพที่นี่ไม่สำคัญ!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // อัลกอริทึมของสไตน์แบบวนซ้ำเราควรจะสร้าง `const fn` นี้ (และเปลี่ยนกลับเป็นอัลกอริทึมแบบวนซ้ำถ้าเราทำ) เพราะอาศัย llvm เพื่อกำหนดทั้งหมดนี้คือ ... ดีมันทำให้ฉันไม่สบายใจ
            //
            //

            // ความปลอดภัย: `a` และ `b` ถูกตรวจสอบว่าเป็นค่าที่ไม่ใช่ศูนย์
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // ลบปัจจัยทั้งหมดของ 2 ออกจาก b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // ความปลอดภัย: `b` ถูกตรวจสอบว่าไม่ใช่ศูนย์
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // ด้วยความรู้นี้เราจะพบว่าเราสามารถใส่ได้กี่ตัว!
        let us_len = self.len() / ts * us;
        // และจะมีกี่ตัว "T" ในชิ้นส่วนต่อท้าย!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// เปลี่ยนชิ้นส่วนเป็นชิ้นส่วนประเภทอื่นเพื่อให้มั่นใจว่าการจัดตำแหน่งของประเภทจะยังคงอยู่
    ///
    /// วิธีนี้จะแบ่งชิ้นส่วนออกเป็นสามส่วนที่แตกต่างกัน: คำนำหน้า, จัดเรียงชิ้นส่วนตรงกลางของประเภทใหม่อย่างถูกต้องและชิ้นส่วนต่อท้าย
    /// วิธีนี้อาจทำให้ชิ้นส่วนตรงกลางมีความยาวมากที่สุดเท่าที่จะเป็นไปได้สำหรับประเภทและชิ้นส่วนอินพุตที่กำหนด แต่ประสิทธิภาพของอัลกอริทึมของคุณเท่านั้นที่ควรขึ้นอยู่กับสิ่งนั้นไม่ใช่ความถูกต้อง
    ///
    /// อนุญาตให้ส่งคืนข้อมูลอินพุตทั้งหมดเป็นส่วนคำนำหน้าหรือส่วนต่อท้าย
    ///
    /// วิธีนี้ไม่มีจุดประสงค์เมื่อองค์ประกอบอินพุต `T` หรือองค์ประกอบเอาต์พุต `U` มีขนาดเป็นศูนย์และจะส่งคืนชิ้นส่วนเดิมโดยไม่แยกส่วนใด ๆ
    ///
    /// # Safety
    ///
    /// วิธีนี้โดยพื้นฐานแล้วคือ `transmute` เมื่อเทียบกับองค์ประกอบในชิ้นส่วนตรงกลางที่ส่งคืนดังนั้นคำเตือนตามปกติทั้งหมดที่เกี่ยวข้องกับ `transmute::<T, U>` จึงนำไปใช้ที่นี่ด้วย
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // โปรดทราบว่าฟังก์ชันนี้ส่วนใหญ่จะได้รับการประเมินค่าคงที่
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // จัดการ ZST เป็นพิเศษซึ่งก็คือ-อย่าจัดการเลย
            return (self, &[], &[]);
        }

        // ขั้นแรกให้ค้นหาว่าจุดใดที่เราแยกระหว่างชิ้นแรกและชิ้นที่ 2
        // ง่ายด้วย ptr.align_offset
        let ptr = self.as_ptr();
        // ความปลอดภัย: ดูวิธี `align_to_mut` สำหรับคำอธิบายด้านความปลอดภัยโดยละเอียด
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // ความปลอดภัย: ตอนนี้ `rest` อยู่ในแนวเดียวกันอย่างแน่นอนดังนั้น `from_raw_parts` ด้านล่างก็โอเค
            // เนื่องจากผู้โทรรับประกันว่าเราสามารถส่งสัญญาณ `T` เป็น `U` ได้อย่างปลอดภัย
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// เปลี่ยนชิ้นส่วนเป็นชิ้นส่วนประเภทอื่นเพื่อให้มั่นใจว่าการจัดตำแหน่งของประเภทจะยังคงอยู่
    ///
    /// วิธีนี้จะแบ่งชิ้นส่วนออกเป็นสามส่วนที่แตกต่างกัน: คำนำหน้า, จัดเรียงชิ้นส่วนตรงกลางของประเภทใหม่อย่างถูกต้องและชิ้นส่วนต่อท้าย
    /// วิธีนี้อาจทำให้ชิ้นส่วนตรงกลางมีความยาวมากที่สุดเท่าที่จะเป็นไปได้สำหรับประเภทและชิ้นส่วนอินพุตที่กำหนด แต่ประสิทธิภาพของอัลกอริทึมของคุณเท่านั้นที่ควรขึ้นอยู่กับสิ่งนั้นไม่ใช่ความถูกต้อง
    ///
    /// อนุญาตให้ส่งคืนข้อมูลอินพุตทั้งหมดเป็นส่วนคำนำหน้าหรือส่วนต่อท้าย
    ///
    /// วิธีนี้ไม่มีจุดประสงค์เมื่อองค์ประกอบอินพุต `T` หรือองค์ประกอบเอาต์พุต `U` มีขนาดเป็นศูนย์และจะส่งคืนชิ้นส่วนเดิมโดยไม่แยกส่วนใด ๆ
    ///
    /// # Safety
    ///
    /// วิธีนี้โดยพื้นฐานแล้วคือ `transmute` เมื่อเทียบกับองค์ประกอบในชิ้นส่วนตรงกลางที่ส่งคืนดังนั้นคำเตือนตามปกติทั้งหมดที่เกี่ยวข้องกับ `transmute::<T, U>` จึงนำไปใช้ที่นี่ด้วย
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // โปรดทราบว่าฟังก์ชันนี้ส่วนใหญ่จะได้รับการประเมินค่าคงที่
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // จัดการ ZST เป็นพิเศษซึ่งก็คือ-อย่าจัดการเลย
            return (self, &mut [], &mut []);
        }

        // ขั้นแรกให้ค้นหาว่าจุดใดที่เราแยกระหว่างชิ้นแรกและชิ้นที่ 2
        // ง่ายด้วย ptr.align_offset
        let ptr = self.as_ptr();
        // ความปลอดภัย: ที่นี่เรามั่นใจว่าเราจะใช้คำแนะนำที่สอดคล้องกับ U สำหรับไฟล์
        // วิธีที่เหลือทำได้โดยส่งตัวชี้ไปที่&[T] โดยมีการจัดตำแหน่งที่กำหนดเป้าหมายสำหรับ U
        // `crate::ptr::align_offset` ถูกเรียกด้วยตัวชี้ที่จัดตำแหน่งอย่างถูกต้องและถูกต้อง `ptr` (มาจากการอ้างอิงถึง `self`) และด้วยขนาดที่มีกำลังสอง (เนื่องจากมาจากการจัดตำแหน่งสำหรับ U) ซึ่งเป็นไปตามข้อ จำกัด ด้านความปลอดภัย
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // เราไม่สามารถใช้ `rest` ได้อีกหลังจากนี้ซึ่งจะทำให้นามแฝง `mut_ptr` เป็นโมฆะ!ความปลอดภัย: ดูความคิดเห็นสำหรับ `align_to`
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// ตรวจสอบว่าองค์ประกอบของส่วนนี้เรียงลำดับหรือไม่
    ///
    /// นั่นคือสำหรับแต่ละองค์ประกอบ `a` และองค์ประกอบต่อไปนี้ `b` ต้องถือ `a <= b` หากชิ้นส่วนให้ผลเป็นศูนย์หรือองค์ประกอบเดียว `true` จะถูกส่งกลับ
    ///
    /// โปรดทราบว่าถ้า `Self::Item` เป็นเพียง `PartialOrd` แต่ไม่ใช่ `Ord` คำจำกัดความข้างต้นหมายความว่าฟังก์ชันนี้จะส่งคืนค่า `false` หากรายการใด ๆ ที่ต่อเนื่องกันสองรายการไม่สามารถเทียบเคียงกันได้
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// ตรวจสอบว่าองค์ประกอบของชิ้นส่วนนี้เรียงลำดับโดยใช้ฟังก์ชันตัวเปรียบเทียบที่กำหนดหรือไม่
    ///
    /// แทนที่จะใช้ `PartialOrd::partial_cmp` ฟังก์ชันนี้จะใช้ฟังก์ชัน `compare` ที่กำหนดเพื่อกำหนดลำดับของสององค์ประกอบ
    /// นอกเหนือจากนั้นเทียบเท่ากับ [`is_sorted`] ดูเอกสารประกอบสำหรับข้อมูลเพิ่มเติม
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// ตรวจสอบว่าองค์ประกอบของชิ้นส่วนนี้เรียงลำดับโดยใช้ฟังก์ชันการแยกคีย์ที่กำหนดหรือไม่
    ///
    /// แทนที่จะเปรียบเทียบองค์ประกอบของชิ้นส่วนโดยตรงฟังก์ชันนี้จะเปรียบเทียบคีย์ขององค์ประกอบตามที่กำหนดโดย `f`
    /// นอกเหนือจากนั้นเทียบเท่ากับ [`is_sorted`] ดูเอกสารประกอบสำหรับข้อมูลเพิ่มเติม
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// ส่งคืนดัชนีของจุดพาร์ติชันตามเพรดิเคตที่กำหนด (ดัชนีขององค์ประกอบแรกของพาร์ติชันที่สอง)
    ///
    /// ชิ้นส่วนจะถือว่าแบ่งพาร์ติชันตามเพรดิเคตที่กำหนด
    /// ซึ่งหมายความว่าองค์ประกอบทั้งหมดที่เพรดิเคตส่งคืนเป็นจริงจะอยู่ที่จุดเริ่มต้นของสไลซ์และองค์ประกอบทั้งหมดที่เพรดิเคตส่งคืนเป็นเท็จจะอยู่ในตอนท้าย
    ///
    /// ตัวอย่างเช่น [7, 15, 3, 5, 4, 12, 6] เป็นพาร์ติชันที่อยู่ภายใต้เพรดิเคต x% 2!=0 (จำนวนคี่ทั้งหมดอยู่ที่จุดเริ่มต้นแม้จะอยู่ท้ายสุด)
    ///
    /// หากชิ้นส่วนนี้ไม่ได้แบ่งพาร์ติชันผลลัพธ์ที่ส่งคืนจะไม่ระบุและไม่มีความหมายเนื่องจากวิธีนี้ทำการค้นหาแบบไบนารี
    ///
    /// ดู [`binary_search`], [`binary_search_by`] และ [`binary_search_by_key`] ด้วย
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // ความปลอดภัย: เมื่อ `left < right` `left <= mid < right`.
            // ดังนั้น `left` จึงเพิ่มขึ้นเสมอและ `right` จะลดลงเสมอและเลือกอย่างใดอย่างหนึ่งในทั้งสองกรณี `left <= right` พอใจดังนั้นหาก `left < right` ในขั้นตอน `left <= right` พอใจในขั้นตอนถัดไป
            //
            // ดังนั้นตราบเท่าที่ `left != right`, `0 <= left < right <= len` พอใจและถ้ากรณีนี้ `0 <= mid < len` ก็พอใจเช่นกัน
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: เราจำเป็นต้องหั่นให้มีความยาวเท่ากันอย่างชัดเจน
        // เพื่อให้เครื่องมือเพิ่มประสิทธิภาพสามารถหลีกเลี่ยงการตรวจสอบขอบเขตได้ง่ายขึ้น
        // แต่เนื่องจากไม่สามารถพึ่งพาได้เราจึงมีความเชี่ยวชาญที่ชัดเจนสำหรับ T: Copy
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// สร้างชิ้นส่วนที่ว่างเปล่า
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// สร้างชิ้นส่วนว่างเปล่าที่ไม่แน่นอน
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// รูปแบบเป็นชิ้นในปัจจุบันใช้โดย `strip_prefix` และ `strip_suffix` เท่านั้น
/// ที่จุด future เราหวังว่าจะทำให้ `core::str::Pattern` (ซึ่งในขณะที่เขียนถูก จำกัด ไว้ที่ `str`) เป็นชิ้นส่วนจากนั้น trait นี้จะถูกแทนที่หรือยกเลิก
///
pub trait SlicePattern {
    /// ประเภทองค์ประกอบของชิ้นส่วนที่จับคู่
    type Item;

    /// ปัจจุบันผู้บริโภค `SlicePattern` ต้องการชิ้นส่วน
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}