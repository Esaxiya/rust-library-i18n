//! การดำเนินการบน ASCII `[u8]`

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// ตรวจสอบว่าไบต์ทั้งหมดในสไลซ์นี้อยู่ในช่วง ASCII หรือไม่
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// ตรวจสอบว่าสองส่วนเป็นการจับคู่แบบไม่คำนึงถึงขนาดตัวพิมพ์ของ ASCII
    ///
    /// เหมือนกับ `to_ascii_lowercase(a) == to_ascii_lowercase(b)` แต่ไม่มีการจัดสรรและคัดลอกชั่วคราว
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// แปลงชิ้นส่วนนี้เป็นตัวพิมพ์ใหญ่ที่เทียบเท่ากับ ASCII ในตำแหน่ง
    ///
    /// ตัวอักษร ASCII 'a' ถึง 'z' ถูกแมปกับ 'A' ถึง 'Z' แต่ตัวอักษรที่ไม่ใช่ ASCII จะไม่เปลี่ยนแปลง
    ///
    /// หากต้องการส่งคืนค่าตัวพิมพ์ใหญ่ใหม่โดยไม่ต้องแก้ไขค่าที่มีอยู่ให้ใช้ [`to_ascii_uppercase`]
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// แปลงชิ้นส่วนนี้เป็น ASCII ตัวพิมพ์เล็กที่เทียบเท่าในตำแหน่ง
    ///
    /// ตัวอักษร ASCII 'A' ถึง 'Z' ถูกแมปกับ 'a' ถึง 'z' แต่ตัวอักษรที่ไม่ใช่ ASCII จะไม่เปลี่ยนแปลง
    ///
    /// หากต้องการส่งคืนค่าที่ลดลงใหม่โดยไม่ต้องแก้ไขค่าที่มีอยู่ให้ใช้ [`to_ascii_lowercase`]
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// ส่งคืนค่า `true` หากไบต์ใด ๆ ในคำว่า `v` เป็น nonascii (>=128)
/// Snarfed จาก `../str/mod.rs` ซึ่งทำสิ่งที่คล้ายกันสำหรับการตรวจสอบความถูกต้อง utf8
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// การทดสอบ ASCII ที่ได้รับการปรับให้เหมาะสมซึ่งจะใช้การดำเนินการตามขนาดในแต่ละครั้งแทนการดำเนินการแบบไบต์ต่อครั้ง (ถ้าเป็นไปได้)
///
/// อัลกอริทึมที่เราใช้ที่นี่ค่อนข้างง่ายหาก `s` สั้นเกินไปเราเพียงแค่ตรวจสอบแต่ละไบต์และดำเนินการให้เสร็จสิ้นมิฉะนั้น:
///
/// - อ่านคำแรกด้วยโหลดที่ไม่ตรงแนว
/// - จัดตำแหน่งตัวชี้อ่านคำที่ตามมาจนจบด้วยการจัดแนว
/// - อ่าน `usize` ล่าสุดจาก `s` ด้วยโหลดที่ไม่ตรงแนว
///
/// หากโหลดใด ๆ เหล่านี้ก่อให้เกิดสิ่งที่ `contains_nonascii` (above) ส่งคืนจริงเราจะรู้ว่าคำตอบนั้นเป็นเท็จ
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // หากเราไม่ได้รับอะไรเลยจากการนำไปใช้ทีละคำให้ถอยกลับไปที่สเกลาร์ลูป
    //
    // นอกจากนี้เรายังทำสิ่งนี้สำหรับสถาปัตยกรรมที่ `size_of::<usize>()` ไม่สามารถจัดตำแหน่งได้เพียงพอสำหรับ `usize` เนื่องจากเป็นเคส edge ที่แปลก
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // เรามักจะอ่านคำแรกไม่ตรงแนวซึ่งหมายความว่า `align_offset` คือ
    // 0 เราจะอ่านค่าเดียวกันอีกครั้งสำหรับการอ่านแบบชิด
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // ความปลอดภัย: เราตรวจสอบ `len < USIZE_SIZE` ด้านบน
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // เราตรวจสอบสิ่งนี้ข้างต้นค่อนข้างโดยปริยาย
    // โปรดทราบว่า `offset_to_aligned` คือ `align_offset` หรือ `USIZE_SIZE` ซึ่งทั้งสองอย่างจะถูกตรวจสอบอย่างชัดเจนด้านบน
    //
    debug_assert!(offset_to_aligned <= len);

    // ความปลอดภัย: word_ptr คือ (จัดแนวอย่างถูกต้อง) ใช้ขนาด ptr ที่เราใช้เพื่ออ่านไฟล์
    // ชิ้นกลางของชิ้น
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` คือดัชนีไบต์ของ `word_ptr` ที่ใช้สำหรับการตรวจสอบการวนซ้ำ
    let mut byte_pos = offset_to_aligned;

    // ตรวจสอบความหวาดระแวงเกี่ยวกับการจัดแนวเนื่องจากเรากำลังจะทำการโหลดที่ไม่ตรงแนว
    // ในทางปฏิบัติสิ่งนี้ควรเป็นไปไม่ได้เลยที่จะยกเว้นข้อบกพร่องใน `align_offset`
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // อ่านคำที่ตามมาจนถึงคำที่จัดชิดสุดท้ายโดยไม่รวมคำที่จัดชิดสุดท้ายด้วยตัวมันเองที่จะต้องทำในการตรวจสอบหางในภายหลังเพื่อให้แน่ใจว่า tail มีค่า `usize` หนึ่งตัวมากที่สุดถึง branch `byte_pos == len`
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // ตรวจสอบความถูกต้องว่าการอ่านอยู่ในขอบเขต
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // และสมมติฐานของเราเกี่ยวกับ `byte_pos` ถือ
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // ความปลอดภัย: เรารู้ว่า `word_ptr` อยู่ในแนวเดียวกันอย่างเหมาะสม (เนื่องจาก
        // "align_offset") และเรารู้ว่าเรามีไบต์เพียงพอระหว่าง `word_ptr` และจุดสิ้นสุด
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // ความปลอดภัย: เรารู้ว่า `byte_pos <= len - USIZE_SIZE` ซึ่งหมายความว่า
        // หลังจาก `add` นี้ `word_ptr` จะอยู่ที่จุดเดียวที่ผ่านมามากที่สุด
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // ตรวจสอบความถูกต้องเพื่อให้แน่ใจว่ามี `usize` เหลืออยู่เพียงเครื่องเดียว
    // สิ่งนี้ควรได้รับการประกันโดยเงื่อนไขการวนซ้ำของเรา
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // ความปลอดภัย: ขึ้นอยู่กับ `len >= USIZE_SIZE` ซึ่งเราตรวจสอบตั้งแต่เริ่มต้น
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}