//! วิธีสร้าง `str` จากชิ้นไบต์

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// แปลงชิ้นส่วนไบต์เป็นสไลซ์สตริง
///
/// ชิ้นสตริง ([`&str`]) สร้างขึ้นจากไบต์ ([`u8`]) และชิ้นส่วนไบต์ ([`&[u8]`][byteslice]) สร้างจากไบต์ดังนั้นฟังก์ชันนี้จะแปลงระหว่างสอง
/// ชิ้นส่วนไบต์ทั้งหมดไม่ได้เป็นสไลซ์สตริงที่ถูกต้องอย่างไรก็ตาม [`&str`] ต้องการให้เป็น UTF-8 ที่ถูกต้อง
/// `from_utf8()` ตรวจสอบเพื่อให้แน่ใจว่าไบต์เป็น UTF-8 ที่ถูกต้องจากนั้นทำการแปลง
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// หากคุณแน่ใจว่าชิ้นส่วนไบต์เป็น UTF-8 ที่ถูกต้องและคุณไม่ต้องการให้มีค่าใช้จ่ายในการตรวจสอบความถูกต้องแสดงว่าฟังก์ชันนี้เป็นเวอร์ชันที่ไม่ปลอดภัยคือ [`from_utf8_unchecked`] ซึ่งมีลักษณะการทำงานเหมือนกัน แต่จะข้ามการตรวจสอบไป
///
///
/// หากคุณต้องการ `String` แทน `&str` ให้พิจารณา [`String::from_utf8`][string]
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// เนื่องจากคุณสามารถจัดสรร `[u8; N]` แบบสแต็กได้และคุณสามารถใช้ [`&[u8]`][byteslice] ได้ฟังก์ชันนี้จึงเป็นวิธีหนึ่งในการมีสตริงที่จัดสรรสแตกมีตัวอย่างนี้ในส่วนตัวอย่างด้านล่าง
///
/// [byteslice]: slice
///
/// # Errors
///
/// ส่งคืน `Err` หากสไลซ์ไม่ใช่ UTF-8 พร้อมคำอธิบายว่าเหตุใดสไลซ์ที่ให้มาจึงไม่ใช่ UTF-8
///
/// # Examples
///
/// การใช้งานพื้นฐาน:
///
/// ```
/// use std::str;
///
/// // ไบต์บางส่วนใน vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // เรารู้ว่าไบต์เหล่านี้ถูกต้องดังนั้นให้ใช้ `unwrap()`
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// ไบต์ไม่ถูกต้อง:
///
/// ```
/// use std::str;
///
/// // บางไบต์ที่ไม่ถูกต้องใน vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// ดูเอกสารสำหรับ [`Utf8Error`] สำหรับรายละเอียดเพิ่มเติมเกี่ยวกับประเภทข้อผิดพลาดที่สามารถส่งคืนได้
///
/// ก "stack allocated string":
///
/// ```
/// use std::str;
///
/// // ไบต์บางส่วนในอาร์เรย์ที่จัดสรรแบบสแต็ก
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // เรารู้ว่าไบต์เหล่านี้ถูกต้องดังนั้นให้ใช้ `unwrap()`
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // ความปลอดภัย: เพิ่งดำเนินการตรวจสอบความถูกต้อง
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// แปลงชิ้นส่วนไบต์ที่ไม่แน่นอนให้เป็นสไลซ์สตริงที่ไม่แน่นอน
///
/// # Examples
///
/// การใช้งานพื้นฐาน:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" เป็น vector ที่ไม่แน่นอน
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // ดังที่เราทราบว่าไบต์เหล่านี้ถูกต้องเราสามารถใช้ `unwrap()` ได้
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// ไบต์ไม่ถูกต้อง:
///
/// ```
/// use std::str;
///
/// // บางไบต์ที่ไม่ถูกต้องใน vector ที่ไม่สามารถเปลี่ยนแปลงได้
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// ดูเอกสารสำหรับ [`Utf8Error`] สำหรับรายละเอียดเพิ่มเติมเกี่ยวกับประเภทข้อผิดพลาดที่สามารถส่งคืนได้
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // ความปลอดภัย: เพิ่งดำเนินการตรวจสอบความถูกต้อง
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// แปลงชิ้นส่วนไบต์เป็นสไลซ์สตริงโดยไม่ต้องตรวจสอบว่าสตริงมี UTF-8 ที่ถูกต้อง
///
/// ดูเวอร์ชันปลอดภัย [`from_utf8`] สำหรับข้อมูลเพิ่มเติม
///
/// # Safety
///
/// ฟังก์ชันนี้ไม่ปลอดภัยเนื่องจากไม่ได้ตรวจสอบว่าไบต์ที่ส่งผ่านไปนั้นเป็น UTF-8 ที่ถูกต้อง
/// หากข้อ จำกัด นี้ถูกละเมิดพฤติกรรมที่ไม่ได้กำหนดจะส่งผลเนื่องจาก Rust ที่เหลือถือว่า [`&str`] s เป็น UTF-8 ที่ถูกต้อง
///
///
/// [`&str`]: str
///
/// # Examples
///
/// การใช้งานพื้นฐาน:
///
/// ```
/// use std::str;
///
/// // ไบต์บางส่วนใน vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // ความปลอดภัย: ผู้เรียกต้องรับประกันว่าไบต์ `v` เป็น UTF-8 ที่ถูกต้อง
    // ยังอาศัย `&str` และ `&[u8]` ที่มีเค้าโครงเดียวกัน
    unsafe { mem::transmute(v) }
}

/// แปลงชิ้นส่วนไบต์เป็นชิ้นสตริงโดยไม่ต้องตรวจสอบว่าสตริงมี UTF-8 ที่ถูกต้องหรือไม่เวอร์ชันที่ไม่แน่นอน
///
///
/// ดูรุ่นที่ไม่เปลี่ยนรูป [`from_utf8_unchecked()`] สำหรับข้อมูลเพิ่มเติม
///
/// # Examples
///
/// การใช้งานพื้นฐาน:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // ความปลอดภัย: ผู้เรียกต้องรับประกันว่าไบต์ `v`
    // เป็น UTF-8 ที่ถูกต้องดังนั้นการส่งไปยัง `*mut str` จึงปลอดภัย
    // นอกจากนี้การอ้างอิงตัวชี้ยังปลอดภัยเนื่องจากตัวชี้นั้นมาจากการอ้างอิงซึ่งรับประกันว่าถูกต้องสำหรับการเขียน
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}