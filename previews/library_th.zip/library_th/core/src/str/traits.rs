//! การใช้งาน Trait สำหรับ `str`

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// ดำเนินการจัดลำดับสตริง
///
/// สตริงจะเรียงลำดับ [lexicographically](Ord#lexicographical-comparison) ตามค่าไบต์
/// สิ่งนี้จะเรียงลำดับคะแนนรหัส Unicode ตามตำแหน่งในแผนภูมิรหัส
/// สิ่งนี้ไม่จำเป็นต้องเหมือนกับคำสั่ง "alphabetical" ซึ่งแตกต่างกันไปตามภาษาและสถานที่
/// การเรียงลำดับสตริงตามมาตรฐานที่ยอมรับทางวัฒนธรรมจำเป็นต้องมีข้อมูลเฉพาะสถานที่ที่อยู่นอกขอบเขตของประเภท `str`
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// ดำเนินการเปรียบเทียบกับสตริง
///
/// สตริงถูกเปรียบเทียบ [lexicographically](Ord#lexicographical-comparison) ด้วยค่าไบต์
/// สิ่งนี้จะเปรียบเทียบจุดรหัส Unicode ตามตำแหน่งในแผนภูมิรหัส
/// สิ่งนี้ไม่จำเป็นต้องเหมือนกับคำสั่ง "alphabetical" ซึ่งแตกต่างกันไปตามภาษาและสถานที่
/// การเปรียบเทียบสตริงตามมาตรฐานที่ยอมรับทางวัฒนธรรมจำเป็นต้องมีข้อมูลเฉพาะสถานที่ที่อยู่นอกขอบเขตของประเภท `str`
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// ใช้การแบ่งส่วนย่อยของสตริงย่อยด้วยไวยากรณ์ `&self[..]` หรือ `&mut self[..]`
///
/// ส่งคืนสไลซ์ของสตริงทั้งหมดเช่นส่งคืน `&self` หรือ `&mut self` เทียบเท่ากับ `&self [0 ..
/// len] `หรือ`&mut self [0 ..
/// len]`.
/// ซึ่งแตกต่างจากการดำเนินการจัดทำดัชนีอื่น ๆ สิ่งนี้ไม่สามารถ panic ได้
///
/// การดำเนินการนี้คือ *O*(1)
///
/// ก่อนหน้า 1.20.0 การดำเนินการจัดทำดัชนีเหล่านี้ยังคงได้รับการสนับสนุนโดยการใช้งาน `Index` และ `IndexMut` โดยตรง
///
/// เทียบเท่ากับ `&self[0 .. len]` หรือ `&mut self[0 .. len]`
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// ใช้การแบ่งส่วนย่อยของสตริงย่อยด้วยไวยากรณ์ `&self[begin .. end]` หรือ `&mut self[begin .. end]`
///
/// ส่งคืนส่วนของสตริงที่กำหนดจากช่วงไบต์ [`begin`, `end`)
///
/// การดำเนินการนี้คือ *O*(1)
///
/// ก่อนหน้า 1.20.0 การดำเนินการจัดทำดัชนีเหล่านี้ยังคงได้รับการสนับสนุนโดยการใช้งาน `Index` และ `IndexMut` โดยตรง
///
/// # Panics
///
/// Panics ถ้า `begin` หรือ `end` ไม่ชี้ไปที่ออฟเซ็ตไบต์เริ่มต้นของอักขระ (ตามที่กำหนดโดย `is_char_boundary`) ถ้า `begin > end` หรือถ้า `end > len`
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // สิ่งเหล่านี้จะ panic:
/// // ไบต์ 2 อยู่ภายใน `ö`:
/// // &s [2 ..3];
///
/// // ไบต์ 8 อยู่ภายใน `老`&s [1 ..
/// // 8];
///
/// // ไบต์ 100 อยู่นอกสตริง&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // ความปลอดภัย: เพิ่งตรวจสอบว่า `start` และ `end` อยู่ในขอบเขตถ่าน
            // และเรากำลังส่งต่อในการอ้างอิงที่ปลอดภัยดังนั้นค่าที่ส่งคืนก็จะเป็นหนึ่งเช่นกัน
            // เรายังตรวจสอบขอบเขตถ่านด้วยดังนั้นนี่คือ UTF-8 ที่ถูกต้อง
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // ความปลอดภัย: เพิ่งตรวจสอบว่า `start` และ `end` อยู่ในขอบเขตถ่าน
            // เรารู้ว่าตัวชี้นั้นไม่เหมือนใครเพราะเราได้มาจาก `slice`
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // ความปลอดภัย: ผู้โทรรับประกันว่า `self` อยู่ในขอบเขต `slice`
        // ซึ่งเป็นไปตามเงื่อนไขทั้งหมดสำหรับ `add`
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // ความปลอดภัย: ดูความคิดเห็นสำหรับ `get_unchecked`
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary ตรวจสอบว่าดัชนีอยู่ใน [0, .len()] ไม่สามารถใช้ `get` ซ้ำได้ตามข้างบนเนื่องจากปัญหา NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // ความปลอดภัย: เพิ่งตรวจสอบว่า `start` และ `end` อยู่ในขอบเขตถ่าน
            // และเรากำลังส่งต่อในการอ้างอิงที่ปลอดภัยดังนั้นค่าที่ส่งคืนก็จะเป็นหนึ่งเช่นกัน
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// ใช้การแบ่งส่วนย่อยของสตริงย่อยด้วยไวยากรณ์ `&self[.. end]` หรือ `&mut self[.. end]`
///
/// ส่งคืนส่วนของสตริงที่กำหนดจากช่วงไบต์ [`0`, `end`)
/// เทียบเท่ากับ `&self[0 .. end]` หรือ `&mut self[0 .. end]`
///
/// การดำเนินการนี้คือ *O*(1)
///
/// ก่อนหน้า 1.20.0 การดำเนินการจัดทำดัชนีเหล่านี้ยังคงได้รับการสนับสนุนโดยการใช้งาน `Index` และ `IndexMut` โดยตรง
///
/// # Panics
///
/// Panics ถ้า `end` ไม่ชี้ไปที่ออฟเซ็ตไบต์เริ่มต้นของอักขระ (ตามที่กำหนดโดย `is_char_boundary`) หรือถ้า `end > len`
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // ความปลอดภัย: เพิ่งตรวจสอบว่า `end` อยู่ในขอบเขตถ่าน
            // และเรากำลังส่งต่อในการอ้างอิงที่ปลอดภัยดังนั้นค่าที่ส่งคืนก็จะเป็นหนึ่งเช่นกัน
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // ความปลอดภัย: เพิ่งตรวจสอบว่า `end` อยู่ในขอบเขตถ่าน
            // และเรากำลังส่งต่อในการอ้างอิงที่ปลอดภัยดังนั้นค่าที่ส่งคืนก็จะเป็นหนึ่งเช่นกัน
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // ความปลอดภัย: เพิ่งตรวจสอบว่า `end` อยู่ในขอบเขตถ่าน
            // และเรากำลังส่งต่อในการอ้างอิงที่ปลอดภัยดังนั้นค่าที่ส่งคืนก็จะเป็นหนึ่งเช่นกัน
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// ใช้การแบ่งส่วนย่อยของสตริงย่อยด้วยไวยากรณ์ `&self[begin ..]` หรือ `&mut self[begin ..]`
///
/// ส่งคืนส่วนของสตริงที่กำหนดจากช่วงไบต์ [`begin`, `len`)เทียบเท่ากับ `&self [เริ่ม ..
/// len] `หรือ`&mut self [เริ่ม ..
/// len]`.
///
/// การดำเนินการนี้คือ *O*(1)
///
/// ก่อนหน้า 1.20.0 การดำเนินการจัดทำดัชนีเหล่านี้ยังคงได้รับการสนับสนุนโดยการใช้งาน `Index` และ `IndexMut` โดยตรง
///
/// # Panics
///
/// Panics ถ้า `begin` ไม่ชี้ไปที่ออฟเซ็ตไบต์เริ่มต้นของอักขระ (ตามที่กำหนดโดย `is_char_boundary`) หรือถ้า `begin > len`
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // ความปลอดภัย: เพิ่งตรวจสอบว่า `start` อยู่ในขอบเขตถ่าน
            // และเรากำลังส่งต่อในการอ้างอิงที่ปลอดภัยดังนั้นค่าที่ส่งคืนก็จะเป็นหนึ่งเช่นกัน
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // ความปลอดภัย: เพิ่งตรวจสอบว่า `start` อยู่ในขอบเขตถ่าน
            // และเรากำลังส่งต่อในการอ้างอิงที่ปลอดภัยดังนั้นค่าที่ส่งคืนก็จะเป็นหนึ่งเช่นกัน
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // ความปลอดภัย: ผู้โทรรับประกันว่า `self` อยู่ในขอบเขต `slice`
        // ซึ่งเป็นไปตามเงื่อนไขทั้งหมดสำหรับ `add`
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // ความปลอดภัย: เหมือนกับ `get_unchecked`
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // ความปลอดภัย: เพิ่งตรวจสอบว่า `start` อยู่ในขอบเขตถ่าน
            // และเรากำลังส่งต่อในการอ้างอิงที่ปลอดภัยดังนั้นค่าที่ส่งคืนก็จะเป็นหนึ่งเช่นกัน
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// ใช้การแบ่งส่วนย่อยของสตริงย่อยด้วยไวยากรณ์ `&self[begin ..= end]` หรือ `&mut self[begin ..= end]`
///
/// ส่งคืนส่วนของสตริงที่กำหนดจากช่วงไบต์ [`begin`, `end`] เทียบเท่ากับ `&self [begin .. end + 1]` หรือ `&mut self[begin .. end + 1]` ยกเว้นว่า `end` มีค่าสูงสุดสำหรับ `usize`
///
/// การดำเนินการนี้คือ *O*(1)
///
/// # Panics
///
/// Panics ถ้า `begin` ไม่ชี้ไปที่ออฟเซ็ตไบต์เริ่มต้นของอักขระ (ตามที่กำหนดโดย `is_char_boundary`) ถ้า `end` ไม่ชี้ไปที่ออฟเซ็ตไบต์สิ้นสุดของอักขระ (`end + 1` เป็นออฟเซ็ตไบต์เริ่มต้นหรือเท่ากับ `len`) ถ้า `begin > end` หรือถ้า `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `get_unchecked`
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `get_unchecked_mut`
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// ใช้การแบ่งส่วนย่อยของสตริงย่อยด้วยไวยากรณ์ `&self[..= end]` หรือ `&mut self[..= end]`
///
/// ส่งคืนส่วนของสตริงที่กำหนดจากช่วงไบต์ [0, `end`]
/// เทียบเท่ากับ `&self [0 .. end + 1]` ยกเว้นว่า `end` มีค่าสูงสุดสำหรับ `usize`
///
/// การดำเนินการนี้คือ *O*(1)
///
/// # Panics
///
/// Panics ถ้า `end` ไม่ชี้ไปที่ออฟเซ็ตไบต์สิ้นสุดของอักขระ (`end + 1` เป็นออฟเซ็ตไบต์เริ่มต้นตามที่กำหนดโดย `is_char_boundary` หรือเท่ากับ `len`) หรือถ้า `end >= len`
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `get_unchecked`
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `get_unchecked_mut`
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// แยกวิเคราะห์ค่าจากสตริง
///
/// วิธี [`from_str`] ของ `FromStr` มักใช้โดยปริยายโดยใช้วิธี [`parse`] ของ [`str`]
/// ดูตัวอย่างเอกสารของ [`parse`]
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` ไม่มีพารามิเตอร์อายุการใช้งานดังนั้นคุณสามารถแยกวิเคราะห์ได้เฉพาะประเภทที่ไม่มีพารามิเตอร์อายุการใช้งานเท่านั้น
///
/// กล่าวอีกนัยหนึ่งคุณสามารถแยกวิเคราะห์ `i32` ด้วย `FromStr` แต่ไม่ใช่ `&i32`
/// คุณสามารถแยกวิเคราะห์โครงสร้างที่มี `i32` แต่ไม่ใช่โครงสร้างที่มี `&i32`
///
/// # Examples
///
/// การใช้งานขั้นพื้นฐานของ `FromStr` ในตัวอย่างประเภท `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// ข้อผิดพลาดที่เกี่ยวข้องซึ่งสามารถส่งคืนได้จากการแยกวิเคราะห์
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// แยกวิเคราะห์สตริง `s` เพื่อส่งคืนค่าประเภทนี้
    ///
    /// หากการแยกวิเคราะห์สำเร็จให้ส่งคืนค่าภายใน [`Ok`] มิฉะนั้นเมื่อสตริงถูกจัดรูปแบบไม่ถูกต้องจะส่งคืนข้อผิดพลาดเฉพาะกับ [`Err`] ภายใน
    /// ประเภทข้อผิดพลาดเฉพาะสำหรับการใช้งาน trait
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐานกับ [`i32`] ประเภทที่ใช้ `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// แยกวิเคราะห์ `bool` จากสตริง
    ///
    /// ให้ `Result<bool, ParseBoolError>` เนื่องจาก `s` อาจแยกวิเคราะห์ได้จริงหรือไม่ก็ได้
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// หมายเหตุในหลาย ๆ กรณีวิธี `.parse()` บน `str` เหมาะสมกว่า
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}