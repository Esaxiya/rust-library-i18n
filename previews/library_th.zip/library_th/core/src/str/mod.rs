//! การจัดการสตริง
//!
//! สำหรับรายละเอียดเพิ่มเติมโปรดดูโมดูล [`std::str`]
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. นอกขอบเขต
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. เริ่ม <=end
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. ขอบเขตตัวละคร
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // ค้นหาตัวละคร
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` ต้องน้อยกว่าเลนและขอบเขตถ่าน
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// ส่งกลับความยาว `self`
    ///
    /// ความยาวนี้มีหน่วยเป็นไบต์ไม่ใช่ ["char`] หรือกราฟ
    /// กล่าวอีกนัยหนึ่งอาจไม่ใช่สิ่งที่มนุษย์พิจารณาถึงความยาวของสตริง
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // แฟนซี f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// ส่งคืน `true` ถ้า `self` มีความยาวเป็นศูนย์ไบต์
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ตรวจสอบว่าไบต์ "index`-th เป็นไบต์แรกในลำดับจุดรหัส UTF-8 หรือจุดสิ้นสุดของสตริง
    ///
    ///
    /// จุดเริ่มต้นและจุดสิ้นสุดของสตริง (เมื่อ `ดัชนี== self.len()`) ถือเป็นขอบเขต
    ///
    /// ส่งคืน `false` ถ้า `index` มากกว่า `self.len()`
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // จุดเริ่มต้นของ `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // ไบต์ที่สองของ `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // ไบต์ที่สามของ `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 และ len ก็โอเคเสมอ
        // ทดสอบ 0 อย่างชัดเจนเพื่อให้สามารถเพิ่มประสิทธิภาพการตรวจสอบได้อย่างง่ายดายและข้ามการอ่านข้อมูลสตริงสำหรับกรณีนั้น
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // นี่เป็นเวทมนตร์ที่เทียบเท่ากับ: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// แปลงสตริงสไลซ์เป็นสไลซ์ไบต์
    /// ในการแปลงชิ้นส่วนไบต์กลับเป็นชิ้นสตริงให้ใช้ฟังก์ชัน [`from_utf8`]
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // ความปลอดภัย: const เสียงเพราะเราส่งสัญญาณสองประเภทด้วยเลย์เอาต์เดียวกัน
        unsafe { mem::transmute(self) }
    }

    /// แปลงสไลซ์สตริงที่เปลี่ยนแปลงได้เป็นชิ้นส่วนไบต์ที่ไม่แน่นอน
    ///
    /// # Safety
    ///
    /// ผู้โทรต้องตรวจสอบให้แน่ใจว่าเนื้อหาของชิ้นส่วนนั้นถูกต้อง UTF-8 ก่อนที่การยืมจะสิ้นสุดลงและมีการใช้ `str` ที่อยู่ภายใต้
    ///
    ///
    /// การใช้ `str` ที่มีเนื้อหาไม่ถูกต้อง UTF-8 เป็นพฤติกรรมที่ไม่ได้กำหนด
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // ความปลอดภัย: นักแสดงจาก `&str` ถึง `&[u8]` ปลอดภัยตั้งแต่ `str`
        // มีรูปแบบเดียวกันกับ `&[u8]` (เฉพาะ libstd เท่านั้นที่สามารถรับประกันได้)
        // การอ้างอิงตัวชี้มีความปลอดภัยเนื่องจากมาจากการอ้างอิงที่ไม่แน่นอนซึ่งรับประกันว่าถูกต้องสำหรับการเขียน
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// แปลงชิ้นสตริงเป็นตัวชี้ดิบ
    ///
    /// เนื่องจากสตริปสไลซ์เป็นชิ้นส่วนไบต์ตัวชี้ดิบจึงชี้ไปที่ [`u8`]
    /// ตัวชี้นี้จะชี้ไปที่ไบต์แรกของชิ้นสตริง
    ///
    /// ผู้โทรต้องตรวจสอบให้แน่ใจว่าไม่มีการเขียนตัวชี้ที่ส่งกลับ
    /// หากคุณต้องการเปลี่ยนเนื้อหาของส่วนสตริงให้ใช้ [`as_mut_ptr`]
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// แปลงส่วนสตริงที่ไม่แน่นอนเป็นตัวชี้ดิบ
    ///
    /// เนื่องจากสตริปสไลซ์เป็นชิ้นส่วนไบต์ตัวชี้ดิบจึงชี้ไปที่ [`u8`]
    /// ตัวชี้นี้จะชี้ไปที่ไบต์แรกของชิ้นสตริง
    ///
    /// เป็นความรับผิดชอบของคุณที่จะต้องตรวจสอบให้แน่ใจว่าส่วนของสตริงได้รับการแก้ไขในลักษณะที่ยังคงเป็น UTF-8 ที่ถูกต้อง
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// ส่งคืนส่วนย่อยของ `str`
    ///
    /// นี่เป็นทางเลือกที่ไม่ตื่นตระหนกในการสร้างดัชนี `str`
    /// ส่งคืน [`None`] เมื่อใดก็ตามที่การดำเนินการจัดทำดัชนีเทียบเท่าจะเป็น panic
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // ดัชนีไม่อยู่ในขอบเขตลำดับ UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // นอกขอบเขต
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// ส่งคืนส่วนย่อยที่ไม่แน่นอนของ `str`
    ///
    /// นี่เป็นทางเลือกที่ไม่ตื่นตระหนกในการสร้างดัชนี `str`
    /// ส่งคืน [`None`] เมื่อใดก็ตามที่การดำเนินการจัดทำดัชนีเทียบเท่าจะเป็น panic
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // ความยาวที่ถูกต้อง
    /// assert!(v.get_mut(0..5).is_some());
    /// // นอกขอบเขต
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// ส่งคืนส่วนย่อยที่ไม่ได้ทำเครื่องหมายของ `str`
    ///
    /// นี่คือทางเลือกที่ไม่ได้เลือกไว้ในการสร้างดัชนี `str`
    ///
    /// # Safety
    ///
    /// ผู้โทรของฟังก์ชั่นนี้ต้องรับผิดชอบต่อเงื่อนไขเบื้องต้นเหล่านี้:
    ///
    /// * ดัชนีเริ่มต้นต้องไม่เกินดัชนีสิ้นสุด
    /// * ดัชนีต้องอยู่ภายในขอบเขตของชิ้นงานต้นฉบับ
    /// * ดัชนีต้องอยู่บนขอบเขตของลำดับ UTF-8
    ///
    /// หากไม่สำเร็จชิ้นสตริงที่ส่งคืนอาจอ้างอิงถึงหน่วยความจำที่ไม่ถูกต้องหรือละเมิดค่าคงที่ที่สื่อสารโดยประเภท `str`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `get_unchecked`
        // ชิ้นส่วนไม่สามารถถอดรหัสได้เนื่องจาก `self` เป็นข้อมูลอ้างอิงที่ปลอดภัย
        // ตัวชี้ที่ส่งกลับมีความปลอดภัยเนื่องจากนัยของ `SliceIndex` ต้องรับประกันว่าเป็น
        unsafe { &*i.get_unchecked(self) }
    }

    /// ส่งคืนส่วนย่อยที่ไม่แน่นอนและไม่ถูกเลือกของ `str`
    ///
    /// นี่คือทางเลือกที่ไม่ได้เลือกไว้ในการสร้างดัชนี `str`
    ///
    /// # Safety
    ///
    /// ผู้โทรของฟังก์ชั่นนี้ต้องรับผิดชอบต่อเงื่อนไขเบื้องต้นเหล่านี้:
    ///
    /// * ดัชนีเริ่มต้นต้องไม่เกินดัชนีสิ้นสุด
    /// * ดัชนีต้องอยู่ภายในขอบเขตของชิ้นงานต้นฉบับ
    /// * ดัชนีต้องอยู่บนขอบเขตของลำดับ UTF-8
    ///
    /// หากไม่สำเร็จชิ้นสตริงที่ส่งคืนอาจอ้างอิงถึงหน่วยความจำที่ไม่ถูกต้องหรือละเมิดค่าคงที่ที่สื่อสารโดยประเภท `str`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `get_unchecked_mut`
        // ชิ้นส่วนไม่สามารถถอดรหัสได้เนื่องจาก `self` เป็นข้อมูลอ้างอิงที่ปลอดภัย
        // ตัวชี้ที่ส่งกลับมีความปลอดภัยเนื่องจากนัยของ `SliceIndex` ต้องรับประกันว่าเป็น
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// สร้างสไลซ์สตริงจากสไลซ์สตริงอื่นโดยผ่านการตรวจสอบความปลอดภัย
    ///
    /// โดยทั่วไปไม่แนะนำให้ใช้ด้วยความระมัดระวัง!สำหรับทางเลือกที่ปลอดภัยโปรดดู [`str`] และ [`Index`]
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// ชิ้นใหม่นี้เปลี่ยนจาก `begin` เป็น `end` รวมถึง `begin` แต่ไม่รวม `end`
    ///
    /// หากต้องการรับสไลซ์สตริงที่ไม่แน่นอนแทนให้ดูวิธี [`slice_mut_unchecked`]
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// ผู้โทรของฟังก์ชั่นนี้ต้องรับผิดชอบต่อเงื่อนไขสามประการที่พึงพอใจ:
    ///
    /// * `begin` ต้องไม่เกิน `end`
    /// * `begin` และ `end` ต้องเป็นตำแหน่งไบต์ภายในส่วนสตริง
    /// * `begin` และ `end` ต้องอยู่บนขอบเขตของลำดับ UTF-8
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `get_unchecked`
        // ชิ้นส่วนไม่สามารถถอดรหัสได้เนื่องจาก `self` เป็นข้อมูลอ้างอิงที่ปลอดภัย
        // ตัวชี้ที่ส่งกลับมีความปลอดภัยเนื่องจากนัยของ `SliceIndex` ต้องรับประกันว่าเป็น
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// สร้างสไลซ์สตริงจากสไลซ์สตริงอื่นโดยผ่านการตรวจสอบความปลอดภัย
    /// โดยทั่วไปไม่แนะนำให้ใช้ด้วยความระมัดระวัง!สำหรับทางเลือกที่ปลอดภัยโปรดดู [`str`] และ [`IndexMut`]
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// ชิ้นใหม่นี้เปลี่ยนจาก `begin` เป็น `end` รวมถึง `begin` แต่ไม่รวม `end`
    ///
    /// หากต้องการรับสไลซ์สตริงที่ไม่เปลี่ยนรูปแทนให้ดูวิธี [`slice_unchecked`]
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// ผู้โทรของฟังก์ชั่นนี้ต้องรับผิดชอบต่อเงื่อนไขสามประการที่พึงพอใจ:
    ///
    /// * `begin` ต้องไม่เกิน `end`
    /// * `begin` และ `end` ต้องเป็นตำแหน่งไบต์ภายในส่วนสตริง
    /// * `begin` และ `end` ต้องอยู่บนขอบเขตของลำดับ UTF-8
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `get_unchecked_mut`
        // ชิ้นส่วนไม่สามารถถอดรหัสได้เนื่องจาก `self` เป็นข้อมูลอ้างอิงที่ปลอดภัย
        // ตัวชี้ที่ส่งกลับมีความปลอดภัยเนื่องจากนัยของ `SliceIndex` ต้องรับประกันว่าเป็น
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// แบ่งสายอักขระหนึ่งเส้นออกเป็นสองเส้นที่ดัชนี
    ///
    /// อาร์กิวเมนต์ `mid` ควรเป็นไบต์ออฟเซ็ตจากจุดเริ่มต้นของสตริง
    /// นอกจากนี้ยังต้องอยู่ในขอบเขตของจุดรหัส UTF-8
    ///
    /// ทั้งสองส่วนที่ส่งคืนไปจากจุดเริ่มต้นของสไลซ์สตริงถึง `mid` และจาก `mid` ไปยังจุดสิ้นสุดของสไลซ์สตริง
    ///
    /// หากต้องการรับส่วนของสตริงที่ไม่แน่นอนให้ดูที่วิธี [`split_at_mut`]
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics ถ้า `mid` ไม่อยู่ในขอบเขตจุดรหัส UTF-8 หรืออยู่เลยจุดสิ้นสุดของจุดรหัสสุดท้ายของชิ้นสตริง
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary ตรวจสอบว่าดัชนีอยู่ใน [0, .len()]
        if self.is_char_boundary(mid) {
            // ความปลอดภัย: เพิ่งตรวจสอบว่า `mid` อยู่ในขอบเขตถ่าน
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// แบ่งหนึ่งสตริงที่ไม่แน่นอนออกเป็นสองส่วนที่ดัชนี
    ///
    /// อาร์กิวเมนต์ `mid` ควรเป็นไบต์ออฟเซ็ตจากจุดเริ่มต้นของสตริง
    /// นอกจากนี้ยังต้องอยู่ในขอบเขตของจุดรหัส UTF-8
    ///
    /// ทั้งสองส่วนที่ส่งคืนไปจากจุดเริ่มต้นของสไลซ์สตริงถึง `mid` และจาก `mid` ไปยังจุดสิ้นสุดของสไลซ์สตริง
    ///
    /// หากต้องการรับส่วนสตริงที่ไม่เปลี่ยนรูปแทนให้ดูวิธี [`split_at`]
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics ถ้า `mid` ไม่อยู่ในขอบเขตจุดรหัส UTF-8 หรืออยู่เลยจุดสิ้นสุดของจุดรหัสสุดท้ายของชิ้นสตริง
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary ตรวจสอบว่าดัชนีอยู่ใน [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // ความปลอดภัย: เพิ่งตรวจสอบว่า `mid` อยู่ในขอบเขตถ่าน
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// ส่งคืนตัววนซ้ำบน ["char`] ของสไลซ์สตริง
    ///
    /// เนื่องจากสตริปสไลซ์ประกอบด้วย UTF-8 ที่ถูกต้องเราจึงสามารถวนซ้ำผ่านสไลซ์สตริงโดย [`char`]
    /// วิธีนี้ส่งคืนตัววนซ้ำดังกล่าว
    ///
    /// สิ่งสำคัญคือต้องจำไว้ว่า [`char`] แสดงถึง Unicode Scalar Value และอาจไม่ตรงกับความคิดของคุณว่า 'character' คืออะไร
    ///
    /// การทำซ้ำบนคลัสเตอร์กราฟฟีมอาจเป็นสิ่งที่คุณต้องการจริงๆ
    /// ฟังก์ชันนี้ไม่ได้จัดทำโดยไลบรารีมาตรฐานของ Rust โปรดตรวจสอบ crates.io แทน
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// โปรดจำไว้ว่า ["char`] อาจไม่ตรงกับสัญชาตญาณของคุณเกี่ยวกับตัวละคร:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // ไม่ใช่ 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// ส่งคืนตัววนซ้ำบน ["char`] ของชิ้นสตริงและตำแหน่งของพวกเขา
    ///
    /// เนื่องจากสตริปสไลซ์ประกอบด้วย UTF-8 ที่ถูกต้องเราจึงสามารถวนซ้ำผ่านสไลซ์สตริงโดย [`char`]
    /// วิธีนี้จะคืนค่าตัววนซ้ำของ ["char`] ทั้งสองนี้รวมทั้งตำแหน่งไบต์
    ///
    /// ตัววนซ้ำจะให้สิ่งที่ได้รับตำแหน่งเป็นอันดับแรก [`char`] เป็นอันดับสอง
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// โปรดจำไว้ว่า ["char`] อาจไม่ตรงกับสัญชาตญาณของคุณเกี่ยวกับตัวละคร:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // ไม่ (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // สังเกต 3 ตรงนี้อักขระสุดท้ายใช้เวลาสองไบต์
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// ตัววนซ้ำบนไบต์ของสไลซ์สตริง
    ///
    /// เนื่องจากสไลซ์สไลซ์ประกอบด้วยลำดับไบต์เราจึงสามารถวนซ้ำผ่านไบต์สไลซ์สตริงได้
    /// วิธีนี้ส่งคืนตัววนซ้ำดังกล่าว
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// แยกชิ้นสตริงด้วยช่องว่าง
    ///
    /// ตัววนซ้ำที่ส่งคืนจะส่งคืนส่วนสตริงที่เป็นส่วนย่อยของชิ้นสตริงต้นฉบับคั่นด้วยช่องว่างจำนวนเท่าใดก็ได้
    ///
    ///
    /// 'Whitespace' ถูกกำหนดตามเงื่อนไขของ Unicode Derived Core Property `White_Space`
    /// หากคุณต้องการแยกเฉพาะบนช่องว่าง ASCII แทนให้ใช้ [`split_ascii_whitespace`]
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// ช่องว่างทุกประเภทได้รับการพิจารณา:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// แบ่งส่วนสตริงด้วยช่องว่าง ASCII
    ///
    /// ตัววนซ้ำที่ส่งคืนจะส่งคืนส่วนสตริงที่เป็นชิ้นส่วนย่อยของชิ้นสตริงต้นฉบับคั่นด้วยช่องว่าง ASCII จำนวนเท่าใดก็ได้
    ///
    ///
    /// หากต้องการแยกโดย Unicode `Whitespace` แทนให้ใช้ [`split_whitespace`]
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// ช่องว่าง ASCII ทุกประเภทได้รับการพิจารณา:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// ตัววนซ้ำบนบรรทัดของสตริงเป็นสไลซ์สตริง
    ///
    /// บรรทัดจะลงท้ายด้วย (`\n`) ขึ้นบรรทัดใหม่หรือการกลับแคร่ด้วยฟีดบรรทัด (`\r\n`)
    ///
    /// การลงท้ายบรรทัดสุดท้ายเป็นทางเลือก
    /// สตริงที่ลงท้ายด้วยการสิ้นสุดบรรทัดสุดท้ายจะส่งคืนบรรทัดเดียวกันเป็นสตริงที่เหมือนกันโดยไม่มีการสิ้นสุดบรรทัดสุดท้าย
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// ไม่จำเป็นต้องลงท้ายบรรทัดสุดท้าย:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// ตัววนซ้ำบนบรรทัดของสตริง
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// ส่งคืนตัววนซ้ำของ `u16` บนสตริงที่เข้ารหัสเป็น UTF-16
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// ส่งคืน `true` หากรูปแบบที่กำหนดตรงกับส่วนย่อยของสไลซ์สตริงนี้
    ///
    /// ส่งคืน `false` ถ้าไม่
    ///
    /// [pattern] สามารถเป็น `&str`, [`char`], ชิ้นส่วนของ ["char`] หรือฟังก์ชันหรือการปิดที่กำหนดว่าอักขระที่ตรงกันหรือไม่
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// ส่งคืน `true` หากรูปแบบที่กำหนดตรงกับคำนำหน้าของส่วนสตริงนี้
    ///
    /// ส่งคืน `false` ถ้าไม่
    ///
    /// [pattern] สามารถเป็น `&str`, [`char`], ชิ้นส่วนของ ["char`] หรือฟังก์ชันหรือการปิดที่กำหนดว่าอักขระที่ตรงกันหรือไม่
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// ส่งคืน `true` หากรูปแบบที่กำหนดตรงกับส่วนต่อท้ายของส่วนสตริงนี้
    ///
    /// ส่งคืน `false` ถ้าไม่
    ///
    /// [pattern] สามารถเป็น `&str`, [`char`], ชิ้นส่วนของ ["char`] หรือฟังก์ชันหรือการปิดที่กำหนดว่าอักขระที่ตรงกันหรือไม่
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// ส่งคืนค่าดัชนีไบต์ของอักขระตัวแรกของชิ้นสตริงนี้ที่ตรงกับรูปแบบ
    ///
    /// ส่งคืน [`None`] หากรูปแบบไม่ตรงกัน
    ///
    /// [pattern] สามารถเป็น `&str`, [`char`], ชิ้นส่วนของ ["char`] หรือฟังก์ชันหรือการปิดที่กำหนดว่าอักขระที่ตรงกันหรือไม่
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// รูปแบบง่ายๆ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// รูปแบบที่ซับซ้อนมากขึ้นโดยใช้สไตล์และการปิดแบบไม่มีจุด:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// ไม่พบรูปแบบ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// ส่งคืนดัชนีไบต์สำหรับอักขระตัวแรกของการจับคู่ทางขวาสุดของรูปแบบในส่วนสตริงนี้
    ///
    /// ส่งคืน [`None`] หากรูปแบบไม่ตรงกัน
    ///
    /// [pattern] สามารถเป็น `&str`, [`char`], ชิ้นส่วนของ ["char`] หรือฟังก์ชันหรือการปิดที่กำหนดว่าอักขระที่ตรงกันหรือไม่
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// รูปแบบง่ายๆ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// รูปแบบที่ซับซ้อนมากขึ้นด้วยการปิด:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// ไม่พบรูปแบบ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// ตัววนซ้ำเหนือสตริงย่อยของส่วนสตริงนี้โดยคั่นด้วยอักขระที่ตรงกับรูปแบบ
    ///
    /// [pattern] สามารถเป็น `&str`, [`char`], ชิ้นส่วนของ ["char`] หรือฟังก์ชันหรือการปิดที่กำหนดว่าอักขระที่ตรงกันหรือไม่
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # พฤติกรรมตัวทำซ้ำ
    ///
    /// ตัววนซ้ำที่ส่งคืนจะเป็น [`DoubleEndedIterator`] หากรูปแบบอนุญาตให้ค้นหาแบบย้อนกลับและการค้นหา forward/reverse ให้องค์ประกอบเดียวกัน
    /// ซึ่งเป็นจริงสำหรับเช่น [`char`] แต่ไม่ใช่สำหรับ `&str`
    ///
    /// หากรูปแบบอนุญาตให้ค้นหาแบบย้อนกลับได้ แต่ผลลัพธ์อาจแตกต่างจากการค้นหาไปข้างหน้าสามารถใช้วิธี [`rsplit`] ได้
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// รูปแบบง่ายๆ:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// หากรูปแบบเป็นส่วนของตัวอักษรให้แบ่งอักขระใด ๆ ที่เกิดขึ้นแต่ละรายการ:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// รูปแบบที่ซับซ้อนมากขึ้นโดยใช้การปิด:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// หากสตริงมีตัวคั่นที่อยู่ติดกันหลายตัวคุณจะจบลงด้วยสตริงว่างในเอาต์พุต:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// ตัวคั่นที่ติดกันจะถูกคั่นด้วยสตริงว่าง
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// ตัวคั่นที่จุดเริ่มต้นหรือจุดสิ้นสุดของสตริงถูกล้อมรอบด้วยสตริงว่าง
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// เมื่อใช้สตริงว่างเป็นตัวคั่นสตริงจะแยกทุกอักขระในสตริงพร้อมกับจุดเริ่มต้นและจุดสิ้นสุดของสตริง
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// ตัวคั่นที่ติดกันอาจทำให้เกิดพฤติกรรมที่น่าแปลกใจเมื่อใช้ช่องว่างเป็นตัวคั่นรหัสนี้ถูกต้อง:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// _not_ ให้คุณ:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// ใช้ [`split_whitespace`] สำหรับพฤติกรรมนี้
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// ตัววนซ้ำเหนือสตริงย่อยของส่วนสตริงนี้โดยคั่นด้วยอักขระที่ตรงกับรูปแบบ
    /// แตกต่างจากตัววนซ้ำที่ผลิตโดย `split` ตรงที่ `split_inclusive` ออกจากส่วนที่ตรงกันเป็นเทอร์มิเนเตอร์ของสตริงย่อย
    ///
    ///
    /// [pattern] สามารถเป็น `&str`, [`char`], ชิ้นส่วนของ ["char`] หรือฟังก์ชันหรือการปิดที่กำหนดว่าอักขระที่ตรงกันหรือไม่
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// หากองค์ประกอบสุดท้ายของสตริงตรงกันองค์ประกอบนั้นจะถือว่าเป็นเทอร์มิเนเตอร์ของสตริงย่อยก่อนหน้า
    /// สตริงย่อยนั้นจะเป็นรายการสุดท้ายที่ส่งคืนโดยตัววนซ้ำ
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// ตัววนซ้ำเหนือสตริงย่อยของส่วนสตริงที่กำหนดโดยคั่นด้วยอักขระที่จับคู่ตามรูปแบบและให้ผลลัพธ์ในลำดับย้อนกลับ
    ///
    /// [pattern] สามารถเป็น `&str`, [`char`], ชิ้นส่วนของ ["char`] หรือฟังก์ชันหรือการปิดที่กำหนดว่าอักขระที่ตรงกันหรือไม่
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # พฤติกรรมตัวทำซ้ำ
    ///
    /// ตัววนซ้ำที่ส่งคืนต้องการให้รูปแบบรองรับการค้นหาแบบย้อนกลับและจะเป็น [`DoubleEndedIterator`] หากการค้นหา forward/reverse ให้องค์ประกอบเดียวกัน
    ///
    ///
    /// สำหรับการวนซ้ำจากด้านหน้าสามารถใช้วิธี [`split`]
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// รูปแบบง่ายๆ:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// รูปแบบที่ซับซ้อนมากขึ้นโดยใช้การปิด:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// ตัววนซ้ำบนสตริงย่อยของสไลซ์สตริงที่กำหนดโดยคั่นด้วยอักขระที่ตรงตามรูปแบบ
    ///
    /// [pattern] สามารถเป็น `&str`, [`char`], ชิ้นส่วนของ ["char`] หรือฟังก์ชันหรือการปิดที่กำหนดว่าอักขระที่ตรงกันหรือไม่
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// เทียบเท่ากับ [`split`] ยกเว้นว่าสตริงย่อยต่อท้ายจะถูกข้ามหากว่างเปล่า
    ///
    /// [`split`]: str::split
    ///
    /// วิธีนี้สามารถใช้สำหรับข้อมูลสตริงที่เป็น _terminated_ แทนที่จะเป็น _separated_ ตามรูปแบบ
    ///
    /// # พฤติกรรมตัวทำซ้ำ
    ///
    /// ตัววนซ้ำที่ส่งคืนจะเป็น [`DoubleEndedIterator`] หากรูปแบบอนุญาตให้ค้นหาแบบย้อนกลับและการค้นหา forward/reverse ให้องค์ประกอบเดียวกัน
    /// ซึ่งเป็นจริงสำหรับเช่น [`char`] แต่ไม่ใช่สำหรับ `&str`
    ///
    /// หากรูปแบบอนุญาตให้ค้นหาแบบย้อนกลับ แต่ผลลัพธ์อาจแตกต่างจากการค้นหาไปข้างหน้าสามารถใช้วิธี [`rsplit_terminator`] ได้
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// ตัววนซ้ำบนสตริงย่อยของ `self` คั่นด้วยอักขระที่ตรงตามรูปแบบและให้ผลลัพธ์ในลำดับย้อนกลับ
    ///
    /// [pattern] สามารถเป็น `&str`, [`char`], ชิ้นส่วนของ ["char`] หรือฟังก์ชันหรือการปิดที่กำหนดว่าอักขระที่ตรงกันหรือไม่
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// เทียบเท่ากับ [`split`] ยกเว้นว่าสตริงย่อยต่อท้ายจะถูกข้ามหากว่างเปล่า
    ///
    /// [`split`]: str::split
    ///
    /// วิธีนี้สามารถใช้สำหรับข้อมูลสตริงที่เป็น _terminated_ แทนที่จะเป็น _separated_ ตามรูปแบบ
    ///
    /// # พฤติกรรมตัวทำซ้ำ
    ///
    /// ตัววนซ้ำที่ส่งคืนต้องการให้รูปแบบรองรับการค้นหาแบบย้อนกลับและจะสิ้นสุดลงสองครั้งหากการค้นหา forward/reverse ให้องค์ประกอบเดียวกัน
    ///
    ///
    /// สำหรับการวนซ้ำจากด้านหน้าสามารถใช้วิธี [`split_terminator`]
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// ตัววนซ้ำบนสตริงย่อยของสไลซ์สตริงที่กำหนดคั่นด้วยรูปแบบ จำกัด การส่งคืนรายการ `n` มากที่สุด
    ///
    /// หากส่งคืนสตริงย่อย `n` สตริงย่อยสุดท้าย (สตริงย่อย "n`th) จะมีส่วนที่เหลือของสตริง
    ///
    /// [pattern] สามารถเป็น `&str`, [`char`], ชิ้นส่วนของ ["char`] หรือฟังก์ชันหรือการปิดที่กำหนดว่าอักขระที่ตรงกันหรือไม่
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # พฤติกรรมตัวทำซ้ำ
    ///
    /// ตัววนซ้ำที่ส่งคืนจะไม่สิ้นสุดลงสองเท่าเนื่องจากไม่มีประสิทธิภาพในการสนับสนุน
    ///
    /// หากรูปแบบอนุญาตให้ค้นหาแบบย้อนกลับสามารถใช้วิธี [`rsplitn`] ได้
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// รูปแบบง่ายๆ:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// รูปแบบที่ซับซ้อนมากขึ้นโดยใช้การปิด:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// ตัววนซ้ำบนสตริงย่อยของส่วนสตริงนี้คั่นด้วยรูปแบบเริ่มต้นจากจุดสิ้นสุดของสตริง จำกัด การส่งคืนรายการ `n` มากที่สุด
    ///
    ///
    /// หากส่งคืนสตริงย่อย `n` สตริงย่อยสุดท้าย (สตริงย่อย "n`th) จะมีส่วนที่เหลือของสตริง
    ///
    /// [pattern] สามารถเป็น `&str`, [`char`], ชิ้นส่วนของ ["char`] หรือฟังก์ชันหรือการปิดที่กำหนดว่าอักขระที่ตรงกันหรือไม่
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # พฤติกรรมตัวทำซ้ำ
    ///
    /// ตัววนซ้ำที่ส่งคืนจะไม่สิ้นสุดลงสองเท่าเนื่องจากไม่มีประสิทธิภาพในการสนับสนุน
    ///
    /// สำหรับการแยกจากด้านหน้าสามารถใช้วิธี [`splitn`]
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// รูปแบบง่ายๆ:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// รูปแบบที่ซับซ้อนมากขึ้นโดยใช้การปิด:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// แยกสตริงในการเกิดขึ้นครั้งแรกของตัวคั่นที่ระบุและส่งกลับคำนำหน้าก่อนตัวคั่นและส่วนต่อท้ายหลังตัวคั่น
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// แยกสตริงในการเกิดครั้งสุดท้ายของตัวคั่นที่ระบุและส่งกลับคำนำหน้าก่อนตัวคั่นและส่วนต่อท้ายหลังตัวคั่น
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// ตัววนซ้ำในการจับคู่ที่ไม่ปะติดปะต่อกันของรูปแบบภายในส่วนสตริงที่กำหนด
    ///
    /// [pattern] สามารถเป็น `&str`, [`char`], ชิ้นส่วนของ ["char`] หรือฟังก์ชันหรือการปิดที่กำหนดว่าอักขระที่ตรงกันหรือไม่
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # พฤติกรรมตัวทำซ้ำ
    ///
    /// ตัววนซ้ำที่ส่งคืนจะเป็น [`DoubleEndedIterator`] หากรูปแบบอนุญาตให้ค้นหาแบบย้อนกลับและการค้นหา forward/reverse ให้องค์ประกอบเดียวกัน
    /// ซึ่งเป็นจริงสำหรับเช่น [`char`] แต่ไม่ใช่สำหรับ `&str`
    ///
    /// หากรูปแบบอนุญาตให้ค้นหาแบบย้อนกลับได้ แต่ผลลัพธ์อาจแตกต่างจากการค้นหาไปข้างหน้าสามารถใช้วิธี [`rmatches`] ได้
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// ตัววนซ้ำในการจับคู่ที่ไม่ปะติดปะต่อกันของรูปแบบภายในส่วนสตริงนี้ให้ผลลัพธ์ในลำดับย้อนกลับ
    ///
    /// [pattern] สามารถเป็น `&str`, [`char`], ชิ้นส่วนของ ["char`] หรือฟังก์ชันหรือการปิดที่กำหนดว่าอักขระที่ตรงกันหรือไม่
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # พฤติกรรมตัวทำซ้ำ
    ///
    /// ตัววนซ้ำที่ส่งคืนต้องการให้รูปแบบรองรับการค้นหาแบบย้อนกลับและจะเป็น [`DoubleEndedIterator`] หากการค้นหา forward/reverse ให้องค์ประกอบเดียวกัน
    ///
    ///
    /// สำหรับการวนซ้ำจากด้านหน้าสามารถใช้วิธี [`matches`]
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// ตัววนซ้ำสำหรับการจับคู่ที่ไม่ปะติดปะต่อกันของรูปแบบภายในส่วนสตริงนี้รวมทั้งดัชนีที่การจับคู่เริ่มต้นที่
    ///
    /// สำหรับการจับคู่ของ `pat` ภายใน `self` ที่ทับซ้อนกันจะมีการส่งคืนเฉพาะดัชนีที่ตรงกับคู่แรกเท่านั้น
    ///
    /// [pattern] สามารถเป็น `&str`, [`char`], ชิ้นส่วนของ ["char`] หรือฟังก์ชันหรือการปิดที่กำหนดว่าอักขระที่ตรงกันหรือไม่
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # พฤติกรรมตัวทำซ้ำ
    ///
    /// ตัววนซ้ำที่ส่งคืนจะเป็น [`DoubleEndedIterator`] หากรูปแบบอนุญาตให้ค้นหาแบบย้อนกลับและการค้นหา forward/reverse ให้องค์ประกอบเดียวกัน
    /// ซึ่งเป็นจริงสำหรับเช่น [`char`] แต่ไม่ใช่สำหรับ `&str`
    ///
    /// หากรูปแบบอนุญาตให้ค้นหาแบบย้อนกลับได้ แต่ผลลัพธ์อาจแตกต่างจากการค้นหาไปข้างหน้าสามารถใช้วิธี [`rmatch_indices`] ได้
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // `aba` เครื่องแรกเท่านั้น
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// ตัววนซ้ำในการจับคู่ที่ไม่ปะติดปะต่อกันของรูปแบบภายใน `self` ให้ผลลัพธ์ในลำดับย้อนกลับพร้อมกับดัชนีของการจับคู่
    ///
    /// สำหรับการจับคู่ของ `pat` ภายใน `self` ที่ทับซ้อนกันจะส่งคืนเฉพาะดัชนีที่ตรงกับการแข่งขันล่าสุดเท่านั้น
    ///
    /// [pattern] สามารถเป็น `&str`, [`char`], ชิ้นส่วนของ ["char`] หรือฟังก์ชันหรือการปิดที่กำหนดว่าอักขระที่ตรงกันหรือไม่
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # พฤติกรรมตัวทำซ้ำ
    ///
    /// ตัววนซ้ำที่ส่งคืนต้องการให้รูปแบบรองรับการค้นหาแบบย้อนกลับและจะเป็น [`DoubleEndedIterator`] หากการค้นหา forward/reverse ให้องค์ประกอบเดียวกัน
    ///
    ///
    /// สำหรับการวนซ้ำจากด้านหน้าสามารถใช้วิธี [`match_indices`]
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // `aba` สุดท้ายเท่านั้น
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// ส่งคืนสไลซ์สตริงที่มีการลบช่องว่างนำหน้าและต่อท้าย
    ///
    /// 'Whitespace' ถูกกำหนดตามเงื่อนไขของ Unicode Derived Core Property `White_Space`
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// ส่งคืนสไลซ์สตริงโดยลบช่องว่างนำหน้า
    ///
    /// 'Whitespace' ถูกกำหนดตามเงื่อนไขของ Unicode Derived Core Property `White_Space`
    ///
    /// # ทิศทางของข้อความ
    ///
    /// สตริงคือลำดับของไบต์
    /// `start` ในบริบทนี้หมายถึงตำแหน่งแรกของสตริงไบต์นั้นสำหรับภาษาจากซ้ายไปขวาเช่นอังกฤษหรือรัสเซียจะอยู่ด้านซ้ายและสำหรับภาษาจากขวาไปซ้ายเช่นอาหรับหรือฮิบรูจะเป็นภาษาด้านขวา
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// ส่งคืนชิ้นสตริงที่มีการลบช่องว่างต่อท้าย
    ///
    /// 'Whitespace' ถูกกำหนดตามเงื่อนไขของ Unicode Derived Core Property `White_Space`
    ///
    /// # ทิศทางของข้อความ
    ///
    /// สตริงคือลำดับของไบต์
    /// `end` ในบริบทนี้หมายถึงตำแหน่งสุดท้ายของสตริงไบต์นั้นสำหรับภาษาจากซ้ายไปขวาเช่นอังกฤษหรือรัสเซียจะอยู่ทางด้านขวาและสำหรับภาษาจากขวาไปซ้ายเช่นอาหรับหรือฮิบรูจะเป็นด้านซ้าย
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// ส่งคืนสไลซ์สตริงโดยลบช่องว่างนำหน้า
    ///
    /// 'Whitespace' ถูกกำหนดตามเงื่อนไขของ Unicode Derived Core Property `White_Space`
    ///
    /// # ทิศทางของข้อความ
    ///
    /// สตริงคือลำดับของไบต์
    /// 'Left' ในบริบทนี้หมายถึงตำแหน่งแรกของสตริงไบต์นั้นสำหรับภาษาเช่นอาหรับหรือฮีบรูซึ่งเป็น "ขวาไปซ้าย" แทนที่จะเป็น "ซ้ายไปขวา" จะเป็นด้าน _right_ ไม่ใช่ด้านซ้าย
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// ส่งคืนชิ้นสตริงที่มีการลบช่องว่างต่อท้าย
    ///
    /// 'Whitespace' ถูกกำหนดตามเงื่อนไขของ Unicode Derived Core Property `White_Space`
    ///
    /// # ทิศทางของข้อความ
    ///
    /// สตริงคือลำดับของไบต์
    /// 'Right' ในบริบทนี้หมายถึงตำแหน่งสุดท้ายของสตริงไบต์นั้นสำหรับภาษาเช่นอาหรับหรือฮีบรูซึ่งเป็น "ขวาไปซ้าย" แทนที่จะเป็น "ซ้ายไปขวา" จะเป็นด้าน _left_ ไม่ใช่ด้านขวา
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// ส่งคืนชิ้นสตริงที่มีคำนำหน้าและคำต่อท้ายทั้งหมดที่ตรงกับรูปแบบที่ถูกลบซ้ำ ๆ
    ///
    /// [pattern] สามารถเป็น [`char`] ชิ้นส่วนของ ["char`] หรือฟังก์ชันหรือตัวปิดที่กำหนดว่าอักขระตรงกันหรือไม่
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// รูปแบบง่ายๆ:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// รูปแบบที่ซับซ้อนมากขึ้นโดยใช้การปิด:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // จำการจับคู่ที่ทราบเร็วที่สุดแก้ไขด้านล่างหาก
            // นัดที่แล้วแตกต่างออกไป
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // ความปลอดภัย: `Searcher` เป็นที่ทราบกันดีว่าส่งคืนดัชนีที่ถูกต้อง
        unsafe { self.get_unchecked(i..j) }
    }

    /// ส่งคืนชิ้นสตริงที่มีคำนำหน้าทั้งหมดที่ตรงกับรูปแบบที่ถูกลบซ้ำ ๆ
    ///
    /// [pattern] สามารถเป็น `&str`, [`char`], ชิ้นส่วนของ ["char`] หรือฟังก์ชันหรือการปิดที่กำหนดว่าอักขระที่ตรงกันหรือไม่
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ทิศทางของข้อความ
    ///
    /// สตริงคือลำดับของไบต์
    /// `start` ในบริบทนี้หมายถึงตำแหน่งแรกของสตริงไบต์นั้นสำหรับภาษาจากซ้ายไปขวาเช่นอังกฤษหรือรัสเซียจะอยู่ด้านซ้ายและสำหรับภาษาจากขวาไปซ้ายเช่นอาหรับหรือฮิบรูจะเป็นภาษาด้านขวา
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // ความปลอดภัย: `Searcher` เป็นที่ทราบกันดีว่าส่งคืนดัชนีที่ถูกต้อง
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// ส่งคืนชิ้นสตริงโดยนำคำนำหน้าออก
    ///
    /// หากสตริงเริ่มต้นด้วยรูปแบบ `prefix` ให้ส่งคืนสตริงย่อยหลังคำนำหน้าซึ่งรวมอยู่ใน `Some`
    /// ซึ่งแตกต่างจาก `trim_start_matches` วิธีนี้จะลบคำนำหน้าเพียงครั้งเดียว
    ///
    /// ถ้าสตริงไม่ขึ้นต้นด้วย `prefix` ให้ส่งคืน `None`
    ///
    /// [pattern] สามารถเป็น `&str`, [`char`], ชิ้นส่วนของ ["char`] หรือฟังก์ชันหรือการปิดที่กำหนดว่าอักขระที่ตรงกันหรือไม่
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// ส่งคืนสไลซ์สตริงโดยลบคำต่อท้ายออก
    ///
    /// หากสตริงลงท้ายด้วยรูปแบบ `suffix` ให้ส่งคืนสตริงย่อยก่อนส่วนต่อท้ายโดยรวมด้วย `Some`
    /// ซึ่งแตกต่างจาก `trim_end_matches` วิธีนี้จะลบคำต่อท้ายเพียงครั้งเดียว
    ///
    /// ถ้าสตริงไม่ได้ลงท้ายด้วย `suffix` ให้ส่งคืน `None`
    ///
    /// [pattern] สามารถเป็น `&str`, [`char`], ชิ้นส่วนของ ["char`] หรือฟังก์ชันหรือการปิดที่กำหนดว่าอักขระที่ตรงกันหรือไม่
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// ส่งคืนสไลซ์สตริงที่มีคำต่อท้ายทั้งหมดที่ตรงกับรูปแบบที่ถูกลบซ้ำ ๆ
    ///
    /// [pattern] สามารถเป็น `&str`, [`char`], ชิ้นส่วนของ ["char`] หรือฟังก์ชันหรือการปิดที่กำหนดว่าอักขระที่ตรงกันหรือไม่
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ทิศทางของข้อความ
    ///
    /// สตริงคือลำดับของไบต์
    /// `end` ในบริบทนี้หมายถึงตำแหน่งสุดท้ายของสตริงไบต์นั้นสำหรับภาษาจากซ้ายไปขวาเช่นอังกฤษหรือรัสเซียจะอยู่ทางด้านขวาและสำหรับภาษาจากขวาไปซ้ายเช่นอาหรับหรือฮิบรูจะเป็นด้านซ้าย
    ///
    ///
    /// # Examples
    ///
    /// รูปแบบง่ายๆ:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// รูปแบบที่ซับซ้อนมากขึ้นโดยใช้การปิด:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // ความปลอดภัย: `Searcher` เป็นที่ทราบกันดีว่าส่งคืนดัชนีที่ถูกต้อง
        unsafe { self.get_unchecked(0..j) }
    }

    /// ส่งคืนชิ้นสตริงที่มีคำนำหน้าทั้งหมดที่ตรงกับรูปแบบที่ถูกลบซ้ำ ๆ
    ///
    /// [pattern] สามารถเป็น `&str`, [`char`], ชิ้นส่วนของ ["char`] หรือฟังก์ชันหรือการปิดที่กำหนดว่าอักขระที่ตรงกันหรือไม่
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ทิศทางของข้อความ
    ///
    /// สตริงคือลำดับของไบต์
    /// 'Left' ในบริบทนี้หมายถึงตำแหน่งแรกของสตริงไบต์นั้นสำหรับภาษาเช่นอาหรับหรือฮีบรูซึ่งเป็น "ขวาไปซ้าย" แทนที่จะเป็น "ซ้ายไปขวา" จะเป็นด้าน _right_ ไม่ใช่ด้านซ้าย
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// ส่งคืนสไลซ์สตริงที่มีคำต่อท้ายทั้งหมดที่ตรงกับรูปแบบที่ถูกลบซ้ำ ๆ
    ///
    /// [pattern] สามารถเป็น `&str`, [`char`], ชิ้นส่วนของ ["char`] หรือฟังก์ชันหรือการปิดที่กำหนดว่าอักขระที่ตรงกันหรือไม่
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ทิศทางของข้อความ
    ///
    /// สตริงคือลำดับของไบต์
    /// 'Right' ในบริบทนี้หมายถึงตำแหน่งสุดท้ายของสตริงไบต์นั้นสำหรับภาษาเช่นอาหรับหรือฮีบรูซึ่งเป็น "ขวาไปซ้าย" แทนที่จะเป็น "ซ้ายไปขวา" จะเป็นด้าน _left_ ไม่ใช่ด้านขวา
    ///
    ///
    /// # Examples
    ///
    /// รูปแบบง่ายๆ:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// รูปแบบที่ซับซ้อนมากขึ้นโดยใช้การปิด:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// แยกวิเคราะห์สายอักขระนี้เป็นประเภทอื่น
    ///
    /// เนื่องจาก `parse` เป็นแบบทั่วไปจึงอาจทำให้เกิดปัญหากับการอนุมานประเภทได้
    /// ดังนั้น `parse` จึงเป็นหนึ่งในไม่กี่ครั้งที่คุณจะเห็นไวยากรณ์ที่เรียกกันติดปากว่า 'turbofish': `::<>`.
    ///
    /// สิ่งนี้ช่วยให้อัลกอริทึมการอนุมานเข้าใจโดยเฉพาะว่าคุณกำลังพยายามแยกวิเคราะห์ประเภทใด
    ///
    /// `parse` สามารถแยกวิเคราะห์เป็นประเภทใดก็ได้ที่ใช้ [`FromStr`] trait
    ///

    /// # Errors
    ///
    /// จะคืนค่า [`Err`] หากไม่สามารถแยกวิเคราะห์ชิ้นสตริงนี้เป็นประเภทที่ต้องการได้
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// การใช้ 'turbofish' แทนการใส่คำอธิบายประกอบ `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// ไม่สามารถแยกวิเคราะห์:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// ตรวจสอบว่าอักขระทั้งหมดในสตริงนี้อยู่ในช่วง ASCII หรือไม่
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // เราสามารถถือว่าแต่ละไบต์เป็นอักขระได้ที่นี่: อักขระหลายไบต์ทั้งหมดเริ่มต้นด้วยไบต์ที่ไม่อยู่ในช่วง ascii ดังนั้นเราจะหยุดอยู่ตรงนั้น
        //
        //
        self.as_bytes().is_ascii()
    }

    /// ตรวจสอบว่าสองสตริงเป็นการจับคู่แบบไม่คำนึงถึงขนาดตัวพิมพ์ของ ASCII
    ///
    /// เหมือนกับ `to_ascii_lowercase(a) == to_ascii_lowercase(b)` แต่ไม่มีการจัดสรรและคัดลอกชั่วคราว
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// แปลงสตริงนี้เป็นตัวพิมพ์ใหญ่ ASCII ในตำแหน่งที่เทียบเท่า
    ///
    /// ตัวอักษร ASCII 'a' ถึง 'z' ถูกแมปกับ 'A' ถึง 'Z' แต่ตัวอักษรที่ไม่ใช่ ASCII จะไม่เปลี่ยนแปลง
    ///
    /// หากต้องการส่งคืนค่าตัวพิมพ์ใหญ่ใหม่โดยไม่ต้องแก้ไขค่าที่มีอยู่ให้ใช้ [`to_ascii_uppercase()`]
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // ความปลอดภัย: ปลอดภัยเพราะเราส่งสัญญาณสองประเภทด้วยเลย์เอาต์เดียวกัน
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// แปลงสตริงนี้เป็น ASCII ตัวพิมพ์เล็กที่เทียบเท่าในตำแหน่ง
    ///
    /// ตัวอักษร ASCII 'A' ถึง 'Z' ถูกแมปกับ 'a' ถึง 'z' แต่ตัวอักษรที่ไม่ใช่ ASCII จะไม่เปลี่ยนแปลง
    ///
    /// หากต้องการส่งคืนค่าที่ลดลงใหม่โดยไม่ต้องแก้ไขค่าที่มีอยู่ให้ใช้ [`to_ascii_lowercase()`]
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // ความปลอดภัย: ปลอดภัยเพราะเราส่งสัญญาณสองประเภทด้วยเลย์เอาต์เดียวกัน
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// ส่งคืนตัววนซ้ำที่หลีกเลี่ยงแต่ละอักขระใน `self` ด้วย [`char::escape_debug`]
    ///
    ///
    /// Note: เฉพาะจุดรหัสกราฟแบบขยายที่เริ่มต้นสตริงเท่านั้นที่จะถูกหลีกหนี
    ///
    /// # Examples
    ///
    /// ในฐานะผู้วนซ้ำ:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ใช้ `println!` โดยตรง:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// ทั้งสองเทียบเท่ากับ:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// ใช้ `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// ส่งคืนตัววนซ้ำที่หลีกเลี่ยงแต่ละอักขระใน `self` ด้วย [`char::escape_default`]
    ///
    ///
    /// # Examples
    ///
    /// ในฐานะผู้วนซ้ำ:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ใช้ `println!` โดยตรง:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// ทั้งสองเทียบเท่ากับ:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// ใช้ `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// ส่งคืนตัววนซ้ำที่หลีกเลี่ยงแต่ละอักขระใน `self` ด้วย [`char::escape_unicode`]
    ///
    ///
    /// # Examples
    ///
    /// ในฐานะผู้วนซ้ำ:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ใช้ `println!` โดยตรง:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// ทั้งสองเทียบเท่ากับ:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// ใช้ `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// สร้าง str ว่าง
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// สร้าง str ที่ไม่สามารถเปลี่ยนแปลงได้ที่ว่างเปล่า
    #[inline]
    fn default() -> Self {
        // ความปลอดภัย: สตริงว่างคือ UTF-8 ที่ถูกต้อง
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// ประเภท fn ที่สามารถลอกเลียนแบบได้
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // ความปลอดภัย: ไม่ปลอดภัย
        unsafe { from_utf8_unchecked(bytes) }
    };
}