//! API รูปแบบสตริง
//!
//! Pattern API มีกลไกทั่วไปสำหรับการใช้รูปแบบประเภทต่างๆเมื่อค้นหาผ่านสตริง
//!
//! สำหรับรายละเอียดเพิ่มเติมโปรดดู traits [`Pattern`], [`Searcher`], [`ReverseSearcher`] และ [`DoubleEndedSearcher`]
//!
//! แม้ว่า API นี้จะไม่เสถียร แต่ก็เปิดเผยผ่าน API ที่เสถียรในประเภท [`str`]
//!
//! # Examples
//!
//! [`Pattern`] คือ [implemented][pattern-impls] ใน API ที่เสถียรสำหรับ [`&str`][`str`], [`char`], ส่วนของ [`char`] และฟังก์ชันและการปิดที่ใช้ `FnMut(char) -> bool`
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // รูปแบบถ่าน
//! assert_eq!(s.find('n'), Some(2));
//! // ชิ้นส่วนของรูปแบบตัวอักษร
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // รูปแบบการปิด
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// รูปแบบสตริง
///
/// `Pattern<'a>` เป็นการแสดงออกว่าสามารถใช้ชนิดการนำไปใช้เป็นรูปแบบสตริงสำหรับการค้นหาใน [`&'a str`][str]
///
/// ตัวอย่างเช่นทั้ง `'a'` และ `"aa"` เป็นรูปแบบที่จะจับคู่ที่ดัชนี `1` ในสตริง `"baaaab"`
///
/// trait เองทำหน้าที่เป็นตัวสร้างสำหรับชนิด [`Searcher`] ที่เกี่ยวข้องซึ่งจะทำงานจริงในการค้นหาการเกิดขึ้นของรูปแบบในสตริง
///
///
/// พฤติกรรมของวิธีการเช่น [`str::find`] และ [`str::contains`] สามารถเปลี่ยนแปลงได้ทั้งนี้ขึ้นอยู่กับประเภทของรูปแบบ
/// ตารางด้านล่างอธิบายพฤติกรรมเหล่านั้นบางส่วน
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// ผู้ค้นหาที่เกี่ยวข้องสำหรับรูปแบบนี้
    type Searcher: Searcher<'a>;

    /// สร้างผู้ค้นหาที่เกี่ยวข้องจาก `self` และ `haystack` เพื่อค้นหา
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// ตรวจสอบว่ารูปแบบตรงกับที่ใดในกองหญ้าหรือไม่
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// ตรวจสอบว่ารูปแบบตรงกับด้านหน้าของกองหญ้าหรือไม่
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// ตรวจสอบว่ารูปแบบตรงกับด้านหลังของกองหญ้าหรือไม่
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// ลบรูปแบบออกจากด้านหน้าของกองหญ้าถ้าตรงกัน
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // ความปลอดภัย: `Searcher` เป็นที่ทราบกันดีว่าส่งคืนดัชนีที่ถูกต้อง
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// ลบรูปแบบออกจากด้านหลังของกองหญ้าถ้าตรงกัน
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // ความปลอดภัย: `Searcher` เป็นที่ทราบกันดีว่าส่งคืนดัชนีที่ถูกต้อง
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// ผลของการโทร [`Searcher::next()`] หรือ [`ReverseSearcher::next_back()`]
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// แสดงว่าพบการจับคู่ของรูปแบบที่ `haystack[a..b]`
    ///
    Match(usize, usize),
    /// แสดงว่า `haystack[a..b]` ถูกปฏิเสธว่าเป็นไปได้ของรูปแบบ
    ///
    /// โปรดทราบว่าอาจมี `Reject` มากกว่าหนึ่งตัวระหว่าง "การจับคู่" สองรายการจึงไม่มีข้อกำหนดให้รวมเป็นหนึ่งเดียว
    ///
    ///
    Reject(usize, usize),
    /// แสดงว่ามีการเยี่ยมชมกองหญ้าทุกไบต์และสิ้นสุดการวนซ้ำ
    ///
    Done,
}

/// ผู้ค้นหารูปแบบสตริง
///
/// trait นี้มีวิธีการค้นหาการจับคู่ที่ไม่ทับซ้อนกันของรูปแบบโดยเริ่มจาก (left) ด้านหน้าของสตริง
///
/// จะดำเนินการโดย `Searcher` ประเภท [`Pattern`] trait ที่เกี่ยวข้อง
///
/// trait ถูกทำเครื่องหมายว่าไม่ปลอดภัยเนื่องจากดัชนีที่ส่งคืนโดยวิธี [`next()`][Searcher::next] จำเป็นต้องอยู่บนขอบเขต utf8 ที่ถูกต้องในกองหญ้า
/// สิ่งนี้ช่วยให้ผู้ใช้ trait นี้สามารถหั่นกองหญ้าได้โดยไม่ต้องตรวจสอบรันไทม์เพิ่มเติม
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter สำหรับสตริงที่อยู่ภายใต้การค้นหา
    ///
    /// จะคืนค่า [`&str`][str] เท่าเดิมเสมอ
    fn haystack(&self) -> &'a str;

    /// ดำเนินการค้นหาขั้นตอนถัดไปโดยเริ่มจากด้านหน้า
    ///
    /// - ส่งคืน [`Match(a, b)`][SearchStep::Match] หาก `haystack[a..b]` ตรงกับรูปแบบ
    /// - ส่งคืน [`Reject(a, b)`][SearchStep::Reject] หาก `haystack[a..b]` ไม่สามารถจับคู่รูปแบบแม้เพียงบางส่วน
    /// - ส่งคืน [`Done`][SearchStep::Done] หากมีการเยี่ยมชมกองหญ้าทุกไบต์
    ///
    /// สตรีมของค่า [`Match`][SearchStep::Match] และ [`Reject`][SearchStep::Reject] จนถึง [`Done`][SearchStep::Done] จะมีช่วงดัชนีที่อยู่ติดกันไม่ทับซ้อนกันครอบคลุมกองหญ้าทั้งหมดและวางบนขอบเขต utf8
    ///
    ///
    /// ผลลัพธ์ [`Match`][SearchStep::Match] จำเป็นต้องมีรูปแบบที่ตรงกันทั้งหมดอย่างไรก็ตามผลลัพธ์ [`Reject`][SearchStep::Reject] อาจถูกแบ่งออกเป็นส่วนย่อย ๆ ที่อยู่ติดกันโดยพลการทั้งสองช่วงอาจมีความยาวเป็นศูนย์
    ///
    /// ตัวอย่างเช่นรูปแบบ `"aaa"` และกองหญ้า `"cbaaaaab"` อาจสร้างสตรีม
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// ค้นหาผลลัพธ์ [`Match`][SearchStep::Match] ถัดไปดู [`next()`][Searcher::next]
    ///
    /// ไม่เหมือนกับ [`next()`][Searcher::next] ไม่มีการรับประกันว่าช่วงที่ส่งคืนของสิ่งนี้และ [`next_reject`][Searcher::next_reject] จะทับซ้อนกัน
    /// สิ่งนี้จะส่งคืน `(start_match, end_match)` โดยที่ start_match คือดัชนีของจุดที่การแข่งขันเริ่มต้นขึ้นและ end_match คือดัชนีหลังจากสิ้นสุดการแข่งขัน
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// ค้นหาผลลัพธ์ [`Reject`][SearchStep::Reject] ถัดไปดู [`next()`][Searcher::next] และ [`next_match()`][Searcher::next_match]
    ///
    /// ไม่เหมือนกับ [`next()`][Searcher::next] ไม่มีการรับประกันว่าช่วงที่ส่งคืนของสิ่งนี้และ [`next_match`][Searcher::next_match] จะทับซ้อนกัน
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// ผู้ค้นหาแบบย้อนกลับสำหรับรูปแบบสตริง
///
/// trait นี้มีวิธีการค้นหาการจับคู่ที่ไม่ทับซ้อนกันของรูปแบบโดยเริ่มจาก (right) ด้านหลังของสตริง
///
/// มันจะถูกนำไปใช้โดย [`Searcher`] ประเภท [`Pattern`] trait ที่เกี่ยวข้องหากรูปแบบรองรับการค้นหาจากด้านหลัง
///
///
/// ช่วงดัชนีที่ส่งกลับโดย trait นี้ไม่จำเป็นต้องตรงกับช่วงของการค้นหาไปข้างหน้าในทางกลับกันทุกประการ
///
/// สำหรับสาเหตุที่ trait นี้ถูกทำเครื่องหมายว่าไม่ปลอดภัยโปรดดูที่พาเรนต์ trait [`Searcher`]
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// ดำเนินการค้นหาขั้นตอนถัดไปโดยเริ่มจากด้านหลัง
    ///
    /// - ส่งคืน [`Match(a, b)`][SearchStep::Match] หาก `haystack[a..b]` ตรงกับรูปแบบ
    /// - ส่งคืน [`Reject(a, b)`][SearchStep::Reject] หาก `haystack[a..b]` ไม่สามารถจับคู่รูปแบบแม้เพียงบางส่วน
    /// - ส่งคืน [`Done`][SearchStep::Done] หากมีการเยี่ยมชมกองหญ้าทุกไบต์
    ///
    /// สตรีมของค่า [`Match`][SearchStep::Match] และ [`Reject`][SearchStep::Reject] จนถึง [`Done`][SearchStep::Done] จะมีช่วงดัชนีที่อยู่ติดกันไม่ทับซ้อนกันครอบคลุมกองหญ้าทั้งหมดและวางบนขอบเขต utf8
    ///
    ///
    /// ผลลัพธ์ [`Match`][SearchStep::Match] จำเป็นต้องมีรูปแบบที่ตรงกันทั้งหมดอย่างไรก็ตามผลลัพธ์ [`Reject`][SearchStep::Reject] อาจถูกแบ่งออกเป็นส่วนย่อย ๆ ที่อยู่ติดกันโดยพลการทั้งสองช่วงอาจมีความยาวเป็นศูนย์
    ///
    /// ตัวอย่างเช่นรูปแบบ `"aaa"` และกองหญ้า `"cbaaaaab"` อาจสร้างสตรีม `[Reject(7, 8), Match(4, 7), Reject(1, 4) Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// ค้นหาผลลัพธ์ [`Match`][SearchStep::Match] ถัดไป
    /// ดู [`next_back()`][ReverseSearcher::next_back]
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// ค้นหาผลลัพธ์ [`Reject`][SearchStep::Reject] ถัดไป
    /// ดู [`next_back()`][ReverseSearcher::next_back]
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// เครื่องหมาย trait เพื่อแสดงว่า [`ReverseSearcher`] สามารถใช้สำหรับการนำ [`DoubleEndedIterator`] ไปใช้งานได้
///
/// สำหรับสิ่งนี้นัยของ [`Searcher`] และ [`ReverseSearcher`] จำเป็นต้องปฏิบัติตามเงื่อนไขเหล่านี้:
///
/// - ผลลัพธ์ทั้งหมดของ `next()` ต้องเหมือนกันกับผลลัพธ์ของ `next_back()` ในลำดับย้อนกลับ
/// - `next()` และ `next_back()` ต้องทำงานเป็นปลายทั้งสองของช่วงของค่านั่นคือไม่สามารถ "walk past each other" ได้
///
/// # Examples
///
/// `char::Searcher` เป็น `DoubleEndedSearcher` เนื่องจากการค้นหา [`char`] ต้องดูทีละรายการเท่านั้นซึ่งจะทำงานเหมือนกันจากปลายทั้งสองด้าน
///
/// `(&str)::Searcher` ไม่ใช่ `DoubleEndedSearcher` เนื่องจากรูปแบบ `"aa"` ในกองหญ้า `"aaa"` ตรงกับ `"[aa]a"` หรือ `"a[aa]"` ขึ้นอยู่กับว่าจะค้นหาจากด้านใด
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl สำหรับถ่าน
/////////////////////////////////////////////////////////////////////////////

/// ประเภทที่เกี่ยวข้องสำหรับ `<char as Pattern<'a>>::Searcher`
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // ค่าไม่แปรผันด้านความปลอดภัย: `finger`/`finger_back` ต้องเป็นดัชนี utf8 ไบต์ที่ถูกต้องของ `haystack` ค่าคงที่นี้สามารถหักได้ *ภายใน* next_match และ next_match_back อย่างไรก็ตามต้องออกด้วยนิ้วบนขอบเขตจุดรหัสที่ถูกต้อง
    //
    //
    /// `finger` คือดัชนีไบต์ปัจจุบันของการค้นหาไปข้างหน้า
    /// ลองนึกภาพว่ามันมีอยู่ก่อนไบต์ที่ดัชนีกล่าวคือ
    /// `haystack[finger]` เป็นไบต์แรกของชิ้นส่วนที่เราต้องตรวจสอบระหว่างการค้นหาไปข้างหน้า
    ///
    finger: usize,
    /// `finger_back` คือดัชนีไบต์ปัจจุบันของการค้นหาย้อนกลับ
    /// ลองนึกภาพว่ามันมีอยู่หลังไบต์ที่ดัชนีกล่าวคือ
    /// haystack [finger_back, 1] คือไบต์สุดท้ายของชิ้นส่วนที่เราต้องตรวจสอบระหว่างการค้นหาไปข้างหน้า (ดังนั้นจึงต้องตรวจสอบไบต์แรกเมื่อเรียก next_back())
    ///
    finger_back: usize,
    /// อักขระที่กำลังค้นหา
    needle: char,

    // ค่าคงที่ความปลอดภัย: `utf8_size` ต้องน้อยกว่า 5
    /// จำนวนไบต์ `needle` จะเพิ่มขึ้นเมื่อเข้ารหัสใน utf8
    utf8_size: usize,
    /// สำเนาที่เข้ารหัส utf8 ของ `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // ความปลอดภัย: 1-4 รับประกันความปลอดภัยของ `get_unchecked`
        // 1. `self.finger` และ `self.finger_back` จะถูกเก็บไว้ในขอบเขต Unicode (ซึ่งไม่แปรผัน)
        // 2. `self.finger >= 0` เนื่องจากเริ่มต้นที่ 0 และเพิ่มขึ้นเท่านั้น
        // 3. `self.finger < self.finger_back` เพราะมิฉะนั้นถ่าน `iter` จะส่งคืน `SearchStep::Done`
        // 4.
        // `self.finger` มาก่อนจุดจบของกองหญ้าเนื่องจาก `self.finger_back` เริ่มต้นที่จุดสิ้นสุดและลดลงเท่านั้น
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // เพิ่มไบต์ออฟเซ็ตของอักขระปัจจุบันโดยไม่ต้องเข้ารหัสซ้ำเป็น utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // รับกองหญ้าหลังจากพบตัวละครสุดท้าย
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // ไบต์สุดท้ายของ utf8 ที่เข้ารหัสเข็ม SAFETY: เรามีค่าคงที่ `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // นิ้วใหม่คือดัชนีของไบต์ที่เราพบบวกหนึ่งเนื่องจากเรา memchr'd สำหรับไบต์สุดท้ายของอักขระ
                //
                // โปรดทราบว่าสิ่งนี้ไม่ได้ทำให้เราเข้าใจขอบเขต UTF8 เสมอไป
                // หากเรา *ไม่* พบอักขระของเราเราอาจสร้างดัชนีเป็นไบต์สุดท้ายของอักขระ 3 ไบต์หรือ 4 ไบต์
                // เราไม่สามารถข้ามไปยังไบต์เริ่มต้นที่ถูกต้องถัดไปได้เนื่องจากอักขระเช่นꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` จะให้เราพบไบต์ที่สองเสมอเมื่อค้นหาไบต์ที่สาม
                //
                //
                // อย่างไรก็ตามไม่เป็นไร
                // ในขณะที่เรามีค่าคงที่ที่ self.finger อยู่บนขอบเขต UTF8 ค่าคงที่นี้ไม่ได้อาศัยอยู่ในวิธีนี้ (ขึ้นอยู่กับใน CharSearcher::next())
                //
                // เราจะออกจากวิธีนี้ก็ต่อเมื่อเราไปถึงจุดสิ้นสุดของสตริงหรือเมื่อเราพบบางสิ่งเมื่อเราพบบางสิ่ง `finger` จะถูกกำหนดเป็นขอบเขต UTF8
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // ไม่พบอะไรทางออก
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // ให้ next_reject ใช้การใช้งานเริ่มต้นจาก Searcher trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // ความปลอดภัย: ดูความคิดเห็นสำหรับ next() ด้านบน
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // ลบไบต์ออฟเซ็ตของอักขระปัจจุบันโดยไม่ต้องเข้ารหัสซ้ำเป็น utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // รับกองหญ้า แต่ไม่รวมอักขระสุดท้ายที่ค้นหา
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // ไบต์สุดท้ายของ utf8 ที่เข้ารหัสเข็ม SAFETY: เรามีค่าคงที่ `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // เราค้นหาชิ้นส่วนที่ถูกชดเชยด้วย self.finger เพิ่ม self.finger เพื่อลบดัชนีเดิม
                //
                let index = self.finger + index;
                // memrchr จะส่งคืนดัชนีของไบต์ที่เราต้องการค้นหา
                // ในกรณีของอักขระ ASCII นี่เป็นสิ่งที่เราต้องการให้นิ้วใหม่ของเราเป็น ("after" อักขระที่พบในกระบวนทัศน์ของการวนซ้ำแบบย้อนกลับ)
                //
                // สำหรับอักขระหลายไบต์เราจำเป็นต้องข้ามลงไปตามจำนวนไบต์ที่มีมากกว่า ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // เลื่อนนิ้วไปก่อนพบอักขระ (กล่าวคือที่ดัชนีเริ่มต้น)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // เราไม่สามารถใช้ finger_back=index, size + 1 ได้ที่นี่
                // หากเราพบอักขระสุดท้ายของอักขระที่มีขนาดแตกต่างกัน (หรือไบต์กลางของอักขระอื่น) เราจำเป็นต้องกระแทก finger_back ลงไปที่ `index`
                // สิ่งนี้ทำให้ `finger_back` มีศักยภาพที่จะไม่อยู่ในขอบเขตอีกต่อไป แต่ก็ใช้ได้เนื่องจากเราออกจากฟังก์ชันนี้เฉพาะในขอบเขตหรือเมื่อมีการค้นหากองหญ้าอย่างสมบูรณ์
                //
                //
                // ซึ่งแตกต่างจาก next_match ตรงนี้ไม่มีปัญหาของไบต์ซ้ำใน utf-8 เนื่องจากเรากำลังค้นหาไบต์สุดท้ายและเราจะพบเฉพาะไบต์สุดท้ายเมื่อค้นหาในสิ่งที่ตรงกันข้าม
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // ไม่พบอะไรทางออก
                return None;
            }
        }
    }

    // ให้ next_reject_back ใช้การใช้งานเริ่มต้นจาก Searcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// ค้นหาตัวอักษรที่เท่ากับ [`char`] ที่กำหนด
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Impl สำหรับ MultiCharEq wrapper
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // เปรียบเทียบความยาวของตัววนซ้ำชิ้นส่วนไบต์ภายในเพื่อหาความยาวของถ่านปัจจุบัน
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // เปรียบเทียบความยาวของตัววนซ้ำชิ้นส่วนไบต์ภายในเพื่อหาความยาวของถ่านปัจจุบัน
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl สำหรับ&[ถ่าน]
/////////////////////////////////////////////////////////////////////////////

// Todo: เปลี่ยน/ลบเนื่องจากความไม่ชัดเจนในความหมาย

/// ประเภทที่เกี่ยวข้องสำหรับ `<&[char] as Pattern<'a>>::Searcher`
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// ค้นหาตัวอักษรที่เท่ากับ ["char"] ใด ๆ ในส่วน
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl สำหรับ F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// ประเภทที่เกี่ยวข้องสำหรับ `<F as Pattern<'a>>::Searcher`
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// ค้นหา ["char`] ที่ตรงกับเพรดิเคตที่ระบุ
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl สำหรับ&&str
/////////////////////////////////////////////////////////////////////////////

/// ผู้แทน `&str` im.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl สำหรับ &str
/////////////////////////////////////////////////////////////////////////////

/// การค้นหาสตริงย่อยที่ไม่จัดสรร
///
/// จะจัดการกับรูปแบบ `""` เป็นการส่งคืนการจับคู่ว่างที่ขอบเขตอักขระแต่ละตัว
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// ตรวจสอบว่ารูปแบบตรงกับด้านหน้าของกองหญ้าหรือไม่
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// ลบรูปแบบออกจากด้านหน้าของกองหญ้าถ้าตรงกัน
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // ความปลอดภัย: คำนำหน้าได้รับการยืนยันว่ามีอยู่จริง
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// ตรวจสอบว่ารูปแบบตรงกับด้านหลังของกองหญ้าหรือไม่
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// ลบรูปแบบออกจากด้านหลังของกองหญ้าถ้าตรงกัน
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // ความปลอดภัย: คำต่อท้ายได้รับการยืนยันว่ามีอยู่จริง
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// ผู้ค้นหาสตริงย่อยสองทาง
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// ประเภทที่เกี่ยวข้องสำหรับ `<&str as Pattern<'a>>::Searcher`
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // เข็มเปล่าจะปฏิเสธทุกอักขระและจับคู่สตริงว่างระหว่างพวกเขา
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher สร้างดัชนี *Match* ที่ถูกต้องซึ่งแบ่งตามขอบเขตถ่านตราบเท่าที่มีการจับคู่ที่ถูกต้องและกองหญ้าและเข็มนั้นถูกต้อง UTF-8 *การปฏิเสธ* จากอัลกอริทึมสามารถตกอยู่ในดัชนีใดก็ได้ แต่เราจะนำดัชนีเหล่านั้นไปยังขอบเขตอักขระถัดไป เพื่อให้พวกเขาปลอดภัย utf-8
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // ข้ามไปยังขอบเขตถ่านถัดไป
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // เขียนเคส `true` และ `false` เพื่อกระตุ้นให้คอมไพเลอร์เชี่ยวชาญทั้งสองเคสแยกกัน
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // ข้ามไปยังขอบเขตถ่านถัดไป
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // เขียน `true` และ `false` เช่น `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// สถานะภายในของอัลกอริทึมการค้นหาสตริงย่อยสองทาง
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// ดัชนีการแยกตัวประกอบวิกฤต
    crit_pos: usize,
    /// ดัชนีการแยกตัวประกอบวิกฤตสำหรับเข็มกลับด้าน
    crit_pos_back: usize,
    period: usize,
    /// `byteset` เป็นส่วนขยาย (ไม่ใช่ส่วนหนึ่งของอัลกอริทึมสองทาง)
    /// เป็น "fingerprint" 64 บิตโดยที่บิต `j` แต่ละชุดสอดคล้องกับ (ไบต์&63)==j ที่มีอยู่ในเข็ม
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// ดัชนีเป็นเข็มก่อนที่เราจับคู่แล้ว
    memory: usize,
    /// ดัชนีเป็นเข็มหลังจากที่เราได้จับคู่แล้ว
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // คำอธิบายที่อ่านได้โดยเฉพาะเกี่ยวกับสิ่งที่เกิดขึ้นที่นี่สามารถพบได้ในหนังสือของ Crochemore and Rytter "Text Algorithms" ตอนที่ 13
        // ดูรหัสสำหรับ "Algorithm CP" โดยเฉพาะในหน้า
        // 323.
        //
        // สิ่งที่เกิดขึ้นคือเรามีการแยกตัวประกอบวิกฤต (u, v) ของเข็มและเราต้องการหาว่า u เป็นส่วนต่อท้ายของ&v [.. period] หรือไม่
        // ถ้าเป็นเราใช้ "Algorithm CP1"
        // มิฉะนั้นเราจะใช้ "Algorithm CP2" ซึ่งเหมาะสำหรับช่วงที่เข็มมีขนาดใหญ่
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // กรณีระยะเวลาสั้น-ระยะเวลาคำนวณที่แน่นอนการแยกตัวประกอบที่สำคัญแยกต่างหากสำหรับเข็มย้อนกลับ x=u 'v' โดยที่ | v '|<period(x).
            //
            // สิ่งนี้เพิ่มขึ้นตามระยะเวลาที่ทราบกันดีอยู่แล้ว
            // โปรดทราบว่ากรณีเช่น x= "acba" อาจถูกแยกตัวประกอบไปข้างหน้าอย่างแน่นอน (Crit_pos=1, period=3) ในขณะที่แยกตัวประกอบด้วยระยะเวลาโดยประมาณในการย้อนกลับ (Crit_pos=2, period=2)
            // เราใช้การแยกตัวประกอบย้อนกลับที่กำหนด แต่รักษาช่วงเวลาที่แน่นอน
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // กรณีระยะยาว-เรามีการประมาณระยะเวลาจริงและไม่ใช้การท่องจำ
            //
            //
            // ระยะเวลาโดยประมาณโดยขอบล่าง max(|u|, |v|) + 1
            // การแยกตัวประกอบวิกฤตมีประสิทธิภาพที่จะใช้สำหรับการค้นหาทั้งไปข้างหน้าและย้อนกลับ
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // ค่า Dummy เพื่อแสดงว่าช่วงเวลานั้นยาว
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // แนวคิดหลักอย่างหนึ่งของ Two-Way คือเราแยกเข็มออกเป็นสองซีก (u, v) และเริ่มพยายามหา v ในกองหญ้าด้วยการสแกนจากซ้ายไปขวา
    // ถ้า v ตรงกันเราจะพยายามจับคู่ u โดยการสแกนจากขวาไปซ้าย
    // เราจะกระโดดได้ไกลแค่ไหนเมื่อเราพบความไม่ตรงกันทั้งหมดนั้นขึ้นอยู่กับข้อเท็จจริงที่ว่า (u, v) เป็นตัวประกอบที่สำคัญสำหรับเข็ม
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` ใช้ `self.position` เป็นเคอร์เซอร์
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // ตรวจสอบว่าเรามีที่ว่างในการค้นหาในตำแหน่ง + needle_last ไม่สามารถล้นได้หากเราถือว่าชิ้นส่วนถูกล้อมรอบด้วยช่วงของ isize
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // ข้ามไปอย่างรวดเร็วโดยส่วนใหญ่ ๆ ที่ไม่เกี่ยวข้องกับสตริงย่อยของเรา
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // ดูว่าส่วนด้านขวาของเข็มตรงกันหรือไม่
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // ดูว่าส่วนด้านซ้ายของเข็มตรงกันหรือไม่
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // เราเจอคู่แล้ว!
            let match_pos = self.position;

            // Note: เพิ่ม self.period แทน needle.len() เพื่อให้มีการจับคู่ที่ทับซ้อนกัน
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // ตั้งค่าเป็น needle.len(), self.period สำหรับการจับคู่ที่ทับซ้อนกัน
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // ทำตามแนวคิดใน `next()`
    //
    // คำจำกัดความเป็นแบบสมมาตรโดย period(x) = period(reverse(x)) และ local_period(u, v) = local_period(reverse(v), reverse(u)) ดังนั้นถ้า (u, v) เป็นการแยกตัวประกอบวิกฤตดังนั้น (reverse(v) ก็เช่นกัน reverse(u)).
    //
    //
    // สำหรับกรณีย้อนกลับเราได้คำนวณการแยกตัวประกอบวิกฤต x=u 'v' (ฟิลด์ `crit_pos_back`)เราต้องการ | u |<period(x) สำหรับเคสส่งต่อดังนั้น | v '|<period(x) สำหรับการย้อนกลับ
    //
    // หากต้องการค้นหาในทางกลับกันผ่านกองหญ้าเราค้นหาไปข้างหน้าผ่านกองหญ้าที่กลับด้านด้วยเข็มที่กลับด้านโดยจับคู่ u 'ตัวแรกแล้วตามด้วย v'
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` ใช้ `self.end` เป็นเคอร์เซอร์-เพื่อให้ `next()` และ `next_back()` เป็นอิสระ
        //
        let old_end = self.end;
        'search: loop {
            // ตรวจสอบว่าเรามีที่ว่างสำหรับการค้นหาในที่สุด needle.len() จะพันรอบเมื่อไม่มีที่ว่างอีกต่อไป แต่เนื่องจากขีดจำกัดความยาวของชิ้นจึงไม่สามารถพันกลับเข้าไปในความยาวของกองหญ้าได้ทั้งหมด
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // ข้ามไปอย่างรวดเร็วโดยส่วนใหญ่ ๆ ที่ไม่เกี่ยวข้องกับสตริงย่อยของเรา
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // ดูว่าส่วนด้านซ้ายของเข็มตรงกันหรือไม่
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // ดูว่าส่วนด้านขวาของเข็มตรงกันหรือไม่
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // เราเจอคู่แล้ว!
            let match_pos = self.end - needle.len();
            // Note: ย่อย self.period แทน needle.len() เพื่อให้มีการจับคู่ที่ทับซ้อนกัน
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // คำนวณส่วนต่อท้ายสูงสุดของ `arr`
    //
    // คำต่อท้ายสูงสุดคือการแยกตัวประกอบวิกฤตที่เป็นไปได้ (u, v) ของ `arr`
    //
    // ผลตอบแทน ("i`, `p`) โดยที่ `i` เป็นดัชนีเริ่มต้นของ v และ `p` คือช่วงเวลาของ v
    //
    // `order_greater` กำหนดว่าลำดับศัพท์คือ `<` หรือ `>`
    // คำสั่งซื้อทั้งสองต้องได้รับการคำนวณ-การสั่งซื้อด้วย `i` ที่ใหญ่ที่สุดจะให้การแยกตัวประกอบที่สำคัญ
    //
    //
    // สำหรับกรณีระยะยาวระยะเวลาผลลัพธ์จะไม่แน่นอน (สั้นเกินไป)
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // สอดคล้องกับ i ในกระดาษ
        let mut right = 1; // สอดคล้องกับ j ในกระดาษ
        let mut offset = 0; // สอดคล้องกับ k ในกระดาษ แต่เริ่มต้นที่ 0
        // เพื่อให้ตรงกับการจัดทำดัชนีตาม 0
        let mut period = 1; // สอดคล้องกับ p ในกระดาษ

        while let Some(&a) = arr.get(right + offset) {
            // `left` จะเป็นขาเข้าเมื่อ `right` คือ
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // คำต่อท้ายมีขนาดเล็กกว่าช่วงเวลาเป็นคำนำหน้าทั้งหมด
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // เลื่อนผ่านการทำซ้ำของช่วงเวลาปัจจุบัน
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // คำต่อท้ายมีขนาดใหญ่ขึ้นเริ่มต้นใหม่จากตำแหน่งปัจจุบัน
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // คำนวณส่วนต่อท้ายสูงสุดของการย้อนกลับของ `arr`
    //
    // คำต่อท้ายสูงสุดคือการแยกตัวประกอบวิกฤตที่เป็นไปได้ (u ', v') ของ `arr`
    //
    // ส่งคืน `i` โดยที่ `i` เป็นดัชนีเริ่มต้นของ v 'จากด้านหลัง
    // ส่งคืนทันทีเมื่อถึงช่วงเวลา `known_period`
    //
    // `order_greater` กำหนดว่าลำดับศัพท์คือ `<` หรือ `>`
    // คำสั่งซื้อทั้งสองต้องได้รับการคำนวณ-การสั่งซื้อด้วย `i` ที่ใหญ่ที่สุดจะให้การแยกตัวประกอบที่สำคัญ
    //
    //
    // สำหรับกรณีระยะยาวระยะเวลาผลลัพธ์จะไม่แน่นอน (สั้นเกินไป)
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // สอดคล้องกับ i ในกระดาษ
        let mut right = 1; // สอดคล้องกับ j ในกระดาษ
        let mut offset = 0; // สอดคล้องกับ k ในกระดาษ แต่เริ่มต้นที่ 0
        // เพื่อให้ตรงกับการจัดทำดัชนีตาม 0
        let mut period = 1; // สอดคล้องกับ p ในกระดาษ
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // คำต่อท้ายมีขนาดเล็กกว่าช่วงเวลาเป็นคำนำหน้าทั้งหมด
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // เลื่อนผ่านการทำซ้ำของช่วงเวลาปัจจุบัน
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // คำต่อท้ายมีขนาดใหญ่ขึ้นเริ่มต้นใหม่จากตำแหน่งปัจจุบัน
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy ช่วยให้อัลกอริทึมสามารถข้ามรายการที่ไม่ตรงกันได้โดยเร็วที่สุดหรือทำงานในโหมดที่ปล่อยออกมาอย่างรวดเร็ว
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// ข้ามเพื่อจับคู่ช่วงเวลาให้เร็วที่สุด
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Emit Rejects เป็นประจำ
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}