//! กำหนดประเภทข้อผิดพลาด utf8

use crate::fmt;

/// ข้อผิดพลาดที่อาจเกิดขึ้นเมื่อพยายามตีความลำดับของ [`u8`] เป็นสตริง
///
/// ดังนั้นตระกูล `from_utf8` ของฟังก์ชันและวิธีการสำหรับทั้ง ["String`] s และ [`&str`] จึงใช้ประโยชน์จากข้อผิดพลาดนี้
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// วิธีการของประเภทข้อผิดพลาดนี้สามารถใช้เพื่อสร้างฟังก์ชันที่คล้ายกับ `String::from_utf8_lossy` โดยไม่ต้องจัดสรรหน่วยความจำฮีป:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// ส่งคืนดัชนีในสตริงที่กำหนดซึ่ง UTF-8 ถูกต้องได้รับการตรวจสอบ
    ///
    /// เป็นดัชนีสูงสุดที่ `from_utf8(&input[..index])` จะคืนค่า `Ok(_)`
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// use std::str;
    ///
    /// // บางไบต์ที่ไม่ถูกต้องใน vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 ส่งคืน Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // ไบต์ที่สองไม่ถูกต้องที่นี่
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// ให้ข้อมูลเพิ่มเติมเกี่ยวกับความล้มเหลว:
    ///
    /// * `None`: ถึงจุดสิ้นสุดของอินพุตโดยไม่คาดคิด
    ///   `self.valid_up_to()` คือ 1 ถึง 3 ไบต์จากจุดสิ้นสุดของอินพุต
    ///   หากสตรีมไบต์ (เช่นไฟล์หรือซ็อกเก็ตเครือข่าย) ถูกถอดรหัสเพิ่มขึ้นนี่อาจเป็น `char` ที่ถูกต้องซึ่งลำดับ UTF-8 ไบต์นั้นครอบคลุมหลายส่วน
    ///
    ///
    /// * `Some(len)`: พบไบต์ที่ไม่คาดคิด
    ///   ความยาวที่ระบุคือลำดับไบต์ที่ไม่ถูกต้องซึ่งเริ่มต้นที่ดัชนีที่กำหนดโดย `valid_up_to()`
    ///   การถอดรหัสควรดำเนินการต่อหลังจากลำดับนั้น (หลังจากใส่ [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) ในกรณีที่มีการถอดรหัสแบบ lossy
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// เกิดข้อผิดพลาดเมื่อแยกวิเคราะห์ `bool` โดยใช้ [`from_str`] ล้มเหลว
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}