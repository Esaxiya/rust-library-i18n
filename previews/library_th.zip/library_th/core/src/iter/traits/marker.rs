/// ตัววนซ้ำที่ยังคงให้ผล `None` เสมอเมื่อหมด
///
/// การเรียกถัดไปบนตัววนซ้ำแบบผสมที่ส่งคืน `None` หนึ่งครั้งรับประกันว่าจะกลับมา [`None`] อีกครั้ง
/// trait นี้ควรได้รับการปรับใช้โดยตัวทำซ้ำทั้งหมดที่ทำงานในลักษณะนี้เนื่องจากอนุญาตให้เพิ่มประสิทธิภาพ [`Iterator::fuse()`]
///
///
/// Note: โดยทั่วไปคุณไม่ควรใช้ `FusedIterator` ในขอบเขตทั่วไปหากคุณต้องการตัววนซ้ำแบบผสม
/// แต่คุณควรเรียกใช้ [`Iterator::fuse()`] บนตัววนซ้ำแทน
/// หากตัววนซ้ำถูกหลอมรวมอยู่แล้วกระดาษห่อหุ้ม [`Fuse`] เพิ่มเติมจะเป็นแบบ no-op และไม่มีการลงโทษด้านประสิทธิภาพ
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// ตัววนซ้ำที่รายงานความยาวที่ถูกต้องโดยใช้ size_hint
///
/// ตัววนซ้ำรายงานคำใบ้ขนาดโดยที่มันถูกต้อง (ขอบเขตล่างเท่ากับขอบเขตบน) หรือขอบเขตบนคือ [`None`]
///
/// ขอบเขตด้านบนต้องเป็น [`None`] เท่านั้นหากความยาวตัววนซ้ำจริงมีขนาดใหญ่กว่า [`usize::MAX`]
/// ในกรณีนั้นขอบเขตล่างจะต้องเป็น [`usize::MAX`] ส่งผลให้ [`Iterator::size_hint()`] เป็น `(usize::MAX, None)`
///
/// ตัววนซ้ำต้องสร้างจำนวนองค์ประกอบที่รายงานหรือแยกส่วนก่อนที่จะถึงจุดสิ้นสุด
///
/// # Safety
///
/// trait นี้จะต้องดำเนินการเมื่อสัญญาถูกยึดถือเท่านั้น
/// ผู้บริโภค trait นี้ต้องตรวจสอบขอบเขตบนของ [`Iterator::size_hint()`]’s
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// ตัวย้ำว่าเมื่อส่งมอบไอเท็มจะได้รับอย่างน้อยหนึ่งองค์ประกอบจาก [`SourceIter`] ที่อยู่ข้างใต้
///
/// เรียกเมธอดใด ๆ ที่ทำให้ตัววนซ้ำเช่น
/// [`next()`] หรือ [`try_fold()`] รับประกันว่าในแต่ละขั้นตอนอย่างน้อยหนึ่งค่าของแหล่งอ้างอิงของตัววนซ้ำถูกย้ายออกและผลลัพธ์ของห่วงโซ่ตัววนซ้ำสามารถแทรกเข้าที่ได้โดยสมมติว่าข้อ จำกัด เชิงโครงสร้างของแหล่งที่มาอนุญาตให้มีการแทรกดังกล่าว
///
/// กล่าวอีกนัยหนึ่ง trait นี้บ่งชี้ว่าสามารถรวบรวมไปป์ไลน์ตัววนซ้ำได้
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}