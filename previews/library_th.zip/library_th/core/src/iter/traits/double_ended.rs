use crate::ops::{ControlFlow, Try};

/// ตัววนซ้ำสามารถให้องค์ประกอบจากปลายทั้งสองด้าน
///
/// สิ่งที่ใช้ `DoubleEndedIterator` มีความสามารถพิเศษอย่างหนึ่งเหนือสิ่งที่ใช้ [`Iterator`] นั่นคือความสามารถในการรับ "ไอเทม" จากด้านหลังเช่นเดียวกับด้านหน้า
///
///
/// สิ่งสำคัญคือต้องสังเกตว่าทั้งไปและกลับทำงานในช่วงเดียวกันและอย่าข้าม: การทำซ้ำจะจบลงเมื่อพบกันตรงกลาง
///
/// ในทำนองเดียวกันกับโปรโตคอล [`Iterator`] เมื่อ `DoubleEndedIterator` ส่งคืน [`None`] จาก [`next_back()`] การเรียกอีกครั้งอาจส่งคืน [`Some`] อีกหรือไม่ก็ได้
/// [`next()`] และ [`next_back()`] สามารถใช้แทนกันได้เพื่อจุดประสงค์นี้
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// การใช้งานพื้นฐาน:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// ลบและส่งคืนองค์ประกอบจากส่วนท้ายของตัววนซ้ำ
    ///
    /// ส่งคืน `None` เมื่อไม่มีองค์ประกอบเพิ่มเติม
    ///
    /// เอกสาร [trait-level] มีรายละเอียดเพิ่มเติม
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// องค์ประกอบที่ได้จากเมธอดของ "DoubleEndedIterator" อาจแตกต่างจากองค์ประกอบที่ได้รับจากเมธอดของ ["Iterator`]:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// เลื่อนตัววนซ้ำจากด้านหลังด้วยองค์ประกอบ `n`
    ///
    /// `advance_back_by` เป็นรุ่นย้อนกลับของ [`advance_by`] วิธีนี้จะข้ามองค์ประกอบ `n` อย่างกระตือรือร้นโดยเริ่มจากด้านหลังโดยเรียก [`next_back`] สูงสุด `n` ครั้งจนกว่าจะพบ [`None`]
    ///
    /// `advance_back_by(n)` จะส่งคืน [`Ok(())`] หากตัววนซ้ำเลื่อนไปข้างหน้าโดยองค์ประกอบ `n` สำเร็จหรือ [`Err(k)`] หากพบ [`None`] โดยที่ `k` คือจำนวนขององค์ประกอบที่ตัววนซ้ำขั้นสูงก่อนที่จะหมดองค์ประกอบ (เช่น
    /// ความยาวของตัววนซ้ำ)
    /// โปรดทราบว่า `k` น้อยกว่า `n` เสมอ
    ///
    /// การเรียกใช้ `advance_back_by(0)` ไม่ใช้องค์ประกอบใด ๆ และส่งคืน [`Ok(())`] เสมอ
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // มีเพียง `&3` เท่านั้นที่ถูกข้ามไป
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// ส่งคืนองค์ประกอบ "n" จากจุดสิ้นสุดของตัววนซ้ำ
    ///
    /// นี่คือเวอร์ชันย้อนกลับของ [`Iterator::nth()`] โดยพื้นฐานแล้ว
    /// แม้ว่าจะเหมือนกับการดำเนินการจัดทำดัชนีส่วนใหญ่การนับจะเริ่มจากศูนย์ดังนั้น `nth_back(0)` จึงส่งคืนค่าแรกจากจุดสิ้นสุด `nth_back(1)` ที่สองและอื่น ๆ
    ///
    ///
    /// โปรดทราบว่าองค์ประกอบทั้งหมดที่อยู่ระหว่างจุดสิ้นสุดและองค์ประกอบที่ส่งคืนจะถูกใช้ไปรวมถึงองค์ประกอบที่ส่งคืนด้วย
    /// นอกจากนี้ยังหมายความว่าการเรียก `nth_back(0)` หลาย ๆ ครั้งบนตัววนซ้ำเดียวกันจะส่งคืนองค์ประกอบที่แตกต่างกัน
    ///
    /// `nth_back()` จะคืนค่า [`None`] ถ้า `n` มากกว่าหรือเท่ากับความยาวของตัววนซ้ำ
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// การโทร `nth_back()` หลาย ๆ ครั้งจะไม่ย้อนกลับตัววนซ้ำ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// การส่งคืน `None` หากมีองค์ประกอบน้อยกว่า `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// นี่คือเวอร์ชันย้อนกลับของ [`Iterator::try_fold()`]: ใช้องค์ประกอบเริ่มจากด้านหลังของตัววนซ้ำ
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // เนื่องจากมันลัดวงจรองค์ประกอบที่เหลือจึงยังคงใช้งานได้ผ่านตัววนซ้ำ
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// วิธีการวนซ้ำที่ลดอิลิเมนต์ของตัววนซ้ำให้เป็นค่าสุดท้ายเพียงค่าเดียวโดยเริ่มจากด้านหลัง
    ///
    /// นี่คือเวอร์ชันย้อนกลับของ [`Iterator::fold()`]: ใช้องค์ประกอบเริ่มจากด้านหลังของตัววนซ้ำ
    ///
    /// `rfold()` รับสองอาร์กิวเมนต์: ค่าเริ่มต้นและปิดด้วยสองอาร์กิวเมนต์: 'accumulator' และองค์ประกอบ
    /// การปิดจะส่งคืนค่าที่ตัวสะสมควรมีสำหรับการทำซ้ำครั้งต่อไป
    ///
    /// ค่าเริ่มต้นคือค่าที่ตัวสะสมจะมีในการโทรครั้งแรก
    ///
    /// หลังจากใช้การปิดนี้กับทุกองค์ประกอบของตัววนซ้ำแล้ว `rfold()` จะส่งคืนตัวสะสม
    ///
    /// การดำเนินการนี้บางครั้งเรียกว่า 'reduce' หรือ 'inject'
    ///
    /// การพับมีประโยชน์ทุกครั้งที่คุณมีของสะสมและต้องการสร้างมูลค่าเดียวจากมัน
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ผลรวมขององค์ประกอบทั้งหมดของก
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// ตัวอย่างนี้สร้างสตริงโดยเริ่มต้นด้วยค่าเริ่มต้นและดำเนินการต่อกับแต่ละองค์ประกอบจากด้านหลังจนถึงด้านหน้า:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// ค้นหาองค์ประกอบของตัววนซ้ำจากด้านหลังที่ตรงตามเพรดิเคต
    ///
    /// `rfind()` รับการปิดที่ส่งคืน `true` หรือ `false`
    /// ใช้การปิดนี้กับแต่ละองค์ประกอบของตัววนซ้ำโดยเริ่มต้นที่จุดสิ้นสุดและหากมีสิ่งใดส่งคืน `true` ดังนั้น `rfind()` จะส่งคืน [`Some(element)`]
    /// หากพวกเขาส่งคืน `false` ทั้งหมดจะส่งคืน [`None`]
    ///
    /// `rfind()` กำลังลัดวงจรกล่าวอีกนัยหนึ่งก็คือจะหยุดประมวลผลทันทีที่การปิดคืนค่า `true`
    ///
    /// เนื่องจาก `rfind()` ใช้การอ้างอิงและผู้ทำซ้ำหลายคนวนซ้ำการอ้างอิงสิ่งนี้จึงนำไปสู่สถานการณ์ที่อาจสับสนซึ่งอาร์กิวเมนต์เป็นการอ้างอิงสองครั้ง
    ///
    /// คุณสามารถดูเอฟเฟกต์นี้ได้ในตัวอย่างด้านล่างด้วย `&&x`
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// การหยุดที่ `true` แรก:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // เรายังสามารถใช้ `iter` ได้เนื่องจากมีองค์ประกอบมากขึ้น
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}