// เพิกเฉยต่อความเป็นระเบียบเรียบร้อยไฟล์ความยาวไฟล์นี้เกือบทั้งหมดประกอบด้วยนิยามของ `Iterator`
// เราไม่สามารถแยกไฟล์นั้นออกเป็นหลายไฟล์ได้
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// อินเทอร์เฟซสำหรับจัดการกับตัวทำซ้ำ
///
/// นี่คือตัววนซ้ำหลัก trait
/// สำหรับข้อมูลเพิ่มเติมเกี่ยวกับแนวคิดของตัววนซ้ำโดยทั่วไปโปรดดู [module-level documentation]
/// โดยเฉพาะอย่างยิ่งคุณอาจต้องการทราบวิธีการ [implement `Iterator`][impl]
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// ประเภทขององค์ประกอบที่ถูกทำซ้ำ
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// เลื่อนตัววนซ้ำและส่งคืนค่าถัดไป
    ///
    /// ส่งคืน [`None`] เมื่อการวนซ้ำเสร็จสิ้น
    /// การใช้งานตัววนซ้ำแต่ละตัวอาจเลือกที่จะดำเนินการวนซ้ำดังนั้นการเรียกใช้ `next()` อีกครั้งอาจหรือไม่อาจเริ่มคืนค่า [`Some(Item)`] อีกครั้งในบางจุด
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // การเรียก next() จะส่งกลับค่าถัดไป ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... แล้วก็ไม่มีเมื่อมันจบลง
    /// assert_eq!(None, iter.next());
    ///
    /// // การโทรเพิ่มเติมอาจส่งคืน `None` หรือไม่ก็ได้ที่นี่พวกเขาจะเสมอ
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// ส่งคืนขอบเขตของความยาวที่เหลือของตัววนซ้ำ
    ///
    /// โดยเฉพาะ `size_hint()` จะส่งคืนทูเพิลโดยที่องค์ประกอบแรกเป็นขอบเขตล่างและองค์ประกอบที่สองคือขอบเขตบน
    ///
    /// ครึ่งหลังของทูเปิลที่ส่งคืนคือ [`Option`]`<`[`usize`] `>`
    /// [`None`] ในที่นี้หมายความว่าไม่มีขอบเขตบนหรือขอบเขตบนมีขนาดใหญ่กว่า [`usize`]
    ///
    /// # บันทึกการใช้งาน
    ///
    /// ไม่มีการบังคับใช้ว่าการใช้ตัววนซ้ำจะให้ผลตามจำนวนองค์ประกอบที่ประกาศไว้ตัววนซ้ำแบบบั๊กกี้อาจให้ผลน้อยกว่าขอบเขตล่างหรือมากกว่าขอบเขตบนขององค์ประกอบ
    ///
    /// `size_hint()` มีวัตถุประสงค์หลักเพื่อใช้สำหรับการเพิ่มประสิทธิภาพเช่นการจองพื้นที่สำหรับองค์ประกอบของตัววนซ้ำ แต่ต้องไม่เชื่อถือเช่นละเว้นการตรวจสอบในรหัสที่ไม่ปลอดภัย
    /// การนำ `size_hint()` ไปใช้อย่างไม่ถูกต้องไม่ควรนำไปสู่การละเมิดความปลอดภัยของหน่วยความจำ
    ///
    /// ที่กล่าวว่าการนำไปใช้งานควรมีการประมาณที่ถูกต้องเพราะมิฉะนั้นจะเป็นการละเมิดโปรโตคอลของ trait
    ///
    /// การใช้งานเริ่มต้นจะส่งคืนค่า "(0," ["ไม่มี"] `)" ซึ่งถูกต้องสำหรับตัววนซ้ำใด ๆ
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// ตัวอย่างที่ซับซ้อนมากขึ้น:
    ///
    /// ```
    /// // เลขคู่จากศูนย์ถึงสิบ
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // เราอาจทำซ้ำจากศูนย์ถึงสิบครั้ง
    /// // การรู้ว่ามันเป็นไปไม่ได้เลยหากไม่ดำเนินการ filter()
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // ลองเพิ่มตัวเลขอีกห้าตัวด้วย chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // ตอนนี้ทั้งสองขอบเขตเพิ่มขึ้นห้า
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// การส่งคืน `None` สำหรับขอบเขตบน:
    ///
    /// ```
    /// // ตัววนซ้ำแบบไม่มีที่สิ้นสุดไม่มีขอบเขตบนและขอบเขตล่างสูงสุดที่เป็นไปได้
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// ใช้ตัววนซ้ำนับจำนวนการวนซ้ำและส่งคืน
    ///
    /// วิธีนี้จะเรียก [`next`] ซ้ำ ๆ จนกว่าจะพบ [`None`] โดยส่งคืนจำนวนครั้งที่เห็น [`Some`]
    /// โปรดทราบว่า [`next`] จะต้องถูกเรียกอย่างน้อยหนึ่งครั้งแม้ว่าตัววนซ้ำจะไม่มีองค์ประกอบใด ๆ ก็ตาม
    ///
    /// [`next`]: Iterator::next
    ///
    /// # พฤติกรรมล้น
    ///
    /// วิธีนี้ไม่ได้ป้องกันการล้นดังนั้นการนับองค์ประกอบของตัววนซ้ำที่มีองค์ประกอบมากกว่า [`usize::MAX`] อาจทำให้เกิดผลลัพธ์ที่ไม่ถูกต้องหรือ panics
    ///
    /// หากเปิดใช้งานการยืนยันการดีบักรับรอง panic
    ///
    /// # Panics
    ///
    /// ฟังก์ชันนี้อาจ panic หากตัววนซ้ำมีองค์ประกอบมากกว่า [`usize::MAX`]
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// ใช้ตัววนซ้ำโดยส่งคืนองค์ประกอบสุดท้าย
    ///
    /// วิธีนี้จะประเมินตัววนซ้ำจนกว่าจะส่งคืน [`None`]
    /// ในขณะที่ทำเช่นนั้นจะติดตามองค์ประกอบปัจจุบัน
    /// หลังจากส่งคืน [`None`] แล้ว `last()` จะส่งคืนองค์ประกอบสุดท้ายที่เห็น
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// เลื่อนตัววนซ้ำด้วยองค์ประกอบ `n`
    ///
    /// วิธีนี้จะข้ามองค์ประกอบ `n` อย่างกระตือรือร้นโดยเรียก [`next`] สูงสุด `n` ครั้งจนกว่าจะพบ [`None`]
    ///
    /// `advance_by(n)` จะส่งคืน [`Ok(())`][Ok] หากตัววนซ้ำเลื่อนไปข้างหน้าโดยองค์ประกอบ `n` สำเร็จหรือ [`Err(k)`][Err] หากพบ [`None`] โดยที่ `k` คือจำนวนขององค์ประกอบที่ตัววนซ้ำขั้นสูงก่อนที่จะหมดองค์ประกอบ (เช่น
    /// ความยาวของตัววนซ้ำ)
    /// โปรดทราบว่า `k` น้อยกว่า `n` เสมอ
    ///
    /// การเรียกใช้ `advance_by(0)` ไม่ใช้องค์ประกอบใด ๆ และส่งคืน [`Ok(())`][Ok] เสมอ
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // มีเพียง `&4` เท่านั้นที่ถูกข้ามไป
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// ส่งคืนองค์ประกอบ "n" ของตัววนซ้ำ
    ///
    /// เช่นเดียวกับการดำเนินการจัดทำดัชนีส่วนใหญ่การนับจะเริ่มจากศูนย์ดังนั้น `nth(0)` จะส่งกลับค่าแรก `nth(1)` ที่สองและอื่น ๆ
    ///
    /// โปรดทราบว่าองค์ประกอบก่อนหน้าทั้งหมดตลอดจนองค์ประกอบที่ส่งคืนจะถูกใช้จากตัววนซ้ำ
    /// นั่นหมายความว่าองค์ประกอบก่อนหน้านี้จะถูกละทิ้งและการเรียก `nth(0)` หลาย ๆ ครั้งบนตัววนซ้ำเดียวกันจะส่งคืนองค์ประกอบที่แตกต่างกัน
    ///
    ///
    /// `nth()` จะคืนค่า [`None`] ถ้า `n` มากกว่าหรือเท่ากับความยาวของตัววนซ้ำ
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// การโทร `nth()` หลาย ๆ ครั้งจะไม่ย้อนกลับตัววนซ้ำ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// การส่งคืน `None` หากมีองค์ประกอบน้อยกว่า `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// สร้างตัววนซ้ำโดยเริ่มจากจุดเดียวกัน แต่จะก้าวตามจำนวนที่กำหนดในการวนซ้ำแต่ละครั้ง
    ///
    /// หมายเหตุ 1: องค์ประกอบแรกของตัววนซ้ำจะถูกส่งกลับเสมอโดยไม่คำนึงถึงขั้นตอนที่กำหนด
    ///
    /// หมายเหตุ 2: เวลาที่ดึงองค์ประกอบที่ละเว้นไม่ได้รับการแก้ไข
    /// `StepBy` ทำงานเหมือนลำดับ `next(), nth(step-1), nth(step-1),…` แต่ก็มีอิสระที่จะทำงานเหมือนลำดับ
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// วิธีที่ใช้อาจเปลี่ยนไปสำหรับตัวทำซ้ำบางตัวด้วยเหตุผลด้านประสิทธิภาพ
    /// วิธีที่สองจะเลื่อนตัวทำซ้ำก่อนหน้านี้และอาจใช้ไอเท็มมากขึ้น
    ///
    /// `advance_n_and_return_first` เทียบเท่ากับ:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// วิธีการจะ panic ถ้าขั้นตอนที่กำหนดคือ `0`
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// ใช้ตัวทำซ้ำสองตัวและสร้างตัววนซ้ำใหม่ทั้งสองตามลำดับ
    ///
    /// `chain()` จะส่งคืนตัวทำซ้ำตัวใหม่ซึ่งก่อนอื่นจะวนซ้ำค่าจากตัววนซ้ำตัวแรกแล้วจึงทับค่าจากตัววนซ้ำตัวที่สอง
    ///
    /// กล่าวอีกนัยหนึ่งก็คือมันเชื่อมโยงตัวทำซ้ำสองตัวเข้าด้วยกันเป็นลูกโซ่🔗
    ///
    /// [`once`] มักใช้เพื่อปรับค่าเดียวให้เป็นห่วงโซ่ของการวนซ้ำประเภทอื่น ๆ
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// เนื่องจากอาร์กิวเมนต์ของ `chain()` ใช้ [`IntoIterator`] เราสามารถส่งผ่านอะไรก็ได้ที่สามารถแปลงเป็น [`Iterator`] ได้ไม่ใช่แค่ [`Iterator`] เท่านั้น
    /// ตัวอย่างเช่นชิ้น (`&[T]`) ใช้ [`IntoIterator`] และสามารถส่งผ่านไปยัง `chain()` ได้โดยตรง:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// หากคุณทำงานกับ Windows API คุณอาจต้องการแปลง [`OsStr`] เป็น `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'ซิปขึ้น' ตัววนซ้ำสองตัวเป็นตัววนซ้ำคู่เดียว
    ///
    /// `zip()` ส่งคืนตัววนซ้ำใหม่ที่จะวนซ้ำบนตัวทำซ้ำอีกสองตัวส่งคืนทูเพิลที่องค์ประกอบแรกมาจากตัววนซ้ำตัวแรกและองค์ประกอบที่สองมาจากตัวทำซ้ำตัวที่สอง
    ///
    ///
    /// กล่าวอีกนัยหนึ่งคือมันจะรวมตัวทำซ้ำสองตัวเข้าด้วยกันเป็นตัวเดียว
    ///
    /// หากตัววนซ้ำส่งคืน [`None`] [`next`] จากตัววนซ้ำที่บีบอัดจะส่งคืน [`None`]
    /// หากตัววนซ้ำตัวแรกส่งคืน [`None`] `zip` จะลัดวงจรและ `next` จะไม่ถูกเรียกบนตัววนซ้ำตัวที่สอง
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// เนื่องจากอาร์กิวเมนต์ของ `zip()` ใช้ [`IntoIterator`] เราสามารถส่งผ่านอะไรก็ได้ที่สามารถแปลงเป็น [`Iterator`] ได้ไม่ใช่แค่ [`Iterator`] เท่านั้น
    /// ตัวอย่างเช่นชิ้น (`&[T]`) ใช้ [`IntoIterator`] และสามารถส่งผ่านไปยัง `zip()` ได้โดยตรง:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` มักใช้เพื่อซิปตัววนซ้ำแบบไม่มีที่สิ้นสุดไปยังตัว จำกัด
    /// วิธีนี้ใช้ได้ผลเนื่องจากตัววนซ้ำแบบ จำกัด จะคืนค่า [`None`] ในที่สุดและสิ้นสุดซิปการซิปด้วย `(0..)` อาจดูเหมือน [`enumerate`] มาก:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// สร้างตัววนซ้ำใหม่ซึ่งวางสำเนา `separator` ไว้ระหว่างรายการที่อยู่ติดกันของตัววนซ้ำเดิม
    ///
    /// ในกรณีที่ `separator` ไม่ใช้ [`Clone`] หรือจำเป็นต้องคำนวณทุกครั้งให้ใช้ [`intersperse_with`]
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // องค์ประกอบแรกจาก `a`
    /// assert_eq!(a.next(), Some(&100)); // ตัวคั่น
    /// assert_eq!(a.next(), Some(&1));   // องค์ประกอบถัดไปจาก `a`
    /// assert_eq!(a.next(), Some(&100)); // ตัวคั่น
    /// assert_eq!(a.next(), Some(&2));   // องค์ประกอบสุดท้ายจาก `a`
    /// assert_eq!(a.next(), None);       // ตัววนซ้ำเสร็จแล้ว
    /// ```
    ///
    /// `intersperse` จะมีประโยชน์มากในการเข้าร่วมรายการของตัววนซ้ำโดยใช้องค์ประกอบทั่วไป:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// สร้างตัววนซ้ำใหม่ซึ่งวางรายการที่สร้างโดย `separator` ระหว่างรายการที่อยู่ติดกันของตัววนซ้ำเดิม
    ///
    /// การปิดจะถูกเรียกอย่างแน่นอนทุกครั้งที่วางไอเท็มระหว่างสองรายการที่อยู่ติดกันจากตัวย้ำต้นแบบ
    /// โดยเฉพาะอย่างยิ่งการปิดจะไม่ถูกเรียกหากตัววนซ้ำที่สำคัญให้ผลตอบแทนน้อยกว่าสองรายการและหลังจากได้รับไอเท็มสุดท้ายแล้ว
    ///
    ///
    /// หากรายการของ iterator ใช้ [`Clone`] อาจใช้ [`intersperse`] ได้ง่ายกว่า
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // องค์ประกอบแรกจาก `v`
    /// assert_eq!(it.next(), Some(NotClone(99))); // ตัวคั่น
    /// assert_eq!(it.next(), Some(NotClone(1)));  // องค์ประกอบถัดไปจาก `v`
    /// assert_eq!(it.next(), Some(NotClone(99))); // ตัวคั่น
    /// assert_eq!(it.next(), Some(NotClone(2)));  // องค์ประกอบสุดท้ายจาก `v`
    /// assert_eq!(it.next(), None);               // ตัววนซ้ำเสร็จแล้ว
    /// ```
    ///
    /// `intersperse_with` สามารถใช้ในสถานการณ์ที่ต้องคำนวณตัวคั่น:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // การปิดจะยืมบริบทเพื่อสร้างรายการ
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// ทำการปิดและสร้างตัววนซ้ำซึ่งเรียกการปิดนั้นในแต่ละองค์ประกอบ
    ///
    /// `map()` แปลงตัววนซ้ำหนึ่งตัวเป็นอีกตัวหนึ่งโดยใช้อาร์กิวเมนต์:
    /// สิ่งที่ใช้ [`FnMut`] สร้างตัววนซ้ำใหม่ซึ่งเรียกสิ่งนี้ว่าการปิดในแต่ละองค์ประกอบของตัววนซ้ำดั้งเดิม
    ///
    /// หากคุณเก่งในการคิดเป็นประเภทต่างๆคุณสามารถนึกถึง `map()` ได้ดังนี้:
    /// หากคุณมีตัววนซ้ำที่ให้องค์ประกอบของ `A` บางประเภทและคุณต้องการตัววนซ้ำของ `B` ประเภทอื่นคุณสามารถใช้ `map()` ผ่านการปิดที่ใช้ `A` และส่งคืน `B`
    ///
    ///
    /// `map()` มีแนวคิดคล้ายกับลูป [`for`] อย่างไรก็ตามเนื่องจาก `map()` ขี้เกียจจึงควรใช้เมื่อคุณทำงานกับตัวทำซ้ำอื่น ๆ อยู่แล้ว
    /// หากคุณกำลังเล่นวนซ้ำเพื่อหาผลข้างเคียงก็ถือว่าเป็นสำนวนที่ใช้ [`for`] มากกว่า `map()`
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// หากคุณกำลังทำผลข้างเคียงบางอย่างให้เลือก [`for`] ถึง `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // อย่าทำสิ่งนี้:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // มันจะไม่ทำงานด้วยซ้ำเพราะขี้เกียจ Rust จะเตือนคุณเกี่ยวกับเรื่องนี้
    ///
    /// // ให้ใช้สำหรับ:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// เรียกการปิดในแต่ละองค์ประกอบของตัววนซ้ำ
    ///
    /// สิ่งนี้เทียบเท่ากับการใช้ลูป [`for`] บนตัววนซ้ำแม้ว่า `break` และ `continue` จะไม่สามารถทำได้จากการปิด
    /// โดยทั่วไปแล้วการใช้ลูป `for` เป็นสำนวนมากกว่า แต่ `for_each` อาจอ่านได้ชัดเจนกว่าเมื่อประมวลผลรายการที่ส่วนท้ายของโซ่วนซ้ำที่ยาวขึ้น
    ///
    /// ในบางกรณี `for_each` อาจเร็วกว่าลูปเนื่องจากจะใช้การวนซ้ำภายในกับอะแดปเตอร์เช่น `Chain`
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// สำหรับตัวอย่างเล็ก ๆ เช่นนี้ลูป `for` อาจจะสะอาดกว่า แต่ `for_each` อาจดีกว่าที่จะคงรูปแบบการทำงานไว้ด้วยตัวทำซ้ำที่ยาวกว่า:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// สร้างตัววนซ้ำซึ่งใช้การปิดเพื่อพิจารณาว่าควรให้องค์ประกอบหรือไม่
    ///
    /// ระบุองค์ประกอบการปิดจะต้องส่งคืน `true` หรือ `false` ตัววนซ้ำที่ส่งคืนจะให้เฉพาะองค์ประกอบที่การปิดคืนค่าเป็นจริง
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// เนื่องจากการปิดที่ส่งผ่านไปยัง `filter()` ต้องใช้การอ้างอิงและผู้ทำซ้ำหลายคนวนซ้ำในการอ้างอิงสิ่งนี้นำไปสู่สถานการณ์ที่อาจสับสนซึ่งประเภทของการปิดเป็นการอ้างอิงสองครั้ง:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // ต้องการสอง * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// เป็นเรื่องปกติที่จะใช้การทำลายโครงสร้างกับอาร์กิวเมนต์เพื่อตัดสิ่งใดสิ่งหนึ่งออกไป:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // ทั้ง&และ *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// หรือทั้งคู่:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // &s สองตัว
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ของเลเยอร์เหล่านี้
    ///
    /// โปรดทราบว่า `iter.filter(f).next()` เทียบเท่ากับ `iter.find(f)`
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// สร้างตัววนซ้ำที่ทั้งตัวกรองและแผนที่
    ///
    /// ตัววนซ้ำที่ส่งคืนจะให้เฉพาะ "ค่า" ซึ่งการปิดที่ให้มาจะส่งกลับ `Some(value)`
    ///
    /// `filter_map` สามารถใช้เพื่อทำให้โซ่ [`filter`] และ [`map`] มีความกระชับมากขึ้น
    /// ตัวอย่างด้านล่างแสดงให้เห็นว่า `map().filter().map()` สามารถย่อให้สั้นลงเป็นการเรียกครั้งเดียวไปยัง `filter_map` ได้อย่างไร
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// นี่คือตัวอย่างเดียวกัน แต่สำหรับ [`filter`] และ [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// สร้างตัววนซ้ำซึ่งให้การนับการวนซ้ำในปัจจุบันรวมทั้งค่าถัดไป
    ///
    /// ตัววนซ้ำส่งคืนค่าคู่ `(i, val)` โดยที่ `i` เป็นดัชนีปัจจุบันของการวนซ้ำและ `val` คือค่าที่ส่งคืนโดยตัววนซ้ำ
    ///
    ///
    /// `enumerate()` นับเป็น [`usize`]
    /// หากคุณต้องการนับด้วยจำนวนเต็มขนาดอื่นฟังก์ชัน [`zip`] จะมีฟังก์ชันการทำงานที่คล้ายคลึงกัน
    ///
    /// # พฤติกรรมล้น
    ///
    /// วิธีนี้ไม่ได้ป้องกันการล้นดังนั้นการระบุองค์ประกอบมากกว่า [`usize::MAX`] อาจทำให้เกิดผลลัพธ์ที่ไม่ถูกต้องหรือ panics
    /// หากเปิดใช้งานการยืนยันการดีบักรับรอง panic
    ///
    /// # Panics
    ///
    /// ตัววนซ้ำที่ส่งคืนอาจ panic หากดัชนีที่จะส่งคืนจะล้น [`usize`]
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// สร้างตัววนซ้ำซึ่งสามารถใช้ [`peek`] เพื่อดูองค์ประกอบถัดไปของตัววนซ้ำได้โดยไม่ต้องใช้มัน
    ///
    /// เพิ่มวิธี [`peek`] ให้กับตัววนซ้ำดูเอกสารประกอบสำหรับข้อมูลเพิ่มเติม
    ///
    /// โปรดทราบว่าตัววนซ้ำพื้นฐานยังคงเป็นขั้นสูงเมื่อ [`peek`] ถูกเรียกเป็นครั้งแรก: ในการดึงข้อมูลองค์ประกอบถัดไป [`next`] จะถูกเรียกบนตัวทำซ้ำที่อยู่เบื้องหลังดังนั้นผลข้างเคียงใด ๆ (เช่น
    ///
    /// นอกเหนือจากการดึงค่าถัดไป) ของวิธี [`next`] จะเกิดขึ้น
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ให้เราเห็นใน future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // เราสามารถ peek() ได้หลายครั้งตัววนซ้ำจะไม่เลื่อนไปข้างหน้า
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // หลังจากตัววนซ้ำเสร็จแล้ว peek() ก็เช่นกัน
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// สร้างตัววนซ้ำที่องค์ประกอบ [`skip`] ตามเพรดิเคต
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` ใช้การปิดเป็นอาร์กิวเมนต์มันจะเรียกการปิดนี้ในแต่ละองค์ประกอบของตัววนซ้ำและละเว้นองค์ประกอบจนกว่าจะส่งคืน `false`
    ///
    /// หลังจากส่งคืน `false` งาน `skip_while()`'s จะสิ้นสุดลงและองค์ประกอบที่เหลือจะได้รับ
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// เนื่องจากการปิดที่ส่งผ่านไปยัง `skip_while()` ต้องใช้การอ้างอิงและผู้ทำซ้ำหลายคนวนซ้ำการอ้างอิงจึงทำให้เกิดสถานการณ์ที่อาจสับสนโดยประเภทของอาร์กิวเมนต์การปิดเป็นการอ้างอิงสองครั้ง:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // ต้องการสอง * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// การหยุดหลังจาก `false` เริ่มต้น:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // แม้ว่าสิ่งนี้จะเป็นเท็จเนื่องจากเราได้เท็จแล้ว skip_while() จึงไม่ได้ใช้อีกต่อไป
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// สร้างตัววนซ้ำที่ให้องค์ประกอบตามเพรดิเคต
    ///
    /// `take_while()` ใช้การปิดเป็นอาร์กิวเมนต์มันจะเรียกสิ่งนี้ว่าการปิดในแต่ละองค์ประกอบของตัววนซ้ำและองค์ประกอบที่ให้ผลตอบแทนในขณะที่ส่งคืนค่า `true`
    ///
    /// หลังจากส่งคืน `false` งาน `take_while()`'s จะสิ้นสุดลงและองค์ประกอบที่เหลือจะถูกละเว้น
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// เนื่องจากการปิดที่ส่งผ่านไปยัง `take_while()` ต้องใช้การอ้างอิงและผู้ทำซ้ำหลายคนวนซ้ำในการอ้างอิงสิ่งนี้นำไปสู่สถานการณ์ที่อาจสับสนซึ่งประเภทของการปิดเป็นการอ้างอิงสองครั้ง:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // ต้องการสอง * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// การหยุดหลังจาก `false` เริ่มต้น:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // เรามีองค์ประกอบที่น้อยกว่าศูนย์มากขึ้น แต่เนื่องจากเรามีเท็จอยู่แล้วจึงไม่ได้ใช้ take_while() อีกต่อไป
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// เนื่องจาก `take_while()` จำเป็นต้องดูที่ค่าเพื่อดูว่าควรรวมหรือไม่การใช้ตัวทำซ้ำจะเห็นว่าถูกลบออก:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` ไม่ได้อยู่ที่นั่นอีกต่อไปแล้วเนื่องจากถูกใช้เพื่อดูว่าการวนซ้ำควรหยุดลงหรือไม่ แต่ไม่ได้ใส่กลับเข้าไปในตัววนซ้ำ
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// สร้างตัววนซ้ำที่ให้ทั้งสององค์ประกอบตามเพรดิเคตและแมป
    ///
    /// `map_while()` ใช้การปิดเป็นอาร์กิวเมนต์
    /// มันจะเรียกสิ่งนี้ว่าการปิดในแต่ละองค์ประกอบของตัววนซ้ำและองค์ประกอบที่ให้ผลตอบแทนในขณะที่ส่งคืนค่า [`Some(_)`][`Some`]
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// นี่คือตัวอย่างเดียวกัน แต่สำหรับ [`take_while`] และ [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// การหยุดหลังจาก [`None`] เริ่มต้น:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // เรามีองค์ประกอบมากกว่าที่สามารถใส่ใน u32 (4, 5) แต่ `map_while` ส่งคืน `None` สำหรับ `-3` (เนื่องจาก `predicate` ส่งคืน `None`) และ `collect` หยุดที่ `None` แรกที่พบ
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// เนื่องจาก `map_while()` จำเป็นต้องดูที่ค่าเพื่อดูว่าควรรวมหรือไม่การใช้ตัวทำซ้ำจะเห็นว่าถูกลบออก:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` ไม่ได้อยู่ที่นั่นอีกต่อไปแล้วเนื่องจากถูกใช้เพื่อดูว่าการวนซ้ำควรหยุดลงหรือไม่ แต่ไม่ได้ใส่กลับเข้าไปในตัววนซ้ำ
    ///
    /// โปรดทราบว่าตัววนซ้ำนี้แตกต่างจาก [`take_while`] คือ **ไม่** ผสม
    /// นอกจากนี้ยังไม่ได้ระบุว่าตัววนซ้ำนี้ส่งคืนอะไรหลังจากส่งคืน [`None`] แรก
    /// หากคุณต้องการตัววนซ้ำแบบผสมให้ใช้ [`fuse`]
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// สร้างตัววนซ้ำที่ข้ามองค์ประกอบ `n` แรก
    ///
    /// หลังจากกินหมดแล้วองค์ประกอบที่เหลือจะได้รับ
    /// แทนที่จะแทนที่วิธีนี้โดยตรงให้แทนที่วิธีการ `nth`
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// สร้างตัววนซ้ำที่ให้องค์ประกอบ `n` แรก
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` มักใช้กับตัววนซ้ำแบบไม่มีที่สิ้นสุดเพื่อให้ จำกัด :
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// หากมีองค์ประกอบน้อยกว่า `n` `take` จะ จำกัด ตัวเองให้มีขนาดของตัววนซ้ำพื้นฐาน:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// อะแด็ปเตอร์ตัววนซ้ำที่คล้ายกับ [`fold`] ที่เก็บสถานะภายในและสร้างตัวทำซ้ำใหม่
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` รับสองอาร์กิวเมนต์: ค่าเริ่มต้นซึ่งเมล็ดสถานะภายในและการปิดด้วยสองอาร์กิวเมนต์โดยครั้งแรกเป็นการอ้างอิงที่ไม่แน่นอนไปยังสถานะภายในและองค์ประกอบที่สองเป็นตัววนซ้ำ
    ///
    /// การปิดสามารถกำหนดให้กับสถานะภายในเพื่อแบ่งปันสถานะระหว่างการทำซ้ำ
    ///
    /// ในการทำซ้ำการปิดจะถูกนำไปใช้กับแต่ละองค์ประกอบของตัววนซ้ำและค่าผลตอบแทนจากการปิด [`Option`] จะได้รับจากตัววนซ้ำ
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // การวนซ้ำแต่ละครั้งเราจะคูณสถานะด้วยองค์ประกอบ
    ///     *state = *state * x;
    ///
    ///     // จากนั้นเราจะให้การปฏิเสธของรัฐ
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// สร้างตัววนซ้ำที่ทำงานเหมือนแผนที่ แต่แบนโครงสร้างที่ซ้อนกัน
    ///
    /// อะแด็ปเตอร์ [`map`] มีประโยชน์มาก แต่เมื่ออาร์กิวเมนต์การปิดสร้างค่าเท่านั้น
    /// หากสร้างตัววนซ้ำแทนแสดงว่ามีการกำหนดทิศทางเพิ่มเติม
    /// `flat_map()` จะลบเลเยอร์พิเศษนี้ออกไปเอง
    ///
    /// คุณสามารถคิดว่า `flat_map(f)` เทียบเท่าความหมายของ [`map`] ping แล้ว [`แบน`] ing เช่นเดียวกับใน `map(f).flatten()`
    ///
    /// อีกวิธีหนึ่งในการคิดเกี่ยวกับ `flat_map()`: การปิดของ [`map`] จะคืนค่าหนึ่งรายการสำหรับแต่ละองค์ประกอบและการปิด `flat_map()`'s จะส่งคืนตัววนซ้ำสำหรับแต่ละองค์ประกอบ
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ส่งคืนตัวทำซ้ำ
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// สร้างตัววนซ้ำที่แบนโครงสร้างที่ซ้อนกัน
    ///
    /// สิ่งนี้มีประโยชน์เมื่อคุณมีตัววนซ้ำของตัวทำซ้ำหรือตัววนซ้ำของสิ่งต่างๆที่สามารถเปลี่ยนเป็นตัวทำซ้ำได้และคุณต้องการลบการกำหนดทิศทางหนึ่งระดับ
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// การทำแผนที่แล้วแบน:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ส่งคืนตัวทำซ้ำ
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// นอกจากนี้คุณยังสามารถเขียนสิ่งนี้ใหม่ในรูปแบบของ [`flat_map()`] ซึ่งเป็นที่นิยมในกรณีนี้เนื่องจากมันบ่งบอกเจตนาได้ชัดเจนกว่า:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ส่งคืนตัวทำซ้ำ
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// การทำให้แบนจะลบการซ้อนทีละระดับเท่านั้น:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// ที่นี่เราจะเห็นว่า `flatten()` ไม่ทำการแบน "deep"
    /// แต่จะมีการลบเพียงระดับเดียวเท่านั้นนั่นคือถ้าคุณ `flatten()` เป็นอาร์เรย์สามมิติผลลัพธ์จะเป็นสองมิติไม่ใช่มิติเดียว
    /// เพื่อให้ได้โครงสร้างมิติเดียวคุณต้อง `flatten()` อีกครั้ง
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// สร้างตัววนซ้ำซึ่งสิ้นสุดหลังจาก [`None`] แรก
    ///
    /// หลังจากตัววนซ้ำส่งคืน [`None`] การเรียกใช้ future อาจให้ผลลัพธ์ [`Some(T)`] อีกครั้งหรือไม่
    /// `fuse()` ปรับตัววนซ้ำเพื่อให้แน่ใจว่าหลังจากกำหนด [`None`] แล้วจะส่งคืน [`None`] ตลอดไป
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// // ตัววนซ้ำซึ่งสลับระหว่างบางตัวและไม่มี
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // ถ้ามันเป็น Some(i32) อื่น ๆ ก็ไม่มี
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // เราสามารถเห็นตัววนซ้ำของเราไปมาได้
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // อย่างไรก็ตามเมื่อเราหลอมรวมเข้าด้วยกัน ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // มันจะส่งคืน `None` เสมอหลังจากครั้งแรก
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// ทำบางสิ่งกับแต่ละองค์ประกอบของตัววนซ้ำโดยส่งผ่านค่าไป
    ///
    /// เมื่อใช้ตัวทำซ้ำคุณมักจะโยงหลายตัวเข้าด้วยกัน
    /// ในขณะที่ทำงานกับโค้ดดังกล่าวคุณอาจต้องการตรวจสอบว่าเกิดอะไรขึ้นกับส่วนต่างๆในท่อโดยใส่สายเรียกเข้า `inspect()`
    ///
    /// เป็นเรื่องปกติที่ `inspect()` จะใช้เป็นเครื่องมือดีบั๊กมากกว่าที่จะมีอยู่ในโค้ดสุดท้ายของคุณ แต่แอปพลิเคชันอาจพบว่ามีประโยชน์ในบางสถานการณ์เมื่อจำเป็นต้องบันทึกข้อผิดพลาดก่อนที่จะถูกทิ้ง
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // ลำดับตัววนซ้ำนี้มีความซับซ้อน
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // มาเพิ่มการโทร inspect() เพื่อตรวจสอบสิ่งที่เกิดขึ้น
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// สิ่งนี้จะพิมพ์:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// บันทึกข้อผิดพลาดก่อนทิ้ง:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// สิ่งนี้จะพิมพ์:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// ยืมตัววนซ้ำแทนที่จะใช้มัน
    ///
    /// สิ่งนี้มีประโยชน์ในการอนุญาตให้ใช้อะแด็ปเตอร์ตัววนซ้ำในขณะที่ยังคงรักษาความเป็นเจ้าของตัววนซ้ำเดิม
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // ถ้าเราลองใช้ iter อีกครั้งมันจะใช้ไม่ได้
    /// // บรรทัดต่อไปนี้ให้ "error: use of moving value: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // ลองอีกครั้ง
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // เราเพิ่ม .by_ref() แทน
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // ตอนนี้ก็โอเคแล้ว:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// แปลงตัววนซ้ำเป็นคอลเลกชัน
    ///
    /// `collect()` สามารถนำไปทำอะไรก็ได้และเปลี่ยนเป็นคอลเล็กชันที่เกี่ยวข้อง
    /// นี่เป็นวิธีการหนึ่งที่มีประสิทธิภาพมากกว่าในไลบรารีมาตรฐานซึ่งใช้ในบริบทต่างๆ
    ///
    /// รูปแบบพื้นฐานที่สุดที่ `collect()` ใช้คือการเปลี่ยนคอลเล็กชันหนึ่งให้กลายเป็นอีกคอลเล็กชันอื่น
    /// คุณรับคอลเลกชั่นเรียก [`iter`] บนนั้นทำการแปลงร่างแล้ว `collect()` ในตอนท้าย
    ///
    /// `collect()` ยังสามารถสร้างอินสแตนซ์ประเภทที่ไม่ใช่คอลเลกชันทั่วไป
    /// ตัวอย่างเช่น [`String`] สามารถสร้างจาก ["char`] s และตัววนซ้ำของรายการ [`Result<T, E>`][`Result`] สามารถรวบรวมเป็น `Result<Collection<T>, E>` ได้
    ///
    /// ดูตัวอย่างด้านล่างสำหรับข้อมูลเพิ่มเติม
    ///
    /// เนื่องจาก `collect()` เป็นแบบทั่วไปจึงอาจทำให้เกิดปัญหากับการอนุมานประเภทได้
    /// ดังนั้น `collect()` จึงเป็นหนึ่งในไม่กี่ครั้งที่คุณจะเห็นไวยากรณ์ที่เรียกกันติดปากว่า 'turbofish': `::<>`.
    /// สิ่งนี้ช่วยให้อัลกอริทึมการอนุมานเข้าใจโดยเฉพาะว่าคุณต้องการรวบรวมคอลเล็กชันใด
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// โปรดทราบว่าเราต้องการ `: Vec<i32>` ทางด้านซ้ายมือนี่เป็นเพราะเราสามารถรวบรวมตัวอย่างเช่น [`VecDeque<T>`] แทน:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// การใช้ 'turbofish' แทนการใส่คำอธิบายประกอบ `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// เนื่องจาก `collect()` ให้ความสำคัญกับสิ่งที่คุณรวบรวมไว้เท่านั้นคุณยังสามารถใช้คำใบ้บางส่วน `_` กับ turbofish ได้:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// ใช้ `collect()` เพื่อสร้าง [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// หากคุณมีรายการ [`Result<T, E>`][` ผลลัพธ์ '] คุณสามารถใช้ `collect()` เพื่อดูว่ามีข้อใดล้มเหลวหรือไม่:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ทำให้เรามีข้อผิดพลาดแรก
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ให้รายการคำตอบแก่เรา
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// ใช้ตัววนซ้ำสร้างสองคอลเลกชันจากมัน
    ///
    /// เพรดิเคตที่ส่งไปยัง `partition()` สามารถคืนค่า `true` หรือ `false`
    /// `partition()` ส่งคืนคู่องค์ประกอบทั้งหมดที่ส่งคืน `true` และองค์ประกอบทั้งหมดที่ส่งคืน `false`
    ///
    ///
    /// ดู [`is_partitioned()`] และ [`partition_in_place()`] ด้วย
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// เรียงลำดับองค์ประกอบของตัววนซ้ำนี้ *ในตำแหน่ง* ตามเพรดิเคตที่กำหนดเพื่อให้ทุกคนที่ส่งคืน `true` นำหน้าทั้งหมดที่ส่งคืน `false`
    ///
    /// ส่งคืนจำนวนองค์ประกอบ `true` ที่พบ
    ///
    /// ไม่มีการรักษาลำดับสัมพัทธ์ของรายการที่แบ่งพาร์ติชัน
    ///
    /// ดู [`is_partitioned()`] และ [`partition()`] ด้วย
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // แบ่งพาร์ติชั่นระหว่างคู่และราคาต่อรอง
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: เราควรกังวลเกี่ยวกับจำนวนที่มากเกินไปหรือไม่?วิธีเดียวที่จะมีมากกว่า
        // `usize::MAX` การอ้างอิงที่ไม่แน่นอนอยู่กับ ZST ซึ่งไม่มีประโยชน์ต่อการแบ่งพาร์ติชัน ...

        // ฟังก์ชัน "factory" การปิดเหล่านี้มีอยู่เพื่อหลีกเลี่ยงความธรรมดาใน `Self`

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // ค้นหา `false` แรกซ้ำแล้วสลับกับ `true` สุดท้าย
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// ตรวจสอบว่าอิลิเมนต์ของตัววนซ้ำนี้ถูกแบ่งพาร์ติชันตามเพรดิเคตที่กำหนดหรือไม่เพื่อให้สิ่งที่ส่งคืน `true` นำหน้าทั้งหมดที่ส่งคืน `false`
    ///
    ///
    /// ดู [`partition()`] และ [`partition_in_place()`] ด้วย
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // รายการทั้งหมดทดสอบ `true` หรือข้อแรกหยุดที่ `false` และเราตรวจสอบว่าไม่มีรายการ `true` อีกแล้วหลังจากนั้น
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// เมธอดตัววนซ้ำที่ใช้ฟังก์ชันตราบเท่าที่ส่งคืนสำเร็จโดยสร้างค่าสุดท้ายเพียงค่าเดียว
    ///
    /// `try_fold()` รับสองอาร์กิวเมนต์: ค่าเริ่มต้นและปิดด้วยสองอาร์กิวเมนต์: 'accumulator' และองค์ประกอบ
    /// การปิดจะส่งคืนสำเร็จโดยมีค่าที่ตัวสะสมควรมีสำหรับการทำซ้ำครั้งต่อไปหรือส่งกลับความล้มเหลวพร้อมกับค่าความผิดพลาดที่แพร่กระจายกลับไปยังผู้เรียกทันที (short-circuiting)
    ///
    ///
    /// ค่าเริ่มต้นคือค่าที่ตัวสะสมจะมีในการโทรครั้งแรกหากใช้การปิดสำเร็จกับทุกองค์ประกอบของตัววนซ้ำ `try_fold()` จะส่งคืนตัวสะสมสุดท้ายเป็นความสำเร็จ
    ///
    /// การพับมีประโยชน์ทุกครั้งที่คุณมีของสะสมและต้องการสร้างมูลค่าเดียวจากมัน
    ///
    /// # หมายเหตุถึงผู้ใช้งาน
    ///
    /// วิธีการ (forward) อื่น ๆ หลายวิธีมีการใช้งานเริ่มต้นในแง่ของวิธีนี้ดังนั้นลองใช้วิธีนี้อย่างชัดเจนหากสามารถทำสิ่งที่ดีกว่าการใช้งานลูป `for` เริ่มต้นได้
    ///
    /// โดยเฉพาะอย่างยิ่งให้ลองเรียก `try_fold()` นี้กับชิ้นส่วนภายในที่ประกอบตัววนซ้ำนี้
    /// หากจำเป็นต้องมีการโทรหลายครั้งตัวดำเนินการ `?` อาจสะดวกในการผูกโยงค่าตัวสะสมไปพร้อมกัน แต่ระวังค่าคงที่ใด ๆ ที่ต้องยึดถือก่อนที่จะกลับมาก่อนเวลาเหล่านั้น
    /// นี่เป็นวิธี `&mut self` ดังนั้นการทำซ้ำจะต้องดำเนินการต่อหลังจากกดปุ่มข้อผิดพลาดที่นี่
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ผลรวมที่ตรวจสอบขององค์ประกอบทั้งหมดของอาร์เรย์
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // ผลรวมนี้จะล้นเมื่อเพิ่มองค์ประกอบ 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // เนื่องจากมันลัดวงจรองค์ประกอบที่เหลือจึงยังคงใช้งานได้ผ่านตัววนซ้ำ
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// วิธีการวนซ้ำที่ใช้ฟังก์ชันที่ผิดพลาดกับแต่ละรายการในตัววนซ้ำโดยหยุดที่ข้อผิดพลาดแรกและส่งคืนข้อผิดพลาดนั้น
    ///
    ///
    /// นอกจากนี้ยังสามารถคิดได้ว่าเป็นรูปแบบที่ผิดพลาดของ [`for_each()`] หรือ [`try_fold()`] เวอร์ชันไร้สัญชาติ
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // มันลัดวงจรดังนั้นรายการที่เหลือจึงยังคงอยู่ในตัววนซ้ำ:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// พับทุกองค์ประกอบลงในตัวสะสมโดยใช้การดำเนินการส่งคืนผลลัพธ์สุดท้าย
    ///
    /// `fold()` รับสองอาร์กิวเมนต์: ค่าเริ่มต้นและปิดด้วยสองอาร์กิวเมนต์: 'accumulator' และองค์ประกอบ
    /// การปิดจะส่งคืนค่าที่ตัวสะสมควรมีสำหรับการทำซ้ำครั้งต่อไป
    ///
    /// ค่าเริ่มต้นคือค่าที่ตัวสะสมจะมีในการโทรครั้งแรก
    ///
    /// หลังจากใช้การปิดนี้กับทุกองค์ประกอบของตัววนซ้ำแล้ว `fold()` จะส่งคืนตัวสะสม
    ///
    /// การดำเนินการนี้บางครั้งเรียกว่า 'reduce' หรือ 'inject'
    ///
    /// การพับมีประโยชน์ทุกครั้งที่คุณมีของสะสมและต้องการสร้างมูลค่าเดียวจากมัน
    ///
    /// Note: `fold()` และวิธีการที่คล้ายคลึงกันที่สำรวจตัววนซ้ำทั้งหมดอาจไม่ยุติสำหรับตัววนซ้ำที่ไม่มีที่สิ้นสุดแม้ใน traits ซึ่งผลลัพธ์สามารถกำหนดได้ในเวลา จำกัด
    ///
    /// Note: [`reduce()`] สามารถใช้เพื่อใช้องค์ประกอบแรกเป็นค่าเริ่มต้นได้หากประเภทตัวสะสมและประเภทไอเท็มเหมือนกัน
    ///
    /// # หมายเหตุถึงผู้ใช้งาน
    ///
    /// วิธีการ (forward) อื่น ๆ หลายวิธีมีการใช้งานเริ่มต้นในแง่ของวิธีนี้ดังนั้นลองใช้วิธีนี้อย่างชัดเจนหากสามารถทำสิ่งที่ดีกว่าการใช้งานลูป `for` เริ่มต้นได้
    ///
    ///
    /// โดยเฉพาะอย่างยิ่งให้ลองเรียก `fold()` นี้กับชิ้นส่วนภายในที่ประกอบตัววนซ้ำนี้
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ผลรวมขององค์ประกอบทั้งหมดของอาร์เรย์
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// มาดูแต่ละขั้นตอนของการทำซ้ำที่นี่:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// ดังนั้นผลลัพธ์สุดท้ายของเรา `6`.
    ///
    /// เป็นเรื่องปกติสำหรับผู้ที่ไม่ได้ใช้ตัวทำซ้ำบ่อยนักในการใช้ลูป `for` กับรายการสิ่งต่างๆเพื่อสร้างผลลัพธ์สิ่งเหล่านี้สามารถเปลี่ยนเป็น `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // สำหรับห่วง:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // เหมือนกัน
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// ลดองค์ประกอบให้เหลือเพียงองค์ประกอบเดียวโดยใช้การดำเนินการลดซ้ำ ๆ
    ///
    /// ถ้าตัววนซ้ำว่างเปล่าให้ส่งกลับ [`None`] มิฉะนั้นจะส่งคืนผลลัพธ์ของการลด
    ///
    /// สำหรับตัววนซ้ำที่มีอย่างน้อยหนึ่งองค์ประกอบค่านี้จะเหมือนกับ [`fold()`] ที่มีองค์ประกอบแรกของตัววนซ้ำเป็นค่าเริ่มต้นโดยจะพับทุกองค์ประกอบที่ตามมาลงในนั้น
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// ค้นหาค่าสูงสุด:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// ทดสอบว่าทุกองค์ประกอบของตัววนซ้ำตรงกับเพรดิเคตหรือไม่
    ///
    /// `all()` รับการปิดที่ส่งคืน `true` หรือ `false` มันใช้การปิดนี้กับแต่ละองค์ประกอบของตัววนซ้ำและถ้าพวกมันส่งคืน `true` ทั้งหมด `all()` ก็เช่นกัน
    /// หากมีรายการใดส่งคืน `false` จะส่งคืน `false`
    ///
    /// `all()` กำลังลัดวงจรกล่าวอีกนัยหนึ่งก็คือมันจะหยุดประมวลผลทันทีที่พบ `false` เนื่องจากไม่ว่าจะเกิดอะไรขึ้นผลลัพธ์ก็จะเป็น `false` เช่นกัน
    ///
    ///
    /// ตัววนซ้ำว่างจะส่งคืน `true`
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// การหยุดที่ `false` แรก:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // เรายังสามารถใช้ `iter` ได้เนื่องจากมีองค์ประกอบมากขึ้น
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// ทดสอบว่าองค์ประกอบใดของตัววนซ้ำตรงกับเพรดิเคตหรือไม่
    ///
    /// `any()` รับการปิดที่ส่งคืน `true` หรือ `false` ใช้การปิดนี้กับแต่ละองค์ประกอบของตัววนซ้ำและหากมีสิ่งใดส่งคืน `true` ดังนั้น `any()` ก็เช่นกัน
    /// หากพวกเขาส่งคืน `false` ทั้งหมดจะส่งคืน `false`
    ///
    /// `any()` กำลังลัดวงจรกล่าวอีกนัยหนึ่งก็คือมันจะหยุดประมวลผลทันทีที่พบ `true` เนื่องจากไม่ว่าจะเกิดอะไรขึ้นผลลัพธ์ก็จะเป็น `true` เช่นกัน
    ///
    ///
    /// ตัววนซ้ำว่างจะส่งคืน `false`
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// การหยุดที่ `true` แรก:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // เรายังสามารถใช้ `iter` ได้เนื่องจากมีองค์ประกอบมากขึ้น
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// ค้นหาองค์ประกอบของตัววนซ้ำที่ตรงตามเพรดิเคต
    ///
    /// `find()` รับการปิดที่ส่งคืน `true` หรือ `false`
    /// ใช้การปิดนี้กับแต่ละองค์ประกอบของตัววนซ้ำและหากมีสิ่งใดส่งคืน `true` ดังนั้น `find()` จะส่งคืน [`Some(element)`]
    /// หากพวกเขาส่งคืน `false` ทั้งหมดจะส่งคืน [`None`]
    ///
    /// `find()` กำลังลัดวงจรกล่าวอีกนัยหนึ่งก็คือจะหยุดประมวลผลทันทีที่การปิดคืนค่า `true`
    ///
    /// เนื่องจาก `find()` ใช้การอ้างอิงและผู้ทำซ้ำหลายคนวนซ้ำการอ้างอิงสิ่งนี้จึงนำไปสู่สถานการณ์ที่อาจสับสนซึ่งอาร์กิวเมนต์เป็นการอ้างอิงสองครั้ง
    ///
    /// คุณสามารถดูเอฟเฟกต์นี้ได้ในตัวอย่างด้านล่างด้วย `&&x`
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// การหยุดที่ `true` แรก:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // เรายังสามารถใช้ `iter` ได้เนื่องจากมีองค์ประกอบมากขึ้น
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// โปรดทราบว่า `iter.find(f)` เทียบเท่ากับ `iter.filter(f).next()`
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// นำฟังก์ชันไปใช้กับอิลิเมนต์ของตัววนซ้ำและส่งกลับผลลัพธ์แรกที่ไม่ใช่ไม่มี
    ///
    ///
    /// `iter.find_map(f)` เทียบเท่ากับ `iter.filter_map(f).next()`
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// ใช้ฟังก์ชันกับอิลิเมนต์ของตัววนซ้ำและส่งคืนผลลัพธ์จริงแรกหรือข้อผิดพลาดแรก
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// ค้นหาองค์ประกอบในตัววนซ้ำโดยส่งคืนดัชนี
    ///
    /// `position()` รับการปิดที่ส่งคืน `true` หรือ `false`
    /// ใช้การปิดนี้กับแต่ละองค์ประกอบของตัววนซ้ำและหากหนึ่งในนั้นส่งคืน `true` ดังนั้น `position()` จะส่งคืน [`Some(index)`]
    /// หากทั้งหมดส่งคืน `false` จะส่งคืน [`None`]
    ///
    /// `position()` กำลังลัดวงจรกล่าวอีกนัยหนึ่งก็คือจะหยุดประมวลผลทันทีที่พบ `true`
    ///
    /// # พฤติกรรมล้น
    ///
    /// วิธีนี้ไม่ได้ป้องกันการล้นดังนั้นหากมีองค์ประกอบที่ไม่ตรงกันมากกว่า [`usize::MAX`] ก็อาจสร้างผลลัพธ์ที่ไม่ถูกต้องหรือ panics
    ///
    /// หากเปิดใช้งานการยืนยันการดีบักรับรอง panic
    ///
    /// # Panics
    ///
    /// ฟังก์ชันนี้อาจ panic หากตัววนซ้ำมีองค์ประกอบที่ไม่ตรงกันมากกว่า `usize::MAX`
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// การหยุดที่ `true` แรก:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // เรายังสามารถใช้ `iter` ได้เนื่องจากมีองค์ประกอบมากขึ้น
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // ดัชนีที่ส่งคืนขึ้นอยู่กับสถานะตัววนซ้ำ
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// ค้นหาองค์ประกอบในตัววนซ้ำจากด้านขวาโดยส่งคืนดัชนี
    ///
    /// `rposition()` รับการปิดที่ส่งคืน `true` หรือ `false`
    /// ใช้การปิดนี้กับแต่ละองค์ประกอบของตัววนซ้ำโดยเริ่มจากจุดสิ้นสุดและหากหนึ่งในนั้นส่งคืน `true` ดังนั้น `rposition()` จะส่งคืน [`Some(index)`]
    ///
    /// หากทั้งหมดส่งคืน `false` จะส่งคืน [`None`]
    ///
    /// `rposition()` กำลังลัดวงจรกล่าวอีกนัยหนึ่งก็คือจะหยุดประมวลผลทันทีที่พบ `true`
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// การหยุดที่ `true` แรก:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // เรายังสามารถใช้ `iter` ได้เนื่องจากมีองค์ประกอบมากขึ้น
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // ไม่จำเป็นต้องตรวจสอบมากเกินไปที่นี่เพราะ `ExactSizeIterator` หมายความว่าจำนวนองค์ประกอบที่พอดีกับ `usize`
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// ส่งคืนองค์ประกอบสูงสุดของตัววนซ้ำ
    ///
    /// หากองค์ประกอบหลายรายการมีค่าสูงสุดเท่ากันระบบจะส่งคืนองค์ประกอบสุดท้าย
    /// หากตัววนซ้ำว่างเปล่าระบบจะส่งคืน [`None`]
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// ส่งคืนองค์ประกอบขั้นต่ำของตัววนซ้ำ
    ///
    /// หากองค์ประกอบหลายอย่างมีค่าต่ำสุดเท่า ๆ กันระบบจะส่งคืนองค์ประกอบแรก
    /// หากตัววนซ้ำว่างเปล่าระบบจะส่งคืน [`None`]
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// ส่งคืนองค์ประกอบที่ให้ค่าสูงสุดจากฟังก์ชันที่ระบุ
    ///
    ///
    /// หากองค์ประกอบหลายรายการมีค่าสูงสุดเท่ากันระบบจะส่งคืนองค์ประกอบสุดท้าย
    /// หากตัววนซ้ำว่างเปล่าระบบจะส่งคืน [`None`]
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// ส่งคืนองค์ประกอบที่ให้ค่าสูงสุดตามฟังก์ชันเปรียบเทียบที่ระบุ
    ///
    ///
    /// หากองค์ประกอบหลายรายการมีค่าสูงสุดเท่ากันระบบจะส่งคืนองค์ประกอบสุดท้าย
    /// หากตัววนซ้ำว่างเปล่าระบบจะส่งคืน [`None`]
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// ส่งคืนองค์ประกอบที่ให้ค่าต่ำสุดจากฟังก์ชันที่ระบุ
    ///
    ///
    /// หากองค์ประกอบหลายอย่างมีค่าต่ำสุดเท่า ๆ กันระบบจะส่งคืนองค์ประกอบแรก
    /// หากตัววนซ้ำว่างเปล่าระบบจะส่งคืน [`None`]
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// ส่งคืนองค์ประกอบที่ให้ค่าต่ำสุดตามฟังก์ชันเปรียบเทียบที่ระบุ
    ///
    ///
    /// หากองค์ประกอบหลายอย่างมีค่าต่ำสุดเท่า ๆ กันระบบจะส่งคืนองค์ประกอบแรก
    /// หากตัววนซ้ำว่างเปล่าระบบจะส่งคืน [`None`]
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// กลับทิศทางของตัววนซ้ำ
    ///
    /// โดยปกติแล้วจะวนซ้ำจากซ้ายไปขวา
    /// หลังจากใช้ `rev()` ตัววนซ้ำจะวนซ้ำจากขวาไปซ้ายแทน
    ///
    /// สิ่งนี้จะเกิดขึ้นได้ก็ต่อเมื่อตัววนซ้ำมีจุดสิ้นสุดดังนั้น `rev()` จึงทำงานบน [`DoubleEndedIterator`] s เท่านั้น
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// แปลงตัววนซ้ำของคู่เป็นคู่ของคอนเทนเนอร์
    ///
    /// `unzip()` ใช้ตัววนซ้ำทั้งหมดของคู่โดยสร้างคอลเล็กชันสองคอลเลคชัน: หนึ่งจากองค์ประกอบด้านซ้ายของคู่และอีกหนึ่งจากองค์ประกอบด้านขวา
    ///
    ///
    /// ในบางแง่ฟังก์ชันนี้ตรงกันข้ามกับ [`zip`]
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// สร้างตัววนซ้ำซึ่งคัดลอกองค์ประกอบทั้งหมด
    ///
    /// สิ่งนี้มีประโยชน์เมื่อคุณมีตัววนซ้ำบน `&T` แต่คุณต้องมีตัววนซ้ำมากกว่า `T`
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // คัดลอกเหมือนกับ .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// สร้างตัววนซ้ำซึ่ง [`โคลน '] เป็นองค์ประกอบทั้งหมด
    ///
    /// สิ่งนี้มีประโยชน์เมื่อคุณมีตัววนซ้ำบน `&T` แต่คุณต้องมีตัววนซ้ำมากกว่า `T`
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // โคลนจะเหมือนกับ .map(|&x| x) สำหรับจำนวนเต็ม
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// ทำซ้ำตัววนซ้ำไม่รู้จบ
    ///
    /// แทนที่จะหยุดที่ [`None`] ตัววนซ้ำจะเริ่มต้นใหม่ตั้งแต่ต้นแทนหลังจากทำซ้ำอีกครั้งจะเริ่มที่จุดเริ่มต้นอีกครั้งและอีกครั้ง.
    /// และอีกครั้ง.
    /// Forever.
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// รวมองค์ประกอบของตัววนซ้ำ
    ///
    /// ใช้แต่ละองค์ประกอบรวมเข้าด้วยกันและส่งคืนผลลัพธ์
    ///
    /// ตัววนซ้ำว่างจะส่งคืนค่าเป็นศูนย์ของชนิด
    ///
    /// # Panics
    ///
    /// เมื่อเรียก `sum()` และกำลังส่งคืนชนิดจำนวนเต็มดั้งเดิมเมธอดนี้จะ panic หากการคำนวณล้นและการยืนยันการดีบักถูกเปิดใช้งาน
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// วนซ้ำบนตัววนซ้ำทั้งหมดคูณองค์ประกอบทั้งหมด
    ///
    /// ตัววนซ้ำว่างจะส่งคืนค่าหนึ่งของประเภท
    ///
    /// # Panics
    ///
    /// เมื่อเรียกใช้ `product()` และชนิดจำนวนเต็มดั้งเดิมจะถูกส่งกลับเมธอดจะ panic หากการคำนวณล้นและการยืนยันการดีบักถูกเปิดใช้งาน
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) เปรียบเทียบองค์ประกอบของ [`Iterator`] นี้กับองค์ประกอบอื่น
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) เปรียบเทียบองค์ประกอบของ [`Iterator`] นี้กับองค์ประกอบอื่นที่เกี่ยวข้องกับฟังก์ชันการเปรียบเทียบที่ระบุ
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) เปรียบเทียบองค์ประกอบของ [`Iterator`] นี้กับองค์ประกอบอื่น
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) เปรียบเทียบองค์ประกอบของ [`Iterator`] นี้กับองค์ประกอบอื่นที่เกี่ยวข้องกับฟังก์ชันการเปรียบเทียบที่ระบุ
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// พิจารณาว่าองค์ประกอบของ [`Iterator`] นี้เท่ากับองค์ประกอบอื่นหรือไม่
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// พิจารณาว่าองค์ประกอบของ [`Iterator`] นี้เท่ากับองค์ประกอบอื่นหรือไม่เมื่อเทียบกับฟังก์ชันความเท่าเทียมที่ระบุ
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// พิจารณาว่าองค์ประกอบของ [`Iterator`] นี้ไม่เท่ากันกับองค์ประกอบอื่นหรือไม่
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// กำหนดว่าองค์ประกอบของ [`Iterator`] นี้ [lexicographically](Ord#lexicographical-comparison) น้อยกว่าองค์ประกอบอื่นหรือไม่
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// พิจารณาว่าองค์ประกอบของ [`Iterator`] นี้ [lexicographically](Ord#lexicographical-comparison) น้อยกว่าหรือเท่ากับองค์ประกอบอื่นหรือไม่
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// พิจารณาว่าองค์ประกอบของ [`Iterator`] นี้มีค่า [lexicographically](Ord#lexicographical-comparison) มากกว่าองค์ประกอบอื่นหรือไม่
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// พิจารณาว่าองค์ประกอบของ [`Iterator`] นี้ [lexicographically](Ord#lexicographical-comparison) มากกว่าหรือเท่ากับองค์ประกอบอื่นหรือไม่
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// ตรวจสอบว่ามีการเรียงลำดับองค์ประกอบของตัววนซ้ำนี้หรือไม่
    ///
    /// นั่นคือสำหรับแต่ละองค์ประกอบ `a` และองค์ประกอบต่อไปนี้ `b` ต้องถือ `a <= b` ถ้าตัววนซ้ำให้ค่าเป็นศูนย์หรือองค์ประกอบเดียวจะส่งคืน `true`
    ///
    /// โปรดทราบว่าถ้า `Self::Item` เป็นเพียง `PartialOrd` แต่ไม่ใช่ `Ord` คำจำกัดความข้างต้นหมายความว่าฟังก์ชันนี้จะส่งคืนค่า `false` หากรายการใด ๆ ที่ต่อเนื่องกันสองรายการไม่สามารถเทียบเคียงกันได้
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// ตรวจสอบว่าองค์ประกอบของตัววนซ้ำนี้เรียงลำดับโดยใช้ฟังก์ชันตัวเปรียบเทียบที่กำหนดหรือไม่
    ///
    /// แทนที่จะใช้ `PartialOrd::partial_cmp` ฟังก์ชันนี้จะใช้ฟังก์ชัน `compare` ที่กำหนดเพื่อกำหนดลำดับของสององค์ประกอบ
    /// นอกเหนือจากนั้นเทียบเท่ากับ [`is_sorted`] ดูเอกสารประกอบสำหรับข้อมูลเพิ่มเติม
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// ตรวจสอบว่าองค์ประกอบของตัววนซ้ำนี้เรียงลำดับโดยใช้ฟังก์ชันการแยกคีย์ที่กำหนดหรือไม่
    ///
    /// แทนที่จะเปรียบเทียบองค์ประกอบของตัววนซ้ำโดยตรงฟังก์ชันนี้จะเปรียบเทียบคีย์ขององค์ประกอบตามที่กำหนดโดย `f`
    /// นอกเหนือจากนั้นเทียบเท่ากับ [`is_sorted`] ดูเอกสารประกอบสำหรับข้อมูลเพิ่มเติม
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// ดู [TrustedRandomAccess]
    // ชื่อที่ผิดปกติคือการหลีกเลี่ยงการชนกันของชื่อในวิธีการแก้ปัญหาโปรดดู #76479
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}