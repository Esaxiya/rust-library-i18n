/// ตัววนซ้ำที่รู้ความยาวที่แน่นอน
///
/// [`Iterator`] หลายคนไม่รู้ว่าจะวนซ้ำกี่ครั้ง แต่บางคนก็ทำ
/// หากผู้วนซ้ำรู้ว่าสามารถทำซ้ำได้กี่ครั้งการให้การเข้าถึงข้อมูลนั้นจะเป็นประโยชน์
/// ตัวอย่างเช่นหากคุณต้องการย้อนกลับการเริ่มต้นที่ดีคือการรู้ว่าจุดสิ้นสุดอยู่ที่ใด
///
/// เมื่อใช้ `ExactSizeIterator` คุณต้องใช้ [`Iterator`] ด้วย
/// เมื่อทำเช่นนั้นการใช้งาน [`Iterator::size_hint`]*ต้อง* ส่งคืนขนาดที่แน่นอนของตัววนซ้ำ
///
/// วิธี [`len`] มีการใช้งานเริ่มต้นดังนั้นคุณจึงไม่ควรนำไปใช้
/// อย่างไรก็ตามคุณอาจสามารถจัดเตรียมการใช้งานที่มีประสิทธิภาพมากกว่าค่าเริ่มต้นได้ดังนั้นการลบล้างในกรณีนี้จึงเหมาะสม
///
///
/// โปรดทราบว่า trait นี้เป็น trait ที่ปลอดภัยและด้วยเหตุนี้จึง *ไม่* และ *ไม่สามารถ* รับประกันได้ว่าความยาวที่ส่งคืนนั้นถูกต้อง
/// ซึ่งหมายความว่ารหัส `unsafe`**ต้องไม่** ขึ้นอยู่กับความถูกต้องของ [`Iterator::size_hint`]
/// [`TrustedLen`](super::marker::TrustedLen) trait ที่ไม่เสถียรและไม่ปลอดภัยให้การรับประกันเพิ่มเติมนี้
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// การใช้งานพื้นฐาน:
///
/// ```
/// // ช่วง จำกัด รู้ว่าจะวนซ้ำกี่ครั้ง
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// ใน [module-level docs] เราใช้ [`Iterator`] `Counter`.
/// มาใช้ `ExactSizeIterator` กันเถอะ:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // เราสามารถคำนวณจำนวนการทำซ้ำที่เหลือได้อย่างง่ายดาย
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // และตอนนี้เราสามารถใช้งานได้แล้ว!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// ส่งกลับค่าความยาวที่แน่นอนของตัววนซ้ำ
    ///
    /// การใช้งานช่วยให้มั่นใจได้ว่าตัววนซ้ำจะส่งคืนค่า `len()` มากกว่าค่า [`Some(T)`] เท่าเดิมก่อนที่จะส่งคืน [`None`]
    ///
    /// วิธีนี้มีการใช้งานเริ่มต้นดังนั้นคุณจึงไม่ควรนำไปใช้โดยตรง
    /// อย่างไรก็ตามหากคุณสามารถนำเสนอการใช้งานที่มีประสิทธิภาพมากขึ้นคุณสามารถทำได้
    /// ดูตัวอย่างเอกสาร [trait-level]
    ///
    /// ฟังก์ชันนี้มีการรับประกันความปลอดภัยเช่นเดียวกับฟังก์ชัน [`Iterator::size_hint`]
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// // ช่วง จำกัด รู้ว่าจะวนซ้ำกี่ครั้ง
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: การยืนยันนี้เป็นการป้องกันมากเกินไป แต่จะตรวจสอบค่าคงที่
        // การันตีโดย trait
        // ถ้า trait นี้เป็น rust-internal เราสามารถใช้ debug_assert !;assert_eq!จะตรวจสอบการใช้งานของผู้ใช้ Rust ทั้งหมดด้วย
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// ส่งคืน `true` หากตัววนซ้ำว่างเปล่า
    ///
    /// วิธีนี้มีการใช้งานเริ่มต้นโดยใช้ [`ExactSizeIterator::len()`] ดังนั้นคุณไม่จำเป็นต้องติดตั้งด้วยตัวเอง
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}