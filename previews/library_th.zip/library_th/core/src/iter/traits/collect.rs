/// การแปลงจาก [`Iterator`]
///
/// เมื่อใช้ `FromIterator` สำหรับประเภทคุณกำหนดวิธีสร้างจากตัววนซ้ำ
/// นี่เป็นเรื่องปกติสำหรับประเภทที่อธิบายถึงคอลเลกชันบางประเภท
///
/// [`FromIterator::from_iter()`] มักไม่ค่อยถูกเรียกอย่างชัดเจนและใช้แทนวิธี [`Iterator::collect()`]
///
/// ดูเอกสาร [`Iterator::collect()`]'s สำหรับตัวอย่างเพิ่มเติม
///
/// ดูสิ่งนี้ด้วย: [`IntoIterator`].
///
/// # Examples
///
/// การใช้งานพื้นฐาน:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// การใช้ [`Iterator::collect()`] เพื่อใช้ `FromIterator` โดยปริยาย:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// การติดตั้ง `FromIterator` สำหรับประเภทของคุณ:
///
/// ```
/// use std::iter::FromIterator;
///
/// // คอลเลกชันตัวอย่างนั่นเป็นเพียงกระดาษห่อหุ้ม Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // ลองมาดูวิธีการบางอย่างเพื่อที่เราจะได้สร้างขึ้นมาและเพิ่มสิ่งต่างๆเข้าไป
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // และเราจะใช้ FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // ตอนนี้เราสามารถสร้างตัวทำซ้ำใหม่ได้ ...
/// let iter = (0..5).into_iter();
///
/// // ... และสร้าง MyCollection จากมัน
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // สะสมผลงานด้วย!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// สร้างค่าจากตัววนซ้ำ
    ///
    /// ดู [module-level documentation] เพิ่มเติม
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// แปลงเป็น [`Iterator`]
///
/// เมื่อใช้ `IntoIterator` สำหรับประเภทคุณกำหนดวิธีที่จะแปลงเป็นตัววนซ้ำ
/// นี่เป็นเรื่องปกติสำหรับประเภทที่อธิบายถึงคอลเลกชันบางประเภท
///
/// ประโยชน์อย่างหนึ่งของการใช้ `IntoIterator` คือประเภทของคุณจะ [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator)
///
///
/// ดูสิ่งนี้ด้วย: [`FromIterator`].
///
/// # Examples
///
/// การใช้งานพื้นฐาน:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// การติดตั้ง `IntoIterator` สำหรับประเภทของคุณ:
///
/// ```
/// // คอลเลกชันตัวอย่างนั่นเป็นเพียงกระดาษห่อหุ้ม Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // ลองมาดูวิธีการบางอย่างเพื่อที่เราจะได้สร้างขึ้นมาและเพิ่มสิ่งต่างๆเข้าไป
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // และเราจะใช้ IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // ตอนนี้เราสามารถสร้างคอลเลกชันใหม่ ...
/// let mut c = MyCollection::new();
///
/// // ... เพิ่มบางอย่างลงไป ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... แล้วเปลี่ยนเป็น Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// เป็นเรื่องปกติที่จะใช้ `IntoIterator` เป็น trait bound สิ่งนี้ทำให้ประเภทคอลเลกชันอินพุตเปลี่ยนแปลงได้ตราบใดที่ยังคงเป็นตัวทำซ้ำ
/// ขอบเขตเพิ่มเติมสามารถระบุได้โดยการ จำกัด
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// ประเภทขององค์ประกอบที่ถูกทำซ้ำ
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// ตัววนซ้ำแบบไหนที่เราเปลี่ยนให้เป็น?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// สร้างตัววนซ้ำจากค่า
    ///
    /// ดู [module-level documentation] เพิ่มเติม
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// ขยายคอลเลกชันที่มีเนื้อหาของตัววนซ้ำ
///
/// ตัวทำซ้ำสร้างชุดของค่าและคอลเลกชันยังสามารถคิดเป็นชุดของค่าได้
/// `Extend` trait เชื่อมช่องว่างนี้ทำให้คุณสามารถขยายคอลเลคชันได้โดยรวมเนื้อหาของตัววนซ้ำนั้น
/// เมื่อขยายคอลเลกชันด้วยคีย์ที่มีอยู่แล้วรายการนั้นจะถูกอัพเดตหรือในกรณีของคอลเลกชันที่อนุญาตหลายรายการที่มีคีย์เท่ากันรายการนั้นจะถูกแทรก
///
///
/// # Examples
///
/// การใช้งานพื้นฐาน:
///
/// ```
/// // คุณสามารถขยายสตริงด้วยตัวอักษรบางตัว:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// การติดตั้ง `Extend`:
///
/// ```
/// // คอลเลกชันตัวอย่างนั่นเป็นเพียงกระดาษห่อหุ้ม Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // ลองมาดูวิธีการบางอย่างเพื่อที่เราจะได้สร้างขึ้นมาและเพิ่มสิ่งต่างๆเข้าไป
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // เนื่องจาก MyCollection มีรายการ i32s เราจึงใช้ Extend สำหรับ i32
/// impl Extend<i32> for MyCollection {
///
///     // สิ่งนี้ง่ายกว่าเล็กน้อยด้วยลายเซ็นประเภทคอนกรีต: เราสามารถเรียกขยายอะไรก็ได้ที่สามารถเปลี่ยนเป็น Iterator ซึ่งให้ i32s แก่เรา
///     // เพราะเราต้องการ i32s เพื่อใส่ใน MyCollection
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // การนำไปใช้นั้นตรงไปตรงมามาก: วนซ้ำผ่านตัววนซ้ำและ add() แต่ละองค์ประกอบกับตัวเราเอง
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // มาขยายคอลเลกชันของเราด้วยตัวเลขอีกสามตัว
/// c.extend(vec![1, 2, 3]);
///
/// // เราได้เพิ่มองค์ประกอบเหล่านี้ในตอนท้าย
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// ขยายคอลเลกชันที่มีเนื้อหาของตัววนซ้ำ
    ///
    /// เนื่องจากเป็นวิธีเดียวที่จำเป็นสำหรับ trait นี้เอกสาร [trait-level] จึงมีรายละเอียดเพิ่มเติม
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// // คุณสามารถขยายสตริงด้วยตัวอักษรบางตัว:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// ขยายคอลเลกชันที่มีองค์ประกอบเดียว
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// สงวนความจุในคอลเล็กชันสำหรับองค์ประกอบเพิ่มเติมตามจำนวนที่กำหนด
    ///
    /// การใช้งานเริ่มต้นไม่ทำอะไรเลย
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}