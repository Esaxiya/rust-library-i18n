use crate::iter::{FusedIterator, TrustedLen};

/// สร้างตัววนซ้ำใหม่ที่ทำซ้ำองค์ประกอบประเภท `A` อย่างไม่มีที่สิ้นสุดโดยใช้ตัวปิดที่ให้มาซึ่งเป็นตัวทำซ้ำ `F: FnMut() -> A`.
///
/// ฟังก์ชัน `repeat_with()` เรียกทวนซ้ำแล้วซ้ำอีก
///
/// ตัววนซ้ำแบบไม่มีที่สิ้นสุดเช่น `repeat_with()` มักใช้กับอะแดปเตอร์เช่น [`Iterator::take()`] เพื่อให้มีจำนวน จำกัด
///
/// หากประเภทองค์ประกอบของตัววนซ้ำที่คุณต้องการใช้ [`Clone`] และสามารถเก็บองค์ประกอบต้นทางไว้ในหน่วยความจำได้คุณควรใช้ฟังก์ชัน [`repeat()`] แทน
///
///
/// ตัววนซ้ำที่ผลิตโดย `repeat_with()` ไม่ใช่ [`DoubleEndedIterator`]
/// หากคุณต้องการ `repeat_with()` เพื่อส่งคืน [`DoubleEndedIterator`] โปรดเปิดปัญหา GitHub เพื่ออธิบายกรณีการใช้งานของคุณ
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// การใช้งานพื้นฐาน:
///
/// ```
/// use std::iter;
///
/// // สมมติว่าเรามีค่าบางประเภทที่ไม่ใช่ `Clone` หรือที่ยังไม่ต้องการมีในหน่วยความจำเพราะมีราคาแพง:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // ค่าเฉพาะตลอดไป:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// การใช้การกลายพันธุ์และการ จำกัด :
///
/// ```rust
/// use std::iter;
///
/// // จากซีโร ธ ถึงยกกำลังสามของสอง:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... และตอนนี้เราทำเสร็จแล้ว
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// ตัววนซ้ำที่ทำซ้ำองค์ประกอบประเภท `A` อย่างไม่มีที่สิ้นสุดโดยใช้การปิด `F: FnMut() -> A` ที่ให้มา
///
///
/// `struct` นี้สร้างขึ้นโดยฟังก์ชัน [`repeat_with()`]
/// ดูเอกสารประกอบสำหรับข้อมูลเพิ่มเติม
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}