use crate::fmt;

/// สร้างตัววนซ้ำใหม่โดยที่การวนซ้ำแต่ละครั้งเรียกการปิด `F: FnMut() -> Option<T>` ที่ให้มา
///
/// สิ่งนี้อนุญาตให้สร้างตัววนซ้ำแบบกำหนดเองพร้อมกับพฤติกรรมใด ๆ โดยไม่ต้องใช้ไวยากรณ์ที่ละเอียดมากขึ้นในการสร้างชนิดเฉพาะและใช้ [`Iterator`] trait สำหรับมัน
///
/// โปรดทราบว่าตัววนซ้ำ `FromFn` ไม่ได้ตั้งสมมติฐานเกี่ยวกับลักษณะการทำงานของการปิดดังนั้นจึงไม่ใช้ [`FusedIterator`] อย่างระมัดระวังหรือแทนที่ [`Iterator::size_hint()`] จาก `(0, None)` เริ่มต้น
///
///
/// การปิดสามารถใช้การจับภาพและสภาพแวดล้อมเพื่อติดตามสถานะในการทำซ้ำขึ้นอยู่กับวิธีการใช้ตัววนซ้ำซึ่งอาจต้องระบุคีย์เวิร์ด [`move`] ในการปิด
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// มาใช้ตัวนับตัวนับจาก [module-level documentation] อีกครั้ง:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // เพิ่มจำนวนของเรานี่คือสาเหตุที่เราเริ่มต้นที่ศูนย์
///     count += 1;
///
///     // ตรวจสอบดูว่าเรานับเสร็จแล้วหรือยัง
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// ตัววนซ้ำที่การวนซ้ำแต่ละครั้งเรียกการปิดที่ให้มา `F: FnMut() -> Option<T>`
///
/// `struct` นี้สร้างขึ้นโดยฟังก์ชัน [`iter::from_fn()`]
/// ดูเอกสารประกอบสำหรับข้อมูลเพิ่มเติม
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}