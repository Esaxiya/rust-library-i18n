use crate::iter::{FusedIterator, TrustedLen};

/// สร้างตัววนซ้ำที่สร้างค่าเพียงครั้งเดียวโดยเรียกใช้การปิดที่ให้มา
///
/// โดยทั่วไปจะใช้เพื่อปรับตัวสร้างค่าเดียวให้เป็น [`chain()`] ของการทำซ้ำประเภทอื่น ๆ
/// บางทีคุณอาจมีตัววนซ้ำที่ครอบคลุมเกือบทุกอย่าง แต่คุณต้องมีกรณีพิเศษเพิ่มเติม
/// บางทีคุณอาจมีฟังก์ชันที่ใช้งานได้กับตัวทำซ้ำ แต่คุณต้องประมวลผลเพียงค่าเดียว
///
/// ซึ่งแตกต่างจาก [`once()`] ฟังก์ชันนี้จะสร้างค่าตามคำขออย่างเกียจคร้าน
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// การใช้งานพื้นฐาน:
///
/// ```
/// use std::iter;
///
/// // หนึ่งคือตัวเลขที่โดดเดี่ยวที่สุด
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // เพียงหนึ่งเดียวนั่นคือทั้งหมดที่เราได้รับ
/// assert_eq!(None, one.next());
/// ```
///
/// เชื่อมต่อกับตัววนซ้ำอีกตัว
/// สมมติว่าเราต้องการทำซ้ำในแต่ละไฟล์ของไดเร็กทอรี `.foo` แต่ยังรวมถึงไฟล์คอนฟิกูเรชันด้วย
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // เราจำเป็นต้องแปลงจากตัววนซ้ำของ DirEntry-s เป็นตัววนซ้ำของ PathBufs ดังนั้นเราจึงใช้แผนที่
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ตอนนี้ตัววนซ้ำของเราสำหรับไฟล์กำหนดค่าของเราเท่านั้น
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // รวมตัวทำซ้ำสองตัวเข้าด้วยกันเป็นตัววนซ้ำขนาดใหญ่เครื่องเดียว
/// let files = dirs.chain(config);
///
/// // สิ่งนี้จะให้ไฟล์ทั้งหมดใน .foo และ .foorc แก่เรา
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// ตัววนซ้ำที่ให้องค์ประกอบเดียวประเภท `A` โดยใช้การปิด `F: FnOnce() -> A` ที่ให้มา
///
///
/// `struct` นี้สร้างขึ้นโดยฟังก์ชัน [`once_with()`]
/// ดูเอกสารประกอบสำหรับข้อมูลเพิ่มเติม
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}