use crate::iter::{FusedIterator, TrustedLen};

/// สร้างตัววนซ้ำที่ให้องค์ประกอบหนึ่งครั้ง
///
/// โดยทั่วไปจะใช้เพื่อปรับค่าเดียวให้เป็น [`chain()`] ของการทำซ้ำประเภทอื่น ๆ
/// บางทีคุณอาจมีตัววนซ้ำที่ครอบคลุมเกือบทุกอย่าง แต่คุณต้องมีกรณีพิเศษเพิ่มเติม
/// บางทีคุณอาจมีฟังก์ชันที่ใช้งานได้กับตัวทำซ้ำ แต่คุณต้องประมวลผลเพียงค่าเดียว
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// การใช้งานพื้นฐาน:
///
/// ```
/// use std::iter;
///
/// // หนึ่งคือตัวเลขที่โดดเดี่ยวที่สุด
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // เพียงหนึ่งเดียวนั่นคือทั้งหมดที่เราได้รับ
/// assert_eq!(None, one.next());
/// ```
///
/// เชื่อมต่อกับตัววนซ้ำอีกตัว
/// สมมติว่าเราต้องการทำซ้ำในแต่ละไฟล์ของไดเร็กทอรี `.foo` แต่ยังรวมถึงไฟล์คอนฟิกูเรชันด้วย
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // เราจำเป็นต้องแปลงจากตัววนซ้ำของ DirEntry-s เป็นตัววนซ้ำของ PathBufs ดังนั้นเราจึงใช้แผนที่
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ตอนนี้ตัววนซ้ำของเราสำหรับไฟล์กำหนดค่าของเราเท่านั้น
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // รวมตัวทำซ้ำสองตัวเข้าด้วยกันเป็นตัววนซ้ำขนาดใหญ่เครื่องเดียว
/// let files = dirs.chain(config);
///
/// // สิ่งนี้จะให้ไฟล์ทั้งหมดใน .foo และ .foorc แก่เรา
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// ตัววนซ้ำที่ให้องค์ประกอบหนึ่งครั้ง
///
/// `struct` นี้สร้างขึ้นโดยฟังก์ชัน [`once()`] ดูเอกสารประกอบสำหรับข้อมูลเพิ่มเติม
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}