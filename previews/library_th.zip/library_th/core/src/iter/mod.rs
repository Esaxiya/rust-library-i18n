//! การทำซ้ำภายนอกที่ประกอบได้
//!
//! หากคุณพบว่าตัวเองมีคอลเล็กชันบางประเภทและจำเป็นต้องดำเนินการกับองค์ประกอบของคอลเล็กชันดังกล่าวคุณจะเข้าสู่ 'iterators' ได้อย่างรวดเร็ว
//! ตัวทำซ้ำถูกใช้อย่างมากในรหัส Rust ที่เป็นสำนวนดังนั้นจึงควรทำความคุ้นเคยกับพวกเขา
//!
//! ก่อนที่จะอธิบายเพิ่มเติมเรามาพูดถึงโครงสร้างของโมดูลนี้:
//!
//! # Organization
//!
//! โมดูลนี้ส่วนใหญ่จัดตามประเภท:
//!
//! * [Traits] เป็นส่วนหลัก: traits เหล่านี้กำหนดว่ามีตัววนซ้ำประเภทใดและคุณสามารถทำอะไรได้บ้างวิธีการของ traits เหล่านี้ควรค่าแก่การใช้เวลาศึกษาเพิ่มเติม
//! * [Functions] ให้วิธีที่เป็นประโยชน์ในการสร้างตัวทำซ้ำพื้นฐาน
//! * [Structs] มักจะเป็นประเภทการส่งคืนของวิธีการต่างๆใน traits ของโมดูลนี้โดยปกติคุณจะต้องการดูวิธีการสร้าง `struct` แทนที่จะเป็น `struct` เอง
//! สำหรับรายละเอียดเพิ่มเติมเกี่ยวกับสาเหตุโปรดดูที่ "[Implementing Iterator](#plementing-iterator)"
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! แค่นั้นแหละ!มาเจาะลึกการทำซ้ำ
//!
//! # Iterator
//!
//! หัวใจและจิตวิญญาณของโมดูลนี้คือ [`Iterator`] trait แกนกลางของ [`Iterator`] มีลักษณะดังนี้:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! ตัววนซ้ำมีเมธอด [`next`] ซึ่งเมื่อเรียกใช้จะส่งกลับ ["ตัวเลือก"] "<Item>`.
//! [`next`] จะคืนค่า [`Some(Item)`] ตราบเท่าที่มีองค์ประกอบและเมื่อใช้งานทั้งหมดหมดแล้วจะส่งคืน `None` เพื่อระบุว่าการทำซ้ำเสร็จสิ้น
//! ผู้ทำซ้ำแต่ละคนอาจเลือกที่จะดำเนินการวนซ้ำดังนั้นการเรียก [`next`] อีกครั้งอาจหรือไม่อาจเริ่มคืนค่า [`Some(Item)`] อีกครั้งในบางจุด (ตัวอย่างเช่นดู [`TryIter`])
//!
//!
//! คำจำกัดความแบบเต็มของ ["Iterator`] มีวิธีการอื่น ๆ ด้วยเช่นกัน แต่เป็นวิธีการเริ่มต้นที่สร้างขึ้นจาก [`next`] และคุณจะได้รับฟรี
//!
//! นอกจากนี้ตัวทำซ้ำยังสามารถประกอบได้และเป็นเรื่องปกติที่จะเชื่อมโยงเข้าด้วยกันเพื่อทำการประมวลผลในรูปแบบที่ซับซ้อนดูส่วน [Adapters](#adapters) ด้านล่างสำหรับรายละเอียดเพิ่มเติม
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # สามรูปแบบของการทำซ้ำ
//!
//! มีวิธีการทั่วไปสามวิธีที่สามารถสร้างตัววนซ้ำจากคอลเล็กชัน:
//!
//! * `iter()`, ซึ่งทำซ้ำบน `&T`
//! * `iter_mut()`, ซึ่งทำซ้ำบน `&mut T`
//! * `into_iter()`, ซึ่งทำซ้ำบน `T`
//!
//! สิ่งต่างๆในไลบรารีมาตรฐานอาจใช้อย่างน้อยหนึ่งอย่างในสามอย่างตามความเหมาะสม
//!
//! # การใช้ Iterator
//!
//! การสร้างตัววนซ้ำของคุณเองมีสองขั้นตอน: การสร้าง `struct` เพื่อเก็บสถานะของตัววนซ้ำจากนั้นใช้ [`Iterator`] สำหรับ `struct` นั้น
//! ด้วยเหตุนี้จึงมี "โครงสร้าง" จำนวนมากในโมดูลนี้: มีหนึ่งสำหรับตัววนซ้ำและอะแดปเตอร์ตัววนซ้ำแต่ละตัว
//!
//! มาสร้างตัววนซ้ำชื่อ `Counter` ซึ่งนับจาก `1` ถึง `5`:
//!
//! ```
//! // ขั้นแรกโครงสร้าง:
//!
//! /// ตัววนซ้ำซึ่งนับตั้งแต่หนึ่งถึงห้า
//! struct Counter {
//!     count: usize,
//! }
//!
//! // เราต้องการให้การนับของเราเริ่มต้นที่หนึ่งดังนั้นให้เพิ่มวิธี new() เพื่อช่วย
//! // สิ่งนี้ไม่จำเป็นอย่างยิ่ง แต่สะดวก
//! // โปรดทราบว่าเราเริ่ม `count` ที่ศูนย์เราจะดูสาเหตุในการใช้งาน `next()`'s ด้านล่าง
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // จากนั้นเราใช้ `Iterator` สำหรับ `Counter` ของเรา:
//!
//! impl Iterator for Counter {
//!     // เราจะนับด้วย usize
//!     type Item = usize;
//!
//!     // next() เป็นวิธีเดียวที่จำเป็น
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // เพิ่มจำนวนของเรานี่คือสาเหตุที่เราเริ่มต้นที่ศูนย์
//!         self.count += 1;
//!
//!         // ตรวจสอบดูว่าเรานับเสร็จแล้วหรือยัง
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // และตอนนี้เราสามารถใช้งานได้แล้ว!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! การเรียก [`next`] ด้วยวิธีนี้จะเกิดขึ้นซ้ำ ๆ Rust มีโครงสร้างที่สามารถเรียก [`next`] บนตัววนซ้ำของคุณได้จนกว่าจะถึง `None` มาดูเรื่องต่อไปกันดีกว่า
//!
//! โปรดทราบว่า `Iterator` มีการใช้งานวิธีการเริ่มต้นเช่น `nth` และ `fold` ซึ่งเรียก `next` เป็นการภายใน
//! อย่างไรก็ตามยังเป็นไปได้ที่จะเขียนการใช้งานเมธอดแบบกำหนดเองเช่น `nth` และ `fold` หากตัววนซ้ำสามารถคำนวณได้อย่างมีประสิทธิภาพมากขึ้นโดยไม่ต้องเรียก `next`
//!
//! # `for` ลูปและ `IntoIterator`
//!
//! ไวยากรณ์ลูป `for` ของ Rust นั้นเป็นน้ำตาลสำหรับตัวทำซ้ำนี่คือตัวอย่างพื้นฐานของ `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! การดำเนินการนี้จะพิมพ์ตัวเลขหนึ่งถึงห้าโดยแต่ละบรรทัดในบรรทัดของตัวเองแต่คุณจะสังเกตเห็นบางอย่างที่นี่: เราไม่เคยเรียกอะไรใน vector ของเราเพื่อสร้างตัววนซ้ำสิ่งที่ช่วยให้?
//!
//! มี trait ในไลบรารีมาตรฐานสำหรับการแปลงบางสิ่งเป็นตัววนซ้ำ: [`IntoIterator`].
//! trait นี้มีวิธีการเดียวคือ [`into_iter`] ซึ่งจะแปลงสิ่งที่ใช้ [`IntoIterator`] เป็นตัววนซ้ำ
//! ลองมาดู `for` ลูปอีกครั้งและสิ่งที่คอมไพเลอร์แปลงเป็น:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust ลดน้ำตาลลงใน:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! อันดับแรกเราเรียกค่า `into_iter()` ว่าจากนั้นเราจับคู่กับตัววนซ้ำที่ส่งคืนเรียก [`next`] ซ้ำแล้วซ้ำเล่าจนกว่าเราจะเห็น `None`
//! เมื่อถึงจุดนั้นเรา `break` ออกจากลูปและเราทำซ้ำแล้ว
//!
//! มีอีกหนึ่งบิตที่ลึกซึ้งที่นี่: ไลบรารีมาตรฐานมีการใช้งาน [`IntoIterator`] ที่น่าสนใจ:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! กล่าวอีกนัยหนึ่ง [`Iterator`] ทั้งหมดใช้ [`IntoIterator`] โดยเพียงแค่ส่งคืนตัวเองนี่หมายถึงสองสิ่ง:
//!
//! 1. หากคุณกำลังเขียน [`Iterator`] คุณสามารถใช้กับลูป `for` ได้
//! 2. หากคุณกำลังสร้างคอลเลกชันการใช้ [`IntoIterator`] จะทำให้คอลเลกชันของคุณสามารถใช้กับลูป `for` ได้
//!
//! # การทำซ้ำโดยการอ้างอิง
//!
//! เนื่องจาก [`into_iter()`] ใช้ `self` ตามค่าการใช้ลูป `for` เพื่อวนซ้ำบนคอลเลกชันจะใช้คอลเลกชันนั้นบ่อยครั้งคุณอาจต้องการทำซ้ำคอลเลกชันโดยไม่ต้องใช้มัน
//! คอลเลกชันจำนวนมากเสนอวิธีการที่ให้ตัวทำซ้ำมากกว่าการอ้างอิงตามอัตภาพเรียกว่า `iter()` และ `iter_mut()` ตามลำดับ:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` ยังคงเป็นของฟังก์ชันนี้
//! ```
//!
//! หากคอลเลกชันประเภท `C` มี `iter()` โดยปกติจะใช้ `IntoIterator` สำหรับ `&C` ด้วยการใช้งานที่เรียกว่า `iter()`
//! ในทำนองเดียวกันคอลเล็กชัน `C` ที่ให้ `iter_mut()` โดยทั่วไปจะใช้ `IntoIterator` สำหรับ `&mut C` โดยการมอบหมายให้ `iter_mut()` สิ่งนี้ช่วยให้สามารถจดชวเลขได้สะดวก:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // เช่นเดียวกับ `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // เช่นเดียวกับ `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! ในขณะที่คอลเลกชันจำนวนมากเสนอ `iter()` แต่ไม่ใช่ทั้งหมดที่เสนอ `iter_mut()`
//! ตัวอย่างเช่นการเปลี่ยนคีย์ของ [`HashSet<T>`] หรือ [`HashMap<K, V>`] อาจทำให้คอลเล็กชันอยู่ในสถานะที่ไม่สอดคล้องกันหากแฮชคีย์เปลี่ยนไปดังนั้นคอลเล็กชันเหล่านี้จึงมีเฉพาะ `iter()`
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! ฟังก์ชันที่ใช้ [`Iterator`] และส่งคืน [`Iterator`] อื่นมักเรียกว่า 'iterator adapters' เนื่องจากเป็นรูปแบบของ 'อะแดปเตอร์'
//! pattern'.
//!
//! อะแด็ปเตอร์ตัววนซ้ำทั่วไป ได้แก่ [`map`], [`take`] และ [`filter`]
//! สำหรับข้อมูลเพิ่มเติมโปรดดูเอกสารประกอบ
//!
//! หากอะแด็ปเตอร์ตัววนซ้ำ panics ตัววนซ้ำจะอยู่ในสถานะไม่ระบุ (แต่หน่วยความจำปลอดภัย)
//! นอกจากนี้สถานะนี้ยังไม่รับประกันว่าจะยังคงเหมือนเดิมในทุกเวอร์ชันของ Rust ดังนั้นคุณควรหลีกเลี่ยงการพึ่งพาค่าที่แน่นอนที่ส่งคืนโดยตัววนซ้ำที่ตื่นตระหนก
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterator (และตัววนซ้ำ [adapters](#adapters)) คือ *lazy* ซึ่งหมายความว่าการสร้างตัววนซ้ำไม่ได้ _do_ มากนักไม่มีอะไรเกิดขึ้นจนกว่าคุณจะเรียก [`next`]
//! บางครั้งนี่เป็นที่มาของความสับสนเมื่อสร้างตัววนซ้ำเพื่อผลข้างเคียงเท่านั้น
//! ตัวอย่างเช่นวิธี [`map`] เรียกการปิดในแต่ละองค์ประกอบที่วนซ้ำ:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! สิ่งนี้จะไม่พิมพ์ค่าใด ๆ เนื่องจากเราสร้างตัววนซ้ำเท่านั้นแทนที่จะใช้มันคอมไพเลอร์จะเตือนเราเกี่ยวกับพฤติกรรมประเภทนี้:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! วิธีสำนวนในการเขียน [`map`] สำหรับผลข้างเคียงคือการใช้ `for` loop หรือเรียกวิธี [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! อีกวิธีหนึ่งในการประเมินตัววนซ้ำคือการใช้วิธี [`collect`] เพื่อสร้างคอลเล็กชันใหม่
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! ตัวทำซ้ำไม่จำเป็นต้อง จำกัดตัวอย่างเช่นช่วงปลายเปิดคือตัววนซ้ำที่ไม่มีที่สิ้นสุด:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! เป็นเรื่องปกติที่จะใช้อะแด็ปเตอร์ตัววนซ้ำ [`take`] เพื่อเปลี่ยนตัววนซ้ำแบบไม่มีที่สิ้นสุดให้เป็นแบบ จำกัด :
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! การดำเนินการนี้จะพิมพ์ตัวเลข `0` ถึง `4` แต่ละหมายเลขในบรรทัดของตัวเอง
//!
//! โปรดจำไว้ว่าวิธีการในการวนซ้ำแบบไม่มีที่สิ้นสุดแม้กระทั่งวิธีที่สามารถกำหนดผลลัพธ์ทางคณิตศาสตร์ได้ในเวลา จำกัด ก็ไม่อาจยุติได้
//! โดยเฉพาะเมธอดเช่น [`min`] ซึ่งในกรณีทั่วไปต้องใช้การข้ามผ่านทุกองค์ประกอบในตัววนซ้ำมีแนวโน้มที่จะไม่ส่งคืนสำเร็จสำหรับตัวทำซ้ำที่ไม่มีที่สิ้นสุด
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // ไม่นะ!วนซ้ำไม่มีที่สิ้นสุด!
//! // `ones.min()` ทำให้เกิดการวนซ้ำไม่สิ้นสุดดังนั้นเราจะไม่มาถึงจุดนี้!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;