use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// อ็อบเจ็กต์ที่มีแนวคิดเกี่ยวกับการดำเนินการแบบ *สืบทอด* และ *รุ่นก่อน*
///
/// การดำเนินการ *สืบต่อ* ย้ายไปสู่ค่าที่เปรียบเทียบมากกว่า
/// การดำเนินการ *รุ่นก่อน* ย้ายไปสู่ค่าที่เปรียบเทียบน้อยกว่า
///
/// # Safety
///
/// trait นี้คือ `unsafe` เนื่องจากการนำไปใช้งานต้องถูกต้องเพื่อความปลอดภัยของการใช้งาน `unsafe trait TrustedLen` และผลลัพธ์ของการใช้ trait นี้สามารถเชื่อถือได้โดยรหัส `unsafe` ว่าถูกต้องและปฏิบัติตามข้อผูกพันที่ระบุไว้
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// ส่งคืนจำนวนขั้นตอน *successor* ที่ต้องการเพื่อรับจาก `start` ถึง `end`
    ///
    /// ส่งคืน `None` หากจำนวนขั้นตอนมากเกินไป `usize` (หรือไม่มีที่สิ้นสุดหรือถ้า `end` จะไม่ถึง)
    ///
    ///
    /// # Invariants
    ///
    /// สำหรับ `a`, `b` และ `n` ใด ๆ :
    ///
    /// * `steps_between(&a, &b) == Some(n)` ถ้าและเฉพาะในกรณีที่ `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` ถ้าและเฉพาะในกรณีที่ `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` เฉพาะในกรณีที่ `a <= b`
    ///   * Corollary: `steps_between(&a, &b) == Some(0)` ถ้า `a == b` เท่านั้น
    ///   * โปรดทราบว่า `a <= b` หมายถึง _not_ หมายถึง `steps_between(&a, &b) != None`
    ///     นี่เป็นกรณีที่ต้องใช้มากกว่า `usize::MAX` ขั้นตอนเพื่อไปยัง `b`
    /// * `steps_between(&a, &b) == None` ถ้า `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// ส่งคืนค่าที่จะได้รับจากการใช้ *successor* ของ `self` `count` คูณ
    ///
    /// หากสิ่งนี้จะเกินช่วงของค่าที่ `Self` สนับสนุนให้ส่งกลับ `None`
    ///
    /// # Invariants
    ///
    /// สำหรับ `a`, `n` และ `m` ใด ๆ :
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// สำหรับ `a`, `n` และ `m` ใด ๆ ที่ `n + m` ไม่ล้น:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// สำหรับ `a` และ `n` ใด ๆ :
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// ส่งคืนค่าที่จะได้รับจากการใช้ *successor* ของ `self` `count` คูณ
    ///
    /// หากสิ่งนี้จะล้นเกินช่วงของค่าที่ `Self` รองรับฟังก์ชันนี้จะได้รับอนุญาตให้ panic ห่อหรืออิ่มตัว
    ///
    /// ลักษณะการทำงานที่แนะนำคือ panic เมื่อเปิดใช้งานการยืนยันการดีบักและเพื่อห่อหรือทำให้อิ่มตัวเป็นอย่างอื่น
    ///
    /// รหัสที่ไม่ปลอดภัยไม่ควรขึ้นอยู่กับความถูกต้องของพฤติกรรมหลังจากล้น
    ///
    /// # Invariants
    ///
    /// สำหรับ `a`, `n` และ `m` ใด ๆ ที่ไม่มีการล้นเกิดขึ้น:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// สำหรับ `a` และ `n` ใด ๆ ที่ไม่มีการล้นเกิดขึ้น:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// ส่งคืนค่าที่จะได้รับจากการใช้ *successor* ของ `self` `count` คูณ
    ///
    /// # Safety
    ///
    /// เป็นพฤติกรรมที่ไม่ได้กำหนดไว้สำหรับการดำเนินการนี้เพื่อล้นช่วงของค่าที่ `Self` สนับสนุน
    /// หากคุณไม่สามารถรับประกันได้ว่าสิ่งนี้จะไม่ล้นให้ใช้ `forward` หรือ `forward_checked` แทน
    ///
    /// # Invariants
    ///
    /// สำหรับ `a` ใด ๆ :
    ///
    /// * หากมี `b` เช่น `b > a` ก็ปลอดภัยที่จะเรียก `Step::forward_unchecked(a, 1)`
    /// * หากมี `b`, `n` เช่น `steps_between(&a, &b) == Some(n)` ก็ปลอดภัยที่จะเรียก `Step::forward_unchecked(a, m)` สำหรับ `m <= n` ใด ๆ
    ///
    ///
    /// สำหรับ `a` และ `n` ใด ๆ ที่ไม่มีการล้นเกิดขึ้น:
    ///
    /// * `Step::forward_unchecked(a, n)` เทียบเท่ากับ `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// ส่งคืนค่าที่จะได้รับจากการรับ *รุ่นก่อนหน้า* ของ `self` `count` คูณ
    ///
    /// หากสิ่งนี้จะเกินช่วงของค่าที่ `Self` สนับสนุนให้ส่งกลับ `None`
    ///
    /// # Invariants
    ///
    /// สำหรับ `a`, `n` และ `m` ใด ๆ :
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// สำหรับ `a` และ `n` ใด ๆ :
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// ส่งคืนค่าที่จะได้รับจากการรับ *รุ่นก่อนหน้า* ของ `self` `count` คูณ
    ///
    /// หากสิ่งนี้จะล้นเกินช่วงของค่าที่ `Self` รองรับฟังก์ชันนี้จะได้รับอนุญาตให้ panic ห่อหรืออิ่มตัว
    ///
    /// ลักษณะการทำงานที่แนะนำคือ panic เมื่อเปิดใช้งานการยืนยันการดีบักและเพื่อห่อหรือทำให้อิ่มตัวเป็นอย่างอื่น
    ///
    /// รหัสที่ไม่ปลอดภัยไม่ควรขึ้นอยู่กับความถูกต้องของพฤติกรรมหลังจากล้น
    ///
    /// # Invariants
    ///
    /// สำหรับ `a`, `n` และ `m` ใด ๆ ที่ไม่มีการล้นเกิดขึ้น:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// สำหรับ `a` และ `n` ใด ๆ ที่ไม่มีการล้นเกิดขึ้น:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// ส่งคืนค่าที่จะได้รับจากการรับ *รุ่นก่อนหน้า* ของ `self` `count` คูณ
    ///
    /// # Safety
    ///
    /// เป็นพฤติกรรมที่ไม่ได้กำหนดไว้สำหรับการดำเนินการนี้เพื่อล้นช่วงของค่าที่ `Self` สนับสนุน
    /// หากคุณไม่สามารถรับประกันได้ว่าสิ่งนี้จะไม่ล้นให้ใช้ `backward` หรือ `backward_checked` แทน
    ///
    /// # Invariants
    ///
    /// สำหรับ `a` ใด ๆ :
    ///
    /// * หากมี `b` เช่น `b < a` ก็ปลอดภัยที่จะเรียก `Step::backward_unchecked(a, 1)`
    /// * หากมี `b`, `n` เช่น `steps_between(&b, &a) == Some(n)` ก็ปลอดภัยที่จะเรียก `Step::backward_unchecked(a, m)` สำหรับ `m <= n` ใด ๆ
    ///
    ///
    /// สำหรับ `a` และ `n` ใด ๆ ที่ไม่มีการล้นเกิดขึ้น:
    ///
    /// * `Step::backward_unchecked(a, n)` เทียบเท่ากับ `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// สิ่งเหล่านี้ยังคงสร้างขึ้นด้วยมาโครเนื่องจากลิเทอรัลจำนวนเต็มแก้ไขเป็นประเภทต่างๆ
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // ความปลอดภัย: ผู้โทรต้องรับประกันว่า `start + n` ไม่ล้น
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // ความปลอดภัย: ผู้โทรต้องรับประกันว่า `start - n` ไม่ล้น
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // ในการแก้ปัญหาบิวด์ทริกเกอร์ panic เมื่อโอเวอร์โฟลว์
            // สิ่งนี้ควรปรับให้เหมาะสมอย่างสมบูรณ์ในรุ่นรุ่น
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // ทำการตัดคณิตศาสตร์เพื่อให้เช่น `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // ในการแก้ปัญหาบิวด์ทริกเกอร์ panic เมื่อโอเวอร์โฟลว์
            // สิ่งนี้ควรปรับให้เหมาะสมอย่างสมบูรณ์ในรุ่นรุ่น
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // ทำการตัดคณิตศาสตร์เพื่อให้เช่น `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // สิ่งนี้อาศัย $u_narrower <=usize
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // ถ้า n อยู่นอกช่วง `unsigned_start + n` ก็เกินไป
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // ถ้า n อยู่นอกช่วง `unsigned_start - n` ก็เกินไป
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // สิ่งนี้อาศัย $i_narrower <=usize
                        //
                        // การหล่อเป็นขนาดใหญ่จะขยายความกว้าง แต่ยังคงรักษาเครื่องหมายไว้
                        // ใช้ wrapping_sub ในพื้นที่ isize และส่งเพื่อใช้ในการคำนวณความแตกต่างที่อาจไม่พอดีกับช่วงของ isize
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // การห่อจัดการเคสเช่น `Step::forward(-120_i8, 200) == Some(80_i8)` แม้ว่า 200 จะอยู่นอกระยะสำหรับ i8
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // นอกจากนี้ล้น
                            }
                        }
                        // ถ้า n อยู่นอกช่วงของเช่น
                        // u8, จากนั้นมันใหญ่กว่าช่วงทั้งหมดสำหรับ i8 นั้นกว้างดังนั้น `any_i8 + n` จึงจำเป็นต้องล้น i8
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // การห่อจัดการเคสเช่น `Step::forward(-120_i8, 200) == Some(80_i8)` แม้ว่า 200 จะอยู่นอกระยะสำหรับ i8
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // การลบมากเกินไป
                            }
                        }
                        // ถ้า n อยู่นอกช่วงของเช่น
                        // u8, จากนั้นมันใหญ่กว่าช่วงทั้งหมดสำหรับ i8 นั้นกว้างดังนั้น `any_i8 - n` จึงจำเป็นต้องล้น i8
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // ถ้าความแตกต่างใหญ่เกินไปสำหรับเช่น
                            // i128 มันจะใหญ่เกินไปสำหรับการใช้งานที่มีจำนวนบิตน้อยลง
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // ความปลอดภัย: res เป็นสเกลาร์ Unicode ที่ถูกต้อง
            // (ต่ำกว่า 0x110000 และไม่อยู่ใน 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // ความปลอดภัย: res เป็นสเกลาร์ Unicode ที่ถูกต้อง
        // (ต่ำกว่า 0x110000 และไม่อยู่ใน 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // ความปลอดภัย: ผู้โทรต้องรับประกันว่าสิ่งนี้จะไม่ล้น
        // ช่วงของค่าสำหรับถ่าน
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // ความปลอดภัย: ผู้โทรต้องรับประกันว่าสิ่งนี้จะไม่ล้น
            // ช่วงของค่าสำหรับถ่าน
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // ความปลอดภัย: เนื่องจากสัญญาก่อนหน้านี้ได้รับการประกัน
        // โดยผู้โทรจะเป็นถ่านที่ถูกต้อง
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // ความปลอดภัย: ผู้โทรต้องรับประกันว่าสิ่งนี้จะไม่ล้น
        // ช่วงของค่าสำหรับถ่าน
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // ความปลอดภัย: ผู้โทรต้องรับประกันว่าสิ่งนี้จะไม่ล้น
            // ช่วงของค่าสำหรับถ่าน
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // ความปลอดภัย: เนื่องจากสัญญาก่อนหน้านี้ได้รับการประกัน
        // โดยผู้โทรจะเป็นถ่านที่ถูกต้อง
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // ความปลอดภัย: เพิ่งตรวจสอบเงื่อนไขเบื้องต้น
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // ความปลอดภัย: เพิ่งตรวจสอบเงื่อนไขเบื้องต้น
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// มาโครเหล่านี้สร้าง `ExactSizeIterator` ims สำหรับช่วงประเภทต่างๆ
//
// * `ExactSizeIterator::len` จำเป็นต้องส่งคืน `usize` ที่แน่นอนเสมอดังนั้นจึงไม่มีช่วงใดที่ยาวเกิน `usize::MAX` ได้
//
// * สำหรับประเภทจำนวนเต็มใน `Range<_>` เป็นกรณีของประเภทที่แคบกว่าหรือกว้างเท่ากับ `usize`
//   สำหรับประเภทจำนวนเต็มใน `RangeInclusive<_>` เป็นกรณีสำหรับประเภท *แคบกว่า* มากกว่า `usize` อย่างเคร่งครัดตั้งแต่เช่น
//   `(0..=u64::MAX).len()` จะเป็น `u64::MAX + 1`
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // สิ่งเหล่านี้เป็นสิ่งที่เกิดขึ้นตามเหตุผลข้างต้น แต่การลบออกจะเป็นการเปลี่ยนแปลงอย่างสิ้นเชิงเนื่องจากมีความเสถียรใน Rust 1.0.0
    // เช่น
    // `(0..66_000_u32).len()` ตัวอย่างเช่นจะคอมไพล์โดยไม่มีข้อผิดพลาดหรือคำเตือนบนแพลตฟอร์ม 16 บิต แต่ยังคงให้ผลลัพธ์ที่ไม่ถูกต้อง
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // สิ่งเหล่านี้เป็นสิ่งที่เกิดขึ้นตามเหตุผลข้างต้น แต่การลบออกจะเป็นการเปลี่ยนแปลงอย่างสิ้นเชิงเนื่องจากมีความเสถียรใน Rust 1.26.0
    // เช่น
    // `(0..=u16::MAX).len()` ตัวอย่างเช่นจะคอมไพล์โดยไม่มีข้อผิดพลาดหรือคำเตือนบนแพลตฟอร์ม 16 บิต แต่ยังคงให้ผลลัพธ์ที่ไม่ถูกต้อง
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // ความปลอดภัย: เพิ่งตรวจสอบเงื่อนไขเบื้องต้น
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // ความปลอดภัย: เพิ่งตรวจสอบเงื่อนไขเบื้องต้น
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // ความปลอดภัย: เพิ่งตรวจสอบเงื่อนไขเบื้องต้น
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // ความปลอดภัย: เพิ่งตรวจสอบเงื่อนไขเบื้องต้น
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // ความปลอดภัย: เพิ่งตรวจสอบเงื่อนไขเบื้องต้น
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // ความปลอดภัย: เพิ่งตรวจสอบเงื่อนไขเบื้องต้น
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}