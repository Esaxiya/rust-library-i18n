use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// trait นี้จัดเตรียมการเข้าถึงสวิทซ์ขั้นตอนต้นทางในไปป์ไลน์อะแด็ปเตอร์จำนวนเต็มภายใต้เงื่อนไขที่
/// * แหล่งที่มาของตัววนซ้ำ `S` เองใช้ `SourceIter<Source = S>`
/// * มีการมอบหมายการใช้งาน trait นี้สำหรับอะแด็ปเตอร์แต่ละตัวในท่อระหว่างต้นทางและผู้ใช้ไปป์ไลน์
///
/// เมื่อซอร์สเป็นโครงสร้างตัววนซ้ำที่เป็นของตัวเอง (โดยทั่วไปเรียกว่า `IntoIter`) สิ่งนี้จะเป็นประโยชน์สำหรับการใช้งาน [`FromIterator`] หรือการกู้คืนองค์ประกอบที่เหลือหลังจากตัววนซ้ำหมดลงบางส่วน
///
///
/// โปรดทราบว่าการนำไปใช้งานไม่จำเป็นต้องให้การเข้าถึงแหล่งที่มาส่วนใหญ่ของไปป์ไลน์อะแด็ปเตอร์ระดับกลางที่มีสถานะอาจประเมินส่วนหนึ่งของไปป์ไลน์อย่างกระตือรือร้นและเปิดเผยที่เก็บข้อมูลภายในเป็นแหล่งที่มา
///
/// trait ไม่ปลอดภัยเนื่องจากผู้ใช้งานต้องรักษาคุณสมบัติด้านความปลอดภัยเพิ่มเติม
/// ดู [`as_inner`] สำหรับรายละเอียด
///
/// # Examples
///
/// การดึงแหล่งที่มาที่ใช้ไปบางส่วน:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// ขั้นตอนต้นทางในไปป์ไลน์ตัววนซ้ำ
    type Source: Iterator;

    /// ดึงแหล่งที่มาของไปป์ไลน์ตัววนซ้ำ
    ///
    /// # Safety
    ///
    /// การใช้งานจะต้องส่งคืนการอ้างอิงที่เปลี่ยนแปลงได้เหมือนกันตลอดอายุการใช้งานเว้นแต่จะถูกแทนที่โดยผู้โทร
    /// ผู้โทรสามารถแทนที่ข้อมูลอ้างอิงได้ก็ต่อเมื่อพวกเขาหยุดการทำซ้ำและปล่อยไปป์ไลน์ตัววนซ้ำหลังจากแยกแหล่งที่มา
    ///
    /// ซึ่งหมายความว่าอะแด็ปเตอร์ตัววนซ้ำสามารถพึ่งพาซอร์สที่ไม่เปลี่ยนแปลงระหว่างการทำซ้ำ แต่ไม่สามารถพึ่งพาได้ในการใช้งาน Drop
    ///
    /// การใช้วิธีนี้หมายความว่าอะแด็ปเตอร์สละสิทธิ์การเข้าถึงแบบไพรเวตเท่านั้นไปยังแหล่งที่มาและสามารถพึ่งพาการรับประกันตามประเภทตัวรับวิธีการเท่านั้น
    /// การขาดการเข้าถึงแบบ จำกัด ยังกำหนดให้อะแด็ปเตอร์ต้องสนับสนุน API สาธารณะของแหล่งที่มาแม้ว่าจะมีการเข้าถึงภายในก็ตาม
    ///
    /// ในทางกลับกันผู้โทรจะต้องคาดหวังให้แหล่งที่มาอยู่ในสถานะใด ๆ ที่สอดคล้องกับ API สาธารณะเนื่องจากอะแดปเตอร์ที่อยู่ระหว่างนั้นและแหล่งที่มามีการเข้าถึงเดียวกัน
    /// โดยเฉพาะอย่างยิ่งอะแดปเตอร์อาจใช้องค์ประกอบมากเกินความจำเป็นอย่างเคร่งครัด
    ///
    /// เป้าหมายโดยรวมของข้อกำหนดเหล่านี้คือเพื่อให้ผู้บริโภคใช้ไปป์ไลน์
    /// * สิ่งที่ยังคงอยู่ในแหล่งที่มาหลังจากหยุดการทำซ้ำ
    /// * หน่วยความจำที่ไม่ได้ใช้งานโดยการพัฒนาตัววนซ้ำที่สิ้นเปลือง
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// อะแด็ปเตอร์ตัววนซ้ำที่สร้างเอาต์พุตตราบเท่าที่ตัวทำซ้ำที่อยู่เบื้องหลังสร้างค่า `Result::Ok`
///
///
/// หากพบข้อผิดพลาดตัววนซ้ำจะหยุดทำงานและข้อผิดพลาดจะถูกเก็บไว้
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// ประมวลผลตัววนซ้ำที่กำหนดราวกับว่ามันให้ผล `T` แทนที่จะเป็น `Result<T, _>`
/// ข้อผิดพลาดใด ๆ จะหยุดการวนซ้ำภายในและผลลัพธ์โดยรวมจะเป็นข้อผิดพลาด
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}