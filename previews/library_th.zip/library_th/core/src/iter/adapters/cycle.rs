use crate::{iter::FusedIterator, ops::Try};

/// ตัววนซ้ำที่ทำซ้ำอย่างไม่มีที่สิ้นสุด
///
/// `struct` นี้สร้างขึ้นโดยวิธี [`cycle`] บน [`Iterator`]
/// ดูเอกสารประกอบสำหรับข้อมูลเพิ่มเติม
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // ตัววนซ้ำรอบจะว่างเปล่าหรือไม่มีที่สิ้นสุด
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // ทำซ้ำตัววนซ้ำปัจจุบันอย่างเต็มที่
        // สิ่งนี้จำเป็นเนื่องจาก `self.iter` อาจว่างเปล่าแม้ว่า `self.orig` จะไม่ใช่ก็ตาม
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // ทำครบวงจรติดตามว่าตัววนซ้ำแบบวนรอบว่างเปล่าหรือไม่
        // เราจำเป็นต้องกลับก่อนเวลาในกรณีที่มีตัววนซ้ำว่างเปล่าเพื่อป้องกันการวนซ้ำที่ไม่มีที่สิ้นสุด
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // ไม่มีการแทนที่ `fold` เนื่องจาก `fold` ไม่เหมาะสมกับ `Cycle` มากนักและเราไม่สามารถทำอะไรได้ดีไปกว่าค่าเริ่มต้น
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}