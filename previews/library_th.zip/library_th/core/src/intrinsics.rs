//! Intrinsics ของคอมไพเลอร์
//!
//! คำจำกัดความที่เกี่ยวข้องอยู่ใน `compiler/rustc_codegen_llvm/src/intrinsic.rs`
//! การใช้งาน const ที่สอดคล้องกันอยู่ใน `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const Intrinsics
//!
//! Note: การเปลี่ยนแปลงใด ๆ ในความมั่นคงของเนื้อแท้ควรได้รับการหารือกับทีมภาษา
//! ซึ่งรวมถึงการเปลี่ยนแปลงความเสถียรของ constness
//!
//! เพื่อให้สามารถใช้งานได้ในเวลาคอมไพล์เราต้องคัดลอกการนำไปใช้งานจาก <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> เป็น `compiler/rustc_mir/src/interpret/intrinsics.rs` และเพิ่ม `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ลงในอินทรินซิก
//!
//!
//! หากควรใช้อินทรินซิกจาก `const fn` ที่มีแอ็ตทริบิวต์ `rustc_const_stable` แอ็ตทริบิวต์ของอินทรินซิกต้องเป็น `rustc_const_stable` ด้วย
//! การเปลี่ยนแปลงดังกล่าวไม่ควรกระทำโดยไม่ได้รับคำปรึกษาจาก T-lang เนื่องจากจะทำให้คุณลักษณะเป็นภาษาที่ไม่สามารถจำลองแบบในรหัสผู้ใช้โดยไม่ได้รับการสนับสนุนจากคอมไพเลอร์
//!
//! # Volatiles
//!
//! ภายในที่ระเหยได้ให้การดำเนินการที่มีจุดประสงค์เพื่อดำเนินการกับหน่วยความจำ I/O ซึ่งรับประกันว่าคอมไพเลอร์จะไม่ถูกจัดลำดับใหม่ในอินทรินซิคอื่นดูเอกสาร LLVM บน [[volatile]]
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! เนื้อแท้ของอะตอมจัดให้มีการดำเนินการเกี่ยวกับอะตอมทั่วไปในคำเครื่องจักรโดยมีลำดับความจำที่เป็นไปได้หลายแบบพวกเขาปฏิบัติตามความหมายเดียวกันกับ C++ 11ดูเอกสาร LLVM บน [[atomics]]
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! การทบทวนการจัดลำดับหน่วยความจำอย่างรวดเร็ว:
//!
//! * ได้รับอุปสรรคสำหรับการได้รับล็อคการอ่านและเขียนในภายหลังจะเกิดขึ้นหลังสิ่งกีดขวาง
//! * ปล่อยสิ่งกีดขวางสำหรับปลดล็อคการอ่านและเขียนก่อนหน้าจะเกิดขึ้นก่อนสิ่งกีดขวาง
//! * การดำเนินการที่สอดคล้องกันตามลำดับและสอดคล้องกันอย่างต่อเนื่องรับประกันว่าจะเกิดขึ้นตามลำดับนี่คือโหมดมาตรฐานสำหรับการทำงานกับประเภทอะตอมและเทียบเท่ากับ `volatile` ของ Java
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// การนำเข้าเหล่านี้ใช้เพื่อลดความซับซ้อนของลิงก์ภายในเอกสาร
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // ความปลอดภัย: ดู `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // หมายเหตุภายในเหล่านี้ใช้พอยน์เตอร์ดิบเนื่องจากกลายพันธุ์หน่วยความจำนามแฝงซึ่งไม่ถูกต้องสำหรับ `&` หรือ `&mut`
    //

    /// เก็บค่าหากค่าปัจจุบันเหมือนกับค่า `old`
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `compare_exchange` โดยส่ง [`Ordering::SeqCst`] เป็นทั้งพารามิเตอร์ `success` และ `failure`
    ///
    /// ตัวอย่างเช่น, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// เก็บค่าหากค่าปัจจุบันเหมือนกับค่า `old`
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `compare_exchange` โดยส่ง [`Ordering::Acquire`] เป็นทั้งพารามิเตอร์ `success` และ `failure`
    ///
    /// ตัวอย่างเช่น, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// เก็บค่าหากค่าปัจจุบันเหมือนกับค่า `old`
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `compare_exchange` โดยส่ง [`Ordering::Release`] เป็น `success` และ [`Ordering::Relaxed`] เป็นพารามิเตอร์ `failure`
    /// ตัวอย่างเช่น, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// เก็บค่าหากค่าปัจจุบันเหมือนกับค่า `old`
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `compare_exchange` โดยส่ง [`Ordering::AcqRel`] เป็น `success` และ [`Ordering::Acquire`] เป็นพารามิเตอร์ `failure`
    /// ตัวอย่างเช่น, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// เก็บค่าหากค่าปัจจุบันเหมือนกับค่า `old`
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `compare_exchange` โดยส่ง [`Ordering::Relaxed`] เป็นทั้งพารามิเตอร์ `success` และ `failure`
    ///
    /// ตัวอย่างเช่น, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// เก็บค่าหากค่าปัจจุบันเหมือนกับค่า `old`
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `compare_exchange` โดยส่ง [`Ordering::SeqCst`] เป็น `success` และ [`Ordering::Relaxed`] เป็นพารามิเตอร์ `failure`
    /// ตัวอย่างเช่น, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// เก็บค่าหากค่าปัจจุบันเหมือนกับค่า `old`
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `compare_exchange` โดยส่ง [`Ordering::SeqCst`] เป็น `success` และ [`Ordering::Acquire`] เป็นพารามิเตอร์ `failure`
    /// ตัวอย่างเช่น, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// เก็บค่าหากค่าปัจจุบันเหมือนกับค่า `old`
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `compare_exchange` โดยส่ง [`Ordering::Acquire`] เป็น `success` และ [`Ordering::Relaxed`] เป็นพารามิเตอร์ `failure`
    /// ตัวอย่างเช่น, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// เก็บค่าหากค่าปัจจุบันเหมือนกับค่า `old`
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `compare_exchange` โดยส่ง [`Ordering::AcqRel`] เป็น `success` และ [`Ordering::Relaxed`] เป็นพารามิเตอร์ `failure`
    /// ตัวอย่างเช่น, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// เก็บค่าหากค่าปัจจุบันเหมือนกับค่า `old`
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `compare_exchange_weak` โดยส่ง [`Ordering::SeqCst`] เป็นทั้งพารามิเตอร์ `success` และ `failure`
    ///
    /// ตัวอย่างเช่น, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// เก็บค่าหากค่าปัจจุบันเหมือนกับค่า `old`
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `compare_exchange_weak` โดยส่ง [`Ordering::Acquire`] เป็นทั้งพารามิเตอร์ `success` และ `failure`
    ///
    /// ตัวอย่างเช่น, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// เก็บค่าหากค่าปัจจุบันเหมือนกับค่า `old`
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `compare_exchange_weak` โดยส่ง [`Ordering::Release`] เป็น `success` และ [`Ordering::Relaxed`] เป็นพารามิเตอร์ `failure`
    /// ตัวอย่างเช่น, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// เก็บค่าหากค่าปัจจุบันเหมือนกับค่า `old`
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `compare_exchange_weak` โดยส่ง [`Ordering::AcqRel`] เป็น `success` และ [`Ordering::Acquire`] เป็นพารามิเตอร์ `failure`
    /// ตัวอย่างเช่น, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// เก็บค่าหากค่าปัจจุบันเหมือนกับค่า `old`
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `compare_exchange_weak` โดยส่ง [`Ordering::Relaxed`] เป็นทั้งพารามิเตอร์ `success` และ `failure`
    ///
    /// ตัวอย่างเช่น, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// เก็บค่าหากค่าปัจจุบันเหมือนกับค่า `old`
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `compare_exchange_weak` โดยส่ง [`Ordering::SeqCst`] เป็น `success` และ [`Ordering::Relaxed`] เป็นพารามิเตอร์ `failure`
    /// ตัวอย่างเช่น, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// เก็บค่าหากค่าปัจจุบันเหมือนกับค่า `old`
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `compare_exchange_weak` โดยส่ง [`Ordering::SeqCst`] เป็น `success` และ [`Ordering::Acquire`] เป็นพารามิเตอร์ `failure`
    /// ตัวอย่างเช่น, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// เก็บค่าหากค่าปัจจุบันเหมือนกับค่า `old`
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `compare_exchange_weak` โดยส่ง [`Ordering::Acquire`] เป็น `success` และ [`Ordering::Relaxed`] เป็นพารามิเตอร์ `failure`
    /// ตัวอย่างเช่น, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// เก็บค่าหากค่าปัจจุบันเหมือนกับค่า `old`
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `compare_exchange_weak` โดยส่ง [`Ordering::AcqRel`] เป็น `success` และ [`Ordering::Relaxed`] เป็นพารามิเตอร์ `failure`
    /// ตัวอย่างเช่น, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// โหลดค่าปัจจุบันของตัวชี้
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `load` โดยส่งผ่าน [`Ordering::SeqCst`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// โหลดค่าปัจจุบันของตัวชี้
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `load` โดยส่งผ่าน [`Ordering::Acquire`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// โหลดค่าปัจจุบันของตัวชี้
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `load` โดยส่งผ่าน [`Ordering::Relaxed`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// เก็บค่าที่ตำแหน่งหน่วยความจำที่ระบุ
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `store` โดยส่งผ่าน [`Ordering::SeqCst`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// เก็บค่าที่ตำแหน่งหน่วยความจำที่ระบุ
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `store` โดยส่งผ่าน [`Ordering::Release`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// เก็บค่าที่ตำแหน่งหน่วยความจำที่ระบุ
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `store` โดยส่งผ่าน [`Ordering::Relaxed`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// เก็บค่าไว้ที่ตำแหน่งหน่วยความจำที่ระบุโดยส่งคืนค่าเก่า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `swap` โดยส่งผ่าน [`Ordering::SeqCst`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// เก็บค่าไว้ที่ตำแหน่งหน่วยความจำที่ระบุโดยส่งคืนค่าเก่า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `swap` โดยส่งผ่าน [`Ordering::Acquire`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// เก็บค่าไว้ที่ตำแหน่งหน่วยความจำที่ระบุโดยส่งคืนค่าเก่า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `swap` โดยส่งผ่าน [`Ordering::Release`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// เก็บค่าไว้ที่ตำแหน่งหน่วยความจำที่ระบุโดยส่งคืนค่าเก่า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `swap` โดยส่งผ่าน [`Ordering::AcqRel`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// เก็บค่าไว้ที่ตำแหน่งหน่วยความจำที่ระบุโดยส่งคืนค่าเก่า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `swap` โดยส่งผ่าน [`Ordering::Relaxed`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// เพิ่มให้กับค่าปัจจุบันโดยส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_add` โดยส่งผ่าน [`Ordering::SeqCst`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// เพิ่มให้กับค่าปัจจุบันโดยส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_add` โดยส่ง [`Ordering::Acquire`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// เพิ่มให้กับค่าปัจจุบันโดยส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_add` โดยส่งผ่าน [`Ordering::Release`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// เพิ่มให้กับค่าปัจจุบันโดยส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_add` โดยส่งผ่าน [`Ordering::AcqRel`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// เพิ่มให้กับค่าปัจจุบันโดยส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_add` โดยส่งผ่าน [`Ordering::Relaxed`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ลบออกจากค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_sub` โดยส่งผ่าน [`Ordering::SeqCst`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// ลบออกจากค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_sub` โดยส่ง [`Ordering::Acquire`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ลบออกจากค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_sub` โดยส่งผ่าน [`Ordering::Release`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ลบออกจากค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_sub` โดยส่งผ่าน [`Ordering::AcqRel`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ลบออกจากค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_sub` โดยส่งผ่าน [`Ordering::Relaxed`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise และด้วยค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_and` โดยส่ง [`Ordering::SeqCst`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise และด้วยค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_and` โดยส่งผ่าน [`Ordering::Acquire`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise และด้วยค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_and` โดยส่งผ่าน [`Ordering::Release`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise และด้วยค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_and` โดยส่งผ่าน [`Ordering::AcqRel`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise และด้วยค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_and` โดยส่งผ่าน [`Ordering::Relaxed`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nand พร้อมค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`AtomicBool`] ผ่านวิธี `fetch_nand` โดยส่ง [`Ordering::SeqCst`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand พร้อมค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`AtomicBool`] ผ่านวิธี `fetch_nand` โดยส่ง [`Ordering::Acquire`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand พร้อมค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`AtomicBool`] ผ่านวิธี `fetch_nand` โดยส่ง [`Ordering::Release`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand พร้อมค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`AtomicBool`] ผ่านวิธี `fetch_nand` โดยส่ง [`Ordering::AcqRel`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand พร้อมค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`AtomicBool`] ผ่านวิธี `fetch_nand` โดยส่ง [`Ordering::Relaxed`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise หรือด้วยค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_or` โดยส่งผ่าน [`Ordering::SeqCst`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise หรือด้วยค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_or` โดยส่งผ่าน [`Ordering::Acquire`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise หรือด้วยค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_or` โดยส่งผ่าน [`Ordering::Release`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise หรือด้วยค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_or` โดยส่งผ่าน [`Ordering::AcqRel`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise หรือด้วยค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_or` โดยส่ง [`Ordering::Relaxed`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor ด้วยค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_xor` โดยส่งผ่าน [`Ordering::SeqCst`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor ด้วยค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_xor` โดยส่ง [`Ordering::Acquire`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor ด้วยค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_xor` โดยส่งผ่าน [`Ordering::Release`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor ด้วยค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_xor` โดยส่งผ่าน [`Ordering::AcqRel`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor ด้วยค่าปัจจุบันส่งคืนค่าก่อนหน้า
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภท [`atomic`] ผ่านวิธี `fetch_xor` โดยส่งผ่าน [`Ordering::Relaxed`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ค่าสูงสุดกับค่าปัจจุบันโดยใช้การเปรียบเทียบที่มีลายเซ็น
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในประเภทจำนวนเต็มที่ลงนาม [`atomic`] ผ่านวิธี `fetch_max` โดยส่งผ่าน [`Ordering::SeqCst`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// ค่าสูงสุดกับค่าปัจจุบันโดยใช้การเปรียบเทียบที่มีลายเซ็น
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในประเภทจำนวนเต็มที่ลงนาม [`atomic`] ผ่านวิธี `fetch_max` โดยส่งผ่าน [`Ordering::Acquire`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ค่าสูงสุดกับค่าปัจจุบันโดยใช้การเปรียบเทียบที่มีลายเซ็น
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในประเภทจำนวนเต็มที่ลงนาม [`atomic`] ผ่านวิธี `fetch_max` โดยส่งผ่าน [`Ordering::Release`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ค่าสูงสุดกับค่าปัจจุบันโดยใช้การเปรียบเทียบที่มีลายเซ็น
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในประเภทจำนวนเต็มที่ลงนาม [`atomic`] ผ่านวิธี `fetch_max` โดยส่งผ่าน [`Ordering::AcqRel`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// สูงสุดกับค่าปัจจุบัน
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในประเภทจำนวนเต็มที่ลงนาม [`atomic`] ผ่านวิธี `fetch_max` โดยส่งผ่าน [`Ordering::Relaxed`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ค่าต่ำสุดด้วยค่าปัจจุบันโดยใช้การเปรียบเทียบที่มีลายเซ็น
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในประเภทจำนวนเต็มที่ลงนาม [`atomic`] ผ่านวิธี `fetch_min` โดยส่งผ่าน [`Ordering::SeqCst`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// ค่าต่ำสุดด้วยค่าปัจจุบันโดยใช้การเปรียบเทียบที่มีลายเซ็น
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในประเภทจำนวนเต็มที่ลงนาม [`atomic`] ผ่านวิธี `fetch_min` โดยส่งผ่าน [`Ordering::Acquire`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ค่าต่ำสุดด้วยค่าปัจจุบันโดยใช้การเปรียบเทียบที่มีลายเซ็น
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในประเภทจำนวนเต็มที่ลงนาม [`atomic`] ผ่านวิธี `fetch_min` โดยส่งผ่าน [`Ordering::Release`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ค่าต่ำสุดด้วยค่าปัจจุบันโดยใช้การเปรียบเทียบที่มีลายเซ็น
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในประเภทจำนวนเต็มที่ลงนาม [`atomic`] ผ่านวิธี `fetch_min` โดยส่งผ่าน [`Ordering::AcqRel`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ค่าต่ำสุดด้วยค่าปัจจุบันโดยใช้การเปรียบเทียบที่มีลายเซ็น
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในประเภทจำนวนเต็มที่ลงนาม [`atomic`] ผ่านวิธี `fetch_min` โดยส่งผ่าน [`Ordering::Relaxed`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ต่ำสุดด้วยค่าปัจจุบันโดยใช้การเปรียบเทียบที่ไม่ได้ลงชื่อ
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภทจำนวนเต็ม [`atomic`] ที่ไม่ได้ลงชื่อผ่านวิธี `fetch_min` โดยส่งผ่าน [`Ordering::SeqCst`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// ต่ำสุดด้วยค่าปัจจุบันโดยใช้การเปรียบเทียบที่ไม่ได้ลงชื่อ
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภทจำนวนเต็ม [`atomic`] ที่ไม่ได้ลงชื่อผ่านวิธี `fetch_min` โดยส่งผ่าน [`Ordering::Acquire`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ต่ำสุดด้วยค่าปัจจุบันโดยใช้การเปรียบเทียบที่ไม่ได้ลงชื่อ
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภทจำนวนเต็ม [`atomic`] ที่ไม่ได้ลงชื่อผ่านวิธี `fetch_min` โดยส่งผ่าน [`Ordering::Release`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ต่ำสุดด้วยค่าปัจจุบันโดยใช้การเปรียบเทียบที่ไม่ได้ลงชื่อ
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภทจำนวนเต็ม [`atomic`] ที่ไม่ได้ลงชื่อผ่านวิธี `fetch_min` โดยส่งผ่าน [`Ordering::AcqRel`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ต่ำสุดด้วยค่าปัจจุบันโดยใช้การเปรียบเทียบที่ไม่ได้ลงชื่อ
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภทจำนวนเต็ม [`atomic`] ที่ไม่ได้ลงชื่อผ่านวิธี `fetch_min` โดยส่งผ่าน [`Ordering::Relaxed`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// สูงสุดกับค่าปัจจุบันโดยใช้การเปรียบเทียบที่ไม่ได้ลงชื่อ
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภทจำนวนเต็ม [`atomic`] ที่ไม่ได้ลงชื่อผ่านวิธี `fetch_max` โดยส่งผ่าน [`Ordering::SeqCst`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// สูงสุดกับค่าปัจจุบันโดยใช้การเปรียบเทียบที่ไม่ได้ลงชื่อ
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภทจำนวนเต็ม [`atomic`] ที่ไม่ได้ลงชื่อผ่านวิธี `fetch_max` โดยส่งผ่าน [`Ordering::Acquire`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// สูงสุดกับค่าปัจจุบันโดยใช้การเปรียบเทียบที่ไม่ได้ลงชื่อ
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภทจำนวนเต็ม [`atomic`] ที่ไม่ได้ลงชื่อผ่านวิธี `fetch_max` โดยส่งผ่าน [`Ordering::Release`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// สูงสุดกับค่าปัจจุบันโดยใช้การเปรียบเทียบที่ไม่ได้ลงชื่อ
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภทจำนวนเต็ม [`atomic`] ที่ไม่ได้ลงชื่อผ่านวิธี `fetch_max` โดยส่งผ่าน [`Ordering::AcqRel`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// สูงสุดกับค่าปัจจุบันโดยใช้การเปรียบเทียบที่ไม่ได้ลงชื่อ
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ในประเภทจำนวนเต็ม [`atomic`] ที่ไม่ได้ลงชื่อผ่านวิธี `fetch_max` โดยส่งผ่าน [`Ordering::Relaxed`] เป็น `order`
    /// ตัวอย่างเช่น, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` intrinsic เป็นคำแนะนำสำหรับตัวสร้างโค้ดเพื่อแทรกคำสั่งการดึงข้อมูลล่วงหน้าหากได้รับการสนับสนุนมิฉะนั้นจะเป็นการไม่ดำเนินการ
    /// การตั้งค่าล่วงหน้าไม่มีผลต่อลักษณะการทำงานของโปรแกรม แต่สามารถเปลี่ยนลักษณะการทำงานได้
    ///
    /// อาร์กิวเมนต์ `locality` ต้องเป็นจำนวนเต็มคงที่และเป็นตัวระบุตำแหน่งชั่วคราวตั้งแต่ (0) ไม่มีโลคัลไปจนถึง (3) เก็บในแคช
    ///
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` intrinsic เป็นคำแนะนำสำหรับตัวสร้างโค้ดเพื่อแทรกคำสั่งการดึงข้อมูลล่วงหน้าหากได้รับการสนับสนุนมิฉะนั้นจะเป็นการไม่ดำเนินการ
    /// การตั้งค่าล่วงหน้าไม่มีผลต่อลักษณะการทำงานของโปรแกรม แต่สามารถเปลี่ยนลักษณะการทำงานได้
    ///
    /// อาร์กิวเมนต์ `locality` ต้องเป็นจำนวนเต็มคงที่และเป็นตัวระบุตำแหน่งชั่วคราวตั้งแต่ (0) ไม่มีโลคัลไปจนถึง (3) เก็บในแคช
    ///
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` intrinsic เป็นคำแนะนำสำหรับตัวสร้างโค้ดเพื่อแทรกคำสั่งการดึงข้อมูลล่วงหน้าหากได้รับการสนับสนุนมิฉะนั้นจะเป็นการไม่ดำเนินการ
    /// การตั้งค่าล่วงหน้าไม่มีผลต่อลักษณะการทำงานของโปรแกรม แต่สามารถเปลี่ยนลักษณะการทำงานได้
    ///
    /// อาร์กิวเมนต์ `locality` ต้องเป็นจำนวนเต็มคงที่และเป็นตัวระบุตำแหน่งชั่วคราวตั้งแต่ (0) ไม่มีโลคัลไปจนถึง (3) เก็บในแคช
    ///
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` intrinsic เป็นคำแนะนำสำหรับตัวสร้างโค้ดเพื่อแทรกคำสั่งการดึงข้อมูลล่วงหน้าหากได้รับการสนับสนุนมิฉะนั้นจะเป็นการไม่ดำเนินการ
    /// การตั้งค่าล่วงหน้าไม่มีผลต่อลักษณะการทำงานของโปรแกรม แต่สามารถเปลี่ยนลักษณะการทำงานได้
    ///
    /// อาร์กิวเมนต์ `locality` ต้องเป็นจำนวนเต็มคงที่และเป็นตัวระบุตำแหน่งชั่วคราวตั้งแต่ (0) ไม่มีโลคัลไปจนถึง (3) เก็บในแคช
    ///
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// รั้วอะตอม
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ใน [`atomic::fence`] โดยส่ง [`Ordering::SeqCst`] เป็น `order`
    ///
    ///
    pub fn atomic_fence();
    /// รั้วอะตอม
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ใน [`atomic::fence`] โดยส่ง [`Ordering::Acquire`] เป็น `order`
    ///
    ///
    pub fn atomic_fence_acq();
    /// รั้วอะตอม
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ใน [`atomic::fence`] โดยส่ง [`Ordering::Release`] เป็น `order`
    ///
    ///
    pub fn atomic_fence_rel();
    /// รั้วอะตอม
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ใน [`atomic::fence`] โดยส่ง [`Ordering::AcqRel`] เป็น `order`
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// อุปสรรคหน่วยความจำคอมไพเลอร์เท่านั้น
    ///
    /// การเข้าถึงหน่วยความจำจะไม่ถูกเรียงลำดับใหม่ข้ามอุปสรรคนี้โดยคอมไพเลอร์ แต่จะไม่มีการแสดงคำสั่งใด ๆ
    /// สิ่งนี้เหมาะสำหรับการดำเนินการบนเธรดเดียวกันที่อาจถูกจองไว้ล่วงหน้าเช่นเมื่อโต้ตอบกับตัวจัดการสัญญาณ
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ใน [`atomic::compiler_fence`] โดยส่ง [`Ordering::SeqCst`] เป็น `order`
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// อุปสรรคหน่วยความจำคอมไพเลอร์เท่านั้น
    ///
    /// การเข้าถึงหน่วยความจำจะไม่ถูกเรียงลำดับใหม่ข้ามอุปสรรคนี้โดยคอมไพเลอร์ แต่จะไม่มีการแสดงคำสั่งใด ๆ
    /// สิ่งนี้เหมาะสำหรับการดำเนินการบนเธรดเดียวกันที่อาจถูกจองไว้ล่วงหน้าเช่นเมื่อโต้ตอบกับตัวจัดการสัญญาณ
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ใน [`atomic::compiler_fence`] โดยส่ง [`Ordering::Acquire`] เป็น `order`
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// อุปสรรคหน่วยความจำคอมไพเลอร์เท่านั้น
    ///
    /// การเข้าถึงหน่วยความจำจะไม่ถูกเรียงลำดับใหม่ข้ามอุปสรรคนี้โดยคอมไพเลอร์ แต่จะไม่มีการแสดงคำสั่งใด ๆ
    /// สิ่งนี้เหมาะสำหรับการดำเนินการบนเธรดเดียวกันที่อาจถูกจองไว้ล่วงหน้าเช่นเมื่อโต้ตอบกับตัวจัดการสัญญาณ
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ใน [`atomic::compiler_fence`] โดยส่ง [`Ordering::Release`] เป็น `order`
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// อุปสรรคหน่วยความจำคอมไพเลอร์เท่านั้น
    ///
    /// การเข้าถึงหน่วยความจำจะไม่ถูกเรียงลำดับใหม่ข้ามอุปสรรคนี้โดยคอมไพเลอร์ แต่จะไม่มีการแสดงคำสั่งใด ๆ
    /// สิ่งนี้เหมาะสำหรับการดำเนินการบนเธรดเดียวกันที่อาจถูกจองไว้ล่วงหน้าเช่นเมื่อโต้ตอบกับตัวจัดการสัญญาณ
    ///
    /// เวอร์ชันที่เสถียรของภายในนี้มีอยู่ใน [`atomic::compiler_fence`] โดยส่ง [`Ordering::AcqRel`] เป็น `order`
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magic Intrinsic ที่ได้รับความหมายจากคุณลักษณะที่แนบมากับฟังก์ชัน
    ///
    /// ตัวอย่างเช่นกระแสข้อมูลจะใช้สิ่งนี้เพื่อแทรกการยืนยันแบบคงที่เพื่อให้ `rustc_peek(potentially_uninitialized)` ตรวจสอบอีกครั้งว่ากระแสข้อมูลได้คำนวณว่ากระแสข้อมูลไม่ได้เริ่มต้น ณ จุดนั้นในโฟลว์การควบคุม
    ///
    ///
    /// ไม่ควรใช้ภายในนี้ภายนอกคอมไพเลอร์
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// ยกเลิกการดำเนินการของกระบวนการ
    ///
    /// เวอร์ชันที่ใช้งานง่ายและเสถียรกว่าของการดำเนินการนี้คือ [`std::process::abort`](../../std/process/fn.abort.html)
    ///
    pub fn abort() -> !;

    /// แจ้งเครื่องมือเพิ่มประสิทธิภาพว่าไม่สามารถเข้าถึงจุดนี้ในโค้ดได้จึงเปิดใช้งานการเพิ่มประสิทธิภาพเพิ่มเติม
    ///
    /// หมายเหตุสิ่งนี้แตกต่างจากมาโคร `unreachable!()` มาก: ต่างจากมาโครซึ่ง panics เมื่อเรียกใช้งานคือ *พฤติกรรมที่ไม่ได้กำหนด* เพื่อเข้าถึงโค้ดที่ทำเครื่องหมายด้วยฟังก์ชันนี้
    ///
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked)
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// แจ้งเครื่องมือเพิ่มประสิทธิภาพว่าเงื่อนไขเป็นจริงเสมอ
    /// หากเงื่อนไขเป็นเท็จแสดงว่าไม่ได้กำหนดลักษณะการทำงาน
    ///
    /// ไม่มีการสร้างรหัสสำหรับภายในนี้ แต่เครื่องมือเพิ่มประสิทธิภาพจะพยายามรักษา (และสภาพของมัน) ระหว่างการส่งผ่านซึ่งอาจรบกวนการเพิ่มประสิทธิภาพของโค้ดโดยรอบและลดประสิทธิภาพ
    /// ไม่ควรใช้หากเครื่องมือเพิ่มประสิทธิภาพสามารถค้นพบค่าคงที่โดยตัวมันเองหรือไม่ได้เปิดใช้งานการเพิ่มประสิทธิภาพที่สำคัญใด ๆ
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// บอกใบ้คอมไพเลอร์ว่าเงื่อนไข branch น่าจะเป็นจริง
    /// ส่งคืนค่าที่ส่งไป
    ///
    /// การใช้งานอื่น ๆ นอกเหนือจากคำสั่ง `if` อาจไม่มีผล
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// บอกใบ้คอมไพเลอร์ว่าเงื่อนไข branch น่าจะเป็นเท็จ
    /// ส่งคืนค่าที่ส่งไป
    ///
    /// การใช้งานอื่น ๆ นอกเหนือจากคำสั่ง `if` อาจไม่มีผล
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// เรียกใช้กับดักเบรกพอยต์สำหรับการตรวจสอบโดยดีบักเกอร์
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    pub fn breakpoint();

    /// ขนาดของประเภทเป็นไบต์
    ///
    /// โดยเฉพาะอย่างยิ่งนี่คือการชดเชยเป็นไบต์ระหว่างรายการที่ต่อเนื่องกันในประเภทเดียวกันรวมถึงช่องว่างในการจัดตำแหน่ง
    ///
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ [`core::mem::size_of`](crate::mem::size_of)
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// การจัดตำแหน่งต่ำสุดของประเภท
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ [`core::mem::align_of`](crate::mem::align_of)
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// การจัดตำแหน่งที่ต้องการของประเภท
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// ขนาดของค่าที่อ้างอิงเป็นไบต์
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ [`mem::size_of_val`]
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// การจัดตำแหน่งที่ต้องการของค่าที่อ้างอิง
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ [`core::mem::align_of_val`](crate::mem::align_of_val)
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// รับส่วนสตริงแบบคงที่ที่มีชื่อของชนิด
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ [`core::any::type_name`](crate::any::type_name)
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// รับตัวระบุซึ่งไม่ซ้ำกันทั่วโลกสำหรับประเภทที่ระบุ
    /// ฟังก์ชันนี้จะส่งคืนค่าเดียวกันสำหรับประเภทไม่ว่าจะเรียกใช้ crate แบบใดก็ตาม
    ///
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ [`core::any::TypeId::of`](crate::any::TypeId::of)
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// ตัวป้องกันสำหรับฟังก์ชันที่ไม่ปลอดภัยที่ไม่สามารถดำเนินการได้หาก `T` ไม่มีใครอยู่:
    /// สิ่งนี้จะคงที่ทั้ง panic หรือไม่ทำอะไรเลย
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// ตัวป้องกันสำหรับฟังก์ชันที่ไม่ปลอดภัยที่ไม่สามารถดำเนินการได้หาก `T` ไม่อนุญาตให้มีการเริ่มต้นเป็นศูนย์: สิ่งนี้จะเป็นแบบคงที่ไม่ว่าจะเป็น panic หรือไม่ทำอะไรเลย
    ///
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    pub fn assert_zero_valid<T>();

    /// การป้องกันสำหรับฟังก์ชันที่ไม่ปลอดภัยที่ไม่สามารถดำเนินการได้หาก `T` มีรูปแบบบิตที่ไม่ถูกต้อง: สิ่งนี้จะเป็นแบบคงที่ทั้ง panic หรือไม่ทำอะไรเลย
    ///
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    pub fn assert_uninit_valid<T>();

    /// รับการอ้างอิงไปยัง `Location` แบบคงที่เพื่อระบุตำแหน่งที่ถูกเรียก
    ///
    /// ลองใช้ [`core::panic::Location::caller`](crate::panic::Location::caller) แทน
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// ย้ายค่าออกนอกขอบเขตโดยไม่ต้องใช้กาวหยด
    ///
    /// สิ่งนี้มีอยู่สำหรับ [`mem::forget_unsized`] เท่านั้น `forget` ปกติใช้ `ManuallyDrop` แทน
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// ตีความบิตของค่าประเภทหนึ่งเป็นอีกประเภทหนึ่ง
    ///
    /// ทั้งสองประเภทต้องมีขนาดเท่ากัน
    /// ทั้งต้นฉบับหรือผลลัพธ์อาจไม่ใช่ [invalid value](../../nomicon/what-unsafe-does.html)
    ///
    /// `transmute` มีความหมายเทียบเท่ากับการย้ายประเภทหนึ่งไปยังอีกประเภทหนึ่งในระดับบิตมันคัดลอกบิตจากค่าต้นทางไปยังค่าปลายทางจากนั้นลืมต้นฉบับ
    /// เทียบเท่ากับ `memcpy` ของ C ภายใต้ประทุนเช่นเดียวกับ `transmute_copy`
    ///
    /// เนื่องจาก `transmute` เป็นการดำเนินการทีละค่าการจัดแนวของ *ค่าที่แปลงด้วยตัวเอง* จึงไม่น่ากังวล
    /// เช่นเดียวกับฟังก์ชั่นอื่น ๆ คอมไพเลอร์มั่นใจแล้วว่าทั้ง `T` และ `U` อยู่ในแนวเดียวกัน
    /// อย่างไรก็ตามเมื่อส่งค่าที่ *ชี้ไปที่อื่น*(เช่นพอยน์เตอร์การอ้างอิงกล่อง ...) ผู้เรียกต้องแน่ใจว่ามีการจัดแนวของค่าที่ชี้ไปที่ถูกต้อง
    ///
    /// `transmute` เป็นสิ่งที่ไม่ปลอดภัยอย่างเหลือเชื่อ **มีหลายวิธีในการทำให้เกิด [undefined behavior][ub] ด้วยฟังก์ชันนี้ `transmute` ควรเป็นทางเลือกสุดท้ายที่แท้จริง
    ///
    /// [nomicon](../../nomicon/transmutes.html) มีเอกสารเพิ่มเติม
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// มีบางสิ่งที่ `transmute` มีประโยชน์จริงๆ
    ///
    /// การเปลี่ยนตัวชี้เป็นตัวชี้ฟังก์ชันนี่คือ *ไม่* พกพาไปยังเครื่องที่ตัวชี้ฟังก์ชันและตัวชี้ข้อมูลมีขนาดต่างกัน
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// การยืดอายุการใช้งานหรือการลดอายุการใช้งานที่ไม่แน่นอนนี่เป็นขั้นสูง Rust ที่ไม่ปลอดภัยมาก!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// อย่าสิ้นหวัง: การใช้ `transmute` จำนวนมากสามารถทำได้ด้วยวิธีอื่น
    /// ด้านล่างนี้คือแอปพลิเคชันทั่วไปของ `transmute` ซึ่งสามารถแทนที่ด้วยโครงสร้างที่ปลอดภัยกว่า
    ///
    /// เปลี่ยน bytes(`&[u8]`) ดิบเป็น `u32`, `f64` ฯลฯ :
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // ใช้ `u32::from_ne_bytes` แทน
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // หรือใช้ `u32::from_le_bytes` หรือ `u32::from_be_bytes` เพื่อระบุ endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// การเปลี่ยนตัวชี้เป็น `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // ใช้ `as` cast แทน
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// การเปลี่ยน `*mut T` ให้เป็น `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // ใช้ reborrow แทน
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// การเปลี่ยน `&mut T` ให้เป็น `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // ตอนนี้รวบรวม `as` และการสร้างใหม่โปรดทราบว่าการเชื่อมโยงของ `as` `as` ไม่ใช่สกรรมกริยา
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// การเปลี่ยน `&str` ให้เป็น `&[u8]`:
    ///
    /// ```
    /// // นี่ไม่ใช่วิธีที่ดีในการทำเช่นนี้
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // คุณสามารถใช้ `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // หรือใช้สตริงไบต์ถ้าคุณสามารถควบคุมสตริงลิเทอรัลได้
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// เปลี่ยน `Vec<&T>` ให้เป็น `Vec<Option<&T>>`
    ///
    /// ในการเปลี่ยนประเภทภายในของเนื้อหาของคอนเทนเนอร์คุณต้องตรวจสอบให้แน่ใจว่าไม่ได้ละเมิดค่าคงที่ใด ๆ ของคอนเทนเนอร์
    /// สำหรับ `Vec` หมายความว่าทั้งขนาด *และการจัดตำแหน่ง* ของประเภทด้านในต้องตรงกัน
    /// คอนเทนเนอร์อื่น ๆ อาจขึ้นอยู่กับขนาดของประเภทการจัดตำแหน่งหรือแม้แต่ `TypeId` ซึ่งในกรณีนี้การส่งข้อมูลจะเป็นไปไม่ได้เลยหากไม่ละเมิดค่าคงที่ของคอนเทนเนอร์
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // โคลน vector เนื่องจากเราจะนำมาใช้ใหม่ในภายหลัง
    /// let v_clone = v_orig.clone();
    ///
    /// // การใช้การแปลงสัญญาณ: สิ่งนี้อาศัยเค้าโครงข้อมูลที่ไม่ระบุของ `Vec` ซึ่งเป็นความคิดที่ไม่ดีและอาจทำให้เกิดพฤติกรรมที่ไม่ได้กำหนด
    /////
    /// // อย่างไรก็ตามไม่มีการคัดลอก
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // นี่คือวิธีที่ปลอดภัยที่แนะนำ
    /// // จะคัดลอก vector ทั้งหมดลงในอาร์เรย์ใหม่
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // นี่เป็นวิธีการไม่คัดลอกที่เหมาะสมและไม่ปลอดภัยของ "transmuting" a `Vec` โดยไม่ต้องอาศัยเค้าโครงข้อมูล
    /// // แทนที่จะเรียก `transmute` อย่างแท้จริงเราใช้ตัวชี้ แต่ในแง่ของการแปลง (`&i32`) ประเภทภายในดั้งเดิมเป็น (`Option<&i32>`) ใหม่สิ่งนี้มีข้อแม้เหมือนกันทั้งหมด
    /////
    /// // นอกเหนือจากข้อมูลที่ให้ไว้ข้างต้นโปรดดูเอกสาร [`from_raw_parts`]
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME อัปเดตสิ่งนี้เมื่อ vec_into_raw_parts เสถียร
    ///     // ตรวจสอบให้แน่ใจว่า vector เดิมไม่ตกหล่น
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// การติดตั้ง `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // มีหลายวิธีในการดำเนินการนี้และมีปัญหาหลายประการเกี่ยวกับวิธี (transmute) ต่อไปนี้
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // ประการแรก: การส่งสัญญาณไม่ใช่ประเภทที่ปลอดภัยทั้งหมดที่ตรวจสอบคือ T และ
    ///         // คุณมีขนาดเท่ากัน
    ///         // ประการที่สองตรงนี้คุณมีการอ้างอิงที่ไม่แน่นอนสองรายการซึ่งชี้ไปที่หน่วยความจำเดียวกัน
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // สิ่งนี้จะกำจัดปัญหาด้านความปลอดภัยประเภท;`&mut *` จะ* เท่านั้น *ให้ `&mut T` จาก `&mut T` หรือ `* mut T`
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // อย่างไรก็ตามคุณยังคงมีการอ้างอิงที่ไม่แน่นอนสองรายการที่ชี้ไปที่หน่วยความจำเดียวกัน
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // นี่คือวิธีที่ไลบรารีมาตรฐานทำ
    /// // นี่เป็นวิธีที่ดีที่สุดหากคุณจำเป็นต้องทำสิ่งนี้
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // ตอนนี้มีการอ้างอิงที่เปลี่ยนแปลงได้สามรายการที่ชี้ไปที่หน่วยความจำเดียวกัน `slice`, rvalue ret.0 และ rvalue ret.1
    ///         // `slice` ไม่เคยใช้หลังจาก `let ptr = ...` ดังนั้นจึงสามารถถือว่าเป็น "dead" ได้ดังนั้นคุณจึงมีชิ้นส่วนที่เปลี่ยนแปลงได้จริงเพียงสองชิ้น
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: แม้ว่าสิ่งนี้จะทำให้ const ที่อยู่ภายในคงที่ แต่เรามีโค้ดที่กำหนดเองใน const fn
    // ตรวจสอบว่าป้องกันการใช้งานภายใน `const fn`
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// ส่งคืน `true` หากประเภทจริงที่ระบุเป็น `T` ต้องใช้กาวหยดส่งคืน `false` หากประเภทจริงที่จัดเตรียมไว้สำหรับ `T` ใช้ `Copy`
    ///
    ///
    /// หากประเภทจริงไม่ต้องใช้กาวหยอดหรือใช้ `Copy` ค่าส่งคืนของฟังก์ชันนี้จะไม่ระบุ
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ [`mem::needs_drop`](crate::mem::needs_drop)
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// คำนวณค่าชดเชยจากตัวชี้
    ///
    /// สิ่งนี้ถูกนำไปใช้เป็นเนื้อแท้เพื่อหลีกเลี่ยงการแปลงเป็นและจากจำนวนเต็มเนื่องจากการแปลงจะทำให้ข้อมูลนามแฝงทิ้งไป
    ///
    /// # Safety
    ///
    /// ทั้งตัวชี้เริ่มต้นและผลลัพธ์ต้องอยู่ในขอบเขตหรือหนึ่งไบต์เลยจุดสิ้นสุดของอ็อบเจ็กต์ที่จัดสรร
    /// หากตัวชี้อยู่นอกขอบเขตหรือเกิดการล้นทางคณิตศาสตร์การใช้ค่าที่ส่งคืนต่อไปจะส่งผลให้เกิดพฤติกรรมที่ไม่ได้กำหนดไว้
    ///
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ [`pointer::offset`]
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// คำนวณค่าชดเชยจากตัวชี้ซึ่งอาจเกิดการตัด
    ///
    /// สิ่งนี้ถูกนำไปใช้เป็นเนื้อแท้เพื่อหลีกเลี่ยงการแปลงเป็นและจากจำนวนเต็มเนื่องจากการแปลงขัดขวางการเพิ่มประสิทธิภาพบางอย่าง
    ///
    /// # Safety
    ///
    /// ไม่เหมือนกับ `offset` ที่อยู่ภายในเนื้อแท้นี้ไม่ได้ จำกัด ตัวชี้ที่เป็นผลลัพธ์ให้ชี้เข้าไปหรือหนึ่งไบต์เลยจุดสิ้นสุดของอ็อบเจ็กต์ที่จัดสรรไว้และจะล้อมรอบด้วยเลขคณิตเสริมสองตัว
    /// ค่าผลลัพธ์ไม่จำเป็นต้องถูกใช้เพื่อเข้าถึงหน่วยความจำจริง
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ [`pointer::wrapping_offset`]
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// เทียบเท่ากับ `llvm.memcpy.p0i8.0i8.*` intrinsic ที่เหมาะสมโดยมีขนาด `count`*`size_of::<T>()` และการจัดตำแหน่ง
    ///
    /// `min_align_of::<T>()`
    ///
    /// พารามิเตอร์ระเหยถูกตั้งค่าเป็น `true` ดังนั้นจะไม่ถูกปรับให้เหมาะสมเว้นแต่ขนาดจะเท่ากับศูนย์
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// เทียบเท่ากับ `llvm.memmove.p0i8.0i8.*` intrinsic ที่เหมาะสมโดยมีขนาด `count* size_of::<T>()` และการจัดตำแหน่ง
    ///
    /// `min_align_of::<T>()`
    ///
    /// พารามิเตอร์ระเหยถูกตั้งค่าเป็น `true` ดังนั้นจะไม่ถูกปรับให้เหมาะสมเว้นแต่ขนาดจะเท่ากับศูนย์
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// เทียบเท่ากับ `llvm.memset.p0i8.*` intrinsic ที่เหมาะสมโดยมีขนาด `count* size_of::<T>()` และการจัดตำแหน่ง `min_align_of::<T>()`
    ///
    ///
    /// พารามิเตอร์ระเหยถูกตั้งค่าเป็น `true` ดังนั้นจะไม่ถูกปรับให้เหมาะสมเว้นแต่ขนาดจะเท่ากับศูนย์
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// ทำการโหลดแบบระเหยจากตัวชี้ `src`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ [`core::ptr::read_volatile`](crate::ptr::read_volatile)
    pub fn volatile_load<T>(src: *const T) -> T;
    /// ดำเนินการจัดเก็บแบบระเหยไปยังตัวชี้ `dst`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ [`core::ptr::write_volatile`](crate::ptr::write_volatile)
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// ทำการโหลดแบบระเหยจากตัวชี้ `src` ไม่จำเป็นต้องจัดตำแหน่งตัวชี้
    ///
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// ดำเนินการจัดเก็บแบบระเหยไปยังตัวชี้ `dst`
    /// ไม่จำเป็นต้องจัดตำแหน่งตัวชี้
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// ส่งคืนค่ารากที่สองของ `f32`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// ส่งคืนค่ารากที่สองของ `f64`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// ยก `f32` เป็นเลขจำนวนเต็ม
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// ยก `f64` เป็นเลขจำนวนเต็ม
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// ส่งคืนไซน์ของ `f32`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// ส่งคืนไซน์ของ `f64`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// ส่งคืนโคไซน์ของ `f32`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// ส่งคืนโคไซน์ของ `f64`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// เพิ่ม `f32` เป็น `f32`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// เพิ่ม `f64` เป็น `f64`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// ส่งคืนเลขชี้กำลังของ `f32`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// ส่งคืนเลขชี้กำลังของ `f64`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// ส่งคืน 2 ยกกำลัง `f32`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// ส่งคืน 2 ยกกำลัง `f64`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// ส่งคืนลอการิทึมธรรมชาติของ `f32`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// ส่งคืนลอการิทึมธรรมชาติของ `f64`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// ส่งคืนลอการิทึมฐาน 10 ของ `f32`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// ส่งคืนลอการิทึมฐาน 10 ของ `f64`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// ส่งคืนลอการิทึมฐาน 2 ของ `f32`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// ส่งคืนลอการิทึมฐาน 2 ของ `f64`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// ส่งคืนค่า `a * b + c` สำหรับค่า `f32`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// ส่งคืนค่า `a * b + c` สำหรับค่า `f64`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// ส่งคืนค่าสัมบูรณ์ของ `f32`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// ส่งคืนค่าสัมบูรณ์ของ `f64`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// ส่งคืนค่า `f32` ขั้นต่ำสองค่า
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// ส่งคืนค่า `f64` ขั้นต่ำสองค่า
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// ส่งคืนค่า `f32` สูงสุดสองค่า
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// ส่งคืนค่า `f64` สูงสุดสองค่า
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// คัดลอกเครื่องหมายจาก `y` ถึง `x` สำหรับค่า `f32`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// คัดลอกเครื่องหมายจาก `y` ถึง `x` สำหรับค่า `f64`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// ส่งคืนจำนวนเต็มที่มากที่สุดน้อยกว่าหรือเท่ากับ `f32`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// ส่งคืนจำนวนเต็มที่มากที่สุดน้อยกว่าหรือเท่ากับ `f64`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// ส่งคืนจำนวนเต็มที่น้อยที่สุดที่มากกว่าหรือเท่ากับ `f32`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// ส่งคืนจำนวนเต็มที่น้อยที่สุดที่มากกว่าหรือเท่ากับ `f64`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// ส่งคืนส่วนจำนวนเต็มของ `f32`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// ส่งคืนส่วนจำนวนเต็มของ `f64`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// ส่งคืนจำนวนเต็มที่ใกล้ที่สุดเป็น `f32`
    /// อาจเพิ่มข้อยกเว้นทศนิยมที่ไม่แน่นอนหากอาร์กิวเมนต์ไม่ใช่จำนวนเต็ม
    pub fn rintf32(x: f32) -> f32;
    /// ส่งคืนจำนวนเต็มที่ใกล้ที่สุดเป็น `f64`
    /// อาจเพิ่มข้อยกเว้นทศนิยมที่ไม่แน่นอนหากอาร์กิวเมนต์ไม่ใช่จำนวนเต็ม
    pub fn rintf64(x: f64) -> f64;

    /// ส่งคืนจำนวนเต็มที่ใกล้ที่สุดเป็น `f32`
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    pub fn nearbyintf32(x: f32) -> f32;
    /// ส่งคืนจำนวนเต็มที่ใกล้ที่สุดเป็น `f64`
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    pub fn nearbyintf64(x: f64) -> f64;

    /// ส่งคืนจำนวนเต็มที่ใกล้ที่สุดเป็น `f32` ปัดเศษกรณีครึ่งทางให้ห่างจากศูนย์
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// ส่งคืนจำนวนเต็มที่ใกล้ที่สุดเป็น `f64` ปัดเศษกรณีครึ่งทางให้ห่างจากศูนย์
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// การเพิ่มแบบลอยตัวที่อนุญาตให้มีการปรับให้เหมาะสมตามกฎพีชคณิต
    /// อาจถือว่าปัจจัยการผลิตมีจำนวน จำกัด
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// การลบแบบลอยที่อนุญาตให้มีการปรับให้เหมาะสมตามกฎพีชคณิต
    /// อาจถือว่าปัจจัยการผลิตมีจำนวน จำกัด
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// การคูณแบบลอยตัวที่อนุญาตให้มีการเพิ่มประสิทธิภาพตามกฎพีชคณิต
    /// อาจถือว่าปัจจัยการผลิตมีจำนวน จำกัด
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// การแบ่งลอยที่ช่วยให้สามารถปรับให้เหมาะสมตามกฎพีชคณิต
    /// อาจถือว่าปัจจัยการผลิตมีจำนวน จำกัด
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// ส่วนที่เหลือลอยที่อนุญาตให้เพิ่มประสิทธิภาพตามกฎพีชคณิต
    /// อาจถือว่าปัจจัยการผลิตมีจำนวน จำกัด
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// แปลงด้วย fptoui/fptosi ของ LLVM ซึ่งอาจส่งคืนค่า undef สำหรับค่าที่อยู่นอกช่วง
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// เสถียรเท่ากับ [`f32::to_int_unchecked`] และ [`f64::to_int_unchecked`]
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// ส่งคืนจำนวนบิตที่กำหนดในประเภทจำนวนเต็ม `T`
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในไพรมารีจำนวนเต็มผ่านวิธี `count_ones`
    /// ตัวอย่างเช่น,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// ส่งคืนจำนวนของบิตที่ไม่ได้ตั้งค่านำหน้า (zeroes) ในประเภทจำนวนเต็ม `T`
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในไพรมารีจำนวนเต็มผ่านวิธี `leading_zeros`
    /// ตัวอย่างเช่น,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` ที่มีค่า `0` จะส่งกลับความกว้างบิตเป็น `T`
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// เช่นเดียวกับ `ctlz` แต่ไม่ปลอดภัยเป็นพิเศษเนื่องจากส่งคืน `undef` เมื่อกำหนด `x` ที่มีค่า `0`
    ///
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// ส่งคืนจำนวนบิตที่ไม่ได้ตั้งค่าต่อท้าย (zeroes) ในประเภทจำนวนเต็ม `T`
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในไพรมารีจำนวนเต็มผ่านวิธี `trailing_zeros`
    /// ตัวอย่างเช่น,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` ที่มีค่า `0` จะคืนค่าความกว้างบิตเป็น `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// เช่นเดียวกับ `cttz` แต่ไม่ปลอดภัยเป็นพิเศษเนื่องจากส่งคืน `undef` เมื่อกำหนด `x` ที่มีค่า `0`
    ///
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// กลับไบต์ในประเภทจำนวนเต็ม `T`
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในไพรมารีจำนวนเต็มผ่านวิธี `swap_bytes`
    /// ตัวอย่างเช่น,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// กลับบิตในประเภทจำนวนเต็ม `T`
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในไพรมารีจำนวนเต็มผ่านวิธี `reverse_bits`
    /// ตัวอย่างเช่น,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// ทำการตรวจสอบการบวกจำนวนเต็ม
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในไพรมารีจำนวนเต็มผ่านวิธี `overflowing_add`
    /// ตัวอย่างเช่น,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// ทำการลบจำนวนเต็มที่ตรวจสอบแล้ว
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในไพรมารีจำนวนเต็มผ่านวิธี `overflowing_sub`
    /// ตัวอย่างเช่น,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// ทำการคูณจำนวนเต็มที่ตรวจสอบแล้ว
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในไพรมารีจำนวนเต็มผ่านวิธี `overflowing_mul`
    /// ตัวอย่างเช่น,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// ทำการหารที่แน่นอนทำให้เกิดพฤติกรรมที่ไม่ได้กำหนดโดยที่ `x % y != 0` หรือ `y == 0` หรือ `x == T::MIN && y == -1`
    ///
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// ดำเนินการหารที่ไม่ถูกตรวจสอบทำให้เกิดพฤติกรรมที่ไม่ได้กำหนดโดยที่ `y == 0` หรือ `x == T::MIN && y == -1`
    ///
    ///
    /// การห่อหุ้มที่ปลอดภัยสำหรับเนื้อแท้นี้มีอยู่ในไพรมารีจำนวนเต็มผ่านวิธี `checked_div`
    /// ตัวอย่างเช่น,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// ส่งคืนส่วนที่เหลือของการหารที่ไม่ถูกตรวจสอบทำให้เกิดพฤติกรรมที่ไม่ได้กำหนดเมื่อ `y == 0` หรือ `x == T::MIN && y == -1`
    ///
    ///
    /// การห่อหุ้มที่ปลอดภัยสำหรับเนื้อแท้นี้มีอยู่ในไพรมารีจำนวนเต็มผ่านวิธี `checked_rem`
    /// ตัวอย่างเช่น,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// ดำเนินการกะทางซ้ายที่ไม่ได้เลือกส่งผลให้เกิดพฤติกรรมที่ไม่ได้กำหนดเมื่อ `y < 0` หรือ `y >= N` โดยที่ N คือความกว้างของ T ในหน่วยบิต
    ///
    ///
    /// การห่อหุ้มที่ปลอดภัยสำหรับเนื้อแท้นี้มีอยู่ในไพรมารีจำนวนเต็มผ่านวิธี `checked_shl`
    /// ตัวอย่างเช่น,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// ดำเนินการกะทางขวาที่ไม่ถูกเลือกส่งผลให้เกิดพฤติกรรมที่ไม่ได้กำหนดเมื่อ `y < 0` หรือ `y >= N` โดยที่ N คือความกว้างของ T ในหน่วยบิต
    ///
    ///
    /// การห่อหุ้มที่ปลอดภัยสำหรับเนื้อแท้นี้มีอยู่ในไพรมารีจำนวนเต็มผ่านวิธี `checked_shr`
    /// ตัวอย่างเช่น,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// ส่งคืนผลลัพธ์ของการเพิ่มที่ไม่ได้เลือกส่งผลให้เกิดพฤติกรรมที่ไม่ได้กำหนดเมื่อ `x + y > T::MAX` หรือ `x + y < T::MIN`
    ///
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// ส่งคืนผลลัพธ์ของการลบที่ไม่ได้เลือกซึ่งส่งผลให้เกิดพฤติกรรมที่ไม่ได้กำหนดเมื่อ `x - y > T::MAX` หรือ `x - y < T::MIN`
    ///
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// ส่งคืนผลลัพธ์ของการคูณที่ไม่ได้ทำเครื่องหมายซึ่งทำให้เกิดพฤติกรรมที่ไม่ได้กำหนดเมื่อ `x *y > T::MAX` หรือ `x* y < T::MIN`
    ///
    ///
    /// เนื้อแท้นี้ไม่มีคู่ที่มั่นคง
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// ทำการหมุนไปทางซ้าย
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในไพรมารีจำนวนเต็มผ่านวิธี `rotate_left`
    /// ตัวอย่างเช่น,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// ทำการหมุนไปทางขวา
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในไพรมารีจำนวนเต็มผ่านวิธี `rotate_right`
    /// ตัวอย่างเช่น,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// ส่งกลับ (a + b) mod 2 <sup>N</sup> โดยที่ N คือความกว้างของ T ในหน่วยบิต
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในไพรมารีจำนวนเต็มผ่านวิธี `wrapping_add`
    /// ตัวอย่างเช่น,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// ส่งกลับ (a, b) mod 2 <sup>N</sup> โดยที่ N คือความกว้างของ T ในหน่วยบิต
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในไพรมารีจำนวนเต็มผ่านวิธี `wrapping_sub`
    /// ตัวอย่างเช่น,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// ส่งกลับ (a * b) mod 2 <sup>N</sup> โดยที่ N คือความกว้างของ T ในหน่วยบิต
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในไพรมารีจำนวนเต็มผ่านวิธี `wrapping_mul`
    /// ตัวอย่างเช่น,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// คำนวณ `a + b` โดยอิ่มตัวที่ขอบเขตตัวเลข
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในไพรมารีจำนวนเต็มผ่านวิธี `saturating_add`
    /// ตัวอย่างเช่น,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// คำนวณ `a - b` โดยอิ่มตัวที่ขอบเขตตัวเลข
    ///
    /// เวอร์ชันที่เสถียรของอินทรินซิกนี้มีอยู่ในไพรมารีจำนวนเต็มผ่านวิธี `saturating_sub`
    /// ตัวอย่างเช่น,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// ส่งคืนค่าของตัวเลือกสำหรับตัวแปรใน 'v'
    /// ถ้า `T` ไม่มีการเลือกปฏิบัติให้ส่งกลับ `0`
    ///
    /// เวอร์ชันที่เสถียรของเนื้อแท้นี้คือ [`core::mem::discriminant`](crate::mem::discriminant)
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// ส่งคืนจำนวนตัวแปรของประเภท `T` ที่ร่ายเป็น `usize`
    /// ถ้า `T` ไม่มีตัวแปรให้ส่งกลับ `0` ระบบจะนับรูปแบบที่ไม่มีใครอยู่
    ///
    /// เวอร์ชันที่จะทำให้เสถียรของภายในนี้คือ [`mem::variant_count`]
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// โครงสร้าง "try catch" ของ Rust ซึ่งเรียกใช้ตัวชี้ฟังก์ชัน `try_fn` ด้วยตัวชี้ข้อมูล `data`
    ///
    /// อาร์กิวเมนต์ที่สามเป็นฟังก์ชันที่เรียกว่าถ้าเกิด panic
    /// ฟังก์ชันนี้จะนำตัวชี้ข้อมูลและตัวชี้ไปยังวัตถุข้อยกเว้นเฉพาะเป้าหมายที่ตรวจพบ
    ///
    /// สำหรับข้อมูลเพิ่มเติมโปรดดูที่มาของคอมไพเลอร์รวมถึงการนำไปใช้งานของ std
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// ปล่อยร้านค้า `!nontemporal` ตาม LLVM (ดูเอกสาร)
    /// อาจจะไม่มีวันมั่นคง
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// ดูรายละเอียดในเอกสารของ `<*const T>::offset_from`
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// ดูรายละเอียดในเอกสารของ `<*const T>::guaranteed_eq`
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// ดูรายละเอียดในเอกสารของ `<*const T>::guaranteed_ne`
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// จัดสรรเวลาคอมไพล์ไม่ควรเรียกใช้ขณะรันไทม์
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// ฟังก์ชั่นบางอย่างถูกกำหนดไว้ที่นี่เนื่องจากมีให้โดยบังเอิญในโมดูลนี้บนเสถียร
// ดู <https://github.com/rust-lang/rust/issues/15702>
// (`transmute` ก็อยู่ในหมวดหมู่นี้เช่นกัน แต่ไม่สามารถห่อหุ้มได้เนื่องจากตรวจสอบว่า `T` และ `U` มีขนาดเท่ากัน)
//

/// ตรวจสอบว่า `ptr` อยู่ในแนวเดียวกันกับ `align_of::<T>()` หรือไม่
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// คัดลอก `count *size_of::<T>()` ไบต์จาก `src` ถึง `dst` ต้นทางและปลายทางต้อง* ไม่ * ทับซ้อนกัน
///
/// สำหรับพื้นที่ของหน่วยความจำที่อาจทับซ้อนกันให้ใช้ [`copy`] แทน
///
/// `copy_nonoverlapping` มีความหมายเทียบเท่ากับ [`memcpy`] ของ C แต่มีการสลับลำดับอาร์กิวเมนต์
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// พฤติกรรมไม่ได้รับการกำหนดหากมีการละเมิดเงื่อนไขใด ๆ ต่อไปนี้:
///
/// * `src` ต้องเป็น [valid] สำหรับการอ่าน `count * size_of::<T>()` ไบต์
///
/// * `dst` ต้องเป็น [valid] สำหรับการเขียน `count * size_of::<T>()` ไบต์
///
/// * ทั้ง `src` และ `dst` ต้องอยู่ในแนวเดียวกัน
///
/// * ขอบเขตของหน่วยความจำเริ่มต้นที่ `src` โดยมีขนาด `นับ *
///   ขนาดของ: :<T>() `ไบต์ต้อง *ไม่* ทับซ้อนกับพื้นที่ของหน่วยความจำที่เริ่มต้นที่ `dst` ที่มีขนาดเท่ากัน
///
/// เช่นเดียวกับ [`read`] `copy_nonoverlapping` จะสร้างสำเนา `T` แบบบิตโดยไม่คำนึงว่า `T` คือ [`Copy`] หรือไม่
/// ถ้า `T` ไม่ใช่ [`Copy`] การใช้ *ทั้งคู่* ค่าในภูมิภาคที่เริ่มต้นที่ `*src` และภูมิภาคที่เริ่มต้นที่ `* dst` สามารถ [violate memory safety][read-ownership] ได้
///
///
/// โปรดทราบว่าแม้ว่าขนาดที่คัดลอกอย่างมีประสิทธิภาพ (`count * size_of: :<T>()`) คือ `0` พอยน์เตอร์ต้องไม่เป็นโมฆะและจัดตำแหน่งให้ถูกต้อง
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// ใช้ [`Vec::append`] ด้วยตนเอง:
///
/// ```
/// use std::ptr;
///
/// /// ย้ายองค์ประกอบทั้งหมดของ `src` เป็น `dst` โดยปล่อยให้ `src` ว่างเปล่า
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // ตรวจสอบให้แน่ใจว่า `dst` มีความจุเพียงพอที่จะถือ `src` ทั้งหมด
///     dst.reserve(src_len);
///
///     unsafe {
///         // การเรียกเพื่อชดเชยนั้นปลอดภัยเสมอเนื่องจาก `Vec` จะไม่จัดสรรไบต์มากกว่า `isize::MAX`
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // ตัด `src` โดยไม่ทิ้งเนื้อหา
///         // เราทำสิ่งนี้ก่อนเพื่อหลีกเลี่ยงปัญหาในกรณีที่มีบางสิ่งบางอย่างเพิ่มเติมลงไปใน panics
///         src.set_len(0);
///
///         // พื้นที่ทั้งสองไม่สามารถทับซ้อนกันได้เนื่องจากการอ้างอิงที่เปลี่ยนแปลงได้ไม่ได้ใช้นามแฝงและ vectors ที่แตกต่างกันสองภูมิภาคไม่สามารถเป็นเจ้าของหน่วยความจำเดียวกันได้
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // แจ้งให้ `dst` ทราบว่าขณะนี้มีเนื้อหาของ `src`
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: ทำการตรวจสอบเหล่านี้ในขณะรันไทม์เท่านั้น
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // ไม่ตื่นตระหนกเพื่อให้ผลกระทบของ codegen เล็กลง
        abort();
    }*/

    // ความปลอดภัย: สัญญาความปลอดภัยสำหรับ `copy_nonoverlapping` ต้องเป็น
    // ยึดถือโดยผู้โทร
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// คัดลอก `count * size_of::<T>()` ไบต์จาก `src` ถึง `dst` ต้นทางและปลายทางอาจทับซ้อนกัน
///
/// หากต้นทางและปลายทางจะ *ไม่* ทับซ้อนกันสามารถใช้ [`copy_nonoverlapping`] แทนได้
///
/// `copy` มีความหมายเทียบเท่ากับ [`memmove`] ของ C แต่มีการสลับลำดับอาร์กิวเมนต์
/// การคัดลอกจะเกิดขึ้นราวกับว่าไบต์ถูกคัดลอกจาก `src` ไปยังอาร์เรย์ชั่วคราวแล้วคัดลอกจากอาร์เรย์ไปยัง `dst`
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// พฤติกรรมไม่ได้รับการกำหนดหากมีการละเมิดเงื่อนไขใด ๆ ต่อไปนี้:
///
/// * `src` ต้องเป็น [valid] สำหรับการอ่าน `count * size_of::<T>()` ไบต์
///
/// * `dst` ต้องเป็น [valid] สำหรับการเขียน `count * size_of::<T>()` ไบต์
///
/// * ทั้ง `src` และ `dst` ต้องอยู่ในแนวเดียวกัน
///
/// เช่นเดียวกับ [`read`] `copy` จะสร้างสำเนา `T` แบบบิตโดยไม่คำนึงว่า `T` คือ [`Copy`] หรือไม่
/// ถ้า `T` ไม่ใช่ [`Copy`] การใช้ทั้งสองค่าในภูมิภาคที่เริ่มต้นที่ `*src` และภูมิภาคที่เริ่มต้นที่ `* dst` สามารถ [violate memory safety][read-ownership] ได้
///
///
/// โปรดทราบว่าแม้ว่าขนาดที่คัดลอกอย่างมีประสิทธิภาพ (`count * size_of: :<T>()`) คือ `0` พอยน์เตอร์ต้องไม่เป็นโมฆะและจัดตำแหน่งให้ถูกต้อง
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// สร้าง Rust vector อย่างมีประสิทธิภาพจากบัฟเฟอร์ที่ไม่ปลอดภัย:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` ต้องจัดตำแหน่งให้ถูกต้องสำหรับประเภทและไม่ใช่ศูนย์
/// /// * `ptr` ต้องถูกต้องสำหรับการอ่าน `elts` องค์ประกอบที่ต่อเนื่องกันของประเภท `T`
/// /// * ห้ามใช้องค์ประกอบเหล่านั้นหลังจากเรียกใช้ฟังก์ชันนี้เว้นแต่ `T: Copy`
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // ความปลอดภัย: เงื่อนไขเบื้องต้นของเราทำให้แน่ใจว่าแหล่งที่มานั้นสอดคล้องและถูกต้อง
///     // และ `Vec::with_capacity` ช่วยให้มั่นใจได้ว่าเรามีพื้นที่ว่างในการเขียน
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // ความปลอดภัย: เราสร้างมันขึ้นมาด้วยความสามารถที่มากก่อนหน้านี้
///     // และ `copy` ก่อนหน้านี้ได้เตรียมใช้งานองค์ประกอบเหล่านี้แล้ว
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: ทำการตรวจสอบเหล่านี้ในขณะรันไทม์เท่านั้น
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // ไม่ตื่นตระหนกเพื่อให้ผลกระทบของ codegen เล็กลง
        abort();
    }*/

    // ความปลอดภัย: สัญญาความปลอดภัยสำหรับ `copy` จะต้องได้รับการยึดถือโดยผู้โทร
    unsafe { copy(src, dst, count) }
}

/// ตั้งค่า `count * size_of::<T>()` ไบต์ของหน่วยความจำเริ่มต้นที่ `dst` ถึง `val`
///
/// `write_bytes` คล้ายกับ [`memset`] ของ C แต่ตั้งค่า `count * size_of::<T>()` ไบต์เป็น `val`
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// พฤติกรรมไม่ได้รับการกำหนดหากมีการละเมิดเงื่อนไขใด ๆ ต่อไปนี้:
///
/// * `dst` ต้องเป็น [valid] สำหรับการเขียน `count * size_of::<T>()` ไบต์
///
/// * `dst` ต้องจัดตำแหน่งให้ถูกต้อง
///
/// นอกจากนี้ผู้เรียกต้องตรวจสอบให้แน่ใจว่าการเขียน `count * size_of::<T>()` ไบต์ไปยังพื้นที่หน่วยความจำที่กำหนดทำให้ค่า `T` ถูกต้อง
/// การใช้พื้นที่ของหน่วยความจำที่พิมพ์เป็น `T` ที่มีค่า `T` ที่ไม่ถูกต้องถือเป็นพฤติกรรมที่ไม่ได้กำหนดไว้
///
/// โปรดทราบว่าแม้ว่าขนาดที่คัดลอกอย่างมีประสิทธิภาพ (`count * size_of: :<T>()`) คือ `0` ตัวชี้จะต้องไม่เป็นโมฆะและจัดตำแหน่งให้ถูกต้อง
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// การใช้งานพื้นฐาน:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// การสร้างค่าที่ไม่ถูกต้อง:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // รั่วไหลของค่าที่ถือไว้ก่อนหน้านี้โดยการเขียนทับ `Box<T>` ด้วยตัวชี้ค่าว่าง
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // ณ จุดนี้การใช้หรือวาง `v` จะทำให้เกิดพฤติกรรมที่ไม่ได้กำหนดไว้
/// // drop(v); // ERROR
///
/// // แม้กระทั่งการรั่ว `v` "uses" ก็ตามและด้วยเหตุนี้จึงเป็นพฤติกรรมที่ไม่ได้กำหนด
/// // mem::forget(v); // ERROR
///
/// // ในความเป็นจริง `v` ไม่ถูกต้องตามค่าคงที่ของเลย์เอาต์ประเภทพื้นฐานดังนั้นการดำเนินการ * ใด ๆ ที่สัมผัสจึงเป็นพฤติกรรมที่ไม่ได้กำหนด
/////
/// // ให้ v2 =v;//ข้อผิดพลาด
///
/// unsafe {
///     // ให้เราใส่ค่าที่ถูกต้องแทน
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // ตอนนี้กล่องเรียบร้อยดี
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // ความปลอดภัย: สัญญาความปลอดภัยสำหรับ `write_bytes` จะต้องได้รับการยึดถือโดยผู้โทร
    unsafe { write_bytes(dst, val, count) }
}