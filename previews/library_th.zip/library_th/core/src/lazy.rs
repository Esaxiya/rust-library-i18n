//! ค่า Lazy และการเริ่มต้นข้อมูลแบบคงที่เพียงครั้งเดียว

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// เซลล์ที่สามารถเขียนได้เพียงครั้งเดียว
///
/// ซึ่งแตกต่างจาก `RefCell` คือ `OnceCell` จะให้เฉพาะการอ้างอิง `&T` ที่ใช้ร่วมกันกับค่าของมัน
/// ไม่เหมือนกับ `Cell` `OnceCell` ไม่จำเป็นต้องคัดลอกหรือแทนที่ค่าเพื่อเข้าถึง
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // Invariant: เขียนถึงมากที่สุดในครั้งเดียว
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// สร้างเซลล์ว่างใหม่
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// รับการอ้างอิงไปยังค่าพื้นฐาน
    ///
    /// ส่งคืน `None` ถ้าเซลล์ว่าง
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // ความปลอดภัย: ปลอดภัยเนื่องจากค่าคงที่ของ "inner"
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// รับการอ้างอิงที่เปลี่ยนแปลงได้กับค่าพื้นฐาน
    ///
    /// ส่งคืน `None` ถ้าเซลล์ว่าง
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // ความปลอดภัย: ปลอดภัยเพราะเรามีการเข้าถึงที่ไม่ซ้ำใคร
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// ตั้งค่าเนื้อหาของเซลล์เป็น `value`
    ///
    /// # Errors
    ///
    /// วิธีนี้จะคืนค่า `Ok(())` ถ้าเซลล์ว่างและ `Err(value)` ถ้าเซลล์เต็ม
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // ความปลอดภัย: ปลอดภัยเพราะเราไม่สามารถมีการยืมแบบผันแปรที่ทับซ้อนกันได้
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // ความปลอดภัย: ที่นี่เป็นที่เดียวที่เรากำหนดช่องไม่มีการแข่งขัน
        // เนื่องจาก reentrancy/concurrency เป็นไปได้และเราได้ตรวจสอบว่าสล็อตปัจจุบันเป็น `None` ดังนั้นการเขียนนี้จึงคงค่าคงที่ของ "inner" ไว้
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// รับเนื้อหาของเซลล์เริ่มต้นด้วย `f` หากเซลล์ว่างเปล่า
    ///
    /// # Panics
    ///
    /// ถ้า `f` panics panic จะแพร่กระจายไปยังผู้เรียกและเซลล์จะยังคงไม่ได้เริ่มต้น
    ///
    ///
    /// เป็นข้อผิดพลาดในการเริ่มต้นเซลล์จาก `f` อีกครั้งการทำเช่นนั้นส่งผลให้เกิด panic
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// รับเนื้อหาของเซลล์เริ่มต้นด้วย `f` หากเซลล์ว่างเปล่า
    /// หากเซลล์ว่างเปล่าและ `f` ล้มเหลวจะมีการส่งคืนข้อผิดพลาด
    ///
    /// # Panics
    ///
    /// ถ้า `f` panics panic จะแพร่กระจายไปยังผู้เรียกและเซลล์จะยังคงไม่ได้เริ่มต้น
    ///
    ///
    /// เป็นข้อผิดพลาดในการเริ่มต้นเซลล์จาก `f` อีกครั้งการทำเช่นนั้นส่งผลให้เกิด panic
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // โปรดทราบว่า * บางรูปแบบของการเริ่มต้นใช้งาน reentrant อาจนำไปสู่ UB (ดูการทดสอบ `reentrant_init`)
        // ฉันเชื่อว่าการลบ `assert` นี้ออกไปในขณะที่การรักษา `set/get` นั้นฟังดูดี แต่ดูเหมือนว่าจะดีกว่าสำหรับ panic แทนที่จะใช้ค่าเก่าอย่างเงียบ ๆ
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// ใช้เซลล์โดยคืนค่าที่ห่อไว้
    ///
    /// ส่งคืน `None` หากเซลล์ว่างเปล่า
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // เนื่องจาก `into_inner` ใช้ `self` ตามค่าคอมไพลเลอร์จะตรวจสอบแบบคงที่ว่ายังไม่ได้ยืมในขณะนี้
        // ดังนั้นจึงปลอดภัยที่จะย้ายออก `Option<T>`
        self.inner.into_inner()
    }

    /// นำค่าออกจาก `OnceCell` นี้และย้ายกลับไปยังสถานะที่ไม่ได้กำหนดค่าเริ่มต้น
    ///
    /// ไม่มีผลและส่งคืน `None` หาก `OnceCell` ไม่ได้รับการเตรียมใช้งาน
    ///
    /// รับประกันความปลอดภัยโดยต้องมีการอ้างอิงที่ไม่แน่นอน
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// ค่าที่เริ่มต้นในการเข้าถึงครั้งแรก
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   พร้อมเริ่มต้น
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// สร้างค่าขี้เกียจใหม่ด้วยฟังก์ชันเริ่มต้นที่กำหนด
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// บังคับให้ประเมินค่าขี้เกียจนี้และส่งกลับการอ้างอิงไปยังผลลัพธ์
    ///
    ///
    /// สิ่งนี้เทียบเท่ากับ `Deref` im แต่มีความชัดเจน
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// สร้างค่าขี้เกียจใหม่โดยใช้ `Default` เป็นฟังก์ชันเริ่มต้น
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}