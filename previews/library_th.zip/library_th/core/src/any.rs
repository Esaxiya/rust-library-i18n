//! โมดูลนี้ใช้ `Any` trait ซึ่งเปิดใช้งานการพิมพ์แบบไดนามิกของประเภท `'static` ใด ๆ ผ่านการสะท้อนรันไทม์
//!
//! `Any` สามารถใช้เพื่อรับ `TypeId` และมีคุณสมบัติเพิ่มเติมเมื่อใช้เป็นวัตถุ trait
//! ในฐานะ `&dyn Any` (ออบเจ็กต์ trait ที่ยืมมา) มีวิธี `is` และ `downcast_ref` เพื่อทดสอบว่าค่าที่มีอยู่เป็นประเภทที่กำหนดหรือไม่และรับการอ้างอิงถึงค่าภายในเป็นประเภท
//! ในฐานะ `&mut dyn Any` นอกจากนี้ยังมีวิธี `downcast_mut` สำหรับการอ้างอิงที่ไม่แน่นอนกับค่าภายใน
//! `Box<dyn Any>` เพิ่มวิธี `downcast` ซึ่งพยายามแปลงเป็น `Box<T>`
//! ดูเอกสาร [`Box`] สำหรับรายละเอียดทั้งหมด
//!
//! โปรดทราบว่า `&dyn Any` ถูก จำกัด ไว้ที่การทดสอบว่าค่าเป็นประเภทคอนกรีตที่ระบุหรือไม่และไม่สามารถใช้เพื่อทดสอบว่าชนิดใช้ trait หรือไม่
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # ตัวชี้อัจฉริยะและ `dyn Any`
//!
//! พฤติกรรมอย่างหนึ่งที่ควรคำนึงถึงเมื่อใช้ `Any` เป็นอ็อบเจ็กต์ trait โดยเฉพาะอย่างยิ่งกับประเภทเช่น `Box<dyn Any>` หรือ `Arc<dyn Any>` ก็คือการเรียก `.type_id()` ตามค่าจะทำให้เกิด `TypeId` ของ *container* ไม่ใช่อ็อบเจ็กต์ trait ที่อยู่ภายใต้
//!
//! สิ่งนี้สามารถหลีกเลี่ยงได้โดยการแปลงตัวชี้อัจฉริยะเป็น `&dyn Any` แทนซึ่งจะส่งคืน `TypeId` ของวัตถุ
//! ตัวอย่างเช่น:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // คุณมีแนวโน้มที่จะต้องการสิ่งนี้:
//! let actual_id = (&*boxed).type_id();
//! // ... กว่านี้:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! พิจารณาสถานการณ์ที่เราต้องการล็อกเอาต์ค่าที่ส่งผ่านไปยังฟังก์ชัน
//! เรารู้คุณค่าที่เรากำลังดำเนินการแก้ไขข้อบกพร่อง แต่เราไม่ทราบประเภทที่เป็นรูปธรรมเราต้องการให้การดูแลบางประเภทเป็นพิเศษ: ในกรณีนี้ให้พิมพ์ความยาวของค่า String ก่อนค่า
//! เราไม่ทราบประเภทรูปธรรมของมูลค่าของเราในเวลาคอมไพล์ดังนั้นเราจึงต้องใช้การสะท้อนแบบรันไทม์แทน
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // ฟังก์ชัน Logger สำหรับทุกประเภทที่ใช้ Debug
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // ลองแปลงค่าของเราเป็น `String`
//!     // หากประสบความสำเร็จเราต้องการส่งออกความยาวของ String พร้อมกับค่าของมัน
//!     // ถ้าไม่ใช่มันเป็นประเภทอื่น: เพียงแค่พิมพ์ออกมาโดยไม่ได้ตกแต่ง
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // ฟังก์ชันนี้ต้องการล็อกพารามิเตอร์ออกก่อนที่จะทำงานกับมัน
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... ทำงานอื่น ๆ
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// trait ใด ๆ
///////////////////////////////////////////////////////////////////////////////

/// trait เพื่อเลียนแบบการพิมพ์แบบไดนามิก
///
/// ประเภทส่วนใหญ่ใช้ `Any` อย่างไรก็ตามประเภทใดก็ตามที่มีการอ้างอิงที่ไม่ใช่ "คงที่" จะไม่มี
/// ดู [module-level documentation][mod] สำหรับรายละเอียดเพิ่มเติม
///
/// [mod]: crate::any
// trait นี้ไม่ปลอดภัยแม้ว่าเราจะอาศัยข้อมูลจำเพาะของฟังก์ชัน `type_id` ของ im เพียงผู้เดียวในรหัสที่ไม่ปลอดภัย (เช่น `downcast`)โดยปกติแล้วนั่นจะเป็นปัญหา แต่เนื่องจาก `Any` มีเพียงคำสั่งเดียวคือการใช้งานแบบครอบคลุมจึงไม่มีโค้ดอื่นใดที่สามารถใช้ `Any` ได้
//
// เราสามารถทำให้ trait นี้ไม่ปลอดภัยอย่างเป็นไปได้-มันจะไม่ทำให้เกิดการแตกหักเนื่องจากเราควบคุมการใช้งานทั้งหมด-แต่เราเลือกที่จะไม่ทำเพราะทั้งสองอย่างนั้นไม่จำเป็นจริงๆและอาจทำให้ผู้ใช้สับสนเกี่ยวกับความแตกต่างของ traits ที่ไม่ปลอดภัยและวิธีการที่ไม่ปลอดภัย (เช่น `type_id` ยังคงปลอดภัยในการโทร แต่เราอาจต้องการระบุไว้ในเอกสารประกอบ)
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// รับ `TypeId` ของ `self`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// วิธีการขยายสำหรับวัตถุ trait ใด ๆ
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// ตรวจสอบให้แน่ใจว่าสามารถพิมพ์ผลลัพธ์ของเช่นการรวมเธรดและใช้กับ `unwrap` ได้
// ในที่สุดอาจไม่จำเป็นอีกต่อไปหากการจัดส่งทำงานร่วมกับการอัปเดต
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// ส่งคืน `true` หากชนิดบรรจุกล่องเหมือนกับ `T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // รับ `TypeId` ของประเภทที่ฟังก์ชันนี้สร้างอินสแตนซ์ด้วย
        let t = TypeId::of::<T>();

        // รับ `TypeId` ของประเภทในวัตถุ trait (`self`)
        let concrete = self.type_id();

        // เปรียบเทียบทั้ง TypeId เกี่ยวกับความเท่าเทียมกัน
        t == concrete
    }

    /// ส่งคืนการอ้างอิงบางส่วนไปยังค่าที่บรรจุกล่องหากเป็นประเภท `T` หรือ `None` หากไม่ใช่
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // ความปลอดภัย: ตรวจสอบว่าเราชี้ไปที่ประเภทที่ถูกต้องหรือไม่และเราสามารถวางใจได้
            // ที่ตรวจสอบความปลอดภัยของหน่วยความจำเนื่องจากเราได้ใช้ Any สำหรับทุกประเภทไม่มีนัยอื่นใดเกิดขึ้นได้เนื่องจากจะขัดแย้งกับนัยของเรา
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// ส่งคืนการอ้างอิงที่ไม่แน่นอนบางส่วนไปยังค่าในกล่องหากเป็นประเภท `T` หรือ `None` หากไม่ใช่
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // ความปลอดภัย: ตรวจสอบว่าเราชี้ไปที่ประเภทที่ถูกต้องหรือไม่และเราสามารถวางใจได้
            // ที่ตรวจสอบความปลอดภัยของหน่วยความจำเนื่องจากเราได้ใช้ Any สำหรับทุกประเภทไม่มีนัยอื่นใดเกิดขึ้นได้เนื่องจากจะขัดแย้งกับนัยของเรา
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// ส่งต่อไปยังวิธีการที่กำหนดไว้ในประเภท `Any`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// ส่งต่อไปยังวิธีการที่กำหนดไว้ในประเภท `Any`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// ส่งต่อไปยังวิธีการที่กำหนดไว้ในประเภท `Any`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// ส่งต่อไปยังวิธีการที่กำหนดไว้ในประเภท `Any`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// ส่งต่อไปยังวิธีการที่กำหนดไว้ในประเภท `Any`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// ส่งต่อไปยังวิธีการที่กำหนดไว้ในประเภท `Any`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID และวิธีการ
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` แสดงถึงตัวระบุที่ไม่ซ้ำกันทั่วโลกสำหรับประเภท
///
/// `TypeId` แต่ละชิ้นเป็นวัตถุทึบแสงซึ่งไม่อนุญาตให้ตรวจสอบสิ่งที่อยู่ภายใน แต่อนุญาตให้มีการดำเนินการขั้นพื้นฐานเช่นการโคลนการเปรียบเทียบการพิมพ์และการแสดง
///
///
/// ขณะนี้ `TypeId` มีให้บริการสำหรับประเภทที่อ้างถึง `'static` เท่านั้น แต่ข้อ จำกัด นี้อาจถูกลบออกใน future
///
/// ในขณะที่ `TypeId` ใช้ `Hash`, `PartialOrd` และ `Ord` เป็นที่น่าสังเกตว่าแฮชและการสั่งซื้อจะแตกต่างกันไประหว่างรุ่น Rust
/// ระวังการพึ่งพาพวกเขาภายในรหัสของคุณ!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// ส่งคืน `TypeId` ของประเภทที่ฟังก์ชันทั่วไปนี้ได้รับการสร้างอินสแตนซ์ด้วย
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// ส่งคืนชื่อชนิดเป็นสไลซ์สตริง
///
/// # Note
///
/// สิ่งนี้มีไว้สำหรับใช้ในการวินิจฉัย
/// ไม่ได้ระบุเนื้อหาและรูปแบบที่แน่นอนของสตริงที่ส่งคืนนอกจากเป็นคำอธิบายประเภทที่พยายามอย่างเต็มที่แล้ว
/// ตัวอย่างเช่นในบรรดาสตริงที่ `type_name::<Option<String>>()` อาจส่งคืนคือ `"Option<String>"` และ `"std::option::Option<std::string::String>"`
///
///
/// สตริงที่ส่งคืนจะต้องไม่ถูกพิจารณาว่าเป็นตัวระบุที่ไม่ซ้ำกันของประเภทเนื่องจากหลายประเภทอาจจับคู่กับชื่อประเภทเดียวกัน
/// ในทำนองเดียวกันไม่มีการรับประกันว่าทุกส่วนของประเภทจะปรากฏในสตริงที่ส่งคืนตัวอย่างเช่นขณะนี้ไม่รวมตัวระบุอายุการใช้งาน
/// นอกจากนี้ผลลัพธ์อาจเปลี่ยนแปลงระหว่างเวอร์ชันของคอมไพเลอร์
///
/// การใช้งานปัจจุบันใช้โครงสร้างพื้นฐานเดียวกับการวินิจฉัยคอมไพลเลอร์และการดีบักข้อมูล แต่ไม่รับประกัน
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// ส่งคืนชื่อชนิดของค่าที่ชี้ไปเป็นสไลซ์สตริง
/// สิ่งนี้เหมือนกับ `type_name::<T>()` แต่สามารถใช้ได้ในกรณีที่ประเภทของตัวแปรไม่สามารถใช้ได้อย่างง่ายดาย
///
/// # Note
///
/// สิ่งนี้มีไว้สำหรับใช้ในการวินิจฉัยไม่ได้ระบุเนื้อหาและรูปแบบที่แน่นอนของสตริงนอกจากเป็นคำอธิบายที่ดีที่สุดของประเภท
/// ตัวอย่างเช่น `type_name_of_val::<Option<String>>(None)` สามารถคืนค่า `"Option<String>"` หรือ `"std::option::Option<std::string::String>"` แต่ไม่ใช่ `"foobar"`
///
/// นอกจากนี้ผลลัพธ์อาจเปลี่ยนแปลงระหว่างเวอร์ชันของคอมไพเลอร์
///
/// ฟังก์ชันนี้ไม่สามารถแก้ไขอ็อบเจ็กต์ trait ซึ่งหมายความว่า `type_name_of_val(&7u32 as &dyn Debug)` อาจคืนค่า `"dyn Debug"` แต่ไม่ใช่ `"u32"`
///
/// ชื่อประเภทไม่ควรถือเป็นตัวระบุเฉพาะของประเภท
/// หลายประเภทอาจใช้ชื่อประเภทเดียวกัน
///
/// การใช้งานปัจจุบันใช้โครงสร้างพื้นฐานเดียวกับการวินิจฉัยคอมไพลเลอร์และการดีบักข้อมูล แต่ไม่รับประกัน
///
/// # Examples
///
/// พิมพ์จำนวนเต็มเริ่มต้นและประเภทลอย
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}