//! `Clone` trait สำหรับประเภทที่ไม่สามารถ 'คัดลอกโดยปริยาย' ได้
//!
//! ใน Rust ประเภทที่เรียบง่ายบางประเภทคือ "implicitly copyable" และเมื่อคุณกำหนดหรือส่งผ่านเป็นอาร์กิวเมนต์ผู้รับจะได้รับสำเนาโดยทิ้งค่าดั้งเดิมไว้
//! ประเภทเหล่านี้ไม่ต้องการการจัดสรรเพื่อคัดลอกและไม่มีโปรแกรมสุดท้าย (กล่าวคือไม่มีกล่องที่เป็นเจ้าของหรือใช้ [`Drop`]) ดังนั้นคอมไพเลอร์จึงพิจารณาว่าถูกและปลอดภัยในการคัดลอก
//!
//! สำหรับประเภทอื่น ๆ จะต้องทำสำเนาอย่างชัดเจนโดยการใช้ [`Clone`] trait และเรียกใช้เมธอด [`clone`]
//!
//! [`clone`]: Clone::clone
//!
//! ตัวอย่างการใช้งานพื้นฐาน:
//!
//! ```
//! let s = String::new(); // ประเภทสตริงใช้ Clone
//! let copy = s.clone(); // เพื่อให้เราสามารถโคลนได้
//! ```
//!
//! ในการใช้งาน Clone trait อย่างง่ายดายคุณยังสามารถใช้ `#[derive(Clone)]` ตัวอย่าง:
//!
//! ```
//! #[derive(Clone)] // เราเพิ่ม Clone trait ไปยัง Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // และตอนนี้เราสามารถโคลนได้แล้ว!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// trait ทั่วไปสำหรับความสามารถในการทำซ้ำวัตถุอย่างชัดเจน
///
/// ความแตกต่างจาก [`Copy`] ตรงที่ [`Copy`] นั้นมีความหมายโดยนัยและราคาไม่แพงมากในขณะที่ `Clone` นั้นชัดเจนเสมอและอาจมีราคาแพงหรือไม่ก็ได้
/// ในการบังคับใช้คุณลักษณะเหล่านี้ Rust ไม่อนุญาตให้คุณใช้งาน [`Copy`] ซ้ำ แต่คุณสามารถติดตั้ง `Clone` ใหม่และเรียกใช้รหัสโดยอำเภอใจได้
///
/// เนื่องจาก `Clone` มีความกว้างมากกว่า [`Copy`] คุณจึงสามารถทำให้ [`Copy`] เป็น `Clone` ได้โดยอัตโนมัติเช่นกัน
///
/// ## Derivable
///
/// trait นี้สามารถใช้กับ `#[derive]` ได้หากฟิลด์ทั้งหมดเป็น `Clone` การใช้งาน "ได้มา" ของ [`Clone`] เรียกใช้ [`clone`] ในแต่ละฟิลด์
///
/// [`clone`]: Clone::clone
///
/// สำหรับโครงสร้างทั่วไป `#[derive]` จะใช้ `Clone` ตามเงื่อนไขโดยการเพิ่ม `Clone` ที่ถูกผูกไว้บนพารามิเตอร์ทั่วไป
///
/// ```
/// // `derive` ใช้ Clone สำหรับการอ่าน<T>เมื่อ T คือ Clone
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## ฉันจะใช้ `Clone` ได้อย่างไร
///
/// ประเภทที่เป็น [`Copy`] ควรมีการใช้งาน `Clone` เล็กน้อยอย่างเป็นทางการมากขึ้น:
/// ถ้า `T: Copy`, `x: T` และ `y: &T` ดังนั้น `let x = y.clone();` จะเทียบเท่ากับ `let x = *y;`
/// การใช้งานด้วยตนเองควรระมัดระวังเพื่อรักษาค่าคงที่นี้ไว้อย่างไรก็ตามรหัสที่ไม่ปลอดภัยจะต้องไม่พึ่งพาเพื่อความปลอดภัยของหน่วยความจำ
///
/// ตัวอย่างคือโครงสร้างทั่วไปที่มีตัวชี้ฟังก์ชันในกรณีนี้การนำ `Clone` ไปใช้ไม่สามารถ "ได้มา" แต่สามารถนำไปใช้เป็น:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## ตัวดำเนินการเพิ่มเติม
///
/// นอกจาก [implementors listed below][impls] แล้วประเภทต่อไปนี้ยังใช้ `Clone`:
///
/// * ประเภทรายการฟังก์ชัน (กล่าวคือประเภทที่แตกต่างกันที่กำหนดไว้สำหรับแต่ละฟังก์ชัน)
/// * ประเภทตัวชี้ฟังก์ชัน (เช่น `fn() -> i32`)
/// * ประเภทอาร์เรย์สำหรับทุกขนาดหากประเภทรายการใช้ `Clone` ด้วย (เช่น `[i32; 123456]`)
/// * ประเภททูเพิลหากแต่ละองค์ประกอบใช้ `Clone` ด้วย (เช่น `()`, `(i32, bool)`)
/// * ชนิดการปิดหากไม่จับค่าจากสภาพแวดล้อมหรือหากค่าที่จับได้ทั้งหมดใช้ `Clone` ด้วยตัวเอง
///   โปรดทราบว่าตัวแปรที่จับโดยการอ้างอิงที่ใช้ร่วมกันจะใช้ `Clone` เสมอ (แม้ว่าผู้อ้างอิงจะไม่ใช้ก็ตาม) ในขณะที่ตัวแปรที่จับโดยการอ้างอิงที่เปลี่ยนแปลงไม่ได้จะไม่ใช้ `Clone`
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// ส่งคืนสำเนาของค่า
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str ใช้ Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// ดำเนินการคัดลอก-กำหนดจาก `source`
    ///
    /// `a.clone_from(&b)` เทียบเท่ากับ `a = b.clone()` ในฟังก์ชันการทำงาน แต่สามารถแทนที่เพื่อนำทรัพยากรของ `a` กลับมาใช้ใหม่ได้เพื่อหลีกเลี่ยงการจัดสรรที่ไม่จำเป็น
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// มาโครที่ได้รับซึ่งสร้างโดยนัยของ trait `Clone`
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): โครงสร้างเหล่านี้ถูกใช้โดย#[derive] เพียงอย่างเดียวเพื่อยืนยันว่าทุกองค์ประกอบของประเภทใช้งาน Clone หรือ Copy
//
//
// โครงสร้างเหล่านี้ไม่ควรปรากฏในรหัสผู้ใช้
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// การใช้งาน `Clone` สำหรับประเภทดั้งเดิม
///
/// การใช้งานที่ไม่สามารถอธิบายได้ใน Rust ถูกนำไปใช้ใน `traits::SelectionContext::copy_clone_conditions()` ใน `rustc_trait_selection`
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// การอ้างอิงที่ใช้ร่วมกันสามารถโคลนได้ แต่การอ้างอิงที่เปลี่ยนแปลงไม่ได้ *ไม่สามารถ*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// การอ้างอิงที่ใช้ร่วมกันสามารถโคลนได้ แต่การอ้างอิงที่เปลี่ยนแปลงไม่ได้ *ไม่สามารถ*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}