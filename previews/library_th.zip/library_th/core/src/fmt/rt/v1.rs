//! นี่คือโมดูลภายในที่ใช้โดย ifmt!รันไทม์โครงสร้างเหล่านี้ถูกส่งไปยังอาร์เรย์แบบคงที่เพื่อคอมไพล์สตริงรูปแบบล่วงหน้าก่อนเวลา
//!
//! คำจำกัดความเหล่านี้คล้ายกับ `ct` ที่เทียบเท่า แต่แตกต่างกันตรงที่สามารถจัดสรรแบบคงที่และได้รับการปรับให้เหมาะสมกับรันไทม์เล็กน้อย
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// การจัดตำแหน่งที่เป็นไปได้ซึ่งสามารถขอเป็นส่วนหนึ่งของคำสั่งการจัดรูปแบบ
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// แสดงว่าเนื้อหาควรจัดชิดซ้าย
    Left,
    /// แสดงว่าเนื้อหาควรจัดชิดขวา
    Right,
    /// การระบุว่าเนื้อหาควรอยู่ในแนวกึ่งกลาง
    Center,
    /// ไม่ได้ร้องขอการจัดตำแหน่ง
    Unknown,
}

/// ใช้โดยตัวระบุ [width](https://doc.rust-lang.org/std/fmt/#width) และ [precision](https://doc.rust-lang.org/std/fmt/#precision)
#[derive(Copy, Clone)]
pub enum Count {
    /// ระบุด้วยตัวเลขตามตัวอักษรเก็บค่า
    Is(usize),
    /// ระบุโดยใช้ไวยากรณ์ `$` และ `*` เก็บดัชนีเป็น `args`
    Param(usize),
    /// ไม่ระบุ
    Implied,
}