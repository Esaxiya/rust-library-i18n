//! การปรับ Rust ของอัลกอริทึม Grisu3 ที่อธิบายไว้ใน "การพิมพ์ตัวเลขจุดลอยตัวอย่างรวดเร็วและแม่นยำด้วยจำนวนเต็ม" [^ 1]
//! มันใช้ตาราง precomputed ประมาณ 1KB และในทางกลับกันมันก็เร็วมากสำหรับอินพุตส่วนใหญ่
//!
//! [^1]: Florian Loitsch.2553. การพิมพ์ตัวเลขทศนิยมอย่างรวดเร็วและ
//!   แม่นยำด้วยจำนวนเต็มSIGPLAN ไม่45, 6 (มิถุนายน 2553), 233-243
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// ดูความคิดเห็นใน `format_shortest_opt` สำหรับเหตุผล
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-ฉัน;e=4* ผม 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (ฉ, จ, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// ให้ `x > 0` ส่งคืน `(k, 10^k)` เช่นนั้น `10^k <= x < 10^(k+1)`
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// การใช้งานโหมดที่สั้นที่สุดสำหรับ Grisu
///
/// มันจะส่งคืน `None` เมื่อมันจะส่งคืนการแทนค่าที่ไม่ตรงเป็นอย่างอื่น
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // เราต้องการความแม่นยำเพิ่มเติมอย่างน้อยสามบิต

    // เริ่มต้นด้วยค่านอร์มัลไลซ์ด้วยเลขชี้กำลังที่ใช้ร่วมกัน
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // ค้นหา `cached = 10^minusk` ใด ๆ เช่น `ALPHA <= minusk + plus.e + 64 <= GAMMA`
    // เนื่องจาก `plus` เป็นมาตรฐานจึงหมายถึง `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`
    // ด้วยตัวเลือก `ALPHA` และ `GAMMA` ของเราสิ่งนี้ทำให้ `plus * cached` เป็น `[4, 2^32)`
    //
    // เห็นได้ชัดว่าเป็นที่พึงปรารถนาที่จะขยาย `GAMMA - ALPHA` ให้สูงสุดเพื่อที่เราจะได้ไม่ต้องการพลังแคชจำนวนมากถึง 10 แต่มีข้อควรพิจารณาบางประการ:
    //
    //
    // 1. เราต้องการให้ `floor(plus * cached)` อยู่ใน `u32` เนื่องจากต้องมีการหารที่มีราคาแพง
    //    (สิ่งนี้ไม่สามารถหลีกเลี่ยงได้จริง ๆ ส่วนที่เหลือจำเป็นสำหรับการประมาณความถูกต้อง)
    // 2.
    // ส่วนที่เหลือของ `floor(plus * cached)` ซ้ำ ๆ จะคูณด้วย 10 และไม่ควรล้น
    //
    // ครั้งแรกให้ `64 + GAMMA <= 32` ในขณะที่ครั้งที่สองให้ `10 * 2^-ALPHA <= 2^64`
    // -60 และ -32 คือช่วงสูงสุดที่มีข้อ จำกัด นี้และ V8 ก็ใช้เช่นกัน
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // ขนาด fpsสิ่งนี้ให้ข้อผิดพลาดสูงสุด 1 ulp (พิสูจน์แล้วจาก Theorem 5.1)
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-ช่วงลบจริง
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // เหนือ `minus`, `v` และ `plus` เป็นค่าประมาณ *เชิงปริมาณ*(ข้อผิดพลาด <1 ulp)
    // เนื่องจากเราไม่รู้ว่าข้อผิดพลาดเป็นบวกหรือลบเราจึงใช้การประมาณสองค่าโดยเว้นระยะห่างเท่า ๆ กันและมีข้อผิดพลาดสูงสุด 2 ulps
    //
    // "unsafe region" เป็นช่วงเวลาเสรีที่เราสร้างขึ้นในตอนแรก
    // "safe region" เป็นช่วงอนุรักษ์นิยมที่เรายอมรับเท่านั้น
    // เราเริ่มต้นด้วย repr ที่ถูกต้องภายในพื้นที่ที่ไม่ปลอดภัยและพยายามค้นหา repr ที่ใกล้เคียงที่สุดกับ `v` ซึ่งอยู่ในพื้นที่ปลอดภัยด้วย
    // ถ้าเราทำไม่ได้เรายอมแพ้
    //
    let plus1 = plus.f + 1;
    // ให้ plus0 = plus.f, 1;//สำหรับคำอธิบายเท่านั้นให้ minus0 = minus.f + 1;//สำหรับคำอธิบายเท่านั้น
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // เลขชี้กำลังที่ใช้ร่วมกัน

    // แบ่ง `plus1` ออกเป็นส่วนหนึ่งและเศษส่วน
    // ชิ้นส่วนภายในได้รับการรับประกันว่าพอดีกับ u32 เนื่องจากกำลังแคชรับประกัน `plus < 2^32` และ `plus.f` ที่เป็นมาตรฐานนั้นจะน้อยกว่า `2^64 - 2^4` เสมอเนื่องจากข้อกำหนดด้านความแม่นยำ
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // คำนวณ `10^max_kappa` ที่ใหญ่ที่สุดไม่เกิน `plus1` (ดังนั้น `plus1 < 10^(max_kappa+1)`)
    // นี่คือขอบเขตบนของ `kappa` ด้านล่าง
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // ทฤษฎีบท 6.2: ถ้า `k` เป็นจำนวนเต็มมากที่สุด
    // `0 <= y mod 10^k <= y - x`,              `V = floor(y / 10^k) * 10^k` อยู่ใน `[x, y]` และเป็นหนึ่งในการแสดงที่สั้นที่สุด (โดยมีเลขนัยสำคัญน้อยที่สุด) ในช่วงนั้น
    //
    //
    // หาความยาวหลัก `kappa` ระหว่าง `(minus1, plus1)` ตาม Theorem 6.2
    // สามารถนำทฤษฎีบท 6.2 มาใช้เพื่อยกเว้น `x` ได้โดยต้องใช้ `y mod 10^k < y - x` แทน
    // (เช่น `x` =32000, `y` =32777; `kappa` =2 ตั้งแต่ "y mod 10 ^ 3=777 <y, x=777") อัลกอริทึมอาศัยขั้นตอนการตรวจสอบภายหลังเพื่อยกเว้น `y`
    //
    let delta1 = plus1 - minus1;
    // ให้ delta1int=(delta1>> e) เป็นขนาด;//สำหรับคำอธิบายเท่านั้น
    let delta1frac = delta1 & ((1 << e) - 1);

    // แสดงผลส่วนหนึ่งในขณะที่ตรวจสอบความถูกต้องในแต่ละขั้นตอน
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // ตัวเลขที่ยังไม่ได้แสดง
    loop {
        // เรามีตัวเลขอย่างน้อยหนึ่งหลักในการแสดงผลเป็นค่าคงที่ `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (ตามนั้น `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // หาร `remainder` ด้วย `10^kappa` ทั้งสองถูกปรับขนาดโดย `2^-e`
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ จ
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; เราพบ `kappa` ที่ถูกต้อง
            let ten_kappa = (ten_kappa as u64) << e; // ปรับขนาด 10 ^ kappa กลับไปที่เลขชี้กำลังที่ใช้ร่วมกัน
            return round_and_weed(
                // ความปลอดภัย: เราเริ่มต้นหน่วยความจำดังกล่าวข้างต้น
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // ทำลายลูปเมื่อเราแสดงตัวเลขอินทิกรัลทั้งหมด
        // จำนวนหลักที่แน่นอนคือ `max_kappa + 1` เป็น `plus1 < 10^(max_kappa+1)`
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // เรียกคืนค่าคงที่
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // แสดงผลส่วนที่เป็นเศษส่วนในขณะที่ตรวจสอบความถูกต้องในแต่ละขั้นตอน
    // คราวนี้เราอาศัยการคูณซ้ำเนื่องจากการหารจะสูญเสียความแม่นยำ
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // ตัวเลขถัดไปควรมีนัยสำคัญเนื่องจากเราได้ทดสอบก่อนที่จะแตกค่าคงที่โดยที่ `m = max_kappa + 1` (#ของตัวเลขในส่วนหนึ่ง):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // จะไม่ล้น `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // หาร `remainder` ด้วย `10^kappa`
        // ทั้งสองถูกปรับขนาดโดย `2^e / 10^kappa` ดังนั้นส่วนหลังจึงเป็นนัยที่นี่
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // ตัวหารโดยปริยาย
            return round_and_weed(
                // ความปลอดภัย: เราเริ่มต้นหน่วยความจำดังกล่าวข้างต้น
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // เรียกคืนค่าคงที่
        kappa -= 1;
        remainder = r;
    }

    // เราได้สร้างเลขนัยสำคัญทั้งหมดของ `plus1` แล้ว แต่ไม่แน่ใจว่าเป็นตัวเลขที่เหมาะสมที่สุดหรือไม่
    // ตัวอย่างเช่นถ้า `minus1` คือ 3.14153 ... และ `plus1` คือ 3.14158 ... จะมีการแทนค่าที่สั้นที่สุด 5 แบบจาก 3.14154 ถึง 3.14158 แต่เรามีค่าที่ยิ่งใหญ่ที่สุดเท่านั้น
    // เราต้องลดตัวเลขสุดท้ายลงเรื่อย ๆ และตรวจสอบว่านี่คือการตอบกลับที่ดีที่สุดหรือไม่
    // มีผู้สมัครมากที่สุด 9 คน (..1 ถึง ..9) ดังนั้นนี่จึงค่อนข้างเร็ว(เฟส "rounding")
    //
    // ฟังก์ชั่นจะตรวจสอบว่าการทำซ้ำ "optimal" นี้อยู่ในช่วง ulp จริงหรือไม่และยังเป็นไปได้ว่าการทำซ้ำ "second-to-optimal" นั้นเหมาะสมที่สุดเนื่องจากข้อผิดพลาดในการปัดเศษ
    // ในทั้งสองกรณีนี้จะส่งคืน `None`
    // (เฟส "weeding")
    //
    // อาร์กิวเมนต์ทั้งหมดที่นี่ถูกปรับขนาดโดยค่าทั่วไป (แต่โดยนัย) `k` เพื่อให้:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (และ `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (และ `threshold > plus1v` จากค่าคงที่ก่อนหน้านี้)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // สร้างค่าประมาณสองค่าให้กับ `v` (จริงคือ `plus1 - v`) ภายใน 1.5 ulps
        // การแสดงผลลัพธ์ควรเป็นการแสดงที่ใกล้เคียงที่สุดกับทั้งสองอย่าง
        //
        // ที่นี่ `plus1 - v` ถูกนำมาใช้เนื่องจากการคำนวณเสร็จสิ้นในส่วนที่เกี่ยวกับ `plus1` เพื่อหลีกเลี่ยง overflow/underflow (ด้วยเหตุนี้จึงมีการสลับชื่อ)
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // ลดตัวเลขสุดท้ายและหยุดที่การแสดงที่ใกล้เคียงที่สุดกับ `v + 1 ulp`
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // เราทำงานกับตัวเลขโดยประมาณ `w(n)` ซึ่งเริ่มแรกเท่ากับ `plus1 - plus1 % 10^kappa` หลังจากเรียกใช้ร่างกายลูป `n` ครั้ง `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // เราตั้งค่า `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (ดังนั้น `ส่วนที่เหลือ= plus1w(0)`) เพื่อให้การตรวจสอบง่ายขึ้น
            // โปรดทราบว่า `plus1w(n)` เพิ่มขึ้นอยู่เสมอ
            //
            // เรามีเงื่อนไขสามประการที่จะยุติสิ่งใดก็ตามจะทำให้ลูปไม่สามารถดำเนินการต่อไปได้ แต่จากนั้นเราก็มีการแสดงที่ถูกต้องอย่างน้อยหนึ่งรายการที่ทราบว่าใกล้เคียงกับ `v + 1 ulp` ที่สุดอยู่ดี
            // เราจะระบุว่าเป็น TC1 ถึง TC3 เพื่อความกะทัดรัด
            //
            // TC1: `w(n) <= v + 1 ulp` กล่าวคือนี่คือการตอบกลับครั้งสุดท้ายที่สามารถใกล้เคียงที่สุด
            // สิ่งนี้เทียบเท่ากับ `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`
            // รวมกับ TC2 (ซึ่งตรวจสอบว่า `w(n+1)` is valid) หรือไม่สิ่งนี้จะป้องกันการล้นที่เป็นไปได้ในการคำนวณ `plus1w(n)`
            //
            // TC2: `w(n+1) < minus1` กล่าวคือการทำซ้ำครั้งต่อไปจะไม่ปัดเศษเป็น `v`
            // สิ่งนี้เทียบเท่ากับ `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`
            // ด้านซ้ายมือสามารถล้นได้ แต่เรารู้ว่า `threshold > plus1v` ดังนั้นหาก TC1 เป็นเท็จ `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` และเราสามารถทดสอบได้อย่างปลอดภัยว่า `threshold - plus1w(n) < 10^kappa` แทนหรือไม่
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))` กล่าวคือการทำซ้ำครั้งต่อไปคือ
            // ไม่ใกล้ `v + 1 ulp` มากกว่าการทำซ้ำในปัจจุบัน
            // เมื่อกำหนด `z(n) = plus1v_up - plus1w(n)` สิ่งนี้จะกลายเป็น `abs(z(n)) <= abs(z(n+1))` อีกครั้งสมมติว่า TC1 เป็นเท็จเรามี `z(n) > 0` เรามีสองกรณีที่ต้องพิจารณา:
            //
            // - เมื่อ `z(n+1) >= 0`: TC3 กลายเป็น `z(n) <= z(n+1)`
            // เมื่อ `plus1w(n)` เพิ่มขึ้น `z(n)` ควรจะลดลงและนี่เป็นเท็จอย่างชัดเจน
            // - เมื่อ `z(n+1) < 0`:
            //   - TC3a: เงื่อนไขเบื้องต้นคือ `plus1v_up < plus1w(n) + 10^kappa` สมมติว่า TC2 เป็นเท็จ `threshold >= plus1w(n) + 10^kappa` จึงไม่สามารถล้นได้
            //   - TC3b: TC3 กลายเป็น `z(n) <= -z(n+1)` กล่าวคือ `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   TC1 ที่ถูกลบจะให้ `plus1v_up > plus1w(n)` ดังนั้นจึงไม่สามารถล้นหรือต่ำเกินไปเมื่อรวมกับ TC3a
            //
            // ดังนั้นเราควรหยุดเมื่อ `TC1 || TC2 || (TC3a && TC3b)` ต่อไปนี้เท่ากับผกผัน `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // การทำซ้ำที่สั้นที่สุดไม่สามารถลงท้ายด้วย `0`
                plus1w += ten_kappa;
            }
        }

        // ตรวจสอบว่าการแสดงนี้เป็นการแสดงที่ใกล้เคียงที่สุดกับ `v - 1 ulp` หรือไม่
        //
        // สิ่งนี้เหมือนกับเงื่อนไขการยุติสำหรับ `v + 1 ulp` โดย `plus1v_up` ทั้งหมดถูกแทนที่ด้วย `plus1v_down` แทน
        // การวิเคราะห์ล้นถือเท่า ๆ กัน
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // ตอนนี้เรามีตัวแทนที่ใกล้เคียงที่สุดกับ `v` ระหว่าง `plus1` และ `minus1`
        // นี่เป็นเสรีนิยมเกินไปดังนั้นเราจึงปฏิเสธ `w(n)` ใด ๆ ที่ไม่อยู่ระหว่าง `plus0` และ `minus0` นั่นคือ `plus1 - plus1w(n) <= minus0` หรือ `plus1 - plus1w(n) >= plus0`
        // เราใช้ข้อเท็จจริงที่ว่า `threshold = plus1 - minus1` และ `plus1 - plus0 = minus0 - minus1 = 2 ulp`
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// การใช้งานโหมดที่สั้นที่สุดสำหรับ Grisu พร้อม Dragon fallback
///
/// ควรใช้สำหรับกรณีส่วนใหญ่
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // ความปลอดภัย: ตัวตรวจสอบการยืมไม่ฉลาดพอที่จะให้เราใช้ `buf`
    // ใน branch ที่สองดังนั้นเราจึงซักตลอดอายุการใช้งานที่นี่
    // แต่เราจะใช้ `buf` อีกครั้งหาก `format_shortest_opt` ส่งคืน `None` ดังนั้นจึงไม่เป็นไร
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// การใช้งานโหมดที่แน่นอนและคงที่สำหรับ Grisu
///
/// มันจะส่งคืน `None` เมื่อมันจะส่งคืนการแทนค่าที่ไม่ตรงเป็นอย่างอื่น
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // เราต้องการความแม่นยำเพิ่มเติมอย่างน้อยสามบิต
    assert!(!buf.is_empty());

    // ทำให้ปกติและปรับขนาด `v`
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // แบ่ง `v` ออกเป็นส่วนหนึ่งและเศษส่วน
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // ทั้ง `v` เก่าและ `v` ใหม่ (ปรับขนาดโดย `10^-k`) มีข้อผิดพลาด <1 ulp (Theorem 5.1)
    // เนื่องจากเราไม่รู้ว่าข้อผิดพลาดเป็นบวกหรือลบเราจึงใช้การประมาณสองค่าโดยเว้นระยะห่างเท่า ๆ กันและมีข้อผิดพลาดสูงสุด 2 ulps (เช่นเดียวกับกรณีที่สั้นที่สุด)
    //
    //
    // เป้าหมายคือการค้นหาชุดตัวเลขที่โค้งมนซึ่งเหมือนกันกับทั้ง `v - 1 ulp` และ `v + 1 ulp` เพื่อให้เรามั่นใจสูงสุด
    // หากเป็นไปไม่ได้เราไม่รู้ว่าอันไหนเป็นเอาต์พุตที่ถูกต้องสำหรับ `v` ดังนั้นเราจึงยอมแพ้และถอยกลับ
    //
    // `err` ถูกกำหนดเป็น `1 ulp * 2^e` ที่นี่ (เหมือนกับ ulp ใน `vfrac`) และเราจะปรับขนาดเมื่อใดก็ตามที่ `v` ได้รับการปรับขนาด
    //
    //
    //
    let mut err = 1;

    // คำนวณ `10^max_kappa` ที่ใหญ่ที่สุดไม่เกิน `v` (ดังนั้น `v < 10^(max_kappa+1)`)
    // นี่คือขอบเขตบนของ `kappa` ด้านล่าง
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // หากเรากำลังทำงานกับข้อ จำกัด หลักสุดท้ายเราจำเป็นต้องทำให้บัฟเฟอร์สั้นลงก่อนการแสดงผลจริงเพื่อหลีกเลี่ยงการปัดเศษซ้ำสอง
    //
    // โปรดทราบว่าเราต้องขยายบัฟเฟอร์อีกครั้งเมื่อการปัดเศษเกิดขึ้น!
    let len = if exp <= limit {
        // อ๊ะเราไม่สามารถสร้างตัวเลข *หนึ่ง* หลักได้
        // เป็นไปได้เมื่อพูดว่าเรามีบางอย่างเช่น 9.5 และมันถูกปัดเศษเป็น 10
        //
        // โดยหลักการแล้วเราสามารถเรียก `possibly_round` ด้วยบัฟเฟอร์ว่างได้ทันที แต่การปรับขนาด `max_ten_kappa << e` เป็น 10 อาจส่งผลให้เกิดการล้น
        //
        // ดังนั้นเราจึงเลอะเทอะที่นี่และขยายช่วงข้อผิดพลาดให้กว้างขึ้นโดยปัจจัย 10
        // สิ่งนี้จะเพิ่มอัตราลบเท็จ แต่มาก *มาก* เล็กน้อยเท่านั้น
        // มันจะมีความสำคัญอย่างเห็นได้ชัดก็ต่อเมื่อแมนทิสซามีขนาดใหญ่กว่า 60 บิต
        //
        // ความปลอดภัย: `len=0` ดังนั้นภาระหน้าที่ในการเตรียมใช้งานหน่วยความจำนี้จึงเป็นเรื่องเล็กน้อย
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // แสดงผลส่วนหนึ่ง
    // ข้อผิดพลาดเป็นเศษส่วนทั้งหมดดังนั้นเราจึงไม่จำเป็นต้องตรวจสอบในส่วนนี้
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // ตัวเลขที่ยังไม่ได้แสดง
    loop {
        // เรามีตัวเลขอย่างน้อยหนึ่งหลักในการแสดงผลค่าคงที่เสมอ:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (ตามนั้น `remainder = vint % 10^(kappa+1)`)
        //
        //

        // หาร `remainder` ด้วย `10^kappa` ทั้งสองถูกปรับขนาดโดย `2^-e`
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // บัฟเฟอร์เต็มหรือไม่เรียกใช้การปัดเศษด้วยส่วนที่เหลือ
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // ความปลอดภัย: เราได้เริ่มต้น `len` หลายไบต์
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // ทำลายลูปเมื่อเราแสดงตัวเลขอินทิกรัลทั้งหมด
        // จำนวนหลักที่แน่นอนคือ `max_kappa + 1` เป็น `plus1 < 10^(max_kappa+1)`
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // เรียกคืนค่าคงที่
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // แสดงผลส่วนที่เป็นเศษส่วน
    //
    // โดยหลักการแล้วเราสามารถดำเนินการต่อไปยังตัวเลขสุดท้ายที่มีอยู่และตรวจสอบความถูกต้อง
    // น่าเสียดายที่เรากำลังทำงานกับจำนวนเต็มขนาด จำกัด ดังนั้นเราจึงต้องการเกณฑ์บางอย่างเพื่อตรวจจับการล้น
    // V8 ใช้ `remainder > err` ซึ่งจะกลายเป็นเท็จเมื่อเลขนัยสำคัญ `i` แรกของ `v - 1 ulp` และ `v` ต่างกัน
    // อย่างไรก็ตามสิ่งนี้ปฏิเสธอินพุตที่ถูกต้องมากเกินไป
    //
    // เนื่องจากระยะต่อมามีการตรวจจับการล้นที่ถูกต้องเราจึงใช้เกณฑ์ที่เข้มงวดกว่า:
    // เรายังคงดำเนินต่อไปจนกว่า `err` จะเกิน `10^kappa / 2` ดังนั้นช่วงระหว่าง `v - 1 ulp` และ `v + 1 ulp` จะมีการแสดงแบบโค้งมนตั้งแต่สองค่าขึ้นไป
    //
    // สิ่งนี้เหมือนกับการเปรียบเทียบสองครั้งแรกจาก `possibly_round` สำหรับการอ้างอิง
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // ค่าคงที่โดยที่ `m = max_kappa + 1` (#ของตัวเลขในส่วนหนึ่ง):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // จะไม่ล้น `2^e * 10 < 2^64`
        err *= 10; // จะไม่ล้น `err * 10 < 2^e * 5 < 2^64`

        // หาร `remainder` ด้วย `10^kappa`
        // ทั้งสองถูกปรับขนาดโดย `2^e / 10^kappa` ดังนั้นส่วนหลังจึงเป็นนัยที่นี่
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // บัฟเฟอร์เต็มหรือไม่เรียกใช้การปัดเศษด้วยส่วนที่เหลือ
        if i == len {
            // ความปลอดภัย: เราได้เริ่มต้น `len` หลายไบต์
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // เรียกคืนค่าคงที่
        remainder = r;
    }

    // การคำนวณเพิ่มเติมนั้นไร้ประโยชน์ (`possibly_round` ล้มเหลวแน่นอน) ดังนั้นเราจึงยอมแพ้
    return None;

    // เราได้สร้างตัวเลข `v` ที่ร้องขอทั้งหมดซึ่งควรจะเหมือนกับตัวเลข `v - 1 ulp` ที่เกี่ยวข้อง
    // ตอนนี้เราตรวจสอบว่ามีการแสดงเฉพาะที่ใช้ร่วมกันทั้ง `v - 1 ulp` และ `v + 1 ulp` หรือไม่ซึ่งอาจเป็นตัวเลขเดียวกันกับตัวเลขที่สร้างขึ้นหรือตัวเลขที่ปัดเศษขึ้น
    //
    // หากช่วงมีการแสดงหลายรายการที่มีความยาวเท่ากันเราไม่สามารถแน่ใจได้และควรส่งคืน `None` แทน
    //
    // อาร์กิวเมนต์ทั้งหมดที่นี่ถูกปรับขนาดโดยค่าทั่วไป (แต่โดยนัย) `k` เพื่อให้:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // ความปลอดภัย: ต้องเริ่มต้น `len` ไบต์แรกของ `buf`
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (สำหรับการอ้างอิงเส้นประระบุค่าที่แน่นอนสำหรับการแสดงที่เป็นไปได้ในจำนวนหลักที่กำหนด)
        //
        //
        // ข้อผิดพลาดใหญ่เกินไปจนมีการแสดงที่เป็นไปได้อย่างน้อยสามรายการระหว่าง `v - 1 ulp` และ `v + 1 ulp`
        // เราไม่สามารถระบุได้ว่าข้อใดถูกต้อง
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // ในความเป็นจริง 1/2 ulp ก็เพียงพอที่จะแนะนำการแสดงที่เป็นไปได้สองแบบ
        // (โปรดจำไว้ว่าเราต้องการการแสดงที่ไม่ซ้ำกันสำหรับทั้ง `v - 1 ulp` และ "v + 1 ulp`) สิ่งนี้จะไม่ล้นเช่น `ulp < ten_kappa` จากการตรวจสอบครั้งแรก
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ กัปปะ---------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // ถ้า `v + 1 ulp` อยู่ใกล้กับการแสดงแบบปัดลง (ซึ่งมีอยู่แล้วใน `buf`) เราก็สามารถกลับมาได้อย่างปลอดภัย
        // โปรดทราบว่า `v - 1 ulp`*สามารถ* น้อยกว่าการแสดงปัจจุบัน แต่ในฐานะ `1 ulp < 10^kappa / 2` เงื่อนไขนี้ก็เพียงพอแล้ว:
        // ระยะห่างระหว่าง `v - 1 ulp` และการแสดงปัจจุบันต้องไม่เกิน `10^kappa / 2`
        //
        // เงื่อนไขเท่ากับ `remainder + ulp < 10^kappa / 2`
        // เนื่องจากสิ่งนี้สามารถล้นได้อย่างง่ายดายก่อนอื่นให้ตรวจสอบว่า `remainder < 10^kappa / 2`
        // เราได้ตรวจสอบแล้วว่า `ulp < 10^kappa / 2` ตราบใดที่ `10^kappa` ไม่ล้นหลังจากนั้นการตรวจสอบครั้งที่สองก็ใช้ได้
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // ความปลอดภัย: ผู้โทรของเราเริ่มต้นหน่วยความจำนั้น
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------เศษเหลือ------> |:
        //   :                          |   :
        //   : <---------10 ^ คัปปา--------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // ในทางกลับกันถ้า `v - 1 ulp` อยู่ใกล้กับการแสดงแบบปัดเศษมากขึ้นเราควรปัดเศษขึ้นและกลับมา
        // ด้วยเหตุผลเดียวกันเราไม่จำเป็นต้องตรวจสอบ `v + 1 ulp`
        //
        // เงื่อนไขเท่ากับ `remainder - ulp >= 10^kappa / 2`
        // อีกครั้งก่อนอื่นเราตรวจสอบว่า `remainder > ulp` (โปรดทราบว่านี่ไม่ใช่ `remainder >= ulp` เนื่องจาก `10^kappa` ไม่เคยเป็นศูนย์)
        //
        // โปรดทราบว่า `remainder - ulp <= 10^kappa` ดังนั้นการตรวจสอบครั้งที่สองจะไม่ล้น
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // ความปลอดภัย: ผู้โทรของเราต้องเริ่มต้นหน่วยความจำนั้น
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // เพิ่มเฉพาะตัวเลขเพิ่มเติมเมื่อเราได้รับการร้องขอความแม่นยำคงที่
                // เราต้องตรวจสอบด้วยว่าหากบัฟเฟอร์เดิมว่างเปล่าตัวเลขเพิ่มเติมจะสามารถเพิ่มได้ก็ต่อเมื่อ `exp == limit` (กรณี edge)
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // ความปลอดภัย: เราและผู้โทรเริ่มต้นหน่วยความจำนั้น
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // มิฉะนั้นเราจะถึงวาระ (กล่าวคือค่าบางอย่างระหว่าง `v - 1 ulp` และ `v + 1 ulp` กำลังปัดเศษลงและค่าอื่น ๆ กำลังปัดเศษขึ้น) และยอมแพ้
        //
        None
    }
}

/// การใช้งานโหมดที่แน่นอนและคงที่สำหรับ Grisu กับ Dragon ทางเลือก
///
/// ควรใช้สำหรับกรณีส่วนใหญ่
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // ความปลอดภัย: ตัวตรวจสอบการยืมไม่ฉลาดพอที่จะให้เราใช้ `buf`
    // ใน branch ที่สองดังนั้นเราจึงซักตลอดอายุการใช้งานที่นี่
    // แต่เราจะใช้ `buf` อีกครั้งหาก `format_exact_opt` ส่งคืน `None` ดังนั้นจึงไม่เป็นไร
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}