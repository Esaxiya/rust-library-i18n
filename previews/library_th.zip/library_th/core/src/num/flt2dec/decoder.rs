//! ถอดรหัสค่าทศนิยมออกเป็นแต่ละส่วนและช่วงข้อผิดพลาด

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// ค่า จำกัด ที่ไม่ได้ลงนามที่ถอดรหัสแล้วเช่น:
///
/// - ค่าเดิมเท่ากับ `mant * 2^exp`
///
/// - ตัวเลขใด ๆ ตั้งแต่ `(mant - minus)*2^exp` ถึง `(mant + plus)* 2^exp` จะปัดเศษเป็นค่าดั้งเดิม
/// ช่วงจะรวมเฉพาะเมื่อ `inclusive` คือ `true`
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// ตั๊กแตนตำข้าวที่ปรับขนาด
    pub mant: u64,
    /// ช่วงข้อผิดพลาดที่ต่ำกว่า
    pub minus: u64,
    /// ช่วงข้อผิดพลาดด้านบน
    pub plus: u64,
    /// เลขชี้กำลังที่ใช้ร่วมกันในฐาน 2
    pub exp: i16,
    /// เป็นจริงเมื่อรวมช่วงข้อผิดพลาด
    ///
    /// ใน IEEE 754 นี่เป็นความจริงเมื่อตั๊กแตนตำหรับ
    pub inclusive: bool,
}

/// ค่าที่ไม่ได้ลงนามที่ถอดรหัส
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinities ไม่ว่าจะเป็นบวกหรือลบ
    Infinite,
    /// ศูนย์ไม่ว่าจะเป็นบวกหรือลบ
    Zero,
    /// จำกัด ตัวเลขด้วยฟิลด์ที่ถอดรหัสเพิ่มเติม
    Finite(Decoded),
}

/// ประเภทจุดลอยตัวซึ่งสามารถ "ถอดรหัส" ได้
pub trait DecodableFloat: RawFloat + Copy {
    /// ค่ามาตรฐานขั้นต่ำที่เป็นบวก
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// ส่งคืนเครื่องหมาย (จริงเมื่อเป็นค่าลบ) และค่า `FullDecoded` จากตัวเลขทศนิยมที่กำหนด
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // เพื่อนบ้าน: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode จะรักษาเลขชี้กำลังไว้เสมอดังนั้นแมนทิสซาจึงถูกปรับขนาดสำหรับสูตรย่อย
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // เพื่อนบ้าน: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // โดยที่ maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // เพื่อนบ้าน: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}