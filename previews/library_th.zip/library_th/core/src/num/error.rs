//! ประเภทข้อผิดพลาดสำหรับการแปลงเป็นประเภทอินทิกรัล

use crate::convert::Infallible;
use crate::fmt;

/// ประเภทข้อผิดพลาดส่งกลับเมื่อการแปลงชนิดอินทิกรัลที่ตรวจสอบล้มเหลว
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // จับคู่แทนที่จะบังคับเพื่อให้แน่ใจว่ารหัสเช่น `From<Infallible> for TryFromIntError` ด้านบนจะทำงานต่อไปเมื่อ `Infallible` กลายเป็นนามแฝงของ `!`
        //
        //
        match never {}
    }
}

/// ข้อผิดพลาดที่สามารถส่งคืนได้เมื่อแยกวิเคราะห์จำนวนเต็ม
///
/// ข้อผิดพลาดนี้ใช้เป็นประเภทข้อผิดพลาดสำหรับฟังก์ชัน `from_str_radix()` ในประเภทจำนวนเต็มดั้งเดิมเช่น [`i8::from_str_radix`]
///
/// # สาเหตุที่เป็นไปได้
///
/// ในบรรดาสาเหตุอื่น ๆ `ParseIntError` สามารถถูกโยนได้เนื่องจากช่องว่างที่นำหน้าหรือต่อท้ายในสตริงเช่นเมื่อได้รับจากอินพุตมาตรฐาน
///
/// การใช้วิธี [`str::trim()`] ช่วยให้มั่นใจได้ว่าไม่มีช่องว่างใด ๆ เหลืออยู่ก่อนการแยกวิเคราะห์
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum เพื่อจัดเก็บข้อผิดพลาดประเภทต่างๆที่อาจทำให้การแยกวิเคราะห์จำนวนเต็มล้มเหลว
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// ค่าที่กำลังแยกวิเคราะห์ว่างเปล่า
    ///
    /// ในบรรดาสาเหตุอื่น ๆ ตัวแปรนี้จะถูกสร้างขึ้นเมื่อแยกวิเคราะห์สตริงว่าง
    Empty,
    /// มีตัวเลขที่ไม่ถูกต้องในบริบท
    ///
    /// ในบรรดาสาเหตุอื่น ๆ ตัวแปรนี้จะถูกสร้างขึ้นเมื่อแยกวิเคราะห์สตริงที่มีอักขระที่ไม่ใช่ ASCII
    ///
    /// ตัวแปรนี้ยังสร้างขึ้นเมื่อ `+` หรือ `-` ถูกใส่ผิดตำแหน่งภายในสตริงไม่ว่าจะเป็นของตัวเองหรืออยู่ตรงกลางของตัวเลข
    ///
    ///
    InvalidDigit,
    /// จำนวนเต็มมีขนาดใหญ่เกินไปที่จะจัดเก็บในประเภทจำนวนเต็มเป้าหมาย
    PosOverflow,
    /// จำนวนเต็มมีขนาดเล็กเกินไปที่จะจัดเก็บในประเภทจำนวนเต็มเป้าหมาย
    NegOverflow,
    /// ค่าเป็นศูนย์
    ///
    /// ตัวแปรนี้จะถูกปล่อยออกมาเมื่อสตริงการแยกวิเคราะห์มีค่าเป็นศูนย์ซึ่งจะผิดกฎหมายสำหรับประเภทที่ไม่ใช่ศูนย์
    ///
    Zero,
}

impl ParseIntError {
    /// แสดงสาเหตุโดยละเอียดของการแยกวิเคราะห์จำนวนเต็มล้มเหลว
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}