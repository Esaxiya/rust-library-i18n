//! ค่าคงที่สำหรับประเภทจำนวนเต็ม 16 บิตที่ลงนาม
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! รหัสใหม่ควรใช้ค่าคงที่ที่เกี่ยวข้องโดยตรงกับประเภทดั้งเดิม

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }