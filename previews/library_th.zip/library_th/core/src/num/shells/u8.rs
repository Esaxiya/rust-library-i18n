//! ค่าคงที่สำหรับประเภทจำนวนเต็ม 8 บิตที่ไม่ได้ลงชื่อ
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! รหัสใหม่ควรใช้ค่าคงที่ที่เกี่ยวข้องโดยตรงกับประเภทดั้งเดิม

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }