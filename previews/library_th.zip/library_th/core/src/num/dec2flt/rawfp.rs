//! เล่นซอเล็กน้อยกับการลอยตัวของ IEEE 754 ที่เป็นบวกตัวเลขติดลบไม่ใช่และไม่จำเป็นต้องจัดการ
//! ตัวเลขจุดลอยตัวปกติมีการแทนมาตรฐานเป็น (frac, exp) ดังนั้นค่าคือ 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) โดยที่ N คือจำนวนบิต
//!
//! Subnormals แตกต่างกันเล็กน้อยและแปลก ๆ แต่ก็ใช้หลักการเดียวกัน
//!
//! อย่างไรก็ตามในที่นี้เราแทนค่าเหล่านี้เป็น (sig, k) ด้วย f บวกดังนั้นค่าคือ f *
//! 2 <sup>จ</sup> .นอกเหนือจากการทำให้ "hidden bit" ชัดเจนแล้วสิ่งนี้จะเปลี่ยนเลขชี้กำลังโดยการเปลี่ยนแมนทิสซาที่เรียกว่า
//!
//! กล่าวอีกนัยหนึ่งการลอยตัวปกติจะเขียนเป็น (1) แต่ที่นี่จะเขียนเป็น (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! เราเรียก (1) ว่า **การแสดงเศษส่วน** และ (2) ว่า **การแสดงเชิงปริพันธ์**
//!
//! ฟังก์ชันหลายอย่างในโมดูลนี้จัดการเฉพาะตัวเลขปกติเท่านั้นกิจวัตร dec2flt ใช้เส้นทางช้าที่ถูกต้องสากล (อัลกอริทึม M) สำหรับตัวเลขที่น้อยและมาก
//! อัลกอริทึมนั้นต้องการ next_float() เท่านั้นซึ่งจัดการกับ subnormals และ zeros
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// ผู้ช่วย trait เพื่อหลีกเลี่ยงการทำซ้ำรหัสการแปลงทั้งหมดสำหรับ `f32` และ `f64`
///
/// ดูข้อคิดเห็นเอกสารของโมดูลหลักว่าเหตุใดจึงจำเป็น
///
/// ควร **ไม่เคย** ถูกนำไปใช้กับประเภทอื่นหรือใช้นอกโมดูล dec2flt
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// ประเภทที่ใช้โดย `to_bits` และ `from_bits`
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// ทำการแปลงข้อมูลดิบเป็นจำนวนเต็ม
    fn to_bits(self) -> Self::Bits;

    /// ทำการแปลงข้อมูลดิบจากจำนวนเต็ม
    fn from_bits(v: Self::Bits) -> Self;

    /// ส่งคืนหมวดหมู่ที่ตัวเลขนี้อยู่
    fn classify(self) -> FpCategory;

    /// ส่งคืน mantissa เลขชี้กำลังและลงชื่อเป็นจำนวนเต็ม
    fn integer_decode(self) -> (u64, i16, i8);

    /// ถอดรหัสการลอย
    fn unpack(self) -> Unpacked;

    /// ร่ายจากจำนวนเต็มขนาดเล็กที่สามารถแทนค่าได้ทั้งหมด
    /// Panic หากไม่สามารถแทนค่าจำนวนเต็มได้โค้ดอื่น ๆ ในโมดูลนี้จะไม่ปล่อยให้สิ่งนั้นเกิดขึ้น
    fn from_int(x: u64) -> Self;

    /// รับค่า 10 <sup>e</sup> จากตารางคำนวณล่วงหน้า
    /// Panics สำหรับ `e >= CEIL_LOG5_OF_MAX_SIG`
    fn short_fast_pow10(e: usize) -> Self;

    /// ชื่ออะไรเอ่ย.
    /// มันง่ายกว่าที่จะฮาร์ดโค้ดมากกว่าการเล่นกลที่อยู่ภายในและหวังว่า LLVM คงที่จะพับมัน
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // อนุรักษนิยมที่ผูกไว้กับตัวเลขทศนิยมของอินพุตที่ไม่สามารถสร้างโอเวอร์โฟลว์หรือเป็นศูนย์หรือ
    /// subnormals.อาจเป็นเลขชี้กำลังของค่าปกติสูงสุดดังนั้นชื่อ
    const MAX_NORMAL_DIGITS: usize;

    /// เมื่อเลขฐานสิบที่สำคัญที่สุดมีค่าสถานที่มากกว่านี้จำนวนนั้นจะถูกปัดเศษเป็นอนันต์
    ///
    const INF_CUTOFF: i64;

    /// เมื่อเลขฐานสิบที่สำคัญที่สุดมีค่าตำแหน่งน้อยกว่านี้จำนวนนั้นจะถูกปัดเศษเป็นศูนย์อย่างแน่นอน
    ///
    const ZERO_CUTOFF: i64;

    /// จำนวนบิตในเลขชี้กำลัง
    const EXP_BITS: u8;

    /// จำนวนบิตในนัยสำคัญ *รวมทั้ง* บิตที่ซ่อนอยู่
    const SIG_BITS: u8;

    /// จำนวนบิตในนัยสำคัญ *ไม่รวม* บิตที่ซ่อนอยู่
    const EXPLICIT_SIG_BITS: u8;

    /// เลขชี้กำลังทางกฎหมายสูงสุดในการแสดงเศษส่วน
    const MAX_EXP: i16;

    /// เลขชี้กำลังทางกฎหมายขั้นต่ำในการแสดงเศษส่วนโดยไม่รวมบรรทัดฐานย่อย
    const MIN_EXP: i16;

    /// `MAX_EXP` สำหรับการเป็นตัวแทนแบบอินทิกรัลกล่าวคือเมื่อใช้กะ
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` เข้ารหัส (กล่าวคือมีอคติออฟเซ็ต)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` สำหรับการเป็นตัวแทนแบบอินทิกรัลกล่าวคือเมื่อใช้กะ
    const MIN_EXP_INT: i16;

    /// นัยสำคัญปกติสูงสุดในการแทนค่าแบบอินทิกรัล
    const MAX_SIG: u64;

    /// ค่านัยสำคัญปกติขั้นต่ำในการแทนค่าแบบอินทิกรัล
    const MIN_SIG: u64;
}

// ส่วนใหญ่เป็นวิธีแก้ปัญหาสำหรับ #34344
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// ส่งคืน mantissa เลขชี้กำลังและลงชื่อเป็นจำนวนเต็ม
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // ความเอนเอียงเลขชี้กำลัง + การกะแมนทิสซา
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe ไม่แน่ใจว่า `as` รอบถูกต้องบนทุกแพลตฟอร์มหรือไม่
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// ส่งคืน mantissa เลขชี้กำลังและลงชื่อเป็นจำนวนเต็ม
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // ความเอนเอียงเลขชี้กำลัง + การกะแมนทิสซา
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe ไม่แน่ใจว่า `as` รอบถูกต้องบนทุกแพลตฟอร์มหรือไม่
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// แปลง `Fp` เป็นประเภทลอยเครื่องที่ใกล้เคียงที่สุด
/// ไม่จัดการผลลัพธ์ที่ไม่ปกติ
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f คือ 64 บิตดังนั้น xe จึงมีการกะแมนทิสซาเป็น 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// ปัดเศษนัยสำคัญ 64 บิตให้เป็นบิต T::SIG_BITS โดยมีค่าครึ่งถึงคู่
/// ไม่จัดการกับเลขชี้กำลังล้น
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // ปรับเปลี่ยน mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// ผกผันของ `RawFloat::unpack()` สำหรับตัวเลขมาตรฐาน
/// Panics ถ้านัยสำคัญหรือเลขชี้กำลังไม่ถูกต้องสำหรับตัวเลขมาตรฐาน
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // ลบบิตที่ซ่อนอยู่
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // ปรับเลขชี้กำลังสำหรับอคติเลขชี้กำลังและแมนทิสซากะ
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // เว้นบิตเครื่องหมายไว้ที่ 0 ("+") ตัวเลขของเราเป็นบวกทั้งหมด
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// สร้าง subnormalอนุญาตให้ใช้ mantissa เป็น 0 และสร้างศูนย์
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // เลขชี้กำลังที่เข้ารหัสคือ 0 บิตเครื่องหมายคือ 0 ดังนั้นเราจึงต้องตีความบิตใหม่
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// ประมาณ bignum ที่มี Fp.ปัดเศษภายใน 0.5 ULP โดยมีค่าครึ่งถึงคู่
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // เราตัดบิตทั้งหมดก่อนดัชนี `start` กล่าวคือเราเลื่อนไปทางขวาอย่างมีประสิทธิภาพด้วยจำนวน `start` ดังนั้นนี่จึงเป็นเลขชี้กำลังที่เราต้องการด้วย
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // รอบ (half-to-even) ขึ้นอยู่กับบิตที่ถูกตัดทอน
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// ค้นหาเลขทศนิยมที่ใหญ่ที่สุดซึ่งมีขนาดเล็กกว่าอาร์กิวเมนต์อย่างเคร่งครัด
/// ไม่จัดการ subnormals, zero หรือ exponent underflow
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// ค้นหาเลขทศนิยมที่เล็กที่สุดที่มีขนาดใหญ่กว่าอาร์กิวเมนต์อย่างเคร่งครัด
// การดำเนินการนี้อิ่มตัวกล่าวคือ next_float(inf) ==inf
// ซึ่งแตกต่างจากโค้ดส่วนใหญ่ในโมดูลนี้ฟังก์ชันนี้จะจัดการกับค่าศูนย์, subnormals และ infinities
// อย่างไรก็ตามเช่นเดียวกับรหัสอื่น ๆ ที่นี่จะไม่จัดการกับ NaN และจำนวนลบ
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // ดูเหมือนจะดีเกินไปที่จะเป็นจริง แต่ก็ใช้ได้ผล
        // 0.0 ถูกเข้ารหัสเป็นคำที่เป็นศูนย์ทั้งหมดSubnormals คือ 0x000m ... m โดยที่ m คือ mantissa
        // โดยเฉพาะค่ามาตรฐานย่อยที่เล็กที่สุดคือ 0x0 ... 01 และที่ใหญ่ที่สุดคือ 0x000F ... F
        // ตัวเลขปกติที่เล็กที่สุดคือ 0x0010 ... 0 ดังนั้นเคสเข้ามุมนี้ก็ใช้ได้เช่นกัน
        // ถ้าส่วนที่เพิ่มขึ้นมากเกินค่าแมนทิสซาบิตพกพาจะเพิ่มเลขชี้กำลังตามที่เราต้องการและบิตแมนทิสซาจะกลายเป็นศูนย์
        // เนื่องจากรูปแบบบิตที่ซ่อนอยู่นี้ก็เป็นสิ่งที่เราต้องการเช่นกัน!
        // สุดท้าย f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}