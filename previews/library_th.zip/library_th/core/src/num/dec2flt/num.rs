//! ฟังก์ชั่นยูทิลิตี้สำหรับ bignums ที่ไม่สมเหตุสมผลเกินไปที่จะเปลี่ยนเป็นวิธีการ

// FIXME ชื่อโมดูลนี้ค่อนข้างโชคร้ายเนื่องจากโมดูลอื่น ๆ ยังนำเข้า `core::num`

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// ทดสอบว่าการตัดทอนบิตทั้งหมดที่มีนัยสำคัญน้อยกว่า `ones_place` ทำให้เกิดข้อผิดพลาดสัมพัทธ์น้อยกว่าเท่ากับหรือมากกว่า 0.5 ULP หรือไม่
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // หากบิตที่เหลือทั้งหมดเป็นศูนย์แสดงว่า= 0.5 ULP มิฉะนั้น> 0.5 หากไม่มีบิตอีกต่อไป (half_bit==0) ด้านล่างจะคืนค่าเท่ากับอย่างถูกต้อง
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// แปลงสตริง ASCII ที่มีเฉพาะเลขฐานสิบเป็น `u64`
///
/// ไม่ทำการตรวจสอบอักขระที่ล้นหรือไม่ถูกต้องดังนั้นหากผู้โทรไม่ระมัดระวังผลลัพธ์จะเป็นของปลอมและสามารถ panic ได้ (แม้ว่าจะไม่ใช่ `unsafe` ก็ตาม)
/// นอกจากนี้สตริงว่างจะถือว่าเป็นศูนย์
/// ฟังก์ชันนี้มีอยู่เนื่องจาก
///
/// 1. การใช้ `FromStr` บน `&[u8]` ต้องใช้ `from_utf8_unchecked` ซึ่งไม่ดีและ
/// 2. การปะติดปะต่อผลลัพธ์ของ `integral.parse()` และ `fractional.parse()` นั้นซับซ้อนกว่าฟังก์ชันทั้งหมดนี้
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// แปลงสตริงของตัวเลข ASCII เป็น bignum
///
/// เช่นเดียวกับ `from_str_unchecked` ฟังก์ชันนี้อาศัยตัวแยกวิเคราะห์เพื่อกำจัดตัวเลขที่ไม่ใช่ตัวเลขออกไป
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// คลาย bignum เป็นจำนวนเต็ม 64 บิต Panics หากตัวเลขมีขนาดใหญ่เกินไป
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// แยกช่วงของบิต

/// ดัชนี 0 เป็นบิตที่มีนัยสำคัญน้อยที่สุดและเป็นช่วงที่เปิดครึ่งหนึ่งตามปกติ
/// Panics หากถูกขอให้แยกบิตมากกว่าที่จะพอดีกับประเภทการส่งคืน
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}