//! อัลกอริทึมต่างๆจากกระดาษ

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// จำนวนนัยสำคัญบิตใน Fp
const P: u32 = 64;

// เราเพียงแค่จัดเก็บค่าประมาณที่ดีที่สุดสำหรับเลขชี้กำลัง * ทั้งหมดดังนั้นตัวแปร "h" และเงื่อนไขที่เกี่ยวข้องจึงสามารถละเว้นได้
// นี่เป็นการแลกเปลี่ยนประสิทธิภาพสำหรับพื้นที่สองสามกิโลไบต์

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// ในสถาปัตยกรรมส่วนใหญ่การดำเนินการจุดลอยตัวจะมีขนาดบิตที่ชัดเจนดังนั้นความแม่นยำของการคำนวณจึงพิจารณาจากพื้นฐานต่อการดำเนินการ
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// บน x86 x87 FPU จะใช้สำหรับการดำเนินการแบบลอยหากไม่มีส่วนขยาย SSE/SSE2
// x87 FPU ทำงานด้วยความแม่นยำ 80 บิตตามค่าเริ่มต้นซึ่งหมายความว่าการดำเนินการจะปัดเศษเป็น 80 บิตทำให้การปัดเศษสองครั้งเกิดขึ้นเมื่อในที่สุดค่าจะแสดงเป็น
//
// 32/64 ค่าบิตลอยเพื่อเอาชนะสิ่งนี้คุณสามารถตั้งค่าคำควบคุม FPU เพื่อให้การคำนวณดำเนินไปด้วยความแม่นยำที่ต้องการ
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// โครงสร้างที่ใช้เพื่อรักษาค่าดั้งเดิมของคำควบคุม FPU เพื่อให้สามารถเรียกคืนได้เมื่อโครงสร้างหลุด
    ///
    ///
    /// x87 FPU เป็นรีจิสเตอร์ 16 บิตซึ่งมีฟิลด์ดังนี้:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// เอกสารสำหรับฟิลด์ทั้งหมดมีอยู่ในคู่มือสำหรับนักพัฒนาซอฟต์แวร์สถาปัตยกรรม IA-32 (เล่ม 1)
    ///
    /// ฟิลด์เดียวที่เกี่ยวข้องกับรหัสต่อไปนี้คือ PC, Precision Control
    /// ฟิลด์นี้กำหนดความแม่นยำของการดำเนินการโดย FPU
    /// สามารถตั้งค่าเป็น:
    ///  - 0b00 ความแม่นยำเดียวคือ 32 บิต
    ///  - 0b10, ความแม่นยำสองเท่าเช่น 64 บิต
    ///  - 0b11, ความแม่นยำที่เพิ่มขึ้นสองเท่าเช่น 80 บิต (สถานะเริ่มต้น) ค่า 0b01 ถูกสงวนไว้และไม่ควรใช้
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // ความปลอดภัย: คำสั่ง `fldcw` ได้รับการตรวจสอบแล้วว่าสามารถทำงานได้อย่างถูกต้อง
        // `u16` ใด ๆ
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: เรากำลังใช้ไวยากรณ์ ATT เพื่อรองรับ LLVM 8 และ LLVM 9
                options(att_syntax, nostack),
            )
        }
    }

    /// ตั้งค่าฟิลด์ความแม่นยำของ FPU เป็น `T` และส่งคืน `FPUControlWord`
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // คำนวณค่าสำหรับฟิลด์ Precision Control ที่เหมาะสมสำหรับ `T`
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 บิต
            8 => 0x0200, // 64 บิต
            _ => 0x0300, // ค่าเริ่มต้น 80 บิต
        };

        // รับค่าดั้งเดิมของคำควบคุมเพื่อเรียกคืนในภายหลังเมื่อโครงสร้าง `FPUControlWord` ลดลง SAFETY: คำสั่ง `fnstcw` ได้รับการตรวจสอบแล้วว่าสามารถทำงานได้อย่างถูกต้องกับ `u16` ใด ๆ
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: เรากำลังใช้ไวยากรณ์ ATT เพื่อรองรับ LLVM 8 และ LLVM 9
                options(att_syntax, nostack),
            )
        }

        // ตั้งค่าคำควบคุมเป็นความแม่นยำที่ต้องการ
        // สิ่งนี้ทำได้โดยการปิดบังความแม่นยำเก่า (บิต 8 และ 9, 0x300) และแทนที่ด้วยแฟล็กความแม่นยำที่คำนวณด้านบน
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// เส้นทางที่รวดเร็วของ Bellerophon โดยใช้จำนวนเต็มขนาดเครื่องจักรและการลอยตัว
///
/// สิ่งนี้ถูกแยกออกเป็นฟังก์ชันแยกต่างหากเพื่อให้สามารถทดลองใช้ก่อนสร้าง bignum
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95
    // เราเปรียบเทียบค่าที่แน่นอนกับ MAX_SIG ใกล้จุดสิ้นสุดนี่เป็นเพียงการปฏิเสธที่รวดเร็วและราคาถูก (และยังช่วยให้โค้ดส่วนที่เหลือไม่ต้องกังวลเกี่ยวกับการล้น)
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // เส้นทางที่รวดเร็วขึ้นอยู่กับการคำนวณทางคณิตศาสตร์เป็นจำนวนบิตที่ถูกต้องโดยไม่มีการปัดเศษตรงกลาง
    // บน x86 (ไม่มี SSE หรือ SSE2) สิ่งนี้ต้องการความแม่นยำของสแต็ก x87 FPU ที่จะเปลี่ยนเพื่อให้ปัดเศษเป็นบิต 64/32 โดยตรง
    // ฟังก์ชั่น `set_precision` ดูแลการตั้งค่าความแม่นยำบนสถาปัตยกรรมที่ต้องการการตั้งค่าโดยการเปลี่ยนสถานะส่วนกลาง (เช่นคำควบคุมของ x87 FPU)
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // เคส e <0 ไม่สามารถพับลงใน branch อื่นได้
    // พลังเชิงลบส่งผลให้เกิดส่วนที่เป็นเศษส่วนซ้ำในไบนารีซึ่งจะถูกปัดเศษซึ่งทำให้เกิดข้อผิดพลาดจริง (และบางครั้งค่อนข้างสำคัญ!) ในผลลัพธ์สุดท้าย
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// อัลกอริทึม Bellerophon เป็นรหัสเล็กน้อยที่ได้รับการพิสูจน์โดยการวิเคราะห์ตัวเลขที่ไม่สำคัญ
///
/// มันจะปัดเศษ `` f '' เป็นทศนิยมที่มีนัยสำคัญ 64 บิตและคูณด้วยค่าประมาณที่ดีที่สุดของ `10^e` (ในรูปแบบจุดลอยตัวเดียวกัน)ซึ่งมักจะเพียงพอที่จะได้ผลลัพธ์ที่ถูกต้อง
/// อย่างไรก็ตามเมื่อผลลัพธ์อยู่ใกล้กึ่งกลางระหว่างการลอยตัว (ordinary) สองตัวที่อยู่ติดกันข้อผิดพลาดในการปัดเศษแบบผสมจากการคูณสองการประมาณหมายความว่าผลลัพธ์อาจจะปิดโดยไม่กี่บิต
/// เมื่อเกิดเหตุการณ์นี้ Algorithm R แบบวนซ้ำจะแก้ไขปัญหาต่างๆ
///
/// Hand-wavy "close to halfway" ถูกสร้างขึ้นอย่างแม่นยำโดยการวิเคราะห์ตัวเลขในกระดาษ
/// ในคำพูดของ Clinger:
///
/// > Slop ซึ่งแสดงในหน่วยของบิตที่มีนัยสำคัญน้อยที่สุดคือการรวมขอบเขตสำหรับข้อผิดพลาด
/// > สะสมระหว่างการคำนวณจุดลอยตัวของค่าประมาณถึง f * 10 ^ e (Slop คือ
/// > ไม่ใช่ขอบเขตสำหรับข้อผิดพลาดที่แท้จริง แต่มีขอบเขตความแตกต่างระหว่างค่าประมาณ z และ
/// > การประมาณที่ดีที่สุดที่เป็นไปได้ที่ใช้ p บิตของนัยสำคัญ)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // กรณี abs(e) <log5(2^N) อยู่ใน fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Slop มีขนาดใหญ่พอที่จะสร้างความแตกต่างเมื่อปัดเศษเป็น n บิตหรือไม่?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// อัลกอริทึมแบบวนซ้ำที่ปรับปรุงการประมาณจุดลอยตัวของ `f * 10^e`
///
/// การวนซ้ำแต่ละครั้งจะทำให้หน่วยหนึ่งในตำแหน่งสุดท้ายใกล้เข้ามามากขึ้นซึ่งแน่นอนว่าต้องใช้เวลานานมากในการมาบรรจบกันหาก `z0` ปิดอยู่เล็กน้อย
/// โชคดีที่เมื่อใช้เป็นทางเลือกสำหรับ Bellerophon การประมาณเริ่มต้นจะถูกปิดโดย ULP มากที่สุดหนึ่งรายการ
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // หาจำนวนเต็มบวก `x`, `y` เพื่อให้ `x / y` เท่ากับ `(f *10^e) / (m* 2^k)`
        // สิ่งนี้ไม่เพียง แต่หลีกเลี่ยงการจัดการกับสัญญาณของ `e` และ `k` แต่เรายังกำจัดพลังของสองสามัญคือ `10^e` และ `2^k` เพื่อทำให้ตัวเลขมีขนาดเล็กลง
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // สิ่งนี้เขียนขึ้นอย่างเชื่องช้าเล็กน้อยเนื่องจาก bignums ของเราไม่รองรับตัวเลขติดลบดังนั้นเราจึงใช้ข้อมูลเครื่องหมาย + ค่าสัมบูรณ์
        // การคูณด้วย m_digits ไม่สามารถล้นได้
        // หาก `x` หรือ `y` มีขนาดใหญ่พอที่เราต้องกังวลเกี่ยวกับการล้นแสดงว่ามีขนาดใหญ่พอที่ `make_ratio` จะลดเศษส่วนลงได้ 2 ^ 64 หรือมากกว่า
        //
        //
        let (d2, d_negative) = if x >= y {
            // ไม่ต้องการ x อีกต่อไปบันทึก clone()
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // ยังคงต้องการ y ทำสำเนา
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// กำหนดให้ `x = f` และ `y = m` โดยที่ `f` แสดงตัวเลขทศนิยมที่ป้อนตามปกติและ `m` คือนัยสำคัญของการประมาณจุดลอยตัวทำให้อัตราส่วน `x / y` เท่ากับ `(f *10^e) / (m* 2^k)` ซึ่งอาจลดลงด้วยกำลังสองทั้งสองอย่างที่มีเหมือนกัน
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, ยกเว้นว่าเราลดเศษส่วนด้วยกำลังสอง
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m สิ่งนี้ไม่สามารถล้นได้เนื่องจากต้องใช้ `e` บวกและ `k` เชิงลบซึ่งจะเกิดขึ้นได้เฉพาะกับค่าที่ใกล้เคียงกับ 1 มากเท่านั้นซึ่งหมายความว่า `e` และ `k` จะค่อนข้างเล็ก
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k สิ่งนี้ไม่สามารถล้นได้เช่นกันดูด้านบน
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e) ลดอีกครั้งด้วยกำลังร่วมสอง
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// ตามแนวคิดแล้วอัลกอริทึม M เป็นวิธีที่ง่ายที่สุดในการแปลงทศนิยมให้เป็นทศนิยม
///
/// เราสร้างอัตราส่วนที่เท่ากับ `f * 10^e` จากนั้นทุ่มกำลังสองจนกว่าจะได้ค่าความสำคัญลอยตัวที่ถูกต้อง
/// เลขยกกำลังไบนารี `k` คือจำนวนครั้งที่เราคูณตัวเศษหรือตัวส่วนด้วยสองเช่นตลอดเวลา `f *10^e` เท่ากับ `(u / v)* 2^k`
/// เมื่อเราพบความสำคัญแล้วเราจะต้องปัดเศษโดยการตรวจสอบส่วนที่เหลือของการหารซึ่งทำในฟังก์ชันตัวช่วยเพิ่มเติมด้านล่าง
///
///
/// อัลกอริทึมนี้ทำงานช้ามากแม้ว่าจะมีการเพิ่มประสิทธิภาพที่อธิบายไว้ใน `quick_start()` ก็ตาม
/// อย่างไรก็ตามอัลกอริทึมเป็นวิธีที่ง่ายที่สุดในการปรับให้เข้ากับผลลัพธ์ที่มากเกินไปการไหลน้อยและผลที่ไม่ปกติ
/// การใช้งานนี้จะเกิดขึ้นเมื่อ Bellerophon และ Algorithm R ถูกครอบงำ
/// การตรวจจับการไหลล้นและการล้นเป็นเรื่องง่าย: อัตราส่วนยังคงไม่เป็นนัยสำคัญในช่วง แต่ถึงเลขชี้กำลัง minimum/maximum แล้ว
/// ในกรณีของการล้นเราเพียงแค่คืนค่าอินฟินิตี้
///
/// การจัดการ underflow และ subnormals นั้นยุ่งยากกว่า
/// ปัญหาใหญ่อย่างหนึ่งคือด้วยเลขชี้กำลังขั้นต่ำอัตราส่วนอาจยังใหญ่เกินไปสำหรับนัยสำคัญ
/// ดู underflow() สำหรับรายละเอียด
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // การเพิ่มประสิทธิภาพที่เป็นไปได้ของ FIXME: กำหนด big_to_fp เพื่อให้เราสามารถเทียบเท่ากับ fp_to_float(big_to_fp(u)) ได้ที่นี่โดยไม่ต้องปัดเศษสองครั้ง
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // เราต้องหยุดที่เลขชี้กำลังต่ำสุดถ้าเรารอจนถึง `k < T::MIN_EXP_INT` เราก็จะได้ตัวคูณสอง
            // น่าเสียดายที่นั่นหมายความว่าเราต้องใช้ตัวเลขปกติกรณีพิเศษที่มีเลขชี้กำลังต่ำสุด
            // FIXME พบสูตรที่หรูหรากว่า แต่เรียกใช้การทดสอบ `tiny-pow10` เพื่อให้แน่ใจว่าถูกต้องจริง!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// ข้ามการทำซ้ำอัลกอริทึม M ส่วนใหญ่โดยตรวจสอบความยาวบิต
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // ความยาวบิตคือค่าประมาณของลอการิทึมฐานสองและ log(u / v) = log(u), log(v)
    // ค่าประมาณจะปิดโดยมากที่สุด 1 แต่มักจะต่ำกว่าประมาณการดังนั้นข้อผิดพลาดบน log(u) และ log(v) จึงเป็นเครื่องหมายเดียวกันและยกเลิก (หากทั้งคู่มีขนาดใหญ่)
    // ดังนั้นข้อผิดพลาดสำหรับ log(u / v) จึงมีมากที่สุดเช่นกัน
    // อัตราส่วนเป้าหมายคือค่าหนึ่งที่ u/v อยู่ในช่วงสำคัญดังนั้นเงื่อนไขการยุติของเราคือ log2(u / v) เป็นบิตสำคัญ plus/minus หนึ่ง
    // FIXME การพิจารณาบิตที่สองสามารถปรับปรุงการประมาณค่าและหลีกเลี่ยงการหารเพิ่มเติมได้
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Underflow หรือ subnormalปล่อยให้เป็นฟังก์ชันหลัก
            break;
        }
        if *k == T::MAX_EXP_INT {
            // ล้น.ปล่อยให้เป็นฟังก์ชันหลัก
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // อัตราส่วนไม่ใช่นัยสำคัญในช่วงที่มีเลขชี้กำลังต่ำสุดดังนั้นเราจำเป็นต้องปัดเศษบิตส่วนเกินออกและปรับเลขชี้กำลังให้เหมาะสม
    // มูลค่าที่แท้จริงตอนนี้มีลักษณะดังนี้:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc (แสดงโดย rem)
    //
    // ดังนั้นเมื่อบิตที่ปัดเศษคือ!= 0.5 ULP พวกเขาจะตัดสินใจการปัดเศษด้วยตัวเอง
    // เมื่อค่าเท่ากันและส่วนที่เหลือไม่เป็นศูนย์ค่ายังคงต้องปัดเศษขึ้น
    // เฉพาะเมื่อบิตที่ปัดเศษเป็น 1/2 และส่วนที่เหลือเป็นศูนย์เราจะมีสถานการณ์ครึ่งเดียวถึงคู่
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// รอบ-ถึง-คู่ธรรมดาทำให้สับสนโดยต้องปัดเศษตามส่วนที่เหลือของการหาร
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}