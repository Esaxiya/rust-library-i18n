//! การแปลงสตริงทศนิยมเป็นเลขทศนิยมไบนารี IEEE 754
//!
//! # คำชี้แจงปัญหา
//!
//! เราได้รับสตริงทศนิยมเช่น `12.34e56`
//! สตริงนี้ประกอบด้วยอินทิกรัล (`12`), (`34`) เศษส่วนและส่วนเอ็กซ์โปเนนต์ (`56`) ชิ้นส่วนทั้งหมดเป็นทางเลือกและตีความว่าเป็นศูนย์เมื่อขาดหายไป
//!
//! เราค้นหาเลขทศนิยมของ IEEE 754 ที่ใกล้เคียงกับค่าที่แน่นอนของสตริงทศนิยมมากที่สุด
//! เป็นที่ทราบกันดีอยู่แล้วว่าสตริงทศนิยมจำนวนมากไม่มีการยุติการแทนค่าในฐานสองดังนั้นเราจึงปัดเศษเป็นหน่วย 0.5 ในตำแหน่งสุดท้าย (กล่าวอีกนัยหนึ่งก็คือเป็นไปได้เช่นกัน)
//! ความสัมพันธ์ค่าทศนิยมครึ่งทางระหว่างการลอยตัวสองครั้งติดต่อกันได้รับการแก้ไขด้วยกลยุทธ์ครึ่งต่อคู่หรือที่เรียกว่าการปัดเศษของนายธนาคาร
//!
//! ไม่จำเป็นต้องพูดสิ่งนี้ค่อนข้างยากทั้งในแง่ของความซับซ้อนในการใช้งานและในแง่ของวงจร CPU ที่ดำเนินการ
//!
//! # Implementation
//!
//! อันดับแรกเราไม่สนใจสัญญาณหรือเราจะลบออกในตอนเริ่มต้นของกระบวนการแปลงและนำมาใช้ใหม่ในตอนท้ายสุด
//! สิ่งนี้ถูกต้องในกรณี edge ทั้งหมดเนื่องจากการลอยของ IEEE นั้นสมมาตรรอบศูนย์การลบเพียงแค่พลิกบิตแรก
//!
//! จากนั้นเราจะลบจุดทศนิยมโดยการปรับเลขชี้กำลัง: ตามแนวคิด `12.34e56` จะเปลี่ยนเป็น `1234e54` ซึ่งเราอธิบายด้วยจำนวนเต็มบวก `f = 1234` และจำนวนเต็ม `e = 54`
//! การแทนค่า `(f, e)` ถูกใช้โดยโค้ดเกือบทั้งหมดที่ผ่านขั้นตอนการแยกวิเคราะห์
//!
//! จากนั้นเราจะลองห่วงโซ่ยาวของกรณีพิเศษทั่วไปและราคาแพงขึ้นเรื่อย ๆ โดยใช้จำนวนเต็มขนาดเครื่องจักรและตัวเลขทศนิยมขนาดเล็กขนาดคงที่ (`f32`/`f64` แรกจากนั้นเป็นประเภทที่มีนัยสำคัญ 64 บิตและ `Fp`)
//!
//! เมื่อสิ่งเหล่านี้ล้มเหลวเราจะกัดกระสุนและใช้อัลกอริทึมที่เรียบง่าย แต่ช้ามากซึ่งเกี่ยวข้องกับการประมวลผล `f * 10^e` อย่างเต็มที่และทำการค้นหาซ้ำเพื่อหาค่าประมาณที่ดีที่สุด
//!
//! โดยพื้นฐานแล้วโมดูลนี้และลูก ๆ จะใช้อัลกอริทึมที่อธิบายไว้ใน:
//! "How to Read Floating Point Numbers Accurately" โดย William D.
//! Clinger พร้อมให้บริการทางออนไลน์: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! นอกจากนี้ยังมีฟังก์ชั่นตัวช่วยมากมายที่ใช้ในกระดาษ แต่ไม่มีใน Rust (หรืออย่างน้อยก็ในแกนกลาง)
//! เวอร์ชันของเรามีความซับซ้อนเพิ่มเติมจากความจำเป็นในการจัดการกับการล้นและการไหลน้อยและความปรารถนาที่จะจัดการกับตัวเลขที่ไม่ปกติ
//! Bellerophon และ Algorithm R มีปัญหากับการล้น, subnormals และ underflow
//! เราเปลี่ยนไปใช้อัลกอริทึม M อย่างระมัดระวัง (ด้วยการปรับเปลี่ยนที่อธิบายไว้ในหัวข้อที่ 8 ของเอกสาร) ให้ดีก่อนที่อินพุตจะเข้าสู่พื้นที่วิกฤต
//!
//! อีกแง่มุมหนึ่งที่ต้องให้ความสนใจคือ ``RawFloat`` trait ซึ่งฟังก์ชั่นเกือบทั้งหมดเป็นพารามิเตอร์อาจมีคนคิดว่ามันเพียงพอที่จะแยกวิเคราะห์เป็น `f64` และส่งผลลัพธ์เป็น `f32`
//! น่าเสียดายที่นี่ไม่ใช่โลกที่เราอาศัยอยู่และสิ่งนี้ไม่เกี่ยวข้องกับการใช้ฐานสองหรือการปัดเศษครึ่งถึงคู่
//!
//! พิจารณาตัวอย่างเช่น `d2` และ `d4` สองประเภทที่แสดงประเภททศนิยมที่มีทศนิยมสองหลักและทศนิยมสี่หลักแต่ละตัวและใช้ "0.01499" เป็นอินพุตลองใช้การปัดเศษครึ่งขึ้น
//! การไปที่ทศนิยมสองหลักโดยตรงจะให้ `0.01` แต่ถ้าเราปัดเศษเป็นสี่หลักก่อนเราจะได้ `0.0150` ซึ่งจะปัดเศษเป็น `0.02`
//! หลักการเดียวกันนี้ใช้กับการดำเนินการอื่น ๆ เช่นกันหากคุณต้องการความแม่นยำของ 0.5 ULP คุณต้องทำ *ทุกอย่าง* ด้วยความแม่นยำเต็มและรอบ *ครั้งเดียวในตอนท้าย* โดยพิจารณาบิตที่ถูกตัดทอนทั้งหมดพร้อมกัน
//!
//! FIXME: แม้ว่าจำเป็นต้องมีการทำสำเนาโค้ดบางส่วน แต่บางส่วนของโค้ดอาจมีการสับเปลี่ยนเพื่อให้โค้ดซ้ำกันน้อยลง
//! ส่วนใหญ่ของอัลกอริทึมไม่ขึ้นอยู่กับประเภทโฟลตไปยังเอาต์พุตหรือต้องการเพียงการเข้าถึงค่าคงที่ไม่กี่ค่าซึ่งสามารถส่งผ่านเป็นพารามิเตอร์ได้
//!
//! # Other
//!
//! การแปลงควร *ไม่* panic
//! มีการยืนยันและ panics อย่างชัดเจนในรหัส แต่ไม่ควรถูกเรียกใช้และใช้เป็นการตรวจสอบสติสัมปชัญญะภายในเท่านั้น panics ใด ๆ ควรได้รับการพิจารณาว่าเป็นจุดบกพร่อง
//!
//! มีการทดสอบหน่วย แต่การทดสอบยังไม่เพียงพอในการตรวจสอบความถูกต้องซึ่งครอบคลุมข้อผิดพลาดที่เป็นไปได้เพียงเล็กน้อยเท่านั้น
//! การทดสอบที่ครอบคลุมมากขึ้นจะอยู่ในไดเร็กทอรี `src/etc/test-float-parse` เป็นสคริปต์ Python
//!
//! หมายเหตุเกี่ยวกับจำนวนเต็มล้น: หลายส่วนของไฟล์นี้คำนวณเลขคณิตด้วยเลขชี้กำลังทศนิยม `e`
//! โดยพื้นฐานแล้วเราจะเลื่อนจุดทศนิยมไปรอบ ๆ: ก่อนเลขฐานสิบหลักตัวแรกหลังเลขฐานสิบตัวสุดท้ายและอื่น ๆสิ่งนี้อาจล้นหากทำอย่างไม่ระมัดระวัง
//! เราอาศัยโมดูลย่อยที่แยกวิเคราะห์เพื่อแจกเฉพาะเลขชี้กำลังที่มีขนาดเล็กเพียงพอโดยที่ "sufficient" หมายถึง "such that the exponent +/- the number of decimal digits fits into a 64 bit integer"
//! เรายอมรับเลขชี้กำลังที่ใหญ่กว่า แต่เราไม่ได้คำนวณเลขคณิตกับพวกมันพวกมันจะกลายเป็น {positive,negative} {zero,infinity} ทันที
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// สองคนนี้มีการทดสอบของตัวเอง
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// แปลงสตริงในฐาน 10 เป็นลอย
            /// ยอมรับเลขชี้กำลังทศนิยมที่เป็นทางเลือก
            ///
            /// ฟังก์ชันนี้ยอมรับสตริงเช่น
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', หรือเทียบเท่า '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', หรือเทียบเท่า '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// ช่องว่างนำหน้าและต่อท้ายแสดงถึงข้อผิดพลาด
            ///
            /// # Grammar
            ///
            /// สตริงทั้งหมดที่เป็นไปตามไวยากรณ์ [EBNF] ต่อไปนี้จะส่งผลให้ [`Ok`] ถูกส่งคืน:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # ข้อบกพร่องที่เป็นที่รู้จัก
            ///
            /// ในบางสถานการณ์สตริงบางตัวที่ควรสร้าง float ที่ถูกต้องแทนที่จะส่งคืนข้อผิดพลาด
            /// ดู [issue #31407] สำหรับรายละเอียด
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src สตริง
            ///
            /// # ส่งคืนค่า
            ///
            /// `Err(ParseFloatError)` หากสตริงไม่ได้แสดงถึงตัวเลขที่ถูกต้อง
            /// มิฉะนั้น `Ok(n)` โดยที่ `n` คือตัวเลขทศนิยมที่แสดงโดย `src`
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// ข้อผิดพลาดที่สามารถส่งคืนได้เมื่อแยกวิเคราะห์ float
///
/// ข้อผิดพลาดนี้ใช้เป็นประเภทข้อผิดพลาดสำหรับการใช้งาน [`FromStr`] สำหรับ [`f32`] และ [`f64`]
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// แยกสตริงทศนิยมเป็นเครื่องหมายและส่วนที่เหลือโดยไม่ต้องตรวจสอบหรือตรวจสอบส่วนที่เหลือ
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // หากสตริงไม่ถูกต้องเราจะไม่ใช้เครื่องหมายดังนั้นเราไม่จำเป็นต้องตรวจสอบความถูกต้องที่นี่
        _ => (Sign::Positive, s),
    }
}

/// แปลงสตริงทศนิยมเป็นตัวเลขทศนิยม
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// เวิร์กฮอร์สหลักสำหรับการแปลงทศนิยมเป็นโฟลต: จัดเตรียมการประมวลผลล่วงหน้าทั้งหมดและคิดว่าอัลกอริทึมใดควรทำการแปลงจริง
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift จุดทศนิยม
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40 จำกัด ไว้ที่ 1280 บิตซึ่งแปลเป็นทศนิยมประมาณ 385 หลัก
    // หากเกินกว่านี้เราจะผิดพลาดดังนั้นเราจึงผิดพลาดก่อนที่จะเข้าใกล้เกินไป (ภายใน 10 ^ 10)
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // ตอนนี้เลขชี้กำลังพอดีกับ 16 บิตซึ่งใช้ตลอดอัลกอริทึมหลัก
    let e = e as i16;
    // FIXME ขอบเขตเหล่านี้ค่อนข้างอนุรักษ์นิยม
    // การวิเคราะห์อย่างรอบคอบมากขึ้นเกี่ยวกับโหมดความล้มเหลวของ Bellerophon อาจทำให้สามารถใช้งานได้ในหลายกรณีเพื่อเพิ่มความเร็วอย่างมาก
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// ตามที่เขียนไว้สิ่งนี้จะปรับให้เหมาะสมไม่ดี (ดู #27130 แม้ว่าจะหมายถึงรหัสรุ่นเก่า)
// `inline(always)` เป็นวิธีแก้ปัญหาสำหรับสิ่งนั้น
// โดยรวมมีไซต์การโทรเพียงสองไซต์และไม่ทำให้ขนาดโค้ดแย่ลง

/// สตริปศูนย์หากเป็นไปได้แม้ว่าจะต้องเปลี่ยนเลขชี้กำลังก็ตาม
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // การตัดค่าศูนย์เหล่านี้ไม่ได้เปลี่ยนแปลงอะไร แต่อาจเปิดใช้งานเส้นทางด่วน (<15 หลัก)
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // ลดความซับซ้อนของรูปแบบ 0.0 ... x และ x ... 0.0 โดยปรับเลขชี้กำลังให้เหมาะสม
    // นี่อาจไม่ใช่การชนะเสมอไป (อาจผลักตัวเลขบางส่วนออกจากเส้นทางที่รวดเร็ว) แต่มันทำให้ส่วนอื่น ๆ ง่ายขึ้นอย่างมาก (โดยเฉพาะอย่างยิ่งโดยประมาณขนาดของค่า)
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// ส่งคืนขอบเขตบนที่รวดเร็วและสกปรกบนขนาด (log10) ของค่าที่ใหญ่ที่สุดที่อัลกอริทึม R และอัลกอริทึม M จะคำนวณในขณะที่ทำงานกับทศนิยมที่กำหนด
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // เราไม่จำเป็นต้องกังวลมากเกินไปเกี่ยวกับการล้นที่นี่ด้วย trivial_cases() และโปรแกรมแยกวิเคราะห์ซึ่งกรองอินพุตที่รุนแรงที่สุดสำหรับเรา
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // ในกรณี e>=0 อัลกอริทึมทั้งสองจะคำนวณเกี่ยวกับ `f * 10^e`
        // อัลกอริทึม R ดำเนินการคำนวณที่ซับซ้อนบางอย่างด้วยสิ่งนี้ แต่เราสามารถเพิกเฉยต่อสิ่งนั้นสำหรับขอบเขตบนเพราะมันลดเศษส่วนล่วงหน้าด้วยดังนั้นเราจึงมีบัฟเฟอร์มากมายที่นั่น
        //
        f_len + (e as u64)
    } else {
        // ถ้า e <0 อัลกอริทึม R จะทำสิ่งเดียวกันโดยประมาณ แต่อัลกอริทึม M แตกต่างกัน:
        // มันพยายามหาจำนวนบวก k เพื่อให้ `f << k / 10^e` มีนัยสำคัญในช่วง
        // ซึ่งจะส่งผลให้ประมาณ `2^53 *f* 10^e` <`10^17 *f* 10^e`
        // อินพุตหนึ่งที่ทำให้เกิดสิ่งนี้คือ 0.33 ... 33 (375 x 3)
        f_len + e.unsigned_abs() + 17
    }
}

/// ตรวจจับการล้นและการล้นที่เห็นได้ชัดโดยไม่ต้องดูตัวเลขทศนิยม
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // มีเลขศูนย์ แต่ถูก simplify() ถอดออก
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // นี่คือค่าประมาณคร่าวๆของ ceil(log10(the real value))
    // เราไม่จำเป็นต้องกังวลมากเกินไปเกี่ยวกับการล้นที่นี่เนื่องจากความยาวอินพุตมีขนาดเล็ก (อย่างน้อยเมื่อเทียบกับ 2 ^ 64) และตัวแยกวิเคราะห์จัดการกับเลขชี้กำลังที่มีค่าสัมบูรณ์มากกว่า 10 ^ 18 อยู่แล้ว (ซึ่งยังคงสั้น 10 ^ 19 จาก 2 ^ 64)
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}