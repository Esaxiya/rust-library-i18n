//! กำหนดตัววนซ้ำที่เป็นเจ้าของ `IntoIter` สำหรับอาร์เรย์

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// ตัววนซ้ำ [array] ตามค่า
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// นี่คืออาร์เรย์ที่เรากำลังทำซ้ำ
    ///
    /// องค์ประกอบที่มีดัชนี `i` โดยที่ `alive.start <= i < alive.end` ยังไม่ได้รับผลและเป็นรายการอาร์เรย์ที่ถูกต้อง
    /// องค์ประกอบที่มีดัชนี `i < alive.start` หรือ `i >= alive.end` ได้รับผลแล้วและจะต้องไม่สามารถเข้าถึงได้อีกต่อไป!องค์ประกอบที่ตายแล้วเหล่านั้นอาจอยู่ในสถานะที่ยังไม่ได้เริ่มต้นอย่างสมบูรณ์!
    ///
    ///
    /// ดังนั้นค่าคงที่คือ:
    /// - `data[alive]` ยังมีชีวิตอยู่ (กล่าวคือมีองค์ประกอบที่ถูกต้อง)
    /// - `data[..alive.start]` และ `data[alive.end..]` ก็ตายไปแล้ว (เช่นอ่านองค์ประกอบไปแล้วและจะต้องไม่แตะต้องอีกต่อไป!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// องค์ประกอบใน `data` ที่ยังไม่ได้รับผล
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// สร้างตัววนซ้ำใหม่บน `array` ที่กำหนด
    ///
    /// *หมายเหตุ*: วิธีนี้อาจเลิกใช้ใน future หลังจาก [`IntoIterator` is implemented for arrays][array-into-iter]
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // ประเภทของ `value` คือ `i32` ที่นี่แทนที่จะเป็น `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // ความปลอดภัย: การส่งสัญญาณที่นี่ปลอดภัยจริงเอกสารของ `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` รับประกันว่าจะมีขนาดและแนวเดียวกัน
        // > เป็น `T`
        //
        // เอกสารยังแสดงการส่งสัญญาณจากอาร์เรย์ `MaybeUninit<T>` ไปยังอาร์เรย์ของ `T`
        //
        //
        // ด้วยเหตุนี้การเริ่มต้นนี้จึงเป็นไปตามค่าคงที่

        // FIXME(LukasKalbertodt): ใช้ `mem::transmute` จริงที่นี่เมื่อทำงานกับ const generics:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // ในระหว่างนี้เราสามารถใช้ `mem::transmute_copy` เพื่อสร้างสำเนาบิตเป็นประเภทอื่นจากนั้นลืม `array` เพื่อไม่ให้ตกหล่น
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// ส่งคืนชิ้นส่วนที่ไม่เปลี่ยนรูปขององค์ประกอบทั้งหมดที่ยังไม่ได้รับผล
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // ความปลอดภัย: เราทราบดีว่าองค์ประกอบทั้งหมดภายใน `alive` ได้รับการเริ่มต้นอย่างเหมาะสม
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// ส่งคืนชิ้นส่วนที่ไม่แน่นอนขององค์ประกอบทั้งหมดที่ยังไม่ได้รับผล
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // ความปลอดภัย: เราทราบดีว่าองค์ประกอบทั้งหมดภายใน `alive` ได้รับการเริ่มต้นอย่างเหมาะสม
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // รับดัชนีถัดไปจากด้านหน้า
        //
        // การเพิ่ม `alive.start` ขึ้น 1 จะรักษาค่าคงที่เกี่ยวกับ `alive`
        // อย่างไรก็ตามเนื่องจากการเปลี่ยนแปลงนี้ในช่วงเวลาสั้น ๆ โซนที่มีชีวิตไม่ใช่ `data[alive]` อีกต่อไป แต่เป็น `data[idx..alive.end]`
        //
        self.alive.next().map(|idx| {
            // อ่านองค์ประกอบจากอาร์เรย์
            // ความปลอดภัย: `idx` เป็นดัชนีในภูมิภาค "alive" เดิมของไฟล์
            // อาร์เรย์การอ่านองค์ประกอบนี้หมายความว่า `data[idx]` ถือว่าตายแล้ว (เช่นห้ามแตะต้อง)
            // เนื่องจาก `idx` เป็นจุดเริ่มต้นของโซนมีชีวิตโซนที่มีชีวิตตอนนี้จึงเป็น `data[alive]` อีกครั้งโดยเรียกคืนค่าคงที่ทั้งหมด
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // รับดัชนีถัดไปจากด้านหลัง
        //
        // การลด `alive.end` ลง 1 จะรักษาค่าคงที่เกี่ยวกับ `alive`
        // อย่างไรก็ตามเนื่องจากการเปลี่ยนแปลงนี้ในช่วงเวลาสั้น ๆ โซนที่มีชีวิตไม่ใช่ `data[alive]` อีกต่อไป แต่เป็น `data[alive.start..=idx]`
        //
        self.alive.next_back().map(|idx| {
            // อ่านองค์ประกอบจากอาร์เรย์
            // ความปลอดภัย: `idx` เป็นดัชนีในภูมิภาค "alive" เดิมของไฟล์
            // อาร์เรย์การอ่านองค์ประกอบนี้หมายความว่า `data[idx]` ถือว่าตายแล้ว (เช่นห้ามแตะต้อง)
            // เนื่องจาก `idx` เป็นจุดสิ้นสุดของโซนมีชีวิตโซนที่มีชีวิตตอนนี้จึงกลายเป็น `data[alive]` อีกครั้งโดยเรียกคืนค่าคงที่ทั้งหมด
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // ความปลอดภัย: ปลอดภัย: `as_mut_slice` ส่งคืนชิ้นส่วนย่อยทุกประการ
        // ขององค์ประกอบที่ยังไม่ถูกย้ายออกและยังคงถูกทิ้ง
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // จะไม่ล้นเนื่องจากค่าคงที่ `alive.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// ตัววนซ้ำรายงานความยาวที่ถูกต้อง
// จำนวนองค์ประกอบ "alive" (ที่จะยังคงได้รับ) คือความยาวของช่วง `alive`
// ช่วงนี้มีความยาวลดลงใน `next` หรือ `next_back`
// มันจะลดลงด้วย 1 ในวิธีการเหล่านั้นเสมอ แต่ถ้าส่งคืน `Some(_)` เท่านั้น
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // โปรดทราบว่าเราไม่จำเป็นต้องจับคู่ช่วงชีวิตที่เหมือนกันทั้งหมดดังนั้นเราสามารถโคลนเป็นค่าชดเชย 0 ได้ไม่ว่า `self` จะอยู่ที่ใดก็ตาม
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // โคลนองค์ประกอบที่มีชีวิตทั้งหมด
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // เขียนโคลนลงในอาร์เรย์ใหม่จากนั้นอัปเดตช่วงที่ยังมีชีวิตอยู่
            // หากโคลน panics เราจะทิ้งรายการก่อนหน้านี้อย่างถูกต้อง
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // พิมพ์เฉพาะองค์ประกอบที่ยังไม่ได้รับผล: เราไม่สามารถเข้าถึงองค์ประกอบที่ให้ผลได้อีกต่อไป
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}