//! Traits สำหรับการแปลงระหว่างประเภท
//!
//! traits ในโมดูลนี้มีวิธีการแปลงจากประเภทหนึ่งไปเป็นอีกประเภทหนึ่ง
//! trait แต่ละตัวมีจุดประสงค์ที่แตกต่างกัน:
//!
//! - ใช้ [`AsRef`] trait สำหรับการแปลงข้อมูลอ้างอิงเพื่ออ้างอิงราคาถูก
//! - ติดตั้ง [`AsMut`] trait สำหรับการแปลงที่ไม่สามารถเปลี่ยนแปลงได้
//! - ติดตั้ง [`From`] trait เพื่อบริโภคการแปลงมูลค่าต่อมูลค่า
//! - ใช้ [`Into`] trait สำหรับการบริโภคการแปลงมูลค่าต่อมูลค่าไปยังประเภทนอก crate ปัจจุบัน
//! - [`TryFrom`] และ [`TryInto`] traits ทำงานเหมือน [`From`] และ [`Into`] แต่ควรนำไปใช้เมื่อการแปลงล้มเหลว
//!
//! traits ในโมดูลนี้มักใช้เป็น trait bounds สำหรับฟังก์ชันทั่วไปเช่นอาร์กิวเมนต์หลายประเภทได้รับการสนับสนุนดูเอกสารประกอบของแต่ละ trait สำหรับตัวอย่าง
//!
//! ในฐานะผู้เขียนไลบรารีคุณควรเลือกใช้ [`From<T>`][`From`] หรือ [`TryFrom<T>`][`TryFrom`] มากกว่า [`Into<U>`][`Into`] หรือ [`TryInto<U>`][`TryInto`] เนื่องจาก [`From`] และ [`TryFrom`] ให้ความยืดหยุ่นมากขึ้นและนำเสนอการใช้งาน [`Into`] หรือ [`TryInto`] ที่เทียบเท่าได้ฟรีด้วยการใช้งานแบบครอบคลุมในไลบรารีมาตรฐาน
//! เมื่อกำหนดเป้าหมายเวอร์ชันก่อน Rust 1.41 อาจจำเป็นต้องใช้ [`Into`] หรือ [`TryInto`] โดยตรงเมื่อแปลงเป็นประเภทนอก crate ปัจจุบัน
//!
//! # การใช้งานทั่วไป
//!
//! - [`AsRef`] และ [`AsMut`] auto-dereference หากประเภทภายในเป็นการอ้างอิง
//! - [`From`]`<U>สำหรับ T` หมายถึง [`Into`]`</u><T><U>สำหรับ U`</u>
//! - [`TryFrom`]`<U>สำหรับ T` หมายถึง [`TryInto`]`</u><T><U>สำหรับ U`</u>
//! - [`From`] และ [`Into`] เป็นแบบรีเฟล็กซ์ซึ่งหมายความว่าทุกประเภทสามารถ `into` ได้เองและ `from` เอง
//!
//! ดู trait แต่ละตัวสำหรับตัวอย่างการใช้งาน
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// ฟังก์ชันเอกลักษณ์
///
/// สิ่งสำคัญสองประการที่ควรทราบเกี่ยวกับฟังก์ชันนี้:
///
/// - ไม่เทียบเท่ากับการปิดเช่น `|x| x` เสมอไปเนื่องจากการปิดอาจบังคับให้ `x` เป็นประเภทอื่น
///
/// - มันย้ายอินพุต `x` ที่ส่งผ่านไปยังฟังก์ชัน
///
/// แม้ว่าอาจจะดูแปลกที่มีฟังก์ชันที่ส่งคืนอินพุตกลับมา แต่ก็มีการใช้งานที่น่าสนใจอยู่บ้าง
///
///
/// # Examples
///
/// การใช้ `identity` เพื่อทำอะไรในลำดับของฟังก์ชั่นอื่น ๆ ที่น่าสนใจ:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // สมมติว่าการเพิ่มหนึ่งเป็นฟังก์ชันที่น่าสนใจ
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// การใช้ `identity` เป็นเคสฐาน "do nothing" ตามเงื่อนไข:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // ทำสิ่งที่น่าสนใจมากขึ้น ...
///
/// let _results = do_stuff(42);
/// ```
///
/// การใช้ `identity` เพื่อเก็บตัวแปร `Some` ของตัววนซ้ำของ `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// ใช้ในการแปลงข้อมูลอ้างอิงเพื่ออ้างอิงราคาถูก
///
/// trait นี้คล้ายกับ [`AsMut`] ซึ่งใช้สำหรับการแปลงระหว่างการอ้างอิงที่ไม่แน่นอน
/// หากคุณต้องการทำการแปลงที่มีราคาแพงคุณควรใช้ [`From`] กับประเภท `&T` หรือเขียนฟังก์ชันที่กำหนดเอง
///
/// `AsRef` มีลายเซ็นเดียวกันกับ [`Borrow`] แต่ [`Borrow`] แตกต่างกันในบางแง่มุม:
///
/// - แตกต่างจาก `AsRef`, [`Borrow`] มีผ้าห่ม im สำหรับ `T` ใด ๆ และสามารถใช้เพื่อยอมรับการอ้างอิงหรือค่า
/// - [`Borrow`] ยังกำหนดให้ [`Hash`], [`Eq`] และ [`Ord`] สำหรับมูลค่าที่ยืมมานั้นเทียบเท่ากับมูลค่าที่เป็นเจ้าของ
/// ด้วยเหตุนี้หากคุณต้องการยืมเพียงฟิลด์เดียวของโครงสร้างคุณสามารถใช้ `AsRef` ได้ แต่ไม่ใช่ [`Borrow`]
///
/// **Note: trait นี้จะต้องไม่ล้มเหลว **หากการแปลงล้มเหลวให้ใช้วิธีเฉพาะซึ่งส่งคืน [`Option<T>`] หรือ [`Result<T, E>`]
///
/// # การใช้งานทั่วไป
///
/// - `AsRef` auto-dereferences หากประเภทภายในเป็นการอ้างอิงหรือการอ้างอิงที่เปลี่ยนแปลงได้ (เช่น: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// ด้วยการใช้ trait bounds เราสามารถยอมรับอาร์กิวเมนต์ประเภทต่างๆได้ตราบเท่าที่สามารถแปลงเป็นประเภท `T` ที่ระบุได้
///
/// ตัวอย่างเช่นการสร้างฟังก์ชันทั่วไปที่ใช้ `AsRef<str>` แสดงว่าเราต้องการยอมรับการอ้างอิงทั้งหมดที่สามารถแปลงเป็น [`&str`] เป็นอาร์กิวเมนต์ได้
/// เนื่องจากทั้ง [`String`] และ [`&str`] ใช้ `AsRef<str>` เราจึงสามารถยอมรับทั้งสองเป็นอาร์กิวเมนต์อินพุต
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// ทำการแปลง
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// ใช้เพื่อทำการแปลงข้อมูลอ้างอิงที่ผันแปรไปสู่การเปลี่ยนแปลงราคาถูก
///
/// trait นี้คล้ายกับ [`AsRef`] แต่ใช้สำหรับการแปลงระหว่างการอ้างอิงที่ไม่แน่นอน
/// หากคุณต้องการทำการแปลงที่มีราคาแพงคุณควรใช้ [`From`] กับประเภท `&mut T` หรือเขียนฟังก์ชันที่กำหนดเอง
///
/// **Note: trait นี้จะต้องไม่ล้มเหลว **หากการแปลงล้มเหลวให้ใช้วิธีเฉพาะซึ่งส่งคืน [`Option<T>`] หรือ [`Result<T, E>`]
///
/// # การใช้งานทั่วไป
///
/// - `AsMut` auto-dereferences หากประเภทภายในเป็นการอ้างอิงที่ไม่แน่นอน (เช่น: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// การใช้ `AsMut` เป็น trait bound สำหรับฟังก์ชันทั่วไปเราสามารถยอมรับการอ้างอิงที่เปลี่ยนแปลงได้ทั้งหมดซึ่งสามารถแปลงเป็นประเภท `&mut T` ได้
/// เนื่องจาก [`Box<T>`] ใช้ `AsMut<T>` เราจึงสามารถเขียนฟังก์ชัน `add_one` ที่รับอาร์กิวเมนต์ทั้งหมดที่สามารถแปลงเป็น `&mut u64` ได้
/// เนื่องจาก [`Box<T>`] ใช้ `AsMut<T>` `add_one` จึงยอมรับอาร์กิวเมนต์ประเภท `&mut Box<u64>` เช่นกัน:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// ทำการแปลง
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// การแปลงมูลค่าเป็นมูลค่าที่ใช้ค่าอินพุตตรงข้ามกับ [`From`]
///
/// ควรหลีกเลี่ยงการใช้ [`Into`] และใช้ [`From`] แทน
/// การนำ [`From`] ไปใช้โดยอัตโนมัติจะช่วยให้สามารถใช้งาน [`Into`] ได้โดยอัตโนมัติด้วยการใช้งานแบบครอบคลุมในไลบรารีมาตรฐาน
///
/// ชอบใช้ [`Into`] มากกว่า [`From`] เมื่อระบุ trait bounds บนฟังก์ชันทั่วไปเพื่อให้แน่ใจว่าประเภทที่ใช้ [`Into`] เท่านั้นที่สามารถใช้ได้เช่นกัน
///
/// **Note: trait นี้จะต้องไม่ล้มเหลว **หากการแปลงล้มเหลวให้ใช้ [`TryInto`]
///
/// # การใช้งานทั่วไป
///
/// - [`จาก`]`<T>สำหรับ U` หมายถึง `Into<U> for T`
/// - [`Into`] เป็นรีเฟล็กซีฟซึ่งหมายความว่า `Into<T> for T` ถูกนำไปใช้
///
/// # การใช้งาน [`Into`] สำหรับการแปลงเป็นประเภทภายนอกใน Rust เวอร์ชันเก่า
///
/// ก่อนหน้า Rust 1.41 หากประเภทปลายทางไม่ได้เป็นส่วนหนึ่งของ crate ปัจจุบันคุณจะไม่สามารถใช้งาน [`From`] ได้โดยตรง
/// ตัวอย่างเช่นใช้รหัสนี้:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// การดำเนินการนี้จะล้มเหลวในการคอมไพล์ในภาษาเวอร์ชันเก่าเนื่องจากกฎการเลี้ยงดูเด็กกำพร้าของ Rust เคยเข้มงวดกว่าเล็กน้อย
/// ในการหลีกเลี่ยงสิ่งนี้คุณสามารถใช้ [`Into`] ได้โดยตรง:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// สิ่งสำคัญคือต้องเข้าใจว่า [`Into`] ไม่มีการใช้งาน [`From`] (เช่นเดียวกับ [`From`] กับ [`Into`])
/// ดังนั้นคุณควรพยายามใช้ [`From`] เสมอแล้วถอยกลับไปที่ [`Into`] หาก [`From`] ไม่สามารถใช้งานได้
///
/// # Examples
///
/// [`String`] ใช้ [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// เพื่อแสดงว่าเราต้องการให้ฟังก์ชันทั่วไปรับอาร์กิวเมนต์ทั้งหมดที่สามารถแปลงเป็น `T` ประเภทที่ระบุได้เราสามารถใช้ trait bound ของ [`Into`]`<T>`.
///
/// ตัวอย่างเช่นฟังก์ชัน `is_hello` รับอาร์กิวเมนต์ทั้งหมดที่สามารถแปลงเป็น [`Vec`]`<`[`u8`] `>"
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// ทำการแปลง
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// ใช้เพื่อทำการแปลงมูลค่าเป็นมูลค่าในขณะที่ใช้ค่าอินพุตมันเป็นส่วนกลับของ [`Into`]
///
/// เราควรเลือกใช้ `From` มากกว่า [`Into`] เสมอเนื่องจากการใช้ `From` จะทำให้ [`Into`] สามารถใช้งานได้โดยอัตโนมัติด้วยการใช้งานแบบครอบคลุมในไลบรารีมาตรฐาน
///
///
/// ใช้ [`Into`] เฉพาะเมื่อกำหนดเป้าหมายเวอร์ชันก่อน Rust 1.41 และแปลงเป็นประเภทนอก crate ปัจจุบัน
/// `From` ไม่สามารถทำการแปลงประเภทนี้ในเวอร์ชันก่อนหน้าได้เนื่องจากกฎการเลี้ยงดูบุตรของ Rust
/// ดู [`Into`] สำหรับรายละเอียดเพิ่มเติม
///
/// ชอบใช้ [`Into`] มากกว่าใช้ `From` เมื่อระบุ trait bounds บนฟังก์ชันทั่วไป
/// ด้วยวิธีนี้ประเภทที่ใช้ [`Into`] โดยตรงสามารถใช้เป็นอาร์กิวเมนต์ได้เช่นกัน
///
/// `From` ยังมีประโยชน์มากเมื่อดำเนินการจัดการข้อผิดพลาดเมื่อสร้างฟังก์ชันที่สามารถล้มเหลวโดยทั่วไปประเภทการส่งคืนจะอยู่ในรูปแบบ `Result<T, E>`
/// `From` trait ช่วยลดความยุ่งยากในการจัดการข้อผิดพลาดโดยอนุญาตให้ฟังก์ชันส่งคืนประเภทข้อผิดพลาดเดียวที่ห่อหุ้มข้อผิดพลาดหลายประเภทดูส่วน "Examples" และ [the book][book] สำหรับรายละเอียดเพิ่มเติม
///
/// **Note: trait นี้จะต้องไม่ล้มเหลว **หากการแปลงล้มเหลวให้ใช้ [`TryFrom`]
///
/// # การใช้งานทั่วไป
///
/// - `From<T> for U` หมายถึง [`Into`]`<U>สำหรับ T`</u>
/// - `From` เป็นรีเฟล็กซีฟซึ่งหมายความว่า `From<T> for T` ถูกนำไปใช้
///
/// # Examples
///
/// [`String`] ใช้ `From<&str>`:
///
/// การแปลงอย่างชัดเจนจาก `&str` เป็น String ทำได้ดังนี้:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// ในขณะที่ดำเนินการจัดการข้อผิดพลาดมักเป็นประโยชน์ในการใช้ `From` สำหรับประเภทข้อผิดพลาดของคุณเอง
/// ด้วยการแปลงประเภทข้อผิดพลาดพื้นฐานเป็นประเภทข้อผิดพลาดที่กำหนดเองของเราเองซึ่งสรุปประเภทข้อผิดพลาดที่อยู่เบื้องหลังเราสามารถส่งคืนข้อผิดพลาดประเภทเดียวโดยไม่สูญเสียข้อมูลเกี่ยวกับสาเหตุที่แท้จริง
/// ตัวดำเนินการ '?' จะแปลงประเภทข้อผิดพลาดพื้นฐานเป็นประเภทข้อผิดพลาดที่กำหนดเองของเราโดยอัตโนมัติโดยเรียกใช้ `Into<CliError>::into` ซึ่งมีให้โดยอัตโนมัติเมื่อใช้งาน `From`
/// จากนั้นคอมไพเลอร์จะสรุปว่าควรใช้ `Into` แบบใด
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// ทำการแปลง
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// การพยายามแปลงที่ใช้ `self` ซึ่งอาจมีราคาแพงหรือไม่ก็ได้
///
/// โดยปกติผู้เขียนไลบรารีไม่ควรนำ trait นี้ไปใช้โดยตรง แต่ควรเลือกใช้ [`TryFrom`] trait ซึ่งให้ความยืดหยุ่นมากกว่าและให้การใช้งาน `TryInto` ที่เทียบเท่าได้ฟรีด้วยการใช้งานแบบครอบคลุมในไลบรารีมาตรฐาน
/// สำหรับข้อมูลเพิ่มเติมโปรดดูเอกสารสำหรับ [`Into`]
///
/// # การติดตั้ง `TryInto`
///
/// สิ่งนี้มีข้อ จำกัด และเหตุผลเช่นเดียวกับการใช้ [`Into`] ดูรายละเอียดที่นั่น
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// ประเภทที่ส่งคืนในกรณีที่เกิดข้อผิดพลาดในการแปลง
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// ทำการแปลง
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// การแปลงประเภทที่เรียบง่ายและปลอดภัยซึ่งอาจล้มเหลวด้วยวิธีการควบคุมภายใต้สถานการณ์บางอย่างมันเป็นส่วนกลับของ [`TryInto`]
///
/// สิ่งนี้มีประโยชน์เมื่อคุณทำการแปลงประเภทที่อาจประสบความสำเร็จเล็กน้อย แต่อาจต้องมีการจัดการพิเศษด้วย
/// ตัวอย่างเช่นไม่มีวิธีใดในการแปลง [`i64`] เป็น [`i32`] โดยใช้ [`From`] trait เนื่องจาก [`i64`] อาจมีค่าที่ [`i32`] ไม่สามารถแสดงได้ดังนั้นการแปลงจึงสูญเสียข้อมูล
///
/// สิ่งนี้อาจจัดการได้โดยการตัดทอน [`i64`] เป็น [`i32`] (โดยพื้นฐานแล้วจะให้ค่าโมดูโล [`i32::MAX`] ของ ["i64`]) หรือเพียงแค่คืนค่า [`i32::MAX`] หรือโดยวิธีอื่น
/// [`From`] trait มีไว้สำหรับการแปลงที่สมบูรณ์แบบดังนั้น `TryFrom` trait จะแจ้งโปรแกรมเมอร์เมื่อการแปลงประเภทอาจส่งผลเสียและให้พวกเขาตัดสินใจว่าจะจัดการอย่างไร
///
/// # การใช้งานทั่วไป
///
/// - `TryFrom<T> for U` หมายถึง [`TryInto`]`<U>สำหรับ T`</u>
/// - [`try_from`] เป็นรีเฟล็กซีฟซึ่งหมายความว่า `TryFrom<T> for T` ถูกนำไปใช้และไม่สามารถล้มเหลว-ประเภท `Error` ที่เกี่ยวข้องสำหรับการเรียก `T::try_from()` โดยใช้ค่าประเภท `T` คือ [`Infallible`]
/// เมื่อประเภท [`!`] มีความเสถียร [`Infallible`] และ [`!`] จะเทียบเท่ากัน
///
/// `TryFrom<T>` สามารถดำเนินการได้ดังนี้:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// ตามที่อธิบายไว้ [`i32`] ใช้ `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // ตัด `big_number` อย่างเงียบ ๆ ต้องมีการตรวจจับและจัดการการตัดทอนหลังจากข้อเท็จจริง
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // ส่งคืนข้อผิดพลาดเนื่องจาก `big_number` ใหญ่เกินไปที่จะใส่ใน `i32`
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // ส่งคืน `Ok(3)`
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// ประเภทที่ส่งคืนในกรณีที่เกิดข้อผิดพลาดในการแปลง
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// ทำการแปลง
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// ผลกระทบทั่วไป
////////////////////////////////////////////////////////////////////////////////

// ขณะที่ยกขึ้น&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// เมื่อยกขึ้นมากกว่า &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): แทนที่นัยข้างต้นสำหรับ&/&mut ด้วยคำสั่งทั่วไปต่อไปนี้:
// // เมื่อยกขึ้นเหนือ Deref
// โดยนัย <D: ?Sized + Deref<Target: AsRef<U>>, U:? ขนาด> AsRef <U>สำหรับ D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut ยกได้มากกว่า &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): แทนที่ impl ด้านบนสำหรับ &mut ด้วยคำสั่งทั่วไปต่อไปนี้:
// // AsMut ยกขึ้นเหนือ DerefMut
// โดยนัย <D: ?Sized + Deref<Target: AsMut<U>>, U:? ขนาด> AsMut <U>สำหรับ D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// จากความหมาย Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// จาก (และกลายเป็น) เป็นแบบสะท้อนกลับ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **หมายเหตุความเสถียร:** ยังไม่มีนัยนี้ แต่เราคือ "reserving space" เพื่อเพิ่มใน future
/// ดู [rust-lang/rust#64715][#64715] สำหรับรายละเอียด
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): ทำการแก้ไขตามหลักการแทน
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom หมายถึง TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// การแปลงที่ไม่ถูกต้องมีความหมายเทียบเท่ากับการแปลงที่ผิดพลาดโดยมีประเภทข้อผิดพลาดที่ไม่มีใครอยู่
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// ผลกระทบคอนกรีต
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// ประเภทข้อผิดพลาด NO-ERROR
////////////////////////////////////////////////////////////////////////////////

/// ประเภทข้อผิดพลาดสำหรับข้อผิดพลาดที่ไม่สามารถเกิดขึ้นได้
///
/// เนื่องจาก enum นี้ไม่มีตัวแปรค่าประเภทนี้จึงไม่มีอยู่จริง
/// สิ่งนี้มีประโยชน์สำหรับ API ทั่วไปที่ใช้ [`Result`] และกำหนดพารามิเตอร์ประเภทข้อผิดพลาดเพื่อระบุว่าผลลัพธ์คือ [`Ok`] เสมอ
///
/// ตัวอย่างเช่น [`TryFrom`] trait (การแปลงที่คืนค่า [`Result`]) มีการใช้งานแบบครอบคลุมสำหรับทุกประเภทที่มีการใช้งาน [`Into`] ย้อนกลับ
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # เข้ากันได้กับ Future
///
/// enum นี้มีบทบาทเช่นเดียวกับ [the `!`“never”type][never] ซึ่งไม่เสถียรใน Rust เวอร์ชันนี้
/// เมื่อ `!` เสถียรเราวางแผนที่จะทำให้ `Infallible` เป็นนามแฝงประเภท:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …และในที่สุดก็เลิกใช้งาน `Infallible`
///
/// อย่างไรก็ตามมีกรณีหนึ่งที่สามารถใช้ไวยากรณ์ `!` ได้ก่อนที่ `!` จะเสถียรเป็นประเภทเต็มเปี่ยม: ในตำแหน่งของประเภทการส่งคืนของฟังก์ชัน
/// โดยเฉพาะอย่างยิ่งการใช้งานที่เป็นไปได้สำหรับตัวชี้ฟังก์ชันที่แตกต่างกันสองประเภท:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// เมื่อ `Infallible` เป็น enum รหัสนี้จึงถูกต้อง
/// อย่างไรก็ตามเมื่อ `Infallible` กลายเป็นนามแฝงสำหรับ never type ทั้งสอง "นัย" จะเริ่มทับซ้อนกันดังนั้นกฎการเชื่อมโยง trait ของภาษาจะไม่อนุญาต
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}