//! การแปลงอักขระ

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// แปลง `u32` เป็น `char`
///
/// โปรดทราบว่า ["char`] ทั้งหมดเป็น ["u32`] ที่ถูกต้องและสามารถแคสต์เป็นหนึ่งเดียวได้ด้วย
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// อย่างไรก็ตามการย้อนกลับไม่เป็นความจริง: ["u32`] s ที่ถูกต้องไม่ถูกต้องทั้งหมด ["char`] s
/// `from_u32()` จะคืนค่า `None` หากอินพุตไม่ใช่ค่าที่ถูกต้องสำหรับ [`char`]
///
/// สำหรับเวอร์ชันที่ไม่ปลอดภัยของฟังก์ชันนี้ซึ่งละเว้นการตรวจสอบเหล่านี้โปรดดู [`from_u32_unchecked`]
///
///
/// # Examples
///
/// การใช้งานพื้นฐาน:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// การส่งคืน `None` เมื่ออินพุตไม่ใช่ [`char`] ที่ถูกต้อง:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// แปลง `u32` เป็น `char` โดยไม่สนใจความถูกต้อง
///
/// โปรดทราบว่า ["char`] ทั้งหมดเป็น ["u32`] ที่ถูกต้องและสามารถแคสต์เป็นหนึ่งเดียวได้ด้วย
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// อย่างไรก็ตามการย้อนกลับไม่เป็นความจริง: ["u32`] s ที่ถูกต้องไม่ถูกต้องทั้งหมด ["char`] s
/// `from_u32_unchecked()` จะเพิกเฉยต่อสิ่งนี้และส่งไปยัง [`char`] แบบสุ่มสี่สุ่มห้าซึ่งอาจสร้างสิ่งที่ไม่ถูกต้อง
///
///
/// # Safety
///
/// ฟังก์ชันนี้ไม่ปลอดภัยเนื่องจากอาจสร้างค่า `char` ที่ไม่ถูกต้อง
///
/// สำหรับเวอร์ชันที่ปลอดภัยของฟังก์ชันนี้โปรดดูฟังก์ชัน [`from_u32`]
///
/// # Examples
///
/// การใช้งานพื้นฐาน:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // ความปลอดภัย: ผู้โทรต้องรับประกันว่า `i` เป็นค่าถ่านที่ถูกต้อง
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// แปลง [`char`] เป็น [`u32`]
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// แปลง [`char`] เป็น [`u64`]
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // ถ่านจะถูกแคสต์ตามค่าของจุดรหัสจากนั้นขยายศูนย์เป็น 64 บิต
        // ดู [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// แปลง [`char`] เป็น [`u128`]
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // ถ่านถูกแคสต์ตามค่าของจุดรหัสจากนั้นขยายศูนย์เป็น 128 บิต
        // ดู [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// แมปไบต์เป็น 0x00 ..=0xFF ไปยัง `char` ซึ่งจุดรหัสมีค่าเท่ากันใน U + 0000 ..=U + 00FF
///
/// Unicode ได้รับการออกแบบมาเพื่อให้สามารถถอดรหัสไบต์ได้อย่างมีประสิทธิภาพด้วยการเข้ารหัสอักขระที่ IANA เรียกว่า ISO-8859-1
/// การเข้ารหัสนี้เข้ากันได้กับ ASCII
///
/// โปรดทราบว่าสิ่งนี้แตกต่างจาก ISO/IEC 8859-1 aka
/// ISO 8859-1 (มียัติภังค์น้อยกว่าหนึ่งตัว) ซึ่งจะทำให้ "blanks" บางค่าไบต์ไม่ได้กำหนดให้กับอักขระใด ๆ
/// ISO-8859-1 (IANA one) กำหนดให้กับรหัสควบคุม C0 และ C1
///
/// โปรดทราบว่าสิ่งนี้ *ยัง* แตกต่างจาก Windows-1252 aka
/// รหัสหน้า 1252 ซึ่งเป็นซูเปอร์เซ็ต ISO/IEC 8859-1 ที่กำหนดช่องว่าง (ไม่ใช่ทั้งหมด!) ให้กับเครื่องหมายวรรคตอนและอักขระละตินต่างๆ
///
/// เพื่อให้เกิดความสับสนเพิ่มเติม [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` และ `windows-1252` คือนามแฝงทั้งหมดสำหรับชุดเหนือของ Windows-1252 ที่เติมช่องว่างที่เหลือด้วยรหัสควบคุม C0 และ C1 ที่สอดคล้องกัน
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// แปลง [`u8`] เป็น [`char`]
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// ข้อผิดพลาดที่สามารถส่งคืนได้เมื่อแยกวิเคราะห์ตัวอักษร
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // ความปลอดภัย: ตรวจสอบว่าเป็นค่า Unicode ที่ถูกต้องตามกฎหมาย
            Ok(unsafe { transmute(i) })
        }
    }
}

/// ประเภทข้อผิดพลาดส่งกลับเมื่อการแปลงจาก u32 เป็นถ่านล้มเหลว
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// แปลงตัวเลขในรัศมีที่กำหนดให้เป็น `char`
///
/// 'radix' บางครั้งเรียกว่า 'base'
/// เลขฐานสองหมายถึงเลขฐานสองเลขฐานสิบเลขฐานสิบและเลขฐานสิบหกเลขฐานสิบหกเพื่อให้ค่าทั่วไปบางค่า
///
/// รองรับ radices โดยพลการ
///
/// `from_digit()` จะส่งคืน `None` หากอินพุตไม่ใช่ตัวเลขในรัศมีที่กำหนด
///
/// # Panics
///
/// Panics ถ้ากำหนดรัศมีมากกว่า 36
///
/// # Examples
///
/// การใช้งานพื้นฐาน:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // ทศนิยม 11 เป็นเลขโดดในฐาน 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// การส่งคืน `None` เมื่ออินพุตไม่ใช่ตัวเลข:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// ผ่านรัศมีขนาดใหญ่ทำให้เกิด panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}