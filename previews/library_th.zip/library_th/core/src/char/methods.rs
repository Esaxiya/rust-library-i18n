//! แสดงถ่าน {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// จุดรหัสที่ถูกต้องสูงสุดที่ `char` สามารถมีได้
    ///
    /// `char` คือ [Unicode Scalar Value] ซึ่งหมายความว่าเป็น [Code Point] แต่จะมีเฉพาะในช่วงที่กำหนดเท่านั้น
    /// `MAX` คือจุดรหัสสูงสุดที่ถูกต้องนั่นคือ [Unicode Scalar Value] ที่ถูกต้อง
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () ใช้ใน Unicode เพื่อแสดงข้อผิดพลาดในการถอดรหัส
    ///
    /// อาจเกิดขึ้นได้ตัวอย่างเช่นเมื่อให้ UTF-8 ไบต์ที่มีรูปแบบไม่ถูกต้องเป็น [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy)
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// เวอร์ชันของ [Unicode](http://www.unicode.org/) ที่ใช้ส่วน Unicode ของ `char` และ `str`
    ///
    /// Unicode เวอร์ชันใหม่จะถูกเผยแพร่อย่างสม่ำเสมอและต่อมาวิธีการทั้งหมดในไลบรารีมาตรฐานจะมีการอัปเดตขึ้นอยู่กับ Unicode
    /// ดังนั้นพฤติกรรมของ `char` และ `str` บางวิธีและค่าของค่าคงที่นี้จึงเปลี่ยนแปลงไปตามกาลเวลา
    /// นี่ถือว่า *ไม่* ถือเป็นการเปลี่ยนแปลงที่ทำลายล้าง
    ///
    /// รูปแบบการกำหนดหมายเลขเวอร์ชันอธิบายไว้ใน [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4)
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// สร้างตัววนซ้ำบนจุดรหัสที่เข้ารหัส UTF-16 ใน `iter` โดยส่งคืนตัวแทนที่ไม่ได้จับคู่เป็น "Err"
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// ตัวถอดรหัสที่สูญเสียสามารถรับได้โดยการแทนที่ผลลัพธ์ `Err` ด้วยอักขระแทนที่:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// แปลง `u32` เป็น `char`
    ///
    /// โปรดทราบว่าอักขระทั้งหมดเป็น ["u32`] ที่ถูกต้องและสามารถแคสต์เป็นหนึ่งเดียวกับ
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// อย่างไรก็ตามการย้อนกลับไม่เป็นความจริง: ["u32`] ไม่ถูกต้องทั้งหมดจะเป็น"อักขระ"ที่ถูกต้อง
    /// `from_u32()` จะคืนค่า `None` หากอินพุตไม่ใช่ค่าที่ถูกต้องสำหรับ `char`
    ///
    /// สำหรับเวอร์ชันที่ไม่ปลอดภัยของฟังก์ชันนี้ซึ่งละเว้นการตรวจสอบเหล่านี้โปรดดู [`from_u32_unchecked`]
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// การส่งคืน `None` เมื่ออินพุตไม่ใช่ `char` ที่ถูกต้อง:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// แปลง `u32` เป็น `char` โดยไม่สนใจความถูกต้อง
    ///
    /// โปรดทราบว่าอักขระทั้งหมดเป็น ["u32`] ที่ถูกต้องและสามารถแคสต์เป็นหนึ่งเดียวกับ
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// อย่างไรก็ตามการย้อนกลับไม่เป็นความจริง: ["u32`] ไม่ถูกต้องทั้งหมดจะเป็น"อักขระ"ที่ถูกต้อง
    /// `from_u32_unchecked()` จะเพิกเฉยต่อสิ่งนี้และส่งไปยัง `char` แบบสุ่มสี่สุ่มห้าซึ่งอาจสร้างสิ่งที่ไม่ถูกต้อง
    ///
    ///
    /// # Safety
    ///
    /// ฟังก์ชันนี้ไม่ปลอดภัยเนื่องจากอาจสร้างค่า `char` ที่ไม่ถูกต้อง
    ///
    /// สำหรับเวอร์ชันที่ปลอดภัยของฟังก์ชันนี้โปรดดูฟังก์ชัน [`from_u32`]
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // ความปลอดภัย: ผู้โทรต้องยึดถือสัญญาความปลอดภัย
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// แปลงตัวเลขในรัศมีที่กำหนดให้เป็น `char`
    ///
    /// 'radix' บางครั้งเรียกว่า 'base'
    /// เลขฐานสองหมายถึงเลขฐานสองเลขฐานสิบเลขฐานสิบและเลขฐานสิบหกเลขฐานสิบหกเพื่อให้ค่าทั่วไปบางค่า
    ///
    /// รองรับ radices โดยพลการ
    ///
    /// `from_digit()` จะส่งคืน `None` หากอินพุตไม่ใช่ตัวเลขในรัศมีที่กำหนด
    ///
    /// # Panics
    ///
    /// Panics ถ้ากำหนดรัศมีมากกว่า 36
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // ทศนิยม 11 เป็นเลขโดดในฐาน 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// การส่งคืน `None` เมื่ออินพุตไม่ใช่ตัวเลข:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// ผ่านรัศมีขนาดใหญ่ทำให้เกิด panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// ตรวจสอบว่า `char` เป็นตัวเลขในรัศมีที่กำหนดหรือไม่
    ///
    /// 'radix' บางครั้งเรียกว่า 'base'
    /// เลขฐานสองหมายถึงเลขฐานสองเลขฐานสิบเลขฐานสิบและเลขฐานสิบหกเลขฐานสิบหกเพื่อให้ค่าทั่วไปบางค่า
    ///
    /// รองรับ radices โดยพลการ
    ///
    /// เมื่อเทียบกับ [`is_numeric()`] ฟังก์ชันนี้จะจดจำเฉพาะอักขระ `0-9`, `a-z` และ `A-Z` เท่านั้น
    ///
    /// 'Digit' ถูกกำหนดให้เป็นเพียงอักขระต่อไปนี้:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// สำหรับความเข้าใจที่ครอบคลุมมากขึ้นเกี่ยวกับ 'digit' โปรดดู [`is_numeric()`]
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics ถ้ากำหนดรัศมีมากกว่า 36
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// ผ่านรัศมีขนาดใหญ่ทำให้เกิด panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// แปลง `char` เป็นตัวเลขในรัศมีที่กำหนด
    ///
    /// 'radix' บางครั้งเรียกว่า 'base'
    /// เลขฐานสองหมายถึงเลขฐานสองเลขฐานสิบเลขฐานสิบและเลขฐานสิบหกเลขฐานสิบหกเพื่อให้ค่าทั่วไปบางค่า
    ///
    /// รองรับ radices โดยพลการ
    ///
    /// 'Digit' ถูกกำหนดให้เป็นเพียงอักขระต่อไปนี้:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// ส่งคืน `None` หาก `char` ไม่ได้อ้างถึงตัวเลขในรัศมีที่กำหนด
    ///
    /// # Panics
    ///
    /// Panics ถ้ากำหนดรัศมีมากกว่า 36
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// การส่งผลลัพธ์ที่ไม่ใช่ตัวเลขในความล้มเหลว:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// ผ่านรัศมีขนาดใหญ่ทำให้เกิด panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // รหัสถูกแบ่งออกที่นี่เพื่อปรับปรุงความเร็วในการดำเนินการสำหรับกรณีที่ `radix` คงที่และ 10 หรือน้อยกว่า
        //
        let val = if likely(radix <= 10) {
            // หากไม่ใช่ตัวเลขจะมีการสร้างตัวเลขที่มากกว่ารัศมี
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// ส่งคืนตัววนซ้ำที่ให้ค่า Escape Unicode ฐานสิบหกของอักขระเป็น "char"
    ///
    /// สิ่งนี้จะหลีกเลี่ยงอักขระที่มีไวยากรณ์ Rust ของรูปแบบ `\u{NNNNNN}` โดยที่ `NNNNNN` เป็นการแสดงเลขฐานสิบหก
    ///
    ///
    /// # Examples
    ///
    /// ในฐานะผู้วนซ้ำ:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ใช้ `println!` โดยตรง:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// ทั้งสองเทียบเท่ากับ:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// ใช้ `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1 ทำให้แน่ใจว่าสำหรับ c==0 โค้ดจะคำนวณว่าควรพิมพ์หนึ่งหลักและ (ซึ่งเหมือนกัน) จะหลีกเลี่ยง (31, 32) อันเดอร์โฟลว์
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // ดัชนีของเลขฐานสิบหกที่สำคัญที่สุด
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// `escape_debug` เวอร์ชันขยายที่อนุญาตให้มีทางเลือกในการหลีกเลี่ยง Extended Grapheme codepoints
    /// สิ่งนี้ช่วยให้เราสามารถจัดรูปแบบอักขระเช่นเครื่องหมายที่ไม่เว้นวรรคได้ดีขึ้นเมื่ออยู่ที่จุดเริ่มต้นของสตริง
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// ส่งคืนตัววนซ้ำที่ให้รหัสหนีตามตัวอักษรของอักขระเป็น "อักขระ"
    ///
    /// สิ่งนี้จะหลีกเลี่ยงอักขระที่คล้ายกับการใช้งาน `Debug` ของ `str` หรือ `char`
    ///
    ///
    /// # Examples
    ///
    /// ในฐานะผู้วนซ้ำ:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ใช้ `println!` โดยตรง:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// ทั้งสองเทียบเท่ากับ:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// ใช้ `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// ส่งคืนตัววนซ้ำที่ให้รหัสหนีตามตัวอักษรของอักขระเป็น "อักขระ"
    ///
    /// ค่าเริ่มต้นถูกเลือกโดยมีอคติในการผลิตตัวอักษรที่ถูกกฎหมายในหลายภาษารวมถึง C++ 11 และภาษาตระกูล C ที่คล้ายกัน
    /// กฎที่แน่นอนคือ:
    ///
    /// * แท็บจะใช้ Escape เป็น `\t`
    /// * การส่งคืนการขนส่งจะหนีเป็น `\r`
    /// * ฟีดบรรทัดจะหนีเป็น `\n`
    /// * เครื่องหมายคำพูดเดี่ยวจะใช้ Escape เป็น `\'`
    /// * เครื่องหมายคำพูดคู่ใช้ Escape เป็น `\"`
    /// * แบ็กสแลชจะใช้ Escape เป็น `\\`
    /// * อักขระใด ๆ ในช่วง "ASCII ที่พิมพ์ได้" `0x20` .. `0x7e` ที่รวมไว้จะไม่ได้รับค่า Escape
    /// * อักขระอื่น ๆ ทั้งหมดจะได้รับค่า Escape Unicode ฐานสิบหกดู [`escape_unicode`]
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// ในฐานะผู้วนซ้ำ:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ใช้ `println!` โดยตรง:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// ทั้งสองเทียบเท่ากับ:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// ใช้ `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// ส่งคืนจำนวนไบต์ที่ `char` ต้องการหากเข้ารหัสใน UTF-8
    ///
    /// จำนวนไบต์นั้นจะอยู่ระหว่าง 1 ถึง 4 เสมอ
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// ประเภท `&str` รับประกันว่าเนื้อหาคือ UTF-8 ดังนั้นเราจึงสามารถเปรียบเทียบความยาวที่จะใช้หากจุดรหัสแต่ละจุดแสดงเป็น `char` เทียบกับใน `&str` เอง:
    ///
    ///
    /// ```
    /// // เป็นตัวอักษร
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // ทั้งสองสามารถแสดงเป็นสามไบต์
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // ในฐานะ &str ทั้งสองถูกเข้ารหัสใน UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // เราจะเห็นว่าพวกมันใช้เวลาทั้งหมดหกไบต์ ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... เช่นเดียวกับ &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// ส่งคืนจำนวนหน่วยรหัส 16 บิตที่ `char` ต้องการหากเข้ารหัสใน UTF-16
    ///
    ///
    /// ดูเอกสารสำหรับ [`len_utf8()`] สำหรับคำอธิบายเพิ่มเติมเกี่ยวกับแนวคิดนี้
    /// ฟังก์ชั่นนี้เป็นกระจกเงา แต่สำหรับ UTF-16 แทนที่จะเป็น UTF-8
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// เข้ารหัสอักขระนี้เป็น UTF-8 ลงในบัฟเฟอร์ไบต์ที่จัดเตรียมไว้จากนั้นส่งคืนส่วนย่อยของบัฟเฟอร์ที่มีอักขระที่เข้ารหัส
    ///
    ///
    /// # Panics
    ///
    /// Panics หากบัฟเฟอร์ไม่ใหญ่พอ
    /// บัฟเฟอร์ความยาวสี่มีขนาดใหญ่พอที่จะเข้ารหัส `char` ใด ๆ
    ///
    /// # Examples
    ///
    /// ในทั้งสองตัวอย่างนี้ 'ß' ใช้เวลาสองไบต์ในการเข้ารหัส
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// บัฟเฟอร์ที่เล็กเกินไป:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // ความปลอดภัย: `char` ไม่ใช่ตัวแทนดังนั้นนี่คือ UTF-8 ที่ถูกต้อง
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// เข้ารหัสอักขระนี้เป็น UTF-16 ลงในบัฟเฟอร์ `u16` ที่ให้มาจากนั้นส่งคืนส่วนย่อยของบัฟเฟอร์ที่มีอักขระที่เข้ารหัส
    ///
    ///
    /// # Panics
    ///
    /// Panics หากบัฟเฟอร์ไม่ใหญ่พอ
    /// บัฟเฟอร์ความยาว 2 มีขนาดใหญ่พอที่จะเข้ารหัส `char` ใด ๆ
    ///
    /// # Examples
    ///
    /// ในทั้งสองตัวอย่างนี้ '𝕊' ใช้สอง "u16" ในการเข้ารหัส
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// บัฟเฟอร์ที่เล็กเกินไป:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// ส่งคืน `true` ถ้า `char` นี้มีคุณสมบัติ `Alphabetic`
    ///
    /// `Alphabetic` ได้อธิบายไว้ในบทที่ 4 (คุณสมบัติของอักขระ) ของ [Unicode Standard] และระบุไว้ใน [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // ความรักมีหลายอย่าง แต่ไม่ใช่ตัวอักษร
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// ส่งคืน `true` ถ้า `char` นี้มีคุณสมบัติ `Lowercase`
    ///
    /// `Lowercase` ได้อธิบายไว้ในบทที่ 4 (คุณสมบัติของอักขระ) ของ [Unicode Standard] และระบุไว้ใน [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // สคริปต์และเครื่องหมายวรรคตอนภาษาจีนต่างๆไม่มีตัวพิมพ์เล็กและใหญ่ดังนั้น:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// ส่งคืน `true` ถ้า `char` นี้มีคุณสมบัติ `Uppercase`
    ///
    /// `Uppercase` ได้อธิบายไว้ในบทที่ 4 (คุณสมบัติของอักขระ) ของ [Unicode Standard] และระบุไว้ใน [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // สคริปต์และเครื่องหมายวรรคตอนภาษาจีนต่างๆไม่มีตัวพิมพ์เล็กและใหญ่ดังนั้น:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// ส่งคืน `true` ถ้า `char` นี้มีคุณสมบัติ `White_Space`
    ///
    /// `White_Space` ระบุไว้ใน [Unicode Character Database][ucd] [`PropList.txt`]
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // พื้นที่ที่ไม่ทำลาย
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// ส่งคืน `true` หาก `char` นี้เป็นไปตาม [`is_alphabetic()`] หรือ [`is_numeric()`]
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// ส่งคืน `true` หาก `char` นี้มีหมวดหมู่ทั่วไปสำหรับรหัสควบคุม
    ///
    /// รหัสควบคุม (จุดรหัสที่มีหมวดหมู่ทั่วไปของ `Cc`) อธิบายไว้ในบทที่ 4 (คุณสมบัติของอักขระ) ของ [Unicode Standard] และระบุไว้ใน [Unicode Character Database][ucd] [`UnicodeData.txt`]
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// // U + 009C, STRING TERMINATOR
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// ส่งคืน `true` ถ้า `char` นี้มีคุณสมบัติ `Grapheme_Extend`
    ///
    /// `Grapheme_Extend` อธิบายไว้ใน [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] และระบุไว้ใน [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// ส่งคืน `true` หาก `char` นี้มีหนึ่งในหมวดหมู่ทั่วไปสำหรับตัวเลข
    ///
    /// หมวดหมู่ทั่วไปสำหรับตัวเลข (`Nd` สำหรับตัวเลขฐานสิบ `Nl` สำหรับอักขระตัวเลขที่เหมือนตัวอักษรและ `No` สำหรับอักขระตัวเลขอื่น ๆ) ระบุไว้ใน [Unicode Character Database][ucd] [`UnicodeData.txt`]
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// ส่งคืนตัววนซ้ำที่ให้การแมปตัวพิมพ์เล็กของ `char` นี้เป็นหนึ่งตัวหรือมากกว่า
    /// `char`s.
    ///
    /// หาก `char` นี้ไม่มีการแมปตัวพิมพ์เล็กตัววนซ้ำจะให้ `char` เดียวกัน
    ///
    /// หาก `char` นี้มีการแม็พตัวพิมพ์เล็กแบบหนึ่งต่อหนึ่งที่กำหนดโดย [Unicode Character Database][ucd] [`UnicodeData.txt`] ตัววนซ้ำจะให้ `char` นั้น
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// หาก `char` นี้ต้องการข้อพิจารณาพิเศษ (เช่น "อักขระ" หลายตัวตัววนซ้ำจะให้ "อักขระ" ที่กำหนดโดย [`SpecialCasing.txt`]
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// การดำเนินการนี้ดำเนินการทำแผนที่โดยไม่มีเงื่อนไขโดยไม่ต้องปรับแต่งนั่นคือการแปลงไม่ขึ้นอยู่กับบริบทและภาษา
    ///
    /// ใน [Unicode Standard] บทที่ 4 (คุณสมบัติของอักขระ) จะกล่าวถึงการแม็ปเคสโดยทั่วไปและบทที่ 3 (Conformance) กล่าวถึงอัลกอริทึมเริ่มต้นสำหรับการแปลงเคส
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// ในฐานะผู้วนซ้ำ:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ใช้ `println!` โดยตรง:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// ทั้งสองเทียบเท่ากับ:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// ใช้ `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // บางครั้งผลลัพธ์มีมากกว่าหนึ่งอักขระ:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // อักขระที่ไม่มีทั้งตัวพิมพ์ใหญ่และตัวพิมพ์เล็กจะแปลงเป็นตัวเอง
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// ส่งคืนตัววนซ้ำที่ให้การแมปตัวพิมพ์ใหญ่ของ `char` นี้เป็นอย่างน้อยหนึ่งรายการ
    /// `char`s.
    ///
    /// หาก `char` นี้ไม่มีการแมปตัวพิมพ์ใหญ่ตัววนซ้ำจะให้ `char` เดียวกัน
    ///
    /// หาก `char` นี้มีการแม็พตัวพิมพ์ใหญ่แบบหนึ่งต่อหนึ่งที่กำหนดโดย [Unicode Character Database][ucd] [`UnicodeData.txt`] ตัววนซ้ำจะให้ `char` นั้น
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// หาก `char` นี้ต้องการข้อพิจารณาพิเศษ (เช่น "อักขระ" หลายตัวตัววนซ้ำจะให้ "อักขระ" ที่กำหนดโดย [`SpecialCasing.txt`]
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// การดำเนินการนี้ดำเนินการทำแผนที่โดยไม่มีเงื่อนไขโดยไม่ต้องปรับแต่งนั่นคือการแปลงไม่ขึ้นอยู่กับบริบทและภาษา
    ///
    /// ใน [Unicode Standard] บทที่ 4 (คุณสมบัติของอักขระ) จะกล่าวถึงการแม็ปเคสโดยทั่วไปและบทที่ 3 (Conformance) กล่าวถึงอัลกอริทึมเริ่มต้นสำหรับการแปลงเคส
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// ในฐานะผู้วนซ้ำ:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ใช้ `println!` โดยตรง:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// ทั้งสองเทียบเท่ากับ:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// ใช้ `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // บางครั้งผลลัพธ์มีมากกว่าหนึ่งอักขระ:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // อักขระที่ไม่มีทั้งตัวพิมพ์ใหญ่และตัวพิมพ์เล็กจะแปลงเป็นตัวเอง
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # หมายเหตุเกี่ยวกับภาษา
    ///
    /// ในภาษาตุรกีเทียบเท่ากับ 'i' ในภาษาละตินมีห้ารูปแบบแทนที่จะเป็นสองแบบ:
    ///
    /// * 'Dotless': I/ıบางครั้งเขียนï
    /// * 'Dotted': İ/i
    ///
    /// โปรดทราบว่า 'i' ตัวพิมพ์เล็กที่มีจุดประจะเหมือนกับภาษาละตินดังนั้น:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// ค่าของ `upper_i` ที่นี่ขึ้นอยู่กับภาษาของข้อความ: ถ้าเราอยู่ใน `en-US` ควรเป็น `"I"` แต่ถ้าเราอยู่ใน `tr_TR` ก็ควรเป็น `"İ"`
    /// `to_uppercase()` ไม่คำนึงถึงสิ่งนี้ดังนั้น:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// ถือข้ามภาษา
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// ตรวจสอบว่าค่าอยู่ในช่วง ASCII หรือไม่
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// สร้างสำเนาของค่าในตัวพิมพ์ใหญ่ ASCII ที่เทียบเท่า
    ///
    /// ตัวอักษร ASCII 'a' ถึง 'z' ถูกแมปกับ 'A' ถึง 'Z' แต่ตัวอักษรที่ไม่ใช่ ASCII จะไม่เปลี่ยนแปลง
    ///
    /// หากต้องการตัวพิมพ์ใหญ่ค่าแทนให้ใช้ [`make_ascii_uppercase()`]
    ///
    /// หากต้องการใช้อักขระ ASCII ตัวพิมพ์ใหญ่นอกเหนือจากอักขระที่ไม่ใช่ ASCII ให้ใช้ [`to_uppercase()`]
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// สร้างสำเนาของค่าที่เทียบเท่าตัวพิมพ์เล็ก ASCII
    ///
    /// ตัวอักษร ASCII 'A' ถึง 'Z' ถูกแมปกับ 'a' ถึง 'z' แต่ตัวอักษรที่ไม่ใช่ ASCII จะไม่เปลี่ยนแปลง
    ///
    /// ในการพิมพ์ค่าให้เล็กลงให้ใช้ [`make_ascii_lowercase()`]
    ///
    /// หากต้องการใช้อักขระ ASCII ตัวพิมพ์เล็กนอกเหนือจากอักขระที่ไม่ใช่ ASCII ให้ใช้ [`to_lowercase()`]
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// ตรวจสอบว่าค่าสองค่าเป็นการจับคู่แบบไม่คำนึงถึงขนาดตัวพิมพ์ของ ASCII
    ///
    /// เทียบเท่ากับ `to_ascii_lowercase(a) == to_ascii_lowercase(b)`
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// แปลงประเภทนี้เป็นตัวพิมพ์ใหญ่ที่เทียบเท่ากับ ASCII ในตำแหน่ง
    ///
    /// ตัวอักษร ASCII 'a' ถึง 'z' ถูกแมปกับ 'A' ถึง 'Z' แต่ตัวอักษรที่ไม่ใช่ ASCII จะไม่เปลี่ยนแปลง
    ///
    /// หากต้องการส่งคืนค่าตัวพิมพ์ใหญ่ใหม่โดยไม่ต้องแก้ไขค่าที่มีอยู่ให้ใช้ [`to_ascii_uppercase()`]
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// แปลงประเภทนี้เป็น ASCII ตัวพิมพ์เล็กที่เทียบเท่าในตำแหน่ง
    ///
    /// ตัวอักษร ASCII 'A' ถึง 'Z' ถูกแมปกับ 'a' ถึง 'z' แต่ตัวอักษรที่ไม่ใช่ ASCII จะไม่เปลี่ยนแปลง
    ///
    /// หากต้องการส่งคืนค่าที่ลดลงใหม่โดยไม่ต้องแก้ไขค่าที่มีอยู่ให้ใช้ [`to_ascii_lowercase()`]
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// ตรวจสอบว่าค่าเป็นอักขระตามตัวอักษร ASCII หรือไม่:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' หรือ
    /// - U + 0061 'a' ..=U + 007A 'z'
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// ตรวจสอบว่าค่าเป็นอักขระตัวพิมพ์ใหญ่ ASCII หรือไม่:
    /// U + 0041 'A' ..=U + 005A 'Z'
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// ตรวจสอบว่าค่าเป็นอักขระตัวพิมพ์เล็ก ASCII หรือไม่:
    /// U + 0061 'a' ..=U + 007A 'z'
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// ตรวจสอบว่าค่าเป็นอักขระตัวเลขและตัวอักษร ASCII หรือไม่:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' หรือ
    /// - U + 0061 'a' ..=U + 007A 'z' หรือ
    /// - U + 0030 '0' ..=U + 0039 '9'
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// ตรวจสอบว่าค่าเป็นเลขฐานสิบ ASCII หรือไม่:
    /// U + 0030 '0' ..=U + 0039 '9'
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// ตรวจสอบว่าค่าเป็นเลขฐานสิบหก ASCII หรือไม่:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9' หรือ
    /// - U + 0041 'A' ..=U + 0046 'F' หรือ
    /// - U + 0061 'a' ..=U + 0066 'f'
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// ตรวจสอบว่าค่าเป็นอักขระเครื่องหมายวรรคตอน ASCII หรือไม่:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /` หรือ
    /// - U + 003A ..=U + 0040 `: ; < = > ? @` หรือ
    /// - U + 005B ..=U + 0060 ``[\] ^ _`` หรือ
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// ตรวจสอบว่าค่าเป็นอักขระกราฟิก ASCII หรือไม่:
    /// U + 0021 '!' ..=U + 007E '~'
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// ตรวจสอบว่าค่าเป็นอักขระช่องว่าง ASCII หรือไม่:
    /// U + 0020 SPACE, U + 0009 HORIZONTAL TAB, U + 000A LINE FEED, U + 000C FORM FEED หรือ U + 000D CARRIAGE RETURN
    ///
    /// Rust ใช้ [definition of ASCII whitespace][infra-aw] ของ WhatWG Infra Standardมีคำจำกัดความอื่น ๆ อีกมากมายที่ใช้กันอย่างแพร่หลาย
    /// ตัวอย่างเช่น [the POSIX locale][pct] ประกอบด้วย U + 000B VERTICAL TAB และอักขระด้านบนทั้งหมด แต่-จากข้อกำหนดเดียวกัน-[กฎเริ่มต้นสำหรับ "field splitting" ใน Bourne shell][bfs] จะพิจารณา *เฉพาะ* SPACE, HORIZONTAL TAB และ LINE FEED เป็นช่องว่าง
    ///
    ///
    /// หากคุณกำลังเขียนโปรแกรมที่จะประมวลผลรูปแบบไฟล์ที่มีอยู่ให้ตรวจสอบว่าคำจำกัดความของช่องว่างของรูปแบบนั้นคืออะไรก่อนที่จะใช้ฟังก์ชันนี้
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// ตรวจสอบว่าค่าเป็นอักขระควบคุม ASCII หรือไม่:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR หรือ U + 007F DELETE
    /// โปรดสังเกตว่าอักขระช่องว่าง ASCII ส่วนใหญ่เป็นอักขระควบคุม แต่ SPACE ไม่ใช่
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// เข้ารหัสค่า u32 ดิบเป็น UTF-8 ลงในบัฟเฟอร์ไบต์ที่จัดเตรียมไว้จากนั้นส่งคืนส่วนย่อยของบัฟเฟอร์ที่มีอักขระที่เข้ารหัส
///
///
/// ซึ่งแตกต่างจาก `char::encode_utf8` วิธีนี้ยังจัดการจุดรหัสในช่วงตัวแทน
/// (การสร้าง `char` ในช่วงตัวแทนคือ UB) ผลลัพธ์คือ [generalized UTF-8] ที่ถูกต้อง แต่ไม่ใช่ UTF-8 ที่ถูกต้อง
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics หากบัฟเฟอร์ไม่ใหญ่พอ
/// บัฟเฟอร์ความยาวสี่มีขนาดใหญ่พอที่จะเข้ารหัส `char` ใด ๆ
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// เข้ารหัสค่า u32 ดิบเป็น UTF-16 ลงในบัฟเฟอร์ `u16` ที่ให้มาจากนั้นส่งคืนส่วนย่อยของบัฟเฟอร์ที่มีอักขระที่เข้ารหัส
///
///
/// ซึ่งแตกต่างจาก `char::encode_utf16` วิธีนี้ยังจัดการจุดรหัสในช่วงตัวแทน
/// (การสร้าง `char` ในช่วงตัวแทนคือ UB)
///
/// # Panics
///
/// Panics หากบัฟเฟอร์ไม่ใหญ่พอ
/// บัฟเฟอร์ความยาว 2 มีขนาดใหญ่พอที่จะเข้ารหัส `char` ใด ๆ
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // ความปลอดภัย: แต่ละแขนตรวจสอบว่ามีบิตเพียงพอที่จะเขียนลงไปหรือไม่
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP ผ่าน
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // เครื่องบินเสริมบุกเข้าไปในตัวแทน
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}