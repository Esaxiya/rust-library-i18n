//! คอนเทนเนอร์ที่เปลี่ยนแปลงได้ที่แชร์ได้
//!
//! ความปลอดภัยของหน่วยความจำ Rust เป็นไปตามกฎนี้: เมื่อพิจารณาจากวัตถุ `T` จึงเป็นไปได้ที่จะมีสิ่งใดสิ่งหนึ่งต่อไปนี้เท่านั้น:
//!
//! - มีการอ้างอิง (`&T`) ที่ไม่เปลี่ยนรูปหลายรายการให้กับวัตถุ (หรือที่เรียกว่า **aliasing**)
//! - มีการอ้างอิงที่ไม่แน่นอน (`&mut T`) กับวัตถุ (หรือที่เรียกว่า **mutability**)
//!
//! สิ่งนี้บังคับใช้โดยคอมไพเลอร์ Rust อย่างไรก็ตามมีสถานการณ์ที่กฎนี้ไม่ยืดหยุ่นเพียงพอบางครั้งจำเป็นต้องมีการอ้างอิงหลายรายการไปยังวัตถุและยังทำให้เกิดการกลายพันธุ์
//!
//! มีคอนเทนเนอร์ที่เปลี่ยนแปลงได้ร่วมกันเพื่ออนุญาตให้มีการเปลี่ยนแปลงในลักษณะที่ควบคุมได้แม้จะมีการใช้นามแฝงก็ตามทั้ง [`Cell<T>`] และ [`RefCell<T>`] อนุญาตให้ทำสิ่งนี้ในลักษณะเธรดเดียว
//! อย่างไรก็ตาม `Cell<T>` และ `RefCell<T>` ไม่เป็นเธรดที่ปลอดภัย (ไม่ใช้ [`Sync`])
//! หากคุณต้องการทำนามแฝงและการกลายพันธุ์ระหว่างหลายเธรดคุณสามารถใช้ประเภท [`Mutex<T>`], [`RwLock<T>`] หรือ [`atomic`] ได้
//!
//! ค่าของประเภท `Cell<T>` และ `RefCell<T>` อาจกลายพันธุ์ได้ผ่านการอ้างอิงที่ใช้ร่วมกัน (เช่น
//! ประเภท `&T` ทั่วไป) ในขณะที่ประเภท Rust ส่วนใหญ่สามารถกลายพันธุ์ได้จากการอ้างอิง ("&mut T`) ที่ไม่ซ้ำกันเท่านั้น
//! เรากล่าวว่า `Cell<T>` และ `RefCell<T>` ให้ 'ความสามารถในการดัดแปลงภายใน' ในทางตรงกันข้ามกับประเภท Rust ทั่วไปที่แสดง 'ความสามารถในการเปลี่ยนแปลงที่สืบทอดมา'
//!
//! ประเภทของเซลล์มีสองรสชาติ: `Cell<T>` และ `RefCell<T>` `Cell<T>` ใช้การเปลี่ยนแปลงภายในโดยการย้ายค่าเข้าและออกจาก `Cell<T>`
//! ในการใช้การอ้างอิงแทนค่าต้องใช้ชนิด `RefCell<T>` ซึ่งจะได้รับการล็อกการเขียนก่อนที่จะกลายพันธุ์ `Cell<T>` มีวิธีการดึงและเปลี่ยนค่าภายในปัจจุบัน:
//!
//!  - สำหรับชนิดที่ใช้ [`Copy`] วิธี [`get`](Cell::get) จะดึงค่าภายในปัจจุบัน
//!  - สำหรับชนิดที่ใช้ [`Default`] เมธอด [`take`](Cell::take) จะแทนที่ค่าภายในปัจจุบันด้วย [`Default::default()`] และส่งคืนค่าที่ถูกแทนที่
//!  - สำหรับทุกประเภทวิธี [`replace`](Cell::replace) จะแทนที่ค่าภายในปัจจุบันและส่งคืนค่าที่ถูกแทนที่และวิธี [`into_inner`](Cell::into_inner) จะใช้ `Cell<T>` และส่งกลับค่าภายใน
//!  นอกจากนี้วิธี [`set`](Cell::set) จะแทนที่ค่าภายในโดยทิ้งค่าที่ถูกแทนที่
//!
//! `RefCell<T>` ใช้อายุการใช้งานของ Rust ในการใช้ 'การยืมแบบไดนามิก' ซึ่งเป็นกระบวนการที่เราสามารถเรียกร้องสิทธิ์การเข้าถึงมูลค่าภายในได้แบบชั่วคราวโดยเฉพาะและเปลี่ยนแปลงไม่ได้
//! ยืมสำหรับ `` RefCell<T>มีการติดตาม 'ที่รันไทม์' ซึ่งแตกต่างจากประเภทการอ้างอิงดั้งเดิมของ Rust ซึ่งติดตามทั้งหมดแบบคงที่ในเวลาคอมไพล์
//! เนื่องจากการยืม `RefCell<T>` เป็นแบบไดนามิกจึงเป็นไปได้ที่จะพยายามยืมค่าที่ยืมไปแล้วซึ่งกันและกันเมื่อสิ่งนี้เกิดขึ้นจะส่งผลให้เธรด panic
//!
//! # เมื่อใดควรเลือกความไม่แน่นอนภายใน
//!
//! ความสามารถในการเปลี่ยนค่าที่สืบทอดกันโดยทั่วไปมากขึ้นโดยที่เราต้องมีการเข้าถึงที่ไม่ซ้ำกันเพื่อเปลี่ยนค่าเป็นหนึ่งในองค์ประกอบภาษาหลักที่ช่วยให้ Rust ให้เหตุผลอย่างมากเกี่ยวกับนามแฝงตัวชี้ป้องกันข้อบกพร่องแบบคงที่
//! ด้วยเหตุนี้ความสามารถในการเปลี่ยนแปลงที่สืบทอดมาจึงเป็นที่ต้องการและความสามารถในการเปลี่ยนแปลงภายในจึงเป็นทางเลือกสุดท้าย
//! เนื่องจากชนิดของเซลล์เปิดใช้งานการกลายพันธุ์โดยที่มันจะไม่ได้รับอนุญาตแม้ว่าจะมีบางครั้งที่ความสามารถในการกลายพันธุ์ภายในอาจเหมาะสมหรือแม้กระทั่ง *ต้อง* ใช้เช่น
//!
//! * ขอแนะนำ 'inside' ของบางสิ่งที่ไม่เปลี่ยนรูป
//! * รายละเอียดการดำเนินการของวิธีการเชิงตรรกะที่ไม่เปลี่ยนรูป
//! * การใช้งานการกลายพันธุ์ของ [`Clone`]
//!
//! ## ขอแนะนำ 'inside' ของบางสิ่งที่ไม่เปลี่ยนรูป
//!
//! ตัวชี้อัจฉริยะที่ใช้ร่วมกันหลายประเภทรวมถึง [`Rc<T>`] และ [`Arc<T>`] มีคอนเทนเนอร์ที่สามารถโคลนและแชร์ระหว่างหลายฝ่ายได้
//! เนื่องจากค่าที่มีอยู่อาจถูกคูณด้วยนามแฝงจึงสามารถยืมได้ด้วย `&` เท่านั้นไม่ใช่ `&mut`
//! หากไม่มีเซลล์จะเป็นไปไม่ได้ที่จะกลายพันธุ์ข้อมูลภายในตัวชี้อัจฉริยะเหล่านี้เลย
//!
//! เป็นเรื่องปกติมากที่จะใส่ `RefCell<T>` ไว้ในประเภทตัวชี้ที่ใช้ร่วมกันเพื่อแนะนำการเปลี่ยนแปลงใหม่:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // สร้างบล็อกใหม่เพื่อ จำกัด ขอบเขตของการยืมแบบไดนามิก
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // โปรดทราบว่าหากเราไม่ปล่อยให้แคชที่ยืมมาก่อนหน้านี้หลุดออกจากขอบเขตการยืมครั้งต่อ ๆ ไปจะทำให้เกิดเธรดแบบไดนามิก panic
//!     //
//!     // นี่คืออันตรายที่สำคัญของการใช้ `RefCell`
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! โปรดสังเกตว่าตัวอย่างนี้ใช้ `Rc<T>` ไม่ใช่ `Arc<T>` RefCell<T>มีไว้สำหรับสถานการณ์แบบเธรดเดียวพิจารณาใช้ [`RwLock<T>`] หรือ [`Mutex<T>`] หากคุณต้องการความผันแปรที่ใช้ร่วมกันในสถานการณ์แบบมัลติเธรด
//!
//! ## รายละเอียดการดำเนินการของวิธีการเชิงตรรกะที่ไม่เปลี่ยนรูป
//!
//! ในบางครั้งอาจไม่พึงประสงค์ที่จะไม่เปิดเผยใน API ว่ามีการกลายพันธุ์เกิดขึ้น "under the hood"
//! อาจเป็นเพราะในทางตรรกะการดำเนินการไม่เปลี่ยนรูป แต่เช่นการแคชบังคับให้การดำเนินการดำเนินการกลายพันธุ์;หรือเนื่องจากคุณต้องใช้การกลายพันธุ์เพื่อใช้เมธอด trait ซึ่งเดิมกำหนดให้ใช้ `&self`
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // การคำนวณราคาแพงไปที่นี่
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## การใช้งานการกลายพันธุ์ของ `Clone`
//!
//! นี่เป็นเพียงกรณีพิเศษ แต่เป็นเรื่องธรรมดาของก่อนหน้านี้: การซ่อนความไม่แน่นอนสำหรับการดำเนินการที่ดูเหมือนจะไม่เปลี่ยนรูป
//! คาดว่าเมธอด [`clone`](Clone::clone) จะไม่เปลี่ยนค่าต้นทางและถูกประกาศให้ใช้ `&self` ไม่ใช่ `&mut self`
//! ดังนั้นการกลายพันธุ์ใด ๆ ที่เกิดขึ้นในวิธี `clone` จะต้องใช้ชนิดของเซลล์
//! ตัวอย่างเช่น [`Rc<T>`] รักษาจำนวนอ้างอิงภายใน `Cell<T>`
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// ตำแหน่งหน่วยความจำที่ไม่แน่นอน
///
/// # Examples
///
/// ในตัวอย่างนี้คุณจะเห็นว่า `Cell<T>` เปิดใช้งานการกลายพันธุ์ภายในโครงสร้างที่ไม่เปลี่ยนรูป
/// กล่าวอีกนัยหนึ่งก็คือเปิดใช้งาน "interior mutability"
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ข้อผิดพลาด: `my_struct` ไม่เปลี่ยนรูป
/// // my_struct.regular_field =new_value;
///
/// // การทำงาน: แม้ว่า `my_struct` จะไม่เปลี่ยนรูป แต่ `special_field` ก็คือ `Cell`
/// // ซึ่งสามารถกลายพันธุ์ได้เสมอ
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// ดู [module-level documentation](self) เพิ่มเติม
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// สร้าง `Cell<T>` โดยมีค่า `Default` สำหรับ T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// สร้าง `Cell` ใหม่ที่มีค่าที่กำหนด
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// ตั้งค่าที่มีอยู่
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// สลับค่าของสองเซลล์
    /// ความแตกต่างกับ `std::mem::swap` คือฟังก์ชันนี้ไม่ต้องการการอ้างอิง `&mut`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // ความปลอดภัย: อาจมีความเสี่ยงหากถูกเรียกจากเธรดแยกกัน แต่ `Cell`
        // คือ `!Sync` ดังนั้นสิ่งนี้จะไม่เกิดขึ้น
        // สิ่งนี้จะไม่ทำให้พอยน์เตอร์เป็นโมฆะเนื่องจาก `Cell` ทำให้แน่ใจว่าจะไม่มีอะไรชี้ไปที่ "เซลล์" อย่างใดอย่างหนึ่งเหล่านี้
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// แทนที่ค่าที่มีอยู่ด้วย `val` และส่งคืนค่าที่มีอยู่เดิม
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // ความปลอดภัย: สิ่งนี้อาจทำให้เกิดการแข่งขันของข้อมูลหากถูกเรียกจากเธรดแยกต่างหาก
        // แต่ `Cell` คือ `!Sync` ดังนั้นสิ่งนี้จะไม่เกิดขึ้น
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// แกะค่า
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// ส่งคืนสำเนาของค่าที่มีอยู่
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // ความปลอดภัย: สิ่งนี้อาจทำให้เกิดการแข่งขันของข้อมูลหากถูกเรียกจากเธรดแยกต่างหาก
        // แต่ `Cell` คือ `!Sync` ดังนั้นสิ่งนี้จะไม่เกิดขึ้น
        unsafe { *self.value.get() }
    }

    /// อัพเดตค่าที่มีอยู่โดยใช้ฟังก์ชันและส่งคืนค่าใหม่
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// ส่งกลับตัวชี้ดิบไปยังข้อมูลพื้นฐานในเซลล์นี้
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// ส่งคืนการอ้างอิงที่ไม่แน่นอนไปยังข้อมูลพื้นฐาน
    ///
    /// สายนี้ยืม `Cell` ร่วมกัน (ในเวลาคอมไพล์) ซึ่งรับประกันว่าเรามีข้อมูลอ้างอิงเพียงอย่างเดียว
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// ส่งคืน `&Cell<T>` จาก `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // ความปลอดภัย: `&mut` รับประกันการเข้าถึงที่ไม่ซ้ำใคร
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// รับค่าของเซลล์โดยปล่อยให้ `Default::default()` แทนค่า
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// ส่งคืน `&[Cell<T>]` จาก `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // ความปลอดภัย: `Cell<T>` มีเค้าโครงหน่วยความจำเช่นเดียวกับ `T`
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// ตำแหน่งหน่วยความจำที่ไม่แน่นอนพร้อมกฎการยืมที่ตรวจสอบแบบไดนามิก
///
/// ดู [module-level documentation](self) เพิ่มเติม
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// ข้อผิดพลาดที่ส่งคืนโดย [`RefCell::try_borrow`]
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// ข้อผิดพลาดที่ส่งคืนโดย [`RefCell::try_borrow_mut`]
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// ค่าบวกแสดงจำนวน `Ref` ที่ใช้งานอยู่ค่าลบแสดงจำนวน `RefMut` ที่ใช้งานอยู่
// "RefMut" หลายรายการสามารถทำงานได้ในแต่ละครั้งหากอ้างถึงส่วนประกอบที่ไม่ซ้ำกันและไม่ซ้อนทับของ `RefCell` (เช่นช่วงที่แตกต่างกันของชิ้นส่วน)
//
// `Ref` และ `RefMut` มีขนาดสองคำดังนั้นจึงไม่มีแนวโน้มที่จะมี "อ้างอิง" หรือ "RefMut" เพียงพอที่จะล้นครึ่งหนึ่งของช่วง `usize`
// ดังนั้น `BorrowFlag` อาจจะไม่ล้นหรือต่ำเกินไป
// อย่างไรก็ตามนี่ไม่ใช่การรับประกันเนื่องจากโปรแกรมทางพยาธิวิทยาสามารถสร้างซ้ำ ๆ ได้แล้ว mem::forget "Ref`s หรือ"RefMut"
// ดังนั้นโค้ดทั้งหมดจะต้องตรวจสอบอย่างชัดเจนว่าล้นและต่ำเกินไปเพื่อหลีกเลี่ยงความไม่ปลอดภัยหรืออย่างน้อยก็ทำงานได้อย่างถูกต้องในกรณีที่เกิดการล้นหรือล้น (เช่นดู BorrowRef::new)
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// สร้าง `RefCell` ใหม่ที่มี `value`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// ใช้ `RefCell` คืนค่าที่ห่อไว้
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // เนื่องจากฟังก์ชันนี้ใช้ `self` (`RefCell`) ตามค่าคอมไพลเลอร์จะตรวจสอบแบบคงที่ว่ายังไม่ได้ยืมในขณะนี้
        //
        self.value.into_inner()
    }

    /// แทนที่ค่าที่ห่อด้วยค่าใหม่โดยส่งคืนค่าเก่าโดยไม่ต้องยกเลิกการกำหนดค่าเริ่มต้นอย่างใดอย่างหนึ่ง
    ///
    ///
    /// ฟังก์ชันนี้สอดคล้องกับ [`std::mem::replace`](../mem/fn.replace.html)
    ///
    /// # Panics
    ///
    /// Panics หากมีการยืมค่าในปัจจุบัน
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// แทนที่ค่าที่รวมไว้ด้วยค่าใหม่ที่คำนวณจาก `f` โดยส่งคืนค่าเก่าโดยไม่ต้องยกเลิกการกำหนดค่าเริ่มต้นอย่างใดอย่างหนึ่ง
    ///
    ///
    /// # Panics
    ///
    /// Panics หากมีการยืมค่าในปัจจุบัน
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// สลับค่าที่ห่อไว้ของ `self` ด้วยค่าที่รวมเป็น `other` โดยไม่ต้องยกเลิกการกำหนดค่าเริ่มต้นอย่างใดอย่างหนึ่ง
    ///
    ///
    /// ฟังก์ชันนี้สอดคล้องกับ [`std::mem::swap`](../mem/fn.swap.html)
    ///
    /// # Panics
    ///
    /// Panics หากมีการยืมค่าใน `RefCell` ในปัจจุบัน
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// ยืมมูลค่าที่ห่อไว้โดยไม่เปลี่ยนแปลง
    ///
    /// การยืมจะมีผลจนกว่า `Ref` ที่ส่งคืนจะออกจากขอบเขต
    /// สามารถนำการยืมที่ไม่เปลี่ยนรูปหลายรายการออกพร้อมกันได้
    ///
    /// # Panics
    ///
    /// Panics หากค่าถูกยืมในปัจจุบัน
    /// สำหรับตัวแปรที่ไม่ตื่นตระหนกให้ใช้ [`try_borrow`](#method.try_borrow)
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// ตัวอย่างของ panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// ยืมค่าที่ห่อไว้โดยไม่เปลี่ยนแปลงโดยจะส่งคืนข้อผิดพลาดหากค่าถูกยืมไปพร้อมกันในขณะนี้
    ///
    ///
    /// การยืมจะมีผลจนกว่า `Ref` ที่ส่งคืนจะออกจากขอบเขต
    /// สามารถนำการยืมที่ไม่เปลี่ยนรูปหลายรายการออกพร้อมกันได้
    ///
    /// นี่คือตัวแปรที่ไม่ตื่นตระหนกของ [`borrow`](#method.borrow)
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // ความปลอดภัย: `BorrowRef` ช่วยให้มั่นใจได้ว่ามีการเข้าถึงที่ไม่เปลี่ยนรูปเท่านั้น
            // เป็นมูลค่าขณะยืม
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// ยืมมูลค่าที่ห่อมาโดยรวมกัน
    ///
    /// การยืมจะมีผลจนกว่า `RefMut` ที่ส่งคืนหรือ "RefMut" ทั้งหมดที่ได้มาจากขอบเขตการออก
    ///
    /// ไม่สามารถยืมมูลค่าได้ในขณะที่การยืมนี้ทำงานอยู่
    ///
    /// # Panics
    ///
    /// Panics หากมีการยืมค่าในปัจจุบัน
    /// สำหรับตัวแปรที่ไม่ตื่นตระหนกให้ใช้ [`try_borrow_mut`](#method.try_borrow_mut)
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// ตัวอย่างของ panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// ยืมค่าที่ห่อมาโดยรวมกันส่งกลับข้อผิดพลาดหากค่าถูกยืมในปัจจุบัน
    ///
    ///
    /// การยืมจะมีผลจนกว่า `RefMut` ที่ส่งคืนหรือ "RefMut" ทั้งหมดที่ได้มาจากขอบเขตการออก
    /// ไม่สามารถยืมมูลค่าได้ในขณะที่การยืมนี้ทำงานอยู่
    ///
    /// นี่คือตัวแปรที่ไม่ตื่นตระหนกของ [`borrow_mut`](#method.borrow_mut)
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // ความปลอดภัย: `BorrowRef` รับประกันการเข้าถึงที่ไม่ซ้ำใคร
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// ส่งกลับตัวชี้ดิบไปยังข้อมูลพื้นฐานในเซลล์นี้
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// ส่งคืนการอ้างอิงที่ไม่แน่นอนไปยังข้อมูลพื้นฐาน
    ///
    /// การเรียกนี้ยืม `RefCell` ร่วมกัน (ในเวลาคอมไพล์) ดังนั้นจึงไม่จำเป็นต้องมีการตรวจสอบแบบไดนามิก
    ///
    /// อย่างไรก็ตามโปรดใช้ความระมัดระวัง: วิธีนี้คาดว่า `self` จะไม่แน่นอนซึ่งโดยทั่วไปไม่เป็นเช่นนั้นเมื่อใช้ `RefCell`
    ///
    /// ลองดูวิธี [`borrow_mut`] แทนหาก `self` ไม่เปลี่ยนแปลง
    ///
    /// นอกจากนี้โปรดทราบว่าวิธีนี้ใช้สำหรับสถานการณ์พิเศษเท่านั้นและมักไม่ใช่สิ่งที่คุณต้องการ
    /// ในกรณีที่มีข้อสงสัยให้ใช้ [`borrow_mut`] แทน
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// ยกเลิกเอฟเฟกต์ของยามรั่วที่มีต่อสถานะการยืมของ `RefCell`
    ///
    /// สายนี้คล้ายกับ [`get_mut`] แต่เชี่ยวชาญกว่า
    /// มันยืม `RefCell` ร่วมกันเพื่อให้แน่ใจว่าไม่มีการยืมแล้วรีเซ็ตการติดตามสถานะที่ใช้ร่วมกันยืม
    /// สิ่งนี้มีความเกี่ยวข้องหากมีการรั่วไหลของการยืม `Ref` หรือ `RefMut` บางรายการ
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// ยืมค่าที่ห่อไว้โดยไม่เปลี่ยนแปลงโดยจะส่งคืนข้อผิดพลาดหากค่าถูกยืมไปพร้อมกันในขณะนี้
    ///
    /// # Safety
    ///
    /// ซึ่งแตกต่างจาก `RefCell::borrow` วิธีนี้ไม่ปลอดภัยเนื่องจากไม่ส่งคืน `Ref` จึงปล่อยให้ค่าสถานะยืมโดยไม่ถูกแตะต้อง
    /// การยืม `RefCell` ร่วมกันในขณะที่การอ้างอิงที่ส่งคืนโดยวิธีนี้ยังมีชีวิตอยู่นั้นเป็นพฤติกรรมที่ไม่ได้กำหนด
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // ความปลอดภัย: เราตรวจสอบว่าไม่มีใครเขียนข้อความอยู่ในขณะนี้ แต่เป็นอย่างนั้น
            // ความรับผิดชอบของผู้โทรในการตรวจสอบให้แน่ใจว่าไม่มีใครเขียนจนกว่าการอ้างอิงที่ส่งคืนจะไม่ถูกใช้งานอีกต่อไป
            // นอกจากนี้ `self.value.get()` ยังหมายถึงมูลค่าที่ `self` เป็นเจ้าของดังนั้นจึงรับประกันได้ว่าจะใช้ได้ตลอดอายุการใช้งานของ `self`
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// รับค่าที่ห่อไว้โดยปล่อยให้ `Default::default()` แทนค่า
    ///
    /// # Panics
    ///
    /// Panics หากมีการยืมค่าในปัจจุบัน
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics หากค่าถูกยืมในปัจจุบัน
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// สร้าง `RefCell<T>` โดยมีค่า `Default` สำหรับ T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics หากมีการยืมค่าใน `RefCell` ในปัจจุบัน
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics หากมีการยืมค่าใน `RefCell` ในปัจจุบัน
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics หากมีการยืมค่าใน `RefCell` ในปัจจุบัน
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics หากมีการยืมค่าใน `RefCell` ในปัจจุบัน
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics หากมีการยืมค่าใน `RefCell` ในปัจจุบัน
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics หากมีการยืมค่าใน `RefCell` ในปัจจุบัน
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics หากมีการยืมค่าใน `RefCell` ในปัจจุบัน
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // การยืมที่เพิ่มขึ้นอาจส่งผลให้เกิดค่าที่ไม่ได้อ่าน (<=0) ในกรณีเหล่านี้:
            // 1. มันเป็น <0 นั่นคือมีการเขียนยืมดังนั้นเราจึงไม่สามารถอนุญาตให้ยืมอ่านได้เนื่องจากกฎนามแฝงอ้างอิงของ Rust
            // 2.
            // มันคือ isize::MAX (จำนวนการยืมสูงสุดของการอ่าน) และมันล้นไปที่ isize::MIN (จำนวนการยืมการเขียนสูงสุด) ดังนั้นเราจึงไม่สามารถอนุญาตให้มีการยืมการอ่านเพิ่มเติมได้เนื่องจาก isize ไม่สามารถแสดงถึงการยืมการอ่านจำนวนมากได้ (สิ่งนี้จะเกิดขึ้นได้ก็ต่อเมื่อ คุณ mem::forget มากกว่าค่าคงที่เล็กน้อยซึ่งไม่ใช่แนวทางปฏิบัติที่ดี)
            //
            //
            //
            //
            None
        } else {
            // การยืมเพิ่มขึ้นอาจส่งผลให้ค่าการอ่าน (> 0) ในกรณีเหล่านี้:
            // 1. มันคือ=0 นั่นคือมันไม่ได้ยืมมาและเรากำลังทำการยืมเพื่ออ่านครั้งแรก
            // 2. มันคือ> 0 และ <isize::MAX กล่าวคือ
            // มีการยืมอ่านและ isize มีขนาดใหญ่พอที่จะแสดงถึงการยืมอ่านอีกครั้งหนึ่ง
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // เนื่องจาก Ref นี้มีอยู่เราจึงรู้ว่าค่าสถานะยืมคือการยืมเพื่ออ่าน
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // ป้องกันไม่ให้เคาน์เตอร์ยืมล้นเป็นการยืมงานเขียน
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// รวมการอ้างอิงที่ยืมไปยังค่าในกล่อง `RefCell`
/// ประเภท Wrapper สำหรับค่าที่ยืมมาจาก `RefCell<T>` อย่างไม่เปลี่ยนรูป
///
/// ดู [module-level documentation](self) เพิ่มเติม
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// คัดลอก `Ref`
    ///
    /// `RefCell` ถูกยืมไปแล้วอย่างไม่เปลี่ยนรูปดังนั้นจึงไม่สามารถล้มเหลวได้
    ///
    /// นี่คือฟังก์ชันที่เกี่ยวข้องซึ่งจำเป็นต้องใช้เป็น `Ref::clone(...)`
    /// การใช้งาน `Clone` หรือวิธีการอาจรบกวนการใช้ `r.borrow().clone()` อย่างกว้างขวางเพื่อโคลนเนื้อหาของ `RefCell`
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// สร้าง `Ref` ใหม่สำหรับส่วนประกอบของข้อมูลที่ยืมมา
    ///
    /// `RefCell` ถูกยืมไปแล้วอย่างไม่เปลี่ยนรูปดังนั้นจึงไม่สามารถล้มเหลวได้
    ///
    /// นี่คือฟังก์ชันที่เกี่ยวข้องซึ่งจำเป็นต้องใช้เป็น `Ref::map(...)`
    /// เมธอดจะรบกวนเมธอดที่มีชื่อเดียวกันในเนื้อหาของ `RefCell` ที่ใช้ผ่าน `Deref`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// สร้าง `Ref` ใหม่สำหรับส่วนประกอบทางเลือกของข้อมูลที่ยืมมา
    /// ตัวป้องกันเดิมจะถูกส่งคืนเป็น `Err(..)` หากการปิดคืนค่า `None`
    ///
    /// `RefCell` ถูกยืมไปแล้วอย่างไม่เปลี่ยนรูปดังนั้นจึงไม่สามารถล้มเหลวได้
    ///
    /// นี่คือฟังก์ชันที่เกี่ยวข้องซึ่งจำเป็นต้องใช้เป็น `Ref::filter_map(...)`
    /// เมธอดจะรบกวนเมธอดที่มีชื่อเดียวกันในเนื้อหาของ `RefCell` ที่ใช้ผ่าน `Deref`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// แยก `Ref` เป็น "อ้างอิง" หลายรายการสำหรับส่วนประกอบต่างๆของข้อมูลที่ยืมมา
    ///
    /// `RefCell` ถูกยืมไปแล้วอย่างไม่เปลี่ยนรูปดังนั้นจึงไม่สามารถล้มเหลวได้
    ///
    /// นี่คือฟังก์ชันที่เกี่ยวข้องซึ่งจำเป็นต้องใช้เป็น `Ref::map_split(...)`
    /// เมธอดจะรบกวนเมธอดที่มีชื่อเดียวกันในเนื้อหาของ `RefCell` ที่ใช้ผ่าน `Deref`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// แปลงเป็นการอ้างอิงข้อมูลพื้นฐาน
    ///
    /// `RefCell` ที่อยู่ภายใต้จะไม่สามารถยืมมาใช้ร่วมกันได้อีกและมักจะปรากฏว่ายืมมาแล้วโดยไม่เปลี่ยนรูป
    ///
    /// ไม่ใช่ความคิดที่ดีที่จะรั่วไหลมากกว่าจำนวนคงที่ของการอ้างอิง
    /// `RefCell` สามารถยืมซ้ำได้อีกครั้งหากเกิดการรั่วไหลเพียงเล็กน้อย
    ///
    /// นี่คือฟังก์ชันที่เกี่ยวข้องซึ่งจำเป็นต้องใช้เป็น `Ref::leak(...)`
    /// เมธอดจะรบกวนเมธอดที่มีชื่อเดียวกันในเนื้อหาของ `RefCell` ที่ใช้ผ่าน `Deref`
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // การลืม Ref นี้ทำให้มั่นใจได้ว่าตัวนับการยืมใน RefCell จะไม่สามารถย้อนกลับไปที่ UNUSED ได้ภายใน `'b` ตลอดอายุการใช้งาน
        // การรีเซ็ตสถานะการติดตามการอ้างอิงจะต้องมีการอ้างอิงเฉพาะกับ RefCell ที่ยืมมา
        // ไม่สามารถสร้างการอ้างอิงที่เปลี่ยนแปลงได้เพิ่มเติมจากเซลล์เดิม
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// สร้าง `RefMut` ใหม่สำหรับส่วนประกอบของข้อมูลที่ยืมมาเช่นตัวแปร enum
    ///
    /// `RefCell` ถูกยืมไปแล้วโดยไม่แน่นอนดังนั้นจึงไม่สามารถล้มเหลวได้
    ///
    /// นี่คือฟังก์ชันที่เกี่ยวข้องซึ่งจำเป็นต้องใช้เป็น `RefMut::map(...)`
    /// เมธอดจะรบกวนเมธอดที่มีชื่อเดียวกันในเนื้อหาของ `RefCell` ที่ใช้ผ่าน `Deref`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): แก้ไขการยืม-ตรวจสอบ
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// สร้าง `RefMut` ใหม่สำหรับส่วนประกอบทางเลือกของข้อมูลที่ยืมมา
    /// ตัวป้องกันเดิมจะถูกส่งคืนเป็น `Err(..)` หากการปิดคืนค่า `None`
    ///
    /// `RefCell` ถูกยืมไปแล้วโดยไม่แน่นอนดังนั้นจึงไม่สามารถล้มเหลวได้
    ///
    /// นี่คือฟังก์ชันที่เกี่ยวข้องซึ่งจำเป็นต้องใช้เป็น `RefMut::filter_map(...)`
    /// เมธอดจะรบกวนเมธอดที่มีชื่อเดียวกันในเนื้อหาของ `RefCell` ที่ใช้ผ่าน `Deref`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): แก้ไขการยืม-ตรวจสอบ
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // ความปลอดภัย: ฟังก์ชั่นถือเป็นข้อมูลอ้างอิงเฉพาะสำหรับช่วงเวลา
        // ของการโทรผ่าน `orig` และตัวชี้จะถูกอ้างถึงภายในการเรียกใช้ฟังก์ชันเท่านั้นที่ไม่อนุญาตให้การอ้างอิงพิเศษหลุดออกไป
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // ความปลอดภัย: เช่นเดียวกับด้านบน
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// แยก `RefMut` เป็น "RefMut" หลายรายการสำหรับส่วนประกอบต่างๆของข้อมูลที่ยืมมา
    ///
    /// `RefCell` ที่อยู่ภายใต้จะยังคงถูกยืมต่อเนื่องกันจนกว่า "RefMut" ที่ส่งคืนทั้งสองจะอยู่นอกขอบเขต
    ///
    /// `RefCell` ถูกยืมไปแล้วโดยไม่แน่นอนดังนั้นจึงไม่สามารถล้มเหลวได้
    ///
    /// นี่คือฟังก์ชันที่เกี่ยวข้องซึ่งจำเป็นต้องใช้เป็น `RefMut::map_split(...)`
    /// เมธอดจะรบกวนเมธอดที่มีชื่อเดียวกันในเนื้อหาของ `RefCell` ที่ใช้ผ่าน `Deref`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// แปลงเป็นการอ้างอิงที่ไม่แน่นอนไปยังข้อมูลพื้นฐาน
    ///
    /// `RefCell` ที่อยู่ภายใต้นั้นไม่สามารถยืมมาใช้ได้อีกและมักจะปรากฏว่ามีการยืมแบบไม่ต่อเนื่องกันอยู่แล้วทำให้การอ้างอิงที่ส่งคืนเป็นเพียงข้อมูลภายในเท่านั้น
    ///
    ///
    /// นี่คือฟังก์ชันที่เกี่ยวข้องซึ่งจำเป็นต้องใช้เป็น `RefMut::leak(...)`
    /// เมธอดจะรบกวนเมธอดที่มีชื่อเดียวกันในเนื้อหาของ `RefCell` ที่ใช้ผ่าน `Deref`
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // การลืม BorrowRefMut นี้เรามั่นใจว่าเคาน์เตอร์ยืมใน RefCell ไม่สามารถย้อนกลับไปที่ UNUSED ได้ภายใน `'b` ตลอดอายุการใช้งาน
        // การรีเซ็ตสถานะการติดตามการอ้างอิงจะต้องมีการอ้างอิงเฉพาะกับ RefCell ที่ยืมมา
        // ไม่สามารถสร้างการอ้างอิงเพิ่มเติมจากเซลล์เดิมภายในอายุการใช้งานนั้นได้ทำให้การยืมในปัจจุบันเป็นเพียงข้อมูลอ้างอิงสำหรับอายุการใช้งานที่เหลืออยู่
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: แตกต่างจาก BorrowRefMut::clone ใหม่ถูกเรียกเพื่อสร้างการเริ่มต้น
        // การอ้างอิงที่ไม่แน่นอนดังนั้นในขณะนี้จะต้องไม่มีการอ้างอิงที่มีอยู่
        // ดังนั้นในขณะที่การโคลนเพิ่มจำนวนการอ้างอิงที่ไม่แน่นอนที่นี่เราอนุญาตให้เปลี่ยนจาก UNUSED เป็น UNUSED เท่านั้น 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // โคลน `BorrowRefMut`
    //
    // สิ่งนี้จะใช้ได้ก็ต่อเมื่อใช้ `BorrowRefMut` แต่ละตัวเพื่อติดตามการอ้างอิงที่เปลี่ยนแปลงไม่ได้ไปยังช่วงที่ไม่ซ้ำกันและไม่ซ้อนทับของออบเจ็กต์ดั้งเดิม
    //
    // สิ่งนี้ไม่ได้อยู่ใน Clone โดยนัยดังนั้นรหัสจึงไม่เรียกสิ่งนี้โดยปริยาย
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // ป้องกันไม่ให้เคาน์เตอร์ยืมเงินล้น
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// ประเภท Wrapper สำหรับมูลค่าที่ยืมมาจาก `RefCell<T>`
///
/// ดู [module-level documentation](self) เพิ่มเติม
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// หลักดั้งเดิมสำหรับการเปลี่ยนแปลงภายในใน Rust
///
/// หากคุณมี `&T` การอ้างอิงตามปกติแล้วใน Rust คอมไพลเลอร์จะทำการปรับแต่งตามความรู้ที่ `&T` ชี้ไปที่ข้อมูลที่ไม่เปลี่ยนรูปการกลายพันธุ์ข้อมูลนั้นเช่นผ่านนามแฝงหรือโดยการส่ง `&T` ไปเป็น `&mut T` ถือเป็นพฤติกรรมที่ไม่ได้กำหนดไว้
/// `UnsafeCell<T>` เลือกไม่ใช้การรับประกันความไม่เปลี่ยนรูปสำหรับ `&T`: การอ้างอิงที่ใช้ร่วมกัน `&UnsafeCell<T>` อาจชี้ไปที่ข้อมูลที่กำลังกลายพันธุ์สิ่งนี้เรียกว่า "interior mutability"
///
/// ประเภทอื่น ๆ ทั้งหมดที่อนุญาตให้มีการเปลี่ยนแปลงภายในเช่น `Cell<T>` และ `RefCell<T>` ภายในใช้ `UnsafeCell` เพื่อรวมข้อมูล
///
/// โปรดทราบว่าเฉพาะการรับประกันความไม่เปลี่ยนรูปสำหรับการอ้างอิงที่ใช้ร่วมกันเท่านั้นที่ได้รับผลกระทบจาก `UnsafeCell` การรับประกันความเป็นเอกลักษณ์สำหรับการอ้างอิงที่ไม่แน่นอนจะไม่ได้รับผลกระทบไม่มีวิธีทางกฎหมายในการรับนามแฝง `&mut` แม้แต่กับ `UnsafeCell<T>`
///
/// `UnsafeCell` API นั้นง่ายมากในทางเทคนิค: [`.get()`] ให้ตัวชี้ดิบ `*mut T` ไปยังเนื้อหาของมันขึ้นอยู่กับ _you_ ในฐานะผู้ออกแบบนามธรรมเพื่อใช้ตัวชี้ดิบนั้นอย่างถูกต้อง
///
/// [`.get()`]: `UnsafeCell::get`
///
/// กฎการใช้นามแฝง Rust ที่แม่นยำนั้นค่อนข้างอยู่ในฟลักซ์ แต่ประเด็นหลักไม่เป็นที่ถกเถียงกัน:
///
/// - หากคุณสร้างการอ้างอิงที่ปลอดภัยโดยใช้ `'a` ตลอดอายุการใช้งาน (ไม่ว่าจะเป็นการอ้างอิง `&T` หรือ `&mut T`) ที่สามารถเข้าถึงได้ด้วยรหัสปลอดภัย (เช่นเนื่องจากคุณส่งคืน) คุณจะต้องไม่เข้าถึงข้อมูลในลักษณะใดก็ตามที่ขัดแย้งกับการอ้างอิงนั้นสำหรับส่วนที่เหลือ ของ `'a`
/// ตัวอย่างเช่นหมายความว่าหากคุณใช้ `*mut T` จาก `UnsafeCell<T>` และส่งไปยัง `&T` ข้อมูลใน `T` จะต้องไม่เปลี่ยนรูป (แน่นอนข้อมูล `UnsafeCell` ใด ๆ ที่พบใน `T`) จนกว่าอายุการใช้งานของข้อมูลอ้างอิงนั้นจะหมดอายุ
/// ในทำนองเดียวกันหากคุณสร้างการอ้างอิง `&mut T` ที่เผยแพร่ไปยังรหัสปลอดภัยคุณจะต้องไม่เข้าถึงข้อมูลภายใน `UnsafeCell` จนกว่าการอ้างอิงนั้นจะหมดอายุ
///
/// - ตลอดเวลาคุณต้องหลีกเลี่ยงการแข่งขันข้อมูลหากเธรดหลายเธรดสามารถเข้าถึง `UnsafeCell` เดียวกันการเขียนใด ๆ จะต้องมีความสัมพันธ์ที่เหมาะสมก่อนเกิดกับการเข้าถึงอื่น ๆ ทั้งหมด (หรือใช้อะตอม)
///
/// เพื่อช่วยในการออกแบบที่เหมาะสมสถานการณ์ต่อไปนี้ได้รับการประกาศอย่างชัดเจนว่าถูกกฎหมายสำหรับโค้ดเธรดเดียว:
///
/// 1. การอ้างอิง `&T` สามารถเผยแพร่ไปยังรหัสปลอดภัยและสามารถอยู่ร่วมกับการอ้างอิง `&T` อื่น ๆ ได้ แต่ไม่สามารถใช้กับ `&mut T` ได้
///
/// 2. การอ้างอิง `&mut T` อาจถูกเผยแพร่ไปยังรหัสปลอดภัยหากไม่มี `&mut T` และ `&T` อื่น ๆ อยู่ร่วมกับมัน `&mut T` ต้องไม่ซ้ำกันเสมอ
///
/// โปรดทราบว่าในขณะที่การกลายพันธุ์เนื้อหาของ `&UnsafeCell<T>` (แม้ในขณะที่การอ้างอิง `&UnsafeCell<T>` อื่น ๆ จะใช้นามแฝงเซลล์) ก็ใช้ได้ (หากคุณบังคับใช้ค่าคงที่ข้างต้นด้วยวิธีอื่น) แต่ก็ยังไม่ได้กำหนดพฤติกรรมที่จะมีนามแฝง `&mut UnsafeCell<T>` หลายตัว
/// นั่นคือ `UnsafeCell` เป็นกระดาษห่อหุ้มที่ออกแบบมาให้มีปฏิสัมพันธ์พิเศษกับ _shared_ accesses (_i.e._ ผ่านการอ้างอิง `&UnsafeCell<_>`)ไม่มีเวทย์มนตร์ใด ๆ เมื่อจัดการกับ _exclusive_ accesses (_e.g._ ผ่าน `&mut UnsafeCell<_>`) ทั้งเซลล์และค่าที่ห่อหุ้มไว้จะไม่สามารถใช้นามแฝงได้ตลอดระยะเวลาของการยืม `&mut` นั้น
///
/// สิ่งนี้จัดแสดงโดยตัวเข้าถึง [`.get_mut()`] ซึ่งเป็น _safe_ getter ที่ให้ผล `&mut T`
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// นี่คือตัวอย่างที่แสดงวิธีการกลายพันธุ์เนื้อหาของ `UnsafeCell<_>` อย่างสมบูรณ์แม้ว่าจะมีการอ้างอิงหลายตัวที่ใช้นามแฝงเซลล์:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // รับการอ้างอิงหลายรายการ/พร้อมกัน/แชร์กับ `x` เดียวกัน
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // ความปลอดภัย: ภายในขอบเขตนี้ไม่มีการอ้างอิงอื่น ๆ เกี่ยวกับเนื้อหาของ "x"
///     // ดังนั้นของเราจึงมีเอกลักษณ์อย่างมีประสิทธิภาพ
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- ยืม-+
///     *p1_exclusive += 27; // |
/// } // <---------- ไม่สามารถไปไกลกว่าจุดนี้ได้ -------------------+
///
/// unsafe {
///     // ความปลอดภัย: ในขอบเขตนี้ไม่มีใครคาดคิดว่าจะมีสิทธิ์เข้าถึงเนื้อหาของ "x" แต่เพียงผู้เดียว
///     // เพื่อให้เราสามารถมีการเข้าถึงที่ใช้ร่วมกันหลายรายการพร้อมกัน
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// ตัวอย่างต่อไปนี้แสดงให้เห็นถึงความจริงที่ว่าการเข้าถึง `UnsafeCell<T>` แบบเอกสิทธิ์เฉพาะบุคคลหมายถึงการเข้าถึง `T` แบบเอกสิทธิ์เฉพาะบุคคล:
///
/// ```rust
/// #![forbid(unsafe_code)] // ด้วยการเข้าถึงพิเศษ
///                         // `UnsafeCell` เป็นกระดาษห่อหุ้มแบบไม่มีออปแบบโปร่งใสดังนั้นจึงไม่จำเป็นต้องใช้ `unsafe` ที่นี่
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // รับข้อมูลอ้างอิงเฉพาะที่ตรวจสอบเวลาคอมไพล์สำหรับ `x`
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // ด้วยการอ้างอิงพิเศษเราสามารถเปลี่ยนเนื้อหาได้ฟรี
/// *p_unique.get_mut() = 0;
/// // หรือเทียบเท่า:
/// x = UnsafeCell::new(0);
///
/// // เมื่อเราเป็นเจ้าของค่าเราสามารถแยกเนื้อหาได้ฟรี
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// สร้างอินสแตนซ์ใหม่ของ `UnsafeCell` ซึ่งจะรวมค่าที่ระบุ
    ///
    ///
    /// การเข้าถึงค่าภายในด้วยวิธีการทั้งหมดคือ `unsafe`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// แกะค่า
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// รับตัวชี้ที่ไม่แน่นอนของค่าที่รวมไว้
    ///
    /// สิ่งนี้สามารถส่งไปยังตัวชี้ได้ทุกชนิด
    /// ตรวจสอบให้แน่ใจว่าการเข้าถึงนั้นไม่ซ้ำกัน (ไม่มีการอ้างอิงที่ใช้งานอยู่ไม่สามารถเปลี่ยนแปลงได้หรือไม่) เมื่อแคสต์ไปที่ `&mut T` และตรวจสอบให้แน่ใจว่าไม่มีการกลายพันธุ์หรือนามแฝงที่เปลี่ยนแปลงได้เกิดขึ้นเมื่อส่งไปที่ `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // เราสามารถส่งตัวชี้จาก `UnsafeCell<T>` ถึง `T` ได้เนื่องจาก #[repr(transparent)]
        // สิ่งนี้ใช้ประโยชน์จากสถานะพิเศษของ libstd ไม่มีการรับประกันสำหรับรหัสผู้ใช้ว่าสิ่งนี้จะทำงานในคอมไพเลอร์รุ่น future!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// ส่งคืนการอ้างอิงที่ไม่แน่นอนไปยังข้อมูลพื้นฐาน
    ///
    /// สายนี้ยืม `UnsafeCell` ร่วมกัน (ในเวลาคอมไพล์) ซึ่งรับประกันว่าเรามีข้อมูลอ้างอิงเพียงอย่างเดียว
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// รับตัวชี้ที่ไม่แน่นอนของค่าที่รวมไว้
    /// ความแตกต่างของ [`get`] คือฟังก์ชันนี้ยอมรับตัวชี้ดิบซึ่งมีประโยชน์ในการหลีกเลี่ยงการสร้างการอ้างอิงชั่วคราว
    ///
    /// ผลลัพธ์สามารถส่งไปยังตัวชี้ได้ทุกชนิด
    /// ตรวจสอบให้แน่ใจว่าการเข้าถึงนั้นไม่ซ้ำกัน (ไม่มีการอ้างอิงที่ใช้งานอยู่ไม่สามารถเปลี่ยนแปลงได้หรือไม่) เมื่อแคสต์ไปที่ `&mut T` และตรวจสอบให้แน่ใจว่าไม่มีการกลายพันธุ์หรือนามแฝงที่ไม่สามารถเปลี่ยนแปลงได้เกิดขึ้นเมื่อแคสต์ไปที่ `&T`
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// การเริ่มต้น `UnsafeCell` แบบค่อยเป็นค่อยไปต้องใช้ `raw_get` เนื่องจากการเรียก `get` จะต้องสร้างการอ้างอิงไปยังข้อมูลที่ไม่ได้กำหนดค่าเริ่มต้น:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // เราสามารถส่งตัวชี้จาก `UnsafeCell<T>` ถึง `T` ได้เนื่องจาก #[repr(transparent)]
        // สิ่งนี้ใช้ประโยชน์จากสถานะพิเศษของ libstd ไม่มีการรับประกันสำหรับรหัสผู้ใช้ว่าสิ่งนี้จะทำงานในคอมไพเลอร์รุ่น future!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// สร้าง `UnsafeCell` โดยมีค่า `Default` สำหรับ T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}