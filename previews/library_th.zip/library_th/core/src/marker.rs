//! traits ดั้งเดิมและประเภทที่แสดงคุณสมบัติพื้นฐานของประเภท
//!
//! ประเภทของ Rust สามารถจำแนกได้หลายวิธีตามคุณสมบัติที่เป็นประโยชน์
//! การจำแนกประเภทเหล่านี้แสดงเป็น traits
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// ประเภทที่สามารถโอนข้ามขอบเขตเธรดได้
///
/// trait นี้จะถูกนำไปใช้โดยอัตโนมัติเมื่อคอมไพเลอร์พิจารณาว่าเหมาะสม
///
/// ตัวอย่างของประเภทที่ไม่ใช่ "ส่ง" คือตัวชี้การนับอ้างอิง [`rc::Rc`][`Rc`]
/// หากเธรดสองเธรดพยายามที่จะโคลน ["Rc`] ที่ชี้ไปที่ค่าที่นับการอ้างอิงเดียวกันพวกเขาอาจพยายามอัปเดตจำนวนการอ้างอิงพร้อมกันซึ่งก็คือ [undefined behavior][ub] เนื่องจาก [`Rc`] ไม่ใช้การดำเนินการของอะตอม
///
/// [`sync::Arc`][arc] ลูกพี่ลูกน้องของมันใช้ปฏิบัติการปรมาณู (มีค่าใช้จ่ายบางส่วน) ดังนั้นจึงเป็น `Send`
///
/// ดู [the Nomicon](../../nomicon/send-and-sync.html) สำหรับรายละเอียดเพิ่มเติม
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// ประเภทที่มีขนาดคงที่ซึ่งทราบเวลาคอมไพล์
///
/// พารามิเตอร์ประเภททั้งหมดมีขอบเขตโดยนัยของ `Sized` ไวยากรณ์พิเศษ `?Sized` สามารถใช้เพื่อลบขอบเขตนี้ได้หากไม่เหมาะสม
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // โครงสร้าง FooUse(Foo<[i32]>);//ข้อผิดพลาด: ไม่มีการใช้ขนาดสำหรับ [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// ข้อยกเว้นประการหนึ่งคือประเภท `Self` โดยปริยายของ trait
/// A trait ไม่มีการผูก `Sized` โดยปริยายเนื่องจากไม่เข้ากันกับ [trait object] s โดยที่ตามนิยามแล้ว trait จำเป็นต้องทำงานร่วมกับตัวดำเนินการที่เป็นไปได้ทั้งหมดและอาจมีขนาดใดก็ได้
///
///
/// แม้ว่า Rust จะให้คุณผูก `Sized` กับ trait แต่คุณจะไม่สามารถใช้มันเพื่อสร้างวัตถุ trait ได้ในภายหลัง:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // ให้ y: &dyn Bar= &Impl;//ข้อผิดพลาด: trait `Bar` ไม่สามารถสร้างเป็นวัตถุได้
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // สำหรับค่าเริ่มต้นเช่นซึ่งต้องการให้ `[T]: !Default` สามารถประเมินได้
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// ประเภทที่สามารถ "unsized" เป็นประเภทขนาดไดนามิก
///
/// ตัวอย่างเช่นประเภทอาร์เรย์ขนาด `[i8; 2]` ใช้ `Unsize<[i8]>` และ `Unsize<dyn fmt::Debug>`
///
/// การใช้งาน `Unsize` ทั้งหมดถูกจัดเตรียมโดยคอมไพเลอร์โดยอัตโนมัติ
///
/// `Unsize` ถูกนำไปใช้สำหรับ:
///
/// - `[T; N]` คือ `Unsize<[T]>`
/// - `T` คือ `Unsize<dyn Trait>` เมื่อ `T: Trait`
/// - `Foo<..., T, ...>` คือ `Unsize<Foo<..., U, ...>>` ถ้า:
///   - `T: Unsize<U>`
///   - Foo เป็นโครงสร้าง
///   - เฉพาะฟิลด์สุดท้ายของ `Foo` เท่านั้นที่มีประเภทที่เกี่ยวข้องกับ `T`
///   - `T` ไม่ได้เป็นส่วนหนึ่งของประเภทของฟิลด์อื่น ๆ
///   - `Bar<T>: Unsize<Bar<U>>`, หากฟิลด์สุดท้ายของ `Foo` มีประเภท `Bar<T>`
///
/// `Unsize` ใช้ร่วมกับ [`ops::CoerceUnsized`] เพื่ออนุญาตให้คอนเทนเนอร์ "user-defined" เช่น [`Rc`] มีประเภทขนาดไดนามิก
/// ดู [DST coercion RFC][RFC982] และ [the nomicon entry on coercion][nomicon-coerce] สำหรับรายละเอียดเพิ่มเติม
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// trait ที่จำเป็นสำหรับค่าคงที่ที่ใช้ในการจับคู่รูปแบบ
///
/// ประเภทใดก็ตามที่ได้รับ `PartialEq` จะใช้ trait นี้โดยอัตโนมัติ *ไม่ว่า* พารามิเตอร์ประเภทจะใช้ `Eq` หรือไม่
///
/// หากรายการ `const` มีบางประเภทที่ไม่ใช้ trait นี้แสดงว่า (1.) ประเภทใดไม่ใช้ `PartialEq` (ซึ่งหมายความว่าค่าคงที่จะไม่ให้วิธีการเปรียบเทียบซึ่งถือว่าการสร้างรหัสมีอยู่) หรือ (2.) ที่ใช้ *ของตัวเอง* เวอร์ชัน `PartialEq` (ซึ่งเราถือว่าไม่เป็นไปตามการเปรียบเทียบความเท่าเทียมกันของโครงสร้าง)
///
///
/// ในสองสถานการณ์ข้างต้นเราปฏิเสธการใช้ค่าคงที่ดังกล่าวในการจับคู่รูปแบบ
///
/// ดู [structural match RFC][RFC1445] และ [issue 63438] ซึ่งกระตุ้นให้ย้ายจากการออกแบบตามแอตทริบิวต์ไปยัง trait นี้
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// trait ที่จำเป็นสำหรับค่าคงที่ที่ใช้ในการจับคู่รูปแบบ
///
/// ประเภทใดก็ตามที่ได้รับ `Eq` จะใช้ trait นี้โดยอัตโนมัติ *ไม่ว่า* พารามิเตอร์ประเภทจะใช้ `Eq` หรือไม่
///
/// นี่เป็นการแฮ็กเพื่อแก้ไขข้อ จำกัด ในระบบประเภทของเรา
///
/// # Background
///
/// เราต้องการกำหนดให้ประเภทของ const ที่ใช้ในการจับคู่รูปแบบมีแอตทริบิวต์ `#[derive(PartialEq, Eq)]`
///
/// ในโลกแห่งอุดมคติเราสามารถตรวจสอบข้อกำหนดนั้นได้โดยเพียงแค่ตรวจสอบว่าประเภทที่กำหนดนั้นใช้ทั้ง `StructuralPartialEq` trait *และ*`Eq` trait
/// อย่างไรก็ตามคุณสามารถมี ADT ที่ *do*`derive(PartialEq, Eq)` และเป็นกรณีที่เราต้องการให้คอมไพเลอร์ยอมรับ แต่ประเภทของค่าคงที่ไม่สามารถใช้งาน `Eq` ได้
///
/// กล่าวคือกรณีเช่นนี้:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (ปัญหาในโค้ดด้านบนคือ `Wrap<fn(&())>` ไม่ใช้ `PartialEq` หรือ `Eq` เนื่องจาก `สำหรับ <'a> fn(&'a _)` does not implement those traits.)
///
/// ดังนั้นเราไม่สามารถพึ่งพาการตรวจสอบไร้เดียงสาสำหรับ `StructuralPartialEq` และ `Eq` ได้
///
/// ในการแฮ็คเพื่อแก้ไขปัญหานี้เราใช้ traits ที่แยกจากกันสองตัวที่ฉีดโดยแต่ละตัวได้รับ (`#[derive(PartialEq)]` และ `#[derive(Eq)]`) และตรวจสอบว่าทั้งสองอย่างมีอยู่ในการตรวจสอบการจับคู่โครงสร้าง
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// ประเภทที่สามารถทำซ้ำค่าได้ง่ายๆโดยการคัดลอกบิต
///
/// โดยค่าเริ่มต้นการเชื่อมโยงตัวแปรจะมี "ย้ายความหมาย"กล่าวอีกนัยหนึ่ง:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` ได้ย้ายไปที่ `y` แล้วจึงไม่สามารถใช้งานได้
///
/// // println! ("{: ?}", x);//ข้อผิดพลาด: การใช้ค่าที่ย้าย
/// ```
///
/// อย่างไรก็ตามหากประเภทใช้ `Copy` จะมี 'copy semantics' แทน:
///
/// ```
/// // เราสามารถได้รับการใช้งาน `Copy`
/// // `Clone` จำเป็นต้องใช้เช่นกันเนื่องจากเป็น supertrait ของ `Copy`
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` เป็นสำเนาของ `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// สิ่งสำคัญคือต้องสังเกตว่าในสองตัวอย่างนี้ข้อแตกต่างเพียงอย่างเดียวคือคุณได้รับอนุญาตให้เข้าถึง `x` หลังจากที่ได้รับมอบหมายหรือไม่
/// ภายใต้ฝากระโปรงทั้งการคัดลอกและการย้ายอาจส่งผลให้บิตถูกคัดลอกในหน่วยความจำแม้ว่าจะมีการปรับให้เหมาะสมในบางครั้ง
///
/// ## ฉันจะใช้ `Copy` ได้อย่างไร
///
/// มีสองวิธีในการนำ `Copy` ไปใช้กับประเภทของคุณวิธีที่ง่ายที่สุดคือการใช้ `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// คุณยังสามารถใช้ `Copy` และ `Clone` ได้ด้วยตนเอง:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// มีความแตกต่างเล็กน้อยระหว่างสองกลยุทธ์นี้: กลยุทธ์ `derive` จะวาง `Copy` ไว้กับพารามิเตอร์ประเภทซึ่งไม่ต้องการเสมอไป
///
/// ## อะไรคือความแตกต่างระหว่าง `Copy` และ `Clone`?
///
/// สำเนาเกิดขึ้นโดยปริยายตัวอย่างเช่นเป็นส่วนหนึ่งของงาน `y = x` พฤติกรรมของ `Copy` ไม่สามารถใช้งานได้มากเกินไปมันเป็นสำเนาที่เรียบง่ายเสมอ
///
/// การโคลนเป็นการกระทำที่ชัดเจน `x.clone()` การใช้งาน [`Clone`] สามารถจัดเตรียมลักษณะการทำงานเฉพาะประเภทที่จำเป็นในการทำซ้ำค่าได้อย่างปลอดภัย
/// ตัวอย่างเช่นการใช้งาน [`Clone`] สำหรับ [`String`] จำเป็นต้องคัดลอกบัฟเฟอร์สตริงชี้ไปที่ฮีป
/// การคัดลอกค่า [`String`] ในระดับบิตอย่างง่ายจะเป็นเพียงการคัดลอกตัวชี้เท่านั้นซึ่งนำไปสู่การเว้นบรรทัดสองครั้ง
/// ด้วยเหตุนี้ [`String`] จึงเป็น [`Clone`] แต่ไม่ใช่ `Copy`
///
/// [`Clone`] เป็น supertrait ของ `Copy` ดังนั้นทุกอย่างที่เป็น `Copy` จะต้องใช้ [`Clone`] ด้วย
/// หากประเภทคือ `Copy` การใช้งาน [`Clone`] จะต้องส่งคืน `*self` เท่านั้น (ดูตัวอย่างด้านบน)
///
/// ## ประเภทของฉันจะเป็น `Copy` ได้เมื่อใด
///
/// ประเภทสามารถใช้ `Copy` ได้หากส่วนประกอบทั้งหมดใช้ `Copy` ตัวอย่างเช่นโครงสร้างนี้สามารถเป็น `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// โครงสร้างสามารถเป็น `Copy` และ [`i32`] คือ `Copy` ดังนั้น `Point` จึงมีสิทธิ์เป็น `Copy`
/// ในทางตรงกันข้ามให้พิจารณา
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// โครงสร้าง `PointList` ไม่สามารถใช้ `Copy` ได้เนื่องจาก [`Vec<T>`] ไม่ใช่ `Copy` หากเราพยายามที่จะได้รับการติดตั้ง `Copy` เราจะได้รับข้อผิดพลาด:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// การอ้างอิงที่ใช้ร่วมกัน (`&T`) ยังเป็น `Copy` ดังนั้นประเภทจึงสามารถเป็น `Copy` ได้แม้ว่าจะมีการอ้างอิงที่ใช้ร่วมกันของประเภท `T` ที่ *ไม่ใช่*`Copy` ก็ตาม
/// พิจารณาโครงสร้างต่อไปนี้ซึ่งสามารถใช้ `Copy` ได้เนื่องจากมีเพียง *การอ้างอิงที่ใช้ร่วมกัน* สำหรับประเภท `PointList` ที่ไม่ใช่ "สำเนา" ของเราจากด้านบน:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## เมื่อ *ไม่สามารถ* ประเภทของฉันเป็น `Copy` ได้?
///
/// บางประเภทไม่สามารถคัดลอกได้อย่างปลอดภัยตัวอย่างเช่นการคัดลอก `&mut T` จะสร้างการอ้างอิงที่ไม่แน่นอนในนามแฝง
/// การคัดลอก [`String`] จะซ้ำซ้อนกับความรับผิดชอบในการจัดการบัฟเฟอร์ของ ["String"] ซึ่งนำไปสู่การฟรีสองเท่า
///
/// สรุปกรณีหลังประเภทใด ๆ ที่ใช้ [`Drop`] ไม่สามารถเป็น `Copy` ได้เนื่องจากกำลังจัดการทรัพยากรบางอย่างนอกเหนือจากไบต์ [`size_of::<T>`] ของตัวเอง
///
/// หากคุณพยายามใช้ `Copy` บนโครงสร้างหรือ enum ที่มีข้อมูลที่ไม่ใช่ "คัดลอก" คุณจะได้รับข้อผิดพลาด [E0204]
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## เมื่อไร *ควร* ประเภทของฉันเป็น `Copy`?
///
/// โดยทั่วไปถ้าประเภท _can_ ของคุณใช้ `Copy` ก็ควร
/// อย่างไรก็ตามโปรดทราบว่าการใช้งาน `Copy` เป็นส่วนหนึ่งของ API สาธารณะประเภทของคุณ
/// หากประเภทอาจไม่ใช่ "คัดลอก" ใน future ก็ควรระมัดระวังที่จะละเว้นการใช้งาน `Copy` ในตอนนี้เพื่อหลีกเลี่ยงการเปลี่ยนแปลง API ที่ไม่สมบูรณ์
///
/// ## ตัวดำเนินการเพิ่มเติม
///
/// นอกจาก [implementors listed below][impls] แล้วประเภทต่อไปนี้ยังใช้ `Copy`:
///
/// * ประเภทรายการฟังก์ชัน (กล่าวคือประเภทที่แตกต่างกันที่กำหนดไว้สำหรับแต่ละฟังก์ชัน)
/// * ประเภทตัวชี้ฟังก์ชัน (เช่น `fn() -> i32`)
/// * ประเภทอาร์เรย์สำหรับทุกขนาดหากประเภทรายการใช้ `Copy` ด้วย (เช่น `[i32; 123456]`)
/// * ประเภททูเพิลหากแต่ละองค์ประกอบใช้ `Copy` ด้วย (เช่น `()`, `(i32, bool)`)
/// * ประเภทการปิดหากไม่จับค่าจากสภาพแวดล้อมหรือหากค่าที่จับได้ทั้งหมดใช้ `Copy` ด้วยตัวเอง
///   โปรดทราบว่าตัวแปรที่จับโดยการอ้างอิงที่ใช้ร่วมกันจะใช้ `Copy` เสมอ (แม้ว่าผู้อ้างอิงจะไม่ใช้) ในขณะที่ตัวแปรที่จับโดยการอ้างอิงที่เปลี่ยนแปลงไม่ได้จะไม่ใช้ `Copy`
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) สิ่งนี้อนุญาตให้คัดลอกประเภทที่ไม่ใช้ `Copy` เนื่องจากขอบเขตอายุการใช้งานที่ไม่เป็นที่พอใจ (คัดลอก `A<'_>` เมื่อเฉพาะ `A<'static>: Copy` และ `A<'_>: Clone`)
// เรามีแอตทริบิวต์นี้ในตอนนี้เนื่องจากมีความเชี่ยวชาญพิเศษที่มีอยู่ค่อนข้างน้อยใน `Copy` ที่มีอยู่แล้วในไลบรารีมาตรฐานและไม่มีวิธีใดที่จะมีพฤติกรรมนี้อย่างปลอดภัยในตอนนี้
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// มาโครที่ได้รับซึ่งสร้างโดยนัยของ trait `Copy`
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// ประเภทที่ปลอดภัยในการแบ่งปันการอ้างอิงระหว่างเธรด
///
/// trait นี้จะถูกนำไปใช้โดยอัตโนมัติเมื่อคอมไพเลอร์พิจารณาว่าเหมาะสม
///
/// คำจำกัดความที่แม่นยำคือ: ประเภท `T` คือ [`Sync`] ถ้า `&T` เป็น [`Send`] เท่านั้น
/// กล่าวอีกนัยหนึ่งถ้าไม่มีความเป็นไปได้ของ [undefined behavior][ub] (รวมถึงการแข่งขันข้อมูล) เมื่อส่งผ่านการอ้างอิง `&T` ระหว่างเธรด
///
/// อย่างที่เราคาดหวังประเภทดั้งเดิมเช่น [`u8`] และ [`f64`] คือ [`Sync`] ทั้งหมดดังนั้นจึงเป็นประเภทรวมอย่างง่ายที่ประกอบด้วยสิ่งเหล่านี้เช่นสิ่งทอโครงสร้างและอีนัม
/// ตัวอย่างเพิ่มเติมของประเภท [`Sync`] พื้นฐาน ได้แก่ ประเภท "immutable" เช่น `&T` และประเภทที่มีความสามารถในการสืบทอดแบบง่ายเช่น [`Box<T>`][box], [`Vec<T>`][vec] และประเภทคอลเลกชันอื่น ๆ ส่วนใหญ่
///
/// (พารามิเตอร์ทั่วไปต้องเป็น [`Sync`] เพื่อให้คอนเทนเนอร์เป็น [`Sync`])
///
/// ผลลัพธ์ที่น่าแปลกใจของคำจำกัดความคือ `&mut T` คือ `Sync` (ถ้า `T` คือ `Sync`) แม้ว่าจะดูเหมือนว่าอาจทำให้เกิดการกลายพันธุ์ที่ไม่ซิงโครไนซ์
/// เคล็ดลับคือการอ้างอิงที่เปลี่ยนแปลงได้ซึ่งอยู่เบื้องหลังการอ้างอิงที่ใช้ร่วมกัน (นั่นคือ `& &mut T`) จะกลายเป็นแบบอ่านอย่างเดียวราวกับว่าเป็น `& &T`
/// ดังนั้นจึงไม่มีความเสี่ยงที่จะเกิดการแย่งชิงข้อมูล
///
/// ประเภทที่ไม่ใช่ `Sync` คือประเภทที่มี "interior mutability" ในรูปแบบที่ไม่ปลอดภัยต่อเธรดเช่น [`Cell`][cell] และ [`RefCell`][refcell]
/// ประเภทเหล่านี้อนุญาตให้มีการกลายพันธุ์ของเนื้อหาแม้จะผ่านการอ้างอิงที่ใช้ร่วมกันที่ไม่เปลี่ยนรูป
/// ตัวอย่างเช่นวิธี `set` บน [`Cell<T>`][cell] ใช้ `&self` ดังนั้นจึงต้องการเฉพาะการอ้างอิงที่ใช้ร่วมกัน [`&Cell<T>`][cell]
/// วิธีนี้ไม่มีการซิงโครไนซ์ดังนั้น [`Cell`][cell] จึงไม่สามารถเป็น `Sync` ได้
///
/// อีกตัวอย่างหนึ่งของประเภทที่ไม่ใช่ "ซิงค์" คือตัวชี้การนับอ้างอิง [`Rc`][rc]
/// จากการอ้างอิง [`&Rc<T>`][rc] คุณสามารถโคลน [`Rc<T>`][rc] ใหม่ได้โดยปรับเปลี่ยนจำนวนการอ้างอิงด้วยวิธีที่ไม่ใช่อะตอม
///
/// สำหรับกรณีที่ต้องการความสามารถในการดัดแปลงภายในที่ปลอดภัยสำหรับเธรด Rust จะให้ [atomic data types] และการล็อคอย่างชัดเจนผ่าน [`sync::Mutex`][mutex] และ [`sync::RwLock`][rwlock]
/// ประเภทเหล่านี้ทำให้แน่ใจได้ว่าการกลายพันธุ์ใด ๆ ไม่สามารถทำให้เกิดการแข่งขันของข้อมูลได้ดังนั้นประเภทจึงเป็น `Sync`
/// ในทำนองเดียวกัน [`sync::Arc`][arc] มีอะนาล็อกที่ปลอดภัยต่อเธรดของ [`Rc`][rc]
///
/// ทุกประเภทที่มีความสามารถในการเปลี่ยนแปลงภายในจะต้องใช้ [`cell::UnsafeCell`][unsafecell] wrapper รอบ ๆ value(s) ซึ่งสามารถกลายพันธุ์ได้โดยใช้การอ้างอิงที่ใช้ร่วมกัน
/// ไม่สามารถทำสิ่งนี้ได้คือ [undefined behavior][ub]
/// ตัวอย่างเช่น [`transmute`][transmute]-ing จาก `&T` ถึง `&mut T` ไม่ถูกต้อง
///
/// ดู [the Nomicon][nomicon-send-and-sync] สำหรับรายละเอียดเพิ่มเติมเกี่ยวกับ `Sync`
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): เมื่อรองรับการเพิ่มบันทึกย่อใน `rustc_on_unimplemented` ในรุ่นเบต้าและได้รับการขยายเพื่อตรวจสอบว่าการปิดอยู่ที่ใดในห่วงโซ่ความต้องการหรือไม่ให้ขยายออกไปเช่น (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// ประเภทศูนย์ใช้เพื่อทำเครื่องหมายสิ่งที่ "act like" เป็นเจ้าของ `T`
///
/// การเพิ่มฟิลด์ `PhantomData<T>` ลงในประเภทของคุณเป็นการบอกคอมไพเลอร์ว่าประเภทของคุณทำหน้าที่ราวกับว่ามันเก็บค่าของประเภท `T` แม้ว่าจะไม่ได้จริงๆก็ตาม
/// ข้อมูลนี้ใช้เมื่อคำนวณคุณสมบัติด้านความปลอดภัยบางประการ
///
/// สำหรับคำอธิบายเชิงลึกเพิ่มเติมเกี่ยวกับวิธีใช้ `PhantomData<T>` โปรดดู [the Nomicon](../../nomicon/phantom-data.html)
///
/// # หมายเหตุที่น่ากลัว👻👻👻
///
/// แม้ว่าทั้งคู่จะมีชื่อที่น่ากลัว แต่ `PhantomData` และ 'phantom types' ก็มีความสัมพันธ์กัน แต่ไม่เหมือนกันพารามิเตอร์ประเภท phantom เป็นเพียงพารามิเตอร์ประเภทที่ไม่เคยใช้
/// ใน Rust สิ่งนี้มักทำให้คอมไพเลอร์บ่นและวิธีแก้ปัญหาคือเพิ่ม "dummy" ที่ใช้โดยใช้ `PhantomData`
///
/// # Examples
///
/// ## พารามิเตอร์อายุการใช้งานที่ไม่ได้ใช้
///
/// บางทีกรณีการใช้งานที่พบบ่อยที่สุดสำหรับ `PhantomData` คือโครงสร้างที่มีพารามิเตอร์อายุการใช้งานที่ไม่ได้ใช้งานโดยทั่วไปเป็นส่วนหนึ่งของรหัสที่ไม่ปลอดภัย
/// ตัวอย่างเช่นต่อไปนี้เป็นโครงสร้าง `Slice` ที่มีพอยน์เตอร์ประเภท `*const T` สองตัวซึ่งน่าจะชี้ไปที่อาร์เรย์ที่ใดที่หนึ่ง:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// ความตั้งใจคือข้อมูลพื้นฐานจะใช้ได้สำหรับ `'a` ตลอดอายุการใช้งานเท่านั้นดังนั้น `Slice` จึงไม่ควรอยู่เหนือ `'a`
/// อย่างไรก็ตามเจตนานี้ไม่ได้แสดงไว้ในรหัสเนื่องจากไม่มีการใช้ `'a` ตลอดอายุการใช้งานและด้วยเหตุนี้จึงไม่ชัดเจนว่าจะใช้กับข้อมูลใด
/// เราสามารถแก้ไขได้โดยบอกให้คอมไพเลอร์ทำหน้าที่ *ราวกับว่า* โครงสร้าง `Slice` มีการอ้างอิง `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// นอกจากนี้ยังต้องใช้คำอธิบายประกอบ `T: 'a` ซึ่งระบุว่าการอ้างอิงใด ๆ ใน `T` นั้นใช้ได้ตลอดอายุการใช้งาน `'a`
///
/// เมื่อเริ่มต้น `Slice` คุณเพียงแค่ระบุค่า `PhantomData` สำหรับฟิลด์ `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## พารามิเตอร์ชนิดที่ไม่ได้ใช้
///
/// บางครั้งอาจเกิดขึ้นที่คุณมีพารามิเตอร์ประเภทที่ไม่ได้ใช้ซึ่งระบุประเภทของข้อมูลที่มีโครงสร้างเป็น "tied" ถึงแม้ว่าข้อมูลนั้นจะไม่พบในโครงสร้างเองก็ตาม
/// นี่คือตัวอย่างที่เกิดขึ้นกับ [FFI]
/// อินเทอร์เฟซต่างประเทศใช้แฮนเดิลประเภท `*mut ()` เพื่ออ้างถึงค่า Rust ของประเภทต่างๆ
/// เราติดตามประเภท Rust โดยใช้พารามิเตอร์ประเภท phantom บนโครงสร้าง `ExternalResource` ซึ่งรวมตัวจับ
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## ความเป็นเจ้าของและการตรวจสอบการลดลง
///
/// การเพิ่มฟิลด์ประเภท `PhantomData<T>` บ่งชี้ว่าประเภทของคุณเป็นเจ้าของข้อมูลประเภท `T` ในทางกลับกันหมายความว่าเมื่อประเภทของคุณหลุดอาจทำให้ประเภท `T` ตกอย่างน้อยหนึ่งอินสแตนซ์
/// สิ่งนี้มีผลต่อการวิเคราะห์ [drop check] ของคอมไพเลอร์ Rust
///
/// หากโครงสร้างของคุณไม่ได้ *เป็นเจ้าของ* ข้อมูลประเภท `T` จริงควรใช้ประเภทการอ้างอิงเช่น `PhantomData<&'a T>` (ideally) หรือ `PhantomData<*const T>` (หากไม่มีอายุการใช้งาน) เพื่อไม่ให้ระบุความเป็นเจ้าของ
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// คอมไพเลอร์ภายใน trait ใช้เพื่อระบุประเภทของสารเลือกปฏิบัติ
///
/// trait นี้ถูกนำไปใช้โดยอัตโนมัติสำหรับทุกประเภทและไม่ได้เพิ่มการรับประกันใด ๆ ให้กับ [`mem::Discriminant`]
/// เป็น **พฤติกรรมที่ไม่ได้กำหนด** ในการส่งสัญญาณระหว่าง `DiscriminantKind::Discriminant` และ `mem::Discriminant`
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// ประเภทของตัวเลือกซึ่งต้องเป็นไปตาม trait bounds ที่ `mem::Discriminant` ต้องการ
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// trait ภายในคอมไพเลอร์ใช้เพื่อกำหนดว่าชนิดมี `UnsafeCell` อยู่ภายในหรือไม่ แต่ไม่ผ่านการกำหนดทิศทาง
///
/// สิ่งนี้มีผลต่อตัวอย่างเช่นว่า `static` ประเภทนั้นถูกวางไว้ในหน่วยความจำคงที่แบบอ่านอย่างเดียวหรือหน่วยความจำแบบคงที่ที่เขียนได้
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// ประเภทที่สามารถเคลื่อนย้ายได้อย่างปลอดภัยหลังจากถูกตรึง
///
/// Rust เองไม่มีความคิดเกี่ยวกับประเภทที่เคลื่อนย้ายไม่ได้และถือว่าการเคลื่อนไหว (เช่นผ่านการมอบหมายหรือ [`mem::replace`]) จะปลอดภัยเสมอ
///
/// ใช้ประเภท [`Pin`][Pin] แทนเพื่อป้องกันการเคลื่อนที่ผ่านระบบประเภทพอยน์เตอร์ `P<T>` ที่ห่อด้วยกระดาษห่อ [`Pin<P<T>>`][Pin] ไม่สามารถเคลื่อนย้ายออกจาก
/// ดูเอกสาร [`pin` module] สำหรับข้อมูลเพิ่มเติมเกี่ยวกับการตรึง
///
/// การใช้ `Unpin` trait สำหรับ `T` จะช่วยลดข้อ จำกัด ในการตรึงประเภทซึ่งจะช่วยให้สามารถย้าย `T` ออกจาก [`Pin<P<T>>`][Pin] ด้วยฟังก์ชันต่างๆเช่น [`mem::replace`]
///
///
/// `Unpin` ไม่มีผลเลยสำหรับข้อมูลที่ไม่ได้ตรึง
/// โดยเฉพาะอย่างยิ่ง [`mem::replace`] ย้ายข้อมูล `!Unpin` อย่างมีความสุข (ใช้ได้กับ `&mut T` ทุกรุ่นไม่ใช่เฉพาะเมื่อ `T: Unpin`)
/// อย่างไรก็ตามคุณไม่สามารถใช้ [`mem::replace`] กับข้อมูลที่อยู่ภายใน [`Pin<P<T>>`][Pin] ได้เนื่องจากคุณไม่สามารถรับ `&mut T` ที่คุณต้องการได้และ * นั่นคือสิ่งที่ทำให้ระบบนี้ทำงานได้
///
/// ตัวอย่างเช่นสิ่งนี้สามารถทำได้เฉพาะกับประเภทที่ใช้ `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // เราต้องการการอ้างอิงที่ไม่แน่นอนเพื่อเรียกใช้ `mem::replace`
/// // เราสามารถขอรับข้อมูลอ้างอิงดังกล่าวได้โดย (implicitly) เรียกใช้ `Pin::deref_mut` แต่นั่นเป็นไปได้เพราะ `String` ใช้ `Unpin` เท่านั้น
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// trait นี้ถูกใช้งานโดยอัตโนมัติสำหรับเกือบทุกประเภท
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// ประเภทเครื่องหมายที่ไม่ใช้ `Unpin`
///
/// หากประเภทมี `PhantomPinned` จะไม่ใช้ `Unpin` ตามค่าเริ่มต้น
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// การใช้งาน `Copy` สำหรับประเภทดั้งเดิม
///
/// การใช้งานที่ไม่สามารถอธิบายได้ใน Rust ถูกนำไปใช้ใน `traits::SelectionContext::copy_clone_conditions()` ใน `rustc_trait_selection`
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// การอ้างอิงที่ใช้ร่วมกันสามารถคัดลอกได้ แต่การอ้างอิงที่เปลี่ยนแปลงได้ *ไม่สามารถ*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}