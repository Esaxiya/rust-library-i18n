#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! มีนิยามโครงสร้างสำหรับโครงร่างของชนิดในตัวคอมไพเลอร์
//!
//! สามารถใช้เป็นเป้าหมายของการส่งสัญญาณในรหัสที่ไม่ปลอดภัยเพื่อจัดการกับการแสดงข้อมูลดิบโดยตรง
//!
//!
//! คำจำกัดความควรตรงกับ ABI ที่กำหนดไว้ใน `rustc_middle::ty::layout` เสมอ
//!

/// การแสดงวัตถุ trait เช่น `&dyn SomeTrait`
///
/// โครงสร้างนี้มีเค้าโครงเดียวกันกับประเภทเช่น `&dyn SomeTrait` และ `Box<dyn AnotherTrait>`
///
/// `TraitObject` รับประกันว่าจะตรงกับเลย์เอาต์ แต่ไม่ใช่ประเภทของอ็อบเจ็กต์ trait (เช่นฟิลด์ไม่สามารถเข้าถึงได้โดยตรงบน `&dyn SomeTrait`) และไม่ได้ควบคุมเลย์เอาต์นั้น (การเปลี่ยนนิยามจะไม่เปลี่ยนเลย์เอาต์ของ `&dyn SomeTrait`)
///
/// ได้รับการออกแบบมาเพื่อใช้โดยโค้ดที่ไม่ปลอดภัยซึ่งจำเป็นต้องปรับแต่งรายละเอียดระดับต่ำเท่านั้น
///
/// ไม่มีวิธีอ้างอิงถึงวัตถุ trait ทั้งหมดโดยทั่วไปดังนั้นวิธีเดียวที่จะสร้างค่าประเภทนี้คือฟังก์ชันเช่น [`std::mem::transmute`][transmute]
/// ในทำนองเดียวกันวิธีเดียวในการสร้างวัตถุ trait ที่แท้จริงจากค่า `TraitObject` คือ `transmute`
///
/// [transmute]: crate::intrinsics::transmute
///
/// การสังเคราะห์ออบเจ็กต์ trait ที่มีประเภทที่ไม่ตรงกันซึ่งเป็นประเภทที่ vtable ไม่ตรงกับประเภทของค่าที่ตัวชี้ข้อมูลชี้-มีแนวโน้มสูงที่จะนำไปสู่พฤติกรรมที่ไม่ได้กำหนดไว้
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // ตัวอย่าง trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // ให้คอมไพเลอร์สร้างอ็อบเจ็กต์ trait
/// let object: &dyn Foo = &value;
///
/// // ดูการแสดงดิบ
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // ตัวชี้ข้อมูลคือที่อยู่ของ `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // สร้างวัตถุใหม่โดยชี้ไปที่ `i32` อื่นโปรดใช้ความระมัดระวังในการใช้ `i32` vtable จาก `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // มันควรจะทำงานเหมือนกับว่าเราสร้างวัตถุ trait จาก `other_value` โดยตรง
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}