#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // ขยายเป็น `$crate::panic::panic_2015` หรือ `$crate::panic::panic_2021` ขึ้นอยู่กับรุ่นของผู้โทร
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// ยืนยันว่าสองนิพจน์มีค่าเท่ากัน (โดยใช้ [`PartialEq`])
///
/// ใน panic มาโครนี้จะพิมพ์ค่าของนิพจน์ด้วยการแทนค่าดีบัก
///
///
/// เช่นเดียวกับ [`assert!`] มาโครนี้มีรูปแบบที่สองซึ่งสามารถให้ข้อความ panic ที่กำหนดเองได้
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // การรีโบรว์ใหม่ด้านล่างเป็นความตั้งใจ
                    // หากไม่มีพวกเขาช่องสแต็กสำหรับการยืมจะเริ่มต้นก่อนที่จะเปรียบเทียบค่าซึ่งส่งผลให้การทำงานช้าลงอย่างเห็นได้ชัด
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // การรีโบรว์ใหม่ด้านล่างเป็นความตั้งใจ
                    // หากไม่มีพวกเขาช่องสแต็กสำหรับการยืมจะเริ่มต้นก่อนที่จะเปรียบเทียบค่าซึ่งส่งผลให้การทำงานช้าลงอย่างเห็นได้ชัด
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// ยืนยันว่าสองนิพจน์ไม่เท่ากัน (โดยใช้ [`PartialEq`])
///
/// ใน panic มาโครนี้จะพิมพ์ค่าของนิพจน์ด้วยการแทนค่าดีบัก
///
///
/// เช่นเดียวกับ [`assert!`] มาโครนี้มีรูปแบบที่สองซึ่งสามารถให้ข้อความ panic ที่กำหนดเองได้
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // การรีโบรว์ใหม่ด้านล่างเป็นความตั้งใจ
                    // หากไม่มีพวกเขาช่องสแต็กสำหรับการยืมจะเริ่มต้นก่อนที่จะเปรียบเทียบค่าซึ่งส่งผลให้การทำงานช้าลงอย่างเห็นได้ชัด
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // การรีโบรว์ใหม่ด้านล่างเป็นความตั้งใจ
                    // หากไม่มีพวกเขาช่องสแต็กสำหรับการยืมจะเริ่มต้นก่อนที่จะเปรียบเทียบค่าซึ่งส่งผลให้การทำงานช้าลงอย่างเห็นได้ชัด
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// ยืนยันว่านิพจน์บูลีนคือ `true` ที่รันไทม์
///
/// สิ่งนี้จะเรียกใช้แมโคร [`panic!`] หากไม่สามารถประเมินนิพจน์ที่ระบุเป็น `true` ในขณะรันไทม์
///
/// เช่นเดียวกับ [`assert!`] มาโครนี้ยังมีเวอร์ชันที่สองซึ่งสามารถให้ข้อความ panic ที่กำหนดเองได้
///
/// # Uses
///
/// ซึ่งแตกต่างจาก [`assert!`] คำสั่ง `debug_assert!` จะเปิดใช้งานในบิลด์ที่ไม่ได้ปรับให้เหมาะสมตามค่าเริ่มต้นเท่านั้น
/// บิลด์ที่ปรับให้เหมาะสมจะไม่รันคำสั่ง `debug_assert!` เว้นแต่ `-C debug-assertions` จะถูกส่งผ่านไปยังคอมไพเลอร์
/// สิ่งนี้ทำให้ `debug_assert!` มีประโยชน์สำหรับการตรวจสอบที่มีราคาแพงเกินไปที่จะมีอยู่ในรุ่นที่วางจำหน่าย แต่อาจเป็นประโยชน์ในระหว่างการพัฒนา
/// ผลลัพธ์ของการขยาย `debug_assert!` จะถูกตรวจสอบประเภทเสมอ
///
/// การยืนยันที่ไม่ได้ตรวจสอบช่วยให้โปรแกรมที่อยู่ในสถานะที่ไม่สอดคล้องกันสามารถทำงานต่อไปได้ซึ่งอาจส่งผลที่ไม่คาดคิด แต่จะไม่ทำให้เกิดความไม่ปลอดภัยตราบใดที่สิ่งนี้เกิดขึ้นในรหัสปลอดภัยเท่านั้น
///
/// อย่างไรก็ตามค่าใช้จ่ายในการยืนยันประสิทธิภาพนั้นไม่สามารถวัดได้โดยทั่วไป
/// ดังนั้นการแทนที่ [`assert!`] ด้วย `debug_assert!` จึงได้รับการสนับสนุนหลังจากการทำโปรไฟล์อย่างละเอียดเท่านั้นและที่สำคัญกว่านั้นคือรหัสปลอดภัยเท่านั้น!
///
/// # Examples
///
/// ```
/// // ข้อความ panic สำหรับการยืนยันเหล่านี้คือค่าสตริงของนิพจน์ที่กำหนด
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // ฟังก์ชั่นที่เรียบง่ายมาก
/// debug_assert!(some_expensive_computation());
///
/// // ยืนยันด้วยข้อความที่กำหนดเอง
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// ยืนยันว่าสองนิพจน์มีค่าเท่ากัน
///
/// ใน panic มาโครนี้จะพิมพ์ค่าของนิพจน์ด้วยการแทนค่าดีบัก
///
/// ซึ่งแตกต่างจาก [`assert_eq!`] คำสั่ง `debug_assert_eq!` จะเปิดใช้งานในบิลด์ที่ไม่ได้ปรับให้เหมาะสมตามค่าเริ่มต้นเท่านั้น
/// บิลด์ที่ปรับให้เหมาะสมจะไม่รันคำสั่ง `debug_assert_eq!` เว้นแต่ `-C debug-assertions` จะถูกส่งผ่านไปยังคอมไพเลอร์
/// สิ่งนี้ทำให้ `debug_assert_eq!` มีประโยชน์สำหรับการตรวจสอบที่มีราคาแพงเกินไปที่จะมีอยู่ในรุ่นที่วางจำหน่าย แต่อาจเป็นประโยชน์ในระหว่างการพัฒนา
///
/// ผลลัพธ์ของการขยาย `debug_assert_eq!` จะถูกตรวจสอบประเภทเสมอ
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// ยืนยันว่าสองนิพจน์ไม่เท่ากัน
///
/// ใน panic มาโครนี้จะพิมพ์ค่าของนิพจน์ด้วยการแทนค่าดีบัก
///
/// ซึ่งแตกต่างจาก [`assert_ne!`] คำสั่ง `debug_assert_ne!` จะเปิดใช้งานในบิลด์ที่ไม่ได้ปรับให้เหมาะสมตามค่าเริ่มต้นเท่านั้น
/// บิลด์ที่ปรับให้เหมาะสมจะไม่รันคำสั่ง `debug_assert_ne!` เว้นแต่ `-C debug-assertions` จะถูกส่งผ่านไปยังคอมไพเลอร์
/// สิ่งนี้ทำให้ `debug_assert_ne!` มีประโยชน์สำหรับการตรวจสอบที่มีราคาแพงเกินไปที่จะมีอยู่ในรุ่นที่วางจำหน่าย แต่อาจเป็นประโยชน์ในระหว่างการพัฒนา
///
/// ผลลัพธ์ของการขยาย `debug_assert_ne!` จะถูกตรวจสอบประเภทเสมอ
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// ส่งคืนว่านิพจน์ที่ระบุตรงกับรูปแบบที่กำหนดหรือไม่
///
/// เช่นเดียวกับนิพจน์ `match` รูปแบบสามารถเลือกได้ตามด้วย `if` และนิพจน์ยามที่เข้าถึงชื่อที่ผูกด้วยรูปแบบ
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// แกะผลลัพธ์หรือเผยแพร่ข้อผิดพลาด
///
/// เพิ่มตัวดำเนินการ `?` เพื่อแทนที่ `try!` และควรใช้แทน
/// นอกจากนี้ `try` ยังเป็นคำสงวนใน Rust 2018 ดังนั้นหากคุณต้องใช้คุณจะต้องใช้ [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` ตรงกับ [`Result`] ที่กำหนดในกรณีของตัวแปร `Ok` นิพจน์จะมีค่าของค่าที่รวมไว้
///
/// ในกรณีของตัวแปร `Err` จะดึงข้อผิดพลาดภายในจากนั้น `try!` ทำการแปลงโดยใช้ `From`
/// สิ่งนี้ให้การแปลงอัตโนมัติระหว่างข้อผิดพลาดเฉพาะและข้อผิดพลาดทั่วไป
/// ข้อผิดพลาดที่เกิดขึ้นจะถูกส่งกลับทันที
///
/// เนื่องจากการส่งคืนก่อนกำหนดจึงสามารถใช้ `try!` ในฟังก์ชันที่ส่งคืน [`Result`] เท่านั้น
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // วิธีที่ต้องการในการส่งคืนข้อผิดพลาดอย่างรวดเร็ว
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // วิธีก่อนหน้านี้ในการส่งคืนข้อผิดพลาดอย่างรวดเร็ว
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // สิ่งนี้เทียบเท่ากับ:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// เขียนข้อมูลที่จัดรูปแบบลงในบัฟเฟอร์
///
/// แมโครนี้ยอมรับ 'writer' สตริงรูปแบบและรายการอาร์กิวเมนต์
/// อาร์กิวเมนต์จะถูกจัดรูปแบบตามสตริงรูปแบบที่ระบุและผลลัพธ์จะถูกส่งต่อไปยังผู้เขียน
/// ตัวเขียนอาจเป็นค่าใดก็ได้ด้วยวิธี `write_fmt` โดยทั่วไปสิ่งนี้มาจากการใช้งาน [`fmt::Write`] หรือ [`io::Write`] trait
/// มาโครจะส่งคืนค่าใดก็ตามที่วิธี `write_fmt` ส่งคืนโดยทั่วไปคือ [`fmt::Result`] หรือ [`io::Result`]
///
/// ดู [`std::fmt`] สำหรับข้อมูลเพิ่มเติมเกี่ยวกับไวยากรณ์สตริงรูปแบบ
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// โมดูลสามารถนำเข้าทั้ง `std::fmt::Write` และ `std::io::Write` และเรียกใช้ `write!` บนอ็อบเจ็กต์ที่ใช้งานได้เนื่องจากโดยทั่วไปแล้วอ็อบเจ็กต์จะไม่ใช้ทั้งสองอย่าง
///
/// อย่างไรก็ตามโมดูลต้องอิมพอร์ต traits ที่ผ่านการรับรองเพื่อไม่ให้ชื่อขัดแย้งกัน:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // ใช้ fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // ใช้ io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: มาโครนี้สามารถใช้ในการตั้งค่า `no_std` ได้เช่นกัน
/// ในการตั้งค่า `no_std` คุณต้องรับผิดชอบต่อรายละเอียดการใช้งานของส่วนประกอบ
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// เขียนข้อมูลที่จัดรูปแบบลงในบัฟเฟอร์โดยมีการขึ้นบรรทัดใหม่ต่อท้าย
///
/// ในทุกแพลตฟอร์มบรรทัดใหม่คือตัวละคร LINE FEED (`\n`/`U+000A`) เพียงอย่างเดียว (ไม่มี CARRIAGE RETURN (`\r`/`U+000D`) เพิ่มเติม
///
/// สำหรับข้อมูลเพิ่มเติมโปรดดู [`write!`] สำหรับข้อมูลเกี่ยวกับไวยากรณ์สตริงรูปแบบโปรดดู [`std::fmt`]
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// โมดูลสามารถนำเข้าทั้ง `std::fmt::Write` และ `std::io::Write` และเรียกใช้ `write!` บนอ็อบเจ็กต์ที่ใช้งานได้เนื่องจากโดยทั่วไปแล้วอ็อบเจ็กต์จะไม่ใช้ทั้งสองอย่าง
/// อย่างไรก็ตามโมดูลต้องอิมพอร์ต traits ที่ผ่านการรับรองเพื่อไม่ให้ชื่อขัดแย้งกัน:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // ใช้ fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // ใช้ io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// ระบุรหัสที่ไม่สามารถเข้าถึงได้
///
/// สิ่งนี้มีประโยชน์ทุกครั้งที่คอมไพเลอร์ไม่สามารถระบุได้ว่าโค้ดบางส่วนไม่สามารถเข้าถึงได้ตัวอย่างเช่น:
///
/// * จับคู่แขนกับเงื่อนไขการป้องกัน
/// * ลูปที่ยุติแบบไดนามิก
/// * ตัวทำซ้ำที่ยุติแบบไดนามิก
///
/// หากการระบุว่ารหัสไม่สามารถเข้าถึงได้พิสูจน์ได้ว่าไม่ถูกต้องโปรแกรมจะสิ้นสุดทันทีด้วย [`panic!`]
///
/// คู่ที่ไม่ปลอดภัยของมาโครนี้คือฟังก์ชัน [`unreachable_unchecked`] ซึ่งจะทำให้เกิดพฤติกรรมที่ไม่ได้กำหนดหากถึงรหัส
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// สิ่งนี้จะ [`panic!`] เสมอ
///
/// # Examples
///
/// จับคู่แขน:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // รวบรวมข้อผิดพลาดหากแสดงความคิดเห็น
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // หนึ่งในการใช้งาน x/3 ที่แย่ที่สุด
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// ระบุรหัสที่ไม่ได้ติดตั้งโดยการตื่นตระหนกด้วยข้อความ "not implemented"
///
/// สิ่งนี้ช่วยให้โค้ดของคุณสามารถพิมพ์ตรวจสอบได้ซึ่งมีประโยชน์หากคุณกำลังสร้างต้นแบบหรือใช้ trait ที่ต้องใช้หลายวิธีซึ่งคุณไม่ได้วางแผนที่จะใช้ทั้งหมด
///
/// ความแตกต่างระหว่าง `unimplemented!` และ [`todo!`] ก็คือในขณะที่ `todo!` บ่งบอกถึงเจตนาในการนำฟังก์ชันไปใช้ในภายหลังและข้อความคือ "not yet implemented" แต่ `unimplemented!` จะไม่มีการอ้างสิทธิ์ดังกล่าว
/// ข้อความของมันคือ "not implemented"
/// นอกจากนี้ IDE บางส่วนจะทำเครื่องหมายว่าเป็นสิ่งที่ต้องทำ
///
/// # Panics
///
/// สิ่งนี้จะ [`panic!`] เสมอเนื่องจาก `unimplemented!` เป็นเพียงชวเลขสำหรับ `panic!` ที่มีข้อความเฉพาะคงที่
///
/// เช่นเดียวกับ `panic!` มาโครนี้มีรูปแบบที่สองสำหรับการแสดงค่าที่กำหนดเอง
///
/// # Examples
///
/// สมมติว่าเรามี trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// เราต้องการใช้ `Foo` สำหรับ 'MyStruct' แต่ด้วยเหตุผลบางประการการใช้ฟังก์ชัน `bar()` ก็สมเหตุสมผลแล้ว
/// `baz()` และ `qux()` จะยังคงต้องกำหนดไว้ในการใช้งาน `Foo` ของเรา แต่เราสามารถใช้ `unimplemented!` ในคำจำกัดความเพื่อให้โค้ดของเราคอมไพล์ได้
///
/// เรายังคงต้องการให้โปรแกรมของเราหยุดทำงานหากถึงวิธีการที่ไม่ได้ใช้งาน
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // มันไม่สมเหตุสมผลกับ `baz` a `MyStruct` ดังนั้นเราจึงไม่มีตรรกะตรงนี้เลย
/////
///         // สิ่งนี้จะแสดง "thread 'main' panicked at 'not implemented'"
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // เรามีตรรกะบางอย่างที่นี่เราสามารถเพิ่มข้อความเพื่อยกเลิกการใช้งานได้!เพื่อแสดงการละเว้นของเรา
///         // สิ่งนี้จะแสดง: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// ระบุรหัสที่ยังไม่เสร็จ
///
/// สิ่งนี้จะมีประโยชน์หากคุณกำลังสร้างต้นแบบและกำลังต้องการตรวจสอบรหัสของคุณ
///
/// ความแตกต่างระหว่าง [`unimplemented!`] และ `todo!` ก็คือในขณะที่ `todo!` บ่งบอกถึงเจตนาในการนำฟังก์ชันไปใช้ในภายหลังและข้อความคือ "not yet implemented" แต่ `unimplemented!` จะไม่มีการอ้างสิทธิ์ดังกล่าว
/// ข้อความของมันคือ "not implemented"
/// นอกจากนี้ IDE บางส่วนจะทำเครื่องหมายว่าเป็นสิ่งที่ต้องทำ
///
/// # Panics
///
/// สิ่งนี้จะ [`panic!`] เสมอ
///
/// # Examples
///
/// นี่คือตัวอย่างของรหัสที่อยู่ระหว่างดำเนินการเรามี trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// เราต้องการใช้ `Foo` ในประเภทใดประเภทหนึ่งของเรา แต่เราต้องการทำงานกับ `bar()` ก่อนเช่นกันในการคอมไพล์โค้ดของเราเราจำเป็นต้องใช้ `baz()` ดังนั้นเราจึงสามารถใช้ `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // การนำไปใช้งานอยู่ที่นี่
///     }
///
///     fn baz(&self) {
///         // ไม่ต้องกังวลกับการใช้งาน baz() ในตอนนี้
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // เราไม่ได้ใช้ baz() ด้วยซ้ำดังนั้นจึงใช้ได้
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// คำจำกัดความของมาโครในตัว
///
/// คุณสมบัติมาโครส่วนใหญ่ (ความเสถียรการมองเห็น ฯลฯ) ถูกนำมาจากซอร์สโค้ดที่นี่ยกเว้นฟังก์ชันการขยายที่เปลี่ยนอินพุตมาโครเป็นเอาต์พุตฟังก์ชันเหล่านั้นจัดเตรียมโดยคอมไพลเลอร์
///
///
pub(crate) mod builtin {

    /// ทำให้การคอมไพล์ล้มเหลวด้วยข้อความแสดงข้อผิดพลาดที่ระบุเมื่อพบ
    ///
    /// ควรใช้มาโครนี้เมื่อ crate ใช้กลยุทธ์การคอมไพล์ตามเงื่อนไขเพื่อให้ข้อความแสดงข้อผิดพลาดที่ดีขึ้นสำหรับเงื่อนไขที่ผิดพลาด
    ///
    /// เป็นรูปแบบระดับคอมไพเลอร์ของ [`panic!`] แต่แสดงข้อผิดพลาดระหว่าง *คอมไพล์* แทนที่จะเป็น *รันไทม์*
    ///
    /// # Examples
    ///
    /// สองตัวอย่างดังกล่าวคือมาโครและสภาพแวดล้อม `#[cfg]`
    ///
    /// ปล่อยข้อผิดพลาดของคอมไพเลอร์ที่ดีกว่าหากส่งผ่านมาโครค่าที่ไม่ถูกต้อง
    /// หากไม่มี branch สุดท้ายคอมไพเลอร์จะยังคงแสดงข้อผิดพลาด แต่ข้อความของข้อผิดพลาดจะไม่กล่าวถึงค่าที่ถูกต้องทั้งสอง
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// ปล่อยข้อผิดพลาดของคอมไพเลอร์หากไม่มีคุณลักษณะใดคุณลักษณะหนึ่ง
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// สร้างพารามิเตอร์สำหรับมาโครการจัดรูปแบบสตริงอื่น ๆ
    ///
    /// มาโครนี้ทำหน้าที่โดยการจัดรูปแบบสตริงลิเทอรัลที่มี `{}` สำหรับแต่ละอาร์กิวเมนต์เพิ่มเติมที่ส่งผ่าน
    /// `format_args!` เตรียมพารามิเตอร์เพิ่มเติมเพื่อให้แน่ใจว่าเอาต์พุตสามารถตีความเป็นสตริงและกำหนดอาร์กิวเมนต์เป็นประเภทเดียว
    /// ค่าใด ๆ ที่ใช้ [`Display`] trait สามารถส่งผ่านไปยัง `format_args!` ได้เนื่องจากการนำ [`Debug`] ไปใช้กับ `{:?}` ภายในสตริงการจัดรูปแบบ
    ///
    ///
    /// มาโครนี้สร้างค่าประเภท [`fmt::Arguments`] ค่านี้สามารถส่งผ่านไปยังมาโครภายใน [`std::fmt`] เพื่อดำเนินการเปลี่ยนเส้นทางที่เป็นประโยชน์
    /// มาโครการจัดรูปแบบอื่น ๆ ทั้งหมด ([`format!`], [`write!`], [`println!`] และอื่น ๆ) จะถูกพร็อกซีผ่านมาโครนี้
    /// `format_args!`, ไม่เหมือนกับมาโครที่ได้รับมาหลีกเลี่ยงการจัดสรรฮีป
    ///
    /// คุณสามารถใช้ค่า [`fmt::Arguments`] ที่ `format_args!` ส่งกลับในบริบท `Debug` และ `Display` ดังที่แสดงด้านล่าง
    /// ตัวอย่างยังแสดงให้เห็นว่ารูปแบบ `Debug` และ `Display` เป็นสิ่งเดียวกัน: สตริงรูปแบบที่ถูกสอดแทรกใน `format_args!`
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// สำหรับข้อมูลเพิ่มเติมโปรดดูเอกสารใน [`std::fmt`]
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// เหมือนกับ `format_args` แต่เพิ่มบรรทัดใหม่ในตอนท้าย
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// ตรวจสอบตัวแปรสภาพแวดล้อมในเวลาคอมไพล์
    ///
    /// มาโครนี้จะขยายเป็นค่าของตัวแปรสภาพแวดล้อมที่ตั้งชื่อในเวลาคอมไพล์โดยให้นิพจน์ประเภท `&'static str`
    ///
    ///
    /// หากไม่ได้กำหนดตัวแปรสภาพแวดล้อมข้อผิดพลาดในการคอมไพล์จะถูกปล่อยออกมา
    /// เพื่อไม่ให้เกิดข้อผิดพลาดในการคอมไพล์ให้ใช้มาโคร [`option_env!`] แทน
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// คุณสามารถปรับแต่งข้อความแสดงข้อผิดพลาดโดยส่งสตริงเป็นพารามิเตอร์ที่สอง:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// หากไม่ได้กำหนดตัวแปรสภาพแวดล้อม `documentation` คุณจะได้รับข้อผิดพลาดต่อไปนี้:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// เลือกที่จะตรวจสอบตัวแปรสภาพแวดล้อมในเวลาคอมไพล์
    ///
    /// หากตัวแปรสภาวะแวดล้อมที่ระบุชื่อมีอยู่ในเวลาคอมไพล์สิ่งนี้จะขยายเป็นนิพจน์ของชนิด `Option<&'static str>` ซึ่งมีค่า `Some` ของค่าของตัวแปรสภาพแวดล้อม
    /// หากไม่มีตัวแปรสภาพแวดล้อมสิ่งนี้จะขยายเป็น `None`
    /// ดู [`Option<T>`][Option] สำหรับข้อมูลเพิ่มเติมเกี่ยวกับประเภทนี้
    ///
    /// ข้อผิดพลาดเวลาคอมไพล์จะไม่ถูกปล่อยออกมาเมื่อใช้มาโครนี้ไม่ว่าจะมีตัวแปรสภาพแวดล้อมอยู่หรือไม่ก็ตาม
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// เชื่อมโยงตัวระบุเป็นตัวระบุเดียว
    ///
    /// มาโครนี้ใช้ตัวระบุที่คั่นด้วยเครื่องหมายจุลภาคจำนวนเท่าใดก็ได้และรวมตัวระบุทั้งหมดเข้าด้วยกันโดยให้นิพจน์ซึ่งเป็นตัวระบุใหม่
    /// โปรดทราบว่าสุขอนามัยทำให้มาโครนี้ไม่สามารถจับตัวแปรภายในได้
    /// นอกจากนี้ตามกฎทั่วไปอนุญาตให้ใช้มาโครในตำแหน่งรายการคำสั่งหรือนิพจน์เท่านั้น
    /// นั่นหมายความว่าในขณะที่คุณอาจใช้มาโครนี้เพื่ออ้างถึงตัวแปรฟังก์ชันหรือโมดูลที่มีอยู่เป็นต้น แต่คุณไม่สามารถกำหนดตัวแปรใหม่ได้
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (ใหม่ชื่อสนุก) { }//ใช้วิธีนี้ไม่ได้!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// เชื่อมต่อตัวอักษรเข้ากับชิ้นส่วนสตริงแบบคงที่
    ///
    /// มาโครนี้ใช้ตัวอักษรที่คั่นด้วยเครื่องหมายจุลภาคจำนวนเท่าใดก็ได้โดยให้นิพจน์ประเภท `&'static str` ซึ่งแสดงถึงตัวอักษรทั้งหมดที่เรียงต่อกันจากซ้ายไปขวา
    ///
    ///
    /// ลิเทอร์ลจำนวนเต็มและจุดลอยตัวถูกกำหนดให้มีการเชื่อมต่อกัน
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ขยายเป็นหมายเลขบรรทัดที่เรียกใช้
    ///
    /// ด้วย [`column!`] และ [`file!`] มาโครเหล่านี้จะให้ข้อมูลการดีบักสำหรับนักพัฒนาเกี่ยวกับตำแหน่งภายในแหล่งที่มา
    ///
    /// นิพจน์ที่ขยายมีประเภท `u32` และเป็นแบบ 1 ดังนั้นบรรทัดแรกในแต่ละไฟล์จึงประเมินเป็น 1 บรรทัดที่สองถึง 2 เป็นต้น
    /// สิ่งนี้สอดคล้องกับข้อความแสดงข้อผิดพลาดโดยคอมไพเลอร์ทั่วไปหรือตัวแก้ไขยอดนิยม
    /// บรรทัดที่ส่งคืนคือ *ไม่จำเป็นต้องเป็น* บรรทัดของการเรียกใช้ `line!` แต่เป็นการเรียกมาโครแรกที่นำไปสู่การเรียกใช้มาโคร `line!`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// ขยายเป็นหมายเลขคอลัมน์ที่เรียกใช้
    ///
    /// ด้วย [`line!`] และ [`file!`] มาโครเหล่านี้จะให้ข้อมูลการดีบักสำหรับนักพัฒนาเกี่ยวกับตำแหน่งภายในแหล่งที่มา
    ///
    /// นิพจน์ที่ขยายมีประเภท `u32` และเป็นแบบ 1 ดังนั้นคอลัมน์แรกในแต่ละบรรทัดจึงประเมินเป็น 1 คอลัมน์ที่สองถึง 2 เป็นต้น
    /// สิ่งนี้สอดคล้องกับข้อความแสดงข้อผิดพลาดโดยคอมไพเลอร์ทั่วไปหรือตัวแก้ไขยอดนิยม
    /// คอลัมน์ที่ส่งคืนคือ *ไม่จำเป็นต้องเป็น* บรรทัดของการเรียกใช้ `column!` แต่เป็นการเรียกมาโครแรกที่นำไปสู่การเรียกใช้มาโคร `column!`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// ขยายเป็นชื่อไฟล์ที่เรียกใช้
    ///
    /// ด้วย [`line!`] และ [`column!`] มาโครเหล่านี้จะให้ข้อมูลการดีบักสำหรับนักพัฒนาเกี่ยวกับตำแหน่งภายในแหล่งที่มา
    ///
    /// นิพจน์ที่ขยายมีประเภท `&'static str` และไฟล์ที่ส่งคืนไม่ใช่การเรียกใช้มาโคร `file!` แต่เป็นการเรียกใช้แมโครแรกที่นำไปสู่การเรียกใช้แมโคร `file!`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// สตริงอาร์กิวเมนต์
    ///
    /// มาโครนี้จะแสดงนิพจน์ประเภท `&'static str` ซึ่งเป็นสตริงของ tokens ทั้งหมดที่ส่งผ่านไปยังมาโคร
    /// ไม่มีการวางข้อ จำกัด ในไวยากรณ์ของการเรียกมาโครเอง
    ///
    /// โปรดทราบว่าผลลัพธ์ที่ขยายของอินพุต tokens อาจเปลี่ยนแปลงใน future คุณควรระมัดระวังหากคุณพึ่งพาผลลัพธ์
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// รวมไฟล์ที่เข้ารหัส UTF-8 เป็นสตริง
    ///
    /// ไฟล์อยู่ในตำแหน่งที่สัมพันธ์กับไฟล์ปัจจุบัน (คล้ายกับวิธีที่พบโมดูล)
    /// พา ธ ที่ระบุจะถูกตีความด้วยวิธีเฉพาะแพลตฟอร์มในเวลาคอมไพล์
    /// ตัวอย่างเช่นการเรียกใช้เส้นทาง Windows ที่มีแบ็กสแลช `\` จะคอมไพล์บน Unix ไม่ถูกต้อง
    ///
    ///
    /// มาโครนี้จะแสดงนิพจน์ประเภท `&'static str` ซึ่งเป็นเนื้อหาของไฟล์
    ///
    /// # Examples
    ///
    /// สมมติว่ามีสองไฟล์ในไดเร็กทอรีเดียวกันโดยมีเนื้อหาต่อไปนี้:
    ///
    /// ไฟล์ 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// ไฟล์ 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// การคอมไพล์ 'main.rs' และรันไบนารีผลลัพธ์จะพิมพ์ "adiós"
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// รวมไฟล์ที่อ้างอิงไปยังอาร์เรย์ไบต์
    ///
    /// ไฟล์อยู่ในตำแหน่งที่สัมพันธ์กับไฟล์ปัจจุบัน (คล้ายกับวิธีที่พบโมดูล)
    /// พา ธ ที่ระบุจะถูกตีความด้วยวิธีเฉพาะแพลตฟอร์มในเวลาคอมไพล์
    /// ตัวอย่างเช่นการเรียกใช้เส้นทาง Windows ที่มีแบ็กสแลช `\` จะคอมไพล์บน Unix ไม่ถูกต้อง
    ///
    ///
    /// มาโครนี้จะแสดงนิพจน์ประเภท `&'static [u8; N]` ซึ่งเป็นเนื้อหาของไฟล์
    ///
    /// # Examples
    ///
    /// สมมติว่ามีสองไฟล์ในไดเร็กทอรีเดียวกันโดยมีเนื้อหาต่อไปนี้:
    ///
    /// ไฟล์ 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// ไฟล์ 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// การคอมไพล์ 'main.rs' และรันไบนารีผลลัพธ์จะพิมพ์ "adiós"
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ขยายเป็นสตริงที่แสดงถึงเส้นทางโมดูลปัจจุบัน
    ///
    /// พา ธ โมดูลปัจจุบันสามารถคิดได้ว่าเป็นลำดับชั้นของโมดูลที่นำกลับไปที่ crate root
    /// ส่วนประกอบแรกของเส้นทางที่ส่งคืนคือชื่อของ crate ที่กำลังคอมไพล์อยู่
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// ประเมินการรวมบูลีนของแฟล็กคอนฟิกูเรชันในเวลาคอมไพล์
    ///
    /// นอกเหนือจากแอ็ตทริบิวต์ `#[cfg]` แล้วมาโครนี้ยังมีไว้เพื่ออนุญาตให้มีการประเมินนิพจน์บูลีนของแฟล็กคอนฟิกูเรชัน
    /// ซึ่งมักจะนำไปสู่รหัสที่ซ้ำกันน้อยลง
    ///
    /// ไวยากรณ์ที่กำหนดให้กับมาโครนี้เป็นไวยากรณ์เดียวกับแอตทริบิวต์ [`cfg`]
    ///
    /// `cfg!`, ซึ่งแตกต่างจาก `#[cfg]` คือไม่ลบโค้ดใด ๆ และประเมินเฉพาะว่าเป็นจริงหรือเท็จเท่านั้น
    /// ตัวอย่างเช่นบล็อกทั้งหมดในนิพจน์ if/else ต้องถูกต้องเมื่อใช้ `cfg!` สำหรับเงื่อนไขไม่ว่า `cfg!` จะประเมินค่าใดก็ตาม
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// แยกวิเคราะห์ไฟล์เป็นนิพจน์หรือรายการตามบริบท
    ///
    /// ไฟล์อยู่ในตำแหน่งที่สัมพันธ์กับไฟล์ปัจจุบัน (คล้ายกับวิธีที่พบโมดูล)พา ธ ที่ระบุจะถูกตีความด้วยวิธีเฉพาะแพลตฟอร์มในเวลาคอมไพล์
    /// ตัวอย่างเช่นการเรียกใช้เส้นทาง Windows ที่มีแบ็กสแลช `\` จะคอมไพล์บน Unix ไม่ถูกต้อง
    ///
    /// การใช้มาโครนี้มักเป็นความคิดที่ไม่ดีเพราะหากไฟล์ถูกแยกวิเคราะห์เป็นนิพจน์ไฟล์นั้นจะถูกวางไว้ในโค้ดโดยรอบอย่างไม่ถูกสุขลักษณะ
    /// ซึ่งอาจส่งผลให้ตัวแปรหรือฟังก์ชันแตกต่างจากที่ไฟล์คาดไว้หากมีตัวแปรหรือฟังก์ชันที่มีชื่อเดียวกันในไฟล์ปัจจุบัน
    ///
    ///
    /// # Examples
    ///
    /// สมมติว่ามีสองไฟล์ในไดเร็กทอรีเดียวกันโดยมีเนื้อหาต่อไปนี้:
    ///
    /// ไฟล์ 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// ไฟล์ 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// การคอมไพล์ 'main.rs' และรันไบนารีผลลัพธ์จะพิมพ์ "🙈🙊🙉🙈🙊🙉"
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ยืนยันว่านิพจน์บูลีนคือ `true` ที่รันไทม์
    ///
    /// สิ่งนี้จะเรียกใช้แมโคร [`panic!`] หากไม่สามารถประเมินนิพจน์ที่ระบุเป็น `true` ในขณะรันไทม์
    ///
    /// # Uses
    ///
    /// การยืนยันจะถูกตรวจสอบเสมอทั้งในรุ่นดีบักและรุ่นรีลีสและไม่สามารถปิดใช้งานได้
    /// โปรดดู [`debug_assert!`] สำหรับการยืนยันที่ไม่ได้เปิดใช้งานในรุ่นสร้างตามค่าเริ่มต้น
    ///
    /// รหัสที่ไม่ปลอดภัยอาจใช้ `assert!` ในการบังคับใช้ค่าคงที่ของรันไทม์ซึ่งหากละเมิดอาจนำไปสู่ความไม่ปลอดภัย
    ///
    /// กรณีการใช้งานอื่น ๆ ของ `assert!` รวมถึงการทดสอบและการบังคับใช้ค่าความไม่แน่นอนรันไทม์ในรหัสปลอดภัย (ซึ่งการละเมิดจะไม่ส่งผลให้เกิดความไม่ปลอดภัย)
    ///
    ///
    /// # ข้อความที่กำหนดเอง
    ///
    /// มาโครนี้มีรูปแบบที่สองซึ่งสามารถจัดเตรียมข้อความ panic แบบกำหนดเองโดยมีหรือไม่มีอาร์กิวเมนต์สำหรับการจัดรูปแบบ
    /// ดู [`std::fmt`] สำหรับไวยากรณ์สำหรับแบบฟอร์มนี้
    /// นิพจน์ที่ใช้เป็นอาร์กิวเมนต์รูปแบบจะได้รับการประเมินก็ต่อเมื่อการยืนยันล้มเหลว
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // ข้อความ panic สำหรับการยืนยันเหล่านี้คือค่าสตริงของนิพจน์ที่กำหนด
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // ฟังก์ชั่นที่เรียบง่ายมาก
    ///
    /// assert!(some_computation());
    ///
    /// // ยืนยันด้วยข้อความที่กำหนดเอง
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// การประกอบแบบอินไลน์
    ///
    /// อ่าน [unstable book] สำหรับการใช้งาน
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// การประกอบแบบอินไลน์แบบ LLVM
    ///
    /// อ่าน [unstable book] สำหรับการใช้งาน
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// การประกอบแบบอินไลน์ระดับโมดูล
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// งานพิมพ์ผ่าน tokens ไปยังเอาต์พุตมาตรฐาน
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// เปิดใช้งานหรือปิดใช้งานฟังก์ชันการติดตามที่ใช้สำหรับการดีบักแมโครอื่น ๆ
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// มาโครแอตทริบิวต์ที่ใช้เพื่อใช้แมโครที่ได้รับมา
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// ใช้มาโครแอตทริบิวต์กับฟังก์ชันเพื่อเปลี่ยนเป็นการทดสอบหน่วย
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// ใช้มาโครแอตทริบิวต์กับฟังก์ชันเพื่อเปลี่ยนเป็นการทดสอบเกณฑ์มาตรฐาน
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// รายละเอียดการใช้งานมาโคร `#[test]` และ `#[bench]`
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// แมโครแอตทริบิวต์นำไปใช้กับสแตติกเพื่อลงทะเบียนเป็นตัวจัดสรรส่วนกลาง
    ///
    /// ดู [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html) ด้วย
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// เก็บรายการที่ใช้หากสามารถเข้าถึงเส้นทางที่ผ่านและลบออก
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// ขยายแอตทริบิวต์ `#[cfg]` และ `#[cfg_attr]` ทั้งหมดในส่วนของโค้ดที่ใช้กับ
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// รายละเอียดการใช้งานที่ไม่เสถียรของคอมไพเลอร์ `rustc` ห้ามใช้
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// รายละเอียดการใช้งานที่ไม่เสถียรของคอมไพเลอร์ `rustc` ห้ามใช้
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}