Panics เธรดปัจจุบัน

ซึ่งจะช่วยให้โปรแกรมสามารถยุติการทำงานได้ทันทีและให้ข้อเสนอแนะแก่ผู้เรียกโปรแกรม
`panic!` ควรใช้เมื่อโปรแกรมถึงสถานะที่ไม่สามารถกู้คืนได้

มาโครนี้เป็นวิธีที่สมบูรณ์แบบในการยืนยันเงื่อนไขในโค้ดตัวอย่างและในการทดสอบ
`panic!` เชื่อมโยงอย่างใกล้ชิดกับวิธี `unwrap` ของทั้ง [`Option`][ounwrap] และ [`Result`][runwrap] enums
การใช้งานทั้งสองเรียกใช้ `panic!` เมื่อตั้งค่าเป็นตัวแปร [`None`] หรือ [`Err`]

เมื่อใช้ `panic!()` คุณสามารถระบุเพย์โหลดสตริงซึ่งสร้างขึ้นโดยใช้ไวยากรณ์ [`format!`]
น้ำหนักบรรทุกนั้นถูกใช้เมื่อฉีด panic ลงในการเรียกใช้เธรด Rust ทำให้เธรดเป็น panic ทั้งหมด

ลักษณะการทำงานของ `std` hook เริ่มต้นคือ
รหัสที่ทำงานโดยตรงหลังจากเรียกใช้ panic คือการพิมพ์เพย์โหลดข้อความไปยัง `stderr` พร้อมกับข้อมูล file/line/column ของการเรียก `panic!()`

คุณสามารถแทนที่ panic hook โดยใช้ [`std::panic::set_hook()`]
ภายใน hook panic สามารถเข้าถึงได้ในรูปแบบ `&dyn Any + Send` ซึ่งมี `&str` หรือ `String` สำหรับการเรียกใช้ `panic!()` ปกติ
สำหรับ panic ด้วยค่าประเภทอื่นสามารถใช้ [`panic_any`] ได้

[`Result`] enum มักเป็นทางออกที่ดีกว่าสำหรับการกู้คืนจากข้อผิดพลาดมากกว่าการใช้มาโคร `panic!`
ควรใช้มาโครนี้เพื่อหลีกเลี่ยงการดำเนินการต่อโดยใช้ค่าที่ไม่ถูกต้องเช่นจากแหล่งภายนอก
ข้อมูลโดยละเอียดเกี่ยวกับการจัดการข้อผิดพลาดมีอยู่ใน [book]

โปรดดูมาโคร [`compile_error!`] สำหรับการเพิ่มข้อผิดพลาดระหว่างการคอมไพล์

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# การใช้งานปัจจุบัน

หากเธรดหลัก panics มันจะยุติเธรดทั้งหมดของคุณและสิ้นสุดโปรแกรมของคุณด้วยรหัส `101`

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





