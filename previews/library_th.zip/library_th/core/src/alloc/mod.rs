//! API การจัดสรรหน่วยความจำ

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// ข้อผิดพลาด `AllocError` บ่งชี้ถึงความล้มเหลวในการจัดสรรซึ่งอาจเกิดจากทรัพยากรหมดหรือเกิดข้อผิดพลาดเมื่อรวมอาร์กิวเมนต์อินพุตที่กำหนดกับตัวจัดสรรนี้
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (เราต้องการสิ่งนี้สำหรับ downstream im ของ trait Error)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// การใช้งาน `Allocator` สามารถจัดสรรขยายย่อขนาดและยกเลิกการจัดสรรบล็อกข้อมูลโดยพลการที่อธิบายผ่าน [`Layout`][]
///
/// `Allocator` ได้รับการออกแบบมาเพื่อใช้กับ ZST การอ้างอิงหรือตัวชี้อัจฉริยะเนื่องจากการมีตัวจัดสรรเช่น `MyAlloc([u8; N])` ไม่สามารถย้ายได้โดยไม่ต้องอัปเดตตัวชี้ไปยังหน่วยความจำที่จัดสรร
///
/// ไม่เหมือนกับ [`GlobalAlloc`][] การจัดสรรขนาดศูนย์จะได้รับอนุญาตใน `Allocator`
/// หากตัวจัดสรรพื้นฐานไม่สนับสนุนสิ่งนี้ (เช่น jemalloc) หรือส่งคืนตัวชี้ค่าว่าง (เช่น `libc::malloc`) สิ่งนี้จะต้องถูกจับโดยการนำไปใช้
///
/// ### จัดสรรหน่วยความจำในปัจจุบัน
///
/// วิธีการบางอย่างกำหนดให้บล็อกหน่วยความจำต้อง *จัดสรรในปัจจุบัน* ผ่านตัวจัดสรรซึ่งหมายความว่า:
///
/// * ที่อยู่เริ่มต้นสำหรับบล็อกหน่วยความจำนั้นถูกส่งคืนก่อนหน้านี้โดย [`allocate`], [`grow`] หรือ [`shrink`] และ
///
/// * บล็อกหน่วยความจำไม่ได้ถูกยกเลิกการจัดสรรในภายหลังโดยที่บล็อกจะถูกยกเลิกการจัดสรรโดยตรงโดยส่งผ่านไปยัง [`deallocate`] หรือถูกเปลี่ยนแปลงโดยส่งผ่านไปยัง [`grow`] หรือ [`shrink`] ที่ส่งคืน `Ok`
///
/// หาก `grow` หรือ `shrink` ส่งคืน `Err` ตัวชี้ที่ผ่านจะยังคงใช้ได้
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### การติดตั้งหน่วยความจำ
///
/// วิธีการบางอย่างต้องการให้เค้าโครง *พอดี* บล็อกหน่วยความจำ
/// ความหมายสำหรับเลย์เอาต์ถึง "fit" บล็อกหน่วยความจำหมายถึง (หรือเทียบเท่าสำหรับบล็อกหน่วยความจำถึง "fit" เลย์เอาต์) คือต้องมีเงื่อนไขต่อไปนี้:
///
/// * บล็อกต้องได้รับการจัดสรรด้วยการจัดแนวเดียวกันกับ [`layout.align()`] และ
///
/// * [`layout.size()`] ที่ให้มาต้องอยู่ในช่วง `min ..= max` โดยที่:
///   - `min` คือขนาดของเค้าโครงที่ใช้ล่าสุดในการจัดสรรบล็อกและ
///   - `max` คือขนาดจริงล่าสุดที่ส่งคืนจาก [`allocate`], [`grow`] หรือ [`shrink`]
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * บล็อกหน่วยความจำที่ส่งคืนจากตัวจัดสรรต้องชี้ไปที่หน่วยความจำที่ถูกต้องและคงความถูกต้องไว้จนกว่าอินสแตนซ์และโคลนทั้งหมดจะหลุดออกไป
///
/// * การโคลนหรือย้ายตัวจัดสรรจะต้องไม่ทำให้บล็อกหน่วยความจำที่ส่งคืนจากตัวจัดสรรนี้เป็นโมฆะผู้จัดสรรที่โคลนต้องทำงานเหมือนผู้จัดสรรคนเดียวกันและ
///
/// * ตัวชี้ใด ๆ ไปยังบล็อกหน่วยความจำซึ่งเป็น [*currently allocated*] อาจถูกส่งผ่านไปยังวิธีการอื่น ๆ ของตัวจัดสรร
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// พยายามจัดสรรบล็อกหน่วยความจำ
    ///
    /// เมื่อประสบความสำเร็จส่งคืน [`NonNull<[u8]>`][NonNull] ที่ตรงตามขนาดและการรับประกันการจัดตำแหน่งของ `layout`
    ///
    /// บล็อกที่ส่งคืนอาจมีขนาดใหญ่กว่าที่ `layout.size()` ระบุและอาจมีหรือไม่มีเนื้อหาเริ่มต้น
    ///
    /// # Errors
    ///
    /// การส่งคืน `Err` บ่งชี้ว่าหน่วยความจำหมดหรือ `layout` ไม่ตรงตามขนาดของผู้จัดสรรหรือข้อ จำกัด ในการจัดแนว
    ///
    /// การใช้งานได้รับการสนับสนุนให้คืนค่า `Err` เมื่อหน่วยความจำอ่อนเพลียแทนที่จะตื่นตระหนกหรือยกเลิก แต่นี่ไม่ใช่ข้อกำหนดที่เข้มงวด
    /// (โดยเฉพาะ: เป็น *ถูกกฎหมาย* ในการใช้ trait นี้บนไลบรารีการจัดสรรเนทีฟพื้นฐานที่ยกเลิกเมื่อหน่วยความจำหมด)
    ///
    /// ลูกค้าที่ต้องการยกเลิกการคำนวณเพื่อตอบสนองต่อข้อผิดพลาดในการจัดสรรควรเรียกใช้ฟังก์ชัน [`handle_alloc_error`] แทนที่จะเรียกใช้ `panic!` หรือสิ่งที่คล้ายกันโดยตรง
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// ทำงานเหมือน `allocate` แต่ยังช่วยให้มั่นใจได้ว่าหน่วยความจำที่ส่งคืนจะถูกกำหนดค่าเริ่มต้นเป็นศูนย์
    ///
    /// # Errors
    ///
    /// การส่งคืน `Err` บ่งชี้ว่าหน่วยความจำหมดหรือ `layout` ไม่ตรงตามขนาดของผู้จัดสรรหรือข้อ จำกัด ในการจัดแนว
    ///
    /// การใช้งานได้รับการสนับสนุนให้คืนค่า `Err` เมื่อหน่วยความจำอ่อนเพลียแทนที่จะตื่นตระหนกหรือยกเลิก แต่นี่ไม่ใช่ข้อกำหนดที่เข้มงวด
    /// (โดยเฉพาะ: เป็น *ถูกกฎหมาย* ในการใช้ trait นี้บนไลบรารีการจัดสรรเนทีฟพื้นฐานที่ยกเลิกเมื่อหน่วยความจำหมด)
    ///
    /// ลูกค้าที่ต้องการยกเลิกการคำนวณเพื่อตอบสนองต่อข้อผิดพลาดในการจัดสรรควรเรียกใช้ฟังก์ชัน [`handle_alloc_error`] แทนที่จะเรียกใช้ `panic!` หรือสิ่งที่คล้ายกันโดยตรง
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // ความปลอดภัย: `alloc` ส่งคืนบล็อกหน่วยความจำที่ถูกต้อง
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// จัดสรรหน่วยความจำที่อ้างถึงโดย `ptr`
    ///
    /// # Safety
    ///
    /// * `ptr` ต้องแสดงถึงบล็อกของหน่วยความจำ [*currently allocated*] ผ่านตัวจัดสรรนี้และ
    /// * `layout` ต้อง [*fit*] บล็อกหน่วยความจำนั้น
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// พยายามขยายบล็อกหน่วยความจำ
    ///
    /// ส่งคืน [`NonNull<[u8]>`][NonNull] ใหม่ที่มีตัวชี้และขนาดจริงของหน่วยความจำที่จัดสรรตัวชี้เหมาะสำหรับเก็บข้อมูลที่อธิบายโดย `new_layout`
    /// ในการดำเนินการนี้ผู้จัดสรรอาจขยายการจัดสรรที่อ้างถึงโดย `ptr` เพื่อให้พอดีกับโครงร่างใหม่
    ///
    /// หากสิ่งนี้ส่งคืน `Ok` แสดงว่าความเป็นเจ้าของบล็อกหน่วยความจำที่อ้างถึงโดย `ptr` จะถูกโอนไปยังตัวจัดสรรนี้
    /// หน่วยความจำอาจเป็นอิสระหรือไม่ก็ได้และควรถูกพิจารณาว่าไม่สามารถใช้งานได้เว้นแต่จะถูกโอนกลับไปยังผู้เรียกอีกครั้งโดยใช้ค่าส่งคืนของวิธีนี้
    ///
    /// หากวิธีนี้คืนค่า `Err` แสดงว่าความเป็นเจ้าของบล็อกหน่วยความจำไม่ได้ถูกโอนไปยังตัวจัดสรรนี้และเนื้อหาของบล็อกหน่วยความจำจะไม่มีการเปลี่ยนแปลง
    ///
    /// # Safety
    ///
    /// * `ptr` ต้องแสดงถึงบล็อกของหน่วยความจำ [*currently allocated*] ผ่านตัวจัดสรรนี้
    /// * `old_layout` ต้อง [*fit*] บล็อกหน่วยความจำนั้น (อาร์กิวเมนต์ `new_layout` ไม่จำเป็นต้องพอดี)
    /// * `new_layout.size()` ต้องมากกว่าหรือเท่ากับ `old_layout.size()`
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// ส่งคืน `Err` หากเค้าโครงใหม่ไม่ตรงตามขนาดของผู้จัดสรรและข้อ จำกัด การจัดแนวของตัวจัดสรรหรือหากการเติบโตเป็นอย่างอื่นล้มเหลว
    ///
    /// การใช้งานได้รับการสนับสนุนให้คืนค่า `Err` เมื่อหน่วยความจำอ่อนเพลียแทนที่จะตื่นตระหนกหรือยกเลิก แต่นี่ไม่ใช่ข้อกำหนดที่เข้มงวด
    /// (โดยเฉพาะ: เป็น *ถูกกฎหมาย* ในการใช้ trait นี้บนไลบรารีการจัดสรรเนทีฟพื้นฐานที่ยกเลิกเมื่อหน่วยความจำหมด)
    ///
    /// ลูกค้าที่ต้องการยกเลิกการคำนวณเพื่อตอบสนองต่อข้อผิดพลาดในการจัดสรรควรเรียกใช้ฟังก์ชัน [`handle_alloc_error`] แทนที่จะเรียกใช้ `panic!` หรือสิ่งที่คล้ายกันโดยตรง
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // ความปลอดภัย: เนื่องจาก `new_layout.size()` ต้องมากกว่าหรือเท่ากับ
        // `old_layout.size()`, การจัดสรรหน่วยความจำทั้งเก่าและใหม่ใช้ได้สำหรับการอ่านและเขียนสำหรับ `old_layout.size()` ไบต์
        // นอกจากนี้เนื่องจากการจัดสรรเก่ายังไม่ได้รับการจัดสรรจึงไม่สามารถซ้อนทับ `new_ptr` ได้
        // ดังนั้นการโทรหา `copy_nonoverlapping` จึงปลอดภัย
        // ผู้เรียกต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `dealloc`
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// ทำงานเหมือน `grow` แต่ยังช่วยให้มั่นใจได้ว่าเนื้อหาใหม่ถูกตั้งค่าเป็นศูนย์ก่อนที่จะส่งคืน
    ///
    /// บล็อกหน่วยความจำจะมีเนื้อหาต่อไปนี้หลังจากโทรไปที่สำเร็จ
    /// `grow_zeroed`:
    ///   * ไบต์ `0..old_layout.size()` ถูกรักษาไว้จากการจัดสรรดั้งเดิม
    ///   * ไบต์ `old_layout.size()..old_size` จะถูกเก็บรักษาไว้หรือเป็นศูนย์ขึ้นอยู่กับการใช้งานตัวจัดสรร
    ///   `old_size` หมายถึงขนาดของบล็อกหน่วยความจำก่อนการเรียก `grow_zeroed` ซึ่งอาจใหญ่กว่าขนาดที่ร้องขอในตอนแรกเมื่อได้รับการจัดสรร
    ///   * ไบต์ `old_size..new_size` เป็นศูนย์ `new_size` หมายถึงขนาดของบล็อกหน่วยความจำที่ส่งคืนโดยการเรียก `grow_zeroed`
    ///
    /// # Safety
    ///
    /// * `ptr` ต้องแสดงถึงบล็อกของหน่วยความจำ [*currently allocated*] ผ่านตัวจัดสรรนี้
    /// * `old_layout` ต้อง [*fit*] บล็อกหน่วยความจำนั้น (อาร์กิวเมนต์ `new_layout` ไม่จำเป็นต้องพอดี)
    /// * `new_layout.size()` ต้องมากกว่าหรือเท่ากับ `old_layout.size()`
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// ส่งคืน `Err` หากเค้าโครงใหม่ไม่ตรงตามขนาดของผู้จัดสรรและข้อ จำกัด การจัดแนวของตัวจัดสรรหรือหากการเติบโตเป็นอย่างอื่นล้มเหลว
    ///
    /// การใช้งานได้รับการสนับสนุนให้คืนค่า `Err` เมื่อหน่วยความจำอ่อนเพลียแทนที่จะตื่นตระหนกหรือยกเลิก แต่นี่ไม่ใช่ข้อกำหนดที่เข้มงวด
    /// (โดยเฉพาะ: เป็น *ถูกกฎหมาย* ในการใช้ trait นี้บนไลบรารีการจัดสรรเนทีฟพื้นฐานที่ยกเลิกเมื่อหน่วยความจำหมด)
    ///
    /// ลูกค้าที่ต้องการยกเลิกการคำนวณเพื่อตอบสนองต่อข้อผิดพลาดในการจัดสรรควรเรียกใช้ฟังก์ชัน [`handle_alloc_error`] แทนที่จะเรียกใช้ `panic!` หรือสิ่งที่คล้ายกันโดยตรง
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // ความปลอดภัย: เนื่องจาก `new_layout.size()` ต้องมากกว่าหรือเท่ากับ
        // `old_layout.size()`, การจัดสรรหน่วยความจำทั้งเก่าและใหม่ใช้ได้สำหรับการอ่านและเขียนสำหรับ `old_layout.size()` ไบต์
        // นอกจากนี้เนื่องจากการจัดสรรเก่ายังไม่ได้รับการจัดสรรจึงไม่สามารถซ้อนทับ `new_ptr` ได้
        // ดังนั้นการโทรหา `copy_nonoverlapping` จึงปลอดภัย
        // ผู้เรียกต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `dealloc`
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// พยายามลดขนาดบล็อกหน่วยความจำ
    ///
    /// ส่งคืน [`NonNull<[u8]>`][NonNull] ใหม่ที่มีตัวชี้และขนาดจริงของหน่วยความจำที่จัดสรรตัวชี้เหมาะสำหรับเก็บข้อมูลที่อธิบายโดย `new_layout`
    /// ในการดำเนินการนี้ผู้จัดสรรอาจลดขนาดการจัดสรรที่อ้างถึงโดย `ptr` เพื่อให้พอดีกับโครงร่างใหม่
    ///
    /// หากสิ่งนี้ส่งคืน `Ok` แสดงว่าความเป็นเจ้าของบล็อกหน่วยความจำที่อ้างถึงโดย `ptr` จะถูกโอนไปยังตัวจัดสรรนี้
    /// หน่วยความจำอาจเป็นอิสระหรือไม่ก็ได้และควรถูกพิจารณาว่าไม่สามารถใช้งานได้เว้นแต่จะถูกโอนกลับไปยังผู้เรียกอีกครั้งโดยใช้ค่าส่งคืนของวิธีนี้
    ///
    /// หากวิธีนี้คืนค่า `Err` แสดงว่าความเป็นเจ้าของบล็อกหน่วยความจำไม่ได้ถูกโอนไปยังตัวจัดสรรนี้และเนื้อหาของบล็อกหน่วยความจำจะไม่มีการเปลี่ยนแปลง
    ///
    /// # Safety
    ///
    /// * `ptr` ต้องแสดงถึงบล็อกของหน่วยความจำ [*currently allocated*] ผ่านตัวจัดสรรนี้
    /// * `old_layout` ต้อง [*fit*] บล็อกหน่วยความจำนั้น (อาร์กิวเมนต์ `new_layout` ไม่จำเป็นต้องพอดี)
    /// * `new_layout.size()` ต้องมีขนาดเล็กกว่าหรือเท่ากับ `old_layout.size()`
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// ส่งคืน `Err` หากเค้าโครงใหม่ไม่ตรงตามขนาดของผู้จัดสรรและข้อ จำกัด การจัดแนวของตัวจัดสรรหรือหากการย่อขนาดล้มเหลว
    ///
    /// การใช้งานได้รับการสนับสนุนให้คืนค่า `Err` เมื่อหน่วยความจำอ่อนเพลียแทนที่จะตื่นตระหนกหรือยกเลิก แต่นี่ไม่ใช่ข้อกำหนดที่เข้มงวด
    /// (โดยเฉพาะ: เป็น *ถูกกฎหมาย* ในการใช้ trait นี้บนไลบรารีการจัดสรรเนทีฟพื้นฐานที่ยกเลิกเมื่อหน่วยความจำหมด)
    ///
    /// ลูกค้าที่ต้องการยกเลิกการคำนวณเพื่อตอบสนองต่อข้อผิดพลาดในการจัดสรรควรเรียกใช้ฟังก์ชัน [`handle_alloc_error`] แทนที่จะเรียกใช้ `panic!` หรือสิ่งที่คล้ายกันโดยตรง
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // ความปลอดภัย: เนื่องจาก `new_layout.size()` ต้องต่ำกว่าหรือเท่ากับ
        // `old_layout.size()`, การจัดสรรหน่วยความจำทั้งเก่าและใหม่ใช้ได้สำหรับการอ่านและเขียนสำหรับ `new_layout.size()` ไบต์
        // นอกจากนี้เนื่องจากการจัดสรรเก่ายังไม่ได้รับการจัดสรรจึงไม่สามารถซ้อนทับ `new_ptr` ได้
        // ดังนั้นการโทรหา `copy_nonoverlapping` จึงปลอดภัย
        // ผู้เรียกต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `dealloc`
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// สร้างอะแด็ปเตอร์ "by reference" สำหรับอินสแตนซ์ของ `Allocator`
    ///
    /// อะแดปเตอร์ที่ส่งคืนยังใช้ `Allocator` และจะยืมสิ่งนี้
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // ความปลอดภัย: ผู้โทรต้องยึดถือสัญญาความปลอดภัย
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ความปลอดภัย: ผู้โทรต้องยึดถือสัญญาความปลอดภัย
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ความปลอดภัย: ผู้โทรต้องยึดถือสัญญาความปลอดภัย
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ความปลอดภัย: ผู้โทรต้องยึดถือสัญญาความปลอดภัย
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}