#![stable(feature = "futures_api", since = "1.36.0")]

//! ค่าอะซิงโครนัส

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// จำเป็นต้องใช้ประเภทนี้เนื่องจาก:
///
/// a) เครื่องกำเนิดไฟฟ้าไม่สามารถใช้ `for<'a, 'b> Generator<&'a mut Context<'b>>` ได้ดังนั้นเราจำเป็นต้องส่งตัวชี้ดิบ (ดู <https://github.com/rust-lang/rust/issues/68923>)
///
/// b) พอยน์เตอร์ดิบและ `NonNull` ไม่ใช่ `Send` หรือ `Sync` ดังนั้นจะทำให้ future non-Send/Sync ทุกตัวเช่นกันและเราไม่ต้องการสิ่งนั้น
///
/// นอกจากนี้ยังช่วยลดความยุ่งยากในการลด HIR ของ `.await`
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// ห่อเครื่องกำเนิดไฟฟ้าใน future
///
/// ฟังก์ชันนี้ส่งคืน `GenFuture` ด้านล่าง แต่ซ่อนไว้ใน `impl Trait` เพื่อให้ข้อความแสดงข้อผิดพลาดที่ดีขึ้น (`impl Future` แทนที่จะเป็น `GenFuture<[closure.....]>`)
///
// นี่คือ `const` เพื่อหลีกเลี่ยงข้อผิดพลาดเพิ่มเติมหลังจากที่เรากู้คืนจาก `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // เราอาศัยข้อเท็จจริงที่ว่า async/await futures นั้นไม่สามารถเคลื่อนย้ายได้เพื่อสร้างการยืมแบบอ้างอิงตัวเองในเครื่องกำเนิดไฟฟ้าที่อยู่เบื้องหลัง
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // ความปลอดภัย: ปลอดภัยเพราะเราคือ !Unpin + !Drop และนี่เป็นเพียงการฉายภาพภาคสนาม
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // เปิดเครื่องกำเนิดไฟฟ้าต่อโดยเปลี่ยน `&mut Context` ให้เป็นตัวชี้ดิบ `NonNull`
            // การลดระดับ `.await` จะทำให้กลับไปเป็น `&mut Context` ได้อย่างปลอดภัย
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // ความปลอดภัย: ผู้โทรต้องรับประกันว่า `cx.0` เป็นตัวชี้ที่ถูกต้อง
    // ที่ตอบสนองความต้องการทั้งหมดสำหรับการอ้างอิงที่ไม่แน่นอน
    unsafe { &mut *cx.0.as_ptr().cast() }
}