//! ฟังก์ชั่นการสั่งซื้อและการเปรียบเทียบ
//!
//! โมดูลนี้ประกอบด้วยเครื่องมือต่างๆสำหรับการสั่งซื้อและเปรียบเทียบค่าสรุป:
//!
//! * [`Eq`] และ [`PartialEq`] คือ traits ที่ให้คุณกำหนดความเท่าเทียมกันทั้งหมดและบางส่วนระหว่างค่าตามลำดับ
//! การนำไปใช้งานจะทำให้ตัวดำเนินการ `==` และ `!=` มากเกินไป
//! * [`Ord`] และ [`PartialOrd`] คือ traits ที่ให้คุณกำหนดลำดับทั้งหมดและบางส่วนระหว่างค่าตามลำดับ
//!
//! การนำไปใช้งานจะทำให้ตัวดำเนินการ `<`, `<=`, `>` และ `>=` มากเกินไป
//! * [`Ordering`] เป็น enum ที่ส่งคืนโดยฟังก์ชันหลักของ [`Ord`] และ [`PartialOrd`] และอธิบายถึงลำดับ
//! * [`Reverse`] เป็นโครงสร้างที่ช่วยให้คุณย้อนกลับการสั่งซื้อได้อย่างง่ายดาย
//! * [`max`] และ [`min`] เป็นฟังก์ชันที่สร้างจาก [`Ord`] และช่วยให้คุณค้นหาค่าสูงสุดหรือต่ำสุดของสองค่า
//!
//! สำหรับรายละเอียดเพิ่มเติมโปรดดูเอกสารที่เกี่ยวข้องของแต่ละรายการในรายการ
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait สำหรับการเปรียบเทียบความเท่าเทียมกันซึ่งเป็น [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation)
///
/// trait นี้อนุญาตให้มีความเท่าเทียมกันบางส่วนสำหรับประเภทที่ไม่มีความสัมพันธ์การเทียบเท่าเต็มรูปแบบ
/// ตัวอย่างเช่นในเลขทศนิยม `NaN != NaN` ดังนั้นประเภทจุดลอยตัวจึงใช้ `PartialEq` แต่ไม่ใช่ [`trait@Eq`]
///
/// ตามปกติความเท่าเทียมกันต้องเป็น (สำหรับ `a`, `b`, `c` ทุกประเภท `A`, `B`, `C`):
///
/// - **Symmetric**: ถ้า `A: PartialEq<B>` และ `B: PartialEq<A>` ดังนั้น **`a==b` หมายถึง`b==a`**;และ
///
/// - **สกรรมกริยา**: ถ้า `A: PartialEq<B>` และ `B: PartialEq<C>` และ `A:
///   PartialEq<C>`แล้ว **` a==b`และ `b == c` หมายถึง"a==c`**
///
/// โปรดทราบว่า `B: PartialEq<A>` (symmetric) และ `A: PartialEq<C>` (transitive) นัยไม่ได้ถูกบังคับให้มีอยู่ แต่ข้อกำหนดเหล่านี้มีผลบังคับใช้เมื่อใดก็ตามที่มีอยู่
///
/// ## Derivable
///
/// trait นี้สามารถใช้กับ `#[derive]` ได้เมื่อ "ได้มา" บนโครงสร้างสองอินสแตนซ์จะเท่ากันถ้าฟิลด์ทั้งหมดเท่ากันและไม่เท่ากันหากฟิลด์ใด ๆ ไม่เท่ากันเมื่อ "ได้รับ" มาจาก enums ตัวแปรแต่ละตัวจะเท่ากับตัวมันเองและไม่เท่ากับตัวแปรอื่น ๆ
///
/// ## ฉันจะใช้ `PartialEq` ได้อย่างไร
///
/// `PartialEq` ต้องใช้เมธอด [`eq`] เท่านั้นจึงจะดำเนินการได้ [`ne`] ถูกกำหนดโดยค่าเริ่มต้นการใช้งาน [`ne`]*ด้วยตนเองต้อง* เคารพกฎที่ [`eq`] เป็นส่วนผกผันที่เข้มงวดของ [`ne`] นั่นคือ `!(a == b)` ถ้า `a != b` เท่านั้น
///
/// การใช้งาน `PartialEq`, [`PartialOrd`] และ [`Ord`]*ต้อง* ตกลงกันเป็นเรื่องง่ายที่จะทำให้พวกเขาไม่เห็นด้วยโดยการหา traits บางส่วนและนำไปใช้งานด้วยตนเอง
///
/// ตัวอย่างการใช้งานสำหรับโดเมนที่หนังสือสองเล่มถือเป็นหนังสือเล่มเดียวกันหาก ISBN ตรงกันแม้ว่ารูปแบบจะแตกต่างกัน:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## ฉันจะเปรียบเทียบสองประเภทที่แตกต่างกันได้อย่างไร?
///
/// ประเภทที่คุณเปรียบเทียบได้ถูกควบคุมโดยพารามิเตอร์ประเภทของ "PartialEq"
/// ตัวอย่างเช่นลองปรับแต่งรหัสก่อนหน้าของเราเล็กน้อย:
///
/// ```
/// // การดำเนินการที่ได้มา<BookFormat>==<BookFormat>การเปรียบเทียบ
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // ดำเนินการ<Book>==<BookFormat>การเปรียบเทียบ
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // ดำเนินการ<BookFormat>==<Book>การเปรียบเทียบ
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// การเปลี่ยน `impl PartialEq for Book` เป็น `impl PartialEq<BookFormat> for Book` ทำให้เราสามารถเปรียบเทียบ "BookFormat" กับ "หนังสือ" ได้
///
/// การเปรียบเทียบเช่นเดียวกับด้านบนซึ่งไม่สนใจบางฟิลด์ของโครงสร้างอาจเป็นอันตรายได้สามารถนำไปสู่การละเมิดข้อกำหนดสำหรับความสัมพันธ์ความเท่าเทียมกันบางส่วนโดยไม่ได้ตั้งใจได้อย่างง่ายดาย
/// ตัวอย่างเช่นหากเรายังคงใช้งาน `PartialEq<Book>` สำหรับ `BookFormat` ข้างต้นและเพิ่มการใช้งาน `PartialEq<Book>` สำหรับ `Book` (ไม่ว่าจะผ่าน `#[derive]` หรือผ่านการใช้งานด้วยตนเองจากตัวอย่างแรก) ผลลัพธ์จะละเมิดการขนส่ง:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// วิธีนี้จะทดสอบค่า `self` และ `other` ให้เท่ากันและใช้โดย `==`
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// วิธีนี้จะทดสอบ `!=`
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// มาโครที่ได้รับซึ่งสร้างโดยนัยของ trait `PartialEq`
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait สำหรับการเปรียบเทียบความเท่าเทียมกันซึ่งเป็น [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation)
///
/// ซึ่งหมายความว่านอกจาก `a == b` และ `a != b` จะเป็นตัวผกผันที่เข้มงวดแล้วความเท่าเทียมกันจะต้องเป็น (สำหรับ `a`, `b` และ `c` ทั้งหมด):
///
/// - reflexive: `a == a`;
/// - สมมาตร: `a == b` หมายถึง `b == a`;และ
/// - สกรรมกริยา: `a == b` และ `b == c` หมายถึง `a == c`
///
/// คอมไพลเลอร์ไม่สามารถตรวจสอบคุณสมบัตินี้ได้ดังนั้น `Eq` จึงหมายถึง [`PartialEq`] และไม่มีเมธอดพิเศษ
///
/// ## Derivable
///
/// trait นี้สามารถใช้กับ `#[derive]` ได้
/// เมื่อ "ได้มา" เนื่องจาก `Eq` ไม่มีเมธอดพิเศษมันเป็นเพียงการแจ้งคอมไพเลอร์ว่านี่เป็นความสัมพันธ์ที่เทียบเท่าแทนที่จะเป็นความสัมพันธ์ที่เทียบเท่าบางส่วน
///
/// โปรดทราบว่ากลยุทธ์ `derive` กำหนดให้ฟิลด์ทั้งหมดคือ `Eq` ซึ่งไม่ต้องการเสมอไป
///
/// ## ฉันจะใช้ `Eq` ได้อย่างไร
///
/// หากคุณไม่สามารถใช้กลยุทธ์ `derive` ได้ให้ระบุว่าประเภทของคุณใช้ `Eq` ซึ่งไม่มีวิธีการใด ๆ :
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // วิธีนี้ใช้เพียงอย่างเดียวโดย#[deriving] เพื่อยืนยันว่าทุกองค์ประกอบของประเภทใช้#[ได้มา] เองโครงสร้างพื้นฐานที่ได้รับในปัจจุบันหมายถึงการยืนยันนี้โดยไม่ใช้วิธีการบน trait นี้แทบจะเป็นไปไม่ได้เลย
    //
    //
    // สิ่งนี้ไม่ควรดำเนินการด้วยมือ
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// มาโครที่ได้รับซึ่งสร้างโดยนัยของ trait `Eq`
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: โครงสร้างนี้ถูกใช้โดย#[derive] ถึง แต่เพียงผู้เดียว
// ยืนยันว่าทุกองค์ประกอบของประเภทใช้ Eq
//
// โครงสร้างนี้ไม่ควรปรากฏในรหัสผู้ใช้
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Ordering` เป็นผลมาจากการเปรียบเทียบระหว่างค่าสองค่า
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// ลำดับที่ค่าเปรียบเทียบน้อยกว่าค่าอื่น
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// ลำดับที่ค่าเปรียบเทียบเท่ากับค่าอื่น
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// ลำดับที่ค่าเปรียบเทียบมากกว่าค่าอื่น
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// ส่งคืน `true` หากการสั่งซื้อเป็นตัวแปร `Equal`
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// ส่งคืน `true` หากการสั่งซื้อไม่ใช่ตัวแปร `Equal`
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// ส่งคืน `true` หากการสั่งซื้อเป็นตัวแปร `Less`
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// ส่งคืน `true` หากการสั่งซื้อเป็นตัวแปร `Greater`
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// ส่งคืน `true` หากการสั่งซื้อเป็นตัวแปร `Less` หรือ `Equal`
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// ส่งคืน `true` หากการสั่งซื้อเป็นตัวแปร `Greater` หรือ `Equal`
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// กลับ `Ordering`
    ///
    /// * `Less` กลายเป็น `Greater`
    /// * `Greater` กลายเป็น `Less`
    /// * `Equal` กลายเป็น `Equal`
    ///
    /// # Examples
    ///
    /// พฤติกรรมพื้นฐาน:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// วิธีนี้สามารถใช้เพื่อย้อนกลับการเปรียบเทียบ:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // จัดเรียงอาร์เรย์จากมากที่สุดไปหาน้อยที่สุด
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// เชื่อมโยงสองคำสั่ง
    ///
    /// ส่งคืน `self` เมื่อไม่ใช่ `Equal` มิฉะนั้นจะคืนค่า `other`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// เชื่อมโยงการสั่งซื้อด้วยฟังก์ชันที่กำหนด
    ///
    /// ส่งคืน `self` เมื่อไม่ใช่ `Equal`
    /// มิฉะนั้นจะเรียกใช้ `f` และส่งกลับผลลัพธ์
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// โครงสร้างตัวช่วยสำหรับการสั่งซื้อย้อนกลับ
///
/// โครงสร้างนี้เป็นตัวช่วยที่จะใช้กับฟังก์ชันเช่น [`Vec::sort_by_key`] และสามารถใช้เพื่อย้อนกลับลำดับส่วนหนึ่งของคีย์ได้
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait สำหรับประเภทที่สร้าง [total order](https://en.wikipedia.org/wiki/Total_order)
///
/// คำสั่งซื้อคือคำสั่งซื้อทั้งหมดหากเป็น (สำหรับ `a`, `b` และ `c` ทั้งหมด):
///
/// - ผลรวมและไม่สมมาตร: หนึ่งใน `a < b`, `a == b` หรือ `a > b` เป็นจริงและ
/// - สกรรมกริยา `a < b` และ `b < c` หมายถึง `a < c` สิ่งเดียวกันจะต้องมีไว้สำหรับทั้ง `==` และ `>`
///
/// ## Derivable
///
/// trait นี้สามารถใช้กับ `#[derive]` ได้
/// เมื่อ "ได้รับ" มาจากโครงสร้างจะสร้างคำสั่ง [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) ตามลำดับการประกาศจากบนลงล่างของสมาชิกของโครงสร้าง
///
/// เมื่อ "ได้รับ" มาจาก enums ตัวแปรต่างๆจะเรียงลำดับตามลำดับการเลือกปฏิบัติจากบนลงล่าง
///
/// ## การเปรียบเทียบพจนานุกรม
///
/// การเปรียบเทียบเชิงศัพท์เป็นการดำเนินการที่มีคุณสมบัติดังต่อไปนี้:
///  - สองลำดับจะถูกเปรียบเทียบองค์ประกอบตามองค์ประกอบ
///  - องค์ประกอบแรกที่ไม่ตรงกันกำหนดว่าลำดับใดมีความหมายตามศัพท์น้อยกว่าหรือมากกว่าองค์ประกอบอื่น
///  - ถ้าลำดับหนึ่งเป็นคำนำหน้าของอีกลำดับหนึ่งลำดับที่สั้นกว่าจะมีความหมายตามศัพท์น้อยกว่าอีกลำดับ
///  - ถ้าสองลำดับมีองค์ประกอบที่เท่ากันและมีความยาวเท่ากันลำดับนั้นจะเท่ากันตามศัพท์
///  - ลำดับว่างมีความหมายตามศัพท์น้อยกว่าลำดับที่ไม่ว่างเปล่า
///  - ลำดับที่ว่างเปล่าสองลำดับมีค่าเท่ากันตามศัพท์
///
/// ## ฉันจะใช้ `Ord` ได้อย่างไร
///
/// `Ord` กำหนดให้ประเภทเป็น [`PartialOrd`] และ [`Eq`] ด้วย (ซึ่งต้องใช้ [`PartialEq`])
///
/// จากนั้นคุณต้องกำหนดการใช้งานสำหรับ [`cmp`] คุณอาจพบว่าการใช้ [`cmp`] ในฟิลด์ประเภทของคุณมีประโยชน์
///
/// การใช้งาน [`PartialEq`], [`PartialOrd`] และ `Ord`*ต้อง* ตกลงกัน
/// นั่นคือ `a.cmp(b) == Ordering::Equal` ถ้า `a == b` และ `Some(a.cmp(b)) == a.partial_cmp(b)` สำหรับ `a` และ `b` ทั้งหมดเท่านั้น
/// เป็นเรื่องง่ายที่จะทำให้พวกเขาไม่เห็นด้วยโดยการหา traits บางส่วนและนำไปใช้งานด้วยตนเอง
///
/// นี่คือตัวอย่างที่คุณต้องการจัดเรียงบุคคลตามความสูงเท่านั้นโดยไม่คำนึงถึง `id` และ `name`:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// วิธีนี้ส่งคืนค่า [`Ordering`] ระหว่าง `self` และ `other`
    ///
    /// ตามแบบแผน `self.cmp(&other)` จะส่งคืนลำดับที่ตรงกับนิพจน์ `self <operator> other` ถ้าเป็นจริง
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// เปรียบเทียบและส่งกลับค่าสูงสุดสองค่า
    ///
    /// ส่งคืนอาร์กิวเมนต์ที่สองหากการเปรียบเทียบกำหนดให้เท่ากัน
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// เปรียบเทียบและส่งคืนค่าต่ำสุดของสองค่า
    ///
    /// ส่งคืนอาร์กิวเมนต์แรกหากการเปรียบเทียบกำหนดให้เท่ากัน
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// จำกัด ค่าให้อยู่ในช่วงเวลาหนึ่ง
    ///
    /// ส่งคืน `max` ถ้า `self` มากกว่า `max` และ `min` ถ้า `self` น้อยกว่า `min`
    /// มิฉะนั้นจะคืนค่า `self`
    ///
    /// # Panics
    ///
    /// Panics ถ้า `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// มาโครที่ได้รับซึ่งสร้างโดยนัยของ trait `Ord`
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait สำหรับค่าที่สามารถเปรียบเทียบกับลำดับการจัดเรียง
///
/// การเปรียบเทียบจะต้องเป็นไปตามสำหรับ `a`, `b` และ `c` ทั้งหมด:
///
/// - ความไม่สมมาตร: ถ้า `a < b` แล้ว `!(a > b)` เช่นเดียวกับ `a > b` หมายถึง `!(a < b)` และ
/// - การขนส่ง: `a < b` และ `b < c` หมายถึง `a < c` สิ่งเดียวกันจะต้องมีไว้สำหรับทั้ง `==` และ `>`
///
/// โปรดทราบว่าข้อกำหนดเหล่านี้หมายความว่า trait จะต้องถูกนำไปใช้งานแบบสมมาตรและแบบสกรรมกริยา: ถ้า `T: PartialOrd<U>` และ `U: PartialOrd<V>` จากนั้น `U: PartialOrd<T>` และ `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// trait นี้สามารถใช้กับ `#[derive]` ได้เมื่อ "ได้รับ" มาจากโครงสร้างจะจัดลำดับคำศัพท์ตามลำดับการประกาศจากบนลงล่างของสมาชิกของโครงสร้าง
/// เมื่อ "ได้รับ" มาจาก enums ตัวแปรต่างๆจะเรียงลำดับตามลำดับการเลือกปฏิบัติจากบนลงล่าง
///
/// ## ฉันจะใช้ `PartialOrd` ได้อย่างไร
///
/// `PartialOrd` ต้องการเพียงการใช้งานวิธี [`partial_cmp`] กับวิธีอื่นที่สร้างขึ้นจากการใช้งานเริ่มต้น
///
/// อย่างไรก็ตามยังคงเป็นไปได้ที่จะใช้งานอื่น ๆ แยกกันสำหรับประเภทที่ไม่มีคำสั่งซื้อทั้งหมด
/// ตัวอย่างเช่นสำหรับตัวเลขทศนิยม `NaN < 0 == false` และ `NaN >= 0 == false` (cf.
/// IEEE 754-2008 ส่วน 5.11)
///
/// `PartialOrd` กำหนดให้ประเภทของคุณเป็น [`PartialEq`]
///
/// การใช้งาน [`PartialEq`], `PartialOrd` และ [`Ord`]*ต้อง* ตกลงกัน
/// เป็นเรื่องง่ายที่จะทำให้พวกเขาไม่เห็นด้วยโดยการหา traits บางส่วนและนำไปใช้งานด้วยตนเอง
///
/// หากประเภทของคุณคือ [`Ord`] คุณสามารถใช้ [`partial_cmp`] ได้โดยใช้ [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// คุณอาจพบว่าการใช้ [`partial_cmp`] ในฟิลด์ประเภทของคุณมีประโยชน์เช่นกัน
/// นี่คือตัวอย่างของประเภท `Person` ที่มีเขตข้อมูล `height` จุดลอยตัวซึ่งเป็นเขตข้อมูลเดียวที่จะใช้ในการเรียงลำดับ:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// วิธีนี้ส่งคืนลำดับระหว่างค่า `self` และ `other` หากมีอยู่
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// เมื่อเปรียบเทียบไม่ได้:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// วิธีนี้ทดสอบน้อยกว่า (สำหรับ `self` และ `other`) และใช้โดยตัวดำเนินการ `<`
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// วิธีนี้ทดสอบน้อยกว่าหรือเท่ากับ (สำหรับ `self` และ `other`) และใช้โดยตัวดำเนินการ `<=`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// วิธีนี้ทดสอบมากกว่า (สำหรับ `self` และ `other`) และใช้โดยตัวดำเนินการ `>`
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// วิธีนี้ทดสอบมากกว่าหรือเท่ากับ (สำหรับ `self` และ `other`) และใช้โดยตัวดำเนินการ `>=`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// มาโครที่ได้รับซึ่งสร้างโดยนัยของ trait `PartialOrd`
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// เปรียบเทียบและส่งคืนค่าต่ำสุดของสองค่า
///
/// ส่งคืนอาร์กิวเมนต์แรกหากการเปรียบเทียบกำหนดให้เท่ากัน
///
/// ภายในใช้นามแฝงเพื่อ [`Ord::min`]
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// ส่งคืนค่าต่ำสุดของสองค่าตามฟังก์ชันเปรียบเทียบที่ระบุ
///
/// ส่งคืนอาร์กิวเมนต์แรกหากการเปรียบเทียบกำหนดให้เท่ากัน
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// ส่งคืนองค์ประกอบที่ให้ค่าต่ำสุดจากฟังก์ชันที่ระบุ
///
/// ส่งคืนอาร์กิวเมนต์แรกหากการเปรียบเทียบกำหนดให้เท่ากัน
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// เปรียบเทียบและส่งกลับค่าสูงสุดสองค่า
///
/// ส่งคืนอาร์กิวเมนต์ที่สองหากการเปรียบเทียบกำหนดให้เท่ากัน
///
/// ภายในใช้นามแฝงเพื่อ [`Ord::max`]
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// ส่งคืนค่าสูงสุดสองค่าตามฟังก์ชันเปรียบเทียบที่ระบุ
///
/// ส่งคืนอาร์กิวเมนต์ที่สองหากการเปรียบเทียบกำหนดให้เท่ากัน
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// ส่งคืนองค์ประกอบที่ให้ค่าสูงสุดจากฟังก์ชันที่ระบุ
///
/// ส่งคืนอาร์กิวเมนต์ที่สองหากการเปรียบเทียบกำหนดให้เท่ากัน
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// การใช้งาน PartialEq, Eq, PartialOrd และ Ord สำหรับประเภทดั้งเดิม
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // ลำดับที่นี่เป็นสิ่งสำคัญในการสร้างการประกอบที่เหมาะสมยิ่งขึ้น
                    // ดู <https://github.com/rust-lang/rust/issues/63758> สำหรับข้อมูลเพิ่มเติม
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // การแคสต์ไปที่ i8 และการแปลงความแตกต่างเป็นการสั่งซื้อทำให้เกิดการประกอบที่เหมาะสมยิ่งขึ้น
            //
            // ดู <https://github.com/rust-lang/rust/issues/66780> สำหรับข้อมูลเพิ่มเติม
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // ความปลอดภัย: bool เป็น i8 ส่งคืน 0 หรือ 1 ดังนั้นความแตกต่างจึงไม่สามารถเป็นอย่างอื่นได้
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &พอยน์เตอร์

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}