//! Panic รองรับ libcore
//!
//! ไลบรารีหลักไม่สามารถกำหนดการตื่นตระหนกได้ แต่จะ *ประกาศ* ตื่นตระหนก
//! ซึ่งหมายความว่าฟังก์ชั่นภายใน libcore ได้รับอนุญาตให้ panic แต่เพื่อให้เป็นประโยชน์อัพสตรีม crate ต้องกำหนดการตื่นตระหนกสำหรับ libcore ที่จะใช้
//! อินเทอร์เฟซปัจจุบันสำหรับการตื่นตระหนกคือ:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! คำจำกัดความนี้ช่วยให้เกิดความตื่นตระหนกกับข้อความทั่วไป แต่ไม่อนุญาตให้ใช้ค่า `Box<Any>` ล้มเหลว
//! (`PanicInfo` มีเพียง `&(dyn Any + Send)` ซึ่งเรากรอกค่าดัมมี่ใน "PanicInfo: : internal_constructor") เหตุผลนี้ก็คือ libcore ไม่ได้รับอนุญาตให้จัดสรร
//!
//!
//! โมดูลนี้มีฟังก์ชันการตื่นตระหนกอื่น ๆ อีกเล็กน้อย แต่เป็นเพียงรายการภาษาที่จำเป็นสำหรับคอมไพเลอร์ panics ทั้งหมดถูกเชื่อมต่อผ่านฟังก์ชั่นเดียวนี้
//! สัญลักษณ์จริงถูกประกาศผ่านแอตทริบิวต์ `#[panic_handler]`
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// การใช้งานมาโคร `panic!` ของ libcore เมื่อไม่มีการใช้การจัดรูปแบบ
#[cold]
// อย่าอินไลน์เว้นแต่ panic_immediate_abort เพื่อหลีกเลี่ยงการขยายตัวของโค้ดที่ไซต์การโทรให้มากที่สุด
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // จำเป็นโดย codegen สำหรับ panic เมื่อโอเวอร์โฟลว์และเทอร์มิเนเตอร์ `Assert` MIR อื่น ๆ
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // ใช้ Arguments::new_v1 แทน format_args! ("{}", expr) เพื่อลดขนาดค่าใช้จ่าย
    // format_args!มาโครใช้ Display trait ของ str เพื่อเขียน expr ซึ่งเรียก Formatter::pad ซึ่งต้องรองรับการตัดสตริงและช่องว่างภายใน (แม้ว่าจะไม่มีการใช้ที่นี่ก็ตาม)
    //
    // การใช้ Arguments::new_v1 อาจทำให้คอมไพลเลอร์สามารถละเว้น Formatter::pad จากไบนารีเอาต์พุตซึ่งประหยัดได้ถึงสองสามกิโลไบต์
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // จำเป็นสำหรับ panics ที่ประเมินโดย const
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // จำเป็นโดย codegen สำหรับ panic ในการเข้าถึง OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// การใช้งานมาโคร `panic!` ของ libcore เมื่อใช้การจัดรูปแบบ
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // หมายเหตุฟังก์ชันนี้ไม่เคยข้ามขอบเขต FFIเป็นการเรียก Rust-to-Rust ที่ได้รับการแก้ไขเป็นฟังก์ชัน `#[panic_handler]`
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // ความปลอดภัย: `panic_impl` ถูกกำหนดไว้ในรหัส Rust ที่ปลอดภัยดังนั้นจึงปลอดภัยในการโทร
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// ฟังก์ชันภายในสำหรับมาโคร `assert_eq!` และ `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}