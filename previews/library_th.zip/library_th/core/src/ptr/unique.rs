use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// กระดาษห่อหุ้มรอบ `*mut T` ดิบที่ไม่ใช่ค่าว่างซึ่งบ่งชี้ว่าผู้ครอบครองกระดาษห่อนี้เป็นเจ้าของการอ้างอิง
/// มีประโยชน์สำหรับการสร้างสิ่งที่เป็นนามธรรมเช่น `Box<T>`, `Vec<T>`, `String` และ `HashMap<K, V>`
///
/// แตกต่างจาก `*mut T` `Unique<T>` จะทำงาน "as if" ซึ่งเป็นอินสแตนซ์ของ `T`
/// ใช้ `Send`/`Sync` ถ้า `T` คือ `Send`/`Sync`
/// นอกจากนี้ยังแสดงถึงประเภทของนามแฝงที่แข็งแกร่งซึ่งรับประกันว่าตัวอย่างของ `T` สามารถคาดหวังได้:
/// ไม่ควรแก้ไขการอ้างอิงของตัวชี้โดยไม่มีเส้นทางที่ไม่ซ้ำกันไปยัง Unique ของตัวเอง
///
/// หากคุณไม่แน่ใจว่าการใช้ `Unique` ตามวัตถุประสงค์ของคุณถูกต้องหรือไม่ให้พิจารณาใช้ `NonNull` ซึ่งมีความหมายที่อ่อนกว่า
///
///
/// ไม่เหมือนกับ `*mut T` ตัวชี้จะต้องไม่เป็นค่าว่างเสมอแม้ว่าตัวชี้จะไม่ถูกอ้างถึงก็ตาม
/// ดังนั้น enums อาจใช้ค่าต้องห้ามนี้เป็นตัวเลือก-`Option<Unique<T>>` มีขนาดเท่ากับ `Unique<T>`
/// อย่างไรก็ตามตัวชี้อาจยังห้อยอยู่หากไม่ได้อ้างถึง
///
/// แตกต่างจาก `*mut T`, `Unique<T>` เป็นโควาเรียมากกว่า `T`
/// สิ่งนี้ควรถูกต้องเสมอสำหรับประเภทใด ๆ ที่สนับสนุนข้อกำหนดการใช้นามแฝงของ Unique
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: เครื่องหมายนี้ไม่มีผลต่อความแปรปรวน แต่จำเป็น
    // เพื่อให้ dropck เข้าใจว่าเราเป็นเจ้าของ `T` อย่างมีเหตุผล
    //
    // สำหรับรายละเอียดโปรดดู:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` พอยน์เตอร์คือ `Send` หาก `T` คือ `Send` เนื่องจากข้อมูลที่อ้างอิงไม่ได้ระบุไว้
/// โปรดสังเกตว่านามแฝงคงที่นี้ไม่ได้บังคับใช้โดยระบบ type;สิ่งที่เป็นนามธรรมที่ใช้ `Unique` ต้องบังคับใช้
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` พอยน์เตอร์คือ `Sync` หาก `T` คือ `Sync` เนื่องจากข้อมูลที่อ้างอิงไม่ได้ระบุไว้
/// โปรดสังเกตว่านามแฝงคงที่นี้ไม่ได้บังคับใช้โดยระบบ type;สิ่งที่เป็นนามธรรมที่ใช้ `Unique` ต้องบังคับใช้
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// สร้าง `Unique` ใหม่ที่ห้อย แต่จัดวางอย่างดี
    ///
    /// สิ่งนี้มีประโยชน์สำหรับการกำหนดค่าเริ่มต้นประเภทที่จัดสรรอย่างเฉื่อยชาเช่นเดียวกับ `Vec::new`
    ///
    /// โปรดทราบว่าค่าตัวชี้อาจเป็นตัวแทนของตัวชี้ที่ถูกต้องไปยัง `T` ซึ่งหมายความว่าจะต้องไม่ใช้เป็นค่า Sentinel "not yet initialized"
    /// ประเภทที่จัดสรรอย่างเกียจคร้านต้องติดตามการเริ่มต้นด้วยวิธีอื่น
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // ความปลอดภัย: mem::align_of() ส่งคืนตัวชี้ที่ไม่เป็นค่าว่างที่ถูกต้อง
        // เงื่อนไขในการเรียก new_unchecked() จึงได้รับการปฏิบัติตาม
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// สร้าง `Unique` ใหม่
    ///
    /// # Safety
    ///
    /// `ptr` ต้องไม่เป็นค่าว่าง
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // ความปลอดภัย: ผู้โทรต้องรับประกันว่า `ptr` ไม่เป็นโมฆะ
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// สร้าง `Unique` ใหม่หาก `ptr` ไม่ใช่ค่าว่าง
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // ความปลอดภัย: ตัวชี้ได้รับการตรวจสอบแล้วและไม่เป็นโมฆะ
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// รับตัวชี้ `*mut` ที่อยู่ภายใต้
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// อ้างถึงเนื้อหา
    ///
    /// อายุการใช้งานที่เกิดขึ้นจะผูกพันกับตัวเองดังนั้นสิ่งนี้จึงทำงาน "as if" ซึ่งเป็นตัวอย่างของ T ที่ถูกยืมมา
    /// หากต้องการอายุการใช้งาน (unbound) นานขึ้นให้ใช้ `&*my_ptr.as_ptr()`
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // ความปลอดภัย: ผู้โทรจะต้องรับประกันว่า `self` ตรงตามไฟล์
        // ข้อกำหนดสำหรับการอ้างอิง
        unsafe { &*self.as_ptr() }
    }

    /// หักล้างเนื้อหาโดยสิ้นเชิง
    ///
    /// อายุการใช้งานที่เกิดขึ้นจะผูกพันกับตัวเองดังนั้นสิ่งนี้จึงทำงาน "as if" ซึ่งเป็นตัวอย่างของ T ที่ถูกยืมมา
    /// หากต้องการอายุการใช้งาน (unbound) นานขึ้นให้ใช้ `&mut *my_ptr.as_ptr()`
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // ความปลอดภัย: ผู้โทรจะต้องรับประกันว่า `self` ตรงตามไฟล์
        // ข้อกำหนดสำหรับการอ้างอิงที่ไม่แน่นอน
        unsafe { &mut *self.as_ptr() }
    }

    /// ส่งไปยังตัวชี้ประเภทอื่น
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // ความปลอดภัย: Unique::new_unchecked() สร้างเอกลักษณ์และความต้องการใหม่ ๆ
        // ตัวชี้ที่กำหนดจะไม่เป็นโมฆะ
        // เนื่องจากเราส่งตัวเองเป็นตัวชี้จึงไม่สามารถเป็นโมฆะได้
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // ความปลอดภัย: การอ้างอิงที่ไม่แน่นอนไม่สามารถเป็นโมฆะได้
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}