use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` แต่ไม่ใช่ศูนย์และแปรปรวน
///
/// สิ่งนี้มักเป็นสิ่งที่ถูกต้องในการสร้างโครงสร้างข้อมูลโดยใช้ตัวชี้ดิบ แต่ในที่สุดก็มีอันตรายมากกว่าที่จะใช้เนื่องจากคุณสมบัติเพิ่มเติมหากคุณไม่แน่ใจว่าควรใช้ `NonNull<T>` หรือไม่ให้ใช้ `*mut T`!
///
/// ไม่เหมือนกับ `*mut T` ตัวชี้จะต้องไม่เป็นค่าว่างเสมอแม้ว่าตัวชี้จะไม่ถูกอ้างถึงก็ตามดังนั้น enums อาจใช้ค่าต้องห้ามนี้เป็นการเลือกปฏิบัติ-`Option<NonNull<T>>` มีขนาดเท่ากับ `* mut T`
/// อย่างไรก็ตามตัวชี้อาจยังห้อยอยู่หากไม่ได้อ้างถึง
///
/// ไม่เหมือนกับ `*mut T` `NonNull<T>` ถูกเลือกให้เป็นโควาเรียมากกว่า `T` สิ่งนี้ทำให้สามารถใช้ `NonNull<T>` ในการสร้างประเภทโควาเรียได้ แต่จะแนะนำความเสี่ยงของความไม่น่าเชื่อถือหากใช้ในประเภทที่ไม่ควรเป็นโควาเรีย
/// (ทางเลือกที่ตรงกันข้ามถูกสร้างขึ้นสำหรับ `*mut T` แม้ว่าในทางเทคนิคแล้วความไม่สมบูรณ์อาจเกิดจากการเรียกใช้ฟังก์ชันที่ไม่ปลอดภัยเท่านั้น)
///
/// ความแปรปรวนร่วมถูกต้องสำหรับนามธรรมที่ปลอดภัยที่สุดเช่น `Box`, `Rc`, `Arc`, `Vec` และ `LinkedList` เป็นกรณีนี้เนื่องจากมี API สาธารณะที่เป็นไปตามกฎ XOR ที่ไม่สามารถใช้ร่วมกันได้ปกติของ Rust
///
/// หากประเภทของคุณไม่สามารถผสมกันได้อย่างปลอดภัยคุณต้องตรวจสอบให้แน่ใจว่าประเภทนั้นมีฟิลด์เพิ่มเติมเพื่อให้ความไม่แน่นอนโดยมากช่องนี้จะเป็นประเภท [`PhantomData`] เช่น `PhantomData<Cell<T>>` หรือ `PhantomData<&'a mut T>`
///
/// สังเกตว่า `NonNull<T>` มีอินสแตนซ์ `From` สำหรับ `&T` อย่างไรก็ตามสิ่งนี้ไม่ได้เปลี่ยนความจริงที่ว่าการกลายพันธุ์ผ่าน (ตัวชี้ที่ได้มาจากการอ้างอิงที่ใช้ร่วมกัน) เป็นพฤติกรรมที่ไม่ได้กำหนดเว้นแต่การกลายพันธุ์จะเกิดขึ้นภายใน [`UnsafeCell<T>`] เช่นเดียวกับการสร้างการอ้างอิงที่เปลี่ยนแปลงได้จากการอ้างอิงที่ใช้ร่วมกัน
///
/// เมื่อใช้อินสแตนซ์ `From` นี้โดยไม่มี `UnsafeCell<T>` เป็นความรับผิดชอบของคุณที่จะต้องตรวจสอบให้แน่ใจว่าไม่มีการเรียก `as_mut` และ `as_ptr` จะไม่ถูกใช้สำหรับการกลายพันธุ์
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` พอยน์เตอร์ไม่ใช่ `Send` เนื่องจากข้อมูลที่อ้างอิงอาจเป็นนามแฝง
// หมายเหตุโดยนัยนี้ไม่จำเป็น แต่ควรให้ข้อความแสดงข้อผิดพลาดที่ดีกว่า
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` พอยน์เตอร์ไม่ใช่ `Sync` เนื่องจากข้อมูลที่อ้างอิงอาจเป็นนามแฝง
// หมายเหตุโดยนัยนี้ไม่จำเป็น แต่ควรให้ข้อความแสดงข้อผิดพลาดที่ดีกว่า
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// สร้าง `NonNull` ใหม่ที่ห้อย แต่จัดวางอย่างดี
    ///
    /// สิ่งนี้มีประโยชน์สำหรับการกำหนดค่าเริ่มต้นประเภทที่จัดสรรอย่างเฉื่อยชาเช่นเดียวกับ `Vec::new`
    ///
    /// โปรดทราบว่าค่าตัวชี้อาจเป็นตัวแทนของตัวชี้ที่ถูกต้องไปยัง `T` ซึ่งหมายความว่าจะต้องไม่ใช้เป็นค่า Sentinel "not yet initialized"
    /// ประเภทที่จัดสรรอย่างเกียจคร้านต้องติดตามการเริ่มต้นด้วยวิธีอื่น
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // ความปลอดภัย: mem::align_of() ส่งคืน usize ที่ไม่ใช่ศูนย์ซึ่งจะถูกร่าย
        // ถึง * mut T.
        // ดังนั้น `ptr` จึงไม่เป็นโมฆะและเคารพเงื่อนไขในการเรียก new_unchecked()
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// ส่งคืนการอ้างอิงที่ใช้ร่วมกันเป็นค่าในทางตรงกันข้ามกับ [`as_ref`] ไม่จำเป็นต้องเริ่มต้นค่า
    ///
    /// สำหรับคู่ที่ไม่แน่นอนโปรดดู [`as_uninit_mut`]
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// เมื่อเรียกวิธีนี้คุณต้องแน่ใจว่าสิ่งต่อไปนี้เป็นจริงทั้งหมด:
    ///
    /// * ตัวชี้จะต้องจัดตำแหน่งให้ถูกต้อง
    ///
    /// * ต้องเป็น "dereferencable" ตามความหมายที่กำหนดไว้ใน [the module documentation]
    ///
    /// * คุณต้องบังคับใช้กฎการใช้นามแฝงของ Rust เนื่องจาก `'a` อายุการใช้งานที่ส่งคืนถูกเลือกโดยพลการและไม่จำเป็นต้องสะท้อนถึงอายุการใช้งานจริงของข้อมูล
    ///
    ///   โดยเฉพาะอย่างยิ่งในช่วงอายุการใช้งานนี้หน่วยความจำที่ตัวชี้ชี้ว่าจะต้องไม่กลายพันธุ์ (ยกเว้นภายใน `UnsafeCell`)
    ///
    /// สิ่งนี้ใช้ได้แม้ว่าจะไม่ได้ใช้ผลลัพธ์ของวิธีนี้ก็ตาม!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // ความปลอดภัย: ผู้โทรจะต้องรับประกันว่า `self` ตรงตามไฟล์
        // ข้อกำหนดสำหรับการอ้างอิง
        unsafe { &*self.cast().as_ptr() }
    }

    /// ส่งคืนการอ้างอิงที่ไม่ซ้ำกับค่าในทางตรงกันข้ามกับ [`as_mut`] ไม่จำเป็นต้องเริ่มต้นค่า
    ///
    /// สำหรับคู่ที่ใช้ร่วมกันโปรดดู [`as_uninit_ref`]
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// เมื่อเรียกวิธีนี้คุณต้องแน่ใจว่าสิ่งต่อไปนี้เป็นจริงทั้งหมด:
    ///
    /// * ตัวชี้จะต้องจัดตำแหน่งให้ถูกต้อง
    ///
    /// * ต้องเป็น "dereferencable" ตามความหมายที่กำหนดไว้ใน [the module documentation]
    ///
    /// * คุณต้องบังคับใช้กฎการใช้นามแฝงของ Rust เนื่องจาก `'a` อายุการใช้งานที่ส่งคืนถูกเลือกโดยพลการและไม่จำเป็นต้องสะท้อนถึงอายุการใช้งานจริงของข้อมูล
    ///
    ///   โดยเฉพาะอย่างยิ่งในช่วงระยะเวลาของอายุการใช้งานนี้หน่วยความจำที่ตัวชี้ชี้ไปจะต้องไม่สามารถเข้าถึงได้ (อ่านหรือเขียน) ผ่านตัวชี้อื่น ๆ
    ///
    /// สิ่งนี้ใช้ได้แม้ว่าจะไม่ได้ใช้ผลลัพธ์ของวิธีนี้ก็ตาม!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // ความปลอดภัย: ผู้โทรจะต้องรับประกันว่า `self` ตรงตามไฟล์
        // ข้อกำหนดสำหรับการอ้างอิง
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// สร้าง `NonNull` ใหม่
    ///
    /// # Safety
    ///
    /// `ptr` ต้องไม่เป็นค่าว่าง
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // ความปลอดภัย: ผู้โทรต้องรับประกันว่า `ptr` ไม่เป็นโมฆะ
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// สร้าง `NonNull` ใหม่หาก `ptr` ไม่ใช่ค่าว่าง
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // ความปลอดภัย: ตัวชี้ถูกตรวจสอบแล้วและไม่เป็นโมฆะ
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// ดำเนินการทำงานเช่นเดียวกับ [`std::ptr::from_raw_parts`] ยกเว้นว่าตัวชี้ `NonNull` จะถูกส่งกลับซึ่งต่างจากตัวชี้ดิบ `*const`
    ///
    ///
    /// ดูเอกสารของ [`std::ptr::from_raw_parts`] สำหรับรายละเอียดเพิ่มเติม
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // ความปลอดภัย: ผลลัพธ์ของ `ptr::from::raw_parts_mut` ไม่ใช่ค่าว่างเนื่องจาก `data_address` คือ
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// แยกตัวชี้ (อาจกว้าง) เป็นองค์ประกอบที่อยู่และข้อมูลเมตา
    ///
    /// ตัวชี้สามารถสร้างขึ้นใหม่ได้ในภายหลังด้วย [`NonNull::from_raw_parts`]
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// รับตัวชี้ `*mut` ที่อยู่ภายใต้
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// ส่งคืนการอ้างอิงที่ใช้ร่วมกันเป็นค่าหากค่าอาจไม่ได้กำหนดค่าเริ่มต้นต้องใช้ [`as_uninit_ref`] แทน
    ///
    /// สำหรับคู่ที่ไม่แน่นอนโปรดดู [`as_mut`]
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// เมื่อเรียกวิธีนี้คุณต้องแน่ใจว่าสิ่งต่อไปนี้เป็นจริงทั้งหมด:
    ///
    /// * ตัวชี้จะต้องจัดตำแหน่งให้ถูกต้อง
    ///
    /// * ต้องเป็น "dereferencable" ตามความหมายที่กำหนดไว้ใน [the module documentation]
    ///
    /// * ตัวชี้ต้องชี้ไปที่อินสแตนซ์เริ่มต้นของ `T`
    ///
    /// * คุณต้องบังคับใช้กฎการใช้นามแฝงของ Rust เนื่องจาก `'a` อายุการใช้งานที่ส่งคืนถูกเลือกโดยพลการและไม่จำเป็นต้องสะท้อนถึงอายุการใช้งานจริงของข้อมูล
    ///
    ///   โดยเฉพาะอย่างยิ่งในช่วงอายุการใช้งานนี้หน่วยความจำที่ตัวชี้ชี้ว่าจะต้องไม่กลายพันธุ์ (ยกเว้นภายใน `UnsafeCell`)
    ///
    /// สิ่งนี้ใช้ได้แม้ว่าจะไม่ได้ใช้ผลลัพธ์ของวิธีนี้ก็ตาม!
    /// (ส่วนที่เกี่ยวกับการเริ่มต้นยังไม่ได้รับการตัดสินใจอย่างสมบูรณ์ แต่จนกว่าจะถึงเวลานั้นแนวทางเดียวที่ปลอดภัยคือเพื่อให้แน่ใจว่าได้เริ่มต้นแล้ว)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // ความปลอดภัย: ผู้โทรจะต้องรับประกันว่า `self` ตรงตามไฟล์
        // ข้อกำหนดสำหรับการอ้างอิง
        unsafe { &*self.as_ptr() }
    }

    /// ส่งคืนการอ้างอิงที่ไม่ซ้ำกับค่าหากค่าอาจไม่ได้กำหนดค่าเริ่มต้นต้องใช้ [`as_uninit_mut`] แทน
    ///
    /// สำหรับคู่ที่ใช้ร่วมกันโปรดดู [`as_ref`]
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// เมื่อเรียกวิธีนี้คุณต้องแน่ใจว่าสิ่งต่อไปนี้เป็นจริงทั้งหมด:
    ///
    /// * ตัวชี้จะต้องจัดตำแหน่งให้ถูกต้อง
    ///
    /// * ต้องเป็น "dereferencable" ตามความหมายที่กำหนดไว้ใน [the module documentation]
    ///
    /// * ตัวชี้ต้องชี้ไปที่อินสแตนซ์เริ่มต้นของ `T`
    ///
    /// * คุณต้องบังคับใช้กฎการใช้นามแฝงของ Rust เนื่องจาก `'a` อายุการใช้งานที่ส่งคืนถูกเลือกโดยพลการและไม่จำเป็นต้องสะท้อนถึงอายุการใช้งานจริงของข้อมูล
    ///
    ///   โดยเฉพาะอย่างยิ่งในช่วงระยะเวลาของอายุการใช้งานนี้หน่วยความจำที่ตัวชี้ชี้ไปจะต้องไม่สามารถเข้าถึงได้ (อ่านหรือเขียน) ผ่านตัวชี้อื่น ๆ
    ///
    /// สิ่งนี้ใช้ได้แม้ว่าจะไม่ได้ใช้ผลลัพธ์ของวิธีนี้ก็ตาม!
    /// (ส่วนที่เกี่ยวกับการเริ่มต้นยังไม่ได้รับการตัดสินใจอย่างสมบูรณ์ แต่จนกว่าจะถึงเวลานั้นแนวทางเดียวที่ปลอดภัยคือเพื่อให้แน่ใจว่าได้เริ่มต้นแล้ว)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // ความปลอดภัย: ผู้โทรจะต้องรับประกันว่า `self` ตรงตามไฟล์
        // ข้อกำหนดสำหรับการอ้างอิงที่ไม่แน่นอน
        unsafe { &mut *self.as_ptr() }
    }

    /// ส่งไปยังตัวชี้ประเภทอื่น
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // ความปลอดภัย: `self` เป็นตัวชี้ `NonNull` ซึ่งไม่จำเป็นต้องเป็นค่าว่าง
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// สร้างชิ้นส่วนดิบที่ไม่เป็นค่าว่างจากตัวชี้แบบบางและความยาว
    ///
    /// อาร์กิวเมนต์ `len` คือจำนวน **องค์ประกอบ** ไม่ใช่จำนวนไบต์
    ///
    /// ฟังก์ชันนี้ปลอดภัย แต่การยกเลิกการอ้างอิงค่าที่ส่งคืนไม่ปลอดภัย
    /// ดูเอกสารของ [`slice::from_raw_parts`] สำหรับข้อกำหนดด้านความปลอดภัยของชิ้นส่วน
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // สร้างตัวชี้สไลซ์เมื่อเริ่มต้นด้วยตัวชี้ไปยังองค์ประกอบแรก
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (โปรดทราบว่าตัวอย่างนี้แสดงให้เห็นถึงการใช้วิธีนี้โดยไม่ได้ตั้งใจ แต่ให้ slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // ความปลอดภัย: `data` เป็นตัวชี้ `NonNull` ซึ่งไม่จำเป็นต้องเป็นค่าว่าง
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// ส่งคืนความยาวของชิ้นส่วนดิบที่ไม่ใช่ค่าว่าง
    ///
    /// ค่าที่ส่งคืนคือจำนวน **องค์ประกอบ** ไม่ใช่จำนวนไบต์
    ///
    /// ฟังก์ชันนี้ปลอดภัยแม้ว่าชิ้นส่วนดิบที่ไม่ใช่ค่าว่างจะไม่สามารถอ้างอิงถึงชิ้นส่วนได้เนื่องจากตัวชี้ไม่มีที่อยู่ที่ถูกต้อง
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// ส่งกลับตัวชี้ที่ไม่เป็นค่าว่างไปยังบัฟเฟอร์ของชิ้นส่วน
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // ความปลอดภัย: เรารู้ว่า `self` ไม่ใช่ค่าว่าง
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// ส่งกลับตัวชี้ดิบไปยังบัฟเฟอร์ของชิ้นส่วน
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// ส่งคืนการอ้างอิงที่ใช้ร่วมกันไปยังส่วนของค่าที่อาจไม่ได้กำหนดค่าเริ่มต้นในทางตรงกันข้ามกับ [`as_ref`] ไม่จำเป็นต้องเริ่มต้นค่า
    ///
    /// สำหรับคู่ที่ไม่แน่นอนโปรดดู [`as_uninit_slice_mut`]
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// เมื่อเรียกวิธีนี้คุณต้องแน่ใจว่าสิ่งต่อไปนี้เป็นจริงทั้งหมด:
    ///
    /// * ตัวชี้ต้องเป็น [valid] สำหรับการอ่าน `ptr.len() * mem::size_of::<T>()` หลายไบต์และต้องจัดตำแหน่งให้ถูกต้องโดยเฉพาะอย่างยิ่ง:
    ///
    ///     * ช่วงหน่วยความจำทั้งหมดของชิ้นส่วนนี้ต้องอยู่ในออบเจ็กต์ที่จัดสรรเพียงชิ้นเดียว!
    ///       ชิ้นส่วนไม่สามารถขยายข้ามวัตถุที่จัดสรรหลายรายการได้
    ///
    ///     * ตัวชี้จะต้องจัดแนวแม้สำหรับชิ้นส่วนที่มีความยาวเป็นศูนย์
    ///     เหตุผลประการหนึ่งคือการเพิ่มประสิทธิภาพโครงร่าง enum อาจอาศัยการอ้างอิง (รวมถึงชิ้นส่วนที่มีความยาวใด ๆ) ได้รับการจัดแนวและไม่เป็นค่าว่างเพื่อแยกความแตกต่างจากข้อมูลอื่น ๆ
    ///
    ///     คุณสามารถรับตัวชี้ที่ใช้งานได้เป็น `data` สำหรับชิ้นส่วนที่มีความยาวเป็นศูนย์โดยใช้ [`NonNull::dangling()`]
    ///
    /// * ขนาดรวม `ptr.len() * mem::size_of::<T>()` ของชิ้นงานต้องไม่เกิน `isize::MAX`
    ///   ดูเอกสารความปลอดภัยของ [`pointer::offset`]
    ///
    /// * คุณต้องบังคับใช้กฎการใช้นามแฝงของ Rust เนื่องจาก `'a` อายุการใช้งานที่ส่งคืนถูกเลือกโดยพลการและไม่จำเป็นต้องสะท้อนถึงอายุการใช้งานจริงของข้อมูล
    ///   โดยเฉพาะอย่างยิ่งในช่วงอายุการใช้งานนี้หน่วยความจำที่ตัวชี้ชี้ว่าจะต้องไม่กลายพันธุ์ (ยกเว้นภายใน `UnsafeCell`)
    ///
    /// สิ่งนี้ใช้ได้แม้ว่าจะไม่ได้ใช้ผลลัพธ์ของวิธีนี้ก็ตาม!
    ///
    /// ดู [`slice::from_raw_parts`] ด้วย
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `as_uninit_slice`
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// ส่งคืนการอ้างอิงที่ไม่ซ้ำกันไปยังส่วนของค่าที่อาจไม่ได้กำหนดค่าเริ่มต้นในทางตรงกันข้ามกับ [`as_mut`] ไม่จำเป็นต้องเริ่มต้นค่า
    ///
    /// สำหรับคู่ที่ใช้ร่วมกันโปรดดู [`as_uninit_slice`]
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// เมื่อเรียกวิธีนี้คุณต้องแน่ใจว่าสิ่งต่อไปนี้เป็นจริงทั้งหมด:
    ///
    /// * ตัวชี้ต้องเป็น [valid] สำหรับการอ่านและเขียนสำหรับ `ptr.len() * mem::size_of::<T>()` หลายไบต์และต้องจัดตำแหน่งให้ถูกต้องโดยเฉพาะอย่างยิ่ง:
    ///
    ///     * ช่วงหน่วยความจำทั้งหมดของชิ้นส่วนนี้ต้องอยู่ในออบเจ็กต์ที่จัดสรรเพียงชิ้นเดียว!
    ///       ชิ้นส่วนไม่สามารถขยายข้ามวัตถุที่จัดสรรหลายรายการได้
    ///
    ///     * ตัวชี้จะต้องจัดแนวแม้สำหรับชิ้นส่วนที่มีความยาวเป็นศูนย์
    ///     เหตุผลประการหนึ่งคือการเพิ่มประสิทธิภาพโครงร่าง enum อาจอาศัยการอ้างอิง (รวมถึงชิ้นส่วนที่มีความยาวใด ๆ) ได้รับการจัดแนวและไม่เป็นค่าว่างเพื่อแยกความแตกต่างจากข้อมูลอื่น ๆ
    ///
    ///     คุณสามารถรับตัวชี้ที่ใช้งานได้เป็น `data` สำหรับชิ้นส่วนที่มีความยาวเป็นศูนย์โดยใช้ [`NonNull::dangling()`]
    ///
    /// * ขนาดรวม `ptr.len() * mem::size_of::<T>()` ของชิ้นงานต้องไม่เกิน `isize::MAX`
    ///   ดูเอกสารความปลอดภัยของ [`pointer::offset`]
    ///
    /// * คุณต้องบังคับใช้กฎการใช้นามแฝงของ Rust เนื่องจาก `'a` อายุการใช้งานที่ส่งคืนถูกเลือกโดยพลการและไม่จำเป็นต้องสะท้อนถึงอายุการใช้งานจริงของข้อมูล
    ///   โดยเฉพาะอย่างยิ่งในช่วงระยะเวลาของอายุการใช้งานนี้หน่วยความจำที่ตัวชี้ชี้ไปจะต้องไม่สามารถเข้าถึงได้ (อ่านหรือเขียน) ผ่านตัวชี้อื่น ๆ
    ///
    /// สิ่งนี้ใช้ได้แม้ว่าจะไม่ได้ใช้ผลลัพธ์ของวิธีนี้ก็ตาม!
    ///
    /// ดู [`slice::from_raw_parts_mut`] ด้วย
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // สิ่งนี้ปลอดภัยเนื่องจาก `memory` ใช้ได้สำหรับการอ่านและเขียนสำหรับ `memory.len()` หลายไบต์
    /// // โปรดทราบว่าที่นี่ไม่อนุญาตให้เรียก `memory.as_mut()` เนื่องจากเนื้อหาอาจไม่ได้กำหนดค่าเริ่มต้น
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `as_uninit_slice_mut`
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// ส่งกลับตัวชี้ดิบไปยังองค์ประกอบหรือส่วนย่อยโดยไม่ต้องทำการตรวจสอบขอบเขต
    ///
    /// การเรียกใช้เมธอดนี้ด้วยดัชนีนอกขอบเขตหรือเมื่อ `self` ไม่สามารถถอดรหัสได้คือ *[พฤติกรรมที่ไม่ได้กำหนด]* แม้ว่าจะไม่ได้ใช้ตัวชี้ผลลัพธ์ก็ตาม
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // ความปลอดภัย: ผู้โทรตรวจสอบให้แน่ใจว่า `self` ไม่สามารถถอดรหัสได้และ `index` อยู่ในขอบเขต
        // ด้วยเหตุนี้ตัวชี้ผลลัพธ์จึงไม่สามารถเป็นโมฆะได้
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // ความปลอดภัย: ตัวชี้ที่ไม่ซ้ำกันไม่สามารถเป็นโมฆะได้ดังนั้นเงื่อนไขสำหรับ
        // new_unchecked() ได้รับความเคารพ
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // ความปลอดภัย: การอ้างอิงที่ไม่แน่นอนไม่สามารถเป็นโมฆะได้
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // ความปลอดภัย: การอ้างอิงไม่สามารถเป็นโมฆะดังนั้นเงื่อนไขสำหรับ
        // new_unchecked() ได้รับความเคารพ
        unsafe { NonNull { pointer: reference as *const T } }
    }
}