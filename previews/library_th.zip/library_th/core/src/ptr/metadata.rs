#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// จัดเตรียมประเภทข้อมูลเมตาของตัวชี้ของประเภทชี้ไปที่
///
/// # ข้อมูลเมตาของตัวชี้
///
/// ประเภทตัวชี้ดิบและประเภทการอ้างอิงใน Rust สามารถพิจารณาได้จากสองส่วน:
/// ตัวชี้ข้อมูลที่มีที่อยู่หน่วยความจำของค่าและข้อมูลเมตาบางส่วน
///
/// สำหรับประเภทขนาดคงที่ (ที่ใช้ `Sized` traits) และสำหรับประเภท `extern` พอยน์เตอร์จะกล่าวว่าเป็น "บาง": ข้อมูลเมตามีขนาดเป็นศูนย์และประเภทคือ `()`
///
///
/// ตัวชี้ไปยัง [dynamically-sized types][dst] มีความหมายว่า "กว้าง" หรือ "อ้วน" มีข้อมูลเมตาที่ไม่ใช่ศูนย์:
///
/// * สำหรับโครงสร้างที่มีฟิลด์สุดท้ายเป็น DST ข้อมูลเมตาคือข้อมูลเมตาสำหรับฟิลด์สุดท้าย
/// * สำหรับประเภท `str` ข้อมูลเมตาคือความยาวเป็นไบต์เท่ากับ `usize`
/// * สำหรับประเภทสไลซ์เช่น `[T]` ข้อมูลเมตาคือความยาวในรายการเท่ากับ `usize`
/// * สำหรับวัตถุ trait เช่น `dyn SomeTrait` ข้อมูลเมตาคือ [`DynMetadata<Self>`][DynMetadata] (เช่น `DynMetadata<dyn SomeTrait>`)
///
/// ใน future ภาษา Rust อาจได้รับประเภทใหม่ ๆ ที่มีข้อมูลเมตาของตัวชี้ที่แตกต่างกัน
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// จุดของ trait นี้คือประเภทที่เกี่ยวข้องกับ `Metadata` ซึ่งก็คือ `()` หรือ `usize` หรือ `DynMetadata<_>` ตามที่อธิบายไว้ข้างต้น
/// มันถูกนำไปใช้โดยอัตโนมัติสำหรับทุกประเภท
/// สามารถสันนิษฐานได้ว่าจะนำไปใช้ในบริบททั่วไปแม้ว่าจะไม่มีขอบเขตที่เกี่ยวข้องก็ตาม
///
/// # Usage
///
/// ตัวชี้ดิบสามารถแยกย่อยลงในที่อยู่ข้อมูลและส่วนประกอบข้อมูลเมตาด้วยวิธี [`to_raw_parts`]
///
/// หรืออีกวิธีหนึ่งคือสามารถแยกข้อมูลเมตาเพียงอย่างเดียวด้วยฟังก์ชัน [`metadata`]
/// การอ้างอิงสามารถส่งผ่านไปยัง [`metadata`] และบังคับโดยปริยาย
///
/// ตัวชี้ (possibly-wide) สามารถนำกลับมารวมกันจากที่อยู่และข้อมูลเมตาด้วย [`from_raw_parts`] หรือ [`from_raw_parts_mut`]
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// ประเภทของข้อมูลเมตาในตัวชี้และการอ้างอิงถึง `Self`
    #[lang = "metadata_type"]
    // NOTE: เก็บ trait bounds ไว้ใน `static_assert_expected_bounds_for_metadata`
    //
    // ใน `library/core/src/ptr/metadata.rs` ซิงค์กับที่นี่:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// ตัวชี้ไปยังประเภทที่ใช้นามแฝง trait นี้ "บาง"
///
/// ซึ่งรวมถึงประเภท "ขนาด" แบบคงที่และประเภท `extern`
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: อย่าทำให้สิ่งนี้เสถียรก่อนที่นามแฝง trait จะเสถียรในภาษา?
pub trait Thin = Pointee<Metadata = ()>;

/// แยกองค์ประกอบข้อมูลเมตาของตัวชี้
///
/// ค่าของประเภท `*mut T`, `&T` หรือ `&mut T` สามารถส่งผ่านไปยังฟังก์ชันนี้ได้โดยตรงเนื่องจากมีการบีบบังคับโดยปริยายถึง `* const T`
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // ความปลอดภัย: การเข้าถึงค่าจากสหภาพ `PtrRepr` นั้นปลอดภัยตั้งแต่ * const T
    // และ PtrComponents<T>มีเค้าโครงหน่วยความจำเหมือนกัน
    // มีเพียง std เท่านั้นที่สามารถรับประกันได้
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// สร้างตัวชี้ดิบ (possibly-wide) จากที่อยู่ข้อมูลและข้อมูลเมตา
///
/// ฟังก์ชันนี้ปลอดภัย แต่ตัวชี้ที่ส่งกลับไม่จำเป็นต้องปลอดภัยในการหักล้าง
/// สำหรับชิ้นส่วนโปรดดูเอกสารของ [`slice::from_raw_parts`] สำหรับข้อกำหนดด้านความปลอดภัย
/// สำหรับออบเจ็กต์ trait ข้อมูลเมตาต้องมาจากตัวชี้ไปยังประเภทการลบที่อยู่ภายใต้เดียวกัน
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // ความปลอดภัย: การเข้าถึงค่าจากสหภาพ `PtrRepr` นั้นปลอดภัยตั้งแต่ * const T
    // และ PtrComponents<T>มีเค้าโครงหน่วยความจำเหมือนกัน
    // มีเพียง std เท่านั้นที่สามารถรับประกันได้
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// ดำเนินการทำงานเช่นเดียวกับ [`from_raw_parts`] ยกเว้นว่าตัวชี้ `*mut` ดิบจะถูกส่งกลับซึ่งตรงข้ามกับตัวชี้ดิบ `* const`
///
///
/// ดูเอกสารของ [`from_raw_parts`] สำหรับรายละเอียดเพิ่มเติม
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // ความปลอดภัย: การเข้าถึงค่าจากสหภาพ `PtrRepr` นั้นปลอดภัยตั้งแต่ * const T
    // และ PtrComponents<T>มีเค้าโครงหน่วยความจำเหมือนกัน
    // มีเพียง std เท่านั้นที่สามารถรับประกันได้
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// จำเป็นต้องใช้ด้วยตนเองเพื่อหลีกเลี่ยงการผูก `T: Copy`
impl<T: ?Sized> Copy for PtrComponents<T> {}

// จำเป็นต้องใช้ด้วยตนเองเพื่อหลีกเลี่ยงการผูก `T: Clone`
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// ข้อมูลเมตาสำหรับประเภทอ็อบเจ็กต์ `Dyn = dyn SomeTrait` trait
///
/// เป็นตัวชี้ไปยัง vtable (virtual call table) ที่แสดงถึงข้อมูลที่จำเป็นทั้งหมดในการจัดการประเภทคอนกรีตที่เก็บไว้ในวัตถุ trait
/// vtable โดยเฉพาะประกอบด้วย:
///
/// * พิมพ์ขนาด
/// * ประเภทการจัดตำแหน่ง
/// * ตัวชี้ไปยัง `drop_in_place` ของประเภท (อาจเป็น no-op สำหรับข้อมูลธรรมดา)
/// * ชี้ถึงวิธีการทั้งหมดสำหรับการใช้งานประเภทของ trait
///
/// โปรดทราบว่าสามอันดับแรกมีความพิเศษเนื่องจากจำเป็นในการจัดสรรวางและจัดสรรออบเจ็กต์ trait ใด ๆ
///
/// เป็นไปได้ที่จะตั้งชื่อโครงสร้างนี้ด้วยพารามิเตอร์ type ที่ไม่ใช่อ็อบเจ็กต์ `dyn` trait (เช่น `DynMetadata<u64>`) แต่จะไม่ได้รับค่าที่มีความหมายของโครงสร้างนั้น
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// คำนำหน้าทั่วไปของ vtables ทั้งหมดตามด้วยฟังก์ชันพอยน์เตอร์สำหรับเมธอด trait
///
/// รายละเอียดการใช้งานส่วนตัวของ `DynMetadata::size_of` เป็นต้น
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// ส่งคืนขนาดของชนิดที่เกี่ยวข้องกับ vtable นี้
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// ส่งกลับการจัดตำแหน่งของชนิดที่เกี่ยวข้องกับ vtable นี้
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// ส่งคืนขนาดและการจัดตำแหน่งพร้อมกันเป็น `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // ความปลอดภัย: คอมไพเลอร์ปล่อย vtable นี้สำหรับคอนกรีตประเภท Rust ซึ่ง
        // เป็นที่ทราบกันดีว่ามีเค้าโครงที่ถูกต้องเหตุผลเดียวกันกับใน `Layout::for_value`
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// จำเป็นต้องมีคำแนะนำด้วยตนเองเพื่อหลีกเลี่ยงขอบเขต `Dyn: $Trait`

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}