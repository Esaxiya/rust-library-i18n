//! ประเภทของอะตอม
//!
//! ประเภทอะตอมจัดเตรียมการสื่อสารระหว่างหน่วยความจำแบบแบ่งใช้แบบดั้งเดิมระหว่างเธรดและเป็นหน่วยการสร้างของประเภทอื่น ๆ ที่เกิดขึ้นพร้อมกัน
//!
//! โมดูลนี้กำหนดเวอร์ชันอะตอมของประเภทดั้งเดิมที่เลือกไว้ ได้แก่ [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`] เป็นต้น
//! ประเภทอะตอมนำเสนอการดำเนินการที่เมื่อใช้อย่างถูกต้องซิงโครไนซ์การอัปเดตระหว่างเธรด
//!
//! แต่ละวิธีใช้ [`Ordering`] ซึ่งแสดงถึงความแข็งแกร่งของอุปสรรคหน่วยความจำสำหรับการดำเนินการนั้นลำดับเหล่านี้เหมือนกับ [C++20 atomic orderings][1] สำหรับข้อมูลเพิ่มเติมโปรดดู [nomicon][2]
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! ตัวแปรอะตอมมีความปลอดภัยในการแบ่งปันระหว่างเธรด (ใช้ [`Sync`]) แต่ไม่ได้จัดเตรียมกลไกสำหรับการแบ่งปันและปฏิบัติตาม [threading model](../../../std/thread/index.html#the-threading-model) ของ Rust
//!
//! วิธีที่ใช้บ่อยที่สุดในการแบ่งปันตัวแปรอะตอมคือการใส่ไว้ใน [`Arc`][arc] (ตัวชี้ที่ใช้ร่วมกันที่นับโดยอ้างอิงอะตอม)
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! ประเภทอะตอมอาจถูกเก็บไว้ในตัวแปรคงที่เริ่มต้นโดยใช้ตัวเริ่มต้นคงที่เช่น [`AtomicBool::new`] สถิตยศาสตร์อะตอมมักใช้สำหรับการเริ่มต้นทั่วโลกที่ขี้เกียจ
//!
//! # Portability
//!
//! อะตอมทุกประเภทในโมดูลนี้รับประกันว่าเป็น [lock-free] หากมีซึ่งหมายความว่าพวกเขาไม่ได้รับ global mutex ภายในไม่รับประกันประเภทและการดำเนินงานของอะตอมว่าจะไม่ต้องรอ
//! ซึ่งหมายความว่าการดำเนินการเช่น `fetch_or` อาจถูกนำไปใช้กับการเปรียบเทียบและสลับลูป
//!
//! การดำเนินการของอะตอมอาจถูกนำไปใช้ที่ชั้นคำสั่งด้วยอะตอมที่มีขนาดใหญ่กว่าตัวอย่างเช่นบางแพลตฟอร์มใช้คำสั่งอะตอม 4 ไบต์เพื่อใช้งาน `AtomicI8`
//! โปรดทราบว่าการจำลองนี้ไม่ควรมีผลกระทบต่อความถูกต้องของรหัสเป็นเพียงสิ่งที่ต้องระวัง
//!
//! ประเภทอะตอมในโมดูลนี้อาจไม่สามารถใช้ได้กับทุกแพลตฟอร์มอย่างไรก็ตามประเภทของอะตอมในที่นี้มีอยู่ทั่วไปอย่างไรก็ตามโดยทั่วไปแล้วสามารถพึ่งพาได้จากสิ่งที่มีอยู่ข้อยกเว้นที่น่าสังเกตบางประการ ได้แก่ :
//!
//! * PowerPC และแพลตฟอร์ม MIPS ที่มีพอยน์เตอร์ 32 บิตไม่มีประเภท `AtomicU64` หรือ `AtomicI64`
//! * ARM แพลตฟอร์มเช่น `armv5te` ที่ไม่ได้มีไว้สำหรับ Linux ให้การดำเนินการ `load` และ `store` เท่านั้นและไม่รองรับการดำเนินการเปรียบเทียบและสลับ (CAS) เช่น `swap`, `fetch_add` เป็นต้น
//! นอกจากนี้ใน Linux การดำเนินการ CAS เหล่านี้จะดำเนินการผ่าน [operating system support] ซึ่งอาจมาพร้อมกับการลงโทษด้านประสิทธิภาพ
//! * ARM เป้าหมายที่มี `thumbv6m` ให้เฉพาะการดำเนินการ `load` และ `store` และไม่สนับสนุนการดำเนินการเปรียบเทียบและสลับ (CAS) เช่น `swap`, `fetch_add` เป็นต้น
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! โปรดทราบว่าอาจมีการเพิ่มแพลตฟอร์ม future ที่ไม่รองรับการทำงานของอะตอมบางอย่างรหัสพกพาสูงสุดจะต้องระมัดระวังเกี่ยวกับอะตอมที่ใช้
//! `AtomicUsize` และโดยทั่วไป `AtomicIsize` เป็นอุปกรณ์พกพามากที่สุด แต่ถึงอย่างนั้นก็ไม่สามารถใช้ได้ทุกที่
//! สำหรับการอ้างอิงไลบรารี `std` ต้องการอะตอมขนาดพอยน์เตอร์แม้ว่า `core` จะไม่ใช้ก็ตาม
//!
//! ตอนนี้คุณจะต้องใช้ `#[cfg(target_arch)]` เป็นหลักในการคอมไพล์โค้ดด้วยอะตอมตามเงื่อนไขมี `#[cfg(target_has_atomic)]` ที่ไม่เสถียรเช่นกันซึ่งอาจเสถียรใน future
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Spinlock ง่ายๆ:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // รอให้เธรดอื่นคลายล็อก
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! รักษาจำนวนเธรดสดทั่วโลก:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// ประเภทบูลีนที่สามารถแชร์ระหว่างเธรดได้อย่างปลอดภัย
///
/// ประเภทนี้มีการแสดงในหน่วยความจำเช่นเดียวกับ [`bool`]
///
/// **หมายเหตุ**: ประเภทนี้มีให้เฉพาะบนแพลตฟอร์มที่รองรับการโหลดอะตอมและร้านค้าของ `u8`
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// สร้าง `AtomicBool` เริ่มต้นเป็น `false`
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// ส่งถูกนำไปใช้โดยปริยายสำหรับ AtomicBool
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// ชนิดตัวชี้ดิบที่สามารถแชร์ระหว่างเธรดได้อย่างปลอดภัย
///
/// ประเภทนี้มีการแสดงในหน่วยความจำเช่นเดียวกับ `*mut T`
///
/// **หมายเหตุ**: ประเภทนี้มีให้เฉพาะบนแพลตฟอร์มที่รองรับโหลดอะตอมและที่เก็บพอยน์เตอร์
/// ขนาดของมันขึ้นอยู่กับขนาดของตัวชี้เป้าหมาย
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// สร้าง `AtomicPtr<T>` ว่าง
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// ลำดับหน่วยความจำปรมาณู
///
/// ลำดับหน่วยความจำระบุวิธีการทำงานของอะตอมซิงโครไนซ์หน่วยความจำ
/// ใน [`Ordering::Relaxed`] ที่อ่อนแอที่สุดจะซิงโครไนซ์เฉพาะหน่วยความจำที่สัมผัสโดยตรงจากการทำงานเท่านั้น
/// ในทางกลับกันคู่การดำเนินการ [`Ordering::SeqCst`] ที่จัดเก็บโหลดจะซิงโครไนซ์หน่วยความจำอื่นในขณะที่ยังรักษาลำดับรวมของการดำเนินการดังกล่าวในทุกเธรด
///
///
/// ลำดับหน่วยความจำของ Rust คือ [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order)
///
/// สำหรับข้อมูลเพิ่มเติมโปรดดู [nomicon]
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// ไม่มีข้อ จำกัด ในการสั่งซื้อมีเพียงการดำเนินการของปรมาณู
    ///
    /// สอดคล้องกับ [`memory_order_relaxed`] ใน C++ 20
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// เมื่อใช้ร่วมกับร้านค้าการดำเนินการก่อนหน้านี้ทั้งหมดจะได้รับคำสั่งก่อนการโหลดค่านี้ด้วยการสั่งซื้อ [`Acquire`] (หรือสูงกว่า)
    ///
    /// โดยเฉพาะอย่างยิ่งการเขียนก่อนหน้านี้ทั้งหมดจะมองเห็นได้สำหรับเธรดทั้งหมดที่ดำเนินการโหลด [`Acquire`] (หรือสูงกว่า) ของค่านี้
    ///
    /// โปรดสังเกตว่าการใช้คำสั่งนี้สำหรับการดำเนินการที่รวมโหลดและการจัดเก็บจะนำไปสู่การดำเนินการโหลด [`Relaxed`]!
    ///
    /// การสั่งซื้อนี้ใช้ได้เฉพาะกับการดำเนินการที่สามารถดำเนินการกับร้านค้าได้
    ///
    /// สอดคล้องกับ [`memory_order_release`] ใน C++ 20
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// เมื่อใช้ร่วมกับโหลดหากค่าที่โหลดถูกเขียนโดยการดำเนินการจัดเก็บที่มีการสั่งซื้อ [`Release`] (หรือสูงกว่า) การดำเนินการที่ตามมาทั้งหมดจะได้รับคำสั่งหลังจากที่จัดเก็บนั้น
    /// โดยเฉพาะอย่างยิ่งการโหลดที่ตามมาทั้งหมดจะเห็นข้อมูลที่เขียนขึ้นก่อนที่จะจัดเก็บ
    ///
    /// สังเกตว่าการใช้คำสั่งนี้สำหรับการดำเนินการที่รวมโหลดและการจัดเก็บจะนำไปสู่การดำเนินการจัดเก็บ [`Relaxed`]!
    ///
    /// คำสั่งนี้ใช้ได้เฉพาะกับการดำเนินการที่สามารถโหลดได้
    ///
    /// สอดคล้องกับ [`memory_order_acquire`] ใน C++ 20
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// มีผลกระทบทั้ง [`Acquire`] และ [`Release`] ด้วยกัน:
    /// สำหรับการโหลดจะใช้การสั่งซื้อ [`Acquire`] สำหรับร้านค้าจะใช้การสั่งซื้อ [`Release`]
    ///
    /// สังเกตว่าในกรณีของ `compare_and_swap` อาจเป็นไปได้ว่าการดำเนินการสิ้นสุดลงโดยไม่มีการดำเนินการกับร้านค้าใด ๆ และด้วยเหตุนี้จึงมีการสั่งซื้อเพียง [`Acquire`]
    ///
    /// อย่างไรก็ตาม `AcqRel` จะไม่ทำการเข้าถึง [`Relaxed`]
    ///
    /// การสั่งซื้อนี้ใช้ได้เฉพาะกับการดำเนินการที่รวมทั้งการโหลดและการจัดเก็บ
    ///
    /// สอดคล้องกับ [`memory_order_acq_rel`] ใน C++ 20
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// เช่นเดียวกับ [`Acquire`]/[`Release`]/[`AcqRel`](สำหรับการโหลดการจัดเก็บและการโหลดที่มีการจัดเก็บตามลำดับ) ด้วยการรับประกันเพิ่มเติมว่าเธรดทั้งหมดจะเห็นการดำเนินการที่สอดคล้องกันตามลำดับทั้งหมดในลำดับเดียวกัน .
    ///
    ///
    /// สอดคล้องกับ [`memory_order_seq_cst`] ใน C++ 20
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] เริ่มต้นเป็น `false`
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// สร้าง `AtomicBool` ใหม่
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// ส่งคืนการอ้างอิงที่ไม่แน่นอนไปยัง [`bool`] ที่อยู่ภายใต้
    ///
    /// สิ่งนี้ปลอดภัยเนื่องจากการอ้างอิงที่เปลี่ยนแปลงได้รับประกันว่าไม่มีเธรดอื่น ๆ ที่เข้าถึงข้อมูลปรมาณูพร้อมกัน
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // ความปลอดภัย: การอ้างอิงที่เปลี่ยนแปลงได้รับประกันความเป็นเจ้าของที่ไม่ซ้ำกัน
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// เข้าถึงอะตอม `&mut bool`
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // ความปลอดภัย: ข้อมูลอ้างอิงที่เปลี่ยนแปลงได้รับประกันความเป็นเจ้าของที่ไม่ซ้ำใครและ
        // การจัดตำแหน่งของทั้ง `bool` และ `Self` คือ 1
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// ใช้อะตอมและส่งคืนค่าที่มีอยู่
    ///
    /// สิ่งนี้ปลอดภัยเนื่องจากการส่ง `self` ตามค่าจะรับประกันว่าไม่มีเธรดอื่น ๆ ที่เข้าถึงข้อมูลปรมาณูพร้อมกัน
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// โหลดค่าจาก bool
    ///
    /// `load` รับอาร์กิวเมนต์ [`Ordering`] ซึ่งอธิบายลำดับความจำของการดำเนินการนี้
    /// ค่าที่เป็นไปได้คือ [`SeqCst`], [`Acquire`] และ [`Relaxed`]
    ///
    /// # Panics
    ///
    /// Panics ถ้า `order` คือ [`Release`] หรือ [`AcqRel`]
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // ความปลอดภัย: การแข่งขันข้อมูลใด ๆ ถูกป้องกันโดยเนื้อแท้ของอะตอมและข้อมูลดิบ
        // ตัวชี้ที่ส่งผ่านนั้นถูกต้องเพราะเราได้มาจากการอ้างอิง
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// เก็บค่าไว้ใน bool
    ///
    /// `store` รับอาร์กิวเมนต์ [`Ordering`] ซึ่งอธิบายลำดับความจำของการดำเนินการนี้
    /// ค่าที่เป็นไปได้คือ [`SeqCst`], [`Release`] และ [`Relaxed`]
    ///
    /// # Panics
    ///
    /// Panics ถ้า `order` คือ [`Acquire`] หรือ [`AcqRel`]
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // ความปลอดภัย: การแข่งขันข้อมูลใด ๆ ถูกป้องกันโดยเนื้อแท้ของอะตอมและข้อมูลดิบ
        // ตัวชี้ที่ส่งผ่านนั้นถูกต้องเพราะเราได้มาจากการอ้างอิง
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// เก็บค่าไว้ใน bool โดยส่งคืนค่าก่อนหน้า
    ///
    /// `swap` รับอาร์กิวเมนต์ [`Ordering`] ซึ่งอธิบายลำดับความจำของการดำเนินการนี้โหมดการสั่งซื้อทั้งหมดเป็นไปได้
    /// โปรดทราบว่าการใช้ [`Acquire`] ทำให้ส่วนจัดเก็บของการดำเนินการนี้ [`Relaxed`] และการใช้ [`Release`] ทำให้ส่วนโหลด [`Relaxed`]
    ///
    ///
    /// **Note:** วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมบน `u8`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // ความปลอดภัย: การแข่งขันข้อมูลถูกป้องกันโดยภายในปรมาณู
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// เก็บค่าไว้ใน [`bool`] หากค่าปัจจุบันเหมือนกับค่า `current`
    ///
    /// ค่าที่ส่งคืนจะเป็นค่าก่อนหน้าเสมอหากมีค่าเท่ากับ `current` แสดงว่ามีการอัปเดตค่า
    ///
    /// `compare_and_swap` ยังใช้อาร์กิวเมนต์ [`Ordering`] ซึ่งอธิบายลำดับความจำของการดำเนินการนี้
    /// สังเกตว่าแม้ว่าจะใช้ [`AcqRel`] การดำเนินการอาจล้มเหลวและด้วยเหตุนี้เพียงแค่ทำการโหลด `Acquire` แต่ไม่มีความหมาย `Release`
    /// การใช้ [`Acquire`] ทำให้ส่วนจัดเก็บของการดำเนินการนี้ [`Relaxed`] ถ้าเกิดขึ้นและการใช้ [`Release`] ทำให้ส่วนโหลด [`Relaxed`]
    ///
    /// **Note:** วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมบน `u8`
    ///
    /// # การย้ายข้อมูลไปยัง `compare_exchange` และ `compare_exchange_weak`
    ///
    /// `compare_and_swap` เทียบเท่ากับ `compare_exchange` โดยมีการแม็พต่อไปนี้สำหรับการจัดลำดับหน่วยความจำ:
    ///
    /// ต้นฉบับ |ความสำเร็จ |ความล้มเหลว
    /// -------- | ------- | -------
    /// ผ่อนคลาย |ผ่อนคลาย |การได้มาแบบผ่อนคลาย |รับ |รับรุ่น |ปล่อย |AcqRel ที่ผ่อนคลาย |AcqRel |รับ SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` ได้รับอนุญาตให้ล้มเหลวอย่างปลอมแปลงแม้ว่าการเปรียบเทียบจะประสบความสำเร็จซึ่งทำให้คอมไพเลอร์สร้างรหัสแอสเซมบลีที่ดีขึ้นเมื่อใช้การเปรียบเทียบและสลับในลูป
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// เก็บค่าไว้ใน [`bool`] หากค่าปัจจุบันเหมือนกับค่า `current`
    ///
    /// ค่าที่ส่งคืนเป็นผลลัพธ์ที่ระบุว่าค่าใหม่ถูกเขียนและมีค่าก่อนหน้าหรือไม่
    /// เมื่อประสบความสำเร็จค่านี้รับประกันว่าจะเท่ากับ `current`
    ///
    /// `compare_exchange` ใช้อาร์กิวเมนต์ [`Ordering`] สองอาร์กิวเมนต์เพื่ออธิบายลำดับความจำของการดำเนินการนี้
    /// `success` อธิบายลำดับที่จำเป็นสำหรับการดำเนินการอ่านแก้ไข-เขียนที่เกิดขึ้นหากการเปรียบเทียบกับ `current` ประสบความสำเร็จ
    /// `failure` อธิบายลำดับที่จำเป็นสำหรับการดำเนินการโหลดที่เกิดขึ้นเมื่อการเปรียบเทียบล้มเหลว
    /// การใช้ [`Acquire`] เป็นลำดับความสำเร็จทำให้การจัดเก็บเป็นส่วนหนึ่งของการดำเนินการนี้ [`Relaxed`] และการใช้ [`Release`] ทำให้การโหลด [`Relaxed`] สำเร็จ
    ///
    /// ลำดับความล้มเหลวสามารถเป็น [`SeqCst`], [`Acquire`] หรือ [`Relaxed`] เท่านั้นและต้องเทียบเท่าหรืออ่อนกว่าลำดับความสำเร็จ
    ///
    /// **Note:** วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมบน `u8`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // ความปลอดภัย: การแข่งขันข้อมูลถูกป้องกันโดยภายในปรมาณู
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// เก็บค่าไว้ใน [`bool`] หากค่าปัจจุบันเหมือนกับค่า `current`
    ///
    /// ซึ่งแตกต่างจาก [`AtomicBool::compare_exchange`] ฟังก์ชันนี้ได้รับอนุญาตให้ล้มเหลวอย่างปลอม ๆ แม้ว่าการเปรียบเทียบจะสำเร็จซึ่งอาจส่งผลให้โค้ดมีประสิทธิภาพมากขึ้นในบางแพลตฟอร์ม
    ///
    /// ค่าที่ส่งคืนเป็นผลลัพธ์ที่ระบุว่าค่าใหม่ถูกเขียนและมีค่าก่อนหน้าหรือไม่
    ///
    /// `compare_exchange_weak` ใช้อาร์กิวเมนต์ [`Ordering`] สองอาร์กิวเมนต์เพื่ออธิบายลำดับความจำของการดำเนินการนี้
    /// `success` อธิบายลำดับที่จำเป็นสำหรับการดำเนินการอ่านแก้ไข-เขียนที่เกิดขึ้นหากการเปรียบเทียบกับ `current` ประสบความสำเร็จ
    /// `failure` อธิบายลำดับที่จำเป็นสำหรับการดำเนินการโหลดที่เกิดขึ้นเมื่อการเปรียบเทียบล้มเหลว
    /// การใช้ [`Acquire`] เป็นลำดับความสำเร็จทำให้การจัดเก็บเป็นส่วนหนึ่งของการดำเนินการนี้ [`Relaxed`] และการใช้ [`Release`] ทำให้การโหลด [`Relaxed`] สำเร็จ
    /// ลำดับความล้มเหลวสามารถเป็น [`SeqCst`], [`Acquire`] หรือ [`Relaxed`] เท่านั้นและต้องเทียบเท่าหรืออ่อนกว่าลำดับความสำเร็จ
    ///
    /// **Note:** วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมบน `u8`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // ความปลอดภัย: การแข่งขันข้อมูลถูกป้องกันโดยภายในปรมาณู
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Logical "and" พร้อมค่าบูลีน
    ///
    /// ดำเนินการ "and" เชิงตรรกะกับค่าปัจจุบันและอาร์กิวเมนต์ `val` และตั้งค่าใหม่เป็นผลลัพธ์
    ///
    /// ส่งคืนค่าก่อนหน้า
    ///
    /// `fetch_and` รับอาร์กิวเมนต์ [`Ordering`] ซึ่งอธิบายลำดับความจำของการดำเนินการนี้โหมดการสั่งซื้อทั้งหมดเป็นไปได้
    /// โปรดทราบว่าการใช้ [`Acquire`] ทำให้ส่วนจัดเก็บของการดำเนินการนี้ [`Relaxed`] และการใช้ [`Release`] ทำให้ส่วนโหลด [`Relaxed`]
    ///
    ///
    /// **Note:** วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมบน `u8`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // ความปลอดภัย: การแข่งขันข้อมูลถูกป้องกันโดยภายในปรมาณู
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Logical "nand" พร้อมค่าบูลีน
    ///
    /// ดำเนินการ "nand" เชิงตรรกะกับค่าปัจจุบันและอาร์กิวเมนต์ `val` และตั้งค่าใหม่เป็นผลลัพธ์
    ///
    /// ส่งคืนค่าก่อนหน้า
    ///
    /// `fetch_nand` รับอาร์กิวเมนต์ [`Ordering`] ซึ่งอธิบายลำดับความจำของการดำเนินการนี้โหมดการสั่งซื้อทั้งหมดเป็นไปได้
    /// โปรดทราบว่าการใช้ [`Acquire`] ทำให้ส่วนจัดเก็บของการดำเนินการนี้ [`Relaxed`] และการใช้ [`Release`] ทำให้ส่วนโหลด [`Relaxed`]
    ///
    ///
    /// **Note:** วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมบน `u8`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // เราไม่สามารถใช้ atomic_nand ที่นี่ได้เนื่องจากอาจส่งผลให้ bool มีค่าที่ไม่ถูกต้อง
        // สิ่งนี้เกิดขึ้นเนื่องจากการดำเนินการของอะตอมทำด้วยจำนวนเต็ม 8 บิตภายในซึ่งจะตั้งค่า 7 บิตบน
        //
        // ดังนั้นเราจึงใช้ fetch_xor หรือ swap แทน
        if val {
            // ! (x&true)== !x เราต้องสลับ bool
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true เราต้องตั้งค่า bool เป็น true
            //
            self.swap(true, order)
        }
    }

    /// Logical "or" พร้อมค่าบูลีน
    ///
    /// ดำเนินการ "or" เชิงตรรกะกับค่าปัจจุบันและอาร์กิวเมนต์ `val` และตั้งค่าใหม่เป็นผลลัพธ์
    ///
    /// ส่งคืนค่าก่อนหน้า
    ///
    /// `fetch_or` รับอาร์กิวเมนต์ [`Ordering`] ซึ่งอธิบายลำดับความจำของการดำเนินการนี้โหมดการสั่งซื้อทั้งหมดเป็นไปได้
    /// โปรดทราบว่าการใช้ [`Acquire`] ทำให้ส่วนจัดเก็บของการดำเนินการนี้ [`Relaxed`] และการใช้ [`Release`] ทำให้ส่วนโหลด [`Relaxed`]
    ///
    ///
    /// **Note:** วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมบน `u8`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // ความปลอดภัย: การแข่งขันข้อมูลถูกป้องกันโดยภายในปรมาณู
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Logical "xor" พร้อมค่าบูลีน
    ///
    /// ดำเนินการ "xor" เชิงตรรกะกับค่าปัจจุบันและอาร์กิวเมนต์ `val` และตั้งค่าใหม่เป็นผลลัพธ์
    ///
    /// ส่งคืนค่าก่อนหน้า
    ///
    /// `fetch_xor` รับอาร์กิวเมนต์ [`Ordering`] ซึ่งอธิบายลำดับความจำของการดำเนินการนี้โหมดการสั่งซื้อทั้งหมดเป็นไปได้
    /// โปรดทราบว่าการใช้ [`Acquire`] ทำให้ส่วนจัดเก็บของการดำเนินการนี้ [`Relaxed`] และการใช้ [`Release`] ทำให้ส่วนโหลด [`Relaxed`]
    ///
    ///
    /// **Note:** วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมบน `u8`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // ความปลอดภัย: การแข่งขันข้อมูลถูกป้องกันโดยภายในปรมาณู
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// ส่งกลับตัวชี้ที่ไม่สามารถเปลี่ยนแปลงได้ไปยัง [`bool`] ที่อยู่ภายใต้
    ///
    /// การอ่านและเขียนที่ไม่ใช่อะตอมในจำนวนเต็มผลลัพธ์อาจเป็นการแย่งชิงข้อมูล
    /// วิธีนี้มีประโยชน์มากสำหรับ FFI โดยที่ลายเซ็นของฟังก์ชันอาจใช้ `*mut bool` แทน `&AtomicBool`
    ///
    /// การส่งคืนตัวชี้ `*mut` จากการอ้างอิงที่ใช้ร่วมกันไปยังอะตอมนี้มีความปลอดภัยเนื่องจากชนิดของอะตอมทำงานร่วมกับความไม่แน่นอนภายใน
    /// การแก้ไขทั้งหมดของอะตอมจะเปลี่ยนค่าผ่านการอ้างอิงที่ใช้ร่วมกันและสามารถทำได้อย่างปลอดภัยตราบเท่าที่พวกเขาใช้การดำเนินการของอะตอม
    /// การใช้ตัวชี้ดิบที่ส่งคืนใด ๆ จำเป็นต้องใช้บล็อก `unsafe` และยังคงต้องรักษาข้อ จำกัด เดิม: การดำเนินการกับมันต้องเป็นแบบปรมาณู
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// ดึงค่าและใช้ฟังก์ชันกับค่าที่ส่งคืนค่าใหม่ที่เป็นทางเลือกส่งคืน `Result` ของ `Ok(previous_value)` หากฟังก์ชันส่งคืน `Some(_)` มิฉะนั้น `Err(previous_value)`
    ///
    /// Note: สิ่งนี้อาจเรียกใช้ฟังก์ชันหลายครั้งหากค่ามีการเปลี่ยนแปลงจากเธรดอื่นในระหว่างนี้ตราบใดที่ฟังก์ชันส่งคืนค่า `Some(_)` แต่ฟังก์ชันจะถูกนำไปใช้เพียงครั้งเดียวกับค่าที่เก็บไว้
    ///
    ///
    /// `fetch_update` ใช้อาร์กิวเมนต์ [`Ordering`] สองอาร์กิวเมนต์เพื่ออธิบายลำดับความจำของการดำเนินการนี้
    /// ลำดับแรกอธิบายถึงลำดับที่จำเป็นเมื่อการดำเนินการสำเร็จในที่สุดในขณะที่ลำดับที่สองอธิบายถึงลำดับที่จำเป็นสำหรับการโหลด
    /// สิ่งเหล่านี้สอดคล้องกับลำดับความสำเร็จและความล้มเหลวของ [`AtomicBool::compare_exchange`] ตามลำดับ
    ///
    /// การใช้ [`Acquire`] เป็นลำดับความสำเร็จทำให้การจัดเก็บเป็นส่วนหนึ่งของการดำเนินการนี้ [`Relaxed`] และการใช้ [`Release`] ทำให้การโหลด [`Relaxed`] สำเร็จขั้นสุดท้าย
    /// ลำดับการโหลด (failed) สามารถเป็น [`SeqCst`], [`Acquire`] หรือ [`Relaxed`] เท่านั้นและต้องเทียบเท่าหรืออ่อนกว่าลำดับความสำเร็จ
    ///
    /// **Note:** วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมบน `u8`
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// สร้าง `AtomicPtr` ใหม่
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// ส่งคืนการอ้างอิงที่ไม่แน่นอนไปยังตัวชี้ที่อยู่ข้างใต้
    ///
    /// สิ่งนี้ปลอดภัยเนื่องจากการอ้างอิงที่เปลี่ยนแปลงได้รับประกันว่าไม่มีเธรดอื่น ๆ ที่เข้าถึงข้อมูลปรมาณูพร้อมกัน
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// รับการเข้าถึงอะตอมไปยังตัวชี้
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - การอ้างอิงที่ไม่แน่นอนรับประกันความเป็นเจ้าของที่ไม่ซ้ำกัน
        //  - การจัดตำแหน่งของ `*mut T` และ `Self` จะเหมือนกันในทุกแพลตฟอร์มที่รองรับโดย rust ตามที่ตรวจสอบแล้วข้างต้น
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// ใช้อะตอมและส่งคืนค่าที่มีอยู่
    ///
    /// สิ่งนี้ปลอดภัยเนื่องจากการส่ง `self` ตามค่าจะรับประกันว่าไม่มีเธรดอื่น ๆ ที่เข้าถึงข้อมูลปรมาณูพร้อมกัน
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// โหลดค่าจากตัวชี้
    ///
    /// `load` รับอาร์กิวเมนต์ [`Ordering`] ซึ่งอธิบายลำดับความจำของการดำเนินการนี้
    /// ค่าที่เป็นไปได้คือ [`SeqCst`], [`Acquire`] และ [`Relaxed`]
    ///
    /// # Panics
    ///
    /// Panics ถ้า `order` คือ [`Release`] หรือ [`AcqRel`]
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // ความปลอดภัย: การแข่งขันข้อมูลถูกป้องกันโดยภายในปรมาณู
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// เก็บค่าไว้ในตัวชี้
    ///
    /// `store` รับอาร์กิวเมนต์ [`Ordering`] ซึ่งอธิบายลำดับความจำของการดำเนินการนี้
    /// ค่าที่เป็นไปได้คือ [`SeqCst`], [`Release`] และ [`Relaxed`]
    ///
    /// # Panics
    ///
    /// Panics ถ้า `order` คือ [`Acquire`] หรือ [`AcqRel`]
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // ความปลอดภัย: การแข่งขันข้อมูลถูกป้องกันโดยภายในปรมาณู
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// เก็บค่าไว้ในตัวชี้โดยส่งคืนค่าก่อนหน้า
    ///
    /// `swap` รับอาร์กิวเมนต์ [`Ordering`] ซึ่งอธิบายลำดับความจำของการดำเนินการนี้โหมดการสั่งซื้อทั้งหมดเป็นไปได้
    /// โปรดทราบว่าการใช้ [`Acquire`] ทำให้ส่วนจัดเก็บของการดำเนินการนี้ [`Relaxed`] และการใช้ [`Release`] ทำให้ส่วนโหลด [`Relaxed`]
    ///
    ///
    /// **Note:** วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมบนพอยน์เตอร์
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // ความปลอดภัย: การแข่งขันข้อมูลถูกป้องกันโดยภายในปรมาณู
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// เก็บค่าไว้ในตัวชี้หากค่าปัจจุบันเหมือนกับค่า `current`
    ///
    /// ค่าที่ส่งคืนจะเป็นค่าก่อนหน้าเสมอหากมีค่าเท่ากับ `current` แสดงว่ามีการอัปเดตค่า
    ///
    /// `compare_and_swap` ยังใช้อาร์กิวเมนต์ [`Ordering`] ซึ่งอธิบายลำดับความจำของการดำเนินการนี้
    /// สังเกตว่าแม้ว่าจะใช้ [`AcqRel`] การดำเนินการอาจล้มเหลวและด้วยเหตุนี้เพียงแค่ทำการโหลด `Acquire` แต่ไม่มีความหมาย `Release`
    /// การใช้ [`Acquire`] ทำให้ส่วนจัดเก็บของการดำเนินการนี้ [`Relaxed`] ถ้าเกิดขึ้นและการใช้ [`Release`] ทำให้ส่วนโหลด [`Relaxed`]
    ///
    /// **Note:** วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมบนพอยน์เตอร์
    ///
    /// # การย้ายข้อมูลไปยัง `compare_exchange` และ `compare_exchange_weak`
    ///
    /// `compare_and_swap` เทียบเท่ากับ `compare_exchange` โดยมีการแม็พต่อไปนี้สำหรับการจัดลำดับหน่วยความจำ:
    ///
    /// ต้นฉบับ |ความสำเร็จ |ความล้มเหลว
    /// -------- | ------- | -------
    /// ผ่อนคลาย |ผ่อนคลาย |การได้มาแบบผ่อนคลาย |รับ |รับรุ่น |ปล่อย |AcqRel ที่ผ่อนคลาย |AcqRel |รับ SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` ได้รับอนุญาตให้ล้มเหลวอย่างปลอมแปลงแม้ว่าการเปรียบเทียบจะประสบความสำเร็จซึ่งทำให้คอมไพเลอร์สร้างรหัสแอสเซมบลีที่ดีขึ้นเมื่อใช้การเปรียบเทียบและสลับในลูป
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// เก็บค่าไว้ในตัวชี้หากค่าปัจจุบันเหมือนกับค่า `current`
    ///
    /// ค่าที่ส่งคืนเป็นผลลัพธ์ที่ระบุว่าค่าใหม่ถูกเขียนและมีค่าก่อนหน้าหรือไม่
    /// เมื่อประสบความสำเร็จค่านี้รับประกันว่าจะเท่ากับ `current`
    ///
    /// `compare_exchange` ใช้อาร์กิวเมนต์ [`Ordering`] สองอาร์กิวเมนต์เพื่ออธิบายลำดับความจำของการดำเนินการนี้
    /// `success` อธิบายลำดับที่จำเป็นสำหรับการดำเนินการอ่านแก้ไข-เขียนที่เกิดขึ้นหากการเปรียบเทียบกับ `current` ประสบความสำเร็จ
    /// `failure` อธิบายลำดับที่จำเป็นสำหรับการดำเนินการโหลดที่เกิดขึ้นเมื่อการเปรียบเทียบล้มเหลว
    /// การใช้ [`Acquire`] เป็นลำดับความสำเร็จทำให้การจัดเก็บเป็นส่วนหนึ่งของการดำเนินการนี้ [`Relaxed`] และการใช้ [`Release`] ทำให้การโหลด [`Relaxed`] สำเร็จ
    ///
    /// ลำดับความล้มเหลวสามารถเป็น [`SeqCst`], [`Acquire`] หรือ [`Relaxed`] เท่านั้นและต้องเทียบเท่าหรืออ่อนกว่าลำดับความสำเร็จ
    ///
    /// **Note:** วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมบนพอยน์เตอร์
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // ความปลอดภัย: การแข่งขันข้อมูลถูกป้องกันโดยภายในปรมาณู
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// เก็บค่าไว้ในตัวชี้หากค่าปัจจุบันเหมือนกับค่า `current`
    ///
    /// ซึ่งแตกต่างจาก [`AtomicPtr::compare_exchange`] ฟังก์ชันนี้ได้รับอนุญาตให้ล้มเหลวอย่างปลอม ๆ แม้ว่าการเปรียบเทียบจะสำเร็จซึ่งอาจส่งผลให้โค้ดมีประสิทธิภาพมากขึ้นในบางแพลตฟอร์ม
    ///
    /// ค่าที่ส่งคืนเป็นผลลัพธ์ที่ระบุว่าค่าใหม่ถูกเขียนและมีค่าก่อนหน้าหรือไม่
    ///
    /// `compare_exchange_weak` ใช้อาร์กิวเมนต์ [`Ordering`] สองอาร์กิวเมนต์เพื่ออธิบายลำดับความจำของการดำเนินการนี้
    /// `success` อธิบายลำดับที่จำเป็นสำหรับการดำเนินการอ่านแก้ไข-เขียนที่เกิดขึ้นหากการเปรียบเทียบกับ `current` ประสบความสำเร็จ
    /// `failure` อธิบายลำดับที่จำเป็นสำหรับการดำเนินการโหลดที่เกิดขึ้นเมื่อการเปรียบเทียบล้มเหลว
    /// การใช้ [`Acquire`] เป็นลำดับความสำเร็จทำให้การจัดเก็บเป็นส่วนหนึ่งของการดำเนินการนี้ [`Relaxed`] และการใช้ [`Release`] ทำให้การโหลด [`Relaxed`] สำเร็จ
    /// ลำดับความล้มเหลวสามารถเป็น [`SeqCst`], [`Acquire`] หรือ [`Relaxed`] เท่านั้นและต้องเทียบเท่าหรืออ่อนกว่าลำดับความสำเร็จ
    ///
    /// **Note:** วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมบนพอยน์เตอร์
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // ความปลอดภัย: ภายในนี้ไม่ปลอดภัยเนื่องจากทำงานบนตัวชี้ดิบ
        // แต่เรารู้แน่นอนว่าตัวชี้นั้นถูกต้อง (เราเพิ่งได้รับจาก `UnsafeCell` ที่เรามีโดยอ้างอิง) และการทำงานของอะตอมเองทำให้เราสามารถเปลี่ยนเนื้อหา `UnsafeCell` ได้อย่างปลอดภัย
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// ดึงค่าและใช้ฟังก์ชันกับค่าที่ส่งคืนค่าใหม่ที่เป็นทางเลือกส่งคืน `Result` ของ `Ok(previous_value)` หากฟังก์ชันส่งคืน `Some(_)` มิฉะนั้น `Err(previous_value)`
    ///
    /// Note: สิ่งนี้อาจเรียกใช้ฟังก์ชันหลายครั้งหากค่ามีการเปลี่ยนแปลงจากเธรดอื่นในระหว่างนี้ตราบใดที่ฟังก์ชันส่งคืนค่า `Some(_)` แต่ฟังก์ชันจะถูกนำไปใช้เพียงครั้งเดียวกับค่าที่เก็บไว้
    ///
    ///
    /// `fetch_update` ใช้อาร์กิวเมนต์ [`Ordering`] สองอาร์กิวเมนต์เพื่ออธิบายลำดับความจำของการดำเนินการนี้
    /// ลำดับแรกอธิบายถึงลำดับที่จำเป็นเมื่อการดำเนินการสำเร็จในที่สุดในขณะที่ลำดับที่สองอธิบายถึงลำดับที่จำเป็นสำหรับการโหลด
    /// สิ่งเหล่านี้สอดคล้องกับลำดับความสำเร็จและความล้มเหลวของ [`AtomicPtr::compare_exchange`] ตามลำดับ
    ///
    /// การใช้ [`Acquire`] เป็นลำดับความสำเร็จทำให้การจัดเก็บเป็นส่วนหนึ่งของการดำเนินการนี้ [`Relaxed`] และการใช้ [`Release`] ทำให้การโหลด [`Relaxed`] สำเร็จขั้นสุดท้าย
    /// ลำดับการโหลด (failed) สามารถเป็น [`SeqCst`], [`Acquire`] หรือ [`Relaxed`] เท่านั้นและต้องเทียบเท่าหรืออ่อนกว่าลำดับความสำเร็จ
    ///
    /// **Note:** วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมบนพอยน์เตอร์
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// แปลง `bool` เป็น `AtomicBool`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // มาโครนี้จะไม่มีการใช้งานในบางสถาปัตยกรรม
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// ประเภทจำนวนเต็มซึ่งสามารถแบ่งใช้ระหว่างเธรดได้อย่างปลอดภัย
        ///
        /// ประเภทนี้มีการแทนค่าในหน่วยความจำเช่นเดียวกับประเภทจำนวนเต็มพื้นฐาน ["
        ///
        #[doc = $s_int_type]
        /// `].
        /// สำหรับข้อมูลเพิ่มเติมเกี่ยวกับความแตกต่างระหว่างประเภทอะตอมและประเภทที่ไม่ใช่อะตอมตลอดจนข้อมูลเกี่ยวกับการพกพาประเภทนี้โปรดดู [module-level documentation]
        ///
        ///
        /// **Note:** ประเภทนี้มีให้เฉพาะบนแพลตฟอร์มที่รองรับโหลดปรมาณูและร้านค้าของ ["
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// จำนวนเต็มอะตอมเริ่มต้นเป็น `0`
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // ส่งถูกนำไปใช้โดยปริยาย
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// สร้างจำนวนเต็มอะตอมใหม่
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// ส่งคืนการอ้างอิงที่ไม่แน่นอนไปยังจำนวนเต็มพื้นฐาน
            ///
            /// สิ่งนี้ปลอดภัยเนื่องจากการอ้างอิงที่เปลี่ยนแปลงได้รับประกันว่าไม่มีเธรดอื่น ๆ ที่เข้าถึงข้อมูลปรมาณูพร้อมกัน
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// ให้ mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - การอ้างอิงที่ไม่แน่นอนรับประกันความเป็นเจ้าของที่ไม่ซ้ำกัน
                //  - การจัดตำแหน่งของ `$int_type` และ `Self` จะเหมือนกันตามที่สัญญาไว้โดย $cfg_align และได้รับการยืนยันข้างต้น
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// ใช้อะตอมและส่งคืนค่าที่มีอยู่
            ///
            /// สิ่งนี้ปลอดภัยเนื่องจากการส่ง `self` ตามค่าจะรับประกันว่าไม่มีเธรดอื่น ๆ ที่เข้าถึงข้อมูลปรมาณูพร้อมกัน
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// โหลดค่าจากจำนวนเต็มอะตอม
            ///
            /// `load` รับอาร์กิวเมนต์ [`Ordering`] ซึ่งอธิบายลำดับความจำของการดำเนินการนี้
            /// ค่าที่เป็นไปได้คือ [`SeqCst`], [`Acquire`] และ [`Relaxed`]
            ///
            /// # Panics
            ///
            /// Panics ถ้า `order` คือ [`Release`] หรือ [`AcqRel`]
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // ความปลอดภัย: การแข่งขันข้อมูลถูกป้องกันโดยภายในปรมาณู
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// เก็บค่าเป็นจำนวนเต็มอะตอม
            ///
            /// `store` รับอาร์กิวเมนต์ [`Ordering`] ซึ่งอธิบายลำดับความจำของการดำเนินการนี้
            ///  ค่าที่เป็นไปได้คือ [`SeqCst`], [`Release`] และ [`Relaxed`]
            ///
            /// # Panics
            ///
            /// Panics ถ้า `order` คือ [`Acquire`] หรือ [`AcqRel`]
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // ความปลอดภัย: การแข่งขันข้อมูลถูกป้องกันโดยภายในปรมาณู
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// เก็บค่าเป็นจำนวนเต็มอะตอมโดยส่งคืนค่าก่อนหน้า
            ///
            /// `swap` รับอาร์กิวเมนต์ [`Ordering`] ซึ่งอธิบายลำดับความจำของการดำเนินการนี้โหมดการสั่งซื้อทั้งหมดเป็นไปได้
            /// โปรดทราบว่าการใช้ [`Acquire`] ทำให้ส่วนจัดเก็บของการดำเนินการนี้ [`Relaxed`] และการใช้ [`Release`] ทำให้ส่วนโหลด [`Relaxed`]
            ///
            ///
            /// **หมายเหตุ**: วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมเท่านั้น
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // ความปลอดภัย: การแข่งขันข้อมูลถูกป้องกันโดยภายในปรมาณู
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// เก็บค่าเป็นจำนวนเต็มอะตอมหากค่าปัจจุบันเหมือนกับค่า `current`
            ///
            /// ค่าที่ส่งคืนจะเป็นค่าก่อนหน้าเสมอหากมีค่าเท่ากับ `current` แสดงว่ามีการอัปเดตค่า
            ///
            /// `compare_and_swap` ยังใช้อาร์กิวเมนต์ [`Ordering`] ซึ่งอธิบายลำดับความจำของการดำเนินการนี้
            /// สังเกตว่าแม้ว่าจะใช้ [`AcqRel`] การดำเนินการอาจล้มเหลวและด้วยเหตุนี้เพียงแค่ทำการโหลด `Acquire` แต่ไม่มีความหมาย `Release`
            ///
            /// การใช้ [`Acquire`] ทำให้ส่วนจัดเก็บของการดำเนินการนี้ [`Relaxed`] ถ้าเกิดขึ้นและการใช้ [`Release`] ทำให้ส่วนโหลด [`Relaxed`]
            ///
            /// **หมายเหตุ**: วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมเท่านั้น
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # การย้ายข้อมูลไปยัง `compare_exchange` และ `compare_exchange_weak`
            ///
            /// `compare_and_swap` เทียบเท่ากับ `compare_exchange` โดยมีการแม็พต่อไปนี้สำหรับการจัดลำดับหน่วยความจำ:
            ///
            /// ต้นฉบับ |ความสำเร็จ |ความล้มเหลว
            /// -------- | ------- | -------
            /// ผ่อนคลาย |ผ่อนคลาย |การได้มาแบบผ่อนคลาย |รับ |รับรุ่น |ปล่อย |AcqRel ที่ผ่อนคลาย |AcqRel |รับ SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` ได้รับอนุญาตให้ล้มเหลวอย่างปลอมแปลงแม้ว่าการเปรียบเทียบจะประสบความสำเร็จซึ่งทำให้คอมไพเลอร์สร้างรหัสแอสเซมบลีที่ดีขึ้นเมื่อใช้การเปรียบเทียบและสลับในลูป
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// เก็บค่าเป็นจำนวนเต็มอะตอมหากค่าปัจจุบันเหมือนกับค่า `current`
            ///
            /// ค่าที่ส่งคืนเป็นผลลัพธ์ที่ระบุว่าค่าใหม่ถูกเขียนและมีค่าก่อนหน้าหรือไม่
            /// เมื่อประสบความสำเร็จค่านี้รับประกันว่าจะเท่ากับ `current`
            ///
            /// `compare_exchange` ใช้อาร์กิวเมนต์ [`Ordering`] สองอาร์กิวเมนต์เพื่ออธิบายลำดับความจำของการดำเนินการนี้
            /// `success` อธิบายลำดับที่จำเป็นสำหรับการดำเนินการอ่านแก้ไข-เขียนที่เกิดขึ้นหากการเปรียบเทียบกับ `current` ประสบความสำเร็จ
            /// `failure` อธิบายลำดับที่จำเป็นสำหรับการดำเนินการโหลดที่เกิดขึ้นเมื่อการเปรียบเทียบล้มเหลว
            /// การใช้ [`Acquire`] เป็นลำดับความสำเร็จทำให้การจัดเก็บเป็นส่วนหนึ่งของการดำเนินการนี้ [`Relaxed`] และการใช้ [`Release`] ทำให้การโหลด [`Relaxed`] สำเร็จ
            ///
            /// ลำดับความล้มเหลวสามารถเป็น [`SeqCst`], [`Acquire`] หรือ [`Relaxed`] เท่านั้นและต้องเทียบเท่าหรืออ่อนกว่าลำดับความสำเร็จ
            ///
            /// **หมายเหตุ**: วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมเท่านั้น
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // ความปลอดภัย: การแข่งขันข้อมูลถูกป้องกันโดยภายในปรมาณู
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// เก็บค่าเป็นจำนวนเต็มอะตอมหากค่าปัจจุบันเหมือนกับค่า `current`
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// ฟังก์ชันนี้ได้รับอนุญาตให้ล้มเหลวอย่างปลอม ๆ แม้ว่าการเปรียบเทียบจะประสบความสำเร็จซึ่งอาจส่งผลให้โค้ดมีประสิทธิภาพมากขึ้นในบางแพลตฟอร์ม
            /// ค่าที่ส่งคืนเป็นผลลัพธ์ที่ระบุว่าค่าใหม่ถูกเขียนและมีค่าก่อนหน้าหรือไม่
            ///
            /// `compare_exchange_weak` ใช้อาร์กิวเมนต์ [`Ordering`] สองอาร์กิวเมนต์เพื่ออธิบายลำดับความจำของการดำเนินการนี้
            /// `success` อธิบายลำดับที่จำเป็นสำหรับการดำเนินการอ่านแก้ไข-เขียนที่เกิดขึ้นหากการเปรียบเทียบกับ `current` ประสบความสำเร็จ
            /// `failure` อธิบายลำดับที่จำเป็นสำหรับการดำเนินการโหลดที่เกิดขึ้นเมื่อการเปรียบเทียบล้มเหลว
            /// การใช้ [`Acquire`] เป็นลำดับความสำเร็จทำให้การจัดเก็บเป็นส่วนหนึ่งของการดำเนินการนี้ [`Relaxed`] และการใช้ [`Release`] ทำให้การโหลด [`Relaxed`] สำเร็จ
            ///
            /// ลำดับความล้มเหลวสามารถเป็น [`SeqCst`], [`Acquire`] หรือ [`Relaxed`] เท่านั้นและต้องเทียบเท่าหรืออ่อนกว่าลำดับความสำเร็จ
            ///
            /// **หมายเหตุ**: วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมเท่านั้น
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// ให้ mut แก่= val.load(Ordering::Relaxed);
            /// วน {ให้ใหม่=เก่า * 2;
            ///     ตรงกับ val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // ความปลอดภัย: การแข่งขันข้อมูลถูกป้องกันโดยภายในปรมาณู
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// เพิ่มให้กับค่าปัจจุบันโดยส่งคืนค่าก่อนหน้า
            ///
            /// การดำเนินการนี้ล้อมรอบเมื่อล้น
            ///
            /// `fetch_add` รับอาร์กิวเมนต์ [`Ordering`] ซึ่งอธิบายลำดับความจำของการดำเนินการนี้โหมดการสั่งซื้อทั้งหมดเป็นไปได้
            /// โปรดทราบว่าการใช้ [`Acquire`] ทำให้ส่วนจัดเก็บของการดำเนินการนี้ [`Relaxed`] และการใช้ [`Release`] ทำให้ส่วนโหลด [`Relaxed`]
            ///
            ///
            /// **หมายเหตุ**: วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมเท่านั้น
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // ความปลอดภัย: การแข่งขันข้อมูลถูกป้องกันโดยภายในปรมาณู
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// ลบออกจากค่าปัจจุบันโดยส่งคืนค่าก่อนหน้า
            ///
            /// การดำเนินการนี้ล้อมรอบเมื่อล้น
            ///
            /// `fetch_sub` รับอาร์กิวเมนต์ [`Ordering`] ซึ่งอธิบายลำดับความจำของการดำเนินการนี้โหมดการสั่งซื้อทั้งหมดเป็นไปได้
            /// โปรดทราบว่าการใช้ [`Acquire`] ทำให้ส่วนจัดเก็บของการดำเนินการนี้ [`Relaxed`] และการใช้ [`Release`] ทำให้ส่วนโหลด [`Relaxed`]
            ///
            ///
            /// **หมายเหตุ**: วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมเท่านั้น
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // ความปลอดภัย: การแข่งขันข้อมูลถูกป้องกันโดยภายในปรมาณู
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" พร้อมค่าปัจจุบัน
            ///
            /// ดำเนินการ "and" แบบบิตตามค่าปัจจุบันและอาร์กิวเมนต์ `val` และตั้งค่าใหม่เป็นผลลัพธ์
            ///
            /// ส่งคืนค่าก่อนหน้า
            ///
            /// `fetch_and` รับอาร์กิวเมนต์ [`Ordering`] ซึ่งอธิบายลำดับความจำของการดำเนินการนี้โหมดการสั่งซื้อทั้งหมดเป็นไปได้
            /// โปรดทราบว่าการใช้ [`Acquire`] ทำให้ส่วนจัดเก็บของการดำเนินการนี้ [`Relaxed`] และการใช้ [`Release`] ทำให้ส่วนโหลด [`Relaxed`]
            ///
            ///
            /// **หมายเหตุ**: วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมเท่านั้น
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // ความปลอดภัย: การแข่งขันข้อมูลถูกป้องกันโดยภายในปรมาณู
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" พร้อมค่าปัจจุบัน
            ///
            /// ดำเนินการ "nand" แบบบิตตามค่าปัจจุบันและอาร์กิวเมนต์ `val` และตั้งค่าใหม่เป็นผลลัพธ์
            ///
            /// ส่งคืนค่าก่อนหน้า
            ///
            /// `fetch_nand` รับอาร์กิวเมนต์ [`Ordering`] ซึ่งอธิบายลำดับความจำของการดำเนินการนี้โหมดการสั่งซื้อทั้งหมดเป็นไปได้
            /// โปรดทราบว่าการใช้ [`Acquire`] ทำให้ส่วนจัดเก็บของการดำเนินการนี้ [`Relaxed`] และการใช้ [`Release`] ทำให้ส่วนโหลด [`Relaxed`]
            ///
            ///
            /// **หมายเหตุ**: วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมเท่านั้น
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // ความปลอดภัย: การแข่งขันข้อมูลถูกป้องกันโดยภายในปรมาณู
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" พร้อมค่าปัจจุบัน
            ///
            /// ดำเนินการ "or" แบบบิตตามค่าปัจจุบันและอาร์กิวเมนต์ `val` และตั้งค่าใหม่เป็นผลลัพธ์
            ///
            /// ส่งคืนค่าก่อนหน้า
            ///
            /// `fetch_or` รับอาร์กิวเมนต์ [`Ordering`] ซึ่งอธิบายลำดับความจำของการดำเนินการนี้โหมดการสั่งซื้อทั้งหมดเป็นไปได้
            /// โปรดทราบว่าการใช้ [`Acquire`] ทำให้ส่วนจัดเก็บของการดำเนินการนี้ [`Relaxed`] และการใช้ [`Release`] ทำให้ส่วนโหลด [`Relaxed`]
            ///
            ///
            /// **หมายเหตุ**: วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมเท่านั้น
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // ความปลอดภัย: การแข่งขันข้อมูลถูกป้องกันโดยภายในปรมาณู
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" พร้อมค่าปัจจุบัน
            ///
            /// ดำเนินการ "xor" แบบบิตตามค่าปัจจุบันและอาร์กิวเมนต์ `val` และตั้งค่าใหม่เป็นผลลัพธ์
            ///
            /// ส่งคืนค่าก่อนหน้า
            ///
            /// `fetch_xor` รับอาร์กิวเมนต์ [`Ordering`] ซึ่งอธิบายลำดับความจำของการดำเนินการนี้โหมดการสั่งซื้อทั้งหมดเป็นไปได้
            /// โปรดทราบว่าการใช้ [`Acquire`] ทำให้ส่วนจัดเก็บของการดำเนินการนี้ [`Relaxed`] และการใช้ [`Release`] ทำให้ส่วนโหลด [`Relaxed`]
            ///
            ///
            /// **หมายเหตุ**: วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมเท่านั้น
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // ความปลอดภัย: การแข่งขันข้อมูลถูกป้องกันโดยภายในปรมาณู
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// ดึงค่าและใช้ฟังก์ชันกับค่าที่ส่งคืนค่าใหม่ที่เป็นทางเลือกส่งคืน `Result` ของ `Ok(previous_value)` หากฟังก์ชันส่งคืน `Some(_)` มิฉะนั้น `Err(previous_value)`
            ///
            /// Note: สิ่งนี้อาจเรียกใช้ฟังก์ชันหลายครั้งหากค่ามีการเปลี่ยนแปลงจากเธรดอื่นในระหว่างนี้ตราบใดที่ฟังก์ชันส่งคืนค่า `Some(_)` แต่ฟังก์ชันจะถูกนำไปใช้เพียงครั้งเดียวกับค่าที่เก็บไว้
            ///
            ///
            /// `fetch_update` ใช้อาร์กิวเมนต์ [`Ordering`] สองอาร์กิวเมนต์เพื่ออธิบายลำดับความจำของการดำเนินการนี้
            /// ลำดับแรกอธิบายถึงลำดับที่จำเป็นเมื่อการดำเนินการสำเร็จในที่สุดในขณะที่ลำดับที่สองอธิบายถึงลำดับที่จำเป็นสำหรับการโหลดสิ่งเหล่านี้สอดคล้องกับลำดับความสำเร็จและความล้มเหลวของ
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// การใช้ [`Acquire`] เป็นลำดับความสำเร็จทำให้การจัดเก็บเป็นส่วนหนึ่งของการดำเนินการนี้ [`Relaxed`] และการใช้ [`Release`] ทำให้การโหลด [`Relaxed`] สำเร็จขั้นสุดท้าย
            /// ลำดับการโหลด (failed) สามารถเป็น [`SeqCst`], [`Acquire`] หรือ [`Relaxed`] เท่านั้นและต้องเทียบเท่าหรืออ่อนกว่าลำดับความสำเร็จ
            ///
            /// **หมายเหตุ**: วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมเท่านั้น
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (การสั่งซื้อ: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (การสั่งซื้อ: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// สูงสุดกับค่าปัจจุบัน
            ///
            /// ค้นหาค่าสูงสุดของค่าปัจจุบันและอาร์กิวเมนต์ `val` และตั้งค่าใหม่เป็นผลลัพธ์
            ///
            /// ส่งคืนค่าก่อนหน้า
            ///
            /// `fetch_max` รับอาร์กิวเมนต์ [`Ordering`] ซึ่งอธิบายลำดับความจำของการดำเนินการนี้โหมดการสั่งซื้อทั้งหมดเป็นไปได้
            /// โปรดทราบว่าการใช้ [`Acquire`] ทำให้ส่วนจัดเก็บของการดำเนินการนี้ [`Relaxed`] และการใช้ [`Release`] ทำให้ส่วนโหลด [`Relaxed`]
            ///
            ///
            /// **หมายเหตุ**: วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมเท่านั้น
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// ให้บาร์=42;
            /// ให้ max_foo=foo.fetch_max (บาร์ Ordering::SeqCst).max(bar);
            /// ยืนยัน! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // ความปลอดภัย: การแข่งขันข้อมูลถูกป้องกันโดยภายในปรมาณู
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// ต่ำสุดด้วยค่าปัจจุบัน
            ///
            /// ค้นหาค่าต่ำสุดของค่าปัจจุบันและอาร์กิวเมนต์ `val` และตั้งค่าใหม่เป็นผลลัพธ์
            ///
            /// ส่งคืนค่าก่อนหน้า
            ///
            /// `fetch_min` รับอาร์กิวเมนต์ [`Ordering`] ซึ่งอธิบายลำดับความจำของการดำเนินการนี้โหมดการสั่งซื้อทั้งหมดเป็นไปได้
            /// โปรดทราบว่าการใช้ [`Acquire`] ทำให้ส่วนจัดเก็บของการดำเนินการนี้ [`Relaxed`] และการใช้ [`Release`] ทำให้ส่วนโหลด [`Relaxed`]
            ///
            ///
            /// **หมายเหตุ**: วิธีนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่รองรับการทำงานของอะตอมเท่านั้น
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// ให้บาร์=12;
            /// ให้ min_foo=foo.fetch_min (bar, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // ความปลอดภัย: การแข่งขันข้อมูลถูกป้องกันโดยภายในปรมาณู
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// ส่งกลับตัวชี้ที่ไม่สามารถเปลี่ยนแปลงได้เป็นจำนวนเต็มพื้นฐาน
            ///
            /// การอ่านและเขียนที่ไม่ใช่อะตอมในจำนวนเต็มผลลัพธ์อาจเป็นการแย่งชิงข้อมูล
            /// วิธีนี้ส่วนใหญ่มีประโยชน์สำหรับ FFI ซึ่งอาจใช้ลายเซ็นของฟังก์ชัน
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// การส่งคืนตัวชี้ `*mut` จากการอ้างอิงที่ใช้ร่วมกันไปยังอะตอมนี้มีความปลอดภัยเนื่องจากชนิดของอะตอมทำงานร่วมกับความไม่แน่นอนภายใน
            /// การแก้ไขทั้งหมดของอะตอมจะเปลี่ยนค่าผ่านการอ้างอิงที่ใช้ร่วมกันและสามารถทำได้อย่างปลอดภัยตราบเท่าที่พวกเขาใช้การดำเนินการของอะตอม
            /// การใช้ตัวชี้ดิบที่ส่งคืนใด ๆ จำเป็นต้องใช้บล็อก `unsafe` และยังคงต้องรักษาข้อ จำกัด เดิม: การดำเนินการกับมันต้องเป็นแบบปรมาณู
            ///
            ///
            /// # Examples
            ///
            /// `` ละเว้น (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// ภายนอก "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // ความปลอดภัย: ปลอดภัยตราบเท่าที่ `my_atomic_op` เป็นปรมาณู
            /// ไม่ปลอดภัย {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `atomic_store`
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `atomic_load`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `atomic_swap`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// ส่งคืนค่าก่อนหน้า (เช่น __sync_fetch_and_add)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `atomic_add`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// ส่งคืนค่าก่อนหน้า (เช่น __sync_fetch_and_sub)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `atomic_sub`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `atomic_compare_exchange`
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `atomic_compare_exchange_weak`
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// ส่งคืนค่าสูงสุด (การเปรียบเทียบที่ลงนาม)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// ส่งคืนค่าขั้นต่ำ (การเปรียบเทียบที่ลงนาม)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// ส่งกลับค่าสูงสุด (การเปรียบเทียบที่ไม่ได้ลงชื่อ)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// ส่งกลับค่าต่ำสุด (การเปรียบเทียบที่ไม่ได้ลงชื่อ)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// รั้วอะตอม
///
/// ขึ้นอยู่กับลำดับที่ระบุรั้วป้องกันคอมไพเลอร์และ CPU จากการจัดลำดับการดำเนินการหน่วยความจำบางประเภทรอบ ๆ โดยขึ้นอยู่กับลำดับที่ระบุ
/// ที่สร้างความสัมพันธ์แบบซิงโครไนซ์ระหว่างมันกับการดำเนินการของอะตอมหรือรั้วในเธรดอื่น
///
/// รั้ว 'A' ซึ่งมี (อย่างน้อย) [`Release`] จัดลำดับความหมายซิงโครไนซ์กับรั้ว 'B' ที่มีความหมาย [`Acquire`] (อย่างน้อย) ถ้ามีการดำเนินการ X และ Y ทั้งคู่ทำงานบนวัตถุปรมาณู 'M' ซึ่ง A จะถูกจัดลำดับก่อนหน้า X, Y จะซิงโครไนซ์ก่อนที่ B และ Y จะสังเกตเห็นการเปลี่ยนแปลงเป็น M
/// สิ่งนี้ให้การพึ่งพาที่เกิดขึ้นก่อนระหว่าง A และ B
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// การดำเนินการของอะตอมด้วยความหมาย [`Release`] หรือ [`Acquire`] ยังสามารถซิงโครไนซ์กับรั้ว
///
/// รั้วที่มีลำดับ [`SeqCst`] นอกเหนือจากการมีทั้งความหมาย [`Acquire`] และ [`Release`] แล้วยังมีส่วนร่วมในลำดับโปรแกรมส่วนกลางของการดำเนินการและ/หรือรั้ว [`SeqCst`] อื่น ๆ
///
/// ยอมรับคำสั่ง [`Acquire`], [`Release`], [`AcqRel`] และ [`SeqCst`]
///
/// # Panics
///
/// Panics ถ้า `order` คือ [`Relaxed`]
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // การกีดกันแบบดั้งเดิมที่มีพื้นฐานมาจาก Spinlock
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // รอจนกว่าค่าเก่าคือ `false`
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // รั้วนี้ซิงโครไนซ์กับร้านค้าใน `unlock`
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // ความปลอดภัย: การใช้รั้วอะตอมนั้นปลอดภัย
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// รั้วหน่วยความจำคอมไพเลอร์
///
/// `compiler_fence` ไม่ปล่อยรหัสเครื่องใด ๆ แต่ จำกัด ชนิดของหน่วยความจำที่สั่งให้คอมไพเลอร์ทำใหม่ได้โดยเฉพาะขึ้นอยู่กับความหมาย [`Ordering`] ที่กำหนดคอมไพเลอร์อาจไม่ได้รับอนุญาตจากการย้ายการอ่านหรือเขียนจากก่อนหรือหลังการเรียกไปยังอีกด้านหนึ่งของการเรียกไปที่ `compiler_fence` โปรดทราบว่า **ไม่** ป้องกัน *ฮาร์ดแวร์* จากการสั่งซื้อซ้ำดังกล่าว
///
/// นี่ไม่ใช่ปัญหาในบริบทการดำเนินการแบบเธรดเดียว แต่เมื่อเธรดอื่นอาจปรับเปลี่ยนหน่วยความจำในเวลาเดียวกันจำเป็นต้องมีไพรมารีซิงโครไนซ์ที่แข็งแกร่งกว่าเช่น [`fence`]
///
/// การจัดลำดับใหม่ที่ป้องกันโดยความหมายการจัดลำดับที่แตกต่างกันคือ:
///
///  - ด้วย [`SeqCst`] ไม่อนุญาตให้จัดลำดับการอ่านและเขียนซ้ำในจุดนี้
///  - ด้วย [`Release`] การอ่านและการเขียนก่อนหน้าจะไม่สามารถย้ายผ่านการเขียนที่ตามมาได้
///  - ด้วย [`Acquire`] การอ่านและการเขียนที่ตามมาจะไม่สามารถย้ายไปข้างหน้าการอ่านก่อนหน้านี้ได้
///  - ด้วย [`AcqRel`] กฎทั้งสองข้อข้างต้นถูกบังคับใช้
///
/// `compiler_fence` โดยทั่วไปมีประโยชน์สำหรับการป้องกันเธรดจากการแข่ง *ด้วยตัวมันเอง* เท่านั้นนั่นคือถ้าเธรดหนึ่ง ๆ กำลังเรียกใช้โค้ดชิ้นเดียวและถูกขัดจังหวะและเริ่มเรียกใช้โค้ดที่อื่น (ในขณะที่ยังคงอยู่ในเธรดเดียวกันและแนวคิดยังคงอยู่บนคอร์เดียวกัน)ในโปรแกรมทั่วไปสิ่งนี้สามารถเกิดขึ้นได้ก็ต่อเมื่อมีการลงทะเบียนตัวจัดการสัญญาณ
/// ในโค้ดระดับต่ำมากขึ้นสถานการณ์เช่นนี้อาจเกิดขึ้นได้เมื่อจัดการการขัดจังหวะเมื่อใช้เธรดสีเขียวที่มีการปล่อยล่วงหน้าเป็นต้น
/// ผู้อ่านที่อยากรู้อยากเห็นควรอ่านการอภิปรายของเคอร์เนล Linux ของ [memory barriers]
///
/// # Panics
///
/// Panics ถ้า `order` คือ [`Relaxed`]
///
/// # Examples
///
/// หากไม่มี `compiler_fence` `assert_eq!` ในรหัสต่อไปนี้ *ไม่* รับประกันว่าจะประสบความสำเร็จแม้ว่าทุกอย่างจะเกิดขึ้นในเธรดเดียว
/// หากต้องการดูสาเหตุโปรดจำไว้ว่าคอมไพเลอร์สามารถเปลี่ยนร้านค้าเป็น `IMPORTANT_VARIABLE` และ `IS_READ` ได้ฟรีเนื่องจากทั้งคู่เป็น `Ordering::Relaxed` หากเป็นเช่นนั้นและตัวจัดการสัญญาณถูกเรียกใช้ทันทีหลังจากที่อัปเดต `IS_READY` ตัวจัดการสัญญาณจะเห็น `IS_READY=1` แต่ `IMPORTANT_VARIABLE=0`
/// การใช้ `compiler_fence` แก้ไขสถานการณ์นี้
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // ป้องกันไม่ให้การเขียนก่อนหน้านี้เคลื่อนไปไกลกว่าจุดนี้
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // ความปลอดภัย: การใช้รั้วอะตอมนั้นปลอดภัย
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// ส่งสัญญาณให้โปรเซสเซอร์ทราบว่าอยู่ในวงรอบหมุนที่รอไม่ว่าง ("สปินล็อก")
///
/// ฟังก์ชันนี้เลิกใช้งานแล้วโดยสนับสนุน [`hint::spin_loop`]
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}