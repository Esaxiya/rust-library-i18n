#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! ยูทิลิตี้ที่เกี่ยวข้องกับการเชื่อมโยงฟังก์ชัน (FFI) ต่างประเทศ

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// เทียบเท่ากับประเภท `void` ของ C เมื่อใช้เป็น [pointer]
///
/// โดยพื้นฐานแล้ว `*const c_void` เทียบเท่ากับ `const void*` ของ C และ `*mut c_void` เทียบเท่ากับ `void*` ของ C
/// ที่กล่าวว่านี่คือ *ไม่* เหมือนกับประเภทการส่งคืน `void` ของ C ซึ่งเป็นประเภท `()` ของ Rust
///
/// ในการสร้างแบบจำลองพอยน์เตอร์เป็นชนิดทึบแสงใน FFI จนกว่า `extern type` จะเสถียรขอแนะนำให้ใช้ newtype wrapper รอบอาร์เรย์ไบต์ว่าง
///
/// ดู [Nomicon] สำหรับรายละเอียด
///
/// สามารถใช้ `std::os::raw::c_void` ได้หากต้องการรองรับคอมไพเลอร์ Rust รุ่นเก่าจนถึง 1.1.0
/// หลังจาก Rust 1.30.0 มันถูกส่งออกอีกครั้งตามคำจำกัดความนี้
/// สำหรับข้อมูลเพิ่มเติมโปรดอ่าน [RFC 2521]
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB เพื่อให้ LLVM จดจำประเภทตัวชี้ที่ว่างเปล่าและโดยฟังก์ชันส่วนขยายเช่น malloc() เราจำเป็นต้องให้มันแสดงเป็น i8 * ในรหัสบิต LLVM
// enum ที่ใช้ที่นี่ช่วยให้มั่นใจได้และป้องกันการใช้งานประเภท "raw" ในทางที่ผิดโดยมีเฉพาะตัวแปรส่วนตัวเท่านั้น
// เราต้องการตัวแปรสองตัวเนื่องจากคอมไพเลอร์บ่นเกี่ยวกับแอตทริบิวต์ repr เป็นอย่างอื่นและเราต้องการตัวแปรอย่างน้อยหนึ่งตัวมิฉะนั้น enum จะไม่มีใครอยู่และอย่างน้อยการอ้างถึงตัวชี้ดังกล่าวจะเป็น UB
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// การใช้งาน `va_list` ขั้นพื้นฐาน
// ชื่อนี้คือ WIP โดยใช้ `VaListImpl` ในตอนนี้
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // คงที่มากกว่า `'f` ดังนั้นวัตถุ `VaListImpl<'f>` แต่ละชิ้นจึงเชื่อมโยงกับพื้นที่ของฟังก์ชันที่กำหนดไว้
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 การใช้งาน ABI ของ `va_list`
/// ดู [AArch64 Procedure Call Standard] สำหรับรายละเอียดเพิ่มเติม
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC การใช้งาน ABI ของ `va_list`
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 การใช้งาน ABI ของ `va_list`
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// กระดาษห่อหุ้มสำหรับ `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// แปลง `VaListImpl` เป็น `VaList` ที่เข้ากันได้กับไบนารีกับ `va_list` ของ C
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// แปลง `VaListImpl` เป็น `VaList` ที่เข้ากันได้กับไบนารีกับ `va_list` ของ C
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// ต้องใช้ VaArgSafe trait ในอินเทอร์เฟซสาธารณะอย่างไรก็ตาม trait เองจะต้องไม่ได้รับอนุญาตให้ใช้นอกโมดูลนี้
// การอนุญาตให้ผู้ใช้ใช้ trait สำหรับประเภทใหม่ (ดังนั้นจึงอนุญาตให้ใช้ va_arg intrinsic ในประเภทใหม่) มีแนวโน้มที่จะทำให้เกิดพฤติกรรมที่ไม่ได้กำหนด
//
// FIXME(dlrobertson): ในการใช้ VaArgSafe trait ในอินเทอร์เฟซสาธารณะ แต่ต้องแน่ใจว่าไม่สามารถใช้ที่อื่นได้ trait จะต้องเป็นแบบสาธารณะภายในโมดูลส่วนตัว
// เมื่อนำ RFC 2145 มาใช้แล้วให้ปรับปรุงสิ่งนี้
//
//
//
//
mod sealed_trait {
    /// Trait ซึ่งอนุญาตให้ใช้ประเภทที่อนุญาตกับ [super::VaListImpl::arg]
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// เลื่อนไปที่อาร์กิวเมนต์ถัดไป
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `va_arg`
        unsafe { va_arg(self) }
    }

    /// คัดลอก `va_list` ที่ตำแหน่งปัจจุบัน
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // ความปลอดภัย: ผู้โทรจะต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `va_end`
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // ความปลอดภัย: เราเขียนถึง `MaybeUninit` ดังนั้นจึงเริ่มต้นและ `assume_init` ถูกกฎหมาย
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: สิ่งนี้ควรเรียกว่า `va_end` แต่ไม่มีวิธีใดที่ชัดเจน
        // รับประกันว่า `drop` จะถูกแทรกเข้ามาในผู้โทรเสมอดังนั้น `va_end` จะถูกเรียกโดยตรงจากฟังก์ชันเดียวกันกับ `va_copy` ที่เกี่ยวข้อง
        // `man va_end` ระบุว่า C ต้องการสิ่งนี้และ LLVM โดยพื้นฐานแล้วจะเป็นไปตามความหมายของ C ดังนั้นเราต้องตรวจสอบให้แน่ใจว่า `va_end` ถูกเรียกจากฟังก์ชันเดียวกับ `va_copy` เสมอ
        //
        // สำหรับรายละเอียดเพิ่มเติม see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // สิ่งนี้ใช้ได้ผลในตอนนี้เนื่องจาก `va_end` ไม่สามารถใช้งานได้กับเป้าหมาย LLVM ทั้งหมดในปัจจุบัน
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// ทำลาย arglist `ap` หลังจากเริ่มต้นด้วย `va_start` หรือ `va_copy`
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// คัดลอกตำแหน่งปัจจุบันของ arglist `src` ไปยัง arglist `dst`
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// โหลดอาร์กิวเมนต์ประเภท `T` จาก `va_list` `ap` และเพิ่มอาร์กิวเมนต์ที่ `ap` ชี้ไป
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}