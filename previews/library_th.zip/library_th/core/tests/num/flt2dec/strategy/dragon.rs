use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // มิริช้าเกินไป
fn exact_sanity_test() {
    // การทดสอบนี้จบลงด้วยการเรียกใช้สิ่งที่ฉันสามารถสันนิษฐานได้คือบางกรณีมุม-ish ของฟังก์ชันไลบรารี `exp2` ซึ่งกำหนดในรันไทม์ C ใดก็ตามที่เราใช้
    // ใน VS 2013 ฟังก์ชั่นนี้ดูเหมือนจะมีข้อบกพร่องเนื่องจากการทดสอบนี้ล้มเหลวเมื่อเชื่อมโยง แต่ด้วย VS 2015 ข้อผิดพลาดจะได้รับการแก้ไขเมื่อการทดสอบทำงานได้ดี
    //
    // จุดบกพร่องดูเหมือนจะเป็นความแตกต่างของค่าส่งคืนของ `exp2(-1057)` โดยที่ใน VS 2013 จะส่งคืนค่าสองเท่าด้วยรูปแบบบิต 0x2 และใน VS 2015 จะส่งคืน 0x20000
    //
    //
    // สำหรับตอนนี้เพียงแค่เพิกเฉยต่อการทดสอบนี้ทั้งหมดบน MSVC เนื่องจากมีการทดสอบที่อื่นอยู่แล้วและเราไม่สนใจอย่างยิ่งที่จะทดสอบการใช้งาน exp2 ของแต่ละแพลตฟอร์ม
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}