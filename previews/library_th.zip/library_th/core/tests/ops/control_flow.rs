use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // นี่ไม่ใช่พื้นที่ผิวที่คงที่ แต่ช่วยให้ `?` มีราคาถูกระหว่างกันแม้ว่า LLVM จะไม่สามารถใช้ประโยชน์จากมันได้ในตอนนี้
    //
    // (ผลลัพธ์และตัวเลือกที่น่าเศร้าไม่สอดคล้องกันดังนั้น ControlFlow จึงไม่สามารถจับคู่ทั้งสองอย่างได้)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}