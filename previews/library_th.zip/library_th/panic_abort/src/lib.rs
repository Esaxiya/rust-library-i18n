//! การใช้งาน Rust panics ผ่านกระบวนการยกเลิก
//!
//! เมื่อเปรียบเทียบกับการนำไปใช้งานผ่านการคลี่คลาย crate นี้ *ง่ายกว่ามาก*!จะว่าไปแล้วมันก็ไม่ได้ใช้งานได้หลากหลาย แต่นี่ไป!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" น้ำหนักบรรทุกและส่งไปยังการยกเลิกที่เกี่ยวข้องบนแพลตฟอร์มที่เป็นปัญหา
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // โทร std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // บน Windows ใช้กลไก __fastfail เฉพาะโปรเซสเซอร์ใน Windows 8 ขึ้นไปสิ่งนี้จะยุติกระบวนการทันทีโดยไม่ต้องเรียกใช้ตัวจัดการข้อยกเว้นใด ๆ ในกระบวนการ
            // ใน Windows เวอร์ชันก่อนหน้าลำดับของคำแนะนำนี้จะถือว่าเป็นการละเมิดการเข้าถึงซึ่งจะยุติกระบวนการ แต่ไม่จำเป็นต้องข้ามตัวจัดการข้อยกเว้นทั้งหมด
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: นี่เป็นการใช้งานแบบเดียวกับใน `abort_internal` ของ libstd
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// นี่ ... เป็นเรื่องแปลกเล็กน้อยtl; dr;คือสิ่งนี้จำเป็นต้องเชื่อมโยงอย่างถูกต้องคำอธิบายที่ยาวขึ้นอยู่ด้านล่าง
//
// ตอนนี้ไบนารีของ libcore/libstd ที่เราจัดส่งนั้นรวบรวมด้วย `-C panic=unwind` ทั้งหมดสิ่งนี้ทำเพื่อให้แน่ใจว่าไบนารีเข้ากันได้สูงสุดกับสถานการณ์ต่างๆให้มากที่สุด
// อย่างไรก็ตามคอมไพเลอร์ต้องการ "personality function" สำหรับฟังก์ชันทั้งหมดที่คอมไพล์ด้วย `-C panic=unwind` ฟังก์ชันบุคลิกภาพนี้ถูกเข้ารหัสเป็นสัญลักษณ์ `rust_eh_personality` และกำหนดโดยรายการ `eh_personality` lang
//
// So...
// ทำไมไม่เพียงกำหนดรายการภาษาที่นี่?คำถามที่ดี!วิธีที่ panic runtimes เชื่อมโยงกันนั้นมีความละเอียดอ่อนเล็กน้อยเนื่องจากพวกมันเป็น "sort of" ในที่เก็บ crate ของคอมไพเลอร์ แต่จะเชื่อมโยงจริงๆก็ต่อเมื่อไม่ได้เชื่อมโยงกันจริงๆ
//
// สิ่งนี้หมายความว่าทั้ง crate และ panic_unwind crate สามารถปรากฏในที่เก็บ crate ของคอมไพเลอร์และหากทั้งคู่กำหนดรายการ `eh_personality` lang สิ่งนั้นจะเกิดข้อผิดพลาด
//
// ในการจัดการสิ่งนี้คอมไพลเลอร์ต้องการ `eh_personality` เท่านั้นที่กำหนดไว้หากรันไทม์ panic ที่เชื่อมโยงเป็นรันไทม์ที่คลี่คลายและมิฉะนั้นก็ไม่จำเป็นต้องกำหนด (อย่างถูกต้อง)
// อย่างไรก็ตามในกรณีนี้ห้องสมุดนี้เพียงแค่กำหนดสัญลักษณ์นี้ดังนั้นอย่างน้อยก็มีบุคลิกบางอย่างอยู่ที่ไหนสักแห่ง
//
// โดยพื้นฐานแล้วสัญลักษณ์นี้ถูกกำหนดให้ต่อสายได้ถึง libcore/libstd ไบนารี แต่ไม่ควรถูกเรียกเนื่องจากเราไม่ได้เชื่อมโยงในรันไทม์ที่คลี่คลายเลย
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // บน x86_64-pc-windows-gnu เราใช้ฟังก์ชันบุคลิกภาพของเราเองที่ต้องการคืนค่า `ExceptionContinueSearch` ขณะที่เราส่งผ่านเฟรมทั้งหมดของเรา
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // คล้ายกับข้างบนนี้ตรงกับรายการ `eh_catch_typeinfo` lang ที่ใช้กับ Emscripten ในปัจจุบันเท่านั้น
    //
    // เนื่องจาก panics ไม่สร้างข้อยกเว้นและข้อยกเว้นจากต่างประเทศในปัจจุบันคือ UB ที่มี -C panic=abort (แม้ว่าอาจมีการเปลี่ยนแปลง) การเรียก catch_unwind ใด ๆ จะไม่ใช้ typeinfo นี้
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // วัตถุทั้งสองนี้ถูกเรียกโดยอ็อบเจ็กต์เริ่มต้นของเราบน i686-pc-windows-gnu แต่พวกเขาไม่จำเป็นต้องทำอะไรเพื่อให้ร่างกายไม่ได้รับ
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}