// rsbegin.o และ rsend.o เรียกว่า "compiler runtime startup objects"
// ซึ่งมีรหัสที่จำเป็นในการเตรียมใช้งานรันไทม์ของคอมไพลเลอร์อย่างถูกต้อง
//
// เมื่อมีการเชื่อมโยงอิมเมจที่เรียกใช้งานได้หรือ dylib รหัสผู้ใช้และไลบรารีทั้งหมดจะเป็น "sandwiched" ระหว่างอ็อบเจ็กต์ไฟล์ทั้งสองนี้ดังนั้นโค้ดหรือข้อมูลจาก rsbegin.o จึงกลายเป็นอันดับแรกในส่วนต่างๆของรูปภาพในขณะที่โค้ดและข้อมูลจาก rsend.o จะกลายเป็นโค้ดสุดท้าย
// เอฟเฟกต์นี้สามารถใช้เพื่อวางสัญลักษณ์ที่จุดเริ่มต้นหรือตอนท้ายของส่วนเช่นเดียวกับการแทรกส่วนหัวหรือส่วนท้ายที่ต้องการ
//
// โปรดสังเกตว่าจุดเริ่มต้นของโมดูลจริงจะอยู่ในอ็อบเจ็กต์การเริ่มต้นรันไทม์ C (โดยปกติเรียกว่า `crtX.o`) ซึ่งจะเรียกใช้การเรียกกลับการเริ่มต้นของคอมโพเนนต์รันไทม์อื่น ๆ (ลงทะเบียนผ่านส่วนอิมเมจพิเศษอื่น)
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // ทำเครื่องหมายจุดเริ่มต้นของสแต็กเฟรมคลายส่วนข้อมูล
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // มีรอยขีดข่วนสำหรับการเก็บหนังสือภายในของคลาย
    // สิ่งนี้ถูกกำหนดให้เป็น `struct object` ใน $ GCC/unind-dw2-fde.h
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // คลายข้อมูล registration/deregistration กิจวัตร
    // ดูเอกสารของ libpanic_unwind
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // ลงทะเบียนคลายข้อมูลในการเริ่มต้นโมดูล
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // ยกเลิกการลงทะเบียนเมื่อปิดเครื่อง
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // การลงทะเบียนประจำ init/uninit เฉพาะ MinGW
    pub mod mingw_init {
        // วัตถุเริ่มต้นของ MinGW (crt0.o/dllcrt0.o) จะเรียกใช้ตัวสร้างร่วมในส่วน .ctors และ .dtors เมื่อเริ่มต้นและออก
        // ในกรณีของ DLL จะกระทำเมื่อโหลดและยกเลิกการโหลด DLL
        //
        // ตัวเชื่อมโยงจะจัดเรียงส่วนต่างๆซึ่งช่วยให้มั่นใจได้ว่าการเรียกกลับของเราจะอยู่ที่ส่วนท้ายของรายการ
        // เนื่องจากคอนสตรัคเตอร์ทำงานในลำดับย้อนกลับสิ่งนี้ทำให้มั่นใจได้ว่าการเรียกกลับของเราเป็นการดำเนินการครั้งแรกและครั้งสุดท้าย
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C การเรียกกลับการเริ่มต้น
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C การยกเลิกการโทรกลับ
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}