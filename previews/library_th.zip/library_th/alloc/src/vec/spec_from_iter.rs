use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// ความเชี่ยวชาญ trait ใช้สำหรับ Vec::from_iter
///
/// ## กราฟการมอบอำนาจ:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // กรณีทั่วไปกำลังส่ง vector ไปยังฟังก์ชันที่รวบรวมใหม่ใน vector ทันที
        // เราสามารถลัดวงจรได้หาก IntoIter ไม่ได้รับการพัฒนาขั้นสูงเลย
        // เมื่อเป็นขั้นสูงแล้วเรายังสามารถนำหน่วยความจำกลับมาใช้ใหม่และย้ายข้อมูลไปด้านหน้าได้
        // แต่เราจะทำเช่นนั้นก็ต่อเมื่อ Vec ที่ได้มาไม่มีความจุที่ไม่ได้ใช้มากไปกว่าการสร้างผ่านการใช้งาน FromIterator ทั่วไป
        //
        // ข้อ จำกัด ดังกล่าวไม่จำเป็นอย่างเคร่งครัดเนื่องจากพฤติกรรมการจัดสรรของ Vec ไม่ได้ระบุโดยเจตนา
        // แต่เป็นทางเลือกที่อนุรักษ์นิยม
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // ต้องมอบหมายให้ spec_extend() เนื่องจาก extend() เองมอบหมายให้ spec_from สำหรับ Vec ว่างเปล่า
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// สิ่งนี้ใช้ `iterator.as_slice().to_vec()` เนื่องจาก spec_extend ต้องใช้ขั้นตอนเพิ่มเติมเพื่อให้เหตุผลเกี่ยวกับความจุสุดท้าย + ความยาวจึงทำงานได้มากขึ้น
// `to_vec()` จัดสรรจำนวนเงินที่ถูกต้องโดยตรงและเติมให้ถูกต้อง
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): ด้วย cfg(test) เมธอด `[T]::to_vec` โดยธรรมชาติซึ่งจำเป็นสำหรับนิยามเมธอดนี้จะไม่พร้อมใช้งาน
    // ใช้ฟังก์ชัน `slice::to_vec` แทนซึ่งใช้ได้เฉพาะกับ cfg(test) NB โปรดดูโมดูล slice::hack ใน slice.rs สำหรับข้อมูลเพิ่มเติม
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}