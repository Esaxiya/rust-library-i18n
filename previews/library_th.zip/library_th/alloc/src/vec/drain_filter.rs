use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// ตัววนซ้ำซึ่งใช้การปิดเพื่อพิจารณาว่าควรลบองค์ประกอบหรือไม่
///
/// โครงสร้างนี้สร้างขึ้นโดย [`Vec::drain_filter`]
/// ดูเอกสารประกอบสำหรับข้อมูลเพิ่มเติม
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// ดัชนีของรายการที่จะถูกตรวจสอบโดยการเรียกถัดไปที่ `next`
    pub(super) idx: usize,
    /// จำนวนรายการที่หมดแล้ว (removed) ป่านนี้
    pub(super) del: usize,
    /// ความยาวเดิมของ `vec` ก่อนการระบายน้ำ
    pub(super) old_len: usize,
    /// เพรดิเคตการทดสอบตัวกรอง
    pub(super) pred: F,
    /// แฟล็กที่ระบุ panic เกิดขึ้นในเพรดิเคตการทดสอบตัวกรอง
    /// สิ่งนี้ใช้เป็นคำแนะนำในการใช้งานดร็อปเพื่อป้องกันการใช้งาน `DrainFilter` ที่เหลือ
    /// ไอเท็มที่ยังไม่ได้ประมวลผลจะถูกเปลี่ยนกลับใน `vec` แต่จะไม่มีการดรอปหรือทดสอบไอเท็มเพิ่มเติมโดยเพรดิเคตตัวกรอง
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// ส่งคืนการอ้างอิงไปยังผู้จัดสรรที่อ้างอิง
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // อัปเดตดัชนี *หลังจาก* เพรดิเคตถูกเรียก
                // หากดัชนีได้รับการอัปเดตก่อนหน้าและเพรดิเคต panics องค์ประกอบที่ดัชนีนี้จะรั่วไหล
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // นี่เป็นสถานะที่ค่อนข้างยุ่งเหยิงและไม่มีสิ่งที่ถูกต้องที่จะทำอย่างชัดเจน
                        // เราไม่ต้องการพยายามเรียกใช้ `pred` ต่อไปดังนั้นเราจึงเปลี่ยนองค์ประกอบที่ยังไม่ได้ประมวลผลทั้งหมดและบอก vec ว่ายังคงมีอยู่
                        //
                        // จำเป็นต้องใช้ backshift เพื่อป้องกันการดร็อปไอเท็มสุดท้ายที่ระบายสำเร็จก่อนหน้า panic ในเพรดิเคต
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // พยายามใช้องค์ประกอบที่เหลือหากเพรดิเคตตัวกรองยังไม่ตื่นตระหนก
        // เราจะเปลี่ยนองค์ประกอบที่เหลือไม่ว่าเราจะตื่นตระหนกไปแล้วหรือว่าการบริโภคที่นี่ panics
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}