use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// เครื่องหมายเฉพาะสำหรับการรวบรวมไปป์ไลน์ตัววนซ้ำลงใน Vec ในขณะที่นำการจัดสรรซอร์สกลับมาใช้เช่น
/// ดำเนินการไปป์ไลน์ในสถานที่
///
/// trait พาเรนต์ SourceIter จำเป็นสำหรับฟังก์ชันที่เชี่ยวชาญในการเข้าถึงการจัดสรรที่จะนำกลับมาใช้
/// แต่ไม่เพียงพอที่ความเชี่ยวชาญจะถูกต้อง
/// ดูขอบเขตเพิ่มเติมของนัย
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-internal SourceIter/InPlaceIterable traits ถูกใช้งานโดยโซ่อะแดปเตอร์เท่านั้น <Adapter<Adapter<IntoIter>>> (ทั้งหมดเป็นของ core/std)
// ขอบเขตเพิ่มเติมเกี่ยวกับการใช้งานอะแด็ปเตอร์ (เกิน `impl<I: Trait> Trait for Adapter<I>`) ขึ้นอยู่กับ traits อื่น ๆ ที่ทำเครื่องหมายไว้แล้วว่าเป็น Specialization traits (Copy, TrustedRandomAccess, FusedIterator) เท่านั้น
//
// I.e. เครื่องหมายไม่ขึ้นอยู่กับอายุการใช้งานของประเภทที่ผู้ใช้จัดหาให้โมดูโลคัดลอกรูซึ่งมีความเชี่ยวชาญอื่น ๆ อีกหลายอย่างขึ้นอยู่แล้ว
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // ข้อกำหนดเพิ่มเติมซึ่งไม่สามารถแสดงผ่าน trait bounds เราอาศัย const eval แทน:
        // a) ไม่มี ZST เนื่องจากจะไม่มีการจัดสรรเพื่อใช้ซ้ำและตัวชี้เลขคณิตจะ panic b) ขนาดที่ตรงตามที่สัญญา Alloc กำหนด c) การจัดตำแหน่งตรงกันตามที่สัญญา Alloc กำหนด
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // ทางเลือกในการใช้งานทั่วไปมากขึ้น
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // ลองพับตั้งแต่
        // - มันเป็นเวกเตอร์ที่ดีกว่าสำหรับอะแดปเตอร์ตัววนซ้ำบางตัว
        // - แตกต่างจากวิธีการทำซ้ำภายในส่วนใหญ่ใช้ &mut ด้วยตนเองเท่านั้น
        // - มันช่วยให้เราด้ายตัวชี้การเขียนผ่านด้านในของมันและดึงกลับมาในตอนท้าย
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // ทำซ้ำสำเร็จอย่าวางหัว
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // ตรวจสอบว่าสัญญา SourceIter ยึดถือข้อแม้หรือไม่: หากพวกเขาไม่ใช่เราก็อาจไม่ถึงจุดนี้
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // ตรวจสอบสัญญา InPlaceIterableสิ่งนี้จะเกิดขึ้นได้ก็ต่อเมื่อตัววนซ้ำเลื่อนตัวชี้ต้นทางไปเลย
        // หากใช้การเข้าถึงที่ไม่ได้ตรวจสอบผ่าน TrustedRandomAccess ตัวชี้แหล่งที่มาจะยังคงอยู่ในตำแหน่งเริ่มต้นและเราไม่สามารถใช้เป็นข้อมูลอ้างอิงได้
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // ปล่อยค่าที่เหลือที่ส่วนท้ายของแหล่งที่มา แต่ป้องกันไม่ให้การจัดสรรลดลงเมื่อ IntoIter ออกนอกขอบเขตหากการดรอป panics เราจะรั่วไหลองค์ประกอบใด ๆ ที่รวบรวมไปยัง dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // ไม่สามารถตรวจสอบสัญญา InPlaceIterable ได้อย่างแม่นยำที่นี่เนื่องจาก try_fold มีการอ้างอิงพิเศษไปยังตัวชี้ต้นทางสิ่งที่เราทำได้คือตรวจสอบว่ายังอยู่ในช่วงหรือไม่
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}