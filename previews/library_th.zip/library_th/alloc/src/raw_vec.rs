#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// เนื้อหาของหน่วยความจำใหม่ไม่ได้กำหนดค่าเริ่มต้น
    Uninitialized,
    /// หน่วยความจำใหม่รับประกันว่าจะเป็นศูนย์
    Zeroed,
}

/// ยูทิลิตี้ระดับต่ำสำหรับการจัดสรรตามหลักสรีรศาสตร์การจัดสรรใหม่และการจัดสรรบัฟเฟอร์หน่วยความจำบนฮีปโดยไม่ต้องกังวลกับกรณีต่างๆที่เกี่ยวข้อง
///
/// ประเภทนี้เหมาะอย่างยิ่งสำหรับการสร้างโครงสร้างข้อมูลของคุณเองเช่น Vec และ VecDeque
/// โดยเฉพาะอย่างยิ่ง:
///
/// * ผลิต `Unique::dangling()` ในประเภทขนาดศูนย์
/// * สร้าง `Unique::dangling()` ในการปันส่วนที่มีความยาวเป็นศูนย์
/// * หลีกเลี่ยงการพ้น `Unique::dangling()`
/// * จับการล้นทั้งหมดในการคำนวณความจุ (เลื่อนระดับเป็น "capacity overflow" panics)
/// * ป้องกันระบบ 32 บิตที่จัดสรรมากกว่า isize::MAX ไบต์
/// * ป้องกันความยาวของคุณมากเกินไป
/// * เรียก `handle_alloc_error` สำหรับการจัดสรรที่ผิดพลาด
/// * ประกอบด้วย `ptr::Unique` และทำให้ผู้ใช้ได้รับประโยชน์ที่เกี่ยวข้องทั้งหมด
/// * ใช้ส่วนเกินที่ส่งคืนจากตัวจัดสรรเพื่อใช้ความจุที่มีอยู่มากที่สุด
///
/// ประเภทนี้ไม่ได้อยู่ในการตรวจสอบหน่วยความจำที่จัดการเมื่อทิ้งลง *จะ* เพิ่มหน่วยความจำ แต่จะไม่ * พยายามทิ้งเนื้อหา
/// ขึ้นอยู่กับผู้ใช้ `RawVec` ที่จะจัดการกับสิ่งของจริง *ที่เก็บไว้* ภายใน `RawVec`
///
/// โปรดทราบว่าประเภทที่มีขนาดศูนย์มากเกินไปมักไม่มีที่สิ้นสุดดังนั้น `capacity()` จึงส่งคืน `usize::MAX` เสมอ
/// ซึ่งหมายความว่าคุณต้องระมัดระวังในการปัดเศษประเภทนี้ด้วย `Box<[T]>` เนื่องจาก `capacity()` จะไม่ให้ความยาว
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): สิ่งนี้มีอยู่เนื่องจาก `#[unstable]` "const fn" ไม่จำเป็นต้องเป็นไปตาม `min_const_fn` ดังนั้นจึงไม่สามารถเรียกใน "min_const_fn`s ด้วยเช่นกัน
    ///
    /// หากคุณเปลี่ยน `RawVec<T>::new` หรือการอ้างอิงโปรดระวังอย่าแนะนำสิ่งใดที่ละเมิด `min_const_fn` อย่างแท้จริง
    ///
    /// NOTE: เราสามารถหลีกเลี่ยงการแฮ็กนี้และตรวจสอบความสอดคล้องกับแอตทริบิวต์ `#[rustc_force_min_const_fn]` บางอย่างที่ต้องการความสอดคล้องกับ `min_const_fn` แต่ไม่จำเป็นต้องอนุญาตให้เรียกมันใน `stable(...) const fn`/รหัสผู้ใช้ที่ไม่เปิดใช้งาน `foo` เมื่อมี `#[rustc_const_unstable(feature = "foo", issue = "01234")]`
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// สร้าง `RawVec` ที่ใหญ่ที่สุดที่เป็นไปได้ (บนฮีประบบ) โดยไม่ต้องจัดสรร
    /// ถ้า `T` มีขนาดบวกสิ่งนี้จะทำให้ `RawVec` มีความจุ `0`
    /// ถ้า `T` มีขนาดศูนย์ก็จะทำให้ `RawVec` มีความจุ `usize::MAX`
    /// มีประโยชน์สำหรับการดำเนินการจัดสรรล่าช้า
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// สร้าง `RawVec` (บนฮีประบบ) ที่มีความจุและข้อกำหนดการจัดตำแหน่งสำหรับ `[T; capacity]`
    /// สิ่งนี้เทียบเท่ากับการเรียก `RawVec::new` เมื่อ `capacity` คือ `0` หรือ `T` เป็นขนาดศูนย์
    /// โปรดทราบว่าหาก `T` มีขนาดเป็นศูนย์หมายความว่าคุณจะ *ไม่* รับ `RawVec` ตามความจุที่ร้องขอ
    ///
    /// # Panics
    ///
    /// Panics ถ้าความจุที่ร้องขอเกิน `isize::MAX` ไบต์
    ///
    /// # Aborts
    ///
    /// การยกเลิก OOM
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// เช่นเดียวกับ `with_capacity` แต่รับประกันว่าบัฟเฟอร์เป็นศูนย์
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// สร้าง `RawVec` ใหม่จากตัวชี้และความจุ
    ///
    /// # Safety
    ///
    /// ต้องจัดสรร `ptr` (บนฮีประบบ) และด้วย `capacity` ที่กำหนด
    /// `capacity` ต้องไม่เกิน `isize::MAX` สำหรับประเภทขนาด(เฉพาะข้อกังวลเกี่ยวกับระบบ 32 บิต)
    /// ZST vectors อาจมีความจุสูงถึง `usize::MAX`
    /// หาก `ptr` และ `capacity` มาจาก `RawVec` ก็รับประกันได้
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Vecs จิ๋วเป็นใบ้ข้ามไปที่:
    // - 8 ถ้าขนาดองค์ประกอบคือ 1 เนื่องจากตัวจัดสรรฮีปใด ๆ มีแนวโน้มที่จะปัดเศษคำขอที่น้อยกว่า 8 ไบต์เป็นอย่างน้อย 8 ไบต์
    //
    // - 4 ถ้าองค์ประกอบมีขนาดปานกลาง (<=1 KiB)
    // - 1 มิฉะนั้นเพื่อหลีกเลี่ยงการเสียพื้นที่มากเกินไปสำหรับ Vecs ที่สั้นมาก
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// เช่นเดียวกับ `new` แต่กำหนดพารามิเตอร์เหนือตัวเลือกตัวจัดสรรสำหรับ `RawVec` ที่ส่งคืน
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` หมายถึง "unallocated" ประเภทขนาดศูนย์จะถูกละเว้น
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// เช่นเดียวกับ `with_capacity` แต่กำหนดพารามิเตอร์เหนือตัวเลือกตัวจัดสรรสำหรับ `RawVec` ที่ส่งคืน
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// เช่นเดียวกับ `with_capacity_zeroed` แต่กำหนดพารามิเตอร์เหนือตัวเลือกตัวจัดสรรสำหรับ `RawVec` ที่ส่งคืน
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// แปลง `Box<[T]>` เป็น `RawVec<T>`
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// แปลงบัฟเฟอร์ทั้งหมดเป็น `Box<[MaybeUninit<T>]>` ด้วย `len` ที่ระบุ
    ///
    /// โปรดทราบว่าสิ่งนี้จะสร้างการเปลี่ยนแปลง `cap` ที่อาจดำเนินการขึ้นใหม่อย่างถูกต้อง(ดูคำอธิบายประเภทสำหรับรายละเอียด)
    ///
    /// # Safety
    ///
    /// * `len` ต้องมากกว่าหรือเท่ากับความจุที่ร้องขอล่าสุดและ
    /// * `len` ต้องน้อยกว่าหรือเท่ากับ `self.capacity()`
    ///
    /// โปรดทราบว่าความจุที่ร้องขอและ `self.capacity()` อาจแตกต่างกันเนื่องจากตัวจัดสรรสามารถระบุตำแหน่งโดยรวมและส่งคืนบล็อกหน่วยความจำที่มากกว่าที่ร้องขอ
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // ตรวจสอบความปลอดภัยครึ่งหนึ่งของข้อกำหนดด้านความปลอดภัย (เราไม่สามารถตรวจสอบอีกครึ่งหนึ่งได้)
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // เราหลีกเลี่ยง `unwrap_or_else` ที่นี่เพราะมันขยายจำนวน LLVM IR ที่สร้างขึ้น
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// สร้าง `RawVec` ใหม่จากตัวชี้ความจุและตัวจัดสรร
    ///
    /// # Safety
    ///
    /// ต้องจัดสรร `ptr` (ผ่านตัวจัดสรรที่กำหนด `alloc`) และด้วย `capacity` ที่กำหนด
    /// `capacity` ต้องไม่เกิน `isize::MAX` สำหรับประเภทขนาด
    /// (เฉพาะข้อกังวลเกี่ยวกับระบบ 32 บิต)
    /// ZST vectors อาจมีความจุสูงถึง `usize::MAX`
    /// หาก `ptr` และ `capacity` มาจาก `RawVec` ที่สร้างผ่าน `alloc` ก็รับประกันได้
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// รับตัวชี้ดิบเพื่อเริ่มต้นการจัดสรร
    /// โปรดทราบว่านี่คือ `Unique::dangling()` หาก `capacity == 0` หรือ `T` มีขนาดเป็นศูนย์
    /// ในอดีตคุณต้องระวัง
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// รับความจุของการจัดสรร
    ///
    /// ค่านี้จะเป็น `usize::MAX` เสมอหาก `T` มีขนาดเป็นศูนย์
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// ส่งคืนการอ้างอิงที่ใช้ร่วมกันไปยังผู้จัดสรรที่สนับสนุน `RawVec` นี้
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // เรามีหน่วยความจำที่จัดสรรไว้จำนวนหนึ่งดังนั้นเราจึงสามารถข้ามการตรวจสอบรันไทม์เพื่อรับเลย์เอาต์ปัจจุบันของเราได้
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// ตรวจสอบให้แน่ใจว่าบัฟเฟอร์มีพื้นที่อย่างน้อยเพียงพอที่จะเก็บองค์ประกอบ `len + additional`
    /// หากมีความจุไม่เพียงพอจะจัดสรรพื้นที่ใหม่ให้เพียงพอรวมทั้งพื้นที่หย่อนที่สะดวกสบายเพื่อให้ได้พฤติกรรมการตัดจำหน่าย *O*(1)
    ///
    /// จะ จำกัด พฤติกรรมนี้หากไม่จำเป็นต้องทำให้ตัวเองเป็น panic
    ///
    /// หาก `len` เกิน `self.capacity()` อาจไม่สามารถจัดสรรพื้นที่ที่ร้องขอได้จริง
    /// สิ่งนี้ไม่ปลอดภัยจริงๆ แต่โค้ดที่ไม่ปลอดภัย *คุณ* เขียนซึ่งอาศัยลักษณะการทำงานของฟังก์ชันนี้อาจใช้งานไม่ได้
    ///
    /// เหมาะอย่างยิ่งสำหรับการใช้งานการกดจำนวนมากเช่น `extend`
    ///
    /// # Panics
    ///
    /// Panics ถ้าความจุใหม่เกิน `isize::MAX` ไบต์
    ///
    /// # Aborts
    ///
    /// การยกเลิก OOM
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // เงินสำรองจะถูกยกเลิกหรือตื่นตระหนกหากเลนเกิน `isize::MAX` ดังนั้นตอนนี้จึงปลอดภัยที่จะไม่ทำเครื่องหมาย
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// เช่นเดียวกับ `reserve` แต่ส่งกลับข้อผิดพลาดแทนที่จะตื่นตระหนกหรือยกเลิก
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// ตรวจสอบให้แน่ใจว่าบัฟเฟอร์มีพื้นที่อย่างน้อยเพียงพอที่จะเก็บองค์ประกอบ `len + additional`
    /// หากยังไม่ได้ดำเนินการจะจัดสรรจำนวนหน่วยความจำขั้นต่ำที่จำเป็นให้ใหม่
    /// โดยทั่วไปแล้วจะเป็นจำนวนหน่วยความจำที่จำเป็น แต่โดยหลักการแล้วผู้จัดสรรมีอิสระที่จะให้คืนมากกว่าที่เราขอ
    ///
    ///
    /// หาก `len` เกิน `self.capacity()` อาจไม่สามารถจัดสรรพื้นที่ที่ร้องขอได้จริง
    /// สิ่งนี้ไม่ปลอดภัยจริงๆ แต่โค้ดที่ไม่ปลอดภัย *คุณ* เขียนซึ่งอาศัยลักษณะการทำงานของฟังก์ชันนี้อาจใช้งานไม่ได้
    ///
    /// # Panics
    ///
    /// Panics ถ้าความจุใหม่เกิน `isize::MAX` ไบต์
    ///
    /// # Aborts
    ///
    /// การยกเลิก OOM
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// เช่นเดียวกับ `reserve_exact` แต่ส่งกลับข้อผิดพลาดแทนที่จะตื่นตระหนกหรือยกเลิก
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// ลดการจัดสรรลงเหลือตามจำนวนที่ระบุ
    /// หากจำนวนที่ระบุเป็น 0 จะทำการจัดสรรทั้งหมด
    ///
    /// # Panics
    ///
    /// Panics หากจำนวนเงินที่ระบุ *มากกว่า* มากกว่าความจุปัจจุบัน
    ///
    /// # Aborts
    ///
    /// การยกเลิก OOM
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// ส่งคืนหากบัฟเฟอร์จำเป็นต้องเพิ่มขึ้นเพื่อเติมเต็มความจุเพิ่มเติมที่จำเป็น
    /// ส่วนใหญ่ใช้เพื่อโทรสำรองแบบอินไลน์ได้โดยไม่ต้องใส่ `grow`
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // วิธีนี้มักจะสร้างอินสแตนซ์หลายครั้งดังนั้นเราจึงต้องการให้มีขนาดเล็กที่สุดเพื่อปรับปรุงเวลาในการคอมไพล์
    // แต่เราต้องการให้เนื้อหาจำนวนมากสามารถคำนวณได้แบบคงที่เพื่อให้โค้ดที่สร้างขึ้นทำงานได้เร็วขึ้น
    // ดังนั้นวิธีนี้จึงถูกเขียนขึ้นอย่างระมัดระวังเพื่อให้โค้ดทั้งหมดที่ขึ้นอยู่กับ `T` อยู่ภายในในขณะที่โค้ดที่ไม่ขึ้นอยู่กับ `T` มากที่สุดเท่าที่จะเป็นไปได้นั้นอยู่ในฟังก์ชันที่ไม่ใช่แบบทั่วไปใน `T`
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // สิ่งนี้ได้รับการรับรองโดยบริบทการโทร
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // เนื่องจากเราคืนค่าความจุ `usize::MAX` เมื่อ `elem_size` เป็น
            // 0 การมาที่นี่จำเป็นต้องหมายความว่า `RawVec` มีน้ำหนักมากเกินไป
            return Err(CapacityOverflow);
        }

        // เราไม่สามารถดำเนินการใด ๆ เกี่ยวกับการตรวจสอบเหล่านี้ได้เลยน่าเศร้า
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // สิ่งนี้รับประกันการเติบโตแบบทวีคูณ
        // การเพิ่มสองเท่าไม่สามารถล้นได้เนื่องจาก `cap <= isize::MAX` และประเภทของ `cap` คือ `usize`
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ไม่ใช่แบบทั่วไปใน `T`
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // ข้อ จำกัด ของวิธีนี้เหมือนกันมากกับ `grow_amortized` แต่วิธีนี้มักจะสร้างอินสแตนซ์น้อยกว่าดังนั้นจึงมีความสำคัญน้อยกว่า
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // เนื่องจากเราคืนค่าความจุ `usize::MAX` เมื่อขนาดของประเภทเป็น
            // 0 การมาที่นี่จำเป็นต้องหมายความว่า `RawVec` มีน้ำหนักมากเกินไป
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ไม่ใช่แบบทั่วไปใน `T`
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// ฟังก์ชันนี้อยู่นอก `RawVec` เพื่อลดเวลาในการคอมไพล์ดูความคิดเห็นด้านบน `RawVec::grow_amortized` สำหรับรายละเอียด
// (พารามิเตอร์ `A` ไม่มีนัยสำคัญเนื่องจากจำนวน `A` ประเภทต่างๆที่เห็นในทางปฏิบัตินั้นน้อยกว่าจำนวนประเภท `T` มาก)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // ตรวจสอบข้อผิดพลาดที่นี่เพื่อย่อขนาด `RawVec::grow_*`
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // ตัวจัดสรรจะตรวจสอบความเท่าเทียมกันของการจัดตำแหน่ง
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// ปลดปล่อยหน่วยความจำที่เป็นของ `RawVec`*โดยไม่ต้อง* พยายามทิ้งเนื้อหา
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// ฟังก์ชั่นกลางสำหรับการจัดการข้อผิดพลาดสำรอง
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// เราจำเป็นต้องรับประกันสิ่งต่อไปนี้:
// * เราไม่เคยจัดสรรวัตถุขนาดไบต์ `> isize::MAX`
// * เราไม่ล้น `usize::MAX` และจัดสรรน้อยเกินไป
//
// ใน 64 บิตเราจำเป็นต้องตรวจสอบการล้นเนื่องจากการพยายามจัดสรรไบต์ `> isize::MAX` จะล้มเหลวอย่างแน่นอน
// ใน 32 บิตและ 16 บิตเราจำเป็นต้องเพิ่มตัวป้องกันพิเศษสำหรับสิ่งนี้ในกรณีที่เรากำลังทำงานบนแพลตฟอร์มที่สามารถใช้ 4GB ทั้งหมดในพื้นที่ผู้ใช้เช่น PAE หรือ x32
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// ฟังก์ชั่นกลางหนึ่งหน้าที่รับผิดชอบในการรายงานความจุล้น
// สิ่งนี้จะช่วยให้มั่นใจได้ว่าการสร้างรหัสที่เกี่ยวข้องกับ panics เหล่านี้มีน้อยมากเนื่องจากมีเพียงตำแหน่งเดียวที่ panics แทนที่จะเป็นกลุ่มทั่วทั้งโมดูล
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}