//! API การจัดสรรหน่วยความจำ

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // นี่คือสัญลักษณ์วิเศษในการเรียกผู้จัดสรรส่วนกลาง rustc สร้างให้เรียก `__rg_alloc` เป็นต้น
    // หากมีแอตทริบิวต์ `#[global_allocator]` (โค้ดที่ขยายมาโครแอตทริบิวต์นั้นจะสร้างฟังก์ชันเหล่านั้น) หรือเพื่อเรียกการใช้งานเริ่มต้นใน libstd (`__rdl_alloc` เป็นต้น
    //
    // ใน `library/std/src/alloc.rs`) มิฉะนั้น
    // rustc fork ของ LLVM ยังมีกรณีพิเศษชื่อฟังก์ชันเหล่านี้เพื่อให้สามารถปรับให้เหมาะสมเช่น `malloc`, `realloc` และ `free` ตามลำดับ
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// ตัวจัดสรรหน่วยความจำส่วนกลาง
///
/// ประเภทนี้ใช้ [`Allocator`] trait โดยการโอนสายไปยังตัวจัดสรรที่ลงทะเบียนด้วยแอ็ตทริบิวต์ `#[global_allocator]` หากมีหนึ่งตัวหรือค่าดีฟอลต์ของ `std` crate
///
///
/// Note: ในขณะที่ประเภทนี้ไม่เสถียรฟังก์ชันการทำงานที่มีให้สามารถเข้าถึงได้ผ่าน [free functions in `alloc`](self#functions)
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// จัดสรรหน่วยความจำด้วยตัวจัดสรรส่วนกลาง
///
/// ฟังก์ชันนี้จะส่งต่อการเรียกใช้เมธอด [`GlobalAlloc::alloc`] ของตัวจัดสรรที่ลงทะเบียนด้วยแอ็ตทริบิวต์ `#[global_allocator]` หากมีอย่างใดอย่างหนึ่งหรือค่าดีฟอลต์ของ `std` crate
///
///
/// คาดว่าฟังก์ชันนี้จะเลิกใช้งานตามวิธี `alloc` ของประเภท [`Global`] เมื่อฟังก์ชันนี้และ [`Allocator`] trait เสถียร
///
/// # Safety
///
/// ดู [`GlobalAlloc::alloc`]
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// จัดสรรหน่วยความจำด้วยตัวจัดสรรส่วนกลาง
///
/// ฟังก์ชันนี้จะส่งต่อการเรียกใช้เมธอด [`GlobalAlloc::dealloc`] ของตัวจัดสรรที่ลงทะเบียนด้วยแอ็ตทริบิวต์ `#[global_allocator]` หากมีอย่างใดอย่างหนึ่งหรือค่าดีฟอลต์ของ `std` crate
///
///
/// คาดว่าฟังก์ชันนี้จะเลิกใช้งานตามวิธี `dealloc` ของประเภท [`Global`] เมื่อฟังก์ชันนี้และ [`Allocator`] trait เสถียร
///
/// # Safety
///
/// ดู [`GlobalAlloc::dealloc`]
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// จัดสรรหน่วยความจำใหม่ด้วยตัวจัดสรรส่วนกลาง
///
/// ฟังก์ชันนี้จะส่งต่อการเรียกใช้เมธอด [`GlobalAlloc::realloc`] ของตัวจัดสรรที่ลงทะเบียนด้วยแอ็ตทริบิวต์ `#[global_allocator]` หากมีอย่างใดอย่างหนึ่งหรือค่าดีฟอลต์ของ `std` crate
///
///
/// คาดว่าฟังก์ชันนี้จะเลิกใช้งานตามวิธี `realloc` ของประเภท [`Global`] เมื่อฟังก์ชันนี้และ [`Allocator`] trait เสถียร
///
/// # Safety
///
/// ดู [`GlobalAlloc::realloc`]
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// จัดสรรหน่วยความจำเริ่มต้นเป็นศูนย์ด้วยตัวจัดสรรส่วนกลาง
///
/// ฟังก์ชันนี้จะส่งต่อการเรียกใช้เมธอด [`GlobalAlloc::alloc_zeroed`] ของตัวจัดสรรที่ลงทะเบียนด้วยแอ็ตทริบิวต์ `#[global_allocator]` หากมีอย่างใดอย่างหนึ่งหรือค่าดีฟอลต์ของ `std` crate
///
///
/// คาดว่าฟังก์ชันนี้จะเลิกใช้งานตามวิธี `alloc_zeroed` ของประเภท [`Global`] เมื่อฟังก์ชันนี้และ [`Allocator`] trait เสถียร
///
/// # Safety
///
/// ดู [`GlobalAlloc::alloc_zeroed`]
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // ความปลอดภัย: `layout` ไม่มีขนาดเป็นศูนย์
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // ความปลอดภัย: เหมือนกับ `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // ความปลอดภัย: `new_size` ไม่ใช่ศูนย์เนื่องจาก `old_size` มากกว่าหรือเท่ากับ `new_size`
            // ตามที่กำหนดโดยเงื่อนไขด้านความปลอดภัยผู้โทรจะต้องยึดถือเงื่อนไขอื่น ๆ
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` อาจตรวจสอบ `new_size >= old_layout.size()` หรือสิ่งที่คล้ายกัน
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // ความปลอดภัย: เนื่องจาก `new_layout.size()` ต้องมากกว่าหรือเท่ากับ `old_size`
            // การจัดสรรหน่วยความจำทั้งเก่าและใหม่ใช้ได้สำหรับการอ่านและเขียนสำหรับ `old_size` ไบต์
            // นอกจากนี้เนื่องจากการจัดสรรเก่ายังไม่ได้รับการจัดสรรจึงไม่สามารถซ้อนทับ `new_ptr` ได้
            // ดังนั้นการโทรหา `copy_nonoverlapping` จึงปลอดภัย
            // ผู้เรียกต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `dealloc`
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // ความปลอดภัย: `layout` ไม่มีขนาดเป็นศูนย์
            // ผู้โทรจะต้องยึดถือเงื่อนไขอื่น ๆ
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ความปลอดภัย: ผู้โทรต้องยึดถือเงื่อนไขทั้งหมด
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ความปลอดภัย: ผู้โทรต้องยึดถือเงื่อนไขทั้งหมด
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // ความปลอดภัย: ผู้โทรต้องยึดถือเงื่อนไข
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // ความปลอดภัย: `new_size` ไม่ใช่ศูนย์ผู้โทรจะต้องยึดถือเงื่อนไขอื่น ๆ
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` อาจตรวจสอบ `new_size <= old_layout.size()` หรือสิ่งที่คล้ายกัน
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // ความปลอดภัย: เนื่องจาก `new_size` ต้องมีขนาดเล็กกว่าหรือเท่ากับ `old_layout.size()`
            // การจัดสรรหน่วยความจำทั้งเก่าและใหม่ใช้ได้สำหรับการอ่านและเขียนสำหรับ `new_size` ไบต์
            // นอกจากนี้เนื่องจากการจัดสรรเก่ายังไม่ได้รับการจัดสรรจึงไม่สามารถซ้อนทับ `new_ptr` ได้
            // ดังนั้นการโทรหา `copy_nonoverlapping` จึงปลอดภัย
            // ผู้เรียกต้องปฏิบัติตามสัญญาด้านความปลอดภัยสำหรับ `dealloc`
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// ตัวจัดสรรสำหรับพอยน์เตอร์ที่ไม่ซ้ำกัน
// ฟังก์ชันนี้ต้องไม่คลายออกหากเป็นเช่นนั้น MIR codegen จะล้มเหลว
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// ลายเซ็นนี้จะต้องเหมือนกับ `Box` มิฉะนั้นจะมี ICE เกิดขึ้น
// เมื่อมีการเพิ่มพารามิเตอร์เพิ่มเติมให้กับ `Box` (เช่น `A: Allocator`) จะต้องเพิ่มพารามิเตอร์นี้ด้วยเช่นกัน
// ตัวอย่างเช่นถ้า `Box` เปลี่ยนเป็น `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` ฟังก์ชันนี้จะต้องเปลี่ยนเป็น `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` เช่นกัน
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # ตัวจัดการข้อผิดพลาดในการจัดสรร

extern "Rust" {
    // นี่คือสัญลักษณ์เวทย์มนตร์เพื่อเรียกตัวจัดการข้อผิดพลาดการจัดสรรส่วนกลาง
    // rustc สร้างมันขึ้นมาเพื่อเรียกใช้ `__rg_oom` หากมี `#[alloc_error_handler]` หรือเพื่อเรียกการใช้งานเริ่มต้นที่ต่ำกว่า (`__rdl_oom`) เป็นอย่างอื่น
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// ยกเลิกข้อผิดพลาดหรือความล้มเหลวในการจัดสรรหน่วยความจำ
///
/// ผู้เรียกใช้ API การจัดสรรหน่วยความจำที่ต้องการยกเลิกการคำนวณเพื่อตอบสนองต่อข้อผิดพลาดในการจัดสรรขอแนะนำให้เรียกใช้ฟังก์ชันนี้แทนที่จะเรียกใช้ `panic!` โดยตรงหรือคล้ายกัน
///
///
/// ลักษณะการทำงานเริ่มต้นของฟังก์ชันนี้คือการพิมพ์ข้อความไปยังข้อผิดพลาดมาตรฐานและยกเลิกกระบวนการ
/// สามารถแทนที่ด้วย [`set_alloc_error_hook`] และ [`take_alloc_error_hook`]
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// สำหรับการทดสอบการจัดสรร `std::alloc::handle_alloc_error` สามารถใช้ได้โดยตรง
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // เรียกผ่าน `__rust_alloc_error_handler` ที่สร้างขึ้น

    // หากไม่มี `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // หากมี `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// เชี่ยวชาญการโคลนในหน่วยความจำที่จัดสรรไว้ล่วงหน้าและไม่ได้กำหนดค่าเริ่มต้น
/// ใช้โดย `Box::clone` และ `Rc`/`Arc::make_mut`
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // การจัดสรร *ครั้งแรก* อาจทำให้เครื่องมือเพิ่มประสิทธิภาพสามารถสร้างค่าที่โคลนขึ้นมาได้โดยข้ามโลคัลและย้าย
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // เราสามารถคัดลอกในสถานที่ได้ตลอดเวลาโดยไม่ต้องเกี่ยวข้องกับค่าท้องถิ่น
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}