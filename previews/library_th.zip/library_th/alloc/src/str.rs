//! สไลซ์สตริง Unicode
//!
//! *[See also the `str` primitive type](str).*
//!
//! ประเภท `&str` เป็นหนึ่งในสตริงหลักสองประเภทส่วนอีกประเภทคือ `String`
//! ซึ่งแตกต่างจากคู่ `String` เนื้อหาจะถูกยืม
//!
//! # การใช้งานพื้นฐาน
//!
//! การประกาศสตริงพื้นฐานของประเภท `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! ที่นี่เราได้ประกาศตัวอักษรสตริงหรือที่เรียกว่าสไลซ์สตริง
//! ตัวอักษรสตริงมีอายุการใช้งานคงที่ซึ่งหมายความว่าสตริง `hello_world` ได้รับการรับรองว่าใช้ได้ตลอดระยะเวลาของโปรแกรมทั้งหมด
//!
//! เราสามารถระบุอายุการใช้งานของ "hello_world" อย่างชัดเจนได้เช่นกัน:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// การใช้งานหลายอย่างในโมดูลนี้ใช้ในการกำหนดค่าการทดสอบเท่านั้น
// เพียงแค่ปิดคำเตือน unused_imports จะสะอาดกว่าที่จะแก้ไข
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` ใน `Concat<str>` ไม่มีความหมายที่นี่
/// พารามิเตอร์ประเภทนี้ของ trait มีอยู่เพื่อเปิดใช้งานการแสดงผลอื่นเท่านั้น
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // ลูปที่มีขนาดฮาร์ดโค้ดจะทำงานได้เร็วกว่ามากโดยเฉพาะกรณีที่มีความยาวตัวคั่นขนาดเล็ก
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // ทางเลือกขนาดที่ไม่ใช่ศูนย์โดยพลการ
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// เพิ่มประสิทธิภาพการใช้งานร่วมที่ใช้ได้กับทั้ง Vec<T>(T: Copy) และ Inner vec ของ String ปัจจุบัน (2018-05-13) มีข้อบกพร่องเกี่ยวกับการอนุมานประเภทและความเชี่ยวชาญ (ดูปัญหา #36262) ด้วยเหตุนี้ SliceConcat<T>ไม่เชี่ยวชาญสำหรับ T: Copy และ SliceConcat<str>เป็นผู้ใช้ฟังก์ชันนี้เพียงคนเดียว
// มันถูกทิ้งไว้ในสถานที่สำหรับเวลาที่ได้รับการแก้ไข
//
// ขอบเขตสำหรับ String-join คือ S: Borrow<str>และสำหรับ Vec-join Borrow <[T]> [T] และ str ทั้งสองกล่าวถึง AsRef <[T]> สำหรับบาง T
// => s.borrow().as_ref() และเรามีชิ้นส่วนอยู่เสมอ
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // ชิ้นแรกเป็นชิ้นเดียวที่ไม่มีตัวคั่นนำหน้า
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // คำนวณความยาวทั้งหมดที่แน่นอนของ Vec ที่เข้าร่วมหากการคำนวณ `len` ล้นเราจะ panic เราจะมีหน่วยความจำหมดอยู่ดีและฟังก์ชันที่เหลือต้องใช้ Vec ที่จัดสรรไว้ล่วงหน้าทั้งหมดเพื่อความปลอดภัย
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // เตรียมบัฟเฟอร์ที่ไม่ได้เริ่มต้น
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // คัดลอกตัวคั่นและชิ้นส่วนโดยไม่มีการตรวจสอบขอบเขตสร้างลูปพร้อมออฟเซ็ตฮาร์ดโค้ดสำหรับตัวคั่นขนาดเล็กปรับปรุงได้มาก (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // การใช้การยืมแบบแปลก ๆ อาจส่งคืนส่วนที่แตกต่างกันสำหรับการคำนวณความยาวและสำเนาจริง
        //
        // ตรวจสอบให้แน่ใจว่าเราไม่เปิดเผยไบต์ที่ไม่ได้กำหนดค่าเริ่มต้นให้กับผู้โทร
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// วิธีการสำหรับชิ้นสตริง
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// แปลง `Box<str>` เป็น `Box<[u8]>` โดยไม่ต้องคัดลอกหรือจัดสรร
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// แทนที่รูปแบบที่ตรงกันทั้งหมดด้วยสตริงอื่น
    ///
    /// `replace` สร้าง [`String`] ใหม่และคัดลอกข้อมูลจากสไลซ์สตริงนี้เข้าไป
    /// ในขณะที่ทำเช่นนั้นมันจะพยายามหารูปแบบที่ตรงกัน
    /// หากพบสิ่งใดสิ่งหนึ่งจะแทนที่ด้วยชิ้นสตริงทดแทน
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// เมื่อรูปแบบไม่ตรงกัน:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// แทนที่ N แรกที่ตรงกันของรูปแบบด้วยสตริงอื่น
    ///
    /// `replacen` สร้าง [`String`] ใหม่และคัดลอกข้อมูลจากสไลซ์สตริงนี้เข้าไป
    /// ในขณะที่ทำเช่นนั้นมันจะพยายามหารูปแบบที่ตรงกัน
    /// หากพบจะแทนที่ด้วยสไลซ์สตริงแทนที่มากที่สุด `count` เท่า
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// เมื่อรูปแบบไม่ตรงกัน:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // หวังว่าจะลดเวลาในการจัดสรรซ้ำ
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// ส่งคืนค่าตัวพิมพ์เล็กที่เทียบเท่ากับชิ้นสตริงนี้เป็น [`String`] ใหม่
    ///
    /// 'Lowercase' ถูกกำหนดตามเงื่อนไขของ Unicode Derived Core Property `Lowercase`
    ///
    /// เนื่องจากอักขระบางตัวสามารถขยายเป็นอักขระหลายตัวเมื่อเปลี่ยนเคสฟังก์ชันนี้จึงส่งคืน [`String`] แทนการแก้ไขพารามิเตอร์แทน
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// ตัวอย่างที่ยุ่งยากด้วยซิกม่า:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // แต่ท้ายคำมันคือςไม่ใช่σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// ภาษาที่ไม่มีตัวพิมพ์จะไม่เปลี่ยนแปลง:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σจับคู่กับσยกเว้นท้ายคำที่จับคู่กับς
                // นี่เป็น (contextual) แบบมีเงื่อนไขเท่านั้น แต่ไม่ขึ้นกับภาษาใน `SpecialCasing.txt` ดังนั้นจึงฮาร์ดโค้ดแทนที่จะมีกลไก "condition" ทั่วไป
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // สำหรับคำจำกัดความของ `Final_Sigma`
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// ส่งคืนค่าเทียบเท่าตัวพิมพ์ใหญ่ของส่วนสตริงนี้เป็น [`String`] ใหม่
    ///
    /// 'Uppercase' ถูกกำหนดตามเงื่อนไขของ Unicode Derived Core Property `Uppercase`
    ///
    /// เนื่องจากอักขระบางตัวสามารถขยายเป็นอักขระหลายตัวเมื่อเปลี่ยนเคสฟังก์ชันนี้จึงส่งคืน [`String`] แทนการแก้ไขพารามิเตอร์แทน
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// สคริปต์ที่ไม่มีตัวพิมพ์จะไม่เปลี่ยนแปลง:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// อักขระหนึ่งตัวสามารถกลายเป็นหลายตัวได้:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// แปลง [`Box<str>`] เป็น [`String`] โดยไม่ต้องคัดลอกหรือจัดสรร
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// สร้าง [`String`] ใหม่โดยการทำซ้ำสตริง `n` ครั้ง
    ///
    /// # Panics
    ///
    /// ฟังก์ชั่นนี้จะ panic หากความจุล้น
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// panic เมื่อล้น:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// ส่งคืนสำเนาของสตริงนี้โดยที่อักขระแต่ละตัวถูกแมปกับตัวพิมพ์ใหญ่ ASCII
    ///
    ///
    /// ตัวอักษร ASCII 'a' ถึง 'z' ถูกแมปกับ 'A' ถึง 'Z' แต่ตัวอักษรที่ไม่ใช่ ASCII จะไม่เปลี่ยนแปลง
    ///
    /// หากต้องการตัวพิมพ์ใหญ่ค่าแทนให้ใช้ [`make_ascii_uppercase`]
    ///
    /// หากต้องการใช้อักขระ ASCII ตัวพิมพ์ใหญ่นอกเหนือจากอักขระที่ไม่ใช่ ASCII ให้ใช้ [`to_uppercase`]
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() รักษาค่าคงที่ของ UTF-8
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// ส่งคืนสำเนาของสตริงนี้โดยที่อักขระแต่ละตัวถูกแมปกับ ASCII ตัวพิมพ์เล็กที่เทียบเท่า
    ///
    ///
    /// ตัวอักษร ASCII 'A' ถึง 'Z' ถูกแมปกับ 'a' ถึง 'z' แต่ตัวอักษรที่ไม่ใช่ ASCII จะไม่เปลี่ยนแปลง
    ///
    /// ในการพิมพ์ค่าให้เล็กลงให้ใช้ [`make_ascii_lowercase`]
    ///
    /// หากต้องการใช้อักขระ ASCII ตัวพิมพ์เล็กนอกเหนือจากอักขระที่ไม่ใช่ ASCII ให้ใช้ [`to_lowercase`]
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() รักษาค่าคงที่ของ UTF-8
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// แปลงชิ้นส่วนไบต์ที่บรรจุกล่องเป็นชิ้นสตริงแบบบรรจุกล่องโดยไม่ต้องตรวจสอบว่าสตริงนั้นมี UTF-8 ที่ถูกต้องหรือไม่
///
///
/// # Examples
///
/// การใช้งานพื้นฐาน:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}