#![stable(feature = "rust1", since = "1.0.0")]

//! ตัวชี้การนับอ้างอิงที่ปลอดภัยของเธรด
//!
//! ดูเอกสาร [`Arc<T>`][Arc] สำหรับรายละเอียดเพิ่มเติม

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// ขีด จำกัด อ่อนสำหรับจำนวนการอ้างอิงที่สามารถทำได้กับ `Arc`
///
/// เกินขีด จำกัด นี้จะยกเลิกโปรแกรมของคุณ (แม้ว่าจะไม่จำเป็น) ที่การอ้างอิง _exactly_ `MAX_REFCOUNT + 1`
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer ไม่รองรับกรอบหน่วยความจำ
// เพื่อหลีกเลี่ยงรายงานผลบวกที่ผิดพลาดในการใช้งาน Arc/Weak ให้ใช้โหลดอะตอมสำหรับการซิงโครไนซ์แทน
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// ตัวชี้การนับการอ้างอิงที่ปลอดภัยสำหรับเธรด 'Arc' ย่อมาจาก 'Atomically Reference Counted'
///
/// ประเภท `Arc<T>` จัดเตรียมความเป็นเจ้าของร่วมของค่าชนิด `T` ซึ่งจัดสรรในฮีปการเรียกใช้ [`clone`][clone] บน `Arc` จะสร้างอินสแตนซ์ `Arc` ใหม่ซึ่งชี้ไปที่การจัดสรรเดียวกันบนฮีปเป็น `Arc` ต้นทางในขณะที่เพิ่มจำนวนการอ้างอิง
/// เมื่อตัวชี้ `Arc` สุดท้ายไปยังการจัดสรรที่กำหนดถูกทำลายค่าที่เก็บไว้ในการจัดสรรนั้น (มักเรียกว่า "inner value") จะถูกทิ้งด้วย
///
/// การอ้างอิงที่ใช้ร่วมกันใน Rust ไม่อนุญาตให้มีการกลายพันธุ์ตามค่าเริ่มต้นและ `Arc` ก็ไม่มีข้อยกเว้น: โดยทั่วไปคุณไม่สามารถรับการอ้างอิงที่เปลี่ยนแปลงได้กับบางสิ่งภายใน `Arc` หากคุณต้องการกลายพันธุ์ผ่าน `Arc` ให้ใช้ [`Mutex`][mutex], [`RwLock`][rwlock] หรือ [`Atomic`][atomic] ประเภทใดประเภทหนึ่ง
///
/// ## ความปลอดภัยของด้าย
///
/// แตกต่างจาก [`Rc<T>`], `Arc<T>` ใช้การดำเนินการปรมาณูสำหรับการนับอ้างอิงซึ่งหมายความว่าปลอดภัยต่อเธรดข้อเสียคือการดำเนินการของอะตอมมีราคาแพงกว่าการเข้าถึงหน่วยความจำธรรมดาหากคุณไม่ได้แชร์การจัดสรรที่นับการอ้างอิงระหว่างเธรดให้พิจารณาใช้ [`Rc<T>`] สำหรับค่าโสหุ้ยที่ต่ำกว่า
/// [`Rc<T>`] เป็นค่าเริ่มต้นที่ปลอดภัยเนื่องจากคอมไพลเลอร์จะตรวจจับความพยายามใด ๆ ที่จะส่ง [`Rc<T>`] ระหว่างเธรด
/// อย่างไรก็ตามไลบรารีอาจเลือก `Arc<T>` เพื่อให้ผู้ใช้ไลบรารีมีความยืดหยุ่นมากขึ้น
///
/// `Arc<T>` จะใช้ [`Send`] และ [`Sync`] ตราบเท่าที่ `T` ใช้ [`Send`] และ [`Sync`]
/// เหตุใดคุณจึงไม่สามารถใส่ `T` ชนิดที่ไม่มีเธรดปลอดภัยใน `Arc<T>` เพื่อทำให้เธรดปลอดภัยได้?นี่อาจจะเป็นเรื่องที่ใช้งานง่ายในตอนแรก: ท้ายที่สุดแล้วความปลอดภัยของเธรด `Arc<T>` ไม่ใช่หรือ?กุญแจสำคัญคือ: `Arc<T>` ทำให้เธรดปลอดภัยที่จะมีการเป็นเจ้าของข้อมูลเดียวกันหลาย ๆ คน แต่ไม่ได้เพิ่มความปลอดภัยของเธรดให้กับข้อมูล
///
/// พิจารณา `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] ไม่ใช่ [`Sync`] และถ้า `Arc<T>` เป็น [`Send`] เสมอ `Arc <` [`RefCell<T>`]`>`ก็เช่นกัน
/// แต่เรามีปัญหา:
/// [`RefCell<T>`] ไม่ปลอดภัยด้าย;มันติดตามการนับการยืมโดยใช้การดำเนินการที่ไม่ใช่ปรมาณู
///
/// ท้ายที่สุดหมายความว่าคุณอาจต้องจับคู่ `Arc<T>` กับ [`std::sync`] บางประเภทโดยปกติคือ [`Mutex<T>`][mutex]
///
/// ## ทำลายรอบด้วย `Weak`
///
/// สามารถใช้วิธี [`downgrade`][downgrade] เพื่อสร้างตัวชี้ [`Weak`] ที่ไม่ใช่ของตนเองตัวชี้ [`Weak`] สามารถ [`upgrade`][อัพเกรด] d เป็น `Arc` ได้ แต่จะคืนค่า [`None`] หากค่าที่เก็บไว้ในการจัดสรรถูกทิ้งไปแล้ว
/// กล่าวอีกนัยหนึ่งพอยน์เตอร์ `Weak` จะไม่รักษามูลค่าภายในการจัดสรรให้คงอยู่อย่างไรก็ตามพวกเขา *ทำ* ให้การจัดสรร (ที่เก็บสำรองสำหรับมูลค่า) มีชีวิตอยู่
///
/// วงจรระหว่างตัวชี้ `Arc` จะไม่ถูกจัดสรร
/// ด้วยเหตุนี้จึงใช้ [`Weak`] ในการตัดวงจรตัวอย่างเช่นต้นไม้อาจมีพอยน์เตอร์ `Arc` ที่แข็งแกร่งจากโหนดแม่ไปยังลูก ๆ และ [`Weak`] พอยน์เตอร์จากเด็กกลับไปหาพ่อแม่
///
/// # การอ้างอิงการโคลน
///
/// การสร้างการอ้างอิงใหม่จากตัวชี้ที่นับการอ้างอิงที่มีอยู่ทำได้โดยใช้ `Clone` trait ที่ใช้กับ [`Arc<T>`][Arc] และ [`Weak<T>`][Weak]
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // ไวยากรณ์ทั้งสองด้านล่างนี้เทียบเท่ากัน
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b และ foo คือ Arcs ทั้งหมดที่ชี้ไปยังตำแหน่งหน่วยความจำเดียวกัน
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` ยกเลิกการอ้างอิงถึง `T` โดยอัตโนมัติ (ผ่าน [`Deref`][deref] trait) ดังนั้นคุณจึงสามารถเรียกเมธอดของ "T" โดยใช้ค่าประเภท `Arc<T>` เพื่อหลีกเลี่ยงการปะทะกันของชื่อกับเมธอดของ "T" เมธอดของ `Arc<T>` นั้นเป็นฟังก์ชันที่เกี่ยวข้องซึ่งเรียกโดยใช้ [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `อาร์ค<T>การใช้งาน traits เช่น `Clone` อาจเรียกได้ว่าใช้ไวยากรณ์ที่มีคุณสมบัติครบถ้วน
/// บางคนชอบใช้ไวยากรณ์ที่มีคุณสมบัติครบถ้วนในขณะที่บางคนชอบใช้ไวยากรณ์วิธีการโทร
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // วิธีการเรียกไวยากรณ์
/// let arc2 = arc.clone();
/// // ไวยากรณ์ที่มีคุณสมบัติครบถ้วน
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] ไม่ dereference อัตโนมัติเป็น `T` เนื่องจากค่าภายในอาจถูกทิ้งไปแล้ว
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// การแบ่งปันข้อมูลที่ไม่เปลี่ยนรูประหว่างเธรด:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// โปรดทราบว่าเรา **ไม่** เรียกใช้การทดสอบเหล่านี้ที่นี่
// ผู้สร้าง windows จะไม่พอใจอย่างยิ่งหากเธรดอยู่ได้นานกว่าเธรดหลักและจากนั้นออกไปในเวลาเดียวกัน (มีบางอย่างที่หยุดชะงัก) ดังนั้นเราจึงหลีกเลี่ยงสิ่งนี้โดยสิ้นเชิงโดยไม่เรียกใช้การทดสอบเหล่านี้
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// การแบ่งปัน [`AtomicUsize`] ที่ไม่แน่นอน:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// ดู [`rc` documentation][rc_examples] สำหรับตัวอย่างเพิ่มเติมของการนับอ้างอิงโดยทั่วไป
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` เป็นเวอร์ชันของ [`Arc`] ที่มีการอ้างอิงที่ไม่ได้เป็นเจ้าของไปยังการจัดสรรที่มีการจัดการ
/// การจัดสรรเข้าถึงได้โดยการเรียก [`upgrade`] บนตัวชี้ `Weak` ซึ่งจะส่งกลับ [`Option`]`<`[`Arc`] `<T>>".
///
/// เนื่องจากการอ้างอิง `Weak` ไม่นับรวมในการเป็นเจ้าของจึงจะไม่ป้องกันไม่ให้ค่าที่จัดเก็บในการจัดสรรหลุดออกไปและ `Weak` เองก็ไม่รับประกันว่ามูลค่าจะยังคงอยู่
///
/// ดังนั้นจึงอาจคืนค่า [`None`] เมื่อ [`upgrade`] d.
/// อย่างไรก็ตามโปรดทราบว่าการอ้างอิง `Weak`*จะ* ป้องกันไม่ให้มีการยกเลิกการจัดสรรตัวเอง (ที่เก็บสำรอง)
///
/// ตัวชี้ `Weak` มีประโยชน์ในการเก็บข้อมูลอ้างอิงชั่วคราวไปยังการจัดสรรที่จัดการโดย [`Arc`] โดยไม่ป้องกันไม่ให้ค่าภายในหลุดออกไป
/// นอกจากนี้ยังใช้เพื่อป้องกันการอ้างอิงแบบวงกลมระหว่างตัวชี้ [`Arc`] เนื่องจากการอ้างอิงที่เป็นเจ้าของร่วมกันจะไม่อนุญาตให้ [`Arc`] หลุด
/// ตัวอย่างเช่นต้นไม้อาจมีพอยน์เตอร์ [`Arc`] ที่แข็งแกร่งจากโหนดแม่ไปยังลูก ๆ และพอยน์เตอร์ `Weak` จากเด็กกลับไปหาพ่อแม่
///
/// วิธีทั่วไปในการรับตัวชี้ `Weak` คือการเรียก [`Arc::downgrade`]
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // นี่คือ `NonNull` ที่อนุญาตให้ปรับขนาดของประเภทนี้ใน enums ให้เหมาะสม แต่ไม่จำเป็นต้องเป็นตัวชี้ที่ถูกต้อง
    //
    // `Weak::new` ตั้งค่านี้เป็น `usize::MAX` เพื่อที่จะไม่ต้องจัดสรรพื้นที่บนฮีป
    // นั่นไม่ใช่ค่าที่ตัวชี้จริงจะเคยมีเพราะ RcBox มีการจัดตำแหน่งอย่างน้อย 2
    // เป็นไปได้เฉพาะเมื่อ `T: Sized`;`T` ที่ไม่มีขนาดไม่เคยห้อย
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// นี่คือการป้องกัน repr(C) ถึง future จากการจัดลำดับฟิลด์ที่เป็นไปได้ซึ่งจะรบกวน [into|from]_raw() ที่ปลอดภัยของประเภทภายในที่เปลี่ยนได้
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // ค่า usize::MAX ทำหน้าที่เป็นผู้พิทักษ์ชั่วคราวสำหรับ "locking" ความสามารถในการอัพเกรดตัวชี้ที่อ่อนแอหรือปรับลดรุ่นที่แข็งแกร่งใช้เพื่อหลีกเลี่ยงการแข่งขันใน `make_mut` และ `get_mut`
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// สร้าง `Arc<T>` ใหม่
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // เริ่มต้นตัวชี้ที่อ่อนแอนับเป็น 1 ซึ่งเป็นตัวชี้ที่อ่อนแอซึ่งถือโดยตัวชี้ที่แข็งแกร่งทั้งหมด (kinda) ดู std/rc.rs สำหรับข้อมูลเพิ่มเติม
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// สร้าง `Arc<T>` ใหม่โดยใช้การอ้างอิงที่อ่อนแอถึงตัวมันเอง
    /// การพยายามอัปเกรดการอ้างอิงที่อ่อนแอก่อนที่ฟังก์ชันนี้จะส่งกลับจะทำให้ได้ค่า `None`
    /// อย่างไรก็ตามการอ้างอิงที่อ่อนแออาจถูกโคลนได้อย่างอิสระและเก็บไว้เพื่อใช้ในภายหลัง
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // สร้างด้านในในสถานะ "uninitialized" ด้วยการอ้างอิงที่อ่อนแอเพียงครั้งเดียว
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // สิ่งสำคัญคือเราต้องไม่เลิกเป็นเจ้าของตัวชี้ที่อ่อนแอมิฉะนั้นหน่วยความจำอาจถูกปลดปล่อยเมื่อ `data_fn` กลับมา
        // หากเราต้องการส่งต่อความเป็นเจ้าของจริงๆเราสามารถสร้างตัวชี้ที่อ่อนแอเพิ่มเติมสำหรับตัวเราเองได้ แต่จะส่งผลให้มีการอัปเดตเพิ่มเติมเกี่ยวกับจำนวนอ้างอิงที่อ่อนแอซึ่งอาจไม่จำเป็น
        //
        //
        //
        //
        let data = data_fn(&weak);

        // ตอนนี้เราสามารถเริ่มต้นค่าภายในได้อย่างถูกต้องและเปลี่ยนการอ้างอิงที่อ่อนแอของเราให้เป็นการอ้างอิงที่แข็งแกร่ง
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // การเขียนด้านบนลงในฟิลด์ข้อมูลจะต้องมองเห็นได้กับเธรดใด ๆ ที่สังเกตเห็นการนับที่แข็งแกร่งที่ไม่ใช่ศูนย์
            // ดังนั้นเราจึงต้องมีการสั่งซื้อ "Release" เป็นอย่างน้อยเพื่อที่จะซิงโครไนซ์กับ `compare_exchange_weak` ใน `Weak::upgrade`
            //
            // "Acquire" ไม่จำเป็นต้องสั่งซื้อ
            // เมื่อพิจารณาถึงพฤติกรรมที่เป็นไปได้ของ `data_fn` เราจำเป็นต้องดูว่ามันสามารถทำอะไรได้บ้างเมื่ออ้างอิงถึง `Weak` ที่ไม่สามารถอัพเกรดได้:
            //
            // - มันสามารถ *โคลน*`Weak` เพิ่มจำนวนอ้างอิงที่อ่อนแอ
            // - มันสามารถดร็อปโคลนเหล่านั้นลดจำนวนอ้างอิงที่อ่อนแอ (แต่จะไม่เป็นศูนย์)
            //
            // ผลข้างเคียงเหล่านี้ไม่ส่งผลกระทบต่อเรา แต่อย่างใดและไม่มีผลข้างเคียงอื่น ๆ ที่เป็นไปได้ด้วยรหัสปลอดภัยเพียงอย่างเดียว
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // การอ้างอิงที่ชัดเจนควรเป็นเจ้าของการอ้างอิงที่ไม่เหมาะสมร่วมกันดังนั้นอย่าเรียกใช้ destructor สำหรับการอ้างอิงที่อ่อนแอแบบเก่าของเรา
        //
        mem::forget(weak);
        strong
    }

    /// สร้าง `Arc` ใหม่ที่มีเนื้อหาที่ไม่ได้กำหนดค่าเริ่มต้น
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // การเริ่มต้นรอการตัดบัญชี:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// สร้าง `Arc` ใหม่ที่มีเนื้อหาที่ไม่ได้กำหนดค่าเริ่มต้นโดยที่หน่วยความจำเต็มไปด้วย `0` ไบต์
    ///
    ///
    /// ดู [`MaybeUninit::zeroed`][zeroed] สำหรับตัวอย่างการใช้วิธีนี้ที่ถูกต้องและไม่ถูกต้อง
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// สร้าง `Pin<Arc<T>>` ใหม่
    /// หาก `T` ไม่ใช้ `Unpin` `data` จะถูกตรึงไว้ในหน่วยความจำและไม่สามารถย้ายได้
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// สร้าง `Arc<T>` ใหม่ส่งคืนข้อผิดพลาดหากการจัดสรรล้มเหลว
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // เริ่มต้นตัวชี้ที่อ่อนแอนับเป็น 1 ซึ่งเป็นตัวชี้ที่อ่อนแอซึ่งถือโดยตัวชี้ที่แข็งแกร่งทั้งหมด (kinda) ดู std/rc.rs สำหรับข้อมูลเพิ่มเติม
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// สร้าง `Arc` ใหม่ที่มีเนื้อหาที่ไม่ได้กำหนดค่าเริ่มต้นส่งคืนข้อผิดพลาดหากการจัดสรรล้มเหลว
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // การเริ่มต้นรอการตัดบัญชี:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// สร้าง `Arc` ใหม่ที่มีเนื้อหาที่ไม่ได้กำหนดค่าเริ่มต้นโดยที่หน่วยความจำเต็มไปด้วย `0` ไบต์ส่งคืนข้อผิดพลาดหากการจัดสรรล้มเหลว
    ///
    ///
    /// ดู [`MaybeUninit::zeroed`][zeroed] สำหรับตัวอย่างการใช้วิธีนี้ที่ถูกต้องและไม่ถูกต้อง
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// ส่งคืนค่าภายในหาก `Arc` มีการอ้างอิงที่ชัดเจนเพียงรายการเดียว
    ///
    /// มิฉะนั้น [`Err`] จะถูกส่งคืนพร้อมกับ `Arc` เดียวกับที่ส่งผ่าน
    ///
    ///
    /// สิ่งนี้จะประสบความสำเร็จแม้ว่าจะมีการอ้างอิงที่อ่อนแอมากก็ตาม
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // สร้างตัวชี้ที่อ่อนแอเพื่อล้างข้อมูลอ้างอิงที่คาดเดายากโดยปริยาย
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// สร้างชิ้นส่วนที่นับการอ้างอิงด้วยอะตอมใหม่ที่มีเนื้อหาที่ไม่ได้กำหนดค่าเริ่มต้น
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // การเริ่มต้นรอการตัดบัญชี:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// สร้างชิ้นส่วนที่มีการนับการอ้างอิงแบบอะตอมใหม่ที่มีเนื้อหาที่ไม่ได้กำหนดค่าเริ่มต้นโดยที่หน่วยความจำจะเต็มไปด้วย `0` ไบต์
    ///
    ///
    /// ดู [`MaybeUninit::zeroed`][zeroed] สำหรับตัวอย่างการใช้วิธีนี้ที่ถูกต้องและไม่ถูกต้อง
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// แปลงเป็น `Arc<T>`
    ///
    /// # Safety
    ///
    /// เช่นเดียวกับ [`MaybeUninit::assume_init`] ผู้เรียกใช้จะต้องรับประกันว่าค่าภายในอยู่ในสถานะเริ่มต้นจริงๆ
    ///
    /// การเรียกสิ่งนี้เมื่อเนื้อหายังไม่ได้เริ่มต้นอย่างสมบูรณ์จะทำให้เกิดพฤติกรรมที่ไม่ได้กำหนดในทันที
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // การเริ่มต้นรอการตัดบัญชี:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// แปลงเป็น `Arc<[T]>`
    ///
    /// # Safety
    ///
    /// เช่นเดียวกับ [`MaybeUninit::assume_init`] ผู้เรียกใช้จะต้องรับประกันว่าค่าภายในอยู่ในสถานะเริ่มต้นจริงๆ
    ///
    /// การเรียกสิ่งนี้เมื่อเนื้อหายังไม่ได้เริ่มต้นอย่างสมบูรณ์จะทำให้เกิดพฤติกรรมที่ไม่ได้กำหนดในทันที
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // การเริ่มต้นรอการตัดบัญชี:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// ใช้ `Arc` ส่งคืนตัวชี้ที่ถูกห่อ
    ///
    /// เพื่อหลีกเลี่ยงการรั่วไหลของหน่วยความจำตัวชี้จะต้องถูกแปลงกลับเป็น `Arc` โดยใช้ [`Arc::from_raw`]
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// แสดงตัวชี้ดิบไปยังข้อมูล
    ///
    /// การนับจะไม่ได้รับผลกระทบ แต่อย่างใดและ `Arc` จะไม่ถูกใช้
    /// ตัวชี้สามารถใช้ได้ตราบเท่าที่มีการนับจำนวนมากใน `Arc`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // ความปลอดภัย: ไม่สามารถผ่าน Deref::deref หรือ RcBoxPtr::inner ได้เนื่องจาก
        // สิ่งนี้จำเป็นเพื่อรักษาแหล่งที่มาของ raw/mut ไว้เช่นนั้น
        // `get_mut` สามารถเขียนผ่านตัวชี้หลังจากกู้คืน Rc ผ่าน `from_raw`
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// สร้าง `Arc<T>` จากตัวชี้ดิบ
    ///
    /// ตัวชี้ดิบต้องถูกส่งคืนก่อนหน้านี้โดยการเรียกไปที่ [`Arc<U>::into_raw`][into_raw] โดยที่ `U` ต้องมีขนาดและการจัดแนวเดียวกันกับ `T`
    /// นี่เป็นความจริงเล็กน้อยถ้า `U` คือ `T`
    /// โปรดทราบว่าหาก `U` ไม่ใช่ `T` แต่มีขนาดและการจัดตำแหน่งเดียวกันโดยพื้นฐานแล้วจะเหมือนกับการส่งข้อมูลอ้างอิงประเภทต่างๆ
    /// ดู [`mem::transmute`][transmute] สำหรับข้อมูลเพิ่มเติมเกี่ยวกับข้อ จำกัด ที่ใช้ในกรณีนี้
    ///
    /// ผู้ใช้ `from_raw` ต้องแน่ใจว่าค่าเฉพาะของ `T` ลดลงเพียงครั้งเดียว
    ///
    /// ฟังก์ชันนี้ไม่ปลอดภัยเนื่องจากการใช้งานที่ไม่เหมาะสมอาจทำให้หน่วยความจำไม่ปลอดภัยแม้ว่าจะไม่มีการเข้าถึง `Arc<T>` ที่ส่งคืนก็ตาม
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // แปลงกลับเป็น `Arc` เพื่อป้องกันการรั่วไหล
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // การโทรไปยัง `Arc::from_raw(x_ptr)` เพิ่มเติมจะทำให้หน่วยความจำไม่ปลอดภัย
    /// }
    ///
    /// // หน่วยความจำได้รับการปลดปล่อยเมื่อ `x` ออกนอกขอบเขตด้านบนดังนั้น `x_ptr` จึงห้อยอยู่ในขณะนี้!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // ย้อนกลับค่าชดเชยเพื่อค้นหา ArcInner ดั้งเดิม
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// สร้างตัวชี้ [`Weak`] ใหม่สำหรับการจัดสรรนี้
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Relaxed นี้ใช้ได้เพราะเรากำลังตรวจสอบค่าใน CAS ด้านล่าง
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // ตรวจสอบว่าตัวนับที่อ่อนแอในขณะนี้คือ "locked" หรือไม่ถ้าเป็นเช่นนั้นให้หมุน
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: ขณะนี้รหัสนี้ไม่สนใจความเป็นไปได้ที่จะเกิดการล้น
            // เป็น usize::MAX;โดยทั่วไปต้องปรับทั้ง Rc และ Arc เพื่อจัดการกับการล้น
            //

            // แตกต่างจาก Clone() เราต้องการให้สิ่งนี้เป็น Acquire read เพื่อซิงโครไนซ์กับการเขียนที่มาจาก `is_unique` เพื่อให้เหตุการณ์ก่อนการเขียนนั้นเกิดขึ้นก่อนการอ่านครั้งนี้
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // ตรวจสอบให้แน่ใจว่าเราไม่ได้สร้างจุดอ่อนที่ห้อยลงมา
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// รับจำนวนตัวชี้ [`Weak`] สำหรับการจัดสรรนี้
    ///
    /// # Safety
    ///
    /// วิธีนี้ปลอดภัย แต่การใช้อย่างถูกต้องต้องใช้ความระมัดระวังเป็นพิเศษ
    /// เธรดอื่นสามารถเปลี่ยนจำนวนที่อ่อนแอได้ตลอดเวลารวมถึงอาจเกิดขึ้นระหว่างการเรียกใช้เมธอดนี้และดำเนินการกับผลลัพธ์
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // การยืนยันนี้ถูกกำหนดเนื่องจากเราไม่ได้แชร์ `Arc` หรือ `Weak` ระหว่างเธรด
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // หากการนับที่อ่อนแอถูกล็อคอยู่ในขณะนี้ค่าของการนับจะเป็น 0 ก่อนที่จะทำการล็อก
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// รับจำนวนพอยน์เตอร์ (`Arc`) ที่แข็งแกร่งสำหรับการจัดสรรนี้
    ///
    /// # Safety
    ///
    /// วิธีนี้ปลอดภัย แต่การใช้อย่างถูกต้องต้องใช้ความระมัดระวังเป็นพิเศษ
    /// เธรดอื่นสามารถเปลี่ยนจำนวนที่แข็งแกร่งได้ตลอดเวลารวมถึงอาจเกิดขึ้นระหว่างการเรียกใช้เมธอดนี้และดำเนินการกับผลลัพธ์
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // การยืนยันนี้ถูกกำหนดเนื่องจากเราไม่ได้แชร์ `Arc` ระหว่างเธรด
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// เพิ่มจำนวนการอ้างอิงที่คาดเดายากบน `Arc<T>` ที่เชื่อมโยงกับตัวชี้ที่ให้มาทีละตัว
    ///
    /// # Safety
    ///
    /// ตัวชี้ต้องได้รับผ่าน `Arc::into_raw` และอินสแตนซ์ `Arc` ที่เกี่ยวข้องต้องถูกต้อง (เช่น
    /// จำนวนที่แข็งแกร่งต้องมีอย่างน้อย 1) ตลอดระยะเวลาของวิธีนี้
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // การยืนยันนี้ถูกกำหนดเนื่องจากเราไม่ได้แชร์ `Arc` ระหว่างเธรด
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // เก็บ Arc ไว้ แต่อย่าแตะต้องการนับซ้ำโดยการห่อด้วย ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // ตอนนี้เพิ่มจำนวนการอ้างอิง แต่อย่าทิ้งการอ้างอิงใหม่ด้วย
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// ลดจำนวนการอ้างอิงที่คาดเดายากบน `Arc<T>` ที่เชื่อมโยงกับตัวชี้ที่ให้มาทีละตัว
    ///
    /// # Safety
    ///
    /// ตัวชี้ต้องได้รับผ่าน `Arc::into_raw` และอินสแตนซ์ `Arc` ที่เกี่ยวข้องต้องถูกต้อง (เช่น
    /// จำนวนที่แข็งแกร่งต้องมีอย่างน้อย 1) เมื่อเรียกใช้วิธีนี้
    /// วิธีนี้สามารถใช้เพื่อปล่อย `Arc` สุดท้ายและหน่วยความจำสำรองได้ แต่ **ไม่ควรเรียกใช้** หลังจาก `Arc` สุดท้ายได้รับการเผยแพร่แล้ว
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // การยืนยันเหล่านั้นเป็นสิ่งที่กำหนดได้เนื่องจากเราไม่ได้แชร์ `Arc` ระหว่างเธรด
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // ความไม่ปลอดภัยนี้ไม่เป็นไรเพราะในขณะที่ส่วนโค้งนี้ยังมีชีวิตอยู่เรารับประกันได้ว่าตัวชี้ด้านในนั้นถูกต้อง
        // นอกจากนี้เราทราบว่าโครงสร้าง `ArcInner` เองก็คือ `Sync` เนื่องจากข้อมูลภายในคือ `Sync` เช่นกันดังนั้นเราจึงสามารถยืมตัวชี้ที่ไม่เปลี่ยนรูปไปยังเนื้อหาเหล่านี้ได้
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // ส่วนที่ไม่อยู่ในบรรทัดของ `drop`
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // ทำลายข้อมูลในขณะนี้แม้ว่าเราอาจไม่ได้ทำให้การจัดสรรกล่องเป็นอิสระ (อาจยังมีตัวชี้ที่อ่อนแออยู่)
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // ทิ้งการอ้างอิงที่อ่อนแอซึ่งจัดขึ้นโดยการอ้างอิงที่แข็งแกร่งทั้งหมด
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// ส่งคืน `true` หาก "ส่วนโค้ง" ทั้งสองชี้ไปที่การจัดสรรเดียวกัน (ในหลอดเลือดดำที่คล้ายกับ [`ptr::eq`])
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// จัดสรร `ArcInner<T>` ที่มีพื้นที่เพียงพอสำหรับค่าภายในที่อาจไม่ได้ปรับขนาดโดยที่ค่ามีเค้าโครงที่จัดเตรียมไว้
    ///
    /// ฟังก์ชัน `mem_to_arcinner` ถูกเรียกด้วยตัวชี้ข้อมูลและต้องส่งกลับตัวชี้ (อาจอ้วน) กลับมาสำหรับ `ArcInner<T>`
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // คำนวณเค้าโครงโดยใช้เค้าโครงค่าที่กำหนด
        // ก่อนหน้านี้เค้าโครงถูกคำนวณบนนิพจน์ `&*(ptr as* const ArcInner<T>)` แต่สิ่งนี้สร้างการอ้างอิงที่ไม่ตรงแนว (ดู #54908)
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// จัดสรร `ArcInner<T>` ที่มีพื้นที่เพียงพอสำหรับค่าภายในที่อาจไม่ได้ปรับขนาดโดยที่ค่ามีเค้าโครงที่จัดเตรียมไว้ส่งคืนข้อผิดพลาดหากการจัดสรรล้มเหลว
    ///
    ///
    /// ฟังก์ชัน `mem_to_arcinner` ถูกเรียกด้วยตัวชี้ข้อมูลและต้องส่งกลับตัวชี้ (อาจอ้วน) กลับมาสำหรับ `ArcInner<T>`
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // คำนวณเค้าโครงโดยใช้เค้าโครงค่าที่กำหนด
        // ก่อนหน้านี้เค้าโครงถูกคำนวณบนนิพจน์ `&*(ptr as* const ArcInner<T>)` แต่สิ่งนี้สร้างการอ้างอิงที่ไม่ตรงแนว (ดู #54908)
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // เริ่มต้น ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// จัดสรร `ArcInner<T>` ที่มีพื้นที่เพียงพอสำหรับค่าภายในที่ไม่ได้กำหนดขนาด
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // จัดสรรสำหรับ `ArcInner<T>` โดยใช้ค่าที่กำหนด
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // คัดลอกค่าเป็นไบต์
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // ปลดปล่อยการจัดสรรโดยไม่ทิ้งเนื้อหา
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// จัดสรร `ArcInner<[T]>` ตามความยาวที่กำหนด
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// คัดลอกองค์ประกอบจากชิ้นส่วนไปยัง Arc <\[T\]> ที่จัดสรรใหม่
    ///
    /// ไม่ปลอดภัยเนื่องจากผู้โทรต้องเป็นเจ้าของหรือผูก `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// สร้าง `Arc<[T]>` จากตัววนซ้ำที่ทราบว่ามีขนาดที่แน่นอน
    ///
    /// พฤติกรรมไม่ได้กำหนดหากขนาดไม่ถูกต้อง
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic ป้องกันขณะโคลนองค์ประกอบ T
        // ในกรณีของ panic องค์ประกอบที่ถูกเขียนลงใน ArcInner ใหม่จะถูกทิ้งจากนั้นหน่วยความจำจะถูกปลดปล่อย
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // ชี้ไปที่องค์ประกอบแรก
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // ทุกอย่างชัดเจนลืมยามเพื่อไม่ให้ ArcInner ใหม่เป็นอิสระ
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// ความเชี่ยวชาญ trait ใช้สำหรับ `From<&[T]>`
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// สร้างโคลนของตัวชี้ `Arc`
    ///
    /// สิ่งนี้จะสร้างตัวชี้อื่นไปยังการจัดสรรเดียวกันโดยเพิ่มจำนวนการอ้างอิงที่คาดเดายาก
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // การใช้การเรียงลำดับแบบสบาย ๆ เป็นเรื่องปกติที่นี่เนื่องจากความรู้เกี่ยวกับการอ้างอิงต้นฉบับจะป้องกันไม่ให้เธรดอื่น ๆ ลบออบเจ็กต์อย่างไม่ถูกต้อง
        //
        // ตามที่อธิบายไว้ใน [Boost documentation][1] การเพิ่มตัวนับการอ้างอิงสามารถทำได้ด้วย memory_order_relaxed เสมอ: การอ้างอิงใหม่ไปยังอ็อบเจ็กต์สามารถสร้างได้จากการอ้างอิงที่มีอยู่เท่านั้นและการส่งการอ้างอิงที่มีอยู่จากเธรดหนึ่งไปยังอีกเธรดจะต้องมีการซิงโครไนซ์ที่จำเป็น
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // อย่างไรก็ตามเราจำเป็นต้องป้องกันการนับจำนวนมากในกรณีที่มีคน "mem: : ลืม" Arcs
        // หากเราไม่ทำเช่นนี้จำนวนอาจล้นและผู้ใช้จะใช้งานได้ฟรี
        // เราอิ่มตัวอย่างรวดเร็วถึง `isize::MAX` โดยสมมติว่าไม่มีเธรด ~2 พันล้านเธรดที่เพิ่มจำนวนการอ้างอิงในครั้งเดียว
        //
        // branch นี้จะไม่ถูกนำไปใช้ในโปรแกรมจริงใด ๆ
        //
        // เรายกเลิกเนื่องจากโปรแกรมดังกล่าวมีความเสื่อมโทรมอย่างไม่น่าเชื่อและเราไม่สนใจที่จะสนับสนุน
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// ทำการอ้างอิงที่ไม่แน่นอนใน `Arc` ที่กำหนด
    ///
    /// หากมีตัวชี้ `Arc` หรือ [`Weak`] อื่นสำหรับการจัดสรรเดียวกัน `make_mut` จะสร้างการจัดสรรใหม่และเรียกใช้ [`clone`][clone] ในค่าภายในเพื่อให้แน่ใจว่าเป็นเจ้าของที่ไม่ซ้ำกัน
    /// สิ่งนี้เรียกอีกอย่างว่าโคลนเมื่อเขียน
    ///
    /// โปรดทราบว่าสิ่งนี้แตกต่างจากลักษณะการทำงานของ [`Rc::make_mut`] ซึ่งแยกตัวชี้ `Weak` ที่เหลือออกไป
    ///
    /// ดู [`get_mut`][get_mut] ด้วยซึ่งจะล้มเหลวมากกว่าการโคลนนิ่ง
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // จะไม่โคลนอะไรเลย
    /// let mut other_data = Arc::clone(&data); // จะไม่โคลนข้อมูลภายใน
    /// *Arc::make_mut(&mut data) += 1;         // โคลนข้อมูลภายใน
    /// *Arc::make_mut(&mut data) += 1;         // จะไม่โคลนอะไรเลย
    /// *Arc::make_mut(&mut other_data) *= 2;   // จะไม่โคลนอะไรเลย
    ///
    /// // ตอนนี้ `data` และ `other_data` ชี้ไปที่การจัดสรรที่แตกต่างกัน
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // โปรดทราบว่าเรามีทั้งการอ้างอิงที่ชัดเจนและการอ้างอิงที่อ่อนแอ
        // ดังนั้นการปล่อยการอ้างอิงที่ชัดเจนของเราเท่านั้นจะไม่ทำให้หน่วยความจำถูกยกเลิกการจัดสรรโดยตัวมันเอง
        //
        // ใช้ Acquire เพื่อให้แน่ใจว่าเราเห็นการเขียนใด ๆ ถึง `weak` ที่เกิดขึ้นก่อนที่จะรีลีสเขียน (กล่าวคือลดลง) เป็น `strong`
        // เนื่องจากเรามีจำนวนที่อ่อนแอจึงไม่มีโอกาสที่ ArcInner จะสามารถยกเลิกการจัดสรรได้
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // มีตัวชี้ที่แข็งแกร่งอีกตัวหนึ่งดังนั้นเราจึงต้องโคลน
            // จัดสรรหน่วยความจำล่วงหน้าเพื่อให้สามารถเขียนค่าที่โคลนได้โดยตรง
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // ผ่อนคลายพอเพียงในข้างต้นเพราะนี่คือการเพิ่มประสิทธิภาพโดยพื้นฐาน: เรามักจะแข่งกับจุดอ่อนที่ถูกทิ้ง
            // ที่แย่ที่สุดคือเราต้องจัดสรร Arc ใหม่โดยไม่จำเป็น
            //

            // เราลบการอ้างอิงที่แข็งแกร่งล่าสุดออกไป แต่ยังมีการอ้างอิงที่อ่อนแอเพิ่มเติมเหลืออยู่
            // เราจะย้ายเนื้อหาไปยัง Arc ใหม่และทำให้การอ้างอิงที่อ่อนแออื่น ๆ เป็นโมฆะ
            //

            // โปรดทราบว่าการอ่าน `weak` ให้ผลลัพธ์ usize::MAX (เช่นล็อก) ไม่ได้เนื่องจากจำนวนที่อ่อนแอสามารถล็อกได้โดยเธรดที่มีการอ้างอิงที่รัดกุมเท่านั้น
            //
            //

            // กำหนดตัวชี้ที่อ่อนแอโดยนัยของเราเองเพื่อให้สามารถทำความสะอาด ArcInner ได้ตามต้องการ
            //
            let _weak = Weak { ptr: this.ptr };

            // สามารถขโมยข้อมูลได้ทั้งหมดที่เหลือก็คือจุดอ่อน
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // เราเป็นข้อมูลอ้างอิง แต่เพียงผู้เดียวในประเภทใดกลับขึ้นนับการอ้างอิงที่แข็งแกร่ง
            //
            this.inner().strong.store(1, Release);
        }

        // เช่นเดียวกับ `get_mut()` ความไม่ปลอดภัยนั้นไม่เป็นไรเนื่องจากการอ้างอิงของเราไม่ซ้ำกันในการเริ่มต้นหรือกลายเป็นหนึ่งเดียวเมื่อโคลนเนื้อหา
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// ส่งคืนการอ้างอิงที่เปลี่ยนแปลงได้ใน `Arc` ที่กำหนดหากไม่มีตัวชี้ `Arc` หรือ [`Weak`] อื่นในการจัดสรรเดียวกัน
    ///
    ///
    /// ส่งคืนค่า [`None`] ไม่เช่นนั้นเนื่องจากไม่ปลอดภัยที่จะเปลี่ยนค่าที่ใช้ร่วมกัน
    ///
    /// ดู [`make_mut`][make_mut] ด้วยซึ่งจะ [`clone`][clone] เป็นค่าภายในเมื่อมีพอยน์เตอร์อื่น ๆ
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // ความไม่ปลอดภัยนี้ไม่เป็นไรเพราะเรารับประกันว่าตัวชี้ที่ส่งกลับเป็นตัวชี้ *เท่านั้น* ที่จะถูกส่งกลับไปที่ T
            // จำนวนอ้างอิงของเรารับประกันได้ว่าเป็น 1 ณ จุดนี้และเรากำหนดให้ส่วนโค้งเป็น `mut` ดังนั้นเราจึงส่งคืนการอ้างอิงที่เป็นไปได้เพียงอย่างเดียวไปยังข้อมูลภายใน
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// ส่งคืนการอ้างอิงที่เปลี่ยนแปลงได้ใน `Arc` ที่ระบุโดยไม่ต้องมีการตรวจสอบใด ๆ
    ///
    /// ดู [`get_mut`] ด้วยซึ่งปลอดภัยและทำการตรวจสอบที่เหมาะสม
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// ตัวชี้ `Arc` หรือ [`Weak`] อื่น ๆ สำหรับการจัดสรรเดียวกันจะต้องไม่ถูกอ้างถึงในช่วงระยะเวลาของการยืมคืน
    ///
    /// นี่เป็นกรณีเล็กน้อยหากไม่มีตัวชี้ดังกล่าวตัวอย่างเช่นทันทีหลังจาก `Arc::new`
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // เราระมัดระวังที่จะ *ไม่* สร้างการอ้างอิงที่ครอบคลุมฟิลด์ "count" เนื่องจากจะใช้แทนการเข้าถึงจำนวนการอ้างอิงพร้อมกัน (เช่น
        // โดย `Weak`)
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// ตรวจสอบว่านี่เป็นการอ้างอิงที่ไม่ซ้ำกัน (รวมถึงการอ้างอิงที่อ่อนแอ) ไปยังข้อมูลพื้นฐานหรือไม่
    ///
    ///
    /// โปรดทราบว่าสิ่งนี้ต้องการการล็อกจำนวนอ้างอิงที่อ่อนแอ
    fn is_unique(&mut self) -> bool {
        // ล็อคการนับตัวชี้ที่อ่อนแอหากดูเหมือนว่าเราเป็นผู้ถือตัวชี้ที่อ่อนแอเพียงคนเดียว
        //
        // ป้ายกำกับการได้รับที่นี่ช่วยให้มั่นใจได้ถึงความสัมพันธ์ที่เกิดขึ้นก่อนหน้ากับการเขียนใด ๆ ไปยัง `strong` (โดยเฉพาะใน `Weak::upgrade`) ก่อนที่จำนวน `weak` จะลดลง (ผ่าน `Weak::drop` ซึ่งใช้รีลีส)
        // หากการอ้างอิงจุดอ่อนที่อัปเกรดไม่เคยหลุด CAS ที่นี่จะล้มเหลวดังนั้นเราจึงไม่สนใจที่จะซิงโครไนซ์
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // สิ่งนี้จำเป็นต้องเป็น `Acquire` เพื่อซิงโครไนซ์กับการลดลงของตัวนับ `strong` ใน `drop`-การเข้าถึงเดียวที่เกิดขึ้นเมื่อมีการอ้างอิงใด ๆ ยกเว้นการอ้างอิงสุดท้าย
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // การเขียนเผยแพร่ที่นี่จะซิงโครไนซ์กับการอ่านใน `downgrade` ซึ่งป้องกันไม่ให้การอ่าน `strong` ข้างต้นเกิดขึ้นหลังจากการเขียนได้อย่างมีประสิทธิภาพ
            //
            //
            self.inner().weak.store(1, Release); // ปลดล็อค
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// วาง `Arc`
    ///
    /// สิ่งนี้จะลดจำนวนการอ้างอิงที่คาดเดายาก
    /// หากจำนวนอ้างอิงที่แข็งแกร่งถึงศูนย์การอ้างอิงอื่น ๆ (ถ้ามี) เท่านั้นคือ [`Weak`] ดังนั้นเราจึง `drop` เป็นค่าภายใน
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // ไม่พิมพ์อะไรเลย
    /// drop(foo2);   // พิมพ์ "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // เนื่องจาก `fetch_sub` เป็นปรมาณูอยู่แล้วเราจึงไม่จำเป็นต้องซิงโครไนซ์กับเธรดอื่นเว้นแต่เราจะลบอ็อบเจ็กต์
        // ตรรกะเดียวกันนี้ใช้กับ `fetch_sub` ด้านล่างกับจำนวน `weak`
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // จำเป็นต้องใช้รั้วนี้เพื่อป้องกันการจัดลำดับการใช้ข้อมูลใหม่และการลบข้อมูล
        // เนื่องจากมีการทำเครื่องหมาย `Release` จำนวนอ้างอิงที่ลดลงจึงซิงโครไนซ์กับรั้ว `Acquire` นี้
        // ซึ่งหมายความว่าการใช้ข้อมูลจะเกิดขึ้นก่อนที่จะลดจำนวนการอ้างอิงซึ่งเกิดขึ้นก่อนรั้วนี้ซึ่งเกิดขึ้นก่อนการลบข้อมูล
        //
        // ตามที่อธิบายไว้ใน [Boost documentation][1]
        //
        // > เป็นสิ่งสำคัญในการบังคับใช้การเข้าถึงวัตถุใด ๆ ที่เป็นไปได้ในหนึ่งเดียว
        // > เธรด (ผ่านการอ้างอิงที่มีอยู่) ถึง *เกิดขึ้นก่อน* ลบ
        // > วัตถุในเธรดอื่นสิ่งนี้ทำได้โดย "release"
        // > การดำเนินการหลังจากทิ้งการอ้างอิง (การเข้าถึงวัตถุใด ๆ
        // > ผ่านการอ้างอิงนี้อย่างชัดเจนต้องเกิดขึ้นก่อน) และไฟล์
        // > "acquire" ก่อนที่จะลบวัตถุ
        //
        // โดยเฉพาะอย่างยิ่งในขณะที่เนื้อหาของ Arc มักจะไม่เปลี่ยนรูป แต่ก็เป็นไปได้ที่จะมีการเขียนภายในถึงบางสิ่งเช่น Mutex<T>.
        // เนื่องจาก Mutex ไม่ได้รับเมื่อถูกลบเราจึงไม่สามารถพึ่งพาตรรกะการซิงโครไนซ์เพื่อทำการเขียนในเธรด A ที่มองเห็นได้โดยผู้ทำลายที่ทำงานในเธรด B
        //
        //
        // นอกจากนี้โปรดทราบว่า Acquire fence ที่นี่อาจถูกแทนที่ด้วย Acquire load ซึ่งสามารถปรับปรุงประสิทธิภาพในสถานการณ์ที่มีการแข่งขันสูงดู [2]
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// พยายามดาวน์แคสต์ `Arc<dyn Any + Send + Sync>` เป็นคอนกรีต
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// สร้าง `Weak<T>` ใหม่โดยไม่ต้องจัดสรรหน่วยความจำใด ๆ
    /// การเรียกใช้ [`upgrade`] ในค่าส่งคืนจะให้ [`None`] เสมอ
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// ประเภทตัวช่วยเพื่ออนุญาตให้เข้าถึงจำนวนการอ้างอิงโดยไม่ต้องยืนยันใด ๆ เกี่ยวกับฟิลด์ข้อมูล
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// ส่งกลับตัวชี้ดิบไปยังวัตถุที่ `T` ชี้โดย `Weak<T>` นี้
    ///
    /// ตัวชี้จะใช้ได้ก็ต่อเมื่อมีการอ้างอิงที่ชัดเจน
    /// ตัวชี้อาจห้อยไม่ตรงแนวหรือแม้แต่ [`null`] เป็นอย่างอื่น
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // ทั้งสองชี้ไปที่วัตถุเดียวกัน
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // สิ่งที่แข็งแกร่งที่นี่ทำให้มันมีชีวิตอยู่ดังนั้นเราจึงยังสามารถเข้าถึงวัตถุได้
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // แต่ไม่ได้อีกต่อไป
    /// // เราสามารถทำ weak.as_ptr() ได้ แต่การเข้าถึงตัวชี้จะนำไปสู่พฤติกรรมที่ไม่ได้กำหนด
    /// // assert_eq! ("สวัสดี" ไม่ปลอดภัย {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // หากตัวชี้ห้อยอยู่เราจะส่งคืนทหารรักษาการณ์โดยตรง
            // นี่ไม่สามารถเป็นที่อยู่เพย์โหลดที่ถูกต้องได้เนื่องจากน้ำหนักบรรทุกอย่างน้อยก็อยู่ในแนวเดียวกับ ArcInner (usize)
            ptr as *const T
        } else {
            // ความปลอดภัย: ถ้า is_dangling ส่งกลับเท็จแสดงว่าตัวชี้นั้นไม่สามารถถอดรหัสได้
            // น้ำหนักบรรทุกอาจลดลง ณ จุดนี้และเราต้องรักษาแหล่งที่มาดังนั้นให้ใช้การจัดการตัวชี้แบบดิบ
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// ใช้ `Weak<T>` และเปลี่ยนเป็นตัวชี้ดิบ
    ///
    /// สิ่งนี้จะแปลงตัวชี้ที่อ่อนแอให้เป็นตัวชี้ดิบในขณะที่ยังคงรักษาความเป็นเจ้าของของการอ้างอิงที่อ่อนแอไว้หนึ่งรายการ (การดำเนินการนี้จะไม่แก้ไขจำนวนที่อ่อนแอ)
    /// สามารถเปลี่ยนกลับเป็น `Weak<T>` ด้วย [`from_raw`]
    ///
    /// มีข้อ จำกัด เดียวกันในการเข้าถึงเป้าหมายของตัวชี้เช่นเดียวกับ [`as_ptr`]
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// แปลงตัวชี้ดิบที่ [`into_raw`] สร้างไว้ก่อนหน้านี้กลับเป็น `Weak<T>`
    ///
    /// สิ่งนี้สามารถใช้เพื่อรับข้อมูลอ้างอิงที่ชัดเจนได้อย่างปลอดภัย (โดยเรียก [`upgrade`] ในภายหลัง) หรือเพื่อยกเลิกการจัดสรรจำนวนที่อ่อนแอโดยการทิ้ง `Weak<T>`
    ///
    /// เป็นเจ้าของการอ้างอิงที่อ่อนแอหนึ่งรายการ (ยกเว้นพอยน์เตอร์ที่สร้างโดย [`new`] เนื่องจากสิ่งเหล่านี้ไม่ได้เป็นเจ้าของอะไรเลยวิธีนี้ยังคงใช้งานได้)
    ///
    /// # Safety
    ///
    /// ตัวชี้ต้องมาจาก [`into_raw`] และยังต้องเป็นเจ้าของการอ้างอิงที่อ่อนแอที่เป็นไปได้
    ///
    /// อนุญาตให้การนับที่แข็งแกร่งเป็น 0 ในเวลาที่เรียกสิ่งนี้
    /// อย่างไรก็ตามสิ่งนี้ใช้ความเป็นเจ้าของการอ้างอิงที่อ่อนแอหนึ่งรายการในปัจจุบันที่แสดงเป็นตัวชี้ดิบ (จำนวนที่อ่อนแอไม่ได้ถูกแก้ไขโดยการดำเนินการนี้) ดังนั้นจึงต้องจับคู่กับการเรียกก่อนหน้าไปยัง [`into_raw`]
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // ลดจำนวนครั้งสุดท้ายที่อ่อนแอ
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // ดู Weak::as_ptr สำหรับบริบทเกี่ยวกับวิธีการรับตัวชี้อินพุต

        let ptr = if is_dangling(ptr as *mut T) {
            // นี่คือจุดอ่อนที่ห้อยลงมา
            ptr as *mut ArcInner<T>
        } else {
            // มิฉะนั้นเรารับประกันได้ว่าตัวชี้มาจากจุดอ่อนที่ไม่เป็นอันตราย
            // ความปลอดภัย: data_offset ปลอดภัยในการโทรเนื่องจาก ptr อ้างถึงของจริง (อาจตกหล่น) T.
            let offset = unsafe { data_offset(ptr) };
            // ดังนั้นเราจึงย้อนกลับค่าชดเชยเพื่อรับ RcBox ทั้งหมด
            // ความปลอดภัย: ตัวชี้มาจากจุดอ่อนดังนั้นการชดเชยนี้จึงปลอดภัย
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // ความปลอดภัย: ตอนนี้เราได้กู้คืนตัวชี้จุดอ่อนดั้งเดิมแล้วดังนั้นสามารถสร้างจุดอ่อนได้
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// พยายามอัพเกรดตัวชี้ `Weak` เป็น [`Arc`] ซึ่งจะชะลอการปล่อยค่าภายในหากสำเร็จ
    ///
    ///
    /// ส่งคืน [`None`] หากค่าภายในถูกทิ้ง
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // ทำลายตัวชี้ที่แข็งแกร่งทั้งหมด
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // เราใช้ CAS loop เพื่อเพิ่มจำนวนที่แข็งแกร่งแทน fetch_add เนื่องจากฟังก์ชันนี้ไม่ควรใช้การนับอ้างอิงจากศูนย์ถึงหนึ่ง
        //
        //
        let inner = self.inner()?;

        // โหลดที่ผ่อนคลายเนื่องจากการเขียน 0 ใด ๆ ที่เราสามารถสังเกตได้ทำให้ฟิลด์อยู่ในสถานะเป็นศูนย์อย่างถาวร (ดังนั้น "stale" ที่อ่านเป็น 0 ก็ใช้ได้) และค่าอื่น ๆ จะได้รับการยืนยันผ่าน CAS ด้านล่าง
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // ดูความคิดเห็นใน `Arc::clone` ว่าทำไมเราถึงทำเช่นนี้ (สำหรับ `mem::forget`)
            if n > MAX_REFCOUNT {
                abort();
            }

            // การผ่อนคลายเป็นเรื่องปกติสำหรับกรณีความล้มเหลวเนื่องจากเราไม่มีความคาดหวังใด ๆ เกี่ยวกับสถานะใหม่
            // การได้มาเป็นสิ่งจำเป็นสำหรับกรณีความสำเร็จในการซิงโครไนซ์กับ `Arc::new_cyclic` เมื่อค่าภายในสามารถเริ่มต้นได้หลังจากสร้างการอ้างอิง `Weak` แล้ว
            // ในกรณีนี้เราคาดว่าจะสังเกตเห็นค่าเริ่มต้นอย่างสมบูรณ์
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // โมฆะตรวจสอบด้านบน
                Err(old) => n = old,
            }
        }
    }

    /// รับจำนวนพอยน์เตอร์ (`Arc`) ที่แข็งแกร่งที่ชี้ไปที่การจัดสรรนี้
    ///
    /// ถ้า `self` ถูกสร้างขึ้นโดยใช้ [`Weak::new`] สิ่งนี้จะส่งกลับ 0
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// รับค่าประมาณของจำนวนพอยน์เตอร์ `Weak` ที่ชี้ไปที่การจัดสรรนี้
    ///
    /// หาก `self` ถูกสร้างขึ้นโดยใช้ [`Weak::new`] หรือหากไม่มีตัวชี้ที่แข็งแกร่งเหลืออยู่สิ่งนี้จะส่งกลับ 0
    ///
    /// # Accuracy
    ///
    /// เนื่องจากรายละเอียดการนำไปใช้งานค่าที่ส่งคืนสามารถปิดได้ 1 ทิศทางในทิศทางใดทิศทางหนึ่งเมื่อเธรดอื่นกำลังจัดการกับ "ส่วนโค้ง" หรือ "อ่อนแอ" ที่ชี้ไปยังการจัดสรรเดียวกัน
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // เนื่องจากเราสังเกตเห็นว่ามีตัวชี้ที่แข็งแกร่งอย่างน้อยหนึ่งตัวหลังจากอ่านจำนวนที่อ่อนแอเราจึงรู้ว่าการอ้างอิงที่อ่อนแอโดยปริยาย (แสดงเมื่อใดก็ตามที่มีการอ้างอิงที่ชัดเจนมีชีวิตอยู่) ยังคงอยู่รอบ ๆ เมื่อเราสังเกตเห็นจำนวนที่อ่อนแอดังนั้นจึงสามารถลบออกได้อย่างปลอดภัย
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// ส่งคืน `None` เมื่อตัวชี้ห้อยและไม่มีการจัดสรร `ArcInner` (กล่าวคือเมื่อ `Weak` นี้สร้างโดย `Weak::new`)
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // เราระมัดระวังที่จะ *ไม่* สร้างการอ้างอิงที่ครอบคลุมฟิลด์ "data" เนื่องจากฟิลด์อาจถูกกลายพันธุ์ไปพร้อม ๆ กัน (ตัวอย่างเช่นหาก `Arc` สุดท้ายหลุดออกไปฟิลด์ข้อมูลจะถูกทิ้งในตำแหน่ง)
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// ส่งคืนค่า `true` หากทั้งสอง "อ่อนแอ" ชี้ไปที่การจัดสรรเดียวกัน (คล้ายกับ [`ptr::eq`]) หรือหากทั้งสองไม่ชี้ไปที่การจัดสรรใด ๆ (เพราะสร้างด้วย `Weak::new()`)
    ///
    ///
    /// # Notes
    ///
    /// เนื่องจากสิ่งนี้เปรียบเทียบตัวชี้หมายความว่า `Weak::new()` จะเท่ากันแม้ว่าจะไม่ชี้ไปที่การจัดสรรใด ๆ ก็ตาม
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// เปรียบเทียบ `Weak::new`
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// สร้างโคลนของตัวชี้ `Weak` ที่ชี้ไปที่การจัดสรรเดียวกัน
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // ดูความคิดเห็นใน Arc::clone() ว่าทำไมถึงผ่อนคลาย
        // สิ่งนี้สามารถใช้ fetch_add (โดยไม่สนใจการล็อก) เนื่องจากจำนวนที่อ่อนแอจะถูกล็อคเฉพาะที่ *ไม่มีตัวชี้จุดอ่อนอื่น ๆ* ที่มีอยู่
        //
        // (ดังนั้นเราจึงไม่สามารถรันโค้ดนี้ได้ในกรณีนั้น)
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // ดูความคิดเห็นใน Arc::clone() ว่าทำไมเราถึงทำเช่นนี้ (สำหรับ mem::forget)
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// สร้าง `Weak<T>` ใหม่โดยไม่ต้องจัดสรรหน่วยความจำ
    /// การเรียกใช้ [`upgrade`] ในค่าส่งคืนจะให้ [`None`] เสมอ
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// วางตัวชี้ `Weak`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // ไม่พิมพ์อะไรเลย
    /// drop(foo);        // พิมพ์ "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // หากเราพบว่าเราเป็นตัวชี้สุดท้ายที่อ่อนแอแสดงว่าถึงเวลาที่ต้องจัดสรรข้อมูลทั้งหมดดูการอภิปรายใน Arc::drop() เกี่ยวกับลำดับหน่วยความจำ
        //
        // ไม่จำเป็นต้องตรวจสอบสถานะล็อกที่นี่เนื่องจากจำนวนที่อ่อนแอสามารถล็อคได้ก็ต่อเมื่อมีการอ้างอิงที่อ่อนแออย่างแม่นยำหนึ่งครั้งซึ่งหมายความว่าการดร็อปสามารถเรียกใช้ในภายหลังจากการอ้างอิงที่อ่อนแอที่เหลือซึ่งจะเกิดขึ้นได้หลังจากคลายการล็อกแล้วเท่านั้น
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// เรากำลังทำความเชี่ยวชาญนี้อยู่ที่นี่ไม่ใช่เป็นการเพิ่มประสิทธิภาพทั่วไปบน `&T` เพราะจะเป็นการเพิ่มต้นทุนให้กับการตรวจสอบความเท่าเทียมกันทั้งหมดในการอ้างอิง
/// เราถือว่า "อาร์ค" ใช้ในการจัดเก็บค่าจำนวนมากซึ่งจะลอกแบบได้ช้า แต่ก็ต้องตรวจสอบความเท่าเทียมกันอย่างหนักด้วยทำให้ต้นทุนนี้จ่ายออกไปได้ง่ายขึ้น
///
/// นอกจากนี้ยังมีแนวโน้มที่จะมีโคลน `Arc` สองตัวซึ่งชี้ไปที่ค่าเดียวกันมากกว่าสอง "&T"
///
/// เราสามารถทำได้ก็ต่อเมื่อ `T: Eq` เป็น `PartialEq` อาจไม่สะท้อนแสงโดยเจตนา
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// ความเท่าเทียมกันสำหรับสอง "ส่วนโค้ง"
    ///
    /// "ส่วนโค้ง" สองค่าเท่ากันหากค่าภายในเท่ากันแม้ว่าจะเก็บไว้ในการจัดสรรที่ต่างกันก็ตาม
    ///
    /// หาก `T` ใช้ `Eq` ด้วย (หมายถึงการสะท้อนกลับของความเท่าเทียมกัน) "ส่วนโค้ง" สองตัวที่ชี้ไปยังการจัดสรรเดียวกันจะเท่ากันเสมอ
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// อสมการสำหรับสอง "ส่วนโค้ง"
    ///
    /// "ส่วนโค้ง" สองค่าไม่เท่ากันหากค่าภายในไม่เท่ากัน
    ///
    /// หาก `T` ใช้ `Eq` ด้วย (หมายถึงการสะท้อนกลับของความเท่าเทียมกัน) "ส่วนโค้ง" สองตัวที่ชี้ไปยังค่าเดียวกันจะไม่มีวันไม่เท่ากัน
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// การเปรียบเทียบบางส่วนสำหรับสอง "ส่วนโค้ง"
    ///
    /// ทั้งสองถูกเปรียบเทียบโดยเรียก `partial_cmp()` ตามค่าภายในของพวกเขา
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// น้อยกว่าการเปรียบเทียบสำหรับสอง "ส่วนโค้ง"
    ///
    /// ทั้งสองถูกเปรียบเทียบโดยเรียก `<` ตามค่าภายในของพวกเขา
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// การเปรียบเทียบ 'น้อยกว่าหรือเท่ากับ' สำหรับสอง "ส่วนโค้ง"
    ///
    /// ทั้งสองถูกเปรียบเทียบโดยเรียก `<=` ตามค่าภายในของพวกเขา
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// มากกว่าการเปรียบเทียบสำหรับสอง "ส่วนโค้ง"
    ///
    /// ทั้งสองถูกเปรียบเทียบโดยเรียก `>` ตามค่าภายในของพวกเขา
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// การเปรียบเทียบ 'มากกว่าหรือเท่ากับ' สำหรับสอง "ส่วนโค้ง"
    ///
    /// ทั้งสองถูกเปรียบเทียบโดยเรียก `>=` ตามค่าภายในของพวกเขา
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// การเปรียบเทียบสอง "ส่วนโค้ง"
    ///
    /// ทั้งสองถูกเปรียบเทียบโดยเรียก `cmp()` ตามค่าภายในของพวกเขา
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// สร้าง `Arc<T>` ใหม่โดยมีค่า `Default` สำหรับ `T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// จัดสรรชิ้นส่วนที่นับการอ้างอิงและเติมโดยการโคลนรายการของ "v"
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// จัดสรร `str` ที่นับการอ้างอิงและคัดลอก `v` ลงในนั้น
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// จัดสรร `str` ที่นับการอ้างอิงและคัดลอก `v` ลงในนั้น
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// ย้ายวัตถุชนิดบรรจุกล่องไปยังการจัดสรรที่นับการอ้างอิงใหม่
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// จัดสรรชิ้นส่วนที่นับการอ้างอิงและย้ายรายการ "v" ไปไว้ในนั้น
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // อนุญาตให้ Vec เพิ่มหน่วยความจำ แต่ไม่ทำลายเนื้อหา
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// ใช้แต่ละองค์ประกอบใน `Iterator` และรวบรวมเป็น `Arc<[T]>`
    ///
    /// # ลักษณะการทำงาน
    ///
    /// ## กรณีทั่วไป
    ///
    /// ในกรณีทั่วไปการรวบรวมเข้า `Arc<[T]>` ทำได้โดยการรวบรวมเป็น `Vec<T>` ก่อนนั่นคือเมื่อเขียนสิ่งต่อไปนี้:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// สิ่งนี้ทำงานราวกับว่าเราเขียน:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // การจัดสรรชุดแรกเกิดขึ้นที่นี่
    ///     .into(); // การจัดสรรครั้งที่สองสำหรับ `Arc<[T]>` เกิดขึ้นที่นี่
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// สิ่งนี้จะจัดสรรหลาย ๆ ครั้งตามที่จำเป็นสำหรับการสร้าง `Vec<T>` จากนั้นจะจัดสรรหนึ่งครั้งสำหรับการเปลี่ยน `Vec<T>` เป็น `Arc<[T]>`
    ///
    ///
    /// ## ตัววนซ้ำของความยาวที่ทราบ
    ///
    /// เมื่อ `Iterator` ของคุณใช้ `TrustedLen` และมีขนาดที่แน่นอนจะมีการจัดสรรครั้งเดียวสำหรับ `Arc<[T]>` ตัวอย่างเช่น:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // การจัดสรรเพียงรายการเดียวเกิดขึ้นที่นี่
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Specialization trait ใช้สำหรับรวบรวมเป็น `Arc<[T]>`
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // นี่เป็นกรณีของตัววนซ้ำ `TrustedLen`
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // ความปลอดภัย: เราจำเป็นต้องตรวจสอบให้แน่ใจว่าตัววนซ้ำมีความยาวที่แน่นอนและเรามี
                Arc::from_iter_exact(self, low)
            }
        } else {
            // ถอยกลับสู่การใช้งานปกติ
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// รับค่าชดเชยภายใน `ArcInner` สำหรับเพย์โหลดหลังตัวชี้
///
/// # Safety
///
/// ตัวชี้ต้องชี้ไปที่ (และมีข้อมูลเมตาที่ถูกต้องสำหรับ) อินสแตนซ์ของ T ที่ถูกต้องก่อนหน้านี้ แต่ T ได้รับอนุญาตให้ทิ้ง
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // จัดแนวค่าที่ไม่ได้กำหนดไว้ที่ส่วนท้ายของ ArcInner
    // เนื่องจาก RcBox คือ repr(C) จึงเป็นฟิลด์สุดท้ายในหน่วยความจำเสมอ
    // ความปลอดภัย: เนื่องจากชนิดที่ไม่ได้ขนาดเท่านั้นที่เป็นไปได้คือชิ้นส่วนวัตถุ trait
    // และประเภทภายนอกปัจจุบันข้อกำหนดด้านความปลอดภัยของอินพุตเพียงพอที่จะตอบสนองความต้องการของ align_of_val_raw;นี่คือรายละเอียดการใช้งานของภาษาที่อาจไม่ได้รับการพึ่งพานอก std
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}