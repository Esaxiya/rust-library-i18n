//! สตริงที่เข้ารหัส UTF-8 และขยายได้
//!
//! โมดูลนี้ประกอบด้วยประเภท [`String`], [`ToString`] trait สำหรับการแปลงเป็นสตริงและข้อผิดพลาดหลายประเภทที่อาจเป็นผลมาจากการทำงานกับ ["สตริง"] s
//!
//!
//! # Examples
//!
//! มีหลายวิธีในการสร้าง [`String`] ใหม่จากสตริงลิเทอรัล:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! คุณสามารถสร้าง [`String`] ใหม่จากที่มีอยู่ได้โดยเชื่อมต่อกับไฟล์
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! หากคุณมี vector ของ UTF-8 ไบต์ที่ถูกต้องคุณสามารถสร้าง [`String`] จากมันได้คุณสามารถทำย้อนกลับได้เช่นกัน
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // เรารู้ว่าไบต์เหล่านี้ถูกต้องดังนั้นเราจึงใช้ `unwrap()`
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// สตริงที่เข้ารหัส UTF-8 และขยายได้
///
/// ประเภท `String` เป็นประเภทสตริงทั่วไปที่มีความเป็นเจ้าของเนื้อหาของสตริงมีความสัมพันธ์ใกล้ชิดกับ [`str`] ดั้งเดิมที่ยืมมา
///
/// # Examples
///
/// คุณสามารถสร้าง `String` จาก [a literal string][`str`] ด้วย [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// คุณสามารถต่อท้าย [`char`] กับ `String` ด้วยวิธี [`push`] และต่อท้าย [`&str`] ด้วยวิธี [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// หากคุณมี vector ของ UTF-8 ไบต์คุณสามารถสร้าง `String` จากมันด้วยวิธี [`from_utf8`]:
///
/// ```
/// // ไบต์บางส่วนใน vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // เรารู้ว่าไบต์เหล่านี้ถูกต้องดังนั้นเราจึงใช้ `unwrap()`
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// "สตริง" คือ UTF-8 ที่ถูกต้องเสมอสิ่งนี้มีผลกระทบเล็กน้อยประการแรกคือหากคุณต้องการสตริงที่ไม่ใช่ UTF-8 ให้พิจารณา [`OsString`] คล้ายกัน แต่ไม่มีข้อ จำกัด UTF-8 นัยที่สองคือคุณไม่สามารถสร้างดัชนีเป็น `String` ได้:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// การจัดทำดัชนีมีจุดมุ่งหมายเพื่อการดำเนินการที่คงที่ แต่การเข้ารหัส UTF-8 ไม่อนุญาตให้เราทำเช่นนี้นอกจากนี้ยังไม่ชัดเจนว่าดัชนีควรส่งคืนประเภทใด: ไบต์จุดรหัสหรือคลัสเตอร์กราฟฟีม
/// วิธี [`bytes`] และ [`chars`] จะส่งคืนตัวทำซ้ำมากกว่าสองตัวแรกตามลำดับ
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// "ใช้สตริง" ["Deref`]"<Target=str>`และสืบทอดวิธีการทั้งหมดของ [`str`]นอกจากนี้หมายความว่าคุณสามารถส่ง `String` ไปยังฟังก์ชันที่ใช้ [`&str`] ได้โดยใช้เครื่องหมายและ (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// สิ่งนี้จะสร้าง [`&str`] จาก `String` และส่งต่อไปการแปลงนี้มีราคาไม่แพงมากและโดยทั่วไปฟังก์ชันจะยอมรับ [`&str`] เป็นอาร์กิวเมนต์เว้นแต่ว่าพวกเขาต้องการ `String` ด้วยเหตุผลบางประการ
///
/// ในบางกรณี Rust ไม่มีข้อมูลเพียงพอที่จะทำการแปลงนี้หรือที่เรียกว่า [`Deref`] coercionในตัวอย่างต่อไปนี้สตริงสไลซ์ [`&'a str`][`&str`] ใช้ trait `TraitExample` และฟังก์ชัน `example_func` ใช้อะไรก็ได้ที่ใช้ trait
/// ในกรณีนี้ Rust จะต้องทำการแปลงโดยนัยสองครั้งซึ่ง Rust ไม่มีวิธีการทำ
/// ด้วยเหตุนี้ตัวอย่างต่อไปนี้จะไม่คอมไพล์
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// มีสองตัวเลือกที่จะทำงานแทนขั้นแรกคือการเปลี่ยนบรรทัด `example_func(&example_string);` เป็น `example_func(example_string.as_str());` โดยใช้วิธี [`as_str()`] เพื่อแยกส่วนสตริงที่มีสตริงอย่างชัดเจน
/// วิธีที่สองเปลี่ยน `example_func(&example_string);` เป็น `example_func(&*example_string);`
/// ในกรณีนี้เรากำลังอ้างถึง `String` เป็น [`str`][`&str`] จากนั้นอ้างอิง [`str`][`&str`] กลับไปที่ [`&str`]
/// วิธีที่สองเป็นสำนวนมากกว่าอย่างไรก็ตามทั้งสองทำงานเพื่อทำการแปลงอย่างชัดเจนแทนที่จะอาศัยการแปลงโดยนัย
///
/// # Representation
///
/// `String` ประกอบด้วยสามองค์ประกอบ: ตัวชี้ไปยังไบต์บางส่วนความยาวและความจุตัวชี้ชี้ไปที่บัฟเฟอร์ภายใน `String` ใช้เพื่อจัดเก็บข้อมูลความยาวคือจำนวนไบต์ที่เก็บอยู่ในบัฟเฟอร์ในปัจจุบันและความจุคือขนาดของบัฟเฟอร์เป็นไบต์
///
/// ดังนั้นความยาวจะน้อยกว่าหรือเท่ากับความจุเสมอ
///
/// บัฟเฟอร์นี้จะถูกเก็บไว้ในฮีปเสมอ
///
/// คุณสามารถดูสิ่งเหล่านี้ด้วยวิธี [`as_ptr`], [`len`] และ [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME อัปเดตสิ่งนี้เมื่อ vec_into_raw_parts เสถียร
/// // ป้องกันการทิ้งข้อมูลของ String โดยอัตโนมัติ
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // เรื่องราวมีสิบเก้าไบต์
/// assert_eq!(19, len);
///
/// // เราสามารถสร้าง String ใหม่จาก ptr, len และ capacity ได้
/// // ทั้งหมดนี้ไม่ปลอดภัยเพราะเราต้องรับผิดชอบในการตรวจสอบว่าส่วนประกอบถูกต้อง:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// หาก `String` มีความจุเพียงพอการเพิ่มองค์ประกอบเข้าไปจะไม่จัดสรรใหม่ตัวอย่างเช่นพิจารณาโปรแกรมนี้:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// สิ่งนี้จะแสดงผลลัพธ์ต่อไปนี้:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// ในตอนแรกเราไม่มีหน่วยความจำที่จัดสรรเลย แต่เมื่อเราต่อท้ายสตริงมันจะเพิ่มความจุอย่างเหมาะสมหากเราใช้วิธี [`with_capacity`] แทนเพื่อจัดสรรความจุที่ถูกต้องในตอนแรก:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// เราจบลงด้วยผลลัพธ์ที่แตกต่างกัน:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// ที่นี่ไม่จำเป็นต้องจัดสรรหน่วยความจำเพิ่มเติมภายในลูป
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// ค่าความผิดพลาดที่เป็นไปได้เมื่อแปลง `String` จาก UTF-8 ไบต์ vector
///
/// ประเภทนี้เป็นประเภทข้อผิดพลาดสำหรับวิธี [`from_utf8`] บน [`String`]
/// ได้รับการออกแบบมาเพื่อหลีกเลี่ยงการจัดสรรซ้ำอย่างระมัดระวัง: วิธี [`into_bytes`] จะคืนค่าไบต์ vector ที่ใช้ในการพยายามแปลง
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// ประเภท [`Utf8Error`] ที่ [`std::str`] จัดเตรียมไว้แสดงถึงข้อผิดพลาดที่อาจเกิดขึ้นเมื่อแปลงชิ้นส่วนของ ["u8`] เป็น [`&str`]
/// ในแง่นี้มันเป็นอะนาล็อกกับ `FromUtf8Error` และคุณสามารถรับได้จาก `FromUtf8Error` ผ่านวิธี [`utf8_error`]
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// การใช้งานพื้นฐาน:
///
/// ```
/// // บางไบต์ที่ไม่ถูกต้องใน vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// ค่าความผิดพลาดที่เป็นไปได้เมื่อแปลง `String` จากชิ้น UTF-16 ไบต์
///
/// ประเภทนี้เป็นประเภทข้อผิดพลาดสำหรับวิธี [`from_utf16`] บน [`String`]
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// การใช้งานพื้นฐาน:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// สร้าง `String` ใหม่ที่ว่างเปล่า
    ///
    /// เนื่องจาก `String` ว่างเปล่าสิ่งนี้จะไม่จัดสรรบัฟเฟอร์เริ่มต้นใด ๆแม้ว่าจะหมายความว่าการดำเนินการเริ่มต้นนี้มีราคาไม่แพงมาก แต่อาจทำให้เกิดการจัดสรรมากเกินไปในภายหลังเมื่อคุณเพิ่มข้อมูล
    ///
    /// หากคุณมีความคิดว่า `String` จะเก็บข้อมูลไว้เท่าใดให้พิจารณาวิธี [`with_capacity`] เพื่อป้องกันการจัดสรรซ้ำมากเกินไป
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// สร้าง `String` ว่างใหม่ที่มีความจุเฉพาะ
    ///
    /// "สตริง" มีบัฟเฟอร์ภายในเพื่อเก็บข้อมูล
    /// ความจุคือความยาวของบัฟเฟอร์นั้นและสามารถสอบถามได้ด้วยวิธี [`capacity`]
    /// วิธีนี้สร้าง `String` ว่าง แต่เป็นหนึ่งที่มีบัฟเฟอร์เริ่มต้นที่สามารถเก็บ `capacity` ไบต์ได้
    /// สิ่งนี้มีประโยชน์เมื่อคุณอาจต่อท้ายข้อมูลจำนวนมากเข้ากับ `String` ซึ่งจะช่วยลดจำนวนการจัดสรรใหม่ที่จำเป็นต้องทำ
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// หากความจุที่กำหนดคือ `0` จะไม่มีการจัดสรรเกิดขึ้นและวิธีนี้จะเหมือนกับวิธี [`new`]
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // สตริงไม่มีตัวอักษรแม้ว่าจะมีความจุมากกว่าก็ตาม
    /// assert_eq!(s.len(), 0);
    ///
    /// // ทั้งหมดนี้ทำได้โดยไม่ต้องจัดสรรใหม่ ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... แต่สิ่งนี้อาจทำให้การจัดสรรสตริงใหม่
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): ด้วย cfg(test) เมธอด `[T]::to_vec` โดยธรรมชาติซึ่งจำเป็นสำหรับนิยามเมธอดนี้จะไม่พร้อมใช้งาน
    // เนื่องจากเราไม่ต้องการวิธีนี้เพื่อจุดประสงค์ในการทดสอบฉันจะตัดมัน NB ดูโมดูล slice::hack ใน slice.rs เพื่อดูข้อมูลเพิ่มเติม
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// แปลง vector ของไบต์เป็น `String`
    ///
    /// สตริง ([`String`]) สร้างจากไบต์ ([`u8`]) และ vector ของไบต์ ([`Vec<u8>`]) สร้างจากไบต์ดังนั้นฟังก์ชันนี้จะแปลงระหว่างสอง
    /// บางส่วนของไบต์ไม่ได้เป็น "สตริง" ที่ถูกต้องอย่างไรก็ตาม `String` ต้องการให้เป็น UTF-8 ที่ถูกต้อง
    /// `from_utf8()` ตรวจสอบเพื่อให้แน่ใจว่าไบต์เป็น UTF-8 ที่ถูกต้องจากนั้นทำการแปลง
    ///
    /// หากคุณแน่ใจว่าชิ้นส่วนไบต์เป็น UTF-8 ที่ถูกต้องและคุณไม่ต้องการให้มีค่าใช้จ่ายในการตรวจสอบความถูกต้องแสดงว่าฟังก์ชันนี้เป็นเวอร์ชันที่ไม่ปลอดภัยคือ [`from_utf8_unchecked`] ซึ่งมีลักษณะการทำงานเหมือนกัน แต่จะข้ามการตรวจสอบไป
    ///
    ///
    /// วิธีนี้จะดูแลไม่คัดลอก vector เพื่อประสิทธิภาพ
    ///
    /// หากคุณต้องการ [`&str`] แทน `String` ให้พิจารณา [`str::from_utf8`]
    ///
    /// ผกผันของวิธีนี้คือ [`into_bytes`]
    ///
    /// # Errors
    ///
    /// ส่งคืน [`Err`] หากสไลซ์ไม่ใช่ UTF-8 พร้อมคำอธิบายว่าทำไมไบต์ที่ให้มาไม่ใช่ UTF-8 vector ที่คุณย้ายเข้ารวมอยู่ด้วย
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// // ไบต์บางส่วนใน vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // เรารู้ว่าไบต์เหล่านี้ถูกต้องดังนั้นเราจึงใช้ `unwrap()`
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// ไบต์ไม่ถูกต้อง:
    ///
    /// ```
    /// // บางไบต์ที่ไม่ถูกต้องใน vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// ดูเอกสารสำหรับ [`FromUtf8Error`] สำหรับรายละเอียดเพิ่มเติมเกี่ยวกับสิ่งที่คุณสามารถทำได้กับข้อผิดพลาดนี้
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// แปลงส่วนของไบต์เป็นสตริงรวมทั้งอักขระที่ไม่ถูกต้อง
    ///
    /// สตริงทำจากไบต์ ([`u8`]) และชิ้นส่วนของไบต์ ([`&[u8]`][byteslice]) สร้างจากไบต์ดังนั้นฟังก์ชันนี้จะแปลงระหว่างสองไบต์ชิ้นส่วนไบต์ทั้งหมดไม่ใช่สตริงที่ถูกต้องอย่างไรก็ตาม: สตริงจำเป็นต้องเป็น UTF-8 ที่ถูกต้อง
    /// ในระหว่างการแปลงนี้ `from_utf8_lossy()` จะแทนที่ลำดับ UTF-8 ที่ไม่ถูกต้องด้วย [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] ซึ่งมีลักษณะดังนี้:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// หากคุณแน่ใจว่าชิ้นส่วนไบต์เป็น UTF-8 ที่ถูกต้องและคุณไม่ต้องการให้เกิดค่าใช้จ่ายในการแปลงมีเวอร์ชันที่ไม่ปลอดภัยคือ [`from_utf8_unchecked`] ซึ่งมีลักษณะการทำงานเหมือนกัน แต่จะข้ามการตรวจสอบไป
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// ฟังก์ชันนี้ส่งคืนค่า [`Cow<'a, str>`] หากชิ้นส่วนไบต์ของเราไม่ถูกต้อง UTF-8 เราจำเป็นต้องแทรกอักขระแทนที่ซึ่งจะเปลี่ยนขนาดของสตริงและด้วยเหตุนี้จึงต้องใช้ `String`
    /// แต่ถ้าเป็น UTF-8 ที่ถูกต้องอยู่แล้วเราก็ไม่จำเป็นต้องมีการจัดสรรใหม่
    /// การคืนสินค้าประเภทนี้ช่วยให้เราสามารถจัดการทั้งสองกรณีได้
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// // ไบต์บางส่วนใน vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// ไบต์ไม่ถูกต้อง:
    ///
    /// ```
    /// // ไบต์บางส่วนไม่ถูกต้อง
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// ถอดรหัส vector `v` ที่เข้ารหัส UTF-16 เป็น `String` โดยส่งคืน [`Err`] หาก `v` มีข้อมูลที่ไม่ถูกต้อง
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // สิ่งนี้ไม่ได้ทำผ่านการรวบรวม: : <Result<_, _>> () ด้วยเหตุผลด้านประสิทธิภาพ
        // FIXME: ฟังก์ชันนี้สามารถทำให้ง่ายขึ้นอีกครั้งเมื่อปิด #48994
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// ถอดรหัสชิ้นส่วน `v` ที่เข้ารหัส UTF-16 เป็น `String` โดยแทนที่ข้อมูลที่ไม่ถูกต้องด้วย [the replacement character (`U+FFFD`)][U+FFFD]
    ///
    /// ไม่เหมือนกับ [`from_utf8_lossy`] ที่ส่งคืน [`Cow<'a, str>`] `from_utf16_lossy` จะส่งคืน `String` เนื่องจากการแปลง UTF-16 เป็น UTF-8 ต้องการการจัดสรรหน่วยความจำ
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// สลาย `String` เป็นส่วนประกอบดิบ
    ///
    /// ส่งกลับตัวชี้ดิบเป็นข้อมูลพื้นฐานความยาวของสตริง (เป็นไบต์) และความจุที่จัดสรรของข้อมูล (เป็นไบต์)
    /// อาร์กิวเมนต์เหล่านี้เป็นอาร์กิวเมนต์เดียวกันในลำดับเดียวกับอาร์กิวเมนต์ของ [`from_raw_parts`]
    ///
    /// หลังจากเรียกใช้ฟังก์ชันนี้แล้วผู้เรียกจะรับผิดชอบหน่วยความจำที่ `String` จัดการก่อนหน้านี้
    /// วิธีเดียวที่จะทำได้คือการแปลงตัวชี้ดิบความยาวและความจุกลับเป็น `String` ด้วยฟังก์ชัน [`from_raw_parts`] เพื่อให้ตัวทำลายล้างดำเนินการล้างข้อมูล
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// สร้าง `String` ใหม่จากความยาวความจุและตัวชี้
    ///
    /// # Safety
    ///
    /// สิ่งนี้ไม่ปลอดภัยอย่างมากเนื่องจากจำนวนค่าคงที่ที่ไม่ได้ตรวจสอบ:
    ///
    /// * หน่วยความจำที่ `buf` จำเป็นต้องได้รับการจัดสรรก่อนหน้านี้โดยตัวจัดสรรเดียวกันกับที่ไลบรารีมาตรฐานใช้โดยมีการจัดตำแหน่งที่ต้องการเท่ากับ 1
    /// * `length` ต้องน้อยกว่าหรือเท่ากับ `capacity`
    /// * `capacity` ต้องเป็นค่าที่ถูกต้อง
    /// * `length` ไบต์แรกที่ `buf` ต้องเป็น UTF-8 ที่ถูกต้อง
    ///
    /// การละเมิดสิ่งเหล่านี้อาจทำให้เกิดปัญหาเช่นการทำให้โครงสร้างข้อมูลภายในของผู้จัดสรรเสียหาย
    ///
    /// ความเป็นเจ้าของ `buf` จะถูกโอนไปยัง `String` อย่างมีประสิทธิภาพซึ่งจากนั้นอาจยกเลิกการจัดสรรจัดสรรใหม่หรือเปลี่ยนเนื้อหาของหน่วยความจำที่ชี้ไปโดยตัวชี้ตามที่ต้องการ
    /// ตรวจสอบให้แน่ใจว่าไม่มีสิ่งอื่นใดที่ใช้ตัวชี้ได้หลังจากเรียกใช้ฟังก์ชันนี้
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME อัปเดตสิ่งนี้เมื่อ vec_into_raw_parts เสถียร
    ///     // ป้องกันการทิ้งข้อมูลของ String โดยอัตโนมัติ
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// แปลง vector ของไบต์เป็น `String` โดยไม่ต้องตรวจสอบว่าสตริงมี UTF-8 ที่ถูกต้อง
    ///
    /// ดูเวอร์ชันปลอดภัย [`from_utf8`] สำหรับรายละเอียดเพิ่มเติม
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// ฟังก์ชันนี้ไม่ปลอดภัยเนื่องจากไม่ได้ตรวจสอบว่าไบต์ที่ส่งผ่านไปนั้นเป็น UTF-8 ที่ถูกต้อง
    /// หากละเมิดข้อ จำกัด นี้อาจทำให้เกิดปัญหาความไม่ปลอดภัยของหน่วยความจำกับผู้ใช้ future ของ `String` เนื่องจากไลบรารีมาตรฐานที่เหลือถือว่า "สตริง" เป็น UTF-8 ที่ถูกต้อง
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// // ไบต์บางส่วนใน vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// แปลง `String` เป็นไบต์ vector
    ///
    /// สิ่งนี้ใช้ `String` ดังนั้นเราจึงไม่จำเป็นต้องคัดลอกเนื้อหา
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// แยกชิ้นสตริงที่มี `String` ทั้งหมด
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// แปลง `String` เป็นสไลซ์สตริงที่เปลี่ยนแปลงได้
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// ต่อท้ายส่วนสตริงที่กำหนดไว้ที่ส่วนท้ายของ `String` นี้
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// ส่งคืนความจุของ "สตริง" นี้เป็นไบต์
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// ตรวจสอบให้แน่ใจว่าความจุของ "สตริง" นี้มีขนาดใหญ่กว่าความยาวอย่างน้อย `additional` ไบต์
    ///
    /// ความจุอาจเพิ่มขึ้นมากกว่า `additional` ไบต์หากเลือกเพื่อป้องกันการจัดสรรซ้ำบ่อยครั้ง
    ///
    ///
    /// หากคุณไม่ต้องการลักษณะการทำงานของ "at least" โปรดดูวิธี [`reserve_exact`]
    ///
    /// # Panics
    ///
    /// Panics หากความจุใหม่ล้น [`usize`]
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// สิ่งนี้อาจไม่ได้เพิ่มความจุ:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // ตอนนี้มีความยาว 2 และความจุ 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // เนื่องจากเรามีความจุพิเศษ 8 อยู่แล้วจึงเรียกสิ่งนี้ว่า ...
    /// s.reserve(8);
    ///
    /// // ... ไม่ได้เพิ่มขึ้นจริง
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// ตรวจสอบให้แน่ใจว่าความจุของ "สตริง" นี้มีขนาด `additional` ไบต์มากกว่าความยาว
    ///
    /// พิจารณาใช้วิธี [`reserve`] เว้นแต่คุณจะรู้ดีกว่าตัวจัดสรร
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics หากความจุใหม่ล้น `usize`
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// สิ่งนี้อาจไม่ได้เพิ่มความจุ:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // ตอนนี้มีความยาว 2 และความจุ 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // เนื่องจากเรามีความจุพิเศษ 8 อยู่แล้วจึงเรียกสิ่งนี้ว่า ...
    /// s.reserve_exact(8);
    ///
    /// // ... ไม่ได้เพิ่มขึ้นจริง
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// พยายามสำรองความจุสำหรับองค์ประกอบอย่างน้อย `additional` ที่จะแทรกใน `String` ที่กำหนด
    /// คอลเลกชันอาจสงวนพื้นที่มากขึ้นเพื่อหลีกเลี่ยงการจัดสรรซ้ำบ่อยๆ
    /// หลังจากเรียก `reserve` แล้วความจุจะมากกว่าหรือเท่ากับ `self.len() + additional`
    /// ไม่ทำอะไรเลยหากความจุเพียงพอแล้ว
    ///
    /// # Errors
    ///
    /// หากความจุล้นหรือผู้จัดสรรรายงานความล้มเหลวข้อผิดพลาดจะถูกส่งกลับ
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // จองหน่วยความจำไว้ล่วงหน้าถ้าเราทำไม่ได้
    ///     output.try_reserve(data.len())?;
    ///
    ///     // ตอนนี้เรารู้แล้วว่าสิ่งนี้ไม่สามารถ OOM ได้ในระหว่างการทำงานที่ซับซ้อนของเรา
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// พยายามสำรองความจุขั้นต่ำสำหรับองค์ประกอบเพิ่มเติม `additional` ที่จะแทรกใน `String` ที่กำหนด
    ///
    /// หลังจากเรียก `reserve_exact` แล้วความจุจะมากกว่าหรือเท่ากับ `self.len() + additional`
    /// ไม่ทำอะไรเลยหากความจุเพียงพอแล้ว
    ///
    /// โปรดสังเกตว่าผู้จัดสรรอาจให้พื้นที่เก็บข้อมูลมากกว่าที่ร้องขอ
    /// ดังนั้นจึงไม่สามารถพึ่งพาความจุให้น้อยที่สุดได้อย่างแม่นยำ
    /// ต้องการ `reserve` หากคาดว่าจะมีการแทรก future
    ///
    /// # Errors
    ///
    /// หากความจุล้นหรือผู้จัดสรรรายงานความล้มเหลวข้อผิดพลาดจะถูกส่งกลับ
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // จองหน่วยความจำไว้ล่วงหน้าถ้าเราทำไม่ได้
    ///     output.try_reserve(data.len())?;
    ///
    ///     // ตอนนี้เรารู้แล้วว่าสิ่งนี้ไม่สามารถ OOM ได้ในระหว่างการทำงานที่ซับซ้อนของเรา
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// ลดความจุของ `String` นี้เพื่อให้พอดีกับความยาว
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// ลดความจุของ `String` นี้ด้วยขอบเขตที่ต่ำกว่า
    ///
    /// ความจุจะยังคงมีขนาดใหญ่เป็นอย่างน้อยทั้งความยาวและค่าที่ให้มา
    ///
    ///
    /// หากความจุปัจจุบันน้อยกว่าขีด จำกัด ล่างนี่คือ no-op
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// ต่อท้าย [`char`] ที่ระบุต่อท้าย `String` นี้
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// ส่งคืนชิ้นส่วนไบต์ของเนื้อหา "สตริง" นี้
    ///
    /// ผกผันของวิธีนี้คือ [`from_utf8`]
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// ย่อ `String` นี้ให้เป็นความยาวที่ระบุ
    ///
    /// ถ้า `new_len` มากกว่าความยาวปัจจุบันของสตริงจะไม่มีผล
    ///
    ///
    /// โปรดทราบว่าวิธีนี้ไม่มีผลต่อความจุที่จัดสรรของสตริง
    ///
    /// # Panics
    ///
    /// Panics ถ้า `new_len` ไม่อยู่บนขอบเขต [`char`]
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// ลบอักขระสุดท้ายออกจากบัฟเฟอร์สตริงและส่งกลับ
    ///
    /// ส่งคืน [`None`] หาก `String` นี้ว่างเปล่า
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// ลบ [`char`] ออกจาก `String` นี้ที่ตำแหน่งไบต์และส่งคืน
    ///
    /// นี่คือการดำเนินการ *O*(*n*) เนื่องจากต้องคัดลอกทุกองค์ประกอบในบัฟเฟอร์
    ///
    /// # Panics
    ///
    /// Panics ถ้า `idx` มีขนาดใหญ่กว่าหรือเท่ากับความยาวของ "สตริง" หรือถ้ามันไม่อยู่บนขอบเขต [`char`]
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// ลบการจับคู่ทั้งหมดของรูปแบบ `pat` ใน `String`
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// การจับคู่จะถูกตรวจจับและลบออกไปเรื่อย ๆ ดังนั้นในกรณีที่รูปแบบทับซ้อนกันระบบจะลบเฉพาะรูปแบบแรกเท่านั้น:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // ความปลอดภัย: จุดเริ่มต้นและจุดสิ้นสุดจะอยู่บนขอบเขต utf8 ไบต์ต่อ
        // เอกสารผู้ค้นหา
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// คงไว้เฉพาะอักขระที่ระบุโดยเพรดิเคต
    ///
    /// กล่าวอีกนัยหนึ่งคือลบอักขระทั้งหมด `c` เพื่อให้ `f(c)` ส่งคืน `false`
    /// วิธีนี้ทำงานในสถานที่เยี่ยมชมแต่ละอักขระหนึ่งครั้งตามลำดับเดิมและรักษาลำดับของอักขระที่เก็บไว้
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// คำสั่งซื้อที่แน่นอนอาจเป็นประโยชน์สำหรับการติดตามสถานะภายนอกเช่นดัชนี
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // ชี้ idx ไปที่อักขระถัดไป
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// แทรกอักขระลงใน `String` นี้ที่ตำแหน่งไบต์
    ///
    /// นี่คือการดำเนินการ *O*(*n*) เนื่องจากต้องคัดลอกทุกองค์ประกอบในบัฟเฟอร์
    ///
    /// # Panics
    ///
    /// Panics ถ้า `idx` ใหญ่กว่าความยาวของ "สตริง" หรือถ้ามันไม่อยู่บนขอบเขต [`char`]
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// แทรกสไลซ์สตริงลงใน `String` นี้ที่ตำแหน่งไบต์
    ///
    /// นี่คือการดำเนินการ *O*(*n*) เนื่องจากต้องคัดลอกทุกองค์ประกอบในบัฟเฟอร์
    ///
    /// # Panics
    ///
    /// Panics ถ้า `idx` ใหญ่กว่าความยาวของ "สตริง" หรือถ้ามันไม่อยู่บนขอบเขต [`char`]
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// ส่งคืนการอ้างอิงที่ไม่แน่นอนไปยังเนื้อหาของ `String` นี้
    ///
    /// # Safety
    ///
    /// ฟังก์ชันนี้ไม่ปลอดภัยเนื่องจากไม่ได้ตรวจสอบว่าไบต์ที่ส่งผ่านไปนั้นเป็น UTF-8 ที่ถูกต้อง
    /// หากละเมิดข้อ จำกัด นี้อาจทำให้เกิดปัญหาความไม่ปลอดภัยของหน่วยความจำกับผู้ใช้ future ของ `String` เนื่องจากไลบรารีมาตรฐานที่เหลือถือว่า "สตริง" เป็น UTF-8 ที่ถูกต้อง
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// ส่งกลับความยาวของ `String` นี้เป็นไบต์ไม่ใช่ ["char`] s หรือ graphemes
    /// กล่าวอีกนัยหนึ่งอาจไม่ใช่สิ่งที่มนุษย์พิจารณาถึงความยาวของสตริง
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// ส่งคืน `true` หาก `String` นี้มีความยาวเป็นศูนย์และ `false` เป็นอย่างอื่น
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// แยกสตริงออกเป็นสองรายการที่ดัชนีไบต์ที่กำหนด
    ///
    /// ส่งคืน `String` ที่จัดสรรใหม่
    /// `self` มีไบต์ `[0, at)` และ `String` ที่ส่งคืนมีไบต์ `[at, len)`
    /// `at` ต้องอยู่ในขอบเขตของจุดรหัส UTF-8
    ///
    /// โปรดทราบว่าความจุของ `self` ไม่เปลี่ยนแปลง
    ///
    /// # Panics
    ///
    /// Panics ถ้า `at` ไม่อยู่บนขอบเขตจุดรหัส `UTF-8` หรืออยู่เลยจุดรหัสสุดท้ายของสตริง
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// ตัดทอน `String` นี้โดยลบเนื้อหาทั้งหมด
    ///
    /// แม้ว่าจะหมายความว่า `String` จะมีความยาวเป็นศูนย์ แต่ก็ไม่ได้สัมผัสกับความจุ
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// สร้างตัววนรอบการระบายน้ำที่ลบช่วงที่ระบุใน `String` และให้ `chars` ที่ถูกลบออก
    ///
    ///
    /// Note: ช่วงขององค์ประกอบจะถูกลบออกแม้ว่าจะไม่มีการใช้ตัววนซ้ำจนกว่าจะสิ้นสุด
    ///
    /// # Panics
    ///
    /// Panics หากจุดเริ่มต้นหรือจุดสิ้นสุดไม่อยู่บนขอบเขต [`char`] หรือหากอยู่นอกขอบเขต
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // ลบช่วงจนถึงβออกจากสตริง
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // ช่วงเต็มจะล้างสตริง
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // ความปลอดภัยของหน่วยความจำ
        //
        // Drain เวอร์ชัน String ไม่มีปัญหาด้านความปลอดภัยของหน่วยความจำของเวอร์ชัน vector
        // ข้อมูลเป็นเพียงไบต์ธรรมดา
        // เนื่องจากการลบช่วงเกิดขึ้นใน Drop หากตัววนซ้ำ Drain รั่วการลบจะไม่เกิดขึ้น
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // ออกสองยืมพร้อมกัน
        // &mut String จะไม่สามารถเข้าถึงได้จนกว่าการทำซ้ำจะสิ้นสุดลงใน Drop
        let self_ptr = self as *mut _;
        // ความปลอดภัย: `slice::range` และ `is_char_boundary` ทำการตรวจสอบขอบเขตที่เหมาะสม
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// ลบช่วงที่ระบุในสตริงและแทนที่ด้วยสตริงที่กำหนด
    /// สตริงที่กำหนดไม่จำเป็นต้องมีความยาวเท่ากับช่วง
    ///
    /// # Panics
    ///
    /// Panics หากจุดเริ่มต้นหรือจุดสิ้นสุดไม่อยู่บนขอบเขต [`char`] หรือหากอยู่นอกขอบเขต
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // แทนที่ช่วงจนถึงβจากสตริง
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // ความปลอดภัยของหน่วยความจำ
        //
        // Replace_range ไม่มีปัญหาด้านความปลอดภัยของหน่วยความจำของ vector Splice
        // ของรุ่น vector ข้อมูลเป็นเพียงไบต์ธรรมดา

        // คำเตือน: การแทรกตัวแปรนี้จะเป็น (#81138) ที่ไม่สมบูรณ์
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // คำเตือน: การแทรกตัวแปรนี้จะเป็น (#81138) ที่ไม่สมบูรณ์
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // การใช้ `range` อีกครั้งจะไม่เป็นผล (#81138) เราถือว่าขอบเขตที่รายงานโดย `range` ยังคงเหมือนเดิม แต่การใช้งานในทางตรงข้ามอาจเปลี่ยนแปลงได้ระหว่างการโทร
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// แปลง `String` นี้เป็น [`Box`]`<`[`str`] `>`
    ///
    /// ซึ่งจะทำให้ความจุส่วนเกินลดลง
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// ส่งคืนส่วนของ ["u8`] s ไบต์ที่พยายามแปลงเป็น `String`
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// // บางไบต์ที่ไม่ถูกต้องใน vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// ส่งคืนไบต์ที่พยายามแปลงเป็น `String`
    ///
    /// วิธีนี้ถูกสร้างขึ้นอย่างรอบคอบเพื่อหลีกเลี่ยงการจัดสรร
    /// มันจะใช้ข้อผิดพลาดโดยย้ายไบต์ออกเพื่อไม่ต้องทำสำเนาไบต์
    ///
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// // บางไบต์ที่ไม่ถูกต้องใน vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// ดึงข้อมูล `Utf8Error` เพื่อดูรายละเอียดเพิ่มเติมเกี่ยวกับความล้มเหลวของการแปลง
    ///
    /// ประเภท [`Utf8Error`] ที่ [`std::str`] จัดเตรียมไว้แสดงถึงข้อผิดพลาดที่อาจเกิดขึ้นเมื่อแปลงชิ้นส่วนของ ["u8`] เป็น [`&str`]
    /// ในแง่นี้มันเป็นอะนาล็อกกับ `FromUtf8Error`
    /// ดูเอกสารประกอบสำหรับรายละเอียดเพิ่มเติมเกี่ยวกับการใช้งาน
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// // บางไบต์ที่ไม่ถูกต้องใน vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // ไบต์แรกไม่ถูกต้องที่นี่
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // เนื่องจากเรากำลังทำซ้ำใน "สตริง" เราจึงสามารถหลีกเลี่ยงการจัดสรรอย่างน้อยหนึ่งรายการโดยรับสตริงแรกจากตัววนซ้ำและผนวกเข้ากับสตริงที่ตามมาทั้งหมด
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // เนื่องจากเรากำลังทำซ้ำใน CoWs เราจึงสามารถ (potentially) หลีกเลี่ยงการจัดสรรอย่างน้อยหนึ่งรายการโดยรับรายการแรกและผนวกเข้ากับรายการที่ตามมาทั้งหมด
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// ความสะดวกหมายถึงการมอบหมายให้กับ im สำหรับ `&str`
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// สร้าง `String` ที่ว่างเปล่า
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// ใช้ตัวดำเนินการ `+` สำหรับการเชื่อมต่อสองสตริง
///
/// สิ่งนี้จะใช้ `String` ทางด้านซ้ายมือและใช้บัฟเฟอร์อีกครั้ง (เพิ่มขึ้นหากจำเป็น)
/// สิ่งนี้ทำเพื่อหลีกเลี่ยงการจัดสรร `String` ใหม่และคัดลอกเนื้อหาทั้งหมดในทุกการดำเนินการซึ่งจะนำไปสู่ *O*(*n*^ 2) เวลาทำงานเมื่อสร้างสตริง *n*-byte โดยการเรียงต่อกันซ้ำ ๆ
///
///
/// สายอักขระทางขวามือยืมมาเท่านั้นเนื้อหาจะถูกคัดลอกไปยัง `String` ที่ส่งคืน
///
/// # Examples
///
/// การเชื่อมต่อสอง "สตริง" จะใช้ค่าแรกตามค่าและยืมค่าที่สอง:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` ถูกย้ายและไม่สามารถใช้ที่นี่ได้อีกต่อไป
/// ```
///
/// หากคุณต้องการใช้ `String` แรกต่อไปคุณสามารถโคลนและต่อท้ายกับโคลนแทนได้:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` ยังใช้ได้อยู่ที่นี่
/// ```
///
/// การต่อชิ้น `&str` สามารถทำได้โดยการแปลงส่วนแรกเป็น `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// ใช้ตัวดำเนินการ `+=` เพื่อต่อท้าย `String`
///
/// สิ่งนี้มีลักษณะการทำงานเช่นเดียวกับวิธี [`push_str`][String::push_str]
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// นามแฝงประเภทสำหรับ [`Infallible`]
///
/// นามแฝงนี้มีอยู่เพื่อความเข้ากันได้แบบย้อนหลังและอาจถูกเลิกใช้ในที่สุด
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// trait สำหรับการแปลงค่าเป็น `String`
///
/// trait นี้ถูกนำไปใช้โดยอัตโนมัติสำหรับทุกประเภทที่ใช้ [`Display`] trait
/// ดังนั้นจึงไม่ควรใช้ `ToString` โดยตรง:
/// [`Display`] ควรนำไปใช้แทนและคุณจะได้รับการติดตั้ง `ToString` ฟรี
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// แปลงค่าที่กำหนดเป็น `String`
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// ในการใช้งานนี้วิธี `to_string` panics หากการใช้งาน `Display` ส่งกลับข้อผิดพลาด
/// สิ่งนี้บ่งชี้ถึงการใช้งาน `Display` ที่ไม่ถูกต้องเนื่องจาก `fmt::Write for String` ไม่เคยส่งกลับข้อผิดพลาดเอง
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // แนวทางทั่วไปคือห้ามใช้ฟังก์ชันทั่วไปแบบอินไลน์
    // อย่างไรก็ตามการลบ `#[inline]` ออกจากวิธีนี้ทำให้เกิดการถอยหลังที่ไม่สำคัญ
    // ดู <https://github.com/rust-lang/rust/pull/74852> ซึ่งเป็นความพยายามครั้งสุดท้ายที่จะพยายามลบออก
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// แปลง `&mut str` เป็น `String`
    ///
    /// ผลลัพธ์จะถูกจัดสรรบนฮีป
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: การทดสอบดึง libstd ซึ่งทำให้เกิดข้อผิดพลาดที่นี่
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// แปลงชิ้น `str` ที่บรรจุกล่องให้เป็น `String`
    /// เป็นที่น่าสังเกตว่า `str` slice เป็นเจ้าของ
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// แปลง `String` ที่กำหนดให้เป็นชิ้น `str` แบบบรรจุกล่องที่เป็นของเจ้าของ
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// แปลงสายอักขระเป็นตัวแปรยืม
    /// ไม่มีการจัดสรรฮีปและไม่ได้คัดลอกสตริง
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// แปลงสตริงเป็นตัวแปรที่เป็นเจ้าของ
    /// ไม่มีการจัดสรรฮีปและไม่ได้คัดลอกสตริง
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// แปลงการอ้างอิงสตริงเป็นตัวแปรที่ยืมมา
    /// ไม่มีการจัดสรรฮีปและไม่ได้คัดลอกสตริง
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// แปลง `String` ที่กำหนดให้เป็น vector `Vec` ที่เก็บค่าของชนิด `u8`
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// ตัววนซ้ำการระบายน้ำสำหรับ `String`
///
/// โครงสร้างนี้สร้างขึ้นโดยวิธี [`drain`] บน [`String`]
/// ดูเอกสารประกอบสำหรับข้อมูลเพิ่มเติม
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// จะใช้เป็น&'mut String ใน destructor
    string: *mut String,
    /// จุดเริ่มต้นของส่วนที่จะลบ
    start: usize,
    /// จุดสิ้นสุดของส่วนที่จะลบ
    end: usize,
    /// ช่วงที่เหลืออยู่ในปัจจุบันที่จะลบ
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // ใช้ Vec::drain
            // "Reaffirm" ขอบเขตจะตรวจสอบเพื่อหลีกเลี่ยงการแทรกโค้ด panic อีกครั้ง
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// ส่งคืนสตริง (ย่อย) ที่เหลือของตัววนซ้ำนี้เป็นสไลซ์
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: ไม่ใส่ข้อคิดเห็น AsRef แสดงถึงด้านล่างเมื่อทำให้เสถียร
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// ไม่แสดงความคิดเห็นเมื่อทำให้ `string_drain_as_str` เสถียร
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// นัย <'a> AsRef<str>สำหรับ Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// แสดงถึง <'a> AsRef <[u8]> สำหรับ Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}