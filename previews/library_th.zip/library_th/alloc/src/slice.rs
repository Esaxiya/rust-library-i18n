//! มุมมองที่มีขนาดแบบไดนามิกเป็นลำดับที่ต่อเนื่องกัน `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Slices คือมุมมองในบล็อกของหน่วยความจำที่แสดงเป็นตัวชี้และความยาว
//!
//! ```
//! // หั่น Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // บังคับอาร์เรย์ให้เป็นชิ้น
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! ชิ้นส่วนสามารถเปลี่ยนแปลงได้หรือใช้ร่วมกันได้
//! ประเภทสไลซ์ที่ใช้ร่วมกันคือ `&[T]` ในขณะที่ประเภทสไลซ์ที่เปลี่ยนแปลงได้คือ `&mut [T]` โดยที่ `T` แสดงถึงประเภทองค์ประกอบ
//! ตัวอย่างเช่นคุณสามารถเปลี่ยนบล็อกของหน่วยความจำที่ชิ้นส่วนที่เปลี่ยนแปลงได้ชี้ไปที่:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! นี่คือบางส่วนของสิ่งต่างๆในโมดูลนี้:
//!
//! ## Structs
//!
//! มีโครงสร้างหลายอย่างที่มีประโยชน์สำหรับสไลซ์เช่น [`Iter`] ซึ่งแสดงถึงการวนซ้ำบนสไลซ์
//!
//! ## การใช้งาน Trait
//!
//! มีการใช้ traits ทั่วไปหลายอย่างสำหรับชิ้นส่วนตัวอย่างบางส่วน ได้แก่ :
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`] สำหรับชิ้นส่วนที่มีประเภทองค์ประกอบคือ [`Eq`] หรือ [`Ord`]
//! * [`Hash`] - สำหรับชิ้นส่วนที่มีประเภทองค์ประกอบคือ [`Hash`]
//!
//! ## Iteration
//!
//! ชิ้นส่วนใช้ `IntoIterator` ตัววนซ้ำให้การอ้างอิงถึงองค์ประกอบของชิ้นส่วน
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! ชิ้นส่วนที่เปลี่ยนแปลงได้ให้การอ้างอิงองค์ประกอบที่ไม่แน่นอน:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! ตัววนซ้ำนี้ให้การอ้างอิงที่ไม่แน่นอนไปยังองค์ประกอบของชิ้นส่วนดังนั้นในขณะที่ประเภทองค์ประกอบของชิ้นส่วนคือ `i32` ประเภทองค์ประกอบของตัววนซ้ำคือ `&mut i32`
//!
//!
//! * [`.iter`] และ [`.iter_mut`] เป็นวิธีการที่ชัดเจนในการคืนค่าตัววนซ้ำเริ่มต้น
//! * วิธีการอื่น ๆ ที่ส่งคืนตัวทำซ้ำ ได้แก่ [`.split`], [`.splitn`], [`.chunks`], [`.windows`] และอื่น ๆ
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// การใช้งานหลายอย่างในโมดูลนี้ใช้ในการกำหนดค่าการทดสอบเท่านั้น
// เพียงแค่ปิดคำเตือน unused_imports จะสะอาดกว่าที่จะแก้ไข
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// วิธีการขยายสไลซ์ขั้นพื้นฐาน
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) จำเป็นสำหรับการใช้งานมาโคร `vec!` ในระหว่างการทดสอบ NB โปรดดูโมดูล `hack` ในไฟล์นี้สำหรับรายละเอียดเพิ่มเติม
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) จำเป็นสำหรับการใช้งาน `Vec::clone` ในระหว่างการทดสอบ NB โปรดดูโมดูล `hack` ในไฟล์นี้สำหรับรายละเอียดเพิ่มเติม
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): ด้วย cfg(test) `impl [T]` ไม่สามารถใช้งานได้จริง ๆ แล้วฟังก์ชันทั้งสามนี้เป็นวิธีการที่อยู่ใน `impl [T]` แต่ไม่ใช่ใน `core::slice::SliceExt` เราจำเป็นต้องจัดหาฟังก์ชันเหล่านี้สำหรับการทดสอบ `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // เราไม่ควรเพิ่มแอตทริบิวต์แบบอินไลน์ในสิ่งนี้เนื่องจากจะใช้ในมาโคร `vec!` เป็นส่วนใหญ่และทำให้เกิดการถดถอยแบบสมบูรณ์
    // ดู #71204 สำหรับการอภิปรายและผลลัพธ์ที่สมบูรณ์แบบ
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // รายการถูกทำเครื่องหมายเริ่มต้นในลูปด้านล่าง
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) จำเป็นสำหรับ LLVM ในการลบการตรวจสอบขอบเขตและมี codegen ที่ดีกว่า zip
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec ได้รับการจัดสรรและกำหนดค่าเริ่มต้นเหนือความยาวนี้เป็นอย่างน้อย
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // จัดสรรไว้ด้านบนด้วยความจุ `s` และเริ่มต้นเป็น `s.len()` ใน ptr::copy_to_non_overlapping ด้านล่าง
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// จัดเรียงชิ้น
    ///
    /// การเรียงลำดับนี้มีเสถียรภาพ (กล่าวคือไม่เรียงลำดับองค์ประกอบที่เท่ากันใหม่) และ *O*(*n*\*log(* n*)) กรณีที่เลวร้ายที่สุด
    ///
    /// หากเป็นไปได้ควรใช้การเรียงลำดับที่ไม่เสถียรเนื่องจากโดยทั่วไปแล้วจะเร็วกว่าการจัดเรียงแบบคงที่และไม่ได้จัดสรรหน่วยความจำเสริม
    /// ดู [`sort_unstable`](slice::sort_unstable)
    ///
    /// # การใช้งานปัจจุบัน
    ///
    /// อัลกอริทึมปัจจุบันเป็นการจัดเรียงการผสานซ้ำแบบปรับได้ซึ่งได้รับแรงบันดาลใจจาก [timsort](https://en.wikipedia.org/wiki/Timsort)
    /// ได้รับการออกแบบมาให้เร็วมากในกรณีที่ชิ้นส่วนเกือบจะเรียงลำดับหรือประกอบด้วยลำดับที่เรียงลำดับสองลำดับขึ้นไปเรียงต่อกัน
    ///
    ///
    /// นอกจากนี้ยังจัดสรรพื้นที่เก็บข้อมูลชั่วคราวครึ่งหนึ่งของขนาด `self` แต่สำหรับส่วนสั้น ๆ จะใช้การเรียงลำดับการแทรกแบบไม่จัดสรรแทน
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// จัดเรียงชิ้นงานด้วยฟังก์ชันเปรียบเทียบ
    ///
    /// การเรียงลำดับนี้มีเสถียรภาพ (กล่าวคือไม่เรียงลำดับองค์ประกอบที่เท่ากันใหม่) และ *O*(*n*\*log(* n*)) กรณีที่เลวร้ายที่สุด
    ///
    /// ฟังก์ชันตัวเปรียบเทียบต้องกำหนดการจัดลำดับทั้งหมดสำหรับองค์ประกอบในสไลซ์หากการสั่งซื้อไม่รวมลำดับขององค์ประกอบจะไม่ระบุ
    /// คำสั่งซื้อคือคำสั่งซื้อทั้งหมดหากเป็น (สำหรับ `a`, `b` และ `c` ทั้งหมด):
    ///
    /// * รวมและ antisymmetric: หนึ่งใน `a < b`, `a == b` หรือ `a > b` เป็นจริงและ
    /// * สกรรมกริยา `a < b` และ `b < c` หมายถึง `a < c` สิ่งเดียวกันจะต้องมีไว้สำหรับทั้ง `==` และ `>`
    ///
    /// ตัวอย่างเช่นในขณะที่ [`f64`] ไม่ใช้ [`Ord`] เนื่องจาก `NaN != NaN` เราสามารถใช้ `partial_cmp` เป็นฟังก์ชันการจัดเรียงของเราเมื่อเรารู้ว่าชิ้นส่วนไม่มี `NaN`
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// หากเป็นไปได้ควรใช้การเรียงลำดับที่ไม่เสถียรเนื่องจากโดยทั่วไปแล้วจะเร็วกว่าการจัดเรียงแบบคงที่และไม่ได้จัดสรรหน่วยความจำเสริม
    /// ดู [`sort_unstable_by`](slice::sort_unstable_by)
    ///
    /// # การใช้งานปัจจุบัน
    ///
    /// อัลกอริทึมปัจจุบันเป็นการจัดเรียงการผสานซ้ำแบบปรับได้ซึ่งได้รับแรงบันดาลใจจาก [timsort](https://en.wikipedia.org/wiki/Timsort)
    /// ได้รับการออกแบบมาให้เร็วมากในกรณีที่ชิ้นส่วนเกือบจะเรียงลำดับหรือประกอบด้วยลำดับที่เรียงลำดับสองลำดับขึ้นไปเรียงต่อกัน
    ///
    /// นอกจากนี้ยังจัดสรรพื้นที่เก็บข้อมูลชั่วคราวครึ่งหนึ่งของขนาด `self` แต่สำหรับส่วนสั้น ๆ จะใช้การเรียงลำดับการแทรกแบบไม่จัดสรรแทน
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // การเรียงลำดับย้อนกลับ
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// จัดเรียงชิ้นงานด้วยฟังก์ชั่นการแยกคีย์
    ///
    /// การเรียงลำดับนี้มีเสถียรภาพ (กล่าวคือไม่เรียงลำดับองค์ประกอบที่เท่ากันใหม่) และ *O*(*m*\*n*\*log(* n *)) กรณีที่แย่ที่สุดโดยที่ฟังก์ชันคีย์คือ* O *(* m *)
    ///
    /// สำหรับฟังก์ชั่นหลักราคาแพง (เช่น
    /// ฟังก์ชันที่ไม่ใช่การเข้าถึงคุณสมบัติอย่างง่ายหรือการดำเนินการขั้นพื้นฐาน) [`sort_by_cached_key`](slice::sort_by_cached_key) มีแนวโน้มที่จะเร็วขึ้นอย่างมากเนื่องจากไม่คำนวณคีย์องค์ประกอบซ้ำ
    ///
    ///
    /// หากเป็นไปได้ควรใช้การเรียงลำดับที่ไม่เสถียรเนื่องจากโดยทั่วไปแล้วจะเร็วกว่าการจัดเรียงแบบคงที่และไม่ได้จัดสรรหน่วยความจำเสริม
    /// ดู [`sort_unstable_by_key`](slice::sort_unstable_by_key)
    ///
    /// # การใช้งานปัจจุบัน
    ///
    /// อัลกอริทึมปัจจุบันเป็นการจัดเรียงการผสานซ้ำแบบปรับได้ซึ่งได้รับแรงบันดาลใจจาก [timsort](https://en.wikipedia.org/wiki/Timsort)
    /// ได้รับการออกแบบมาให้เร็วมากในกรณีที่ชิ้นส่วนเกือบจะเรียงลำดับหรือประกอบด้วยลำดับที่เรียงลำดับสองลำดับขึ้นไปเรียงต่อกัน
    ///
    /// นอกจากนี้ยังจัดสรรพื้นที่เก็บข้อมูลชั่วคราวครึ่งหนึ่งของขนาด `self` แต่สำหรับส่วนสั้น ๆ จะใช้การเรียงลำดับการแทรกแบบไม่จัดสรรแทน
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// จัดเรียงชิ้นงานด้วยฟังก์ชั่นการแยกคีย์
    ///
    /// ในระหว่างการเรียงลำดับฟังก์ชันคีย์จะถูกเรียกใช้เพียงครั้งเดียวต่อองค์ประกอบ
    ///
    /// การเรียงลำดับนี้มีเสถียรภาพ (กล่าวคือไม่เรียงลำดับองค์ประกอบที่เท่ากันใหม่) และ *O*(*m*\*n* + *n*\*log(* n *)) กรณีที่เลวร้ายที่สุดโดยที่ฟังก์ชันคีย์คือ* O *(* m *) .
    ///
    /// สำหรับฟังก์ชันหลักอย่างง่าย (เช่นฟังก์ชันที่เป็นการเข้าถึงคุณสมบัติหรือการทำงานพื้นฐาน) [`sort_by_key`](slice::sort_by_key) น่าจะเร็วกว่า
    ///
    /// # การใช้งานปัจจุบัน
    ///
    /// อัลกอริทึมปัจจุบันอยู่บนพื้นฐานของ [pattern-defeating quicksort][pdqsort] โดย Orson Peters ซึ่งรวมกรณีค่าเฉลี่ยที่รวดเร็วของ Quicksort แบบสุ่มกับกรณีที่เลวร้ายที่สุดของ heapsort อย่างรวดเร็วในขณะที่บรรลุเวลาเชิงเส้นบนชิ้นงานที่มีรูปแบบบางอย่าง
    /// มันใช้การสุ่มบางอย่างเพื่อหลีกเลี่ยงกรณีที่เสื่อมสภาพ แต่ด้วย seed คงที่เพื่อให้พฤติกรรมที่กำหนดไว้เสมอ
    ///
    /// ในกรณีที่เลวร้ายที่สุดอัลกอริทึมจะจัดสรรพื้นที่เก็บข้อมูลชั่วคราวเป็น `Vec<(K, usize)>` ตามความยาวของชิ้นส่วน
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // มาโครตัวช่วยสำหรับจัดทำดัชนี vector ของเราตามประเภทที่เล็กที่สุดเพื่อลดการจัดสรร
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // องค์ประกอบของ `indices` มีลักษณะเฉพาะเนื่องจากมีการจัดทำดัชนีดังนั้นการจัดเรียงใด ๆ จะคงที่เมื่อเทียบกับชิ้นส่วนต้นฉบับ
                // เราใช้ `sort_unstable` ที่นี่เนื่องจากต้องการการจัดสรรหน่วยความจำน้อยลง
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// คัดลอก `self` เป็น `Vec` ใหม่
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // ที่นี่ `s` และ `x` สามารถแก้ไขได้อย่างอิสระ
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// คัดลอก `self` ลงใน `Vec` ใหม่ด้วยตัวจัดสรร
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // ที่นี่ `s` และ `x` สามารถแก้ไขได้อย่างอิสระ
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // หมายเหตุโปรดดูโมดูล `hack` ในไฟล์นี้สำหรับรายละเอียดเพิ่มเติม
        hack::to_vec(self, alloc)
    }

    /// แปลง `self` เป็น vector โดยไม่ต้องโคลนหรือจัดสรร
    ///
    /// vector ที่เป็นผลลัพธ์สามารถแปลงกลับเป็นกล่องผ่านทาง ``Vec<T>วิธี `into_boxed_slice` ของ``
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` ไม่สามารถใช้งานได้อีกต่อไปเนื่องจากถูกแปลงเป็น `x`
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // หมายเหตุโปรดดูโมดูล `hack` ในไฟล์นี้สำหรับรายละเอียดเพิ่มเติม
        hack::into_vec(self)
    }

    /// สร้าง vector โดยการทำซ้ำ `n` ครั้ง
    ///
    /// # Panics
    ///
    /// ฟังก์ชั่นนี้จะ panic หากความจุล้น
    ///
    /// # Examples
    ///
    /// การใช้งานพื้นฐาน:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic เมื่อล้น:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // หาก `n` มีขนาดใหญ่กว่าศูนย์สามารถแยกเป็น `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` ได้
        // `2^expn` คือตัวเลขที่แทนด้วย '1' บิตซ้ายสุดของ `n` และ `rem` คือส่วนที่เหลือของ `n`
        //
        //

        // ใช้ `Vec` เพื่อเข้าถึง `set_len()`
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` การทำซ้ำทำได้โดยการเพิ่ม `buf` "expn`-times เป็นสองเท่า
        buf.extend(self);
        {
            let mut m = n >> 1;
            // ถ้า `m > 0` มีบิตเหลืออยู่จนถึง '1' ซ้ายสุด
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` มีความจุ `self.len() * n`
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) การทำซ้ำทำได้โดยการคัดลอกการทำซ้ำ `rem` ครั้งแรกจาก `buf` เอง
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // สิ่งนี้ไม่ทับซ้อนกันตั้งแต่ `2^expn > rem`
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` เท่ากับ `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// แผ่ `T` เป็นค่าเดียว `Self::Output`
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// แผ่ส่วน `T` ให้เป็นค่า `Self::Output` ค่าเดียวโดยวางตัวคั่นที่กำหนดไว้ระหว่างแต่ละค่า
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// แผ่ส่วน `T` ให้เป็นค่า `Self::Output` ค่าเดียวโดยวางตัวคั่นที่กำหนดไว้ระหว่างแต่ละค่า
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// ส่งคืน vector ที่มีสำเนาของชิ้นส่วนนี้โดยที่แต่ละไบต์ถูกแมปกับ ASCII ตัวพิมพ์ใหญ่
    ///
    ///
    /// ตัวอักษร ASCII 'a' ถึง 'z' ถูกแมปกับ 'A' ถึง 'Z' แต่ตัวอักษรที่ไม่ใช่ ASCII จะไม่เปลี่ยนแปลง
    ///
    /// หากต้องการตัวพิมพ์ใหญ่ค่าแทนให้ใช้ [`make_ascii_uppercase`]
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// ส่งคืน vector ที่มีสำเนาของชิ้นส่วนนี้โดยที่แต่ละไบต์ถูกแมปกับ ASCII ตัวพิมพ์เล็กที่เทียบเท่า
    ///
    ///
    /// ตัวอักษร ASCII 'A' ถึง 'Z' ถูกแมปกับ 'a' ถึง 'z' แต่ตัวอักษรที่ไม่ใช่ ASCII จะไม่เปลี่ยนแปลง
    ///
    /// ในการพิมพ์ค่าให้เล็กลงให้ใช้ [`make_ascii_lowercase`]
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// ส่วนขยาย traits สำหรับชิ้นส่วนข้อมูลบางประเภท
////////////////////////////////////////////////////////////////////////////////

/// ตัวช่วย trait สำหรับ [`[T]: : concat`](slice::concat)
///
/// Note: ไม่ได้ใช้พารามิเตอร์ประเภท `Item` ใน trait นี้ แต่อนุญาตให้มีการแสดงนัยทั่วไปมากขึ้น
/// หากไม่มีเราจะได้รับข้อผิดพลาดนี้:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// เนื่องจากอาจมีประเภท `V` ที่มี `Borrow<[_]>` หลายนัยดังนั้นจึงใช้ `T` หลายประเภท:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// ประเภทผลลัพธ์หลังจากการเรียงต่อกัน
    type Output;

    /// การใช้งาน [`[T]: : concat`](slice::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// ตัวช่วย trait สำหรับ [`[T]: : join`](slice::join)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// ประเภทผลลัพธ์หลังจากการเรียงต่อกัน
    type Output;

    /// การใช้งาน [`[T]: : join`](slice::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// การใช้งาน trait มาตรฐานสำหรับชิ้นส่วน
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // วางอะไรก็ได้ในเป้าหมายที่จะไม่ถูกเขียนทับ
        target.truncate(self.len());

        // target.len <= self.len เนื่องจากการตัดทอนด้านบนดังนั้นชิ้นส่วนที่นี่จึงอยู่ในขอบเขตเสมอ
        //
        let (init, tail) = self.split_at(target.len());

        // นำค่าที่มีอยู่มาใช้ซ้ำ allocations/resources
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// แทรก `v[0]` ลงในลำดับที่เรียงไว้ล่วงหน้า `v[1..]` เพื่อให้ `v[..]` ทั้งหมดถูกจัดเรียง
///
/// นี่คือรูทีนย่อยอินทิกรัลของการเรียงลำดับการแทรก
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // มีสามวิธีในการใช้การแทรกที่นี่:
            //
            // 1. สลับองค์ประกอบที่อยู่ติดกันจนกว่าองค์ประกอบแรกจะไปถึงปลายทางสุดท้าย
            //    อย่างไรก็ตามวิธีนี้เราคัดลอกข้อมูลมากเกินความจำเป็น
            //    หากองค์ประกอบมีโครงสร้างขนาดใหญ่ (มีค่าใช้จ่ายสูงในการคัดลอก) วิธีนี้จะช้า
            //
            // 2. วนซ้ำจนกว่าจะพบตำแหน่งที่เหมาะสมสำหรับองค์ประกอบแรก
            // จากนั้นเปลี่ยนองค์ประกอบที่ประสบความสำเร็จเพื่อให้มีที่ว่างและสุดท้ายวางลงในรูที่เหลือ
            // นี่เป็นวิธีการที่ดี
            //
            // 3. คัดลอกองค์ประกอบแรกลงในตัวแปรชั่วคราวทำซ้ำจนกว่าจะพบตำแหน่งที่เหมาะสม
            // ในขณะที่เราดำเนินการต่อให้คัดลอกทุกองค์ประกอบที่ข้ามไปยังช่องที่อยู่ข้างหน้า
            // สุดท้ายคัดลอกข้อมูลจากตัวแปรชั่วคราวลงในรูที่เหลือ
            // วิธีนี้เป็นวิธีที่ดีมาก
            // เกณฑ์มาตรฐานแสดงให้เห็นถึงประสิทธิภาพที่ดีขึ้นเล็กน้อยเมื่อเทียบกับวิธีที่ 2
            //
            // วิธีการทั้งหมดได้รับการเปรียบเทียบและวิธีที่ 3 แสดงผลลัพธ์ที่ดีที่สุดเราก็เลยเลือกอันนั้น
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // สถานะระดับกลางของกระบวนการแทรกจะถูกติดตามโดย `hole` เสมอซึ่งทำหน้าที่สองวัตถุประสงค์:
            // 1. ปกป้องความสมบูรณ์ของ `v` จาก panics ใน `is_less`
            // 2. เติมรูที่เหลือใน `v` ในตอนท้าย
            //
            // Panic ความปลอดภัย:
            //
            // หาก `is_less` panics ณ จุดใดก็ได้ในระหว่างกระบวนการ `hole` จะหลุดและอุดรูใน `v` ด้วย `tmp` ดังนั้นจึงมั่นใจได้ว่า `v` ยังคงถือวัตถุทุกชิ้นที่ถือไว้ในตอนแรกอย่างแน่นอน
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` หลุดออกจึงคัดลอก `tmp` ลงในรูที่เหลือใน `v`
        }
    }

    // เมื่อตกหล่นให้คัดลอกจาก `src` เป็น `dest`
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// ผสานการรันที่ไม่ลดลง `v[..mid]` และ `v[mid..]` โดยใช้ `buf` เป็นที่เก็บข้อมูลชั่วคราวและเก็บผลลัพธ์ไว้ใน `v[..]`
///
/// # Safety
///
/// สองชิ้นต้องไม่ว่างเปล่าและ `mid` ต้องอยู่ในขอบเขต
/// บัฟเฟอร์ `buf` ต้องยาวพอที่จะเก็บสำเนาของชิ้นส่วนที่สั้นกว่าได้
/// นอกจากนี้ `T` ต้องไม่เป็นประเภทศูนย์
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // ขั้นแรกการผสานจะคัดลอกการรันที่สั้นกว่าลงใน `buf`
    // จากนั้นจะติดตามการวิ่งที่คัดลอกใหม่และการวิ่งไปข้างหน้าอีกต่อไป (หรือถอยหลัง) เปรียบเทียบองค์ประกอบที่ไม่มีการบริโภคถัดไปและคัดลอกองค์ประกอบที่น้อยกว่า (หรือมากกว่า) ลงใน `v`
    //
    // ทันทีที่การวิ่งที่สั้นกว่าถูกใช้จนหมดกระบวนการจะเสร็จสิ้นหากการวิ่งที่ยาวกว่าหมดไปก่อนเราจะต้องคัดลอกสิ่งที่เหลืออยู่ของการวิ่งที่สั้นกว่าลงในรูที่เหลือใน `v`
    //
    // สถานะระดับกลางของกระบวนการจะถูกติดตามโดย `hole` เสมอซึ่งทำหน้าที่สองวัตถุประสงค์:
    // 1. ปกป้องความสมบูรณ์ของ `v` จาก panics ใน `is_less`
    // 2. เติมช่องที่เหลือใน `v` หากการวิ่งที่ยาวขึ้นจะหมดลงก่อน
    //
    // Panic ความปลอดภัย:
    //
    // หาก `is_less` panics ณ จุดใด ๆ ในระหว่างกระบวนการ `hole` จะหลุดและเติมหลุมใน `v` ด้วยช่วงที่ไม่มีการบริโภคใน `buf` ดังนั้นจึงมั่นใจได้ว่า `v` ยังคงเก็บวัตถุทุกชิ้นที่ถือไว้ในตอนแรกอย่างแน่นอน
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // วิ่งซ้ายจะสั้นกว่า
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // ในขั้นต้นพอยน์เตอร์เหล่านี้จะชี้ไปที่จุดเริ่มต้นของอาร์เรย์
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // กินด้านที่น้อยกว่า
            // ถ้าเท่ากันให้เลือกวิ่งซ้ายเพื่อรักษาเสถียรภาพ
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // วิ่งขวาจะสั้นกว่า
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // ในขั้นต้นพอยน์เตอร์เหล่านี้จะชี้เลยจุดสิ้นสุดของอาร์เรย์
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // กินด้านที่มากขึ้น
            // หากเท่ากันให้เลือกการวิ่งที่ถูกต้องเพื่อรักษาเสถียรภาพ
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // ในที่สุด `hole` ก็หลุด
    // หากการวิ่งที่สั้นกว่าไม่ได้ใช้จนหมดตอนนี้สิ่งที่เหลืออยู่จะถูกคัดลอกลงในรูใน `v`

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // เมื่อตกหล่นให้คัดลอกช่วง `start..end` ลงใน `dest..`
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` ไม่ใช่ประเภทที่มีขนาดศูนย์ดังนั้นจึงสามารถหารด้วยขนาดได้
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// การเรียงลำดับการผสานนี้ยืมแนวคิดบางอย่าง (แต่ไม่ใช่ทั้งหมด) จาก TimSort ซึ่งอธิบายไว้ในรายละเอียด [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt)
///
///
/// อัลกอริทึมระบุลำดับจากมากไปน้อยอย่างเคร่งครัดและไม่ลดลงซึ่งเรียกว่าการวิ่งตามธรรมชาติมีสแต็กของการดำเนินการที่รอดำเนินการที่ยังไม่ได้รวม
/// การเรียกใช้ที่พบใหม่แต่ละครั้งจะถูกผลักไปยังสแต็กจากนั้นการรันที่อยู่ติดกันบางคู่จะถูกรวมเข้าด้วยกันจนกว่าค่าคงที่ทั้งสองนี้จะเป็นที่พอใจ
///
/// 1. สำหรับทุก `i` ใน `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. สำหรับทุก `i` ใน `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// ค่าคงที่ทำให้แน่ใจว่าเวลาทำงานทั้งหมดคือ *O*(*n*\*log(* n*)) กรณีที่เลวร้ายที่สุด
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // ชิ้นส่วนที่มีความยาวไม่เกินนี้จะถูกจัดเรียงโดยใช้การเรียงลำดับการแทรก
    const MAX_INSERTION: usize = 20;
    // การวิ่งระยะสั้นมากจะขยายโดยใช้การเรียงลำดับการแทรกเพื่อขยายองค์ประกอบจำนวนมากนี้เป็นอย่างน้อย
    const MIN_RUN: usize = 10;

    // การเรียงลำดับไม่มีพฤติกรรมที่มีความหมายสำหรับประเภทที่มีขนาดศูนย์
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // อาร์เรย์แบบสั้นจะถูกจัดเรียงในตำแหน่งผ่านการเรียงลำดับการแทรกเพื่อหลีกเลี่ยงการจัดสรร
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // จัดสรรบัฟเฟอร์เพื่อใช้เป็นหน่วยความจำรอยขีดข่วนเรารักษาความยาวเป็น 0 เพื่อให้เราสามารถเก็บสำเนาเนื้อหาของ `v` ไว้ได้โดยไม่ต้องเสี่ยงกับ dtors ที่ทำงานบนสำเนาหาก `is_less` panics
    //
    // เมื่อผสานการทำงานที่เรียงลำดับสองรายการบัฟเฟอร์นี้จะเก็บสำเนาของการรันที่สั้นกว่าซึ่งจะมีความยาวสูงสุด `len / 2` เสมอ
    //
    let mut buf = Vec::with_capacity(len / 2);

    // ในการระบุการวิ่งตามธรรมชาติใน `v` เราจะข้ามมันไปข้างหลัง
    // นั่นอาจดูเหมือนเป็นการตัดสินใจที่แปลก แต่ให้พิจารณาข้อเท็จจริงที่ว่าการผสานมักจะไปในทิศทางตรงกันข้ามกับ (forwards)
    // ตามเกณฑ์มาตรฐานการรวมไปข้างหน้าจะเร็วกว่าการรวมไปข้างหลังเล็กน้อย
    // สรุปได้ว่าการระบุการวิ่งโดยการย้อนกลับจะช่วยเพิ่มประสิทธิภาพ
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // ค้นหาการวิ่งตามธรรมชาติครั้งต่อไปและย้อนกลับหากเป็นการวิ่งจากมากไปน้อยอย่างเคร่งครัด
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // แทรกองค์ประกอบเพิ่มเติมลงในการวิ่งหากสั้นเกินไป
        // การเรียงลำดับการแทรกจะเร็วกว่าการเรียงลำดับแบบผสานในลำดับสั้น ๆ ดังนั้นสิ่งนี้จึงช่วยเพิ่มประสิทธิภาพได้อย่างมาก
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // ดันการวิ่งนี้ไปยังสแต็ก
        runs.push(Run { start, len: end - start });
        end = start;

        // ผสานการวิ่งที่อยู่ติดกันบางคู่เพื่อตอบสนองค่าคงที่
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // สุดท้ายการรันหนึ่งครั้งจะต้องอยู่ในสแต็ก
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // ตรวจสอบสแต็กของการรันและระบุการวิ่งคู่ถัดไปที่จะผสาน
    // โดยเฉพาะอย่างยิ่งถ้าส่งคืน `Some(r)` นั่นหมายความว่า `runs[r]` และ `runs[r + 1]` จะต้องถูกรวมเข้าด้วยกัน
    // หากอัลกอริทึมควรสร้างการรันใหม่แทน `None` จะถูกส่งคืน
    //
    // TimSort นั้นน่าอับอายสำหรับการใช้งานที่ผิดพลาดดังที่อธิบายไว้ที่นี่:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // สาระสำคัญของเรื่องนี้คือ: เราต้องบังคับให้ไม่แปรผันในสี่อันดับแรกวิ่งบนสแต็ก
    // การบังคับใช้เพียงสามอันดับแรกนั้นไม่เพียงพอที่จะทำให้มั่นใจได้ว่าค่าคงที่จะยังคงอยู่สำหรับการรัน *ทั้งหมด* ในสแต็ก
    //
    // ฟังก์ชันนี้จะตรวจสอบค่าคงที่สำหรับการรันสี่อันดับแรกอย่างถูกต้อง
    // นอกจากนี้หากการรันบนสุดเริ่มต้นที่ดัชนี 0 จะต้องมีการดำเนินการผสานเสมอจนกว่าสแต็กจะยุบลงทั้งหมดเพื่อให้การเรียงลำดับเสร็จสมบูรณ์
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}