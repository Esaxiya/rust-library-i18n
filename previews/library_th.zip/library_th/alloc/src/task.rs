#![stable(feature = "wake_trait", since = "1.51.0")]
//! ประเภทและ Traits สำหรับการทำงานกับงานอะซิงโครนัส
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// การดำเนินการปลุกงานบนตัวดำเนินการ
///
/// trait นี้สามารถใช้เพื่อสร้าง [`Waker`]
/// ผู้ดำเนินการสามารถกำหนดการใช้งาน trait นี้และใช้เพื่อสร้าง Waker เพื่อส่งผ่านไปยังงานที่ดำเนินการบนตัวดำเนินการนั้น
///
/// trait นี้เป็นทางเลือกที่ปลอดภัยต่อหน่วยความจำและถูกหลักสรีรศาสตร์ในการสร้าง [`RawWaker`]
/// สนับสนุนการออกแบบตัวดำเนินการทั่วไปซึ่งข้อมูลที่ใช้ในการปลุกงานจะถูกเก็บไว้ใน [`Arc`]
/// ตัวดำเนินการบางตัว (โดยเฉพาะสำหรับระบบฝังตัว) ไม่สามารถใช้ API นี้ได้จึงมี [`RawWaker`] เป็นทางเลือกสำหรับระบบเหล่านั้น
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// ฟังก์ชัน `block_on` พื้นฐานที่ใช้ future และรันจนเสร็จสมบูรณ์บนเธรดปัจจุบัน
///
/// **Note:** ตัวอย่างนี้แลกเปลี่ยนความถูกต้องเพื่อความเรียบง่าย
/// เพื่อป้องกันการชะงักงันการใช้งานเกรดการผลิตจะต้องจัดการการเรียกระดับกลางไปยัง `thread::unpark` เช่นเดียวกับการเรียกใช้แบบซ้อนกัน
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Waker ที่ปลุกเธรดปัจจุบันเมื่อถูกเรียก
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// รัน future เพื่อทำให้เธรดปัจจุบันเสร็จสมบูรณ์
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // ตรึง future เพื่อให้สามารถสำรวจได้
///     let mut fut = Box::pin(fut);
///
///     // สร้างบริบทใหม่เพื่อส่งต่อไปยัง future
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // รัน future จนเสร็จสิ้น
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// ปลุกงานนี้
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// ปลุกงานนี้โดยไม่ต้องใช้เวคเกอร์
    ///
    /// หากผู้ดำเนินการสนับสนุนวิธีการปลุกที่ถูกกว่าโดยไม่ต้องใช้เวคเกอร์ก็ควรแทนที่วิธีนี้
    /// โดยค่าเริ่มต้นจะโคลน [`Arc`] และเรียกใช้ [`wake`] บนโคลน
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // ความปลอดภัย: ปลอดภัยเนื่องจาก raw_waker สร้างขึ้นอย่างปลอดภัย
        // RawWaker จาก Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: ฟังก์ชันส่วนตัวนี้สำหรับการสร้าง RawWaker ใช้แทน
// การรวมสิ่งนี้ไว้ใน `From<Arc<W>> for RawWaker` im เพื่อให้แน่ใจว่าความปลอดภัยของ `From<Arc<W>> for Waker` ไม่ได้ขึ้นอยู่กับการจัดส่ง trait ที่ถูกต้อง แต่ทั้งสองนัยจะเรียกฟังก์ชันนี้โดยตรงและชัดเจน
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // เพิ่มจำนวนอ้างอิงของส่วนโค้งเพื่อโคลน
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // ปลุกตามค่าย้าย Arc ไปยังฟังก์ชัน Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // ปลุกโดยอ้างอิงห่อ waker ใน ManuallyDrop เพื่อหลีกเลี่ยงการหล่น
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // ลดจำนวนอ้างอิงของ Arc เมื่อดรอป
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}