//! # ไลบรารีการจัดสรรแกนและคอลเลกชัน Rust
//!
//! ไลบรารีนี้มีพอยน์เตอร์อัจฉริยะและคอลเล็กชันสำหรับจัดการค่าที่จัดสรรฮีป
//!
//! ไลบรารีนี้เช่น libcore โดยปกติไม่จำเป็นต้องใช้โดยตรงเนื่องจากเนื้อหาจะถูกส่งออกอีกครั้งใน [`std` crate](../std/index.html)
//! Crates ที่ใช้แอตทริบิวต์ `#![no_std]` อย่างไรก็ตามโดยทั่วไปจะไม่ขึ้นอยู่กับ `std` ดังนั้นพวกเขาจึงใช้ crate นี้แทน
//!
//! ## ค่าบรรจุกล่อง
//!
//! ประเภท [`Box`] เป็นประเภทตัวชี้อัจฉริยะสามารถมีเจ้าของ [`Box`] ได้เพียงคนเดียวและเจ้าของสามารถตัดสินใจที่จะกลายพันธุ์เนื้อหาที่อยู่บนฮีปได้
//!
//! ประเภทนี้สามารถส่งระหว่างเธรดได้อย่างมีประสิทธิภาพเนื่องจากขนาดของค่า `Box` เท่ากับของตัวชี้
//! โครงสร้างข้อมูลแบบต้นไม้มักสร้างด้วยกล่องเนื่องจากแต่ละโหนดมักมีเจ้าของเพียงคนเดียวคือพาเรนต์
//!
//! ## ตัวชี้การนับอ้างอิง
//!
//! ชนิด [`Rc`] เป็นชนิดตัวชี้ที่นับการอ้างอิงที่ไม่ปลอดภัยสำหรับเธรดที่มีไว้สำหรับการแบ่งปันหน่วยความจำภายในเธรด
//! ตัวชี้ [`Rc`] ห่อหุ้มชนิด `T` และอนุญาตให้เข้าถึง `&T` เท่านั้นซึ่งเป็นข้อมูลอ้างอิงที่ใช้ร่วมกัน
//!
//! ประเภทนี้มีประโยชน์เมื่อความสามารถในการกลายพันธุ์ที่สืบทอดมา (เช่นการใช้ [`Box`]) เป็นสิ่งที่ จำกัด เกินไปสำหรับแอปพลิเคชันและมักจะจับคู่กับประเภท [`Cell`] หรือ [`RefCell`] เพื่ออนุญาตให้เกิดการกลายพันธุ์
//!
//!
//! ## พอยน์เตอร์ที่นับอ้างอิงทางอะตอม
//!
//! ประเภท [`Arc`] เทียบเท่ากับ threadsafe ของ [`Rc`] มีฟังก์ชันการทำงานที่เหมือนกันทั้งหมดของ [`Rc`] ยกเว้นต้องการให้ `T` ประเภทที่มีอยู่นั้นสามารถแชร์ได้
//! นอกจากนี้ [`Arc<T>`][`Arc`] ยังสามารถส่งได้ในขณะที่ [`Rc<T>`][`Rc`] ไม่ใช่
//!
//! ประเภทนี้อนุญาตให้ใช้ร่วมกันในการเข้าถึงข้อมูลที่มีอยู่และมักจะจับคู่กับซิงโครไนซ์ไพรมารีเช่น mutexes เพื่อให้เกิดการกลายพันธุ์ของทรัพยากรที่แบ่งใช้
//!
//! ## Collections
//!
//! การปรับใช้โครงสร้างข้อมูลวัตถุประสงค์ทั่วไปส่วนใหญ่ถูกกำหนดไว้ในไลบรารีนี้พวกมันถูกส่งออกอีกครั้งผ่าน [standard collections library](../std/collections/index.html)
//!
//! ## ฮีปอินเทอร์เฟซ
//!
//! โมดูล [`alloc`](alloc/index.html) กำหนดอินเทอร์เฟซระดับต่ำให้กับตัวจัดสรรส่วนกลางเริ่มต้นเข้ากันไม่ได้กับ libc ตัวจัดสรร API
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// ในทางเทคนิคนี่เป็นข้อผิดพลาดใน rustdoc: rustdoc เห็นเอกสารเกี่ยวกับบล็อก `#[lang = slice_alloc]` สำหรับ `&[T]` ซึ่งมีเอกสารประกอบโดยใช้คุณลักษณะนี้ใน `core` และรู้สึกไม่ดีที่ไม่ได้เปิดใช้งานประตูคุณลักษณะ
// ตามหลักการแล้วมันจะไม่ตรวจสอบประตูคุณลักษณะสำหรับเอกสารจาก crates อื่น ๆ แต่เนื่องจากสิ่งนี้สามารถปรากฏได้เฉพาะสำหรับรายการ lang จึงดูเหมือนไม่คุ้มค่าที่จะแก้ไข
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// อนุญาตให้ทดสอบไลบรารีนี้

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// โมดูลที่มีมาโครภายในที่ใช้โดยโมดูลอื่น ๆ (จำเป็นต้องรวมไว้ก่อนโมดูลอื่น ๆ)
#[macro_use]
mod macros;

// ฮีปจัดเตรียมไว้สำหรับกลยุทธ์การจัดสรรระดับต่ำ

pub mod alloc;

// ประเภทดั้งเดิมโดยใช้ฮีปด้านบน

// จำเป็นต้องกำหนด mod ตามเงื่อนไขจาก `boxed.rs` เพื่อหลีกเลี่ยงการทำซ้ำ lang-items เมื่อสร้างใน cfg การทดสอบแต่ยังต้องอนุญาตให้โค้ดมีการประกาศ `use boxed::Box;`
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}