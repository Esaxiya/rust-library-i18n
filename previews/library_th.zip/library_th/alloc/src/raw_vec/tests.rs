use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // การเขียนการทดสอบการผสานรวมระหว่างผู้จัดสรรบุคคลที่สามและ `RawVec` เป็นเรื่องยุ่งยากเล็กน้อยเนื่องจาก `RawVec` API ไม่เปิดเผยวิธีการจัดสรรที่ผิดพลาดดังนั้นเราจึงไม่สามารถตรวจสอบสิ่งที่เกิดขึ้นเมื่อตัวจัดสรรหมดลง (นอกเหนือจากการตรวจจับ panic)
    //
    //
    // แต่นี่เป็นเพียงการตรวจสอบว่าอย่างน้อยวิธี `RawVec` ต้องผ่าน Allocator API เมื่อมีการสำรองพื้นที่เก็บข้อมูล
    //
    //
    //
    //
    //

    // ตัวจัดสรรใบ้ที่ใช้เชื้อเพลิงจำนวนคงที่ก่อนที่ความพยายามในการจัดสรรจะเริ่มล้มเหลว
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (ทำให้เกิด realloc ดังนั้นจึงใช้เชื้อเพลิง 50 + 150=200 หน่วย)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // ขั้นแรก `reserve` จะจัดสรรเช่น `reserve_exact`
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 มากกว่าสองเท่าของ 7 ดังนั้น `reserve` ควรทำงานเหมือน `reserve_exact`
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 น้อยกว่าครึ่งหนึ่งของ 12 ดังนั้น `reserve` ต้องเติบโตแบบทวีคูณ
        // ในขณะที่เขียนการทดสอบนี้ grow factor คือ 2 ดังนั้นกำลังการผลิตใหม่คือ 24 อย่างไรก็ตามปัจจัยการเติบโตของ 1.5 ก็โอเคเช่นกัน
        //
        // ดังนั้น `>= 18` ในการยืนยัน
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}