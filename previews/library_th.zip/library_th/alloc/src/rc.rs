//! ตัวชี้การนับอ้างอิงแบบเธรดเดียว 'Rc' ย่อมาจาก 'Reference
//! Counted'.
//!
//! ประเภท [`Rc<T>`][`Rc`] จัดเตรียมความเป็นเจ้าของร่วมของค่าชนิด `T` ซึ่งจัดสรรในฮีป
//! การเรียกใช้ [`clone`][clone] บน [`Rc`] จะสร้างตัวชี้ใหม่ไปยังการจัดสรรเดียวกันในฮีป
//! เมื่อตัวชี้ [`Rc`] สุดท้ายไปยังการจัดสรรที่กำหนดถูกทำลายค่าที่เก็บไว้ในการจัดสรรนั้น (มักเรียกว่า "inner value") จะถูกทิ้งด้วย
//!
//! การอ้างอิงที่ใช้ร่วมกันใน Rust ไม่อนุญาตให้มีการกลายพันธุ์ตามค่าเริ่มต้นและ [`Rc`] ก็ไม่มีข้อยกเว้น: โดยทั่วไปคุณไม่สามารถรับการอ้างอิงที่เปลี่ยนแปลงได้กับบางสิ่งภายใน [`Rc`]
//! หากคุณต้องการความสามารถในการเปลี่ยนแปลงได้ให้ใส่ [`Cell`] หรือ [`RefCell`] ไว้ใน [`Rc`] ดู [an example of mutability inside an `Rc`][mutability]
//!
//! [`Rc`] ใช้การนับอ้างอิงที่ไม่ใช่อะตอม
//! ซึ่งหมายความว่าค่าโสหุ้ยต่ำมาก แต่ [`Rc`] ไม่สามารถส่งระหว่างเธรดได้ดังนั้น [`Rc`] จึงไม่ใช้ [`Send`][send]
//! ด้วยเหตุนี้คอมไพลเลอร์ Rust จะตรวจสอบ *ในเวลาคอมไพล์* ว่าคุณไม่ได้ส่ง [`Rc`] ระหว่างเธรด
//! หากคุณต้องการการนับการอ้างอิงอะตอมแบบมัลติเธรดให้ใช้ [`sync::Arc`][arc]
//!
//! สามารถใช้วิธี [`downgrade`][downgrade] เพื่อสร้างตัวชี้ [`Weak`] ที่ไม่ใช่ของตนเอง
//! ตัวชี้ [`Weak`] สามารถ [`upgrade`][อัพเกรด] d เป็น [`Rc`] ได้ แต่จะส่งคืน [`None`] หากค่าที่เก็บไว้ในการจัดสรรถูกทิ้งไปแล้ว
//! กล่าวอีกนัยหนึ่งพอยน์เตอร์ `Weak` จะไม่รักษามูลค่าภายในการจัดสรรให้คงอยู่อย่างไรก็ตามพวกเขา *ทำ* ให้การจัดสรร (ที่เก็บสำรองสำหรับมูลค่าภายใน) มีชีวิตอยู่
//!
//! วงจรระหว่างตัวชี้ [`Rc`] จะไม่ถูกจัดสรร
//! ด้วยเหตุนี้จึงใช้ [`Weak`] ในการตัดวงจร
//! ตัวอย่างเช่นต้นไม้อาจมีพอยน์เตอร์ [`Rc`] ที่แข็งแกร่งจากโหนดแม่ไปยังลูก ๆ และพอยน์เตอร์ [`Weak`] จากเด็กกลับไปหาพ่อแม่
//!
//! `Rc<T>` ยกเลิกการอ้างอิงถึง `T` โดยอัตโนมัติ (ผ่าน [`Deref`] trait) ดังนั้นคุณจึงสามารถเรียกใช้เมธอดของ "T" โดยใช้ค่าประเภท [`Rc<T>`][`Rc`]
//! เพื่อหลีกเลี่ยงการปะทะกันของชื่อกับเมธอดของ "T" เมธอดของ [`Rc<T>`][`Rc`] นั้นเป็นฟังก์ชันที่เกี่ยวข้องซึ่งเรียกโดยใช้ [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>การใช้งาน traits เช่น `Clone` อาจเรียกได้ว่าใช้ไวยากรณ์ที่มีคุณสมบัติครบถ้วน
//! บางคนชอบใช้ไวยากรณ์ที่มีคุณสมบัติครบถ้วนในขณะที่บางคนชอบใช้ไวยากรณ์วิธีการโทร
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // วิธีการเรียกไวยากรณ์
//! let rc2 = rc.clone();
//! // ไวยากรณ์ที่มีคุณสมบัติครบถ้วน
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] ไม่ dereference อัตโนมัติเป็น `T` เนื่องจากค่าภายในอาจถูกทิ้งไปแล้ว
//!
//! # การอ้างอิงการโคลน
//!
//! การสร้างการอ้างอิงใหม่ไปยังการจัดสรรเดียวกันกับตัวชี้การนับการอ้างอิงที่มีอยู่นั้นทำได้โดยใช้ `Clone` trait ที่ใช้กับ [`Rc<T>`][`Rc`] และ [`Weak<T>`][`Weak`]
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // ไวยากรณ์ทั้งสองด้านล่างนี้เทียบเท่ากัน
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a และ b ชี้ไปที่ตำแหน่งหน่วยความจำเดียวกันกับ foo
//! ```
//!
//! ไวยากรณ์ `Rc::clone(&from)` เป็นสำนวนที่ชัดเจนที่สุดเพราะสื่อถึงความหมายของรหัสได้ชัดเจนกว่า
//! ในตัวอย่างด้านบนไวยากรณ์นี้ช่วยให้เห็นได้ง่ายขึ้นว่าโค้ดนี้กำลังสร้างข้อมูลอ้างอิงใหม่แทนที่จะคัดลอกเนื้อหาทั้งหมดของ foo
//!
//! # Examples
//!
//! พิจารณาสถานการณ์ที่ชุดของ "Gadget" เป็นของ `Owner` ที่ระบุ
//! เราต้องการให้ "Gadget" ชี้ไปที่ `Owner` เราไม่สามารถดำเนินการนี้ได้ด้วยความเป็นเจ้าของที่ไม่ซ้ำใครเนื่องจากแกดเจ็ตมากกว่าหนึ่งรายการอาจเป็นของ `Owner` เดียวกัน
//! [`Rc`] ช่วยให้เราสามารถแบ่งปัน `Owner` ระหว่าง "Gadget" หลาย ๆ ตัวและกำหนดให้ `Owner` ยังคงจัดสรรได้ตราบเท่าที่ `Gadget` มีจุดใด ๆ ก็ตาม
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... สาขาอื่น ๆ
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... สาขาอื่น ๆ
//! }
//!
//! fn main() {
//!     // สร้าง `Owner` ที่นับการอ้างอิง
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // สร้าง "Gadget" ของ `gadget_owner`
//!     // การโคลน `Rc<Owner>` ทำให้เรามีตัวชี้ใหม่ไปยังการจัดสรร `Owner` เดียวกันโดยเพิ่มจำนวนการอ้างอิงในกระบวนการ
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // กำจัด `gadget_owner` ตัวแปรท้องถิ่นของเรา
//!     drop(gadget_owner);
//!
//!     // แม้จะลดลง `gadget_owner` แต่เรายังสามารถพิมพ์ชื่อ `Owner` ของ "Gadget" ได้
//!     // นี่เป็นเพราะเราทิ้ง `Rc<Owner>` เพียงตัวเดียวไม่ใช่ `Owner` ที่ชี้ไป
//!     // ตราบใดที่มี `Rc<Owner>` อื่น ๆ ชี้ไปที่การจัดสรร `Owner` เดียวกันก็จะยังคงใช้งานได้
//!     // การฉายภาพฟิลด์ `gadget1.owner.name` ทำงานได้เนื่องจาก `Rc<Owner>` ยกเลิกการอ้างอิงถึง `Owner` โดยอัตโนมัติ
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // ในตอนท้ายของฟังก์ชั่น `gadget1` และ `gadget2` จะถูกทำลายและด้วยการอ้างอิงที่นับครั้งสุดท้ายถึง `Owner` ของเรา
//!     // ตอนนี้ Gadget Man ก็ถูกทำลายเช่นกัน
//!     //
//! }
//! ```
//!
//! หากข้อกำหนดของเราเปลี่ยนไปและเราต้องสามารถข้ามจาก `Owner` ไปยัง `Gadget` ได้เราจะพบปัญหา
//! ตัวชี้ [`Rc`] จาก `Owner` ถึง `Gadget` แนะนำวงจร
//! ซึ่งหมายความว่าจำนวนอ้างอิงจะไม่มีวันถึง 0 และการจัดสรรจะไม่ถูกทำลาย:
//! หน่วยความจำรั่วในการแก้ไขปัญหานี้เราสามารถใช้พอยน์เตอร์ [`Weak`]
//!
//! Rust ทำให้การสร้างลูปนี้ค่อนข้างยากในตอนแรกเพื่อที่จะลงเอยด้วยค่าสองค่าที่ชี้ถึงกันและกันค่าหนึ่งในนั้นจะต้องมีความผันแปร
//! สิ่งนี้เป็นเรื่องยากเนื่องจาก [`Rc`] บังคับใช้ความปลอดภัยของหน่วยความจำโดยให้เฉพาะการอ้างอิงที่ใช้ร่วมกันกับมูลค่าที่รวมไว้และสิ่งเหล่านี้ไม่อนุญาตให้เกิดการกลายพันธุ์โดยตรง
//! เราจำเป็นต้องรวมส่วนของมูลค่าที่เราต้องการจะกลายพันธุ์ใน [`RefCell`] ซึ่งให้ *ความสามารถในการเปลี่ยนแปลงภายใน*: วิธีการที่จะทำให้เกิดการเปลี่ยนแปลงได้ผ่านการอ้างอิงที่ใช้ร่วมกัน
//! [`RefCell`] บังคับใช้กฎการยืมของ Rust ที่รันไทม์
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... สาขาอื่น ๆ
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... สาขาอื่น ๆ
//! }
//!
//! fn main() {
//!     // สร้าง `Owner` ที่นับการอ้างอิง
//!     // โปรดทราบว่าเราได้ใส่ vector ของ "Gadget" ของเจ้าของไว้ใน `RefCell` เพื่อให้เราสามารถเปลี่ยนผ่านการอ้างอิงที่แชร์ได้
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // สร้าง "Gadget" ของ `gadget_owner` เหมือนเดิม
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // เพิ่ม "Gadget" ใน `Owner`
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` การยืมแบบไดนามิกสิ้นสุดที่นี่
//!     }
//!
//!     // ทำซ้ำบน "Gadget" ของเราโดยพิมพ์รายละเอียดออกมา
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` คือ `Weak<Gadget>`
//!         // เนื่องจากตัวชี้ `Weak` ไม่สามารถรับประกันว่าการจัดสรรยังคงมีอยู่เราจึงต้องเรียกใช้ `upgrade` ซึ่งส่งคืน `Option<Rc<Gadget>>`
//!         //
//!         //
//!         // ในกรณีนี้เรารู้ว่าการจัดสรรยังคงมีอยู่ดังนั้นเราจึงเพียงแค่ `unwrap` กับ `Option`
//!         // ในโปรแกรมที่ซับซ้อนกว่านี้คุณอาจต้องการการจัดการข้อผิดพลาดที่ดีสำหรับผลลัพธ์ `None`
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // ในตอนท้ายของฟังก์ชัน `gadget_owner`, `gadget1` และ `gadget2` จะถูกทำลาย
//!     // ขณะนี้ไม่มีตัวชี้ (`Rc`) ที่แข็งแกร่งสำหรับแกดเจ็ตดังนั้นพวกเขาจึงถูกทำลาย
//!     // สิ่งนี้ทำให้การอ้างอิงของ Gadget Man เป็นศูนย์ดังนั้นเขาจึงถูกทำลายเช่นกัน
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// นี่คือการป้องกัน repr(C) ถึง future จากการจัดลำดับฟิลด์ที่เป็นไปได้ซึ่งจะรบกวน [into|from]_raw() ที่ปลอดภัยของประเภทภายในที่เปลี่ยนได้
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// ตัวชี้การนับการอ้างอิงแบบเธรดเดียว 'Rc' ย่อมาจาก 'Reference
/// Counted'.
///
/// ดู [module-level documentation](./index.html) สำหรับรายละเอียดเพิ่มเติม
///
/// วิธีการโดยธรรมชาติของ `Rc` เป็นฟังก์ชันที่เกี่ยวข้องทั้งหมดซึ่งหมายความว่าคุณต้องเรียกมันว่าเช่น [`Rc::get_mut(&mut value)`][get_mut] แทนที่จะเป็น `value.get_mut()`
/// สิ่งนี้หลีกเลี่ยงความขัดแย้งกับวิธีการของ `T` ประเภทภายใน
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // ความไม่ปลอดภัยนี้ไม่เป็นไรเพราะในขณะที่ Rc นี้ยังมีชีวิตอยู่เรารับประกันได้ว่าตัวชี้ด้านในนั้นถูกต้อง
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// สร้าง `Rc<T>` ใหม่
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // มีตัวชี้ที่อ่อนแอโดยปริยายเป็นของตัวชี้ที่แข็งแกร่งทั้งหมดซึ่งทำให้มั่นใจได้ว่าตัวทำลายที่อ่อนแอจะไม่ปลดปล่อยการจัดสรรในขณะที่ตัวทำลายที่แข็งแกร่งกำลังทำงานอยู่แม้ว่าตัวชี้ที่อ่อนแอจะถูกเก็บไว้ในตัวชี้ที่แข็งแกร่งก็ตาม
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// สร้าง `Rc<T>` ใหม่โดยใช้การอ้างอิงที่อ่อนแอถึงตัวมันเอง
    /// การพยายามอัปเกรดการอ้างอิงที่อ่อนแอก่อนที่ฟังก์ชันนี้จะส่งกลับจะทำให้ได้ค่า `None`
    ///
    /// อย่างไรก็ตามการอ้างอิงที่อ่อนแออาจถูกโคลนได้อย่างอิสระและเก็บไว้เพื่อใช้ในภายหลัง
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... ช่องเพิ่มเติม
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // สร้างด้านในในสถานะ "uninitialized" ด้วยการอ้างอิงที่อ่อนแอเพียงครั้งเดียว
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // สิ่งสำคัญคือเราต้องไม่เลิกเป็นเจ้าของตัวชี้ที่อ่อนแอมิฉะนั้นหน่วยความจำอาจถูกปลดปล่อยเมื่อ `data_fn` กลับมา
        // หากเราต้องการส่งต่อความเป็นเจ้าของจริงๆเราสามารถสร้างตัวชี้ที่อ่อนแอเพิ่มเติมสำหรับตัวเราเองได้ แต่จะส่งผลให้มีการอัปเดตเพิ่มเติมเกี่ยวกับจำนวนอ้างอิงที่อ่อนแอซึ่งอาจไม่จำเป็น
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // การอ้างอิงที่ชัดเจนควรเป็นเจ้าของการอ้างอิงที่ไม่เหมาะสมร่วมกันดังนั้นอย่าเรียกใช้ destructor สำหรับการอ้างอิงที่อ่อนแอแบบเก่าของเรา
        //
        mem::forget(weak);
        strong
    }

    /// สร้าง `Rc` ใหม่ที่มีเนื้อหาที่ไม่ได้กำหนดค่าเริ่มต้น
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // การเริ่มต้นรอการตัดบัญชี:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// สร้าง `Rc` ใหม่ที่มีเนื้อหาที่ไม่ได้กำหนดค่าเริ่มต้นโดยที่หน่วยความจำเต็มไปด้วย `0` ไบต์
    ///
    ///
    /// ดู [`MaybeUninit::zeroed`][zeroed] สำหรับตัวอย่างการใช้วิธีนี้ที่ถูกต้องและไม่ถูกต้อง
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// สร้าง `Rc<T>` ใหม่ส่งคืนข้อผิดพลาดหากการจัดสรรล้มเหลว
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // มีตัวชี้ที่อ่อนแอโดยปริยายเป็นของตัวชี้ที่แข็งแกร่งทั้งหมดซึ่งทำให้มั่นใจได้ว่าตัวทำลายที่อ่อนแอจะไม่ปลดปล่อยการจัดสรรในขณะที่ตัวทำลายที่แข็งแกร่งกำลังทำงานอยู่แม้ว่าตัวชี้ที่อ่อนแอจะถูกเก็บไว้ในตัวชี้ที่แข็งแกร่งก็ตาม
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// สร้าง `Rc` ใหม่ที่มีเนื้อหาที่ไม่ได้กำหนดค่าเริ่มต้นส่งคืนข้อผิดพลาดหากการจัดสรรล้มเหลว
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // การเริ่มต้นรอการตัดบัญชี:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// สร้าง `Rc` ใหม่ที่มีเนื้อหาที่ไม่ได้กำหนดค่าเริ่มต้นโดยที่หน่วยความจำเต็มไปด้วย `0` ไบต์ส่งคืนข้อผิดพลาดหากการจัดสรรล้มเหลว
    ///
    ///
    /// ดู [`MaybeUninit::zeroed`][zeroed] สำหรับตัวอย่างการใช้วิธีนี้ที่ถูกต้องและไม่ถูกต้อง
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// สร้าง `Pin<Rc<T>>` ใหม่
    /// หาก `T` ไม่ใช้ `Unpin` `value` จะถูกตรึงไว้ในหน่วยความจำและไม่สามารถย้ายได้
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// ส่งคืนค่าภายในหาก `Rc` มีการอ้างอิงที่ชัดเจนเพียงรายการเดียว
    ///
    /// มิฉะนั้น [`Err`] จะถูกส่งคืนพร้อมกับ `Rc` เดียวกับที่ส่งผ่าน
    ///
    ///
    /// สิ่งนี้จะประสบความสำเร็จแม้ว่าจะมีการอ้างอิงที่อ่อนแอมากก็ตาม
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // คัดลอกวัตถุที่มีอยู่

                // ระบุให้ Weaks ไม่สามารถเลื่อนระดับได้โดยการลดจำนวนที่แข็งแกร่งจากนั้นจึงลบตัวชี้ "strong weak" โดยปริยายออกในขณะเดียวกันก็จัดการตรรกะการดร็อปด้วยการสร้างจุดอ่อนปลอม
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// สร้างชิ้นส่วนที่นับการอ้างอิงใหม่ด้วยเนื้อหาที่ไม่ได้กำหนดค่าเริ่มต้น
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // การเริ่มต้นรอการตัดบัญชี:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// สร้างชิ้นส่วนที่นับการอ้างอิงใหม่ด้วยเนื้อหาที่ไม่ได้กำหนดค่าเริ่มต้นโดยที่หน่วยความจำเต็มไปด้วย `0` ไบต์
    ///
    ///
    /// ดู [`MaybeUninit::zeroed`][zeroed] สำหรับตัวอย่างการใช้วิธีนี้ที่ถูกต้องและไม่ถูกต้อง
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// แปลงเป็น `Rc<T>`
    ///
    /// # Safety
    ///
    /// เช่นเดียวกับ [`MaybeUninit::assume_init`] ผู้เรียกใช้จะต้องรับประกันว่าค่าภายในอยู่ในสถานะเริ่มต้นจริงๆ
    ///
    /// การเรียกสิ่งนี้เมื่อเนื้อหายังไม่ได้เริ่มต้นอย่างสมบูรณ์จะทำให้เกิดพฤติกรรมที่ไม่ได้กำหนดในทันที
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // การเริ่มต้นรอการตัดบัญชี:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// แปลงเป็น `Rc<[T]>`
    ///
    /// # Safety
    ///
    /// เช่นเดียวกับ [`MaybeUninit::assume_init`] ผู้เรียกใช้จะต้องรับประกันว่าค่าภายในอยู่ในสถานะเริ่มต้นจริงๆ
    ///
    /// การเรียกสิ่งนี้เมื่อเนื้อหายังไม่ได้เริ่มต้นอย่างสมบูรณ์จะทำให้เกิดพฤติกรรมที่ไม่ได้กำหนดในทันที
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // การเริ่มต้นรอการตัดบัญชี:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// ใช้ `Rc` ส่งคืนตัวชี้ที่ถูกห่อ
    ///
    /// เพื่อหลีกเลี่ยงการรั่วไหลของหน่วยความจำตัวชี้จะต้องถูกแปลงกลับเป็น `Rc` โดยใช้ [`Rc::from_raw`][from_raw]
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// แสดงตัวชี้ดิบไปยังข้อมูล
    ///
    /// การนับจะไม่ได้รับผลกระทบ แต่อย่างใดและ `Rc` จะไม่ถูกใช้
    /// ตัวชี้สามารถใช้ได้ตราบเท่าที่มีการนับจำนวนมากใน `Rc`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // ความปลอดภัย: ไม่สามารถผ่าน Deref::deref หรือ Rc::inner ได้เนื่องจาก
        // สิ่งนี้จำเป็นเพื่อรักษาแหล่งที่มาของ raw/mut ไว้เช่นนั้น
        // `get_mut` สามารถเขียนผ่านตัวชี้หลังจากกู้คืน Rc ผ่าน `from_raw`
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// สร้าง `Rc<T>` จากตัวชี้ดิบ
    ///
    /// ตัวชี้ดิบต้องถูกส่งคืนก่อนหน้านี้โดยการเรียกไปที่ [`Rc<U>::into_raw`][into_raw] โดยที่ `U` ต้องมีขนาดและการจัดแนวเดียวกันกับ `T`
    /// นี่เป็นความจริงเล็กน้อยถ้า `U` คือ `T`
    /// โปรดทราบว่าหาก `U` ไม่ใช่ `T` แต่มีขนาดและการจัดตำแหน่งเดียวกันโดยพื้นฐานแล้วจะเหมือนกับการส่งข้อมูลอ้างอิงประเภทต่างๆ
    /// ดู [`mem::transmute`][transmute] สำหรับข้อมูลเพิ่มเติมเกี่ยวกับข้อ จำกัด ที่ใช้ในกรณีนี้
    ///
    /// ผู้ใช้ `from_raw` ต้องแน่ใจว่าค่าเฉพาะของ `T` ลดลงเพียงครั้งเดียว
    ///
    /// ฟังก์ชันนี้ไม่ปลอดภัยเนื่องจากการใช้งานที่ไม่เหมาะสมอาจทำให้หน่วยความจำไม่ปลอดภัยแม้ว่าจะไม่มีการเข้าถึง `Rc<T>` ที่ส่งคืนก็ตาม
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // แปลงกลับเป็น `Rc` เพื่อป้องกันการรั่วไหล
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // การโทรไปยัง `Rc::from_raw(x_ptr)` เพิ่มเติมจะทำให้หน่วยความจำไม่ปลอดภัย
    /// }
    ///
    /// // หน่วยความจำได้รับการปลดปล่อยเมื่อ `x` ออกนอกขอบเขตด้านบนดังนั้น `x_ptr` จึงห้อยอยู่ในขณะนี้!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // ย้อนกลับค่าชดเชยเพื่อค้นหา RcBox ดั้งเดิม
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// สร้างตัวชี้ [`Weak`] ใหม่สำหรับการจัดสรรนี้
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // ตรวจสอบให้แน่ใจว่าเราไม่ได้สร้างจุดอ่อนที่ห้อยลงมา
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// รับจำนวนตัวชี้ [`Weak`] สำหรับการจัดสรรนี้
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// รับจำนวนพอยน์เตอร์ (`Rc`) ที่แข็งแกร่งสำหรับการจัดสรรนี้
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// ส่งคืน `true` หากไม่มีตัวชี้ `Rc` หรือ [`Weak`] อื่นสำหรับการจัดสรรนี้
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// ส่งคืนการอ้างอิงที่เปลี่ยนแปลงได้ใน `Rc` ที่กำหนดหากไม่มีตัวชี้ `Rc` หรือ [`Weak`] อื่นในการจัดสรรเดียวกัน
    ///
    ///
    /// ส่งคืนค่า [`None`] ไม่เช่นนั้นเนื่องจากไม่ปลอดภัยที่จะเปลี่ยนค่าที่ใช้ร่วมกัน
    ///
    /// ดู [`make_mut`][make_mut] ด้วยซึ่งจะ [`clone`][clone] เป็นค่าภายในเมื่อมีพอยน์เตอร์อื่น ๆ
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// ส่งคืนการอ้างอิงที่เปลี่ยนแปลงได้ใน `Rc` ที่ระบุโดยไม่ต้องมีการตรวจสอบใด ๆ
    ///
    /// ดู [`get_mut`] ด้วยซึ่งปลอดภัยและทำการตรวจสอบที่เหมาะสม
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// ตัวชี้ `Rc` หรือ [`Weak`] อื่น ๆ สำหรับการจัดสรรเดียวกันจะต้องไม่ถูกอ้างถึงในช่วงระยะเวลาของการยืมคืน
    ///
    /// นี่เป็นกรณีเล็กน้อยหากไม่มีตัวชี้ดังกล่าวตัวอย่างเช่นทันทีหลังจาก `Rc::new`
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // เราระมัดระวังที่จะ *ไม่* สร้างการอ้างอิงที่ครอบคลุมฟิลด์ "count" เนื่องจากจะขัดแย้งกับการเข้าถึงจำนวนการอ้างอิง (เช่น
        // โดย `Weak`)
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// ส่งคืน `true` หาก "Rc" ทั้งสองชี้ไปที่การจัดสรรเดียวกัน (ในหลอดเลือดดำที่คล้ายกับ [`ptr::eq`])
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// ทำการอ้างอิงที่ไม่แน่นอนใน `Rc` ที่กำหนด
    ///
    /// หากมีตัวชี้ `Rc` อื่นสำหรับการจัดสรรเดียวกันดังนั้น `make_mut` จะ [`clone`] เป็นค่าภายในสำหรับการจัดสรรใหม่เพื่อให้แน่ใจว่าเป็นเจ้าของที่ไม่ซ้ำกัน
    /// สิ่งนี้เรียกอีกอย่างว่าโคลนเมื่อเขียน
    ///
    /// หากไม่มีตัวชี้ `Rc` อื่นสำหรับการจัดสรรนี้พอยน์เตอร์ [`Weak`] สำหรับการจัดสรรนี้จะถูกยกเลิกการเชื่อมโยง
    ///
    /// ดู [`get_mut`] ด้วยซึ่งจะล้มเหลวมากกว่าการโคลนนิ่ง
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // จะไม่โคลนอะไรเลย
    /// let mut other_data = Rc::clone(&data);    // จะไม่โคลนข้อมูลภายใน
    /// *Rc::make_mut(&mut data) += 1;        // โคลนข้อมูลภายใน
    /// *Rc::make_mut(&mut data) += 1;        // จะไม่โคลนอะไรเลย
    /// *Rc::make_mut(&mut other_data) *= 2;  // จะไม่โคลนอะไรเลย
    ///
    /// // ตอนนี้ `data` และ `other_data` ชี้ไปที่การจัดสรรที่แตกต่างกัน
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] พอยน์เตอร์จะถูกยกเลิกการเชื่อมโยง:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // ต้องโคลนข้อมูลมี Rcs อื่น ๆ
            // จัดสรรหน่วยความจำล่วงหน้าเพื่อให้สามารถเขียนค่าที่โคลนได้โดยตรง
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // สามารถขโมยข้อมูลได้ทั้งหมดที่เหลือก็คือจุดอ่อน
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // ลบการอ้างอิงที่แข็งแกร่ง-อ่อนแอโดยนัย (ไม่จำเป็นต้องสร้างจุดอ่อนปลอมที่นี่-เรารู้ว่า Weaks อื่น ๆ สามารถทำความสะอาดให้เราได้)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // ความไม่ปลอดภัยนี้ไม่เป็นไรเพราะเรารับประกันว่าตัวชี้ที่ส่งกลับเป็นตัวชี้ *เท่านั้น* ที่จะถูกส่งกลับไปที่ T
        // จำนวนอ้างอิงของเรารับประกันได้ว่าเป็น 1 ณ จุดนี้และเรากำหนดให้ `Rc<T>` เป็น `mut` ดังนั้นเราจึงส่งคืนการอ้างอิงที่เป็นไปได้เพียงรายการเดียวในการจัดสรร
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// พยายามดาวน์แคสต์ `Rc<dyn Any>` เป็นคอนกรีต
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// จัดสรร `RcBox<T>` ที่มีพื้นที่เพียงพอสำหรับค่าภายในที่อาจไม่ได้ปรับขนาดโดยที่ค่ามีเค้าโครงที่จัดเตรียมไว้
    ///
    /// ฟังก์ชัน `mem_to_rcbox` ถูกเรียกด้วยตัวชี้ข้อมูลและต้องส่งกลับตัวชี้ (อาจอ้วน) กลับมาสำหรับ `RcBox<T>`
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // คำนวณเค้าโครงโดยใช้เค้าโครงค่าที่กำหนด
        // ก่อนหน้านี้เค้าโครงถูกคำนวณบนนิพจน์ `&*(ptr as* const RcBox<T>)` แต่สิ่งนี้สร้างการอ้างอิงที่ไม่ตรงแนว (ดู #54908)
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// จัดสรร `RcBox<T>` ที่มีพื้นที่เพียงพอสำหรับค่าภายในที่อาจไม่ได้ปรับขนาดโดยที่ค่ามีเค้าโครงที่จัดเตรียมไว้ส่งคืนข้อผิดพลาดหากการจัดสรรล้มเหลว
    ///
    ///
    /// ฟังก์ชัน `mem_to_rcbox` ถูกเรียกด้วยตัวชี้ข้อมูลและต้องส่งกลับตัวชี้ (อาจอ้วน) กลับมาสำหรับ `RcBox<T>`
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // คำนวณเค้าโครงโดยใช้เค้าโครงค่าที่กำหนด
        // ก่อนหน้านี้เค้าโครงถูกคำนวณบนนิพจน์ `&*(ptr as* const RcBox<T>)` แต่สิ่งนี้สร้างการอ้างอิงที่ไม่ตรงแนว (ดู #54908)
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // จัดสรรสำหรับเค้าโครง
        let ptr = allocate(layout)?;

        // เริ่มต้น RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// จัดสรร `RcBox<T>` ที่มีพื้นที่เพียงพอสำหรับค่าภายในที่ไม่ได้กำหนดขนาด
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // จัดสรรสำหรับ `RcBox<T>` โดยใช้ค่าที่กำหนด
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // คัดลอกค่าเป็นไบต์
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // ปลดปล่อยการจัดสรรโดยไม่ทิ้งเนื้อหา
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// จัดสรร `RcBox<[T]>` ตามความยาวที่กำหนด
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// คัดลอกองค์ประกอบจากชิ้นส่วนไปยัง Rc ที่จัดสรรใหม่ <\[T\]>
    ///
    /// ไม่ปลอดภัยเนื่องจากผู้โทรต้องเป็นเจ้าของหรือผูก `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// สร้าง `Rc<[T]>` จากตัววนซ้ำที่ทราบว่ามีขนาดที่แน่นอน
    ///
    /// พฤติกรรมไม่ได้กำหนดหากขนาดไม่ถูกต้อง
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic ป้องกันขณะโคลนองค์ประกอบ T
        // ในกรณีของ panic องค์ประกอบที่ถูกเขียนลงใน RcBox ใหม่จะถูกทิ้งจากนั้นหน่วยความจำจะถูกปลดปล่อย
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // ชี้ไปที่องค์ประกอบแรก
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // ทุกอย่างชัดเจนลืมยามเพื่อไม่ให้ RcBox ใหม่เป็นอิสระ
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// ความเชี่ยวชาญ trait ใช้สำหรับ `From<&[T]>`
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// วาง `Rc`
    ///
    /// สิ่งนี้จะลดจำนวนการอ้างอิงที่คาดเดายาก
    /// หากจำนวนอ้างอิงที่แข็งแกร่งถึงศูนย์การอ้างอิงอื่น ๆ (ถ้ามี) เท่านั้นคือ [`Weak`] ดังนั้นเราจึง `drop` เป็นค่าภายใน
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // ไม่พิมพ์อะไรเลย
    /// drop(foo2);   // พิมพ์ "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // ทำลายวัตถุที่บรรจุอยู่
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // ลบตัวชี้ "strong weak" โดยนัยตอนนี้เราได้ทำลายเนื้อหาแล้ว
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// สร้างโคลนของตัวชี้ `Rc`
    ///
    /// สิ่งนี้จะสร้างตัวชี้อื่นไปยังการจัดสรรเดียวกันโดยเพิ่มจำนวนการอ้างอิงที่คาดเดายาก
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// สร้าง `Rc<T>` ใหม่โดยมีค่า `Default` สำหรับ `T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// แฮ็คเพื่อให้เชี่ยวชาญ `Eq` แม้ว่า `Eq` จะมีวิธีการก็ตาม
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// เรากำลังทำความเชี่ยวชาญนี้อยู่ที่นี่ไม่ใช่เป็นการเพิ่มประสิทธิภาพทั่วไปบน `&T` เพราะจะเป็นการเพิ่มต้นทุนให้กับการตรวจสอบความเท่าเทียมกันทั้งหมดในการอ้างอิง
/// เราถือว่าใช้ "Rc" เพื่อจัดเก็บค่าขนาดใหญ่ซึ่งช้าในการลอกแบบ แต่ยังตรวจสอบความเท่าเทียมกันอย่างหนักทำให้ต้นทุนนี้จ่ายออกไปได้ง่ายขึ้น
///
/// นอกจากนี้ยังมีแนวโน้มที่จะมีโคลน `Rc` สองตัวซึ่งชี้ไปที่ค่าเดียวกันมากกว่าสอง "&T"
///
/// เราสามารถทำได้ก็ต่อเมื่อ `T: Eq` เป็น `PartialEq` อาจไม่สะท้อนแสงโดยเจตนา
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// ความเท่าเทียมกันสำหรับสอง "Rc"
    ///
    /// "Rc" สองค่าเท่ากันหากค่าภายในเท่ากันแม้ว่าจะเก็บไว้ในการจัดสรรที่ต่างกันก็ตาม
    ///
    /// หาก `T` ใช้ `Eq` ด้วย (หมายถึงการสะท้อนกลับของความเท่าเทียมกัน) "Rc" สองตัวที่ชี้ไปยังการจัดสรรเดียวกันจะเท่ากันเสมอ
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// อสมการสำหรับสอง "Rc"
    ///
    /// "Rc" สองค่าไม่เท่ากันหากค่าภายในไม่เท่ากัน
    ///
    /// หาก `T` ใช้ `Eq` ด้วย (หมายถึงการสะท้อนกลับของความเท่าเทียมกัน) "Rc" สองตัวที่ชี้ไปยังการจัดสรรเดียวกันจะไม่ไม่เท่ากัน
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// การเปรียบเทียบบางส่วนสำหรับสอง "Rc"
    ///
    /// ทั้งสองถูกเปรียบเทียบโดยเรียก `partial_cmp()` ตามค่าภายในของพวกเขา
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// น้อยกว่าการเปรียบเทียบสำหรับสอง "Rc"
    ///
    /// ทั้งสองถูกเปรียบเทียบโดยเรียก `<` ตามค่าภายในของพวกเขา
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// การเปรียบเทียบ 'น้อยกว่าหรือเท่ากับ' สำหรับสอง "Rc`
    ///
    /// ทั้งสองถูกเปรียบเทียบโดยเรียก `<=` ตามค่าภายในของพวกเขา
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// มากกว่าการเปรียบเทียบสำหรับสอง "Rc"
    ///
    /// ทั้งสองถูกเปรียบเทียบโดยเรียก `>` ตามค่าภายในของพวกเขา
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// การเปรียบเทียบ "มากกว่าหรือเท่ากับ" สำหรับสอง "Rc"
    ///
    /// ทั้งสองถูกเปรียบเทียบโดยเรียก `>=` ตามค่าภายในของพวกเขา
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// การเปรียบเทียบสำหรับสอง "Rc"
    ///
    /// ทั้งสองถูกเปรียบเทียบโดยเรียก `cmp()` ตามค่าภายในของพวกเขา
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// จัดสรรชิ้นส่วนที่นับการอ้างอิงและเติมโดยการโคลนรายการของ "v"
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// จัดสรรสไลซ์สตริงที่นับการอ้างอิงและคัดลอก `v` ลงในนั้น
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// จัดสรรสไลซ์สตริงที่นับการอ้างอิงและคัดลอก `v` ลงในนั้น
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// ย้ายวัตถุชนิดบรรจุกล่องไปยังการนับการอ้างอิงการจัดสรรใหม่
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// จัดสรรชิ้นส่วนที่นับการอ้างอิงและย้ายรายการ "v" ไปไว้ในนั้น
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // อนุญาตให้ Vec เพิ่มหน่วยความจำ แต่ไม่ทำลายเนื้อหา
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// ใช้แต่ละองค์ประกอบใน `Iterator` และรวบรวมเป็น `Rc<[T]>`
    ///
    /// # ลักษณะการทำงาน
    ///
    /// ## กรณีทั่วไป
    ///
    /// ในกรณีทั่วไปการรวบรวมเข้า `Rc<[T]>` ทำได้โดยการรวบรวมเป็น `Vec<T>` ก่อนนั่นคือเมื่อเขียนสิ่งต่อไปนี้:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// สิ่งนี้ทำงานราวกับว่าเราเขียน:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // การจัดสรรชุดแรกเกิดขึ้นที่นี่
    ///     .into(); // การจัดสรรครั้งที่สองสำหรับ `Rc<[T]>` เกิดขึ้นที่นี่
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// สิ่งนี้จะจัดสรรหลาย ๆ ครั้งตามที่จำเป็นสำหรับการสร้าง `Vec<T>` จากนั้นจะจัดสรรหนึ่งครั้งสำหรับการเปลี่ยน `Vec<T>` เป็น `Rc<[T]>`
    ///
    ///
    /// ## ตัววนซ้ำของความยาวที่ทราบ
    ///
    /// เมื่อ `Iterator` ของคุณใช้ `TrustedLen` และมีขนาดที่แน่นอนจะมีการจัดสรรครั้งเดียวสำหรับ `Rc<[T]>` ตัวอย่างเช่น:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // การจัดสรรเพียงรายการเดียวเกิดขึ้นที่นี่
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Specialization trait ใช้สำหรับรวบรวมเป็น `Rc<[T]>`
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // นี่เป็นกรณีของตัววนซ้ำ `TrustedLen`
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // ความปลอดภัย: เราจำเป็นต้องตรวจสอบให้แน่ใจว่าตัววนซ้ำมีความยาวที่แน่นอนและเรามี
                Rc::from_iter_exact(self, low)
            }
        } else {
            // ถอยกลับสู่การใช้งานปกติ
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` เป็นเวอร์ชันของ [`Rc`] ที่มีการอ้างอิงที่ไม่ได้เป็นเจ้าของไปยังการจัดสรรที่มีการจัดการการจัดสรรเข้าถึงได้โดยการเรียก [`upgrade`] บนตัวชี้ `Weak` ซึ่งจะส่งกลับ [`Option`]`<`[`Rc`] `<T>>".
///
/// เนื่องจากการอ้างอิง `Weak` ไม่นับรวมในการเป็นเจ้าของจึงจะไม่ป้องกันไม่ให้ค่าที่จัดเก็บในการจัดสรรหลุดออกไปและ `Weak` เองก็ไม่รับประกันว่ามูลค่าจะยังคงอยู่
/// ดังนั้นจึงอาจคืนค่า [`None`] เมื่อ [`upgrade`] d.
/// อย่างไรก็ตามโปรดทราบว่าการอ้างอิง `Weak`*จะ* ป้องกันไม่ให้มีการยกเลิกการจัดสรรตัวเอง (ที่เก็บสำรอง)
///
/// ตัวชี้ `Weak` มีประโยชน์ในการเก็บข้อมูลอ้างอิงชั่วคราวไปยังการจัดสรรที่จัดการโดย [`Rc`] โดยไม่ป้องกันไม่ให้ค่าภายในหลุดออกไป
/// นอกจากนี้ยังใช้เพื่อป้องกันการอ้างอิงแบบวงกลมระหว่างตัวชี้ [`Rc`] เนื่องจากการอ้างอิงที่เป็นเจ้าของร่วมกันจะไม่อนุญาตให้ [`Rc`] หลุด
/// ตัวอย่างเช่นต้นไม้อาจมีพอยน์เตอร์ [`Rc`] ที่แข็งแกร่งจากโหนดแม่ไปยังลูก ๆ และพอยน์เตอร์ `Weak` จากเด็กกลับไปหาพ่อแม่
///
/// วิธีทั่วไปในการรับตัวชี้ `Weak` คือการเรียก [`Rc::downgrade`]
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // นี่คือ `NonNull` ที่อนุญาตให้ปรับขนาดของประเภทนี้ใน enums ให้เหมาะสม แต่ไม่จำเป็นต้องเป็นตัวชี้ที่ถูกต้อง
    //
    // `Weak::new` ตั้งค่านี้เป็น `usize::MAX` เพื่อที่จะไม่ต้องจัดสรรพื้นที่บนฮีป
    // นั่นไม่ใช่ค่าที่ตัวชี้จริงจะเคยมีเพราะ RcBox มีการจัดตำแหน่งอย่างน้อย 2
    // เป็นไปได้เฉพาะเมื่อ `T: Sized`;`T` ที่ไม่มีขนาดไม่เคยห้อย
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// สร้าง `Weak<T>` ใหม่โดยไม่ต้องจัดสรรหน่วยความจำใด ๆ
    /// การเรียกใช้ [`upgrade`] ในค่าส่งคืนจะให้ [`None`] เสมอ
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// ประเภทตัวช่วยเพื่ออนุญาตให้เข้าถึงจำนวนการอ้างอิงโดยไม่ต้องยืนยันใด ๆ เกี่ยวกับฟิลด์ข้อมูล
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// ส่งกลับตัวชี้ดิบไปยังวัตถุที่ `T` ชี้โดย `Weak<T>` นี้
    ///
    /// ตัวชี้จะใช้ได้ก็ต่อเมื่อมีการอ้างอิงที่ชัดเจน
    /// ตัวชี้อาจห้อยไม่ตรงแนวหรือแม้แต่ [`null`] เป็นอย่างอื่น
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // ทั้งสองชี้ไปที่วัตถุเดียวกัน
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // สิ่งที่แข็งแกร่งที่นี่ทำให้มันมีชีวิตอยู่ดังนั้นเราจึงยังสามารถเข้าถึงวัตถุได้
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // แต่ไม่ได้อีกต่อไป
    /// // เราสามารถทำ weak.as_ptr() ได้ แต่การเข้าถึงตัวชี้จะนำไปสู่พฤติกรรมที่ไม่ได้กำหนด
    /// // assert_eq! ("สวัสดี" ไม่ปลอดภัย {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // หากตัวชี้ห้อยอยู่เราจะส่งคืนทหารรักษาการณ์โดยตรง
            // นี่ไม่สามารถเป็นที่อยู่เพย์โหลดที่ถูกต้องได้เนื่องจากน้ำหนักบรรทุกอย่างน้อยก็อยู่ในแนวเดียวกับ RcBox (usize)
            ptr as *const T
        } else {
            // ความปลอดภัย: ถ้า is_dangling ส่งกลับเท็จแสดงว่าตัวชี้นั้นไม่สามารถถอดรหัสได้
            // น้ำหนักบรรทุกอาจลดลง ณ จุดนี้และเราต้องรักษาแหล่งที่มาดังนั้นให้ใช้การจัดการตัวชี้แบบดิบ
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// ใช้ `Weak<T>` และเปลี่ยนเป็นตัวชี้ดิบ
    ///
    /// สิ่งนี้จะแปลงตัวชี้ที่อ่อนแอให้เป็นตัวชี้ดิบในขณะที่ยังคงรักษาความเป็นเจ้าของของการอ้างอิงที่อ่อนแอไว้หนึ่งรายการ (การดำเนินการนี้จะไม่แก้ไขจำนวนที่อ่อนแอ)
    /// สามารถเปลี่ยนกลับเป็น `Weak<T>` ด้วย [`from_raw`]
    ///
    /// มีข้อ จำกัด เดียวกันในการเข้าถึงเป้าหมายของตัวชี้เช่นเดียวกับ [`as_ptr`]
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// แปลงตัวชี้ดิบที่ [`into_raw`] สร้างไว้ก่อนหน้านี้กลับเป็น `Weak<T>`
    ///
    /// สิ่งนี้สามารถใช้เพื่อรับข้อมูลอ้างอิงที่ชัดเจนได้อย่างปลอดภัย (โดยเรียก [`upgrade`] ในภายหลัง) หรือเพื่อยกเลิกการจัดสรรจำนวนที่อ่อนแอโดยการทิ้ง `Weak<T>`
    ///
    /// เป็นเจ้าของการอ้างอิงที่อ่อนแอหนึ่งรายการ (ยกเว้นพอยน์เตอร์ที่สร้างโดย [`new`] เนื่องจากสิ่งเหล่านี้ไม่ได้เป็นเจ้าของอะไรเลยวิธีนี้ยังคงใช้งานได้)
    ///
    /// # Safety
    ///
    /// ตัวชี้ต้องมาจาก [`into_raw`] และยังต้องเป็นเจ้าของการอ้างอิงที่อ่อนแอที่เป็นไปได้
    ///
    /// อนุญาตให้การนับที่แข็งแกร่งเป็น 0 ในเวลาที่เรียกสิ่งนี้
    /// อย่างไรก็ตามสิ่งนี้ใช้ความเป็นเจ้าของการอ้างอิงที่อ่อนแอหนึ่งรายการในปัจจุบันที่แสดงเป็นตัวชี้ดิบ (จำนวนที่อ่อนแอไม่ได้ถูกแก้ไขโดยการดำเนินการนี้) ดังนั้นจึงต้องจับคู่กับการเรียกก่อนหน้าไปยัง [`into_raw`]
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // ลดจำนวนครั้งสุดท้ายที่อ่อนแอ
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // ดู Weak::as_ptr สำหรับบริบทเกี่ยวกับวิธีการรับตัวชี้อินพุต

        let ptr = if is_dangling(ptr as *mut T) {
            // นี่คือจุดอ่อนที่ห้อยลงมา
            ptr as *mut RcBox<T>
        } else {
            // มิฉะนั้นเรารับประกันได้ว่าตัวชี้มาจากจุดอ่อนที่ไม่เป็นอันตราย
            // ความปลอดภัย: data_offset ปลอดภัยในการโทรเนื่องจาก ptr อ้างถึงของจริง (อาจตกหล่น) T.
            let offset = unsafe { data_offset(ptr) };
            // ดังนั้นเราจึงย้อนกลับค่าชดเชยเพื่อรับ RcBox ทั้งหมด
            // ความปลอดภัย: ตัวชี้มาจากจุดอ่อนดังนั้นการชดเชยนี้จึงปลอดภัย
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // ความปลอดภัย: ตอนนี้เราได้กู้คืนตัวชี้จุดอ่อนดั้งเดิมแล้วดังนั้นสามารถสร้างจุดอ่อนได้
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// พยายามอัพเกรดตัวชี้ `Weak` เป็น [`Rc`] ซึ่งจะชะลอการปล่อยค่าภายในหากสำเร็จ
    ///
    ///
    /// ส่งคืน [`None`] หากค่าภายในถูกทิ้ง
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // ทำลายตัวชี้ที่แข็งแกร่งทั้งหมด
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// รับจำนวนพอยน์เตอร์ (`Rc`) ที่แข็งแกร่งที่ชี้ไปที่การจัดสรรนี้
    ///
    /// ถ้า `self` ถูกสร้างขึ้นโดยใช้ [`Weak::new`] สิ่งนี้จะส่งกลับ 0
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// รับจำนวนตัวชี้ `Weak` ที่ชี้ไปที่การจัดสรรนี้
    ///
    /// หากไม่มีตัวชี้ที่ชัดเจนสิ่งนี้จะส่งกลับศูนย์
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // ลบ ptr ที่อ่อนแอโดยปริยาย
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// ส่งคืน `None` เมื่อตัวชี้ห้อยและไม่มีการจัดสรร `RcBox` (กล่าวคือเมื่อ `Weak` นี้สร้างโดย `Weak::new`)
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // เราระมัดระวังที่จะ *ไม่* สร้างการอ้างอิงที่ครอบคลุมฟิลด์ "data" เนื่องจากฟิลด์อาจถูกกลายพันธุ์ไปพร้อม ๆ กัน (ตัวอย่างเช่นหาก `Rc` สุดท้ายหลุดออกไปฟิลด์ข้อมูลจะถูกทิ้งในตำแหน่ง)
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// ส่งคืนค่า `true` หากทั้งสอง "อ่อนแอ" ชี้ไปที่การจัดสรรเดียวกัน (คล้ายกับ [`ptr::eq`]) หรือหากทั้งสองไม่ชี้ไปที่การจัดสรรใด ๆ (เพราะสร้างด้วย `Weak::new()`)
    ///
    ///
    /// # Notes
    ///
    /// เนื่องจากสิ่งนี้เปรียบเทียบตัวชี้หมายความว่า `Weak::new()` จะเท่ากันแม้ว่าจะไม่ชี้ไปที่การจัดสรรใด ๆ ก็ตาม
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// เปรียบเทียบ `Weak::new`
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// วางตัวชี้ `Weak`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // ไม่พิมพ์อะไรเลย
    /// drop(foo);        // พิมพ์ "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // จำนวนที่อ่อนแอเริ่มต้นที่ 1 และจะไปที่ศูนย์ก็ต่อเมื่อพอยน์เตอร์ที่แข็งแกร่งทั้งหมดหายไป
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// สร้างโคลนของตัวชี้ `Weak` ที่ชี้ไปที่การจัดสรรเดียวกัน
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// สร้าง `Weak<T>` ใหม่โดยจัดสรรหน่วยความจำสำหรับ `T` โดยไม่ต้องเริ่มต้น
    /// การเรียกใช้ [`upgrade`] ในค่าส่งคืนจะให้ [`None`] เสมอ
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: เรา checked_add ที่นี่เพื่อจัดการกับ mem::forget อย่างปลอดภัยโดยเฉพาะอย่างยิ่ง
// หากคุณ mem::forget Rcs (หรือ Weaks) การนับการอ้างอิงอาจล้นจากนั้นคุณสามารถปลดปล่อยการจัดสรรได้ในขณะที่ Rcs (หรือ Weaks) ที่โดดเด่นมีอยู่
//
// เรายกเลิกเพราะนี่เป็นสถานการณ์ที่เลวร้ายซึ่งเราไม่สนใจว่าจะเกิดอะไรขึ้น-ไม่ควรมีโปรแกรมจริงใด ๆ เกิดขึ้น
//
// สิ่งนี้ควรมีค่าใช้จ่ายเล็กน้อยเนื่องจากคุณไม่จำเป็นต้องโคลนสิ่งเหล่านี้มากนักใน Rust ด้วยความเป็นเจ้าของและความหมายการเคลื่อนย้าย
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // เราต้องการยกเลิกเมื่อ overflow แทนที่จะทิ้งค่า
        // จำนวนอ้างอิงจะไม่เป็นศูนย์เมื่อมีการเรียกสิ่งนี้
        // อย่างไรก็ตามเราใส่การยกเลิกที่นี่เพื่อบอกใบ้ LLVM เกี่ยวกับการเพิ่มประสิทธิภาพที่ไม่ได้รับ
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // เราต้องการยกเลิกเมื่อ overflow แทนที่จะทิ้งค่า
        // จำนวนอ้างอิงจะไม่เป็นศูนย์เมื่อมีการเรียกสิ่งนี้
        // อย่างไรก็ตามเราใส่การยกเลิกที่นี่เพื่อบอกใบ้ LLVM เกี่ยวกับการเพิ่มประสิทธิภาพที่ไม่ได้รับ
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// รับค่าชดเชยภายใน `RcBox` สำหรับเพย์โหลดหลังตัวชี้
///
/// # Safety
///
/// ตัวชี้ต้องชี้ไปที่ (และมีข้อมูลเมตาที่ถูกต้องสำหรับ) อินสแตนซ์ของ T ที่ถูกต้องก่อนหน้านี้ แต่ T ได้รับอนุญาตให้ทิ้ง
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // จัดแนวค่าที่ไม่ได้กำหนดไว้ที่ส่วนท้ายของ RcBox
    // เนื่องจาก RcBox คือ repr(C) จึงเป็นฟิลด์สุดท้ายในหน่วยความจำเสมอ
    // ความปลอดภัย: เนื่องจากชนิดที่ไม่ได้ขนาดเท่านั้นที่เป็นไปได้คือชิ้นส่วนวัตถุ trait
    // และประเภทภายนอกปัจจุบันข้อกำหนดด้านความปลอดภัยของอินพุตเพียงพอที่จะตอบสนองความต้องการของ align_of_val_raw;นี่คือรายละเอียดการใช้งานของภาษาที่อาจไม่ได้รับการพึ่งพานอก std
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}