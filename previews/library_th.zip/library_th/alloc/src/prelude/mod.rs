//! จัดสรร Prelude
//!
//! จุดประสงค์ของโมดูลนี้คือเพื่อลดการนำเข้ารายการที่ใช้กันทั่วไปของ `alloc` crate โดยการเพิ่มการนำเข้าลูกโลกที่ด้านบนของโมดูล:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;