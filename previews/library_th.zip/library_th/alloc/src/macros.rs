/// สร้าง [`Vec`] ที่มีอาร์กิวเมนต์
///
/// `vec!` อนุญาตให้กำหนด "Vec" ด้วยไวยากรณ์เดียวกับนิพจน์อาร์เรย์
/// มาโครนี้มีสองรูปแบบ:
///
/// - สร้าง [`Vec`] ที่มีรายการองค์ประกอบที่กำหนด:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - สร้าง [`Vec`] จากองค์ประกอบและขนาดที่กำหนด:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// โปรดทราบว่าแตกต่างจากนิพจน์อาร์เรย์ไวยากรณ์นี้สนับสนุนองค์ประกอบทั้งหมดที่ใช้ [`Clone`] และจำนวนองค์ประกอบไม่จำเป็นต้องเป็นค่าคงที่
///
/// สิ่งนี้จะใช้ `clone` เพื่อทำสำเนานิพจน์ดังนั้นจึงควรระมัดระวังในการใช้สิ่งนี้กับประเภทที่มีการใช้งาน `Clone` ที่ไม่เป็นมาตรฐาน
/// ตัวอย่างเช่น `vec![Rc::new(1);5] `จะสร้าง vector จากการอ้างอิงห้ารายการสำหรับค่าจำนวนเต็มกล่องเดียวกันไม่ใช่การอ้างอิงห้ารายการที่ชี้ไปยังจำนวนเต็มแบบบรรจุกล่องที่แยกจากกัน
///
///
/// นอกจากนี้โปรดทราบว่า `vec![expr; 0]` ได้รับอนุญาตและสร้าง vector ที่ว่างเปล่า
/// อย่างไรก็ตามสิ่งนี้จะยังคงประเมิน `expr` และลดค่าผลลัพธ์ลงทันทีดังนั้นโปรดระวังผลข้างเคียง
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): ด้วย cfg(test) เมธอด `[T]::into_vec` โดยธรรมชาติซึ่งจำเป็นสำหรับนิยามมาโครนี้จะไม่พร้อมใช้งาน
// ใช้ฟังก์ชัน `slice::into_vec` แทนซึ่งใช้ได้เฉพาะกับ cfg(test) NB โปรดดูโมดูล slice::hack ใน slice.rs สำหรับข้อมูลเพิ่มเติม
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// สร้าง `String` โดยใช้การแก้ไขนิพจน์รันไทม์
///
/// อาร์กิวเมนต์แรกที่ `format!` ได้รับคือสตริงรูปแบบต้องเป็นสตริงลิเทอรัลพลังของสตริงการจัดรูปแบบอยู่ใน "{}" ที่มีอยู่
///
/// พารามิเตอร์เพิ่มเติมที่ส่งไปยัง `format!` แทนที่ "{}" ภายในสตริงการจัดรูปแบบตามลำดับที่กำหนดเว้นแต่จะใช้พารามิเตอร์ที่มีชื่อหรือตำแหน่งดู [`std::fmt`] สำหรับข้อมูลเพิ่มเติม
///
///
/// การใช้งานทั่วไปสำหรับ `format!` คือการต่อและการแก้ไขสตริง
/// รูปแบบเดียวกันนี้ใช้กับมาโคร [`print!`] และ [`write!`] ขึ้นอยู่กับปลายทางที่ต้องการของสตริง
///
/// ในการแปลงค่าเดียวเป็นสตริงให้ใช้วิธี [`to_string`] สิ่งนี้จะใช้การจัดรูปแบบ [`Display`] trait
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics หากการจัดรูปแบบการใช้งาน trait ส่งกลับข้อผิดพลาด
/// สิ่งนี้บ่งชี้ถึงการนำไปใช้งานที่ไม่ถูกต้องเนื่องจาก `fmt::Write for String` ไม่เคยส่งกลับข้อผิดพลาดเอง
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// บังคับให้ AST node กับนิพจน์เพื่อปรับปรุงการวินิจฉัยในตำแหน่งรูปแบบ
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}