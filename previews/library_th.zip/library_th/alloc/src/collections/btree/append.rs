use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// ต่อท้ายคู่คีย์-ค่าทั้งหมดจากการรวมกันของตัววนซ้ำจากน้อยไปหามากสองตัวโดยเพิ่มตัวแปร `length` ไปพร้อมกันข้อหลังนี้ช่วยให้ผู้โทรสามารถหลีกเลี่ยงการรั่วไหลได้ง่ายขึ้นเมื่อตัวจัดการหล่นเลื่อน
    ///
    /// หากตัววนซ้ำทั้งสองสร้างคีย์เดียวกันวิธีนี้จะลดคู่จากตัววนซ้ำด้านซ้ายและต่อท้ายคู่จากตัววนซ้ำด้านขวา
    ///
    /// หากคุณต้องการให้ต้นไม้เรียงลำดับจากน้อยไปหามากเช่น `BTreeMap` ผู้วนซ้ำทั้งสองควรสร้างคีย์ตามลำดับจากน้อยไปหามากอย่างเคร่งครัดแต่ละคีย์จะมีค่ามากกว่าคีย์ทั้งหมดในแผนภูมิรวมถึงคีย์ใด ๆ ที่อยู่ในแผนภูมิเมื่อเข้า
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // เราเตรียมที่จะรวม `left` และ `right` เข้าในลำดับที่เรียงลำดับตามเวลาเชิงเส้น
        let iter = MergeIter(MergeIterInner::new(left, right));

        // ในขณะเดียวกันเราสร้างต้นไม้จากลำดับที่เรียงตามเวลาเชิงเส้น
        self.bulk_push(iter, length)
    }

    /// พุชคู่คีย์-ค่าทั้งหมดไปที่ส่วนท้ายของแผนภูมิโดยเพิ่มตัวแปร `length` ไปพร้อมกัน
    /// อย่างหลังนี้ช่วยให้ผู้โทรสามารถหลีกเลี่ยงการรั่วไหลได้ง่ายขึ้นเมื่อตัววนซ้ำส่ายไปมา
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // วนซ้ำผ่านคู่คีย์-ค่าทั้งหมดผลักดันให้เป็นโหนดในระดับที่เหมาะสม
        for (key, value) in iter {
            // พยายามดันคู่คีย์-ค่าลงในโหนดลีฟปัจจุบัน
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // ไม่เหลือที่ว่างให้ขึ้นไปดันตรงนั้น
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // พบโหนดที่มีพื้นที่เหลือให้กดที่นี่
                                open_node = parent;
                                break;
                            } else {
                                // ขึ้นไปอีก.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // เราอยู่ที่ด้านบนสุดสร้างโหนดรูทใหม่และผลักดันไปที่นั่น
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // กดคู่คีย์-ค่าและแผนผังย่อยด้านขวาใหม่
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // ลงไปทางขวาสุดอีกครั้ง
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // เพิ่มความยาวทุกๆการวนซ้ำเพื่อให้แน่ใจว่าแผนที่จะลดองค์ประกอบที่ต่อท้ายแม้ว่าจะเลื่อนตัววนซ้ำไปมา
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// ตัววนซ้ำสำหรับการรวมลำดับที่เรียงลำดับสองลำดับเข้าด้วยกัน
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// หากสองคีย์เท่ากันให้ส่งคืนคู่คีย์-ค่าจากแหล่งที่มาที่ถูกต้อง
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}