use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// พิมพ์เขียวสำหรับอินสแตนซ์จำลองการทดสอบข้อขัดข้องที่ตรวจสอบเหตุการณ์เฉพาะ
/// บางอินสแตนซ์อาจกำหนดค่าเป็น panic ในบางจุด
/// เหตุการณ์คือ `clone`, `drop` หรือ `query` ที่ไม่ระบุชื่อ
///
/// หุ่นทดสอบการชนถูกระบุและเรียงลำดับโดย id ดังนั้นจึงสามารถใช้เป็นคีย์ใน BTreeMap ได้
/// การนำไปใช้โดยเจตนาไม่ได้ขึ้นอยู่กับสิ่งที่กำหนดไว้ใน crate นอกเหนือจาก `Debug` trait
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// สร้างแบบจำลองการทดสอบการชน `id` กำหนดลำดับและความเท่าเทียมกันของอินสแตนซ์
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// สร้างตัวอย่างของหุ่นทดสอบการชนที่บันทึกเหตุการณ์ที่เกิดขึ้นและ panics เป็นทางเลือก
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// ส่งคืนจำนวนครั้งที่จำลองหุ่นจำลองถูกโคลน
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// ส่งคืนจำนวนครั้งที่ดร็อปหุ่นจำลอง
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// ส่งคืนจำนวนครั้งที่อินสแตนซ์ของดัมมี่มีการเรียกใช้สมาชิก `query`
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// แบบสอบถามที่ไม่ระบุชื่อซึ่งเป็นผลลัพธ์ที่ได้รับแล้ว
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}