// นี่เป็นความพยายามในการดำเนินการตามอุดมคติ
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// เนื่องจาก Rust ไม่มีประเภทที่ขึ้นต่อกันและการเรียกซ้ำหลายรูปแบบเราจึงทำด้วยความไม่ปลอดภัยมากมาย
//

// เป้าหมายหลักของโมดูลนี้คือการหลีกเลี่ยงความซับซ้อนโดยถือว่าต้นไม้เป็นภาชนะทั่วไป (ถ้ามีรูปร่างแปลก ๆ) และหลีกเลี่ยงการจัดการกับค่าคงที่ของ B-Tree ส่วนใหญ่
//
// ด้วยเหตุนี้โมดูลนี้จึงไม่สนใจว่ารายการจะถูกจัดเรียงหรือไม่โหนดใดอาจมีค่าน้อยหรือแม้แต่ความหมายที่ไม่สมบูรณ์อย่างไรก็ตามเราอาศัยค่าคงที่ไม่กี่ตัว:
//
// - ต้นไม้ต้องมี depth/height เหมือนกันซึ่งหมายความว่าทุกเส้นทางลงไปยังใบไม้จากโหนดที่กำหนดมีความยาวเท่ากันทุกประการ
// - โหนดที่มีความยาว `n` มีปุ่ม `n` ค่า `n` และขอบ `n + 1`
//   นี่หมายความว่าแม้แต่โหนดว่างก็มี edge อย่างน้อยหนึ่งตัว
//   สำหรับโหนดลีฟ "having an edge" หมายความว่าเราสามารถระบุตำแหน่งในโหนดได้เท่านั้นเนื่องจากขอบใบว่างเปล่าและไม่จำเป็นต้องแสดงข้อมูล
// ในโหนดภายใน edge ทั้งสองระบุตำแหน่งและมีตัวชี้ไปยังโหนดลูก
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// การเป็นตัวแทนของโหนดลีฟและส่วนหนึ่งของการแสดงโหนดภายใน
struct LeafNode<K, V> {
    /// เราต้องการเป็นโควาเรียใน `K` และ `V`
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// ดัชนีของโหนดนี้ในอาร์เรย์ `edges` ของโหนดแม่
    /// `*node.parent.edges[node.parent_idx]` ควรจะเหมือนกับ `node`
    /// สิ่งนี้รับประกันได้ว่าจะเริ่มต้นเมื่อ `parent` ไม่ใช่ค่าว่างเท่านั้น
    parent_idx: MaybeUninit<u16>,

    /// จำนวนคีย์และค่าที่โหนดนี้จัดเก็บ
    len: u16,

    /// อาร์เรย์ที่จัดเก็บข้อมูลจริงของโหนด
    /// เฉพาะองค์ประกอบ `len` แรกของแต่ละอาร์เรย์เท่านั้นที่เริ่มต้นและถูกต้อง
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// เริ่มต้น `LeafNode` ใหม่ในสถานที่
    unsafe fn init(this: *mut Self) {
        // ตามนโยบายทั่วไปเราปล่อยให้ช่องที่ไม่ได้เริ่มต้นหากสามารถทำได้เนื่องจากควรจะเร็วกว่าเล็กน้อยและง่ายต่อการติดตามใน Valgrind
        //
        unsafe {
            // parent_idx, คีย์และ vals ทั้งหมดเป็นครั้งเดียว
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// สร้าง `LeafNode` ใหม่แกะกล่อง
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// การเป็นตัวแทนของโหนดภายในเช่นเดียวกับ "LeafNode" สิ่งเหล่านี้ควรซ่อนอยู่หลัง "BoxedNode" เพื่อป้องกันการทิ้งคีย์และค่าที่ไม่ได้เริ่มต้น
/// ตัวชี้ใด ๆ ไปยัง `InternalNode` สามารถส่งไปยังตัวชี้ไปยังส่วน `LeafNode` ที่อยู่เบื้องหลังของโหนดได้โดยตรงทำให้โค้ดสามารถทำงานกับโหนดลีฟและโหนดภายในโดยทั่วไปได้โดยไม่ต้องตรวจสอบว่าตัวชี้ทั้งสองตัวชี้ไปที่ใด
///
/// คุณสมบัตินี้เปิดใช้งานโดยใช้ `repr(C)`
///
#[repr(C)]
// gdb_providers.py ใช้ชื่อประเภทนี้สำหรับวิปัสสนา
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// พอยน์เตอร์ถึงชายด์ของโหนดนี้
    /// `len + 1` สิ่งเหล่านี้ถือเป็นการเริ่มต้นและถูกต้องยกเว้นว่าใกล้ถึงจุดสิ้นสุดในขณะที่ต้นไม้ถูกยึดผ่านประเภทยืม `Dying` พอยน์เตอร์เหล่านี้บางส่วนห้อยอยู่
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// สร้าง `InternalNode` ใหม่แกะกล่อง
    ///
    /// # Safety
    /// ความไม่แน่นอนของโหนดภายในคือมีอย่างน้อยหนึ่งที่เริ่มต้นและถูกต้อง edge
    /// ฟังก์ชันนี้ไม่ได้ตั้งค่า edge ดังกล่าว
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // เราจำเป็นต้องเริ่มต้นข้อมูลเท่านั้นขอบอาจจะเป็นหน่วย
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// ตัวชี้ที่มีการจัดการและไม่เป็นค่าว่างไปยังโหนดนี่คือตัวชี้ที่เป็นเจ้าของไปที่ `LeafNode<K, V>` หรือตัวชี้ที่เป็นของ `InternalNode<K, V>`
///
/// อย่างไรก็ตาม `BoxedNode` ไม่มีข้อมูลเกี่ยวกับโหนดสองประเภทที่มีอยู่จริงและบางส่วนเนื่องจากการขาดข้อมูลนี้ไม่ใช่ประเภทแยกต่างหากและไม่มีตัวทำลาย
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// โหนดรากของต้นไม้ที่เป็นเจ้าของ
///
/// โปรดทราบว่าสิ่งนี้ไม่มีตัวทำลายและต้องล้างข้อมูลด้วยตนเอง
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// ส่งคืนทรีที่เป็นเจ้าของใหม่โดยมีโหนดรูทของตัวเองซึ่งตอนแรกว่างเปล่า
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` ต้องไม่เป็นศูนย์
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// ยืมโหนดรูทที่เป็นเจ้าของโดยรวมกัน
    /// ซึ่งแตกต่างจาก `reborrow_mut` ซึ่งปลอดภัยเนื่องจากไม่สามารถใช้ค่าที่ส่งคืนเพื่อทำลายรากและไม่มีการอ้างอิงอื่น ๆ ไปยังทรี
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// สามารถยืมโหนดรูทที่เป็นเจ้าของได้โดยไม่แน่นอน
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// เปลี่ยนกลับไม่ได้เป็นการอ้างอิงที่อนุญาตการข้ามผ่านและเสนอวิธีการทำลายล้างและอื่น ๆ อีกเล็กน้อย
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// เพิ่มโหนดภายในใหม่ด้วย edge เดียวที่ชี้ไปยังโหนดรูทก่อนหน้าทำให้โหนดใหม่เป็นโหนดรูทและส่งคืน
    /// สิ่งนี้จะเพิ่มความสูงขึ้น 1 และตรงข้ามกับ `pop_internal_level`
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, ยกเว้นว่าเราลืมไปแล้วว่าเรากำลังอยู่ภายในตอนนี้:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ลบโหนดรูทภายในโดยใช้ลูกแรกเป็นโหนดรูทใหม่
    /// ตามที่ตั้งใจจะเรียกเมื่อโหนดรูทมีลูกเดียวเท่านั้นจึงไม่มีการล้างข้อมูลบนคีย์ค่าและลูกอื่น ๆ
    ///
    /// สิ่งนี้จะลดความสูงลง 1 และตรงข้ามกับ `push_internal_level`
    ///
    /// ต้องการการเข้าถึงเอกสิทธิ์เฉพาะสำหรับอ็อบเจ็กต์ `Root` แต่ไม่ใช่รูทโหนด
    /// จะไม่ทำให้การจัดการอื่น ๆ หรือการอ้างอิงไปยังโหนดรากเป็นโมฆะ
    ///
    /// Panics ถ้าไม่มีระดับภายในกล่าวคือถ้าโหนดรูทเป็นใบไม้
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // ความปลอดภัย: เรายืนยันว่าเป็นเรื่องภายใน
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // ความปลอดภัย: เรายืม `self` โดยเฉพาะและประเภทการยืมเป็นแบบเฉพาะตัว
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // ความปลอดภัย: edge แรกจะเริ่มต้นเสมอ
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` มีความแปรปรวนร่วมเสมอใน `K` และ `V` แม้ว่า `BorrowType` จะเป็น `Mut` ก็ตาม
// นี่เป็นความผิดทางเทคนิค แต่ไม่สามารถส่งผลให้เกิดความไม่ปลอดภัยใด ๆ เนื่องจากการใช้ `NodeRef` ภายในเนื่องจากเราใช้ `K` และ `V` โดยทั่วไป
//
// อย่างไรก็ตามเมื่อใดก็ตามที่ประเภทพับลิกปิด `NodeRef` ตรวจสอบให้แน่ใจว่ามีความแปรปรวนที่ถูกต้อง
//
/// การอ้างอิงถึงโหนด
///
/// ประเภทนี้มีพารามิเตอร์หลายตัวที่ควบคุมการทำงานของมัน:
/// - `BorrowType`: แบบจำลองที่อธิบายประเภทของการยืมและดำเนินการตลอดชีวิต
///    - เมื่อนี่คือ `Immut<'a>` `NodeRef` จะทำหน้าที่คล้ายกับ `&'a Node`
///    - เมื่อนี่คือ `ValMut<'a>` `NodeRef` จะทำหน้าที่คล้ายกับ `&'a Node` เมื่อเทียบกับคีย์และโครงสร้างของต้นไม้ แต่ยังช่วยให้การอ้างอิงค่าต่างๆทั่วทั้งต้นไม้สามารถอยู่ร่วมกันได้
///    - เมื่อนี่คือ `Mut<'a>` `NodeRef` จะทำหน้าที่คล้ายกับ `&'a mut Node` แม้ว่าวิธีการแทรกจะอนุญาตให้ตัวชี้ที่ไม่แน่นอนของค่าที่จะอยู่ร่วมกันได้
///    - เมื่อนี่คือ `Owned` `NodeRef` จะทำหน้าที่คล้ายกับ `Box<Node>` แต่ไม่มีตัวทำลายและต้องล้างข้อมูลด้วยตนเอง
///    - เมื่อนี่คือ `Dying` `NodeRef` ยังคงทำหน้าที่คล้ายกับ `Box<Node>` แต่มีวิธีการทำลายต้นไม้ทีละนิดและวิธีการธรรมดาในขณะที่ไม่ถูกทำเครื่องหมายว่าไม่ปลอดภัยในการเรียกสามารถเรียก UB ได้หากเรียกไม่ถูกต้อง
///
///   เนื่องจาก `NodeRef` ใด ๆ อนุญาตให้นำทางผ่านทรี `BorrowType` จึงใช้ได้อย่างมีประสิทธิภาพกับทั้งทรีไม่ใช่เฉพาะกับโหนดเท่านั้น
/// - `K` และ `V`: คือประเภทของคีย์และค่าที่เก็บไว้ในโหนด
/// - `Type`: ซึ่งอาจเป็น `Leaf`, `Internal` หรือ `LeafOrInternal`
/// เมื่อนี่คือ `Leaf` `NodeRef` จะชี้ไปที่โหนดลีฟเมื่อนี่คือ `Internal` `NodeRef` จะชี้ไปที่โหนดภายในและเมื่อนี่คือ `LeafOrInternal` `NodeRef` อาจชี้ไปที่โหนดประเภทใดประเภทหนึ่ง
///   `Type` ชื่อ `NodeType` เมื่อใช้ภายนอก `NodeRef`
///
/// ทั้ง `BorrowType` และ `NodeType` จำกัด วิธีการที่เราใช้เพื่อใช้ประโยชน์จากความปลอดภัยแบบคงที่มีข้อ จำกัด ในการใช้ข้อ จำกัด ดังกล่าว:
/// - สำหรับพารามิเตอร์แต่ละประเภทเราสามารถกำหนดวิธีการโดยทั่วไปหรือสำหรับประเภทใดประเภทหนึ่งเท่านั้น
/// ตัวอย่างเช่นเราไม่สามารถกำหนดวิธีการเช่น `into_kv` โดยทั่วไปสำหรับ `BorrowType` ทั้งหมดหรือครั้งเดียวสำหรับทุกประเภทที่มีอายุการใช้งานเนื่องจากเราต้องการให้ส่งคืนการอ้างอิง `&'a`
///   ดังนั้นเราจึงกำหนดไว้สำหรับ `Immut<'a>` ประเภทที่มีประสิทธิภาพน้อยที่สุดเท่านั้น
/// - เราไม่สามารถบังคับโดยปริยายจากการพูด `Mut<'a>` ถึง `Immut<'a>` ได้
///   ดังนั้นเราต้องเรียก `reborrow` อย่างชัดเจนบน `NodeRef` ที่มีประสิทธิภาพมากขึ้นเพื่อให้ได้วิธีการเช่น `into_kv`
///
/// วิธีการทั้งหมดบน `NodeRef` ที่ส่งคืนการอ้างอิงบางประเภท:
/// - ใช้ `self` ตามมูลค่าและส่งคืนอายุการใช้งานที่ถือโดย `BorrowType`
///   บางครั้งในการเรียกใช้วิธีการดังกล่าวเราจำเป็นต้องเรียกใช้ `reborrow_mut`
/// - ใช้ `self` โดยการอ้างอิงและ (implicitly) ส่งคืนอายุการใช้งานของข้อมูลอ้างอิงนั้นแทนอายุการใช้งานที่ถือโดย `BorrowType`
/// ด้วยวิธีนี้เครื่องตรวจสอบการยืมจะรับประกันว่า `NodeRef` จะยังคงถูกยืมตราบเท่าที่มีการใช้ข้อมูลอ้างอิงที่ส่งคืน
///   วิธีการที่รองรับเม็ดมีดจะโค้งงอกฎนี้โดยส่งกลับตัวชี้ดิบนั่นคือการอ้างอิงที่ไม่มีอายุการใช้งานใด ๆ
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// จำนวนระดับที่โหนดและระดับของใบไม้อยู่ห่างกันค่าคงที่ของโหนดที่ `Type` อธิบายไม่ได้ทั้งหมดและโหนดเองไม่ได้จัดเก็บ
    /// เราจำเป็นต้องจัดเก็บความสูงของโหนดรูทและรับความสูงของโหนดอื่น ๆ ทั้งหมดจากโหนดนั้น
    /// ต้องเป็นศูนย์ถ้า `Type` คือ `Leaf` และไม่ใช่ศูนย์ถ้า `Type` คือ `Internal`
    ///
    ///
    height: usize,
    /// ตัวชี้ไปที่ลีฟหรือโหนดภายใน
    /// คำจำกัดความของ `InternalNode` ช่วยให้มั่นใจได้ว่าตัวชี้ถูกต้องไม่ว่าจะด้วยวิธีใดก็ตาม
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// คลายการอ้างอิงโหนดที่บรรจุเป็น `NodeRef::parent`
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// เปิดเผยข้อมูลของโหนดภายใน
    ///
    /// ส่งคืน ptr ดิบเพื่อหลีกเลี่ยงไม่ให้การอ้างอิงอื่น ๆ ไปยังโหนดนี้เป็นโมฆะ
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // ความปลอดภัย: ประเภทโหนดคงที่คือ `Internal`
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// ยืมการเข้าถึงข้อมูลของโหนดภายในแบบเอกสิทธิ์เฉพาะบุคคล
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// ค้นหาความยาวของโหนดนี่คือจำนวนคีย์หรือค่า
    /// จำนวนขอบคือ `len() + 1`
    /// โปรดทราบว่าแม้จะปลอดภัย แต่การเรียกใช้ฟังก์ชันนี้อาจมีผลข้างเคียงของการทำให้การอ้างอิงที่เปลี่ยนแปลงไม่ได้ที่สร้างรหัสที่ไม่ปลอดภัย
    ///
    pub fn len(&self) -> usize {
        // ที่สำคัญเราเข้าถึงฟิลด์ `len` ที่นี่เท่านั้น
        // หาก BorrowType เป็น marker::ValMut อาจมีการอ้างอิงที่ไม่แน่นอนที่ไม่สามารถเปลี่ยนแปลงได้สำหรับค่าที่เราต้องไม่ทำให้เป็นโมฆะ
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// ส่งคืนจำนวนระดับที่โหนดและออกจากกัน
    /// ความสูงเป็นศูนย์หมายถึงโหนดคือใบไม้นั่นเอง
    /// หากคุณวาดภาพต้นไม้โดยให้รูทอยู่ด้านบนตัวเลขจะบอกว่าโหนดใดที่ระดับความสูงปรากฏขึ้น
    /// หากคุณวาดภาพต้นไม้ที่มีใบไม้อยู่ด้านบนตัวเลขจะบอกว่าต้นไม้นั้นยื่นออกมาเหนือโหนดได้สูงเพียงใด
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// นำการอ้างอิงอื่นที่ไม่เปลี่ยนรูปไปใช้กับโหนดเดียวกันชั่วคราว
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// เปิดเผยส่วนของใบไม้หรือโหนดภายใน
    ///
    /// ส่งคืน ptr ดิบเพื่อหลีกเลี่ยงไม่ให้การอ้างอิงอื่น ๆ ไปยังโหนดนี้เป็นโมฆะ
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // โหนดต้องถูกต้องสำหรับส่วน LeafNode เป็นอย่างน้อย
        // นี่ไม่ใช่การอ้างอิงในประเภท NodeRef เนื่องจากเราไม่รู้ว่าควรจะไม่ซ้ำกันหรือใช้ร่วมกัน
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// ค้นหาพาเรนต์ของโหนดปัจจุบัน
    /// ส่งคืน `Ok(handle)` หากโหนดปัจจุบันมีพาเรนต์จริงโดยที่ `handle` ชี้ไปที่ edge ของพาเรนต์ที่ชี้ไปยังโหนดปัจจุบัน
    ///
    /// ส่งคืน `Err(self)` หากโหนดปัจจุบันไม่มีพาเรนต์ให้คืนค่า `NodeRef` ดั้งเดิม
    ///
    /// ชื่อเมธอดจะถือว่าต้นไม้รูปภาพของคุณมีโหนดรูทอยู่ด้านบน
    ///
    /// `edge.descend().ascend().unwrap()` และ `node.ascend().unwrap().descend()` ควรทำทั้งสองอย่างเมื่อประสบความสำเร็จไม่ต้องทำอะไรเลย
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // เราจำเป็นต้องใช้พอยน์เตอร์ดิบกับโหนดเนื่องจากถ้า BorrowType เป็น marker::ValMut อาจมีการอ้างอิงที่ไม่แน่นอนที่ไม่สามารถเปลี่ยนแปลงได้กับค่าที่เราต้องไม่ทำให้เป็นโมฆะ
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// โปรดทราบว่า `self` ต้องไม่ว่างเปล่า
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// โปรดทราบว่า `self` ต้องไม่ว่างเปล่า
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// เปิดเผยส่วนของใบไม้หรือโหนดภายในในต้นไม้ที่ไม่เปลี่ยนรูป
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // ความปลอดภัย: ไม่มีการอ้างอิงที่เปลี่ยนแปลงไม่ได้ในต้นไม้นี้ที่ยืมมาเป็น `Immut`
        unsafe { &*ptr }
    }

    /// ยืมมุมมองลงในคีย์ที่เก็บไว้ในโหนด
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// คล้ายกับ `ascend` ได้รับการอ้างอิงไปยังโหนดแม่ของโหนด แต่ยังจัดสรรโหนดปัจจุบันในกระบวนการ
    /// สิ่งนี้ไม่ปลอดภัยเนื่องจากโหนดปัจจุบันจะยังคงสามารถเข้าถึงได้แม้ว่าจะถูกยกเลิกการจัดสรรแล้วก็ตาม
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ไม่ปลอดภัยยืนยันข้อมูลสแตติกกับคอมไพลเลอร์ว่าโหนดนี้เป็น `Leaf`
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ไม่ปลอดภัยยืนยันข้อมูลสแตติกกับคอมไพลเลอร์ว่าโหนดนี้คือ `Internal`
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// นำการอ้างอิงอื่นที่เปลี่ยนแปลงไม่ได้ไปใช้กับโหนดเดียวกันชั่วคราวระวังเนื่องจากวิธีนี้อันตรายมากเป็นทวีคูณเนื่องจากอาจไม่ปรากฏว่าเป็นอันตรายในทันที
    ///
    /// เนื่องจากพอยน์เตอร์ที่เปลี่ยนแปลงได้สามารถเดินเตร่ไปที่ใดก็ได้รอบ ๆ ต้นไม้ตัวชี้ที่ส่งคืนจึงสามารถใช้เพื่อทำให้ตัวชี้เดิมห้อยอยู่นอกขอบเขตหรือไม่ถูกต้องภายใต้กฎการยืมแบบซ้อนกัน
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) พิจารณาเพิ่มพารามิเตอร์ประเภทอื่นให้กับ `NodeRef` ที่ จำกัด การใช้วิธีการนำทางบนพอยน์เตอร์ที่สร้างใหม่เพื่อป้องกันความไม่ปลอดภัยนี้
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ยืมสิทธิ์เข้าถึงเฉพาะส่วนของ Leaf หรือโหนดภายใน
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // ความปลอดภัย: เรามีสิทธิพิเศษในการเข้าถึงโหนดทั้งหมด
        unsafe { &mut *ptr }
    }

    /// เสนอการเข้าถึงพิเศษเฉพาะในส่วนของใบไม้หรือโหนดภายในใด ๆ
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // ความปลอดภัย: เรามีสิทธิพิเศษในการเข้าถึงโหนดทั้งหมด
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// ยืมการเข้าถึงพิเศษไปยังองค์ประกอบของพื้นที่จัดเก็บคีย์
    ///
    /// # Safety
    /// `index` อยู่ในขอบเขต 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // ความปลอดภัย: ผู้โทรจะไม่สามารถโทรหาวิธีการเพิ่มเติมได้ด้วยตนเอง
        // จนกว่าการอ้างอิงส่วนสำคัญจะหลุดเนื่องจากเรามีสิทธิ์เข้าถึงที่ไม่ซ้ำกันตลอดอายุการยืม
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// ยืมการเข้าถึงแบบเอกสิทธิ์เฉพาะบุคคลไปยังองค์ประกอบหรือส่วนของพื้นที่จัดเก็บค่าของโหนด
    ///
    /// # Safety
    /// `index` อยู่ในขอบเขต 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // ความปลอดภัย: ผู้โทรจะไม่สามารถโทรหาวิธีการเพิ่มเติมได้ด้วยตนเอง
        // จนกว่าการอ้างอิงชิ้นส่วนมูลค่าจะหลุดเนื่องจากเรามีสิทธิ์เข้าถึงที่ไม่ซ้ำกันตลอดอายุการยืม
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// ยืมการเข้าถึงแบบเอกสิทธิ์เฉพาะบุคคลไปยังองค์ประกอบหรือส่วนของพื้นที่จัดเก็บของโหนดสำหรับเนื้อหา edge
    ///
    /// # Safety
    /// `index` อยู่ในขอบเขต 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // ความปลอดภัย: ผู้โทรจะไม่สามารถโทรหาวิธีการเพิ่มเติมได้ด้วยตนเอง
        // จนกว่าการอ้างอิงชิ้นส่วน edge จะหลุดเนื่องจากเรามีสิทธิ์เข้าถึงที่ไม่ซ้ำกันตลอดอายุการยืม
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - โหนดมีองค์ประกอบเริ่มต้นมากกว่า `idx`
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // เราสร้างการอ้างอิงไปยังองค์ประกอบเดียวที่เราสนใจเท่านั้นเพื่อหลีกเลี่ยงการใช้นามแฝงที่มีการอ้างอิงที่โดดเด่นไปยังองค์ประกอบอื่น ๆ โดยเฉพาะอย่างยิ่งส่วนที่ส่งกลับไปยังผู้เรียกในการทำซ้ำก่อนหน้านี้
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // เราต้องบังคับให้ตัวชี้อาร์เรย์ที่ไม่มีขนาดเนื่องจาก Rust ออก #74679
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// ยืมสิทธิ์การเข้าถึงเฉพาะความยาวของโหนด
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ตั้งค่าการเชื่อมโยงของโหนดไปยัง edge พาเรนต์โดยไม่ทำให้การอ้างอิงอื่นไปยังโหนดไม่ถูกต้อง
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// ล้างลิงก์ของรูทไปยัง edge พาเรนต์
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// เพิ่มคู่คีย์-ค่าที่ท้ายโหนด
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// ทุกรายการที่ส่งคืนโดย `range` คือดัชนี edge ที่ถูกต้องสำหรับโหนด
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// เพิ่มคู่คีย์-ค่าและ edge ไปทางขวาของคู่นั้นไปที่ท้ายโหนด
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// ตรวจสอบว่าโหนดเป็นโหนด `Internal` หรือโหนด `Leaf`
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// การอ้างอิงคู่คีย์-ค่าเฉพาะหรือ edge ภายในโหนด
/// พารามิเตอร์ `Node` ต้องเป็น `NodeRef` ในขณะที่ `Type` สามารถเป็น `KV` (หมายถึงหมายเลขอ้างอิงของคู่คีย์-ค่า) หรือ `Edge` (หมายถึงจุดจับบน edge)
///
/// โปรดทราบว่าแม้แต่โหนด `Leaf` ก็สามารถมีที่จับ `Edge` ได้
/// แทนที่จะแสดงตัวชี้ไปยังโหนดลูกสิ่งเหล่านี้แสดงถึงช่องว่างที่ตัวชี้ลูกจะอยู่ระหว่างคู่คีย์-ค่า
/// ตัวอย่างเช่นในโหนดที่มีความยาว 2 จะมีตำแหน่ง edge ที่เป็นไปได้ 3 ตำแหน่งทางด้านซ้ายของโหนดหนึ่งตำแหน่งระหว่างสองคู่และอีกหนึ่งตำแหน่งทางด้านขวาของโหนด
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// เราไม่ต้องการความสมบูรณ์ของ `#[derive(Clone)]` โดยทั่วไปเนื่องจาก `Node` ครั้งเดียวที่จะ `` โคลน 'ได้ก็คือเมื่อมันเป็นข้อมูลอ้างอิงที่ไม่เปลี่ยนรูปและดังนั้น `Copy`
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// ดึงโหนดที่มี edge หรือคีย์-ค่าที่จับคู่จุดจับนี้
    pub fn into_node(self) -> Node {
        self.node
    }

    /// ส่งคืนตำแหน่งของจุดจับนี้ในโหนด
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// สร้างหมายเลขอ้างอิงใหม่ให้กับคู่คีย์-ค่าใน `node`
    /// ไม่ปลอดภัยเนื่องจากผู้โทรต้องมั่นใจว่า `idx < node.len()`
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// อาจเป็นการใช้งาน PartialEq แบบสาธารณะ แต่ใช้เฉพาะในโมดูลนี้
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// ดึงที่จับอื่นที่ไม่เปลี่ยนรูปชั่วคราวออกจากตำแหน่งเดียวกัน
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // เราไม่สามารถใช้ Handle::new_kv หรือ Handle::new_edge ได้เนื่องจากเราไม่ทราบประเภทของเรา
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// ไม่ปลอดภัยยืนยันข้อมูลสแตติกกับคอมไพลเลอร์ว่าโหนดของแฮนเดิลคือ `Leaf`
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// ดึงที่จับอื่นที่ไม่แน่นอนออกจากตำแหน่งเดียวกันชั่วคราว
    /// ระวังเนื่องจากวิธีนี้อันตรายมากเป็นทวีคูณเนื่องจากอาจไม่ปรากฏว่าเป็นอันตรายในทันที
    ///
    ///
    /// สำหรับรายละเอียดโปรดดู `NodeRef::reborrow_mut`
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // เราไม่สามารถใช้ Handle::new_kv หรือ Handle::new_edge ได้เนื่องจากเราไม่ทราบประเภทของเรา
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// สร้างหมายเลขอ้างอิงใหม่ให้กับ edge ใน `node`
    /// ไม่ปลอดภัยเนื่องจากผู้โทรต้องมั่นใจว่า `idx <= node.len()`
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// ด้วยดัชนี edge ที่เราต้องการแทรกลงในโหนดที่เต็มไปด้วยความจุคำนวณดัชนี KV ที่เหมาะสมของจุดแยกและตำแหน่งที่จะทำการแทรก
///
/// เป้าหมายของจุดแยกคือคีย์และค่าที่จะสิ้นสุดในโหนดหลัก
/// คีย์ค่าและขอบทางด้านซ้ายของจุดแยกกลายเป็นลูกด้านซ้าย
/// คีย์ค่าและขอบทางด้านขวาของจุดแยกจะกลายเป็นลูกที่เหมาะสม
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // ปัญหา Rust #74834 พยายามอธิบายกฎสมมาตรเหล่านี้
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// แทรกคู่คีย์-ค่าใหม่ระหว่างคู่คีย์-ค่าทางขวาและซ้ายของ edge นี้
    /// วิธีนี้จะถือว่ามีพื้นที่ว่างเพียงพอในโหนดสำหรับคู่ใหม่ที่จะใส่ได้
    ///
    /// ตัวชี้ที่ส่งกลับจะชี้ไปที่ค่าที่แทรก
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// แทรกคู่คีย์-ค่าใหม่ระหว่างคู่คีย์-ค่าทางขวาและซ้ายของ edge นี้
    /// วิธีนี้จะแยกโหนดหากไม่มีที่ว่างเพียงพอ
    ///
    /// ตัวชี้ที่ส่งกลับจะชี้ไปที่ค่าที่แทรก
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// แก้ไขตัวชี้พาเรนต์และดัชนีในโหนดลูกที่ edge เชื่อมโยงไป
    /// สิ่งนี้มีประโยชน์เมื่อมีการเปลี่ยนแปลงลำดับของขอบ
    fn correct_parent_link(self) {
        // สร้าง backpointer โดยไม่ทำให้การอ้างอิงอื่นไปยังโหนดไม่ถูกต้อง
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// แทรกคู่คีย์-ค่าใหม่และ edge ที่จะไปทางขวาของคู่ใหม่ระหว่าง edge นี้กับคู่คีย์-ค่าทางด้านขวาของ edge นี้
    /// วิธีนี้จะถือว่ามีพื้นที่ว่างเพียงพอในโหนดสำหรับคู่ใหม่ที่จะใส่ได้
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// แทรกคู่คีย์-ค่าใหม่และ edge ที่จะไปทางขวาของคู่ใหม่ระหว่าง edge นี้กับคู่คีย์-ค่าทางด้านขวาของ edge นี้
    /// วิธีนี้จะแยกโหนดหากไม่มีที่ว่างเพียงพอ
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// แทรกคู่คีย์-ค่าใหม่ระหว่างคู่คีย์-ค่าทางขวาและซ้ายของ edge นี้
    /// วิธีนี้จะแยกโหนดหากไม่มีที่ว่างเพียงพอและพยายามแทรกส่วนที่แยกออกไปในโหนดแม่แบบวนซ้ำจนกว่าจะถึงรูท
    ///
    ///
    /// หากผลลัพธ์ที่ส่งคืนเป็น `Fit` โหนดของแฮนเดิลอาจเป็นโหนดของ edge หรือบรรพบุรุษ
    /// หากผลลัพธ์ที่ส่งคืนเป็น `Split` ฟิลด์ `left` จะเป็นรูทโหนด
    /// ตัวชี้ที่ส่งกลับจะชี้ไปที่ค่าที่แทรก
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// ค้นหาโหนดที่ชี้โดย edge นี้
    ///
    /// ชื่อเมธอดจะถือว่าต้นไม้รูปภาพของคุณมีโหนดรูทอยู่ด้านบน
    ///
    /// `edge.descend().ascend().unwrap()` และ `node.ascend().unwrap().descend()` ควรทำทั้งสองอย่างเมื่อประสบความสำเร็จไม่ต้องทำอะไรเลย
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // เราจำเป็นต้องใช้พอยน์เตอร์ดิบกับโหนดเนื่องจากถ้า BorrowType เป็น marker::ValMut อาจมีการอ้างอิงที่ไม่แน่นอนที่ไม่สามารถเปลี่ยนแปลงได้กับค่าที่เราต้องไม่ทำให้เป็นโมฆะ
        // ไม่ต้องกังวลในการเข้าถึงช่องความสูงเนื่องจากค่านั้นถูกคัดลอก
        // ระวังว่าเมื่อยกเลิกการอ้างอิงโหนดพอยน์เตอร์แล้วเราจะเข้าถึงอาร์เรย์ edge ด้วยการอ้างอิง (Rust issue #73987) และทำให้การอ้างอิงอื่นใดที่เป็นโมฆะหรือภายในอาร์เรย์ไม่ถูกต้องควรอยู่รอบ ๆ
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // เราไม่สามารถเรียกวิธีการคีย์และค่าแยกกันได้เนื่องจากการเรียกแบบที่สองจะทำให้การอ้างอิงที่ส่งคืนโดยครั้งแรกไม่ถูกต้อง
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// แทนที่คีย์และค่าที่ตัวจับ KV อ้างถึง
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// ช่วยการใช้งาน `split` สำหรับ `NodeType` เฉพาะโดยดูแลข้อมูลใบไม้
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// แยกโหนดที่อยู่ภายใต้ออกเป็นสามส่วน:
    ///
    /// - โหนดถูกตัดทอนให้มีเฉพาะคู่คีย์-ค่าทางด้านซ้ายของจุดจับนี้
    /// - คีย์และค่าที่ชี้ไปที่แฮนเดิลนี้จะถูกแยกออก
    /// - คู่คีย์-ค่าทั้งหมดทางด้านขวาของแฮนเดิลนี้จะใส่ลงในโหนดที่จัดสรรใหม่
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// ลบคู่คีย์-ค่าที่ชี้ไปที่จุดจับนี้และส่งคืนพร้อมกับ edge ที่คู่คีย์-ค่ายุบเข้าไป
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// แยกโหนดที่อยู่ภายใต้ออกเป็นสามส่วน:
    ///
    /// - โหนดจะถูกตัดให้เหลือเพียงขอบและคู่คีย์-ค่าทางด้านซ้ายของจุดจับนี้
    /// - คีย์และค่าที่ชี้ไปที่แฮนเดิลนี้จะถูกแยกออก
    /// - คู่ขอบและคีย์-ค่าทั้งหมดทางด้านขวาของแฮนเดิลนี้จะถูกใส่ลงในโหนดที่จัดสรรใหม่
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// แสดงเซสชันสำหรับการประเมินและดำเนินการปรับสมดุลรอบคู่คีย์-ค่าภายใน
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// เลือกบริบทการปรับสมดุลที่เกี่ยวข้องกับโหนดเป็นชายด์ดังนั้นระหว่าง KV ไปทางซ้ายหรือทางขวาในโหนดพาเรนต์
    /// ส่งคืน `Err` หากไม่มีพาเรนต์
    /// Panics หากพาเรนต์ว่างเปล่า
    ///
    /// ชอบด้านซ้ายเพื่อให้เหมาะสมที่สุดหากโหนดที่ระบุมีน้อยเกินไปหมายความว่าในที่นี้จะมีองค์ประกอบน้อยกว่าพี่น้องทางซ้ายและมากกว่าพี่น้องทางขวาหากมีอยู่
    /// ในกรณีนี้การรวมกับพี่น้องทางซ้ายจะเร็วกว่าเนื่องจากเราจำเป็นต้องย้ายองค์ประกอบ N ของโหนดเท่านั้นแทนที่จะเลื่อนไปทางขวาและย้ายมากกว่า N องค์ประกอบที่อยู่ข้างหน้า
    /// โดยทั่วไปแล้วการขโมยจากพี่น้องทางซ้ายจะเร็วกว่าเช่นกันเนื่องจากเราจำเป็นต้องเลื่อนองค์ประกอบ N ของโหนดไปทางขวาเท่านั้นแทนที่จะเลื่อนองค์ประกอบของพี่น้องไปทางซ้ายอย่างน้อย N
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// ส่งคืนว่าการรวมเป็นไปได้หรือไม่กล่าวคือมีที่ว่างเพียงพอในโหนดที่จะรวม KV กลางกับโหนดลูกที่อยู่ติดกันทั้งสองหรือไม่
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// ทำการรวมและให้การปิดตัดสินใจว่าจะส่งคืนอะไร
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // ความปลอดภัย: ความสูงของโหนดที่ผสานอยู่ต่ำกว่าความสูง
                // ของโหนดของ edge นี้จึงอยู่เหนือศูนย์ดังนั้นจึงอยู่ภายใน
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// ผสานคู่คีย์-ค่าของพาเรนต์และโหนดลูกที่อยู่ติดกันทั้งสองโหนดเข้ากับโหนดลูกทางซ้ายและส่งคืนโหนดพาเรนต์ที่หดตัว
    ///
    ///
    /// Panics เว้นแต่เราจะ `.can_merge()`
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// ผสานคู่คีย์-ค่าของพาเรนต์และโหนดลูกที่อยู่ติดกันทั้งสองเข้ากับโหนดลูกทางซ้ายและส่งคืนโหนดลูกนั้น
    ///
    ///
    /// Panics เว้นแต่เราจะ `.can_merge()`
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// ผสานคู่คีย์-ค่าของพาเรนต์และโหนดชายด์ที่อยู่ติดกันทั้งสองโหนดเข้ากับโหนดลูกทางซ้ายและส่งคืนหมายเลขอ้างอิง edge ในโหนดลูกนั้นที่ลูกที่ถูกติดตาม edge สิ้นสุด
    ///
    ///
    /// Panics เว้นแต่เราจะ `.can_merge()`
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// ลบคู่คีย์-ค่าออกจากชายด์ด้านซ้ายและวางไว้ในที่เก็บคีย์-ค่าของพาเรนต์ในขณะที่ดันคู่คีย์-ค่าพาเรนต์เก่าลงในชายด์ด้านขวา
    ///
    /// ส่งคืนหมายเลขอ้างอิงให้กับ edge ในชายด์ด้านขวาที่ตรงกับจุดที่ edge ดั้งเดิมที่ระบุโดย `track_right_edge_idx` ลงเอย
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// ลบคู่คีย์-ค่าออกจากชายด์ด้านขวาและวางไว้ในที่เก็บคีย์-ค่าของพาเรนต์ในขณะที่ดันคู่คีย์-ค่าพาเรนต์เก่าไปยังลูกด้านซ้าย
    ///
    /// ส่งคืนหมายเลขอ้างอิงให้กับ edge ในชายด์ด้านซ้ายที่ระบุโดย `track_left_edge_idx` ซึ่งไม่เคลื่อนที่
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// การขโมยนี้คล้ายกับ `steal_left` แต่ขโมยหลายองค์ประกอบพร้อมกัน
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // ตรวจสอบให้แน่ใจว่าเราอาจขโมยได้อย่างปลอดภัย
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // ย้ายข้อมูลใบไม้
            {
                // หาที่ว่างสำหรับองค์ประกอบที่ถูกขโมยในเด็กที่เหมาะสม
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // ย้ายองค์ประกอบจากเด็กทางซ้ายไปทางขวา
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // ย้ายคู่ซ้ายสุดที่ถูกขโมยไปที่ระดับบนสุด
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // ย้ายคู่คีย์-ค่าของผู้ปกครองไปยังลูกที่เหมาะสม
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // สร้างที่ว่างสำหรับขอบที่ถูกขโมย
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // ขโมยขอบ
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// โคลนสมมาตรของ `bulk_steal_left`
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // ตรวจสอบให้แน่ใจว่าเราอาจขโมยได้อย่างปลอดภัย
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // ย้ายข้อมูลใบไม้
            {
                // ย้ายคู่ที่ถูกขโมยที่สุดไปยังผู้ปกครอง
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // ย้ายคู่คีย์-ค่าของผู้ปกครองไปที่ลูกด้านซ้าย
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // ย้ายองค์ประกอบจากลูกด้านขวาไปทางซ้าย
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // เติมช่องว่างที่องค์ประกอบที่ถูกขโมยเคยเป็น
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // ขโมยขอบ
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // เติมช่องว่างที่ขอบที่ถูกขโมยเคยเป็น
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// ลบข้อมูลคงที่ที่ยืนยันว่าโหนดนี้เป็นโหนด `Leaf`
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// ลบข้อมูลคงที่ที่ยืนยันว่าโหนดนี้เป็นโหนด `Internal`
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// ตรวจสอบว่าโหนดต้นแบบเป็นโหนด `Internal` หรือโหนด `Leaf`
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// ย้ายคำต่อท้ายหลัง `self` จากโหนดหนึ่งไปยังอีกโหนดหนึ่ง `right` ต้องว่างเปล่า
    /// edge แรกของ `right` ยังคงไม่เปลี่ยนแปลง
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// ผลลัพธ์ของการแทรกเมื่อโหนดจำเป็นต้องขยายเกินความจุ
pub struct SplitResult<'a, K, V, NodeType> {
    // โหนดที่เปลี่ยนแปลงในโครงสร้างที่มีอยู่พร้อมองค์ประกอบและขอบที่อยู่ทางด้านซ้ายของ `kv`
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // คีย์และค่าบางส่วนแยกออกเพื่อแทรกที่อื่น
    pub kv: (K, V),
    // โหนดใหม่ที่เป็นเจ้าของและไม่ได้เชื่อมต่อพร้อมองค์ประกอบและขอบที่อยู่ทางขวาของ `kv`
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // การอ้างอิงโหนดของประเภทการยืมนี้อนุญาตให้ข้ามไปยังโหนดอื่นในแผนภูมิได้หรือไม่
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // ไม่จำเป็นต้องใช้การข้ามผ่านมันเกิดขึ้นโดยใช้ผลลัพธ์ของ `borrow_mut`
        // ด้วยการปิดใช้งานการข้ามผ่านและสร้างการอ้างอิงใหม่ไปยังรูทเท่านั้นเรารู้ว่าการอ้างอิงทุกประเภทของ `Owned` นั้นไปที่โหนดรูท
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// แทรกค่าลงในชิ้นส่วนขององค์ประกอบที่เริ่มต้นแล้วตามด้วยองค์ประกอบที่ไม่ได้เริ่มต้นหนึ่งรายการ
///
/// # Safety
/// ชิ้นส่วนมีองค์ประกอบมากกว่า `idx`
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// ลบและส่งคืนค่าจากชิ้นส่วนขององค์ประกอบที่เริ่มต้นทั้งหมดโดยทิ้งไว้เบื้องหลังองค์ประกอบที่ไม่ได้เริ่มต้นหนึ่งรายการ
///
///
/// # Safety
/// ชิ้นส่วนมีองค์ประกอบมากกว่า `idx`
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// เลื่อนองค์ประกอบในตำแหน่ง `distance` สไลซ์ไปทางซ้าย
///
/// # Safety
/// ชิ้นส่วนมีองค์ประกอบ `distance` เป็นอย่างน้อย
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// เลื่อนองค์ประกอบในตำแหน่ง `distance` สไลซ์ไปทางขวา
///
/// # Safety
/// ชิ้นส่วนมีองค์ประกอบ `distance` เป็นอย่างน้อย
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// ย้ายค่าทั้งหมดจากชิ้นส่วนขององค์ประกอบที่เริ่มต้นไปยังชิ้นส่วนขององค์ประกอบที่ไม่ได้เริ่มต้นโดยทิ้ง `src` ไว้ในลักษณะที่ไม่ได้เริ่มต้นทั้งหมด
///
/// ทำงานเหมือน `dst.copy_from_slice(src)` แต่ไม่ต้องการให้ `T` เป็น `Copy`
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;