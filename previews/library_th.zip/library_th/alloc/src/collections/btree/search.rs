use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// รวมที่ต้องมองหาเช่นเดียวกับ `Bound::Included(T)`
    Included(T),
    /// สิ่งที่ต้องมองหาเป็นพิเศษเช่นเดียวกับ `Bound::Excluded(T)`
    Excluded(T),
    /// ขอบเขตรวมที่ไม่มีเงื่อนไขเช่นเดียวกับ `Bound::Unbounded`
    AllIncluded,
    /// ขอบเขตพิเศษที่ไม่มีเงื่อนไข
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// ค้นหาคีย์ที่กำหนดในโครงสร้าง (ย่อย) ที่นำโดยโหนดแบบวนซ้ำ
    /// ส่งคืน `Found` โดยใช้หมายเลขอ้างอิงของ KV ที่ตรงกันถ้ามี
    /// มิฉะนั้นจะส่งคืน `GoDown` ด้วยหมายเลขอ้างอิงของใบไม้ edge ที่ซึ่งคีย์อยู่
    ///
    /// ผลลัพธ์จะมีความหมายก็ต่อเมื่อต้นไม้ถูกเรียงลำดับตามคีย์เช่นเดียวกับต้นไม้ใน `BTreeMap`
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// ลงไปที่โหนดที่ใกล้ที่สุดโดยที่ edge ตรงกับขอบเขตล่างของช่วงนั้นแตกต่างจาก edge ที่ตรงกับขอบเขตบนกล่าวคือโหนดที่ใกล้ที่สุดซึ่งมีคีย์อย่างน้อยหนึ่งคีย์อยู่ในช่วง
    ///
    ///
    /// หากพบให้ส่งคืน `Ok` พร้อมกับโหนดนั้นคู่ของดัชนี edge ในนั้นโดยคั่นช่วงและคู่ของขอบเขตที่เกี่ยวข้องสำหรับการค้นหาต่อในโหนดลูกในกรณีที่โหนดอยู่ภายใน
    ///
    /// หากไม่พบให้ส่งคืน `Err` โดยให้ใบ edge ตรงกับช่วงทั้งหมด
    ///
    /// ผลลัพธ์จะมีความหมายก็ต่อเมื่อต้นไม้ถูกเรียงลำดับตามคีย์
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // ควรหลีกเลี่ยงการแทรกตัวแปรเหล่านี้
        // เราถือว่าขอบเขตที่รายงานโดย `range` ยังคงเหมือนเดิม แต่การใช้งานในทางตรงข้ามอาจเปลี่ยนแปลงระหว่างการเรียก (#81138)
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// ค้นหา edge ในโหนดที่ขีดเส้นขอบล่างของช่วง
    /// ยังส่งคืนขอบเขตล่างที่จะใช้สำหรับการค้นหาต่อในโหนดลูกที่ตรงกันถ้า `self` เป็นโหนดภายใน
    ///
    ///
    /// ผลลัพธ์จะมีความหมายก็ต่อเมื่อต้นไม้ถูกเรียงลำดับตามคีย์
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// โคลน `find_lower_bound_edge` สำหรับขอบเขตบน
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// ค้นหาคีย์ที่กำหนดในโหนดโดยไม่ต้องเรียกซ้ำ
    /// ส่งคืน `Found` โดยใช้หมายเลขอ้างอิงของ KV ที่ตรงกันถ้ามี
    /// มิฉะนั้นจะส่งคืน `GoDown` ด้วยหมายเลขอ้างอิงของ edge ที่ซึ่งอาจพบคีย์ (หากโหนดอยู่ภายใน) หรือตำแหน่งที่สามารถใส่คีย์ได้
    ///
    ///
    /// ผลลัพธ์จะมีความหมายก็ต่อเมื่อต้นไม้ถูกเรียงลำดับตามคีย์เช่นเดียวกับต้นไม้ใน `BTreeMap`
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// ส่งคืนดัชนี KV ในโหนดที่มีคีย์ (หรือเทียบเท่า) หรือดัชนี edge ที่คีย์อยู่
    ///
    ///
    /// ผลลัพธ์จะมีความหมายก็ต่อเมื่อต้นไม้ถูกเรียงลำดับตามคีย์เช่นเดียวกับต้นไม้ใน `BTreeMap`
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// ค้นหาดัชนี edge ในโหนดที่ขีดเส้นขอบล่างของช่วง
    /// ยังส่งคืนขอบเขตล่างที่จะใช้สำหรับการค้นหาต่อในโหนดลูกที่ตรงกันถ้า `self` เป็นโหนดภายใน
    ///
    ///
    /// ผลลัพธ์จะมีความหมายก็ต่อเมื่อต้นไม้ถูกเรียงลำดับตามคีย์
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// โคลน `find_lower_bound_index` สำหรับขอบเขตบน
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}