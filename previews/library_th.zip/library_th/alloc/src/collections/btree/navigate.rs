use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// นำช่วงที่เทียบเท่ากันไม่เปลี่ยนรูปอีกอันออกชั่วคราว
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// ค้นหาขอบใบที่แตกต่างกันซึ่งขีดเส้นแบ่งช่วงที่ระบุในต้นไม้
    /// ส่งคืนค่าคู่ของแฮนเดิลที่แตกต่างกันในทรีเดียวกันหรือคู่ของอ็อพชันว่าง
    ///
    /// # Safety
    ///
    /// เว้นแต่ `BorrowType` คือ `Immut` อย่าใช้แฮนเดิลที่ซ้ำกันเพื่อเยี่ยมชม KV เดียวกันสองครั้ง
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// เทียบเท่ากับ `(root1.first_leaf_edge(), root2.last_leaf_edge())` แต่มีประสิทธิภาพมากกว่า
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// ค้นหาคู่ของขอบใบที่ขีดเส้นช่วงเฉพาะในต้นไม้
    ///
    /// ผลลัพธ์จะมีความหมายก็ต่อเมื่อต้นไม้ถูกเรียงลำดับตามคีย์เช่นเดียวกับต้นไม้ใน `BTreeMap`
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // ความปลอดภัย: ประเภทการกู้ยืมของเราไม่เปลี่ยนรูป
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// ค้นหาคู่ของขอบใบที่ขีดเส้นรอบต้นไม้ทั้งต้น
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// แยกการอ้างอิงที่ไม่ซ้ำกันออกเป็นคู่ของขอบใบที่คั่นช่วงที่ระบุ
    /// ผลลัพธ์คือการอ้างอิงที่ไม่ซ้ำกันซึ่งอนุญาตให้มีการกลายพันธุ์ (some) ซึ่งต้องใช้อย่างระมัดระวัง
    ///
    /// ผลลัพธ์จะมีความหมายก็ต่อเมื่อต้นไม้ถูกเรียงลำดับตามคีย์เช่นเดียวกับต้นไม้ใน `BTreeMap`
    ///
    ///
    /// # Safety
    /// อย่าใช้ที่จับซ้ำเพื่อเยี่ยมชม KV เดียวกันสองครั้ง
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// แยกการอ้างอิงที่ไม่ซ้ำกันออกเป็นคู่ของขอบใบที่ขีดเส้นเต็มช่วงของต้นไม้
    /// ผลลัพธ์คือการอ้างอิงที่ไม่ซ้ำกันซึ่งอนุญาตให้มีการกลายพันธุ์ (ของค่าเท่านั้น) ดังนั้นต้องใช้ด้วยความระมัดระวัง
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // เราทำซ้ำ NodeRef รูทที่นี่-เราจะไม่ไปที่ KV เดียวกันซ้ำสองครั้งและจะไม่จบลงด้วยการอ้างอิงค่าที่ทับซ้อนกัน
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// แยกการอ้างอิงที่ไม่ซ้ำกันออกเป็นคู่ของขอบใบที่ขีดเส้นเต็มช่วงของต้นไม้
    /// ผลลัพธ์ที่ได้คือการอ้างอิงที่ไม่ซ้ำกันซึ่งอนุญาตให้มีการกลายพันธุ์ที่ทำลายล้างอย่างมากดังนั้นจึงต้องใช้ด้วยความระมัดระวังสูงสุด
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // เราทำซ้ำ NodeRef รูทที่นี่-เราจะไม่เข้าถึงมันในลักษณะที่ทับซ้อนการอ้างอิงที่ได้รับจากรูท
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// ให้ใบจับ edge ส่งคืน [`Result::Ok`] พร้อมกับแฮนเดิลไปยัง KV ที่อยู่ใกล้เคียงทางด้านขวาซึ่งอยู่ในโหนดลีฟเดียวกันหรือในโหนดบรรพบุรุษ
    ///
    /// ถ้าใบ edge เป็นใบสุดท้ายในทรีให้ส่งคืน [`Result::Err`] พร้อมกับโหนดรูท
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// ให้ใบจับ edge ส่งคืน [`Result::Ok`] พร้อมกับแฮนเดิลไปยัง KV ที่อยู่ใกล้เคียงทางด้านซ้ายซึ่งอยู่ในโหนดลีฟเดียวกันหรือในโหนดบรรพบุรุษ
    ///
    /// ถ้าใบ edge เป็นใบแรกในแผนภูมิให้ส่งคืน [`Result::Err`] พร้อมกับโหนดราก
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// ระบุหมายเลขอ้างอิง edge ภายในให้ส่งคืน [`Result::Ok`] พร้อมแฮนเดิลไปยัง KV ที่อยู่ใกล้เคียงทางด้านขวาซึ่งอยู่ในโหนดภายในเดียวกันหรือในโหนดบรรพบุรุษ
    ///
    /// ถ้า edge ภายในเป็นตัวสุดท้ายในทรีให้ส่งคืน [`Result::Err`] พร้อมกับโหนดรูท
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// กำหนดใบจับ edge ลงในต้นไม้ที่กำลังจะตายส่งกลับใบถัดไป edge ทางด้านขวาและคู่คีย์-ค่าระหว่างซึ่งอยู่ในโหนดลีฟเดียวกันในโหนดบรรพบุรุษหรือไม่มีอยู่จริง
    ///
    ///
    /// วิธีนี้ยังจัดสรร node(s) ใด ๆ ที่ถึงจุดสิ้นสุดของไฟล์.
    /// นี่หมายความว่าหากไม่มีคู่คีย์-ค่าอีกต่อไปส่วนที่เหลือทั้งหมดของทรีจะถูกยกเลิกการจัดสรรและไม่เหลืออะไรให้ส่งคืน
    ///
    /// # Safety
    /// edge ที่ระบุจะต้องไม่ถูกส่งคืนก่อนหน้านี้โดย `deallocating_next_back` คู่กัน
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// กำหนดใบจับ edge ลงในต้นไม้ที่กำลังจะตายส่งกลับใบถัดไป edge ทางด้านซ้ายและคู่คีย์-ค่าที่อยู่ระหว่างซึ่งอยู่ในโหนดลีฟเดียวกันในโหนดบรรพบุรุษหรือไม่มีอยู่จริง
    ///
    ///
    /// วิธีนี้ยังจัดสรร node(s) ใด ๆ ที่ถึงจุดสิ้นสุดของไฟล์.
    /// นี่หมายความว่าหากไม่มีคู่คีย์-ค่าอีกต่อไปส่วนที่เหลือทั้งหมดของทรีจะถูกยกเลิกการจัดสรรและไม่เหลืออะไรให้ส่งคืน
    ///
    /// # Safety
    /// edge ที่ระบุจะต้องไม่ถูกส่งคืนก่อนหน้านี้โดย `deallocating_next` คู่กัน
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// จัดสรรกองโหนดจากใบไม้ขึ้นไปที่ราก
    /// นี่เป็นวิธีเดียวในการจัดสรรส่วนที่เหลือของต้นไม้หลังจาก `deallocating_next` และ `deallocating_next_back` แทะทั้งสองข้างของต้นไม้และได้ชน edge เดียวกัน
    /// ตามที่มีไว้เพื่อเรียกใช้เมื่อคีย์และค่าทั้งหมดถูกส่งกลับเท่านั้นจึงไม่มีการล้างข้อมูลบนคีย์หรือค่าใด ๆ
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ย้ายจุดจับ edge ไปยังใบถัดไป edge และส่งคืนการอ้างอิงไปยังคีย์และค่าที่อยู่ระหว่าง
    ///
    ///
    /// # Safety
    /// จะต้องมี KV อื่นในทิศทางที่เดินทาง
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// ย้ายลีฟ edge แฮนเดิลไปยังลีฟก่อนหน้า edge และส่งคืนการอ้างอิงไปยังคีย์และค่าที่อยู่ระหว่าง
    ///
    ///
    /// # Safety
    /// จะต้องมี KV อื่นในทิศทางที่เดินทาง
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ย้ายจุดจับ edge ไปยังใบถัดไป edge และส่งคืนการอ้างอิงไปยังคีย์และค่าที่อยู่ระหว่าง
    ///
    ///
    /// # Safety
    /// จะต้องมี KV อื่นในทิศทางที่เดินทาง
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // การทำครั้งสุดท้ายเร็วกว่าตามเกณฑ์มาตรฐาน
        kv.into_kv_valmut()
    }

    /// ย้ายจุดจับ edge ไปยังใบก่อนหน้าและส่งคืนการอ้างอิงไปยังคีย์และค่าที่อยู่ระหว่าง
    ///
    ///
    /// # Safety
    /// จะต้องมี KV อื่นในทิศทางที่เดินทาง
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // การทำครั้งสุดท้ายเร็วกว่าตามเกณฑ์มาตรฐาน
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// ย้ายจุดจับ edge ไปยังใบถัดไป edge และส่งคืนคีย์และค่าที่อยู่ระหว่างการยกเลิกการจัดสรรโหนดใด ๆ ที่ทิ้งไว้ในขณะที่ปล่อย edge ที่เกี่ยวข้องไว้ในโหนดหลักที่ห้อยอยู่
    ///
    /// # Safety
    /// - จะต้องมี KV อื่นในทิศทางที่เดินทาง
    /// - KV นั้นไม่ได้ถูกส่งคืนก่อนหน้านี้โดย `next_back_unchecked` คู่กันในสำเนาของแฮนเดิลใด ๆ ที่ใช้เพื่อสำรวจต้นไม้
    ///
    /// วิธีเดียวที่ปลอดภัยในการดำเนินการกับแฮนเดิลที่อัปเดตคือการเปรียบเทียบปล่อยวางเรียกวิธีนี้อีกครั้งภายใต้เงื่อนไขความปลอดภัยหรือโทรหา `next_back_unchecked` คู่กันภายใต้เงื่อนไขความปลอดภัย
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// ย้ายลีฟ edge แฮนเดิลไปยังลีฟก่อนหน้า edge และส่งคืนคีย์และค่าที่อยู่ระหว่างการยกเลิกการจัดสรรโหนดใด ๆ ที่ทิ้งไว้ในขณะที่ออกจาก edge ที่เกี่ยวข้องในโหนดพาเรนต์ที่ห้อยอยู่
    ///
    /// # Safety
    /// - จะต้องมี KV อื่นในทิศทางที่เดินทาง
    /// - ใบนั้น edge ก่อนหน้านี้ไม่ได้ถูกส่งคืนโดย `next_unchecked` คู่กับสำเนาของที่จับใด ๆ ที่ใช้ในการสำรวจต้นไม้
    ///
    /// วิธีเดียวที่ปลอดภัยในการดำเนินการกับแฮนเดิลที่อัปเดตคือการเปรียบเทียบปล่อยวางเรียกวิธีนี้อีกครั้งภายใต้เงื่อนไขความปลอดภัยหรือโทรหา `next_unchecked` คู่กันภายใต้เงื่อนไขความปลอดภัย
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// ส่งกลับใบซ้ายสุด edge ในหรือใต้โหนดหรืออีกนัยหนึ่งคือ edge ที่คุณต้องใช้ก่อนเมื่อนำทางไปข้างหน้า (หรือสุดท้ายเมื่อนำทางย้อนกลับ)
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// ส่งคืนใบ edge ทางขวาสุดในหรือใต้โหนดหรืออีกนัยหนึ่งคือ edge ที่คุณต้องการล่าสุดเมื่อนำทางไปข้างหน้า (หรือก่อนอื่นเมื่อนำทางย้อนกลับ)
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// เยี่ยมชมโหนดลีฟและ KV ภายในตามลำดับคีย์จากน้อยไปหามากและยังเยี่ยมชมโหนดภายในโดยรวมในลำดับแรกเชิงลึกซึ่งหมายความว่าโหนดภายในจะนำหน้า KV แต่ละรายการและโหนดลูก
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// คำนวณจำนวนองค์ประกอบในแผนภูมิ (ย่อย)
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// ส่งคืนใบ edge ที่ใกล้เคียงที่สุดกับ KV สำหรับการนำทางไปข้างหน้า
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// ส่งกลับใบ edge ที่ใกล้เคียงที่สุดกับ KV สำหรับการนำทางย้อนกลับ
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}