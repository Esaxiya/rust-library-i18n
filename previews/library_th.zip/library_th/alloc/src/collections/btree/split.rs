use super::node::{ForceResult::*, Root};
use super::search::SearchResult::*;
use core::borrow::Borrow;

impl<K, V> Root<K, V> {
    /// คำนวณความยาวของต้นไม้ทั้งสองซึ่งเป็นผลมาจากการแบ่งคู่คีย์-ค่าที่แตกต่างกันตามจำนวนที่กำหนด
    ///
    pub fn calc_split_length(
        total_num: usize,
        root_a: &Root<K, V>,
        root_b: &Root<K, V>,
    ) -> (usize, usize) {
        let (length_a, length_b);
        if root_a.height() < root_b.height() {
            length_a = root_a.reborrow().calc_length();
            length_b = total_num - length_a;
            debug_assert_eq!(length_b, root_b.reborrow().calc_length());
        } else {
            length_b = root_b.reborrow().calc_length();
            length_a = total_num - length_b;
            debug_assert_eq!(length_a, root_a.reborrow().calc_length());
        }
        (length_a, length_b)
    }

    /// แยกต้นไม้ที่มีคู่คีย์-ค่าที่และหลังคีย์ที่กำหนด
    /// ผลลัพธ์จะมีความหมายก็ต่อเมื่อต้นไม้เรียงตามคีย์และถ้าลำดับของ `Q` สอดคล้องกับ `K`
    /// ถ้า `self` เคารพค่าคงที่ของต้นไม้ `BTreeMap` ทั้งหมดดังนั้นทั้ง `self` และต้นไม้ที่ส่งคืนจะเคารพค่าคงที่เหล่านั้น
    ///
    ///
    pub fn split_off<Q: ?Sized + Ord>(&mut self, key: &Q) -> Self
    where
        K: Borrow<Q>,
    {
        let left_root = self;
        let mut right_root = Root::new_pillar(left_root.height());
        let mut left_node = left_root.borrow_mut();
        let mut right_node = right_root.borrow_mut();

        loop {
            let mut split_edge = match left_node.search_node(key) {
                // คีย์จะไปที่ต้นไม้ที่ถูกต้อง
                Found(kv) => kv.left_edge(),
                GoDown(edge) => edge,
            };

            split_edge.move_suffix(&mut right_node);

            match (split_edge.force(), right_node.force()) {
                (Internal(edge), Internal(node)) => {
                    left_node = edge.descend();
                    right_node = node.first_edge().descend();
                }
                (Leaf(_), Leaf(_)) => break,
                _ => unreachable!(),
            }
        }

        left_root.fix_right_border();
        right_root.fix_left_border();
        right_root
    }

    /// สร้างต้นไม้ที่ประกอบด้วยโหนดว่าง
    fn new_pillar(height: usize) -> Self {
        let mut root = Root::new();
        for _ in 0..height {
            root.push_internal_level();
        }
        root
    }
}