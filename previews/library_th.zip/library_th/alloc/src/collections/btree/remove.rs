use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef};

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    /// ลบคู่คีย์-ค่าออกจากทรีและส่งคืนคู่นั้นตลอดจนใบ edge ที่ตรงกับคู่เดิมนั้น
    /// เป็นไปได้ว่าสิ่งนี้จะล้างโหนดรูทที่อยู่ภายในซึ่งผู้โทรควรปรากฏจากแผนที่ที่ถือต้นไม้
    /// ผู้โทรควรลดความยาวของแผนที่ด้วย
    ///
    pub fn remove_kv_tracking<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        match self.force() {
            Leaf(node) => node.remove_leaf_kv(handle_emptied_internal_root),
            Internal(node) => node.remove_internal_kv(handle_emptied_internal_root),
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    fn remove_leaf_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let (old_kv, mut pos) = self.remove();
        let len = pos.reborrow().into_node().len();
        if len < MIN_LEN {
            let idx = pos.idx();
            // เราต้องลืมประเภทย่อยชั่วคราวเนื่องจากไม่มีประเภทโหนดที่แตกต่างกันสำหรับผู้ปกครองในทันทีของใบไม้
            //
            let new_pos = match pos.into_node().forget_type().choose_parent_kv() {
                Ok(Left(left_parent_kv)) => {
                    debug_assert!(left_parent_kv.right_child_len() == MIN_LEN - 1);
                    if left_parent_kv.can_merge() {
                        left_parent_kv.merge_tracking_child_edge(Right(idx))
                    } else {
                        debug_assert!(left_parent_kv.left_child_len() > MIN_LEN);
                        left_parent_kv.steal_left(idx)
                    }
                }
                Ok(Right(right_parent_kv)) => {
                    debug_assert!(right_parent_kv.left_child_len() == MIN_LEN - 1);
                    if right_parent_kv.can_merge() {
                        right_parent_kv.merge_tracking_child_edge(Left(idx))
                    } else {
                        debug_assert!(right_parent_kv.right_child_len() > MIN_LEN);
                        right_parent_kv.steal_right(idx)
                    }
                }
                Err(pos) => unsafe { Handle::new_edge(pos, idx) },
            };
            // ความปลอดภัย: `new_pos` คือใบไม้ที่เราเริ่มต้นจากพี่น้อง
            pos = unsafe { new_pos.cast_to_leaf_unchecked() };

            // เฉพาะในกรณีที่เรารวมเข้าด้วยกันผู้ปกครอง (ถ้ามี) จะหดตัวลง แต่การข้ามขั้นตอนต่อไปนี้จะไม่ได้ผลในเกณฑ์มาตรฐาน
            //
            // ความปลอดภัย: เราจะไม่ทำลายหรือจัดเรียงใบไม้ใหม่ที่ `pos` อยู่ที่
            // โดยการจัดการแม่แบบซ้ำ ๆที่แย่ที่สุดเราจะทำลายหรือจัดเรียงพ่อแม่ใหม่ผ่านปู่ย่าตายายดังนั้นจึงเปลี่ยนลิงก์ไปยังผู้ปกครองที่อยู่ในใบไม้
            //
            //
            //
            if let Ok(parent) = unsafe { pos.reborrow_mut() }.into_node().ascend() {
                if !parent.into_node().forget_type().fix_node_and_affected_ancestors() {
                    handle_emptied_internal_root();
                }
            }
        }
        (old_kv, pos)
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    fn remove_internal_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        // ลบ KV ที่อยู่ติดกันออกจากใบไม้แล้วใส่กลับเข้าไปแทนที่องค์ประกอบที่เราถูกขอให้ลบ
        //
        // ต้องการ KV ที่อยู่ติดกันทางซ้ายด้วยเหตุผลที่ระบุไว้ใน `choose_parent_kv`
        let left_leaf_kv = self.left_edge().descend().last_leaf_edge().left_kv();
        let left_leaf_kv = unsafe { left_leaf_kv.ok().unwrap_unchecked() };
        let (left_kv, left_hole) = left_leaf_kv.remove_leaf_kv(handle_emptied_internal_root);

        // โหนดภายในอาจถูกขโมยหรือรวมเข้าด้วยกัน
        // ย้อนกลับไปทางขวาเพื่อค้นหาว่า KV ดั้งเดิมสิ้นสุดที่ใด
        let mut internal = unsafe { left_hole.next_kv().ok().unwrap_unchecked() };
        let old_kv = internal.replace_kv(left_kv.0, left_kv.1);
        let pos = internal.next_leaf_edge();
        (old_kv, pos)
    }
}