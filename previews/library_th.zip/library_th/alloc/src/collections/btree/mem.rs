use core::intrinsics;
use core::mem;
use core::ptr;

/// สิ่งนี้จะแทนที่ค่าหลังการอ้างอิงเฉพาะ `v` โดยการเรียกใช้ฟังก์ชันที่เกี่ยวข้อง
///
///
/// หาก panic เกิดขึ้นในการปิด `change` กระบวนการทั้งหมดจะถูกยกเลิก
#[allow(dead_code)] // เก็บไว้เป็นภาพประกอบและสำหรับการใช้งาน future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// สิ่งนี้จะแทนที่ค่าที่อยู่เบื้องหลังการอ้างอิงเฉพาะ `v` โดยการเรียกใช้ฟังก์ชันที่เกี่ยวข้องและส่งกลับผลลัพธ์ที่ได้รับระหว่างทาง
///
///
/// หาก panic เกิดขึ้นในการปิด `change` กระบวนการทั้งหมดจะถูกยกเลิก
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}