use backtrace::Backtrace;

// การทดสอบนี้ใช้ได้เฉพาะบนแพลตฟอร์มที่มีฟังก์ชัน `symbol_address` ที่ใช้งานได้สำหรับเฟรมที่รายงานที่อยู่เริ่มต้นของสัญลักษณ์
// ด้วยเหตุนี้จึงเปิดใช้งานบนแพลตฟอร์มเพียงไม่กี่แพลตฟอร์มเท่านั้น
//
const ENABLED: bool = cfg!(all(
    // Windows ยังไม่ได้รับการทดสอบจริง ๆ และ OSX ไม่รองรับการค้นหาเฟรมที่ปิดล้อมดังนั้นให้ปิดใช้งานสิ่งนี้
    //
    target_os = "linux",
    // บน ARM การค้นหาฟังก์ชั่นการปิดล้อมเป็นเพียงการส่งคืน ip เอง
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}