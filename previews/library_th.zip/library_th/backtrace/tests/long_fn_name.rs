use backtrace::Backtrace;

// ชื่อโมดูล 50 อักขระ
mod _234567890_234567890_234567890_234567890_234567890 {
    // ชื่อโครงสร้าง 50 อักขระ
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// ชื่อฟังก์ชันแบบยาวต้องถูกตัดให้เหลือ (MAX_SYM_NAME, 1) อักขระ
// รันการทดสอบนี้สำหรับ msvc เท่านั้นเนื่องจาก gnu พิมพ์ "<no info>" สำหรับเฟรมทั้งหมด
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // การทำซ้ำ 10 ครั้งของชื่อ struct ดังนั้นชื่อฟังก์ชันแบบเต็มจึงมีความยาวอย่างน้อย 10 *(50 + 50)* 2=2,000 อักขระ
    //
    // จริงๆแล้วมันยาวกว่าเนื่องจากมี `::`, `<>` และชื่อของโมดูลปัจจุบันด้วย
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}