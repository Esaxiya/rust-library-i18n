# backtrace-rs

[Documentation](https://docs.rs/backtrace)

ไลบรารีสำหรับการรับ backtraces ที่รันไทม์สำหรับ Rust
ไลบรารีนี้มีจุดมุ่งหมายเพื่อเพิ่มการสนับสนุนของไลบรารีมาตรฐานโดยจัดเตรียมอินเทอร์เฟซแบบเป็นโปรแกรมเพื่อใช้งานได้ แต่ยังรองรับการพิมพ์ backtrace ปัจจุบันได้อย่างง่ายดายเช่น panics ของ libstd

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

หากต้องการจับภาพย้อนหลังและเลื่อนการรับมือไปในภายหลังคุณสามารถใช้ประเภท `Backtrace` ระดับบนสุดได้

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

อย่างไรก็ตามหากคุณต้องการเข้าถึงฟังก์ชันการติดตามที่แท้จริงมากขึ้นคุณสามารถใช้ฟังก์ชัน `trace` และ `resolve` ได้โดยตรง

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // แก้ไขตัวชี้คำสั่งนี้เป็นชื่อสัญลักษณ์
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // ไปที่เฟรมถัดไป
    });
}
```

# License

โครงการนี้ได้รับอนุญาตภายใต้ข้อใดข้อหนึ่ง

 * Apache License, เวอร์ชัน 2.0, ([LICENSE-APACHE](LICENSE-APACHE) หรือ http://www.apache.org/licenses/LICENSE-2.0)
 * ใบอนุญาต MIT ([LICENSE-MIT](LICENSE-MIT) หรือ http://opensource.org/licenses/MIT)

ตามตัวเลือกของคุณ

### Contribution

เว้นแต่คุณจะระบุไว้เป็นอย่างอื่นอย่างชัดเจนการมีส่วนร่วมใด ๆ ที่ส่งโดยเจตนาเพื่อรวมไว้ใน backtrace-rs โดยคุณตามที่กำหนดไว้ในใบอนุญาต Apache-2.0 จะต้องได้รับใบอนุญาตเป็นคู่ตามข้างต้นโดยไม่มีข้อกำหนดหรือเงื่อนไขเพิ่มเติมใด ๆ







