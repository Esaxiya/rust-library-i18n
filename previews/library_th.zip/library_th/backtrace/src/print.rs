#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// ฟอร์แมตเตอร์สำหรับการย้อนกลับ
///
/// ประเภทนี้สามารถใช้เพื่อพิมพ์ backtrace ได้ไม่ว่า backtrace จะมาจากที่ใดก็ตาม
/// หากคุณมีประเภท `Backtrace` การใช้งาน `Debug` จะใช้รูปแบบการพิมพ์นี้อยู่แล้ว
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// รูปแบบของการพิมพ์ที่เราสามารถพิมพ์ได้
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// พิมพ์ backtrace terser ซึ่งมีเฉพาะข้อมูลที่เกี่ยวข้องเท่านั้น
    Short,
    /// พิมพ์ backtrace ที่มีข้อมูลที่เป็นไปได้ทั้งหมด
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// สร้าง `BacktraceFmt` ใหม่ซึ่งจะเขียนเอาต์พุตไปยัง `fmt` ที่ให้มา
    ///
    /// อาร์กิวเมนต์ `format` จะควบคุมสไตล์ที่พิมพ์ backtrace และอาร์กิวเมนต์ `print_path` จะใช้เพื่อพิมพ์อินสแตนซ์ `BytesOrWideString` ของชื่อไฟล์
    /// ประเภทนี้ไม่ได้พิมพ์ชื่อไฟล์ใด ๆ แต่จำเป็นต้องเรียกกลับนี้
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// พิมพ์คำนำหน้าสำหรับ backtrace ที่กำลังจะพิมพ์
    ///
    /// สิ่งนี้จำเป็นสำหรับบางแพลตฟอร์มเพื่อให้ backtraces เป็นสัญลักษณ์อย่างสมบูรณ์ในภายหลังมิฉะนั้นนี่ควรเป็นวิธีแรกที่คุณเรียกใช้หลังจากสร้าง `BacktraceFmt`
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// เพิ่มเฟรมให้กับเอาต์พุต backtrace
    ///
    /// การกระทำนี้ส่งคืนอินสแตนซ์ RAII ของ `BacktraceFrameFmt` ซึ่งสามารถใช้ในการพิมพ์เฟรมได้จริงและเมื่อทำลายมันจะเพิ่มตัวนับเฟรม
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// เสร็จสิ้นการส่งออก backtrace
    ///
    /// ขณะนี้ยังไม่มีการดำเนินการ แต่ถูกเพิ่มเข้ามาสำหรับความเข้ากันได้ของ future กับรูปแบบ backtrace
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // ขณะนี้ไม่มีการดำเนินการ-รวมถึง hook นี้เพื่อให้สามารถเพิ่ม future ได้
        Ok(())
    }
}

/// ฟอร์แมตเตอร์สำหรับ backtrace เพียงเฟรมเดียว
///
/// ประเภทนี้สร้างขึ้นโดยฟังก์ชัน `BacktraceFmt::frame`
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// พิมพ์ `BacktraceFrame` ด้วยตัวจัดรูปแบบเฟรมนี้
    ///
    /// การดำเนินการนี้จะพิมพ์อินสแตนซ์ `BacktraceSymbol` ทั้งหมดซ้ำภายใน `BacktraceFrame`
    ///
    /// # คุณสมบัติที่จำเป็น
    ///
    /// ฟังก์ชันนี้ต้องการคุณสมบัติ `std` ของ `backtrace` crate เพื่อเปิดใช้งานและคุณลักษณะ `std` จะเปิดใช้งานตามค่าเริ่มต้น
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// พิมพ์ `BacktraceSymbol` ภายใน `BacktraceFrame`
    ///
    /// # คุณสมบัติที่จำเป็น
    ///
    /// ฟังก์ชันนี้ต้องการคุณสมบัติ `std` ของ `backtrace` crate เพื่อเปิดใช้งานและคุณลักษณะ `std` จะเปิดใช้งานตามค่าเริ่มต้น
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: นี่ไม่ใช่เรื่องดีที่เราจะไม่พิมพ์อะไรเลย
            // ด้วยชื่อไฟล์ที่ไม่ใช่ utf8
            // โชคดีที่เกือบทุกอย่างคือ utf8 ดังนั้นสิ่งนี้ไม่ควรเลวร้ายเกินไป
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// พิมพ์ Raw Traced `Frame` และ `Symbol` โดยทั่วไปจากภายในการเรียกกลับแบบดิบของ crate นี้
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// เพิ่มเฟรมดิบให้กับเอาต์พุต backtrace
    ///
    /// วิธีนี้ไม่เหมือนก่อนหน้านี้คือใช้อาร์กิวเมนต์ดิบในกรณีที่เป็นแหล่งที่มาจากสถานที่ต่างกัน
    /// โปรดทราบว่าสิ่งนี้อาจเรียกได้หลายครั้งสำหรับหนึ่งเฟรม
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// เพิ่มเฟรมดิบให้กับเอาต์พุต backtrace รวมถึงข้อมูลคอลัมน์
    ///
    /// วิธีนี้เช่นเดียวกับวิธีก่อนหน้านี้ใช้อาร์กิวเมนต์ดิบในกรณีที่เป็นแหล่งที่มาจากสถานที่ต่างๆ
    /// โปรดทราบว่าสิ่งนี้อาจเรียกได้หลายครั้งสำหรับหนึ่งเฟรม
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia ไม่สามารถเป็นสัญลักษณ์ภายในกระบวนการได้ดังนั้นจึงมีรูปแบบพิเศษที่สามารถใช้เพื่อเป็นสัญลักษณ์ในภายหลังได้
        // พิมพ์แทนการพิมพ์ที่อยู่ในรูปแบบของเราเองที่นี่
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // ไม่จำเป็นต้องพิมพ์เฟรม "null" โดยทั่วไปหมายความว่าระบบ backtrace กระตือรือร้นที่จะติดตามย้อนกลับไปไกลมาก
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // เพื่อลดขนาด TCB ในวงล้อม Sgx เราไม่ต้องการใช้ฟังก์ชันการแก้ปัญหาสัญลักษณ์
        // แต่เราสามารถพิมพ์ออฟเซ็ตของที่อยู่ได้ที่นี่ซึ่งสามารถแมปในภายหลังเพื่อแก้ไขฟังก์ชันได้
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // พิมพ์ดัชนีของเฟรมรวมทั้งตัวชี้คำสั่งเสริมของเฟรม
        // หากเราอยู่นอกเหนือสัญลักษณ์แรกของเฟรมนี้แม้ว่าเราจะพิมพ์ช่องว่างที่เหมาะสม
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // ถัดไปเขียนชื่อสัญลักษณ์โดยใช้การจัดรูปแบบทางเลือกสำหรับข้อมูลเพิ่มเติมหากเราเป็น backtrace แบบเต็ม
        // นอกจากนี้เรายังจัดการกับสัญลักษณ์ที่ไม่มีชื่อ
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // สุดท้ายพิมพ์หมายเลข filename/line หากมี
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line จะพิมพ์เป็นเส้นใต้ชื่อสัญลักษณ์ดังนั้นให้พิมพ์ช่องว่างที่เหมาะสมเพื่อจัดเรียงตัวเราให้ชิดขวา
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // มอบหมายให้โทรกลับภายในของเราเพื่อพิมพ์ชื่อไฟล์จากนั้นพิมพ์หมายเลขบรรทัด
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // เพิ่มหมายเลขคอลัมน์ถ้ามี
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // เราสนใจเฉพาะสัญลักษณ์แรกของเฟรมเท่านั้น
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}