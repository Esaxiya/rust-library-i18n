use core::ffi::c_void;
use core::fmt;

/// ตรวจสอบ call-stack ปัจจุบันส่งผ่านเฟรมที่ใช้งานอยู่ทั้งหมดไปยังการปิดที่จัดเตรียมไว้เพื่อคำนวณการติดตามสแต็ก
///
/// ฟังก์ชันนี้เป็นส่วนสำคัญของไลบรารีนี้ในการคำนวณสแต็กเทรซสำหรับโปรแกรมการปิด `cb` ที่กำหนดให้เป็นอินสแตนซ์ของ `Frame` ซึ่งแสดงถึงข้อมูลเกี่ยวกับ call frame นั้นบนสแต็ก
/// การปิดจะให้เฟรมในรูปแบบจากบนลงล่าง (ล่าสุดเรียกว่าฟังก์ชันก่อน)
///
/// ค่าการส่งคืนของการปิดเป็นการบ่งชี้ว่าควรมีการติดตามย้อนหลังหรือไม่ค่าส่งคืน `false` จะยุติการติดตามย้อนกลับและส่งคืนทันที
///
/// เมื่อได้รับ `Frame` แล้วคุณอาจต้องการเรียก `backtrace::resolve` เพื่อแปลง `ip` (ตัวชี้คำสั่ง) หรือที่อยู่สัญลักษณ์เป็น `Symbol` ซึ่งสามารถเรียนรู้ชื่อและ/หรือชื่อไฟล์/หมายเลขบรรทัดได้
///
///
/// โปรดทราบว่านี่เป็นฟังก์ชั่นระดับค่อนข้างต่ำและหากคุณต้องการจับภาพ backtrace เพื่อตรวจสอบในภายหลังประเภท `Backtrace` อาจเหมาะสมกว่า
///
/// # คุณสมบัติที่จำเป็น
///
/// ฟังก์ชันนี้ต้องการคุณสมบัติ `std` ของ `backtrace` crate เพื่อเปิดใช้งานและคุณลักษณะ `std` จะเปิดใช้งานตามค่าเริ่มต้น
///
/// # Panics
///
/// ฟังก์ชันนี้มุ่งมั่นที่จะไม่ใช้ panic แต่ถ้า `cb` ให้ panics แล้วบางแพลตฟอร์มจะบังคับให้ panic สองเท่าเพื่อยกเลิกกระบวนการ
/// บางแพลตฟอร์มใช้ไลบรารี C ซึ่งใช้การโทรกลับภายในซึ่งไม่สามารถคลายออกได้ดังนั้นการตื่นตระหนกจาก `cb` อาจทำให้กระบวนการยกเลิก
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // ดำเนินการ backtrace ต่อไป
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// เช่นเดียวกับ `trace` ไม่ปลอดภัยเนื่องจากไม่ได้ซิงโครไนซ์
///
/// ฟังก์ชั่นนี้ไม่มี guarentees การซิงโครไนซ์ แต่จะพร้อมใช้งานเมื่อคุณสมบัติ `std` ของ crate นี้ไม่ได้คอมไพล์
/// ดูฟังก์ชัน `trace` สำหรับเอกสารและตัวอย่างเพิ่มเติม
///
/// # Panics
///
/// ดูข้อมูลเกี่ยวกับ `trace` สำหรับข้อควรระวังในการตื่นตระหนกของ `cb`
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// A trait แทนเฟรมหนึ่งของ backtrace ซึ่งให้ผลกับฟังก์ชัน `trace` ของ crate นี้
///
/// การปิดฟังก์ชั่นการติดตามจะได้รับเฟรมและเฟรมจะถูกส่งไปแทบทุกครั้งเนื่องจากการใช้งานที่เป็นพื้นฐานไม่เป็นที่รู้จักเสมอไปจนกว่าจะถึงรันไทม์
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// ส่งกลับตัวชี้คำสั่งปัจจุบันของเฟรมนี้
    ///
    /// โดยปกติจะเป็นคำสั่งถัดไปในการดำเนินการในเฟรม แต่การใช้งานทั้งหมดไม่ได้แสดงรายการนี้ด้วยความแม่นยำ 100% (แต่โดยทั่วไปแล้วจะค่อนข้างใกล้เคียง)
    ///
    ///
    /// ขอแนะนำให้ส่งค่านี้ไปที่ `backtrace::resolve` เพื่อเปลี่ยนเป็นชื่อสัญลักษณ์
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// ส่งกลับตัวชี้สแต็กปัจจุบันของเฟรมนี้
    ///
    /// ในกรณีที่แบ็กเอนด์ไม่สามารถกู้คืนตัวชี้สแต็กสำหรับเฟรมนี้ได้จะมีการส่งคืนตัวชี้ค่าว่าง
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// ส่งกลับที่อยู่สัญลักษณ์เริ่มต้นของเฟรมของฟังก์ชันนี้
    ///
    /// สิ่งนี้จะพยายามย้อนกลับตัวชี้คำสั่งที่ส่งกลับโดย `ip` ไปยังจุดเริ่มต้นของฟังก์ชันโดยส่งคืนค่านั้น
    ///
    /// อย่างไรก็ตามในบางกรณีแบ็กเอนด์จะคืนค่า `ip` จากฟังก์ชันนี้
    ///
    /// บางครั้งสามารถใช้ค่าที่ส่งคืนได้หาก `backtrace::resolve` ล้มเหลวใน `ip` ที่ระบุไว้ข้างต้น
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// ส่งคืนที่อยู่ฐานของโมดูลที่เป็นของเฟรม
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // สิ่งนี้ต้องมาก่อนเพื่อให้แน่ใจว่า Miri มีลำดับความสำคัญเหนือแพลตฟอร์มโฮสต์
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // ใช้เฉพาะในสัญลักษณ์ dbghelp
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}