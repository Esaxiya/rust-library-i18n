//! โมดูลที่ช่วยในการจัดการการรวม dbghelp บน Windows
//!
//! Backtraces บน Windows (อย่างน้อยสำหรับ MSVC) ส่วนใหญ่ขับเคลื่อนผ่าน `dbghelp.dll` และฟังก์ชันต่างๆที่มีอยู่
//! ขณะนี้ฟังก์ชันเหล่านี้ถูกโหลด *แบบไดนามิก* แทนที่จะเชื่อมโยงกับ `dbghelp.dll` แบบคงที่
//! ปัจจุบันไลบรารีมาตรฐานทำได้ (และตามทฤษฎีแล้ว) แต่เป็นความพยายามที่จะช่วยลดการพึ่งพา dll แบบคงที่ของไลบรารีเนื่องจากการย้อนกลับมักเป็นทางเลือกที่ดี
//!
//! ดังที่กล่าวไว้ `dbghelp.dll` มักจะโหลดบน Windows ได้สำเร็จ
//!
//! โปรดทราบว่าเนื่องจากเรากำลังโหลดการสนับสนุนทั้งหมดนี้แบบไดนามิกเราจึงไม่สามารถใช้นิยามดิบใน `winapi` ได้ แต่เราจำเป็นต้องกำหนดตัวชี้ฟังก์ชันให้พิมพ์ตัวเองและใช้สิ่งนั้น
//! เราไม่ต้องการอยู่ในธุรกิจของการทำสำเนา winapi ดังนั้นเราจึงมีคุณลักษณะ Cargo `verify-winapi` ซึ่งยืนยันว่าการผูกทั้งหมดตรงกับที่อยู่ใน winapi และคุณลักษณะนี้เปิดใช้งานบน CI
//!
//! สุดท้ายคุณจะทราบว่า dll สำหรับ `dbghelp.dll` จะไม่ถูกยกเลิกการโหลดและนั่นเป็นความตั้งใจในขณะนี้
//! แนวคิดคือเราสามารถแคชได้ทั่วโลกและใช้ระหว่างการโทรไปยัง API โดยหลีกเลี่ยง loads/unloads ที่มีราคาแพง
//! หากนี่เป็นปัญหาสำหรับเครื่องตรวจจับการรั่วไหลหรืออะไรทำนองนั้นเราสามารถข้ามสะพานได้เมื่อไปถึงที่นั่น
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// หลีกเลี่ยง `SymGetOptions` และ `SymSetOptions` ที่ไม่มีอยู่ใน winapi เอง
// มิฉะนั้นจะใช้เฉพาะเมื่อเราตรวจสอบประเภท winapi ซ้ำ
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // ยังไม่ได้กำหนดไว้ใน winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // สิ่งนี้ถูกกำหนดใน winapi แต่ไม่ถูกต้อง (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // ยังไม่ได้กำหนดไว้ใน winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// มาโครนี้ใช้เพื่อกำหนดโครงสร้าง `Dbghelp` ซึ่งภายในมีตัวชี้ฟังก์ชันทั้งหมดที่เราอาจโหลด
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// DLL ที่โหลดสำหรับ `dbghelp.dll`
            dll: HMODULE,

            // ตัวชี้ฟังก์ชันแต่ละตัวสำหรับแต่ละฟังก์ชันที่เราอาจใช้
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // เริ่มแรกเรายังไม่ได้โหลด DLL
            dll: 0 as *mut _,
            // Initiall ฟังก์ชันทั้งหมดถูกตั้งค่าเป็นศูนย์เพื่อบอกว่าต้องโหลดแบบไดนามิก
            //
            $($name: 0,)*
        };

        // พิมพ์ดีดที่สะดวกสำหรับแต่ละประเภทฟังก์ชั่น
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// พยายามเปิด `dbghelp.dll`
            /// ส่งคืนความสำเร็จหากทำงานหรือเกิดข้อผิดพลาดหาก `LoadLibraryW` ล้มเหลว
            ///
            /// Panics ถ้าไลบรารีโหลดแล้ว
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // ฟังก์ชันสำหรับแต่ละวิธีที่เราต้องการใช้
            // เมื่อเรียกมันจะอ่านตัวชี้ฟังก์ชันแคชหรือโหลดและส่งคืนค่าที่โหลด
            // การโหลดจะถูกยืนยันว่าจะประสบความสำเร็จ
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // พร็อกซีที่สะดวกในการใช้ล็อกการล้างข้อมูลเพื่ออ้างอิงฟังก์ชัน dbghelp
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// เริ่มต้นการสนับสนุนทั้งหมดที่จำเป็นในการเข้าถึงฟังก์ชัน `dbghelp` API จาก crate นี้
///
///
/// โปรดทราบว่าฟังก์ชันนี้ **ปลอดภัย** มีการซิงโครไนซ์ภายในของตัวเอง
/// นอกจากนี้โปรดทราบว่าการเรียกใช้ฟังก์ชันนี้ซ้ำหลาย ๆ ครั้งสามารถทำได้อย่างปลอดภัย
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // สิ่งแรกที่เราต้องทำคือการซิงโครไนซ์ฟังก์ชันนี้สิ่งนี้สามารถเรียกพร้อมกันจากเธรดอื่นหรือเรียกซ้ำภายในเธรดเดียว
        // โปรดทราบว่ามันยากกว่านั้นเพราะสิ่งที่เราใช้อยู่ที่นี่ `dbghelp`,*ยัง* จำเป็นต้องซิงโครไนซ์กับผู้โทรอื่น ๆ ทั้งหมดไปที่ `dbghelp` ในกระบวนการนี้
        //
        // โดยปกติแล้วจะมีการเรียก `dbghelp` ไม่มากนักในกระบวนการเดียวกันและเราอาจสันนิษฐานได้อย่างปลอดภัยว่าเราเป็นเพียงคนเดียวที่เข้าถึงได้
        // อย่างไรก็ตามมีผู้ใช้หลักอีกคนหนึ่งที่เราต้องกังวลว่าตัวไหนเป็นเรื่องแดกดัน แต่อยู่ในไลบรารีมาตรฐาน
        // ไลบรารีมาตรฐาน Rust ขึ้นอยู่กับ crate นี้สำหรับการสนับสนุน backtrace และ crate นี้ยังมีอยู่ใน crates.io
        // ซึ่งหมายความว่าหากไลบรารีมาตรฐานกำลังพิมพ์ panic backtrace มันอาจแข่งกับ crate ที่มาจาก crates.io ทำให้เกิดการแยกส่วน
        //
        // เพื่อช่วยแก้ปัญหาการซิงโครไนซ์นี้เราใช้เคล็ดลับเฉพาะของ Windows ที่นี่ (นั่นคือข้อ จำกัด เฉพาะของ Windows เกี่ยวกับการซิงโครไนซ์)
        // เราสร้าง *session-local* ชื่อ mutex เพื่อป้องกันการโทรนี้
        // ความตั้งใจที่นี่คือไลบรารีมาตรฐานและ crate นี้ไม่จำเป็นต้องแชร์ API ระดับ Rust เพื่อซิงโครไนซ์ที่นี่ แต่สามารถทำงานเบื้องหลังแทนเพื่อให้แน่ใจว่าพวกเขาซิงโครไนซ์กัน
        //
        // ด้วยวิธีนี้เมื่อเรียกใช้ฟังก์ชันนี้ผ่านไลบรารีมาตรฐานหรือผ่าน crates.io เราสามารถมั่นใจได้ว่าจะได้รับ mutex เดียวกัน
        //
        // ทั้งหมดนี้คือการบอกว่าสิ่งแรกที่เราทำที่นี่คือเราสร้าง `HANDLE` แบบอะตอมซึ่งเป็นชื่อ mutex บน Windows
        // เราซิงโครไนซ์บิตกับเธรดอื่น ๆ ที่แบ่งปันฟังก์ชันนี้โดยเฉพาะและตรวจสอบให้แน่ใจว่ามีการสร้างเพียงจุดจับเดียวต่ออินสแตนซ์ของฟังก์ชันนี้
        // โปรดทราบว่าที่จับจะไม่ปิดทันทีที่เก็บไว้ในส่วนกลาง
        //
        // หลังจากที่เราไปล็อคจริงเราก็ได้มาและด้ามจับ `Init` ของเราที่เรามอบให้จะต้องรับผิดชอบในการทิ้งมันในที่สุด
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // โอเคว้าว!ตอนนี้เราทุกคนซิงโครไนซ์อย่างปลอดภัยแล้วเรามาเริ่มประมวลผลทุกอย่างกันเลย
        // ก่อนอื่นเราต้องตรวจสอบให้แน่ใจว่า `dbghelp.dll` ถูกโหลดจริงในกระบวนการนี้
        // เราทำสิ่งนี้แบบไดนามิกเพื่อหลีกเลี่ยงการพึ่งพาแบบคงที่
        // ในอดีตมีการทำเช่นนี้เพื่อแก้ไขปัญหาการเชื่อมโยงแปลก ๆ และมีจุดมุ่งหมายเพื่อทำให้ไบนารีพกพาได้ง่ายขึ้นเนื่องจากส่วนใหญ่เป็นเพียงยูทิลิตี้การดีบัก
        //
        //
        // เมื่อเราเปิด `dbghelp.dll` แล้วเราจำเป็นต้องเรียกใช้ฟังก์ชันการเริ่มต้นบางอย่างในนั้นและมีรายละเอียดเพิ่มเติมด้านล่าง
        // เราทำสิ่งนี้เพียงครั้งเดียวดังนั้นเราจึงมีบูลีนส่วนกลางที่ระบุว่าเราทำเสร็จแล้วหรือยัง
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // ตรวจสอบให้แน่ใจว่าได้ตั้งค่าสถานะ `SYMOPT_DEFERRED_LOADS` แล้วเนื่องจากตามเอกสารของ MSVC เกี่ยวกับสิ่งนี้: "This is the fastest, most efficient way to use the symbol handler." งั้นมาทำกัน!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // เริ่มต้นสัญลักษณ์ด้วย MSVCโปรดทราบว่าสิ่งนี้อาจล้มเหลว แต่เราเพิกเฉย
        // ไม่มีงานศิลปะก่อนหน้านี้มากมายสำหรับสิ่งนี้ แต่ LLVM ภายในดูเหมือนจะเพิกเฉยต่อค่าส่งคืนที่นี่และหนึ่งในไลบรารีเจลทำความสะอาดใน LLVM พิมพ์คำเตือนที่น่ากลัวหากสิ่งนี้ล้มเหลว แต่โดยทั่วไปแล้วจะเพิกเฉยในระยะยาว
        //
        //
        // กรณีหนึ่งที่เกิดขึ้นมากสำหรับ Rust คือไลบรารีมาตรฐานและ crate บน crates.io ทั้งคู่ต้องการแข่งขันเพื่อ `SymInitializeW`
        // ในอดีตไลบรารีมาตรฐานต้องการเริ่มต้นจากนั้นล้างข้อมูลเกือบตลอดเวลา แต่ตอนนี้ใช้ crate นี้หมายความว่าจะมีคนเริ่มต้นก่อนและอีกคนจะรับการเริ่มต้นนั้น
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}