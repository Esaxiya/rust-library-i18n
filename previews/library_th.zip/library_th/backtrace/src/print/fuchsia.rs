use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr รับการเรียกกลับที่จะรับตัวชี้ dl_phdr_info สำหรับ DSO ทุกตัวที่เชื่อมโยงเข้ากับกระบวนการ
    // dl_iterate_phdr ยังช่วยให้แน่ใจว่าตัวเชื่อมโยงแบบไดนามิกถูกล็อกตั้งแต่ต้นจนจบการทำซ้ำ
    // หากการเรียกกลับส่งคืนค่าที่ไม่ใช่ศูนย์การทำซ้ำจะถูกยกเลิกก่อนกำหนด
    // 'data' จะถูกส่งเป็นอาร์กิวเมนต์ที่สามไปยังการเรียกกลับในแต่ละการโทร
    // 'size' ให้ขนาดของ dl_phdr_info
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// เราจำเป็นต้องแยกวิเคราะห์รหัสการสร้างและข้อมูลส่วนหัวของโปรแกรมพื้นฐานซึ่งหมายความว่าเราต้องการข้อมูลเล็กน้อยจากข้อมูลจำเพาะของ ELF เช่นกัน
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// ตอนนี้เราต้องทำซ้ำบิตต่อบิตโครงสร้างของประเภท dl_phdr_info ที่ใช้โดยตัวเชื่อมโยงไดนามิกปัจจุบันของ fuchsia
// Chromium ยังมีขอบเขต ABI นี้เช่นเดียวกับ Crashpad
// ในที่สุดเราต้องการย้ายกรณีเหล่านี้ไปใช้ elf-search แต่เราจำเป็นต้องระบุใน SDK และยังไม่ได้ดำเนินการ
//
// ดังนั้นเรา (และพวกเขา) จึงติดอยู่ที่ต้องใช้วิธีนี้ซึ่งทำให้เกิดการมีเพศสัมพันธ์ที่แน่นหนากับ fuchsia libc
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // เราไม่มีทางรู้ได้เลยว่า e_phoff และ e_phnum ถูกต้องหรือไม่
    // libc ควรมั่นใจในสิ่งนี้สำหรับเราอย่างไรก็ตามจึงปลอดภัยที่จะสร้างชิ้นส่วนที่นี่
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr แสดงส่วนหัวของโปรแกรม ELF 64 บิตในส่วนท้ายของสถาปัตยกรรมเป้าหมาย
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr แสดงส่วนหัวของโปรแกรม ELF ที่ถูกต้องและเนื้อหา
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // เราไม่มีวิธีตรวจสอบว่า p_addr หรือ p_memsz ถูกต้องหรือไม่
    // Libc ของ Fuchsia จะแยกวิเคราะห์โน้ตก่อนอย่างไรก็ตามโดยอาศัยเหตุผลที่อยู่ที่นี่ส่วนหัวเหล่านี้จะต้องถูกต้อง
    //
    // NoteIter ไม่ต้องการให้ข้อมูลพื้นฐานถูกต้อง แต่ต้องมีขอบเขตที่ถูกต้อง
    // เราเชื่อว่า libc มั่นใจได้ว่านี่เป็นกรณีของเราที่นี่
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// ประเภทบันทึกย่อสำหรับรหัสการสร้าง
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr แสดงถึงส่วนหัวของโน้ต ELF ในส่วนท้ายของเป้าหมาย
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// หมายเหตุหมายถึงบันทึกย่อของ ELF (ส่วนหัว + เนื้อหา)
// ชื่อจะถูกปล่อยให้เป็นชิ้น u8 เนื่องจากไม่ได้ถูกยกเลิกด้วยค่าว่างเสมอไปและ rust ทำให้ง่ายพอที่จะตรวจสอบว่าไบต์นั้นตรงกันทั้งสองทางหรือไม่
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter ช่วยให้คุณสามารถทำซ้ำได้อย่างปลอดภัยในส่วนบันทึกย่อ
// จะสิ้นสุดทันทีที่เกิดข้อผิดพลาดหรือไม่มีบันทึกเพิ่มเติม
// หากคุณวนซ้ำข้อมูลที่ไม่ถูกต้องข้อมูลจะทำงานเหมือนกับว่าไม่พบบันทึกย่อ
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // เป็นค่าคงที่ของฟังก์ชันที่ตัวชี้และขนาดที่กำหนดแสดงถึงช่วงไบต์ที่ถูกต้องซึ่งทั้งหมดสามารถอ่านได้
    // เนื้อหาของไบต์เหล่านี้อาจเป็นอะไรก็ได้ แต่ต้องเป็นช่วงที่ถูกต้องเพื่อให้ปลอดภัย
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to จัดแนว 'x' เป็น 'ถึง' การจัดตำแหน่งไบต์โดยสมมติว่า 'to' เป็นกำลัง 2
// สิ่งนี้เป็นไปตามรูปแบบมาตรฐานในรหัสการแยกวิเคราะห์ C/C ++ ELF โดยใช้ (x + ถึง 1)&-to
// Rust ไม่อนุญาตให้คุณลบล้างการใช้งานดังนั้นฉันจึงใช้
// 2's-complement Conversion เพื่อสร้างสิ่งนั้นขึ้นมาใหม่
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 ใช้จำนวนไบต์จากสไลซ์ (ถ้ามี) และยังช่วยให้มั่นใจได้ว่าสไลซ์สุดท้ายได้รับการจัดแนวอย่างเหมาะสม
// หากจำนวนไบต์ที่ร้องขอมีขนาดใหญ่เกินไปหรือไม่สามารถจัดเรียงชิ้นส่วนใหม่ได้ในภายหลังเนื่องจากมีจำนวนไบต์ที่เหลืออยู่ไม่เพียงพอจะไม่มีการส่งคืนและไม่มีการแก้ไขสไลซ์
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// ฟังก์ชันนี้ไม่มีค่าคงที่ที่แท้จริงที่ผู้เรียกต้องรักษาไว้นอกเหนือจากที่ 'bytes' ควรจะจัดแนวเพื่อประสิทธิภาพ (และความถูกต้องของสถาปัตยกรรมบางอย่าง)
// ค่าในฟิลด์ Elf_Nhdr อาจเป็นเรื่องไร้สาระ แต่ฟังก์ชันนี้จะไม่รับประกันสิ่งนั้น
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // สิ่งนี้ปลอดภัยตราบเท่าที่มีพื้นที่เพียงพอและเราเพิ่งยืนยันว่าในคำสั่ง if ด้านบนดังนั้นสิ่งนี้ไม่ควรจะไม่ปลอดภัย
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // โปรดทราบว่า sice_of: :<Elf_Nhdr>() จัดเรียงเป็น 4 ไบต์เสมอ
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // ตรวจสอบว่าเรามาถึงจุดสิ้นสุดแล้วหรือยัง
        if self.base.len() == 0 || self.error {
            return None;
        }
        // เราถ่ายทอด nhdr ออกมา แต่เราพิจารณาโครงสร้างผลลัพธ์อย่างรอบคอบ
        // เราไม่เชื่อถือ namesz หรือ descsz และเราไม่มีการตัดสินใจที่ไม่ปลอดภัยตามประเภท
        //
        // ดังนั้นแม้ว่าเราจะกำจัดขยะออกไปหมดแล้วเราก็ยังปลอดภัย
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// ระบุว่าเซ็กเมนต์สามารถเรียกใช้งานได้
const PERM_X: u32 = 0b00000001;
/// ระบุว่าเซ็กเมนต์สามารถเขียนได้
const PERM_W: u32 = 0b00000010;
/// ระบุว่าเซ็กเมนต์สามารถอ่านได้
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// แสดงเซกเมนต์ ELF ที่รันไทม์
struct Segment {
    /// ให้ที่อยู่เสมือนรันไทม์ของเนื้อหาของเซ็กเมนต์นี้
    addr: usize,
    /// กำหนดขนาดหน่วยความจำของเนื้อหาของส่วนนี้
    size: usize,
    /// ให้ที่อยู่เสมือนโมดูลของส่วนนี้ด้วยไฟล์ ELF
    mod_rel_addr: usize,
    /// ให้สิทธิ์ที่พบในไฟล์ ELF
    /// อย่างไรก็ตามสิทธิ์เหล่านี้ไม่จำเป็นต้องเป็นสิทธิ์ที่มีอยู่ในรันไทม์
    flags: Perm,
}

/// ให้คนหนึ่งทำซ้ำส่วนต่างๆจาก DSO
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// แสดงถึง ELF DSO (Dynamic Shared Object)
/// ประเภทนี้อ้างอิงข้อมูลที่จัดเก็บใน DSO จริงแทนที่จะทำสำเนาของตัวเอง
struct Dso<'a> {
    /// ตัวเชื่อมโยงแบบไดนามิกจะตั้งชื่อให้เราเสมอแม้ว่าชื่อจะว่างเปล่าก็ตาม
    /// ในกรณีของไฟล์ปฏิบัติการหลักชื่อนี้จะว่างเปล่า
    /// ในกรณีของออบเจ็กต์ที่ใช้ร่วมกันจะเป็น soname (ดู DT_SONAME)
    name: &'a str,
    /// ใน Fuchsia ไบนารีเกือบทั้งหมดมีรหัสการสร้าง แต่นี่ไม่ใช่ข้อกำหนดที่เข้มงวด
    /// ไม่มีทางที่จะจับคู่ข้อมูล DSO กับไฟล์ ELF จริงได้ในภายหลังหากไม่มี build_id ดังนั้นเราจึงต้องการให้ DSO ทุกตัวมีที่นี่
    ///
    /// DSO ที่ไม่มี build_id จะถูกละเว้น
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// ส่งคืนตัววนซ้ำเหนือเซ็กเมนต์ใน DSO นี้
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// ข้อผิดพลาดเหล่านี้เข้ารหัสปัญหาที่เกิดขึ้นขณะแยกวิเคราะห์ข้อมูลเกี่ยวกับ DSO แต่ละรายการ
///
enum Error {
    /// NameError หมายความว่าเกิดข้อผิดพลาดขณะแปลงสตริงสไตล์ C เป็นสตริง rust
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError หมายความว่าเราไม่พบรหัสรุ่น
    /// อาจเป็นเพราะ DSO ไม่มีรหัสบิวด์หรือเนื่องจากเซ็กเมนต์ที่มีรหัสบิวด์ผิดรูปแบบ
    ///
    BuildIDError,
}

/// เรียกใช้ 'dso' หรือ 'error' สำหรับ DSO แต่ละตัวที่เชื่อมโยงกับกระบวนการโดยตัวเชื่อมโยงแบบไดนามิก
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter ที่จะมีหนึ่งในวิธีการกินที่เรียกว่า foreach DSO
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr ทำให้แน่ใจว่า info.name จะชี้ไปยังตำแหน่งที่ถูกต้อง
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// ฟังก์ชันนี้จะพิมพ์มาร์กอัป Fuchsia symbolizer สำหรับข้อมูลทั้งหมดที่มีอยู่ใน DSO
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}