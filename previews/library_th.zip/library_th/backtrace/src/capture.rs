use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// การเป็นตัวแทนของ backtrace ที่เป็นเจ้าของและมีอยู่ในตัวเอง
///
/// โครงสร้างนี้สามารถใช้เพื่อจับ backtrace ในจุดต่างๆในโปรแกรมและใช้ในภายหลังเพื่อตรวจสอบว่า backtrace คืออะไรในเวลานั้น
///
///
/// `Backtrace` รองรับการพิมพ์ย้อนรอยผ่านการใช้งาน `Debug`
///
/// # คุณสมบัติที่จำเป็น
///
/// ฟังก์ชันนี้ต้องการคุณสมบัติ `std` ของ `backtrace` crate เพื่อเปิดใช้งานและคุณลักษณะ `std` จะเปิดใช้งานตามค่าเริ่มต้น
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // เฟรมที่นี่แสดงรายการจากบนลงล่างของสแต็ก
    frames: Vec<BacktraceFrame>,
    // ดัชนีที่เราเชื่อว่าเป็นจุดเริ่มต้นที่แท้จริงของ backtrace โดยละเว้นเฟรมเช่น `Backtrace::new` และ `backtrace::trace`
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// เฟรมเวอร์ชันที่จับได้ใน backtrace
///
/// ประเภทนี้จะถูกส่งคืนเป็นรายการจาก `Backtrace::frames` และแสดงถึงเฟรมสแต็กหนึ่งเฟรมใน backtrace ที่จับได้
///
/// # คุณสมบัติที่จำเป็น
///
/// ฟังก์ชันนี้ต้องการคุณสมบัติ `std` ของ `backtrace` crate เพื่อเปิดใช้งานและคุณลักษณะ `std` จะเปิดใช้งานตามค่าเริ่มต้น
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// สัญลักษณ์เวอร์ชันที่จับได้ใน backtrace
///
/// ชนิดนี้จะถูกส่งคืนเป็นรายการจาก `BacktraceFrame::symbols` และแสดงถึงข้อมูลเมตาสำหรับสัญลักษณ์ใน backtrace
///
/// # คุณสมบัติที่จำเป็น
///
/// ฟังก์ชันนี้ต้องการคุณสมบัติ `std` ของ `backtrace` crate เพื่อเปิดใช้งานและคุณลักษณะ `std` จะเปิดใช้งานตามค่าเริ่มต้น
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// จับ backtrace ที่ callite ของฟังก์ชันนี้โดยส่งคืนการแสดงที่เป็นเจ้าของ
    ///
    /// ฟังก์ชันนี้มีประโยชน์สำหรับการแสดง backtrace เป็นวัตถุใน Rust ค่าที่ส่งคืนนี้สามารถส่งข้ามเธรดและพิมพ์ที่อื่นได้และจุดประสงค์ของค่านี้คือการมีอยู่ในตัวเองทั้งหมด
    ///
    /// โปรดทราบว่าในบางแพลตฟอร์มการได้รับ backtrace แบบเต็มและการแก้ไขอาจมีราคาแพงมาก
    /// หากค่าใช้จ่ายสำหรับแอปพลิเคชันของคุณมากเกินไปขอแนะนำให้ใช้ `Backtrace::new_unresolved()` แทนซึ่งจะหลีกเลี่ยงขั้นตอนการแก้ไขสัญลักษณ์ (ซึ่งโดยปกติจะใช้เวลานานที่สุด) และอนุญาตให้เลื่อนไปเป็นวันที่ในภายหลัง
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # คุณสมบัติที่จำเป็น
    ///
    /// ฟังก์ชันนี้ต้องการคุณสมบัติ `std` ของ `backtrace` crate เพื่อเปิดใช้งานและคุณลักษณะ `std` จะเปิดใช้งานตามค่าเริ่มต้น
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // ต้องการตรวจสอบให้แน่ใจว่ามีกรอบที่จะลบออก
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// เช่นเดียวกับ `new` ยกเว้นว่าจะไม่สามารถแก้ไขสัญลักษณ์ใด ๆ ได้เพียงแค่จับ backtrace เป็นรายการที่อยู่
    ///
    /// ในเวลาต่อมาสามารถเรียกใช้ฟังก์ชัน `resolve` เพื่อแก้ไขสัญลักษณ์ของ backtrace นี้เป็นชื่อที่อ่านได้
    /// ฟังก์ชันนี้มีอยู่เนื่องจากบางครั้งกระบวนการแก้ไขปัญหาอาจใช้เวลานานมากในขณะที่การพิมพ์ย้อนกลับใด ๆ อาจไม่ค่อยได้รับการพิมพ์ออกมา
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // ไม่มีชื่อสัญลักษณ์
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // ตอนนี้มีชื่อสัญลักษณ์
    /// ```
    ///
    /// # คุณสมบัติที่จำเป็น
    ///
    /// ฟังก์ชันนี้ต้องการคุณสมบัติ `std` ของ `backtrace` crate เพื่อเปิดใช้งานและคุณลักษณะ `std` จะเปิดใช้งานตามค่าเริ่มต้น
    ///
    ///
    ///
    #[inline(never)] // ต้องการตรวจสอบให้แน่ใจว่ามีกรอบที่จะลบออก
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// ส่งคืนเฟรมจากเวลาที่จับ backtrace นี้
    ///
    /// รายการแรกของชิ้นส่วนนี้น่าจะเป็นฟังก์ชัน `Backtrace::new` และเฟรมสุดท้ายน่าจะเป็นข้อมูลเกี่ยวกับการเริ่มต้นของเธรดหรือฟังก์ชันหลัก
    ///
    ///
    /// # คุณสมบัติที่จำเป็น
    ///
    /// ฟังก์ชันนี้ต้องการคุณสมบัติ `std` ของ `backtrace` crate เพื่อเปิดใช้งานและคุณลักษณะ `std` จะเปิดใช้งานตามค่าเริ่มต้น
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// หาก backtrace นี้สร้างขึ้นจาก `new_unresolved` ฟังก์ชันนี้จะแก้ไขที่อยู่ทั้งหมดใน backtrace เป็นชื่อสัญลักษณ์
    ///
    ///
    /// หาก backtrace นี้ได้รับการแก้ไขก่อนหน้านี้หรือสร้างผ่าน `new` ฟังก์ชันนี้จะไม่ทำอะไรเลย
    ///
    /// # คุณสมบัติที่จำเป็น
    ///
    /// ฟังก์ชันนี้ต้องการคุณสมบัติ `std` ของ `backtrace` crate เพื่อเปิดใช้งานและคุณลักษณะ `std` จะเปิดใช้งานตามค่าเริ่มต้น
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// เช่นเดียวกับ `Frame::ip`
    ///
    /// # คุณสมบัติที่จำเป็น
    ///
    /// ฟังก์ชันนี้ต้องการคุณสมบัติ `std` ของ `backtrace` crate เพื่อเปิดใช้งานและคุณลักษณะ `std` จะเปิดใช้งานตามค่าเริ่มต้น
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// เช่นเดียวกับ `Frame::symbol_address`
    ///
    /// # คุณสมบัติที่จำเป็น
    ///
    /// ฟังก์ชันนี้ต้องการคุณสมบัติ `std` ของ `backtrace` crate เพื่อเปิดใช้งานและคุณลักษณะ `std` จะเปิดใช้งานตามค่าเริ่มต้น
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// เช่นเดียวกับ `Frame::module_base_address`
    ///
    /// # คุณสมบัติที่จำเป็น
    ///
    /// ฟังก์ชันนี้ต้องการคุณสมบัติ `std` ของ `backtrace` crate เพื่อเปิดใช้งานและคุณลักษณะ `std` จะเปิดใช้งานตามค่าเริ่มต้น
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// ส่งคืนรายการสัญลักษณ์ที่สอดคล้องกับเฟรมนี้
    ///
    /// โดยปกติจะมีเพียงหนึ่งสัญลักษณ์ต่อเฟรม แต่บางครั้งหากมีการแทรกฟังก์ชันจำนวนหนึ่งไว้ในเฟรมเดียวจะมีการส่งคืนสัญลักษณ์หลายตัว
    /// สัญลักษณ์แรกที่แสดงคือ "innermost function" ในขณะที่สัญลักษณ์สุดท้ายอยู่ด้านนอกสุด (ตัวเรียกสุดท้าย)
    ///
    /// โปรดทราบว่าหากเฟรมนี้มาจาก backtrace ที่ไม่ได้รับการแก้ไขสิ่งนี้จะส่งคืนรายการว่างเปล่า
    ///
    /// # คุณสมบัติที่จำเป็น
    ///
    /// ฟังก์ชันนี้ต้องการคุณสมบัติ `std` ของ `backtrace` crate เพื่อเปิดใช้งานและคุณลักษณะ `std` จะเปิดใช้งานตามค่าเริ่มต้น
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// เช่นเดียวกับ `Symbol::name`
    ///
    /// # คุณสมบัติที่จำเป็น
    ///
    /// ฟังก์ชันนี้ต้องการคุณสมบัติ `std` ของ `backtrace` crate เพื่อเปิดใช้งานและคุณลักษณะ `std` จะเปิดใช้งานตามค่าเริ่มต้น
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// เช่นเดียวกับ `Symbol::addr`
    ///
    /// # คุณสมบัติที่จำเป็น
    ///
    /// ฟังก์ชันนี้ต้องการคุณสมบัติ `std` ของ `backtrace` crate เพื่อเปิดใช้งานและคุณลักษณะ `std` จะเปิดใช้งานตามค่าเริ่มต้น
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// เช่นเดียวกับ `Symbol::filename`
    ///
    /// # คุณสมบัติที่จำเป็น
    ///
    /// ฟังก์ชันนี้ต้องการคุณสมบัติ `std` ของ `backtrace` crate เพื่อเปิดใช้งานและคุณลักษณะ `std` จะเปิดใช้งานตามค่าเริ่มต้น
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// เช่นเดียวกับ `Symbol::lineno`
    ///
    /// # คุณสมบัติที่จำเป็น
    ///
    /// ฟังก์ชันนี้ต้องการคุณสมบัติ `std` ของ `backtrace` crate เพื่อเปิดใช้งานและคุณลักษณะ `std` จะเปิดใช้งานตามค่าเริ่มต้น
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// เช่นเดียวกับ `Symbol::colno`
    ///
    /// # คุณสมบัติที่จำเป็น
    ///
    /// ฟังก์ชันนี้ต้องการคุณสมบัติ `std` ของ `backtrace` crate เพื่อเปิดใช้งานและคุณลักษณะ `std` จะเปิดใช้งานตามค่าเริ่มต้น
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // เมื่อพิมพ์เส้นทางเราพยายามตัด cwd ถ้ามีอยู่มิฉะนั้นเราก็พิมพ์เส้นทางตามที่เป็นอยู่
        // โปรดทราบว่าเราทำสิ่งนี้สำหรับรูปแบบสั้น ๆ เท่านั้นเพราะถ้าเต็มแล้วเราน่าจะต้องการพิมพ์ทุกอย่าง
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}