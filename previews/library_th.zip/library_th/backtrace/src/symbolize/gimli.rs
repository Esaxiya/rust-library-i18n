//! รองรับการแสดงสัญลักษณ์โดยใช้ `gimli` crate บน crates.io
//!
//! นี่คือการใช้งานสัญลักษณ์เริ่มต้นสำหรับ Rust

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'อายุการใช้งานคงที่เป็นเรื่องโกหกสำหรับการแฮ็กเนื่องจากขาดการสนับสนุนโครงสร้างการอ้างอิงตัวเอง
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // แปลงเป็น 'อายุการใช้งานคงที่เนื่องจากสัญลักษณ์ควรยืม `map` และ `stash` เท่านั้นและเราจะสงวนไว้ด้านล่าง
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // สำหรับการโหลดไลบรารีเนทีฟบน Windows โปรดดูการอภิปรายเกี่ยวกับ rust-lang/rust#71060 สำหรับกลยุทธ์ต่างๆที่นี่
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // ปัจจุบันไลบรารี MinGW ไม่รองรับ ASLR (rust-lang/rust#16514) แต่ยังสามารถย้าย DLL ไปรอบ ๆ ในพื้นที่ที่อยู่ได้
            // ดูเหมือนว่าที่อยู่ในข้อมูลการดีบักจะเหมือนกับว่าไลบรารีนี้ถูกโหลดที่ "image base" ซึ่งเป็นฟิลด์ในส่วนหัวของไฟล์ COFF
            // เนื่องจากนี่คือสิ่งที่ debuginfo ดูเหมือนจะแสดงรายการเราจึงแยกวิเคราะห์ตารางสัญลักษณ์และจัดเก็บที่อยู่ราวกับว่าไลบรารีถูกโหลดที่ "image base" เช่นกัน
            //
            // อย่างไรก็ตามอาจไม่สามารถโหลดไลบรารีที่ "image base" ได้
            // (สันนิษฐานว่าอาจมีการโหลดอย่างอื่นอยู่ที่นั่น?) นี่คือจุดที่ฟิลด์ `bias` เข้ามามีบทบาทและเราต้องหาค่า `bias` ที่นี่น่าเสียดายที่ยังไม่ชัดเจนว่าจะรับสิ่งนี้จากโมดูลที่โหลดได้อย่างไร
            // อย่างไรก็ตามสิ่งที่เรามีคือที่อยู่โหลดจริง (`modBaseAddr`)
            //
            // ในฐานะที่เป็น cop-out สำหรับตอนนี้เรา mmap ไฟล์อ่านข้อมูลส่วนหัวของไฟล์จากนั้นวาง mmapสิ่งนี้สิ้นเปลืองเพราะเราอาจจะเปิด mmap ขึ้นมาใหม่ในภายหลัง แต่ตอนนี้น่าจะใช้ได้ดีพอสมควร
            //
            // เมื่อเรามี `image_base` (ตำแหน่งโหลดที่ต้องการ) และ `base_addr` (ตำแหน่งโหลดจริง) เราสามารถกรอก `bias` (ความแตกต่างระหว่างของจริงและที่ต้องการ) จากนั้นที่อยู่ที่ระบุไว้ของแต่ละส่วนคือ `image_base` เนื่องจากนั่นคือสิ่งที่ไฟล์ระบุ
            //
            //
            // สำหรับตอนนี้ดูเหมือนว่าแตกต่างจาก ELF/MachO ที่เราสามารถทำกับหนึ่งเซ็กเมนต์ต่อไลบรารีโดยใช้ `modBaseSize` เป็นขนาดทั้งหมด
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS ใช้รูปแบบไฟล์ Mach-O และใช้ API เฉพาะ DYLD เพื่อโหลดรายการไลบรารีเนทีฟที่เป็นส่วนหนึ่งของแอปพลิเคชัน
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // ดึงชื่อของไลบรารีนี้ซึ่งตรงกับเส้นทางของตำแหน่งที่จะโหลดเช่นกัน
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // โหลดส่วนหัวของรูปภาพของไลบรารีนี้และมอบหมายให้ `object` เพื่อแยกวิเคราะห์คำสั่งโหลดทั้งหมดเพื่อให้เราสามารถหาเซ็กเมนต์ทั้งหมดที่เกี่ยวข้องได้ที่นี่
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // ทำซ้ำบนเซ็กเมนต์และลงทะเบียนภูมิภาคที่รู้จักสำหรับเซ็กเมนต์ที่เราพบ
            // นอกจากนี้บันทึกข้อมูลเกี่ยวกับส่วนข้อความสำหรับการประมวลผลในภายหลังโปรดดูความคิดเห็นด้านล่าง
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // กำหนด "slide" สำหรับไลบรารีนี้ซึ่งท้ายที่สุดก็คืออคติที่เราใช้เพื่อหาว่าจะโหลดอ็อบเจ็กต์หน่วยความจำไว้ที่ใด
            // นี่เป็นการคำนวณแปลก ๆ เล็กน้อยและเป็นผลมาจากการลองทำบางสิ่งในป่าและดูว่าแท่งอะไร
            //
            // แนวคิดทั่วไปคือ `bias` บวก `stated_virtual_memory_address` ของเซ็กเมนต์จะไปอยู่ที่ใดในพื้นที่แอดเดรสจริงที่เซ็กเมนต์นั้นอยู่
            // สิ่งอื่นที่เราพึ่งพาคือที่อยู่จริงลบ `bias` คือดัชนีที่จะค้นหาในตารางสัญลักษณ์และข้อมูลดีบัก
            //
            // อย่างไรก็ตามปรากฎว่าสำหรับไลบรารีที่โหลดระบบการคำนวณเหล่านี้ไม่ถูกต้องอย่างไรก็ตามสำหรับไฟล์ปฏิบัติการดั้งเดิมดูเหมือนว่าถูกต้อง
            // การยกตรรกะบางอย่างจากแหล่งที่มาของ LLDB มันมีปลอกพิเศษสำหรับส่วน `__TEXT` แรกที่โหลดจากไฟล์ออฟเซ็ต 0 ที่มีขนาดที่ไม่ใช่ศูนย์
            // ไม่ว่าจะด้วยเหตุผลใดก็ตามเมื่อสิ่งนี้ปรากฏขึ้นหมายความว่าตารางสัญลักษณ์นั้นสัมพันธ์กับสไลด์ vmaddr สำหรับไลบรารีเท่านั้น
            // ถ้ามัน *ไม่* แสดงตารางสัญลักษณ์จะสัมพันธ์กับสไลด์ vmaddr บวกกับที่อยู่ที่ระบุไว้ของเซ็กเมนต์
            //
            // เพื่อจัดการกับสถานการณ์นี้หากเรา *ไม่* พบส่วนข้อความที่ไฟล์ออฟเซ็ตศูนย์เราจึงเพิ่มอคติตามที่อยู่ที่ระบุของส่วนข้อความแรกและลดที่อยู่ที่ระบุไว้ทั้งหมดตามจำนวนนั้นเช่นกัน
            //
            // ด้วยวิธีนี้ตารางสัญลักษณ์จะปรากฏขึ้นโดยเทียบกับจำนวนอคติของไลบรารีเสมอ
            // สิ่งนี้ดูเหมือนจะมีผลลัพธ์ที่ถูกต้องสำหรับการแสดงสัญลักษณ์ผ่านตารางสัญลักษณ์
            //
            // ฉันไม่แน่ใจจริงๆว่าสิ่งนี้ถูกต้องหรือมีอย่างอื่นที่ควรระบุวิธีการทำ
            // สำหรับตอนนี้ดูเหมือนว่า (?) จะทำงานได้ดีพอและเราควรจะปรับแต่งสิ่งนี้ได้ตลอดเวลาหากจำเป็น
            //
            // สำหรับข้อมูลเพิ่มเติมโปรดดู #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Unix อื่น ๆ (เช่น
        // Linux) ใช้ ELF เป็นรูปแบบไฟล์ออบเจ็กต์และโดยทั่วไปจะใช้ API ที่เรียกว่า `dl_iterate_phdr` เพื่อโหลดไลบรารีเนทีฟ
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` ควรเป็นตัวชี้ที่ถูกต้อง
        // `vec` ควรเป็นตัวชี้ที่ถูกต้องไปยัง `std::Vec`
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 ไม่สนับสนุนข้อมูลการดีบัก แต่ระบบสร้างจะวางข้อมูลการดีบักที่พา ธ `romfs:/debug_info.elf`
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // อย่างอื่นควรใช้ ELF แต่ไม่รู้วิธีโหลดไลบรารีเนทีฟ
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// ไลบรารีแบบแบ่งใช้ที่รู้จักทั้งหมดที่ถูกโหลด
    libraries: Vec<Library>,

    /// แมปแคชที่เราเก็บข้อมูลแคระที่แยกวิเคราะห์
    ///
    /// รายการนี้มีความจุคงที่สำหรับช่วงยกทั้งหมดซึ่งไม่เคยเพิ่มขึ้น
    /// องค์ประกอบ `usize` ของแต่ละคู่เป็นดัชนีใน `libraries` ด้านบนโดยที่ `usize::max_value()` แสดงถึงปฏิบัติการปัจจุบัน
    ///
    /// `Mapping` เป็นข้อมูลแคระที่แยกวิเคราะห์แล้ว
    ///
    /// โปรดทราบว่าโดยพื้นฐานแล้วนี่เป็นแคช LRU และเราจะเปลี่ยนสิ่งต่างๆที่นี่ในขณะที่เราเป็นสัญลักษณ์ของที่อยู่
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// ส่วนของไลบรารีนี้โหลดลงในหน่วยความจำและตำแหน่งที่โหลด
    segments: Vec<LibrarySegment>,
    /// "bias" ของไลบรารีนี้โดยทั่วไปจะโหลดลงในหน่วยความจำ
    /// ค่านี้จะถูกเพิ่มลงในแอดเดรสที่ระบุไว้ของแต่ละเซ็กเมนต์เพื่อรับแอดเดรสหน่วยความจำเสมือนจริงที่เซกเมนต์ถูกโหลดลงใน
    /// นอกจากนี้อคตินี้ยังถูกลบออกจากที่อยู่หน่วยความจำเสมือนจริงเพื่อจัดทำดัชนีลงใน debuginfo และตารางสัญลักษณ์
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// ที่อยู่ที่ระบุไว้ของส่วนนี้ในไฟล์ออบเจ็กต์
    /// นี่ไม่ใช่ที่ที่โหลดเซ็กเมนต์ แต่เป็นที่อยู่นี้บวก `bias` ของไลบรารีที่มีอยู่เป็นที่ที่จะค้นหาได้
    ///
    stated_virtual_memory_address: usize,
    /// ขนาดของเซ็กเมนต์ ths ในหน่วยความจำ
    len: usize,
}

// ไม่ปลอดภัยเนื่องจากจำเป็นต้องซิงโครไนซ์กับภายนอก
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // ไม่ปลอดภัยเนื่องจากจำเป็นต้องซิงโครไนซ์กับภายนอก
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // แคช LRU ขนาดเล็กและเรียบง่ายมากสำหรับการแมปข้อมูลการดีบัก
        //
        // อัตราการเข้าชมควรสูงมากเนื่องจากสแต็กทั่วไปไม่ข้ามระหว่างไลบรารีที่แชร์จำนวนมาก
        //
        // โครงสร้าง `addr2line::Context` ค่อนข้างแพงในการสร้าง
        // คาดว่าต้นทุนจะถูกตัดจำหน่ายโดยการสืบค้น `locate` ที่ตามมาซึ่งใช้ประโยชน์จากโครงสร้างที่สร้างขึ้นเมื่อสร้าง "addr2line: : Context" เพื่อให้ได้ความเร็วที่ดี
        //
        // หากเราไม่มีแคชนี้การตัดจำหน่ายนั้นจะไม่เกิดขึ้นและการย้อนกลับที่เป็นสัญลักษณ์จะเป็น ssssllllooooowwww
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // ก่อนอื่นให้ทดสอบว่า `lib` นี้มีเซ็กเมนต์ใด ๆ ที่มี `addr` (การจัดการการย้ายตำแหน่ง) หรือไม่หากการตรวจสอบนี้ผ่านเราสามารถดำเนินการต่อด้านล่างและแปลที่อยู่ได้จริง
                //
                // โปรดทราบว่าเรากำลังใช้ `wrapping_add` ที่นี่เพื่อหลีกเลี่ยงการตรวจสอบมากเกินไปเป็นที่เห็นกันทั่วไปว่าการคำนวณอคติ SVMA + ล้นเกิน
                // ดูเหมือนเป็นเรื่องแปลกเล็กน้อยที่จะเกิดขึ้น แต่ไม่มีจำนวนมากที่เราสามารถทำได้นอกเหนือจากการเพิกเฉยต่อส่วนเหล่านั้นเนื่องจากมีแนวโน้มที่จะชี้ออกไปในอวกาศ
                //
                // สิ่งนี้เกิดขึ้นใน rust-lang/backtrace-rs#329
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // ตอนนี้เรารู้แล้วว่า `lib` มี `addr` เราสามารถหักล้างด้วยอคติเพื่อค้นหาที่อยู่หน่วยความจำที่ระบุไว้
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariant: หลังจากเงื่อนไขนี้เสร็จสมบูรณ์โดยไม่ต้องส่งคืนก่อนเวลา
        // จากข้อผิดพลาดรายการแคชสำหรับเส้นทางนี้อยู่ที่ดัชนี 0

        if let Some(idx) = idx {
            // เมื่อการแมปอยู่ในแคชแล้วให้ย้ายไปด้านหน้า
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // เมื่อการแม็ปไม่ได้อยู่ในแคชให้สร้างการแม็ปใหม่แทรกลงในด้านหน้าของแคชและขับไล่รายการแคชที่เก่าที่สุดหากจำเป็น
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // อย่าให้อายุการใช้งานของ `'static` รั่วไหลตรวจสอบให้แน่ใจว่าขอบเขตของตัวเราเอง
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // ยืดอายุการใช้งานของ `sym` เป็น `'static` เนื่องจากเราจำเป็นต้องอยู่ที่นี่ แต่มันก็ยังคงเป็นข้อมูลอ้างอิงอยู่ดังนั้นจึงไม่ควรมีการอ้างอิงถึงมันเกินกว่าเฟรมนี้ต่อไป
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // สุดท้ายรับการแมปแคชหรือสร้างการแมปใหม่สำหรับไฟล์นี้และประเมินข้อมูล DWARF เพื่อค้นหา file/line/name สำหรับที่อยู่นี้
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// เราสามารถค้นหาข้อมูลเฟรมสำหรับสัญลักษณ์นี้ได้และเฟรมของ "addr2line" ภายในจะมีรายละเอียดที่สำคัญทั้งหมด
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// ไม่พบข้อมูลการดีบัก แต่เราพบในตารางสัญลักษณ์ของเอลฟ์ปฏิบัติการ
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}