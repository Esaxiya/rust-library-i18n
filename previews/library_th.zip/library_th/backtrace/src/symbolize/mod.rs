use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// แก้ไขที่อยู่เป็นสัญลักษณ์ส่งผ่านสัญลักษณ์ไปยังการปิดที่ระบุ
///
/// ฟังก์ชันนี้จะค้นหาที่อยู่ที่ระบุในพื้นที่ต่างๆเช่นตารางสัญลักษณ์เฉพาะที่ตารางสัญลักษณ์แบบไดนามิกหรือข้อมูลการดีบัก DWARF (ขึ้นอยู่กับการใช้งานที่เปิดใช้งาน) เพื่อค้นหาสัญลักษณ์ที่จะให้ผล
///
///
/// การปิดอาจไม่ถูกเรียกหากไม่สามารถดำเนินการแก้ปัญหาได้และอาจเรียกมากกว่าหนึ่งครั้งในกรณีของฟังก์ชันแบบอินไลน์
///
/// สัญลักษณ์ที่ให้แสดงถึงการดำเนินการที่ `addr` ที่ระบุโดยส่งคืนคู่ file/line สำหรับแอดเดรสนั้น (ถ้ามี)
///
/// โปรดทราบว่าหากคุณมี `Frame` ขอแนะนำให้ใช้ฟังก์ชัน `resolve_frame` แทนฟังก์ชันนี้
///
/// # คุณสมบัติที่จำเป็น
///
/// ฟังก์ชันนี้ต้องการคุณสมบัติ `std` ของ `backtrace` crate เพื่อเปิดใช้งานและคุณลักษณะ `std` จะเปิดใช้งานตามค่าเริ่มต้น
///
/// # Panics
///
/// ฟังก์ชันนี้มุ่งมั่นที่จะไม่ใช้ panic แต่ถ้า `cb` ให้ panics แล้วบางแพลตฟอร์มจะบังคับให้ panic สองเท่าเพื่อยกเลิกกระบวนการ
/// บางแพลตฟอร์มใช้ไลบรารี C ซึ่งใช้การโทรกลับภายในซึ่งไม่สามารถคลายออกได้ดังนั้นการตื่นตระหนกจาก `cb` อาจทำให้กระบวนการยกเลิก
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // ดูที่กรอบด้านบนเท่านั้น
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// แก้ไขกรอบการจับภาพก่อนหน้านี้เป็นสัญลักษณ์โดยส่งผ่านสัญลักษณ์ไปยังการปิดที่ระบุ
///
/// functin นี้ทำหน้าที่เช่นเดียวกับ `resolve` ยกเว้นว่าจะใช้ `Frame` เป็นอาร์กิวเมนต์แทนที่อยู่
/// สิ่งนี้สามารถช่วยให้การใช้งานแพลตฟอร์มบางอย่างของ backtracing สามารถให้ข้อมูลสัญลักษณ์ที่ถูกต้องมากขึ้นหรือข้อมูลเกี่ยวกับอินไลน์เฟรมเป็นต้น
///
/// ขอแนะนำให้ใช้สิ่งนี้หากทำได้
///
/// # คุณสมบัติที่จำเป็น
///
/// ฟังก์ชันนี้ต้องการคุณสมบัติ `std` ของ `backtrace` crate เพื่อเปิดใช้งานและคุณลักษณะ `std` จะเปิดใช้งานตามค่าเริ่มต้น
///
/// # Panics
///
/// ฟังก์ชันนี้มุ่งมั่นที่จะไม่ใช้ panic แต่ถ้า `cb` ให้ panics แล้วบางแพลตฟอร์มจะบังคับให้ panic สองเท่าเพื่อยกเลิกกระบวนการ
/// บางแพลตฟอร์มใช้ไลบรารี C ซึ่งใช้การโทรกลับภายในซึ่งไม่สามารถคลายออกได้ดังนั้นการตื่นตระหนกจาก `cb` อาจทำให้กระบวนการยกเลิก
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // ดูที่กรอบด้านบนเท่านั้น
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// โดยทั่วไปค่า IP จากสแต็กเฟรมจะเป็น (always?) คำสั่ง *หลัง* การเรียกที่เป็นการติดตามสแต็กจริง
// การแสดงสัญลักษณ์นี้ทำให้หมายเลข filename/line อยู่ข้างหน้าและอาจอยู่ในช่องว่างหากอยู่ใกล้จุดสิ้นสุดของฟังก์ชัน
//
// โดยพื้นฐานแล้วสิ่งนี้มักจะเกิดขึ้นในทุกแพลตฟอร์มดังนั้นเราจึงลบหนึ่งรายการออกจาก ip ที่แก้ไขแล้วเพื่อแก้ไขเป็นคำสั่งการโทรก่อนหน้าแทนที่จะเป็นคำสั่งที่ถูกส่งกลับไป
//
//
// ตามหลักการแล้วเราจะไม่ทำเช่นนี้
// ตามหลักการแล้วเราต้องการให้ผู้เรียกใช้ `resolve` API ที่นี่ทำ -1 ด้วยตนเองและบัญชีที่ต้องการข้อมูลตำแหน่งสำหรับคำสั่ง *ก่อนหน้า* ไม่ใช่ข้อมูลปัจจุบัน
// ตามหลักการแล้วเราจะเปิดเผยบน `Frame` หากเราเป็นที่อยู่ของคำสั่งถัดไปหรือปัจจุบัน
//
// สำหรับตอนนี้แม้ว่านี่จะเป็นปัญหาเฉพาะกลุ่มดังนั้นเราจึงลบ 1 อันภายในเสมอ
// ผู้บริโภคควรทำงานต่อไปและได้รับผลลัพธ์ที่ดีดังนั้นเราควรจะดีพอ
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// เช่นเดียวกับ `resolve` ไม่ปลอดภัยเนื่องจากไม่ได้ซิงโครไนซ์
///
/// ฟังก์ชั่นนี้ไม่มี guarentees การซิงโครไนซ์ แต่จะพร้อมใช้งานเมื่อคุณสมบัติ `std` ของ crate นี้ไม่ได้คอมไพล์
/// ดูฟังก์ชัน `resolve` สำหรับเอกสารและตัวอย่างเพิ่มเติม
///
/// # Panics
///
/// ดูข้อมูลเกี่ยวกับ `resolve` สำหรับข้อควรระวังในการตื่นตระหนกของ `cb`
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// เช่นเดียวกับ `resolve_frame` ไม่ปลอดภัยเนื่องจากไม่ได้ซิงโครไนซ์
///
/// ฟังก์ชั่นนี้ไม่มี guarentees การซิงโครไนซ์ แต่จะพร้อมใช้งานเมื่อคุณสมบัติ `std` ของ crate นี้ไม่ได้คอมไพล์
/// ดูฟังก์ชัน `resolve_frame` สำหรับเอกสารและตัวอย่างเพิ่มเติม
///
/// # Panics
///
/// ดูข้อมูลเกี่ยวกับ `resolve_frame` สำหรับข้อควรระวังในการตื่นตระหนกของ `cb`
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait แสดงถึงความละเอียดของสัญลักษณ์ในไฟล์
///
/// trait นี้ให้ผลเป็นวัตถุ trait สำหรับการปิดที่มอบให้กับฟังก์ชัน `backtrace::resolve` และแทบจะถูกส่งไปเนื่องจากไม่ทราบว่าการนำไปใช้งานใดอยู่เบื้องหลัง
///
///
/// สัญลักษณ์สามารถให้ข้อมูลเชิงบริบทเกี่ยวกับฟังก์ชันตัวอย่างเช่นชื่อชื่อไฟล์หมายเลขบรรทัดที่อยู่ที่แน่นอนเป็นต้น
/// อย่างไรก็ตามข้อมูลบางอย่างอาจไม่มีอยู่ในสัญลักษณ์เสมอไปดังนั้นวิธีการทั้งหมดจึงส่งคืนค่า `Option`
///
///
pub struct Symbol {
    // TODO: ความผูกพันตลอดชีวิตนี้จะต้องคงอยู่ไปที่ `Symbol` ในที่สุด
    // แต่นั่นเป็นการเปลี่ยนแปลงที่รุนแรงในขณะนี้
    // ตอนนี้สิ่งนี้ปลอดภัยแล้วเนื่องจาก `Symbol` ถูกส่งมอบโดยการอ้างอิงเท่านั้นและไม่สามารถโคลนได้
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// ส่งคืนชื่อของฟังก์ชันนี้
    ///
    /// โครงสร้างที่ส่งคืนสามารถใช้เพื่อสอบถามคุณสมบัติต่างๆเกี่ยวกับชื่อสัญลักษณ์:
    ///
    ///
    /// * การใช้งาน `Display` จะพิมพ์สัญลักษณ์ที่แยกออกมา
    /// * สามารถเข้าถึงค่าดิบ `str` ของสัญลักษณ์ได้ (ถ้าเป็น utf-8 ที่ถูกต้อง)
    /// * สามารถเข้าถึงไบต์ดิบสำหรับชื่อสัญลักษณ์ได้
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// ส่งกลับที่อยู่เริ่มต้นของฟังก์ชันนี้
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// ส่งคืนชื่อไฟล์ดิบเป็นสไลซ์
    /// สิ่งนี้มีประโยชน์สำหรับสภาพแวดล้อม `no_std` เป็นหลัก
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// ส่งคืนหมายเลขคอลัมน์สำหรับตำแหน่งที่สัญลักษณ์นี้กำลังดำเนินการอยู่
    ///
    /// ปัจจุบัน gimli เท่านั้นที่ให้ค่าที่นี่และถึงแม้ `filename` จะส่งคืน `Some` ดังนั้นจึงอยู่ภายใต้ข้อแม้ที่คล้ายกัน
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// ส่งคืนหมายเลขบรรทัดสำหรับตำแหน่งที่สัญลักษณ์นี้กำลังดำเนินการอยู่
    ///
    /// โดยทั่วไปค่าที่ส่งคืนนี้คือ `Some` หาก `filename` ส่งคืน `Some` และด้วยเหตุนี้จึงเป็นไปตามข้อแม้ที่คล้ายกัน
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// ส่งคืนชื่อไฟล์ที่กำหนดฟังก์ชันนี้
    ///
    /// ขณะนี้ใช้ได้เฉพาะเมื่อมีการใช้ libbacktrace หรือ gimli (เช่น
    /// unix แพลตฟอร์มอื่น ๆ) และเมื่อไบนารีถูกคอมไพล์ด้วย debuginfo
    /// หากไม่ตรงตามเงื่อนไขทั้งสองข้อนี้จะส่งคืน `None`
    ///
    /// # คุณสมบัติที่จำเป็น
    ///
    /// ฟังก์ชันนี้ต้องการคุณสมบัติ `std` ของ `backtrace` crate เพื่อเปิดใช้งานและคุณลักษณะ `std` จะเปิดใช้งานตามค่าเริ่มต้น
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // อาจเป็นสัญลักษณ์ C++ ที่แยกวิเคราะห์หากการแยกวิเคราะห์สัญลักษณ์ที่แหลกเหลวเป็น Rust ล้มเหลว
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // ตรวจสอบให้แน่ใจว่าได้รักษาขนาดเป็นศูนย์ไว้เพื่อให้คุณลักษณะ `cpp_demangle` ไม่มีค่าใช้จ่ายเมื่อปิดใช้งาน
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// กระดาษห่อหุ้มรอบชื่อสัญลักษณ์เพื่อให้ตัวเข้าถึงตามหลักสรีรศาสตร์สำหรับชื่อที่แยกส่วนไบต์ดิบสตริงดิบ ฯลฯ
///
// อนุญาตรหัสตายเมื่อไม่ได้เปิดใช้งานคุณสมบัติ `cpp_demangle`
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// สร้างชื่อสัญลักษณ์ใหม่จากไบต์พื้นฐานดิบ
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// ส่งคืนชื่อสัญลักษณ์ดิบ (mangled) เป็น `str` หากสัญลักษณ์เป็น utf-8 ที่ถูกต้อง
    ///
    /// ใช้การใช้งาน `Display` หากคุณต้องการเวอร์ชันที่แยกส่วน
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// ส่งคืนชื่อสัญลักษณ์ดิบเป็นรายการไบต์
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // สิ่งนี้อาจจะพิมพ์ได้หากสัญลักษณ์ที่แยกส่วนไม่ถูกต้องจริงดังนั้นจัดการข้อผิดพลาดที่นี่อย่างสง่างามโดยไม่เผยแพร่ออกไปด้านนอก
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// พยายามเรียกคืนหน่วยความจำแคชที่ใช้เพื่อแสดงที่อยู่เป็นสัญลักษณ์
///
/// วิธีนี้จะพยายามปล่อยโครงสร้างข้อมูลส่วนกลางใด ๆ ที่ถูกแคชไว้ทั่วโลกหรือในเธรดซึ่งโดยทั่วไปจะแสดงถึงข้อมูล DWARF ที่แยกวิเคราะห์หรือคล้ายกัน
///
///
/// # Caveats
///
/// แม้ว่าฟังก์ชันนี้จะพร้อมใช้งานเสมอ แต่ก็ไม่ได้ทำอะไรกับการใช้งานส่วนใหญ่
/// ไลบรารีเช่น dbghelp หรือ libbacktrace ไม่มีสิ่งอำนวยความสะดวกในการจัดสรรสถานะและจัดการหน่วยความจำที่จัดสรร
/// สำหรับตอนนี้คุณสมบัติ `gimli-symbolize` ของ crate นี้เป็นคุณสมบัติเดียวที่ฟังก์ชันนี้มีผลกระทบใด ๆ
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}