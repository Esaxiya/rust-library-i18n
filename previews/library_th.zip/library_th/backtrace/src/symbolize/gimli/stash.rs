// ใช้เฉพาะกับ Linux ในขณะนี้ดังนั้นให้อนุญาตรหัสตายที่อื่น
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// ตัวจัดสรรอารีน่าอย่างง่ายสำหรับบัฟเฟอร์ไบต์
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// จัดสรรบัฟเฟอร์ตามขนาดที่ระบุและส่งคืนการอ้างอิงที่ไม่แน่นอนให้กับมัน
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // ความปลอดภัย: นี่เป็นฟังก์ชั่นเดียวที่สร้างสิ่งที่เปลี่ยนแปลงได้
        // อ้างอิงถึง `self.buffers`
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // ความปลอดภัย: เราไม่เคยลบองค์ประกอบออกจาก `self.buffers` ดังนั้นการอ้างอิง
        // ไปยังข้อมูลภายในบัฟเฟอร์ใด ๆ จะอยู่ตราบเท่าที่ `self` ทำ
        &mut buffers[i]
    }
}