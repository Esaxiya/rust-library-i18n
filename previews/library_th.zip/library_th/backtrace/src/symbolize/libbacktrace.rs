//! กลยุทธ์การใช้สัญลักษณ์โดยใช้รหัสการแยกวิเคราะห์ DWARF ใน libbacktrace
//!
//! ไลบรารี libbacktrace C ซึ่งโดยทั่วไปแจกจ่ายด้วย gcc ไม่เพียง แต่สนับสนุนการสร้าง backtrace (ซึ่งเราไม่ได้ใช้จริง) แต่ยังเป็นสัญลักษณ์ของการย้อนกลับและการจัดการข้อมูลการดีบักของคนแคระเกี่ยวกับสิ่งต่างๆเช่นเฟรมแบบอินไลน์และอะไรก็ตาม
//!
//!
//! สิ่งนี้ค่อนข้างซับซ้อนเนื่องจากมีข้อกังวลมากมายที่นี่ แต่แนวคิดพื้นฐานคือ:
//!
//! * อันดับแรกเราเรียก `backtrace_syminfo` สิ่งนี้จะได้รับข้อมูลสัญลักษณ์จากตารางสัญลักษณ์ไดนามิกหากเราทำได้
//! * ต่อไปเราเรียก `backtrace_pcinfo` สิ่งนี้จะแยกวิเคราะห์ตาราง debuginfo หากมีและช่วยให้เราสามารถกู้คืนข้อมูลเกี่ยวกับอินไลน์เฟรมชื่อไฟล์หมายเลขบรรทัด ฯลฯ
//!
//! มีกลอุบายมากมายเกี่ยวกับการนำตารางคนแคระเข้าสู่ libbacktrace แต่หวังว่ามันจะไม่ใช่จุดจบของโลกและชัดเจนพอเมื่ออ่านด้านล่าง
//!
//! นี่คือกลยุทธ์การแสดงสัญลักษณ์เริ่มต้นสำหรับแพลตฟอร์มที่ไม่ใช่ MSVC และไม่ใช่ OSXใน libstd แม้ว่านี่จะเป็นกลยุทธ์เริ่มต้นสำหรับ OSX
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // หากเป็นไปได้ให้ใช้ชื่อ `function` ซึ่งมาจาก debuginfo และโดยทั่วไปแล้วจะแม่นยำกว่าสำหรับอินไลน์เฟรม
                // หากไม่มีอยู่แม้ว่าจะกลับไปที่ชื่อตารางสัญลักษณ์ที่ระบุใน `symname`
                //
                // โปรดทราบว่าบางครั้ง `function` อาจรู้สึกว่ามีความแม่นยำน้อยลงบ้างเช่นแสดงว่า `try<i32,closure>` ไม่ใช่ `std::panicking::try::do_call`
                //
                // ยังไม่ชัดเจนว่าทำไม แต่โดยรวมแล้วชื่อ `function` ดูเหมือนจะแม่นยำกว่า
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // ไม่ต้องทำอะไรในตอนนี้
}

/// ประเภทของตัวชี้ `data` ที่ส่งผ่านไปยัง `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // เมื่อเรียกใช้การโทรกลับนี้จาก `backtrace_syminfo` เมื่อเราเริ่มการแก้ไขเราจะเรียกใช้ `backtrace_pcinfo` ต่อไป
    // ฟังก์ชัน `backtrace_pcinfo` จะตรวจสอบข้อมูลการดีบักและแก้ไขเพื่อทำสิ่งต่างๆเช่นกู้คืนข้อมูล file/line รวมถึงเฟรมแบบอินไลน์
    // โปรดทราบว่า `backtrace_pcinfo` สามารถล้มเหลวหรือไม่สามารถทำอะไรได้มากหากไม่มีข้อมูลการดีบักดังนั้นหากเกิดเหตุการณ์นี้ขึ้นเราแน่ใจว่าจะโทรกลับด้วยสัญลักษณ์อย่างน้อยหนึ่งสัญลักษณ์จาก `syminfo_cb`
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// ประเภทของตัวชี้ `data` ที่ส่งผ่านไปยัง `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// libbacktrace API รองรับการสร้างสถานะ แต่ไม่สนับสนุนการทำลายสถานะ
// โดยส่วนตัวแล้วฉันใช้สิ่งนี้เพื่อหมายความว่ารัฐมีขึ้นเพื่อสร้างขึ้นแล้วมีชีวิตอยู่ตลอดไป
//
// ฉันชอบที่จะลงทะเบียนตัวจัดการ at_exit() ซึ่งจะล้างสถานะนี้ แต่ libbacktrace ไม่มีวิธีการทำเช่นนั้น
//
// ด้วยข้อ จำกัด เหล่านี้ฟังก์ชันนี้จึงมีสถานะแคชแบบคงที่ซึ่งคำนวณได้ในครั้งแรกที่มีการร้องขอ
//
// โปรดจำไว้ว่าการย้อนกลับทั้งหมดเกิดขึ้นตามลำดับ (ล็อคเดียวทั่วโลก)
//
// โปรดทราบว่าการขาดการซิงโครไนซ์ที่นี่เกิดจากข้อกำหนดที่ให้ `resolve` ซิงโครไนซ์กับภายนอก
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // อย่าใช้ความสามารถที่ปลอดภัยของ threadsafe ของ libbacktrace เพราะเรามักจะเรียกมันแบบซิงโครไนซ์
        //
        0,
        error_cb,
        ptr::null_mut(), // ไม่มีข้อมูลเพิ่มเติม
    );

    return STATE;

    // โปรดทราบว่าเพื่อให้ libbacktrace ดำเนินการได้ทั้งหมดจำเป็นต้องค้นหาข้อมูลการดีบัก DWARF สำหรับไฟล์ปฏิบัติการปัจจุบันโดยทั่วไปแล้วจะทำได้โดยใช้กลไกหลายอย่างรวมถึง แต่ไม่ จำกัด เพียง:
    //
    // * /proc/self/exe บนแพลตฟอร์มที่รองรับ
    // * ชื่อไฟล์ส่งผ่านอย่างชัดเจนเมื่อสร้างสถานะ
    //
    // ไลบรารี libbacktrace เป็นรหัส C ขนาดใหญ่โดยปกติหมายความว่ามีช่องโหว่ด้านความปลอดภัยของหน่วยความจำโดยเฉพาะอย่างยิ่งเมื่อจัดการกับ debuginfo ที่ผิดรูปแบบ
    // Libstd ได้พบกับสิ่งเหล่านี้มากมายในอดีต
    //
    // หากใช้ /proc/self/exe โดยทั่วไปเราสามารถเพิกเฉยต่อสิ่งเหล่านี้ได้เนื่องจากเราคิดว่า libbacktrace คือ "mostly correct" และมิฉะนั้นจะไม่ทำสิ่งแปลก ๆ ด้วยข้อมูลการดีบักของคนแคระ "attempted to be correct"
    //
    //
    // อย่างไรก็ตามหากเราส่งชื่อไฟล์เป็นไปได้ในบางแพลตฟอร์ม (เช่น BSD) ที่ผู้ประสงค์ร้ายอาจทำให้ไฟล์ถูกวางไว้ที่ตำแหน่งนั้นโดยพลการ
    // ซึ่งหมายความว่าถ้าเราบอก libbacktrace เกี่ยวกับชื่อไฟล์อาจเป็นการใช้ไฟล์โดยพลการซึ่งอาจทำให้เกิด segfaults
    // หากเราไม่บอก libbacktrace อะไรเลยมันจะไม่ทำอะไรบนแพลตฟอร์มที่ไม่รองรับเส้นทางเช่น /proc/self/exe!
    //
    // จากทุกสิ่งที่เราพยายามอย่างหนักที่สุดที่จะ *ไม่* ส่งผ่านในชื่อไฟล์ แต่เราต้องใช้บนแพลตฟอร์มที่ไม่รองรับ /proc/self/exe เลย
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // โปรดทราบว่าตามหลักการแล้วเราควรใช้ `std::env::current_exe` แต่เราไม่ต้องการ `std` ที่นี่
            //
            // ใช้ `_NSGetExecutablePath` เพื่อโหลดพา ธ ปฏิบัติการปัจจุบันลงในพื้นที่คงที่ (ซึ่งถ้ามันเล็กเกินไปก็ยอมแพ้)
            //
            //
            // โปรดทราบว่าเราให้ความไว้วางใจ libbacktrace อย่างจริงจังที่นี่ว่าจะไม่ตายบนไฟล์ปฏิบัติการที่เสียหาย แต่ก็ทำได้อย่างแน่นอน ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows มีโหมดการเปิดไฟล์โดยที่หลังจากเปิดแล้วจะไม่สามารถลบได้
            // โดยทั่วไปแล้วสิ่งที่เราต้องการที่นี่เพราะเราต้องการให้แน่ใจว่าไฟล์ปฏิบัติการของเราจะไม่เปลี่ยนไปจากที่อยู่ภายใต้เราหลังจากที่เราส่งต่อไปยัง libbacktrace หวังว่าจะช่วยลดความสามารถในการส่งผ่านข้อมูลโดยพลการไปยัง libbacktrace (ซึ่งอาจมีการจัดการที่ไม่ถูกต้อง)
            //
            //
            // เนื่องจากเราเต้นรำกันเล็กน้อยที่นี่เพื่อพยายามล็อคภาพของเราเอง:
            //
            // * จัดการกับกระบวนการปัจจุบันโหลดชื่อไฟล์
            // * เปิดไฟล์เป็นชื่อไฟล์นั้นด้วยแฟล็กที่ถูกต้อง
            // * โหลดชื่อไฟล์ของกระบวนการปัจจุบันอีกครั้งตรวจสอบให้แน่ใจว่าเป็นชื่อเดียวกัน
            //
            // หากทุกอย่างผ่านไปในทางทฤษฎีเราได้เปิดไฟล์ของกระบวนการของเราและเรารับประกันว่ามันจะไม่เปลี่ยนแปลงFWIW สิ่งนี้คัดลอกมาจาก libstd ในอดีตดังนั้นนี่คือการตีความที่ดีที่สุดของฉันเกี่ยวกับสิ่งที่เกิดขึ้น
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // สิ่งนี้อาศัยอยู่ในความทรงจำที่คงที่เพื่อให้เราได้คืน ..
                static mut BUF: [i8; N] = [0; N];
                // ... และสิ่งนี้อาศัยอยู่ในสแต็กเนื่องจากเป็นแบบชั่วคราว
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // รั่ว `handle` โดยเจตนาที่นี่เนื่องจากการเปิดดังกล่าวควรรักษาการล็อกชื่อไฟล์นี้ไว้
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // เราต้องการส่งคืนสไลซ์ที่ถูกยกเลิกด้วย nul ดังนั้นหากทุกอย่างถูกเติมเต็มและมันเท่ากับความยาวทั้งหมดก็เท่ากับว่ามันเป็นความล้มเหลว
                //
                //
                // มิฉะนั้นเมื่อส่งคืนความสำเร็จตรวจสอบให้แน่ใจว่ามี nul byte รวมอยู่ในชิ้น
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // ขณะนี้ข้อผิดพลาดในการย้อนกลับถูกกวาดไปใต้พรม
    let state = init_state();
    if state.is_null() {
        return;
    }

    // เรียกใช้ `backtrace_syminfo` API ซึ่ง (จากการอ่านรหัส) ควรเรียกใช้ `syminfo_cb` ทุกครั้ง (หรือล้มเหลวโดยมีข้อผิดพลาด)
    // จากนั้นเราจะจัดการเพิ่มเติมภายใน `syminfo_cb`
    //
    // โปรดทราบว่าเราทำสิ่งนี้ตั้งแต่ `syminfo` จะดูตารางสัญลักษณ์ค้นหาชื่อสัญลักษณ์แม้ว่าจะไม่มีข้อมูลการดีบักในไบนารีก็ตาม
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}