//! Windows SEH
//!
//! บน Windows (ปัจจุบันมีเฉพาะบน MSVC) กลไกการจัดการข้อยกเว้นเริ่มต้นคือ Structured Exception Handling (SEH)
//! สิ่งนี้ค่อนข้างแตกต่างจากการจัดการข้อยกเว้นของ Dwarf (เช่นแพลตฟอร์ม unix อื่น ๆ ใช้) ในแง่ของคอมไพเลอร์ภายในดังนั้น LLVM จึงจำเป็นต้องได้รับการสนับสนุนเพิ่มเติมสำหรับ SEH
//!
//! สรุปสิ่งที่เกิดขึ้นที่นี่คือ:
//!
//! 1. ฟังก์ชัน `panic` เรียกใช้ฟังก์ชัน Windows มาตรฐาน `_CxxThrowException` เพื่อโยนข้อยกเว้นเช่น C++ ซึ่งเรียกใช้กระบวนการคลี่คลาย
//! 2.
//! แผ่นเชื่อมโยงไปถึงทั้งหมดที่สร้างโดยคอมไพเลอร์ใช้ฟังก์ชันบุคลิกภาพ `__CxxFrameHandler3` ซึ่งเป็นฟังก์ชันใน CRT และรหัสคลี่คลายใน Windows จะใช้ฟังก์ชันบุคลิกภาพนี้เพื่อเรียกใช้รหัสการล้างข้อมูลทั้งหมดบนสแต็ก
//!
//! 3. การเรียกใช้คอมไพเลอร์ที่สร้างขึ้นทั้งหมดไปยัง `invoke` มีชุดแลนดิ้งแพดเป็นคำสั่ง `cleanuppad` LLVM ซึ่งระบุการเริ่มต้นของรูทีนการล้างข้อมูล
//! บุคลิกภาพ (ในขั้นตอนที่ 2 กำหนดไว้ใน CRT) มีหน้าที่รับผิดชอบในการรันรูทีนการล้างข้อมูล
//! 4. ในที่สุดโค้ด "catch" ใน `try` intrinsic (สร้างโดยคอมไพเลอร์) จะถูกเรียกใช้งานและบ่งชี้ว่าการควบคุมควรกลับมาที่ Rust
//! สิ่งนี้ทำได้ผ่าน `catchswitch` บวกกับคำสั่ง `catchpad` ในเงื่อนไข LLVM IR ในที่สุดก็คืนการควบคุมปกติให้กับโปรแกรมด้วยคำสั่ง `catchret`
//!
//! ความแตกต่างเฉพาะบางประการจากการจัดการข้อยกเว้นที่ใช้ gcc ได้แก่ :
//!
//! * Rust ไม่มีฟังก์ชันบุคลิกภาพแบบกำหนดเอง แต่จะเป็น *เสมอ*`__CxxFrameHandler3` แทนนอกจากนี้ไม่มีการกรองเพิ่มเติมดังนั้นเราจึงพบข้อยกเว้น C++ ใด ๆ ที่ดูเหมือนว่าเรากำลังขว้างปา
//! โปรดทราบว่าการโยนข้อยกเว้นลงใน Rust นั้นเป็นพฤติกรรมที่ไม่ได้กำหนดไว้ดังนั้นสิ่งนี้ก็น่าจะใช้ได้
//! * เรามีข้อมูลบางอย่างที่จะส่งข้ามขอบเขตที่คลี่คลายโดยเฉพาะ `Box<dyn Any + Send>` เช่นเดียวกับข้อยกเว้นของ Dwarf พอยน์เตอร์ทั้งสองนี้จะถูกเก็บไว้เป็นเพย์โหลดในข้อยกเว้นนั้นเอง
//! อย่างไรก็ตามบน MSVC ไม่จำเป็นต้องมีการจัดสรรฮีพเพิ่มเติมเนื่องจาก call stack จะถูกเก็บรักษาไว้ในขณะที่กำลังดำเนินการฟังก์ชันตัวกรอง
//! ซึ่งหมายความว่าพอยน์เตอร์จะถูกส่งไปยัง `_CxxThrowException` โดยตรงซึ่งจะถูกกู้คืนในฟังก์ชันฟิลเตอร์เพื่อเขียนไปยังสแต็กเฟรมของภายใน `try`
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // สิ่งนี้จำเป็นต้องเป็นตัวเลือกเนื่องจากเราตรวจจับข้อยกเว้นโดยการอ้างอิงและตัวทำลายของมันถูกดำเนินการโดยรันไทม์ C++
    // เมื่อเรานำ Box ออกจากข้อยกเว้นเราจำเป็นต้องปล่อยให้ข้อยกเว้นอยู่ในสถานะที่ถูกต้องเพื่อให้ตัวทำลายของมันทำงานได้โดยไม่ต้องวางกล่องสองครั้ง
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// ก่อนอื่นคำจำกัดความประเภททั้งหมดมีสิ่งแปลกประหลาดเฉพาะแพลตฟอร์มอยู่ที่นี่และอีกมากมายที่คัดลอกมาจาก LLVM อย่างโจ่งแจ้งจุดประสงค์ของทั้งหมดนี้คือการใช้ฟังก์ชัน `panic` ด้านล่างผ่านการโทรไปที่ `_CxxThrowException`
//
// ฟังก์ชันนี้รับสองอาร์กิวเมนต์ตัวแรกคือตัวชี้ไปยังข้อมูลที่เราส่งผ่านซึ่งในกรณีนี้คือออบเจ็กต์ trait ของเราหาง่ายมาก!อย่างไรก็ตามต่อไปมีความซับซ้อนมากขึ้น
// นี่คือตัวชี้ไปยังโครงสร้าง `_ThrowInfo` และโดยทั่วไปมีไว้เพื่ออธิบายถึงข้อยกเว้นที่เกิดขึ้นเท่านั้น
//
// ปัจจุบันคำจำกัดความของ [1] ประเภทนี้มีขนดกเล็กน้อยและความแปลกหลัก (และความแตกต่างจากบทความออนไลน์) คือใน 32 บิตพอยน์เตอร์เป็นพอยน์เตอร์ แต่ใน 64 บิตพอยน์เตอร์จะแสดงเป็นออฟเซ็ต 32 บิตจาก สัญลักษณ์ `__ImageBase`
//
// มาโคร `ptr_t` และ `ptr!` ในโมดูลด้านล่างใช้เพื่อแสดงสิ่งนี้
//
// คำจำกัดความของประเภทเขาวงกตยังติดตามสิ่งที่ LLVM เปล่งออกมาสำหรับการดำเนินการประเภทนี้อย่างใกล้ชิดตัวอย่างเช่นหากคุณรวบรวมรหัส C++ นี้บน MSVC และปล่อย LLVM IR:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      เป็นโมฆะ foo() { rust_panic a = {0, 1};
//          โยน;}
//
// นั่นคือสิ่งที่เราพยายามจะเลียนแบบเป็นหลักค่าคงที่ด้านล่างส่วนใหญ่คัดลอกมาจาก LLVM
//
// ไม่ว่าในกรณีใดโครงสร้างเหล่านี้ล้วนสร้างขึ้นในลักษณะที่คล้ายคลึงกันและมันก็ค่อนข้างละเอียดสำหรับเรา
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// โปรดทราบว่าเราจงใจละเลยกฎการโกงชื่อที่นี่: เราไม่ต้องการให้ C++ สามารถจับ Rust panics ได้เพียงแค่ประกาศ `struct rust_panic`
//
//
// เมื่อแก้ไขตรวจสอบให้แน่ใจว่าสตริงชื่อชนิดตรงกับที่ใช้ใน `compiler/rustc_codegen_llvm/src/intrinsic.rs` ทุกประการ
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // ไบต์ `\x01` ชั้นนำในที่นี้เป็นสัญญาณวิเศษสำหรับ LLVM ถึง *ไม่* ใช้การรบกวนอื่น ๆ เช่นการขึ้นต้นด้วยอักขระ `_`
    //
    //
    // สัญลักษณ์นี้คือ vtable ที่ใช้โดย `std::type_info` ของ C++
    // ออบเจ็กต์ประเภท `std::type_info` ตัวบอกประเภทมีตัวชี้ไปที่ตารางนี้
    // ตัวบอกประเภทอ้างอิงโดยโครงสร้าง C++ EH ที่กำหนดไว้ข้างต้นและที่เราสร้างไว้ด้านล่าง
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// ตัวบอกประเภทนี้ใช้เฉพาะเมื่อมีข้อยกเว้น
// ส่วนที่จับได้รับการจัดการโดย try intrinsic ซึ่งสร้าง TypeDescriptor ของตัวเอง
//
// สิ่งนี้ใช้ได้ดีเนื่องจากรันไทม์ MSVC ใช้การเปรียบเทียบสตริงกับชื่อชนิดเพื่อให้ตรงกับ TypeDescriptors แทนที่จะเป็นความเท่าเทียมกันของตัวชี้
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor ใช้หากโค้ด C++ ตัดสินใจจับข้อยกเว้นและปล่อยทิ้งโดยไม่เผยแพร่
// ส่วนที่จับได้ของ try intrinsic จะตั้งค่าคำแรกของอ็อบเจ็กต์ข้อยกเว้นเป็น 0 เพื่อให้ถูกข้ามโดย destructor
//
// โปรดสังเกตว่า x86 Windows ใช้รูปแบบการเรียก "thiscall" สำหรับฟังก์ชันสมาชิก C++ แทนที่จะใช้หลักการเรียก "C" เริ่มต้น
//
// ฟังก์ชัน except_copy เป็นฟังก์ชันพิเศษที่นี่: เรียกใช้โดยรันไทม์ MSVC ภายใต้บล็อก try/catch และ panic ที่เราสร้างขึ้นที่นี่จะถูกใช้เป็นผลลัพธ์ของสำเนาข้อยกเว้น
//
// สิ่งนี้ใช้โดยรันไทม์ C++ เพื่อรองรับการจับข้อยกเว้นด้วย std::exception_ptr ซึ่งเราไม่สามารถรองรับได้เนื่องจาก Box<dyn Any>ไม่สามารถโคลนได้
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException ดำเนินการทั้งหมดในสแต็กเฟรมนี้ดังนั้นจึงไม่จำเป็นต้องโอน `data` ไปยังฮีป
    // เราเพียงแค่ส่งสแต็กพอยน์เตอร์ไปยังฟังก์ชันนี้
    //
    // จำเป็นต้องใช้ ManuallyDrop ที่นี่เนื่องจากเราไม่ต้องการให้ Exception ถูกทิ้งเมื่อคลี่คลาย
    // แต่จะถูกทิ้งโดย exception_cleanup ซึ่งเรียกใช้โดยรันไทม์ C++
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // สิ่งนี้ ... อาจดูน่าประหลาดใจและสมเหตุสมผลบน MSVC แบบ 32 บิตพอยน์เตอร์ระหว่างโครงสร้างเหล่านี้เป็นเพียงพอยน์เตอร์
    // อย่างไรก็ตามบน MSVC 64 บิตตัวชี้ระหว่างโครงสร้างจะแสดงเป็นออฟเซ็ต 32 บิตจาก `__ImageBase`
    //
    // ดังนั้นบน MSVC แบบ 32 บิตเราสามารถประกาศพอยน์เตอร์เหล่านี้ทั้งหมดใน "แบบคงที่" ด้านบน
    // บน MSVC 64 บิตเราจะต้องแสดงการลบพอยน์เตอร์ในรูปแบบสถิตซึ่งขณะนี้ Rust ไม่อนุญาตดังนั้นเราจึงไม่สามารถทำได้จริง
    //
    // สิ่งที่ดีที่สุดถัดไปคือการเติมเต็มโครงสร้างเหล่านี้ในรันไทม์ (การตื่นตระหนกก็คือ "slow path" อยู่ดี)
    // ดังนั้นเราจึงตีความฟิลด์ตัวชี้ทั้งหมดเหล่านี้ใหม่เป็นจำนวนเต็ม 32 บิตจากนั้นเก็บค่าที่เกี่ยวข้องไว้ในนั้น (ในเชิงอะตอมเนื่องจาก panics อาจเกิดขึ้นพร้อมกัน)
    //
    // ในทางเทคนิครันไทม์อาจจะอ่านฟิลด์เหล่านี้แบบ nonatomic แต่ในทางทฤษฎีพวกเขาไม่เคยอ่านค่า *ผิด* ดังนั้นจึงไม่ควรเลวร้ายเกินไป ...
    //
    // ไม่ว่าในกรณีใดโดยพื้นฐานแล้วเราจำเป็นต้องทำสิ่งนี้จนกว่าเราจะสามารถแสดงการดำเนินการในสถิตยศาสตร์ได้มากขึ้น (และเราอาจไม่สามารถทำได้)
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // เพย์โหลด NULL ที่นี่หมายความว่าเรามาที่นี่จากการจับ (...) ของ __rust_try
    // สิ่งนี้เกิดขึ้นเมื่อตรวจพบข้อยกเว้นแปลกปลอมที่ไม่ใช่ Rust
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// สิ่งนี้จำเป็นสำหรับคอมไพลเลอร์เพื่อให้มีอยู่ (เช่นเป็นรายการ lang) แต่ไม่เคยเรียกโดยคอมไพเลอร์เนื่องจาก __C_specific_handler หรือ _except_handler3 เป็นฟังก์ชันบุคลิกภาพที่ใช้เสมอ
//
// ดังนั้นนี่เป็นเพียงการยกเลิกต้นขั้ว
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}