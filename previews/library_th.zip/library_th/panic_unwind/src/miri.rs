//! คลี่คลาย panics สำหรับมิริ
use alloc::boxed::Box;
use core::any::Any;

// ประเภทของน้ำหนักบรรทุกที่เครื่องยนต์ Miri แพร่กระจายผ่านการคลี่คลายสำหรับเรา
// ต้องมีขนาดตัวชี้
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// ฟังก์ชั่นภายนอกที่ให้ Miri เพื่อเริ่มคลี่คลาย
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // น้ำหนักบรรทุกที่เราส่งไปยัง `miri_start_panic` จะตรงกับอาร์กิวเมนต์ที่เราได้รับใน `cleanup` ด้านล่าง
    // เราจึงจัดกล่องขึ้นมาหนึ่งครั้งเพื่อให้ได้ขนาดตัวชี้
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // กู้คืน `Box` ที่อยู่ภายใต้
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}