//! คอมไพล์ส่วน profiler ของไลบรารี `compiler-rt`
//!
//! ดู build.rs สำหรับ libcompiler_builtins crate สำหรับรายละเอียด

use std::env;
use std::path::Path;

fn main() {
    let target = env::var("TARGET").expect("TARGET was not set");
    let cfg = &mut cc::Build::new();

    // FIXME: คำสั่ง `rerun-if-changed` ไม่ได้ถูกปล่อยออกมาในขณะนี้และสร้างสคริปต์
    // จะไม่ดำเนินการซ้ำกับการเปลี่ยนแปลงในไฟล์ต้นฉบับเหล่านี้หรือส่วนหัวที่รวมอยู่ในไฟล์เหล่านี้
    let mut profile_sources = vec![
        "GCDAProfiling.c",
        "InstrProfiling.c",
        "InstrProfilingBuffer.c",
        "InstrProfilingFile.c",
        "InstrProfilingMerge.c",
        "InstrProfilingMergeFile.c",
        "InstrProfilingNameVar.c",
        "InstrProfilingPlatformDarwin.c",
        "InstrProfilingPlatformFuchsia.c",
        "InstrProfilingPlatformLinux.c",
        "InstrProfilingPlatformOther.c",
        "InstrProfilingPlatformWindows.c",
        "InstrProfilingUtil.c",
        "InstrProfilingValue.c",
        "InstrProfilingVersionVar.c",
        "InstrProfilingWriter.c",
        // ไฟล์นี้ถูกเปลี่ยนชื่อเป็น LLVM 10
        "InstrProfilingRuntime.cc",
        "InstrProfilingRuntime.cpp",
        // ไฟล์เหล่านี้ถูกเพิ่มใน LLVM 11
        "InstrProfilingInternal.c",
        "InstrProfilingBiasVar.c",
    ];

    if target.contains("msvc") {
        // อย่าดึงไลบรารีเพิ่มเติมใน MSVC
        cfg.flag("/Zl");
        profile_sources.push("WindowsMMap.c");
        cfg.define("strdup", Some("_strdup"));
        cfg.define("open", Some("_open"));
        cfg.define("fdopen", Some("_fdopen"));
        cfg.define("getpid", Some("_getpid"));
        cfg.define("fileno", Some("_fileno"));
    } else {
        // ปิดคุณสมบัติต่างๆของ gcc และส่วนใหญ่จะคัดลอกระบบ build ของ compiler-rt อยู่แล้ว
        //
        cfg.flag("-fno-builtin");
        cfg.flag("-fomit-frame-pointer");
        cfg.define("VISIBILITY_HIDDEN", None);
        if !target.contains("windows") {
            cfg.flag("-fvisibility=hidden");
            cfg.define("COMPILER_RT_HAS_UNAME", Some("1"));
        } else {
            profile_sources.push("WindowsMMap.c");
        }
    }

    // สมมติว่า Unixes ที่เรากำลังสร้างนี้มี fnctl() พร้อมใช้งาน
    if env::var_os("CARGO_CFG_UNIX").is_some() {
        cfg.define("COMPILER_RT_HAS_FCNTL_LCK", Some("1"));
    }

    // นี่ควรเป็นฮิวริสติกที่ดีสำหรับเวลาที่ควรตั้งค่า COMPILER_RT_HAS_ATOMICS
    //
    if env::var_os("CARGO_CFG_TARGET_HAS_ATOMIC")
        .map(|features| features.to_string_lossy().to_lowercase().contains("ptr"))
        .unwrap_or(false)
    {
        cfg.define("COMPILER_RT_HAS_ATOMICS", Some("1"));
    }

    // โปรดทราบว่าสิ่งนี้ควรมีอยู่หากเราจะเรียกใช้ (มิฉะนั้นเราจะไม่สร้าง profiler builtins เลย)
    //
    let root = Path::new("../../src/llvm-project/compiler-rt");

    let src_root = root.join("lib").join("profile");
    for src in profile_sources {
        let path = src_root.join(src);
        if path.exists() {
            cfg.file(path);
        }
    }

    cfg.include(root.join("include"));
    cfg.warnings(false);
    cfg.compile("profiler-rt");
}