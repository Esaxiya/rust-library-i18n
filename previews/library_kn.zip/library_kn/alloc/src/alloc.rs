//! ಮೆಮೊರಿ ಹಂಚಿಕೆ API ಗಳು

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // ಜಾಗತಿಕ ಹಂಚಿಕೆಯನ್ನು ಕರೆಯುವ ಮ್ಯಾಜಿಕ್ ಚಿಹ್ನೆಗಳು ಇವು.rustc ಅವುಗಳನ್ನು `__rg_alloc` ಇತ್ಯಾದಿಗಳನ್ನು ಕರೆಯಲು ಉತ್ಪಾದಿಸುತ್ತದೆ.
    // `#[global_allocator]` ಗುಣಲಕ್ಷಣ ಇದ್ದರೆ (ಮ್ಯಾಕ್ರೋ ಗುಣಲಕ್ಷಣವನ್ನು ವಿಸ್ತರಿಸುವ ಕೋಡ್ ಆ ಕಾರ್ಯಗಳನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ), ಅಥವಾ libstd (`__rdl_alloc` ಇತ್ಯಾದಿಗಳಲ್ಲಿ ಡೀಫಾಲ್ಟ್ ಅನುಷ್ಠಾನಗಳನ್ನು ಕರೆಯುವುದು.
    //
    // `library/std/src/alloc.rs` ನಲ್ಲಿ) ಇಲ್ಲದಿದ್ದರೆ.
    // LLVM ನ rustc fork ಸಹ ವಿಶೇಷ-ಪ್ರಕರಣಗಳು ಈ ಕಾರ್ಯದ ಹೆಸರುಗಳು ಕ್ರಮವಾಗಿ `malloc`, `realloc`, ಮತ್ತು `free` ನಂತಹ ಅತ್ಯುತ್ತಮವಾಗಿಸಲು ಸಾಧ್ಯವಾಗುತ್ತದೆ.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// ಜಾಗತಿಕ ಮೆಮೊರಿ ಹಂಚಿಕೆ.
///
/// ಈ ಪ್ರಕಾರವು [`Allocator`] trait ಅನ್ನು `#[global_allocator]` ಗುಣಲಕ್ಷಣದೊಂದಿಗೆ ನೋಂದಾಯಿಸಲಾದ ಹಂಚಿಕೆದಾರರಿಗೆ ಕರೆಗಳನ್ನು ಫಾರ್ವರ್ಡ್ ಮಾಡುವ ಮೂಲಕ ಅಥವಾ `std` crate ನ ಡೀಫಾಲ್ಟ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
///
///
/// Note: ಈ ಪ್ರಕಾರವು ಅಸ್ಥಿರವಾಗಿದ್ದರೂ, ಅದು ಒದಗಿಸುವ ಕಾರ್ಯವನ್ನು [free functions in `alloc`](self#functions) ಮೂಲಕ ಪ್ರವೇಶಿಸಬಹುದು.
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// ಜಾಗತಿಕ ಹಂಚಿಕೆಯೊಂದಿಗೆ ಮೆಮೊರಿಯನ್ನು ನಿಯೋಜಿಸಿ.
///
/// ಈ ಕಾರ್ಯವು `#[global_allocator]` ಗುಣಲಕ್ಷಣದೊಂದಿಗೆ ನೋಂದಾಯಿಸಲ್ಪಟ್ಟ ಹಂಚಿಕೆಯ [`GlobalAlloc::alloc`] ವಿಧಾನಕ್ಕೆ ಕರೆಗಳನ್ನು ಫಾರ್ವರ್ಡ್ ಮಾಡುತ್ತದೆ, ಅಥವಾ `std` crate ಡೀಫಾಲ್ಟ್ ಆಗಿರುತ್ತದೆ.
///
///
/// ಈ ಕಾರ್ಯವು [`Global`] ಪ್ರಕಾರದ `alloc` ವಿಧಾನ ಮತ್ತು [`Allocator`] trait ಸ್ಥಿರವಾದಾಗ ಅದನ್ನು ಅಸಮ್ಮತಿಗೊಳಿಸುವ ನಿರೀಕ್ಷೆಯಿದೆ.
///
/// # Safety
///
/// [`GlobalAlloc::alloc`] ನೋಡಿ.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// ಜಾಗತಿಕ ಹಂಚಿಕೆಯೊಂದಿಗೆ ಮೆಮೊರಿಯನ್ನು ಡಿಲೊಕೇಟ್ ಮಾಡಿ.
///
/// ಈ ಕಾರ್ಯವು `#[global_allocator]` ಗುಣಲಕ್ಷಣದೊಂದಿಗೆ ನೋಂದಾಯಿಸಲ್ಪಟ್ಟ ಹಂಚಿಕೆಯ [`GlobalAlloc::dealloc`] ವಿಧಾನಕ್ಕೆ ಕರೆಗಳನ್ನು ಫಾರ್ವರ್ಡ್ ಮಾಡುತ್ತದೆ, ಅಥವಾ `std` crate ಡೀಫಾಲ್ಟ್ ಆಗಿರುತ್ತದೆ.
///
///
/// ಈ ಕಾರ್ಯವು [`Global`] ಪ್ರಕಾರದ `dealloc` ವಿಧಾನ ಮತ್ತು [`Allocator`] trait ಸ್ಥಿರವಾದಾಗ ಅದನ್ನು ಅಸಮ್ಮತಿಗೊಳಿಸುವ ನಿರೀಕ್ಷೆಯಿದೆ.
///
/// # Safety
///
/// [`GlobalAlloc::dealloc`] ನೋಡಿ.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// ಜಾಗತಿಕ ಹಂಚಿಕೆಯೊಂದಿಗೆ ಮೆಮೊರಿಯನ್ನು ಮರುಹಂಚಿಕೆ ಮಾಡಿ.
///
/// ಈ ಕಾರ್ಯವು `#[global_allocator]` ಗುಣಲಕ್ಷಣದೊಂದಿಗೆ ನೋಂದಾಯಿಸಲ್ಪಟ್ಟ ಹಂಚಿಕೆಯ [`GlobalAlloc::realloc`] ವಿಧಾನಕ್ಕೆ ಕರೆಗಳನ್ನು ಫಾರ್ವರ್ಡ್ ಮಾಡುತ್ತದೆ, ಅಥವಾ `std` crate ಡೀಫಾಲ್ಟ್ ಆಗಿರುತ್ತದೆ.
///
///
/// ಈ ಕಾರ್ಯವು [`Global`] ಪ್ರಕಾರದ `realloc` ವಿಧಾನ ಮತ್ತು [`Allocator`] trait ಸ್ಥಿರವಾದಾಗ ಅದನ್ನು ಅಸಮ್ಮತಿಗೊಳಿಸುವ ನಿರೀಕ್ಷೆಯಿದೆ.
///
/// # Safety
///
/// [`GlobalAlloc::realloc`] ನೋಡಿ.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// ಜಾಗತಿಕ ಹಂಚಿಕೆಯೊಂದಿಗೆ ಶೂನ್ಯ-ಪ್ರಾರಂಭದ ಮೆಮೊರಿಯನ್ನು ನಿಯೋಜಿಸಿ.
///
/// ಈ ಕಾರ್ಯವು `#[global_allocator]` ಗುಣಲಕ್ಷಣದೊಂದಿಗೆ ನೋಂದಾಯಿಸಲ್ಪಟ್ಟ ಹಂಚಿಕೆಯ [`GlobalAlloc::alloc_zeroed`] ವಿಧಾನಕ್ಕೆ ಕರೆಗಳನ್ನು ಫಾರ್ವರ್ಡ್ ಮಾಡುತ್ತದೆ, ಅಥವಾ `std` crate ಡೀಫಾಲ್ಟ್ ಆಗಿರುತ್ತದೆ.
///
///
/// ಈ ಕಾರ್ಯವು [`Global`] ಪ್ರಕಾರದ `alloc_zeroed` ವಿಧಾನ ಮತ್ತು [`Allocator`] trait ಸ್ಥಿರವಾದಾಗ ಅದನ್ನು ಅಸಮ್ಮತಿಗೊಳಿಸುವ ನಿರೀಕ್ಷೆಯಿದೆ.
///
/// # Safety
///
/// [`GlobalAlloc::alloc_zeroed`] ನೋಡಿ.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // ಸುರಕ್ಷತೆ: `layout` ಗಾತ್ರದಲ್ಲಿ ಶೂನ್ಯವಲ್ಲ,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // ಸುರಕ್ಷತೆ: `Allocator::grow` ನಂತೆಯೇ
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // ಸುರಕ್ಷತೆ: `old_size` ಶೂನ್ಯವಲ್ಲದ ಕಾರಣ `old_size` `new_size` ಗಿಂತ ದೊಡ್ಡದಾಗಿದೆ ಅಥವಾ ಸಮಾನವಾಗಿರುತ್ತದೆ
            // ಸುರಕ್ಷತಾ ಪರಿಸ್ಥಿತಿಗಳಿಗೆ ಅಗತ್ಯವಿರುವಂತೆ.ಇತರ ಷರತ್ತುಗಳನ್ನು ಕರೆ ಮಾಡುವವರು ಎತ್ತಿಹಿಡಿಯಬೇಕು
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` ಬಹುಶಃ `new_size >= old_layout.size()` ಅಥವಾ ಅದೇ ರೀತಿಯದ್ದನ್ನು ಪರಿಶೀಲಿಸುತ್ತದೆ.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // ಸುರಕ್ಷತೆ: ಏಕೆಂದರೆ `new_layout.size()` `old_size` ಗಿಂತ ದೊಡ್ಡದಾಗಿರಬೇಕು ಅಥವಾ ಸಮನಾಗಿರಬೇಕು,
            // ಹಳೆಯ ಮತ್ತು ಹೊಸ ಮೆಮೊರಿ ಹಂಚಿಕೆ ಎರಡೂ `old_size` ಬೈಟ್‌ಗಳಿಗಾಗಿ ಓದಲು ಮತ್ತು ಬರೆಯಲು ಮಾನ್ಯವಾಗಿರುತ್ತದೆ.
            // ಅಲ್ಲದೆ, ಹಳೆಯ ಹಂಚಿಕೆಯನ್ನು ಇನ್ನೂ ಸ್ಥಳಾಂತರಿಸಲಾಗಿಲ್ಲವಾದ್ದರಿಂದ, ಇದು `new_ptr` ಅನ್ನು ಅತಿಕ್ರಮಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ.
            // ಹೀಗಾಗಿ, `copy_nonoverlapping` ಗೆ ಕರೆ ಸುರಕ್ಷಿತವಾಗಿದೆ.
            // `dealloc` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಕರೆ ಮಾಡುವವರು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // ಸುರಕ್ಷತೆ: `layout` ಗಾತ್ರದಲ್ಲಿ ಶೂನ್ಯವಲ್ಲ,
            // ಇತರ ಷರತ್ತುಗಳನ್ನು ಕರೆ ಮಾಡುವವರು ಎತ್ತಿಹಿಡಿಯಬೇಕು
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ಸುರಕ್ಷತೆ: ಎಲ್ಲಾ ಷರತ್ತುಗಳನ್ನು ಕರೆ ಮಾಡುವವರು ಎತ್ತಿಹಿಡಿಯಬೇಕು
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ಸುರಕ್ಷತೆ: ಎಲ್ಲಾ ಷರತ್ತುಗಳನ್ನು ಕರೆ ಮಾಡುವವರು ಎತ್ತಿಹಿಡಿಯಬೇಕು
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರಿಂದ ಷರತ್ತುಗಳನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // ಸುರಕ್ಷತೆ: `new_size` ಶೂನ್ಯವಲ್ಲ.ಇತರ ಷರತ್ತುಗಳನ್ನು ಕರೆ ಮಾಡುವವರು ಎತ್ತಿಹಿಡಿಯಬೇಕು
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` ಬಹುಶಃ `new_size <= old_layout.size()` ಅಥವಾ ಅದೇ ರೀತಿಯದ್ದನ್ನು ಪರಿಶೀಲಿಸುತ್ತದೆ.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // ಸುರಕ್ಷತೆ: ಏಕೆಂದರೆ `new_size` `old_layout.size()` ಗಿಂತ ಚಿಕ್ಕದಾಗಿರಬೇಕು ಅಥವಾ ಸಮನಾಗಿರಬೇಕು,
            // ಹಳೆಯ ಮತ್ತು ಹೊಸ ಮೆಮೊರಿ ಹಂಚಿಕೆ ಎರಡೂ `new_size` ಬೈಟ್‌ಗಳಿಗಾಗಿ ಓದಲು ಮತ್ತು ಬರೆಯಲು ಮಾನ್ಯವಾಗಿರುತ್ತದೆ.
            // ಅಲ್ಲದೆ, ಹಳೆಯ ಹಂಚಿಕೆಯನ್ನು ಇನ್ನೂ ಸ್ಥಳಾಂತರಿಸಲಾಗಿಲ್ಲವಾದ್ದರಿಂದ, ಇದು `new_ptr` ಅನ್ನು ಅತಿಕ್ರಮಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ.
            // ಹೀಗಾಗಿ, `copy_nonoverlapping` ಗೆ ಕರೆ ಸುರಕ್ಷಿತವಾಗಿದೆ.
            // `dealloc` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಕರೆ ಮಾಡುವವರು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// ಅನನ್ಯ ಪಾಯಿಂಟರ್‌ಗಳಿಗೆ ಹಂಚಿಕೆದಾರ.
// ಈ ಕಾರ್ಯವು ಬಿಚ್ಚಬಾರದು.ಅದು ಮಾಡಿದರೆ, ಎಂಐಆರ್ ಕೋಡೆಜೆನ್ ವಿಫಲಗೊಳ್ಳುತ್ತದೆ.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// ಈ ಸಹಿ `Box` ನಂತೆಯೇ ಇರಬೇಕು, ಇಲ್ಲದಿದ್ದರೆ ICE ಸಂಭವಿಸುತ್ತದೆ.
// `Box` ಗೆ ಹೆಚ್ಚುವರಿ ನಿಯತಾಂಕವನ್ನು ಸೇರಿಸಿದಾಗ (`A: Allocator` ನಂತೆ), ಇದನ್ನು ಇಲ್ಲಿಯೂ ಸೇರಿಸಬೇಕಾಗುತ್ತದೆ.
// ಉದಾಹರಣೆಗೆ, `Box` ಅನ್ನು `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` ಗೆ ಬದಲಾಯಿಸಿದರೆ, ಈ ಕಾರ್ಯವನ್ನು `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` ಗೆ ಬದಲಾಯಿಸಬೇಕಾಗುತ್ತದೆ.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # ಹಂಚಿಕೆ ದೋಷ ಹ್ಯಾಂಡ್ಲರ್

extern "Rust" {
    // ಜಾಗತಿಕ ಹಂಚಿಕೆ ದೋಷ ಹ್ಯಾಂಡ್ಲರ್ ಎಂದು ಕರೆಯಲು ಇದು ಮ್ಯಾಜಿಕ್ ಚಿಹ್ನೆ.
    // `#[alloc_error_handler]` ಇದ್ದರೆ `__rg_oom` ಗೆ ಕರೆ ಮಾಡಲು ಅಥವಾ (`__rdl_oom`) ಗಿಂತ ಕೆಳಗಿನ ಡೀಫಾಲ್ಟ್ ಅನುಷ್ಠಾನಗಳನ್ನು ಕರೆಯಲು rustc ಅದನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// ಮೆಮೊರಿ ಹಂಚಿಕೆ ದೋಷ ಅಥವಾ ವೈಫಲ್ಯವನ್ನು ಸ್ಥಗಿತಗೊಳಿಸಿ.
///
/// ಹಂಚಿಕೆ ದೋಷಕ್ಕೆ ಪ್ರತಿಕ್ರಿಯೆಯಾಗಿ ಗಣನೆಯನ್ನು ಸ್ಥಗಿತಗೊಳಿಸಲು ಬಯಸುವ ಮೆಮೊರಿ ಹಂಚಿಕೆ API ಗಳ ಕರೆ ಮಾಡುವವರು `panic!` ಅಥವಾ ಅಂತಹುದೇ ರೀತಿಯನ್ನು ನೇರವಾಗಿ ಆಹ್ವಾನಿಸುವ ಬದಲು ಈ ಕಾರ್ಯವನ್ನು ಕರೆಯಲು ಪ್ರೋತ್ಸಾಹಿಸಲಾಗುತ್ತದೆ.
///
///
/// ಈ ಕಾರ್ಯದ ಪೂರ್ವನಿಯೋಜಿತ ನಡವಳಿಕೆಯು ಸಂದೇಶವನ್ನು ಪ್ರಮಾಣಿತ ದೋಷಕ್ಕೆ ಮುದ್ರಿಸುವುದು ಮತ್ತು ಪ್ರಕ್ರಿಯೆಯನ್ನು ಸ್ಥಗಿತಗೊಳಿಸುವುದು.
/// ಇದನ್ನು [`set_alloc_error_hook`] ಮತ್ತು [`take_alloc_error_hook`] ನೊಂದಿಗೆ ಬದಲಾಯಿಸಬಹುದು.
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// ಹಂಚಿಕೆ ಪರೀಕ್ಷೆಗಾಗಿ `std::alloc::handle_alloc_error` ಅನ್ನು ನೇರವಾಗಿ ಬಳಸಬಹುದು.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // ರಚಿಸಿದ `__rust_alloc_error_handler` ಮೂಲಕ ಕರೆಯಲಾಗುತ್ತದೆ

    // `#[alloc_error_handler]` ಇಲ್ಲದಿದ್ದರೆ
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // `#[alloc_error_handler]` ಇದ್ದರೆ
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// ಪೂರ್ವ ನಿಯೋಜಿತ, ಪ್ರಾರಂಭಿಸದ ಮೆಮೊರಿಗೆ ತದ್ರೂಪುಗಳನ್ನು ವಿಶೇಷಗೊಳಿಸಿ.
/// `Box::clone` ಮತ್ತು `Rc`/`Arc::make_mut` ನಿಂದ ಬಳಸಲಾಗುತ್ತದೆ.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // *ಮೊದಲು* ನಿಗದಿಪಡಿಸಿದ ನಂತರ ಆಪ್ಟಿಮೈಜರ್‌ಗೆ ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮೌಲ್ಯವನ್ನು ರಚಿಸಲು, ಸ್ಥಳೀಯವನ್ನು ಬಿಟ್ಟು ಚಲಿಸಲು ಅನುಮತಿಸಬಹುದು.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // ಸ್ಥಳೀಯ ಮೌಲ್ಯವನ್ನು ಎಂದಿಗೂ ಒಳಗೊಳ್ಳದೆ ನಾವು ಯಾವಾಗಲೂ ಸ್ಥಳದಲ್ಲಿಯೇ ನಕಲಿಸಬಹುದು.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}