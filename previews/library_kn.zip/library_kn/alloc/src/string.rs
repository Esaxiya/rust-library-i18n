//! ಯುಟಿಎಫ್-8-ಎನ್ಕೋಡ್ ಮಾಡಲಾದ, ಬೆಳೆಯಬಹುದಾದ ಸ್ಟ್ರಿಂಗ್.
//!
//! ಈ ಮಾಡ್ಯೂಲ್ [`String`] ಪ್ರಕಾರ, ತಂತಿಗಳಾಗಿ ಪರಿವರ್ತಿಸಲು [`ToString`] trait, ಮತ್ತು [`ಸ್ಟ್ರಿಂಗ್`] ಗಳೊಂದಿಗೆ ಕೆಲಸ ಮಾಡುವುದರಿಂದ ಉಂಟಾಗುವ ಹಲವಾರು ದೋಷ ಪ್ರಕಾರಗಳನ್ನು ಒಳಗೊಂಡಿದೆ.
//!
//!
//! # Examples
//!
//! ಸ್ಟ್ರಿಂಗ್ ಅಕ್ಷರಶಃ ಹೊಸ [`String`] ಅನ್ನು ರಚಿಸಲು ಅನೇಕ ಮಾರ್ಗಗಳಿವೆ:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! ನೀವು ಒಂದಕ್ಕೊಂದು ಹೊಸ [`String`] ಅನ್ನು ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ ಒಂದರಿಂದ ರಚಿಸಬಹುದು
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! ನೀವು ಮಾನ್ಯ UTF-8 ಬೈಟ್‌ಗಳ vector ಹೊಂದಿದ್ದರೆ, ನೀವು ಅದರಿಂದ [`String`] ಅನ್ನು ಮಾಡಬಹುದು.ನೀವು ರಿವರ್ಸ್ ಕೂಡ ಮಾಡಬಹುದು.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // ಈ ಬೈಟ್‌ಗಳು ಮಾನ್ಯವೆಂದು ನಮಗೆ ತಿಳಿದಿದೆ, ಆದ್ದರಿಂದ ನಾವು `unwrap()` ಅನ್ನು ಬಳಸುತ್ತೇವೆ.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// ಯುಟಿಎಫ್-8-ಎನ್ಕೋಡ್ ಮಾಡಲಾದ, ಬೆಳೆಯಬಹುದಾದ ಸ್ಟ್ರಿಂಗ್.
///
/// `String` ಪ್ರಕಾರವು ಸ್ಟ್ರಿಂಗ್‌ನ ವಿಷಯಗಳ ಮೇಲೆ ಮಾಲೀಕತ್ವವನ್ನು ಹೊಂದಿರುವ ಸಾಮಾನ್ಯ ಸ್ಟ್ರಿಂಗ್ ಪ್ರಕಾರವಾಗಿದೆ.ಇದು ತನ್ನ ಎರವಲು ಪಡೆದ ಪ್ರತಿರೂಪವಾದ ಪ್ರಾಚೀನ [`str`] ನೊಂದಿಗೆ ನಿಕಟ ಸಂಬಂಧವನ್ನು ಹೊಂದಿದೆ.
///
/// # Examples
///
/// ನೀವು [`String::from`] ನೊಂದಿಗೆ [a literal string][`str`] ನಿಂದ `String` ಅನ್ನು ರಚಿಸಬಹುದು:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// ನೀವು [`push`] ವಿಧಾನದೊಂದಿಗೆ `String` ಗೆ [`char`] ಅನ್ನು ಸೇರಿಸಬಹುದು, ಮತ್ತು [`push_str`] ವಿಧಾನದೊಂದಿಗೆ [`&str`] ಅನ್ನು ಸೇರಿಸಬಹುದು:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// ನೀವು UTF-8 ಬೈಟ್‌ಗಳ vector ಹೊಂದಿದ್ದರೆ, ನೀವು [`from_utf8`] ವಿಧಾನದಿಂದ ಅದರಿಂದ `String` ಅನ್ನು ರಚಿಸಬಹುದು:
///
/// ```
/// // ಕೆಲವು ಬೈಟ್‌ಗಳು, vector ನಲ್ಲಿ
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // ಈ ಬೈಟ್‌ಗಳು ಮಾನ್ಯವೆಂದು ನಮಗೆ ತಿಳಿದಿದೆ, ಆದ್ದರಿಂದ ನಾವು `unwrap()` ಅನ್ನು ಬಳಸುತ್ತೇವೆ.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `ಸ್ಟ್ರಿಂಗ್`ಗಳು ಯಾವಾಗಲೂ ಮಾನ್ಯ UTF-8 ಆಗಿರುತ್ತವೆ.ಇದು ಕೆಲವು ಪರಿಣಾಮಗಳನ್ನು ಹೊಂದಿದೆ, ಅದರಲ್ಲಿ ಮೊದಲನೆಯದು ನಿಮಗೆ ಯುಟಿಎಫ್-8 ಅಲ್ಲದ ಸ್ಟ್ರಿಂಗ್ ಅಗತ್ಯವಿದ್ದರೆ, ಎಕ್ಸ್ 02 ಎಕ್ಸ್ ಅನ್ನು ಪರಿಗಣಿಸಿ.ಇದು ಹೋಲುತ್ತದೆ, ಆದರೆ UTF-8 ನಿರ್ಬಂಧವಿಲ್ಲದೆ.ಎರಡನೆಯ ಸೂಚನೆಯೆಂದರೆ ನೀವು `String` ಗೆ ಸೂಚ್ಯಂಕ ಮಾಡಲು ಸಾಧ್ಯವಿಲ್ಲ:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// ಸೂಚ್ಯಂಕವು ಸ್ಥಿರ-ಸಮಯದ ಕಾರ್ಯಾಚರಣೆಯಾಗಿದೆ, ಆದರೆ UTF-8 ಎನ್‌ಕೋಡಿಂಗ್ ಇದನ್ನು ಮಾಡಲು ನಮಗೆ ಅನುಮತಿಸುವುದಿಲ್ಲ.ಇದಲ್ಲದೆ, ಸೂಚ್ಯಂಕವು ಯಾವ ರೀತಿಯ ವಿಷಯವನ್ನು ಹಿಂತಿರುಗಿಸಬೇಕು ಎಂಬುದು ಸ್ಪಷ್ಟವಾಗಿಲ್ಲ: ಬೈಟ್, ಕೋಡ್‌ಪಾಯಿಂಟ್ ಅಥವಾ ಗ್ರ್ಯಾಫೀಮ್ ಕ್ಲಸ್ಟರ್.
/// [`bytes`] ಮತ್ತು [`chars`] ವಿಧಾನಗಳು ಕ್ರಮವಾಗಿ ಮೊದಲ ಎರಡರ ಮೇಲೆ ಪುನರಾವರ್ತಕಗಳನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತವೆ.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `ಸ್ಟ್ರಿಂಗ್` ಕಾರ್ಯಗತಗೊಳಿಸಿ [`ಡೆರೆಫ್`] `<Target=str>`, ಮತ್ತು ಆದ್ದರಿಂದ [`str`] ನ ಎಲ್ಲಾ ವಿಧಾನಗಳನ್ನು ಆನುವಂಶಿಕವಾಗಿ ಪಡೆದುಕೊಳ್ಳಿ.ಹೆಚ್ಚುವರಿಯಾಗಿ, ಆಂಪರ್‌ಸಾಂಡ್ (`&`) ಅನ್ನು ಬಳಸಿಕೊಂಡು [`&str`] ತೆಗೆದುಕೊಳ್ಳುವ ಕಾರ್ಯಕ್ಕೆ ನೀವು `String` ಅನ್ನು ರವಾನಿಸಬಹುದು ಎಂದರ್ಥ:
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// ಇದು `String` ನಿಂದ [`&str`] ಅನ್ನು ರಚಿಸುತ್ತದೆ ಮತ್ತು ಅದನ್ನು ಹಾದುಹೋಗುತ್ತದೆ. ಈ ಪರಿವರ್ತನೆಯು ತುಂಬಾ ಅಗ್ಗವಾಗಿದೆ, ಮತ್ತು ಸಾಮಾನ್ಯವಾಗಿ, ಕಾರ್ಯಗಳು [`&str`] ಗಳನ್ನು ಕೆಲವು ನಿರ್ದಿಷ್ಟ ಕಾರಣಗಳಿಗಾಗಿ `String` ಅಗತ್ಯವಿಲ್ಲದಿದ್ದರೆ ವಾದಗಳಾಗಿ ಸ್ವೀಕರಿಸುತ್ತವೆ.
///
/// ಕೆಲವು ಸಂದರ್ಭಗಳಲ್ಲಿ, [`Deref`] ಬಲಾತ್ಕಾರ ಎಂದು ಕರೆಯಲ್ಪಡುವ ಈ ಪರಿವರ್ತನೆ ಮಾಡಲು Rust ಗೆ ಸಾಕಷ್ಟು ಮಾಹಿತಿ ಇಲ್ಲ.ಕೆಳಗಿನ ಉದಾಹರಣೆಯಲ್ಲಿ [`&'a str`][`&str`] ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ trait `TraitExample` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ, ಮತ್ತು `example_func` ಕಾರ್ಯವು trait ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಯಾವುದನ್ನಾದರೂ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
/// ಈ ಸಂದರ್ಭದಲ್ಲಿ Rust ಎರಡು ಸೂಚ್ಯ ಪರಿವರ್ತನೆಗಳನ್ನು ಮಾಡಬೇಕಾಗುತ್ತದೆ, ಅದು Rust ಗೆ ಮಾಡಲು ಮಾರ್ಗವಿಲ್ಲ.
/// ಆ ಕಾರಣಕ್ಕಾಗಿ, ಈ ಕೆಳಗಿನ ಉದಾಹರಣೆಯು ಕಂಪೈಲ್ ಮಾಡುವುದಿಲ್ಲ.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// ಬದಲಿಗೆ ಎರಡು ಆಯ್ಕೆಗಳಿವೆ.ಮೊದಲನೆಯದು `example_func(&example_string);` ರೇಖೆಯನ್ನು `example_func(example_string.as_str());` ಗೆ ಬದಲಾಯಿಸುವುದು, [`as_str()`] ವಿಧಾನವನ್ನು ಬಳಸಿಕೊಂಡು ಸ್ಟ್ರಿಂಗ್ ಹೊಂದಿರುವ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಸ್ಪಷ್ಟವಾಗಿ ಹೊರತೆಗೆಯುವುದು.
/// ಎರಡನೇ ಮಾರ್ಗವು `example_func(&example_string);` ಅನ್ನು `example_func(&*example_string);` ಗೆ ಬದಲಾಯಿಸುತ್ತದೆ.
/// ಈ ಸಂದರ್ಭದಲ್ಲಿ ನಾವು `String` ಅನ್ನು [`str`][`&str`] ಗೆ ಡಿಫರೆನ್ಸ್ ಮಾಡುತ್ತಿದ್ದೇವೆ, ನಂತರ [`str`][`&str`] ಅನ್ನು [`&str`] ಗೆ ಉಲ್ಲೇಖಿಸುತ್ತೇವೆ.
/// ಎರಡನೆಯ ಮಾರ್ಗವು ಹೆಚ್ಚು ಭಾಷಾಶಾಸ್ತ್ರೀಯವಾಗಿದೆ, ಆದಾಗ್ಯೂ ಎರಡೂ ಸೂಚ್ಯ ಪರಿವರ್ತನೆಯನ್ನು ಅವಲಂಬಿಸುವುದಕ್ಕಿಂತ ಸ್ಪಷ್ಟವಾಗಿ ಮತಾಂತರವನ್ನು ಮಾಡಲು ಕೆಲಸ ಮಾಡುತ್ತದೆ.
///
/// # Representation
///
/// `String` ಮೂರು ಘಟಕಗಳಿಂದ ಕೂಡಿದೆ: ಕೆಲವು ಬೈಟ್‌ಗಳಿಗೆ ಪಾಯಿಂಟರ್, ಉದ್ದ ಮತ್ತು ಸಾಮರ್ಥ್ಯ.ಪಾಯಿಂಟರ್ ತನ್ನ ಡೇಟಾವನ್ನು ಸಂಗ್ರಹಿಸಲು ಬಳಸುವ ಆಂತರಿಕ ಬಫರ್ `String` ಗೆ ಸೂಚಿಸುತ್ತದೆ.ಉದ್ದವು ಪ್ರಸ್ತುತ ಬಫರ್‌ನಲ್ಲಿ ಸಂಗ್ರಹವಾಗಿರುವ ಬೈಟ್‌ಗಳ ಸಂಖ್ಯೆ, ಮತ್ತು ಸಾಮರ್ಥ್ಯವು ಬೈಟ್‌ಗಳಲ್ಲಿ ಬಫರ್‌ನ ಗಾತ್ರವಾಗಿದೆ.
///
/// ಅದರಂತೆ, ಉದ್ದವು ಯಾವಾಗಲೂ ಸಾಮರ್ಥ್ಯಕ್ಕಿಂತ ಕಡಿಮೆ ಅಥವಾ ಸಮನಾಗಿರುತ್ತದೆ.
///
/// ಈ ಬಫರ್ ಅನ್ನು ಯಾವಾಗಲೂ ರಾಶಿಯಲ್ಲಿ ಸಂಗ್ರಹಿಸಲಾಗುತ್ತದೆ.
///
/// ನೀವು ಇವುಗಳನ್ನು [`as_ptr`], [`len`], ಮತ್ತು [`capacity`] ವಿಧಾನಗಳೊಂದಿಗೆ ನೋಡಬಹುದು:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME vec_into_raw_parts ಅನ್ನು ಸ್ಥಿರಗೊಳಿಸಿದಾಗ ಇದನ್ನು ನವೀಕರಿಸಿ.
/// // ಸ್ಟ್ರಿಂಗ್‌ನ ಡೇಟಾವನ್ನು ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಬಿಡುವುದನ್ನು ತಡೆಯಿರಿ
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // ಕಥೆಯಲ್ಲಿ ಹತ್ತೊಂಬತ್ತು ಬೈಟ್‌ಗಳಿವೆ
/// assert_eq!(19, len);
///
/// // ನಾವು ಪಿಟಿಆರ್, ಲೆನ್ ಮತ್ತು ಸಾಮರ್ಥ್ಯದಿಂದ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಮರು-ನಿರ್ಮಿಸಬಹುದು.
/// // ಇದು ಅಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ಘಟಕಗಳು ಮಾನ್ಯವಾಗಿದೆಯೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ನಾವು ಜವಾಬ್ದಾರರಾಗಿರುತ್ತೇವೆ:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// `String` ಸಾಕಷ್ಟು ಸಾಮರ್ಥ್ಯವನ್ನು ಹೊಂದಿದ್ದರೆ, ಅದಕ್ಕೆ ಅಂಶಗಳನ್ನು ಸೇರಿಸುವುದರಿಂದ ಮರು ಹಂಚಿಕೆ ಆಗುವುದಿಲ್ಲ.ಉದಾಹರಣೆಗೆ, ಈ ಪ್ರೋಗ್ರಾಂ ಅನ್ನು ಪರಿಗಣಿಸಿ:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// ಇದು ಈ ಕೆಳಗಿನವುಗಳನ್ನು ನೀಡುತ್ತದೆ:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// ಮೊದಲಿಗೆ, ನಮ್ಮಲ್ಲಿ ಯಾವುದೇ ಮೆಮೊರಿ ಹಂಚಿಕೆಯಾಗಿಲ್ಲ, ಆದರೆ ನಾವು ಸ್ಟ್ರಿಂಗ್‌ಗೆ ಸೇರ್ಪಡೆಗೊಳ್ಳುತ್ತಿದ್ದಂತೆ, ಅದು ಅದರ ಸಾಮರ್ಥ್ಯವನ್ನು ಸೂಕ್ತವಾಗಿ ಹೆಚ್ಚಿಸುತ್ತದೆ.ಆರಂಭದಲ್ಲಿ ಸರಿಯಾದ ಸಾಮರ್ಥ್ಯವನ್ನು ನಿಯೋಜಿಸಲು ನಾವು [`with_capacity`] ವಿಧಾನವನ್ನು ಬಳಸಿದರೆ:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// ನಾವು ಬೇರೆ output ಟ್‌ಪುಟ್‌ನೊಂದಿಗೆ ಕೊನೆಗೊಳ್ಳುತ್ತೇವೆ:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// ಇಲ್ಲಿ, ಲೂಪ್ ಒಳಗೆ ಹೆಚ್ಚಿನ ಮೆಮೊರಿಯನ್ನು ನಿಯೋಜಿಸುವ ಅಗತ್ಯವಿಲ್ಲ.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// UTF-8 ಬೈಟ್ vector ನಿಂದ `String` ಅನ್ನು ಪರಿವರ್ತಿಸುವಾಗ ಸಂಭವನೀಯ ದೋಷ ಮೌಲ್ಯ.
///
/// ಈ ಪ್ರಕಾರವು [`String`] ನಲ್ಲಿನ [`from_utf8`] ವಿಧಾನದ ದೋಷ ಪ್ರಕಾರವಾಗಿದೆ.
/// ಮರುಹಂಚಿಕೆಗಳನ್ನು ಎಚ್ಚರಿಕೆಯಿಂದ ತಪ್ಪಿಸುವ ರೀತಿಯಲ್ಲಿ ಇದನ್ನು ವಿನ್ಯಾಸಗೊಳಿಸಲಾಗಿದೆ: ಪರಿವರ್ತನೆ ಪ್ರಯತ್ನದಲ್ಲಿ ಬಳಸಲಾದ ಬೈಟ್ vector ಅನ್ನು [`into_bytes`] ವಿಧಾನವು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// [`std::str`] ಒದಗಿಸಿದ [`Utf8Error`] ಪ್ರಕಾರವು [`u8`] ನ ಸ್ಲೈಸ್ ಅನ್ನು [`&str`] ಗೆ ಪರಿವರ್ತಿಸುವಾಗ ಸಂಭವಿಸಬಹುದಾದ ದೋಷವನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
/// ಈ ಅರ್ಥದಲ್ಲಿ, ಇದು `FromUtf8Error` ಗೆ ಅನಲಾಗ್ ಆಗಿದೆ, ಮತ್ತು ನೀವು `FromUtf8Error` ನಿಂದ [`utf8_error`] ವಿಧಾನದ ಮೂಲಕ ಒಂದನ್ನು ಪಡೆಯಬಹುದು.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// ಮೂಲ ಬಳಕೆ:
///
/// ```
/// // vector ನಲ್ಲಿ ಕೆಲವು ಅಮಾನ್ಯ ಬೈಟ್‌ಗಳು
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// UTF-16 ಬೈಟ್ ಸ್ಲೈಸ್‌ನಿಂದ `String` ಅನ್ನು ಪರಿವರ್ತಿಸುವಾಗ ಸಂಭವನೀಯ ದೋಷ ಮೌಲ್ಯ.
///
/// ಈ ಪ್ರಕಾರವು [`String`] ನಲ್ಲಿನ [`from_utf16`] ವಿಧಾನದ ದೋಷ ಪ್ರಕಾರವಾಗಿದೆ.
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// ಮೂಲ ಬಳಕೆ:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// ಹೊಸ ಖಾಲಿ `String` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// `String` ಖಾಲಿಯಾಗಿರುವುದರಿಂದ, ಇದು ಯಾವುದೇ ಆರಂಭಿಕ ಬಫರ್ ಅನ್ನು ನಿಯೋಜಿಸುವುದಿಲ್ಲ.ಇದರರ್ಥ ಈ ಆರಂಭಿಕ ಕಾರ್ಯಾಚರಣೆಯು ತುಂಬಾ ಅಗ್ಗವಾಗಿದೆ, ನೀವು ಡೇಟಾವನ್ನು ಸೇರಿಸಿದಾಗ ಅದು ನಂತರ ಹೆಚ್ಚಿನ ಹಂಚಿಕೆಗೆ ಕಾರಣವಾಗಬಹುದು.
    ///
    /// `String` ಎಷ್ಟು ಡೇಟಾವನ್ನು ಹಿಡಿದಿಟ್ಟುಕೊಳ್ಳುತ್ತದೆ ಎಂಬ ಕಲ್ಪನೆಯನ್ನು ನೀವು ಹೊಂದಿದ್ದರೆ, ಅತಿಯಾದ ಮರು-ಹಂಚಿಕೆಯನ್ನು ತಡೆಯಲು [`with_capacity`] ವಿಧಾನವನ್ನು ಪರಿಗಣಿಸಿ.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// ನಿರ್ದಿಷ್ಟ ಸಾಮರ್ಥ್ಯದೊಂದಿಗೆ ಹೊಸ ಖಾಲಿ `String` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// `ಸ್ಟ್ರಿಂಗ್‌ಗಳು ತಮ್ಮ ಡೇಟಾವನ್ನು ಹಿಡಿದಿಡಲು ಆಂತರಿಕ ಬಫರ್ ಅನ್ನು ಹೊಂದಿವೆ.
    /// ಸಾಮರ್ಥ್ಯವು ಆ ಬಫರ್‌ನ ಉದ್ದವಾಗಿದೆ, ಮತ್ತು ಇದನ್ನು [`capacity`] ವಿಧಾನದೊಂದಿಗೆ ಪ್ರಶ್ನಿಸಬಹುದು.
    /// ಈ ವಿಧಾನವು ಖಾಲಿ `String` ಅನ್ನು ರಚಿಸುತ್ತದೆ, ಆದರೆ `capacity` ಬೈಟ್‌ಗಳನ್ನು ಹಿಡಿದಿಟ್ಟುಕೊಳ್ಳಬಲ್ಲ ಆರಂಭಿಕ ಬಫರ್‌ನೊಂದಿಗೆ.
    /// ನೀವು `String` ಗೆ ಒಂದು ಗುಂಪಿನ ಡೇಟಾವನ್ನು ಸೇರಿಸುತ್ತಿರುವಾಗ ಇದು ಉಪಯುಕ್ತವಾಗಿದೆ, ಇದು ಮಾಡಬೇಕಾದ ಮರುಹಂಚಿಕೆಗಳ ಸಂಖ್ಯೆಯನ್ನು ಕಡಿಮೆ ಮಾಡುತ್ತದೆ.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// ಕೊಟ್ಟಿರುವ ಸಾಮರ್ಥ್ಯವು `0` ಆಗಿದ್ದರೆ, ಯಾವುದೇ ಹಂಚಿಕೆ ಸಂಭವಿಸುವುದಿಲ್ಲ, ಮತ್ತು ಈ ವಿಧಾನವು [`new`] ವಿಧಾನಕ್ಕೆ ಹೋಲುತ್ತದೆ.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // ಹೆಚ್ಚಿನ ಸಾಮರ್ಥ್ಯವನ್ನು ಹೊಂದಿದ್ದರೂ ಸಹ ಸ್ಟ್ರಿಂಗ್ ಯಾವುದೇ ಅಕ್ಷರಗಳನ್ನು ಹೊಂದಿಲ್ಲ
    /// assert_eq!(s.len(), 0);
    ///
    /// // ಮರುಹಂಚಿಕೆ ಮಾಡದೆ ಇವೆಲ್ಲವನ್ನೂ ಮಾಡಲಾಗುತ್ತದೆ ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... ಆದರೆ ಇದು ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಮರುಹಂಚಿಕೆ ಮಾಡುವಂತೆ ಮಾಡಬಹುದು
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): cfg(test) ನೊಂದಿಗೆ ಈ ವಿಧಾನದ ವ್ಯಾಖ್ಯಾನಕ್ಕೆ ಅಗತ್ಯವಿರುವ ಅಂತರ್ಗತ `[T]::to_vec` ವಿಧಾನವು ಲಭ್ಯವಿಲ್ಲ.
    // ಪರೀಕ್ಷಾ ಉದ್ದೇಶಗಳಿಗಾಗಿ ನಮಗೆ ಈ ವಿಧಾನದ ಅಗತ್ಯವಿಲ್ಲದ ಕಾರಣ, ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ ನಾನು ಅದನ್ನು ಎನ್‌ಬಿ slice.rs ನಲ್ಲಿ slice::hack ಮಾಡ್ಯೂಲ್ ಅನ್ನು ನೋಡುತ್ತೇನೆ
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// vector ಬೈಟ್‌ಗಳನ್ನು `String` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ([`String`]) ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ([`u8`]) ಬೈಟ್‌ಗಳಿಂದ ಮಾಡಲಾಗಿದೆ, ಮತ್ತು X0vector0Z ಬೈಟ್‌ಗಳ ([`Vec<u8>`]) ಅನ್ನು ಬೈಟ್‌ಗಳಿಂದ ಮಾಡಲಾಗಿದೆ, ಆದ್ದರಿಂದ ಈ ಕಾರ್ಯವು ಎರಡರ ನಡುವೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    /// ಎಲ್ಲಾ ಬೈಟ್ ಚೂರುಗಳು ಮಾನ್ಯ `ಸ್ಟ್ರಿಂಗ್` ಗಳಲ್ಲ, ಆದಾಗ್ಯೂ: `String` ಗೆ ಅದು ಮಾನ್ಯ UTF-8 ಎಂದು ಅಗತ್ಯವಿದೆ.
    /// `from_utf8()` ಬೈಟ್‌ಗಳು ಮಾನ್ಯ UTF-8 ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ಪರಿಶೀಲಿಸುತ್ತದೆ, ತದನಂತರ ಪರಿವರ್ತನೆ ಮಾಡುತ್ತದೆ.
    ///
    /// ಬೈಟ್ ಸ್ಲೈಸ್ ಮಾನ್ಯ UTF-8 ಎಂದು ನಿಮಗೆ ಖಚಿತವಾಗಿದ್ದರೆ, ಮತ್ತು ಸಿಂಧುತ್ವ ಪರಿಶೀಲನೆಯ ಓವರ್ಹೆಡ್ ಅನ್ನು ನೀವು ಅನುಭವಿಸಲು ಬಯಸುವುದಿಲ್ಲವಾದರೆ, ಈ ಕಾರ್ಯದ ಅಸುರಕ್ಷಿತ ಆವೃತ್ತಿಯಿದೆ, [`from_utf8_unchecked`], ಅದೇ ನಡವಳಿಕೆಯನ್ನು ಹೊಂದಿದೆ ಆದರೆ ಚೆಕ್ ಅನ್ನು ಬಿಟ್ಟುಬಿಡುತ್ತದೆ.
    ///
    ///
    /// ದಕ್ಷತೆಯ ದೃಷ್ಟಿಯಿಂದ vector ಅನ್ನು ನಕಲಿಸದಂತೆ ಈ ವಿಧಾನವು ಕಾಳಜಿ ವಹಿಸುತ್ತದೆ.
    ///
    /// ನಿಮಗೆ `String` ಬದಲಿಗೆ [`&str`] ಅಗತ್ಯವಿದ್ದರೆ, [`str::from_utf8`] ಅನ್ನು ಪರಿಗಣಿಸಿ.
    ///
    /// ಈ ವಿಧಾನದ ವಿಲೋಮವು [`into_bytes`] ಆಗಿದೆ.
    ///
    /// # Errors
    ///
    /// ಒದಗಿಸಿದ ಬೈಟ್‌ಗಳು ಏಕೆ UTF-8 ಅಲ್ಲ ಎಂಬ ವಿವರಣೆಯೊಂದಿಗೆ ಸ್ಲೈಸ್ UTF-8 ಅಲ್ಲದಿದ್ದರೆ [`Err`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.ನೀವು ಸ್ಥಳಾಂತರಿಸಿದ vector ಅನ್ನು ಸಹ ಸೇರಿಸಲಾಗಿದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// // ಕೆಲವು ಬೈಟ್‌ಗಳು, vector ನಲ್ಲಿ
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // ಈ ಬೈಟ್‌ಗಳು ಮಾನ್ಯವೆಂದು ನಮಗೆ ತಿಳಿದಿದೆ, ಆದ್ದರಿಂದ ನಾವು `unwrap()` ಅನ್ನು ಬಳಸುತ್ತೇವೆ.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// ತಪ್ಪಾದ ಬೈಟ್‌ಗಳು:
    ///
    /// ```
    /// // vector ನಲ್ಲಿ ಕೆಲವು ಅಮಾನ್ಯ ಬೈಟ್‌ಗಳು
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// ಈ ದೋಷದಿಂದ ನೀವು ಏನು ಮಾಡಬಹುದು ಎಂಬುದರ ಕುರಿತು ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ [`FromUtf8Error`] ಗಾಗಿ ಡಾಕ್ಸ್ ನೋಡಿ.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// ಅಮಾನ್ಯ ಅಕ್ಷರಗಳನ್ನು ಒಳಗೊಂಡಂತೆ ಬೈಟ್‌ಗಳ ಸ್ಲೈಸ್ ಅನ್ನು ಸ್ಟ್ರಿಂಗ್‌ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ತಂತಿಗಳನ್ನು ([`u8`]) ಬೈಟ್‌ಗಳಿಂದ ತಯಾರಿಸಲಾಗುತ್ತದೆ, ಮತ್ತು ([`&[u8]`][byteslice]) ಬೈಟ್‌ಗಳ ಸ್ಲೈಸ್ ಬೈಟ್‌ಗಳಿಂದ ಮಾಡಲ್ಪಟ್ಟಿದೆ, ಆದ್ದರಿಂದ ಈ ಕಾರ್ಯವು ಎರಡರ ನಡುವೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.ಎಲ್ಲಾ ಬೈಟ್ ಚೂರುಗಳು ಮಾನ್ಯ ತಂತಿಗಳಲ್ಲ, ಆದಾಗ್ಯೂ: ತಂತಿಗಳು ಮಾನ್ಯ UTF-8 ಆಗಿರಬೇಕು.
    /// ಈ ಪರಿವರ್ತನೆಯ ಸಮಯದಲ್ಲಿ, `from_utf8_lossy()` ಯಾವುದೇ ಅಮಾನ್ಯ UTF-8 ಅನುಕ್ರಮಗಳನ್ನು [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] ನೊಂದಿಗೆ ಬದಲಾಯಿಸುತ್ತದೆ, ಅದು ಈ ರೀತಿ ಕಾಣುತ್ತದೆ:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// ಬೈಟ್ ಸ್ಲೈಸ್ ಮಾನ್ಯ UTF-8 ಎಂದು ನಿಮಗೆ ಖಚಿತವಾಗಿದ್ದರೆ, ಮತ್ತು ಪರಿವರ್ತನೆಯ ಓವರ್ಹೆಡ್ ಅನ್ನು ನೀವು ಅನುಭವಿಸಲು ಬಯಸುವುದಿಲ್ಲವಾದರೆ, ಈ ಕಾರ್ಯದ ಅಸುರಕ್ಷಿತ ಆವೃತ್ತಿಯಿದೆ, [`from_utf8_unchecked`], ಅದೇ ನಡವಳಿಕೆಯನ್ನು ಹೊಂದಿದೆ ಆದರೆ ಚೆಕ್ ಗಳನ್ನು ಬಿಟ್ಟುಬಿಡುತ್ತದೆ.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// ಈ ಕಾರ್ಯವು [`Cow<'a, str>`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.ನಮ್ಮ ಬೈಟ್ ಸ್ಲೈಸ್ ಅಮಾನ್ಯ UTF-8 ಆಗಿದ್ದರೆ, ನಾವು ಬದಲಿ ಅಕ್ಷರಗಳನ್ನು ಸೇರಿಸುವ ಅಗತ್ಯವಿದೆ, ಅದು ಸ್ಟ್ರಿಂಗ್‌ನ ಗಾತ್ರವನ್ನು ಬದಲಾಯಿಸುತ್ತದೆ ಮತ್ತು ಆದ್ದರಿಂದ, `String` ಅಗತ್ಯವಿದೆ.
    /// ಆದರೆ ಇದು ಈಗಾಗಲೇ ಮಾನ್ಯ UTF-8 ಆಗಿದ್ದರೆ, ನಮಗೆ ಹೊಸ ಹಂಚಿಕೆ ಅಗತ್ಯವಿಲ್ಲ.
    /// ಈ ರಿಟರ್ನ್ ಪ್ರಕಾರವು ಎರಡೂ ಪ್ರಕರಣಗಳನ್ನು ನಿರ್ವಹಿಸಲು ನಮಗೆ ಅನುಮತಿಸುತ್ತದೆ.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// // ಕೆಲವು ಬೈಟ್‌ಗಳು, vector ನಲ್ಲಿ
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// ತಪ್ಪಾದ ಬೈಟ್‌ಗಳು:
    ///
    /// ```
    /// // ಕೆಲವು ಅಮಾನ್ಯ ಬೈಟ್‌ಗಳು
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// ಯುಟಿಎಫ್-16-ಎನ್ಕೋಡ್ ಮಾಡಲಾದ vector `v` ಅನ್ನು `String` ಗೆ ಡಿಕೋಡ್ ಮಾಡಿ, `v` ಯಾವುದೇ ಅಮಾನ್ಯ ಡೇಟಾವನ್ನು ಹೊಂದಿದ್ದರೆ [`Err`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // ಸಂಗ್ರಹಣೆ ಮೂಲಕ ಇದನ್ನು ಮಾಡಲಾಗುವುದಿಲ್ಲ: : <Result<_, _>> () ಕಾರ್ಯಕ್ಷಮತೆ ಕಾರಣಗಳಿಗಾಗಿ.
        // FIXME: #48994 ಮುಚ್ಚಿದಾಗ ಕಾರ್ಯವನ್ನು ಮತ್ತೆ ಸರಳಗೊಳಿಸಬಹುದು.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// ಯುಟಿಎಫ್-16-ಎನ್ಕೋಡ್ ಮಾಡಿದ ಸ್ಲೈಸ್ ಎಕ್ಸ್ 02 ಎಕ್ಸ್ ಅನ್ನು ಎಕ್ಸ್ 01 ಎಕ್ಸ್ ಆಗಿ ಡಿಕೋಡ್ ಮಾಡಿ, ಅಮಾನ್ಯ ಡೇಟಾವನ್ನು ಎಕ್ಸ್ 00 ಎಕ್ಸ್ ನೊಂದಿಗೆ ಬದಲಾಯಿಸುತ್ತದೆ.
    ///
    /// [`Cow<'a, str>`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುವ [`from_utf8_lossy`] ಗಿಂತ ಭಿನ್ನವಾಗಿ, `from_utf16_lossy` `String` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ ಏಕೆಂದರೆ UTF-16 ನಿಂದ UTF-8 ಪರಿವರ್ತನೆಗೆ ಮೆಮೊರಿ ಹಂಚಿಕೆ ಅಗತ್ಯವಿರುತ್ತದೆ.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// `String` ಅನ್ನು ಅದರ ಕಚ್ಚಾ ಘಟಕಗಳಾಗಿ ವಿಭಜಿಸುತ್ತದೆ.
    ///
    /// ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಅನ್ನು ಆಧಾರವಾಗಿರುವ ಡೇಟಾ, ಸ್ಟ್ರಿಂಗ್‌ನ ಉದ್ದ (ಬೈಟ್‌ಗಳಲ್ಲಿ) ಮತ್ತು ಡೇಟಾದ ನಿಯೋಜಿತ ಸಾಮರ್ಥ್ಯಕ್ಕೆ (ಬೈಟ್‌ಗಳಲ್ಲಿ) ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// [`from_raw_parts`] ಗೆ ವಾದಗಳಂತೆಯೇ ಅದೇ ಕ್ರಮದಲ್ಲಿ ಇವು ಒಂದೇ ವಾದಗಳಾಗಿವೆ.
    ///
    /// ಈ ಕಾರ್ಯವನ್ನು ಕರೆದ ನಂತರ, ಈ ಹಿಂದೆ `String` ನಿರ್ವಹಿಸುತ್ತಿದ್ದ ಮೆಮೊರಿಗೆ ಕರೆ ಮಾಡುವವರು ಜವಾಬ್ದಾರರಾಗಿರುತ್ತಾರೆ.
    /// ಕಚ್ಚಾ ಪಾಯಿಂಟರ್, ಉದ್ದ ಮತ್ತು ಸಾಮರ್ಥ್ಯವನ್ನು [`from_raw_parts`] ಕಾರ್ಯದೊಂದಿಗೆ `String` ಗೆ ಪರಿವರ್ತಿಸುವುದು ಇದಕ್ಕೆ ಏಕೈಕ ಮಾರ್ಗವಾಗಿದೆ, ಇದರಿಂದಾಗಿ ಡಿಸ್ಟ್ರಕ್ಟರ್ ಸ್ವಚ್ clean ಗೊಳಿಸುವಿಕೆಯನ್ನು ಮಾಡಲು ಅನುವು ಮಾಡಿಕೊಡುತ್ತದೆ.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// ಉದ್ದ, ಸಾಮರ್ಥ್ಯ ಮತ್ತು ಪಾಯಿಂಟರ್‌ನಿಂದ ಹೊಸ `String` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// ಪರಿಶೀಲಿಸದ ಅಸ್ಥಿರತೆಗಳ ಸಂಖ್ಯೆಯಿಂದಾಗಿ ಇದು ಹೆಚ್ಚು ಅಸುರಕ್ಷಿತವಾಗಿದೆ:
    ///
    /// * `buf` ನಲ್ಲಿನ ಮೆಮೊರಿಯನ್ನು ಈ ಹಿಂದೆ ಸ್ಟ್ಯಾಂಡರ್ಡ್ ಲೈಬ್ರರಿ ಬಳಸುವ ಅದೇ ಹಂಚಿಕೆಯಿಂದ ಹಂಚಿಕೆ ಮಾಡಬೇಕಾಗಿತ್ತು, ಅಗತ್ಯವಿರುವ ಜೋಡಣೆಯನ್ನು ನಿಖರವಾಗಿ 1.
    /// * `length` `capacity` ಗಿಂತ ಕಡಿಮೆ ಅಥವಾ ಸಮನಾಗಿರಬೇಕು.
    /// * `capacity` ಸರಿಯಾದ ಮೌಲ್ಯವಾಗಿರಬೇಕು.
    /// * `buf` ನಲ್ಲಿನ ಮೊದಲ `length` ಬೈಟ್‌ಗಳು ಮಾನ್ಯ UTF-8 ಆಗಿರಬೇಕು.
    ///
    /// ಇವುಗಳನ್ನು ಉಲ್ಲಂಘಿಸುವುದರಿಂದ ಹಂಚಿಕೆಯ ಆಂತರಿಕ ದತ್ತಾಂಶ ರಚನೆಗಳನ್ನು ಭ್ರಷ್ಟಗೊಳಿಸುವಂತಹ ಸಮಸ್ಯೆಗಳು ಉಂಟಾಗಬಹುದು.
    ///
    /// `buf` ನ ಮಾಲೀಕತ್ವವನ್ನು `String` ಗೆ ಪರಿಣಾಮಕಾರಿಯಾಗಿ ವರ್ಗಾಯಿಸಲಾಗುತ್ತದೆ, ನಂತರ ಅದನ್ನು ಇಚ್ .ೆಯಂತೆ ಪಾಯಿಂಟರ್ ಸೂಚಿಸಿದ ಮೆಮೊರಿಯ ವಿಷಯಗಳನ್ನು ಸ್ಥಳಾಂತರಿಸಬಹುದು, ಮರುಹಂಚಿಕೆ ಮಾಡಬಹುದು ಅಥವಾ ಬದಲಾಯಿಸಬಹುದು.
    /// ಈ ಕಾರ್ಯವನ್ನು ಕರೆದ ನಂತರ ಬೇರೆ ಯಾವುದೂ ಪಾಯಿಂಟರ್ ಅನ್ನು ಬಳಸುವುದಿಲ್ಲ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME vec_into_raw_parts ಅನ್ನು ಸ್ಥಿರಗೊಳಿಸಿದಾಗ ಇದನ್ನು ನವೀಕರಿಸಿ.
    ///     // ಸ್ಟ್ರಿಂಗ್‌ನ ಡೇಟಾವನ್ನು ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಬಿಡುವುದನ್ನು ತಡೆಯಿರಿ
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// ಸ್ಟ್ರಿಂಗ್ ಮಾನ್ಯ UTF-8 ಅನ್ನು ಹೊಂದಿದೆಯೆ ಎಂದು ಪರಿಶೀಲಿಸದೆ vector ಬೈಟ್‌ಗಳನ್ನು `String` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ ಸುರಕ್ಷಿತ ಆವೃತ್ತಿ, [`from_utf8`] ನೋಡಿ.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// ಈ ಕಾರ್ಯವು ಅಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ಅದು ರವಾನಿಸಿದ ಬೈಟ್‌ಗಳು ಮಾನ್ಯ UTF-8 ಎಂದು ಪರಿಶೀಲಿಸುವುದಿಲ್ಲ.
    /// ಈ ನಿರ್ಬಂಧವನ್ನು ಉಲ್ಲಂಘಿಸಿದರೆ, ಇದು `String` ನ future ಬಳಕೆದಾರರೊಂದಿಗೆ ಮೆಮೊರಿ ಅಸುರಕ್ಷಿತ ಸಮಸ್ಯೆಗಳನ್ನು ಉಂಟುಮಾಡಬಹುದು, ಏಕೆಂದರೆ ಉಳಿದ ಪ್ರಮಾಣಿತ ಗ್ರಂಥಾಲಯವು `ಸ್ಟ್ರಿಂಗ್`ಗಳು ಮಾನ್ಯ UTF-8 ಎಂದು umes ಹಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// // ಕೆಲವು ಬೈಟ್‌ಗಳು, vector ನಲ್ಲಿ
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// `String` ಅನ್ನು ಬೈಟ್ vector ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ಇದು `String` ಅನ್ನು ಬಳಸುತ್ತದೆ, ಆದ್ದರಿಂದ ನಾವು ಅದರ ವಿಷಯಗಳನ್ನು ನಕಲಿಸುವ ಅಗತ್ಯವಿಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// ಸಂಪೂರ್ಣ `String` ಹೊಂದಿರುವ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಹೊರತೆಗೆಯುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// `String` ಅನ್ನು ರೂಪಾಂತರಿತ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// ಈ `String` ನ ಕೊನೆಯಲ್ಲಿ ನಿರ್ದಿಷ್ಟ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// ಈ `ಸ್ಟ್ರಿಂಗ್` ಸಾಮರ್ಥ್ಯವನ್ನು ಬೈಟ್‌ಗಳಲ್ಲಿ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// ಈ `ಸ್ಟ್ರಿಂಗ್` ಸಾಮರ್ಥ್ಯವು ಅದರ ಉದ್ದಕ್ಕಿಂತ ಕನಿಷ್ಠ `additional` ಬೈಟ್‌ಗಳಷ್ಟು ದೊಡ್ಡದಾಗಿದೆ ಎಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ.
    ///
    /// ಪದೇ ಪದೇ ಮರುಹಂಚಿಕೆಗಳನ್ನು ತಡೆಯಲು ಸಾಮರ್ಥ್ಯವನ್ನು ಆರಿಸಿದರೆ `additional` ಬೈಟ್‌ಗಳಿಗಿಂತ ಹೆಚ್ಚಿನದನ್ನು ಹೆಚ್ಚಿಸಬಹುದು.
    ///
    ///
    /// ಈ "at least" ನಡವಳಿಕೆಯನ್ನು ನೀವು ಬಯಸದಿದ್ದರೆ, [`reserve_exact`] ವಿಧಾನವನ್ನು ನೋಡಿ.
    ///
    /// # Panics
    ///
    /// ಹೊಸ ಸಾಮರ್ಥ್ಯವು [`usize`] ಅನ್ನು ಉಕ್ಕಿ ಹರಿಸಿದರೆ Panics.
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// ಇದು ವಾಸ್ತವವಾಗಿ ಸಾಮರ್ಥ್ಯವನ್ನು ಹೆಚ್ಚಿಸದಿರಬಹುದು:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ಈಗ 2 ಉದ್ದ ಮತ್ತು 10 ಸಾಮರ್ಥ್ಯವನ್ನು ಹೊಂದಿದೆ
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // ನಾವು ಈಗಾಗಲೇ ಹೆಚ್ಚುವರಿ 8 ಸಾಮರ್ಥ್ಯವನ್ನು ಹೊಂದಿರುವುದರಿಂದ, ಇದನ್ನು ಕರೆಯುತ್ತೇವೆ ...
    /// s.reserve(8);
    ///
    /// // ... ವಾಸ್ತವವಾಗಿ ಹೆಚ್ಚಾಗುವುದಿಲ್ಲ.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// ಈ `ಸ್ಟ್ರಿಂಗ್` ಸಾಮರ್ಥ್ಯವು `additional` ಬೈಟ್‌ಗಳು ಅದರ ಉದ್ದಕ್ಕಿಂತ ದೊಡ್ಡದಾಗಿದೆ ಎಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ.
    ///
    /// ಹಂಚಿಕೆದಾರರಿಗಿಂತ ಉತ್ತಮವಾಗಿ ನಿಮಗೆ ತಿಳಿದಿಲ್ಲದಿದ್ದರೆ [`reserve`] ವಿಧಾನವನ್ನು ಬಳಸುವುದನ್ನು ಪರಿಗಣಿಸಿ.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// ಹೊಸ ಸಾಮರ್ಥ್ಯವು `usize` ಅನ್ನು ಉಕ್ಕಿ ಹರಿಸಿದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// ಇದು ವಾಸ್ತವವಾಗಿ ಸಾಮರ್ಥ್ಯವನ್ನು ಹೆಚ್ಚಿಸದಿರಬಹುದು:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ಈಗ 2 ಉದ್ದ ಮತ್ತು 10 ಸಾಮರ್ಥ್ಯವನ್ನು ಹೊಂದಿದೆ
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // ನಾವು ಈಗಾಗಲೇ ಹೆಚ್ಚುವರಿ 8 ಸಾಮರ್ಥ್ಯವನ್ನು ಹೊಂದಿರುವುದರಿಂದ, ಇದನ್ನು ಕರೆಯುತ್ತೇವೆ ...
    /// s.reserve_exact(8);
    ///
    /// // ... ವಾಸ್ತವವಾಗಿ ಹೆಚ್ಚಾಗುವುದಿಲ್ಲ.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// ಕೊಟ್ಟಿರುವ `String` ನಲ್ಲಿ ಕನಿಷ್ಠ `additional` ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ಸೇರಿಸಲು ಸಾಮರ್ಥ್ಯವನ್ನು ಕಾಯ್ದಿರಿಸಲು ಪ್ರಯತ್ನಿಸುತ್ತದೆ.
    /// ಆಗಾಗ್ಗೆ ಮರುಹಂಚಿಕೆಗಳನ್ನು ತಪ್ಪಿಸಲು ಸಂಗ್ರಹವು ಹೆಚ್ಚಿನ ಸ್ಥಳವನ್ನು ಕಾಯ್ದಿರಿಸಬಹುದು.
    /// `reserve` ಗೆ ಕರೆ ಮಾಡಿದ ನಂತರ, ಸಾಮರ್ಥ್ಯವು `self.len() + additional` ಗಿಂತ ಹೆಚ್ಚಿರುತ್ತದೆ ಅಥವಾ ಸಮಾನವಾಗಿರುತ್ತದೆ.
    /// ಸಾಮರ್ಥ್ಯವು ಈಗಾಗಲೇ ಸಾಕಷ್ಟು ಇದ್ದರೆ ಏನನ್ನೂ ಮಾಡುವುದಿಲ್ಲ.
    ///
    /// # Errors
    ///
    /// ಸಾಮರ್ಥ್ಯವು ಉಕ್ಕಿ ಹರಿಯುತ್ತಿದ್ದರೆ, ಅಥವಾ ಹಂಚಿಕೆದಾರರು ವೈಫಲ್ಯವನ್ನು ವರದಿ ಮಾಡಿದರೆ, ದೋಷವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // ಮೆಮೊರಿಯನ್ನು ಮೊದಲೇ ಕಾಯ್ದಿರಿಸಿ, ನಮಗೆ ಸಾಧ್ಯವಾಗದಿದ್ದರೆ ನಿರ್ಗಮಿಸುತ್ತದೆ
    ///     output.try_reserve(data.len())?;
    ///
    ///     // ನಮ್ಮ ಸಂಕೀರ್ಣ ಕೆಲಸದ ಮಧ್ಯದಲ್ಲಿ ಇದು OOM ಆಗುವುದಿಲ್ಲ ಎಂದು ಈಗ ನಮಗೆ ತಿಳಿದಿದೆ
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// ಕೊಟ್ಟಿರುವ `String` ನಲ್ಲಿ ನಿಖರವಾಗಿ `additional` ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ಸೇರಿಸಲು ಕನಿಷ್ಠ ಸಾಮರ್ಥ್ಯವನ್ನು ಕಾಯ್ದಿರಿಸಲು ಪ್ರಯತ್ನಿಸುತ್ತದೆ.
    ///
    /// `reserve_exact` ಗೆ ಕರೆ ಮಾಡಿದ ನಂತರ, ಸಾಮರ್ಥ್ಯವು `self.len() + additional` ಗಿಂತ ಹೆಚ್ಚಿರುತ್ತದೆ ಅಥವಾ ಸಮಾನವಾಗಿರುತ್ತದೆ.
    /// ಸಾಮರ್ಥ್ಯವು ಈಗಾಗಲೇ ಸಾಕಷ್ಟು ಇದ್ದರೆ ಏನನ್ನೂ ಮಾಡುವುದಿಲ್ಲ.
    ///
    /// ಹಂಚಿಕೆದಾರನು ಸಂಗ್ರಹಣೆಗೆ ವಿನಂತಿಸುವುದಕ್ಕಿಂತ ಹೆಚ್ಚಿನ ಸ್ಥಳವನ್ನು ನೀಡಬಹುದು ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    /// ಆದ್ದರಿಂದ, ಸಾಮರ್ಥ್ಯವನ್ನು ನಿಖರವಾಗಿ ಕಡಿಮೆ ಎಂದು ಅವಲಂಬಿಸಲಾಗುವುದಿಲ್ಲ.
    /// future ಒಳಸೇರಿಸುವಿಕೆಯನ್ನು ನಿರೀಕ್ಷಿಸಿದ್ದರೆ `reserve` ಗೆ ಆದ್ಯತೆ ನೀಡಿ.
    ///
    /// # Errors
    ///
    /// ಸಾಮರ್ಥ್ಯವು ಉಕ್ಕಿ ಹರಿಯುತ್ತಿದ್ದರೆ, ಅಥವಾ ಹಂಚಿಕೆದಾರರು ವೈಫಲ್ಯವನ್ನು ವರದಿ ಮಾಡಿದರೆ, ದೋಷವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // ಮೆಮೊರಿಯನ್ನು ಮೊದಲೇ ಕಾಯ್ದಿರಿಸಿ, ನಮಗೆ ಸಾಧ್ಯವಾಗದಿದ್ದರೆ ನಿರ್ಗಮಿಸುತ್ತದೆ
    ///     output.try_reserve(data.len())?;
    ///
    ///     // ನಮ್ಮ ಸಂಕೀರ್ಣ ಕೆಲಸದ ಮಧ್ಯದಲ್ಲಿ ಇದು OOM ಆಗುವುದಿಲ್ಲ ಎಂದು ಈಗ ನಮಗೆ ತಿಳಿದಿದೆ
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// ಈ `String` ನ ಉದ್ದವನ್ನು ಹೊಂದಿಸಲು ಅದರ ಸಾಮರ್ಥ್ಯವನ್ನು ಕುಗ್ಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// ಈ `String` ನ ಸಾಮರ್ಥ್ಯವನ್ನು ಕಡಿಮೆ ಬೌಂಡ್‌ನೊಂದಿಗೆ ಕುಗ್ಗಿಸುತ್ತದೆ.
    ///
    /// ಸಾಮರ್ಥ್ಯವು ಉದ್ದ ಮತ್ತು ಸರಬರಾಜು ಮೌಲ್ಯ ಎರಡರಷ್ಟು ದೊಡ್ಡದಾಗಿರುತ್ತದೆ.
    ///
    ///
    /// ಪ್ರಸ್ತುತ ಸಾಮರ್ಥ್ಯವು ಕಡಿಮೆ ಮಿತಿಗಿಂತ ಕಡಿಮೆಯಿದ್ದರೆ, ಇದು ಯಾವುದೇ ಆಪ್ ಅಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// ಕೊಟ್ಟಿರುವ [`char`] ಅನ್ನು ಈ `String` ನ ಕೊನೆಯಲ್ಲಿ ಸೇರಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// ಈ `ಸ್ಟ್ರಿಂಗ್` ವಿಷಯಗಳ ಬೈಟ್ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ವಿಧಾನದ ವಿಲೋಮವು [`from_utf8`] ಆಗಿದೆ.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// ಈ `String` ಅನ್ನು ನಿಗದಿತ ಉದ್ದಕ್ಕೆ ಕಡಿಮೆ ಮಾಡುತ್ತದೆ.
    ///
    /// `new_len` ಸ್ಟ್ರಿಂಗ್‌ನ ಪ್ರಸ್ತುತ ಉದ್ದಕ್ಕಿಂತ ಹೆಚ್ಚಿದ್ದರೆ, ಇದು ಯಾವುದೇ ಪರಿಣಾಮ ಬೀರುವುದಿಲ್ಲ.
    ///
    ///
    /// ಈ ವಿಧಾನವು ಸ್ಟ್ರಿಂಗ್‌ನ ನಿಯೋಜಿತ ಸಾಮರ್ಥ್ಯದ ಮೇಲೆ ಯಾವುದೇ ಪರಿಣಾಮ ಬೀರುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ
    ///
    /// # Panics
    ///
    /// `new_len` [`char`] ಗಡಿಯಲ್ಲಿ ಮಲಗದಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// ಸ್ಟ್ರಿಂಗ್ ಬಫರ್‌ನಿಂದ ಕೊನೆಯ ಅಕ್ಷರವನ್ನು ತೆಗೆದುಹಾಕಿ ಮತ್ತು ಅದನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ `String` ಖಾಲಿಯಾಗಿದ್ದರೆ [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// ಈ `String` ನಿಂದ [`char`] ಅನ್ನು ಬೈಟ್ ಸ್ಥಾನದಲ್ಲಿ ತೆಗೆದುಹಾಕಿ ಅದನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಇದು *O*(*n*) ಕಾರ್ಯಾಚರಣೆಯಾಗಿದೆ, ಏಕೆಂದರೆ ಇದಕ್ಕೆ ಬಫರ್‌ನಲ್ಲಿರುವ ಪ್ರತಿಯೊಂದು ಅಂಶವನ್ನು ನಕಲಿಸುವ ಅಗತ್ಯವಿದೆ.
    ///
    /// # Panics
    ///
    /// `idx` `ಸ್ಟ್ರಿಂಗ್` ಉದ್ದಕ್ಕಿಂತ ದೊಡ್ಡದಾಗಿದ್ದರೆ ಅಥವಾ ಸಮನಾಗಿದ್ದರೆ ಅಥವಾ ಅದು [`char`] ಗಡಿಯಲ್ಲಿ ಮಲಗದಿದ್ದರೆ Panics.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// `String` ನಲ್ಲಿ `pat` ಮಾದರಿಯ ಎಲ್ಲಾ ಹೊಂದಾಣಿಕೆಗಳನ್ನು ತೆಗೆದುಹಾಕಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// ಹೊಂದಾಣಿಕೆಗಳನ್ನು ಪತ್ತೆಹಚ್ಚಲಾಗುತ್ತದೆ ಮತ್ತು ಪುನರಾವರ್ತಿತವಾಗಿ ತೆಗೆದುಹಾಕಲಾಗುತ್ತದೆ, ಆದ್ದರಿಂದ ಮಾದರಿಗಳು ಅತಿಕ್ರಮಿಸುವ ಸಂದರ್ಭಗಳಲ್ಲಿ, ಮೊದಲ ಮಾದರಿಯನ್ನು ಮಾತ್ರ ತೆಗೆದುಹಾಕಲಾಗುತ್ತದೆ:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // ಸುರಕ್ಷತೆ: ಪ್ರಾರಂಭ ಮತ್ತು ಅಂತ್ಯವು ಪ್ರತಿ utf8 ಬೈಟ್ ಗಡಿಗಳಲ್ಲಿರುತ್ತದೆ
        // ಶೋಧಕ ಡಾಕ್ಸ್
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// ಮುನ್ಸೂಚನೆಯಿಂದ ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಅಕ್ಷರಗಳನ್ನು ಮಾತ್ರ ಉಳಿಸಿಕೊಳ್ಳುತ್ತದೆ.
    ///
    /// ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, `f(c)` ಎಲ್ಲಾ ಅಕ್ಷರಗಳನ್ನು ತೆಗೆದುಹಾಕಿ, ಅಂದರೆ `f(c)` `false` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    /// ಈ ವಿಧಾನವು ಸ್ಥಳದಲ್ಲಿ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ, ಪ್ರತಿಯೊಂದು ಅಕ್ಷರವನ್ನು ಮೂಲ ಕ್ರಮದಲ್ಲಿ ನಿಖರವಾಗಿ ಒಮ್ಮೆ ಭೇಟಿ ಮಾಡುತ್ತದೆ ಮತ್ತು ಉಳಿಸಿಕೊಂಡಿರುವ ಅಕ್ಷರಗಳ ಕ್ರಮವನ್ನು ಕಾಪಾಡುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// ಸೂಚ್ಯಂಕದಂತೆ ಬಾಹ್ಯ ಸ್ಥಿತಿಯನ್ನು ಪತ್ತೆಹಚ್ಚಲು ನಿಖರವಾದ ಕ್ರಮವು ಉಪಯುಕ್ತವಾಗಬಹುದು.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // ಮುಂದಿನ ಚಾರ್‌ಗೆ ಐಡಿಕ್ಸ್ ಅನ್ನು ಸೂಚಿಸಿ
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// ಬೈಟ್ ಸ್ಥಾನದಲ್ಲಿ ಈ `String` ಗೆ ಅಕ್ಷರವನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///
    /// ಇದು ಬಫರ್‌ನಲ್ಲಿರುವ ಪ್ರತಿಯೊಂದು ಅಂಶವನ್ನು ನಕಲಿಸುವ ಅಗತ್ಯವಿರುವುದರಿಂದ ಇದು *O*(*n*) ಕಾರ್ಯಾಚರಣೆಯಾಗಿದೆ.
    ///
    /// # Panics
    ///
    /// `idx` `ಸ್ಟ್ರಿಂಗ್` ಉದ್ದಕ್ಕಿಂತ ದೊಡ್ಡದಾಗಿದ್ದರೆ ಅಥವಾ ಅದು [`char`] ಗಡಿಯಲ್ಲಿ ಮಲಗದಿದ್ದರೆ Panics.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// ಈ `String` ಗೆ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಬೈಟ್ ಸ್ಥಾನದಲ್ಲಿ ಸೇರಿಸುತ್ತದೆ.
    ///
    /// ಇದು ಬಫರ್‌ನಲ್ಲಿರುವ ಪ್ರತಿಯೊಂದು ಅಂಶವನ್ನು ನಕಲಿಸುವ ಅಗತ್ಯವಿರುವುದರಿಂದ ಇದು *O*(*n*) ಕಾರ್ಯಾಚರಣೆಯಾಗಿದೆ.
    ///
    /// # Panics
    ///
    /// `idx` `ಸ್ಟ್ರಿಂಗ್` ಉದ್ದಕ್ಕಿಂತ ದೊಡ್ಡದಾಗಿದ್ದರೆ ಅಥವಾ ಅದು [`char`] ಗಡಿಯಲ್ಲಿ ಮಲಗದಿದ್ದರೆ Panics.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// ಈ `String` ನ ವಿಷಯಗಳಿಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// ಈ ಕಾರ್ಯವು ಅಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ಅದು ರವಾನಿಸಿದ ಬೈಟ್‌ಗಳು ಮಾನ್ಯ UTF-8 ಎಂದು ಪರಿಶೀಲಿಸುವುದಿಲ್ಲ.
    /// ಈ ನಿರ್ಬಂಧವನ್ನು ಉಲ್ಲಂಘಿಸಿದರೆ, ಇದು `String` ನ future ಬಳಕೆದಾರರೊಂದಿಗೆ ಮೆಮೊರಿ ಅಸುರಕ್ಷಿತ ಸಮಸ್ಯೆಗಳನ್ನು ಉಂಟುಮಾಡಬಹುದು, ಏಕೆಂದರೆ ಉಳಿದ ಪ್ರಮಾಣಿತ ಗ್ರಂಥಾಲಯವು `ಸ್ಟ್ರಿಂಗ್`ಗಳು ಮಾನ್ಯ UTF-8 ಎಂದು umes ಹಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// ಈ `String` ನ ಉದ್ದವನ್ನು ಬೈಟ್‌ಗಳಲ್ಲಿ, [`ಚಾರ್`] ಅಥವಾ ಗ್ರ್ಯಾಫೀಮ್‌ಗಳಲ್ಲ.
    /// ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, ದಾರದ ಉದ್ದವನ್ನು ಮನುಷ್ಯ ಪರಿಗಣಿಸುವಂತಿಲ್ಲ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// ಈ `String` ಶೂನ್ಯದ ಉದ್ದವನ್ನು ಹೊಂದಿದ್ದರೆ ಮತ್ತು `false` ಇಲ್ಲದಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ಕೊಟ್ಟಿರುವ ಬೈಟ್ ಸೂಚ್ಯಂಕದಲ್ಲಿ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಎರಡು ಭಾಗಗಳಾಗಿ ವಿಭಜಿಸುತ್ತದೆ.
    ///
    /// ಹೊಸದಾಗಿ ನಿಯೋಜಿಸಲಾದ `String` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// `self` `[0, at)` ಬೈಟ್‌ಗಳನ್ನು ಒಳಗೊಂಡಿದೆ, ಮತ್ತು ಹಿಂತಿರುಗಿದ `String` ಬೈಟ್‌ಗಳು `[at, len)` ಅನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    /// `at` UTF-8 ಕೋಡ್ ಪಾಯಿಂಟ್‌ನ ಗಡಿಯಲ್ಲಿರಬೇಕು.
    ///
    /// `self` ಸಾಮರ್ಥ್ಯವು ಬದಲಾಗುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    /// # Panics
    ///
    /// `at` `UTF-8` ಕೋಡ್ ಪಾಯಿಂಟ್ ಗಡಿಯಲ್ಲಿಲ್ಲದಿದ್ದರೆ ಅಥವಾ ಅದು ಸ್ಟ್ರಿಂಗ್‌ನ ಕೊನೆಯ ಕೋಡ್ ಪಾಯಿಂಟ್ ಅನ್ನು ಮೀರಿದ್ದರೆ Panics.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// ಈ `String` ಅನ್ನು ಮೊಟಕುಗೊಳಿಸುತ್ತದೆ, ಎಲ್ಲಾ ವಿಷಯಗಳನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ.
    ///
    /// ಇದರರ್ಥ `String` ಶೂನ್ಯದ ಉದ್ದವನ್ನು ಹೊಂದಿರುತ್ತದೆ, ಅದು ಅದರ ಸಾಮರ್ಥ್ಯವನ್ನು ಮುಟ್ಟುವುದಿಲ್ಲ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// `String` ನಲ್ಲಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಶ್ರೇಣಿಯನ್ನು ತೆಗೆದುಹಾಕುವ ಮತ್ತು ತೆಗೆದುಹಾಕಲಾದ `chars` ಅನ್ನು ನೀಡುವ ಬರಿದಾಗುವ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    ///
    /// Note: ಪುನರಾವರ್ತಕವನ್ನು ಕೊನೆಯವರೆಗೂ ಸೇವಿಸದಿದ್ದರೂ ಸಹ ಅಂಶ ಶ್ರೇಣಿಯನ್ನು ತೆಗೆದುಹಾಕಲಾಗುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// ಪ್ರಾರಂಭದ ಹಂತ ಅಥವಾ ಅಂತಿಮ ಬಿಂದುವು [`char`] ಗಡಿಯಲ್ಲಿ ಮಲಗದಿದ್ದರೆ ಅಥವಾ ಅವು ಮಿತಿ ಮೀರದಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // ಸ್ಟ್ರಿಂಗ್‌ನಿಂದ β ರವರೆಗೆ ಶ್ರೇಣಿಯನ್ನು ತೆಗೆದುಹಾಕಿ
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // ಪೂರ್ಣ ಶ್ರೇಣಿಯು ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ತೆರವುಗೊಳಿಸುತ್ತದೆ
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // ಮೆಮೊರಿ ಸುರಕ್ಷತೆ
        //
        // Drain ನ ಸ್ಟ್ರಿಂಗ್ ಆವೃತ್ತಿಯು vector ಆವೃತ್ತಿಯ ಮೆಮೊರಿ ಸುರಕ್ಷತಾ ಸಮಸ್ಯೆಗಳನ್ನು ಹೊಂದಿಲ್ಲ.
        // ಡೇಟಾ ಕೇವಲ ಸರಳ ಬೈಟ್‌ಗಳು.
        // ಡ್ರಾಪ್‌ನಲ್ಲಿ ಶ್ರೇಣಿ ತೆಗೆಯುವಿಕೆ ಸಂಭವಿಸುವ ಕಾರಣ, Drain ಇಟರೇಟರ್ ಸೋರಿಕೆಯಾಗಿದ್ದರೆ, ತೆಗೆಯುವಿಕೆ ಸಂಭವಿಸುವುದಿಲ್ಲ.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // ಏಕಕಾಲದಲ್ಲಿ ಎರಡು ಸಾಲಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳಿ.
        // ಡ್ರಾಪ್‌ನಲ್ಲಿ, ಪುನರಾವರ್ತನೆ ಮುಗಿಯುವವರೆಗೆ &mut ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಪ್ರವೇಶಿಸಲಾಗುವುದಿಲ್ಲ.
        let self_ptr = self as *mut _;
        // ಸುರಕ್ಷತೆ: `slice::range` ಮತ್ತು `is_char_boundary` ಸೂಕ್ತವಾದ ಗಡಿ ಪರಿಶೀಲನೆಗಳನ್ನು ಮಾಡುತ್ತವೆ.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// ಸ್ಟ್ರಿಂಗ್‌ನಲ್ಲಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಶ್ರೇಣಿಯನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ ಮತ್ತು ಅದನ್ನು ನಿರ್ದಿಷ್ಟ ಸ್ಟ್ರಿಂಗ್‌ನೊಂದಿಗೆ ಬದಲಾಯಿಸುತ್ತದೆ.
    /// ಕೊಟ್ಟಿರುವ ಸ್ಟ್ರಿಂಗ್ ಶ್ರೇಣಿಯ ಉದ್ದವಾಗಿರಬೇಕಾಗಿಲ್ಲ.
    ///
    /// # Panics
    ///
    /// ಪ್ರಾರಂಭದ ಹಂತ ಅಥವಾ ಅಂತಿಮ ಬಿಂದುವು [`char`] ಗಡಿಯಲ್ಲಿ ಮಲಗದಿದ್ದರೆ ಅಥವಾ ಅವು ಮಿತಿ ಮೀರದಿದ್ದರೆ Panics.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // ಸ್ಟ್ರಿಂಗ್‌ನಿಂದ β ರವರೆಗೆ ಶ್ರೇಣಿಯನ್ನು ಬದಲಾಯಿಸಿ
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // ಮೆಮೊರಿ ಸುರಕ್ಷತೆ
        //
        // ರಿಪ್ಲೇಸ್_ರೇಂಜ್ vector ಸ್ಪ್ಲೈಸ್‌ನ ಮೆಮೊರಿ ಸುರಕ್ಷತಾ ಸಮಸ್ಯೆಗಳನ್ನು ಹೊಂದಿಲ್ಲ.
        // vector ಆವೃತ್ತಿಯ.ಡೇಟಾ ಕೇವಲ ಸರಳ ಬೈಟ್‌ಗಳು.

        // ಎಚ್ಚರಿಕೆ: ಈ ವೇರಿಯೇಬಲ್ ಅನ್ನು ಇನ್‌ಲೈನ್ ಮಾಡುವುದು ಅಸಮರ್ಪಕ (#81138) ಆಗಿರುತ್ತದೆ
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // ಎಚ್ಚರಿಕೆ: ಈ ವೇರಿಯೇಬಲ್ ಅನ್ನು ಇನ್‌ಲೈನ್ ಮಾಡುವುದು ಅಸಮರ್ಪಕ (#81138) ಆಗಿರುತ್ತದೆ
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // `range` ಅನ್ನು ಮತ್ತೆ ಬಳಸುವುದು (#81138) ಅನ್ನು ತಪ್ಪಿಸುತ್ತದೆ `range` ವರದಿ ಮಾಡಿದ ಗಡಿಗಳು ಒಂದೇ ಆಗಿರುತ್ತವೆ ಎಂದು ನಾವು ಭಾವಿಸುತ್ತೇವೆ, ಆದರೆ ಕರೆಗಳ ನಡುವೆ ವಿರೋಧಿ ಅನುಷ್ಠಾನವು ಬದಲಾಗಬಹುದು
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// ಈ `String` ಅನ್ನು [`ಬಾಕ್ಸ್`]`<`[`str`] `>` ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ಇದು ಯಾವುದೇ ಹೆಚ್ಚುವರಿ ಸಾಮರ್ಥ್ಯವನ್ನು ಕುಸಿಯುತ್ತದೆ.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// `String` ಗೆ ಪರಿವರ್ತಿಸಲು ಪ್ರಯತ್ನಿಸಿದ [`u8`] ಬೈಟ್‌ಗಳ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// // vector ನಲ್ಲಿ ಕೆಲವು ಅಮಾನ್ಯ ಬೈಟ್‌ಗಳು
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// `String` ಗೆ ಪರಿವರ್ತಿಸಲು ಪ್ರಯತ್ನಿಸಿದ ಬೈಟ್‌ಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಹಂಚಿಕೆಯನ್ನು ತಪ್ಪಿಸಲು ಈ ವಿಧಾನವನ್ನು ಎಚ್ಚರಿಕೆಯಿಂದ ನಿರ್ಮಿಸಲಾಗಿದೆ.
    /// ಇದು ದೋಷವನ್ನು ಬಳಸುತ್ತದೆ, ಬೈಟ್‌ಗಳನ್ನು ಹೊರಹಾಕುತ್ತದೆ, ಇದರಿಂದ ಬೈಟ್‌ಗಳ ನಕಲನ್ನು ಮಾಡಬೇಕಾಗಿಲ್ಲ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// // vector ನಲ್ಲಿ ಕೆಲವು ಅಮಾನ್ಯ ಬೈಟ್‌ಗಳು
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// ಪರಿವರ್ತನೆ ವೈಫಲ್ಯದ ಕುರಿತು ಹೆಚ್ಚಿನ ವಿವರಗಳನ್ನು ಪಡೆಯಲು `Utf8Error` ಅನ್ನು ಪಡೆಯಿರಿ.
    ///
    /// [`std::str`] ಒದಗಿಸಿದ [`Utf8Error`] ಪ್ರಕಾರವು [`u8`] ನ ಸ್ಲೈಸ್ ಅನ್ನು [`&str`] ಗೆ ಪರಿವರ್ತಿಸುವಾಗ ಸಂಭವಿಸಬಹುದಾದ ದೋಷವನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
    /// ಈ ಅರ್ಥದಲ್ಲಿ, ಇದು `FromUtf8Error` ಗೆ ಅನಲಾಗ್ ಆಗಿದೆ.
    /// ಅದನ್ನು ಬಳಸುವ ಕುರಿತು ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// // vector ನಲ್ಲಿ ಕೆಲವು ಅಮಾನ್ಯ ಬೈಟ್‌ಗಳು
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // ಮೊದಲ ಬೈಟ್ ಇಲ್ಲಿ ಅಮಾನ್ಯವಾಗಿದೆ
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // ನಾವು `ಸ್ಟ್ರಿಂಗ್‌'ಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಿಸುತ್ತಿರುವುದರಿಂದ, ಇಟರೇಟರ್‌ನಿಂದ ಮೊದಲ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಪಡೆದುಕೊಳ್ಳುವ ಮೂಲಕ ಮತ್ತು ನಂತರದ ಎಲ್ಲಾ ತಂತಿಗಳನ್ನು ಸೇರಿಸುವ ಮೂಲಕ ನಾವು ಕನಿಷ್ಠ ಒಂದು ಹಂಚಿಕೆಯನ್ನು ತಪ್ಪಿಸಬಹುದು.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // ನಾವು CoW ಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಿಸುತ್ತಿರುವುದರಿಂದ, ಮೊದಲ ಐಟಂ ಅನ್ನು ಪಡೆದುಕೊಳ್ಳುವ ಮೂಲಕ ಮತ್ತು ನಂತರದ ಎಲ್ಲಾ ವಸ್ತುಗಳನ್ನು ಸೇರಿಸುವ ಮೂಲಕ ನಾವು (potentially) ಕನಿಷ್ಠ ಒಂದು ಹಂಚಿಕೆಯನ್ನು ತಪ್ಪಿಸಬಹುದು.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// `&str` ಗಾಗಿ impl ಗೆ ಪ್ರತಿನಿಧಿಸುವ ಅನುಕೂಲಕರ impl.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// ಖಾಲಿ `String` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// ಎರಡು ತಂತಿಗಳನ್ನು ಜೋಡಿಸಲು `+` ಆಪರೇಟರ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
///
/// ಇದು ಎಡಗೈಯಲ್ಲಿರುವ `String` ಅನ್ನು ಬಳಸುತ್ತದೆ ಮತ್ತು ಅದರ ಬಫರ್ ಅನ್ನು ಮತ್ತೆ ಬಳಸುತ್ತದೆ (ಅಗತ್ಯವಿದ್ದರೆ ಅದನ್ನು ಬೆಳೆಯುವುದು).
/// ಹೊಸ `String` ಅನ್ನು ನಿಯೋಜಿಸುವುದನ್ನು ತಪ್ಪಿಸಲು ಮತ್ತು ಪ್ರತಿ ಕಾರ್ಯಾಚರಣೆಯಲ್ಲಿ ಸಂಪೂರ್ಣ ವಿಷಯಗಳನ್ನು ನಕಲಿಸುವುದನ್ನು ತಪ್ಪಿಸಲು ಇದನ್ನು ಮಾಡಲಾಗುತ್ತದೆ, ಇದು ಪುನರಾವರ್ತಿತ ಒಗ್ಗೂಡಿಸುವಿಕೆಯಿಂದ *n*-ಬೈಟ್ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ನಿರ್ಮಿಸುವಾಗ *O*(*n*^ 2) ಚಾಲನೆಯಲ್ಲಿರುವ ಸಮಯಕ್ಕೆ ಕಾರಣವಾಗುತ್ತದೆ.
///
///
/// ಬಲಗೈಯಲ್ಲಿರುವ ದಾರವನ್ನು ಮಾತ್ರ ಎರವಲು ಪಡೆಯಲಾಗುತ್ತದೆ;ಅದರ ವಿಷಯಗಳನ್ನು ಹಿಂತಿರುಗಿಸಿದ `String` ಗೆ ನಕಲಿಸಲಾಗುತ್ತದೆ.
///
/// # Examples
///
/// ಎರಡು `ಸ್ಟ್ರಿಂಗ್'ಗಳನ್ನು ಒಗ್ಗೂಡಿಸುವುದು ಮೊದಲನೆಯದನ್ನು ಮೌಲ್ಯದಿಂದ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ ಮತ್ತು ಎರಡನೆಯದನ್ನು ಎರವಲು ಪಡೆಯುತ್ತದೆ:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` ಸರಿಸಲಾಗಿದೆ ಮತ್ತು ಇನ್ನು ಮುಂದೆ ಇಲ್ಲಿ ಬಳಸಲಾಗುವುದಿಲ್ಲ.
/// ```
///
/// ನೀವು ಮೊದಲ `String` ಅನ್ನು ಬಳಸುವುದನ್ನು ಮುಂದುವರಿಸಲು ಬಯಸಿದರೆ, ನೀವು ಅದನ್ನು ಕ್ಲೋನ್ ಮಾಡಬಹುದು ಮತ್ತು ಬದಲಿಗೆ ಕ್ಲೋನ್‌ಗೆ ಸೇರಿಸಬಹುದು:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` ಇನ್ನೂ ಇಲ್ಲಿ ಮಾನ್ಯವಾಗಿದೆ.
/// ```
///
/// ಮೊದಲನೆಯದನ್ನು `String` ಗೆ ಪರಿವರ್ತಿಸುವ ಮೂಲಕ `&str` ಚೂರುಗಳನ್ನು ಜೋಡಿಸಬಹುದು:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// `String` ಗೆ ಸೇರಿಸಲು `+=` ಆಪರೇಟರ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
///
/// ಇದು [`push_str`][String::push_str] ವಿಧಾನದಂತೆಯೇ ವರ್ತನೆಯನ್ನು ಹೊಂದಿದೆ.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// [`Infallible`] ಗಾಗಿ ಒಂದು ರೀತಿಯ ಅಲಿಯಾಸ್.
///
/// ಈ ಅಲಿಯಾಸ್ ಹಿಮ್ಮುಖ ಹೊಂದಾಣಿಕೆಗಾಗಿ ಅಸ್ತಿತ್ವದಲ್ಲಿದೆ, ಮತ್ತು ಅಂತಿಮವಾಗಿ ಅದನ್ನು ಅಸಮ್ಮತಿಸಬಹುದು.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// ಮೌಲ್ಯವನ್ನು `String` ಗೆ ಪರಿವರ್ತಿಸಲು trait.
///
/// [`Display`] trait ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಯಾವುದೇ ಪ್ರಕಾರಕ್ಕೆ ಈ trait ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಕಾರ್ಯಗತಗೊಳ್ಳುತ್ತದೆ.
/// ಅಂತೆಯೇ, `ToString` ಅನ್ನು ನೇರವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸಬಾರದು:
/// [`Display`] ಬದಲಿಗೆ ಕಾರ್ಯಗತಗೊಳಿಸಬೇಕು, ಮತ್ತು ನೀವು `ToString` ಅನುಷ್ಠಾನವನ್ನು ಉಚಿತವಾಗಿ ಪಡೆಯುತ್ತೀರಿ.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// ಕೊಟ್ಟಿರುವ ಮೌಲ್ಯವನ್ನು `String` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// ಈ ಅನುಷ್ಠಾನದಲ್ಲಿ, `Display` ಅನುಷ್ಠಾನವು ದೋಷವನ್ನು ನೀಡಿದರೆ `to_string` ವಿಧಾನ panics.
/// `fmt::Write for String` ಎಂದಿಗೂ ದೋಷವನ್ನು ಹಿಂತಿರುಗಿಸದ ಕಾರಣ ಇದು ತಪ್ಪಾದ `Display` ಅನುಷ್ಠಾನವನ್ನು ಸೂಚಿಸುತ್ತದೆ.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // ಸಾಮಾನ್ಯ ಕಾರ್ಯಗಳನ್ನು ಇನ್ಲೈನ್ ಮಾಡದಿರುವುದು ಸಾಮಾನ್ಯ ಮಾರ್ಗಸೂಚಿ.
    // ಆದಾಗ್ಯೂ, ಈ ವಿಧಾನದಿಂದ `#[inline]` ಅನ್ನು ತೆಗೆದುಹಾಕುವುದು ನಗಣ್ಯವಲ್ಲದ ಹಿಂಜರಿತಗಳಿಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
    // ಅದನ್ನು ತೆಗೆದುಹಾಕಲು ಪ್ರಯತ್ನಿಸುವ ಕೊನೆಯ ಪ್ರಯತ್ನವಾದ <https://github.com/rust-lang/rust/pull/74852> ನೋಡಿ.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// `&mut str` ಅನ್ನು `String` ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ಫಲಿತಾಂಶವನ್ನು ರಾಶಿಯ ಮೇಲೆ ಹಂಚಲಾಗುತ್ತದೆ.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: ಪರೀಕ್ಷೆಯು libstd ನಲ್ಲಿ ಎಳೆಯುತ್ತದೆ, ಅದು ಇಲ್ಲಿ ದೋಷಗಳನ್ನು ಉಂಟುಮಾಡುತ್ತದೆ
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// ಕೊಟ್ಟಿರುವ ಪೆಟ್ಟಿಗೆಯ `str` ಸ್ಲೈಸ್ ಅನ್ನು `String` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    /// `str` ಸ್ಲೈಸ್ ಒಡೆತನದಲ್ಲಿದೆ ಎಂಬುದು ಗಮನಾರ್ಹ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// ಕೊಟ್ಟಿರುವ `String` ಅನ್ನು ಬಾಕ್ಸ್ಡ್ `str` ಸ್ಲೈಸ್‌ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಎರವಲು ಪಡೆದ ರೂಪಾಂತರವಾಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    /// ಯಾವುದೇ ರಾಶಿ ಹಂಚಿಕೆಯನ್ನು ನಡೆಸಲಾಗುವುದಿಲ್ಲ, ಮತ್ತು ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ನಕಲಿಸಲಾಗುವುದಿಲ್ಲ.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಮಾಲೀಕತ್ವದ ರೂಪಾಂತರವಾಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    /// ಯಾವುದೇ ರಾಶಿ ಹಂಚಿಕೆಯನ್ನು ನಡೆಸಲಾಗುವುದಿಲ್ಲ, ಮತ್ತು ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ನಕಲಿಸಲಾಗುವುದಿಲ್ಲ.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// ಸ್ಟ್ರಿಂಗ್ ಉಲ್ಲೇಖವನ್ನು ಎರವಲು ಪಡೆದ ರೂಪಾಂತರವಾಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    /// ಯಾವುದೇ ರಾಶಿ ಹಂಚಿಕೆಯನ್ನು ನಡೆಸಲಾಗುವುದಿಲ್ಲ, ಮತ್ತು ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ನಕಲಿಸಲಾಗುವುದಿಲ್ಲ.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// ಕೊಟ್ಟಿರುವ `String` ಅನ್ನು vector `Vec` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ, ಅದು `u8` ಪ್ರಕಾರದ ಮೌಲ್ಯಗಳನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// `String` ಗಾಗಿ ಬರಿದಾಗುತ್ತಿರುವ ಪುನರಾವರ್ತಕ.
///
/// ಈ ರಚನೆಯನ್ನು [`String`] ನಲ್ಲಿ [`drain`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// ವಿನಾಶಕದಲ್ಲಿ&'ಮಟ್ ಸ್ಟ್ರಿಂಗ್ ಆಗಿ ಬಳಸಲಾಗುತ್ತದೆ
    string: *mut String,
    /// ತೆಗೆದುಹಾಕಲು ಭಾಗದ ಪ್ರಾರಂಭ
    start: usize,
    /// ತೆಗೆದುಹಾಕಲು ಭಾಗದ ಅಂತ್ಯ
    end: usize,
    /// ತೆಗೆದುಹಾಕಲು ಪ್ರಸ್ತುತ ಉಳಿದ ಶ್ರೇಣಿ
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Vec::drain ಬಳಸಿ.
            // "Reaffirm" panic ಕೋಡ್ ಅನ್ನು ಮತ್ತೆ ಸೇರಿಸುವುದನ್ನು ತಪ್ಪಿಸಲು ಬೌಂಡ್ಸ್ ಪರಿಶೀಲಿಸುತ್ತದೆ.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// ಈ ಪುನರಾವರ್ತಕದ ಉಳಿದ (ಉಪ) ದಾರವನ್ನು ಸ್ಲೈಸ್‌ನಂತೆ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: ಸ್ಥಿರತೆ AsRef ಸ್ಥಿರಗೊಳಿಸುವಾಗ ಕೆಳಗೆ ಇಂಪ್ಲ್ಸ್.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// `string_drain_as_str` ಅನ್ನು ಸ್ಥಿರಗೊಳಿಸುವಾಗ ಅಸಮಾಧಾನ.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>Drain <'a> {fn as_ref(&self)-> &str for ಗಾಗಿ
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// Drain <'a> {fn as_ref(&self)->&[u8] for ಗಾಗಿ impl <' a> AsRef <[u8]>
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}