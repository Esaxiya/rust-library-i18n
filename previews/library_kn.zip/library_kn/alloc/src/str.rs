//! ಯೂನಿಕೋಡ್ ಸ್ಟ್ರಿಂಗ್ ಚೂರುಗಳು.
//!
//! *[See also the `str` primitive type](str).*
//!
//! `&str` ಪ್ರಕಾರವು ಎರಡು ಮುಖ್ಯ ಸ್ಟ್ರಿಂಗ್ ಪ್ರಕಾರಗಳಲ್ಲಿ ಒಂದಾಗಿದೆ, ಇನ್ನೊಂದು `String`.
//! ಅದರ `String` ಪ್ರತಿರೂಪಕ್ಕಿಂತ ಭಿನ್ನವಾಗಿ, ಅದರ ವಿಷಯಗಳನ್ನು ಎರವಲು ಪಡೆಯಲಾಗುತ್ತದೆ.
//!
//! # ಮೂಲ ಬಳಕೆ
//!
//! `&str` ಪ್ರಕಾರದ ಮೂಲ ಸ್ಟ್ರಿಂಗ್ ಘೋಷಣೆ:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! ಇಲ್ಲಿ ನಾವು ಸ್ಟ್ರಿಂಗ್ ಅಕ್ಷರಶಃ ಘೋಷಿಸಿದ್ದೇವೆ, ಇದನ್ನು ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಎಂದೂ ಕರೆಯುತ್ತಾರೆ.
//! ಸ್ಟ್ರಿಂಗ್ ಅಕ್ಷರಸ್ಥರು ಸ್ಥಿರ ಜೀವಿತಾವಧಿಯನ್ನು ಹೊಂದಿದ್ದಾರೆ, ಇದರರ್ಥ ಸ್ಟ್ರಿಂಗ್ `hello_world` ಇಡೀ ಪ್ರೋಗ್ರಾಂನ ಅವಧಿಗೆ ಮಾನ್ಯವಾಗಿರುತ್ತದೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.
//!
//! `ಹಲೋ_ವರ್ಲ್ಡ್` ಅವರ ಜೀವಿತಾವಧಿಯನ್ನು ನಾವು ಸ್ಪಷ್ಟವಾಗಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಬಹುದು:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// ಈ ಮಾಡ್ಯೂಲ್‌ನಲ್ಲಿನ ಅನೇಕ ಬಳಕೆಗಳನ್ನು ಪರೀಕ್ಷಾ ಸಂರಚನೆಯಲ್ಲಿ ಮಾತ್ರ ಬಳಸಲಾಗುತ್ತದೆ.
// ಅವುಗಳನ್ನು ಸರಿಪಡಿಸುವುದಕ್ಕಿಂತ ಬಳಕೆಯಾಗದ_ ಆಮದುಗಳ ಎಚ್ಚರಿಕೆಯನ್ನು ಆಫ್ ಮಾಡುವುದು ಸ್ವಚ್ er ವಾಗಿದೆ.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `Concat<str>` ನಲ್ಲಿನ `str` ಇಲ್ಲಿ ಅರ್ಥಪೂರ್ಣವಾಗಿಲ್ಲ.
/// trait ನ ಈ ಪ್ರಕಾರದ ನಿಯತಾಂಕವು ಮತ್ತೊಂದು impl ಅನ್ನು ಸಕ್ರಿಯಗೊಳಿಸಲು ಮಾತ್ರ ಅಸ್ತಿತ್ವದಲ್ಲಿದೆ.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // ಹಾರ್ಡ್‌ಕೋಡ್ ಗಾತ್ರವನ್ನು ಹೊಂದಿರುವ ಕುಣಿಕೆಗಳು ಹೆಚ್ಚು ವೇಗವಾಗಿ ಚಲಿಸುತ್ತವೆ ಸಣ್ಣ ವಿಭಜಕ ಉದ್ದಗಳನ್ನು ಹೊಂದಿರುವ ಪ್ರಕರಣಗಳನ್ನು ವಿಶೇಷಗೊಳಿಸುತ್ತವೆ
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // ಅನಿಯಂತ್ರಿತ ಶೂನ್ಯವಲ್ಲದ ಗಾತ್ರದ ಹಿನ್ನಡೆ
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Vec ಎರಡಕ್ಕೂ ಕೆಲಸ ಮಾಡುವ ಆಪ್ಟಿಮೈಸ್ಡ್ ಸೇರ್ಪಡೆ ಅನುಷ್ಠಾನ<T>(ಟಿ: ನಕಲಿಸಿ) ಮತ್ತು ಸ್ಟ್ರಿಂಗ್‌ನ ಆಂತರಿಕ ವೆಕ್ ಪ್ರಸ್ತುತ (2018-05-13) ಪ್ರಕಾರದ ಅನುಮಾನ ಮತ್ತು ವಿಶೇಷತೆಯೊಂದಿಗೆ ದೋಷವಿದೆ (ಸಂಚಿಕೆ #36262 ನೋಡಿ) ಈ ಕಾರಣಕ್ಕಾಗಿ ಸ್ಲೈಸ್‌ಕಾನ್‌ಕ್ಯಾಟ್<T>ಟಿ ಗಾಗಿ ವಿಶೇಷವಲ್ಲ: ನಕಲು ಮತ್ತು ಸ್ಲೈಸ್‌ಕಾನ್‌ಕ್ಯಾಟ್<str>ಈ ಕಾರ್ಯದ ಏಕೈಕ ಬಳಕೆದಾರ.
// ಅದನ್ನು ನಿಗದಿಪಡಿಸಿದ ಸಮಯಕ್ಕೆ ಅದನ್ನು ಸ್ಥಳದಲ್ಲಿ ಬಿಡಲಾಗುತ್ತದೆ.
//
// ಸ್ಟ್ರಿಂಗ್-ಸೇರ್ಪಡೆಗಾಗಿ ಮಿತಿಗಳು ಎಸ್: ಎರವಲು<str>ಮತ್ತು Vec-join Borrow <[T]> [T] ಮತ್ತು str ಎರಡೂ ಕೆಲವು T ಗಾಗಿ AsRef <[T]> ಅನ್ನು ಸೂಚಿಸುತ್ತವೆ
// => s.borrow().as_ref() ಮತ್ತು ನಾವು ಯಾವಾಗಲೂ ಚೂರುಗಳನ್ನು ಹೊಂದಿದ್ದೇವೆ
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // ಮೊದಲ ಸ್ಲೈಸ್ ಅದರ ಮೊದಲು ವಿಭಜಕವಿಲ್ಲದೆ ಮಾತ್ರ
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // `len` ಲೆಕ್ಕಾಚಾರವು ಉಕ್ಕಿ ಹರಿಯುತ್ತಿದ್ದರೆ ಸೇರ್ಪಡೆಗೊಂಡ Vec ಯ ನಿಖರವಾದ ಒಟ್ಟು ಉದ್ದವನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡಿ, ನಾವು panic ಅನ್ನು ಹೇಗಾದರೂ ಮೆಮೊರಿಯಿಂದ ಹೊರಗುಳಿಯುತ್ತಿದ್ದೆವು ಮತ್ತು ಉಳಿದ ಕಾರ್ಯಗಳಿಗೆ ಸಂಪೂರ್ಣ Vec ಸುರಕ್ಷತೆಗಾಗಿ ಮೊದಲೇ ನಿಗದಿಪಡಿಸಲಾಗಿದೆ
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // ಪ್ರಾರಂಭಿಸದ ಬಫರ್ ತಯಾರಿಸಿ
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // ನಕಲು ವಿಭಜಕ ಮತ್ತು ಚೂರುಗಳು ಮಿತಿಯಿಲ್ಲದೆ ಚೆಕ್‌ಗಳು ಸಣ್ಣ ವಿಭಜಕಗಳಿಗೆ ಹಾರ್ಡ್‌ಕೋಡ್ ಮಾಡಲಾದ ಆಫ್‌ಸೆಟ್‌ಗಳೊಂದಿಗೆ ಕುಣಿಕೆಗಳನ್ನು ಉತ್ಪಾದಿಸುತ್ತವೆ. (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // ವಿಲಕ್ಷಣ ಸಾಲ ಅನುಷ್ಠಾನವು ಉದ್ದದ ಲೆಕ್ಕಾಚಾರ ಮತ್ತು ನಿಜವಾದ ನಕಲುಗಾಗಿ ವಿಭಿನ್ನ ಹೋಳುಗಳನ್ನು ಹಿಂತಿರುಗಿಸಬಹುದು.
        //
        // ನಾವು ಕರೆ ಮಾಡದವರಿಗೆ ಪ್ರಾರಂಭಿಸದ ಬೈಟ್‌ಗಳನ್ನು ಬಹಿರಂಗಪಡಿಸುವುದಿಲ್ಲ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// ಸ್ಟ್ರಿಂಗ್ ಚೂರುಗಳ ವಿಧಾನಗಳು.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// ನಕಲಿಸುವ ಅಥವಾ ಹಂಚಿಕೆ ಮಾಡದೆ `Box<str>` ಅನ್ನು `Box<[u8]>` ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// ಮಾದರಿಯ ಎಲ್ಲಾ ಹೊಂದಾಣಿಕೆಗಳನ್ನು ಮತ್ತೊಂದು ಸ್ಟ್ರಿಂಗ್‌ನೊಂದಿಗೆ ಬದಲಾಯಿಸುತ್ತದೆ.
    ///
    /// `replace` ಹೊಸ [`String`] ಅನ್ನು ರಚಿಸುತ್ತದೆ, ಮತ್ತು ಈ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನಿಂದ ಡೇಟಾವನ್ನು ಅದರಲ್ಲಿ ನಕಲಿಸುತ್ತದೆ.
    /// ಹಾಗೆ ಮಾಡುವಾಗ, ಇದು ಒಂದು ಮಾದರಿಯ ಹೊಂದಾಣಿಕೆಗಳನ್ನು ಕಂಡುಹಿಡಿಯಲು ಪ್ರಯತ್ನಿಸುತ್ತದೆ.
    /// ಅದು ಯಾವುದನ್ನಾದರೂ ಕಂಡುಕೊಂಡರೆ, ಅದು ಅವುಗಳನ್ನು ಬದಲಿ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನೊಂದಿಗೆ ಬದಲಾಯಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// ಮಾದರಿಯು ಹೊಂದಿಕೆಯಾಗದಿದ್ದಾಗ:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// ಮಾದರಿಯ ಮೊದಲ N ಪಂದ್ಯಗಳನ್ನು ಮತ್ತೊಂದು ಸ್ಟ್ರಿಂಗ್‌ನೊಂದಿಗೆ ಬದಲಾಯಿಸುತ್ತದೆ.
    ///
    /// `replacen` ಹೊಸ [`String`] ಅನ್ನು ರಚಿಸುತ್ತದೆ, ಮತ್ತು ಈ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನಿಂದ ಡೇಟಾವನ್ನು ಅದರಲ್ಲಿ ನಕಲಿಸುತ್ತದೆ.
    /// ಹಾಗೆ ಮಾಡುವಾಗ, ಇದು ಒಂದು ಮಾದರಿಯ ಹೊಂದಾಣಿಕೆಗಳನ್ನು ಕಂಡುಹಿಡಿಯಲು ಪ್ರಯತ್ನಿಸುತ್ತದೆ.
    /// ಅದು ಯಾವುದನ್ನಾದರೂ ಕಂಡುಕೊಂಡರೆ, ಅದು ಅವುಗಳನ್ನು `count` ಸಮಯಗಳಲ್ಲಿ ಬದಲಿ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನೊಂದಿಗೆ ಬದಲಾಯಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// ಮಾದರಿಯು ಹೊಂದಿಕೆಯಾಗದಿದ್ದಾಗ:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // ಮರು ಹಂಚಿಕೆಯ ಸಮಯವನ್ನು ಕಡಿಮೆ ಮಾಡುವ ಭರವಸೆ
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// ಹೊಸ [`String`] ನಂತೆ ಈ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ಗೆ ಸಮಾನವಾದ ಸಣ್ಣ ಅಕ್ಷರವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// 'Lowercase' ಯುನಿಕೋಡ್ ಪಡೆದ ಕೋರ್ ಪ್ರಾಪರ್ಟಿ `Lowercase` ನ ನಿಯಮಗಳ ಪ್ರಕಾರ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿದೆ.
    ///
    /// ಪ್ರಕರಣವನ್ನು ಬದಲಾಯಿಸುವಾಗ ಕೆಲವು ಅಕ್ಷರಗಳು ಅನೇಕ ಅಕ್ಷರಗಳಾಗಿ ವಿಸ್ತರಿಸಬಹುದು, ಈ ಕಾರ್ಯವು ನಿಯತಾಂಕವನ್ನು ಸ್ಥಳದಲ್ಲಿ ಮಾರ್ಪಡಿಸುವ ಬದಲು [`String`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// ಸಿಗ್ಮಾದೊಂದಿಗೆ ಒಂದು ಟ್ರಿಕಿ ಉದಾಹರಣೆ:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // ಆದರೆ ಪದದ ಕೊನೆಯಲ್ಲಿ, ಅದು ς, not ಅಲ್ಲ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// ಪ್ರಕರಣವಿಲ್ಲದ ಭಾಷೆಗಳನ್ನು ಬದಲಾಯಿಸಲಾಗುವುದಿಲ್ಲ:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Word ಗೆ ನಕ್ಷೆಗಳು where, ಪದದ ಕೊನೆಯಲ್ಲಿ maps ಗೆ ನಕ್ಷೆ ಮಾಡುವುದನ್ನು ಹೊರತುಪಡಿಸಿ.
                // ಇದು `SpecialCasing.txt` ನಲ್ಲಿನ ಏಕೈಕ ಷರತ್ತುಬದ್ಧ (contextual) ಆದರೆ ಭಾಷೆ-ಸ್ವತಂತ್ರ ಮ್ಯಾಪಿಂಗ್ ಆಗಿದೆ, ಆದ್ದರಿಂದ ಜೆನೆರಿಕ್ "condition" ಯಾಂತ್ರಿಕ ವ್ಯವಸ್ಥೆಯನ್ನು ಹೊಂದಿರುವುದಕ್ಕಿಂತ ಹಾರ್ಡ್-ಕೋಡ್ ಮಾಡಿ.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // `Final_Sigma` ವ್ಯಾಖ್ಯಾನಕ್ಕಾಗಿ.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// ಈ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ಗೆ ದೊಡ್ಡಕ್ಷರವನ್ನು ಹೊಸ [`String`] ಆಗಿ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// 'Uppercase' ಯುನಿಕೋಡ್ ಪಡೆದ ಕೋರ್ ಪ್ರಾಪರ್ಟಿ `Uppercase` ನ ನಿಯಮಗಳ ಪ್ರಕಾರ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿದೆ.
    ///
    /// ಪ್ರಕರಣವನ್ನು ಬದಲಾಯಿಸುವಾಗ ಕೆಲವು ಅಕ್ಷರಗಳು ಅನೇಕ ಅಕ್ಷರಗಳಾಗಿ ವಿಸ್ತರಿಸಬಹುದು, ಈ ಕಾರ್ಯವು ನಿಯತಾಂಕವನ್ನು ಸ್ಥಳದಲ್ಲಿ ಮಾರ್ಪಡಿಸುವ ಬದಲು [`String`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// ಪ್ರಕರಣವಿಲ್ಲದ ಸ್ಕ್ರಿಪ್ಟ್‌ಗಳನ್ನು ಬದಲಾಯಿಸಲಾಗುವುದಿಲ್ಲ:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// ಒಂದು ಅಕ್ಷರ ಬಹು ಆಗಬಹುದು:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// ನಕಲಿಸುವ ಅಥವಾ ಹಂಚಿಕೆ ಮಾಡದೆ [`Box<str>`] ಅನ್ನು [`String`] ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// ಸ್ಟ್ರಿಂಗ್ `n` ಬಾರಿ ಪುನರಾವರ್ತಿಸುವ ಮೂಲಕ ಹೊಸ [`String`] ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// ಸಾಮರ್ಥ್ಯವು ಉಕ್ಕಿ ಹರಿಯುತ್ತಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// ಉಕ್ಕಿ ಹರಿಯುವಾಗ panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// ಈ ಸ್ಟ್ರಿಂಗ್‌ನ ನಕಲನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಲ್ಲಿ ಪ್ರತಿಯೊಂದು ಅಕ್ಷರವನ್ನು ಅದರ ಎಎಸ್‌ಸಿಐಐ ಮೇಲಿನ ಪ್ರಕರಣಕ್ಕೆ ಸಮನಾಗಿ ಮ್ಯಾಪ್ ಮಾಡಲಾಗುತ್ತದೆ.
    ///
    ///
    /// ASCII ಅಕ್ಷರಗಳು 'a' ರಿಂದ 'z' ಅನ್ನು 'A' ನಿಂದ 'Z' ಗೆ ಮ್ಯಾಪ್ ಮಾಡಲಾಗಿದೆ, ಆದರೆ ASCII ಅಲ್ಲದ ಅಕ್ಷರಗಳು ಬದಲಾಗುವುದಿಲ್ಲ.
    ///
    /// ಸ್ಥಳದಲ್ಲಿ ಮೌಲ್ಯವನ್ನು ದೊಡ್ಡದಾಗಿಸಲು, [`make_ascii_uppercase`] ಬಳಸಿ.
    ///
    /// ASCII ಅಲ್ಲದ ಅಕ್ಷರಗಳ ಜೊತೆಗೆ ASCII ಅಕ್ಷರಗಳನ್ನು ದೊಡ್ಡದಾಗಿಸಲು, [`to_uppercase`] ಬಳಸಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() UTF-8 ಅಸ್ಥಿರತೆಯನ್ನು ಸಂರಕ್ಷಿಸುತ್ತದೆ.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// ಈ ಸ್ಟ್ರಿಂಗ್‌ನ ನಕಲನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಲ್ಲಿ ಪ್ರತಿಯೊಂದು ಅಕ್ಷರವನ್ನು ಅದರ ಎಎಸ್‌ಸಿಐಐ ಲೋವರ್ ಕೇಸ್ ಸಮಾನಕ್ಕೆ ಮ್ಯಾಪ್ ಮಾಡಲಾಗುತ್ತದೆ.
    ///
    ///
    /// ASCII ಅಕ್ಷರಗಳು 'A' ರಿಂದ 'Z' ಅನ್ನು 'a' ನಿಂದ 'z' ಗೆ ಮ್ಯಾಪ್ ಮಾಡಲಾಗಿದೆ, ಆದರೆ ASCII ಅಲ್ಲದ ಅಕ್ಷರಗಳು ಬದಲಾಗುವುದಿಲ್ಲ.
    ///
    /// ಸ್ಥಳದಲ್ಲಿ ಮೌಲ್ಯವನ್ನು ಕಡಿಮೆ ಮಾಡಲು, [`make_ascii_lowercase`] ಬಳಸಿ.
    ///
    /// ASCII ಅಲ್ಲದ ಅಕ್ಷರಗಳ ಜೊತೆಗೆ ASCII ಅಕ್ಷರಗಳನ್ನು ಕಡಿಮೆ ಮಾಡಲು, [`to_lowercase`] ಬಳಸಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() UTF-8 ಅಸ್ಥಿರತೆಯನ್ನು ಸಂರಕ್ಷಿಸುತ್ತದೆ.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// ಸ್ಟ್ರಿಂಗ್ ಮಾನ್ಯ UTF-8 ಅನ್ನು ಹೊಂದಿದೆಯೆ ಎಂದು ಪರಿಶೀಲಿಸದೆ ಬಾಕ್ಸಡ್ ಸ್ಲೈಸ್ ಬೈಟ್‌ಗಳನ್ನು ಬಾಕ್ಸಡ್ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
///
///
/// # Examples
///
/// ಮೂಲ ಬಳಕೆ:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}