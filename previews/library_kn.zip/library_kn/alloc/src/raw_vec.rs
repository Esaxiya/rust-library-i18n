#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// ಹೊಸ ಮೆಮೊರಿಯ ವಿಷಯಗಳನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗಿಲ್ಲ.
    Uninitialized,
    /// ಹೊಸ ಮೆಮೊರಿ ಶೂನ್ಯವಾಗಿರುತ್ತದೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.
    Zeroed,
}

/// ಒಳಗೊಂಡಿರುವ ಎಲ್ಲಾ ಮೂಲೆಯ ಪ್ರಕರಣಗಳ ಬಗ್ಗೆ ಚಿಂತಿಸದೆ ಹೆಚ್ಚು ದಕ್ಷತಾಶಾಸ್ತ್ರೀಯವಾಗಿ ಹಂಚಿಕೆ, ಮರುಹಂಚಿಕೆ ಮತ್ತು ರಾಶಿಯಲ್ಲಿ ಮೆಮೊರಿಯ ಬಫರ್ ಅನ್ನು ಡಿಲೊಲೊಕೇಟ್ ಮಾಡಲು ಕಡಿಮೆ ಮಟ್ಟದ ಉಪಯುಕ್ತತೆ.
///
/// Vec ಮತ್ತು VecDeque ನಂತಹ ನಿಮ್ಮ ಸ್ವಂತ ಡೇಟಾ ರಚನೆಗಳನ್ನು ನಿರ್ಮಿಸಲು ಈ ಪ್ರಕಾರವು ಅತ್ಯುತ್ತಮವಾಗಿದೆ.
/// ನಿರ್ದಿಷ್ಟವಾಗಿ:
///
/// * ಶೂನ್ಯ-ಗಾತ್ರದ ಪ್ರಕಾರಗಳಲ್ಲಿ `Unique::dangling()` ಅನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ.
/// * ಶೂನ್ಯ-ಉದ್ದದ ಹಂಚಿಕೆಗಳಲ್ಲಿ `Unique::dangling()` ಅನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ.
/// * `Unique::dangling()` ಅನ್ನು ಮುಕ್ತಗೊಳಿಸುವುದನ್ನು ತಪ್ಪಿಸುತ್ತದೆ.
/// * ಸಾಮರ್ಥ್ಯದ ಗಣನೆಗಳಲ್ಲಿ ಎಲ್ಲಾ ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆ (ಅವುಗಳನ್ನು "capacity overflow" panics ಗೆ ಉತ್ತೇಜಿಸುತ್ತದೆ).
/// * isize::MAX ಬೈಟ್‌ಗಳಿಗಿಂತ ಹೆಚ್ಚು ಹಂಚಿಕೆ ಮಾಡುವ 32-ಬಿಟ್ ವ್ಯವಸ್ಥೆಗಳ ವಿರುದ್ಧ ಕಾವಲುಗಾರರು.
/// * ನಿಮ್ಮ ಉದ್ದವನ್ನು ಉಕ್ಕಿ ಹರಿಯದಂತೆ ಕಾವಲುಗಾರರು.
/// * ತಪ್ಪಾದ ಹಂಚಿಕೆಗಳಿಗಾಗಿ `handle_alloc_error` ಅನ್ನು ಕರೆ ಮಾಡುತ್ತದೆ.
/// * `ptr::Unique` ಅನ್ನು ಹೊಂದಿರುತ್ತದೆ ಮತ್ತು ಆದ್ದರಿಂದ ಬಳಕೆದಾರರಿಗೆ ಎಲ್ಲಾ ಸಂಬಂಧಿತ ಪ್ರಯೋಜನಗಳನ್ನು ನೀಡುತ್ತದೆ.
/// * ಲಭ್ಯವಿರುವ ಅತಿದೊಡ್ಡ ಸಾಮರ್ಥ್ಯವನ್ನು ಬಳಸಲು ಹಂಚಿಕೆದಾರರಿಂದ ಹಿಂತಿರುಗಿದ ಹೆಚ್ಚುವರಿವನ್ನು ಬಳಸುತ್ತದೆ.
///
/// ಈ ಪ್ರಕಾರವು ಅದು ನಿರ್ವಹಿಸುವ ಮೆಮೊರಿಯನ್ನು ಹೇಗಾದರೂ ಪರೀಕ್ಷಿಸುವುದಿಲ್ಲ.ಅದನ್ನು ಕೈಬಿಟ್ಟಾಗ *ಅದರ ಸ್ಮರಣೆಯನ್ನು ಮುಕ್ತಗೊಳಿಸುತ್ತದೆ, ಆದರೆ ಅದು* ಅದರ ವಿಷಯಗಳನ್ನು ಬಿಡಲು ಪ್ರಯತ್ನಿಸುವುದಿಲ್ಲ.
/// `RawVec` ನ ಒಳಗೆ *ಸಂಗ್ರಹವಾಗಿರುವ* ನೈಜ ವಸ್ತುಗಳನ್ನು ನಿರ್ವಹಿಸುವುದು `RawVec` ನ ಬಳಕೆದಾರರಿಗೆ ಬಿಟ್ಟದ್ದು.
///
/// ಶೂನ್ಯ-ಗಾತ್ರದ ಪ್ರಕಾರಗಳ ಮಿತಿ ಯಾವಾಗಲೂ ಅನಂತವಾಗಿರುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಆದ್ದರಿಂದ `capacity()` ಯಾವಾಗಲೂ `usize::MAX` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
/// ಇದರರ್ಥ `Box<[T]>` ನೊಂದಿಗೆ ಈ ಪ್ರಕಾರವನ್ನು ರೌಂಡ್-ಟ್ರಿಪ್ಪಿಂಗ್ ಮಾಡುವಾಗ ನೀವು ಜಾಗರೂಕರಾಗಿರಬೇಕು, ಏಕೆಂದರೆ `capacity()` ಉದ್ದವನ್ನು ನೀಡುವುದಿಲ್ಲ.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): ಇದು ಅಸ್ತಿತ್ವದಲ್ಲಿದೆ ಏಕೆಂದರೆ `#[unstable]` `const fn`s `min_const_fn` ಗೆ ಅನುಗುಣವಾಗಿರಬೇಕಾಗಿಲ್ಲ ಮತ್ತು ಆದ್ದರಿಂದ ಅವುಗಳನ್ನು`min_const_fn` ಗಳಲ್ಲಿ ಕರೆಯಲಾಗುವುದಿಲ್ಲ.
    ///
    /// ನೀವು `RawVec<T>::new` ಅಥವಾ ಅವಲಂಬನೆಗಳನ್ನು ಬದಲಾಯಿಸಿದರೆ, ದಯವಿಟ್ಟು `min_const_fn` ಅನ್ನು ನಿಜವಾಗಿಯೂ ಉಲ್ಲಂಘಿಸುವ ಯಾವುದನ್ನೂ ಪರಿಚಯಿಸದಂತೆ ನೋಡಿಕೊಳ್ಳಿ.
    ///
    /// NOTE: ನಾವು ಈ ಹ್ಯಾಕ್ ಅನ್ನು ತಪ್ಪಿಸಬಹುದು ಮತ್ತು ಕೆಲವು `#[rustc_force_min_const_fn]` ಗುಣಲಕ್ಷಣದೊಂದಿಗೆ ಅನುಸರಣೆಯನ್ನು ಪರಿಶೀಲಿಸಬಹುದು, ಅದು `min_const_fn` ನೊಂದಿಗೆ ಅನುಸರಣೆಯ ಅಗತ್ಯವಿರುತ್ತದೆ ಆದರೆ `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ಇರುವಾಗ `foo` ಅನ್ನು ಸಕ್ರಿಯಗೊಳಿಸದ `stable(...) const fn`/ಯೂಸರ್ ಕೋಡ್‌ನಲ್ಲಿ ಕರೆ ಮಾಡಲು ಅನುಮತಿಸುವುದಿಲ್ಲ.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// ಹಂಚಿಕೆ ಮಾಡದೆ ಅತಿದೊಡ್ಡ `RawVec` (ಸಿಸ್ಟಮ್ ರಾಶಿಯಲ್ಲಿ) ರಚಿಸುತ್ತದೆ.
    /// `T` ಸಕಾರಾತ್ಮಕ ಗಾತ್ರವನ್ನು ಹೊಂದಿದ್ದರೆ, ಇದು `0` ಸಾಮರ್ಥ್ಯದೊಂದಿಗೆ `RawVec` ಅನ್ನು ಮಾಡುತ್ತದೆ.
    /// `T` ಶೂನ್ಯ-ಗಾತ್ರದ್ದಾಗಿದ್ದರೆ, ಅದು `usize::MAX` ಸಾಮರ್ಥ್ಯದೊಂದಿಗೆ `RawVec` ಅನ್ನು ಮಾಡುತ್ತದೆ.
    /// ವಿಳಂಬ ಹಂಚಿಕೆಯನ್ನು ಅನುಷ್ಠಾನಗೊಳಿಸಲು ಉಪಯುಕ್ತವಾಗಿದೆ.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// `[T; capacity]` ಗಾಗಿ ನಿಖರವಾಗಿ ಸಾಮರ್ಥ್ಯ ಮತ್ತು ಜೋಡಣೆ ಅಗತ್ಯತೆಗಳೊಂದಿಗೆ `RawVec` (ಸಿಸ್ಟಮ್ ರಾಶಿಯಲ್ಲಿ) ರಚಿಸುತ್ತದೆ.
    /// `capacity` `0` ಅಥವಾ `T` ಶೂನ್ಯ-ಗಾತ್ರದಾಗ `RawVec::new` ಗೆ ಕರೆ ಮಾಡಲು ಇದು ಸಮಾನವಾಗಿರುತ್ತದೆ.
    /// `T` ಶೂನ್ಯ-ಗಾತ್ರದ್ದಾಗಿದ್ದರೆ ಇದರರ್ಥ ನೀವು ವಿನಂತಿಸಿದ ಸಾಮರ್ಥ್ಯದೊಂದಿಗೆ `RawVec` ಅನ್ನು ಪಡೆಯುವುದಿಲ್ಲ.
    ///
    /// # Panics
    ///
    /// ವಿನಂತಿಸಿದ ಸಾಮರ್ಥ್ಯವು `isize::MAX` ಬೈಟ್‌ಗಳನ್ನು ಮೀರಿದರೆ Panics.
    ///
    /// # Aborts
    ///
    /// OOM ನಲ್ಲಿ ಸ್ಥಗಿತಗೊಳ್ಳುತ್ತದೆ.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// `with_capacity` ನಂತೆ, ಆದರೆ ಬಫರ್ ಶೂನ್ಯವಾಗಿರುತ್ತದೆ ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// ಪಾಯಿಂಟರ್ ಮತ್ತು ಸಾಮರ್ಥ್ಯದಿಂದ `RawVec` ಅನ್ನು ಪುನರ್ನಿರ್ಮಿಸುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// `ptr` ಅನ್ನು ನಿಯೋಜಿಸಬೇಕು (ಸಿಸ್ಟಮ್ ರಾಶಿಯಲ್ಲಿ), ಮತ್ತು ಕೊಟ್ಟಿರುವ `capacity` ನೊಂದಿಗೆ.
    /// ಗಾತ್ರದ ಪ್ರಕಾರಗಳಿಗಾಗಿ `capacity` `isize::MAX` ಅನ್ನು ಮೀರಬಾರದು.(32-ಬಿಟ್ ವ್ಯವಸ್ಥೆಗಳಲ್ಲಿ ಮಾತ್ರ ಕಾಳಜಿ).
    /// ZST vectors `usize::MAX` ವರೆಗೆ ಸಾಮರ್ಥ್ಯವನ್ನು ಹೊಂದಿರಬಹುದು.
    /// `ptr` ಮತ್ತು `capacity` `RawVec` ನಿಂದ ಬಂದರೆ, ಇದು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // ಸಣ್ಣ ವೆಕ್ಸ್ ಮೂಕ.ಇದಕ್ಕೆ ತೆರಳಿ:
    // - 8 ಅಂಶದ ಗಾತ್ರ 1 ಆಗಿದ್ದರೆ, ಏಕೆಂದರೆ ಯಾವುದೇ ರಾಶಿ ಹಂಚಿಕೆದಾರರು 8 ಬೈಟ್‌ಗಳಿಗಿಂತ ಕಡಿಮೆ ಇರುವ ವಿನಂತಿಯನ್ನು ಕನಿಷ್ಠ 8 ಬೈಟ್‌ಗಳಿಗೆ ಪೂರ್ಣಗೊಳಿಸುವ ಸಾಧ್ಯತೆಯಿದೆ.
    //
    // - 4 ಅಂಶಗಳು ಮಧ್ಯಮ ಗಾತ್ರದದ್ದಾಗಿದ್ದರೆ (<=1 ಕಿಬಿ).
    // - 1 ಇಲ್ಲದಿದ್ದರೆ, ಬಹಳ ಕಡಿಮೆ Vec ಗಳಿಗೆ ಹೆಚ್ಚಿನ ಸ್ಥಳವನ್ನು ವ್ಯರ್ಥ ಮಾಡುವುದನ್ನು ತಪ್ಪಿಸಲು.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// `new` ನಂತೆ, ಆದರೆ ಹಿಂತಿರುಗಿದ `RawVec` ಗಾಗಿ ಹಂಚಿಕೆಯ ಆಯ್ಕೆಯ ಮೇಲೆ ನಿಯತಾಂಕಗೊಳಿಸಲಾಗಿದೆ.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` ಅಂದರೆ "unallocated".ಶೂನ್ಯ-ಗಾತ್ರದ ಪ್ರಕಾರಗಳನ್ನು ನಿರ್ಲಕ್ಷಿಸಲಾಗುತ್ತದೆ.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// `with_capacity` ನಂತೆ, ಆದರೆ ಹಿಂತಿರುಗಿದ `RawVec` ಗಾಗಿ ಹಂಚಿಕೆಯ ಆಯ್ಕೆಯ ಮೇಲೆ ನಿಯತಾಂಕಗೊಳಿಸಲಾಗಿದೆ.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// `with_capacity_zeroed` ನಂತೆ, ಆದರೆ ಹಿಂತಿರುಗಿದ `RawVec` ಗಾಗಿ ಹಂಚಿಕೆಯ ಆಯ್ಕೆಯ ಮೇಲೆ ನಿಯತಾಂಕಗೊಳಿಸಲಾಗಿದೆ.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>` ಅನ್ನು `RawVec<T>` ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ `len` ನೊಂದಿಗೆ ಸಂಪೂರ್ಣ ಬಫರ್ ಅನ್ನು `Box<[MaybeUninit<T>]>` ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ನಿರ್ವಹಿಸಿದ ಯಾವುದೇ `cap` ಬದಲಾವಣೆಗಳನ್ನು ಇದು ಸರಿಯಾಗಿ ಪುನರ್ನಿರ್ಮಿಸುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.(ವಿವರಗಳಿಗಾಗಿ ಪ್ರಕಾರದ ವಿವರಣೆಯನ್ನು ನೋಡಿ.)
    ///
    /// # Safety
    ///
    /// * `len` ತೀರಾ ಇತ್ತೀಚೆಗೆ ವಿನಂತಿಸಿದ ಸಾಮರ್ಥ್ಯಕ್ಕಿಂತ ದೊಡ್ಡದಾಗಿರಬೇಕು ಅಥವಾ ಸಮನಾಗಿರಬೇಕು, ಮತ್ತು
    /// * `len` `self.capacity()` ಗಿಂತ ಕಡಿಮೆ ಅಥವಾ ಸಮನಾಗಿರಬೇಕು.
    ///
    /// ಗಮನಿಸಿ, ವಿನಂತಿಸಿದ ಸಾಮರ್ಥ್ಯ ಮತ್ತು `self.capacity()` ಭಿನ್ನವಾಗಿರಬಹುದು, ಏಕೆಂದರೆ ಹಂಚಿಕೆದಾರನು ವಿನಂತಿಸಿದಕ್ಕಿಂತ ಹೆಚ್ಚಿನ ಮೆಮೊರಿ ಬ್ಲಾಕ್ ಅನ್ನು ಒಟ್ಟುಗೂಡಿಸಬಹುದು ಮತ್ತು ಹಿಂದಿರುಗಿಸಬಹುದು.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // ಸುರಕ್ಷತೆಯ ಅವಶ್ಯಕತೆಯ ಅರ್ಧದಷ್ಟು ಭಾಗವನ್ನು ವಿವೇಕ-ಪರಿಶೀಲಿಸಿ (ನಾವು ಉಳಿದ ಅರ್ಧವನ್ನು ಪರಿಶೀಲಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // ನಾವು ಇಲ್ಲಿ `unwrap_or_else` ಅನ್ನು ತಪ್ಪಿಸುತ್ತೇವೆ ಏಕೆಂದರೆ ಅದು ಉತ್ಪತ್ತಿಯಾಗುವ LLVM IR ಪ್ರಮಾಣವನ್ನು ಉಬ್ಬಿಸುತ್ತದೆ.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// ಪಾಯಿಂಟರ್, ಸಾಮರ್ಥ್ಯ ಮತ್ತು ಹಂಚಿಕೆದಾರರಿಂದ `RawVec` ಅನ್ನು ಪುನರ್ನಿರ್ಮಿಸುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// `ptr` ಅನ್ನು ನಿಯೋಜಿಸಬೇಕು (ಕೊಟ್ಟಿರುವ ಹಂಚಿಕೆದಾರ `alloc` ಮೂಲಕ), ಮತ್ತು ಕೊಟ್ಟಿರುವ `capacity` ನೊಂದಿಗೆ.
    /// ಗಾತ್ರದ ಪ್ರಕಾರಗಳಿಗಾಗಿ `capacity` `isize::MAX` ಅನ್ನು ಮೀರಬಾರದು.
    /// (32-ಬಿಟ್ ವ್ಯವಸ್ಥೆಗಳಲ್ಲಿ ಮಾತ್ರ ಕಾಳಜಿ).
    /// ZST vectors `usize::MAX` ವರೆಗೆ ಸಾಮರ್ಥ್ಯವನ್ನು ಹೊಂದಿರಬಹುದು.
    /// `ptr` ಮತ್ತು `capacity` `alloc` ಮೂಲಕ ರಚಿಸಲಾದ `RawVec` ನಿಂದ ಬಂದಿದ್ದರೆ, ಇದು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// ಹಂಚಿಕೆಯ ಪ್ರಾರಂಭಕ್ಕೆ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಪಡೆಯುತ್ತದೆ.
    /// `capacity == 0` ಅಥವಾ `T` ಶೂನ್ಯ ಗಾತ್ರದ್ದಾಗಿದ್ದರೆ ಇದು `Unique::dangling()` ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    /// ಹಿಂದಿನ ಸಂದರ್ಭದಲ್ಲಿ, ನೀವು ಜಾಗರೂಕರಾಗಿರಬೇಕು.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// ಹಂಚಿಕೆಯ ಸಾಮರ್ಥ್ಯವನ್ನು ಪಡೆಯುತ್ತದೆ.
    ///
    /// `T` ಶೂನ್ಯ ಗಾತ್ರದ್ದಾಗಿದ್ದರೆ ಇದು ಯಾವಾಗಲೂ `usize::MAX` ಆಗಿರುತ್ತದೆ.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// ಈ `RawVec` ಅನ್ನು ಬೆಂಬಲಿಸುವ ಹಂಚಿಕೆಯ ಹಂಚಿಕೆಯ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // ನಮ್ಮಲ್ಲಿ ಹಂಚಿಕೆಯ ಮೆಮೊರಿಯ ಭಾಗವಿದೆ, ಆದ್ದರಿಂದ ನಮ್ಮ ಪ್ರಸ್ತುತ ವಿನ್ಯಾಸವನ್ನು ಪಡೆಯಲು ನಾವು ಚಾಲನಾಸಮಯ ಪರಿಶೀಲನೆಗಳನ್ನು ಬೈಪಾಸ್ ಮಾಡಬಹುದು.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// `len + additional` ಅಂಶಗಳನ್ನು ಹಿಡಿದಿಡಲು ಬಫರ್ ಕನಿಷ್ಠ ಸ್ಥಳಾವಕಾಶವನ್ನು ಹೊಂದಿದೆ ಎಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ.
    /// ಇದು ಈಗಾಗಲೇ ಸಾಕಷ್ಟು ಸಾಮರ್ಥ್ಯವನ್ನು ಹೊಂದಿಲ್ಲದಿದ್ದರೆ, ಭೋಗ್ಯ *ಒ*(1) ನಡವಳಿಕೆಯನ್ನು ಪಡೆಯಲು ಸಾಕಷ್ಟು ಸ್ಥಳಾವಕಾಶ ಮತ್ತು ಆರಾಮದಾಯಕವಾದ ಸಡಿಲವಾದ ಜಾಗವನ್ನು ಮರುಹಂಚಿಕೆ ಮಾಡುತ್ತದೆ.
    ///
    /// ಅನಗತ್ಯವಾಗಿ panic ಗೆ ಕಾರಣವಾಗಿದ್ದರೆ ಈ ನಡವಳಿಕೆಯನ್ನು ಮಿತಿಗೊಳಿಸುತ್ತದೆ.
    ///
    /// `len` `self.capacity()` ಅನ್ನು ಮೀರಿದರೆ, ಇದು ವಿನಂತಿಸಿದ ಜಾಗವನ್ನು ನಿಯೋಜಿಸುವಲ್ಲಿ ವಿಫಲವಾಗಬಹುದು.
    /// ಇದು ನಿಜವಾಗಿಯೂ ಅಸುರಕ್ಷಿತವಲ್ಲ, ಆದರೆ ಈ ಕಾರ್ಯದ ನಡವಳಿಕೆಯನ್ನು ಅವಲಂಬಿಸಿರುವ *ನೀವು* ಬರೆಯುವ ಅಸುರಕ್ಷಿತ ಕೋಡ್ ಮುರಿಯಬಹುದು.
    ///
    /// `extend` ನಂತಹ ಬೃಹತ್-ಪುಶ್ ಕಾರ್ಯಾಚರಣೆಯನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ಇದು ಸೂಕ್ತವಾಗಿದೆ.
    ///
    /// # Panics
    ///
    /// ಹೊಸ ಸಾಮರ್ಥ್ಯವು `isize::MAX` ಬೈಟ್‌ಗಳನ್ನು ಮೀರಿದರೆ Panics.
    ///
    /// # Aborts
    ///
    /// OOM ನಲ್ಲಿ ಸ್ಥಗಿತಗೊಳ್ಳುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // ಲೆನ್ `isize::MAX` ಅನ್ನು ಮೀರಿದ್ದರೆ ಮೀಸಲು ಸ್ಥಗಿತಗೊಳ್ಳುತ್ತದೆ ಅಥವಾ ಭಯಭೀತರಾಗಬಹುದು, ಆದ್ದರಿಂದ ಇದೀಗ ಪರಿಶೀಲಿಸದೆ ಮಾಡುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// `reserve` ನಂತೆಯೇ ಇರುತ್ತದೆ, ಆದರೆ ಭೀತಿಗೊಳಿಸುವ ಅಥವಾ ಸ್ಥಗಿತಗೊಳಿಸುವ ಬದಲು ದೋಷಗಳನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// `len + additional` ಅಂಶಗಳನ್ನು ಹಿಡಿದಿಡಲು ಬಫರ್ ಕನಿಷ್ಠ ಸ್ಥಳಾವಕಾಶವನ್ನು ಹೊಂದಿದೆ ಎಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ.
    /// ಅದು ಈಗಾಗಲೇ ಇಲ್ಲದಿದ್ದರೆ, ಅಗತ್ಯವಿರುವ ಕನಿಷ್ಠ ಪ್ರಮಾಣದ ಮೆಮೊರಿಯನ್ನು ಮರುಹಂಚಿಕೆ ಮಾಡುತ್ತದೆ.
    /// ಸಾಮಾನ್ಯವಾಗಿ ಇದು ನಿಖರವಾಗಿ ಅಗತ್ಯವಿರುವ ಮೆಮೊರಿಯ ಪ್ರಮಾಣವಾಗಿರುತ್ತದೆ, ಆದರೆ ತಾತ್ವಿಕವಾಗಿ ಹಂಚಿಕೆದಾರರು ನಾವು ಕೇಳಿದ್ದಕ್ಕಿಂತ ಹೆಚ್ಚಿನದನ್ನು ಹಿಂದಿರುಗಿಸಲು ಉಚಿತ.
    ///
    ///
    /// `len` `self.capacity()` ಅನ್ನು ಮೀರಿದರೆ, ಇದು ವಿನಂತಿಸಿದ ಜಾಗವನ್ನು ನಿಯೋಜಿಸುವಲ್ಲಿ ವಿಫಲವಾಗಬಹುದು.
    /// ಇದು ನಿಜವಾಗಿಯೂ ಅಸುರಕ್ಷಿತವಲ್ಲ, ಆದರೆ ಈ ಕಾರ್ಯದ ನಡವಳಿಕೆಯನ್ನು ಅವಲಂಬಿಸಿರುವ *ನೀವು* ಬರೆಯುವ ಅಸುರಕ್ಷಿತ ಕೋಡ್ ಮುರಿಯಬಹುದು.
    ///
    /// # Panics
    ///
    /// ಹೊಸ ಸಾಮರ್ಥ್ಯವು `isize::MAX` ಬೈಟ್‌ಗಳನ್ನು ಮೀರಿದರೆ Panics.
    ///
    /// # Aborts
    ///
    /// OOM ನಲ್ಲಿ ಸ್ಥಗಿತಗೊಳ್ಳುತ್ತದೆ.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// `reserve_exact` ನಂತೆಯೇ ಇರುತ್ತದೆ, ಆದರೆ ಭೀತಿಗೊಳಿಸುವ ಅಥವಾ ಸ್ಥಗಿತಗೊಳಿಸುವ ಬದಲು ದೋಷಗಳನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// ನಿಗದಿತ ಮೊತ್ತಕ್ಕೆ ಹಂಚಿಕೆಯನ್ನು ಕುಗ್ಗಿಸುತ್ತದೆ.
    /// ಕೊಟ್ಟಿರುವ ಮೊತ್ತವು 0 ಆಗಿದ್ದರೆ, ವಾಸ್ತವವಾಗಿ ಸಂಪೂರ್ಣವಾಗಿ ಡಿಲೊಕೇಟ್ ಆಗುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// ಕೊಟ್ಟಿರುವ ಮೊತ್ತವು ಪ್ರಸ್ತುತ ಸಾಮರ್ಥ್ಯಕ್ಕಿಂತ * ದೊಡ್ಡದಾಗಿದ್ದರೆ Panics.
    ///
    /// # Aborts
    ///
    /// OOM ನಲ್ಲಿ ಸ್ಥಗಿತಗೊಳ್ಳುತ್ತದೆ.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// ಅಗತ್ಯವಿರುವ ಹೆಚ್ಚುವರಿ ಸಾಮರ್ಥ್ಯವನ್ನು ಪೂರೈಸಲು ಬಫರ್ ಬೆಳೆಯಬೇಕಾದರೆ ಹಿಂತಿರುಗುತ್ತದೆ.
    /// `grow` ಅನ್ನು ಇನ್ಲೈನ್ ಮಾಡದೆಯೇ ಇನ್ಲೈನ್ ರಿಸರ್ವ್-ಕರೆಗಳನ್ನು ಸಾಧ್ಯವಾಗಿಸಲು ಮುಖ್ಯವಾಗಿ ಬಳಸಲಾಗುತ್ತದೆ.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // ಈ ವಿಧಾನವನ್ನು ಸಾಮಾನ್ಯವಾಗಿ ಅನೇಕ ಬಾರಿ ತ್ವರಿತಗೊಳಿಸಲಾಗುತ್ತದೆ.ಆದ್ದರಿಂದ ಕಂಪೈಲ್ ಸಮಯವನ್ನು ಸುಧಾರಿಸಲು ಇದು ಸಾಧ್ಯವಾದಷ್ಟು ಚಿಕ್ಕದಾಗಿರಬೇಕು ಎಂದು ನಾವು ಬಯಸುತ್ತೇವೆ.
    // ಆದರೆ ರಚಿತವಾದ ಕೋಡ್ ವೇಗವಾಗಿ ಚಲಿಸುವಂತೆ ಮಾಡಲು, ಅದರ ಹೆಚ್ಚಿನ ವಿಷಯಗಳನ್ನು ಸಾಧ್ಯವಾದಷ್ಟು ಸ್ಥಿರವಾಗಿ ಲೆಕ್ಕಹಾಕಬೇಕೆಂದು ನಾವು ಬಯಸುತ್ತೇವೆ.
    // ಆದ್ದರಿಂದ, ಈ ವಿಧಾನವನ್ನು ಎಚ್ಚರಿಕೆಯಿಂದ ಬರೆಯಲಾಗಿದೆ ಆದ್ದರಿಂದ `T` ಅನ್ನು ಅವಲಂಬಿಸಿರುವ ಎಲ್ಲಾ ಕೋಡ್‌ಗಳು ಅದರೊಳಗೆ ಇರುತ್ತವೆ, ಆದರೆ `T` ಅನ್ನು ಸಾಧ್ಯವಾದಷ್ಟು ಅವಲಂಬಿಸದ ಕೋಡ್‌ನ ಹೆಚ್ಚಿನವು `T` ಗಿಂತ ಸಾಮಾನ್ಯವಲ್ಲದ ಕಾರ್ಯಗಳಲ್ಲಿವೆ.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // ಕರೆ ಮಾಡುವ ಸಂದರ್ಭಗಳಿಂದ ಇದನ್ನು ಖಚಿತಪಡಿಸಲಾಗುತ್ತದೆ.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // `elem_size` ಇದ್ದಾಗ ನಾವು `usize::MAX` ಸಾಮರ್ಥ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತೇವೆ
            // 0, ಇಲ್ಲಿಗೆ ಹೋಗುವುದು ಎಂದರೆ `RawVec` ಓವರ್‌ಫುಲ್ ಆಗಿದೆ.
            return Err(CapacityOverflow);
        }

        // ದುಃಖಕರವೆಂದರೆ, ಈ ತಪಾಸಣೆಗಳ ಬಗ್ಗೆ ನಾವು ನಿಜವಾಗಿಯೂ ಏನೂ ಮಾಡಲಾಗುವುದಿಲ್ಲ.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // ಇದು ಘಾತೀಯ ಬೆಳವಣಿಗೆಯನ್ನು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
        // `cap <= isize::MAX` ಮತ್ತು `cap` ಪ್ರಕಾರವು `usize` ಆಗಿರುವುದರಿಂದ ದ್ವಿಗುಣಗೊಳಿಸುವಿಕೆಯು ಉಕ್ಕಿ ಹರಿಯಲು ಸಾಧ್ಯವಿಲ್ಲ.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` ಗಿಂತ ಸಾಮಾನ್ಯವಲ್ಲ.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // ಈ ವಿಧಾನದ ಮೇಲಿನ ನಿರ್ಬಂಧಗಳು `grow_amortized` ನಲ್ಲಿರುವಂತೆಯೇ ಇರುತ್ತವೆ, ಆದರೆ ಈ ವಿಧಾನವನ್ನು ಸಾಮಾನ್ಯವಾಗಿ ಕಡಿಮೆ ಬಾರಿ ತ್ವರಿತಗೊಳಿಸಲಾಗುತ್ತದೆ ಆದ್ದರಿಂದ ಇದು ಕಡಿಮೆ ವಿಮರ್ಶಾತ್ಮಕವಾಗಿರುತ್ತದೆ.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // ಪ್ರಕಾರದ ಗಾತ್ರ ಇದ್ದಾಗ ನಾವು `usize::MAX` ಸಾಮರ್ಥ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತೇವೆ
            // 0, ಇಲ್ಲಿಗೆ ಹೋಗುವುದು ಎಂದರೆ `RawVec` ಓವರ್‌ಫುಲ್ ಆಗಿದೆ.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` ಗಿಂತ ಸಾಮಾನ್ಯವಲ್ಲ.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// ಕಂಪೈಲ್ ಸಮಯವನ್ನು ಕಡಿಮೆ ಮಾಡಲು ಈ ಕಾರ್ಯವು `RawVec` ಹೊರಗೆ ಇದೆ.ವಿವರಗಳಿಗಾಗಿ `RawVec::grow_amortized` ಮೇಲಿನ ಕಾಮೆಂಟ್ ನೋಡಿ.
// (`A` ನಿಯತಾಂಕವು ಮಹತ್ವದ್ದಾಗಿಲ್ಲ, ಏಕೆಂದರೆ ಆಚರಣೆಯಲ್ಲಿ ಕಂಡುಬರುವ ವಿಭಿನ್ನ `A` ಪ್ರಕಾರಗಳ ಸಂಖ್ಯೆ `T` ಪ್ರಕಾರಗಳ ಸಂಖ್ಯೆಗಿಂತ ಚಿಕ್ಕದಾಗಿದೆ.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // `RawVec::grow_*` ಗಾತ್ರವನ್ನು ಕಡಿಮೆ ಮಾಡಲು ಇಲ್ಲಿ ದೋಷವನ್ನು ಪರಿಶೀಲಿಸಿ.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // ಜೋಡಣೆ ಸಮಾನತೆಗಾಗಿ ಹಂಚಿಕೆದಾರರು ಪರಿಶೀಲಿಸುತ್ತಾರೆ
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// `RawVec`*ಒಡೆತನದ ಮೆಮೊರಿಯನ್ನು* ಅದರ ವಿಷಯಗಳನ್ನು ಬಿಡಲು ಪ್ರಯತ್ನಿಸದೆ ಮುಕ್ತಗೊಳಿಸುತ್ತದೆ.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// ಮೀಸಲು ದೋಷ ನಿರ್ವಹಣೆಗಾಗಿ ಕೇಂದ್ರ ಕಾರ್ಯ.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// ನಾವು ಈ ಕೆಳಗಿನವುಗಳನ್ನು ಖಾತರಿಪಡಿಸಬೇಕು:
// * ನಾವು ಎಂದಿಗೂ `> isize::MAX` ಬೈಟ್ ಗಾತ್ರದ ವಸ್ತುಗಳನ್ನು ನಿಯೋಜಿಸುವುದಿಲ್ಲ.
// * ನಾವು `usize::MAX` ಅನ್ನು ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ ಮತ್ತು ವಾಸ್ತವವಾಗಿ ತುಂಬಾ ಕಡಿಮೆ ಹಂಚಿಕೆ ಮಾಡುತ್ತೇವೆ.
//
// 6400-ಬಿಟ್‌ನಲ್ಲಿ ನಾವು ಓವರ್‌ಫ್ಲೋಗಾಗಿ ಪರಿಶೀಲಿಸಬೇಕಾಗಿರುವುದರಿಂದ `> isize::MAX` ಬೈಟ್‌ಗಳನ್ನು ನಿಯೋಜಿಸಲು ಪ್ರಯತ್ನಿಸುವುದರಿಂದ ಖಂಡಿತವಾಗಿಯೂ ವಿಫಲಗೊಳ್ಳುತ್ತದೆ.
// 32-ಬಿಟ್ ಮತ್ತು 16-ಬಿಟ್‌ಗಳಲ್ಲಿ ನಾವು ಪ್ಲಾಟ್‌ಫಾರ್ಮ್‌ನಲ್ಲಿ ಚಾಲನೆಯಲ್ಲಿರುವಾಗ ಇದಕ್ಕಾಗಿ ಹೆಚ್ಚುವರಿ ಗಾರ್ಡ್ ಅನ್ನು ಸೇರಿಸಬೇಕಾಗಿದೆ, ಅದು ಎಲ್ಲಾ 4 ಜಿಬಿಯನ್ನು ಬಳಕೆದಾರ-ಜಾಗದಲ್ಲಿ ಬಳಸಬಹುದು, ಉದಾ, ಪಿಎಇ ಅಥವಾ ಎಕ್ಸ್‌00 ಎಕ್ಸ್.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// ಸಾಮರ್ಥ್ಯದ ಉಕ್ಕಿ ಹರಿಯುವುದನ್ನು ವರದಿ ಮಾಡುವ ಒಂದು ಕೇಂದ್ರ ಕಾರ್ಯ.
// ಮಾಡ್ಯೂಲ್ನಾದ್ಯಂತ ಒಂದು ಗುಂಪಿನ ಬದಲು panics ಇರುವ ಒಂದೇ ಒಂದು ಸ್ಥಳ ಇರುವುದರಿಂದ ಈ panics ಗೆ ಸಂಬಂಧಿಸಿದ ಕೋಡ್ ಉತ್ಪಾದನೆಯು ಕನಿಷ್ಠವಾಗಿದೆ ಎಂದು ಇದು ಖಚಿತಪಡಿಸುತ್ತದೆ.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}