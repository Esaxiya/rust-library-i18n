//! ರಾಶಿ ಹಂಚಿಕೆಗಾಗಿ ಪಾಯಿಂಟರ್ ಪ್ರಕಾರ.
//!
//! [`Box<T>`], ಆಕಸ್ಮಿಕವಾಗಿ 'box' ಎಂದು ಕರೆಯಲಾಗುತ್ತದೆ, Rust ನಲ್ಲಿ ರಾಶಿ ಹಂಚಿಕೆಯ ಸರಳ ರೂಪವನ್ನು ಒದಗಿಸುತ್ತದೆ.ಪೆಟ್ಟಿಗೆಗಳು ಈ ಹಂಚಿಕೆಗಾಗಿ ಮಾಲೀಕತ್ವವನ್ನು ಒದಗಿಸುತ್ತವೆ, ಮತ್ತು ಅವುಗಳು ವ್ಯಾಪ್ತಿಯಿಂದ ಹೊರಬಂದಾಗ ಅವುಗಳ ವಿಷಯಗಳನ್ನು ಬಿಡಿ.ಪೆಟ್ಟಿಗೆಗಳು ಎಂದಿಗೂ `isize::MAX` ಬೈಟ್‌ಗಳಿಗಿಂತ ಹೆಚ್ಚಿನದನ್ನು ನಿಯೋಜಿಸುವುದಿಲ್ಲ ಎಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ.
//!
//! # Examples
//!
//! [`Box`] ಅನ್ನು ರಚಿಸುವ ಮೂಲಕ ಮೌಲ್ಯವನ್ನು ಸ್ಟ್ಯಾಕ್‌ನಿಂದ ರಾಶಿಗೆ ಸರಿಸಿ:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! [dereferencing] ನಿಂದ [`Box`] ನಿಂದ ಮೌಲ್ಯವನ್ನು ಸ್ಟ್ಯಾಕ್‌ಗೆ ಸರಿಸಿ:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! ಪುನರಾವರ್ತಿತ ಡೇಟಾ ರಚನೆಯನ್ನು ರಚಿಸುವುದು:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! ಇದು `Cons (1, Cons(2, Nil))`.
//!
//! ಪುನರಾವರ್ತಿತ ರಚನೆಗಳನ್ನು ಪೆಟ್ಟಿಗೆಯಾಗಿರಬೇಕು, ಏಕೆಂದರೆ `Cons` ನ ವ್ಯಾಖ್ಯಾನವು ಈ ರೀತಿ ಕಾಣುತ್ತಿದ್ದರೆ:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! ಇದು ಕೆಲಸ ಮಾಡುವುದಿಲ್ಲ.ಏಕೆಂದರೆ `List` ನ ಗಾತ್ರವು ಪಟ್ಟಿಯಲ್ಲಿ ಎಷ್ಟು ಅಂಶಗಳಿವೆ ಎಂಬುದರ ಮೇಲೆ ಅವಲಂಬಿತವಾಗಿರುತ್ತದೆ ಮತ್ತು ಆದ್ದರಿಂದ `Cons` ಗೆ ಎಷ್ಟು ಮೆಮೊರಿಯನ್ನು ನಿಯೋಜಿಸಬೇಕು ಎಂದು ನಮಗೆ ತಿಳಿದಿಲ್ಲ.ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ಗಾತ್ರವನ್ನು ಹೊಂದಿರುವ [`Box<T>`] ಅನ್ನು ಪರಿಚಯಿಸುವ ಮೂಲಕ, `Cons` ಎಷ್ಟು ದೊಡ್ಡದಾಗಿರಬೇಕು ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ.
//!
//! # ಮೆಮೊರಿ ವಿನ್ಯಾಸ
//!
//! ಶೂನ್ಯ-ಅಲ್ಲದ ಗಾತ್ರದ ಮೌಲ್ಯಗಳಿಗಾಗಿ, [`Box`] ಅದರ ಹಂಚಿಕೆಗಾಗಿ [`Global`] ಹಂಚಿಕೆಯನ್ನು ಬಳಸುತ್ತದೆ.[`Box`] ಮತ್ತು [`Global`] ಹಂಚಿಕೆಯೊಂದಿಗೆ ಹಂಚಿಕೆಯಾದ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ನಡುವೆ ಎರಡೂ ಮಾರ್ಗಗಳನ್ನು ಪರಿವರ್ತಿಸುವುದು ಮಾನ್ಯವಾಗಿದೆ, ಏಕೆಂದರೆ ಹಂಚಿಕೆಯೊಂದಿಗೆ ಬಳಸಲಾದ [`Layout`] ಪ್ರಕಾರಕ್ಕೆ ಸರಿಯಾಗಿರುತ್ತದೆ.
//!
//! ಹೆಚ್ಚು ನಿಖರವಾಗಿ, `Layout::for_value(&*value)` ನೊಂದಿಗೆ [`Global`] ಹಂಚಿಕೆಯೊಂದಿಗೆ ಹಂಚಿಕೆಯಾದ `value:* mut T` ಅನ್ನು [`Box::<T>::from_raw(value)`] ಬಳಸಿ ಪೆಟ್ಟಿಗೆಯಾಗಿ ಪರಿವರ್ತಿಸಬಹುದು.
//! ಇದಕ್ಕೆ ವ್ಯತಿರಿಕ್ತವಾಗಿ, [`Box::<T>::into_raw`] ನಿಂದ ಪಡೆದ `value:*mut T` ಅನ್ನು ಬೆಂಬಲಿಸುವ ಮೆಮೊರಿಯನ್ನು [`Layout::for_value(&* value)`] ನೊಂದಿಗೆ [`Global`] ಹಂಚಿಕೆಯನ್ನು ಬಳಸಿಕೊಂಡು ಡಿಲೊಲೊಕೇಟ್ ಮಾಡಬಹುದು.
//!
//! ಶೂನ್ಯ-ಗಾತ್ರದ ಮೌಲ್ಯಗಳಿಗಾಗಿ, ಓದಲು ಮತ್ತು ಬರೆಯಲು `Box` ಪಾಯಿಂಟರ್ ಇನ್ನೂ [valid] ಆಗಿರಬೇಕು ಮತ್ತು ಸಾಕಷ್ಟು ಹೊಂದಿಸಲಾಗಿದೆ.
//! ನಿರ್ದಿಷ್ಟವಾಗಿ ಹೇಳುವುದಾದರೆ, ಯಾವುದೇ ಜೋಡಿಸಲಾದ ಶೂನ್ಯೇತರ ಪೂರ್ಣಾಂಕವನ್ನು ಅಕ್ಷರಶಃ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ಗೆ ಬಿತ್ತರಿಸುವುದು ಮಾನ್ಯ ಪಾಯಿಂಟರ್ ಅನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ, ಆದರೆ ಈ ಹಿಂದೆ ನಿಯೋಜಿಸಲಾದ ಮೆಮೊರಿಗೆ ಸೂಚಿಸುವ ಪಾಯಿಂಟರ್ ಮುಕ್ತವಾದಾಗಿನಿಂದ ಮಾನ್ಯವಾಗಿಲ್ಲ.
//! `Box::new` ಅನ್ನು ಬಳಸಲಾಗದಿದ್ದರೆ ZST ಗೆ ಬಾಕ್ಸ್ ನಿರ್ಮಿಸಲು ಶಿಫಾರಸು ಮಾಡಲಾದ ಮಾರ್ಗವೆಂದರೆ [`ptr::NonNull::dangling`] ಅನ್ನು ಬಳಸುವುದು.
//!
//! `T: Sized` ಇರುವವರೆಗೂ, `Box<T>` ಅನ್ನು ಒಂದೇ ಪಾಯಿಂಟರ್‌ನಂತೆ ಪ್ರತಿನಿಧಿಸುವ ಭರವಸೆ ಇದೆ ಮತ್ತು ಇದು ಸಿ ಪಾಯಿಂಟರ್‌ಗಳೊಂದಿಗೆ ಎಬಿಐ-ಹೊಂದಿಕೊಳ್ಳುತ್ತದೆ (ಅಂದರೆ ಸಿ ಟೈಪ್ ಎಕ್ಸ್‌02 ಎಕ್ಸ್).
//! ಇದರರ್ಥ ನೀವು C ನಿಂದ ಕರೆಯಲ್ಪಡುವ ಬಾಹ್ಯ "C" Rust ಕಾರ್ಯಗಳನ್ನು ಹೊಂದಿದ್ದರೆ, ನೀವು `Box<T>` ಪ್ರಕಾರಗಳನ್ನು ಬಳಸಿಕೊಂಡು ಆ Rust ಕಾರ್ಯಗಳನ್ನು ವ್ಯಾಖ್ಯಾನಿಸಬಹುದು, ಮತ್ತು `T*` ಅನ್ನು C ಬದಿಯಲ್ಲಿ ಅನುಗುಣವಾದ ಪ್ರಕಾರವಾಗಿ ಬಳಸಬಹುದು.
//! ಉದಾಹರಣೆಯಾಗಿ, ಕೆಲವು ರೀತಿಯ `Foo` ಮೌಲ್ಯವನ್ನು ರಚಿಸುವ ಮತ್ತು ನಾಶಪಡಿಸುವ ಕಾರ್ಯಗಳನ್ನು ಘೋಷಿಸುವ ಈ ಸಿ ಹೆಡರ್ ಅನ್ನು ಪರಿಗಣಿಸಿ:
//!
//! ```c
//! /* ಸಿ ಹೆಡರ್ */
//!
//! /* ಕರೆ ಮಾಡಿದವರಿಗೆ ಮಾಲೀಕತ್ವವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ */
//! struct Foo* foo_new(void);
//!
//! /* ಕರೆ ಮಾಡುವವರಿಂದ ಮಾಲೀಕತ್ವವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ;NULL ನೊಂದಿಗೆ ಆಹ್ವಾನಿಸಿದಾಗ ನೋ-ಆಪ್ */
//! void foo_delete(struct Foo*);
//! ```
//!
//! ಈ ಎರಡು ಕಾರ್ಯಗಳನ್ನು ಈ ಕೆಳಗಿನಂತೆ Rust ನಲ್ಲಿ ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು.ಇಲ್ಲಿ, C ಯಿಂದ `struct Foo*` ಪ್ರಕಾರವನ್ನು `Box<Foo>` ಗೆ ಅನುವಾದಿಸಲಾಗುತ್ತದೆ, ಇದು ಮಾಲೀಕತ್ವದ ನಿರ್ಬಂಧಗಳನ್ನು ಸೆರೆಹಿಡಿಯುತ್ತದೆ.
//! `foo_delete` ಗೆ ಶೂನ್ಯ ವಾದವನ್ನು Rust ನಲ್ಲಿ `Option<Box<Foo>>` ಎಂದು ನಿರೂಪಿಸಲಾಗಿದೆ, ಏಕೆಂದರೆ `Box<Foo>` ಶೂನ್ಯವಾಗಿರಲು ಸಾಧ್ಯವಿಲ್ಲ.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! `Box<T>` ಒಂದೇ ಪ್ರಾತಿನಿಧ್ಯವನ್ನು ಹೊಂದಿದ್ದರೂ ಮತ್ತು ಸಿ ಎಬಿಐ ಅನ್ನು ಸಿ ಪಾಯಿಂಟರ್‌ನಂತೆ ಹೊಂದಿದ್ದರೂ ಸಹ, ನೀವು ಅನಿಯಂತ್ರಿತ `T*` ಅನ್ನು `Box<T>` ಆಗಿ ಪರಿವರ್ತಿಸಬಹುದು ಮತ್ತು ಕೆಲಸಗಳು ನಿರೀಕ್ಷಿಸಬಹುದು ಎಂದು ಇದರ ಅರ್ಥವಲ್ಲ.
//! `Box<T>` ಮೌಲ್ಯಗಳನ್ನು ಯಾವಾಗಲೂ ಸಂಪೂರ್ಣವಾಗಿ ಜೋಡಿಸಲಾಗುತ್ತದೆ, ಶೂನ್ಯವಲ್ಲದ ಪಾಯಿಂಟರ್‌ಗಳು.ಇದಲ್ಲದೆ, `Box<T>` ಗಾಗಿ ಡಿಸ್ಟ್ರಕ್ಟರ್ ಜಾಗತಿಕ ಹಂಚಿಕೆಯೊಂದಿಗೆ ಮೌಲ್ಯವನ್ನು ಮುಕ್ತಗೊಳಿಸಲು ಪ್ರಯತ್ನಿಸುತ್ತದೆ.ಸಾಮಾನ್ಯವಾಗಿ, ಜಾಗತಿಕ ಹಂಚಿಕೆಯಿಂದ ಹುಟ್ಟಿದ ಪಾಯಿಂಟರ್‌ಗಳಿಗೆ ಮಾತ್ರ `Box<T>` ಅನ್ನು ಬಳಸುವುದು ಉತ್ತಮ ಅಭ್ಯಾಸ.
//!
//! **ಪ್ರಮುಖ.** ಪ್ರಸ್ತುತ, ಸಿ ಯಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ಆದರೆ Rust ನಿಂದ ಆಹ್ವಾನಿಸಲಾದ ಕಾರ್ಯಗಳಿಗಾಗಿ ನೀವು `Box<T>` ಪ್ರಕಾರಗಳನ್ನು ಬಳಸುವುದನ್ನು ತಪ್ಪಿಸಬೇಕು.ಅಂತಹ ಸಂದರ್ಭಗಳಲ್ಲಿ, ನೀವು ನೇರವಾಗಿ ಸಿ ಪ್ರಕಾರಗಳನ್ನು ಸಾಧ್ಯವಾದಷ್ಟು ಹತ್ತಿರ ಪ್ರತಿಬಿಂಬಿಸಬೇಕು.
//! ಸಿ ವ್ಯಾಖ್ಯಾನವು ಕೇವಲ `T*` ಅನ್ನು ಬಳಸುತ್ತಿರುವ `Box<T>` ನಂತಹ ಪ್ರಕಾರಗಳನ್ನು ಬಳಸುವುದರಿಂದ [rust-lang/unsafe-code-guidelines#198][ucg#198] ನಲ್ಲಿ ವಿವರಿಸಿದಂತೆ ವಿವರಿಸಲಾಗದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗಬಹುದು.
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// ರಾಶಿ ಹಂಚಿಕೆಗಾಗಿ ಪಾಯಿಂಟರ್ ಪ್ರಕಾರ.
///
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ [module-level documentation](../../std/boxed/index.html) ನೋಡಿ.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// ರಾಶಿಯಲ್ಲಿ ಮೆಮೊರಿಯನ್ನು ನಿಯೋಜಿಸುತ್ತದೆ ಮತ್ತು ನಂತರ `x` ಅನ್ನು ಇರಿಸುತ್ತದೆ.
    ///
    /// `T` ಶೂನ್ಯ ಗಾತ್ರದ್ದಾಗಿದ್ದರೆ ಇದು ನಿಜವಾಗಿ ಹಂಚುವುದಿಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// ಪ್ರಾರಂಭಿಸದ ವಿಷಯಗಳೊಂದಿಗೆ ಹೊಸ ಪೆಟ್ಟಿಗೆಯನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ಮುಂದೂಡಲ್ಪಟ್ಟ ಪ್ರಾರಂಭ:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// ಮೆಮೊರಿಯನ್ನು `0` ಬೈಟ್‌ಗಳಿಂದ ತುಂಬಿಸುವುದರೊಂದಿಗೆ, ಪ್ರಾರಂಭಿಸದ ವಿಷಯಗಳೊಂದಿಗೆ ಹೊಸ `Box` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    ///
    ///
    /// ಈ ವಿಧಾನದ ಸರಿಯಾದ ಮತ್ತು ತಪ್ಪಾದ ಬಳಕೆಯ ಉದಾಹರಣೆಗಳಿಗಾಗಿ [`MaybeUninit::zeroed`][zeroed] ನೋಡಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// ಹೊಸ `Pin<Box<T>>` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    /// `T` `Unpin` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸದಿದ್ದರೆ, `x` ಅನ್ನು ಮೆಮೊರಿಯಲ್ಲಿ ಪಿನ್ ಮಾಡಲಾಗುತ್ತದೆ ಮತ್ತು ಸರಿಸಲು ಸಾಧ್ಯವಾಗುವುದಿಲ್ಲ.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// ರಾಶಿಯಲ್ಲಿ ಮೆಮೊರಿಯನ್ನು ನಿಯೋಜಿಸುತ್ತದೆ ಮತ್ತು ನಂತರ `x` ಅನ್ನು ಅದರಲ್ಲಿ ಇರಿಸುತ್ತದೆ, ಹಂಚಿಕೆ ವಿಫಲವಾದರೆ ದೋಷವನ್ನು ನೀಡುತ್ತದೆ
    ///
    ///
    /// `T` ಶೂನ್ಯ ಗಾತ್ರದ್ದಾಗಿದ್ದರೆ ಇದು ನಿಜವಾಗಿ ಹಂಚುವುದಿಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// ರಾಶಿಯಲ್ಲಿ ಪ್ರಾರಂಭಿಸದ ವಿಷಯಗಳೊಂದಿಗೆ ಹೊಸ ಪೆಟ್ಟಿಗೆಯನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ, ಹಂಚಿಕೆ ವಿಫಲವಾದರೆ ದೋಷವನ್ನು ನೀಡುತ್ತದೆ
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // ಮುಂದೂಡಲ್ಪಟ್ಟ ಪ್ರಾರಂಭ:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// ಪ್ರಾರಂಭವಿಲ್ಲದ ವಿಷಯಗಳೊಂದಿಗೆ ಹೊಸ `Box` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ, ಮೆಮೊರಿಯನ್ನು ರಾಶಿಯಲ್ಲಿ `0` ಬೈಟ್‌ಗಳಿಂದ ತುಂಬಿಸಲಾಗುತ್ತದೆ
    ///
    ///
    /// ಈ ವಿಧಾನದ ಸರಿಯಾದ ಮತ್ತು ತಪ್ಪಾದ ಬಳಕೆಯ ಉದಾಹರಣೆಗಳಿಗಾಗಿ [`MaybeUninit::zeroed`][zeroed] ನೋಡಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// ಕೊಟ್ಟಿರುವ ಹಂಚಿಕೆಯಲ್ಲಿ ಮೆಮೊರಿಯನ್ನು ನಿಯೋಜಿಸುತ್ತದೆ ಮತ್ತು ನಂತರ ಅದರಲ್ಲಿ `x` ಅನ್ನು ಇರಿಸುತ್ತದೆ.
    ///
    /// `T` ಶೂನ್ಯ ಗಾತ್ರದ್ದಾಗಿದ್ದರೆ ಇದು ನಿಜವಾಗಿ ಹಂಚುವುದಿಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// ಕೊಟ್ಟಿರುವ ಹಂಚಿಕೆಯಲ್ಲಿ ಮೆಮೊರಿಯನ್ನು ನಿಯೋಜಿಸುತ್ತದೆ ಮತ್ತು ನಂತರ ಅದರಲ್ಲಿ `x` ಅನ್ನು ಇರಿಸುತ್ತದೆ, ಹಂಚಿಕೆ ವಿಫಲವಾದರೆ ದೋಷವನ್ನು ನೀಡುತ್ತದೆ
    ///
    ///
    /// `T` ಶೂನ್ಯ ಗಾತ್ರದ್ದಾಗಿದ್ದರೆ ಇದು ನಿಜವಾಗಿ ಹಂಚುವುದಿಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// ಒದಗಿಸಿದ ಹಂಚಿಕೆಯಲ್ಲಿ ಪ್ರಾರಂಭಿಸದ ವಿಷಯಗಳೊಂದಿಗೆ ಹೊಸ ಪೆಟ್ಟಿಗೆಯನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // ಮುಂದೂಡಲ್ಪಟ್ಟ ಪ್ರಾರಂಭ:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: ಮುಚ್ಚುವಿಕೆಯು ಕೆಲವೊಮ್ಮೆ ಇನ್ಲೈನ್ ಮಾಡಲಾಗದ ಕಾರಣ ಅನ್ರ್ಯಾಪ್_ಅರ್_ಇಲ್ಲಕ್ಕಿಂತ ಪಂದ್ಯವನ್ನು ಆದ್ಯತೆ ನೀಡಿ.
        // ಅದು ಕೋಡ್ ಗಾತ್ರವನ್ನು ದೊಡ್ಡದಾಗಿಸುತ್ತದೆ.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// ಒದಗಿಸಿದ ಹಂಚಿಕೆಯಲ್ಲಿ ಪ್ರಾರಂಭಿಸದ ವಿಷಯಗಳೊಂದಿಗೆ ಹೊಸ ಪೆಟ್ಟಿಗೆಯನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ, ಹಂಚಿಕೆ ವಿಫಲವಾದರೆ ದೋಷವನ್ನು ನೀಡುತ್ತದೆ
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // ಮುಂದೂಡಲ್ಪಟ್ಟ ಪ್ರಾರಂಭ:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// ಪ್ರಾರಂಭಿಸದ ವಿಷಯಗಳೊಂದಿಗೆ ಹೊಸ `Box` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ, ಒದಗಿಸಿದ ಹಂಚಿಕೆಯಲ್ಲಿ ಮೆಮೊರಿಯನ್ನು `0` ಬೈಟ್‌ಗಳಿಂದ ತುಂಬಿಸಲಾಗುತ್ತದೆ.
    ///
    ///
    /// ಈ ವಿಧಾನದ ಸರಿಯಾದ ಮತ್ತು ತಪ್ಪಾದ ಬಳಕೆಯ ಉದಾಹರಣೆಗಳಿಗಾಗಿ [`MaybeUninit::zeroed`][zeroed] ನೋಡಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: ಮುಚ್ಚುವಿಕೆಯು ಕೆಲವೊಮ್ಮೆ ಇನ್ಲೈನ್ ಮಾಡಲಾಗದ ಕಾರಣ ಅನ್ರ್ಯಾಪ್_ಅರ್_ಇಲ್ಲಕ್ಕಿಂತ ಪಂದ್ಯವನ್ನು ಆದ್ಯತೆ ನೀಡಿ.
        // ಅದು ಕೋಡ್ ಗಾತ್ರವನ್ನು ದೊಡ್ಡದಾಗಿಸುತ್ತದೆ.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// ಪ್ರಾರಂಭಿಸದ ವಿಷಯಗಳೊಂದಿಗೆ ಹೊಸ `Box` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ, ಒದಗಿಸಿದ ಹಂಚಿಕೆಯಲ್ಲಿ ಮೆಮೊರಿಯನ್ನು `0` ಬೈಟ್‌ಗಳಿಂದ ತುಂಬಿಸಲಾಗುತ್ತದೆ, ಹಂಚಿಕೆ ವಿಫಲವಾದರೆ ದೋಷವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ,
    ///
    ///
    /// ಈ ವಿಧಾನದ ಸರಿಯಾದ ಮತ್ತು ತಪ್ಪಾದ ಬಳಕೆಯ ಉದಾಹರಣೆಗಳಿಗಾಗಿ [`MaybeUninit::zeroed`][zeroed] ನೋಡಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// ಹೊಸ `Pin<Box<T, A>>` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    /// `T` `Unpin` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸದಿದ್ದರೆ, `x` ಅನ್ನು ಮೆಮೊರಿಯಲ್ಲಿ ಪಿನ್ ಮಾಡಲಾಗುತ್ತದೆ ಮತ್ತು ಸರಿಸಲು ಸಾಧ್ಯವಾಗುವುದಿಲ್ಲ.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// `Box<T>` ಅನ್ನು `Box<[T]>` ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ
    ///
    /// ಈ ಪರಿವರ್ತನೆಯು ರಾಶಿಯ ಮೇಲೆ ಹಂಚುವುದಿಲ್ಲ ಮತ್ತು ಸ್ಥಳದಲ್ಲಿ ನಡೆಯುತ್ತದೆ.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// `Box` ಅನ್ನು ಬಳಸುತ್ತದೆ, ಸುತ್ತಿದ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// ಪ್ರಾರಂಭಿಸದ ವಿಷಯಗಳೊಂದಿಗೆ ಹೊಸ ಪೆಟ್ಟಿಗೆಯ ಸ್ಲೈಸ್ ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ಮುಂದೂಡಲ್ಪಟ್ಟ ಪ್ರಾರಂಭ:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// ಮೆಮೊರಿಯನ್ನು `0` ಬೈಟ್‌ಗಳಿಂದ ತುಂಬಿಸುವುದರೊಂದಿಗೆ, ಪ್ರಾರಂಭಿಸದ ವಿಷಯಗಳೊಂದಿಗೆ ಹೊಸ ಪೆಟ್ಟಿಗೆಯ ಸ್ಲೈಸ್ ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    ///
    ///
    /// ಈ ವಿಧಾನದ ಸರಿಯಾದ ಮತ್ತು ತಪ್ಪಾದ ಬಳಕೆಯ ಉದಾಹರಣೆಗಳಿಗಾಗಿ [`MaybeUninit::zeroed`][zeroed] ನೋಡಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// ಒದಗಿಸಿದ ಹಂಚಿಕೆಯಲ್ಲಿ ಪ್ರಾರಂಭಿಸದ ವಿಷಯಗಳೊಂದಿಗೆ ಹೊಸ ಪೆಟ್ಟಿಗೆಯ ಸ್ಲೈಸ್ ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // ಮುಂದೂಡಲ್ಪಟ್ಟ ಪ್ರಾರಂಭ:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// ಒದಗಿಸಿದ ಹಂಚಿಕೆಯಲ್ಲಿ ಪ್ರಾರಂಭಿಸದ ವಿಷಯಗಳೊಂದಿಗೆ ಹೊಸ ಪೆಟ್ಟಿಗೆಯ ಸ್ಲೈಸ್ ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ, ಮೆಮೊರಿಯನ್ನು `0` ಬೈಟ್‌ಗಳಿಂದ ತುಂಬಿಸಲಾಗುತ್ತದೆ.
    ///
    ///
    /// ಈ ವಿಧಾನದ ಸರಿಯಾದ ಮತ್ತು ತಪ್ಪಾದ ಬಳಕೆಯ ಉದಾಹರಣೆಗಳಿಗಾಗಿ [`MaybeUninit::zeroed`][zeroed] ನೋಡಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// `Box<T, A>` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] ನಂತೆ, ಮೌಲ್ಯವು ನಿಜವಾಗಿಯೂ ಪ್ರಾರಂಭಿಕ ಸ್ಥಿತಿಯಲ್ಲಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸುವುದು ಕರೆ ಮಾಡುವವರಿಗೆ ಬಿಟ್ಟದ್ದು.
    ///
    /// ವಿಷಯವನ್ನು ಇನ್ನೂ ಸಂಪೂರ್ಣವಾಗಿ ಪ್ರಾರಂಭಿಸದಿದ್ದಾಗ ಇದನ್ನು ಕರೆಯುವುದು ತಕ್ಷಣದ ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // ಮುಂದೂಡಲ್ಪಟ್ಟ ಪ್ರಾರಂಭ:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// `Box<[T], A>` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] ನಂತೆ, ಮೌಲ್ಯಗಳು ನಿಜವಾಗಿಯೂ ಪ್ರಾರಂಭಿಕ ಸ್ಥಿತಿಯಲ್ಲಿವೆ ಎಂದು ಖಾತರಿಪಡಿಸುವುದು ಕರೆ ಮಾಡುವವರಿಗೆ ಬಿಟ್ಟದ್ದು.
    ///
    /// ವಿಷಯವನ್ನು ಇನ್ನೂ ಸಂಪೂರ್ಣವಾಗಿ ಪ್ರಾರಂಭಿಸದಿದ್ದಾಗ ಇದನ್ನು ಕರೆಯುವುದು ತಕ್ಷಣದ ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ಮುಂದೂಡಲ್ಪಟ್ಟ ಪ್ರಾರಂಭ:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ನಿಂದ ಪೆಟ್ಟಿಗೆಯನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    ///
    /// ಈ ಕಾರ್ಯವನ್ನು ಕರೆದ ನಂತರ, ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಪರಿಣಾಮವಾಗಿ ಬರುವ `Box` ನ ಒಡೆತನದಲ್ಲಿದೆ.
    /// ನಿರ್ದಿಷ್ಟವಾಗಿ, `Box` ಡಿಸ್ಟ್ರಕ್ಟರ್ `T` ನ ಡಿಸ್ಟ್ರಕ್ಟರ್ ಅನ್ನು ಕರೆಯುತ್ತದೆ ಮತ್ತು ಹಂಚಿದ ಮೆಮೊರಿಯನ್ನು ಮುಕ್ತಗೊಳಿಸುತ್ತದೆ.
    /// ಇದು ಸುರಕ್ಷಿತವಾಗಿರಲು, `Box` ಬಳಸುವ [memory layout] ಗೆ ಅನುಗುಣವಾಗಿ ಮೆಮೊರಿಯನ್ನು ನಿಯೋಜಿಸಿರಬೇಕು.
    ///
    ///
    /// # Safety
    ///
    /// ಈ ಕಾರ್ಯವು ಅಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ಅನುಚಿತ ಬಳಕೆಯು ಮೆಮೊರಿ ಸಮಸ್ಯೆಗಳಿಗೆ ಕಾರಣವಾಗಬಹುದು.
    /// ಉದಾಹರಣೆಗೆ, ಒಂದೇ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ನಲ್ಲಿ ಕಾರ್ಯವನ್ನು ಎರಡು ಬಾರಿ ಕರೆದರೆ ಡಬಲ್-ಫ್ರೀ ಸಂಭವಿಸಬಹುದು.
    ///
    /// ಸುರಕ್ಷತಾ ಪರಿಸ್ಥಿತಿಗಳನ್ನು [memory layout] ವಿಭಾಗದಲ್ಲಿ ವಿವರಿಸಲಾಗಿದೆ.
    ///
    /// # Examples
    ///
    /// `Box` ಅನ್ನು ಹಿಂದೆ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ಗೆ ಪರಿವರ್ತಿಸಿದ `Box` ಅನ್ನು ಮರುಸೃಷ್ಟಿಸಿ:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// ಜಾಗತಿಕ ಹಂಚಿಕೆಯನ್ನು ಬಳಸಿಕೊಂಡು ಮೊದಲಿನಿಂದ `Box` ಅನ್ನು ಹಸ್ತಚಾಲಿತವಾಗಿ ರಚಿಸಿ:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // `ptr` ನ (uninitialized) ಹಿಂದಿನ ವಿಷಯಗಳನ್ನು ನಾಶಮಾಡುವ ಪ್ರಯತ್ನವನ್ನು ತಪ್ಪಿಸಲು ಸಾಮಾನ್ಯವಾಗಿ .write ಅಗತ್ಯವಿದೆ, ಆದರೂ ಈ ಸರಳ ಉದಾಹರಣೆಗಾಗಿ `*ptr = 5` ಸಹ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತಿತ್ತು.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// ಕೊಟ್ಟಿರುವ ಹಂಚಿಕೆಯಲ್ಲಿ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ನಿಂದ ಪೆಟ್ಟಿಗೆಯನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    ///
    /// ಈ ಕಾರ್ಯವನ್ನು ಕರೆದ ನಂತರ, ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಪರಿಣಾಮವಾಗಿ ಬರುವ `Box` ನ ಒಡೆತನದಲ್ಲಿದೆ.
    /// ನಿರ್ದಿಷ್ಟವಾಗಿ, `Box` ಡಿಸ್ಟ್ರಕ್ಟರ್ `T` ನ ಡಿಸ್ಟ್ರಕ್ಟರ್ ಅನ್ನು ಕರೆಯುತ್ತದೆ ಮತ್ತು ಹಂಚಿದ ಮೆಮೊರಿಯನ್ನು ಮುಕ್ತಗೊಳಿಸುತ್ತದೆ.
    /// ಇದು ಸುರಕ್ಷಿತವಾಗಿರಲು, `Box` ಬಳಸುವ [memory layout] ಗೆ ಅನುಗುಣವಾಗಿ ಮೆಮೊರಿಯನ್ನು ನಿಯೋಜಿಸಿರಬೇಕು.
    ///
    ///
    /// # Safety
    ///
    /// ಈ ಕಾರ್ಯವು ಅಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ಅನುಚಿತ ಬಳಕೆಯು ಮೆಮೊರಿ ಸಮಸ್ಯೆಗಳಿಗೆ ಕಾರಣವಾಗಬಹುದು.
    /// ಉದಾಹರಣೆಗೆ, ಒಂದೇ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ನಲ್ಲಿ ಕಾರ್ಯವನ್ನು ಎರಡು ಬಾರಿ ಕರೆದರೆ ಡಬಲ್-ಫ್ರೀ ಸಂಭವಿಸಬಹುದು.
    ///
    /// # Examples
    ///
    /// `Box` ಅನ್ನು ಹಿಂದೆ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ಗೆ ಪರಿವರ್ತಿಸಿದ `Box` ಅನ್ನು ಮರುಸೃಷ್ಟಿಸಿ:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// ಸಿಸ್ಟಮ್ ಹಂಚಿಕೆಯನ್ನು ಬಳಸಿಕೊಂಡು ಮೊದಲಿನಿಂದ `Box` ಅನ್ನು ಹಸ್ತಚಾಲಿತವಾಗಿ ರಚಿಸಿ:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // `ptr` ನ (uninitialized) ಹಿಂದಿನ ವಿಷಯಗಳನ್ನು ನಾಶಮಾಡುವ ಪ್ರಯತ್ನವನ್ನು ತಪ್ಪಿಸಲು ಸಾಮಾನ್ಯವಾಗಿ .write ಅಗತ್ಯವಿದೆ, ಆದರೂ ಈ ಸರಳ ಉದಾಹರಣೆಗಾಗಿ `*ptr = 5` ಸಹ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತಿತ್ತು.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// `Box` ಅನ್ನು ಬಳಸುತ್ತದೆ, ಸುತ್ತಿದ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಪಾಯಿಂಟರ್ ಅನ್ನು ಸರಿಯಾಗಿ ಜೋಡಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ಶೂನ್ಯವಲ್ಲ.
    ///
    /// ಈ ಕಾರ್ಯವನ್ನು ಕರೆದ ನಂತರ, ಈ ಹಿಂದೆ `Box` ನಿರ್ವಹಿಸುತ್ತಿದ್ದ ಮೆಮೊರಿಗೆ ಕರೆ ಮಾಡುವವರು ಜವಾಬ್ದಾರರಾಗಿರುತ್ತಾರೆ.
    /// ನಿರ್ದಿಷ್ಟವಾಗಿ ಹೇಳುವುದಾದರೆ, ಕರೆ ಮಾಡುವವರು `T` ಅನ್ನು ಸರಿಯಾಗಿ ನಾಶಪಡಿಸಬೇಕು ಮತ್ತು ಮೆಮೊರಿಯನ್ನು ಬಿಡುಗಡೆ ಮಾಡಬೇಕು, `Box` ಬಳಸುವ [memory layout] ಅನ್ನು ಗಣನೆಗೆ ತೆಗೆದುಕೊಳ್ಳಬೇಕು.
    /// ಇದನ್ನು ಮಾಡಲು ಸುಲಭವಾದ ಮಾರ್ಗವೆಂದರೆ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಅನ್ನು [`Box::from_raw`] ಕ್ರಿಯೆಯೊಂದಿಗೆ ಮತ್ತೆ `Box` ಆಗಿ ಪರಿವರ್ತಿಸುವುದು, `Box` ಡಿಸ್ಟ್ರಕ್ಟರ್ ಅನ್ನು ಸ್ವಚ್ clean ಗೊಳಿಸಲು ಅನುವು ಮಾಡಿಕೊಡುತ್ತದೆ.
    ///
    ///
    /// Note: ಇದು ಸಂಬಂಧಿತ ಕಾರ್ಯವಾಗಿದೆ, ಇದರರ್ಥ ನೀವು ಇದನ್ನು `b.into_raw()` ಬದಲಿಗೆ `Box::into_raw(b)` ಎಂದು ಕರೆಯಬೇಕು.
    /// ಆಂತರಿಕ ಪ್ರಕಾರದ ವಿಧಾನದೊಂದಿಗೆ ಯಾವುದೇ ಸಂಘರ್ಷವಿಲ್ಲ ಎಂದು ಇದು.
    ///
    /// # Examples
    /// ಸ್ವಯಂಚಾಲಿತ ಸ್ವಚ್ up ಗೊಳಿಸುವಿಕೆಗಾಗಿ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಅನ್ನು [`Box::from_raw`] ನೊಂದಿಗೆ `Box` ಗೆ ಪರಿವರ್ತಿಸುವುದು:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// ಡಿಸ್ಟ್ರಕ್ಟರ್ ಅನ್ನು ಸ್ಪಷ್ಟವಾಗಿ ಚಲಾಯಿಸುವ ಮೂಲಕ ಮತ್ತು ಮೆಮೊರಿಯನ್ನು ಡಿಲೊಲೊಕೇಟ್ ಮಾಡುವ ಮೂಲಕ ಹಸ್ತಚಾಲಿತ ಸ್ವಚ್ up ಗೊಳಿಸುವಿಕೆ:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// `Box` ಅನ್ನು ಬಳಸುತ್ತದೆ, ಸುತ್ತಿದ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಮತ್ತು ಹಂಚಿಕೆಯನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಪಾಯಿಂಟರ್ ಅನ್ನು ಸರಿಯಾಗಿ ಜೋಡಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ಶೂನ್ಯವಲ್ಲ.
    ///
    /// ಈ ಕಾರ್ಯವನ್ನು ಕರೆದ ನಂತರ, ಈ ಹಿಂದೆ `Box` ನಿರ್ವಹಿಸುತ್ತಿದ್ದ ಮೆಮೊರಿಗೆ ಕರೆ ಮಾಡುವವರು ಜವಾಬ್ದಾರರಾಗಿರುತ್ತಾರೆ.
    /// ನಿರ್ದಿಷ್ಟವಾಗಿ ಹೇಳುವುದಾದರೆ, ಕರೆ ಮಾಡುವವರು `T` ಅನ್ನು ಸರಿಯಾಗಿ ನಾಶಪಡಿಸಬೇಕು ಮತ್ತು ಮೆಮೊರಿಯನ್ನು ಬಿಡುಗಡೆ ಮಾಡಬೇಕು, `Box` ಬಳಸುವ [memory layout] ಅನ್ನು ಗಣನೆಗೆ ತೆಗೆದುಕೊಳ್ಳಬೇಕು.
    /// ಇದನ್ನು ಮಾಡಲು ಸುಲಭವಾದ ಮಾರ್ಗವೆಂದರೆ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಅನ್ನು [`Box::from_raw_in`] ಕ್ರಿಯೆಯೊಂದಿಗೆ ಮತ್ತೆ `Box` ಆಗಿ ಪರಿವರ್ತಿಸುವುದು, `Box` ಡಿಸ್ಟ್ರಕ್ಟರ್ ಅನ್ನು ಸ್ವಚ್ clean ಗೊಳಿಸಲು ಅನುವು ಮಾಡಿಕೊಡುತ್ತದೆ.
    ///
    ///
    /// Note: ಇದು ಸಂಯೋಜಿತ ಕಾರ್ಯವಾಗಿದೆ, ಇದರರ್ಥ ನೀವು ಅದನ್ನು `b.into_raw_with_allocator()` ಬದಲಿಗೆ `Box::into_raw_with_allocator(b)` ಎಂದು ಕರೆಯಬೇಕು.
    /// ಆಂತರಿಕ ಪ್ರಕಾರದ ವಿಧಾನದೊಂದಿಗೆ ಯಾವುದೇ ಸಂಘರ್ಷವಿಲ್ಲ ಎಂದು ಇದು.
    ///
    /// # Examples
    /// ಸ್ವಯಂಚಾಲಿತ ಸ್ವಚ್ up ಗೊಳಿಸುವಿಕೆಗಾಗಿ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಅನ್ನು [`Box::from_raw_in`] ನೊಂದಿಗೆ `Box` ಗೆ ಪರಿವರ್ತಿಸುವುದು:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// ಡಿಸ್ಟ್ರಕ್ಟರ್ ಅನ್ನು ಸ್ಪಷ್ಟವಾಗಿ ಚಲಾಯಿಸುವ ಮೂಲಕ ಮತ್ತು ಮೆಮೊರಿಯನ್ನು ಡಿಲೊಲೊಕೇಟ್ ಮಾಡುವ ಮೂಲಕ ಹಸ್ತಚಾಲಿತ ಸ್ವಚ್ up ಗೊಳಿಸುವಿಕೆ:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // ಬಾಕ್ಸ್ ಅನ್ನು ಸ್ಟ್ಯಾಕ್ಡ್ ಎರವಲುಗಳು "unique pointer" ಎಂದು ಗುರುತಿಸಿವೆ, ಆದರೆ ಆಂತರಿಕವಾಗಿ ಇದು ಟೈಪ್ ಸಿಸ್ಟಮ್‌ಗೆ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಆಗಿದೆ.
        // ಇದನ್ನು ನೇರವಾಗಿ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಆಗಿ ಪರಿವರ್ತಿಸುವುದರಿಂದ ಅಲಿಯಾಸ್ ಕಚ್ಚಾ ಪ್ರವೇಶಗಳನ್ನು ಅನುಮತಿಸುವ ಅನನ್ಯ ಪಾಯಿಂಟರ್ ಅನ್ನು "releasing" ಎಂದು ಗುರುತಿಸಲಾಗುವುದಿಲ್ಲ, ಆದ್ದರಿಂದ ಎಲ್ಲಾ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ವಿಧಾನಗಳು `Box::leak` ಮೂಲಕ ಹೋಗಬೇಕಾಗುತ್ತದೆ.
        //
        // *ಆ* ಅನ್ನು ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ಗೆ ತಿರುಗಿಸುವುದು ಸರಿಯಾಗಿ ವರ್ತಿಸುತ್ತದೆ.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// ಆಧಾರವಾಗಿರುವ ಹಂಚಿಕೆಯ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// Note: ಇದು ಸಂಬಂಧಿತ ಕಾರ್ಯವಾಗಿದೆ, ಇದರರ್ಥ ನೀವು ಇದನ್ನು `b.allocator()` ಬದಲಿಗೆ `Box::allocator(&b)` ಎಂದು ಕರೆಯಬೇಕು.
    /// ಆಂತರಿಕ ಪ್ರಕಾರದ ವಿಧಾನದೊಂದಿಗೆ ಯಾವುದೇ ಸಂಘರ್ಷವಿಲ್ಲ ಎಂದು ಇದು.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// `Box` ಅನ್ನು ಬಳಸುತ್ತದೆ ಮತ್ತು ಸೋರಿಕೆ ಮಾಡುತ್ತದೆ, ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ನೀಡುತ್ತದೆ, `&'a mut T`.
    /// `T` ಪ್ರಕಾರವು ಆಯ್ಕೆಮಾಡಿದ ಜೀವಿತಾವಧಿಯ `'a` ಅನ್ನು ಮೀರಿಸಬೇಕು ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    /// ಪ್ರಕಾರವು ಕೇವಲ ಸ್ಥಿರ ಉಲ್ಲೇಖಗಳನ್ನು ಹೊಂದಿದ್ದರೆ, ಅಥವಾ ಯಾವುದೂ ಇಲ್ಲದಿದ್ದರೆ, ಇದನ್ನು `'static` ಎಂದು ಆಯ್ಕೆ ಮಾಡಬಹುದು.
    ///
    /// ಈ ಕಾರ್ಯವು ಮುಖ್ಯವಾಗಿ ಕಾರ್ಯಕ್ರಮದ ಉಳಿದ ಜೀವಿತಾವಧಿಯಲ್ಲಿ ವಾಸಿಸುವ ಡೇಟಾಗೆ ಉಪಯುಕ್ತವಾಗಿದೆ.
    /// ಹಿಂತಿರುಗಿದ ಉಲ್ಲೇಖವನ್ನು ಬಿಡುವುದರಿಂದ ಮೆಮೊರಿ ಸೋರಿಕೆಯಾಗುತ್ತದೆ.
    /// ಇದು ಸ್ವೀಕಾರಾರ್ಹವಲ್ಲದಿದ್ದರೆ, ಮೊದಲು `Box` ಅನ್ನು ಉತ್ಪಾದಿಸುವ [`Box::from_raw`] ಕಾರ್ಯದೊಂದಿಗೆ ಉಲ್ಲೇಖವನ್ನು ಸುತ್ತಿಡಬೇಕು.
    ///
    /// ಈ `Box` ಅನ್ನು ನಂತರ ಕೈಬಿಡಬಹುದು ಅದು `T` ಅನ್ನು ಸರಿಯಾಗಿ ನಾಶಪಡಿಸುತ್ತದೆ ಮತ್ತು ಹಂಚಿದ ಮೆಮೊರಿಯನ್ನು ಬಿಡುಗಡೆ ಮಾಡುತ್ತದೆ.
    ///
    /// Note: ಇದು ಸಂಬಂಧಿತ ಕಾರ್ಯವಾಗಿದೆ, ಇದರರ್ಥ ನೀವು ಇದನ್ನು `b.leak()` ಬದಲಿಗೆ `Box::leak(b)` ಎಂದು ಕರೆಯಬೇಕು.
    /// ಆಂತರಿಕ ಪ್ರಕಾರದ ವಿಧಾನದೊಂದಿಗೆ ಯಾವುದೇ ಸಂಘರ್ಷವಿಲ್ಲ ಎಂದು ಇದು.
    ///
    /// # Examples
    ///
    /// ಸರಳ ಬಳಕೆ:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// ಗಾತ್ರೀಕರಿಸದ ಡೇಟಾ:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// `Box<T>` ಅನ್ನು `Pin<Box<T>>` ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ
    ///
    /// ಈ ಪರಿವರ್ತನೆಯು ರಾಶಿಯ ಮೇಲೆ ಹಂಚುವುದಿಲ್ಲ ಮತ್ತು ಸ್ಥಳದಲ್ಲಿ ನಡೆಯುತ್ತದೆ.
    ///
    /// ಇದು [`From`] ಮೂಲಕವೂ ಲಭ್ಯವಿದೆ.
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // `T: !Unpin` ಇದ್ದಾಗ `Pin<Box<T>>` ನ ಒಳಹರಿವುಗಳನ್ನು ಸರಿಸಲು ಅಥವಾ ಬದಲಾಯಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ, ಆದ್ದರಿಂದ ಯಾವುದೇ ಹೆಚ್ಚುವರಿ ಅವಶ್ಯಕತೆಗಳಿಲ್ಲದೆ ಅದನ್ನು ನೇರವಾಗಿ ಪಿನ್ ಮಾಡುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: ಏನನ್ನೂ ಮಾಡಬೇಡಿ, ಡ್ರಾಪ್ ಅನ್ನು ಪ್ರಸ್ತುತ ಕಂಪೈಲರ್ ನಿರ್ವಹಿಸುತ್ತದೆ.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// T ಗಾಗಿ `Default` ಮೌಲ್ಯದೊಂದಿಗೆ `Box<T>` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// ಈ ಪೆಟ್ಟಿಗೆಯ ವಿಷಯಗಳ `clone()` ನೊಂದಿಗೆ ಹೊಸ ಪೆಟ್ಟಿಗೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // ಮೌಲ್ಯವು ಒಂದೇ ಆಗಿರುತ್ತದೆ
    /// assert_eq!(x, y);
    ///
    /// // ಆದರೆ ಅವು ವಿಶಿಷ್ಟ ವಸ್ತುಗಳು
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮೌಲ್ಯವನ್ನು ನೇರವಾಗಿ ಬರೆಯಲು ಅನುಮತಿಸಲು ಮೆಮೊರಿಯನ್ನು ಮೊದಲೇ ನಿಯೋಜಿಸಿ.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// ಹೊಸ ಹಂಚಿಕೆಯನ್ನು ರಚಿಸದೆ `ಮೂಲದ` ವಿಷಯಗಳನ್ನು `self` ಗೆ ನಕಲಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // ಮೌಲ್ಯವು ಒಂದೇ ಆಗಿರುತ್ತದೆ
    /// assert_eq!(x, y);
    ///
    /// // ಮತ್ತು ಯಾವುದೇ ಹಂಚಿಕೆ ಸಂಭವಿಸಿಲ್ಲ
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // ಇದು ಡೇಟಾದ ನಕಲನ್ನು ಮಾಡುತ್ತದೆ
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// ಜೆನೆರಿಕ್ ಪ್ರಕಾರದ `T` ಅನ್ನು `Box<T>` ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ
    ///
    /// ಪರಿವರ್ತನೆಯು ರಾಶಿಯ ಮೇಲೆ ಹಂಚುತ್ತದೆ ಮತ್ತು `t` ಅನ್ನು ಸ್ಟಾಕ್‌ನಿಂದ ಚಲಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// `Box<T>` ಅನ್ನು `Pin<Box<T>>` ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ
    ///
    /// ಈ ಪರಿವರ್ತನೆಯು ರಾಶಿಯ ಮೇಲೆ ಹಂಚುವುದಿಲ್ಲ ಮತ್ತು ಸ್ಥಳದಲ್ಲಿ ನಡೆಯುತ್ತದೆ.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// `&[T]` ಅನ್ನು `Box<[T]>` ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ
    ///
    /// ಈ ಪರಿವರ್ತನೆಯು ರಾಶಿಯ ಮೇಲೆ ಹಂಚುತ್ತದೆ ಮತ್ತು `slice` ನ ನಕಲನ್ನು ಮಾಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // ಬಾಕ್ಸ್ <[u8]> ಅನ್ನು ರಚಿಸಲು ಬಳಸಲಾಗುವ&[u8] ಅನ್ನು ರಚಿಸಿ
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// `&str` ಅನ್ನು `Box<str>` ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ
    ///
    /// ಈ ಪರಿವರ್ತನೆಯು ರಾಶಿಯ ಮೇಲೆ ಹಂಚುತ್ತದೆ ಮತ್ತು `s` ನ ನಕಲನ್ನು ಮಾಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// `Box<str>` ಅನ್ನು `Box<[u8]>` ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ
    /// ಈ ಪರಿವರ್ತನೆಯು ರಾಶಿಯ ಮೇಲೆ ಹಂಚುವುದಿಲ್ಲ ಮತ್ತು ಸ್ಥಳದಲ್ಲಿ ನಡೆಯುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // ಬಾಕ್ಸ್ ರಚಿಸಿ<str>ಬಾಕ್ಸ್ <[u8]> ಅನ್ನು ರಚಿಸಲು ಇದನ್ನು ಬಳಸಲಾಗುತ್ತದೆ
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // ಬಾಕ್ಸ್ <[u8]> ಅನ್ನು ರಚಿಸಲು ಬಳಸಲಾಗುವ&[u8] ಅನ್ನು ರಚಿಸಿ
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// `[T; N]` ಅನ್ನು `Box<[T]>` ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ
    /// ಈ ಪರಿವರ್ತನೆಯು ರಚನೆಯನ್ನು ಹೊಸದಾಗಿ ರಾಶಿ-ನಿಯೋಜಿತ ಮೆಮೊರಿಗೆ ಚಲಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// ಪೆಟ್ಟಿಗೆಯನ್ನು ಕಾಂಕ್ರೀಟ್ ಪ್ರಕಾರಕ್ಕೆ ಇಳಿಸುವ ಪ್ರಯತ್ನ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// ಪೆಟ್ಟಿಗೆಯನ್ನು ಕಾಂಕ್ರೀಟ್ ಪ್ರಕಾರಕ್ಕೆ ಇಳಿಸುವ ಪ್ರಯತ್ನ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// ಪೆಟ್ಟಿಗೆಯನ್ನು ಕಾಂಕ್ರೀಟ್ ಪ್ರಕಾರಕ್ಕೆ ಇಳಿಸುವ ಪ್ರಯತ್ನ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // ಒಳಗಿನ ಯುನಿಕ್ ಅನ್ನು ನೇರವಾಗಿ ಪೆಟ್ಟಿಗೆಯಿಂದ ಹೊರತೆಗೆಯಲು ಸಾಧ್ಯವಿಲ್ಲ, ಬದಲಿಗೆ ನಾವು ಅದನ್ನು * ಕಾನ್ಸ್ಟ್‌ಗೆ ಬಿತ್ತರಿಸುತ್ತೇವೆ ಅದು ಅನನ್ಯತೆಯನ್ನು ಅಲಿಯಾಸ್ ಮಾಡುತ್ತದೆ
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// ಡೀಫಾಲ್ಟ್ ಬದಲಿಗೆ `last()` ನ `I` ಅನುಷ್ಠಾನವನ್ನು ಬಳಸುವ ಗಾತ್ರದ`I` ಗಳ ವಿಶೇಷತೆ.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}