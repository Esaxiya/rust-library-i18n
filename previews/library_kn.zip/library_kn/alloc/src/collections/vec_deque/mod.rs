//! ಬೆಳೆಯಬಹುದಾದ ರಿಂಗ್ ಬಫರ್‌ನೊಂದಿಗೆ ಡಬಲ್-ಎಂಡ್ ಕ್ಯೂ ಅಳವಡಿಸಲಾಗಿದೆ.
//!
//! ಈ ಕ್ಯೂ *O*(1) ಭೋಗ್ಯ ಒಳಸೇರಿಸುವಿಕೆಯನ್ನು ಮತ್ತು ಧಾರಕದ ಎರಡೂ ತುದಿಗಳಿಂದ ತೆಗೆದುಹಾಕುವಿಕೆಯನ್ನು ಹೊಂದಿದೆ.
//! ಇದು vector ನಂತಹ *O*(1) ಸೂಚಿಕೆ ಸಹ ಹೊಂದಿದೆ.
//! ಒಳಗೊಂಡಿರುವ ಅಂಶಗಳನ್ನು ನಕಲಿಸಲು ಅಗತ್ಯವಿಲ್ಲ, ಮತ್ತು ಒಳಗೊಂಡಿರುವ ಪ್ರಕಾರವನ್ನು ಕಳುಹಿಸಬಹುದಾದರೆ ಕ್ಯೂ ಕಳುಹಿಸಬಹುದಾಗಿದೆ.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // ಎರಡು ದೊಡ್ಡ ಸಂಭವನೀಯ ಶಕ್ತಿ

/// ಬೆಳೆಯಬಹುದಾದ ರಿಂಗ್ ಬಫರ್‌ನೊಂದಿಗೆ ಡಬಲ್-ಎಂಡ್ ಕ್ಯೂ ಅಳವಡಿಸಲಾಗಿದೆ.
///
/// ಈ ಪ್ರಕಾರದ "default" ಬಳಕೆಯು ಕ್ಯೂಗೆ ಸೇರಿಸಲು [`push_back`] ಮತ್ತು ಕ್ಯೂನಿಂದ ತೆಗೆದುಹಾಕಲು [`pop_front`] ಅನ್ನು ಬಳಸುವುದು.
///
/// [`extend`] ಮತ್ತು [`append`] ಈ ರೀತಿಯಲ್ಲಿ ಹಿಂಭಾಗಕ್ಕೆ ತಳ್ಳುತ್ತದೆ, ಮತ್ತು `VecDeque` ಮೂಲಕ ಪುನರಾವರ್ತಿಸುವುದು ಮುಂಭಾಗದಿಂದ ಹಿಂದಕ್ಕೆ ಹೋಗುತ್ತದೆ.
///
/// `VecDeque` ರಿಂಗ್ ಬಫರ್ ಆಗಿರುವುದರಿಂದ, ಅದರ ಅಂಶಗಳು ಮೆಮೊರಿಯಲ್ಲಿ ಅಗತ್ಯವಾಗಿರುವುದಿಲ್ಲ.
/// ಪರಿಣಾಮಕಾರಿ ವಿಂಗಡಣೆಯಂತಹ ಅಂಶಗಳನ್ನು ಒಂದೇ ಸ್ಲೈಸ್‌ನಂತೆ ಪ್ರವೇಶಿಸಲು ನೀವು ಬಯಸಿದರೆ, ನೀವು [`make_contiguous`] ಅನ್ನು ಬಳಸಬಹುದು.
/// ಇದು `VecDeque` ಅನ್ನು ತಿರುಗಿಸುತ್ತದೆ ಇದರಿಂದ ಅದರ ಅಂಶಗಳು ಸುತ್ತುವರಿಯುವುದಿಲ್ಲ, ಮತ್ತು ರೂಪಾಂತರಿತ ಸ್ಲೈಸ್ ಅನ್ನು ಈಗ-ಸಮೀಪದ ಅಂಶ ಅನುಕ್ರಮಕ್ಕೆ ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // ಬಾಲ ಮತ್ತು ತಲೆ ಬಫರ್‌ಗೆ ಪಾಯಿಂಟರ್‌ಗಳಾಗಿವೆ.
    // ಬಾಲವು ಯಾವಾಗಲೂ ಓದಬಹುದಾದ ಮೊದಲ ಅಂಶವನ್ನು ಸೂಚಿಸುತ್ತದೆ, ಹೆಡ್ ಯಾವಾಗಲೂ ಡೇಟಾವನ್ನು ಎಲ್ಲಿ ಬರೆಯಬೇಕು ಎಂದು ಸೂಚಿಸುತ್ತದೆ.
    //
    // ಬಾಲ==ತಲೆ ಇದ್ದರೆ ಬಫರ್ ಖಾಲಿಯಾಗಿದೆ.ರಿಂಗ್‌ಬಫರ್‌ನ ಉದ್ದವನ್ನು ಎರಡರ ನಡುವಿನ ಅಂತರ ಎಂದು ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿದೆ.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// ಸ್ಲೈಸ್‌ನಲ್ಲಿರುವ ಎಲ್ಲಾ ವಸ್ತುಗಳನ್ನು ಕೈಬಿಟ್ಟಾಗ (ಸಾಮಾನ್ಯವಾಗಿ ಅಥವಾ ಬಿಚ್ಚುವ ಸಮಯದಲ್ಲಿ) ಡಿಸ್ಟ್ರಕ್ಟರ್ ಅನ್ನು ಚಾಲನೆ ಮಾಡುತ್ತದೆ.
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // [T] ಗಾಗಿ ಡ್ರಾಪ್ ಬಳಸಿ
            ptr::drop_in_place(front);
        }
        // ರಾವೆಕ್ ಡಿಲೊಕೇಶನ್ ಅನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// ಖಾಲಿ `VecDeque<T>` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// ಮಾರ್ಜಿನಲಿ ಹೆಚ್ಚು ಅನುಕೂಲಕರ
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// ಮಾರ್ಜಿನಲಿ ಹೆಚ್ಚು ಅನುಕೂಲಕರ
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // ಶೂನ್ಯ ಗಾತ್ರದ ಪ್ರಕಾರಗಳಿಗಾಗಿ, ನಾವು ಯಾವಾಗಲೂ ಗರಿಷ್ಠ ಸಾಮರ್ಥ್ಯದಲ್ಲಿರುತ್ತೇವೆ
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// ಪಿಟಿಆರ್ ಅನ್ನು ಸ್ಲೈಸ್ ಆಗಿ ಪರಿವರ್ತಿಸಿ
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// ಪಿಟಿಆರ್ ಅನ್ನು ಮಟ್ ಸ್ಲೈಸ್ ಆಗಿ ಪರಿವರ್ತಿಸಿ
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// ಒಂದು ಅಂಶವನ್ನು ಬಫರ್‌ನಿಂದ ಹೊರಗೆ ಸರಿಸುತ್ತದೆ
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// ಒಂದು ಅಂಶವನ್ನು ಬಫರ್‌ಗೆ ಬರೆಯುತ್ತದೆ, ಅದನ್ನು ಚಲಿಸುತ್ತದೆ.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// ಬಫರ್ ಪೂರ್ಣ ಸಾಮರ್ಥ್ಯದಲ್ಲಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// ನಿರ್ದಿಷ್ಟ ತಾರ್ಕಿಕ ಅಂಶ ಸೂಚ್ಯಂಕಕ್ಕಾಗಿ ಆಧಾರವಾಗಿರುವ ಬಫರ್‌ನಲ್ಲಿ ಸೂಚ್ಯಂಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// ನಿರ್ದಿಷ್ಟ ತಾರ್ಕಿಕ ಅಂಶ ಸೂಚ್ಯಂಕ + ಸೇರ್ಪಡೆಗಾಗಿ ಆಧಾರವಾಗಿರುವ ಬಫರ್‌ನಲ್ಲಿ ಸೂಚ್ಯಂಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// ನಿರ್ದಿಷ್ಟ ತಾರ್ಕಿಕ ಅಂಶ ಸೂಚ್ಯಂಕ, ಸಬ್‌ಟ್ರಾಹೆಂಡ್‌ಗಾಗಿ ಆಧಾರವಾಗಿರುವ ಬಫರ್‌ನಲ್ಲಿ ಸೂಚಿಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// src ನಿಂದ dst ವರೆಗೆ ಉದ್ದವಾದ ಮೆಮೊರಿ ಲೆನ್ ಅನ್ನು ನಕಲಿಸುತ್ತದೆ
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// src ನಿಂದ dst ವರೆಗೆ ಉದ್ದವಾದ ಮೆಮೊರಿ ಲೆನ್ ಅನ್ನು ನಕಲಿಸುತ್ತದೆ
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// src ನಿಂದ ಡೆಸ್ಟ್‌ಗೆ ಉದ್ದವಾದ ಮೆಮೊರಿ ಲೆನ್‌ನ ಸಂಭಾವ್ಯ ಸುತ್ತುವ ಬ್ಲಾಕ್ ಅನ್ನು ನಕಲಿಸುತ್ತದೆ.
    /// (abs(dst - src) + ಲೆನ್) cap() ಗಿಂತ ದೊಡ್ಡದಾಗಿರಬಾರದು (src ಮತ್ತು dest ನಡುವೆ ನಿರಂತರವಾಗಿ ಒಂದು ಅತಿಕ್ರಮಿಸುವ ಪ್ರದೇಶ ಇರಬೇಕು).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src ಸುತ್ತುವುದಿಲ್ಲ, dst ಸುತ್ತುವುದಿಲ್ಲ
                //
                //        ಎಸ್...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] ಡಿ.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // src ಗೆ ಮೊದಲು, src ಸುತ್ತುವುದಿಲ್ಲ, dst ಸುತ್ತುತ್ತದೆ
                //
                //
                //    ಎಸ್...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 ಎಕ್ಸ್ 00 ಎಕ್ಸ್ .. ಡಿ.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // Dst ಗೆ ಮೊದಲು src, src ಸುತ್ತುವುದಿಲ್ಲ, dst ಹೊದಿಕೆಗಳು
                //
                //
                //              ಎಸ್...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 ಎಕ್ಸ್ 00 ಎಕ್ಸ್ .. ಡಿ.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // src, src ಸುತ್ತುವ ಮೊದಲು dst, dst ಸುತ್ತುವುದಿಲ್ಲ
                //
                //
                //    .. ಎಸ್.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] ಡಿ...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // Dst ಮೊದಲು src, src ಸುತ್ತುತ್ತದೆ, dst ಸುತ್ತುವುದಿಲ್ಲ
                //
                //
                //    .. ಎಸ್.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] ಡಿ...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // d0 ಮೊದಲು src, src ಹೊದಿಕೆಗಳು, dst ಹೊದಿಕೆಗಳು
                //
                //
                //    ... ಎಸ್.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 ಎಕ್ಸ್ 00 ಎಕ್ಸ್ .. ಡಿ..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // Dst ಮೊದಲು src, src ಹೊದಿಕೆಗಳು, dst ಹೊದಿಕೆಗಳು
                //
                //
                //    .. ಎಸ್..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... ಡಿ.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// ನಾವು ಮರುಹಂಚಿಕೆ ಮಾಡಿದ್ದೇವೆ ಎಂಬ ಅಂಶವನ್ನು ನಿಭಾಯಿಸಲು ತಲೆ ಮತ್ತು ಬಾಲ ವಿಭಾಗಗಳನ್ನು ಸುತ್ತಿಕೊಳ್ಳುತ್ತದೆ.
    /// ಅಸುರಕ್ಷಿತ ಏಕೆಂದರೆ ಅದು ಹಳೆಯ_ ಸಾಮರ್ಥ್ಯವನ್ನು ನಂಬುತ್ತದೆ.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // ರಿಂಗ್ ಬಫರ್ TH ನ ಚಿಕ್ಕದಾದ ಸಮೀಪ ವಿಭಾಗವನ್ನು ಸರಿಸಿ
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo......
        //          ] ಎಚ್‌ಟಿ
        //   [o o o o o . o o ]
        //              ಹೆಚ್ಟಿಸಿ ಎಕ್ಸ್ 00 ಎಕ್ಸ್
        //
        //
        //
        //

        if self.tail <= self.head {
            // ಎ ನೋಪ್
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// ಖಾಲಿ `VecDeque` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// ಕನಿಷ್ಠ `capacity` ಅಂಶಗಳಿಗೆ ಸ್ಥಳಾವಕಾಶದೊಂದಿಗೆ ಖಾಲಿ `VecDeque` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // ರಿಂಗ್‌ಬಫರ್ ಯಾವಾಗಲೂ ಒಂದು ಜಾಗವನ್ನು ಖಾಲಿ ಬಿಡುವುದರಿಂದ +1
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// ನಿರ್ದಿಷ್ಟ ಸೂಚ್ಯಂಕದಲ್ಲಿನ ಅಂಶಕ್ಕೆ ಉಲ್ಲೇಖವನ್ನು ಒದಗಿಸುತ್ತದೆ.
    ///
    /// ಸೂಚ್ಯಂಕ 0 ನಲ್ಲಿರುವ ಅಂಶವು ಕ್ಯೂನ ಮುಂಭಾಗವಾಗಿದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// ನಿರ್ದಿಷ್ಟ ಸೂಚ್ಯಂಕದಲ್ಲಿನ ಅಂಶಕ್ಕೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಒದಗಿಸುತ್ತದೆ.
    ///
    /// ಸೂಚ್ಯಂಕ 0 ನಲ್ಲಿರುವ ಅಂಶವು ಕ್ಯೂನ ಮುಂಭಾಗವಾಗಿದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// `i` ಮತ್ತು `j` ಸೂಚ್ಯಂಕಗಳಲ್ಲಿ ಅಂಶಗಳನ್ನು ಬದಲಾಯಿಸುತ್ತದೆ.
    ///
    /// `i` ಮತ್ತು `j` ಸಮಾನವಾಗಿರಬಹುದು.
    ///
    /// ಸೂಚ್ಯಂಕ 0 ನಲ್ಲಿರುವ ಅಂಶವು ಕ್ಯೂನ ಮುಂಭಾಗವಾಗಿದೆ.
    ///
    /// # Panics
    ///
    /// ಎರಡೂ ಸೂಚ್ಯಂಕವು ಮಿತಿ ಮೀರದಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// ಮರುಹಂಚಿಕೆ ಮಾಡದೆ `VecDeque` ಹಿಡಿದಿಟ್ಟುಕೊಳ್ಳಬಹುದಾದ ಅಂಶಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// ಕೊಟ್ಟಿರುವ `VecDeque` ನಲ್ಲಿ ನಿಖರವಾಗಿ `additional` ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ಸೇರಿಸಲು ಕನಿಷ್ಠ ಸಾಮರ್ಥ್ಯವನ್ನು ಕಾಯ್ದಿರಿಸಲಾಗಿದೆ.
    /// ಸಾಮರ್ಥ್ಯವು ಈಗಾಗಲೇ ಸಾಕಷ್ಟು ಇದ್ದರೆ ಏನನ್ನೂ ಮಾಡುವುದಿಲ್ಲ.
    ///
    /// ಹಂಚಿಕೆದಾರನು ಸಂಗ್ರಹಣೆಗೆ ವಿನಂತಿಸುವುದಕ್ಕಿಂತ ಹೆಚ್ಚಿನ ಸ್ಥಳವನ್ನು ನೀಡಬಹುದು ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    /// ಆದ್ದರಿಂದ ಸಾಮರ್ಥ್ಯವನ್ನು ನಿಖರವಾಗಿ ಕಡಿಮೆ ಎಂದು ಅವಲಂಬಿಸಲಾಗುವುದಿಲ್ಲ.
    /// future ಒಳಸೇರಿಸುವಿಕೆಯನ್ನು ನಿರೀಕ್ಷಿಸಿದ್ದರೆ [`reserve`] ಗೆ ಆದ್ಯತೆ ನೀಡಿ.
    ///
    /// # Panics
    ///
    /// ಹೊಸ ಸಾಮರ್ಥ್ಯವು `usize` ಅನ್ನು ಉಕ್ಕಿ ಹರಿಸಿದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// ಕೊಟ್ಟಿರುವ `VecDeque` ನಲ್ಲಿ ಕನಿಷ್ಠ `additional` ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ಸೇರಿಸಲು ಸಾಮರ್ಥ್ಯವನ್ನು ಕಾಯ್ದಿರಿಸಲಾಗಿದೆ.
    /// ಆಗಾಗ್ಗೆ ಮರುಹಂಚಿಕೆಗಳನ್ನು ತಪ್ಪಿಸಲು ಸಂಗ್ರಹವು ಹೆಚ್ಚಿನ ಸ್ಥಳವನ್ನು ಕಾಯ್ದಿರಿಸಬಹುದು.
    ///
    /// # Panics
    ///
    /// ಹೊಸ ಸಾಮರ್ಥ್ಯವು `usize` ಅನ್ನು ಉಕ್ಕಿ ಹರಿಸಿದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// ಕೊಟ್ಟಿರುವ `VecDeque<T>` ನಲ್ಲಿ ನಿಖರವಾಗಿ `additional` ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ಸೇರಿಸಲು ಕನಿಷ್ಠ ಸಾಮರ್ಥ್ಯವನ್ನು ಕಾಯ್ದಿರಿಸಲು ಪ್ರಯತ್ನಿಸುತ್ತದೆ.
    ///
    /// `try_reserve_exact` ಗೆ ಕರೆ ಮಾಡಿದ ನಂತರ, ಸಾಮರ್ಥ್ಯವು `self.len() + additional` ಗಿಂತ ಹೆಚ್ಚಿರುತ್ತದೆ ಅಥವಾ ಸಮಾನವಾಗಿರುತ್ತದೆ.
    /// ಸಾಮರ್ಥ್ಯವು ಈಗಾಗಲೇ ಸಾಕಷ್ಟು ಇದ್ದರೆ ಏನನ್ನೂ ಮಾಡುವುದಿಲ್ಲ.
    ///
    /// ಹಂಚಿಕೆದಾರನು ಸಂಗ್ರಹಣೆಗೆ ವಿನಂತಿಸುವುದಕ್ಕಿಂತ ಹೆಚ್ಚಿನ ಸ್ಥಳವನ್ನು ನೀಡಬಹುದು ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    /// ಆದ್ದರಿಂದ, ಸಾಮರ್ಥ್ಯವನ್ನು ನಿಖರವಾಗಿ ಕಡಿಮೆ ಎಂದು ಅವಲಂಬಿಸಲಾಗುವುದಿಲ್ಲ.
    /// future ಒಳಸೇರಿಸುವಿಕೆಯನ್ನು ನಿರೀಕ್ಷಿಸಿದ್ದರೆ `reserve` ಗೆ ಆದ್ಯತೆ ನೀಡಿ.
    ///
    /// # Errors
    ///
    /// ಸಾಮರ್ಥ್ಯವು `usize` ಅನ್ನು ಉಕ್ಕಿ ಹರಿಯುತ್ತಿದ್ದರೆ, ಅಥವಾ ಹಂಚಿಕೆದಾರರು ವೈಫಲ್ಯವನ್ನು ವರದಿ ಮಾಡಿದರೆ, ದೋಷವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // ಮೆಮೊರಿಯನ್ನು ಮೊದಲೇ ಕಾಯ್ದಿರಿಸಿ, ನಮಗೆ ಸಾಧ್ಯವಾಗದಿದ್ದರೆ ನಿರ್ಗಮಿಸುತ್ತದೆ
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // ನಮ್ಮ ಸಂಕೀರ್ಣ ಕೆಲಸದ ಮಧ್ಯದಲ್ಲಿ ಇದು OOM(Out-Of-Memory) ಸಾಧ್ಯವಿಲ್ಲ ಎಂದು ಈಗ ನಮಗೆ ತಿಳಿದಿದೆ
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ಬಹಳ ಸಂಕೀರ್ಣವಾಗಿದೆ
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// ಕೊಟ್ಟಿರುವ `VecDeque<T>` ನಲ್ಲಿ ಕನಿಷ್ಠ `additional` ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ಸೇರಿಸಲು ಸಾಮರ್ಥ್ಯವನ್ನು ಕಾಯ್ದಿರಿಸಲು ಪ್ರಯತ್ನಿಸುತ್ತದೆ.
    /// ಆಗಾಗ್ಗೆ ಮರುಹಂಚಿಕೆಗಳನ್ನು ತಪ್ಪಿಸಲು ಸಂಗ್ರಹವು ಹೆಚ್ಚಿನ ಸ್ಥಳವನ್ನು ಕಾಯ್ದಿರಿಸಬಹುದು.
    /// `try_reserve` ಗೆ ಕರೆ ಮಾಡಿದ ನಂತರ, ಸಾಮರ್ಥ್ಯವು `self.len() + additional` ಗಿಂತ ಹೆಚ್ಚಿರುತ್ತದೆ ಅಥವಾ ಸಮಾನವಾಗಿರುತ್ತದೆ.
    /// ಸಾಮರ್ಥ್ಯವು ಈಗಾಗಲೇ ಸಾಕಷ್ಟು ಇದ್ದರೆ ಏನನ್ನೂ ಮಾಡುವುದಿಲ್ಲ.
    ///
    /// # Errors
    ///
    /// ಸಾಮರ್ಥ್ಯವು `usize` ಅನ್ನು ಉಕ್ಕಿ ಹರಿಯುತ್ತಿದ್ದರೆ, ಅಥವಾ ಹಂಚಿಕೆದಾರರು ವೈಫಲ್ಯವನ್ನು ವರದಿ ಮಾಡಿದರೆ, ದೋಷವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // ಮೆಮೊರಿಯನ್ನು ಮೊದಲೇ ಕಾಯ್ದಿರಿಸಿ, ನಮಗೆ ಸಾಧ್ಯವಾಗದಿದ್ದರೆ ನಿರ್ಗಮಿಸುತ್ತದೆ
    ///     output.try_reserve(data.len())?;
    ///
    ///     // ನಮ್ಮ ಸಂಕೀರ್ಣ ಕೆಲಸದ ಮಧ್ಯದಲ್ಲಿ ಇದು OOM ಆಗುವುದಿಲ್ಲ ಎಂದು ಈಗ ನಮಗೆ ತಿಳಿದಿದೆ
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ಬಹಳ ಸಂಕೀರ್ಣವಾಗಿದೆ
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// `VecDeque` ನ ಸಾಮರ್ಥ್ಯವನ್ನು ಸಾಧ್ಯವಾದಷ್ಟು ಕುಗ್ಗಿಸುತ್ತದೆ.
    ///
    /// ಇದು ಉದ್ದಕ್ಕೆ ಸಾಧ್ಯವಾದಷ್ಟು ಹತ್ತಿರಕ್ಕೆ ಇಳಿಯುತ್ತದೆ ಆದರೆ ಇನ್ನೂ ಕೆಲವು ಅಂಶಗಳಿಗೆ ಸ್ಥಳವಿದೆ ಎಂದು ಹಂಚಿಕೆದಾರರು ಇನ್ನೂ `VecDeque` ಗೆ ತಿಳಿಸಬಹುದು.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// `VecDeque` ನ ಸಾಮರ್ಥ್ಯವನ್ನು ಕಡಿಮೆ ಬೌಂಡ್‌ನೊಂದಿಗೆ ಕುಗ್ಗಿಸುತ್ತದೆ.
    ///
    /// ಸಾಮರ್ಥ್ಯವು ಉದ್ದ ಮತ್ತು ಸರಬರಾಜು ಮೌಲ್ಯ ಎರಡರಷ್ಟು ದೊಡ್ಡದಾಗಿರುತ್ತದೆ.
    ///
    ///
    /// ಪ್ರಸ್ತುತ ಸಾಮರ್ಥ್ಯವು ಕಡಿಮೆ ಮಿತಿಗಿಂತ ಕಡಿಮೆಯಿದ್ದರೆ, ಇದು ಯಾವುದೇ ಆಪ್ ಅಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // `self.len()` ಅಥವಾ `self.capacity()` ಎಂದಿಗೂ `usize::MAX` ಆಗಿರದ ಕಾರಣ ನಾವು ಉಕ್ಕಿ ಹರಿಯುವ ಬಗ್ಗೆ ಚಿಂತಿಸಬೇಕಾಗಿಲ್ಲ.
        // ರಿಂಗ್‌ಬಫರ್ ಯಾವಾಗಲೂ ಒಂದು ಜಾಗವನ್ನು ಖಾಲಿ ಬಿಡುವುದರಿಂದ +1.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // ಆಸಕ್ತಿಯ ಮೂರು ಪ್ರಕರಣಗಳಿವೆ:
            //   ಎಲ್ಲಾ ಅಂಶಗಳು ಅಪೇಕ್ಷಿತ ಗಡಿರೇಖೆಗಳಿಲ್ಲ ಎಲಿಮೆಂಟ್ಸ್ ಪರಸ್ಪರ ಮತ್ತು ತಲೆ ಅಪೇಕ್ಷಿತ ಗಡಿರೇಖೆಯಿಂದ ಹೊರಗಿದೆ ಅಂಶಗಳು ಅಸಂಖ್ಯಾತವಾಗಿವೆ, ಮತ್ತು ಬಾಲವು ಅಪೇಕ್ಷಿತ ಮಿತಿ ಮೀರಿದೆ
            //
            //
            // ಎಲ್ಲಾ ಇತರ ಸಮಯಗಳಲ್ಲಿ, ಅಂಶದ ಸ್ಥಾನಗಳು ಪರಿಣಾಮ ಬೀರುವುದಿಲ್ಲ.
            //
            // ತಲೆಯಲ್ಲಿರುವ ಅಂಶಗಳನ್ನು ಸರಿಸಬೇಕು ಎಂದು ಸೂಚಿಸುತ್ತದೆ.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // ಅಂಶಗಳನ್ನು ಅಪೇಕ್ಷಿತ ಗಡಿರೇಖೆಯಿಂದ ಸರಿಸಿ (ಟಾರ್ಗೆಟ್_ಕ್ಯಾಪ್ ನಂತರದ ಸ್ಥಾನಗಳು)
            if self.tail >= target_cap && head_outside {
                // ಟಿ.ಎಚ್
                //   [. . . . . . . . o o o o o o o . ]
                //    ಟಿ.ಎಚ್
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // ಟಿ.ಎಚ್
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // ಎಚ್‌ಟಿ
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// `VecDeque` ಅನ್ನು ಕಡಿಮೆಗೊಳಿಸುತ್ತದೆ, ಮೊದಲ `len` ಅಂಶಗಳನ್ನು ಇಟ್ಟುಕೊಂಡು ಉಳಿದದ್ದನ್ನು ಬಿಡುತ್ತದೆ.
    ///
    ///
    /// `len` `VecDeque` ನ ಪ್ರಸ್ತುತ ಉದ್ದಕ್ಕಿಂತ ಹೆಚ್ಚಿದ್ದರೆ, ಇದು ಯಾವುದೇ ಪರಿಣಾಮ ಬೀರುವುದಿಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// ಸ್ಲೈಸ್‌ನಲ್ಲಿರುವ ಎಲ್ಲಾ ವಸ್ತುಗಳನ್ನು ಕೈಬಿಟ್ಟಾಗ (ಸಾಮಾನ್ಯವಾಗಿ ಅಥವಾ ಬಿಚ್ಚುವ ಸಮಯದಲ್ಲಿ) ಡಿಸ್ಟ್ರಕ್ಟರ್ ಅನ್ನು ಚಾಲನೆ ಮಾಡುತ್ತದೆ.
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // ಸುರಕ್ಷಿತ ಏಕೆಂದರೆ:
        //
        // * `drop_in_place` ಗೆ ರವಾನಿಸಿದ ಯಾವುದೇ ಸ್ಲೈಸ್ ಮಾನ್ಯವಾಗಿರುತ್ತದೆ;ಎರಡನೆಯ ಪ್ರಕರಣವು `len <= front.len()` ಅನ್ನು ಹೊಂದಿದೆ ಮತ್ತು `len > self.len()` ನಲ್ಲಿ ಹಿಂತಿರುಗುವುದು ಮೊದಲ ಸಂದರ್ಭದಲ್ಲಿ `begin <= back.len()` ಅನ್ನು ಖಾತ್ರಿಗೊಳಿಸುತ್ತದೆ
        //
        // * `drop_in_place` ಗೆ ಕರೆ ಮಾಡುವ ಮೊದಲು VecDeque ನ ತಲೆಯನ್ನು ಸರಿಸಲಾಗಿದೆ, ಆದ್ದರಿಂದ `drop_in_place` panics ಆಗಿದ್ದರೆ ಯಾವುದೇ ಮೌಲ್ಯವನ್ನು ಎರಡು ಬಾರಿ ಕೈಬಿಡಲಾಗುವುದಿಲ್ಲ
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // ಮೊದಲ ಒಂದು panics ನಲ್ಲಿ ವಿನಾಶಕ ಇದ್ದಾಗಲೂ ದ್ವಿತೀಯಾರ್ಧವನ್ನು ಕೈಬಿಡಲಾಗಿದೆಯೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// ಫ್ರಂಟ್-ಟು-ಬ್ಯಾಕ್ ಇಟರೇಟರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// ರೂಪಾಂತರಗೊಳ್ಳುವ ಉಲ್ಲೇಖಗಳನ್ನು ಹಿಂತಿರುಗಿಸುವ ಮುಂಭಾಗದಿಂದ ಹಿಂದಕ್ಕೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // ಸುರಕ್ಷತೆ: ಆಂತರಿಕ `IterMut` ಸುರಕ್ಷತಾ ಅಸ್ಥಿರತೆಯನ್ನು ಸ್ಥಾಪಿಸಲಾಗಿದೆ ಏಕೆಂದರೆ
        // `ring` ನಾವು ರಚಿಸುವುದು ಜೀವಮಾನದ '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// `VecDeque` ನ ವಿಷಯಗಳನ್ನು ಒಳಗೊಂಡಿರುವ ಒಂದು ಜೋಡಿ ಚೂರುಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [`make_contiguous`] ಅನ್ನು ಈ ಹಿಂದೆ ಕರೆಯಲಾಗಿದ್ದರೆ, `VecDeque` ನ ಎಲ್ಲಾ ಅಂಶಗಳು ಮೊದಲ ಸ್ಲೈಸ್‌ನಲ್ಲಿರುತ್ತವೆ ಮತ್ತು ಎರಡನೇ ಸ್ಲೈಸ್ ಖಾಲಿಯಾಗಿರುತ್ತದೆ.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// `VecDeque` ನ ವಿಷಯಗಳನ್ನು ಒಳಗೊಂಡಿರುವ ಒಂದು ಜೋಡಿ ಚೂರುಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [`make_contiguous`] ಅನ್ನು ಈ ಹಿಂದೆ ಕರೆಯಲಾಗಿದ್ದರೆ, `VecDeque` ನ ಎಲ್ಲಾ ಅಂಶಗಳು ಮೊದಲ ಸ್ಲೈಸ್‌ನಲ್ಲಿರುತ್ತವೆ ಮತ್ತು ಎರಡನೇ ಸ್ಲೈಸ್ ಖಾಲಿಯಾಗಿರುತ್ತದೆ.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// `VecDeque` ನಲ್ಲಿನ ಅಂಶಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// `VecDeque` ಖಾಲಿಯಾಗಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// `VecDeque` ನಲ್ಲಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಶ್ರೇಣಿಯನ್ನು ಒಳಗೊಳ್ಳುವ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// ಆರಂಭಿಕ ಬಿಂದುವು ಅಂತಿಮ ಬಿಂದುವಿಗಿಂತ ದೊಡ್ಡದಾಗಿದ್ದರೆ ಅಥವಾ ಅಂತಿಮ ಬಿಂದು vector ನ ಉದ್ದಕ್ಕಿಂತ ದೊಡ್ಡದಾಗಿದ್ದರೆ Panics.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // ಪೂರ್ಣ ಶ್ರೇಣಿಯು ಎಲ್ಲಾ ವಿಷಯಗಳನ್ನು ಒಳಗೊಂಡಿದೆ
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // &self ನಲ್ಲಿ ನಾವು ಹೊಂದಿರುವ ಹಂಚಿಕೆಯ ಉಲ್ಲೇಖವನ್ನು '_ ಇಟರ್' ನಲ್ಲಿ ನಿರ್ವಹಿಸಲಾಗಿದೆ.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// `VecDeque` ನಲ್ಲಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ರೂಪಾಂತರಿತ ಶ್ರೇಣಿಯನ್ನು ಒಳಗೊಳ್ಳುವ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// ಆರಂಭಿಕ ಬಿಂದುವು ಅಂತಿಮ ಬಿಂದುವಿಗಿಂತ ದೊಡ್ಡದಾಗಿದ್ದರೆ ಅಥವಾ ಅಂತಿಮ ಬಿಂದು vector ನ ಉದ್ದಕ್ಕಿಂತ ದೊಡ್ಡದಾಗಿದ್ದರೆ Panics.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // ಪೂರ್ಣ ಶ್ರೇಣಿಯು ಎಲ್ಲಾ ವಿಷಯಗಳನ್ನು ಒಳಗೊಂಡಿದೆ
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // ಸುರಕ್ಷತೆ: ಆಂತರಿಕ `IterMut` ಸುರಕ್ಷತಾ ಅಸ್ಥಿರತೆಯನ್ನು ಸ್ಥಾಪಿಸಲಾಗಿದೆ ಏಕೆಂದರೆ
        // `ring` ನಾವು ರಚಿಸುವುದು ಜೀವಮಾನದ '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// `VecDeque` ನಲ್ಲಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಶ್ರೇಣಿಯನ್ನು ತೆಗೆದುಹಾಕುವ ಮತ್ತು ತೆಗೆದುಹಾಕಲಾದ ವಸ್ತುಗಳನ್ನು ನೀಡುವ ಡ್ರೈಯಿಂಗ್ ಇಟರೇಟರ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// ಗಮನಿಸಿ 1: ಪುನರಾವರ್ತಕವನ್ನು ಕೊನೆಯವರೆಗೂ ಸೇವಿಸದಿದ್ದರೂ ಸಹ ಅಂಶ ಶ್ರೇಣಿಯನ್ನು ತೆಗೆದುಹಾಕಲಾಗುತ್ತದೆ.
    ///
    /// ಗಮನಿಸಿ 2: `Drain` ಮೌಲ್ಯವನ್ನು ಕೈಬಿಡದಿದ್ದರೆ, ಡೆಕ್‌ನಿಂದ ಎಷ್ಟು ಅಂಶಗಳನ್ನು ತೆಗೆದುಹಾಕಲಾಗುತ್ತದೆ ಎಂದು ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿಲ್ಲ, ಆದರೆ ಅದು ಹೊಂದಿರುವ ಸಾಲವು ಮುಕ್ತಾಯಗೊಳ್ಳುತ್ತದೆ (ಉದಾ., `mem::forget` ಕಾರಣ).
    ///
    ///
    /// # Panics
    ///
    /// ಆರಂಭಿಕ ಬಿಂದುವು ಅಂತಿಮ ಬಿಂದುವಿಗಿಂತ ದೊಡ್ಡದಾಗಿದ್ದರೆ ಅಥವಾ ಅಂತಿಮ ಬಿಂದು vector ನ ಉದ್ದಕ್ಕಿಂತ ದೊಡ್ಡದಾಗಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // ಪೂರ್ಣ ಶ್ರೇಣಿಯು ಎಲ್ಲಾ ವಿಷಯಗಳನ್ನು ತೆರವುಗೊಳಿಸುತ್ತದೆ
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // ಮೆಮೊರಿ ಸುರಕ್ಷತೆ
        //
        // Drain ಅನ್ನು ಮೊದಲು ರಚಿಸಿದಾಗ, Drain ನ ವಿನಾಶಕವು ಎಂದಿಗೂ ಚಾಲನೆಯಲ್ಲಿಲ್ಲದಿದ್ದರೆ ಯಾವುದೇ ಪ್ರಾರಂಭಿಸದ ಅಥವಾ ಸ್ಥಳಾಂತರಗೊಂಡ ಅಂಶಗಳು ಪ್ರವೇಶಿಸಲಾಗುವುದಿಲ್ಲ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ಮೂಲ ಡಿಕ್ಯೂ ಅನ್ನು ಸಂಕ್ಷಿಪ್ತಗೊಳಿಸಲಾಗುತ್ತದೆ.
        //
        //
        // Drain ತೆಗೆದುಹಾಕಲು ptr::read ಮೌಲ್ಯಗಳನ್ನು ಹೊರಹಾಕುತ್ತದೆ.
        // ಪೂರ್ಣಗೊಂಡಾಗ, ರಂಧ್ರವನ್ನು ಮುಚ್ಚಲು ಉಳಿದ ಡೇಟಾವನ್ನು ಮತ್ತೆ ನಕಲಿಸಲಾಗುತ್ತದೆ ಮತ್ತು head/tail ಮೌಲ್ಯಗಳನ್ನು ಸರಿಯಾಗಿ ಮರುಸ್ಥಾಪಿಸಲಾಗುತ್ತದೆ.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // ಡೆಕ್ನ ಅಂಶಗಳನ್ನು ಮೂರು ಭಾಗಗಳಾಗಿ ವಿಂಗಡಿಸಲಾಗಿದೆ:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // ಟಿ=ಎಕ್ಸ್ 00 ಎಕ್ಸ್;ಎಚ್=ಎಕ್ಸ್ 01 ಎಕ್ಸ್;t=drain_tail;h=drain_head
        //
        // ನಾವು drain_tail ಅನ್ನು self.head ಆಗಿ, ಮತ್ತು drain_head ಮತ್ತು self.head ಅನ್ನು ಕ್ರಮವಾಗಿ after0tail ಮತ್ತು after_head ಆಗಿ Drain ನಲ್ಲಿ ಸಂಗ್ರಹಿಸುತ್ತೇವೆ.
        // Drain ಸೋರಿಕೆಯಾಗಿದ್ದರೆ, drain ಪ್ರಾರಂಭವಾದ ನಂತರ ಚಲಿಸುವ ಸಂಭಾವ್ಯ ಮೌಲ್ಯಗಳ ಬಗ್ಗೆ ನಾವು ಮರೆತಿದ್ದೇವೆ ಎಂಬಂತಹ ಪರಿಣಾಮಕಾರಿ ಶ್ರೇಣಿಯನ್ನು ಇದು ಮೊಟಕುಗೊಳಿಸುತ್ತದೆ.
        //
        //
        //        ಟಿ ನೇ ಎಚ್
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" drain ಪ್ರಾರಂಭವಾದ ನಂತರ drain ಪೂರ್ಣಗೊಂಡ ನಂತರ ಮತ್ತು Drain ಡಿಸ್ಟ್ರಕ್ಟರ್ ಅನ್ನು ಚಾಲನೆ ಮಾಡುವವರೆಗೆ ಮೌಲ್ಯಗಳ ಬಗ್ಗೆ.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // ಬಹುಮುಖ್ಯವಾಗಿ, ನಾವು ಇಲ್ಲಿ `self` ನಿಂದ ಹಂಚಿದ ಉಲ್ಲೇಖಗಳನ್ನು ಮಾತ್ರ ರಚಿಸುತ್ತೇವೆ ಮತ್ತು ಅದರಿಂದ ಓದುತ್ತೇವೆ.
                // ನಾವು `self` ಗೆ ಬರೆಯುವುದಿಲ್ಲ ಅಥವಾ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಕ್ಕೆ ಮರುಬಳಕೆ ಮಾಡುವುದಿಲ್ಲ.
                // ಆದ್ದರಿಂದ ನಾವು ಮೇಲೆ ರಚಿಸಿದ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್, `deque` ಗಾಗಿ ಮಾನ್ಯವಾಗಿ ಉಳಿದಿದೆ.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// `VecDeque` ಅನ್ನು ತೆರವುಗೊಳಿಸುತ್ತದೆ, ಎಲ್ಲಾ ಮೌಲ್ಯಗಳನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// `VecDeque` ನಿರ್ದಿಷ್ಟ ಮೌಲ್ಯಕ್ಕೆ ಸಮಾನವಾದ ಅಂಶವನ್ನು ಹೊಂದಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// ಮುಂಭಾಗದ ಅಂಶಕ್ಕೆ ಉಲ್ಲೇಖವನ್ನು ಒದಗಿಸುತ್ತದೆ, ಅಥವಾ `VecDeque` ಖಾಲಿಯಾಗಿದ್ದರೆ `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// ಮುಂಭಾಗದ ಅಂಶಕ್ಕೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಒದಗಿಸುತ್ತದೆ, ಅಥವಾ `VecDeque` ಖಾಲಿಯಾಗಿದ್ದರೆ `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// ಹಿಂದಿನ ಅಂಶಕ್ಕೆ ಉಲ್ಲೇಖವನ್ನು ಒದಗಿಸುತ್ತದೆ, ಅಥವಾ `VecDeque` ಖಾಲಿಯಾಗಿದ್ದರೆ `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// ಹಿಂದಿನ ಅಂಶಕ್ಕೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಒದಗಿಸುತ್ತದೆ, ಅಥವಾ `VecDeque` ಖಾಲಿಯಾಗಿದ್ದರೆ `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// ಮೊದಲ ಅಂಶವನ್ನು ತೆಗೆದುಹಾಕಿ ಅದನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಅಥವಾ `VecDeque` ಖಾಲಿಯಾಗಿದ್ದರೆ `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// `VecDeque` ನಿಂದ ಕೊನೆಯ ಅಂಶವನ್ನು ತೆಗೆದುಹಾಕಿ ಅದನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಅಥವಾ ಅದು ಖಾಲಿಯಾಗಿದ್ದರೆ `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// `VecDeque` ಗೆ ಒಂದು ಅಂಶವನ್ನು ಸಿದ್ಧಪಡಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// `VecDeque` ನ ಹಿಂಭಾಗಕ್ಕೆ ಒಂದು ಅಂಶವನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: ನಾವು `head == 0` ಅನ್ನು ಅರ್ಥೈಸಿಕೊಳ್ಳಬೇಕೆ
        // `self` ಸಮೀಪದಲ್ಲಿದೆ?
        self.tail <= self.head
    }

    /// `VecDeque` ನಲ್ಲಿ ಎಲ್ಲಿಂದಲಾದರೂ ಒಂದು ಅಂಶವನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ ಮತ್ತು ಅದನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಅದನ್ನು ಮೊದಲ ಅಂಶದೊಂದಿಗೆ ಬದಲಾಯಿಸುತ್ತದೆ.
    ///
    ///
    /// ಇದು ಆದೇಶವನ್ನು ಸಂರಕ್ಷಿಸುವುದಿಲ್ಲ, ಆದರೆ *O*(1) ಆಗಿದೆ.
    ///
    /// `index` ಮಿತಿ ಮೀರದಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಸೂಚ್ಯಂಕ 0 ನಲ್ಲಿರುವ ಅಂಶವು ಕ್ಯೂನ ಮುಂಭಾಗವಾಗಿದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// `VecDeque` ನಲ್ಲಿ ಎಲ್ಲಿಂದಲಾದರೂ ಒಂದು ಅಂಶವನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ ಮತ್ತು ಅದನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಅದನ್ನು ಕೊನೆಯ ಅಂಶದೊಂದಿಗೆ ಬದಲಾಯಿಸುತ್ತದೆ.
    ///
    ///
    /// ಇದು ಆದೇಶವನ್ನು ಸಂರಕ್ಷಿಸುವುದಿಲ್ಲ, ಆದರೆ *O*(1) ಆಗಿದೆ.
    ///
    /// `index` ಮಿತಿ ಮೀರದಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಸೂಚ್ಯಂಕ 0 ನಲ್ಲಿರುವ ಅಂಶವು ಕ್ಯೂನ ಮುಂಭಾಗವಾಗಿದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// `VecDeque` ಒಳಗೆ `index` ನಲ್ಲಿ ಒಂದು ಅಂಶವನ್ನು ಸೇರಿಸುತ್ತದೆ, ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು `index` ಗಿಂತ ಹೆಚ್ಚಿನ ಅಥವಾ ಸಮನಾದ ಸೂಚ್ಯಂಕಗಳೊಂದಿಗೆ ಹಿಂಭಾಗಕ್ಕೆ ವರ್ಗಾಯಿಸುತ್ತದೆ.
    ///
    ///
    /// ಸೂಚ್ಯಂಕ 0 ನಲ್ಲಿರುವ ಅಂಶವು ಕ್ಯೂನ ಮುಂಭಾಗವಾಗಿದೆ.
    ///
    /// # Panics
    ///
    /// `index` `VecDeque` ನ ಉದ್ದಕ್ಕಿಂತ ಹೆಚ್ಚಿದ್ದರೆ Panics
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // ರಿಂಗ್ ಬಫರ್‌ನಲ್ಲಿ ಕನಿಷ್ಠ ಸಂಖ್ಯೆಯ ಅಂಶಗಳನ್ನು ಸರಿಸಿ ಮತ್ತು ನಿರ್ದಿಷ್ಟ ವಸ್ತುವನ್ನು ಸೇರಿಸಿ
        //
        // ಹೆಚ್ಚಿನ len/2 ನಲ್ಲಿ, 1 ಅಂಶಗಳನ್ನು ಸರಿಸಲಾಗುವುದು. O(min(n, n-i))
        //
        // ಮೂರು ಮುಖ್ಯ ಪ್ರಕರಣಗಳಿವೆ:
        //  ಅಂಶಗಳು ಪರಸ್ಪರ ಹೊಂದಿರುತ್ತವೆ
        //      - ಬಾಲ 0 ಆಗಿರುವಾಗ ವಿಶೇಷ ಪ್ರಕರಣಗಳು ಅಂಶಗಳು ಅಸಂಖ್ಯಾತವಾಗಿರುತ್ತವೆ ಮತ್ತು ಇನ್ಸರ್ಟ್ ಬಾಲ ವಿಭಾಗದಲ್ಲಿದೆ ಎಲಿಮೆಂಟ್ಸ್ ಸ್ಥಗಿತಗೊಳ್ಳುತ್ತದೆ ಮತ್ತು ಇನ್ಸರ್ಟ್ ಮುಖ್ಯ ವಿಭಾಗದಲ್ಲಿದೆ
        //
        //
        // ಪ್ರತಿಯೊಂದಕ್ಕೂ ಇನ್ನೂ ಎರಡು ಪ್ರಕರಣಗಳಿವೆ:
        //  ಇನ್ಸರ್ಟ್ ಬಾಲಕ್ಕೆ ಹತ್ತಿರದಲ್ಲಿದೆ ಇನ್ಸರ್ಟ್ ತಲೆಗೆ ಹತ್ತಿರದಲ್ಲಿದೆ
        //
        // ಕೀ: ಎಚ್, ಎಕ್ಸ್ 00 ಎಕ್ಸ್
        //      T, self.tail o, ಮಾನ್ಯ ಅಂಶ I, ಅಳವಡಿಕೆ ಅಂಶ A, ಅಳವಡಿಕೆ ಬಿಂದು M ನಂತರ ಇರಬೇಕಾದ ಅಂಶ, ಅಂಶವನ್ನು ಸರಿಸಲಾಗಿದೆ ಎಂದು ಸೂಚಿಸುತ್ತದೆ
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       ಟಿಐಹೆಚ್
                //      [ಎ oo ಹೂ.......
                //      .
                //      .]
                //
                //                       ಎಚ್‌ಟಿ
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // ಪರಸ್ಪರ, ಬಾಲಕ್ಕೆ ಹತ್ತಿರ ಸೇರಿಸಿ:
                    //
                    //             ಟಿಐಹೆಚ್
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           ಟಿ.ಎಚ್
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // ಪರಸ್ಪರ, ಬಾಲ ಮತ್ತು ಬಾಲಕ್ಕೆ ಹತ್ತಿರ ಸೇರಿಸಿ 0:
                    //
                    //
                    //       ಟಿಐಹೆಚ್
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       ಎಚ್‌ಟಿ
                    //      [o I A o o o o o . . . . . . . o]
                    //       ಎಂ.ಎಂ.

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // ಈಗಾಗಲೇ ಬಾಲವನ್ನು ಸರಿಸಲಾಗಿದೆ, ಆದ್ದರಿಂದ ನಾವು `index - 1` ಅಂಶಗಳನ್ನು ಮಾತ್ರ ನಕಲಿಸುತ್ತೇವೆ.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // ಪರಸ್ಪರ, ತಲೆಗೆ ಹತ್ತಿರ ಸೇರಿಸಿ:
                    //
                    //             ಟಿಐಹೆಚ್
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             ಟಿ.ಎಚ್
                    //      [. . . o o o o I A o o . . . . .]
                    //                       ಎಂಎಂಎಂ

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // ಸ್ಥಗಿತ, ಬಾಲ, ಬಾಲ ವಿಭಾಗಕ್ಕೆ ಹತ್ತಿರ ಸೇರಿಸಿ:
                    //
                    //                   ಎಚ್‌ಟಿಐ
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   ಎಚ್‌ಟಿ
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // ಸ್ಥಗಿತ, ತಲೆಗೆ ಹತ್ತಿರ ಸೇರಿಸಿ, ಬಾಲ ವಿಭಾಗ:
                    //
                    //           ಎಚ್‌ಟಿಐ
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             ಎಚ್‌ಟಿ
                    //      [o o o . . . . . . o o o o o I A]
                    //       ಎಂಎಂಎಂಎಂ

                    // ಅಂಶಗಳನ್ನು ಹೊಸ ತಲೆಗೆ ನಕಲಿಸಿ
                    self.copy(1, 0, self.head);

                    // ಕೊನೆಯ ಅಂಶವನ್ನು ಬಫರ್‌ನ ಕೆಳಭಾಗದಲ್ಲಿರುವ ಖಾಲಿ ಸ್ಥಳಕ್ಕೆ ನಕಲಿಸಿ
                    self.copy(0, self.cap() - 1, 1);

                    // id ಅಂಶವನ್ನು ಒಳಗೊಂಡಂತೆ ಐಡಿಕ್ಸ್‌ನಿಂದ ಅಂಶಗಳನ್ನು ಮುಂದಕ್ಕೆ ಸರಿಸಲು
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // ಅಸ್ಥಿರ, ಒಳಸೇರಿಸುವಿಕೆಯು ಬಾಲ, ತಲೆ ವಿಭಾಗಕ್ಕೆ ಹತ್ತಿರದಲ್ಲಿದೆ ಮತ್ತು ಆಂತರಿಕ ಬಫರ್‌ನಲ್ಲಿ ಸೂಚ್ಯಂಕ ಶೂನ್ಯದಲ್ಲಿದೆ:
                    //
                    //
                    //       ಐಎಚ್‌ಟಿ
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           ಎಚ್‌ಟಿ
                    //      [A o o o o o o o o o . . o o o I]
                    //                               ಎಂಎಂಎಂ

                    // ಹೊಸ ಬಾಲದವರೆಗೆ ಅಂಶಗಳನ್ನು ನಕಲಿಸಿ
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // ಕೊನೆಯ ಅಂಶವನ್ನು ಬಫರ್‌ನ ಕೆಳಭಾಗದಲ್ಲಿರುವ ಖಾಲಿ ಸ್ಥಳಕ್ಕೆ ನಕಲಿಸಿ
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // ಸ್ಥಗಿತ, ಬಾಲಕ್ಕೆ ಹತ್ತಿರ ಸೇರಿಸಿ, ತಲೆ ವಿಭಾಗ:
                    //
                    //             ಐಎಚ್‌ಟಿ
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           ಎಚ್‌ಟಿ
                    //      [o o I A o o o o o o . . o o o o]
                    //       ಎಂಎಂಎಂಎಂಎಂಎಂ

                    // ಹೊಸ ಬಾಲದವರೆಗೆ ಅಂಶಗಳನ್ನು ನಕಲಿಸಿ
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // ಕೊನೆಯ ಅಂಶವನ್ನು ಬಫರ್‌ನ ಕೆಳಭಾಗದಲ್ಲಿರುವ ಖಾಲಿ ಸ್ಥಳಕ್ಕೆ ನಕಲಿಸಿ
                    self.copy(self.cap() - 1, 0, 1);

                    // X ಅಂಶವನ್ನು ಒಳಗೊಂಡಂತೆ idx-1 ನಿಂದ ಅಂಶಗಳನ್ನು ಮುಂದಕ್ಕೆ ಸರಿಸಲು
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // ಸ್ಥಗಿತ, ತಲೆಗೆ ಹತ್ತಿರ ಸೇರಿಸಿ, ತಲೆ ವಿಭಾಗ:
                    //
                    //               ಐಎಚ್‌ಟಿ
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     ಎಚ್‌ಟಿ
                    //      [o o o o I A o o . . . . . o o o]
                    //                 ಎಂಎಂಎಂ

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // ಬಾಲವನ್ನು ಬದಲಾಯಿಸಲಾಗಿದೆ ಆದ್ದರಿಂದ ನಾವು ಮರು ಲೆಕ್ಕಾಚಾರ ಮಾಡಬೇಕಾಗಿದೆ
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// `VecDeque` ನಿಂದ `index` ನಲ್ಲಿ ಅಂಶವನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ ಮತ್ತು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    /// ತೆಗೆಯುವ ಬಿಂದುವಿಗೆ ಯಾವ ತುದಿ ಹತ್ತಿರದಲ್ಲಿದೆಯೋ ಅದನ್ನು ಸ್ಥಳಾಂತರಿಸಲು ಸರಿಸಲಾಗುವುದು, ಮತ್ತು ಎಲ್ಲಾ ಪೀಡಿತ ಅಂಶಗಳನ್ನು ಹೊಸ ಸ್ಥಾನಗಳಿಗೆ ಸರಿಸಲಾಗುತ್ತದೆ.
    ///
    /// `index` ಮಿತಿ ಮೀರದಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಸೂಚ್ಯಂಕ 0 ನಲ್ಲಿರುವ ಅಂಶವು ಕ್ಯೂನ ಮುಂಭಾಗವಾಗಿದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // ಮೂರು ಮುಖ್ಯ ಪ್ರಕರಣಗಳಿವೆ:
        //  ಅಂಶಗಳು ಪರಸ್ಪರ ಹೊಂದಿರುತ್ತವೆ ಎಲಿಮೆಂಟ್ಸ್ ಅಸ್ಥಿರವಾಗಿದೆ ಮತ್ತು ತೆಗೆಯುವುದು ಬಾಲ ವಿಭಾಗದಲ್ಲಿದೆ ಎಲಿಮೆಂಟ್ಸ್ ಸ್ಥಗಿತವಾಗಿದೆ ಮತ್ತು ತೆಗೆಯುವಿಕೆ ತಲೆ ವಿಭಾಗದಲ್ಲಿದೆ
        //
        //      - ಅಂಶಗಳು ತಾಂತ್ರಿಕವಾಗಿ ಸಮೀಪದಲ್ಲಿರುವಾಗ ವಿಶೇಷ ಸಂದರ್ಭ, ಆದರೆ self.head =0
        //
        // ಪ್ರತಿಯೊಂದಕ್ಕೂ ಇನ್ನೂ ಎರಡು ಪ್ರಕರಣಗಳಿವೆ:
        //  ಇನ್ಸರ್ಟ್ ಬಾಲಕ್ಕೆ ಹತ್ತಿರದಲ್ಲಿದೆ ಇನ್ಸರ್ಟ್ ತಲೆಗೆ ಹತ್ತಿರದಲ್ಲಿದೆ
        //
        // ಕೀ: ಎಚ್, ಎಕ್ಸ್ 00 ಎಕ್ಸ್
        //      T, self.tail o, ಮಾನ್ಯ ಅಂಶ x, ಎಲಿಮೆಂಟ್ ಅನ್ನು ತೆಗೆದುಹಾಕಲು ಗುರುತಿಸಲಾಗಿದೆ R, ತೆಗೆದುಹಾಕಲಾಗುತ್ತಿರುವ ಅಂಶವನ್ನು ಸೂಚಿಸುತ್ತದೆ M, ಅಂಶವನ್ನು ಸರಿಸಲಾಗಿದೆ ಎಂದು ಸೂಚಿಸುತ್ತದೆ
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // ಪರಸ್ಪರ, ಬಾಲಕ್ಕೆ ಹತ್ತಿರ ತೆಗೆದುಹಾಕಿ:
                    //
                    //             ಟಿಆರ್ಹೆಚ್
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               ಟಿ.ಎಚ್
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // ಪರಸ್ಪರ, ತಲೆಗೆ ಹತ್ತಿರ ತೆಗೆದುಹಾಕಿ:
                    //
                    //             ಟಿಆರ್ಹೆಚ್
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             ಟಿ.ಎಚ್
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // ಸ್ಥಗಿತ, ಬಾಲ, ಬಾಲ ವಿಭಾಗಕ್ಕೆ ಹತ್ತಿರ ತೆಗೆದುಹಾಕಿ:
                    //
                    //                   ಎಚ್‌ಟಿಆರ್
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   ಎಚ್‌ಟಿ
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // ಸ್ಥಗಿತ, ತಲೆಗೆ ಹತ್ತಿರ, ತಲೆ ವಿಭಾಗವನ್ನು ತೆಗೆದುಹಾಕಿ:
                    //
                    //               ಆರ್‌ಎಚ್‌ಟಿ
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   ಎಚ್‌ಟಿ
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // ಸ್ಥಗಿತ, ತಲೆ, ಬಾಲ ವಿಭಾಗಕ್ಕೆ ಹತ್ತಿರ ತೆಗೆದುಹಾಕಿ:
                    //
                    //             ಎಚ್‌ಟಿಆರ್
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           ಎಚ್‌ಟಿ
                    //      [o o . . . . . . . o o o o o o o]
                    //       ಎಂಎಂಎಂಎಂ
                    //
                    // ಅಥವಾ ಅರೆ-ಸ್ಥಗಿತ, ತಲೆ, ಬಾಲ ವಿಭಾಗದ ಪಕ್ಕದಲ್ಲಿ ತೆಗೆದುಹಾಕಿ:
                    //
                    //       ಎಚ್‌ಟಿಆರ್
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         ಟಿ.ಎಚ್
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // ಬಾಲ ವಿಭಾಗದಲ್ಲಿನ ಅಂಶಗಳನ್ನು ಎಳೆಯಿರಿ
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // ಒಳಹರಿವು ತಡೆಯುತ್ತದೆ.
                    if self.head != 0 {
                        // ಮೊದಲ ಅಂಶವನ್ನು ಖಾಲಿ ಸ್ಥಳಕ್ಕೆ ನಕಲಿಸಿ
                        self.copy(self.cap() - 1, 0, 1);

                        // ತಲೆ ವಿಭಾಗದಲ್ಲಿನ ಅಂಶಗಳನ್ನು ಹಿಂದಕ್ಕೆ ಸರಿಸಿ
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // ಸ್ಥಗಿತ, ಬಾಲ, ತಲೆ ವಿಭಾಗಕ್ಕೆ ಹತ್ತಿರ ತೆಗೆದುಹಾಕಿ:
                    //
                    //           ಆರ್‌ಎಚ್‌ಟಿ
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           ಎಚ್‌ಟಿ
                    //      [o o o o o o o o o o . . . . o o]
                    //       ಎಂಎಂಎಂಎಂಎಂ

                    // ಐಡಿಎಕ್ಸ್ ವರೆಗಿನ ಅಂಶಗಳನ್ನು ಸೆಳೆಯಿರಿ
                    self.copy(1, 0, idx);

                    // ಕೊನೆಯ ಅಂಶವನ್ನು ಖಾಲಿ ಸ್ಥಳಕ್ಕೆ ನಕಲಿಸಿ
                    self.copy(0, self.cap() - 1, 1);

                    // ಕೊನೆಯದನ್ನು ಹೊರತುಪಡಿಸಿ ಅಂಶಗಳನ್ನು ಬಾಲದಿಂದ ಮುಂದಕ್ಕೆ ಸರಿಸಿ
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// ಕೊಟ್ಟಿರುವ ಸೂಚ್ಯಂಕದಲ್ಲಿ `VecDeque` ಅನ್ನು ಎರಡು ಭಾಗಗಳಾಗಿ ವಿಭಜಿಸುತ್ತದೆ.
    ///
    /// ಹೊಸದಾಗಿ ನಿಯೋಜಿಸಲಾದ `VecDeque` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// `self` `[0, at)` ಅಂಶಗಳನ್ನು ಒಳಗೊಂಡಿದೆ, ಮತ್ತು ಹಿಂತಿರುಗಿದ `VecDeque` `[at, len)` ಅಂಶಗಳನ್ನು ಒಳಗೊಂಡಿದೆ.
    ///
    /// `self` ಸಾಮರ್ಥ್ಯವು ಬದಲಾಗುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    /// ಸೂಚ್ಯಂಕ 0 ನಲ್ಲಿರುವ ಅಂಶವು ಕ್ಯೂನ ಮುಂಭಾಗವಾಗಿದೆ.
    ///
    /// # Panics
    ///
    /// `at > len` ವೇಳೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` ಮೊದಲಾರ್ಧದಲ್ಲಿದೆ.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // ದ್ವಿತೀಯಾರ್ಧವನ್ನು ತೆಗೆದುಕೊಳ್ಳಿ.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` ದ್ವಿತೀಯಾರ್ಧದಲ್ಲಿದೆ, ಮೊದಲಾರ್ಧದಲ್ಲಿ ನಾವು ಬಿಟ್ಟುಬಿಟ್ಟ ಅಂಶಗಳಿಗೆ ಕಾರಣವಾಗಬೇಕು.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // ಬಫರ್‌ಗಳ ತುದಿಗಳು ಇರುವಲ್ಲಿ ಸ್ವಚ್ up ಗೊಳಿಸುವಿಕೆ
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// `other` ನ ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು `self` ಗೆ ಸರಿಸುತ್ತದೆ, `other` ಖಾಲಿಯಾಗಿರುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// ಸ್ವಯಂನಲ್ಲಿನ ಹೊಸ ಸಂಖ್ಯೆಯ ಅಂಶಗಳು `usize` ಅನ್ನು ಉಕ್ಕಿ ಹರಿಯುತ್ತಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // ನಿಷ್ಕಪಟ impl
        self.extend(other.drain(..));
    }

    /// ಮುನ್ಸೂಚನೆಯಿಂದ ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಅಂಶಗಳನ್ನು ಮಾತ್ರ ಉಳಿಸಿಕೊಳ್ಳುತ್ತದೆ.
    ///
    /// ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ,`e` ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ತೆಗೆದುಹಾಕಿ, ಅಂದರೆ `f(&e)` ಸುಳ್ಳನ್ನು ನೀಡುತ್ತದೆ.
    /// ಈ ವಿಧಾನವು ಸ್ಥಳದಲ್ಲಿ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ, ಪ್ರತಿಯೊಂದು ಅಂಶವನ್ನು ಮೂಲ ಕ್ರಮದಲ್ಲಿ ನಿಖರವಾಗಿ ಒಮ್ಮೆ ಭೇಟಿ ಮಾಡುತ್ತದೆ ಮತ್ತು ಉಳಿಸಿಕೊಂಡ ಅಂಶಗಳ ಕ್ರಮವನ್ನು ಕಾಪಾಡುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// ಸೂಚ್ಯಂಕದಂತೆ ಬಾಹ್ಯ ಸ್ಥಿತಿಯನ್ನು ಪತ್ತೆಹಚ್ಚಲು ನಿಖರವಾದ ಕ್ರಮವು ಉಪಯುಕ್ತವಾಗಬಹುದು.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // ಇದು panic ಅಥವಾ ಸ್ಥಗಿತಗೊಳಿಸಬಹುದು
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // ಬಫರ್ ಗಾತ್ರವನ್ನು ದ್ವಿಗುಣಗೊಳಿಸಿ.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// `VecDeque` ಅನ್ನು ಸ್ಥಳದಲ್ಲಿಯೇ ಮಾರ್ಪಡಿಸುತ್ತದೆ ಇದರಿಂದ `len()` `new_len` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ, ಹಿಂಭಾಗದಿಂದ ಹೆಚ್ಚುವರಿ ಅಂಶಗಳನ್ನು ತೆಗೆದುಹಾಕುವುದರ ಮೂಲಕ ಅಥವಾ `generator` ಅನ್ನು ಹಿಂಭಾಗಕ್ಕೆ ಕರೆಯುವ ಮೂಲಕ ಉತ್ಪತ್ತಿಯಾಗುವ ಅಂಶಗಳನ್ನು ಸೇರಿಸುವ ಮೂಲಕ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// ಈ ಡೆಕ್ನ ಆಂತರಿಕ ಸಂಗ್ರಹಣೆಯನ್ನು ಮರುಹೊಂದಿಸುತ್ತದೆ ಆದ್ದರಿಂದ ಇದು ಒಂದು ಪಕ್ಕದ ಸ್ಲೈಸ್ ಆಗಿದೆ, ನಂತರ ಅದನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// ಈ ವಿಧಾನವು ನಿಯೋಜಿಸುವುದಿಲ್ಲ ಮತ್ತು ಸೇರಿಸಿದ ಅಂಶಗಳ ಕ್ರಮವನ್ನು ಬದಲಾಯಿಸುವುದಿಲ್ಲ.ಇದು ರೂಪಾಂತರಿತ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂದಿರುಗಿಸಿದಾಗ, ಡಿಕ್ಯೂ ಅನ್ನು ವಿಂಗಡಿಸಲು ಇದನ್ನು ಬಳಸಬಹುದು.
    ///
    /// ಆಂತರಿಕ ಸಂಗ್ರಹಣೆಯು ಸಮೀಪದಲ್ಲಿದ್ದರೆ, [`as_slices`] ಮತ್ತು [`as_mut_slices`] ವಿಧಾನಗಳು `VecDeque` ನ ಸಂಪೂರ್ಣ ವಿಷಯಗಳನ್ನು ಒಂದೇ ಸ್ಲೈಸ್‌ನಲ್ಲಿ ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// ಡೆಕ್ನ ವಿಷಯವನ್ನು ವಿಂಗಡಿಸುವುದು.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // ಡಿಕ್ಯೂ ಅನ್ನು ವಿಂಗಡಿಸುವುದು
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // ಅದನ್ನು ಹಿಮ್ಮುಖ ಕ್ರಮದಲ್ಲಿ ವಿಂಗಡಿಸುವುದು
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// ಸಮೀಪದ ಸ್ಲೈಸ್‌ಗೆ ಬದಲಾಯಿಸಲಾಗದ ಪ್ರವೇಶವನ್ನು ಪಡೆಯುವುದು.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // `buf` ಗೆ ಬದಲಾಯಿಸಲಾಗದ ಪ್ರವೇಶವನ್ನು ಹೊಂದಿರುವಾಗ, `slice` ಡೆಕ್ನ ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ಒಳಗೊಂಡಿದೆ ಎಂದು ನಾವು ಈಗ ಖಚಿತವಾಗಿ ಹೇಳಬಹುದು.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // ಒಂದೇ ಸಮಯದಲ್ಲಿ ಬಾಲವನ್ನು ನಕಲಿಸಲು ಸಾಕಷ್ಟು ಉಚಿತ ಸ್ಥಳವಿದೆ, ಇದರರ್ಥ ನಾವು ಮೊದಲು ತಲೆಯನ್ನು ಹಿಂದಕ್ಕೆ ಬದಲಾಯಿಸುತ್ತೇವೆ, ತದನಂತರ ಬಾಲವನ್ನು ಸರಿಯಾದ ಸ್ಥಾನಕ್ಕೆ ನಕಲಿಸುತ್ತೇವೆ.
            //
            //
            // ಇಂದ: ಡೆಫ್ .... ಎಬಿಸಿ
            // ಗೆ: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: ನಾವು ಪ್ರಸ್ತುತ ಪರಿಗಣಿಸುವುದಿಲ್ಲ .... ಎಬಿಸಿಡಿಇಎಫ್ಜಿಹೆಚ್
            // ಈ ಸಂದರ್ಭದಲ್ಲಿ `head` `0` ಆಗಿರುತ್ತದೆ.
            // ನಾವು ಬಹುಶಃ ಇದನ್ನು ಬದಲಾಯಿಸಲು ಬಯಸಿದಾಗ ಇದು ಕ್ಷುಲ್ಲಕವಲ್ಲ, ಏಕೆಂದರೆ ಕೆಲವು ಸ್ಥಳಗಳು `is_contiguous` ಅನ್ನು ನಿರೀಕ್ಷಿಸುವುದರಿಂದ ನಾವು `buf[tail..head]` ಬಳಸಿ ತುಂಡು ಮಾಡಬಹುದು.
            //
            //

            // ಒಂದೇ ಸಮಯದಲ್ಲಿ ತಲೆಯನ್ನು ನಕಲಿಸಲು ಸಾಕಷ್ಟು ಉಚಿತ ಸ್ಥಳವಿದೆ, ಇದರರ್ಥ ನಾವು ಮೊದಲು ಬಾಲವನ್ನು ಮುಂದಕ್ಕೆ ಬದಲಾಯಿಸುತ್ತೇವೆ ಮತ್ತು ತಲೆಯನ್ನು ಸರಿಯಾದ ಸ್ಥಾನಕ್ಕೆ ನಕಲಿಸುತ್ತೇವೆ.
            //
            //
            // ಇಂದ: ಎಫ್‌ಜಿಹೆಚ್ .... ಎಬಿಸಿಡಿಇ
            // ಗೆ: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // ಉಚಿತ ತಲೆ ಮತ್ತು ಬಾಲ ಎರಡಕ್ಕಿಂತ ಚಿಕ್ಕದಾಗಿದೆ, ಇದರರ್ಥ ನಾವು ನಿಧಾನವಾಗಿ "swap" ಬಾಲ ಮತ್ತು ತಲೆಗಳನ್ನು ಹೊಂದಿರಬೇಕು.
            //
            //
            // ಇವರಿಂದ: EFGHI ... ABCD ಅಥವಾ HIJK.ABCDEFG
            // ಗೆ: ABCDEFGHI ... ಅಥವಾ ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // ಸಾಮಾನ್ಯ ಸಮಸ್ಯೆ ಈ GHIJKLM ನಂತೆ ಕಾಣುತ್ತದೆ ... ABCDEF, ಯಾವುದೇ ಸ್ವ್ಯಾಪ್ ಮಾಡುವ ಮೊದಲು ABCDEFM ... GHIJKL, 1 ಪಾಸ್ ವಿನಿಮಯದ ನಂತರ ABCDEFGHIJM ... KL, ಎಡ edge ಟೆಂಪ್ ಸ್ಟೋರ್ ತಲುಪುವವರೆಗೆ ವಿನಿಮಯ ಮಾಡಿಕೊಳ್ಳಿ
                //                  - ನಂತರ ಹೊಸ (smaller) ಅಂಗಡಿಯೊಂದಿಗೆ ಅಲ್ಗಾರಿದಮ್ ಅನ್ನು ಮರುಪ್ರಾರಂಭಿಸಿ ಕೆಲವೊಮ್ಮೆ ಬಲ edge ಬಫರ್‌ನ ಕೊನೆಯಲ್ಲಿರುವಾಗ ತಾತ್ಕಾಲಿಕ ಅಂಗಡಿಯನ್ನು ತಲುಪಲಾಗುತ್ತದೆ, ಇದರರ್ಥ ನಾವು ಕಡಿಮೆ ವಿನಿಮಯದೊಂದಿಗೆ ಸರಿಯಾದ ಕ್ರಮವನ್ನು ಹೊಡೆದಿದ್ದೇವೆ!
                //
                // E.g
                // ಇಎಫ್..ಎಬಿಸಿಡಿ ಎಬಿಸಿಡಿಇಎಫ್ .., ನಾಲ್ಕು ವಿನಿಮಯಗಳ ನಂತರ ನಾವು ಮುಗಿಸಿದ್ದೇವೆ
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// ಡಬಲ್-ಎಂಡ್ ಕ್ಯೂ `mid` ಸ್ಥಳಗಳನ್ನು ಎಡಕ್ಕೆ ತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// Equivalently,
    /// - ಐಟಂ `mid` ಅನ್ನು ಮೊದಲ ಸ್ಥಾನಕ್ಕೆ ತಿರುಗಿಸುತ್ತದೆ.
    /// - ಮೊದಲ `mid` ವಸ್ತುಗಳನ್ನು ಪಾಪ್ ಮಾಡುತ್ತದೆ ಮತ್ತು ಅವುಗಳನ್ನು ಕೊನೆಯಲ್ಲಿ ತಳ್ಳುತ್ತದೆ.
    /// - `len() - mid` ಸ್ಥಳಗಳನ್ನು ಬಲಕ್ಕೆ ತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// `mid` `len()` ಗಿಂತ ಹೆಚ್ಚಿದ್ದರೆ.
    /// `mid == len()` _not_ panic ಮಾಡುತ್ತದೆ ಮತ್ತು ನೋ-ಆಪ್ ತಿರುಗುವಿಕೆಯಾಗಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    /// # Complexity
    ///
    /// `*O*(min(mid, len() - mid))` ಸಮಯ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ ಮತ್ತು ಹೆಚ್ಚುವರಿ ಸ್ಥಳವಿಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// ಡಬಲ್-ಎಂಡ್ ಕ್ಯೂ `k` ಸ್ಥಳಗಳನ್ನು ಬಲಕ್ಕೆ ತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// Equivalently,
    /// - ಮೊದಲ ಐಟಂ ಅನ್ನು `k` ಸ್ಥಾನಕ್ಕೆ ತಿರುಗಿಸುತ್ತದೆ.
    /// - ಕೊನೆಯ `k` ವಸ್ತುಗಳನ್ನು ಪಾಪ್ ಮಾಡುತ್ತದೆ ಮತ್ತು ಅವುಗಳನ್ನು ಮುಂಭಾಗಕ್ಕೆ ತಳ್ಳುತ್ತದೆ.
    /// - `len() - k` ಸ್ಥಳಗಳನ್ನು ಎಡಕ್ಕೆ ತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// `k` `len()` ಗಿಂತ ಹೆಚ್ಚಿದ್ದರೆ.
    /// `k == len()` _not_ panic ಮಾಡುತ್ತದೆ ಮತ್ತು ನೋ-ಆಪ್ ತಿರುಗುವಿಕೆಯಾಗಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    /// # Complexity
    ///
    /// `*O*(min(k, len() - k))` ಸಮಯ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ ಮತ್ತು ಹೆಚ್ಚುವರಿ ಸ್ಥಳವಿಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // ಸುರಕ್ಷತೆ: ಈ ಕೆಳಗಿನ ಎರಡು ವಿಧಾನಗಳಿಗೆ ತಿರುಗುವಿಕೆಯ ಪ್ರಮಾಣ ಬೇಕಾಗುತ್ತದೆ
    // ಡೆಕ್ನ ಉದ್ದಕ್ಕಿಂತ ಅರ್ಧಕ್ಕಿಂತ ಕಡಿಮೆ ಇರಲಿ.
    //
    // `wrap_copy` `min(x, cap() - x) + copy_len <= cap()` ಅಗತ್ಯವಿದೆ, ಆದರೆ `min` ಗಿಂತಲೂ ಎಂದಿಗೂ ಸಾಮರ್ಥ್ಯಕ್ಕಿಂತ ಅರ್ಧಕ್ಕಿಂತ ಹೆಚ್ಚಿಲ್ಲ, ಆದ್ದರಿಂದ ಇಲ್ಲಿ ಕರೆ ಮಾಡುವುದು ಉತ್ತಮ ಏಕೆಂದರೆ ನಾವು ಅರ್ಧದಷ್ಟು ಉದ್ದಕ್ಕಿಂತ ಕಡಿಮೆ ಏನನ್ನಾದರೂ ಕರೆಯುತ್ತಿದ್ದೇವೆ, ಅದು ಎಂದಿಗೂ ಅರ್ಧದಷ್ಟು ಸಾಮರ್ಥ್ಯಕ್ಕಿಂತ ಹೆಚ್ಚಿಲ್ಲ.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// ನಿರ್ದಿಷ್ಟ ಅಂಶಕ್ಕಾಗಿ ಬೈನರಿ ಈ ವಿಂಗಡಿಸಲಾದ `VecDeque` ಅನ್ನು ಹುಡುಕುತ್ತದೆ.
    ///
    /// ಮೌಲ್ಯವು ಕಂಡುಬಂದಲ್ಲಿ [`Result::Ok`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ, ಇದು ಹೊಂದಾಣಿಕೆಯ ಅಂಶದ ಸೂಚಿಯನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    /// ಬಹು ಪಂದ್ಯಗಳಿದ್ದರೆ, ಯಾವುದೇ ಒಂದು ಪಂದ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸಬಹುದು.
    /// ಮೌಲ್ಯವು ಕಂಡುಬಂದಿಲ್ಲವಾದರೆ, [`Result::Err`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ, ವಿಂಗಡಿಸಲಾದ ಕ್ರಮವನ್ನು ನಿರ್ವಹಿಸುವಾಗ ಹೊಂದಾಣಿಕೆಯ ಅಂಶವನ್ನು ಸೇರಿಸಬಹುದಾದ ಸೂಚಿಯನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ನಾಲ್ಕು ಅಂಶಗಳ ಸರಣಿಯನ್ನು ಹುಡುಕುತ್ತದೆ.
    /// ಮೊದಲನೆಯದು ಅನನ್ಯವಾಗಿ ನಿರ್ಧರಿಸಲ್ಪಟ್ಟ ಸ್ಥಾನದೊಂದಿಗೆ ಕಂಡುಬರುತ್ತದೆ;ಎರಡನೆಯ ಮತ್ತು ಮೂರನೆಯದು ಕಂಡುಬರುವುದಿಲ್ಲ;ನಾಲ್ಕನೆಯದು `[1, 4]` ನಲ್ಲಿ ಯಾವುದೇ ಸ್ಥಾನಕ್ಕೆ ಹೊಂದಿಕೆಯಾಗಬಹುದು.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// ವಿಂಗಡಿಸಲಾದ ಕ್ರಮವನ್ನು ನಿರ್ವಹಿಸುವಾಗ ನೀವು ವಿಂಗಡಿಸಲಾದ `VecDeque` ಗೆ ಐಟಂ ಅನ್ನು ಸೇರಿಸಲು ಬಯಸಿದರೆ:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// ಬೈನರಿ ಈ ವಿಂಗಡಿಸಲಾದ `VecDeque` ಅನ್ನು ತುಲನಾತ್ಮಕ ಕಾರ್ಯದೊಂದಿಗೆ ಹುಡುಕುತ್ತದೆ.
    ///
    /// ಹೋಲಿಕೆದಾರರ ಕಾರ್ಯವು ಆಧಾರವಾಗಿರುವ `VecDeque` ನ ವಿಂಗಡಣೆಯ ಕ್ರಮಕ್ಕೆ ಅನುಗುಣವಾದ ಆದೇಶವನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಬೇಕು, ಅದರ ಆರ್ಗ್ಯುಮೆಂಟ್ ಅಪೇಕ್ಷಿತ ಗುರಿಗಿಂತ `Less`, `Equal` ಅಥವಾ `Greater` ಎಂಬುದನ್ನು ಸೂಚಿಸುವ ಆದೇಶ ಕೋಡ್ ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// ಮೌಲ್ಯವು ಕಂಡುಬಂದಲ್ಲಿ [`Result::Ok`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ, ಇದು ಹೊಂದಾಣಿಕೆಯ ಅಂಶದ ಸೂಚಿಯನ್ನು ಹೊಂದಿರುತ್ತದೆ.ಬಹು ಪಂದ್ಯಗಳಿದ್ದರೆ, ಯಾವುದೇ ಒಂದು ಪಂದ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸಬಹುದು.
    /// ಮೌಲ್ಯವು ಕಂಡುಬಂದಿಲ್ಲವಾದರೆ, [`Result::Err`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ, ವಿಂಗಡಿಸಲಾದ ಕ್ರಮವನ್ನು ನಿರ್ವಹಿಸುವಾಗ ಹೊಂದಾಣಿಕೆಯ ಅಂಶವನ್ನು ಸೇರಿಸಬಹುದಾದ ಸೂಚಿಯನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ನಾಲ್ಕು ಅಂಶಗಳ ಸರಣಿಯನ್ನು ಹುಡುಕುತ್ತದೆ.ಮೊದಲನೆಯದು ಅನನ್ಯವಾಗಿ ನಿರ್ಧರಿಸಲ್ಪಟ್ಟ ಸ್ಥಾನದೊಂದಿಗೆ ಕಂಡುಬರುತ್ತದೆ;ಎರಡನೆಯ ಮತ್ತು ಮೂರನೆಯದು ಕಂಡುಬರುವುದಿಲ್ಲ;ನಾಲ್ಕನೆಯದು `[1, 4]` ನಲ್ಲಿ ಯಾವುದೇ ಸ್ಥಾನಕ್ಕೆ ಹೊಂದಿಕೆಯಾಗಬಹುದು.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// ಕೀಲಿ ಹೊರತೆಗೆಯುವ ಕಾರ್ಯದೊಂದಿಗೆ ಬೈನರಿ ಈ ವಿಂಗಡಿಸಲಾದ `VecDeque` ಅನ್ನು ಹುಡುಕುತ್ತದೆ.
    ///
    /// `VecDeque` ಅನ್ನು ಕೀಲಿಯಿಂದ ವಿಂಗಡಿಸಲಾಗಿದೆ ಎಂದು umes ಹಿಸುತ್ತದೆ, ಉದಾಹರಣೆಗೆ [`make_contiguous().sort_by_key()`](#method.make_contiguous) ನೊಂದಿಗೆ ಅದೇ ಕೀ ಹೊರತೆಗೆಯುವ ಕಾರ್ಯವನ್ನು ಬಳಸಿ.
    ///
    ///
    /// ಮೌಲ್ಯವು ಕಂಡುಬಂದಲ್ಲಿ [`Result::Ok`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ, ಇದು ಹೊಂದಾಣಿಕೆಯ ಅಂಶದ ಸೂಚಿಯನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    /// ಬಹು ಪಂದ್ಯಗಳಿದ್ದರೆ, ಯಾವುದೇ ಒಂದು ಪಂದ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸಬಹುದು.
    /// ಮೌಲ್ಯವು ಕಂಡುಬಂದಿಲ್ಲವಾದರೆ, [`Result::Err`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ, ವಿಂಗಡಿಸಲಾದ ಕ್ರಮವನ್ನು ನಿರ್ವಹಿಸುವಾಗ ಹೊಂದಾಣಿಕೆಯ ಅಂಶವನ್ನು ಸೇರಿಸಬಹುದಾದ ಸೂಚಿಯನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಜೋಡಿಗಳ ಸ್ಲೈಸ್‌ನಲ್ಲಿ ನಾಲ್ಕು ಅಂಶಗಳ ಸರಣಿಯನ್ನು ಅವುಗಳ ಎರಡನೆಯ ಅಂಶಗಳಿಂದ ವಿಂಗಡಿಸಲಾಗಿದೆ.
    /// ಮೊದಲನೆಯದು ಅನನ್ಯವಾಗಿ ನಿರ್ಧರಿಸಲ್ಪಟ್ಟ ಸ್ಥಾನದೊಂದಿಗೆ ಕಂಡುಬರುತ್ತದೆ;ಎರಡನೆಯ ಮತ್ತು ಮೂರನೆಯದು ಕಂಡುಬರುವುದಿಲ್ಲ;ನಾಲ್ಕನೆಯದು `[1, 4]` ನಲ್ಲಿ ಯಾವುದೇ ಸ್ಥಾನಕ್ಕೆ ಹೊಂದಿಕೆಯಾಗಬಹುದು.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// `VecDeque` ಅನ್ನು ಸ್ಥಳದಲ್ಲಿಯೇ ಮಾರ್ಪಡಿಸುತ್ತದೆ ಇದರಿಂದ `len()` ಹೊಸ_ಲೆನ್‌ಗೆ ಸಮನಾಗಿರುತ್ತದೆ, ಹಿಂಭಾಗದಿಂದ ಹೆಚ್ಚುವರಿ ಅಂಶಗಳನ್ನು ತೆಗೆದುಹಾಕುವುದರ ಮೂಲಕ ಅಥವಾ `value` ನ ತದ್ರೂಪುಗಳನ್ನು ಹಿಂಭಾಗಕ್ಕೆ ಸೇರಿಸುವ ಮೂಲಕ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// ನಿರ್ದಿಷ್ಟ ತಾರ್ಕಿಕ ಅಂಶ ಸೂಚ್ಯಂಕಕ್ಕಾಗಿ ಆಧಾರವಾಗಿರುವ ಬಫರ್‌ನಲ್ಲಿ ಸೂಚ್ಯಂಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // ಗಾತ್ರವು ಯಾವಾಗಲೂ 2 ರ ಶಕ್ತಿಯಾಗಿದೆ
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// ಬಫರ್‌ನಲ್ಲಿ ಓದಲು ಉಳಿದಿರುವ ಅಂಶಗಳ ಸಂಖ್ಯೆಯನ್ನು ಲೆಕ್ಕಹಾಕಿ
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // ಗಾತ್ರವು ಯಾವಾಗಲೂ 2 ರ ಶಕ್ತಿಯಾಗಿದೆ
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // ಯಾವಾಗಲೂ ಮೂರು ವಿಭಾಗಗಳಲ್ಲಿ ಭಾಗಿಸಬಹುದು, ಉದಾಹರಣೆಗೆ: ಸ್ವಯಂ: [a b c|d e f] ಇತರೆ: [0 1 2 3|4 5] ಮುಂಭಾಗ=3, ಮಧ್ಯ=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // As_slices ವಿಧಾನದಿಂದ ಹಿಂತಿರುಗಿಸಲಾದ ಚೂರುಗಳಲ್ಲಿ Hash::hash_slice ಅನ್ನು ಬಳಸುವುದು ಸಾಧ್ಯವಿಲ್ಲ ಏಕೆಂದರೆ ಅವುಗಳ ಉದ್ದವು ಒಂದೇ ರೀತಿಯ ಡೆಕ್‌ಗಳಲ್ಲಿ ಬದಲಾಗಬಹುದು.
        //
        //
        // ಹ್ಯಾಶರ್ ಅದರ ವಿಧಾನಗಳಿಗೆ ಒಂದೇ ರೀತಿಯ ಕರೆಗಳಿಗೆ ಸಮಾನತೆಯನ್ನು ಮಾತ್ರ ಖಾತರಿಪಡಿಸುತ್ತದೆ.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// ಮೌಲ್ಯದಿಂದ ಅಂಶಗಳನ್ನು ನೀಡುವ ಅಂಶಗಳನ್ನು ಮುಂಭಾಗದಿಂದ ಹಿಂದಕ್ಕೆ ಪುನರಾವರ್ತಿಸುವ `VecDeque` ಅನ್ನು ಬಳಸುತ್ತದೆ.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // ಈ ಕಾರ್ಯವು ನೈತಿಕ ಸಮಾನವಾಗಿರಬೇಕು:
        //
        //      iter.into_iter() in ನಲ್ಲಿ ಐಟಂಗಾಗಿ
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// [`Vec<T>`] ಅನ್ನು [`VecDeque<T>`] ಆಗಿ ಪರಿವರ್ತಿಸಿ.
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// ಇದು ಸಾಧ್ಯವಿರುವಲ್ಲಿ ಮರುಹಂಚಿಕೆ ಮಾಡುವುದನ್ನು ತಪ್ಪಿಸುತ್ತದೆ, ಆದರೆ ಅದಕ್ಕಾಗಿ ಷರತ್ತುಗಳು ಕಟ್ಟುನಿಟ್ಟಾಗಿರುತ್ತವೆ ಮತ್ತು ಬದಲಾವಣೆಗೆ ಒಳಪಟ್ಟಿರುತ್ತವೆ, ಮತ್ತು `Vec<T>` `From<VecDeque<T>>` ನಿಂದ ಬಂದು ಮರುಹಂಚಿಕೆ ಮಾಡದ ಹೊರತು ಅದನ್ನು ಅವಲಂಬಿಸಬಾರದು.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // ಸಾಮರ್ಥ್ಯದ ಬಗ್ಗೆ ಚಿಂತೆ ಮಾಡಲು ZST ಗಳಿಗೆ ನಿಜವಾದ ಹಂಚಿಕೆ ಇಲ್ಲ, ಆದರೆ `VecDeque` ಗೆ `Vec` ನಷ್ಟು ಉದ್ದವನ್ನು ನಿಭಾಯಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // ಸಾಮರ್ಥ್ಯವು ಎರಡು ಶಕ್ತಿಯಲ್ಲದಿದ್ದರೆ, ತುಂಬಾ ಚಿಕ್ಕದಾಗಿದೆ ಅಥವಾ ಕನಿಷ್ಠ ಒಂದು ಮುಕ್ತ ಸ್ಥಳವನ್ನು ಹೊಂದಿಲ್ಲದಿದ್ದರೆ ನಾವು ಮರುಗಾತ್ರಗೊಳಿಸಬೇಕಾಗಿದೆ.
            // ಇದು ಇನ್ನೂ `Vec` ನಲ್ಲಿರುವಾಗ ನಾವು ಇದನ್ನು ಮಾಡುತ್ತೇವೆ ಆದ್ದರಿಂದ ವಸ್ತುಗಳು panic ನಲ್ಲಿ ಇಳಿಯುತ್ತವೆ.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// [`VecDeque<T>`] ಅನ್ನು [`Vec<T>`] ಆಗಿ ಪರಿವರ್ತಿಸಿ.
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// ಇದು ಎಂದಿಗೂ ಮರು-ಹಂಚಿಕೆ ಮಾಡುವ ಅಗತ್ಯವಿಲ್ಲ, ಆದರೆ ವೃತ್ತಾಕಾರದ ಬಫರ್ ಹಂಚಿಕೆಯ ಪ್ರಾರಂಭದಲ್ಲಿ ಆಗದಿದ್ದರೆ *O*(*n*) ಡೇಟಾ ಚಲನೆಯನ್ನು ಮಾಡಬೇಕಾಗುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // ಇದು *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // ಇದಕ್ಕೆ ಡೇಟಾ ಮರುಜೋಡಣೆ ಅಗತ್ಯವಿದೆ.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}