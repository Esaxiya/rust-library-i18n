//! ಬೈನರಿ ರಾಶಿಯೊಂದಿಗೆ ಆದ್ಯತೆಯ ಕ್ಯೂ ಅಳವಡಿಸಲಾಗಿದೆ.
//!
//! ಅತಿದೊಡ್ಡ ಅಂಶವನ್ನು ಸೇರಿಸುವುದು ಮತ್ತು ಪಾಪಿಂಗ್ ಮಾಡುವುದು *O*(log(*n*)) ಸಮಯದ ಸಂಕೀರ್ಣತೆಯನ್ನು ಹೊಂದಿರುತ್ತದೆ.
//! ಅತಿದೊಡ್ಡ ಅಂಶವನ್ನು ಪರಿಶೀಲಿಸುವುದು *O*(1).vector ಅನ್ನು ಬೈನರಿ ರಾಶಿಯಾಗಿ ಪರಿವರ್ತಿಸುವುದನ್ನು ಸ್ಥಳದಲ್ಲಿಯೇ ಮಾಡಬಹುದು ಮತ್ತು *O*(*n*) ಸಂಕೀರ್ಣತೆಯನ್ನು ಹೊಂದಿರುತ್ತದೆ.
//! ಬೈನರಿ ರಾಶಿಯನ್ನು ಸ್ಥಳದಲ್ಲಿರುವ ವಿಂಗಡಿಸಲಾದ vector ಗೆ ಪರಿವರ್ತಿಸಬಹುದು, ಇದನ್ನು *O*(*n*\*log(* n*)) ಇನ್-ಪ್ಲೇಸ್ ಹೆಪ್ಸೋರ್ಟ್‌ಗೆ ಬಳಸಲು ಅನುಮತಿಸುತ್ತದೆ.
//!
//! # Examples
//!
//! ಇದು [directed graph][dir_graph] ನಲ್ಲಿ [shortest path problem][sssp] ಅನ್ನು ಪರಿಹರಿಸಲು [Dijkstra's algorithm][dijkstra] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ದೊಡ್ಡ ಉದಾಹರಣೆಯಾಗಿದೆ.
//!
//! ಕಸ್ಟಮ್ ಪ್ರಕಾರಗಳೊಂದಿಗೆ [`BinaryHeap`] ಅನ್ನು ಹೇಗೆ ಬಳಸುವುದು ಎಂಬುದನ್ನು ಇದು ತೋರಿಸುತ್ತದೆ.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // ಆದ್ಯತೆಯ ಕ್ಯೂ `Ord` ಅನ್ನು ಅವಲಂಬಿಸಿರುತ್ತದೆ.
//! // trait ಅನ್ನು ಸ್ಪಷ್ಟವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸಿ ಆದ್ದರಿಂದ ಕ್ಯೂ ಗರಿಷ್ಠ-ರಾಶಿಯ ಬದಲು ನಿಮಿಷ-ರಾಶಿಯಾಗುತ್ತದೆ.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // ನಾವು ವೆಚ್ಚಗಳ ಮೇಲೆ ಆದೇಶವನ್ನು ತಿರುಗಿಸುತ್ತೇವೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
//!         // ನಾವು ಸ್ಥಾನಗಳನ್ನು ಹೋಲಿಸಿದಲ್ಲಿ, `PartialEq` ಮತ್ತು `Ord` ನ ಅನುಷ್ಠಾನಗಳನ್ನು ಸ್ಥಿರಗೊಳಿಸಲು ಈ ಹಂತವು ಅವಶ್ಯಕವಾಗಿದೆ.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` ಕಾರ್ಯಗತಗೊಳಿಸಬೇಕಾಗಿದೆ.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // ಕಡಿಮೆ ಅನುಷ್ಠಾನಕ್ಕಾಗಿ ಪ್ರತಿಯೊಂದು ನೋಡ್ ಅನ್ನು `usize` ಎಂದು ನಿರೂಪಿಸಲಾಗಿದೆ.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // ಡಿಜ್ಕ್‌ಸ್ಟ್ರಾ ಅವರ ಕಡಿಮೆ ಮಾರ್ಗ ಅಲ್ಗಾರಿದಮ್.
//!
//! // ಪ್ರತಿ ನೋಡ್‌ಗೆ ಪ್ರಸ್ತುತ ಕಡಿಮೆ ಅಂತರವನ್ನು ಪತ್ತೆಹಚ್ಚಲು `start` ನಿಂದ ಪ್ರಾರಂಭಿಸಿ ಮತ್ತು `dist` ಬಳಸಿ.ಈ ಅನುಷ್ಠಾನವು ಮೆಮೊರಿ-ಪರಿಣಾಮಕಾರಿಯಲ್ಲ ಏಕೆಂದರೆ ಅದು ನಕಲಿ ನೋಡ್‌ಗಳನ್ನು ಸರದಿಯಲ್ಲಿ ಬಿಡಬಹುದು.
//! //
//! // ಇದು ಸರಳವಾದ ಅನುಷ್ಠಾನಕ್ಕಾಗಿ `usize::MAX` ಅನ್ನು ಸೆಂಟಿನೆಲ್ ಮೌಲ್ಯವಾಗಿ ಬಳಸುತ್ತದೆ.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [ನೋಡ್]= `start` ನಿಂದ `node` ಗೆ ಪ್ರಸ್ತುತ ಕಡಿಮೆ ಅಂತರ
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // ನಾವು ಶೂನ್ಯ ವೆಚ್ಚದೊಂದಿಗೆ `start` ನಲ್ಲಿದ್ದೇವೆ
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // ಮೊದಲ (min-heap) ಕಡಿಮೆ ವೆಚ್ಚದ ನೋಡ್‌ಗಳೊಂದಿಗೆ ಗಡಿಯನ್ನು ಪರೀಕ್ಷಿಸಿ
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // ಪರ್ಯಾಯವಾಗಿ ನಾವು ಎಲ್ಲಾ ಕಡಿಮೆ ಮಾರ್ಗಗಳನ್ನು ಕಂಡುಹಿಡಿಯುವುದನ್ನು ಮುಂದುವರಿಸಬಹುದಿತ್ತು
//!         if position == goal { return Some(cost); }
//!
//!         // ನಾವು ಈಗಾಗಲೇ ಉತ್ತಮ ಮಾರ್ಗವನ್ನು ಕಂಡುಕೊಂಡಿದ್ದರಿಂದ ಮುಖ್ಯ
//!         if cost > dist[position] { continue; }
//!
//!         // ನಾವು ತಲುಪಬಹುದಾದ ಪ್ರತಿ ನೋಡ್‌ಗೆ, ಈ ನೋಡ್ ಮೂಲಕ ಕಡಿಮೆ ವೆಚ್ಚದಲ್ಲಿ ನಾವು ಒಂದು ಮಾರ್ಗವನ್ನು ಕಂಡುಕೊಳ್ಳಬಹುದೇ ಎಂದು ನೋಡಿ
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // ಹಾಗಿದ್ದಲ್ಲಿ, ಅದನ್ನು ಗಡಿನಾಡಿಗೆ ಸೇರಿಸಿ ಮತ್ತು ಮುಂದುವರಿಸಿ
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // ವಿಶ್ರಾಂತಿ, ನಾವು ಈಗ ಉತ್ತಮ ಮಾರ್ಗವನ್ನು ಕಂಡುಕೊಂಡಿದ್ದೇವೆ
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // ಗುರಿ ತಲುಪಲಾಗುವುದಿಲ್ಲ
//!     None
//! }
//!
//! fn main() {
//!     // ಇದು ನಾವು ಬಳಸಲಿರುವ ನಿರ್ದೇಶಿತ ಗ್ರಾಫ್.
//!     // ನೋಡ್ ಸಂಖ್ಯೆಗಳು ವಿಭಿನ್ನ ರಾಜ್ಯಗಳಿಗೆ ಅನುಗುಣವಾಗಿರುತ್ತವೆ, ಮತ್ತು edge ತೂಕವು ಒಂದು ನೋಡ್‌ನಿಂದ ಇನ್ನೊಂದಕ್ಕೆ ಚಲಿಸುವ ವೆಚ್ಚವನ್ನು ಸಂಕೇತಿಸುತ್ತದೆ.
//!     //
//!     // ಅಂಚುಗಳು ಏಕಮುಖವಾಗಿವೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // ಗ್ರಾಫ್ ಅನ್ನು ಪಕ್ಕದ ಪಟ್ಟಿಯಾಗಿ ಪ್ರತಿನಿಧಿಸಲಾಗುತ್ತದೆ, ಅಲ್ಲಿ ಪ್ರತಿ ಸೂಚ್ಯಂಕವು ನೋಡ್ ಮೌಲ್ಯಕ್ಕೆ ಅನುಗುಣವಾಗಿರುತ್ತದೆ, ಹೊರಹೋಗುವ ಅಂಚುಗಳ ಪಟ್ಟಿಯನ್ನು ಹೊಂದಿರುತ್ತದೆ.
//!     // ಅದರ ದಕ್ಷತೆಗಾಗಿ ಆಯ್ಕೆ ಮಾಡಲಾಗಿದೆ.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // ನೋಡ್ 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // ನೋಡ್ 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // ನೋಡ್ 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // ನೋಡ್ 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // ನೋಡ್ 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// ಬೈನರಿ ರಾಶಿಯೊಂದಿಗೆ ಆದ್ಯತೆಯ ಕ್ಯೂ ಅಳವಡಿಸಲಾಗಿದೆ.
///
/// ಇದು ಗರಿಷ್ಠ-ರಾಶಿ ಆಗಿರುತ್ತದೆ.
///
/// `Ord` trait ನಿಂದ ನಿರ್ಧರಿಸಲ್ಪಟ್ಟ ಯಾವುದೇ ವಸ್ತುವಿಗೆ ಹೋಲಿಸಿದರೆ ಐಟಂನ ಆದೇಶವು ರಾಶಿಯಲ್ಲಿರುವಾಗ ಬದಲಾಗುವ ರೀತಿಯಲ್ಲಿ ಮಾರ್ಪಡಿಸುವುದು ತರ್ಕ ದೋಷವಾಗಿದೆ.
///
/// ಇದು ಸಾಮಾನ್ಯವಾಗಿ `Cell`, `RefCell`, ಜಾಗತಿಕ ಸ್ಥಿತಿ, I/O, ಅಥವಾ ಅಸುರಕ್ಷಿತ ಕೋಡ್ ಮೂಲಕ ಮಾತ್ರ ಸಾಧ್ಯ.
/// ಅಂತಹ ತರ್ಕ ದೋಷದಿಂದ ಉಂಟಾಗುವ ನಡವಳಿಕೆಯನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿಲ್ಲ, ಆದರೆ ವಿವರಿಸಲಾಗದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುವುದಿಲ್ಲ.
/// ಇದು panics, ತಪ್ಪಾದ ಫಲಿತಾಂಶಗಳು, ಸ್ಥಗಿತಗೊಳಿಸುವಿಕೆ, ಮೆಮೊರಿ ಸೋರಿಕೆಗಳು ಮತ್ತು ಮುಕ್ತಾಯಗೊಳ್ಳದವುಗಳನ್ನು ಒಳಗೊಂಡಿರಬಹುದು.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // ಟೈಪ್ ಅನುಮಾನವು ಸ್ಪಷ್ಟ ಪ್ರಕಾರದ ಸಹಿಯನ್ನು ಬಿಟ್ಟುಬಿಡಲು ನಮಗೆ ಅನುಮತಿಸುತ್ತದೆ (ಇದು ಈ ಉದಾಹರಣೆಯಲ್ಲಿ `BinaryHeap<i32>` ಆಗಿರುತ್ತದೆ).
/////
/// let mut heap = BinaryHeap::new();
///
/// // ರಾಶಿಯಲ್ಲಿ ಮುಂದಿನ ಐಟಂ ಅನ್ನು ನೋಡಲು ನಾವು ಪೀಕ್ ಅನ್ನು ಬಳಸಬಹುದು.
/// // ಈ ಸಂದರ್ಭದಲ್ಲಿ, ಅಲ್ಲಿ ಇನ್ನೂ ಯಾವುದೇ ವಸ್ತುಗಳು ಇಲ್ಲ ಆದ್ದರಿಂದ ನಾವು ಯಾವುದನ್ನೂ ಪಡೆಯುವುದಿಲ್ಲ.
/// assert_eq!(heap.peek(), None);
///
/// // ಕೆಲವು ಅಂಕಗಳನ್ನು ಸೇರಿಸೋಣ ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // ಈಗ ಪೀಕ್ ರಾಶಿಯಲ್ಲಿನ ಪ್ರಮುಖ ವಸ್ತುವನ್ನು ತೋರಿಸುತ್ತದೆ.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // ನಾವು ರಾಶಿಯ ಉದ್ದವನ್ನು ಪರಿಶೀಲಿಸಬಹುದು.
/// assert_eq!(heap.len(), 3);
///
/// // ರಾಶಿಯಲ್ಲಿರುವ ವಸ್ತುಗಳನ್ನು ಯಾದೃಚ್ order ಿಕ ಕ್ರಮದಲ್ಲಿ ಹಿಂತಿರುಗಿಸಿದರೂ ನಾವು ಅವುಗಳನ್ನು ಪುನರಾವರ್ತಿಸಬಹುದು.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // ನಾವು ಈ ಸ್ಕೋರ್‌ಗಳನ್ನು ಪಾಪ್ ಮಾಡಿದರೆ, ಅವು ಕ್ರಮವಾಗಿ ಹಿಂತಿರುಗಬೇಕು.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // ಉಳಿದಿರುವ ಯಾವುದೇ ವಸ್ತುಗಳ ರಾಶಿಯನ್ನು ನಾವು ತೆರವುಗೊಳಿಸಬಹುದು.
/// heap.clear();
///
/// // ರಾಶಿ ಈಗ ಖಾಲಿಯಾಗಿರಬೇಕು.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// `BinaryHeap` ಅನ್ನು ನಿಮಿಷ-ರಾಶಿಯನ್ನಾಗಿ ಮಾಡಲು `std::cmp::Reverse` ಅಥವಾ ಕಸ್ಟಮ್ `Ord` ಅನುಷ್ಠಾನವನ್ನು ಬಳಸಬಹುದು.
/// ಇದು `heap.pop()` ದೊಡ್ಡದಕ್ಕಿಂತ ಚಿಕ್ಕದಾದ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // `Reverse` ನಲ್ಲಿ ಮೌಲ್ಯಗಳನ್ನು ಕಟ್ಟಿಕೊಳ್ಳಿ
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // ನಾವು ಈಗ ಈ ಸ್ಕೋರ್‌ಗಳನ್ನು ಪಾಪ್ ಮಾಡಿದರೆ, ಅವು ಹಿಮ್ಮುಖ ಕ್ರಮದಲ್ಲಿ ಹಿಂತಿರುಗಬೇಕು.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # ಸಮಯದ ಸಂಕೀರ್ಣತೆ
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// `push` ಗಾಗಿನ ಮೌಲ್ಯವು ನಿರೀಕ್ಷಿತ ವೆಚ್ಚವಾಗಿದೆ;ವಿಧಾನ ದಸ್ತಾವೇಜನ್ನು ಹೆಚ್ಚು ವಿವರವಾದ ವಿಶ್ಲೇಷಣೆಯನ್ನು ನೀಡುತ್ತದೆ.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// `BinaryHeap` ನಲ್ಲಿನ ಶ್ರೇಷ್ಠ ಐಟಂಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಸುತ್ತುವ ರಚನೆ.
///
///
/// ಈ `struct` ಅನ್ನು [`BinaryHeap`] ನಲ್ಲಿ [`peek_mut`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // ಸುರಕ್ಷತೆ: ಖಾಲಿ ಇಲ್ಲದ ರಾಶಿಗಳಿಗೆ ಮಾತ್ರ ಪೀಕ್‌ಮಟ್ ಅನ್ನು ತ್ವರಿತಗೊಳಿಸಲಾಗುತ್ತದೆ.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // ಸುರಕ್ಷಿತ: ಖಾಲಿ ಇಲ್ಲದ ರಾಶಿಗಳಿಗೆ ಮಾತ್ರ ಪೀಕ್‌ಮಟ್ ಅನ್ನು ತ್ವರಿತಗೊಳಿಸಲಾಗುತ್ತದೆ
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // ಸುರಕ್ಷಿತ: ಖಾಲಿ ಇಲ್ಲದ ರಾಶಿಗಳಿಗೆ ಮಾತ್ರ ಪೀಕ್‌ಮಟ್ ಅನ್ನು ತ್ವರಿತಗೊಳಿಸಲಾಗುತ್ತದೆ
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// ರಾಶಿಯಿಂದ ಇಣುಕಿದ ಮೌಲ್ಯವನ್ನು ತೆಗೆದುಹಾಕಿ ಮತ್ತು ಅದನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// ಖಾಲಿ `BinaryHeap<T>` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// ಖಾಲಿ `BinaryHeap` ಅನ್ನು ಗರಿಷ್ಠ-ರಾಶಿಯಾಗಿ ರಚಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// ನಿರ್ದಿಷ್ಟ ಸಾಮರ್ಥ್ಯದೊಂದಿಗೆ ಖಾಲಿ `BinaryHeap` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    /// ಇದು `capacity` ಅಂಶಗಳಿಗೆ ಸಾಕಷ್ಟು ಮೆಮೊರಿಯನ್ನು ಮೊದಲೇ ನಿಗದಿಪಡಿಸುತ್ತದೆ, ಇದರಿಂದಾಗಿ `BinaryHeap` ಅನ್ನು ಕನಿಷ್ಟ ಹಲವು ಮೌಲ್ಯಗಳನ್ನು ಒಳಗೊಂಡಿರುವವರೆಗೆ ಮರುಹಂಚಿಕೆ ಮಾಡಬೇಕಾಗಿಲ್ಲ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// ಬೈನರಿ ರಾಶಿಯಲ್ಲಿನ ಶ್ರೇಷ್ಠ ಐಟಂಗೆ ರೂಪಾಂತರಗೊಳ್ಳುವ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಥವಾ ಅದು ಖಾಲಿಯಾಗಿದ್ದರೆ `None`.
    ///
    /// Note: `PeekMut` ಮೌಲ್ಯವು ಸೋರಿಕೆಯಾಗಿದ್ದರೆ, ರಾಶಿ ಅಸಮಂಜಸ ಸ್ಥಿತಿಯಲ್ಲಿರಬಹುದು.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # ಸಮಯದ ಸಂಕೀರ್ಣತೆ
    ///
    /// ಐಟಂ ಅನ್ನು ಮಾರ್ಪಡಿಸಿದರೆ ಕೆಟ್ಟ ಸಮಯದ ಸಂಕೀರ್ಣತೆ *O*(log(*n*)), ಇಲ್ಲದಿದ್ದರೆ ಅದು *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// ಬೈನರಿ ರಾಶಿಯಿಂದ ದೊಡ್ಡ ಐಟಂ ಅನ್ನು ತೆಗೆದುಹಾಕಿ ಅದನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಅಥವಾ ಅದು ಖಾಲಿಯಾಗಿದ್ದರೆ `None`.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # ಸಮಯದ ಸಂಕೀರ್ಣತೆ
    ///
    /// *N* ಅಂಶಗಳನ್ನು ಹೊಂದಿರುವ ರಾಶಿಯಲ್ಲಿ `pop` ನ ಕೆಟ್ಟ ಪ್ರಕರಣವೆಂದರೆ *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // ಸುರಕ್ಷತೆ: !self.is_empty() ಎಂದರೆ self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// ಬೈನರಿ ರಾಶಿಯ ಮೇಲೆ ಐಟಂ ಅನ್ನು ತಳ್ಳುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # ಸಮಯದ ಸಂಕೀರ್ಣತೆ
    ///
    /// `push` ನ ನಿರೀಕ್ಷಿತ ವೆಚ್ಚ, ಅಂಶಗಳ ತಳ್ಳುವಿಕೆಯ ಪ್ರತಿಯೊಂದು ಕ್ರಮಕ್ಕಿಂತಲೂ ಸರಾಸರಿ ಮತ್ತು ಸಾಕಷ್ಟು ದೊಡ್ಡ ಸಂಖ್ಯೆಯ ತಳ್ಳುವಿಕೆಗಳು *O*(1).
    ///
    /// ಯಾವುದೇ ವಿಂಗಡಿಸಲಾದ ಮಾದರಿಯಲ್ಲಿ ಈಗಾಗಲೇ * ಇಲ್ಲದಿರುವ ಅಂಶಗಳನ್ನು ತಳ್ಳುವಾಗ ಇದು ಅತ್ಯಂತ ಅರ್ಥಪೂರ್ಣವಾದ ವೆಚ್ಚದ ಮೆಟ್ರಿಕ್ ಆಗಿದೆ.
    ///
    /// ಅಂಶಗಳನ್ನು ಪ್ರಧಾನವಾಗಿ ಆರೋಹಣ ಕ್ರಮದಲ್ಲಿ ತಳ್ಳಿದರೆ ಸಮಯದ ಸಂಕೀರ್ಣತೆ ಕುಸಿಯುತ್ತದೆ.
    /// ಕೆಟ್ಟ ಸಂದರ್ಭದಲ್ಲಿ, ಅಂಶಗಳನ್ನು ಆರೋಹಣ ವಿಂಗಡಿಸಲಾದ ಕ್ರಮದಲ್ಲಿ ತಳ್ಳಲಾಗುತ್ತದೆ ಮತ್ತು *n* ಅಂಶಗಳನ್ನು ಹೊಂದಿರುವ ರಾಶಿಯ ವಿರುದ್ಧ ಪ್ರತಿ ಪುಶ್‌ಗೆ ಭೋಗ್ಯ ವೆಚ್ಚ *O*(log(*n*)) ಆಗಿದೆ.
    ///
    /// `push` ಗೆ *ಏಕ* ಕರೆಯ ಕೆಟ್ಟ ಪರಿಸ್ಥಿತಿ *O*(*n*).ಸಾಮರ್ಥ್ಯವು ಖಾಲಿಯಾದಾಗ ಮತ್ತು ಮರುಗಾತ್ರಗೊಳಿಸುವಿಕೆಯ ಅಗತ್ಯವಿರುವಾಗ ಕೆಟ್ಟ ಪ್ರಕರಣ ಸಂಭವಿಸುತ್ತದೆ.
    /// ಮರುಗಾತ್ರಗೊಳಿಸುವಿಕೆಯ ವೆಚ್ಚವನ್ನು ಹಿಂದಿನ ಅಂಕಿ ಅಂಶಗಳಲ್ಲಿ ಭೋಗ್ಯ ಮಾಡಲಾಗಿದೆ.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // ಸುರಕ್ಷತೆ: ನಾವು ಹೊಸ ಐಟಂ ಅನ್ನು ತಳ್ಳಿದ ಕಾರಣ ಇದರ ಅರ್ಥ
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// `BinaryHeap` ಅನ್ನು ಬಳಸುತ್ತದೆ ಮತ್ತು ವಿಂಗಡಿಸಲಾದ (ascending) ಕ್ರಮದಲ್ಲಿ vector ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // ಸುರಕ್ಷತೆ: `end` `self.len() - 1` ನಿಂದ 1 ಕ್ಕೆ ಹೋಗುತ್ತದೆ (ಎರಡೂ ಒಳಗೊಂಡಿದೆ),
            //  ಆದ್ದರಿಂದ ಇದು ಯಾವಾಗಲೂ ಪ್ರವೇಶಿಸಲು ಮಾನ್ಯ ಸೂಚ್ಯಂಕವಾಗಿದೆ.
            //  ಸೂಚ್ಯಂಕ 0 (ಅಂದರೆ `ptr`) ಅನ್ನು ಪ್ರವೇಶಿಸುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ, ಏಕೆಂದರೆ
            //  1 <=end <self.len(), ಅಂದರೆ self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // ಸುರಕ್ಷತೆ: `end` `self.len() - 1` ನಿಂದ 1 ಕ್ಕೆ ಹೋಗುತ್ತದೆ (ಎರಡೂ ಒಳಗೊಂಡಿದೆ) ಆದ್ದರಿಂದ:
            //  0 <1 <=end <= self.len(), 1 <self.len() ಅಂದರೆ 0 <end and end <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Sift_up ಮತ್ತು sift_down ನ ಅನುಷ್ಠಾನಗಳು vector (ರಂಧ್ರದ ಹಿಂದೆ ಬಿಟ್ಟು) ಯಿಂದ ಒಂದು ಅಂಶವನ್ನು ಸರಿಸಲು, ಇತರರ ಉದ್ದಕ್ಕೂ ಸ್ಥಳಾಂತರಿಸಲು ಮತ್ತು ರಂಧ್ರದ ಅಂತಿಮ ಸ್ಥಳದಲ್ಲಿ ತೆಗೆದ ಅಂಶವನ್ನು vector ಗೆ ಸರಿಸಲು ಅಸುರಕ್ಷಿತ ಬ್ಲಾಕ್ಗಳನ್ನು ಬಳಸುತ್ತವೆ.
    //
    // ಇದನ್ನು ಪ್ರತಿನಿಧಿಸಲು `Hole` ಪ್ರಕಾರವನ್ನು ಬಳಸಲಾಗುತ್ತದೆ, ಮತ್ತು panic ನಲ್ಲಿಯೂ ಸಹ, ಅದರ ವ್ಯಾಪ್ತಿಯ ಕೊನೆಯಲ್ಲಿ ರಂಧ್ರವನ್ನು ಮತ್ತೆ ತುಂಬಿಸಲಾಗಿದೆಯೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ.
    // ಸ್ವಾಪ್‌ಗಳನ್ನು ಬಳಸುವುದರೊಂದಿಗೆ ಹೋಲಿಸಿದರೆ ರಂಧ್ರವನ್ನು ಬಳಸುವುದರಿಂದ ಸ್ಥಿರವಾದ ಅಂಶವು ಕಡಿಮೆಯಾಗುತ್ತದೆ, ಇದು ಎರಡು ಪಟ್ಟು ಹೆಚ್ಚು ಚಲನೆಗಳನ್ನು ಒಳಗೊಂಡಿರುತ್ತದೆ.
    //
    //
    //
    //

    /// # Safety
    ///
    /// ಕರೆ ಮಾಡುವವರು `pos < self.len()` ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // `pos` ನಲ್ಲಿ ಮೌಲ್ಯವನ್ನು ತೆಗೆದುಕೊಂಡು ರಂಧ್ರವನ್ನು ರಚಿಸಿ.
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು ಪೋಸ್ <self.len() ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತಾರೆ
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // ಸುರಕ್ಷತೆ: hole.pos()> ಪ್ರಾರಂಭ>=0, ಅಂದರೆ hole.pos()> 0
            //  ಆದ್ದರಿಂದ hole.pos(), 1 ಒಳಹರಿವು ಸಾಧ್ಯವಿಲ್ಲ.
            //  ಇದು ಪೋಷಕ <hole.pos() ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತದೆ ಆದ್ದರಿಂದ ಇದು ಮಾನ್ಯವಾದ ಸೂಚ್ಯಂಕ ಮತ್ತು!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // ಸುರಕ್ಷತೆ: ಮೇಲಿನಂತೆಯೇ
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// `pos` ನಲ್ಲಿ ಒಂದು ಅಂಶವನ್ನು ತೆಗೆದುಕೊಂಡು ಅದನ್ನು ರಾಶಿಯಿಂದ ಕೆಳಕ್ಕೆ ಸರಿಸಿ, ಅದರ ಮಕ್ಕಳು ದೊಡ್ಡದಾಗಿರುತ್ತಾರೆ.
    ///
    ///
    /// # Safety
    ///
    /// ಕರೆ ಮಾಡುವವರು `pos < end <= self.len()` ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು ಪೋಸ್ <ಎಂಡ್ <=ಎಕ್ಸ್‌00 ಎಕ್ಸ್ ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತಾರೆ.
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // ಲೂಪ್ ಅಸ್ಥಿರ: ಮಗು==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // ಸುರಕ್ಷಿತ ಎರಡು ಮಕ್ಕಳೊಂದಿಗೆ ಹೋಲಿಕೆ ಮಾಡಿ: ಮಗು <ಅಂತ್ಯ, 1 <self.len() ಮತ್ತು ಮಗು + 1 <ಅಂತ್ಯ <= self.len(), ಆದ್ದರಿಂದ ಅವು ಮಾನ್ಯ ಸೂಚ್ಯಂಕಗಳಾಗಿವೆ.
            //
            //  ಮಗು==2 *hole.pos() + 1!= hole.pos() ಮತ್ತು ಮಗು + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: T ಒಂದು ZST ಆಗಿದ್ದರೆ 2 *hole.pos() + 1 ಅಥವಾ 2* hole.pos() + 2 ಉಕ್ಕಿ ಹರಿಯಬಹುದು
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // ನಾವು ಈಗಾಗಲೇ ಕ್ರಮದಲ್ಲಿದ್ದರೆ, ನಿಲ್ಲಿಸಿ.
            // ಸುರಕ್ಷತೆ: ಮಗು ಈಗ ಹಳೆಯ ಮಗು ಅಥವಾ ಹಳೆಯ ಮಗು + 1 ಆಗಿದೆ
            //  ಎರಡೂ <self.len() ಮತ್ತು!= hole.pos() ಎಂದು ನಾವು ಈಗಾಗಲೇ ಸಾಬೀತುಪಡಿಸಿದ್ದೇವೆ
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // ಸುರಕ್ಷತೆ: ಮೇಲಿನಂತೆಯೇ.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // ಸುರಕ್ಷತೆ: &&ಶಾರ್ಟ್ ಸರ್ಕ್ಯೂಟ್, ಇದರರ್ಥ
        //  ಎರಡನೆಯ ಸ್ಥಿತಿ ಮಗು==ಅಂತ್ಯ, 1 <self.len() ಎಂಬುದು ಈಗಾಗಲೇ ನಿಜ.
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // ಸುರಕ್ಷತೆ: ಮಗು ಈಗಾಗಲೇ ಮಾನ್ಯ ಸೂಚ್ಯಂಕವೆಂದು ಸಾಬೀತಾಗಿದೆ ಮತ್ತು
            //  ಮಗು==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// ಕರೆ ಮಾಡುವವರು `pos < self.len()` ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // ಸುರಕ್ಷತೆ: ಪೋಸ್ <ಲೆನ್ ಅನ್ನು ಕರೆ ಮಾಡುವವರಿಂದ ಖಾತರಿಪಡಿಸಲಾಗುತ್ತದೆ ಮತ್ತು
        //  ನಿಸ್ಸಂಶಯವಾಗಿ len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// `pos` ನಲ್ಲಿ ಒಂದು ಅಂಶವನ್ನು ತೆಗೆದುಕೊಂಡು ಅದನ್ನು ರಾಶಿಯಿಂದ ಕೆಳಕ್ಕೆ ಸರಿಸಿ, ನಂತರ ಅದನ್ನು ಅದರ ಸ್ಥಾನಕ್ಕೆ ಶೋಧಿಸಿ.
    ///
    ///
    /// Note: ಅಂಶವು ದೊಡ್ಡದಾಗಿದೆ/ಕೆಳಭಾಗಕ್ಕೆ ಹತ್ತಿರವಾಗಬೇಕು ಎಂದು ತಿಳಿದಾಗ ಇದು ವೇಗವಾಗಿರುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// ಕರೆ ಮಾಡುವವರು `pos < self.len()` ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು ಪೋಸ್ <self.len() ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತಾರೆ.
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // ಲೂಪ್ ಅಸ್ಥಿರ: ಮಗು==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // ಸುರಕ್ಷತೆ: ಮಗು <ಅಂತ್ಯ, 1 <self.len() ಮತ್ತು
            //  ಮಗು + 1 <ಅಂತ್ಯ <= self.len(), ಆದ್ದರಿಂದ ಅವು ಮಾನ್ಯ ಸೂಚ್ಯಂಕಗಳಾಗಿವೆ.
            //  ಮಗು==2 *hole.pos() + 1!= hole.pos() ಮತ್ತು ಮಗು + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: T ಒಂದು ZST ಆಗಿದ್ದರೆ 2 *hole.pos() + 1 ಅಥವಾ 2* hole.pos() + 2 ಉಕ್ಕಿ ಹರಿಯಬಹುದು
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // ಸುರಕ್ಷತೆ: ಮೇಲಿನಂತೆಯೇ
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // ಸುರಕ್ಷತೆ: ಮಗು==ಅಂತ್ಯ, 1 <self.len(), ಆದ್ದರಿಂದ ಇದು ಮಾನ್ಯವಾದ ಸೂಚ್ಯಂಕವಾಗಿದೆ
            //  ಮತ್ತು ಮಗು==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // ಸುರಕ್ಷತೆ: pos ಎಂಬುದು ರಂಧ್ರದಲ್ಲಿನ ಸ್ಥಾನ ಮತ್ತು ಈಗಾಗಲೇ ಸಾಬೀತಾಗಿದೆ
        //  ಮಾನ್ಯ ಸೂಚ್ಯಂಕವಾಗಿದೆ.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // ಸುರಕ್ಷತೆ: n self.len()/2 ರಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ ಮತ್ತು 0 ಕ್ಕೆ ಇಳಿಯುತ್ತದೆ.
            //  (N <self.len()) ಎಂಬುದು self.len() ==0 ಆಗಿದ್ದರೆ ಮಾತ್ರ, ಆದರೆ ಅದನ್ನು ಲೂಪ್ ಸ್ಥಿತಿಯಿಂದ ತಳ್ಳಿಹಾಕಲಾಗುತ್ತದೆ.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// `other` ನ ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು `self` ಗೆ ಸರಿಸುತ್ತದೆ, `other` ಖಾಲಿಯಾಗಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` O(len1 + len2) ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ ಮತ್ತು ಸುಮಾರು 2 *(len1 + len2) ಹೋಲಿಕೆಗಳನ್ನು ಕೆಟ್ಟ ಸಂದರ್ಭದಲ್ಲಿ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ, ಆದರೆ `extend` O(len2* log(len1)) ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ ಮತ್ತು ಸುಮಾರು 1 *len2* log_2(len1) ಹೋಲಿಕೆಗಳನ್ನು ಕೆಟ್ಟ ಸಂದರ್ಭದಲ್ಲಿ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ, len1>= len2 ಎಂದು uming ಹಿಸುತ್ತದೆ.
        // ದೊಡ್ಡ ರಾಶಿಗಳಿಗಾಗಿ, ಕ್ರಾಸ್ಒವರ್ ಪಾಯಿಂಟ್ ಇನ್ನು ಮುಂದೆ ಈ ತಾರ್ಕಿಕತೆಯನ್ನು ಅನುಸರಿಸುವುದಿಲ್ಲ ಮತ್ತು ಪ್ರಾಯೋಗಿಕವಾಗಿ ನಿರ್ಧರಿಸಲಾಗುತ್ತದೆ.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// ರಾಶಿ ಕ್ರಮದಲ್ಲಿ ಅಂಶಗಳನ್ನು ಹಿಂಪಡೆಯುವ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಮರುಪಡೆಯಲಾದ ಅಂಶಗಳನ್ನು ಮೂಲ ರಾಶಿಯಿಂದ ತೆಗೆದುಹಾಕಲಾಗುತ್ತದೆ.
    /// ರಾಶಿ ಕ್ರಮದಲ್ಲಿ ಡ್ರಾಪ್ನಲ್ಲಿ ಉಳಿದ ಅಂಶಗಳನ್ನು ತೆಗೆದುಹಾಕಲಾಗುತ್ತದೆ.
    ///
    /// Note:
    /// * `.drain_sorted()` *O*(*n*\*log(* n*)); `.drain()` ಗಿಂತ ನಿಧಾನವಾಗಿರುತ್ತದೆ.
    ///   ಎರಡನೆಯದನ್ನು ನೀವು ಹೆಚ್ಚಿನ ಸಂದರ್ಭಗಳಲ್ಲಿ ಬಳಸಬೇಕು.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // ರಾಶಿ ಕ್ರಮದಲ್ಲಿ ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// ಮುನ್ಸೂಚನೆಯಿಂದ ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಅಂಶಗಳನ್ನು ಮಾತ್ರ ಉಳಿಸಿಕೊಳ್ಳುತ್ತದೆ.
    ///
    /// ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, `e` ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ತೆಗೆದುಹಾಕಿ, ಅಂದರೆ `f(&e)` `false` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    /// ಅಂಶಗಳನ್ನು ವಿಂಗಡಿಸದ (ಮತ್ತು ಅನಿರ್ದಿಷ್ಟ) ಕ್ರಮದಲ್ಲಿ ಭೇಟಿ ನೀಡಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // ಸಮ ಸಂಖ್ಯೆಗಳನ್ನು ಮಾತ್ರ ಇರಿಸಿ
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// ಅನಿಯಂತ್ರಿತ ಕ್ರಮದಲ್ಲಿ ಆಧಾರವಾಗಿರುವ vector ನಲ್ಲಿನ ಎಲ್ಲಾ ಮೌಲ್ಯಗಳಿಗೆ ಭೇಟಿ ನೀಡುವ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // 1, 2, 3, 4 ಅನ್ನು ಅನಿಯಂತ್ರಿತ ಕ್ರಮದಲ್ಲಿ ಮುದ್ರಿಸಿ
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// ರಾಶಿ ಕ್ರಮದಲ್ಲಿ ಅಂಶಗಳನ್ನು ಹಿಂಪಡೆಯುವ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಈ ವಿಧಾನವು ಮೂಲ ರಾಶಿಯನ್ನು ಬಳಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// ಬೈನರಿ ರಾಶಿಯಲ್ಲಿನ ದೊಡ್ಡ ಐಟಂ ಅಥವಾ ಅದು ಖಾಲಿಯಾಗಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # ಸಮಯದ ಸಂಕೀರ್ಣತೆ
    ///
    /// ಕೆಟ್ಟ ಸಂದರ್ಭದಲ್ಲಿ ವೆಚ್ಚವು *ಒ*(1).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// ಮರುಹಂಚಿಕೆ ಮಾಡದೆ ಬೈನರಿ ರಾಶಿ ಹಿಡಿದಿಟ್ಟುಕೊಳ್ಳಬಹುದಾದ ಅಂಶಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// ಕೊಟ್ಟಿರುವ `BinaryHeap` ನಲ್ಲಿ ನಿಖರವಾಗಿ `additional` ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ಸೇರಿಸಲು ಕನಿಷ್ಠ ಸಾಮರ್ಥ್ಯವನ್ನು ಕಾಯ್ದಿರಿಸಲಾಗಿದೆ.
    /// ಸಾಮರ್ಥ್ಯವು ಈಗಾಗಲೇ ಸಾಕಷ್ಟು ಇದ್ದರೆ ಏನನ್ನೂ ಮಾಡುವುದಿಲ್ಲ.
    ///
    /// ಹಂಚಿಕೆದಾರನು ಸಂಗ್ರಹಣೆಗೆ ವಿನಂತಿಸುವುದಕ್ಕಿಂತ ಹೆಚ್ಚಿನ ಸ್ಥಳವನ್ನು ನೀಡಬಹುದು ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    /// ಆದ್ದರಿಂದ ಸಾಮರ್ಥ್ಯವನ್ನು ನಿಖರವಾಗಿ ಕಡಿಮೆ ಎಂದು ಅವಲಂಬಿಸಲಾಗುವುದಿಲ್ಲ.
    /// future ಒಳಸೇರಿಸುವಿಕೆಯನ್ನು ನಿರೀಕ್ಷಿಸಿದ್ದರೆ [`reserve`] ಗೆ ಆದ್ಯತೆ ನೀಡಿ.
    ///
    /// # Panics
    ///
    /// ಹೊಸ ಸಾಮರ್ಥ್ಯವು `usize` ಅನ್ನು ಉಕ್ಕಿ ಹರಿಸಿದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// `BinaryHeap` ನಲ್ಲಿ ಸೇರಿಸಲು ಕನಿಷ್ಠ `additional` ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ಕಾಯ್ದಿರಿಸುವ ಸಾಮರ್ಥ್ಯ.
    /// ಆಗಾಗ್ಗೆ ಮರುಹಂಚಿಕೆಗಳನ್ನು ತಪ್ಪಿಸಲು ಸಂಗ್ರಹವು ಹೆಚ್ಚಿನ ಸ್ಥಳವನ್ನು ಕಾಯ್ದಿರಿಸಬಹುದು.
    ///
    /// # Panics
    ///
    /// ಹೊಸ ಸಾಮರ್ಥ್ಯವು `usize` ಅನ್ನು ಉಕ್ಕಿ ಹರಿಸಿದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// ಸಾಧ್ಯವಾದಷ್ಟು ಹೆಚ್ಚುವರಿ ಸಾಮರ್ಥ್ಯವನ್ನು ತಿರಸ್ಕರಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// ಕಡಿಮೆ ಬೌಂಡ್ ಹೊಂದಿರುವ ಸಾಮರ್ಥ್ಯವನ್ನು ತಿರಸ್ಕರಿಸುತ್ತದೆ.
    ///
    /// ಸಾಮರ್ಥ್ಯವು ಉದ್ದ ಮತ್ತು ಸರಬರಾಜು ಮೌಲ್ಯ ಎರಡರಷ್ಟು ದೊಡ್ಡದಾಗಿರುತ್ತದೆ.
    ///
    ///
    /// ಪ್ರಸ್ತುತ ಸಾಮರ್ಥ್ಯವು ಕಡಿಮೆ ಮಿತಿಗಿಂತ ಕಡಿಮೆಯಿದ್ದರೆ, ಇದು ಯಾವುದೇ ಆಪ್ ಅಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// `BinaryHeap` ಅನ್ನು ಬಳಸುತ್ತದೆ ಮತ್ತು ಆಧಾರವಾಗಿರುವ vector ಅನ್ನು ಅನಿಯಂತ್ರಿತ ಕ್ರಮದಲ್ಲಿ ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // ಕೆಲವು ಕ್ರಮದಲ್ಲಿ ಮುದ್ರಿಸುತ್ತದೆ
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// ಬೈನರಿ ರಾಶಿಯ ಉದ್ದವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// ಬೈನರಿ ರಾಶಿ ಖಾಲಿಯಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ಬೈನರಿ ರಾಶಿಯನ್ನು ತೆರವುಗೊಳಿಸುತ್ತದೆ, ತೆಗೆದುಹಾಕಲಾದ ಅಂಶಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಅಂಶಗಳನ್ನು ಅನಿಯಂತ್ರಿತ ಕ್ರಮದಲ್ಲಿ ತೆಗೆದುಹಾಕಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// ಬೈನರಿ ರಾಶಿಯಿಂದ ಎಲ್ಲಾ ವಸ್ತುಗಳನ್ನು ಬೀಳಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// ರಂಧ್ರವು ಸ್ಲೈಸ್‌ನಲ್ಲಿರುವ ರಂಧ್ರವನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ, ಅಂದರೆ ಮಾನ್ಯ ಮೌಲ್ಯವಿಲ್ಲದ ಸೂಚ್ಯಂಕ (ಏಕೆಂದರೆ ಅದನ್ನು ಸರಿಸಲಾಗಿದೆ ಅಥವಾ ನಕಲು ಮಾಡಲಾಗಿದೆ).
///
/// ಡ್ರಾಪ್‌ನಲ್ಲಿ, ಮೂಲತಃ ತೆಗೆದುಹಾಕಲಾದ ಮೌಲ್ಯದೊಂದಿಗೆ ರಂಧ್ರದ ಸ್ಥಾನವನ್ನು ತುಂಬುವ ಮೂಲಕ `Hole` ಸ್ಲೈಸ್ ಅನ್ನು ಪುನಃಸ್ಥಾಪಿಸುತ್ತದೆ.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// ಸೂಚ್ಯಂಕ `pos` ನಲ್ಲಿ ಹೊಸ `Hole` ಅನ್ನು ರಚಿಸಿ.
    ///
    /// ಅಸುರಕ್ಷಿತ ಏಕೆಂದರೆ ಪಿಒಎಸ್ ಡೇಟಾ ಸ್ಲೈಸ್‌ನಲ್ಲಿರಬೇಕು.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // ಸುರಕ್ಷಿತ: ಪೋಸ್ ಸ್ಲೈಸ್ ಒಳಗೆ ಇರಬೇಕು
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// ತೆಗೆದುಹಾಕಲಾದ ಅಂಶದ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// `index` ನಲ್ಲಿರುವ ಅಂಶದ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಅಸುರಕ್ಷಿತ ಏಕೆಂದರೆ ಸೂಚ್ಯಂಕವು ಡೇಟಾ ಸ್ಲೈಸ್‌ನೊಳಗೆ ಇರಬೇಕು ಮತ್ತು ಪೋಸ್‌ಗೆ ಸಮನಾಗಿರಬಾರದು.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// ರಂಧ್ರವನ್ನು ಹೊಸ ಸ್ಥಳಕ್ಕೆ ಸರಿಸಿ
    ///
    /// ಅಸುರಕ್ಷಿತ ಏಕೆಂದರೆ ಸೂಚ್ಯಂಕವು ಡೇಟಾ ಸ್ಲೈಸ್‌ನೊಳಗೆ ಇರಬೇಕು ಮತ್ತು ಪೋಸ್‌ಗೆ ಸಮನಾಗಿರಬಾರದು.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // ರಂಧ್ರವನ್ನು ಮತ್ತೆ ತುಂಬಿಸಿ
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// `BinaryHeap` ನ ಅಂಶಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ.
///
/// ಈ `struct` ಅನ್ನು [`BinaryHeap::iter()`] ನಿಂದ ರಚಿಸಲಾಗಿದೆ.
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) `#[derive(Clone)]` ಪರವಾಗಿ ತೆಗೆದುಹಾಕಿ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// `BinaryHeap` ನ ಅಂಶಗಳ ಮೇಲೆ ಮಾಲೀಕತ್ವದ ಪುನರಾವರ್ತಕ.
///
/// ಈ `struct` ಅನ್ನು [`BinaryHeap::into_iter()`] ನಿಂದ ರಚಿಸಲಾಗಿದೆ (`IntoIterator` trait ನಿಂದ ಒದಗಿಸಲಾಗಿದೆ).
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// `BinaryHeap` ನ ಅಂಶಗಳ ಮೇಲೆ ಬರಿದಾಗುತ್ತಿರುವ ಪುನರಾವರ್ತಕ.
///
/// ಈ `struct` ಅನ್ನು [`BinaryHeap::drain()`] ನಿಂದ ರಚಿಸಲಾಗಿದೆ.
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// `BinaryHeap` ನ ಅಂಶಗಳ ಮೇಲೆ ಬರಿದಾಗುತ್ತಿರುವ ಪುನರಾವರ್ತಕ.
///
/// ಈ `struct` ಅನ್ನು [`BinaryHeap::drain_sorted()`] ನಿಂದ ರಚಿಸಲಾಗಿದೆ.
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// ರಾಶಿ ಕ್ರಮದಲ್ಲಿ ರಾಶಿ ಅಂಶಗಳನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// `Vec<T>` ಅನ್ನು `BinaryHeap<T>` ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ಈ ಪರಿವರ್ತನೆಯು ಸ್ಥಳದಲ್ಲಿಯೇ ನಡೆಯುತ್ತದೆ ಮತ್ತು *O*(*n*) ಸಮಯದ ಸಂಕೀರ್ಣತೆಯನ್ನು ಹೊಂದಿದೆ.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// `BinaryHeap<T>` ಅನ್ನು `Vec<T>` ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ಈ ಪರಿವರ್ತನೆಗೆ ಯಾವುದೇ ಡೇಟಾ ಚಲನೆ ಅಥವಾ ಹಂಚಿಕೆ ಅಗತ್ಯವಿಲ್ಲ, ಮತ್ತು ಸ್ಥಿರ ಸಮಯದ ಸಂಕೀರ್ಣತೆಯನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// ಸೇವಿಸುವ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ, ಅಂದರೆ, ಪ್ರತಿ ಮೌಲ್ಯವನ್ನು ಬೈನರಿ ರಾಶಿಯಿಂದ ಅನಿಯಂತ್ರಿತ ಕ್ರಮದಲ್ಲಿ ಚಲಿಸುತ್ತದೆ.
    /// ಇದನ್ನು ಕರೆದ ನಂತರ ಬೈನರಿ ರಾಶಿಯನ್ನು ಬಳಸಲಾಗುವುದಿಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // 1, 2, 3, 4 ಅನ್ನು ಅನಿಯಂತ್ರಿತ ಕ್ರಮದಲ್ಲಿ ಮುದ್ರಿಸಿ
    /// for x in heap.into_iter() {
    ///     // x ಪ್ರಕಾರವು i32 ಅನ್ನು ಹೊಂದಿದೆ, &i32 ಅಲ್ಲ
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}