use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// `Bound::Included(T)` ನಂತೆಯೇ ನೋಡಲು ಒಂದು ಅಂತರ್ಗತ ಬೌಂಡ್.
    Included(T),
    /// `Bound::Excluded(T)` ನಂತೆಯೇ ನೋಡಲು ವಿಶೇಷವಾದ ಬೌಂಡ್.
    Excluded(T),
    /// `Bound::Unbounded` ನಂತೆಯೇ ಬೇಷರತ್ತಾದ ಅಂತರ್ಗತ ಬೌಂಡ್.
    AllIncluded,
    /// ಬೇಷರತ್ತಾದ ವಿಶೇಷ ಬೌಂಡ್.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// ನಿರ್ದಿಷ್ಟ ಕೀಲಿಯನ್ನು ನೋಡ್ ನೇತೃತ್ವದ (ಉಪ) ಮರದಲ್ಲಿ ಪುನರಾವರ್ತಿತವಾಗಿ ನೋಡುತ್ತದೆ.
    /// ಹೊಂದಾಣಿಕೆಯ ಕೆವಿಯ ಹ್ಯಾಂಡಲ್ನೊಂದಿಗೆ `Found` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಇಲ್ಲದಿದ್ದರೆ, ಕೀ ಸೇರಿದ edge ಎಲೆಯ ಹ್ಯಾಂಡಲ್‌ನೊಂದಿಗೆ `GoDown` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `BTreeMap` ನಲ್ಲಿರುವ ಮರದಂತೆ ಮರವನ್ನು ಕೀಲಿಯಿಂದ ಆದೇಶಿಸಿದರೆ ಮಾತ್ರ ಫಲಿತಾಂಶವು ಅರ್ಥಪೂರ್ಣವಾಗಿರುತ್ತದೆ.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// ಹತ್ತಿರದ ನೋಡ್‌ಗೆ ಇಳಿಯುತ್ತದೆ, ಅಲ್ಲಿ ಶ್ರೇಣಿಯ ಕೆಳಗಿನ ಬೌಂಡ್‌ಗೆ ಹೊಂದಿಕೆಯಾಗುವ edge ಮೇಲಿನ ಬೌಂಡ್‌ಗೆ ಹೊಂದಿಕೆಯಾಗುವ edge ನಿಂದ ಭಿನ್ನವಾಗಿರುತ್ತದೆ, ಅಂದರೆ, ವ್ಯಾಪ್ತಿಯಲ್ಲಿ ಕನಿಷ್ಠ ಒಂದು ಕೀಲಿಯನ್ನು ಹೊಂದಿರುವ ಹತ್ತಿರದ ನೋಡ್.
    ///
    ///
    /// ಕಂಡುಬಂದಲ್ಲಿ, ಆ ನೋಡ್‌ನೊಂದಿಗೆ `Ok` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಅದರಲ್ಲಿರುವ edge ಸೂಚ್ಯಂಕಗಳು ಶ್ರೇಣಿಯನ್ನು ಡಿಲಿಮಿಟ್ ಮಾಡುತ್ತವೆ ಮತ್ತು ಮಕ್ಕಳ ನೋಡ್‌ಗಳಲ್ಲಿ ಹುಡುಕಾಟವನ್ನು ಮುಂದುವರೆಸಲು ಅನುಗುಣವಾದ ಜೋಡಿ ಗಡಿಗಳು, ನೋಡ್ ಆಂತರಿಕವಾಗಿದ್ದರೆ.
    ///
    /// ಕಂಡುಬಂದಿಲ್ಲವಾದರೆ, ಸಂಪೂರ್ಣ ಶ್ರೇಣಿಗೆ ಹೊಂದಿಕೆಯಾಗುವ edge ಎಲೆಯೊಂದಿಗೆ `Err` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಮರವನ್ನು ಕೀಲಿಯಿಂದ ಆದೇಶಿಸಿದರೆ ಮಾತ್ರ ಫಲಿತಾಂಶವು ಅರ್ಥಪೂರ್ಣವಾಗಿರುತ್ತದೆ.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // ಈ ಅಸ್ಥಿರಗಳನ್ನು ಒಳಗೊಳ್ಳುವುದನ್ನು ತಪ್ಪಿಸಬೇಕು.
        // `range` ವರದಿ ಮಾಡಿದ ಗಡಿರೇಖೆಗಳು ಒಂದೇ ಆಗಿರುತ್ತವೆ ಎಂದು ನಾವು ume ಹಿಸುತ್ತೇವೆ, ಆದರೆ (#81138) ಕರೆಗಳ ನಡುವೆ ವಿರೋಧಿ ಅನುಷ್ಠಾನವು ಬದಲಾಗಬಹುದು.
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// ಒಂದು ಶ್ರೇಣಿಯ ಕೆಳಗಿನ ಪರಿಮಿತಿಯನ್ನು ಡಿಲಿಮಿಟ್ ಮಾಡುವ ನೋಡ್‌ನಲ್ಲಿ edge ಅನ್ನು ಹುಡುಕುತ್ತದೆ.
    /// `self` ಆಂತರಿಕ ನೋಡ್ ಆಗಿದ್ದರೆ, ಹೊಂದಾಣಿಕೆಯ ಮಕ್ಕಳ ನೋಡ್‌ನಲ್ಲಿ ಹುಡುಕಾಟವನ್ನು ಮುಂದುವರಿಸಲು ಬಳಸಬೇಕಾದ ಕಡಿಮೆ ಬೌಂಡ್ ಅನ್ನು ಸಹ ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// ಮರವನ್ನು ಕೀಲಿಯಿಂದ ಆದೇಶಿಸಿದರೆ ಮಾತ್ರ ಫಲಿತಾಂಶವು ಅರ್ಥಪೂರ್ಣವಾಗಿರುತ್ತದೆ.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// ಮೇಲಿನ ಬೌಂಡ್ಗಾಗಿ `find_lower_bound_edge` ನ ಕ್ಲೋನ್.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// ಪುನರಾವರ್ತನೆಯಿಲ್ಲದೆ ನೋಡ್‌ನಲ್ಲಿ ಕೊಟ್ಟಿರುವ ಕೀಲಿಯನ್ನು ಹುಡುಕುತ್ತದೆ.
    /// ಹೊಂದಾಣಿಕೆಯ ಕೆವಿಯ ಹ್ಯಾಂಡಲ್ನೊಂದಿಗೆ `Found` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಇಲ್ಲದಿದ್ದರೆ, edge ನ ಹ್ಯಾಂಡಲ್‌ನೊಂದಿಗೆ `GoDown` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಲ್ಲಿ ಕೀಲಿಯನ್ನು ಕಂಡುಹಿಡಿಯಬಹುದು (ನೋಡ್ ಆಂತರಿಕವಾಗಿದ್ದರೆ) ಅಥವಾ ಕೀಲಿಯನ್ನು ಎಲ್ಲಿ ಸೇರಿಸಬಹುದು.
    ///
    ///
    /// `BTreeMap` ನಲ್ಲಿರುವ ಮರದಂತೆ ಮರವನ್ನು ಕೀಲಿಯಿಂದ ಆದೇಶಿಸಿದರೆ ಮಾತ್ರ ಫಲಿತಾಂಶವು ಅರ್ಥಪೂರ್ಣವಾಗಿರುತ್ತದೆ.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// ಕೀಲಿ (ಅಥವಾ ಸಮಾನ) ಇರುವ ನೋಡ್‌ನಲ್ಲಿರುವ ಕೆವಿ ಸೂಚ್ಯಂಕ ಅಥವಾ ಕೀ ಸೇರಿದ edge ಸೂಚಿಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// `BTreeMap` ನಲ್ಲಿರುವ ಮರದಂತೆ ಮರವನ್ನು ಕೀಲಿಯಿಂದ ಆದೇಶಿಸಿದರೆ ಮಾತ್ರ ಫಲಿತಾಂಶವು ಅರ್ಥಪೂರ್ಣವಾಗಿರುತ್ತದೆ.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// ಒಂದು ಶ್ರೇಣಿಯ ಕೆಳಗಿನ ಪರಿಮಿತಿಯನ್ನು ಡಿಲಿಮಿಟ್ ಮಾಡುವ ನೋಡ್‌ನಲ್ಲಿ edge ಸೂಚಿಯನ್ನು ಹುಡುಕುತ್ತದೆ.
    /// `self` ಆಂತರಿಕ ನೋಡ್ ಆಗಿದ್ದರೆ, ಹೊಂದಾಣಿಕೆಯ ಮಕ್ಕಳ ನೋಡ್‌ನಲ್ಲಿ ಹುಡುಕಾಟವನ್ನು ಮುಂದುವರಿಸಲು ಬಳಸಬೇಕಾದ ಕಡಿಮೆ ಬೌಂಡ್ ಅನ್ನು ಸಹ ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// ಮರವನ್ನು ಕೀಲಿಯಿಂದ ಆದೇಶಿಸಿದರೆ ಮಾತ್ರ ಫಲಿತಾಂಶವು ಅರ್ಥಪೂರ್ಣವಾಗಿರುತ್ತದೆ.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// ಮೇಲಿನ ಬೌಂಡ್ಗಾಗಿ `find_lower_bound_index` ನ ಕ್ಲೋನ್.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}