use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef};

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    /// ಮರದಿಂದ ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿಯನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ, ಮತ್ತು ಆ ಜೋಡಿಯನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಜೊತೆಗೆ ಹಿಂದಿನ ಜೋಡಿಗೆ ಅನುಗುಣವಾದ edge ಎಲೆ.
    /// ಇದು ಆಂತರಿಕವಾಗಿರುವ ರೂಟ್ ನೋಡ್ ಅನ್ನು ಖಾಲಿ ಮಾಡುವ ಸಾಧ್ಯತೆಯಿದೆ, ಮರವನ್ನು ಹಿಡಿದಿರುವ ನಕ್ಷೆಯಿಂದ ಕರೆ ಮಾಡುವವರು ಪಾಪ್ ಮಾಡಬೇಕು.
    /// ಕರೆ ಮಾಡುವವರು ನಕ್ಷೆಯ ಉದ್ದವನ್ನು ಸಹ ಕಡಿಮೆ ಮಾಡಬೇಕು.
    ///
    pub fn remove_kv_tracking<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        match self.force() {
            Leaf(node) => node.remove_leaf_kv(handle_emptied_internal_root),
            Internal(node) => node.remove_internal_kv(handle_emptied_internal_root),
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    fn remove_leaf_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let (old_kv, mut pos) = self.remove();
        let len = pos.reborrow().into_node().len();
        if len < MIN_LEN {
            let idx = pos.idx();
            // ನಾವು ಮಗುವಿನ ಪ್ರಕಾರವನ್ನು ತಾತ್ಕಾಲಿಕವಾಗಿ ಮರೆತುಬಿಡಬೇಕು, ಏಕೆಂದರೆ ಎಲೆಯ ತಕ್ಷಣದ ಪೋಷಕರಿಗೆ ಯಾವುದೇ ವಿಶಿಷ್ಟವಾದ ನೋಡ್ ಪ್ರಕಾರವಿಲ್ಲ.
            //
            let new_pos = match pos.into_node().forget_type().choose_parent_kv() {
                Ok(Left(left_parent_kv)) => {
                    debug_assert!(left_parent_kv.right_child_len() == MIN_LEN - 1);
                    if left_parent_kv.can_merge() {
                        left_parent_kv.merge_tracking_child_edge(Right(idx))
                    } else {
                        debug_assert!(left_parent_kv.left_child_len() > MIN_LEN);
                        left_parent_kv.steal_left(idx)
                    }
                }
                Ok(Right(right_parent_kv)) => {
                    debug_assert!(right_parent_kv.left_child_len() == MIN_LEN - 1);
                    if right_parent_kv.can_merge() {
                        right_parent_kv.merge_tracking_child_edge(Left(idx))
                    } else {
                        debug_assert!(right_parent_kv.right_child_len() > MIN_LEN);
                        right_parent_kv.steal_right(idx)
                    }
                }
                Err(pos) => unsafe { Handle::new_edge(pos, idx) },
            };
            // ಸುರಕ್ಷತೆ: `new_pos` ಎಂಬುದು ನಾವು ಪ್ರಾರಂಭಿಸಿದ ಎಲೆ ಅಥವಾ ಒಡಹುಟ್ಟಿದವನು.
            pos = unsafe { new_pos.cast_to_leaf_unchecked() };

            // ನಾವು ವಿಲೀನಗೊಂಡರೆ ಮಾತ್ರ, ಪೋಷಕರು (ಯಾವುದಾದರೂ ಇದ್ದರೆ) ಕುಗ್ಗಿದ್ದಾರೆ, ಆದರೆ ಈ ಕೆಳಗಿನ ಹಂತವನ್ನು ಬಿಟ್ಟುಬಿಡುವುದು ಇಲ್ಲದಿದ್ದರೆ ಮಾನದಂಡಗಳಲ್ಲಿ ಪಾವತಿಸುವುದಿಲ್ಲ.
            //
            // ಸುರಕ್ಷತೆ: ನಾವು `pos` ಇರುವ ಎಲೆಯನ್ನು ನಾಶಪಡಿಸುವುದಿಲ್ಲ ಅಥವಾ ಮರುಹೊಂದಿಸುವುದಿಲ್ಲ
            // ಅದರ ಪೋಷಕರನ್ನು ಪುನರಾವರ್ತಿತವಾಗಿ ನಿರ್ವಹಿಸುವ ಮೂಲಕ;ಕೆಟ್ಟದಾಗಿ ನಾವು ಅಜ್ಜಿಯ ಮೂಲಕ ಪೋಷಕರನ್ನು ನಾಶಪಡಿಸುತ್ತೇವೆ ಅಥವಾ ಮರುಹೊಂದಿಸುತ್ತೇವೆ, ಹೀಗಾಗಿ ಎಲೆಯೊಳಗಿನ ಪೋಷಕರಿಗೆ ಲಿಂಕ್ ಅನ್ನು ಬದಲಾಯಿಸುತ್ತೇವೆ.
            //
            //
            //
            if let Ok(parent) = unsafe { pos.reborrow_mut() }.into_node().ascend() {
                if !parent.into_node().forget_type().fix_node_and_affected_ancestors() {
                    handle_emptied_internal_root();
                }
            }
        }
        (old_kv, pos)
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    fn remove_internal_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        // ಅದರ ಎಲೆಯಿಂದ ಪಕ್ಕದ ಕೆವಿಯನ್ನು ತೆಗೆದುಹಾಕಿ ಮತ್ತು ನಂತರ ಅದನ್ನು ತೆಗೆದುಹಾಕಲು ನಾವು ಕೇಳಿದ ಅಂಶದ ಸ್ಥಳದಲ್ಲಿ ಇರಿಸಿ.
        //
        // `choose_parent_kv` ನಲ್ಲಿ ಪಟ್ಟಿ ಮಾಡಲಾದ ಕಾರಣಗಳಿಗಾಗಿ ಎಡ ಪಕ್ಕದ KV ಗೆ ಆದ್ಯತೆ ನೀಡಿ.
        let left_leaf_kv = self.left_edge().descend().last_leaf_edge().left_kv();
        let left_leaf_kv = unsafe { left_leaf_kv.ok().unwrap_unchecked() };
        let (left_kv, left_hole) = left_leaf_kv.remove_leaf_kv(handle_emptied_internal_root);

        // ಆಂತರಿಕ ನೋಡ್ ಅನ್ನು ಕದ್ದಿರಬಹುದು ಅಥವಾ ವಿಲೀನಗೊಳಿಸಿರಬಹುದು.
        // ಮೂಲ ಕೆವಿ ಎಲ್ಲಿ ಕೊನೆಗೊಂಡಿತು ಎಂಬುದನ್ನು ಕಂಡುಹಿಡಿಯಲು ಬಲಕ್ಕೆ ಹಿಂತಿರುಗಿ.
        let mut internal = unsafe { left_hole.next_kv().ok().unwrap_unchecked() };
        let old_kv = internal.replace_kv(left_kv.0, left_kv.1);
        let pos = internal.next_leaf_edge();
        (old_kv, pos)
    }
}