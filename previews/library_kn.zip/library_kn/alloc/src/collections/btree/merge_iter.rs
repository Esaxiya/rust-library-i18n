use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::iter::FusedIterator;

/// ಎರಡು ಕಟ್ಟುನಿಟ್ಟಾಗಿ ಆರೋಹಣ ಪುನರಾವರ್ತಕಗಳ output ಟ್‌ಪುಟ್ ಅನ್ನು ವಿಲೀನಗೊಳಿಸುವ ಪುನರಾವರ್ತಕನ ಕೋರ್, ಉದಾಹರಣೆಗೆ ಯೂನಿಯನ್ ಅಥವಾ ಸಮ್ಮಿತೀಯ ವ್ಯತ್ಯಾಸ.
///
pub struct MergeIterInner<I: Iterator> {
    a: I,
    b: I,
    peeked: Option<Peeked<I>>,
}

/// ಎರಡೂ ಪುನರಾವರ್ತಕಗಳನ್ನು ಪೀಕಬಲ್‌ನಲ್ಲಿ ಸುತ್ತಿಕೊಳ್ಳುವುದಕ್ಕಿಂತ ವೇಗವಾಗಿ ಮಾನದಂಡಗಳು, ಬಹುಶಃ ನಾವು ಫ್ಯೂಸ್ಡ್ಇಟರೇಟರ್ ಅನ್ನು ವಿಧಿಸಲು ಶಕ್ತರಾಗಬಹುದು.
///
#[derive(Clone, Debug)]
enum Peeked<I: Iterator> {
    A(I::Item),
    B(I::Item),
}

impl<I: Iterator> Clone for MergeIterInner<I>
where
    I: Clone,
    I::Item: Clone,
{
    fn clone(&self) -> Self {
        Self { a: self.a.clone(), b: self.b.clone(), peeked: self.peeked.clone() }
    }
}

impl<I: Iterator> Debug for MergeIterInner<I>
where
    I: Debug,
    I::Item: Debug,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("MergeIterInner").field(&self.a).field(&self.b).field(&self.peeked).finish()
    }
}

impl<I: Iterator> MergeIterInner<I> {
    /// ಒಂದು ಜೋಡಿ ಮೂಲಗಳನ್ನು ವಿಲೀನಗೊಳಿಸುವ ಪುನರಾವರ್ತಕಕ್ಕಾಗಿ ಹೊಸ ಕೋರ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    pub fn new(a: I, b: I) -> Self {
        MergeIterInner { a, b, peeked: None }
    }

    /// ವಿಲೀನಗೊಳ್ಳುತ್ತಿರುವ ಮೂಲಗಳ ಜೋಡಿಯಿಂದ ಉಂಟಾಗುವ ಮುಂದಿನ ಜೋಡಿ ವಸ್ತುಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಹಿಂದಿರುಗಿದ ಎರಡೂ ಆಯ್ಕೆಗಳು ಮೌಲ್ಯವನ್ನು ಹೊಂದಿದ್ದರೆ, ಆ ಮೌಲ್ಯವು ಸಮಾನವಾಗಿರುತ್ತದೆ ಮತ್ತು ಎರಡೂ ಮೂಲಗಳಲ್ಲಿ ಸಂಭವಿಸುತ್ತದೆ.
    /// ಹಿಂದಿರುಗಿದ ಆಯ್ಕೆಗಳಲ್ಲಿ ಒಂದು ಮೌಲ್ಯವನ್ನು ಹೊಂದಿದ್ದರೆ, ಆ ಮೌಲ್ಯವು ಇತರ ಮೂಲದಲ್ಲಿ ಸಂಭವಿಸುವುದಿಲ್ಲ (ಅಥವಾ ಮೂಲಗಳು ಕಟ್ಟುನಿಟ್ಟಾಗಿ ಆರೋಹಣವಾಗುವುದಿಲ್ಲ).
    ///
    /// ಹಿಂದಿರುಗಿದ ಯಾವುದೇ ಆಯ್ಕೆಯು ಮೌಲ್ಯವನ್ನು ಹೊಂದಿಲ್ಲದಿದ್ದರೆ, ಪುನರಾವರ್ತನೆ ಮುಗಿದಿದೆ ಮತ್ತು ನಂತರದ ಕರೆಗಳು ಅದೇ ಖಾಲಿ ಜೋಡಿಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    pub fn nexts<Cmp: Fn(&I::Item, &I::Item) -> Ordering>(
        &mut self,
        cmp: Cmp,
    ) -> (Option<I::Item>, Option<I::Item>)
    where
        I: FusedIterator,
    {
        let mut a_next;
        let mut b_next;
        match self.peeked.take() {
            Some(Peeked::A(next)) => {
                a_next = Some(next);
                b_next = self.b.next();
            }
            Some(Peeked::B(next)) => {
                b_next = Some(next);
                a_next = self.a.next();
            }
            None => {
                a_next = self.a.next();
                b_next = self.b.next();
            }
        }
        if let (Some(ref a1), Some(ref b1)) = (&a_next, &b_next) {
            match cmp(a1, b1) {
                Ordering::Less => self.peeked = b_next.take().map(Peeked::B),
                Ordering::Greater => self.peeked = a_next.take().map(Peeked::A),
                Ordering::Equal => (),
            }
        }
        (a_next, b_next)
    }

    /// ಅಂತಿಮ ಪುನರಾವರ್ತಕದ `size_hint` ಗಾಗಿ ಒಂದು ಜೋಡಿ ಮೇಲಿನ ಗಡಿಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    pub fn lens(&self) -> (usize, usize)
    where
        I: ExactSizeIterator,
    {
        match self.peeked {
            Some(Peeked::A(_)) => (1 + self.a.len(), self.b.len()),
            Some(Peeked::B(_)) => (self.a.len(), 1 + self.b.len()),
            _ => (self.a.len(), self.b.len()),
        }
    }
}