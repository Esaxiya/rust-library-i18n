use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// ಎರಡು ಆರೋಹಣ ಪುನರಾವರ್ತಕರ ಒಕ್ಕೂಟದಿಂದ ಎಲ್ಲಾ ಕೀ-ಮೌಲ್ಯ ಜೋಡಿಗಳನ್ನು ಸೇರಿಸುತ್ತದೆ, ದಾರಿಯುದ್ದಕ್ಕೂ `length` ವೇರಿಯೇಬಲ್ ಅನ್ನು ಹೆಚ್ಚಿಸುತ್ತದೆ.ಡ್ರಾಪ್ ಹ್ಯಾಂಡ್ಲರ್ ಭಯಭೀತರಾದಾಗ ಸೋರಿಕೆಯನ್ನು ತಪ್ಪಿಸಲು ಕರೆ ಮಾಡುವವರಿಗೆ ಸುಲಭವಾಗುತ್ತದೆ.
    ///
    /// ಎರಡೂ ಪುನರಾವರ್ತಕಗಳು ಒಂದೇ ಕೀಲಿಯನ್ನು ಉತ್ಪಾದಿಸಿದರೆ, ಈ ವಿಧಾನವು ಜೋಡಿಯನ್ನು ಎಡ ಪುನರಾವರ್ತಕದಿಂದ ಇಳಿಸುತ್ತದೆ ಮತ್ತು ಜೋಡಿಯನ್ನು ಬಲ ಪುನರಾವರ್ತಕದಿಂದ ಸೇರಿಸುತ್ತದೆ.
    ///
    /// `BTreeMap` ನಂತೆ ಮರವು ಕಟ್ಟುನಿಟ್ಟಾಗಿ ಆರೋಹಣ ಕ್ರಮದಲ್ಲಿ ಕೊನೆಗೊಳ್ಳಬೇಕೆಂದು ನೀವು ಬಯಸಿದರೆ, ಎರಡೂ ಪುನರಾವರ್ತಕರು ಕೀಲಿಗಳನ್ನು ಕಟ್ಟುನಿಟ್ಟಾಗಿ ಆರೋಹಣ ಕ್ರಮದಲ್ಲಿ ಉತ್ಪಾದಿಸಬೇಕು, ಪ್ರತಿಯೊಂದೂ ಮರದ ಎಲ್ಲಾ ಕೀಲಿಗಳಿಗಿಂತ ದೊಡ್ಡದಾಗಿದೆ, ಪ್ರವೇಶದ ನಂತರ ಮರದಲ್ಲಿರುವ ಯಾವುದೇ ಕೀಲಿಗಳನ್ನು ಒಳಗೊಂಡಂತೆ.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // ರೇಖೀಯ ಸಮಯದಲ್ಲಿ `left` ಮತ್ತು `right` ಅನ್ನು ವಿಂಗಡಿಸಲಾದ ಅನುಕ್ರಮಕ್ಕೆ ವಿಲೀನಗೊಳಿಸಲು ನಾವು ಸಿದ್ಧಪಡಿಸುತ್ತೇವೆ.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // ಏತನ್ಮಧ್ಯೆ, ನಾವು ರೇಖೀಯ ಸಮಯದಲ್ಲಿ ವಿಂಗಡಿಸಲಾದ ಅನುಕ್ರಮದಿಂದ ಮರವನ್ನು ನಿರ್ಮಿಸುತ್ತೇವೆ.
        self.bulk_push(iter, length)
    }

    /// ಎಲ್ಲಾ ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿಗಳನ್ನು ಮರದ ಕೊನೆಯಲ್ಲಿ ತಳ್ಳುತ್ತದೆ, ದಾರಿಯುದ್ದಕ್ಕೂ `length` ವೇರಿಯೇಬಲ್ ಅನ್ನು ಹೆಚ್ಚಿಸುತ್ತದೆ.
    /// ಎರಡನೆಯದು ಪುನರಾವರ್ತಕ ಭಯಭೀತರಾದಾಗ ಸೋರಿಕೆಯನ್ನು ತಪ್ಪಿಸಲು ಕರೆ ಮಾಡುವವರಿಗೆ ಸುಲಭಗೊಳಿಸುತ್ತದೆ.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // ಎಲ್ಲಾ ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿಗಳ ಮೂಲಕ ಪುನರಾವರ್ತಿಸಿ, ಅವುಗಳನ್ನು ಸರಿಯಾದ ಮಟ್ಟದಲ್ಲಿ ನೋಡ್‌ಗಳಿಗೆ ತಳ್ಳುತ್ತದೆ.
        for (key, value) in iter {
            // ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿಯನ್ನು ಪ್ರಸ್ತುತ ಎಲೆ ನೋಡ್‌ಗೆ ತಳ್ಳಲು ಪ್ರಯತ್ನಿಸಿ.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // ಸ್ಥಳಾವಕಾಶವಿಲ್ಲ, ಮೇಲಕ್ಕೆ ಹೋಗಿ ಅಲ್ಲಿಗೆ ತಳ್ಳಿರಿ.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // ಸ್ಥಳಾವಕಾಶವಿರುವ ನೋಡ್ ಕಂಡುಬಂದಿದೆ, ಇಲ್ಲಿಗೆ ತಳ್ಳಿರಿ.
                                open_node = parent;
                                break;
                            } else {
                                // ಮತ್ತೆ ಮೇಲಕ್ಕೆ ಹೋಗಿ.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // ನಾವು ಮೇಲ್ಭಾಗದಲ್ಲಿದ್ದೇವೆ, ಹೊಸ ರೂಟ್ ನೋಡ್ ಅನ್ನು ರಚಿಸಿ ಮತ್ತು ಅಲ್ಲಿಗೆ ತಳ್ಳಿರಿ.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿ ಮತ್ತು ಹೊಸ ಬಲ ಸಬ್‌ಟ್ರೀ ಅನ್ನು ಒತ್ತಿರಿ.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // ಮತ್ತೆ ಬಲಕ್ಕೆ ಹೆಚ್ಚು ಎಲೆಯ ಕೆಳಗೆ ಹೋಗಿ.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // ಪುನರಾವರ್ತಕ ಪ್ಯಾನಿಕ್ಗಳನ್ನು ಮುಂದುವರೆಸಿದರೂ ಸಹ ನಕ್ಷೆಯು ಸಂಯೋಜಿತ ಅಂಶಗಳನ್ನು ಇಳಿಯುತ್ತದೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ಪ್ರತಿ ಪುನರಾವರ್ತನೆಯ ಉದ್ದವನ್ನು ಹೆಚ್ಚಿಸಿ.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// ಎರಡು ವಿಂಗಡಿಸಲಾದ ಅನುಕ್ರಮಗಳನ್ನು ಒಂದಕ್ಕೆ ವಿಲೀನಗೊಳಿಸುವ ಪುನರಾವರ್ತಕ
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// ಎರಡು ಕೀಗಳು ಸಮಾನವಾಗಿದ್ದರೆ, ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿಯನ್ನು ಸರಿಯಾದ ಮೂಲದಿಂದ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}