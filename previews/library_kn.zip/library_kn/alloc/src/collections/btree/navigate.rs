use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// ಅದೇ ಶ್ರೇಣಿಯ ತಾತ್ಕಾಲಿಕವಾಗಿ ಮತ್ತೊಂದು, ಬದಲಾಗದ ಸಮಾನತೆಯನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// ಮರದಲ್ಲಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಶ್ರೇಣಿಯನ್ನು ಡಿಲಿಮಿಟ್ ಮಾಡುವ ವಿಭಿನ್ನ ಎಲೆ ಅಂಚುಗಳನ್ನು ಕಂಡುಕೊಳ್ಳುತ್ತದೆ.
    /// ಒಂದೇ ಮರಕ್ಕೆ ಒಂದು ಜೋಡಿ ವಿಭಿನ್ನ ಹ್ಯಾಂಡಲ್‌ಗಳನ್ನು ಅಥವಾ ಖಾಲಿ ಆಯ್ಕೆಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// `BorrowType` `Immut` ಆಗಿರದಿದ್ದರೆ, ಒಂದೇ KV ಯನ್ನು ಎರಡು ಬಾರಿ ಭೇಟಿ ಮಾಡಲು ನಕಲಿ ಹ್ಯಾಂಡಲ್‌ಗಳನ್ನು ಬಳಸಬೇಡಿ.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// `(root1.first_leaf_edge(), root2.last_leaf_edge())` ಗೆ ಸಮಾನ ಆದರೆ ಹೆಚ್ಚು ಪರಿಣಾಮಕಾರಿ.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// ಮರದ ನಿರ್ದಿಷ್ಟ ಶ್ರೇಣಿಯನ್ನು ಡಿಲಿಮಿಟ್ ಮಾಡುವ ಎಲೆ ಅಂಚುಗಳ ಜೋಡಿಯನ್ನು ಕಂಡುಕೊಳ್ಳುತ್ತದೆ.
    ///
    /// `BTreeMap` ನಲ್ಲಿರುವ ಮರದಂತೆ ಮರವನ್ನು ಕೀಲಿಯಿಂದ ಆದೇಶಿಸಿದರೆ ಮಾತ್ರ ಫಲಿತಾಂಶವು ಅರ್ಥಪೂರ್ಣವಾಗಿರುತ್ತದೆ.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // ಸುರಕ್ಷತೆ: ನಮ್ಮ ಸಾಲ ಪ್ರಕಾರವು ಬದಲಾಗದು.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// ಇಡೀ ಮರವನ್ನು ಡಿಲಿಮಿಟ್ ಮಾಡುವ ಎಲೆ ಅಂಚುಗಳ ಜೋಡಿಯನ್ನು ಕಂಡುಕೊಳ್ಳುತ್ತದೆ.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// ನಿರ್ದಿಷ್ಟ ಶ್ರೇಣಿಯನ್ನು ಡಿಲಿಮಿಟ್ ಮಾಡುವ ಒಂದು ಜೋಡಿ ಎಲೆ ಅಂಚುಗಳಾಗಿ ಅನನ್ಯ ಉಲ್ಲೇಖವನ್ನು ವಿಭಜಿಸುತ್ತದೆ.
    /// ಇದರ ಫಲಿತಾಂಶವು (some) ರೂಪಾಂತರವನ್ನು ಅನುಮತಿಸುವ ಅನನ್ಯವಲ್ಲದ ಉಲ್ಲೇಖಗಳಾಗಿವೆ, ಇದನ್ನು ಎಚ್ಚರಿಕೆಯಿಂದ ಬಳಸಬೇಕು.
    ///
    /// `BTreeMap` ನಲ್ಲಿರುವ ಮರದಂತೆ ಮರವನ್ನು ಕೀಲಿಯಿಂದ ಆದೇಶಿಸಿದರೆ ಮಾತ್ರ ಫಲಿತಾಂಶವು ಅರ್ಥಪೂರ್ಣವಾಗಿರುತ್ತದೆ.
    ///
    ///
    /// # Safety
    /// ಒಂದೇ ಕೆವಿಯನ್ನು ಎರಡು ಬಾರಿ ಭೇಟಿ ಮಾಡಲು ನಕಲಿ ಹ್ಯಾಂಡಲ್‌ಗಳನ್ನು ಬಳಸಬೇಡಿ.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// ಮರದ ಪೂರ್ಣ ಶ್ರೇಣಿಯನ್ನು ಡಿಲಿಮಿಟ್ ಮಾಡುವ ಒಂದು ಜೋಡಿ ಎಲೆ ಅಂಚುಗಳಾಗಿ ಒಂದು ವಿಶಿಷ್ಟ ಉಲ್ಲೇಖವನ್ನು ವಿಭಜಿಸುತ್ತದೆ.
    /// ಫಲಿತಾಂಶಗಳು ರೂಪಾಂತರವನ್ನು ಅನುಮತಿಸುವ ಅನನ್ಯವಲ್ಲದ ಉಲ್ಲೇಖಗಳಾಗಿವೆ (ಮೌಲ್ಯಗಳ ಮಾತ್ರ), ಆದ್ದರಿಂದ ಅದನ್ನು ಎಚ್ಚರಿಕೆಯಿಂದ ಬಳಸಬೇಕು.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // ನಾವು ಇಲ್ಲಿ ಮೂಲ ನೋಡ್ ರೀಫ್ ಅನ್ನು ನಕಲು ಮಾಡುತ್ತೇವೆ-ನಾವು ಒಂದೇ ಕೆವಿಯನ್ನು ಎರಡು ಬಾರಿ ಭೇಟಿ ಮಾಡುವುದಿಲ್ಲ ಮತ್ತು ಅತಿಕ್ರಮಿಸುವ ಮೌಲ್ಯ ಉಲ್ಲೇಖಗಳೊಂದಿಗೆ ಎಂದಿಗೂ ಕೊನೆಗೊಳ್ಳುವುದಿಲ್ಲ.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// ಮರದ ಪೂರ್ಣ ಶ್ರೇಣಿಯನ್ನು ಡಿಲಿಮಿಟ್ ಮಾಡುವ ಒಂದು ಜೋಡಿ ಎಲೆ ಅಂಚುಗಳಾಗಿ ಒಂದು ವಿಶಿಷ್ಟ ಉಲ್ಲೇಖವನ್ನು ವಿಭಜಿಸುತ್ತದೆ.
    /// ಫಲಿತಾಂಶಗಳು ಅನನ್ಯವಲ್ಲದ ಉಲ್ಲೇಖಗಳಾಗಿವೆ, ಅದು ಭಾರಿ ವಿನಾಶಕಾರಿ ರೂಪಾಂತರವನ್ನು ಅನುಮತಿಸುತ್ತದೆ, ಆದ್ದರಿಂದ ಅದನ್ನು ಅತ್ಯಂತ ಎಚ್ಚರಿಕೆಯಿಂದ ಬಳಸಬೇಕು.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // ನಾವು ಇಲ್ಲಿ ಮೂಲ ನೋಡ್ ರೀಫ್ ಅನ್ನು ನಕಲು ಮಾಡುತ್ತೇವೆ-ಮೂಲದಿಂದ ಪಡೆದ ಉಲ್ಲೇಖಗಳನ್ನು ಅತಿಕ್ರಮಿಸುವ ರೀತಿಯಲ್ಲಿ ನಾವು ಅದನ್ನು ಎಂದಿಗೂ ಪ್ರವೇಶಿಸುವುದಿಲ್ಲ.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// edge ಹ್ಯಾಂಡಲ್ ಅನ್ನು ನೀಡಿದರೆ, [`Result::Ok`] ಅನ್ನು ಹ್ಯಾಂಡಲ್ನೊಂದಿಗೆ ನೆರೆಯ KV ಗೆ ಬಲಭಾಗದಲ್ಲಿ ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅದು ಒಂದೇ ಎಲೆ ನೋಡ್‌ನಲ್ಲಿ ಅಥವಾ ಪೂರ್ವಜ ನೋಡ್‌ನಲ್ಲಿರುತ್ತದೆ.
    ///
    /// edge ಎಲೆ ಮರದ ಕೊನೆಯದಾಗಿದ್ದರೆ, ರೂಟ್ ನೋಡ್ನೊಂದಿಗೆ [`Result::Err`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// edge ಹ್ಯಾಂಡಲ್ ಅನ್ನು ನೀಡಿದರೆ, [`Result::Ok`] ಅನ್ನು ಹ್ಯಾಂಡಲ್ನೊಂದಿಗೆ ಎಡಭಾಗದಲ್ಲಿರುವ ನೆರೆಯ KV ಗೆ ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಅದು ಒಂದೇ ಎಲೆ ನೋಡ್‌ನಲ್ಲಿ ಅಥವಾ ಪೂರ್ವಜ ನೋಡ್‌ನಲ್ಲಿರುತ್ತದೆ.
    ///
    /// ಮರದ edge ಎಲೆ ಮೊದಲನೆಯದಾಗಿದ್ದರೆ, ರೂಟ್ ನೋಡ್‌ನೊಂದಿಗೆ [`Result::Err`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// ಆಂತರಿಕ edge ಹ್ಯಾಂಡಲ್ ಅನ್ನು ನೀಡಿದರೆ, [`Result::Ok`] ಅನ್ನು ಹ್ಯಾಂಡಲ್ನೊಂದಿಗೆ ನೆರೆಯ KV ಗೆ ಬಲಭಾಗದಲ್ಲಿ ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅದು ಒಂದೇ ಆಂತರಿಕ ನೋಡ್‌ನಲ್ಲಿ ಅಥವಾ ಪೂರ್ವಜ ನೋಡ್‌ನಲ್ಲಿರುತ್ತದೆ.
    ///
    /// ಆಂತರಿಕ edge ಮರದಲ್ಲಿ ಕೊನೆಯದಾಗಿದ್ದರೆ, ರೂಟ್ ನೋಡ್‌ನೊಂದಿಗೆ [`Result::Err`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// edge ಹ್ಯಾಂಡಲ್ ಅನ್ನು ಸಾಯುತ್ತಿರುವ ಮರಕ್ಕೆ ನೀಡಿದರೆ, ಮುಂದಿನ ಎಲೆಯ edge ಅನ್ನು ಬಲಭಾಗದಲ್ಲಿ ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಮತ್ತು ನಡುವೆ ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿ, ಅದೇ ಎಲೆ ನೋಡ್‌ನಲ್ಲಿ, ಪೂರ್ವಜರ ನೋಡ್‌ನಲ್ಲಿ ಅಥವಾ ಅಸ್ತಿತ್ವದಲ್ಲಿಲ್ಲ.
    ///
    ///
    /// ಈ ವಿಧಾನವು ಯಾವುದೇ node(s) ನ ಅಂತ್ಯವನ್ನು ತಲುಪುತ್ತದೆ.
    /// ಹೆಚ್ಚಿನ ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿ ಅಸ್ತಿತ್ವದಲ್ಲಿಲ್ಲದಿದ್ದರೆ, ಮರದ ಸಂಪೂರ್ಣ ಉಳಿದ ಭಾಗವನ್ನು ಸ್ಥಳಾಂತರಿಸಲಾಗುವುದು ಮತ್ತು ಹಿಂತಿರುಗಲು ಏನೂ ಉಳಿದಿಲ್ಲ ಎಂದು ಇದು ಸೂಚಿಸುತ್ತದೆ.
    ///
    /// # Safety
    /// ಕೊಟ್ಟಿರುವ edge ಅನ್ನು ಈ ಹಿಂದೆ ಪ್ರತಿರೂಪವಾದ `deallocating_next_back` ಹಿಂದಿರುಗಿಸಬಾರದು.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// ಸಾಯುತ್ತಿರುವ ಮರಕ್ಕೆ ಎಲೆ edge ಹ್ಯಾಂಡಲ್ ಅನ್ನು ನೀಡಿದರೆ, ಮುಂದಿನ ಎಲೆಯ edge ಅನ್ನು ಎಡಭಾಗದಲ್ಲಿ ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಮತ್ತು ನಡುವೆ ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿ, ಅದೇ ಎಲೆ ನೋಡ್‌ನಲ್ಲಿ, ಪೂರ್ವಜರ ನೋಡ್‌ನಲ್ಲಿ ಅಥವಾ ಅಸ್ತಿತ್ವದಲ್ಲಿಲ್ಲ.
    ///
    ///
    /// ಈ ವಿಧಾನವು ಯಾವುದೇ node(s) ನ ಅಂತ್ಯವನ್ನು ತಲುಪುತ್ತದೆ.
    /// ಹೆಚ್ಚಿನ ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿ ಅಸ್ತಿತ್ವದಲ್ಲಿಲ್ಲದಿದ್ದರೆ, ಮರದ ಸಂಪೂರ್ಣ ಉಳಿದ ಭಾಗವನ್ನು ಸ್ಥಳಾಂತರಿಸಲಾಗುವುದು ಮತ್ತು ಹಿಂತಿರುಗಲು ಏನೂ ಉಳಿದಿಲ್ಲ ಎಂದು ಇದು ಸೂಚಿಸುತ್ತದೆ.
    ///
    /// # Safety
    /// ಕೊಟ್ಟಿರುವ edge ಅನ್ನು ಈ ಹಿಂದೆ ಪ್ರತಿರೂಪವಾದ `deallocating_next` ಹಿಂದಿರುಗಿಸಬಾರದು.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// ಎಲೆಯಿಂದ ಬೇರಿನವರೆಗೆ ನೋಡ್ಗಳ ರಾಶಿಯನ್ನು ಡಿಯೊಲೊಕೇಟ್ ಮಾಡುತ್ತದೆ.
    /// `deallocating_next` ಮತ್ತು `deallocating_next_back` ಮರದ ಎರಡೂ ಬದಿಗಳಲ್ಲಿ ನಿಬ್ಬೆರಗಾಗಿಸಿದ ನಂತರ ಮತ್ತು ಅದೇ edge ಅನ್ನು ಹೊಡೆದ ನಂತರ ಮರದ ಉಳಿದ ಭಾಗವನ್ನು ಡಿಲೊಕೊಲೇಟ್ ಮಾಡಲು ಇದು ಏಕೈಕ ಮಾರ್ಗವಾಗಿದೆ.
    /// ಎಲ್ಲಾ ಕೀಲಿಗಳು ಮತ್ತು ಮೌಲ್ಯಗಳನ್ನು ಹಿಂತಿರುಗಿಸಿದಾಗ ಮಾತ್ರ ಕರೆಯಲು ಉದ್ದೇಶಿಸಿರುವುದರಿಂದ, ಯಾವುದೇ ಕೀಲಿಗಳು ಅಥವಾ ಮೌಲ್ಯಗಳಲ್ಲಿ ಯಾವುದೇ ಸ್ವಚ್ clean ಗೊಳಿಸುವಿಕೆಯನ್ನು ಮಾಡಲಾಗುವುದಿಲ್ಲ.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// edge ಎಲೆಯನ್ನು ಮುಂದಿನ ಎಲೆ edge ಗೆ ಸರಿಸುತ್ತದೆ ಮತ್ತು ನಡುವೆ ಇರುವ ಕೀ ಮತ್ತು ಮೌಲ್ಯದ ಉಲ್ಲೇಖಗಳನ್ನು ನೀಡುತ್ತದೆ.
    ///
    ///
    /// # Safety
    /// ಪ್ರಯಾಣಿಸಿದ ದಿಕ್ಕಿನಲ್ಲಿ ಮತ್ತೊಂದು ಕೆ.ವಿ ಇರಬೇಕು.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// edge ಹ್ಯಾಂಡಲ್ ಅನ್ನು ಹಿಂದಿನ ಎಲೆ edge ಗೆ ಸರಿಸುತ್ತದೆ ಮತ್ತು ಕೀ ಮತ್ತು ಮೌಲ್ಯದ ಉಲ್ಲೇಖಗಳನ್ನು ನೀಡುತ್ತದೆ.
    ///
    ///
    /// # Safety
    /// ಪ್ರಯಾಣಿಸಿದ ದಿಕ್ಕಿನಲ್ಲಿ ಮತ್ತೊಂದು ಕೆ.ವಿ ಇರಬೇಕು.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// edge ಎಲೆಯನ್ನು ಮುಂದಿನ ಎಲೆ edge ಗೆ ಸರಿಸುತ್ತದೆ ಮತ್ತು ನಡುವೆ ಇರುವ ಕೀ ಮತ್ತು ಮೌಲ್ಯದ ಉಲ್ಲೇಖಗಳನ್ನು ನೀಡುತ್ತದೆ.
    ///
    ///
    /// # Safety
    /// ಪ್ರಯಾಣಿಸಿದ ದಿಕ್ಕಿನಲ್ಲಿ ಮತ್ತೊಂದು ಕೆ.ವಿ ಇರಬೇಕು.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // ಮಾನದಂಡಗಳ ಪ್ರಕಾರ ಇದನ್ನು ಕೊನೆಯದಾಗಿ ಮಾಡುವುದು ವೇಗವಾಗಿರುತ್ತದೆ.
        kv.into_kv_valmut()
    }

    /// edge ಹ್ಯಾಂಡಲ್ ಅನ್ನು ಹಿಂದಿನ ಎಲಿಗೆ ಸರಿಸುತ್ತದೆ ಮತ್ತು ನಡುವೆ ಇರುವ ಕೀ ಮತ್ತು ಮೌಲ್ಯದ ಉಲ್ಲೇಖಗಳನ್ನು ನೀಡುತ್ತದೆ.
    ///
    ///
    /// # Safety
    /// ಪ್ರಯಾಣಿಸಿದ ದಿಕ್ಕಿನಲ್ಲಿ ಮತ್ತೊಂದು ಕೆ.ವಿ ಇರಬೇಕು.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // ಮಾನದಂಡಗಳ ಪ್ರಕಾರ ಇದನ್ನು ಕೊನೆಯದಾಗಿ ಮಾಡುವುದು ವೇಗವಾಗಿರುತ್ತದೆ.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// edge ಹ್ಯಾಂಡಲ್ ಅನ್ನು ಮುಂದಿನ ಎಲೆ edge ಗೆ ಸರಿಸುತ್ತದೆ ಮತ್ತು ನಡುವೆ ಕೀ ಮತ್ತು ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಅನುಗುಣವಾದ edge ಅನ್ನು ಅದರ ಮೂಲ ನೋಡ್ ಡ್ಯಾಂಗ್ಲಿಂಗ್‌ನಲ್ಲಿ ಬಿಡುವಾಗ ಉಳಿದಿರುವ ಯಾವುದೇ ನೋಡ್ ಅನ್ನು ಡಿಲೊಲೊಕೇಟ್ ಮಾಡುತ್ತದೆ.
    ///
    /// # Safety
    /// - ಪ್ರಯಾಣಿಸಿದ ದಿಕ್ಕಿನಲ್ಲಿ ಮತ್ತೊಂದು ಕೆ.ವಿ ಇರಬೇಕು.
    /// - ಮರವನ್ನು ಹಾದುಹೋಗಲು ಬಳಸಲಾಗುವ ಹ್ಯಾಂಡಲ್‌ಗಳ ಯಾವುದೇ ನಕಲಿನಲ್ಲಿ ಪ್ರತಿರೂಪವಾದ `next_back_unchecked` ನಿಂದ ಕೆವಿಯನ್ನು ಈ ಹಿಂದೆ ಹಿಂತಿರುಗಿಸಲಾಗಿಲ್ಲ.
    ///
    /// ನವೀಕರಿಸಿದ ಹ್ಯಾಂಡಲ್‌ನೊಂದಿಗೆ ಮುಂದುವರಿಯಲು ಇರುವ ಏಕೈಕ ಸುರಕ್ಷಿತ ಮಾರ್ಗವೆಂದರೆ ಅದನ್ನು ಹೋಲಿಸುವುದು, ಬಿಡುವುದು, ಈ ವಿಧಾನವನ್ನು ಅದರ ಸುರಕ್ಷತಾ ಪರಿಸ್ಥಿತಿಗಳಿಗೆ ಒಳಪಟ್ಟು ಮತ್ತೆ ಕರೆಯುವುದು ಅಥವಾ ಅದರ ಸುರಕ್ಷತಾ ಪರಿಸ್ಥಿತಿಗಳಿಗೆ ಒಳಪಟ್ಟು `next_back_unchecked` ಅನ್ನು ಕರೆ ಮಾಡುವುದು.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// edge ಎಲೆ ಹ್ಯಾಂಡಲ್ ಅನ್ನು ಹಿಂದಿನ ಎಲೆ edge ಗೆ ಸರಿಸುತ್ತದೆ ಮತ್ತು ನಡುವೆ ಕೀ ಮತ್ತು ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಅನುಗುಣವಾದ edge ಅನ್ನು ಅದರ ಮೂಲ ನೋಡ್ ಡ್ಯಾಂಗ್ಲಿಂಗ್‌ನಲ್ಲಿ ಬಿಡುವಾಗ ಉಳಿದಿರುವ ಯಾವುದೇ ನೋಡ್ ಅನ್ನು ಡಿಲೊಲೊಕೇಟ್ ಮಾಡುತ್ತದೆ.
    ///
    /// # Safety
    /// - ಪ್ರಯಾಣಿಸಿದ ದಿಕ್ಕಿನಲ್ಲಿ ಮತ್ತೊಂದು ಕೆ.ವಿ ಇರಬೇಕು.
    /// - ಮರವನ್ನು ಹಾದುಹೋಗಲು ಬಳಸಲಾಗುವ ಹ್ಯಾಂಡಲ್‌ಗಳ ಯಾವುದೇ ನಕಲಿನಲ್ಲಿ ಆ ಎಲೆ edge ಅನ್ನು ಈ ಹಿಂದೆ ಪ್ರತಿರೂಪವಾದ `next_unchecked` ಹಿಂದಿರುಗಿಸಲಿಲ್ಲ.
    ///
    /// ನವೀಕರಿಸಿದ ಹ್ಯಾಂಡಲ್‌ನೊಂದಿಗೆ ಮುಂದುವರಿಯಲು ಇರುವ ಏಕೈಕ ಸುರಕ್ಷಿತ ಮಾರ್ಗವೆಂದರೆ ಅದನ್ನು ಹೋಲಿಸುವುದು, ಬಿಡುವುದು, ಈ ವಿಧಾನವನ್ನು ಅದರ ಸುರಕ್ಷತಾ ಪರಿಸ್ಥಿತಿಗಳಿಗೆ ಒಳಪಟ್ಟು ಮತ್ತೆ ಕರೆಯುವುದು ಅಥವಾ ಅದರ ಸುರಕ್ಷತಾ ಪರಿಸ್ಥಿತಿಗಳಿಗೆ ಒಳಪಟ್ಟು `next_unchecked` ಅನ್ನು ಕರೆ ಮಾಡುವುದು.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// ನೋಡ್‌ನಲ್ಲಿ ಅಥವಾ ಅದರ ಕೆಳಗಿರುವ ಎಡಭಾಗದ edge ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, ಮುಂದಕ್ಕೆ ನ್ಯಾವಿಗೇಟ್ ಮಾಡುವಾಗ ನಿಮಗೆ ಮೊದಲು ಬೇಕಾದ edge (ಅಥವಾ ಹಿಂದಕ್ಕೆ ನ್ಯಾವಿಗೇಟ್ ಮಾಡುವಾಗ ಕೊನೆಯದು).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// ನೋಡ್‌ನಲ್ಲಿ ಅಥವಾ ಅದರ ಕೆಳಗಿರುವ ಬಲಭಾಗದ ಎಲೆ edge ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಂದರೆ, ಮುಂದಕ್ಕೆ ನ್ಯಾವಿಗೇಟ್ ಮಾಡುವಾಗ ನಿಮಗೆ ಕೊನೆಯದಾಗಿ ಬೇಕಾದ edge (ಅಥವಾ ಮೊದಲು ಹಿಂದಕ್ಕೆ ನ್ಯಾವಿಗೇಟ್ ಮಾಡುವಾಗ).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// ಆರೋಹಣ ಕೀಗಳ ಕ್ರಮದಲ್ಲಿ ಎಲೆ ನೋಡ್‌ಗಳು ಮತ್ತು ಆಂತರಿಕ ಕೆವಿಗಳನ್ನು ಭೇಟಿ ಮಾಡುತ್ತದೆ, ಮತ್ತು ಆಂತರಿಕ ನೋಡ್‌ಗಳನ್ನು ಒಟ್ಟಾರೆಯಾಗಿ ಆಳವಾದ ಮೊದಲ ಕ್ರಮದಲ್ಲಿ ಭೇಟಿ ಮಾಡುತ್ತದೆ, ಅಂದರೆ ಆಂತರಿಕ ನೋಡ್‌ಗಳು ತಮ್ಮ ವೈಯಕ್ತಿಕ ಕೆವಿಗಳು ಮತ್ತು ಮಕ್ಕಳ ನೋಡ್‌ಗಳಿಗಿಂತ ಮುಂಚಿತವಾಗಿರುತ್ತವೆ.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// (ಉಪ) ಮರದಲ್ಲಿನ ಅಂಶಗಳ ಸಂಖ್ಯೆಯನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// ಫಾರ್ವರ್ಡ್ ನ್ಯಾವಿಗೇಷನ್ಗಾಗಿ ಕೆವಿಗೆ ಹತ್ತಿರವಿರುವ edge ಎಲೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// ಹಿಂದುಳಿದ ಸಂಚರಣೆಗಾಗಿ ಕೆವಿಗೆ ಹತ್ತಿರವಿರುವ edge ಎಲೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}