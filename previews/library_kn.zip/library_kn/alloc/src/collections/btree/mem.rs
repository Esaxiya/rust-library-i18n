use core::intrinsics;
use core::mem;
use core::ptr;

/// ಸಂಬಂಧಿತ ಕಾರ್ಯವನ್ನು ಕರೆಯುವ ಮೂಲಕ ಇದು `v` ಅನನ್ಯ ಉಲ್ಲೇಖದ ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಬದಲಾಯಿಸುತ್ತದೆ.
///
///
/// `change` ಮುಚ್ಚುವಿಕೆಯಲ್ಲಿ panic ಸಂಭವಿಸಿದಲ್ಲಿ, ಸಂಪೂರ್ಣ ಪ್ರಕ್ರಿಯೆಯನ್ನು ಸ್ಥಗಿತಗೊಳಿಸಲಾಗುತ್ತದೆ.
#[allow(dead_code)] // ವಿವರಣೆಯಾಗಿ ಮತ್ತು future ಬಳಕೆಗಾಗಿ ಇರಿಸಿ
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// ಇದು ಸಂಬಂಧಿತ ಕಾರ್ಯವನ್ನು ಕರೆಯುವ ಮೂಲಕ `v` ಅನನ್ಯ ಉಲ್ಲೇಖದ ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಬದಲಾಯಿಸುತ್ತದೆ ಮತ್ತು ದಾರಿಯುದ್ದಕ್ಕೂ ಪಡೆದ ಫಲಿತಾಂಶವನ್ನು ನೀಡುತ್ತದೆ.
///
///
/// `change` ಮುಚ್ಚುವಿಕೆಯಲ್ಲಿ panic ಸಂಭವಿಸಿದಲ್ಲಿ, ಸಂಪೂರ್ಣ ಪ್ರಕ್ರಿಯೆಯನ್ನು ಸ್ಥಗಿತಗೊಳಿಸಲಾಗುತ್ತದೆ.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}