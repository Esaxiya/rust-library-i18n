// ಇದು ಆದರ್ಶವನ್ನು ಅನುಸರಿಸಿ ಅನುಷ್ಠಾನಗೊಳಿಸುವ ಪ್ರಯತ್ನವಾಗಿದೆ
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Rust ವಾಸ್ತವವಾಗಿ ಅವಲಂಬಿತ ಪ್ರಕಾರಗಳು ಮತ್ತು ಬಹುರೂಪಿ ಪುನರಾವರ್ತನೆಯನ್ನು ಹೊಂದಿರದ ಕಾರಣ, ನಾವು ಸಾಕಷ್ಟು ಅಸುರಕ್ಷಿತತೆಯನ್ನು ಮಾಡುತ್ತೇವೆ.
//

// ಈ ಮಾಡ್ಯೂಲ್‌ನ ಒಂದು ಪ್ರಮುಖ ಗುರಿಯೆಂದರೆ ಮರವನ್ನು ಜೆನೆರಿಕ್ (ವಿಲಕ್ಷಣವಾಗಿ ಆಕಾರದಲ್ಲಿದ್ದರೆ) ಪಾತ್ರೆಯಾಗಿ ಪರಿಗಣಿಸುವ ಮೂಲಕ ಮತ್ತು ಬಿ-ಟ್ರೀ ಅಸ್ಥಿರತೆಗಳೊಂದಿಗೆ ವ್ಯವಹರಿಸುವುದನ್ನು ತಪ್ಪಿಸುವ ಮೂಲಕ ಸಂಕೀರ್ಣತೆಯನ್ನು ತಪ್ಪಿಸುವುದು.
//
// ಅಂತೆಯೇ, ಈ ಮಾಡ್ಯೂಲ್ ನಮೂದುಗಳನ್ನು ವಿಂಗಡಿಸಲಾಗಿದೆಯೆ, ಯಾವ ನೋಡ್‌ಗಳನ್ನು ಅಂಡರ್ಫುಲ್ ಮಾಡಬಹುದು, ಅಥವಾ ಅಂಡರ್ಫುಲ್ ಎಂದರೆ ಏನು ಎಂದು ಹೆದರುವುದಿಲ್ಲ.ಆದಾಗ್ಯೂ, ನಾವು ಕೆಲವು ಅಸ್ಥಿರಗಳನ್ನು ಅವಲಂಬಿಸಿದ್ದೇವೆ:
//
// - ಮರಗಳು ಏಕರೂಪದ depth/height ಹೊಂದಿರಬೇಕು.ಇದರರ್ಥ ನಿರ್ದಿಷ್ಟ ನೋಡ್‌ನಿಂದ ಎಲೆಯವರೆಗಿನ ಪ್ರತಿಯೊಂದು ಹಾದಿಯು ಒಂದೇ ಉದ್ದವನ್ನು ಹೊಂದಿರುತ್ತದೆ.
// - `n` ಉದ್ದದ ನೋಡ್ `n` ಕೀಗಳು, `n` ಮೌಲ್ಯಗಳು ಮತ್ತು `n + 1` ಅಂಚುಗಳನ್ನು ಹೊಂದಿದೆ.
//   ಖಾಲಿ ನೋಡ್ ಸಹ ಕನಿಷ್ಠ ಒಂದು edge ಅನ್ನು ಹೊಂದಿದೆ ಎಂದು ಇದು ಸೂಚಿಸುತ್ತದೆ.
//   ಎಲೆ ನೋಡ್‌ಗಾಗಿ, "having an edge" ಎಂದರೆ ನಾವು ನೋಡ್‌ನಲ್ಲಿ ಒಂದು ಸ್ಥಾನವನ್ನು ಗುರುತಿಸಬಹುದು, ಏಕೆಂದರೆ ಎಲೆ ಅಂಚುಗಳು ಖಾಲಿಯಾಗಿರುತ್ತವೆ ಮತ್ತು ಡೇಟಾ ಪ್ರಾತಿನಿಧ್ಯ ಅಗತ್ಯವಿಲ್ಲ.
// ಆಂತರಿಕ ನೋಡ್‌ನಲ್ಲಿ, edge ಎರಡೂ ಸ್ಥಾನವನ್ನು ಗುರುತಿಸುತ್ತದೆ ಮತ್ತು ಮಕ್ಕಳ ನೋಡ್‌ಗೆ ಪಾಯಿಂಟರ್ ಅನ್ನು ಹೊಂದಿರುತ್ತದೆ.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// ಎಲೆ ನೋಡ್‌ಗಳ ಆಧಾರವಾಗಿರುವ ಪ್ರಾತಿನಿಧ್ಯ ಮತ್ತು ಆಂತರಿಕ ನೋಡ್‌ಗಳ ಪ್ರಾತಿನಿಧ್ಯದ ಭಾಗ.
struct LeafNode<K, V> {
    /// ನಾವು `K` ಮತ್ತು `V` ನಲ್ಲಿ ಕೋವಿಯರಿಯಂಟ್ ಆಗಲು ಬಯಸುತ್ತೇವೆ.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// ಈ ನೋಡ್‌ನ ಸೂಚ್ಯಂಕವು ಮೂಲ ನೋಡ್‌ನ `edges` ರಚನೆಯಲ್ಲಿದೆ.
    /// `*node.parent.edges[node.parent_idx]` `node` ನಂತೆಯೇ ಇರಬೇಕು.
    /// `parent` ಶೂನ್ಯವಲ್ಲದಿದ್ದಾಗ ಮಾತ್ರ ಇದನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗುವುದು ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.
    parent_idx: MaybeUninit<u16>,

    /// ಈ ನೋಡ್ ಸಂಗ್ರಹಿಸುವ ಕೀಗಳು ಮತ್ತು ಮೌಲ್ಯಗಳ ಸಂಖ್ಯೆ.
    len: u16,

    /// ನೋಡ್ನ ನಿಜವಾದ ಡೇಟಾವನ್ನು ಸಂಗ್ರಹಿಸುವ ಸರಣಿಗಳು.
    /// ಪ್ರತಿ ರಚನೆಯ ಮೊದಲ `len` ಅಂಶಗಳು ಮಾತ್ರ ಪ್ರಾರಂಭವಾಗುತ್ತವೆ ಮತ್ತು ಮಾನ್ಯವಾಗಿರುತ್ತವೆ.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// ಸ್ಥಳದಲ್ಲಿ ಹೊಸ `LeafNode` ಅನ್ನು ಪ್ರಾರಂಭಿಸುತ್ತದೆ.
    unsafe fn init(this: *mut Self) {
        // ಸಾಮಾನ್ಯ ನೀತಿಯಂತೆ, ಕ್ಷೇತ್ರಗಳು ಸಾಧ್ಯವಾದರೆ ನಾವು ಅವುಗಳನ್ನು ಪ್ರಾರಂಭಿಸದೆ ಬಿಡುತ್ತೇವೆ, ಏಕೆಂದರೆ ಇದು ವಾಲ್ಗ್ರಿಂಡ್‌ನಲ್ಲಿ ಸ್ವಲ್ಪ ವೇಗವಾಗಿ ಮತ್ತು ಸುಲಭವಾಗಿ ಟ್ರ್ಯಾಕ್ ಆಗಿರಬೇಕು.
        //
        unsafe {
            // ಪೇರೆಂಟ್_ಐಡಿಎಕ್ಸ್, ಕೀಗಳು ಮತ್ತು ವಾಲ್ಸ್ ಎಲ್ಲವೂ ಬಹುಶಃ ಯುನಿಟ್ ಆಗಿರಬಹುದು
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// ಹೊಸ ಪೆಟ್ಟಿಗೆಯ `LeafNode` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// ಆಂತರಿಕ ನೋಡ್‌ಗಳ ಆಧಾರವಾಗಿರುವ ಪ್ರಾತಿನಿಧ್ಯ.`ಲೀಫ್‌ನೋಡ್'ಗಳಂತೆ, ಪ್ರಾರಂಭಿಸದ ಕೀಗಳು ಮತ್ತು ಮೌಲ್ಯಗಳನ್ನು ಬಿಡುವುದನ್ನು ತಡೆಯಲು ಇವುಗಳನ್ನು` ಬಾಕ್ಸಡ್‌ನೋಡ್'ಗಳ ಹಿಂದೆ ಮರೆಮಾಡಬೇಕು.
/// `InternalNode` ಗೆ ಯಾವುದೇ ಪಾಯಿಂಟರ್ ಅನ್ನು ನೋಡ್ನ ಆಧಾರವಾಗಿರುವ `LeafNode` ಭಾಗಕ್ಕೆ ನೇರವಾಗಿ ಪಾಯಿಂಟರ್‌ಗೆ ಬಿತ್ತರಿಸಬಹುದು, ಇದು ಒಂದು ಪಾಯಿಂಟರ್ ಯಾವ ಎರಡು ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಸೂಚಿಸುತ್ತದೆ ಎಂಬುದನ್ನು ಸಹ ಪರಿಶೀಲಿಸದೆ ಕೋಡ್ ಅನ್ನು ಎಲೆ ಮತ್ತು ಆಂತರಿಕ ನೋಡ್‌ಗಳಲ್ಲಿ ಸಾಮಾನ್ಯವಾಗಿ ಕಾರ್ಯನಿರ್ವಹಿಸಲು ಅನುವು ಮಾಡಿಕೊಡುತ್ತದೆ.
///
/// `repr(C)` ಬಳಕೆಯಿಂದ ಈ ಆಸ್ತಿಯನ್ನು ಸಕ್ರಿಯಗೊಳಿಸಲಾಗಿದೆ.
///
#[repr(C)]
// gdb_providers.py ಆತ್ಮಾವಲೋಕನಕ್ಕಾಗಿ ಈ ಪ್ರಕಾರದ ಹೆಸರನ್ನು ಬಳಸುತ್ತದೆ.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// ಈ ನೋಡ್ನ ಮಕ್ಕಳಿಗೆ ಪಾಯಿಂಟರ್ಸ್.
    /// `len + 1` ಇವುಗಳನ್ನು ಪ್ರಾರಂಭಿಕ ಮತ್ತು ಮಾನ್ಯವೆಂದು ಪರಿಗಣಿಸಲಾಗುತ್ತದೆ, ಕೊನೆಯಲ್ಲಿ ಹೊರತುಪಡಿಸಿ, ಮರವನ್ನು ಎರವಲು ಪ್ರಕಾರ `Dying` ಮೂಲಕ ಹಿಡಿದಿದ್ದರೆ, ಈ ಕೆಲವು ಪಾಯಿಂಟರ್‌ಗಳು ತೂಗಾಡುತ್ತಿವೆ.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// ಹೊಸ ಪೆಟ್ಟಿಗೆಯ `InternalNode` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Safety
    /// ಆಂತರಿಕ ನೋಡ್‌ಗಳ ಅಸ್ಥಿರತೆಯೆಂದರೆ ಅವುಗಳು ಕನಿಷ್ಟ ಒಂದು ಪ್ರಾರಂಭಿಕ ಮತ್ತು ಮಾನ್ಯ edge ಅನ್ನು ಹೊಂದಿರುತ್ತವೆ.
    /// ಈ ಕಾರ್ಯವು ಅಂತಹ edge ಅನ್ನು ಹೊಂದಿಸುವುದಿಲ್ಲ.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // ನಾವು ಡೇಟಾವನ್ನು ಮಾತ್ರ ಪ್ರಾರಂಭಿಸಬೇಕಾಗಿದೆ;ಅಂಚುಗಳು ಬಹುಶಃ ಯುನಿನಿಟ್.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// ನಿರ್ವಹಿಸಿದ, ಶೂನ್ಯವಲ್ಲದ ಪಾಯಿಂಟರ್ ನೋಡ್‌ಗೆ.ಇದು `LeafNode<K, V>` ಗೆ ಒಡೆತನದ ಪಾಯಿಂಟರ್ ಅಥವಾ `InternalNode<K, V>` ಗೆ ಒಡೆತನದ ಪಾಯಿಂಟರ್ ಆಗಿದೆ.
///
/// ಆದಾಗ್ಯೂ, `BoxedNode` ಎರಡು ರೀತಿಯ ನೋಡ್‌ಗಳಲ್ಲಿ ಯಾವುದು ನಿಜವಾಗಿ ಒಳಗೊಂಡಿರುತ್ತದೆ ಎಂಬುದರ ಬಗ್ಗೆ ಯಾವುದೇ ಮಾಹಿತಿಯನ್ನು ಹೊಂದಿಲ್ಲ, ಮತ್ತು ಭಾಗಶಃ ಈ ಮಾಹಿತಿಯ ಕೊರತೆಯಿಂದಾಗಿ, ಇದು ಪ್ರತ್ಯೇಕ ಪ್ರಕಾರವಲ್ಲ ಮತ್ತು ಯಾವುದೇ ವಿನಾಶಕವನ್ನು ಹೊಂದಿಲ್ಲ.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// ಒಡೆತನದ ಮರದ ಮೂಲ ನೋಡ್.
///
/// ಇದು ವಿನಾಶಕವನ್ನು ಹೊಂದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ ಮತ್ತು ಅದನ್ನು ಕೈಯಾರೆ ಸ್ವಚ್ ed ಗೊಳಿಸಬೇಕು.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// ಹೊಸ ಖಾಲಿ ಇರುವ ಮರವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅದರ ಸ್ವಂತ ರೂಟ್ ನೋಡ್ ಆರಂಭದಲ್ಲಿ ಖಾಲಿಯಾಗಿದೆ.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` ಶೂನ್ಯವಾಗಿರಬಾರದು.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// ಒಡೆತನದ ರೂಟ್ ನೋಡ್ ಅನ್ನು ಪರಸ್ಪರ ಎರವಲು ಪಡೆಯುತ್ತದೆ.
    /// `reborrow_mut` ಗಿಂತ ಭಿನ್ನವಾಗಿ, ಇದು ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ರಿಟರ್ನ್ ಮೌಲ್ಯವನ್ನು ಮೂಲವನ್ನು ನಾಶಮಾಡಲು ಬಳಸಲಾಗುವುದಿಲ್ಲ, ಮತ್ತು ಮರದ ಬಗ್ಗೆ ಇತರ ಉಲ್ಲೇಖಗಳು ಇರಬಾರದು.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ಸ್ವಾಭಾವಿಕವಾಗಿ ರೂಟ್ ನೋಡ್ ಅನ್ನು ಸ್ವಲ್ಪಮಟ್ಟಿಗೆ ಪರಿವರ್ತಿಸಬಹುದು.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ಅಡ್ಡಹಾಯುವಿಕೆಯನ್ನು ಅನುಮತಿಸುವ ಮತ್ತು ವಿನಾಶಕಾರಿ ವಿಧಾನಗಳನ್ನು ಮತ್ತು ಸ್ವಲ್ಪವನ್ನು ನೀಡುವ ಉಲ್ಲೇಖಕ್ಕೆ ಬದಲಾಯಿಸಲಾಗದಂತೆ ಪರಿವರ್ತನೆ.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// ಹಿಂದಿನ ರೂಟ್ ನೋಡ್‌ಗೆ ಸೂಚಿಸುವ ಒಂದೇ edge ನೊಂದಿಗೆ ಹೊಸ ಆಂತರಿಕ ನೋಡ್ ಅನ್ನು ಸೇರಿಸುತ್ತದೆ, ಆ ಹೊಸ ನೋಡ್ ಅನ್ನು ರೂಟ್ ನೋಡ್ ಮಾಡಿ ಮತ್ತು ಅದನ್ನು ಹಿಂತಿರುಗಿಸಿ.
    /// ಇದು ಎತ್ತರವನ್ನು 1 ರಷ್ಟು ಹೆಚ್ಚಿಸುತ್ತದೆ ಮತ್ತು ಇದು `pop_internal_level` ಗೆ ವಿರುದ್ಧವಾಗಿರುತ್ತದೆ.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, ನಾವು ಈಗ ಆಂತರಿಕವಾಗಿರುವುದನ್ನು ನಾವು ಮರೆತಿದ್ದೇವೆ ಹೊರತುಪಡಿಸಿ:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ಆಂತರಿಕ ರೂಟ್ ನೋಡ್ ಅನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ, ಅದರ ಮೊದಲ ಮಗುವನ್ನು ಹೊಸ ರೂಟ್ ನೋಡ್ ಆಗಿ ಬಳಸುತ್ತದೆ.
    /// ರೂಟ್ ನೋಡ್ ಕೇವಲ ಒಂದು ಮಗುವನ್ನು ಹೊಂದಿರುವಾಗ ಮಾತ್ರ ಕರೆಯಲು ಉದ್ದೇಶಿಸಿರುವುದರಿಂದ, ಯಾವುದೇ ಕೀಲಿಗಳು, ಮೌಲ್ಯಗಳು ಮತ್ತು ಇತರ ಮಕ್ಕಳ ಮೇಲೆ ಯಾವುದೇ ಸ್ವಚ್ clean ಗೊಳಿಸುವಿಕೆಯನ್ನು ಮಾಡಲಾಗುವುದಿಲ್ಲ.
    ///
    /// ಇದು ಎತ್ತರವನ್ನು 1 ರಷ್ಟು ಕಡಿಮೆ ಮಾಡುತ್ತದೆ ಮತ್ತು ಇದು `push_internal_level` ಗೆ ವಿರುದ್ಧವಾಗಿರುತ್ತದೆ.
    ///
    /// `Root` ಆಬ್ಜೆಕ್ಟ್ಗೆ ವಿಶೇಷ ಪ್ರವೇಶದ ಅಗತ್ಯವಿದೆ ಆದರೆ ರೂಟ್ ನೋಡ್ಗೆ ಅಲ್ಲ;
    /// ಇದು ರೂಟ್ ನೋಡ್‌ಗೆ ಇತರ ಹ್ಯಾಂಡಲ್‌ಗಳು ಅಥವಾ ಉಲ್ಲೇಖಗಳನ್ನು ಅಮಾನ್ಯಗೊಳಿಸುವುದಿಲ್ಲ.
    ///
    /// ಆಂತರಿಕ ಮಟ್ಟವಿಲ್ಲದಿದ್ದರೆ Panics, ಅಂದರೆ, ಮೂಲ ನೋಡ್ ಎಲೆಯಾಗಿದ್ದರೆ.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // ಸುರಕ್ಷತೆ: ನಾವು ಆಂತರಿಕ ಎಂದು ಪ್ರತಿಪಾದಿಸಿದ್ದೇವೆ.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // ಸುರಕ್ಷತೆ: ನಾವು `self` ಅನ್ನು ಪ್ರತ್ಯೇಕವಾಗಿ ಎರವಲು ಪಡೆದುಕೊಂಡಿದ್ದೇವೆ ಮತ್ತು ಅದರ ಸಾಲ ಪ್ರಕಾರವು ಪ್ರತ್ಯೇಕವಾಗಿದೆ.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // ಸುರಕ್ಷತೆ: ಮೊದಲ edge ಅನ್ನು ಯಾವಾಗಲೂ ಪ್ರಾರಂಭಿಸಲಾಗುತ್ತದೆ.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `BorrowType` ಯಾವಾಗಲೂ `K` ಮತ್ತು `V` ನಲ್ಲಿ ಸಹವರ್ತಿವಾಗಿರುತ್ತದೆ, `BorrowType` `Mut` ಆಗಿದ್ದರೂ ಸಹ.
// ಇದು ತಾಂತ್ರಿಕವಾಗಿ ತಪ್ಪಾಗಿದೆ, ಆದರೆ `NodeRef` ನ ಆಂತರಿಕ ಬಳಕೆಯಿಂದಾಗಿ ಯಾವುದೇ ಅಸುರಕ್ಷಿತತೆಗೆ ಕಾರಣವಾಗುವುದಿಲ್ಲ ಏಕೆಂದರೆ ನಾವು `K` ಮತ್ತು `V` ಗಿಂತ ಸಂಪೂರ್ಣವಾಗಿ ಸಾರ್ವತ್ರಿಕವಾಗಿರುತ್ತೇವೆ.
//
// ಆದಾಗ್ಯೂ, ಸಾರ್ವಜನಿಕ ಪ್ರಕಾರವು `NodeRef` ಅನ್ನು ಸುತ್ತುವರೆದಾಗ, ಅದು ಸರಿಯಾದ ವ್ಯತ್ಯಾಸವನ್ನು ಹೊಂದಿದೆಯೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ.
//
/// ನೋಡ್ಗೆ ಉಲ್ಲೇಖ.
///
/// ಈ ಪ್ರಕಾರವು ಹಲವಾರು ನಿಯತಾಂಕಗಳನ್ನು ಹೊಂದಿದೆ ಅದು ಅದು ಹೇಗೆ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ ಎಂಬುದನ್ನು ನಿಯಂತ್ರಿಸುತ್ತದೆ:
/// - `BorrowType`: ಒಂದು ರೀತಿಯ ಸಾಲವನ್ನು ವಿವರಿಸುವ ಮತ್ತು ಜೀವಿತಾವಧಿಯನ್ನು ಹೊಂದಿರುವ ನಕಲಿ ಪ್ರಕಾರ.
///    - ಇದು `Immut<'a>` ಆಗಿದ್ದಾಗ, `NodeRef` ಸರಿಸುಮಾರು `&'a Node` ನಂತೆ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ.
///    - ಇದು `ValMut<'a>` ಆಗಿದ್ದಾಗ, `NodeRef` ಕೀಗಳು ಮತ್ತು ಮರದ ರಚನೆಗೆ ಸಂಬಂಧಿಸಿದಂತೆ ಸರಿಸುಮಾರು `&'a Node` ನಂತೆ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ, ಆದರೆ ಮರದ ಉದ್ದಕ್ಕೂ ಇರುವ ಮೌಲ್ಯಗಳಿಗೆ ಅನೇಕ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳನ್ನು ಸಹಬಾಳ್ವೆಗೆ ಅನುಮತಿಸುತ್ತದೆ.
///    - ಇದು `Mut<'a>` ಆಗಿದ್ದಾಗ, `NodeRef` ಸರಿಸುಮಾರು `&'a mut Node` ನಂತೆ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ, ಆದರೂ ಇನ್ಸರ್ಟ್ ವಿಧಾನಗಳು ರೂಪಾಂತರಗೊಳ್ಳುವ ಪಾಯಿಂಟರ್ ಅನ್ನು ಒಂದು ಮೌಲ್ಯಕ್ಕೆ ಸಹಬಾಳ್ವೆಗೆ ಅನುಮತಿಸುತ್ತದೆ.
///    - ಇದು `Owned` ಆಗಿದ್ದಾಗ, `NodeRef` ಸರಿಸುಮಾರು `Box<Node>` ನಂತೆ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ, ಆದರೆ ವಿನಾಶಕವನ್ನು ಹೊಂದಿಲ್ಲ, ಮತ್ತು ಅದನ್ನು ಕೈಯಾರೆ ಸ್ವಚ್ ed ಗೊಳಿಸಬೇಕು.
///    - ಇದು `Dying` ಆಗಿದ್ದಾಗ, `NodeRef` ಇನ್ನೂ ಸರಿಸುಮಾರು `Box<Node>` ನಂತೆ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ, ಆದರೆ ಮರವನ್ನು ಬಿಟ್‌ನಿಂದ ನಾಶಮಾಡುವ ವಿಧಾನಗಳನ್ನು ಹೊಂದಿದೆ, ಮತ್ತು ಸಾಮಾನ್ಯ ವಿಧಾನಗಳು, ಕರೆ ಮಾಡಲು ಅಸುರಕ್ಷಿತವೆಂದು ಗುರುತಿಸದಿದ್ದರೂ, ತಪ್ಪಾಗಿ ಕರೆದರೆ UB ಯನ್ನು ಆಹ್ವಾನಿಸಬಹುದು.
///
///   ಯಾವುದೇ `NodeRef` ಮರದ ಮೂಲಕ ನ್ಯಾವಿಗೇಟ್ ಮಾಡಲು ಅನುಮತಿಸುವುದರಿಂದ, `BorrowType` ನೋಡ್‌ಗೆ ಮಾತ್ರವಲ್ಲದೆ ಇಡೀ ಮರಕ್ಕೂ ಪರಿಣಾಮಕಾರಿಯಾಗಿ ಅನ್ವಯಿಸುತ್ತದೆ.
/// - `K` ಮತ್ತು `V`: ಇವುಗಳು ನೋಡ್‌ಗಳಲ್ಲಿ ಸಂಗ್ರಹವಾಗಿರುವ ಕೀಗಳು ಮತ್ತು ಮೌಲ್ಯಗಳ ಪ್ರಕಾರಗಳಾಗಿವೆ.
/// - `Type`: ಇದು `Leaf`, `Internal`, ಅಥವಾ `LeafOrInternal` ಆಗಿರಬಹುದು.
/// ಇದು `Leaf` ಆಗಿದ್ದಾಗ, `NodeRef` ಎಲೆಯ ನೋಡ್‌ಗೆ ಸೂಚಿಸುತ್ತದೆ, ಇದು `Internal` ಆಗಿರುವಾಗ `NodeRef` ಆಂತರಿಕ ನೋಡ್‌ಗೆ ಸೂಚಿಸುತ್ತದೆ, ಮತ್ತು ಇದು `LeafOrInternal` ಆಗಿದ್ದಾಗ `NodeRef` ಎರಡೂ ರೀತಿಯ ನೋಡ್‌ಗೆ ಸೂಚಿಸುತ್ತದೆ.
///   `Type` `NodeRef` ಹೊರಗೆ ಬಳಸಿದಾಗ `NodeType` ಎಂದು ಹೆಸರಿಸಲಾಗಿದೆ.
///
/// ಸ್ಥಿರ ಪ್ರಕಾರದ ಸುರಕ್ಷತೆಯನ್ನು ಬಳಸಿಕೊಳ್ಳಲು ನಾವು ಯಾವ ವಿಧಾನಗಳನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತೇವೆ ಎಂಬುದನ್ನು `BorrowType` ಮತ್ತು `NodeType` ಎರಡೂ ನಿರ್ಬಂಧಿಸುತ್ತವೆ.ಅಂತಹ ನಿರ್ಬಂಧಗಳನ್ನು ನಾವು ಅನ್ವಯಿಸುವ ವಿಧಾನದಲ್ಲಿ ಮಿತಿಗಳಿವೆ:
/// - ಪ್ರತಿ ಪ್ರಕಾರದ ನಿಯತಾಂಕಕ್ಕಾಗಿ, ನಾವು ಒಂದು ವಿಧಾನವನ್ನು ಸಾಮಾನ್ಯವಾಗಿ ಅಥವಾ ಒಂದು ನಿರ್ದಿಷ್ಟ ಪ್ರಕಾರಕ್ಕೆ ಮಾತ್ರ ವ್ಯಾಖ್ಯಾನಿಸಬಹುದು.
/// ಉದಾಹರಣೆಗೆ, ನಾವು `into_kv` ನಂತಹ ವಿಧಾನವನ್ನು ಎಲ್ಲಾ `BorrowType` ಗೆ ಸಾಮಾನ್ಯವಾಗಿ ವ್ಯಾಖ್ಯಾನಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ, ಅಥವಾ ಒಮ್ಮೆ ಜೀವಿತಾವಧಿಯನ್ನು ಸಾಗಿಸುವ ಎಲ್ಲಾ ಪ್ರಕಾರಗಳಿಗೆ, ಏಕೆಂದರೆ ಅದು `&'a` ಉಲ್ಲೇಖಗಳನ್ನು ಹಿಂತಿರುಗಿಸಲು ನಾವು ಬಯಸುತ್ತೇವೆ.
///   ಆದ್ದರಿಂದ, ನಾವು ಅದನ್ನು ಕನಿಷ್ಠ ಶಕ್ತಿಯುತ `Immut<'a>` ಗೆ ಮಾತ್ರ ವ್ಯಾಖ್ಯಾನಿಸುತ್ತೇವೆ.
/// - `Mut<'a>` ನಿಂದ `Immut<'a>` ಗೆ ನಾವು ಸೂಚ್ಯ ದಬ್ಬಾಳಿಕೆಯನ್ನು ಪಡೆಯಲು ಸಾಧ್ಯವಿಲ್ಲ.
///   ಆದ್ದರಿಂದ, `into_kv` ನಂತಹ ವಿಧಾನವನ್ನು ತಲುಪಲು ನಾವು ಹೆಚ್ಚು ಶಕ್ತಿಯುತ `NodeRef` ನಲ್ಲಿ `reborrow` ಅನ್ನು ಸ್ಪಷ್ಟವಾಗಿ ಕರೆಯಬೇಕಾಗಿದೆ.
///
/// `NodeRef` ನಲ್ಲಿನ ಎಲ್ಲಾ ವಿಧಾನಗಳು ಕೆಲವು ರೀತಿಯ ಉಲ್ಲೇಖವನ್ನು ನೀಡುತ್ತದೆ,
/// - ಮೌಲ್ಯದಿಂದ `self` ತೆಗೆದುಕೊಳ್ಳಿ, ಮತ್ತು `BorrowType` ಹೊತ್ತ ಜೀವಿತಾವಧಿಯನ್ನು ಹಿಂತಿರುಗಿಸಿ.
///   ಕೆಲವೊಮ್ಮೆ, ಅಂತಹ ವಿಧಾನವನ್ನು ಆಹ್ವಾನಿಸಲು, ನಾವು `reborrow_mut` ಗೆ ಕರೆ ಮಾಡಬೇಕಾಗುತ್ತದೆ.
/// - `self` ಅನ್ನು ಉಲ್ಲೇಖದಿಂದ ತೆಗೆದುಕೊಳ್ಳಿ, ಮತ್ತು (implicitly) ಆ ಉಲ್ಲೇಖದ ಜೀವಿತಾವಧಿಯನ್ನು `BorrowType` ಹೊತ್ತೊಯ್ಯುವ ಜೀವಿತಾವಧಿಗೆ ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
/// ಆ ರೀತಿಯಲ್ಲಿ, ಹಿಂದಿರುಗಿದ ಉಲ್ಲೇಖವನ್ನು ಬಳಸುವವರೆಗೂ `NodeRef` ಎರವಲು ಪಡೆಯುತ್ತದೆ ಎಂದು ಸಾಲ ಪರೀಕ್ಷಕ ಖಾತರಿಪಡಿಸುತ್ತದೆ.
///   ಒಳಸೇರಿಸುವಿಕೆಯನ್ನು ಬೆಂಬಲಿಸುವ ವಿಧಾನಗಳು ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಅನ್ನು ಹಿಂದಿರುಗಿಸುವ ಮೂಲಕ ಈ ನಿಯಮವನ್ನು ಬಾಗಿಸುತ್ತವೆ, ಅಂದರೆ, ಯಾವುದೇ ಜೀವಿತಾವಧಿಯಿಲ್ಲದ ಉಲ್ಲೇಖ.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// ನೋಡ್ ಮತ್ತು ಎಲೆಗಳ ಮಟ್ಟವು ಪ್ರತ್ಯೇಕವಾಗಿರುವ ಮಟ್ಟಗಳ ಸಂಖ್ಯೆ, `Type` ನಿಂದ ಸಂಪೂರ್ಣವಾಗಿ ವಿವರಿಸಲಾಗದ ನೋಡ್ನ ಸ್ಥಿರ ಮತ್ತು ನೋಡ್ ಸ್ವತಃ ಸಂಗ್ರಹಿಸುವುದಿಲ್ಲ.
    /// ನಾವು ರೂಟ್ ನೋಡ್ನ ಎತ್ತರವನ್ನು ಮಾತ್ರ ಸಂಗ್ರಹಿಸಬೇಕಾಗಿದೆ ಮತ್ತು ಅದರಿಂದ ಪ್ರತಿ ಇತರ ನೋಡ್ನ ಎತ್ತರವನ್ನು ಪಡೆಯಬೇಕು.
    /// `Type` `Leaf` ಆಗಿದ್ದರೆ ಶೂನ್ಯವಾಗಿರಬೇಕು ಮತ್ತು `Type` `Internal` ಆಗಿದ್ದರೆ ಶೂನ್ಯವಲ್ಲ.
    ///
    ///
    height: usize,
    /// ಎಲೆ ಅಥವಾ ಆಂತರಿಕ ನೋಡ್‌ಗೆ ಪಾಯಿಂಟರ್.
    /// `InternalNode` ನ ವ್ಯಾಖ್ಯಾನವು ಪಾಯಿಂಟರ್ ಎರಡೂ ರೀತಿಯಲ್ಲಿ ಮಾನ್ಯವಾಗಿದೆ ಎಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// `NodeRef::parent` ಎಂದು ಪ್ಯಾಕ್ ಮಾಡಲಾದ ನೋಡ್ ಉಲ್ಲೇಖವನ್ನು ಅನ್ಪ್ಯಾಕ್ ಮಾಡಿ.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// ಆಂತರಿಕ ನೋಡ್ನ ಡೇಟಾವನ್ನು ಬಹಿರಂಗಪಡಿಸುತ್ತದೆ.
    ///
    /// ಈ ನೋಡ್‌ಗೆ ಇತರ ಉಲ್ಲೇಖಗಳನ್ನು ಅಮಾನ್ಯಗೊಳಿಸುವುದನ್ನು ತಪ್ಪಿಸಲು ಕಚ್ಚಾ ಪಿಟಿಆರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // ಸುರಕ್ಷತೆ: ಸ್ಥಿರ ನೋಡ್ ಪ್ರಕಾರವು `Internal` ಆಗಿದೆ.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// ಆಂತರಿಕ ನೋಡ್ನ ಡೇಟಾಗೆ ವಿಶೇಷ ಪ್ರವೇಶವನ್ನು ಎರವಲು ಪಡೆಯುತ್ತದೆ.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// ನೋಡ್ನ ಉದ್ದವನ್ನು ಹುಡುಕುತ್ತದೆ.ಇದು ಕೀಲಿಗಳು ಅಥವಾ ಮೌಲ್ಯಗಳ ಸಂಖ್ಯೆ.
    /// ಅಂಚುಗಳ ಸಂಖ್ಯೆ `len() + 1`.
    /// ಗಮನಿಸಿ, ಸುರಕ್ಷಿತವಾಗಿದ್ದರೂ, ಈ ಕಾರ್ಯವನ್ನು ಕರೆಯುವುದರಿಂದ ಅಸುರಕ್ಷಿತ ಕೋಡ್ ರಚಿಸಿದ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳನ್ನು ಅಮಾನ್ಯಗೊಳಿಸುವ ಅಡ್ಡಪರಿಣಾಮ ಉಂಟಾಗುತ್ತದೆ.
    ///
    pub fn len(&self) -> usize {
        // ಬಹುಮುಖ್ಯವಾಗಿ, ನಾವು ಇಲ್ಲಿ `len` ಕ್ಷೇತ್ರವನ್ನು ಮಾತ್ರ ಪ್ರವೇಶಿಸುತ್ತೇವೆ.
        // ಬಾರೊಟೈಪ್ marker::ValMut ಆಗಿದ್ದರೆ, ನಾವು ಅಮಾನ್ಯಗೊಳಿಸದ ಮೌಲ್ಯಗಳಿಗೆ ಬಾಕಿ ಉಳಿದಿರುವ ಉಲ್ಲೇಖಗಳು ಇರಬಹುದು.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// ನೋಡ್ ಮತ್ತು ಎಲೆಗಳು ಪ್ರತ್ಯೇಕವಾಗಿರುವ ಮಟ್ಟಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಶೂನ್ಯ ಎತ್ತರ ಎಂದರೆ ನೋಡ್ ಒಂದು ಎಲೆ.
    /// ನೀವು ಮೇಲಿನ ಮೂಲದೊಂದಿಗೆ ಮರಗಳನ್ನು ಚಿತ್ರಿಸಿದರೆ, ನೋಡ್ ಯಾವ ಎತ್ತರದಲ್ಲಿ ಕಾಣಿಸಿಕೊಳ್ಳುತ್ತದೆ ಎಂದು ಸಂಖ್ಯೆ ಹೇಳುತ್ತದೆ.
    /// ನೀವು ಮೇಲೆ ಎಲೆಗಳನ್ನು ಹೊಂದಿರುವ ಮರಗಳನ್ನು ಚಿತ್ರಿಸಿದರೆ, ಮರವು ನೋಡ್ಗಿಂತ ಎಷ್ಟು ಎತ್ತರಕ್ಕೆ ವಿಸ್ತರಿಸುತ್ತದೆ ಎಂದು ಸಂಖ್ಯೆ ಹೇಳುತ್ತದೆ.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// ಅದೇ ನೋಡ್‌ಗೆ ತಾತ್ಕಾಲಿಕವಾಗಿ ಮತ್ತೊಂದು, ಬದಲಾಗದ ಉಲ್ಲೇಖವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ಯಾವುದೇ ಎಲೆ ಅಥವಾ ಆಂತರಿಕ ನೋಡ್‌ನ ಎಲೆ ಭಾಗವನ್ನು ಒಡ್ಡುತ್ತದೆ.
    ///
    /// ಈ ನೋಡ್‌ಗೆ ಇತರ ಉಲ್ಲೇಖಗಳನ್ನು ಅಮಾನ್ಯಗೊಳಿಸುವುದನ್ನು ತಪ್ಪಿಸಲು ಕಚ್ಚಾ ಪಿಟಿಆರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // ನೋಡ್ ಕನಿಷ್ಠ ಲೀಫ್ನೋಡ್ ಭಾಗಕ್ಕೆ ಮಾನ್ಯವಾಗಿರಬೇಕು.
        // ಇದು ನೋಡ್ ರೀಫ್ ಪ್ರಕಾರದಲ್ಲಿ ಉಲ್ಲೇಖವಲ್ಲ ಏಕೆಂದರೆ ಅದು ಅನನ್ಯವಾಗಿದೆಯೇ ಅಥವಾ ಹಂಚಿಕೊಳ್ಳಬೇಕೆ ಎಂದು ನಮಗೆ ತಿಳಿದಿಲ್ಲ.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// ಪ್ರಸ್ತುತ ನೋಡ್ನ ಪೋಷಕರನ್ನು ಹುಡುಕುತ್ತದೆ.
    /// ಪ್ರಸ್ತುತ ನೋಡ್ ವಾಸ್ತವವಾಗಿ ಪೋಷಕರನ್ನು ಹೊಂದಿದ್ದರೆ `Ok(handle)` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಲ್ಲಿ `handle` ಪ್ರಸ್ತುತ ನೋಡ್‌ಗೆ ಸೂಚಿಸುವ ಪೋಷಕರ edge ಗೆ ಸೂಚಿಸುತ್ತದೆ.
    ///
    /// ಪ್ರಸ್ತುತ ನೋಡ್‌ಗೆ ಪೋಷಕರು ಇಲ್ಲದಿದ್ದರೆ `Err(self)` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಮೂಲ `NodeRef` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ವಿಧಾನದ ಹೆಸರು ನೀವು ಮೇಲಿನ ಮರದ ನೋಡ್ನೊಂದಿಗೆ ಮರಗಳನ್ನು ಚಿತ್ರಿಸುತ್ತದೆ ಎಂದು umes ಹಿಸುತ್ತದೆ.
    ///
    /// `edge.descend().ascend().unwrap()` ಮತ್ತು `node.ascend().unwrap().descend()` ಎರಡೂ ಯಶಸ್ಸಿನ ನಂತರ ಏನನ್ನೂ ಮಾಡಬಾರದು.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // ನಾವು ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ನೋಡ್‌ಗಳಿಗೆ ಬಳಸಬೇಕಾಗಿದೆ ಏಕೆಂದರೆ, ಬಾರೊಟೈಪ್ marker::ValMut ಆಗಿದ್ದರೆ, ನಾವು ಅಮಾನ್ಯಗೊಳಿಸದ ಮೌಲ್ಯಗಳಿಗೆ ಬಾಕಿ ಉಳಿದಿರುವ ಉಲ್ಲೇಖಗಳು ಇರಬಹುದು.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// `self` ನಿಸ್ಸಂಶಯವಾಗಿರಬೇಕು ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// `self` ನಿಸ್ಸಂಶಯವಾಗಿರಬೇಕು ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// ಬದಲಾಗದ ಮರದಲ್ಲಿ ಯಾವುದೇ ಎಲೆ ಅಥವಾ ಆಂತರಿಕ ನೋಡ್‌ನ ಎಲೆ ಭಾಗವನ್ನು ಒಡ್ಡುತ್ತದೆ.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // ಸುರಕ್ಷತೆ: `Immut` ಎಂದು ಎರವಲು ಪಡೆದ ಈ ಮರದ ಬಗ್ಗೆ ಯಾವುದೇ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳಿಲ್ಲ.
        unsafe { &*ptr }
    }

    /// ನೋಡ್‌ನಲ್ಲಿ ಸಂಗ್ರಹವಾಗಿರುವ ಕೀಲಿಗಳಿಗೆ ವೀಕ್ಷಣೆಯನ್ನು ಎರವಲು ಪಡೆಯುತ್ತದೆ.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// `ascend` ನಂತೆಯೇ, ನೋಡ್‌ನ ಮೂಲ ನೋಡ್‌ಗೆ ಉಲ್ಲೇಖವನ್ನು ಪಡೆಯುತ್ತದೆ, ಆದರೆ ಪ್ರಕ್ರಿಯೆಯಲ್ಲಿ ಪ್ರಸ್ತುತ ನೋಡ್ ಅನ್ನು ಸಹ ಡಿಲೊಕೊಲೇಟ್ ಮಾಡುತ್ತದೆ.
    /// ಇದು ಅಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ಪ್ರಸ್ತುತ ನೋಡ್ ಅನ್ನು ಸ್ಥಳಾಂತರಿಸಲಾಗಿದ್ದರೂ ಸಹ ಪ್ರವೇಶಿಸಬಹುದು.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ಈ ನೋಡ್ `Leaf` ಎಂದು ಸ್ಥಿರ ಮಾಹಿತಿಯನ್ನು ಕಂಪೈಲರ್‌ಗೆ ಅಸುರಕ್ಷಿತವಾಗಿ ಪ್ರತಿಪಾದಿಸುತ್ತದೆ.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ಈ ನೋಡ್ `Internal` ಎಂದು ಸ್ಥಿರ ಮಾಹಿತಿಯನ್ನು ಕಂಪೈಲರ್‌ಗೆ ಅಸುರಕ್ಷಿತವಾಗಿ ಪ್ರತಿಪಾದಿಸುತ್ತದೆ.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// ಅದೇ ನೋಡ್‌ಗೆ ತಾತ್ಕಾಲಿಕವಾಗಿ ಮತ್ತೊಂದು, ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.ಹುಷಾರಾಗಿರು, ಈ ವಿಧಾನವು ತುಂಬಾ ಅಪಾಯಕಾರಿಯಾದ ಕಾರಣ, ದುಪ್ಪಟ್ಟು ಆದ್ದರಿಂದ ಅದು ತಕ್ಷಣ ಅಪಾಯಕಾರಿಯಾಗಿ ಕಾಣಿಸುವುದಿಲ್ಲ.
    ///
    /// ರೂಪಾಂತರಿತ ಪಾಯಿಂಟರ್‌ಗಳು ಮರದ ಸುತ್ತಲೂ ಎಲ್ಲಿಯಾದರೂ ಸಂಚರಿಸುವುದರಿಂದ, ಹಿಂತಿರುಗಿದ ಪಾಯಿಂಟರ್ ಅನ್ನು ಮೂಲ ಪಾಯಿಂಟರ್ ಅನ್ನು ತೂಗಾಡಿಸಲು, ಮಿತಿ ಮೀರಿ ಅಥವಾ ಜೋಡಿಸಲಾದ ಸಾಲ ನಿಯಮಗಳ ಅಡಿಯಲ್ಲಿ ಅಮಾನ್ಯವಾಗಿಸಲು ಸುಲಭವಾಗಿ ಬಳಸಬಹುದು.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) `NodeRef` ಗೆ ಮತ್ತೊಂದು ಪ್ರಕಾರದ ನಿಯತಾಂಕವನ್ನು ಸೇರಿಸುವುದನ್ನು ಪರಿಗಣಿಸಿ, ಅದು ಮರುಬಳಕೆಯ ಪಾಯಿಂಟರ್‌ಗಳಲ್ಲಿ ನ್ಯಾವಿಗೇಷನ್ ವಿಧಾನಗಳ ಬಳಕೆಯನ್ನು ನಿರ್ಬಂಧಿಸುತ್ತದೆ, ಈ ಅಸುರಕ್ಷಿತತೆಯನ್ನು ತಡೆಯುತ್ತದೆ.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ಯಾವುದೇ ಎಲೆ ಅಥವಾ ಆಂತರಿಕ ನೋಡ್‌ನ ಎಲೆ ಭಾಗಕ್ಕೆ ವಿಶೇಷ ಪ್ರವೇಶವನ್ನು ಪಡೆಯುತ್ತದೆ.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // ಸುರಕ್ಷತೆ: ಸಂಪೂರ್ಣ ನೋಡ್‌ಗೆ ನಮಗೆ ವಿಶೇಷ ಪ್ರವೇಶವಿದೆ.
        unsafe { &mut *ptr }
    }

    /// ಯಾವುದೇ ಎಲೆ ಅಥವಾ ಆಂತರಿಕ ನೋಡ್‌ನ ಎಲೆ ಭಾಗಕ್ಕೆ ವಿಶೇಷ ಪ್ರವೇಶವನ್ನು ನೀಡುತ್ತದೆ.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // ಸುರಕ್ಷತೆ: ಸಂಪೂರ್ಣ ನೋಡ್‌ಗೆ ನಮಗೆ ವಿಶೇಷ ಪ್ರವೇಶವಿದೆ.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// ಕೀ ಶೇಖರಣಾ ಪ್ರದೇಶದ ಒಂದು ಅಂಶಕ್ಕೆ ವಿಶೇಷ ಪ್ರವೇಶವನ್ನು ಎರವಲು ಪಡೆಯುತ್ತದೆ.
    ///
    /// # Safety
    /// `index` 0. .CAPACITY ಗಡಿಯಲ್ಲಿದೆ
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರಿಗೆ ಸ್ವಯಂ ಕುರಿತು ಹೆಚ್ಚಿನ ವಿಧಾನಗಳನ್ನು ಕರೆಯಲು ಸಾಧ್ಯವಾಗುವುದಿಲ್ಲ
        // ಕೀ ಸ್ಲೈಸ್ ಉಲ್ಲೇಖವನ್ನು ಕೈಬಿಡುವವರೆಗೆ, ಸಾಲದ ಜೀವಿತಾವಧಿಯಲ್ಲಿ ನಮಗೆ ಅನನ್ಯ ಪ್ರವೇಶವಿದೆ.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// ನೋಡ್ನ ಮೌಲ್ಯ ಸಂಗ್ರಹ ಪ್ರದೇಶದ ಒಂದು ಅಂಶ ಅಥವಾ ಸ್ಲೈಸ್‌ಗೆ ವಿಶೇಷ ಪ್ರವೇಶವನ್ನು ಎರವಲು ಪಡೆಯುತ್ತದೆ.
    ///
    /// # Safety
    /// `index` 0. .CAPACITY ಗಡಿಯಲ್ಲಿದೆ
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರಿಗೆ ಸ್ವಯಂ ಕುರಿತು ಹೆಚ್ಚಿನ ವಿಧಾನಗಳನ್ನು ಕರೆಯಲು ಸಾಧ್ಯವಾಗುವುದಿಲ್ಲ
        // ಮೌಲ್ಯದ ಸ್ಲೈಸ್ ಉಲ್ಲೇಖವನ್ನು ಕೈಬಿಡುವವರೆಗೆ, ಸಾಲದ ಜೀವಿತಾವಧಿಯಲ್ಲಿ ನಮಗೆ ಅನನ್ಯ ಪ್ರವೇಶವಿದೆ.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// edge ವಿಷಯಗಳಿಗಾಗಿ ನೋಡ್‌ನ ಶೇಖರಣಾ ಪ್ರದೇಶದ ಒಂದು ಅಂಶ ಅಥವಾ ಸ್ಲೈಸ್‌ಗೆ ವಿಶೇಷ ಪ್ರವೇಶವನ್ನು ಎರವಲು ಪಡೆಯುತ್ತದೆ.
    ///
    /// # Safety
    /// `index` 0. .CAPACITY + 1 ರ ಗಡಿಯಲ್ಲಿದೆ
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರಿಗೆ ಸ್ವಯಂ ಕುರಿತು ಹೆಚ್ಚಿನ ವಿಧಾನಗಳನ್ನು ಕರೆಯಲು ಸಾಧ್ಯವಾಗುವುದಿಲ್ಲ
        // edge ಸ್ಲೈಸ್ ಉಲ್ಲೇಖವನ್ನು ಕೈಬಿಡುವವರೆಗೆ, ಏಕೆಂದರೆ ನಾವು ಸಾಲದ ಜೀವಿತಾವಧಿಯಲ್ಲಿ ಅನನ್ಯ ಪ್ರವೇಶವನ್ನು ಹೊಂದಿದ್ದೇವೆ.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - ನೋಡ್ `idx` ಗಿಂತ ಹೆಚ್ಚು ಪ್ರಾರಂಭಿಕ ಅಂಶಗಳನ್ನು ಹೊಂದಿದೆ.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // ಇತರ ಅಂಶಗಳಿಗೆ ಮಹೋನ್ನತ ಉಲ್ಲೇಖಗಳೊಂದಿಗೆ ಅಲಿಯಾಸ್ ಮಾಡುವುದನ್ನು ತಪ್ಪಿಸಲು ನಾವು ಆಸಕ್ತಿ ಹೊಂದಿರುವ ಒಂದು ಅಂಶಕ್ಕೆ ಮಾತ್ರ ಉಲ್ಲೇಖವನ್ನು ರಚಿಸುತ್ತೇವೆ, ನಿರ್ದಿಷ್ಟವಾಗಿ, ಹಿಂದಿನ ಪುನರಾವರ್ತನೆಗಳಲ್ಲಿ ಕರೆ ಮಾಡಿದವರಿಗೆ ಹಿಂತಿರುಗಿದವರು.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Rust ಸಂಚಿಕೆ #74679 ಕಾರಣ ನಾವು ಗಾತ್ರೀಕರಿಸದ ಅರೇ ಪಾಯಿಂಟರ್‌ಗಳಿಗೆ ಒತ್ತಾಯಿಸಬೇಕು.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// ನೋಡ್ನ ಉದ್ದಕ್ಕೆ ವಿಶೇಷ ಪ್ರವೇಶವನ್ನು ಎರವಲು ಪಡೆಯುತ್ತದೆ.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ನೋಡ್ನ ಇತರ ಉಲ್ಲೇಖಗಳನ್ನು ಅಮಾನ್ಯಗೊಳಿಸದೆ, ನೋಡ್ನ ಲಿಂಕ್ ಅನ್ನು ಅದರ ಮೂಲ edge ಗೆ ಹೊಂದಿಸುತ್ತದೆ.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// ಅದರ ಮೂಲ edge ಗೆ ರೂಟ್‌ನ ಲಿಂಕ್ ಅನ್ನು ತೆರವುಗೊಳಿಸುತ್ತದೆ.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿಯನ್ನು ನೋಡ್‌ನ ಕೊನೆಯಲ್ಲಿ ಸೇರಿಸುತ್ತದೆ.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// `range` ನಿಂದ ಹಿಂತಿರುಗಿಸಲಾದ ಪ್ರತಿಯೊಂದು ಐಟಂ ನೋಡ್‌ಗೆ ಮಾನ್ಯ edge ಸೂಚ್ಯಂಕವಾಗಿದೆ.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿಯನ್ನು ಮತ್ತು ನೋಡ್ನ ಕೊನೆಯಲ್ಲಿ ಆ ಜೋಡಿಯ ಬಲಕ್ಕೆ ಹೋಗಲು edge ಅನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// ನೋಡ್ `Internal` ನೋಡ್ ಅಥವಾ `Leaf` ನೋಡ್ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// ನಿರ್ದಿಷ್ಟ ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿ ಅಥವಾ ನೋಡ್‌ನೊಳಗಿನ edge ಗೆ ಉಲ್ಲೇಖ.
/// `Node` ನಿಯತಾಂಕವು `NodeRef` ಆಗಿರಬೇಕು, ಆದರೆ `Type` `KV` ಆಗಿರಬಹುದು (ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿಯಲ್ಲಿ ಹ್ಯಾಂಡಲ್ ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ) ಅಥವಾ `Edge` (edge ನಲ್ಲಿ ಹ್ಯಾಂಡಲ್ ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ).
///
/// `Leaf` ನೋಡ್‌ಗಳು ಸಹ `Edge` ಹ್ಯಾಂಡಲ್‌ಗಳನ್ನು ಹೊಂದಬಹುದು ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
/// ಮಕ್ಕಳ ನೋಡ್‌ಗೆ ಪಾಯಿಂಟರ್ ಅನ್ನು ಪ್ರತಿನಿಧಿಸುವ ಬದಲು, ಇವು ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿಗಳ ನಡುವೆ ಮಕ್ಕಳ ಪಾಯಿಂಟರ್‌ಗಳು ಹೋಗುವ ಸ್ಥಳಗಳನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತವೆ.
/// ಉದಾಹರಣೆಗೆ, ಉದ್ದ 2 ಹೊಂದಿರುವ ನೋಡ್‌ನಲ್ಲಿ, 3 ಸಂಭವನೀಯ edge ಸ್ಥಳಗಳು, ನೋಡ್‌ನ ಎಡಕ್ಕೆ ಒಂದು, ಎರಡು ಜೋಡಿಗಳ ನಡುವೆ ಒಂದು, ಮತ್ತು ನೋಡ್‌ನ ಬಲಭಾಗದಲ್ಲಿ ಒಂದು ಇರುತ್ತದೆ.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// ನಮಗೆ `#[derive(Clone)]` ನ ಸಂಪೂರ್ಣ ಸಾಮಾನ್ಯತೆಯ ಅಗತ್ಯವಿಲ್ಲ, ಏಕೆಂದರೆ `Node` ಕೇವಲ ಸಮಯವಲ್ಲದ ಉಲ್ಲೇಖವಾಗಿದ್ದಾಗ `ಕ್ಲೋನ್` ಆಗಿರುತ್ತದೆ ಮತ್ತು ಆದ್ದರಿಂದ `Copy` ಆಗಿರುತ್ತದೆ.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// ಈ ಹ್ಯಾಂಡಲ್ ಸೂಚಿಸುವ edge ಅಥವಾ ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿಯನ್ನು ಹೊಂದಿರುವ ನೋಡ್ ಅನ್ನು ಹಿಂಪಡೆಯುತ್ತದೆ.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// ನೋಡ್ನಲ್ಲಿ ಈ ಹ್ಯಾಂಡಲ್ನ ಸ್ಥಾನವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// `node` ನಲ್ಲಿ ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿಗೆ ಹೊಸ ಹ್ಯಾಂಡಲ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    /// ಅಸುರಕ್ಷಿತ ಏಕೆಂದರೆ ಕರೆ ಮಾಡುವವರು `idx < node.len()` ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// ಭಾಗಶಃ ಎಕ್ನ ಸಾರ್ವಜನಿಕ ಅನುಷ್ಠಾನವಾಗಬಹುದು, ಆದರೆ ಈ ಮಾಡ್ಯೂಲ್ನಲ್ಲಿ ಮಾತ್ರ ಬಳಸಲಾಗುತ್ತದೆ.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// ಅದೇ ಸ್ಥಳದಲ್ಲಿ ತಾತ್ಕಾಲಿಕವಾಗಿ ಮತ್ತೊಂದು, ಬದಲಾಗದ ಹ್ಯಾಂಡಲ್ ಅನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // ನಮ್ಮ ಪ್ರಕಾರ ನಮಗೆ ತಿಳಿದಿಲ್ಲದ ಕಾರಣ ನಾವು Handle::new_kv ಅಥವಾ Handle::new_edge ಅನ್ನು ಬಳಸಲಾಗುವುದಿಲ್ಲ
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// ಹ್ಯಾಂಡಲ್ನ ನೋಡ್ `Leaf` ಎಂದು ಸ್ಥಿರ ಮಾಹಿತಿಯನ್ನು ಕಂಪೈಲರ್ಗೆ ಅಸುರಕ್ಷಿತವಾಗಿ ಪ್ರತಿಪಾದಿಸುತ್ತದೆ.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// ಅದೇ ಸ್ಥಳದಲ್ಲಿ ತಾತ್ಕಾಲಿಕವಾಗಿ ಮತ್ತೊಂದು, ರೂಪಾಂತರಿತ ಹ್ಯಾಂಡಲ್ ಅನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    /// ಹುಷಾರಾಗಿರು, ಈ ವಿಧಾನವು ತುಂಬಾ ಅಪಾಯಕಾರಿಯಾದ ಕಾರಣ, ದುಪ್ಪಟ್ಟು ಆದ್ದರಿಂದ ಅದು ತಕ್ಷಣ ಅಪಾಯಕಾರಿಯಾಗಿ ಕಾಣಿಸುವುದಿಲ್ಲ.
    ///
    ///
    /// ವಿವರಗಳಿಗಾಗಿ, `NodeRef::reborrow_mut` ನೋಡಿ.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // ನಮ್ಮ ಪ್ರಕಾರ ನಮಗೆ ತಿಳಿದಿಲ್ಲದ ಕಾರಣ ನಾವು Handle::new_kv ಅಥವಾ Handle::new_edge ಅನ್ನು ಬಳಸಲಾಗುವುದಿಲ್ಲ
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// `node` ನಲ್ಲಿ edge ಗೆ ಹೊಸ ಹ್ಯಾಂಡಲ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    /// ಅಸುರಕ್ಷಿತ ಏಕೆಂದರೆ ಕರೆ ಮಾಡುವವರು `idx <= node.len()` ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// edge ಸೂಚಿಯನ್ನು ನೀಡಿದರೆ, ಅಲ್ಲಿ ನಾವು ಸಾಮರ್ಥ್ಯಕ್ಕೆ ತುಂಬಿದ ನೋಡ್‌ಗೆ ಸೇರಿಸಲು ಬಯಸುತ್ತೇವೆ, ವಿಭಜಿತ ಬಿಂದುವಿನ ಸಂವೇದನಾಶೀಲ ಕೆವಿ ಸೂಚ್ಯಂಕವನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ ಮತ್ತು ಒಳಸೇರಿಸುವಿಕೆಯನ್ನು ಎಲ್ಲಿ ನಿರ್ವಹಿಸಬೇಕು.
///
/// ಸ್ಪ್ಲಿಟ್ ಪಾಯಿಂಟ್‌ನ ಗುರಿ ಅದರ ಕೀ ಮತ್ತು ಮೌಲ್ಯವು ಮೂಲ ನೋಡ್‌ನಲ್ಲಿ ಕೊನೆಗೊಳ್ಳುವುದು;
/// ವಿಭಜಿತ ಬಿಂದುವಿನ ಎಡಭಾಗದಲ್ಲಿರುವ ಕೀಲಿಗಳು, ಮೌಲ್ಯಗಳು ಮತ್ತು ಅಂಚುಗಳು ಎಡ ಮಗುವಾಗುತ್ತವೆ;
/// ವಿಭಜಿತ ಬಿಂದುವಿನ ಬಲಭಾಗದಲ್ಲಿರುವ ಕೀಲಿಗಳು, ಮೌಲ್ಯಗಳು ಮತ್ತು ಅಂಚುಗಳು ಸರಿಯಾದ ಮಗುವಾಗುತ್ತವೆ.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust ಸಂಚಿಕೆ #74834 ಈ ಸಮ್ಮಿತೀಯ ನಿಯಮಗಳನ್ನು ವಿವರಿಸಲು ಪ್ರಯತ್ನಿಸುತ್ತದೆ.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ಈ edge ನ ಬಲ ಮತ್ತು ಎಡಕ್ಕೆ ಕೀ-ಮೌಲ್ಯ ಜೋಡಿಗಳ ನಡುವೆ ಹೊಸ ಕೀ-ಮೌಲ್ಯ ಜೋಡಿಯನ್ನು ಸೇರಿಸುತ್ತದೆ.
    /// ಹೊಸ ಜೋಡಿಯು ಹೊಂದಿಕೊಳ್ಳಲು ನೋಡ್‌ನಲ್ಲಿ ಸಾಕಷ್ಟು ಸ್ಥಳವಿದೆ ಎಂದು ಈ ವಿಧಾನವು umes ಹಿಸುತ್ತದೆ.
    ///
    /// ಹಿಂತಿರುಗಿದ ಪಾಯಿಂಟರ್ ಸೇರಿಸಿದ ಮೌಲ್ಯಕ್ಕೆ ಸೂಚಿಸುತ್ತದೆ.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ಈ edge ನ ಬಲ ಮತ್ತು ಎಡಕ್ಕೆ ಕೀ-ಮೌಲ್ಯ ಜೋಡಿಗಳ ನಡುವೆ ಹೊಸ ಕೀ-ಮೌಲ್ಯ ಜೋಡಿಯನ್ನು ಸೇರಿಸುತ್ತದೆ.
    /// ಸಾಕಷ್ಟು ಸ್ಥಳವಿಲ್ಲದಿದ್ದರೆ ಈ ವಿಧಾನವು ನೋಡ್ ಅನ್ನು ವಿಭಜಿಸುತ್ತದೆ.
    ///
    /// ಹಿಂತಿರುಗಿದ ಪಾಯಿಂಟರ್ ಸೇರಿಸಿದ ಮೌಲ್ಯಕ್ಕೆ ಸೂಚಿಸುತ್ತದೆ.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// ಈ edge ಲಿಂಕ್ ಮಾಡುವ ಮಕ್ಕಳ ನೋಡ್‌ನಲ್ಲಿ ಮೂಲ ಪಾಯಿಂಟರ್ ಮತ್ತು ಸೂಚಿಯನ್ನು ಸರಿಪಡಿಸುತ್ತದೆ.
    /// ಅಂಚುಗಳ ಕ್ರಮವನ್ನು ಬದಲಾಯಿಸಿದಾಗ ಇದು ಉಪಯುಕ್ತವಾಗಿದೆ,
    fn correct_parent_link(self) {
        // ನೋಡ್‌ಗೆ ಇತರ ಉಲ್ಲೇಖಗಳನ್ನು ಅಮಾನ್ಯಗೊಳಿಸದೆ ಬ್ಯಾಕ್‌ಪಾಯಿಂಟರ್ ರಚಿಸಿ.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// ಹೊಸ ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿ ಮತ್ತು edge ಅನ್ನು ಸೇರಿಸುತ್ತದೆ, ಅದು ಈ edge ಮತ್ತು ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿಯ ನಡುವೆ ಈ edge ನ ಬಲಕ್ಕೆ ಹೋಗುತ್ತದೆ.
    /// ಹೊಸ ಜೋಡಿಯು ಹೊಂದಿಕೊಳ್ಳಲು ನೋಡ್‌ನಲ್ಲಿ ಸಾಕಷ್ಟು ಸ್ಥಳವಿದೆ ಎಂದು ಈ ವಿಧಾನವು umes ಹಿಸುತ್ತದೆ.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// ಹೊಸ ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿ ಮತ್ತು edge ಅನ್ನು ಸೇರಿಸುತ್ತದೆ, ಅದು ಈ edge ಮತ್ತು ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿಯ ನಡುವೆ ಈ edge ನ ಬಲಕ್ಕೆ ಹೋಗುತ್ತದೆ.
    /// ಸಾಕಷ್ಟು ಸ್ಥಳವಿಲ್ಲದಿದ್ದರೆ ಈ ವಿಧಾನವು ನೋಡ್ ಅನ್ನು ವಿಭಜಿಸುತ್ತದೆ.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ಈ edge ನ ಬಲ ಮತ್ತು ಎಡಕ್ಕೆ ಕೀ-ಮೌಲ್ಯ ಜೋಡಿಗಳ ನಡುವೆ ಹೊಸ ಕೀ-ಮೌಲ್ಯ ಜೋಡಿಯನ್ನು ಸೇರಿಸುತ್ತದೆ.
    /// ಸಾಕಷ್ಟು ಸ್ಥಳವಿಲ್ಲದಿದ್ದರೆ ಈ ವಿಧಾನವು ನೋಡ್ ಅನ್ನು ವಿಭಜಿಸುತ್ತದೆ, ಮತ್ತು ಮೂಲವನ್ನು ತಲುಪುವವರೆಗೆ ವಿಭಜಿತ ಭಾಗವನ್ನು ಪುನರಾವರ್ತಿತವಾಗಿ ಮೂಲ ನೋಡ್‌ಗೆ ಸೇರಿಸಲು ಪ್ರಯತ್ನಿಸುತ್ತದೆ.
    ///
    ///
    /// ಹಿಂತಿರುಗಿದ ಫಲಿತಾಂಶವು `Fit` ಆಗಿದ್ದರೆ, ಅದರ ಹ್ಯಾಂಡಲ್‌ನ ನೋಡ್ ಈ edge ನ ನೋಡ್ ಅಥವಾ ಪೂರ್ವಜರಾಗಿರಬಹುದು.
    /// ಹಿಂತಿರುಗಿದ ಫಲಿತಾಂಶವು `Split` ಆಗಿದ್ದರೆ, `left` ಕ್ಷೇತ್ರವು ರೂಟ್ ನೋಡ್ ಆಗಿರುತ್ತದೆ.
    /// ಹಿಂತಿರುಗಿದ ಪಾಯಿಂಟರ್ ಸೇರಿಸಿದ ಮೌಲ್ಯಕ್ಕೆ ಸೂಚಿಸುತ್ತದೆ.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// ಈ edge ಸೂಚಿಸಿದ ನೋಡ್ ಅನ್ನು ಹುಡುಕುತ್ತದೆ.
    ///
    /// ವಿಧಾನದ ಹೆಸರು ನೀವು ಮೇಲಿನ ಮರದ ನೋಡ್ನೊಂದಿಗೆ ಮರಗಳನ್ನು ಚಿತ್ರಿಸುತ್ತದೆ ಎಂದು umes ಹಿಸುತ್ತದೆ.
    ///
    /// `edge.descend().ascend().unwrap()` ಮತ್ತು `node.ascend().unwrap().descend()` ಎರಡೂ ಯಶಸ್ಸಿನ ನಂತರ ಏನನ್ನೂ ಮಾಡಬಾರದು.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // ನಾವು ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ನೋಡ್‌ಗಳಿಗೆ ಬಳಸಬೇಕಾಗಿದೆ ಏಕೆಂದರೆ, ಬಾರೊಟೈಪ್ marker::ValMut ಆಗಿದ್ದರೆ, ನಾವು ಅಮಾನ್ಯಗೊಳಿಸದ ಮೌಲ್ಯಗಳಿಗೆ ಬಾಕಿ ಉಳಿದಿರುವ ಉಲ್ಲೇಖಗಳು ಇರಬಹುದು.
        // ಎತ್ತರ ಕ್ಷೇತ್ರವನ್ನು ಪ್ರವೇಶಿಸಲು ಯಾವುದೇ ಚಿಂತೆಯಿಲ್ಲ ಏಕೆಂದರೆ ಆ ಮೌಲ್ಯವನ್ನು ನಕಲಿಸಲಾಗಿದೆ.
        // ನೋಡ್ ಪಾಯಿಂಟರ್ ಅನ್ನು ಒಮ್ಮೆ ಡಿಫರೆನ್ಸ್ ಮಾಡಿದ ನಂತರ, ನಾವು ಅಂಚುಗಳ ಶ್ರೇಣಿಯನ್ನು ಒಂದು ಉಲ್ಲೇಖದೊಂದಿಗೆ (Rust ಸಂಚಿಕೆ #73987) ಪ್ರವೇಶಿಸುತ್ತೇವೆ ಮತ್ತು ರಚನೆಯ ಒಳಗೆ ಅಥವಾ ಒಳಗೆ ಬೇರೆ ಯಾವುದೇ ಉಲ್ಲೇಖಗಳನ್ನು ಅಮಾನ್ಯಗೊಳಿಸುತ್ತೇವೆ, ಯಾವುದಾದರೂ ಸುತ್ತಲೂ ಇರಲಿ.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // ನಾವು ಪ್ರತ್ಯೇಕ ಕೀ ಮತ್ತು ಮೌಲ್ಯ ವಿಧಾನಗಳನ್ನು ಕರೆಯಲು ಸಾಧ್ಯವಿಲ್ಲ, ಏಕೆಂದರೆ ಎರಡನೆಯದನ್ನು ಕರೆಯುವುದರಿಂದ ಮೊದಲನೆಯದು ಹಿಂದಿರುಗಿದ ಉಲ್ಲೇಖವನ್ನು ಅಮಾನ್ಯಗೊಳಿಸುತ್ತದೆ.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// ಕೆವಿ ಹ್ಯಾಂಡಲ್ ಸೂಚಿಸುವ ಕೀ ಮತ್ತು ಮೌಲ್ಯವನ್ನು ಬದಲಾಯಿಸಿ.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// ಎಲೆಗಳ ಡೇಟಾವನ್ನು ನೋಡಿಕೊಳ್ಳುವ ಮೂಲಕ ನಿರ್ದಿಷ್ಟ `NodeType` ಗಾಗಿ `split` ನ ಅನುಷ್ಠಾನಕ್ಕೆ ಸಹಾಯ ಮಾಡುತ್ತದೆ.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// ಆಧಾರವಾಗಿರುವ ನೋಡ್ ಅನ್ನು ಮೂರು ಭಾಗಗಳಾಗಿ ವಿಭಜಿಸುತ್ತದೆ:
    ///
    /// - ಈ ಹ್ಯಾಂಡಲ್‌ನ ಎಡಭಾಗದಲ್ಲಿರುವ ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿಗಳನ್ನು ಮಾತ್ರ ಹೊಂದಲು ನೋಡ್ ಅನ್ನು ಮೊಟಕುಗೊಳಿಸಲಾಗುತ್ತದೆ.
    /// - ಈ ಹ್ಯಾಂಡಲ್ ಸೂಚಿಸಿದ ಕೀ ಮತ್ತು ಮೌಲ್ಯವನ್ನು ಹೊರತೆಗೆಯಲಾಗುತ್ತದೆ.
    /// - ಈ ಹ್ಯಾಂಡಲ್‌ನ ಬಲಭಾಗದಲ್ಲಿರುವ ಎಲ್ಲಾ ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿಗಳನ್ನು ಹೊಸದಾಗಿ ನಿಯೋಜಿಸಲಾದ ನೋಡ್‌ಗೆ ಹಾಕಲಾಗುತ್ತದೆ.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// ಈ ಹ್ಯಾಂಡಲ್‌ನಿಂದ ಸೂಚಿಸಲಾದ ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿಯನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ ಮತ್ತು ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿ ಕುಸಿದ edge ಜೊತೆಗೆ ಅದನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// ಆಧಾರವಾಗಿರುವ ನೋಡ್ ಅನ್ನು ಮೂರು ಭಾಗಗಳಾಗಿ ವಿಭಜಿಸುತ್ತದೆ:
    ///
    /// - ಈ ಹ್ಯಾಂಡಲ್‌ನ ಎಡಭಾಗದಲ್ಲಿರುವ ಅಂಚುಗಳು ಮತ್ತು ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿಗಳನ್ನು ಮಾತ್ರ ಹೊಂದಲು ನೋಡ್ ಅನ್ನು ಮೊಟಕುಗೊಳಿಸಲಾಗುತ್ತದೆ.
    /// - ಈ ಹ್ಯಾಂಡಲ್ ಸೂಚಿಸಿದ ಕೀ ಮತ್ತು ಮೌಲ್ಯವನ್ನು ಹೊರತೆಗೆಯಲಾಗುತ್ತದೆ.
    /// - ಈ ಹ್ಯಾಂಡಲ್‌ನ ಬಲಭಾಗದಲ್ಲಿರುವ ಎಲ್ಲಾ ಅಂಚುಗಳು ಮತ್ತು ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿಗಳನ್ನು ಹೊಸದಾಗಿ ನಿಯೋಜಿಸಲಾದ ನೋಡ್‌ಗೆ ಹಾಕಲಾಗುತ್ತದೆ.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// ಆಂತರಿಕ ಕೀ-ಮೌಲ್ಯ ಜೋಡಿಯ ಸುತ್ತ ಸಮತೋಲನ ಕಾರ್ಯಾಚರಣೆಯನ್ನು ಮೌಲ್ಯಮಾಪನ ಮಾಡಲು ಮತ್ತು ನಿರ್ವಹಿಸಲು ಅಧಿವೇಶನವನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ಬಾಲ್ಯದಲ್ಲಿ ನೋಡ್ ಅನ್ನು ಒಳಗೊಂಡಿರುವ ಸಮತೋಲನ ಸಂದರ್ಭವನ್ನು ಆಯ್ಕೆ ಮಾಡುತ್ತದೆ, ಹೀಗಾಗಿ ಕೆವಿ ನಡುವೆ ತಕ್ಷಣ ಎಡಕ್ಕೆ ಅಥವಾ ಪೋಷಕ ನೋಡ್ನಲ್ಲಿ ಬಲಕ್ಕೆ.
    /// ಪೋಷಕರು ಇಲ್ಲದಿದ್ದರೆ `Err` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಪೋಷಕರು ಖಾಲಿಯಾಗಿದ್ದರೆ Panics.
    ///
    /// ಕೊಟ್ಟಿರುವ ನೋಡ್ ಹೇಗಾದರೂ ಅಂಡರ್ಫುಲ್ ಆಗಿದ್ದರೆ ಸೂಕ್ತವಾಗಲು ಎಡಭಾಗವನ್ನು ಆದ್ಯತೆ ನೀಡುತ್ತದೆ, ಇದರರ್ಥ ಇಲ್ಲಿ ಅದು ಎಡ ಸಹೋದರರಿಗಿಂತ ಕಡಿಮೆ ಅಂಶಗಳನ್ನು ಮತ್ತು ಅದರ ಬಲ ಒಡಹುಟ್ಟಿದವರಿಗಿಂತ ಕಡಿಮೆ ಅಂಶಗಳನ್ನು ಹೊಂದಿದೆ.
    /// ಅಂತಹ ಸಂದರ್ಭದಲ್ಲಿ, ಎಡ ಒಡಹುಟ್ಟಿದವರೊಂದಿಗೆ ವಿಲೀನಗೊಳ್ಳುವುದು ವೇಗವಾಗಿರುತ್ತದೆ, ಏಕೆಂದರೆ ನಾವು ನೋಡ್‌ನ N ಅಂಶಗಳನ್ನು ಮಾತ್ರ ಬಲಕ್ಕೆ ವರ್ಗಾಯಿಸುವ ಬದಲು ಮತ್ತು ಮುಂದೆ N ಅಂಶಗಳಿಗಿಂತ ಹೆಚ್ಚು ಚಲಿಸುವ ಬದಲು ಚಲಿಸಬೇಕಾಗುತ್ತದೆ.
    /// ಎಡ ಒಡಹುಟ್ಟಿದವರಿಂದ ಕದಿಯುವುದು ಸಹ ಸಾಮಾನ್ಯವಾಗಿ ವೇಗವಾಗಿರುತ್ತದೆ, ಏಕೆಂದರೆ ನಾವು ಒಡಹುಟ್ಟಿದವರ ಅಂಶಗಳಲ್ಲಿ ಕನಿಷ್ಠ N ಅನ್ನು ಎಡಕ್ಕೆ ವರ್ಗಾಯಿಸುವ ಬದಲು ನೋಡ್‌ನ N ಅಂಶಗಳನ್ನು ಬಲಕ್ಕೆ ವರ್ಗಾಯಿಸಬೇಕಾಗುತ್ತದೆ.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// ವಿಲೀನಗೊಳ್ಳಲು ಸಾಧ್ಯವಿದೆಯೇ ಎಂದು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಂದರೆ, ಕೇಂದ್ರ ಕೆವಿಯನ್ನು ಪಕ್ಕದ ಎರಡೂ ಮಕ್ಕಳ ನೋಡ್‌ಗಳೊಂದಿಗೆ ಸಂಯೋಜಿಸಲು ನೋಡ್‌ನಲ್ಲಿ ಸಾಕಷ್ಟು ಸ್ಥಳವಿದೆಯೇ ಎಂದು.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// ವಿಲೀನವನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ ಮತ್ತು ಮುಚ್ಚುವಿಕೆಯು ಏನು ಹಿಂದಿರುಗಿಸಬೇಕೆಂದು ನಿರ್ಧರಿಸಲು ಅನುವು ಮಾಡಿಕೊಡುತ್ತದೆ.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // ಸುರಕ್ಷತೆ: ವಿಲೀನಗೊಳ್ಳುವ ನೋಡ್‌ಗಳ ಎತ್ತರವು ಎತ್ತರಕ್ಕಿಂತ ಒಂದು
                // ಈ edge ನ ನೋಡ್‌ನ, ಆದ್ದರಿಂದ ಶೂನ್ಯಕ್ಕಿಂತ ಮೇಲಿರುತ್ತದೆ, ಆದ್ದರಿಂದ ಅವು ಆಂತರಿಕವಾಗಿರುತ್ತವೆ.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// ಪೋಷಕರ ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿ ಮತ್ತು ಪಕ್ಕದ ಮಕ್ಕಳ ನೋಡ್‌ಗಳನ್ನು ಎಡ ಮಕ್ಕಳ ನೋಡ್‌ಗೆ ವಿಲೀನಗೊಳಿಸುತ್ತದೆ ಮತ್ತು ಕುಗ್ಗಿದ ಪೋಷಕ ನೋಡ್ ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// ನಾವು `.can_merge()` ಹೊರತು Panics.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// ಪೋಷಕರ ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿ ಮತ್ತು ಪಕ್ಕದ ಮಕ್ಕಳ ನೋಡ್‌ಗಳನ್ನು ಎಡ ಮಕ್ಕಳ ನೋಡ್‌ಗೆ ವಿಲೀನಗೊಳಿಸುತ್ತದೆ ಮತ್ತು ಆ ಮಕ್ಕಳ ನೋಡ್ ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// ನಾವು `.can_merge()` ಹೊರತು Panics.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// ಪೋಷಕರ ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿ ಮತ್ತು ಪಕ್ಕದ ಮಕ್ಕಳ ನೋಡ್‌ಗಳನ್ನು ಎಡ ಮಕ್ಕಳ ನೋಡ್‌ಗೆ ವಿಲೀನಗೊಳಿಸುತ್ತದೆ ಮತ್ತು ಟ್ರ್ಯಾಕ್ ಮಾಡಲಾದ ಮಗು edge ಕೊನೆಗೊಂಡ ಆ ಮಕ್ಕಳ ನೋಡ್‌ನಲ್ಲಿ edge ಹ್ಯಾಂಡಲ್ ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ,
    ///
    ///
    /// ನಾವು `.can_merge()` ಹೊರತು Panics.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿಯನ್ನು ಎಡ ಮಗುವಿನಿಂದ ತೆಗೆದುಹಾಕಿ ಮತ್ತು ಅದನ್ನು ಪೋಷಕರ ಕೀ-ಮೌಲ್ಯ ಸಂಗ್ರಹದಲ್ಲಿ ಇಡುತ್ತದೆ, ಅದೇ ಸಮಯದಲ್ಲಿ ಹಳೆಯ ಪೋಷಕ ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿಯನ್ನು ಸರಿಯಾದ ಮಗುವಿಗೆ ತಳ್ಳುತ್ತದೆ.
    ///
    /// `track_right_edge_idx` ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಮೂಲ edge ಕೊನೆಗೊಂಡ ಸ್ಥಳಕ್ಕೆ ಅನುಗುಣವಾಗಿ ಸರಿಯಾದ ಮಗುವಿನಲ್ಲಿ edge ಗೆ ಹ್ಯಾಂಡಲ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿಯನ್ನು ಸರಿಯಾದ ಮಗುವಿನಿಂದ ತೆಗೆದುಹಾಕಿ ಮತ್ತು ಅದನ್ನು ಪೋಷಕರ ಕೀ-ಮೌಲ್ಯ ಸಂಗ್ರಹದಲ್ಲಿ ಇಡುತ್ತದೆ, ಅದೇ ಸಮಯದಲ್ಲಿ ಹಳೆಯ ಪೋಷಕ ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿಯನ್ನು ಎಡ ಮಗುವಿನ ಮೇಲೆ ತಳ್ಳುತ್ತದೆ.
    ///
    /// `track_left_edge_idx` ನಿಂದ ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಎಡ ಮಗುವಿನಲ್ಲಿ edge ಗೆ ಹ್ಯಾಂಡಲ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅದು ಚಲಿಸಲಿಲ್ಲ.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// ಇದು `steal_left` ನಂತೆಯೇ ಕದಿಯುತ್ತದೆ ಆದರೆ ಏಕಕಾಲದಲ್ಲಿ ಅನೇಕ ಅಂಶಗಳನ್ನು ಕದಿಯುತ್ತದೆ.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // ನಾವು ಸುರಕ್ಷಿತವಾಗಿ ಕದಿಯಬಹುದೆಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // ಎಲೆ ಡೇಟಾವನ್ನು ಸರಿಸಿ.
            {
                // ಸರಿಯಾದ ಮಗುವಿನಲ್ಲಿ ಕದ್ದ ಅಂಶಗಳಿಗೆ ಸ್ಥಳಾವಕಾಶ ಕಲ್ಪಿಸಿ.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // ಅಂಶಗಳನ್ನು ಎಡ ಮಗುವಿನಿಂದ ಬಲಕ್ಕೆ ಸರಿಸಿ.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // ಎಡ-ಹೆಚ್ಚು ಕದ್ದ ಜೋಡಿಯನ್ನು ಪೋಷಕರಿಗೆ ಸರಿಸಿ.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // ಪೋಷಕರ ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿಯನ್ನು ಸರಿಯಾದ ಮಗುವಿಗೆ ಸರಿಸಿ.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // ಕದ್ದ ಅಂಚುಗಳಿಗೆ ಸ್ಥಳಾವಕಾಶ ಕಲ್ಪಿಸಿ.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // ಅಂಚುಗಳನ್ನು ಕದಿಯಿರಿ.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left` ನ ಸಮ್ಮಿತೀಯ ತದ್ರೂಪಿ.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // ನಾವು ಸುರಕ್ಷಿತವಾಗಿ ಕದಿಯಬಹುದೆಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // ಎಲೆ ಡೇಟಾವನ್ನು ಸರಿಸಿ.
            {
                // ಬಲಕ್ಕೆ ಹೆಚ್ಚು ಕದ್ದ ಜೋಡಿಯನ್ನು ಪೋಷಕರಿಗೆ ಸರಿಸಿ.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // ಪೋಷಕರ ಕೀ-ಮೌಲ್ಯದ ಜೋಡಿಯನ್ನು ಎಡ ಮಗುವಿಗೆ ಸರಿಸಿ.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // ಅಂಶಗಳನ್ನು ಬಲ ಮಗುವಿನಿಂದ ಎಡಕ್ಕೆ ಸರಿಸಿ.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // ಕದ್ದ ಅಂಶಗಳು ಇರುವ ಅಂತರವನ್ನು ಭರ್ತಿ ಮಾಡಿ.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // ಅಂಚುಗಳನ್ನು ಕದಿಯಿರಿ.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // ಕದ್ದ ಅಂಚುಗಳು ಇರುವ ಜಾಗವನ್ನು ಭರ್ತಿ ಮಾಡಿ.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// ಈ ನೋಡ್ `Leaf` ನೋಡ್ ಎಂದು ಪ್ರತಿಪಾದಿಸುವ ಯಾವುದೇ ಸ್ಥಿರ ಮಾಹಿತಿಯನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// ಈ ನೋಡ್ `Internal` ನೋಡ್ ಎಂದು ಪ್ರತಿಪಾದಿಸುವ ಯಾವುದೇ ಸ್ಥಿರ ಮಾಹಿತಿಯನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// ಆಧಾರವಾಗಿರುವ ನೋಡ್ `Internal` ನೋಡ್ ಅಥವಾ `Leaf` ನೋಡ್ ಆಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// `self` ನಂತರ ಪ್ರತ್ಯಯವನ್ನು ಒಂದು ನೋಡ್‌ನಿಂದ ಇನ್ನೊಂದಕ್ಕೆ ಸರಿಸಿ.`right` ಖಾಲಿಯಾಗಿರಬೇಕು.
    /// `right` ನ ಮೊದಲ edge ಬದಲಾಗದೆ ಉಳಿದಿದೆ.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// ಒಳಸೇರಿಸುವಿಕೆಯ ಫಲಿತಾಂಶ, ಅದರ ಸಾಮರ್ಥ್ಯವನ್ನು ಮೀರಿ ವಿಸ್ತರಿಸಲು ನೋಡ್ ಅಗತ್ಯವಿದ್ದಾಗ.
pub struct SplitResult<'a, K, V, NodeType> {
    // `kv` ನ ಎಡಭಾಗಕ್ಕೆ ಸೇರಿದ ಅಂಶಗಳು ಮತ್ತು ಅಂಚುಗಳೊಂದಿಗೆ ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ ಮರದಲ್ಲಿ ಬದಲಾದ ನೋಡ್.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // ಬೇರೆಡೆ ಸೇರಿಸಲು ಕೆಲವು ಕೀ ಮತ್ತು ಮೌಲ್ಯವನ್ನು ವಿಭಜಿಸಲಾಗಿದೆ.
    pub kv: (K, V),
    // `kv` ನ ಬಲಕ್ಕೆ ಸೇರಿದ ಅಂಶಗಳು ಮತ್ತು ಅಂಚುಗಳೊಂದಿಗೆ ಮಾಲೀಕತ್ವದ, ಜೋಡಿಸದ, ಹೊಸ ನೋಡ್.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // ಈ ಎರವಲು ಪ್ರಕಾರದ ನೋಡ್ ಉಲ್ಲೇಖಗಳು ಮರದ ಇತರ ನೋಡ್‌ಗಳಿಗೆ ಹೋಗಲು ಅನುಮತಿಸುತ್ತದೆಯೇ.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // ಟ್ರಾವೆರ್ಸಲ್ ಅಗತ್ಯವಿಲ್ಲ, ಇದು `borrow_mut` ಫಲಿತಾಂಶವನ್ನು ಬಳಸಿ ಸಂಭವಿಸುತ್ತದೆ.
        // ಅಡ್ಡಹಾಯುವಿಕೆಯನ್ನು ನಿಷ್ಕ್ರಿಯಗೊಳಿಸುವ ಮೂಲಕ ಮತ್ತು ಬೇರುಗಳಿಗೆ ಹೊಸ ಉಲ್ಲೇಖಗಳನ್ನು ಮಾತ್ರ ರಚಿಸುವ ಮೂಲಕ, `Owned` ಪ್ರಕಾರದ ಪ್ರತಿಯೊಂದು ಉಲ್ಲೇಖವು ರೂಟ್ ನೋಡ್‌ಗೆ ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// ಪ್ರಾರಂಭಿಕ ಅಂಶಗಳ ಸ್ಲೈಸ್‌ಗೆ ಮೌಲ್ಯವನ್ನು ಸೇರಿಸುತ್ತದೆ ಮತ್ತು ನಂತರ ಪ್ರಾರಂಭಿಸದ ಅಂಶ.
///
/// # Safety
/// ಸ್ಲೈಸ್ `idx` ಗಿಂತ ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ಹೊಂದಿದೆ.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// ಎಲ್ಲಾ ಪ್ರಾರಂಭಿಕ ಅಂಶಗಳ ಸ್ಲೈಸ್‌ನಿಂದ ಮೌಲ್ಯವನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ ಮತ್ತು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಪ್ರಾರಂಭಿಸದ ಒಂದು ಅಂಶವನ್ನು ಬಿಟ್ಟುಬಿಡುತ್ತದೆ.
///
///
/// # Safety
/// ಸ್ಲೈಸ್ `idx` ಗಿಂತ ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ಹೊಂದಿದೆ.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// ಸ್ಲೈಸ್ `distance` ಸ್ಥಾನಗಳಲ್ಲಿನ ಅಂಶಗಳನ್ನು ಎಡಕ್ಕೆ ಬದಲಾಯಿಸುತ್ತದೆ.
///
/// # Safety
/// ಸ್ಲೈಸ್ ಕನಿಷ್ಠ `distance` ಅಂಶಗಳನ್ನು ಹೊಂದಿದೆ.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// ಸ್ಲೈಸ್ `distance` ಸ್ಥಾನಗಳಲ್ಲಿನ ಅಂಶಗಳನ್ನು ಬಲಕ್ಕೆ ಬದಲಾಯಿಸುತ್ತದೆ.
///
/// # Safety
/// ಸ್ಲೈಸ್ ಕನಿಷ್ಠ `distance` ಅಂಶಗಳನ್ನು ಹೊಂದಿದೆ.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// ಎಲ್ಲಾ ಮೌಲ್ಯಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ ಅಂಶಗಳ ಸ್ಲೈಸ್‌ನಿಂದ ಪ್ರಾರಂಭಿಸದ ಅಂಶಗಳ ಸ್ಲೈಸ್‌ಗೆ ಸರಿಸುತ್ತದೆ, ಮತ್ತು `src` ಅನ್ನು ಎಲ್ಲಾ ಪ್ರಾರಂಭಿಸದಂತೆ ಬಿಟ್ಟುಬಿಡುತ್ತದೆ.
///
/// `dst.copy_from_slice(src)` ನಂತೆ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ ಆದರೆ `T` ಗೆ `Copy` ಆಗುವ ಅಗತ್ಯವಿಲ್ಲ.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;