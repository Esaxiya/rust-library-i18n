//! ಒಡೆತನದ ನೋಡ್‌ಗಳೊಂದಿಗೆ ದ್ವಿಗುಣ-ಲಿಂಕ್ ಮಾಡಿದ ಪಟ್ಟಿ.
//!
//! `LinkedList` ಸ್ಥಿರ ಸಮಯದಲ್ಲಿ ಎರಡೂ ತುದಿಯಲ್ಲಿರುವ ಅಂಶಗಳನ್ನು ತಳ್ಳಲು ಮತ್ತು ಪಾಪಿಂಗ್ ಮಾಡಲು ಅನುಮತಿಸುತ್ತದೆ.
//!
//! NOTE: [`Vec`] ಅಥವಾ [`VecDeque`] ಅನ್ನು ಬಳಸುವುದು ಯಾವಾಗಲೂ ಉತ್ತಮವಾಗಿದೆ ಏಕೆಂದರೆ ರಚನೆ ಆಧಾರಿತ ಪಾತ್ರೆಗಳು ಸಾಮಾನ್ಯವಾಗಿ ವೇಗವಾಗಿರುತ್ತವೆ, ಹೆಚ್ಚು ಮೆಮೊರಿ ದಕ್ಷತೆಯನ್ನು ಹೊಂದಿರುತ್ತವೆ ಮತ್ತು ಸಿಪಿಯು ಸಂಗ್ರಹವನ್ನು ಉತ್ತಮವಾಗಿ ಬಳಸಿಕೊಳ್ಳುತ್ತವೆ.
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// ಒಡೆತನದ ನೋಡ್‌ಗಳೊಂದಿಗೆ ದ್ವಿಗುಣ-ಲಿಂಕ್ ಮಾಡಿದ ಪಟ್ಟಿ.
///
/// `LinkedList` ಸ್ಥಿರ ಸಮಯದಲ್ಲಿ ಎರಡೂ ತುದಿಯಲ್ಲಿರುವ ಅಂಶಗಳನ್ನು ತಳ್ಳಲು ಮತ್ತು ಪಾಪಿಂಗ್ ಮಾಡಲು ಅನುಮತಿಸುತ್ತದೆ.
///
/// NOTE: `Vec` ಅಥವಾ `VecDeque` ಅನ್ನು ಬಳಸುವುದು ಯಾವಾಗಲೂ ಉತ್ತಮವಾಗಿದೆ ಏಕೆಂದರೆ ರಚನೆ ಆಧಾರಿತ ಪಾತ್ರೆಗಳು ಸಾಮಾನ್ಯವಾಗಿ ವೇಗವಾಗಿರುತ್ತವೆ, ಹೆಚ್ಚು ಮೆಮೊರಿ ದಕ್ಷತೆಯನ್ನು ಹೊಂದಿರುತ್ತವೆ ಮತ್ತು ಸಿಪಿಯು ಸಂಗ್ರಹವನ್ನು ಉತ್ತಮವಾಗಿ ಬಳಸಿಕೊಳ್ಳುತ್ತವೆ.
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// `LinkedList` ನ ಅಂಶಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ.
///
/// ಈ `struct` ಅನ್ನು [`LinkedList::iter()`] ನಿಂದ ರಚಿಸಲಾಗಿದೆ.
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) `#[derive(Clone)]` ಪರವಾಗಿ ತೆಗೆದುಹಾಕಿ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// `LinkedList` ನ ಅಂಶಗಳ ಮೇಲೆ ರೂಪಾಂತರಿತ ಪುನರಾವರ್ತಕ.
///
/// ಈ `struct` ಅನ್ನು [`LinkedList::iter_mut()`] ನಿಂದ ರಚಿಸಲಾಗಿದೆ.
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // ನಾವು ಇಲ್ಲಿ ಸಂಪೂರ್ಣ ಪಟ್ಟಿಯನ್ನು ಹೊಂದಿಲ್ಲ *, ನೋಡ್‌ನ `element` ನ ಉಲ್ಲೇಖಗಳನ್ನು ಪುನರಾವರ್ತಕರಿಂದ ನೀಡಲಾಗಿದೆ!ಆದ್ದರಿಂದ ಇದನ್ನು ಬಳಸುವಾಗ ಜಾಗರೂಕರಾಗಿರಿ;`element` ಗೆ ಅಲಿಯಾಸಿಂಗ್ ಪಾಯಿಂಟರ್‌ಗಳು ಇರಬಹುದೆಂದು ತಿಳಿದಿರುವ ವಿಧಾನಗಳು ತಿಳಿದಿರಬೇಕು.
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// `LinkedList` ನ ಅಂಶಗಳ ಮೇಲೆ ಮಾಲೀಕತ್ವದ ಪುನರಾವರ್ತಕ.
///
/// ಈ `struct` ಅನ್ನು [`LinkedList`] ನಲ್ಲಿ [`into_iter`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ (`IntoIterator` trait ನಿಂದ ಒದಗಿಸಲಾಗಿದೆ).
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// ಖಾಸಗಿ ವಿಧಾನಗಳು
impl<T> LinkedList<T> {
    /// ಕೊಟ್ಟಿರುವ ನೋಡ್ ಅನ್ನು ಪಟ್ಟಿಯ ಮುಂಭಾಗಕ್ಕೆ ಸೇರಿಸುತ್ತದೆ.
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // `element` ಗೆ ಅಲಿಯಾಸಿಂಗ್ ಪಾಯಿಂಟರ್‌ಗಳ ಸಿಂಧುತ್ವವನ್ನು ಕಾಪಾಡಿಕೊಳ್ಳಲು, ಸಂಪೂರ್ಣ ನೋಡ್‌ಗಳಿಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳನ್ನು ರಚಿಸದಂತೆ ಈ ವಿಧಾನವು ಕಾಳಜಿ ವಹಿಸುತ್ತದೆ.
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // `element` ಅನ್ನು ಅತಿಕ್ರಮಿಸುವ ಹೊಸ ರೂಪಾಂತರಿತ (unique!) ಉಲ್ಲೇಖಗಳನ್ನು ರಚಿಸುತ್ತಿಲ್ಲ.
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// ಪಟ್ಟಿಯ ಮುಂಭಾಗದಲ್ಲಿರುವ ನೋಡ್ ಅನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ ಮತ್ತು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // `element` ಗೆ ಅಲಿಯಾಸಿಂಗ್ ಪಾಯಿಂಟರ್‌ಗಳ ಸಿಂಧುತ್ವವನ್ನು ಕಾಪಾಡಿಕೊಳ್ಳಲು, ಸಂಪೂರ್ಣ ನೋಡ್‌ಗಳಿಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳನ್ನು ರಚಿಸದಂತೆ ಈ ವಿಧಾನವು ಕಾಳಜಿ ವಹಿಸುತ್ತದೆ.
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // `element` ಅನ್ನು ಅತಿಕ್ರಮಿಸುವ ಹೊಸ ರೂಪಾಂತರಿತ (unique!) ಉಲ್ಲೇಖಗಳನ್ನು ರಚಿಸುತ್ತಿಲ್ಲ.
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// ಕೊಟ್ಟಿರುವ ನೋಡ್ ಅನ್ನು ಪಟ್ಟಿಯ ಹಿಂಭಾಗಕ್ಕೆ ಸೇರಿಸುತ್ತದೆ.
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // `element` ಗೆ ಅಲಿಯಾಸಿಂಗ್ ಪಾಯಿಂಟರ್‌ಗಳ ಸಿಂಧುತ್ವವನ್ನು ಕಾಪಾಡಿಕೊಳ್ಳಲು, ಸಂಪೂರ್ಣ ನೋಡ್‌ಗಳಿಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳನ್ನು ರಚಿಸದಂತೆ ಈ ವಿಧಾನವು ಕಾಳಜಿ ವಹಿಸುತ್ತದೆ.
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // `element` ಅನ್ನು ಅತಿಕ್ರಮಿಸುವ ಹೊಸ ರೂಪಾಂತರಿತ (unique!) ಉಲ್ಲೇಖಗಳನ್ನು ರಚಿಸುತ್ತಿಲ್ಲ.
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// ಪಟ್ಟಿಯ ಹಿಂಭಾಗದಲ್ಲಿರುವ ನೋಡ್ ಅನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ ಮತ್ತು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // `element` ಗೆ ಅಲಿಯಾಸಿಂಗ್ ಪಾಯಿಂಟರ್‌ಗಳ ಸಿಂಧುತ್ವವನ್ನು ಕಾಪಾಡಿಕೊಳ್ಳಲು, ಸಂಪೂರ್ಣ ನೋಡ್‌ಗಳಿಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳನ್ನು ರಚಿಸದಂತೆ ಈ ವಿಧಾನವು ಕಾಳಜಿ ವಹಿಸುತ್ತದೆ.
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // `element` ಅನ್ನು ಅತಿಕ್ರಮಿಸುವ ಹೊಸ ರೂಪಾಂತರಿತ (unique!) ಉಲ್ಲೇಖಗಳನ್ನು ರಚಿಸುತ್ತಿಲ್ಲ.
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// ಪ್ರಸ್ತುತ ಪಟ್ಟಿಯಿಂದ ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ನೋಡ್ ಅನ್ನು ಅನ್ಲಿಂಕ್ ಮಾಡುತ್ತದೆ.
    ///
    /// ಎಚ್ಚರಿಕೆ: ಒದಗಿಸಿದ ನೋಡ್ ಪ್ರಸ್ತುತ ಪಟ್ಟಿಗೆ ಸೇರಿದೆ ಎಂದು ಇದು ಪರಿಶೀಲಿಸುವುದಿಲ್ಲ.
    ///
    /// ಅಲಿಯಾಸಿಂಗ್ ಪಾಯಿಂಟರ್‌ಗಳ ಸಿಂಧುತ್ವವನ್ನು ಕಾಪಾಡಿಕೊಳ್ಳಲು, `element` ಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳನ್ನು ರಚಿಸದಂತೆ ಈ ವಿಧಾನವು ಕಾಳಜಿ ವಹಿಸುತ್ತದೆ.
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // ಇದು ಈಗ ನಮ್ಮದು, ನಾವು &mut ಅನ್ನು ರಚಿಸಬಹುದು.

        // `element` ಅನ್ನು ಅತಿಕ್ರಮಿಸುವ ಹೊಸ ರೂಪಾಂತರಿತ (unique!) ಉಲ್ಲೇಖಗಳನ್ನು ರಚಿಸುತ್ತಿಲ್ಲ.
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // ಈ ನೋಡ್ ಹೆಡ್ ನೋಡ್ ಆಗಿದೆ
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // ಈ ನೋಡ್ ಟೈಲ್ ನೋಡ್ ಆಗಿದೆ
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ ಎರಡು ನೋಡ್‌ಗಳ ನಡುವೆ ನೋಡ್‌ಗಳ ಸರಣಿಯನ್ನು ವಿಭಜಿಸುತ್ತದೆ.
    ///
    /// ಎಚ್ಚರಿಕೆ: ಒದಗಿಸಿದ ನೋಡ್ ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ ಎರಡು ಪಟ್ಟಿಗಳಿಗೆ ಸೇರಿದೆ ಎಂದು ಇದು ಪರಿಶೀಲಿಸುವುದಿಲ್ಲ.
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // `element` ಗೆ ಅಲಿಯಾಸಿಂಗ್ ಪಾಯಿಂಟರ್‌ಗಳ ಸಿಂಧುತ್ವವನ್ನು ಕಾಪಾಡಿಕೊಳ್ಳಲು, ಒಂದೇ ಸಮಯದಲ್ಲಿ ಇಡೀ ನೋಡ್‌ಗಳಿಗೆ ಅನೇಕ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳನ್ನು ರಚಿಸದಂತೆ ಈ ವಿಧಾನವು ಕಾಳಜಿ ವಹಿಸುತ್ತದೆ.
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// ಲಿಂಕ್ ಮಾಡಿದ ಪಟ್ಟಿಯಿಂದ ಎಲ್ಲಾ ನೋಡ್‌ಗಳನ್ನು ನೋಡ್‌ಗಳ ಸರಣಿಯಾಗಿ ಬೇರ್ಪಡಿಸುತ್ತದೆ.
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // ಸ್ಪ್ಲಿಟ್ ನೋಡ್ ಎರಡನೇ ಭಾಗದ ಹೊಸ ಹೆಡ್ ನೋಡ್ ಆಗಿದೆ
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // ಎರಡನೇ ಭಾಗದ ಹೆಡ್ ಪಿಟಿಆರ್ ಅನ್ನು ಸರಿಪಡಿಸಿ
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // ಸ್ಪ್ಲಿಟ್ ನೋಡ್ ಮೊದಲ ಭಾಗದ ಹೊಸ ಟೈಲ್ ನೋಡ್ ಮತ್ತು ಎರಡನೇ ಭಾಗದ ತಲೆಯನ್ನು ಹೊಂದಿದೆ.
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // ಮೊದಲ ಭಾಗದ ಬಾಲ ಪಿಟಿಆರ್ ಅನ್ನು ಸರಿಪಡಿಸಿ
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// ಖಾಲಿ `LinkedList<T>` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// ಖಾಲಿ `LinkedList` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು `other` ನಿಂದ ಪಟ್ಟಿಯ ಅಂತ್ಯಕ್ಕೆ ಸರಿಸುತ್ತದೆ.
    ///
    /// ಇದು `other` ನಿಂದ ಎಲ್ಲಾ ನೋಡ್‌ಗಳನ್ನು ಮರುಬಳಕೆ ಮಾಡುತ್ತದೆ ಮತ್ತು ಅವುಗಳನ್ನು `self` ಗೆ ಚಲಿಸುತ್ತದೆ.
    /// ಈ ಕಾರ್ಯಾಚರಣೆಯ ನಂತರ, `other` ಖಾಲಿಯಾಗುತ್ತದೆ.
    ///
    /// ಈ ಕಾರ್ಯಾಚರಣೆಯು *O*(1) ಸಮಯ ಮತ್ತು *O*(1) ಮೆಮೊರಿಯಲ್ಲಿ ಲೆಕ್ಕಾಚಾರ ಮಾಡಬೇಕು.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` ಇಲ್ಲಿ ಎರಡೂ ಸರಿಯಾಗಿದೆ ಏಕೆಂದರೆ ನಾವು ಎರಡೂ ಪಟ್ಟಿಗಳಿಗೆ ಸಂಪೂರ್ಣ ಪ್ರವೇಶವನ್ನು ಹೊಂದಿದ್ದೇವೆ.
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು `other` ನಿಂದ ಪಟ್ಟಿಯ ಪ್ರಾರಂಭಕ್ಕೆ ಸರಿಸುತ್ತದೆ.
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` ಇಲ್ಲಿ ಎರಡೂ ಸರಿಯಾಗಿದೆ ಏಕೆಂದರೆ ನಾವು ಎರಡೂ ಪಟ್ಟಿಗಳಿಗೆ ಸಂಪೂರ್ಣ ಪ್ರವೇಶವನ್ನು ಹೊಂದಿದ್ದೇವೆ.
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// ಫಾರ್ವರ್ಡ್ ಪುನರಾವರ್ತಕವನ್ನು ಒದಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳೊಂದಿಗೆ ಫಾರ್ವರ್ಡ್ ಇಟರೇಟರ್ ಅನ್ನು ಒದಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// ಮುಂಭಾಗದ ಅಂಶದಲ್ಲಿ ಕರ್ಸರ್ ಅನ್ನು ಒದಗಿಸುತ್ತದೆ.
    ///
    /// ಪಟ್ಟಿ ಖಾಲಿಯಾಗಿದ್ದರೆ ಕರ್ಸರ್ "ghost" ಅಂಶವಲ್ಲದ ಅಂಶವನ್ನು ತೋರಿಸುತ್ತದೆ.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// ಮುಂಭಾಗದ ಅಂಶದಲ್ಲಿ ಸಂಪಾದನೆ ಕಾರ್ಯಾಚರಣೆಗಳೊಂದಿಗೆ ಕರ್ಸರ್ ಅನ್ನು ಒದಗಿಸುತ್ತದೆ.
    ///
    /// ಪಟ್ಟಿ ಖಾಲಿಯಾಗಿದ್ದರೆ ಕರ್ಸರ್ "ghost" ಅಂಶವಲ್ಲದ ಅಂಶವನ್ನು ತೋರಿಸುತ್ತದೆ.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// ಹಿಂದಿನ ಅಂಶದಲ್ಲಿ ಕರ್ಸರ್ ಅನ್ನು ಒದಗಿಸುತ್ತದೆ.
    ///
    /// ಪಟ್ಟಿ ಖಾಲಿಯಾಗಿದ್ದರೆ ಕರ್ಸರ್ "ghost" ಅಂಶವಲ್ಲದ ಅಂಶವನ್ನು ತೋರಿಸುತ್ತದೆ.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// ಹಿಂದಿನ ಅಂಶದಲ್ಲಿ ಸಂಪಾದನೆ ಕಾರ್ಯಾಚರಣೆಗಳೊಂದಿಗೆ ಕರ್ಸರ್ ಅನ್ನು ಒದಗಿಸುತ್ತದೆ.
    ///
    /// ಪಟ್ಟಿ ಖಾಲಿಯಾಗಿದ್ದರೆ ಕರ್ಸರ್ "ghost" ಅಂಶವಲ್ಲದ ಅಂಶವನ್ನು ತೋರಿಸುತ್ತದೆ.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// `LinkedList` ಖಾಲಿಯಾಗಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಕಾರ್ಯಾಚರಣೆಯು *O*(1) ಸಮಯದಲ್ಲಿ ಲೆಕ್ಕಾಚಾರ ಮಾಡಬೇಕು.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// `LinkedList` ನ ಉದ್ದವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಕಾರ್ಯಾಚರಣೆಯು *O*(1) ಸಮಯದಲ್ಲಿ ಲೆಕ್ಕಾಚಾರ ಮಾಡಬೇಕು.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// `LinkedList` ನಿಂದ ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ.
    ///
    /// ಈ ಕಾರ್ಯಾಚರಣೆಯು *O*(*n*) ಸಮಯದಲ್ಲಿ ಲೆಕ್ಕಾಚಾರ ಮಾಡಬೇಕು.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// `LinkedList` ನಿರ್ದಿಷ್ಟ ಮೌಲ್ಯಕ್ಕೆ ಸಮಾನವಾದ ಅಂಶವನ್ನು ಹೊಂದಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// ಮುಂಭಾಗದ ಅಂಶಕ್ಕೆ ಉಲ್ಲೇಖವನ್ನು ಒದಗಿಸುತ್ತದೆ, ಅಥವಾ ಪಟ್ಟಿ ಖಾಲಿಯಾಗಿದ್ದರೆ `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// ಮುಂಭಾಗದ ಅಂಶಕ್ಕೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಒದಗಿಸುತ್ತದೆ, ಅಥವಾ ಪಟ್ಟಿ ಖಾಲಿಯಾಗಿದ್ದರೆ `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// ಹಿಂದಿನ ಅಂಶಕ್ಕೆ ಉಲ್ಲೇಖವನ್ನು ಒದಗಿಸುತ್ತದೆ, ಅಥವಾ ಪಟ್ಟಿ ಖಾಲಿಯಾಗಿದ್ದರೆ `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// ಹಿಂದಿನ ಅಂಶಕ್ಕೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಒದಗಿಸುತ್ತದೆ, ಅಥವಾ ಪಟ್ಟಿ ಖಾಲಿಯಾಗಿದ್ದರೆ `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// ಪಟ್ಟಿಯಲ್ಲಿ ಮೊದಲು ಒಂದು ಅಂಶವನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///
    /// ಈ ಕಾರ್ಯಾಚರಣೆಯು *O*(1) ಸಮಯದಲ್ಲಿ ಲೆಕ್ಕಾಚಾರ ಮಾಡಬೇಕು.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// ಮೊದಲ ಅಂಶವನ್ನು ತೆಗೆದುಹಾಕಿ ಅದನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಅಥವಾ ಪಟ್ಟಿ ಖಾಲಿಯಾಗಿದ್ದರೆ `None`.
    ///
    ///
    /// ಈ ಕಾರ್ಯಾಚರಣೆಯು *O*(1) ಸಮಯದಲ್ಲಿ ಲೆಕ್ಕಾಚಾರ ಮಾಡಬೇಕು.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// ಪಟ್ಟಿಯ ಹಿಂಭಾಗಕ್ಕೆ ಒಂದು ಅಂಶವನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///
    /// ಈ ಕಾರ್ಯಾಚರಣೆಯು *O*(1) ಸಮಯದಲ್ಲಿ ಲೆಕ್ಕಾಚಾರ ಮಾಡಬೇಕು.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// ಪಟ್ಟಿಯಿಂದ ಕೊನೆಯ ಅಂಶವನ್ನು ತೆಗೆದುಹಾಕಿ ಅದನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಅಥವಾ ಅದು ಖಾಲಿಯಾಗಿದ್ದರೆ `None`.
    ///
    ///
    /// ಈ ಕಾರ್ಯಾಚರಣೆಯು *O*(1) ಸಮಯದಲ್ಲಿ ಲೆಕ್ಕಾಚಾರ ಮಾಡಬೇಕು.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// ಕೊಟ್ಟಿರುವ ಸೂಚ್ಯಂಕದಲ್ಲಿ ಪಟ್ಟಿಯನ್ನು ಎರಡು ಭಾಗಗಳಾಗಿ ವಿಭಜಿಸುತ್ತದೆ.
    /// ಸೂಚ್ಯಂಕ ಸೇರಿದಂತೆ ನಿರ್ದಿಷ್ಟ ಸೂಚ್ಯಂಕದ ನಂತರ ಎಲ್ಲವನ್ನೂ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಕಾರ್ಯಾಚರಣೆಯು *O*(*n*) ಸಮಯದಲ್ಲಿ ಲೆಕ್ಕಾಚಾರ ಮಾಡಬೇಕು.
    ///
    /// # Panics
    ///
    /// `at > len` ವೇಳೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // ಕೆಳಗೆ, ನಾವು ಪ್ರಾರಂಭದಿಂದ ಅಥವಾ ಅಂತ್ಯದಿಂದ `i-1` ನೇ ನೋಡ್ ಕಡೆಗೆ ಪುನರಾವರ್ತಿಸುತ್ತೇವೆ, ಅದು ವೇಗವಾಗಿರುವುದನ್ನು ಅವಲಂಬಿಸಿರುತ್ತದೆ.
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // .skip() ಅನ್ನು ಬಳಸುವ ಬದಲು (ಇದು ಹೊಸ ರಚನೆಯನ್ನು ರಚಿಸುತ್ತದೆ), ನಾವು ಹಸ್ತಚಾಲಿತವಾಗಿ ಬಿಟ್ಟುಬಿಡುತ್ತೇವೆ ಆದ್ದರಿಂದ ಸ್ಕಿಪ್‌ನ ಅನುಷ್ಠಾನದ ವಿವರಗಳನ್ನು ಅವಲಂಬಿಸದೆ ನಾವು ಮುಖ್ಯ ಕ್ಷೇತ್ರವನ್ನು ಪ್ರವೇಶಿಸಬಹುದು.
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // ಕೊನೆಯಿಂದ ಪ್ರಾರಂಭಿಸುವುದು ಉತ್ತಮ
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// ಕೊಟ್ಟಿರುವ ಸೂಚ್ಯಂಕದಲ್ಲಿನ ಅಂಶವನ್ನು ತೆಗೆದುಹಾಕಿ ಮತ್ತು ಅದನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಕಾರ್ಯಾಚರಣೆಯು *O*(*n*) ಸಮಯದಲ್ಲಿ ಲೆಕ್ಕಾಚಾರ ಮಾಡಬೇಕು.
    ///
    /// # Panics
    /// > =ಲೆನ್ ನಲ್ಲಿ ಇದ್ದರೆ Panics
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // ಕೆಳಗೆ, ನಾವು ಪ್ರಾರಂಭದಲ್ಲಿ ಅಥವಾ ಅಂತ್ಯದಿಂದ ಕೊಟ್ಟಿರುವ ಸೂಚ್ಯಂಕದಲ್ಲಿ ನೋಡ್ ಕಡೆಗೆ ಪುನರಾವರ್ತಿಸುತ್ತೇವೆ, ಅದು ವೇಗವಾಗಿರುವುದನ್ನು ಅವಲಂಬಿಸಿರುತ್ತದೆ.
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// ಒಂದು ಅಂಶವನ್ನು ತೆಗೆದುಹಾಕಬೇಕೆ ಎಂದು ನಿರ್ಧರಿಸಲು ಮುಚ್ಚುವಿಕೆಯನ್ನು ಬಳಸುವ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// ಮುಚ್ಚುವಿಕೆಯು ನಿಜವಾಗಿದ್ದರೆ, ನಂತರ ಅಂಶವನ್ನು ತೆಗೆದುಹಾಕಲಾಗುತ್ತದೆ ಮತ್ತು ಇಳುವರಿ ನೀಡಲಾಗುತ್ತದೆ.
    /// ಮುಚ್ಚುವಿಕೆಯು ತಪ್ಪಾಗಿ ಮರಳಿದರೆ, ಅಂಶವು ಪಟ್ಟಿಯಲ್ಲಿ ಉಳಿಯುತ್ತದೆ ಮತ್ತು ಪುನರಾವರ್ತಕರಿಂದ ನೀಡಲಾಗುವುದಿಲ್ಲ.
    ///
    /// ಫಿಲ್ಟರ್ ಮುಚ್ಚುವಿಕೆಯ ಪ್ರತಿಯೊಂದು ಅಂಶವನ್ನು ರೂಪಾಂತರಿಸಲು `drain_filter` ನಿಮಗೆ ಅನುಮತಿಸುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ನೀವು ಅದನ್ನು ಇರಿಸಿಕೊಳ್ಳಲು ಅಥವಾ ತೆಗೆದುಹಾಕಲು ಆರಿಸುತ್ತೀರಾ.
    ///
    ///
    /// # Examples
    ///
    /// ಪಟ್ಟಿಯನ್ನು ಸಮ ಮತ್ತು ವಿಚಿತ್ರವಾಗಿ ವಿಭಜಿಸುವುದು, ಮೂಲ ಪಟ್ಟಿಯನ್ನು ಮರುಬಳಕೆ ಮಾಡುವುದು:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // ಸಾಲ ಸಮಸ್ಯೆಗಳನ್ನು ತಪ್ಪಿಸಿ.
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // ನಾವು ಕೆಳಗೆ ಮಾಡುವ ಅದೇ ಲೂಪ್ ಅನ್ನು ಮುಂದುವರಿಸಿ.ಡಿಸ್ಟ್ರಕ್ಟರ್ ಭಯಭೀತರಾದಾಗ ಮಾತ್ರ ಇದು ಚಲಿಸುತ್ತದೆ.
                // ಇನ್ನೊಬ್ಬರು panics ಮಾಡಿದರೆ ಇದು ಸ್ಥಗಿತಗೊಳ್ಳುತ್ತದೆ.
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // 'ಎ' ಪಡೆಯಲು ಮಿತಿಯಿಲ್ಲದ ಜೀವಿತಾವಧಿಯ ಅಗತ್ಯವಿದೆ
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // 'ಎ' ಪಡೆಯಲು ಮಿತಿಯಿಲ್ಲದ ಜೀವಿತಾವಧಿಯ ಅಗತ್ಯವಿದೆ
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // 'ಎ' ಪಡೆಯಲು ಮಿತಿಯಿಲ್ಲದ ಜೀವಿತಾವಧಿಯ ಅಗತ್ಯವಿದೆ
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // 'ಎ' ಪಡೆಯಲು ಮಿತಿಯಿಲ್ಲದ ಜೀವಿತಾವಧಿಯ ಅಗತ್ಯವಿದೆ
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// `LinkedList` ಮೇಲೆ ಕರ್ಸರ್.
///
/// `Cursor` ಒಂದು ಪುನರಾವರ್ತಕನಂತಿದೆ, ಅದು ಹಿಂದಕ್ಕೆ ಮತ್ತು ಮುಂದಕ್ಕೆ ಮುಕ್ತವಾಗಿ ಹುಡುಕಬಹುದು.
///
/// ಕರ್ಸರ್ಗಳು ಯಾವಾಗಲೂ ಪಟ್ಟಿಯ ಎರಡು ಅಂಶಗಳ ನಡುವೆ ವಿಶ್ರಾಂತಿ ಪಡೆಯುತ್ತವೆ, ಮತ್ತು ಸೂಚ್ಯಂಕವು ತಾರ್ಕಿಕವಾಗಿ ವೃತ್ತಾಕಾರದಲ್ಲಿದೆ.
/// ಇದಕ್ಕೆ ಸರಿಹೊಂದುವಂತೆ, ಪಟ್ಟಿಯ ತಲೆ ಮತ್ತು ಬಾಲದ ನಡುವೆ `None` ಅನ್ನು ನೀಡುವ "ghost" ಅಂಶೇತರ ಅಂಶವಿದೆ.
///
///
/// ರಚಿಸಿದಾಗ, ಕರ್ಸರ್ಗಳು ಪಟ್ಟಿಯ ಮುಂಭಾಗದಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತವೆ, ಅಥವಾ ಪಟ್ಟಿ ಖಾಲಿಯಾಗಿದ್ದರೆ "ghost" ಅಂಶವಲ್ಲದ ಅಂಶ.
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// ಸಂಪಾದನೆ ಕಾರ್ಯಾಚರಣೆಗಳೊಂದಿಗೆ `LinkedList` ನಲ್ಲಿ ಕರ್ಸರ್.
///
/// `Cursor` ಒಂದು ಪುನರಾವರ್ತಕನಂತಿದೆ, ಅದು ಮುಕ್ತವಾಗಿ ಹಿಂದಕ್ಕೆ ಮತ್ತು ಮುಂದಕ್ಕೆ ಹುಡುಕಬಹುದು ಮತ್ತು ಪುನರಾವರ್ತನೆಯ ಸಮಯದಲ್ಲಿ ಪಟ್ಟಿಯನ್ನು ಸುರಕ್ಷಿತವಾಗಿ ಪರಿವರ್ತಿಸಬಹುದು.
/// ಏಕೆಂದರೆ ಅದರ ಇಳುವರಿ ಉಲ್ಲೇಖಗಳ ಜೀವಿತಾವಧಿಯು ಕೇವಲ ಆಧಾರವಾಗಿರುವ ಪಟ್ಟಿಯ ಬದಲು ತನ್ನದೇ ಆದ ಜೀವಿತಾವಧಿಯೊಂದಿಗೆ ಸಂಬಂಧ ಹೊಂದಿದೆ.
/// ಇದರರ್ಥ ಕರ್ಸರ್ಗಳು ಏಕಕಾಲದಲ್ಲಿ ಅನೇಕ ಅಂಶಗಳನ್ನು ನೀಡಲಾಗುವುದಿಲ್ಲ.
///
/// ಕರ್ಸರ್ಗಳು ಯಾವಾಗಲೂ ಪಟ್ಟಿಯ ಎರಡು ಅಂಶಗಳ ನಡುವೆ ವಿಶ್ರಾಂತಿ ಪಡೆಯುತ್ತವೆ, ಮತ್ತು ಸೂಚ್ಯಂಕವು ತಾರ್ಕಿಕವಾಗಿ ವೃತ್ತಾಕಾರದಲ್ಲಿದೆ.
/// ಇದಕ್ಕೆ ಸರಿಹೊಂದುವಂತೆ, ಪಟ್ಟಿಯ ತಲೆ ಮತ್ತು ಬಾಲದ ನಡುವೆ `None` ಅನ್ನು ನೀಡುವ "ghost" ಅಂಶೇತರ ಅಂಶವಿದೆ.
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// `LinkedList` ಒಳಗೆ ಕರ್ಸರ್ ಸ್ಥಾನ ಸೂಚ್ಯಂಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಕರ್ಸರ್ ಪ್ರಸ್ತುತ "ghost" ಅಲ್ಲದ ಅಂಶಕ್ಕೆ ಸೂಚಿಸುತ್ತಿದ್ದರೆ ಇದು `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// ಕರ್ಸರ್ ಅನ್ನು `LinkedList` ನ ಮುಂದಿನ ಅಂಶಕ್ಕೆ ಸರಿಸುತ್ತದೆ.
    ///
    /// ಕರ್ಸರ್ "ghost" ಅಲ್ಲದ ಅಂಶಕ್ಕೆ ಸೂಚಿಸುತ್ತಿದ್ದರೆ, ಇದು ಅದನ್ನು `LinkedList` ನ ಮೊದಲ ಅಂಶಕ್ಕೆ ಸರಿಸುತ್ತದೆ.
    /// ಇದು `LinkedList` ನ ಕೊನೆಯ ಅಂಶಕ್ಕೆ ಸೂಚಿಸುತ್ತಿದ್ದರೆ, ಇದು ಅದನ್ನು "ghost" ಅಲ್ಲದ ಅಂಶಕ್ಕೆ ಸರಿಸುತ್ತದೆ.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // ನಮಗೆ ಪ್ರಸ್ತುತ ಅಂಶವಿಲ್ಲ;ಕರ್ಸರ್ ಪ್ರಾರಂಭದ ಸ್ಥಾನದಲ್ಲಿ ಕುಳಿತಿದೆ ಮುಂದಿನ ಅಂಶವು ಪಟ್ಟಿಯ ಮುಖ್ಯಸ್ಥರಾಗಿರಬೇಕು
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // ನಾವು ಹಿಂದಿನ ಅಂಶವನ್ನು ಹೊಂದಿದ್ದೇವೆ, ಆದ್ದರಿಂದ ಅದರ ಮುಂದಿನದಕ್ಕೆ ಹೋಗೋಣ
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// ಕರ್ಸರ್ ಅನ್ನು `LinkedList` ನ ಹಿಂದಿನ ಅಂಶಕ್ಕೆ ಸರಿಸುತ್ತದೆ.
    ///
    /// ಕರ್ಸರ್ "ghost" ಅಲ್ಲದ ಅಂಶಕ್ಕೆ ಸೂಚಿಸುತ್ತಿದ್ದರೆ, ಇದು ಅದನ್ನು `LinkedList` ನ ಕೊನೆಯ ಅಂಶಕ್ಕೆ ಸರಿಸುತ್ತದೆ.
    /// ಇದು `LinkedList` ನ ಮೊದಲ ಅಂಶಕ್ಕೆ ಸೂಚಿಸುತ್ತಿದ್ದರೆ, ಅದು ಅದನ್ನು "ghost" ಅಲ್ಲದ ಅಂಶಕ್ಕೆ ಸರಿಸುತ್ತದೆ.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // ಕರೆಂಟ್ ಇಲ್ಲ.ನಾವು ಪಟ್ಟಿಯ ಪ್ರಾರಂಭದಲ್ಲಿದ್ದೇವೆ.ಯಾವುದೂ ಇಲ್ಲ ಇಳುವರಿ ಮತ್ತು ಕೊನೆಗೆ ನೆಗೆಯಿರಿ.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // ಹಿಂದಿನದು.ಅದನ್ನು ಇಳುವರಿ ಮಾಡಿ ಮತ್ತು ಹಿಂದಿನ ಅಂಶಕ್ಕೆ ಹೋಗಿ.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// ಕರ್ಸರ್ ಪ್ರಸ್ತುತ ಸೂಚಿಸುತ್ತಿರುವ ಅಂಶದ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಕರ್ಸರ್ ಪ್ರಸ್ತುತ "ghost" ಅಲ್ಲದ ಅಂಶಕ್ಕೆ ಸೂಚಿಸುತ್ತಿದ್ದರೆ ಇದು `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// ಮುಂದಿನ ಅಂಶಕ್ಕೆ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಕರ್ಸರ್ "ghost" ಅಲ್ಲದ ಅಂಶಕ್ಕೆ ಸೂಚಿಸುತ್ತಿದ್ದರೆ, ಇದು `LinkedList` ನ ಮೊದಲ ಅಂಶವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    /// ಇದು `LinkedList` ನ ಕೊನೆಯ ಅಂಶವನ್ನು ತೋರಿಸುತ್ತಿದ್ದರೆ ಇದು `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// ಹಿಂದಿನ ಅಂಶಕ್ಕೆ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಕರ್ಸರ್ "ghost" ಅಲ್ಲದ ಅಂಶಕ್ಕೆ ಸೂಚಿಸುತ್ತಿದ್ದರೆ, ಇದು `LinkedList` ನ ಕೊನೆಯ ಅಂಶವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    /// ಇದು `LinkedList` ನ ಮೊದಲ ಅಂಶವನ್ನು ತೋರಿಸುತ್ತಿದ್ದರೆ ಅದು `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// `LinkedList` ಒಳಗೆ ಕರ್ಸರ್ ಸ್ಥಾನ ಸೂಚ್ಯಂಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಕರ್ಸರ್ ಪ್ರಸ್ತುತ "ghost" ಅಲ್ಲದ ಅಂಶಕ್ಕೆ ಸೂಚಿಸುತ್ತಿದ್ದರೆ ಇದು `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// ಕರ್ಸರ್ ಅನ್ನು `LinkedList` ನ ಮುಂದಿನ ಅಂಶಕ್ಕೆ ಸರಿಸುತ್ತದೆ.
    ///
    /// ಕರ್ಸರ್ "ghost" ಅಲ್ಲದ ಅಂಶಕ್ಕೆ ಸೂಚಿಸುತ್ತಿದ್ದರೆ, ಇದು ಅದನ್ನು `LinkedList` ನ ಮೊದಲ ಅಂಶಕ್ಕೆ ಸರಿಸುತ್ತದೆ.
    /// ಇದು `LinkedList` ನ ಕೊನೆಯ ಅಂಶಕ್ಕೆ ಸೂಚಿಸುತ್ತಿದ್ದರೆ, ಇದು ಅದನ್ನು "ghost" ಅಲ್ಲದ ಅಂಶಕ್ಕೆ ಸರಿಸುತ್ತದೆ.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // ನಮಗೆ ಪ್ರಸ್ತುತ ಅಂಶವಿಲ್ಲ;ಕರ್ಸರ್ ಪ್ರಾರಂಭದ ಸ್ಥಾನದಲ್ಲಿ ಕುಳಿತಿದೆ ಮುಂದಿನ ಅಂಶವು ಪಟ್ಟಿಯ ಮುಖ್ಯಸ್ಥರಾಗಿರಬೇಕು
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // ನಾವು ಹಿಂದಿನ ಅಂಶವನ್ನು ಹೊಂದಿದ್ದೇವೆ, ಆದ್ದರಿಂದ ಅದರ ಮುಂದಿನದಕ್ಕೆ ಹೋಗೋಣ
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// ಕರ್ಸರ್ ಅನ್ನು `LinkedList` ನ ಹಿಂದಿನ ಅಂಶಕ್ಕೆ ಸರಿಸುತ್ತದೆ.
    ///
    /// ಕರ್ಸರ್ "ghost" ಅಲ್ಲದ ಅಂಶಕ್ಕೆ ಸೂಚಿಸುತ್ತಿದ್ದರೆ, ಇದು ಅದನ್ನು `LinkedList` ನ ಕೊನೆಯ ಅಂಶಕ್ಕೆ ಸರಿಸುತ್ತದೆ.
    /// ಇದು `LinkedList` ನ ಮೊದಲ ಅಂಶಕ್ಕೆ ಸೂಚಿಸುತ್ತಿದ್ದರೆ, ಅದು ಅದನ್ನು "ghost" ಅಲ್ಲದ ಅಂಶಕ್ಕೆ ಸರಿಸುತ್ತದೆ.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // ಕರೆಂಟ್ ಇಲ್ಲ.ನಾವು ಪಟ್ಟಿಯ ಪ್ರಾರಂಭದಲ್ಲಿದ್ದೇವೆ.ಯಾವುದೂ ಇಲ್ಲ ಇಳುವರಿ ಮತ್ತು ಕೊನೆಗೆ ನೆಗೆಯಿರಿ.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // ಹಿಂದಿನದು.ಅದನ್ನು ಇಳುವರಿ ಮಾಡಿ ಮತ್ತು ಹಿಂದಿನ ಅಂಶಕ್ಕೆ ಹೋಗಿ.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// ಕರ್ಸರ್ ಪ್ರಸ್ತುತ ಸೂಚಿಸುತ್ತಿರುವ ಅಂಶದ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಕರ್ಸರ್ ಪ್ರಸ್ತುತ "ghost" ಅಲ್ಲದ ಅಂಶಕ್ಕೆ ಸೂಚಿಸುತ್ತಿದ್ದರೆ ಇದು `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// ಮುಂದಿನ ಅಂಶಕ್ಕೆ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಕರ್ಸರ್ "ghost" ಅಲ್ಲದ ಅಂಶಕ್ಕೆ ಸೂಚಿಸುತ್ತಿದ್ದರೆ, ಇದು `LinkedList` ನ ಮೊದಲ ಅಂಶವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    /// ಇದು `LinkedList` ನ ಕೊನೆಯ ಅಂಶವನ್ನು ತೋರಿಸುತ್ತಿದ್ದರೆ ಇದು `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// ಹಿಂದಿನ ಅಂಶಕ್ಕೆ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಕರ್ಸರ್ "ghost" ಅಲ್ಲದ ಅಂಶಕ್ಕೆ ಸೂಚಿಸುತ್ತಿದ್ದರೆ, ಇದು `LinkedList` ನ ಕೊನೆಯ ಅಂಶವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    /// ಇದು `LinkedList` ನ ಮೊದಲ ಅಂಶವನ್ನು ತೋರಿಸುತ್ತಿದ್ದರೆ ಅದು `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// ಪ್ರಸ್ತುತ ಅಂಶವನ್ನು ಸೂಚಿಸುವ ಓದಲು-ಮಾತ್ರ ಕರ್ಸರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಹಿಂತಿರುಗಿದ `Cursor` ನ ಜೀವಿತಾವಧಿಯು `CursorMut` ಗೆ ಸಂಬಂಧಿಸಿದೆ, ಇದರರ್ಥ ಅದು `CursorMut` ಅನ್ನು ಮೀರಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ ಮತ್ತು `Cursor` ನ ಜೀವಿತಾವಧಿಯಲ್ಲಿ `CursorMut` ಹೆಪ್ಪುಗಟ್ಟುತ್ತದೆ.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// ಈಗ ಪಟ್ಟಿ ಸಂಪಾದನೆ ಕಾರ್ಯಾಚರಣೆಗಳು

impl<'a, T> CursorMut<'a, T> {
    /// ಪ್ರಸ್ತುತದ ನಂತರ `LinkedList` ಗೆ ಹೊಸ ಅಂಶವನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///
    /// ಕರ್ಸರ್ "ghost" ಅಲ್ಲದ ಅಂಶಕ್ಕೆ ಸೂಚಿಸುತ್ತಿದ್ದರೆ, ಹೊಸ ಅಂಶವನ್ನು `LinkedList` ನ ಮುಂಭಾಗದಲ್ಲಿ ಸೇರಿಸಲಾಗುತ್ತದೆ.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // "ghost" ಅಂಶೇತರ ಸೂಚ್ಯಂಕ ಬದಲಾಗಿದೆ.
                self.index = self.list.len;
            }
        }
    }

    /// ಪ್ರಸ್ತುತದ ಮೊದಲು `LinkedList` ಗೆ ಹೊಸ ಅಂಶವನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///
    /// ಕರ್ಸರ್ "ghost" ಅಲ್ಲದ ಅಂಶಕ್ಕೆ ಸೂಚಿಸುತ್ತಿದ್ದರೆ, ಹೊಸ ಅಂಶವನ್ನು `LinkedList` ನ ಕೊನೆಯಲ್ಲಿ ಸೇರಿಸಲಾಗುತ್ತದೆ.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// `LinkedList` ನಿಂದ ಪ್ರಸ್ತುತ ಅಂಶವನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ.
    ///
    /// ತೆಗೆದುಹಾಕಲಾದ ಅಂಶವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ, ಮತ್ತು ಕರ್ಸರ್ ಅನ್ನು `LinkedList` ನಲ್ಲಿ ಮುಂದಿನ ಅಂಶಕ್ಕೆ ಸೂಚಿಸಲು ಸರಿಸಲಾಗುತ್ತದೆ.
    ///
    ///
    /// ಕರ್ಸರ್ ಪ್ರಸ್ತುತ "ghost" ಅಂಶವಲ್ಲದ ಅಂಶಕ್ಕೆ ಸೂಚಿಸುತ್ತಿದ್ದರೆ ಯಾವುದೇ ಅಂಶವನ್ನು ತೆಗೆದುಹಾಕಲಾಗುವುದಿಲ್ಲ ಮತ್ತು `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// ಪಟ್ಟಿ ನೋಡ್ ಅನ್ನು ಡಿಲೊಲೊಕೇಟ್ ಮಾಡದೆ `LinkedList` ನಿಂದ ಪ್ರಸ್ತುತ ಅಂಶವನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ.
    ///
    /// ತೆಗೆದುಹಾಕಲಾದ ನೋಡ್ ಅನ್ನು ಈ ನೋಡ್ ಅನ್ನು ಮಾತ್ರ ಹೊಂದಿರುವ ಹೊಸ `LinkedList` ಆಗಿ ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    /// ಪ್ರಸ್ತುತ `LinkedList` ನಲ್ಲಿ ಮುಂದಿನ ಅಂಶವನ್ನು ಸೂಚಿಸಲು ಕರ್ಸರ್ ಅನ್ನು ಸರಿಸಲಾಗಿದೆ.
    ///
    /// ಕರ್ಸರ್ ಪ್ರಸ್ತುತ "ghost" ಅಂಶವಲ್ಲದ ಅಂಶಕ್ಕೆ ಸೂಚಿಸುತ್ತಿದ್ದರೆ ಯಾವುದೇ ಅಂಶವನ್ನು ತೆಗೆದುಹಾಕಲಾಗುವುದಿಲ್ಲ ಮತ್ತು `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// ಪ್ರಸ್ತುತದ ನಂತರ ಕೊಟ್ಟಿರುವ `LinkedList` ನಿಂದ ಅಂಶಗಳನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///
    /// ಕರ್ಸರ್ "ghost" ಅಲ್ಲದ ಅಂಶಕ್ಕೆ ಸೂಚಿಸುತ್ತಿದ್ದರೆ, ಹೊಸ ಅಂಶಗಳನ್ನು `LinkedList` ನ ಪ್ರಾರಂಭದಲ್ಲಿ ಸೇರಿಸಲಾಗುತ್ತದೆ.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // "ghost" ಅಂಶೇತರ ಸೂಚ್ಯಂಕ ಬದಲಾಗಿದೆ.
                self.index = self.list.len;
            }
        }
    }

    /// ಪ್ರಸ್ತುತದ ಮೊದಲು ಕೊಟ್ಟಿರುವ `LinkedList` ನಿಂದ ಅಂಶಗಳನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///
    /// ಕರ್ಸರ್ "ghost" ಅಲ್ಲದ ಅಂಶಕ್ಕೆ ಸೂಚಿಸುತ್ತಿದ್ದರೆ, ಹೊಸ ಅಂಶಗಳನ್ನು `LinkedList` ನ ಕೊನೆಯಲ್ಲಿ ಸೇರಿಸಲಾಗುತ್ತದೆ.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// ಪ್ರಸ್ತುತ ಅಂಶದ ನಂತರ ಪಟ್ಟಿಯನ್ನು ಎರಡು ಭಾಗಗಳಾಗಿ ವಿಭಜಿಸುತ್ತದೆ.
    /// ಇದು ಕರ್ಸರ್ ನಂತರ ಎಲ್ಲವನ್ನೂ ಒಳಗೊಂಡಿರುವ ಹೊಸ ಪಟ್ಟಿಯನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಮೂಲ ಪಟ್ಟಿಯು ಮೊದಲು ಎಲ್ಲವನ್ನೂ ಉಳಿಸಿಕೊಳ್ಳುತ್ತದೆ.
    ///
    ///
    /// ಕರ್ಸರ್ "ghost" ಅಲ್ಲದ ಅಂಶಕ್ಕೆ ಸೂಚಿಸುತ್ತಿದ್ದರೆ, `LinkedList` ನ ಸಂಪೂರ್ಣ ವಿಷಯಗಳನ್ನು ಸರಿಸಲಾಗುತ್ತದೆ.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // "ghost" ಅಂಶೇತರ ಸೂಚ್ಯಂಕ 0 ಕ್ಕೆ ಬದಲಾಗಿದೆ.
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// ಪ್ರಸ್ತುತ ಅಂಶದ ಮೊದಲು ಪಟ್ಟಿಯನ್ನು ಎರಡು ಭಾಗಗಳಾಗಿ ವಿಭಜಿಸುತ್ತದೆ.
    /// ಇದು ಕರ್ಸರ್ ಮೊದಲು ಎಲ್ಲವನ್ನೂ ಒಳಗೊಂಡಿರುವ ಹೊಸ ಪಟ್ಟಿಯನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಮೂಲ ಪಟ್ಟಿಯು ನಂತರ ಎಲ್ಲವನ್ನೂ ಉಳಿಸಿಕೊಳ್ಳುತ್ತದೆ.
    ///
    ///
    /// ಕರ್ಸರ್ "ghost" ಅಲ್ಲದ ಅಂಶಕ್ಕೆ ಸೂಚಿಸುತ್ತಿದ್ದರೆ, `LinkedList` ನ ಸಂಪೂರ್ಣ ವಿಷಯಗಳನ್ನು ಸರಿಸಲಾಗುತ್ತದೆ.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// ಲಿಂಕ್ಡ್‌ಲಿಸ್ಟ್‌ನಲ್ಲಿ `drain_filter` ಗೆ ಕರೆ ಮಾಡುವ ಮೂಲಕ ಪುನರಾವರ್ತಕ.
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` `element` ಉಲ್ಲೇಖಗಳನ್ನು ಅಲಿಯಾಸ್ ಮಾಡುವುದರೊಂದಿಗೆ ಸರಿ.
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// ಮೌಲ್ಯದಿಂದ ಅಂಶಗಳನ್ನು ನೀಡುವ ಇಟರೇಟರ್ ಆಗಿ ಪಟ್ಟಿಯನ್ನು ಬಳಸುತ್ತದೆ.
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// `LinkedList` ಮತ್ತು ಅದರ ಓದಲು-ಮಾತ್ರ ಪುನರಾವರ್ತಕಗಳು ಅವುಗಳ ಪ್ರಕಾರದ ನಿಯತಾಂಕಗಳಲ್ಲಿ ಸಹವರ್ತಿಗಳಾಗಿವೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ.
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}