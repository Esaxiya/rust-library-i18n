use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // ತೃತೀಯ ಹಂಚಿಕೆದಾರರು ಮತ್ತು `RawVec` ನಡುವಿನ ಏಕೀಕರಣದ ಪರೀಕ್ಷೆಯನ್ನು ಬರೆಯುವುದು ಸ್ವಲ್ಪ ಟ್ರಿಕಿ ಏಕೆಂದರೆ `RawVec` API ತಪ್ಪಾದ ಹಂಚಿಕೆ ವಿಧಾನಗಳನ್ನು ಬಹಿರಂಗಪಡಿಸುವುದಿಲ್ಲ, ಆದ್ದರಿಂದ ಹಂಚಿಕೆ ಖಾಲಿಯಾದಾಗ ಏನಾಗುತ್ತದೆ ಎಂಬುದನ್ನು ನಾವು ಪರಿಶೀಲಿಸಲಾಗುವುದಿಲ್ಲ (panic ಅನ್ನು ಕಂಡುಹಿಡಿಯುವುದನ್ನು ಮೀರಿ).
    //
    //
    // ಬದಲಾಗಿ, `RawVec` ವಿಧಾನಗಳು ಶೇಖರಣೆಯನ್ನು ಕಾಯ್ದಿರಿಸಿದಾಗ ಅಲೋಕೇಟರ್ API ಮೂಲಕ ಹೋಗುತ್ತದೆಯೇ ಎಂದು ಇದು ಪರಿಶೀಲಿಸುತ್ತದೆ.
    //
    //
    //
    //
    //

    // ಹಂಚಿಕೆ ಪ್ರಯತ್ನಗಳು ವಿಫಲಗೊಳ್ಳುವ ಮೊದಲು ನಿಗದಿತ ಪ್ರಮಾಣದ ಇಂಧನವನ್ನು ಬಳಸುವ ಮೂಕ ಹಂಚಿಕೆದಾರ.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (ಮರುಹಂಚಿಕೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ, ಹೀಗಾಗಿ 50 + 150=200 ಯುನಿಟ್ ಇಂಧನವನ್ನು ಬಳಸುತ್ತದೆ)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // ಮೊದಲಿಗೆ, `reserve` `reserve_exact` ನಂತೆ ಹಂಚುತ್ತದೆ.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 7 ಕ್ಕಿಂತ ಎರಡು ಪಟ್ಟು ಹೆಚ್ಚಾಗಿದೆ, ಆದ್ದರಿಂದ `reserve` `reserve_exact` ನಂತೆ ಕಾರ್ಯನಿರ್ವಹಿಸಬೇಕು.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 12 ರ ಅರ್ಧಕ್ಕಿಂತ ಕಡಿಮೆಯಿದೆ, ಆದ್ದರಿಂದ `reserve` ಘಾತೀಯವಾಗಿ ಬೆಳೆಯಬೇಕು.
        // ಈ ಟೆಸ್ಟ್ ಗ್ರೋ ಫ್ಯಾಕ್ಟರ್ ಬರೆಯುವ ಸಮಯದಲ್ಲಿ 2, ಆದ್ದರಿಂದ ಹೊಸ ಸಾಮರ್ಥ್ಯ 24 ಆಗಿದೆ, ಆದಾಗ್ಯೂ, 1.5 ನ ಗ್ರೋ ಫ್ಯಾಕ್ಟರ್ ಕೂಡ ಸರಿ.
        //
        // ಆದ್ದರಿಂದ ಪ್ರತಿಪಾದನೆಯಲ್ಲಿ `>= 18`.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}