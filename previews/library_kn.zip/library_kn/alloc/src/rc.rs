//! ಏಕ-ಥ್ರೆಡ್ ಉಲ್ಲೇಖ-ಎಣಿಕೆಯ ಪಾಯಿಂಟರ್‌ಗಳು.'Rc' ಎಂದರೆ 'ಉಲ್ಲೇಖ
//! Counted'.
//!
//! [`Rc<T>`][`Rc`] ಪ್ರಕಾರವು ರಾಶಿಯಲ್ಲಿ ಹಂಚಿಕೆಯಾದ `T` ಪ್ರಕಾರದ ಮೌಲ್ಯದ ಹಂಚಿಕೆಯ ಮಾಲೀಕತ್ವವನ್ನು ಒದಗಿಸುತ್ತದೆ.
//! [`Rc`] ನಲ್ಲಿ [`clone`][clone] ಅನ್ನು ಆಹ್ವಾನಿಸುವುದು ರಾಶಿಯಲ್ಲಿ ಅದೇ ಹಂಚಿಕೆಗೆ ಹೊಸ ಪಾಯಿಂಟರ್ ಅನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ.
//! ನಿರ್ದಿಷ್ಟ ಹಂಚಿಕೆಯ ಕೊನೆಯ [`Rc`] ಪಾಯಿಂಟರ್ ನಾಶವಾದಾಗ, ಆ ಹಂಚಿಕೆಯಲ್ಲಿ ಸಂಗ್ರಹವಾಗಿರುವ ಮೌಲ್ಯವನ್ನು (ಇದನ್ನು ಸಾಮಾನ್ಯವಾಗಿ "inner value" ಎಂದು ಕರೆಯಲಾಗುತ್ತದೆ) ಕೈಬಿಡಲಾಗುತ್ತದೆ.
//!
//! Rust ನಲ್ಲಿ ಹಂಚಿದ ಉಲ್ಲೇಖಗಳು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ರೂಪಾಂತರವನ್ನು ಅನುಮತಿಸುವುದಿಲ್ಲ, ಮತ್ತು [`Rc`] ಇದಕ್ಕೆ ಹೊರತಾಗಿಲ್ಲ: ನೀವು ಸಾಮಾನ್ಯವಾಗಿ [`Rc`] ಒಳಗೆ ಯಾವುದನ್ನಾದರೂ ಬದಲಾಯಿಸಬಹುದಾದ ಉಲ್ಲೇಖವನ್ನು ಪಡೆಯಲು ಸಾಧ್ಯವಿಲ್ಲ.
//! ನಿಮಗೆ ರೂಪಾಂತರದ ಅಗತ್ಯವಿದ್ದರೆ, [`Rc`] ಒಳಗೆ [`Cell`] ಅಥವಾ [`RefCell`] ಅನ್ನು ಇರಿಸಿ;[an example of mutability inside an `Rc`][mutability] ನೋಡಿ.
//!
//! [`Rc`] ಪರಮಾಣು ಅಲ್ಲದ ಉಲ್ಲೇಖ ಎಣಿಕೆಯನ್ನು ಬಳಸುತ್ತದೆ.
//! ಇದರರ್ಥ ಓವರ್ಹೆಡ್ ತುಂಬಾ ಕಡಿಮೆ, ಆದರೆ ಎಳೆಗಳ ನಡುವೆ [`Rc`] ಅನ್ನು ಕಳುಹಿಸಲಾಗುವುದಿಲ್ಲ ಮತ್ತು ಇದರ ಪರಿಣಾಮವಾಗಿ [`Rc`] [`Send`][send] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದಿಲ್ಲ.
//! ಪರಿಣಾಮವಾಗಿ, ನೀವು ಎಳೆಗಳ ನಡುವೆ [`Rc`] ಗಳನ್ನು ಕಳುಹಿಸುತ್ತಿಲ್ಲ ಎಂದು Rust ಕಂಪೈಲರ್ ಕಂಪೈಲ್ ಸಮಯದಲ್ಲಿ * ಪರಿಶೀಲಿಸುತ್ತದೆ.
//! ನಿಮಗೆ ಬಹು-ಥ್ರೆಡ್, ಪರಮಾಣು ಉಲ್ಲೇಖ ಎಣಿಕೆಯ ಅಗತ್ಯವಿದ್ದರೆ, [`sync::Arc`][arc] ಬಳಸಿ.
//!
//! [`downgrade`][downgrade] ವಿಧಾನವನ್ನು ಮಾಲೀಕತ್ವವಿಲ್ಲದ [`Weak`] ಪಾಯಿಂಟರ್ ರಚಿಸಲು ಬಳಸಬಹುದು.
//! [`Weak`] ಪಾಯಿಂಟರ್ ಅನ್ನು [`Rc`] ಗೆ [`ಅಪ್‌ಗ್ರೇಡ್`][ಅಪ್‌ಗ್ರೇಡ್] ಮಾಡಬಹುದು, ಆದರೆ ಹಂಚಿಕೆಯಲ್ಲಿ ಸಂಗ್ರಹವಾಗಿರುವ ಮೌಲ್ಯವನ್ನು ಈಗಾಗಲೇ ಕೈಬಿಟ್ಟರೆ ಇದು [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
//! ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, `Weak` ಪಾಯಿಂಟರ್‌ಗಳು ಹಂಚಿಕೆಯೊಳಗಿನ ಮೌಲ್ಯವನ್ನು ಜೀವಂತವಾಗಿರಿಸುವುದಿಲ್ಲ;ಆದಾಗ್ಯೂ, ಅವರು ಹಂಚಿಕೆಯನ್ನು (ಆಂತರಿಕ ಮೌಲ್ಯದ ಹಿಮ್ಮೇಳ ಅಂಗಡಿ) ಜೀವಂತವಾಗಿರಿಸುತ್ತಾರೆ.
//!
//! [`Rc`] ಪಾಯಿಂಟರ್‌ಗಳ ನಡುವಿನ ಚಕ್ರವನ್ನು ಎಂದಿಗೂ ಡಿಲೊಲೊಕೇಟ್ ಮಾಡಲಾಗುವುದಿಲ್ಲ.
//! ಈ ಕಾರಣಕ್ಕಾಗಿ, ಚಕ್ರಗಳನ್ನು ಮುರಿಯಲು [`Weak`] ಅನ್ನು ಬಳಸಲಾಗುತ್ತದೆ.
//! ಉದಾಹರಣೆಗೆ, ಒಂದು ಮರವು ಪೋಷಕ ನೋಡ್‌ಗಳಿಂದ ಮಕ್ಕಳಿಗೆ ಬಲವಾದ [`Rc`] ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಹೊಂದಿರಬಹುದು ಮತ್ತು ಮಕ್ಕಳಿಂದ [`Weak`] ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಅವರ ಪೋಷಕರಿಗೆ ಹಿಂತಿರುಗಿಸಬಹುದು.
//!
//! `Rc<T>` `T` ಗೆ ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಅಪನಗದೀಕರಣಗಳು ([`Deref`] trait ಮೂಲಕ), ಆದ್ದರಿಂದ ನೀವು [`Rc<T>`][`Rc`] ಪ್ರಕಾರದ ಮೌಲ್ಯದ ಮೇಲೆ `T` ವಿಧಾನಗಳನ್ನು ಕರೆಯಬಹುದು.
//! `ಟಿ` ವಿಧಾನಗಳೊಂದಿಗೆ ಹೆಸರು ಘರ್ಷಣೆಯನ್ನು ತಪ್ಪಿಸಲು, [`Rc<T>`][`Rc`] ನ ವಿಧಾನಗಳು ಸಂಬಂಧಿತ ಕಾರ್ಯಗಳಾಗಿವೆ, ಇದನ್ನು [fully qualified syntax] ಬಳಸಿ ಕರೆಯಲಾಗುತ್ತದೆ:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `ಆರ್ಸಿ<T>`Clone` ನಂತಹ traits ನ ಅನುಷ್ಠಾನಗಳನ್ನು ಸಹ ಸಂಪೂರ್ಣ ಅರ್ಹ ಸಿಂಟ್ಯಾಕ್ಸ್ ಬಳಸಿ ಕರೆಯಬಹುದು.
//! ಕೆಲವು ಜನರು ಸಂಪೂರ್ಣ ಅರ್ಹ ಸಿಂಟ್ಯಾಕ್ಸ್ ಅನ್ನು ಬಳಸಲು ಬಯಸುತ್ತಾರೆ, ಆದರೆ ಇತರರು ವಿಧಾನ-ಕರೆ ಸಿಂಟ್ಯಾಕ್ಸ್ ಅನ್ನು ಬಳಸಲು ಬಯಸುತ್ತಾರೆ.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // ವಿಧಾನ-ಕರೆ ಸಿಂಟ್ಯಾಕ್ಸ್
//! let rc2 = rc.clone();
//! // ಸಂಪೂರ್ಣ ಅರ್ಹ ಸಿಂಟ್ಯಾಕ್ಸ್
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] `T` ಗೆ ಸ್ವಯಂ-ವಿರೂಪಗೊಳ್ಳುವುದಿಲ್ಲ, ಏಕೆಂದರೆ ಆಂತರಿಕ ಮೌಲ್ಯವನ್ನು ಈಗಾಗಲೇ ಕೈಬಿಡಲಾಗಿದೆ.
//!
//! # ಕ್ಲೋನಿಂಗ್ ಉಲ್ಲೇಖಗಳು
//!
//! ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ ಉಲ್ಲೇಖದ ಎಣಿಕೆ ಪಾಯಿಂಟರ್‌ನಂತೆಯೇ ಅದೇ ಹಂಚಿಕೆಗೆ ಹೊಸ ಉಲ್ಲೇಖವನ್ನು ರಚಿಸುವುದು [`Rc<T>`][`Rc`] ಮತ್ತು [`Weak<T>`][`Weak`] ಗಾಗಿ ಜಾರಿಗೆ ತರಲಾದ `Clone` trait ಬಳಸಿ ಮಾಡಲಾಗುತ್ತದೆ.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // ಕೆಳಗಿನ ಎರಡು ಸಿಂಟ್ಯಾಕ್ಸ್‌ಗಳು ಸಮಾನವಾಗಿವೆ.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a ಮತ್ತು b ಎರಡೂ foo ನಂತೆಯೇ ಒಂದೇ ಮೆಮೊರಿ ಸ್ಥಳವನ್ನು ಸೂಚಿಸುತ್ತವೆ.
//! ```
//!
//! `Rc::clone(&from)` ಸಿಂಟ್ಯಾಕ್ಸ್ ಅತ್ಯಂತ ಭಾಷಾಶಾಸ್ತ್ರೀಯವಾಗಿದೆ ಏಕೆಂದರೆ ಅದು ಕೋಡ್‌ನ ಅರ್ಥವನ್ನು ಹೆಚ್ಚು ಸ್ಪಷ್ಟವಾಗಿ ತಿಳಿಸುತ್ತದೆ.
//! ಮೇಲಿನ ಉದಾಹರಣೆಯಲ್ಲಿ, ಈ ಸಿಂಟ್ಯಾಕ್ಸ್ ಫೂನ ಸಂಪೂರ್ಣ ವಿಷಯವನ್ನು ನಕಲಿಸುವ ಬದಲು ಈ ಕೋಡ್ ಹೊಸ ಉಲ್ಲೇಖವನ್ನು ರಚಿಸುತ್ತಿದೆ ಎಂದು ನೋಡಲು ಸುಲಭಗೊಳಿಸುತ್ತದೆ.
//!
//! # Examples
//!
//! ನಿರ್ದಿಷ್ಟ ಗ್ಯಾಸ್ಜೆಟ್‌ಗಳ ಒಂದು ಸೆಟ್ ನಿರ್ದಿಷ್ಟ `Owner` ಒಡೆತನದ ಸನ್ನಿವೇಶವನ್ನು ಪರಿಗಣಿಸಿ.
//! ನಮ್ಮ `ಗ್ಯಾಜೆಟ್‌ನ ಬಿಂದುವನ್ನು ಅವರ `Owner` ಗೆ ಹೊಂದಲು ನಾವು ಬಯಸುತ್ತೇವೆ.ಅನನ್ಯ ಮಾಲೀಕತ್ವದಿಂದ ನಾವು ಇದನ್ನು ಮಾಡಲು ಸಾಧ್ಯವಿಲ್ಲ, ಏಕೆಂದರೆ ಒಂದಕ್ಕಿಂತ ಹೆಚ್ಚು ಗ್ಯಾಜೆಟ್‌ಗಳು ಒಂದೇ `Owner` ಗೆ ಸೇರಿರಬಹುದು.
//! [`Rc`] ಅನೇಕ `ಗ್ಯಾಜೆಟ್‌ಗಳ ನಡುವೆ `Owner` ಅನ್ನು ಹಂಚಿಕೊಳ್ಳಲು ನಮಗೆ ಅನುಮತಿಸುತ್ತದೆ, ಮತ್ತು ಯಾವುದೇ `Gadget` ಪಾಯಿಂಟ್‌ಗಳವರೆಗೆ `Owner` ಅನ್ನು ಹಂಚಲಾಗುತ್ತದೆ.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... ಇತರ ಕ್ಷೇತ್ರಗಳು
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... ಇತರ ಕ್ಷೇತ್ರಗಳು
//! }
//!
//! fn main() {
//!     // ಉಲ್ಲೇಖ-ಎಣಿಸಿದ `Owner` ಅನ್ನು ರಚಿಸಿ.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // `gadget_owner` ಗೆ ಸೇರಿದ `ಗ್ಯಾಜೆಟ್`ಗಳನ್ನು ರಚಿಸಿ.
//!     // `Rc<Owner>` ಅನ್ನು ಕ್ಲೋನಿಂಗ್ ಮಾಡುವುದರಿಂದ ಅದೇ `Owner` ಹಂಚಿಕೆಗೆ ಹೊಸ ಪಾಯಿಂಟರ್ ನೀಡುತ್ತದೆ, ಪ್ರಕ್ರಿಯೆಯಲ್ಲಿ ಉಲ್ಲೇಖದ ಸಂಖ್ಯೆಯನ್ನು ಹೆಚ್ಚಿಸುತ್ತದೆ.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // ನಮ್ಮ ಸ್ಥಳೀಯ ವೇರಿಯಬಲ್ `gadget_owner` ಅನ್ನು ವಿಲೇವಾರಿ ಮಾಡಿ.
//!     drop(gadget_owner);
//!
//!     // `gadget_owner` ಅನ್ನು ಕೈಬಿಟ್ಟ ಹೊರತಾಗಿಯೂ, `ಗ್ಯಾಜೆಟ್‌ನ` `Owner` ಹೆಸರನ್ನು ನಾವು ಇನ್ನೂ ಮುದ್ರಿಸಲು ಸಾಧ್ಯವಾಗುತ್ತದೆ.
//!     // ಏಕೆಂದರೆ ನಾವು ಒಂದೇ `Rc<Owner>` ಅನ್ನು ಮಾತ್ರ ಕೈಬಿಟ್ಟಿದ್ದೇವೆ, ಆದರೆ ಅದು ಸೂಚಿಸುವ `Owner` ಅಲ್ಲ.
//!     // ಅದೇ `Owner` ಹಂಚಿಕೆಯಲ್ಲಿ ಇತರ `Rc<Owner>` ಪಾಯಿಂಟಿಂಗ್ ಇರುವವರೆಗೆ, ಅದು ಲೈವ್ ಆಗಿ ಉಳಿಯುತ್ತದೆ.
//!     // ಫೀಲ್ಡ್ ಪ್ರೊಜೆಕ್ಷನ್ `gadget1.owner.name` ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ ಏಕೆಂದರೆ `Rc<Owner>` ಸ್ವಯಂಚಾಲಿತವಾಗಿ `Owner` ಗೆ ವಿರೂಪಗೊಳ್ಳುತ್ತದೆ.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // ಕಾರ್ಯದ ಕೊನೆಯಲ್ಲಿ, `gadget1` ಮತ್ತು `gadget2` ನಾಶವಾಗುತ್ತವೆ, ಮತ್ತು ಅವರೊಂದಿಗೆ ನಮ್ಮ `Owner` ಗೆ ಕೊನೆಯ ಎಣಿಕೆಯ ಉಲ್ಲೇಖಗಳು.
//!     // ಗ್ಯಾಜೆಟ್ ಮ್ಯಾನ್ ಈಗ ನಾಶವಾಗುತ್ತಿದೆ.
//!     //
//! }
//! ```
//!
//! ನಮ್ಮ ಅವಶ್ಯಕತೆಗಳು ಬದಲಾದರೆ, ಮತ್ತು ನಾವು ಸಹ `Owner` ನಿಂದ `Gadget` ಗೆ ಸಂಚರಿಸಲು ಸಾಧ್ಯವಾಗುತ್ತದೆ, ನಾವು ಸಮಸ್ಯೆಗಳಿಗೆ ಸಿಲುಕುತ್ತೇವೆ.
//! `Owner` ನಿಂದ `Gadget` ವರೆಗಿನ [`Rc`] ಪಾಯಿಂಟರ್ ಒಂದು ಚಕ್ರವನ್ನು ಪರಿಚಯಿಸುತ್ತದೆ.
//! ಇದರರ್ಥ ಅವರ ಉಲ್ಲೇಖ ಎಣಿಕೆಗಳು ಎಂದಿಗೂ 0 ತಲುಪಲು ಸಾಧ್ಯವಿಲ್ಲ, ಮತ್ತು ಹಂಚಿಕೆ ಎಂದಿಗೂ ನಾಶವಾಗುವುದಿಲ್ಲ:
//! ಮೆಮೊರಿ ಸೋರಿಕೆ.ಇದನ್ನು ಪಡೆಯಲು, ನಾವು [`Weak`] ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಬಳಸಬಹುದು.
//!
//! Rust ವಾಸ್ತವವಾಗಿ ಈ ಲೂಪ್ ಅನ್ನು ಮೊದಲ ಸ್ಥಾನದಲ್ಲಿ ಉತ್ಪಾದಿಸಲು ಸ್ವಲ್ಪ ಕಷ್ಟಕರವಾಗಿಸುತ್ತದೆ.ಪರಸ್ಪರ ಸೂಚಿಸುವ ಎರಡು ಮೌಲ್ಯಗಳೊಂದಿಗೆ ಕೊನೆಗೊಳ್ಳಲು, ಅವುಗಳಲ್ಲಿ ಒಂದು ರೂಪಾಂತರಗೊಳ್ಳುವ ಅಗತ್ಯವಿದೆ.
//! ಇದು ಕಷ್ಟಕರವಾಗಿದೆ ಏಕೆಂದರೆ [`Rc`] ಮೆಮೊರಿ ಸುರಕ್ಷತೆಯನ್ನು ಅದು ಸುತ್ತುವ ಮೌಲ್ಯಕ್ಕೆ ಹಂಚಿದ ಉಲ್ಲೇಖಗಳನ್ನು ಮಾತ್ರ ನೀಡುವ ಮೂಲಕ ಜಾರಿಗೊಳಿಸುತ್ತದೆ ಮತ್ತು ಇವು ನೇರ ರೂಪಾಂತರವನ್ನು ಅನುಮತಿಸುವುದಿಲ್ಲ.
//! ನಾವು [`RefCell`] ನಲ್ಲಿ ರೂಪಾಂತರಗೊಳ್ಳಲು ಬಯಸುವ ಮೌಲ್ಯದ ಭಾಗವನ್ನು ನಾವು ಸುತ್ತುವ ಅಗತ್ಯವಿದೆ, ಅದು *ಆಂತರಿಕ ರೂಪಾಂತರವನ್ನು* ಒದಗಿಸುತ್ತದೆ: ಹಂಚಿಕೆಯ ಉಲ್ಲೇಖದ ಮೂಲಕ ರೂಪಾಂತರವನ್ನು ಸಾಧಿಸುವ ವಿಧಾನ.
//! [`RefCell`] ಚಾಲನಾಸಮಯದಲ್ಲಿ Rust ನ ಎರವಲು ನಿಯಮಗಳನ್ನು ಜಾರಿಗೊಳಿಸುತ್ತದೆ.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... ಇತರ ಕ್ಷೇತ್ರಗಳು
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... ಇತರ ಕ್ಷೇತ್ರಗಳು
//! }
//!
//! fn main() {
//!     // ಉಲ್ಲೇಖ-ಎಣಿಸಿದ `Owner` ಅನ್ನು ರಚಿಸಿ.
//!     // ನಾವು `ಗ್ಯಾಜೆಟ್‌ನ` ಮಾಲೀಕರ vector ಅನ್ನು `RefCell` ಒಳಗೆ ಇರಿಸಿದ್ದೇವೆ ಆದ್ದರಿಂದ ನಾವು ಅದನ್ನು ಹಂಚಿದ ಉಲ್ಲೇಖದ ಮೂಲಕ ಪರಿವರ್ತಿಸಬಹುದು.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // ಮೊದಲಿನಂತೆ `gadget_owner` ಗೆ ಸೇರಿದ `ಗ್ಯಾಜೆಟ್`ಗಳನ್ನು ರಚಿಸಿ.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // ಅವರ `Owner` ಗೆ `ಗ್ಯಾಜೆಟ್‌ಗಳನ್ನು` ಸೇರಿಸಿ.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` ಡೈನಾಮಿಕ್ ಎರವಲು ಇಲ್ಲಿ ಕೊನೆಗೊಳ್ಳುತ್ತದೆ.
//!     }
//!
//!     // ನಮ್ಮ `ಗ್ಯಾಜೆಟ್'ಗಳ ಬಗ್ಗೆ ಪುನರಾವರ್ತಿಸಿ, ಅವರ ವಿವರಗಳನ್ನು ಮುದ್ರಿಸಿ.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` ಇದು `Weak<Gadget>` ಆಗಿದೆ.
//!         // `Weak` ಪಾಯಿಂಟರ್‌ಗಳು ಹಂಚಿಕೆ ಇನ್ನೂ ಅಸ್ತಿತ್ವದಲ್ಲಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸುವುದಿಲ್ಲವಾದ್ದರಿಂದ, ನಾವು `upgrade` ಗೆ ಕರೆ ಮಾಡಬೇಕಾಗಿದೆ, ಅದು `Option<Rc<Gadget>>` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
//!         //
//!         //
//!         // ಈ ಸಂದರ್ಭದಲ್ಲಿ ಹಂಚಿಕೆ ಇನ್ನೂ ಅಸ್ತಿತ್ವದಲ್ಲಿದೆ ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ, ಆದ್ದರಿಂದ ನಾವು `unwrap` `Option` ಅನ್ನು ಸರಳವಾಗಿ ಮಾಡುತ್ತೇವೆ.
//!         // ಹೆಚ್ಚು ಸಂಕೀರ್ಣವಾದ ಪ್ರೋಗ್ರಾಂನಲ್ಲಿ, ನಿಮಗೆ `None` ಫಲಿತಾಂಶಕ್ಕಾಗಿ ಆಕರ್ಷಕ ದೋಷ ನಿರ್ವಹಣೆ ಅಗತ್ಯವಿರಬಹುದು.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // ಕಾರ್ಯದ ಕೊನೆಯಲ್ಲಿ, `gadget_owner`, `gadget1`, ಮತ್ತು `gadget2` ನಾಶವಾಗುತ್ತವೆ.
//!     // ಗ್ಯಾಜೆಟ್‌ಗಳಿಗೆ ಈಗ ಬಲವಾದ (`Rc`) ಪಾಯಿಂಟರ್‌ಗಳಿಲ್ಲ, ಆದ್ದರಿಂದ ಅವು ನಾಶವಾಗುತ್ತವೆ.
//!     // ಇದು ಗ್ಯಾಜೆಟ್ ಮ್ಯಾನ್‌ನಲ್ಲಿ ಉಲ್ಲೇಖದ ಸಂಖ್ಯೆಯನ್ನು ಶೂನ್ಯಗೊಳಿಸುತ್ತದೆ, ಆದ್ದರಿಂದ ಅವನು ನಾಶವಾಗುತ್ತಾನೆ.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// ಸಂಭವನೀಯ ಕ್ಷೇತ್ರ-ಮರುಕ್ರಮಗೊಳಿಸುವಿಕೆಯ ವಿರುದ್ಧ ಇದು repr(C) ರಿಂದ future-ಪ್ರೂಫ್ ಆಗಿದೆ, ಇದು ಸುರಕ್ಷಿತ [into|from]_raw() ಟ್ರಾನ್ಸ್‌ಮ್ಯೂಟಬಲ್ ಆಂತರಿಕ ಪ್ರಕಾರಗಳಿಗೆ ಅಡ್ಡಿಪಡಿಸುತ್ತದೆ.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// ಏಕ-ಥ್ರೆಡ್ ಉಲ್ಲೇಖ-ಎಣಿಕೆಯ ಪಾಯಿಂಟರ್.'Rc' ಎಂದರೆ 'ಉಲ್ಲೇಖ
/// Counted'.
///
/// ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ [module-level documentation](./index.html) ನೋಡಿ.
///
/// `Rc` ನ ಅಂತರ್ಗತ ವಿಧಾನಗಳು ಎಲ್ಲಾ ಸಂಬಂಧಿತ ಕಾರ್ಯಗಳಾಗಿವೆ, ಅಂದರೆ ನೀವು ಅವುಗಳನ್ನು ಉದಾ, `value.get_mut()` ಬದಲಿಗೆ [`Rc::get_mut(&mut value)`][get_mut] ಎಂದು ಕರೆಯಬೇಕು.
/// ಆಂತರಿಕ ಪ್ರಕಾರದ `T` ವಿಧಾನಗಳೊಂದಿಗಿನ ಘರ್ಷಣೆಯನ್ನು ಇದು ತಪ್ಪಿಸುತ್ತದೆ.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // ಈ ಅಸುರಕ್ಷಿತತೆಯು ಸರಿಯಾಗಿದೆ ಏಕೆಂದರೆ ಈ ಆರ್ಸಿ ಜೀವಂತವಾಗಿರುವಾಗ ಆಂತರಿಕ ಪಾಯಿಂಟರ್ ಮಾನ್ಯವಾಗಿದೆ ಎಂದು ನಮಗೆ ಖಾತ್ರಿಯಿದೆ.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// ಹೊಸ `Rc<T>` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // ಎಲ್ಲಾ ಬಲವಾದ ಪಾಯಿಂಟರ್‌ಗಳ ಒಡೆತನದ ಒಂದು ಸೂಚ್ಯ ದುರ್ಬಲ ಪಾಯಿಂಟರ್ ಇದೆ, ಇದು ಬಲವಾದ ಡಿಸ್ಟ್ರಕ್ಟರ್ ಚಾಲನೆಯಲ್ಲಿರುವಾಗ ದುರ್ಬಲ ಡಿಸ್ಟ್ರಕ್ಟರ್ ಎಂದಿಗೂ ಹಂಚಿಕೆಯನ್ನು ಮುಕ್ತಗೊಳಿಸುವುದಿಲ್ಲ ಎಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ, ದುರ್ಬಲ ಪಾಯಿಂಟರ್ ಅನ್ನು ಬಲವಾದ ಒಂದರೊಳಗೆ ಸಂಗ್ರಹಿಸಿದ್ದರೂ ಸಹ.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// ಸ್ವತಃ ದುರ್ಬಲ ಉಲ್ಲೇಖವನ್ನು ಬಳಸಿಕೊಂಡು ಹೊಸ `Rc<T>` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    /// ಈ ಕಾರ್ಯವು ಹಿಂದಿರುಗುವ ಮೊದಲು ದುರ್ಬಲ ಉಲ್ಲೇಖವನ್ನು ಅಪ್‌ಗ್ರೇಡ್ ಮಾಡಲು ಪ್ರಯತ್ನಿಸುವುದರಿಂದ `None` ಮೌಲ್ಯಕ್ಕೆ ಕಾರಣವಾಗುತ್ತದೆ.
    ///
    /// ಆದಾಗ್ಯೂ, ದುರ್ಬಲ ಉಲ್ಲೇಖವನ್ನು ಮುಕ್ತವಾಗಿ ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮಾಡಬಹುದು ಮತ್ತು ನಂತರದ ಸಮಯದಲ್ಲಿ ಬಳಕೆಗಾಗಿ ಸಂಗ್ರಹಿಸಬಹುದು.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... ಹೆಚ್ಚಿನ ಕ್ಷೇತ್ರಗಳು
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // ಒಂದೇ ದುರ್ಬಲ ಉಲ್ಲೇಖದೊಂದಿಗೆ "uninitialized" ಸ್ಥಿತಿಯಲ್ಲಿ ಒಳಭಾಗವನ್ನು ನಿರ್ಮಿಸಿ.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // ದುರ್ಬಲ ಪಾಯಿಂಟರ್‌ನ ಮಾಲೀಕತ್ವವನ್ನು ನಾವು ಬಿಟ್ಟುಕೊಡುವುದಿಲ್ಲ ಎಂಬುದು ಮುಖ್ಯ, ಇಲ್ಲದಿದ್ದರೆ `data_fn` ಹಿಂದಿರುಗುವ ಹೊತ್ತಿಗೆ ಮೆಮೊರಿಯನ್ನು ಮುಕ್ತಗೊಳಿಸಬಹುದು.
        // ನಾವು ನಿಜವಾಗಿಯೂ ಮಾಲೀಕತ್ವವನ್ನು ರವಾನಿಸಲು ಬಯಸಿದರೆ, ನಾವು ನಮಗಾಗಿ ಹೆಚ್ಚುವರಿ ದುರ್ಬಲ ಪಾಯಿಂಟರ್ ಅನ್ನು ರಚಿಸಬಹುದು, ಆದರೆ ಇದು ದುರ್ಬಲ ಉಲ್ಲೇಖ ಎಣಿಕೆಗೆ ಹೆಚ್ಚುವರಿ ನವೀಕರಣಗಳಿಗೆ ಕಾರಣವಾಗುತ್ತದೆ, ಅದು ಅಗತ್ಯವಿಲ್ಲದಿರಬಹುದು.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // ಬಲವಾದ ಉಲ್ಲೇಖಗಳು ಒಟ್ಟಾಗಿ ಹಂಚಿಕೆಯ ದುರ್ಬಲ ಉಲ್ಲೇಖವನ್ನು ಹೊಂದಿರಬೇಕು, ಆದ್ದರಿಂದ ನಮ್ಮ ಹಳೆಯ ದುರ್ಬಲ ಉಲ್ಲೇಖಕ್ಕಾಗಿ ವಿನಾಶಕವನ್ನು ಚಲಾಯಿಸಬೇಡಿ.
        //
        mem::forget(weak);
        strong
    }

    /// ಪ್ರಾರಂಭಿಸದ ವಿಷಯಗಳೊಂದಿಗೆ ಹೊಸ `Rc` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ಮುಂದೂಡಲ್ಪಟ್ಟ ಪ್ರಾರಂಭ:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// ಮೆಮೊರಿಯನ್ನು `0` ಬೈಟ್‌ಗಳಿಂದ ತುಂಬಿಸುವುದರೊಂದಿಗೆ, ಪ್ರಾರಂಭಿಸದ ವಿಷಯಗಳೊಂದಿಗೆ ಹೊಸ `Rc` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    ///
    ///
    /// ಈ ವಿಧಾನದ ಸರಿಯಾದ ಮತ್ತು ತಪ್ಪಾದ ಬಳಕೆಯ ಉದಾಹರಣೆಗಳಿಗಾಗಿ [`MaybeUninit::zeroed`][zeroed] ನೋಡಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// ಹೊಸ `Rc<T>` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ, ಹಂಚಿಕೆ ವಿಫಲವಾದರೆ ದೋಷವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // ಎಲ್ಲಾ ಬಲವಾದ ಪಾಯಿಂಟರ್‌ಗಳ ಒಡೆತನದ ಒಂದು ಸೂಚ್ಯ ದುರ್ಬಲ ಪಾಯಿಂಟರ್ ಇದೆ, ಇದು ಬಲವಾದ ಡಿಸ್ಟ್ರಕ್ಟರ್ ಚಾಲನೆಯಲ್ಲಿರುವಾಗ ದುರ್ಬಲ ಡಿಸ್ಟ್ರಕ್ಟರ್ ಎಂದಿಗೂ ಹಂಚಿಕೆಯನ್ನು ಮುಕ್ತಗೊಳಿಸುವುದಿಲ್ಲ ಎಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ, ದುರ್ಬಲ ಪಾಯಿಂಟರ್ ಅನ್ನು ಬಲವಾದ ಒಂದರೊಳಗೆ ಸಂಗ್ರಹಿಸಿದ್ದರೂ ಸಹ.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// ಪ್ರಾರಂಭಿಸದ ವಿಷಯಗಳೊಂದಿಗೆ ಹೊಸ `Rc` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ, ಹಂಚಿಕೆ ವಿಫಲವಾದರೆ ದೋಷವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // ಮುಂದೂಡಲ್ಪಟ್ಟ ಪ್ರಾರಂಭ:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// ಪ್ರಾರಂಭವಿಲ್ಲದ ವಿಷಯಗಳೊಂದಿಗೆ ಹೊಸ `Rc` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ, ಮೆಮೊರಿಯು `0` ಬೈಟ್‌ಗಳಿಂದ ತುಂಬಿರುತ್ತದೆ, ಹಂಚಿಕೆ ವಿಫಲವಾದರೆ ದೋಷವನ್ನು ನೀಡುತ್ತದೆ
    ///
    ///
    /// ಈ ವಿಧಾನದ ಸರಿಯಾದ ಮತ್ತು ತಪ್ಪಾದ ಬಳಕೆಯ ಉದಾಹರಣೆಗಳಿಗಾಗಿ [`MaybeUninit::zeroed`][zeroed] ನೋಡಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// ಹೊಸ `Pin<Rc<T>>` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    /// `T` `Unpin` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸದಿದ್ದರೆ, `value` ಅನ್ನು ಮೆಮೊರಿಯಲ್ಲಿ ಪಿನ್ ಮಾಡಲಾಗುತ್ತದೆ ಮತ್ತು ಸರಿಸಲು ಸಾಧ್ಯವಾಗುವುದಿಲ್ಲ.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// `Rc` ನಿಖರವಾಗಿ ಒಂದು ಬಲವಾದ ಉಲ್ಲೇಖವನ್ನು ಹೊಂದಿದ್ದರೆ ಆಂತರಿಕ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಇಲ್ಲದಿದ್ದರೆ, ರವಾನಿಸಲಾದ ಅದೇ `Rc` ನೊಂದಿಗೆ [`Err`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    ///
    /// ಅತ್ಯುತ್ತಮ ದುರ್ಬಲ ಉಲ್ಲೇಖಗಳು ಇದ್ದರೂ ಇದು ಯಶಸ್ವಿಯಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // ಒಳಗೊಂಡಿರುವ ವಸ್ತುವನ್ನು ನಕಲಿಸಿ

                // ಬಲವಾದ ಎಣಿಕೆಯನ್ನು ಕಡಿಮೆ ಮಾಡುವುದರ ಮೂಲಕ ಅವುಗಳನ್ನು ಉತ್ತೇಜಿಸಲಾಗುವುದಿಲ್ಲ ಎಂದು ದುರ್ಬಲರಿಗೆ ಸೂಚಿಸಿ, ತದನಂತರ ನಕಲಿ ದುರ್ಬಲತೆಯನ್ನು ರಚಿಸುವ ಮೂಲಕ ಡ್ರಾಪ್ ಲಾಜಿಕ್ ಅನ್ನು ನಿರ್ವಹಿಸುವಾಗ ಸೂಚ್ಯ "strong weak" ಪಾಯಿಂಟರ್ ಅನ್ನು ತೆಗೆದುಹಾಕಿ.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// ಪ್ರಾರಂಭಿಸದ ವಿಷಯಗಳೊಂದಿಗೆ ಹೊಸ ಉಲ್ಲೇಖ-ಎಣಿಕೆಯ ಸ್ಲೈಸ್ ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ಮುಂದೂಡಲ್ಪಟ್ಟ ಪ್ರಾರಂಭ:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// ಪ್ರಾರಂಭವಿಲ್ಲದ ವಿಷಯಗಳೊಂದಿಗೆ ಹೊಸ ಉಲ್ಲೇಖ-ಎಣಿಕೆಯ ಸ್ಲೈಸ್ ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ, ಮೆಮೊರಿ `0` ಬೈಟ್‌ಗಳಿಂದ ತುಂಬಿರುತ್ತದೆ.
    ///
    ///
    /// ಈ ವಿಧಾನದ ಸರಿಯಾದ ಮತ್ತು ತಪ್ಪಾದ ಬಳಕೆಯ ಉದಾಹರಣೆಗಳಿಗಾಗಿ [`MaybeUninit::zeroed`][zeroed] ನೋಡಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// `Rc<T>` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] ನಂತೆ, ಆಂತರಿಕ ಮೌಲ್ಯವು ನಿಜವಾಗಿಯೂ ಪ್ರಾರಂಭಿಕ ಸ್ಥಿತಿಯಲ್ಲಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸುವುದು ಕರೆ ಮಾಡುವವರಿಗೆ ಬಿಟ್ಟದ್ದು.
    ///
    /// ವಿಷಯವನ್ನು ಇನ್ನೂ ಸಂಪೂರ್ಣವಾಗಿ ಪ್ರಾರಂಭಿಸದಿದ್ದಾಗ ಇದನ್ನು ಕರೆಯುವುದು ತಕ್ಷಣದ ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ಮುಂದೂಡಲ್ಪಟ್ಟ ಪ್ರಾರಂಭ:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// `Rc<[T]>` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] ನಂತೆ, ಆಂತರಿಕ ಮೌಲ್ಯವು ನಿಜವಾಗಿಯೂ ಪ್ರಾರಂಭಿಕ ಸ್ಥಿತಿಯಲ್ಲಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸುವುದು ಕರೆ ಮಾಡುವವರಿಗೆ ಬಿಟ್ಟದ್ದು.
    ///
    /// ವಿಷಯವನ್ನು ಇನ್ನೂ ಸಂಪೂರ್ಣವಾಗಿ ಪ್ರಾರಂಭಿಸದಿದ್ದಾಗ ಇದನ್ನು ಕರೆಯುವುದು ತಕ್ಷಣದ ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ಮುಂದೂಡಲ್ಪಟ್ಟ ಪ್ರಾರಂಭ:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// `Rc` ಅನ್ನು ಬಳಸುತ್ತದೆ, ಸುತ್ತಿದ ಪಾಯಿಂಟರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಮೆಮೊರಿ ಸೋರಿಕೆಯನ್ನು ತಪ್ಪಿಸಲು ಪಾಯಿಂಟರ್ ಅನ್ನು [`Rc::from_raw`][from_raw] ಬಳಸಿ ಮತ್ತೆ `Rc` ಗೆ ಪರಿವರ್ತಿಸಬೇಕು.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// ಡೇಟಾಗೆ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಒದಗಿಸುತ್ತದೆ.
    ///
    /// ಎಣಿಕೆಗಳು ಯಾವುದೇ ರೀತಿಯಲ್ಲಿ ಪರಿಣಾಮ ಬೀರುವುದಿಲ್ಲ ಮತ್ತು `Rc` ಅನ್ನು ಸೇವಿಸುವುದಿಲ್ಲ.
    /// `Rc` ನಲ್ಲಿ ಬಲವಾದ ಎಣಿಕೆಗಳು ಇರುವವರೆಗೆ ಪಾಯಿಂಟರ್ ಮಾನ್ಯವಾಗಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // ಸುರಕ್ಷತೆ: ಇದು Deref::deref ಅಥವಾ Rc::inner ಮೂಲಕ ಹೋಗಲು ಸಾಧ್ಯವಿಲ್ಲ ಏಕೆಂದರೆ
        // ಉದಾ. raw/mut ಮೂಲವನ್ನು ಉಳಿಸಿಕೊಳ್ಳಲು ಇದು ಅಗತ್ಯವಾಗಿರುತ್ತದೆ
        // `get_mut` `from_raw` ಮೂಲಕ Rc ಅನ್ನು ಮರುಪಡೆಯಲಾದ ನಂತರ ಪಾಯಿಂಟರ್ ಮೂಲಕ ಬರೆಯಬಹುದು.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ನಿಂದ `Rc<T>` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    ///
    /// ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಅನ್ನು ಈ ಹಿಂದೆ [`Rc<U>::into_raw`][into_raw] ಗೆ ಕರೆಯಿಂದ ಹಿಂತಿರುಗಿಸಿರಬೇಕು, ಅಲ್ಲಿ `U` `T` ನಂತೆಯೇ ಒಂದೇ ಗಾತ್ರ ಮತ್ತು ಜೋಡಣೆಯನ್ನು ಹೊಂದಿರಬೇಕು.
    /// `U` `T` ಆಗಿದ್ದರೆ ಇದು ಕ್ಷುಲ್ಲಕ ಸತ್ಯ.
    /// `U` `T` ಅಲ್ಲ ಆದರೆ ಒಂದೇ ಗಾತ್ರ ಮತ್ತು ಜೋಡಣೆಯನ್ನು ಹೊಂದಿದ್ದರೆ, ಇದು ಮೂಲತಃ ವಿಭಿನ್ನ ಪ್ರಕಾರಗಳ ಉಲ್ಲೇಖಗಳನ್ನು ರವಾನಿಸುವಂತಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    /// ಈ ಸಂದರ್ಭದಲ್ಲಿ ಯಾವ ನಿರ್ಬಂಧಗಳು ಅನ್ವಯವಾಗುತ್ತವೆ ಎಂಬುದರ ಕುರಿತು ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ [`mem::transmute`][transmute] ನೋಡಿ.
    ///
    /// `from_raw` ನ ಬಳಕೆದಾರರು `T` ನ ನಿರ್ದಿಷ್ಟ ಮೌಲ್ಯವನ್ನು ಒಮ್ಮೆ ಮಾತ್ರ ಕೈಬಿಡಲಾಗಿದೆಯೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು.
    ///
    /// ಈ ಕಾರ್ಯವು ಅಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ಹಿಂದಿರುಗಿದ `Rc<T>` ಅನ್ನು ಎಂದಿಗೂ ಪ್ರವೇಶಿಸದಿದ್ದರೂ ಸಹ, ಅಸಮರ್ಪಕ ಬಳಕೆಯು ಮೆಮೊರಿ ಅಸುರಕ್ಷಿತತೆಗೆ ಕಾರಣವಾಗಬಹುದು.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // ಸೋರಿಕೆಯನ್ನು ತಡೆಗಟ್ಟಲು `Rc` ಗೆ ಹಿಂತಿರುಗಿ.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Rc::from_raw(x_ptr)` ಗೆ ಹೆಚ್ಚಿನ ಕರೆಗಳು ಮೆಮೊರಿ-ಅಸುರಕ್ಷಿತವಾಗಿರುತ್ತದೆ.
    /// }
    ///
    /// // `x` ಮೇಲಿನ ವ್ಯಾಪ್ತಿಯಿಂದ ಹೊರಬಂದಾಗ ಮೆಮೊರಿಯನ್ನು ಮುಕ್ತಗೊಳಿಸಲಾಯಿತು, ಆದ್ದರಿಂದ `x_ptr` ಈಗ ತೂಗಾಡುತ್ತಿದೆ!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // ಮೂಲ RcBox ಅನ್ನು ಕಂಡುಹಿಡಿಯಲು ಆಫ್‌ಸೆಟ್ ಅನ್ನು ಹಿಮ್ಮುಖಗೊಳಿಸಿ.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// ಈ ಹಂಚಿಕೆಗೆ ಹೊಸ [`Weak`] ಪಾಯಿಂಟರ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // ನಾವು ತೂಗಾಡುತ್ತಿರುವ ದುರ್ಬಲತೆಯನ್ನು ರಚಿಸುವುದಿಲ್ಲ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// ಈ ಹಂಚಿಕೆಗೆ [`Weak`] ಪಾಯಿಂಟರ್‌ಗಳ ಸಂಖ್ಯೆಯನ್ನು ಪಡೆಯುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// ಈ ಹಂಚಿಕೆಗೆ ಬಲವಾದ (`Rc`) ಪಾಯಿಂಟರ್‌ಗಳ ಸಂಖ್ಯೆಯನ್ನು ಪಡೆಯುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// ಈ ಹಂಚಿಕೆಗೆ ಬೇರೆ `Rc` ಅಥವಾ [`Weak`] ಪಾಯಿಂಟರ್‌ಗಳು ಇಲ್ಲದಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// ಒಂದೇ ಹಂಚಿಕೆಗೆ ಬೇರೆ `Rc` ಅಥವಾ [`Weak`] ಪಾಯಿಂಟರ್‌ಗಳು ಇಲ್ಲದಿದ್ದರೆ, ಕೊಟ್ಟಿರುವ `Rc` ಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಏಕೆಂದರೆ ಹಂಚಿದ ಮೌಲ್ಯವನ್ನು ಪರಿವರ್ತಿಸುವುದು ಸುರಕ್ಷಿತವಲ್ಲ.
    ///
    /// [`make_mut`][make_mut] ಅನ್ನು ಸಹ ನೋಡಿ, ಇದು ಇತರ ಪಾಯಿಂಟರ್‌ಗಳು ಇದ್ದಾಗ ಆಂತರಿಕ ಮೌಲ್ಯವನ್ನು [`clone`][clone] ಮಾಡುತ್ತದೆ.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// ಯಾವುದೇ ಪರಿಶೀಲನೆಯಿಲ್ಲದೆ, ಕೊಟ್ಟಿರುವ `Rc` ಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [`get_mut`] ಅನ್ನು ಸಹ ನೋಡಿ, ಅದು ಸುರಕ್ಷಿತವಾಗಿದೆ ಮತ್ತು ಸೂಕ್ತವಾದ ತಪಾಸಣೆ ಮಾಡುತ್ತದೆ.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// ಅದೇ ಹಂಚಿಕೆಗೆ ಬೇರೆ ಯಾವುದೇ `Rc` ಅಥವಾ [`Weak`] ಪಾಯಿಂಟರ್‌ಗಳು ಹಿಂತಿರುಗಿದ ಸಾಲದ ಅವಧಿಗೆ ಡಿಫರೆನ್ಸ್ ಮಾಡಬಾರದು.
    ///
    /// ಅಂತಹ ಯಾವುದೇ ಪಾಯಿಂಟರ್‌ಗಳು ಅಸ್ತಿತ್ವದಲ್ಲಿಲ್ಲದಿದ್ದರೆ ಇದು ಕ್ಷುಲ್ಲಕ ಸಂಗತಿಯಾಗಿದೆ, ಉದಾಹರಣೆಗೆ `Rc::new` ನಂತರ ತಕ್ಷಣ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // "count" ಕ್ಷೇತ್ರಗಳನ್ನು ಒಳಗೊಂಡ ಉಲ್ಲೇಖವನ್ನು * ರಚಿಸದಿರಲು ನಾವು ಜಾಗರೂಕರಾಗಿರುತ್ತೇವೆ, ಏಕೆಂದರೆ ಇದು ಉಲ್ಲೇಖ ಎಣಿಕೆಗಳಿಗೆ ಪ್ರವೇಶದೊಂದಿಗೆ ಸಂಘರ್ಷಗೊಳ್ಳುತ್ತದೆ (ಉದಾ
        // `Weak` ನಿಂದ).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// ಎರಡು `Rc` ಗಳು ಒಂದೇ ಹಂಚಿಕೆಗೆ ಸೂಚಿಸಿದರೆ ([`ptr::eq`] ಗೆ ಹೋಲುವ ಧಾಟಿಯಲ್ಲಿ) `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// ಕೊಟ್ಟಿರುವ `Rc` ಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಮಾಡುತ್ತದೆ.
    ///
    /// ಒಂದೇ ಹಂಚಿಕೆಗೆ ಇತರ `Rc` ಪಾಯಿಂಟರ್‌ಗಳು ಇದ್ದರೆ, ಅನನ್ಯ ಮಾಲೀಕತ್ವವನ್ನು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು `make_mut` ಹೊಸ ಹಂಚಿಕೆಗೆ ಆಂತರಿಕ ಮೌಲ್ಯವನ್ನು [`clone`] ಮಾಡುತ್ತದೆ.
    /// ಇದನ್ನು ಕ್ಲೋನ್-ಆನ್-ರೈಟ್ ಎಂದೂ ಕರೆಯಲಾಗುತ್ತದೆ.
    ///
    /// ಈ ಹಂಚಿಕೆಗೆ ಬೇರೆ `Rc` ಪಾಯಿಂಟರ್‌ಗಳು ಇಲ್ಲದಿದ್ದರೆ, ಈ ಹಂಚಿಕೆಗೆ [`Weak`] ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಬೇರ್ಪಡಿಸಲಾಗುತ್ತದೆ.
    ///
    /// [`get_mut`] ಅನ್ನು ಸಹ ನೋಡಿ, ಅದು ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿಗಿಂತ ವಿಫಲಗೊಳ್ಳುತ್ತದೆ.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // ಯಾವುದನ್ನೂ ಕ್ಲೋನ್ ಮಾಡುವುದಿಲ್ಲ
    /// let mut other_data = Rc::clone(&data);    // ಆಂತರಿಕ ಡೇಟಾವನ್ನು ಕ್ಲೋನ್ ಮಾಡುವುದಿಲ್ಲ
    /// *Rc::make_mut(&mut data) += 1;        // ಆಂತರಿಕ ಡೇಟಾವನ್ನು ಕ್ಲೋನ್ ಮಾಡುತ್ತದೆ
    /// *Rc::make_mut(&mut data) += 1;        // ಯಾವುದನ್ನೂ ಕ್ಲೋನ್ ಮಾಡುವುದಿಲ್ಲ
    /// *Rc::make_mut(&mut other_data) *= 2;  // ಯಾವುದನ್ನೂ ಕ್ಲೋನ್ ಮಾಡುವುದಿಲ್ಲ
    ///
    /// // ಈಗ `data` ಮತ್ತು `other_data` ವಿಭಿನ್ನ ಹಂಚಿಕೆಗಳಿಗೆ ಸೂಚಿಸುತ್ತವೆ.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಬೇರ್ಪಡಿಸಲಾಗುತ್ತದೆ:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // ಡೇಟಾವನ್ನು ಕ್ಲೋನ್ ಮಾಡಬೇಕು, ಇತರ ಆರ್ಸಿಗಳಿವೆ.
            // ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮೌಲ್ಯವನ್ನು ನೇರವಾಗಿ ಬರೆಯಲು ಅನುಮತಿಸಲು ಮೆಮೊರಿಯನ್ನು ಮೊದಲೇ ನಿಯೋಜಿಸಿ.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // ಡೇಟಾವನ್ನು ಕದಿಯಬಹುದು, ಉಳಿದಿರುವುದು ದುರ್ಬಲವಾಗಿದೆ
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // ಸೂಚ್ಯ ಬಲವಾದ-ದುರ್ಬಲ ರೆಫ್ ಅನ್ನು ತೆಗೆದುಹಾಕಿ (ನಕಲಿ ದುರ್ಬಲತೆಯನ್ನು ಇಲ್ಲಿ ರಚಿಸುವ ಅಗತ್ಯವಿಲ್ಲ-ಇತರ ದುರ್ಬಲರು ನಮಗೆ ಸ್ವಚ್ up ಗೊಳಿಸಬಹುದು ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // ಈ ಅಸುರಕ್ಷಿತತೆಯು ಸರಿಯಾಗಿದೆ ಏಕೆಂದರೆ ಹಿಂದಿರುಗಿದ ಪಾಯಿಂಟರ್ *ಮಾತ್ರ* ಪಾಯಿಂಟರ್ ಎಂದು ನಾವು ಖಾತರಿಪಡಿಸುತ್ತೇವೆ ಅದು ಎಂದಿಗೂ ಟಿ ಗೆ ಹಿಂತಿರುಗುತ್ತದೆ.
        // ಈ ಸಮಯದಲ್ಲಿ ನಮ್ಮ ಉಲ್ಲೇಖ ಎಣಿಕೆ 1 ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ, ಮತ್ತು ನಮಗೆ `Rc<T>` ಸ್ವತಃ `mut` ಆಗಿರಬೇಕು, ಆದ್ದರಿಂದ ನಾವು ಹಂಚಿಕೆಗೆ ಸಾಧ್ಯವಿರುವ ಏಕೈಕ ಉಲ್ಲೇಖವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತಿದ್ದೇವೆ.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Rc<dyn Any>` ಅನ್ನು ಕಾಂಕ್ರೀಟ್ ಪ್ರಕಾರಕ್ಕೆ ಇಳಿಸುವ ಪ್ರಯತ್ನ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// ಮೌಲ್ಯವು ವಿನ್ಯಾಸವನ್ನು ಒದಗಿಸಿರುವ ಸಂಭಾವ್ಯ-ಗಾತ್ರದ ಆಂತರಿಕ ಮೌಲ್ಯಕ್ಕೆ ಸಾಕಷ್ಟು ಸ್ಥಳಾವಕಾಶದೊಂದಿಗೆ `RcBox<T>` ಅನ್ನು ನಿಯೋಜಿಸುತ್ತದೆ.
    ///
    /// `mem_to_rcbox` ಕಾರ್ಯವನ್ನು ಡೇಟಾ ಪಾಯಿಂಟರ್‌ನೊಂದಿಗೆ ಕರೆಯಲಾಗುತ್ತದೆ ಮತ್ತು `RcBox<T>` ಗಾಗಿ ಒಂದು (ಸಂಭಾವ್ಯ ಕೊಬ್ಬು)-ಪಾಯಿಂಟರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸಬೇಕು.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // ಕೊಟ್ಟಿರುವ ಮೌಲ್ಯ ವಿನ್ಯಾಸವನ್ನು ಬಳಸಿಕೊಂಡು ವಿನ್ಯಾಸವನ್ನು ಲೆಕ್ಕಹಾಕಿ.
        // ಹಿಂದೆ, `&*(ptr as* const RcBox<T>)` ಅಭಿವ್ಯಕ್ತಿಯಲ್ಲಿ ವಿನ್ಯಾಸವನ್ನು ಲೆಕ್ಕಹಾಕಲಾಗಿತ್ತು, ಆದರೆ ಇದು ತಪ್ಪಾಗಿ ವಿನ್ಯಾಸಗೊಳಿಸಲಾದ ಉಲ್ಲೇಖವನ್ನು ರಚಿಸಿದೆ (#54908 ನೋಡಿ).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// ಮೌಲ್ಯವು ವಿನ್ಯಾಸವನ್ನು ಒದಗಿಸಿರುವ ಸಂಭಾವ್ಯ-ಗಾತ್ರದ ಆಂತರಿಕ ಮೌಲ್ಯಕ್ಕೆ ಸಾಕಷ್ಟು ಸ್ಥಳಾವಕಾಶದೊಂದಿಗೆ `RcBox<T>` ಅನ್ನು ನಿಯೋಜಿಸುತ್ತದೆ, ಹಂಚಿಕೆ ವಿಫಲವಾದರೆ ದೋಷವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// `mem_to_rcbox` ಕಾರ್ಯವನ್ನು ಡೇಟಾ ಪಾಯಿಂಟರ್‌ನೊಂದಿಗೆ ಕರೆಯಲಾಗುತ್ತದೆ ಮತ್ತು `RcBox<T>` ಗಾಗಿ ಒಂದು (ಸಂಭಾವ್ಯ ಕೊಬ್ಬು)-ಪಾಯಿಂಟರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸಬೇಕು.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // ಕೊಟ್ಟಿರುವ ಮೌಲ್ಯ ವಿನ್ಯಾಸವನ್ನು ಬಳಸಿಕೊಂಡು ವಿನ್ಯಾಸವನ್ನು ಲೆಕ್ಕಹಾಕಿ.
        // ಹಿಂದೆ, `&*(ptr as* const RcBox<T>)` ಅಭಿವ್ಯಕ್ತಿಯಲ್ಲಿ ವಿನ್ಯಾಸವನ್ನು ಲೆಕ್ಕಹಾಕಲಾಗಿತ್ತು, ಆದರೆ ಇದು ತಪ್ಪಾಗಿ ವಿನ್ಯಾಸಗೊಳಿಸಲಾದ ಉಲ್ಲೇಖವನ್ನು ರಚಿಸಿದೆ (#54908 ನೋಡಿ).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // ವಿನ್ಯಾಸಕ್ಕಾಗಿ ನಿಗದಿಪಡಿಸಿ.
        let ptr = allocate(layout)?;

        // ಆರ್ಸಿಬಾಕ್ಸ್ ಅನ್ನು ಪ್ರಾರಂಭಿಸಿ
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// ಗಾತ್ರವಿಲ್ಲದ ಆಂತರಿಕ ಮೌಲ್ಯಕ್ಕೆ ಸಾಕಷ್ಟು ಸ್ಥಳಾವಕಾಶವಿರುವ `RcBox<T>` ಅನ್ನು ನಿಯೋಜಿಸುತ್ತದೆ
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // ಕೊಟ್ಟಿರುವ ಮೌಲ್ಯವನ್ನು ಬಳಸಿಕೊಂಡು `RcBox<T>` ಗಾಗಿ ನಿಯೋಜಿಸಿ.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // ಮೌಲ್ಯವನ್ನು ಬೈಟ್‌ಗಳಾಗಿ ನಕಲಿಸಿ
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // ಹಂಚಿಕೆಯನ್ನು ಅದರ ವಿಷಯಗಳನ್ನು ಬಿಡದೆ ಮುಕ್ತಗೊಳಿಸಿ
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// ನಿರ್ದಿಷ್ಟ ಉದ್ದದೊಂದಿಗೆ `RcBox<[T]>` ಅನ್ನು ನಿಯೋಜಿಸುತ್ತದೆ.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// ಸ್ಲೈಸ್‌ನಿಂದ ಹೊಸದಾಗಿ ನಿಯೋಜಿಸಲಾದ Rc <\[T\]> ಗೆ ಅಂಶಗಳನ್ನು ನಕಲಿಸಿ
    ///
    /// ಅಸುರಕ್ಷಿತ ಏಕೆಂದರೆ ಕರೆ ಮಾಡುವವರು ಮಾಲೀಕತ್ವವನ್ನು ತೆಗೆದುಕೊಳ್ಳಬೇಕು ಅಥವಾ `T: Copy` ಅನ್ನು ಬಂಧಿಸಬೇಕು
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// ನಿರ್ದಿಷ್ಟ ಗಾತ್ರದ್ದಾಗಿರುವ ಇಟರೇಟರ್‌ನಿಂದ `Rc<[T]>` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    ///
    /// ಗಾತ್ರವು ತಪ್ಪಾಗಿರಬೇಕು ಎಂದು ವರ್ತನೆಯನ್ನು ವಿವರಿಸಲಾಗುವುದಿಲ್ಲ.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // ಟಿ ಅಂಶಗಳನ್ನು ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮಾಡುವಾಗ Panic ಗಾರ್ಡ್.
        // panic ನ ಸಂದರ್ಭದಲ್ಲಿ, ಹೊಸ RcBox ಗೆ ಬರೆಯಲಾದ ಅಂಶಗಳನ್ನು ಕೈಬಿಡಲಾಗುತ್ತದೆ, ನಂತರ ಮೆಮೊರಿ ಮುಕ್ತವಾಗುತ್ತದೆ.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // ಮೊದಲ ಅಂಶಕ್ಕೆ ಪಾಯಿಂಟರ್
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // ಎಲ್ಲಾ ಸ್ಪಷ್ಟವಾಗಿದೆ.ಗಾರ್ಡ್ ಅನ್ನು ಮರೆತುಬಿಡಿ ಆದ್ದರಿಂದ ಅದು ಹೊಸ ಆರ್ಸಿಬಾಕ್ಸ್ ಅನ್ನು ಮುಕ್ತಗೊಳಿಸುವುದಿಲ್ಲ.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// ವಿಶೇಷತೆ trait ಅನ್ನು `From<&[T]>` ಗಾಗಿ ಬಳಸಲಾಗುತ್ತದೆ.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// `Rc` ಅನ್ನು ಇಳಿಯುತ್ತದೆ.
    ///
    /// ಇದು ಬಲವಾದ ಉಲ್ಲೇಖ ಸಂಖ್ಯೆಯನ್ನು ಕಡಿಮೆ ಮಾಡುತ್ತದೆ.
    /// ಬಲವಾದ ಉಲ್ಲೇಖ ಎಣಿಕೆ ಶೂನ್ಯವನ್ನು ತಲುಪಿದರೆ, ಇತರ ಉಲ್ಲೇಖಗಳು (ಯಾವುದಾದರೂ ಇದ್ದರೆ) [`Weak`], ಆದ್ದರಿಂದ ನಾವು ಆಂತರಿಕ ಮೌಲ್ಯವನ್ನು `drop` ಮಾಡುತ್ತೇವೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // ಯಾವುದನ್ನೂ ಮುದ್ರಿಸುವುದಿಲ್ಲ
    /// drop(foo2);   // "dropped!" ಅನ್ನು ಮುದ್ರಿಸುತ್ತದೆ
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // ಒಳಗೊಂಡಿರುವ ವಸ್ತುವನ್ನು ನಾಶಮಾಡಿ
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // ನಾವು ವಿಷಯಗಳನ್ನು ನಾಶಪಡಿಸಿದ್ದೇವೆ ಎಂಬ ಸೂಚ್ಯ "strong weak" ಪಾಯಿಂಟರ್ ಅನ್ನು ಈಗ ತೆಗೆದುಹಾಕಿ.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// `Rc` ಪಾಯಿಂಟರ್‌ನ ತದ್ರೂಪಿ ಮಾಡುತ್ತದೆ.
    ///
    /// ಇದು ಅದೇ ಹಂಚಿಕೆಗೆ ಮತ್ತೊಂದು ಪಾಯಿಂಟರ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ, ಇದು ಬಲವಾದ ಉಲ್ಲೇಖ ಸಂಖ್ಯೆಯನ್ನು ಹೆಚ್ಚಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// `T` ಗಾಗಿ `Default` ಮೌಲ್ಯದೊಂದಿಗೆ ಹೊಸ `Rc<T>` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// `Eq` ಒಂದು ವಿಧಾನವನ್ನು ಹೊಂದಿದ್ದರೂ ಸಹ `Eq` ನಲ್ಲಿ ವಿಶೇಷತೆಯನ್ನು ಅನುಮತಿಸಲು ಹ್ಯಾಕ್ ಮಾಡಿ.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// ನಾವು ಈ ವಿಶೇಷತೆಯನ್ನು ಇಲ್ಲಿ ಮಾಡುತ್ತಿದ್ದೇವೆ ಮತ್ತು `&T` ನಲ್ಲಿ ಹೆಚ್ಚು ಸಾಮಾನ್ಯ ಆಪ್ಟಿಮೈಸೇಶನ್ ಆಗಿ ಅಲ್ಲ, ಏಕೆಂದರೆ ಇದು ರೆಫ್‌ಗಳಲ್ಲಿನ ಎಲ್ಲಾ ಸಮಾನತೆ ಪರಿಶೀಲನೆಗಳಿಗೆ ವೆಚ್ಚವನ್ನು ಸೇರಿಸುತ್ತದೆ.
/// `ಆರ್‌ಸಿ'ಗಳನ್ನು ದೊಡ್ಡ ಮೌಲ್ಯಗಳನ್ನು ಶೇಖರಿಸಿಡಲು ಬಳಸಲಾಗುತ್ತದೆ, ಅದು ಕ್ಲೋನ್ ಮಾಡಲು ನಿಧಾನವಾಗಿರುತ್ತದೆ, ಆದರೆ ಸಮಾನತೆಯನ್ನು ಪರೀಕ್ಷಿಸಲು ಭಾರವಾಗಿರುತ್ತದೆ, ಇದರಿಂದಾಗಿ ಈ ವೆಚ್ಚವು ಹೆಚ್ಚು ಸುಲಭವಾಗಿ ತೀರಿಸಲ್ಪಡುತ್ತದೆ.
///
/// ಇದು ಎರಡು `&ಟಿ`ಗಳಿಗಿಂತ ಎರಡು ಎಕ್ಸ್‌00 ಎಕ್ಸ್ ಕ್ಲೋನ್‌ಗಳನ್ನು ಹೊಂದುವ ಸಾಧ್ಯತೆಯಿದೆ.
///
/// `PartialEq` ಆಗಿ `T: Eq` ಉದ್ದೇಶಪೂರ್ವಕವಾಗಿ ಅಪ್ರಚಲಿತವಾಗಿದ್ದಾಗ ಮಾತ್ರ ನಾವು ಇದನ್ನು ಮಾಡಬಹುದು.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// ಎರಡು `ಆರ್‌ಸಿ'ಗಳಿಗೆ ಸಮಾನತೆ.
    ///
    /// ಎರಡು `ಆರ್‌ಸಿ'ಗಳು ಅವುಗಳ ಆಂತರಿಕ ಮೌಲ್ಯಗಳು ಸಮಾನವಾಗಿದ್ದರೆ, ಅವುಗಳನ್ನು ವಿಭಿನ್ನ ಹಂಚಿಕೆಯಲ್ಲಿ ಸಂಗ್ರಹಿಸಿದ್ದರೂ ಸಹ ಸಮಾನವಾಗಿರುತ್ತದೆ.
    ///
    /// `T` ಸಹ `Eq` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದರೆ (ಸಮಾನತೆಯ ಪ್ರತಿಫಲಿತತೆಯನ್ನು ಸೂಚಿಸುತ್ತದೆ), ಒಂದೇ ಹಂಚಿಕೆಯನ್ನು ಸೂಚಿಸುವ ಎರಡು `Rc` ಗಳು ಯಾವಾಗಲೂ ಸಮಾನವಾಗಿರುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// ಎರಡು `ಆರ್‌ಸಿ'ಗಳಿಗೆ ಅಸಮಾನತೆ.
    ///
    /// ಆಂತರಿಕ ಮೌಲ್ಯಗಳು ಅಸಮಾನವಾಗಿದ್ದರೆ ಎರಡು `ಆರ್ಸಿ'ಗಳು ಅಸಮಾನವಾಗಿವೆ.
    ///
    /// `T` ಸಹ `Eq` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದರೆ (ಸಮಾನತೆಯ ಪ್ರತಿಫಲಿತತೆಯನ್ನು ಸೂಚಿಸುತ್ತದೆ), ಒಂದೇ ಹಂಚಿಕೆಯನ್ನು ಸೂಚಿಸುವ ಎರಡು `Rc` ಗಳು ಎಂದಿಗೂ ಅಸಮಾನವಾಗಿರುವುದಿಲ್ಲ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// ಎರಡು `ಆರ್ಸಿ'ಗಳಿಗೆ ಭಾಗಶಃ ಹೋಲಿಕೆ.
    ///
    /// ಇಬ್ಬರನ್ನು ತಮ್ಮ ಆಂತರಿಕ ಮೌಲ್ಯಗಳಿಗೆ `partial_cmp()` ಗೆ ಕರೆ ಮಾಡುವ ಮೂಲಕ ಹೋಲಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// ಎರಡು `ಆರ್‌ಸಿ'ಗಳಿಗೆ ಹೋಲಿಕೆಗಿಂತ ಕಡಿಮೆ.
    ///
    /// ಇಬ್ಬರನ್ನು ತಮ್ಮ ಆಂತರಿಕ ಮೌಲ್ಯಗಳಿಗೆ `<` ಗೆ ಕರೆ ಮಾಡುವ ಮೂಲಕ ಹೋಲಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// ಎರಡು `ಆರ್‌ಸಿ'ಗಳಿಗೆ ಹೋಲಿಕೆ 'ಕಡಿಮೆ ಅಥವಾ ಸಮ'.
    ///
    /// ಇಬ್ಬರನ್ನು ತಮ್ಮ ಆಂತರಿಕ ಮೌಲ್ಯಗಳಿಗೆ `<=` ಗೆ ಕರೆ ಮಾಡುವ ಮೂಲಕ ಹೋಲಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// ಎರಡು `ಆರ್‌ಸಿ'ಗಳಿಗೆ ಹೋಲಿಕೆಗಿಂತ ದೊಡ್ಡದಾಗಿದೆ.
    ///
    /// ಇಬ್ಬರನ್ನು ತಮ್ಮ ಆಂತರಿಕ ಮೌಲ್ಯಗಳಿಗೆ `>` ಗೆ ಕರೆ ಮಾಡುವ ಮೂಲಕ ಹೋಲಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// ಎರಡು `ಆರ್‌ಸಿ'ಗಳಿಗೆ ಹೋಲಿಕೆ 'ದೊಡ್ಡದು ಅಥವಾ ಸಮ'.
    ///
    /// ಇಬ್ಬರನ್ನು ತಮ್ಮ ಆಂತರಿಕ ಮೌಲ್ಯಗಳಿಗೆ `>=` ಗೆ ಕರೆ ಮಾಡುವ ಮೂಲಕ ಹೋಲಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// ಎರಡು `ಆರ್‌ಸಿ'ಗಳಿಗೆ ಹೋಲಿಕೆ.
    ///
    /// ಇಬ್ಬರನ್ನು ತಮ್ಮ ಆಂತರಿಕ ಮೌಲ್ಯಗಳಿಗೆ `cmp()` ಗೆ ಕರೆ ಮಾಡುವ ಮೂಲಕ ಹೋಲಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// ಉಲ್ಲೇಖ-ಎಣಿಸಿದ ಸ್ಲೈಸ್ ಅನ್ನು ನಿಯೋಜಿಸಿ ಮತ್ತು `v` ನ ವಸ್ತುಗಳನ್ನು ಕ್ಲೋನ್ ಮಾಡುವ ಮೂಲಕ ಅದನ್ನು ಭರ್ತಿ ಮಾಡಿ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// ಉಲ್ಲೇಖ-ಎಣಿಸಿದ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ನಿಯೋಜಿಸಿ ಮತ್ತು ಅದರಲ್ಲಿ `v` ಅನ್ನು ನಕಲಿಸಿ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// ಉಲ್ಲೇಖ-ಎಣಿಸಿದ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ನಿಯೋಜಿಸಿ ಮತ್ತು ಅದರಲ್ಲಿ `v` ಅನ್ನು ನಕಲಿಸಿ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// ಪೆಟ್ಟಿಗೆಯ ವಸ್ತುವನ್ನು ಹೊಸ, ಉಲ್ಲೇಖ ಎಣಿಕೆ, ಹಂಚಿಕೆಗೆ ಸರಿಸಿ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// ಉಲ್ಲೇಖ-ಎಣಿಸಿದ ಸ್ಲೈಸ್ ಅನ್ನು ನಿಯೋಜಿಸಿ ಮತ್ತು `v` ನ ವಸ್ತುಗಳನ್ನು ಅದರೊಳಗೆ ಸರಿಸಿ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Vec ಅನ್ನು ಅದರ ಸ್ಮರಣೆಯನ್ನು ಮುಕ್ತಗೊಳಿಸಲು ಅನುಮತಿಸಿ, ಆದರೆ ಅದರ ವಿಷಯಗಳನ್ನು ನಾಶಪಡಿಸಬೇಡಿ
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// `Iterator` ನಲ್ಲಿನ ಪ್ರತಿಯೊಂದು ಅಂಶವನ್ನು ತೆಗೆದುಕೊಂಡು ಅದನ್ನು `Rc<[T]>` ಗೆ ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// # ಕಾರ್ಯಕ್ಷಮತೆಯ ಗುಣಲಕ್ಷಣಗಳು
    ///
    /// ## ಸಾಮಾನ್ಯ ಪ್ರಕರಣ
    ///
    /// ಸಾಮಾನ್ಯ ಸಂದರ್ಭದಲ್ಲಿ, `Rc<[T]>` ಗೆ ಸಂಗ್ರಹಿಸುವುದನ್ನು ಮೊದಲು `Vec<T>` ಗೆ ಸಂಗ್ರಹಿಸುವ ಮೂಲಕ ಮಾಡಲಾಗುತ್ತದೆ.ಅಂದರೆ, ಈ ಕೆಳಗಿನವುಗಳನ್ನು ಬರೆಯುವಾಗ:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ಇದು ನಾವು ಬರೆದಂತೆ ವರ್ತಿಸುತ್ತದೆ:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // ಮೊದಲ ಹಂಚಿಕೆ ಇಲ್ಲಿ ನಡೆಯುತ್ತದೆ.
    ///     .into(); // `Rc<[T]>` ಗಾಗಿ ಎರಡನೇ ಹಂಚಿಕೆ ಇಲ್ಲಿ ನಡೆಯುತ್ತದೆ.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ಇದು `Vec<T>` ಅನ್ನು ನಿರ್ಮಿಸಲು ಅಗತ್ಯವಿರುವಷ್ಟು ಬಾರಿ ನಿಗದಿಪಡಿಸುತ್ತದೆ ಮತ್ತು ನಂತರ `Vec<T>` ಅನ್ನು `Rc<[T]>` ಆಗಿ ಪರಿವರ್ತಿಸಲು ಇದು ಒಮ್ಮೆ ಹಂಚುತ್ತದೆ.
    ///
    ///
    /// ## ತಿಳಿದಿರುವ ಉದ್ದದ ಪುನರಾವರ್ತಕರು
    ///
    /// ನಿಮ್ಮ `Iterator` `TrustedLen` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದಾಗ ಮತ್ತು ನಿಖರವಾದ ಗಾತ್ರದಲ್ಲಿದ್ದಾಗ, `Rc<[T]>` ಗಾಗಿ ಒಂದೇ ಹಂಚಿಕೆಯನ್ನು ಮಾಡಲಾಗುತ್ತದೆ.ಉದಾಹರಣೆಗೆ:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // ಒಂದೇ ಹಂಚಿಕೆ ಇಲ್ಲಿ ನಡೆಯುತ್ತದೆ.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// ವಿಶೇಷತೆ trait ಅನ್ನು `Rc<[T]>` ಗೆ ಸಂಗ್ರಹಿಸಲು ಬಳಸಲಾಗುತ್ತದೆ.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // `TrustedLen` ಪುನರಾವರ್ತಕಕ್ಕೆ ಇದೇ ಪರಿಸ್ಥಿತಿ.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // ಸುರಕ್ಷತೆ: ಪುನರಾವರ್ತಕವು ನಿಖರವಾದ ಉದ್ದವನ್ನು ಹೊಂದಿದೆ ಮತ್ತು ನಾವು ಹೊಂದಿದ್ದೇವೆ ಎಂದು ನಾವು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // ಸಾಮಾನ್ಯ ಅನುಷ್ಠಾನಕ್ಕೆ ಹಿಂತಿರುಗಿ.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` ಇದು [`Rc`] ನ ಒಂದು ಆವೃತ್ತಿಯಾಗಿದ್ದು ಅದು ನಿರ್ವಹಿಸಿದ ಹಂಚಿಕೆಗೆ ಮಾಲೀಕತ್ವ ರಹಿತ ಉಲ್ಲೇಖವನ್ನು ಹೊಂದಿದೆ.`Weak` ಪಾಯಿಂಟರ್‌ನಲ್ಲಿ [`upgrade`] ಗೆ ಕರೆ ಮಾಡುವ ಮೂಲಕ ಹಂಚಿಕೆಯನ್ನು ಪ್ರವೇಶಿಸಬಹುದು, ಅದು [`ಆಯ್ಕೆ`]`<`[`Rc`] `ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ<T>>`.
///
/// `Weak` ಉಲ್ಲೇಖವು ಮಾಲೀಕತ್ವದ ಕಡೆಗೆ ಎಣಿಸದ ಕಾರಣ, ಹಂಚಿಕೆಯಲ್ಲಿ ಸಂಗ್ರಹವಾಗಿರುವ ಮೌಲ್ಯವನ್ನು ಕೈಬಿಡುವುದನ್ನು ಇದು ತಡೆಯುವುದಿಲ್ಲ, ಮತ್ತು `Weak` ಸ್ವತಃ ಇನ್ನೂ ಇರುವ ಮೌಲ್ಯದ ಬಗ್ಗೆ ಯಾವುದೇ ಭರವಸೆ ನೀಡುವುದಿಲ್ಲ.
/// [`ಅಪ್‌ಗ್ರೇಡ್`] ಡಿ ಮಾಡಿದಾಗ ಅದು [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಬಹುದು.
/// ಆದಾಗ್ಯೂ, `Weak` ಉಲ್ಲೇಖ * ಹಂಚಿಕೆಯನ್ನು (ಬ್ಯಾಕಿಂಗ್ ಸ್ಟೋರ್) ಡಿಲೊಲೊಕೇಟ್ ಮಾಡುವುದನ್ನು ತಡೆಯುತ್ತದೆ.
///
/// `Weak` ಪಾಯಿಂಟರ್ ಅದರ ಆಂತರಿಕ ಮೌಲ್ಯವನ್ನು ಕೈಬಿಡುವುದನ್ನು ತಡೆಯದೆ [`Rc`] ನಿರ್ವಹಿಸುವ ಹಂಚಿಕೆಗೆ ತಾತ್ಕಾಲಿಕ ಉಲ್ಲೇಖವನ್ನು ಇರಿಸಲು ಉಪಯುಕ್ತವಾಗಿದೆ.
/// [`Rc`] ಪಾಯಿಂಟರ್‌ಗಳ ನಡುವಿನ ವೃತ್ತಾಕಾರದ ಉಲ್ಲೇಖಗಳನ್ನು ತಡೆಯಲು ಸಹ ಇದನ್ನು ಬಳಸಲಾಗುತ್ತದೆ, ಏಕೆಂದರೆ ಪರಸ್ಪರ ಮಾಲೀಕತ್ವದ ಉಲ್ಲೇಖಗಳು [`Rc`] ಅನ್ನು ಕೈಬಿಡಲು ಎಂದಿಗೂ ಅನುಮತಿಸುವುದಿಲ್ಲ.
/// ಉದಾಹರಣೆಗೆ, ಒಂದು ಮರವು ಪೋಷಕ ನೋಡ್‌ಗಳಿಂದ ಮಕ್ಕಳಿಗೆ ಬಲವಾದ [`Rc`] ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಹೊಂದಿರಬಹುದು ಮತ್ತು ಮಕ್ಕಳಿಂದ `Weak` ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಅವರ ಪೋಷಕರಿಗೆ ಹಿಂತಿರುಗಿಸಬಹುದು.
///
/// `Weak` ಪಾಯಿಂಟರ್ ಪಡೆಯುವ ವಿಶಿಷ್ಟ ಮಾರ್ಗವೆಂದರೆ [`Rc::downgrade`] ಗೆ ಕರೆ ಮಾಡುವುದು.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // ಎನ್ಯುಮ್‌ಗಳಲ್ಲಿ ಈ ಪ್ರಕಾರದ ಗಾತ್ರವನ್ನು ಅತ್ಯುತ್ತಮವಾಗಿಸಲು ಇದು ಎಕ್ಸ್‌00 ಎಕ್ಸ್ ಆಗಿದೆ, ಆದರೆ ಇದು ಮಾನ್ಯ ಪಾಯಿಂಟರ್ ಆಗಿರಬೇಕಾಗಿಲ್ಲ.
    //
    // `Weak::new` ಇದನ್ನು `usize::MAX` ಗೆ ಹೊಂದಿಸುತ್ತದೆ ಇದರಿಂದ ರಾಶಿಯಲ್ಲಿ ಜಾಗವನ್ನು ನಿಯೋಜಿಸುವ ಅಗತ್ಯವಿಲ್ಲ.
    // ನಿಜವಾದ ಪಾಯಿಂಟರ್ ಎಂದಿಗೂ ಹೊಂದಿರದ ಮೌಲ್ಯವಲ್ಲ ಏಕೆಂದರೆ ಆರ್‌ಸಿಬಾಕ್ಸ್ ಕನಿಷ್ಠ 2 ಹೊಂದಾಣಿಕೆಯನ್ನು ಹೊಂದಿದೆ.
    // `T: Sized` ಇದ್ದಾಗ ಮಾತ್ರ ಇದು ಸಾಧ್ಯ;ಗಾತ್ರೀಕರಿಸದ `T` ಎಂದಿಗೂ ತೂಗಾಡುವುದಿಲ್ಲ.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// ಯಾವುದೇ ಮೆಮೊರಿಯನ್ನು ನಿಯೋಜಿಸದೆ ಹೊಸ `Weak<T>` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    /// ರಿಟರ್ನ್ ಮೌಲ್ಯದಲ್ಲಿ [`upgrade`] ಗೆ ಕರೆ ಮಾಡುವುದು ಯಾವಾಗಲೂ [`None`] ಅನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// ಡೇಟಾ ಕ್ಷೇತ್ರದ ಬಗ್ಗೆ ಯಾವುದೇ ಸಮರ್ಥನೆಗಳನ್ನು ನೀಡದೆ ಉಲ್ಲೇಖ ಎಣಿಕೆಗಳನ್ನು ಪ್ರವೇಶಿಸಲು ಅನುಮತಿಸುವ ಸಹಾಯಕ ಪ್ರಕಾರ.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// ಈ `Weak<T>` ಸೂಚಿಸಿದ `T` ವಸ್ತುವಿಗೆ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಕೆಲವು ಬಲವಾದ ಉಲ್ಲೇಖಗಳಿದ್ದರೆ ಮಾತ್ರ ಪಾಯಿಂಟರ್ ಮಾನ್ಯವಾಗಿರುತ್ತದೆ.
    /// ಪಾಯಿಂಟರ್ ತೂಗಾಡುತ್ತಿರುವ, ಜೋಡಿಸದ ಅಥವಾ [`null`] ಇಲ್ಲದಿದ್ದರೆ ಇರಬಹುದು.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // ಎರಡೂ ಒಂದೇ ವಸ್ತುವನ್ನು ಸೂಚಿಸುತ್ತವೆ
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // ಇಲ್ಲಿ ಬಲವಾದವರು ಅದನ್ನು ಜೀವಂತವಾಗಿರಿಸುತ್ತಾರೆ, ಆದ್ದರಿಂದ ನಾವು ಇನ್ನೂ ವಸ್ತುವನ್ನು ಪ್ರವೇಶಿಸಬಹುದು.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // ಆದರೆ ಇನ್ನೊಂದಿಲ್ಲ.
    /// // ನಾವು weak.as_ptr() ಮಾಡಬಹುದು, ಆದರೆ ಪಾಯಿಂಟರ್ ಅನ್ನು ಪ್ರವೇಶಿಸುವುದು ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
    /// // assert_eq! ("ಹಲೋ", ಅಸುರಕ್ಷಿತ {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // ಪಾಯಿಂಟರ್ ತೂಗಾಡುತ್ತಿದ್ದರೆ, ನಾವು ನೇರವಾಗಿ ಸೆಂಟಿನೆಲ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತೇವೆ.
            // ಇದು ಮಾನ್ಯ ಪೇಲೋಡ್ ವಿಳಾಸವಾಗಿರಬಾರದು, ಏಕೆಂದರೆ ಪೇಲೋಡ್ ಕನಿಷ್ಠ RcBox (usize) ನಂತೆ ಜೋಡಿಸಲ್ಪಟ್ಟಿರುತ್ತದೆ.
            ptr as *const T
        } else {
            // ಸುರಕ್ಷತೆ: is_dangling ಸುಳ್ಳನ್ನು ಹಿಂತಿರುಗಿಸಿದರೆ, ನಂತರ ಪಾಯಿಂಟರ್ ಡಿಫರೆನ್ಸೆಬಲ್ ಆಗಿದೆ.
            // ಈ ಸಮಯದಲ್ಲಿ ಪೇಲೋಡ್ ಅನ್ನು ಕೈಬಿಡಬಹುದು, ಮತ್ತು ನಾವು ಮೂಲವನ್ನು ಕಾಪಾಡಿಕೊಳ್ಳಬೇಕು, ಆದ್ದರಿಂದ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಕುಶಲತೆಯನ್ನು ಬಳಸಿ.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// `Weak<T>` ಅನ್ನು ಬಳಸುತ್ತದೆ ಮತ್ತು ಅದನ್ನು ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ಇದು ದುರ್ಬಲ ಪಾಯಿಂಟರ್ ಅನ್ನು ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ, ಆದರೆ ಒಂದು ದುರ್ಬಲ ಉಲ್ಲೇಖದ ಮಾಲೀಕತ್ವವನ್ನು ಇನ್ನೂ ಕಾಪಾಡಿಕೊಳ್ಳುತ್ತದೆ (ಈ ಕಾರ್ಯಾಚರಣೆಯಿಂದ ದುರ್ಬಲ ಎಣಿಕೆಯನ್ನು ಮಾರ್ಪಡಿಸಲಾಗಿಲ್ಲ).
    /// ಇದನ್ನು [`from_raw`] ನೊಂದಿಗೆ `Weak<T>` ಗೆ ಹಿಂತಿರುಗಿಸಬಹುದು.
    ///
    /// [`as_ptr`] ನಂತೆ ಪಾಯಿಂಟರ್‌ನ ಗುರಿಯನ್ನು ಪ್ರವೇಶಿಸುವ ಅದೇ ನಿರ್ಬಂಧಗಳು ಅನ್ವಯಿಸುತ್ತವೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// ಈ ಹಿಂದೆ [`into_raw`] ರಚಿಸಿದ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಅನ್ನು ಮತ್ತೆ `Weak<T>` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ಬಲವಾದ ಉಲ್ಲೇಖವನ್ನು ಸುರಕ್ಷಿತವಾಗಿ ಪಡೆಯಲು (ನಂತರ [`upgrade`] ಗೆ ಕರೆ ಮಾಡುವ ಮೂಲಕ) ಅಥವಾ `Weak<T>` ಅನ್ನು ಬಿಡುವುದರ ಮೂಲಕ ದುರ್ಬಲ ಎಣಿಕೆಯನ್ನು ನಿವಾರಿಸಲು ಇದನ್ನು ಬಳಸಬಹುದು.
    ///
    /// ಇದು ಒಂದು ದುರ್ಬಲ ಉಲ್ಲೇಖದ ಮಾಲೀಕತ್ವವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ ([`new`] ರಚಿಸಿದ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಹೊರತುಪಡಿಸಿ, ಇವುಗಳು ಯಾವುದನ್ನೂ ಹೊಂದಿಲ್ಲವಾದ್ದರಿಂದ; ವಿಧಾನವು ಅವುಗಳ ಮೇಲೆ ಇನ್ನೂ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ).
    ///
    /// # Safety
    ///
    /// ಪಾಯಿಂಟರ್ [`into_raw`] ನಿಂದ ಹುಟ್ಟಿಕೊಂಡಿರಬೇಕು ಮತ್ತು ಅದರ ಸಂಭಾವ್ಯ ದುರ್ಬಲ ಉಲ್ಲೇಖವನ್ನು ಇನ್ನೂ ಹೊಂದಿರಬೇಕು.
    ///
    /// ಇದನ್ನು ಕರೆಯುವ ಸಮಯದಲ್ಲಿ ಬಲವಾದ ಎಣಿಕೆ 0 ಆಗಿರಲು ಅನುಮತಿಸಲಾಗಿದೆ.
    /// ಅದೇನೇ ಇದ್ದರೂ, ಇದು ಪ್ರಸ್ತುತ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ನಂತೆ ಪ್ರತಿನಿಧಿಸಲ್ಪಟ್ಟಿರುವ ಒಂದು ದುರ್ಬಲ ಉಲ್ಲೇಖದ ಮಾಲೀಕತ್ವವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ (ಈ ಕಾರ್ಯಾಚರಣೆಯಿಂದ ದುರ್ಬಲ ಎಣಿಕೆ ಮಾರ್ಪಡಿಸಲಾಗಿಲ್ಲ) ಮತ್ತು ಆದ್ದರಿಂದ ಇದನ್ನು [`into_raw`] ಗೆ ಹಿಂದಿನ ಕರೆಯೊಂದಿಗೆ ಜೋಡಿಸಬೇಕು.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // ಕೊನೆಯ ದುರ್ಬಲ ಎಣಿಕೆ ಕಡಿಮೆ ಮಾಡಿ.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // ಇನ್ಪುಟ್ ಪಾಯಿಂಟರ್ ಅನ್ನು ಹೇಗೆ ಪಡೆಯಲಾಗಿದೆ ಎಂಬುದರ ಕುರಿತು ಸಂದರ್ಭಕ್ಕಾಗಿ Weak::as_ptr ನೋಡಿ.

        let ptr = if is_dangling(ptr as *mut T) {
            // ಇದು ತೂಗಾಡುತ್ತಿರುವ ದುರ್ಬಲ.
            ptr as *mut RcBox<T>
        } else {
            // ಇಲ್ಲದಿದ್ದರೆ, ಪಾಯಿಂಟರ್ ದುರ್ಬಲವಾದ ದುರ್ಬಲತೆಯಿಂದ ಬಂದಿದೆ ಎಂದು ನಮಗೆ ಖಾತ್ರಿಯಿದೆ.
            // ಸುರಕ್ಷತೆ: ಡೇಟಾ_ಆಫ್ಸೆಟ್ ಕರೆ ಮಾಡಲು ಸುರಕ್ಷಿತವಾಗಿದೆ, ಏಕೆಂದರೆ ಪಿಟಿಆರ್ ನಿಜವಾದ (ಸಂಭಾವ್ಯವಾಗಿ ಕೈಬಿಡಲಾಗಿದೆ) ಟಿ.
            let offset = unsafe { data_offset(ptr) };
            // ಹೀಗಾಗಿ, ಇಡೀ ಆರ್‌ಸಿಬಾಕ್ಸ್ ಪಡೆಯಲು ನಾವು ಆಫ್‌ಸೆಟ್ ಅನ್ನು ಹಿಮ್ಮುಖಗೊಳಿಸುತ್ತೇವೆ.
            // ಸುರಕ್ಷತೆ: ಪಾಯಿಂಟರ್ ದುರ್ಬಲದಿಂದ ಹುಟ್ಟಿಕೊಂಡಿದೆ, ಆದ್ದರಿಂದ ಈ ಆಫ್‌ಸೆಟ್ ಸುರಕ್ಷಿತವಾಗಿದೆ.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // ಸುರಕ್ಷತೆ: ನಾವು ಈಗ ಮೂಲ ದುರ್ಬಲ ಪಾಯಿಂಟರ್ ಅನ್ನು ಮರುಪಡೆಯಿದ್ದೇವೆ, ಆದ್ದರಿಂದ ದುರ್ಬಲತೆಯನ್ನು ರಚಿಸಬಹುದು.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// `Weak` ಪಾಯಿಂಟರ್ ಅನ್ನು [`Rc`] ಗೆ ಅಪ್‌ಗ್ರೇಡ್ ಮಾಡಲು ಪ್ರಯತ್ನಿಸುತ್ತದೆ, ಯಶಸ್ವಿಯಾದರೆ ಆಂತರಿಕ ಮೌಲ್ಯವನ್ನು ಬಿಡುವುದನ್ನು ವಿಳಂಬಗೊಳಿಸುತ್ತದೆ.
    ///
    ///
    /// ಆಂತರಿಕ ಮೌಲ್ಯವನ್ನು ಕೈಬಿಟ್ಟರೆ [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // ಎಲ್ಲಾ ಬಲವಾದ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ನಾಶಮಾಡಿ.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// ಈ ಹಂಚಿಕೆಯನ್ನು ಸೂಚಿಸುವ ಬಲವಾದ (`Rc`) ಪಾಯಿಂಟರ್‌ಗಳ ಸಂಖ್ಯೆಯನ್ನು ಪಡೆಯುತ್ತದೆ.
    ///
    /// [`Weak::new`] ಬಳಸಿ `self` ಅನ್ನು ರಚಿಸಿದ್ದರೆ, ಇದು 0 ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// ಈ ಹಂಚಿಕೆಯನ್ನು ಸೂಚಿಸುವ `Weak` ಪಾಯಿಂಟರ್‌ಗಳ ಸಂಖ್ಯೆಯನ್ನು ಪಡೆಯುತ್ತದೆ.
    ///
    /// ಯಾವುದೇ ಬಲವಾದ ಪಾಯಿಂಟರ್‌ಗಳು ಉಳಿದಿಲ್ಲದಿದ್ದರೆ, ಇದು ಶೂನ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // ಸೂಚ್ಯ ದುರ್ಬಲ ptr ಅನ್ನು ಕಳೆಯಿರಿ
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// ಪಾಯಿಂಟರ್ ತೂಗಾಡುತ್ತಿರುವಾಗ ಮತ್ತು ಹಂಚಿಕೆಯಾದ `RcBox` ಇಲ್ಲದಿದ್ದಾಗ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, (ಅಂದರೆ, ಈ `Weak` ಅನ್ನು `Weak::new` ನಿಂದ ರಚಿಸಿದಾಗ).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // ಕ್ಷೇತ್ರವು ಏಕಕಾಲದಲ್ಲಿ ರೂಪಾಂತರಗೊಳ್ಳುವುದರಿಂದ, "data" ಕ್ಷೇತ್ರವನ್ನು ಒಳಗೊಂಡ ಉಲ್ಲೇಖವನ್ನು * ರಚಿಸದಿರಲು ನಾವು ಜಾಗರೂಕರಾಗಿರುತ್ತೇವೆ (ಉದಾಹರಣೆಗೆ, ಕೊನೆಯ `Rc` ಅನ್ನು ಕೈಬಿಟ್ಟರೆ, ಡೇಟಾ ಕ್ಷೇತ್ರವನ್ನು ಸ್ಥಳದಲ್ಲಿ ಬಿಡಲಾಗುತ್ತದೆ).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// ಎರಡು `ದುರ್ಬಲ'ಗಳು ಒಂದೇ ಹಂಚಿಕೆಗೆ ([`ptr::eq`] ನಂತೆಯೇ) ಸೂಚಿಸಿದರೆ ಅಥವಾ ಎರಡೂ ಯಾವುದೇ ಹಂಚಿಕೆಗೆ ಸೂಚಿಸದಿದ್ದರೆ (ಏಕೆಂದರೆ ಅವುಗಳನ್ನು `Weak::new()`) ನೊಂದಿಗೆ ರಚಿಸಲಾಗಿದೆ) `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Notes
    ///
    /// ಇದು ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಹೋಲಿಸುವ ಕಾರಣ, ಯಾವುದೇ ಹಂಚಿಕೆಗೆ ಅವರು ಸೂಚಿಸದಿದ್ದರೂ ಸಹ, `Weak::new()` ಪರಸ್ಪರ ಸಮಾನವಾಗಿರುತ್ತದೆ ಎಂದರ್ಥ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` ಅನ್ನು ಹೋಲಿಸುವುದು.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` ಪಾಯಿಂಟರ್ ಅನ್ನು ಬಿಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // ಯಾವುದನ್ನೂ ಮುದ್ರಿಸುವುದಿಲ್ಲ
    /// drop(foo);        // "dropped!" ಅನ್ನು ಮುದ್ರಿಸುತ್ತದೆ
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // ದುರ್ಬಲ ಎಣಿಕೆ 1 ರಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ, ಮತ್ತು ಎಲ್ಲಾ ಬಲವಾದ ಪಾಯಿಂಟರ್‌ಗಳು ಕಣ್ಮರೆಯಾದರೆ ಮಾತ್ರ ಶೂನ್ಯಕ್ಕೆ ಹೋಗುತ್ತದೆ.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// ಒಂದೇ ಹಂಚಿಕೆಯನ್ನು ಸೂಚಿಸುವ `Weak` ಪಾಯಿಂಟರ್‌ನ ತದ್ರೂಪಿ ಮಾಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// ಹೊಸ `Weak<T>` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ, `T` ಗಾಗಿ ಮೆಮೊರಿಯನ್ನು ಪ್ರಾರಂಭಿಸದೆ ನಿಯೋಜಿಸುತ್ತದೆ.
    /// ರಿಟರ್ನ್ ಮೌಲ್ಯದಲ್ಲಿ [`upgrade`] ಗೆ ಕರೆ ಮಾಡುವುದು ಯಾವಾಗಲೂ [`None`] ಅನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: mem::forget ಅನ್ನು ಸುರಕ್ಷಿತವಾಗಿ ಎದುರಿಸಲು ನಾವು ಇಲ್ಲಿ ಪರಿಶೀಲಿಸಿದ್ದೇವೆ.ನಿರ್ದಿಷ್ಟವಾಗಿ
// ನೀವು mem::forget Rcs (ಅಥವಾ ದುರ್ಬಲ) ಆಗಿದ್ದರೆ, ref-ಎಣಿಕೆ ಉಕ್ಕಿ ಹರಿಯಬಹುದು, ಮತ್ತು ನಂತರ ನೀವು ಅತ್ಯುತ್ತಮ Rc ಗಳು (ಅಥವಾ ದುರ್ಬಲಗಳು) ಅಸ್ತಿತ್ವದಲ್ಲಿದ್ದಾಗ ಹಂಚಿಕೆಯನ್ನು ಮುಕ್ತಗೊಳಿಸಬಹುದು.
//
// ನಾವು ಸ್ಥಗಿತಗೊಳಿಸುತ್ತೇವೆ ಏಕೆಂದರೆ ಇದು ಅವನತಿ ಹೊಂದಿದ ಸನ್ನಿವೇಶವಾಗಿದ್ದು, ಏನಾಗುತ್ತದೆ ಎಂಬುದರ ಬಗ್ಗೆ ನಾವು ಹೆದರುವುದಿಲ್ಲ-ಯಾವುದೇ ನೈಜ ಪ್ರೋಗ್ರಾಂ ಇದನ್ನು ಅನುಭವಿಸಬಾರದು.
//
// ಮಾಲೀಕತ್ವ ಮತ್ತು ಚಲಿಸುವ-ಶಬ್ದಾರ್ಥಗಳಿಗೆ ಧನ್ಯವಾದಗಳು Rust ನಲ್ಲಿ ನೀವು ನಿಜವಾಗಿಯೂ ಕ್ಲೋನ್ ಮಾಡುವ ಅಗತ್ಯವಿಲ್ಲದ ಕಾರಣ ಇದು ನಗಣ್ಯ ಓವರ್ಹೆಡ್ ಅನ್ನು ಹೊಂದಿರಬೇಕು.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // ಮೌಲ್ಯವನ್ನು ಕೈಬಿಡುವ ಬದಲು ಓವರ್‌ಫ್ಲೋನಲ್ಲಿ ಸ್ಥಗಿತಗೊಳಿಸಲು ನಾವು ಬಯಸುತ್ತೇವೆ.
        // ಇದನ್ನು ಕರೆಯುವಾಗ ಉಲ್ಲೇಖ ಎಣಿಕೆ ಎಂದಿಗೂ ಶೂನ್ಯವಾಗುವುದಿಲ್ಲ;
        // ಅದೇನೇ ಇದ್ದರೂ, ಎಲ್‌ಎಲ್‌ವಿಎಂ ಅನ್ನು ತಪ್ಪಿಹೋದ ಆಪ್ಟಿಮೈಸೇಶನ್‌ನಲ್ಲಿ ಸುಳಿವು ನೀಡಲು ನಾವು ಇಲ್ಲಿ ಸ್ಥಗಿತಗೊಳಿಸುತ್ತೇವೆ.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // ಮೌಲ್ಯವನ್ನು ಕೈಬಿಡುವ ಬದಲು ಓವರ್‌ಫ್ಲೋನಲ್ಲಿ ಸ್ಥಗಿತಗೊಳಿಸಲು ನಾವು ಬಯಸುತ್ತೇವೆ.
        // ಇದನ್ನು ಕರೆಯುವಾಗ ಉಲ್ಲೇಖ ಎಣಿಕೆ ಎಂದಿಗೂ ಶೂನ್ಯವಾಗುವುದಿಲ್ಲ;
        // ಅದೇನೇ ಇದ್ದರೂ, ಎಲ್‌ಎಲ್‌ವಿಎಂ ಅನ್ನು ತಪ್ಪಿಹೋದ ಆಪ್ಟಿಮೈಸೇಶನ್‌ನಲ್ಲಿ ಸುಳಿವು ನೀಡಲು ನಾವು ಇಲ್ಲಿ ಸ್ಥಗಿತಗೊಳಿಸುತ್ತೇವೆ.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// ಪಾಯಿಂಟರ್‌ನ ಹಿಂದಿನ ಪೇಲೋಡ್‌ಗಾಗಿ `RcBox` ಒಳಗೆ ಆಫ್‌ಸೆಟ್ ಪಡೆಯಿರಿ.
///
/// # Safety
///
/// ಪಾಯಿಂಟರ್ ಹಿಂದೆ ಟಿ ಯ ಮಾನ್ಯ ಉದಾಹರಣೆಯನ್ನು ಸೂಚಿಸಬೇಕು (ಮತ್ತು ಮಾನ್ಯ ಮೆಟಾಡೇಟಾವನ್ನು ಹೊಂದಿರಬೇಕು), ಆದರೆ ಟಿ ಅನ್ನು ಕೈಬಿಡಲು ಅನುಮತಿಸಲಾಗಿದೆ.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // ಗಾತ್ರೀಕರಿಸದ ಮೌಲ್ಯವನ್ನು ಆರ್‌ಸಿಬಾಕ್ಸ್‌ನ ಕೊನೆಯಲ್ಲಿ ಜೋಡಿಸಿ.
    // ಆರ್ಸಿಬಾಕ್ಸ್ ಎಕ್ಸ್ 00 ಎಕ್ಸ್ ಆಗಿರುವುದರಿಂದ, ಇದು ಯಾವಾಗಲೂ ಮೆಮೊರಿಯಲ್ಲಿ ಕೊನೆಯ ಕ್ಷೇತ್ರವಾಗಿರುತ್ತದೆ.
    // ಸುರಕ್ಷತೆ: ಚೂರುಗಳು, trait ವಸ್ತುಗಳು,
    // ಮತ್ತು ಬಾಹ್ಯ ಪ್ರಕಾರಗಳು, align_of_val_raw ನ ಅವಶ್ಯಕತೆಗಳನ್ನು ಪೂರೈಸಲು ಪ್ರಸ್ತುತ ಇನ್ಪುಟ್ ಸುರಕ್ಷತೆಯ ಅವಶ್ಯಕತೆ ಸಾಕು;ಇದು std ನ ಹೊರಗಡೆ ಅವಲಂಬಿಸದ ಭಾಷೆಯ ಅನುಷ್ಠಾನ ವಿವರವಾಗಿದೆ.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}