use crate::boxed::Box;

#[rustc_specialization_trait]
pub(super) unsafe trait IsZero {
    /// ಈ ಮೌಲ್ಯವು ಶೂನ್ಯವಾಗಿದೆಯೆ
    fn is_zero(&self) -> bool;
}

macro_rules! impl_is_zero {
    ($t:ty, $is_zero:expr) => {
        unsafe impl IsZero for $t {
            #[inline]
            fn is_zero(&self) -> bool {
                $is_zero(*self)
            }
        }
    };
}

impl_is_zero!(i16, |x| x == 0);
impl_is_zero!(i32, |x| x == 0);
impl_is_zero!(i64, |x| x == 0);
impl_is_zero!(i128, |x| x == 0);
impl_is_zero!(isize, |x| x == 0);

impl_is_zero!(u16, |x| x == 0);
impl_is_zero!(u32, |x| x == 0);
impl_is_zero!(u64, |x| x == 0);
impl_is_zero!(u128, |x| x == 0);
impl_is_zero!(usize, |x| x == 0);

impl_is_zero!(bool, |x| x == false);
impl_is_zero!(char, |x| x == '\0');

impl_is_zero!(f32, |x: f32| x.to_bits() == 0);
impl_is_zero!(f64, |x: f64| x.to_bits() == 0);

unsafe impl<T> IsZero for *const T {
    #[inline]
    fn is_zero(&self) -> bool {
        (*self).is_null()
    }
}

unsafe impl<T> IsZero for *mut T {
    #[inline]
    fn is_zero(&self) -> bool {
        (*self).is_null()
    }
}

// `Option<&T>` ಮತ್ತು `Option<Box<T>>` `None` ಅನ್ನು ಶೂನ್ಯವೆಂದು ಪ್ರತಿನಿಧಿಸುವ ಭರವಸೆ ಇದೆ.
// ಫ್ಯಾಟ್ ಪಾಯಿಂಟರ್‌ಗಳಿಗಾಗಿ, `Some` ರೂಪಾಂತರದಲ್ಲಿ ಪಾಯಿಂಟರ್ ಮೆಟಾಡೇಟಾ ಆಗಿರುವ ಬೈಟ್‌ಗಳು `None` ರೂಪಾಂತರದಲ್ಲಿ ಪ್ಯಾಡಿಂಗ್ ಆಗಿರುತ್ತವೆ, ಆದ್ದರಿಂದ ಅವುಗಳನ್ನು ನಿರ್ಲಕ್ಷಿಸಿ ಮತ್ತು ಬದಲಾಗಿ ಶೂನ್ಯ-ಪ್ರಾರಂಭಿಸುವುದು ಸರಿಯಾಗಿದೆ.
//
// `Option<&mut T>` `Clone` ಅನ್ನು ಎಂದಿಗೂ ಕಾರ್ಯಗತಗೊಳಿಸುವುದಿಲ್ಲ, ಆದ್ದರಿಂದ `SpecFromElem` ನ ಇಂಪ್ಲ್ ಅಗತ್ಯವಿಲ್ಲ.
//
//

unsafe impl<T: ?Sized> IsZero for Option<&T> {
    #[inline]
    fn is_zero(&self) -> bool {
        self.is_none()
    }
}

unsafe impl<T: ?Sized> IsZero for Option<Box<T>> {
    #[inline]
    fn is_zero(&self) -> bool {
        self.is_none()
    }
}