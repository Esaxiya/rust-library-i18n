use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// ಮೂಲ ಹಂಚಿಕೆಯನ್ನು ಮರುಬಳಕೆ ಮಾಡುವಾಗ ಇಇರೇಟರ್ ಪೈಪ್‌ಲೈನ್ ಅನ್ನು ವೆಕ್‌ಗೆ ಸಂಗ್ರಹಿಸಲು ವಿಶೇಷ ಮಾರ್ಕರ್, ಅಂದರೆ
/// ಸ್ಥಳದಲ್ಲಿ ಪೈಪ್ಲೈನ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
///
/// ಮರುಬಳಕೆ ಮಾಡಬೇಕಾದ ಹಂಚಿಕೆಯನ್ನು ಪ್ರವೇಶಿಸಲು ವಿಶೇಷ ಕಾರ್ಯಕ್ಕಾಗಿ ಸೋರ್ಸ್‌ಇಟರ್ ಮೂಲ trait ಅವಶ್ಯಕವಾಗಿದೆ.
/// ಆದರೆ ವಿಶೇಷತೆಯು ಮಾನ್ಯವಾಗಲು ಇದು ಸಾಕಾಗುವುದಿಲ್ಲ.
/// Impl ನಲ್ಲಿ ಹೆಚ್ಚುವರಿ ಮಿತಿಗಳನ್ನು ನೋಡಿ.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-ಆಂತರಿಕ SourceIter/InPlaceIterable traits ಅನ್ನು ಅಡಾಪ್ಟರ್ ಸರಪಳಿಗಳಿಂದ ಮಾತ್ರ ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗುತ್ತದೆ <Adapter<Adapter<IntoIter>>> (ಎಲ್ಲವೂ core/std ಒಡೆತನದಲ್ಲಿದೆ).
// ಅಡಾಪ್ಟರ್ ಅನುಷ್ಠಾನಗಳ ಮೇಲಿನ ಹೆಚ್ಚುವರಿ ಮಿತಿಗಳು (`impl<I: Trait> Trait for Adapter<I>` ಮೀರಿ) ಈಗಾಗಲೇ ವಿಶೇಷ traits ಎಂದು ಗುರುತಿಸಲಾದ ಇತರ traits ಅನ್ನು ಮಾತ್ರ ಅವಲಂಬಿಸಿರುತ್ತದೆ (ನಕಲು, ವಿಶ್ವಾಸಾರ್ಹ ರಾಂಡಮ್ಆಕ್ಸೆಸ್, ಫ್ಯೂಸ್ಡ್ಇಟರೇಟರ್).
//
// I.e. ಮಾರ್ಕರ್ ಬಳಕೆದಾರ-ಸರಬರಾಜು ಪ್ರಕಾರಗಳ ಜೀವಿತಾವಧಿಯನ್ನು ಅವಲಂಬಿಸಿರುವುದಿಲ್ಲ.ಮಾಡ್ಯುಲೋ ಕಾಪಿ ಹೋಲ್, ಇದು ಹಲವಾರು ಇತರ ವಿಶೇಷತೆಗಳನ್ನು ಈಗಾಗಲೇ ಅವಲಂಬಿಸಿದೆ.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // trait bounds ಮೂಲಕ ವ್ಯಕ್ತಪಡಿಸಲಾಗದ ಹೆಚ್ಚುವರಿ ಅವಶ್ಯಕತೆಗಳು.ನಾವು ಬದಲಿಗೆ ಕಾನ್ಸ್ ಇವಾಲ್ ಅನ್ನು ಅವಲಂಬಿಸಿದ್ದೇವೆ:
        // ಎ) ಮರುಬಳಕೆ ಮತ್ತು ಪಾಯಿಂಟರ್ ಅಂಕಗಣಿತಕ್ಕೆ ಯಾವುದೇ ಹಂಚಿಕೆ ಇರುವುದಿಲ್ಲವಾದ್ದರಿಂದ ZST ಗಳು ಇಲ್ಲ panic b) ಅಲೋಕ್ ಒಪ್ಪಂದಕ್ಕೆ ಅಗತ್ಯವಿರುವಂತೆ ಗಾತ್ರ ಹೊಂದಾಣಿಕೆ c) ಅಲೋಕ್ ಒಪ್ಪಂದಕ್ಕೆ ಅಗತ್ಯವಿರುವಂತೆ ಜೋಡಣೆಗಳು ಹೊಂದಿಕೆಯಾಗುತ್ತವೆ
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // ಹೆಚ್ಚು ಸಾಮಾನ್ಯ ಅನುಷ್ಠಾನಗಳಿಗೆ ಹಿನ್ನಡೆ
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // ಅಂದಿನಿಂದ ಪ್ರಯತ್ನಿಸಿ-ಪಟ್ಟು ಬಳಸಿ
        // - ಇದು ಕೆಲವು ಪುನರಾವರ್ತಕ ಅಡಾಪ್ಟರುಗಳಿಗೆ ಉತ್ತಮ ವೆಕ್ಟರೈಜ್ ಮಾಡುತ್ತದೆ
        // - ಹೆಚ್ಚಿನ ಆಂತರಿಕ ಪುನರಾವರ್ತನೆ ವಿಧಾನಗಳಿಗಿಂತ ಭಿನ್ನವಾಗಿ, ಇದು ಕೇವಲ &mut ಸ್ವಯಂ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ
        // - ಇದು ರೈಟ್ ಪಾಯಿಂಟರ್ ಅನ್ನು ಅದರ ಒಳಭಾಗದಲ್ಲಿ ಥ್ರೆಡ್ ಮಾಡಲು ಮತ್ತು ಕೊನೆಯಲ್ಲಿ ಅದನ್ನು ಮರಳಿ ಪಡೆಯಲು ನಮಗೆ ಅನುಮತಿಸುತ್ತದೆ
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // ಪುನರಾವರ್ತನೆ ಯಶಸ್ವಿಯಾಗಿದೆ, ತಲೆ ಬಿಡಬೇಡಿ
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // ಸೋರ್ಸ್‌ಇಟರ್ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಲಾಗಿದೆಯೆ ಎಂದು ಪರಿಶೀಲಿಸಿ: ಅವುಗಳು ಇಲ್ಲದಿದ್ದರೆ ನಾವು ಅದನ್ನು ಈ ಹಂತಕ್ಕೆ ತಲುಪಿಸದಿರಬಹುದು
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // InPlaceIterable ಒಪ್ಪಂದವನ್ನು ಪರಿಶೀಲಿಸಿ.ಪುನರಾವರ್ತಕವು ಮೂಲ ಪಾಯಿಂಟರ್ ಅನ್ನು ಸುಧಾರಿಸಿದರೆ ಮಾತ್ರ ಇದು ಸಾಧ್ಯ.
        // ಇದು ಟ್ರಸ್ಟೆಡ್ ರಾಂಡಮ್ ಆಕ್ಸೆಸ್ ಮೂಲಕ ಪರಿಶೀಲಿಸದ ಪ್ರವೇಶವನ್ನು ಬಳಸಿದರೆ ಮೂಲ ಪಾಯಿಂಟರ್ ಅದರ ಆರಂಭಿಕ ಸ್ಥಾನದಲ್ಲಿ ಉಳಿಯುತ್ತದೆ ಮತ್ತು ನಾವು ಅದನ್ನು ಉಲ್ಲೇಖವಾಗಿ ಬಳಸಲಾಗುವುದಿಲ್ಲ
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // ಉಳಿದಿರುವ ಯಾವುದೇ ಮೌಲ್ಯಗಳನ್ನು ಮೂಲದ ಬಾಲದಲ್ಲಿ ಬಿಡಿ ಆದರೆ panics ಡ್ರಾಪ್ ಮಾಡಿದರೆ IntoIter ವ್ಯಾಪ್ತಿಯಿಂದ ಹೊರಗುಳಿದ ನಂತರ ಹಂಚಿಕೆಯ ಡ್ರಾಪ್ ಅನ್ನು ತಡೆಯಿರಿ, ನಂತರ ನಾವು ಸಂಗ್ರಹಿಸಿದ ಯಾವುದೇ ಅಂಶಗಳನ್ನು dst_buf ಗೆ ಸೋರಿಕೆ ಮಾಡುತ್ತೇವೆ
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // ಟ್ರೈ_ಫೋಲ್ಡ್ ಮೂಲ ಪಾಯಿಂಟರ್‌ಗೆ ವಿಶೇಷ ಉಲ್ಲೇಖವನ್ನು ಹೊಂದಿರುವುದರಿಂದ ಇನ್‌ಪ್ಲೇಸ್‌ಇಟೆರಬಲ್ ಒಪ್ಪಂದವನ್ನು ಇಲ್ಲಿ ನಿಖರವಾಗಿ ಪರಿಶೀಲಿಸಲಾಗುವುದಿಲ್ಲ, ಅದು ಇನ್ನೂ ವ್ಯಾಪ್ತಿಯಲ್ಲಿದೆಯೇ ಎಂದು ನಾವು ಪರಿಶೀಲಿಸಬಹುದು
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}