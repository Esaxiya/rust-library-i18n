use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// ಅತಿಕ್ರಮಿಸುವ ವಿಶೇಷತೆಗಳಿಗೆ ಹಸ್ತಚಾಲಿತವಾಗಿ ಆದ್ಯತೆ ನೀಡಲು ಅಗತ್ಯವಿರುವ Vec::from_iter ಗಾಗಿ ಮತ್ತೊಂದು ವಿಶೇಷತೆ trait ವಿವರಗಳಿಗಾಗಿ [`SpecFromIter`](super::SpecFromIter) ನೋಡಿ.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // ಮೊದಲ ಪುನರಾವರ್ತನೆಯನ್ನು ಅನ್ರೋಲ್ ಮಾಡಿ, ಏಕೆಂದರೆ ಪುನರಾವರ್ತನೆಯ ಖಾಲಿ ಇಲ್ಲದಿದ್ದಾಗ ಪ್ರತಿಯೊಂದು ಸಂದರ್ಭದಲ್ಲೂ vector ವಿಸ್ತರಿಸಲಿದೆ, ಆದರೆ extend_desugared() ನಲ್ಲಿನ ಲೂಪ್ ಕೆಲವು ನಂತರದ ಲೂಪ್ ಪುನರಾವರ್ತನೆಗಳಲ್ಲಿ vector ಪೂರ್ಣವಾಗಿರುವುದನ್ನು ನೋಡಲು ಹೋಗುವುದಿಲ್ಲ.
        //
        // ಆದ್ದರಿಂದ ನಾವು ಉತ್ತಮ branch ಮುನ್ಸೂಚನೆಯನ್ನು ಪಡೆಯುತ್ತೇವೆ.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // extend() ಖಾಲಿ Vecs ಗಾಗಿ spec_from ಗೆ ಪ್ರತಿನಿಧಿಸುವುದರಿಂದ spec_extend() ಗೆ ಪ್ರತಿನಿಧಿಸಬೇಕು
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // extend() ಖಾಲಿ Vecs ಗಾಗಿ spec_from ಗೆ ಪ್ರತಿನಿಧಿಸುವುದರಿಂದ spec_extend() ಗೆ ಪ್ರತಿನಿಧಿಸಬೇಕು
        //
        vector.spec_extend(iterator);
        vector
    }
}