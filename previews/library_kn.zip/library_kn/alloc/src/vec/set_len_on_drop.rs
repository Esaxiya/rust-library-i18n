// `SetLenOnDrop` ಮೌಲ್ಯವು ವ್ಯಾಪ್ತಿಯಿಂದ ಹೊರಬಂದಾಗ ವೆಕ್ನ ಉದ್ದವನ್ನು ಹೊಂದಿಸಿ.
//
// ಕಲ್ಪನೆ ಹೀಗಿದೆ: ಸೆಟ್‌ಲೆನ್‌ಆನ್‌ಡ್ರಾಪ್‌ನಲ್ಲಿನ ಉದ್ದದ ಕ್ಷೇತ್ರವು ಸ್ಥಳೀಯ ವೇರಿಯೇಬಲ್ ಆಗಿದ್ದು, ಆಪ್ಟಿಮೈಜರ್ ನೋಡುವಂತಹವು ವೆಕ್‌ನ ಡೇಟಾ ಪಾಯಿಂಟರ್ ಮೂಲಕ ಯಾವುದೇ ಅಂಗಡಿಗಳೊಂದಿಗೆ ಅಲಿಯಾಸ್ ಆಗುವುದಿಲ್ಲ.
// ಅಲಿಯಾಸ್ ಅನಾಲಿಸಿಸ್ ಸಂಚಿಕೆ #32155 ಗೆ ಇದು ಒಂದು ಪರಿಹಾರವಾಗಿದೆ
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}