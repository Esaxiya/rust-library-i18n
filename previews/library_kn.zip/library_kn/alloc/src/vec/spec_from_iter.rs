use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// ವಿಶೇಷತೆ trait ಅನ್ನು Vec::from_iter ಗಾಗಿ ಬಳಸಲಾಗುತ್ತದೆ
///
/// ## ನಿಯೋಗದ ಗ್ರಾಫ್:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // ಒಂದು ಸಾಮಾನ್ಯ ಪ್ರಕರಣವೆಂದರೆ vector ಅನ್ನು ಒಂದು ಕಾರ್ಯಕ್ಕೆ ಹಾದುಹೋಗುತ್ತದೆ, ಅದು ತಕ್ಷಣವೇ vector ಗೆ ಮರು-ಸಂಗ್ರಹಿಸುತ್ತದೆ.
        // ಇಂಟೈಟರ್ ಅನ್ನು ಮುಂದುವರೆಸದಿದ್ದರೆ ನಾವು ಇದನ್ನು ಶಾರ್ಟ್ ಸರ್ಕ್ಯೂಟ್ ಮಾಡಬಹುದು.
        // ಇದು ಮುಂದುವರಿದಾಗ ನಾವು ಮೆಮೊರಿಯನ್ನು ಮರುಬಳಕೆ ಮಾಡಬಹುದು ಮತ್ತು ಡೇಟಾವನ್ನು ಮುಂಭಾಗಕ್ಕೆ ಸರಿಸಬಹುದು.
        // ಆದರೆ ಫ್ರಮ್ಇಟೆರೇಟರ್ ಅನುಷ್ಠಾನದ ಮೂಲಕ ಅದನ್ನು ರಚಿಸುವುದಕ್ಕಿಂತ ಹೆಚ್ಚು ಬಳಕೆಯಾಗದ ಸಾಮರ್ಥ್ಯವನ್ನು ವೆಕ್ ಹೊಂದಿರದಿದ್ದಾಗ ಮಾತ್ರ ನಾವು ಹಾಗೆ ಮಾಡುತ್ತೇವೆ.
        //
        // ವೆಕ್ನ ಹಂಚಿಕೆ ನಡವಳಿಕೆಯು ಉದ್ದೇಶಪೂರ್ವಕವಾಗಿ ಅನಿರ್ದಿಷ್ಟವಾಗಿರುವುದರಿಂದ ಆ ಮಿತಿ ಕಟ್ಟುನಿಟ್ಟಾಗಿ ಅಗತ್ಯವಿಲ್ಲ.
        // ಆದರೆ ಇದು ಸಂಪ್ರದಾಯವಾದಿ ಆಯ್ಕೆಯಾಗಿದೆ.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // extend() ಖಾಲಿ Vecs ಗಾಗಿ spec_from ಗೆ ಪ್ರತಿನಿಧಿಸುವುದರಿಂದ spec_extend() ಗೆ ಪ್ರತಿನಿಧಿಸಬೇಕು
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// ಇದು `iterator.as_slice().to_vec()` ಅನ್ನು ಬಳಸುತ್ತದೆ ಏಕೆಂದರೆ ಸ್ಪೆಕ್_ಎಕ್ಸ್ಟೆಂಡ್ ಅಂತಿಮ ಸಾಮರ್ಥ್ಯ + ಉದ್ದದ ಬಗ್ಗೆ ತಾರ್ಕಿಕವಾಗಿ ಹೆಚ್ಚಿನ ಕ್ರಮಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳಬೇಕು ಮತ್ತು ಆದ್ದರಿಂದ ಹೆಚ್ಚಿನ ಕೆಲಸಗಳನ್ನು ಮಾಡುತ್ತದೆ.
// `to_vec()` ನೇರವಾಗಿ ಸರಿಯಾದ ಮೊತ್ತವನ್ನು ನಿಗದಿಪಡಿಸುತ್ತದೆ ಮತ್ತು ಅದನ್ನು ನಿಖರವಾಗಿ ತುಂಬುತ್ತದೆ.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cfg(test) ನೊಂದಿಗೆ ಈ ವಿಧಾನದ ವ್ಯಾಖ್ಯಾನಕ್ಕೆ ಅಗತ್ಯವಿರುವ ಅಂತರ್ಗತ `[T]::to_vec` ವಿಧಾನವು ಲಭ್ಯವಿಲ್ಲ.
    // ಬದಲಾಗಿ cfg(test) NB ಯೊಂದಿಗೆ ಮಾತ್ರ ಲಭ್ಯವಿರುವ `slice::to_vec` ಕಾರ್ಯವನ್ನು ಬಳಸಿ ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ slice.rs ನಲ್ಲಿ slice::hack ಮಾಡ್ಯೂಲ್ ನೋಡಿ
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}