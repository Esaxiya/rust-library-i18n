use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::{Drain, Vec};

/// `Vec` ಗಾಗಿ ವಿಭಜಿಸುವ ಪುನರಾವರ್ತಕ.
///
/// ಈ ರಚನೆಯನ್ನು [`Vec::splice()`] ನಿಂದ ರಚಿಸಲಾಗಿದೆ.
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
///
/// # Example
///
/// ```
/// let mut v = vec![0, 1, 2];
/// let new = [7, 8];
/// let iter: std::vec::Splice<_> = v.splice(1.., new.iter().cloned());
/// ```
#[derive(Debug)]
#[stable(feature = "vec_splice", since = "1.21.0")]
pub struct Splice<
    'a,
    I: Iterator + 'a,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator + 'a = Global,
> {
    pub(super) drain: Drain<'a, I::Item, A>,
    pub(super) replace_with: I,
}

#[stable(feature = "vec_splice", since = "1.21.0")]
impl<I: Iterator, A: Allocator> Iterator for Splice<'_, I, A> {
    type Item = I::Item;

    fn next(&mut self) -> Option<Self::Item> {
        self.drain.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.drain.size_hint()
    }
}

#[stable(feature = "vec_splice", since = "1.21.0")]
impl<I: Iterator, A: Allocator> DoubleEndedIterator for Splice<'_, I, A> {
    fn next_back(&mut self) -> Option<Self::Item> {
        self.drain.next_back()
    }
}

#[stable(feature = "vec_splice", since = "1.21.0")]
impl<I: Iterator, A: Allocator> ExactSizeIterator for Splice<'_, I, A> {}

#[stable(feature = "vec_splice", since = "1.21.0")]
impl<I: Iterator, A: Allocator> Drop for Splice<'_, I, A> {
    fn drop(&mut self) {
        self.drain.by_ref().for_each(drop);

        unsafe {
            if self.drain.tail_len == 0 {
                self.drain.vec.as_mut().extend(self.replace_with.by_ref());
                return;
            }

            // ಮೊದಲು drain() ನಿಂದ ಉಳಿದಿರುವ ಶ್ರೇಣಿಯನ್ನು ಭರ್ತಿ ಮಾಡಿ.
            if !self.drain.fill(&mut self.replace_with) {
                return;
            }

            // ಹೆಚ್ಚಿನ ಅಂಶಗಳು ಇರಬಹುದು.ಕಡಿಮೆ ಬೌಂಡ್ ಅನ್ನು ಅಂದಾಜಿನಂತೆ ಬಳಸಿ.
            // FIXME: ಮೇಲ್ಭಾಗವು ಉತ್ತಮ ess ಹೆ?ಅಥವ ಇನ್ನೇನಾದರು?
            let (lower_bound, _upper_bound) = self.replace_with.size_hint();
            if lower_bound > 0 {
                self.drain.move_tail(lower_bound);
                if !self.drain.fill(&mut self.replace_with) {
                    return;
                }
            }

            // ಉಳಿದಿರುವ ಯಾವುದೇ ಅಂಶಗಳನ್ನು ಸಂಗ್ರಹಿಸಿ.
            // ಇದು ಶೂನ್ಯ-ಉದ್ದದ vector ಆಗಿದ್ದು, ಇದು `lower_bound` ನಿಖರವಾಗಿದ್ದರೆ ಹಂಚುವುದಿಲ್ಲ.
            let mut collected = self.replace_with.by_ref().collect::<Vec<I::Item>>().into_iter();
            // ಈಗ ನಮಗೆ ನಿಖರವಾದ ಎಣಿಕೆ ಇದೆ.
            if collected.len() > 0 {
                self.drain.move_tail(collected.len());
                let filled = self.drain.fill(&mut collected);
                debug_assert!(filled);
                debug_assert_eq!(collected.len(), 0);
            }
        }
        // ಅಗತ್ಯವಿದ್ದರೆ `Drain::drop` ಬಾಲವನ್ನು ಹಿಂದಕ್ಕೆ ಸರಿಸಲು ಮತ್ತು `vec.len` ಅನ್ನು ಮರುಸ್ಥಾಪಿಸಲು ಬಿಡಿ.
    }
}

/// `Splice::drop` ಗಾಗಿ ಖಾಸಗಿ ಸಹಾಯಕ ವಿಧಾನಗಳು
impl<T, A: Allocator> Drain<'_, T, A> {
    /// `self.vec.len` ನಿಂದ `self.tail_start` ವರೆಗಿನ ವ್ಯಾಪ್ತಿಯು ಹೊರಹೋಗಿರುವ ಅಂಶಗಳನ್ನು ಒಳಗೊಂಡಿದೆ.
    ///
    /// `replace_with` ಪುನರಾವರ್ತಕದಿಂದ ಹೊಸ ಅಂಶಗಳೊಂದಿಗೆ ಆ ಶ್ರೇಣಿಯನ್ನು ಸಾಧ್ಯವಾದಷ್ಟು ಭರ್ತಿ ಮಾಡಿ.
    /// ನಾವು ಸಂಪೂರ್ಣ ಶ್ರೇಣಿಯನ್ನು ಭರ್ತಿ ಮಾಡಿದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ. (`replace_with.next()` didn’t return `None`.)
    unsafe fn fill<I: Iterator<Item = T>>(&mut self, replace_with: &mut I) -> bool {
        let vec = unsafe { self.vec.as_mut() };
        let range_start = vec.len;
        let range_end = self.tail_start;
        let range_slice = unsafe {
            slice::from_raw_parts_mut(vec.as_mut_ptr().add(range_start), range_end - range_start)
        };

        for place in range_slice {
            if let Some(new_item) = replace_with.next() {
                unsafe { ptr::write(place, new_item) };
                vec.len += 1;
            } else {
                return false;
            }
        }
        true
    }

    /// ಬಾಲದ ಮೊದಲು ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ಸೇರಿಸಲು ಸ್ಥಳಾವಕಾಶ ನೀಡುತ್ತದೆ.
    unsafe fn move_tail(&mut self, additional: usize) {
        let vec = unsafe { self.vec.as_mut() };
        let len = self.tail_start + self.tail_len;
        vec.buf.reserve(len, additional);

        let new_tail_start = self.tail_start + additional;
        unsafe {
            let src = vec.as_ptr().add(self.tail_start);
            let dst = vec.as_mut_ptr().add(new_tail_start);
            ptr::copy(src, dst, self.tail_len);
        }
        self.tail_start = new_tail_start;
    }
}