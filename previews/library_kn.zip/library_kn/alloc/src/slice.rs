//! ಒಂದು ಅನುಕ್ರಮ ಅನುಕ್ರಮಕ್ಕೆ ಕ್ರಿಯಾತ್ಮಕವಾಗಿ ಗಾತ್ರದ ನೋಟ, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! ಚೂರುಗಳು ಪಾಯಿಂಟರ್ ಮತ್ತು ಉದ್ದವಾಗಿ ಪ್ರತಿನಿಧಿಸುವ ಮೆಮೊರಿಯ ಬ್ಲಾಕ್‌ಗೆ ಒಂದು ನೋಟವಾಗಿದೆ.
//!
//! ```
//! // Vec ಅನ್ನು ಕತ್ತರಿಸುವುದು
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // ಸ್ಲೈಸ್‌ಗೆ ಒಂದು ಶ್ರೇಣಿಯನ್ನು ಒತ್ತಾಯಿಸುವುದು
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! ಚೂರುಗಳು ರೂಪಾಂತರ ಅಥವಾ ಹಂಚಿಕೆಯಾಗಿವೆ.
//! ಹಂಚಿದ ಸ್ಲೈಸ್ ಪ್ರಕಾರವು `&[T]` ಆಗಿದ್ದರೆ, ರೂಪಾಂತರಿತ ಸ್ಲೈಸ್ ಪ್ರಕಾರವು `&mut [T]` ಆಗಿದೆ, ಅಲ್ಲಿ `T` ಅಂಶ ಪ್ರಕಾರವನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
//! ಉದಾಹರಣೆಗೆ, ರೂಪಾಂತರಿತ ಸ್ಲೈಸ್ ಸೂಚಿಸುವ ಮೆಮೊರಿಯ ಬ್ಲಾಕ್ ಅನ್ನು ನೀವು ರೂಪಾಂತರಿಸಬಹುದು:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! ಈ ಮಾಡ್ಯೂಲ್ ಒಳಗೊಂಡಿರುವ ಕೆಲವು ವಿಷಯಗಳು ಇಲ್ಲಿವೆ:
//!
//! ## Structs
//!
//! ಚೂರುಗಳಿಗೆ ಉಪಯುಕ್ತವಾದ ಹಲವಾರು ರಚನೆಗಳು ಇವೆ, ಉದಾಹರಣೆಗೆ [`Iter`], ಇದು ಸ್ಲೈಸ್‌ನ ಮೇಲೆ ಪುನರಾವರ್ತನೆಯನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
//!
//! ## Trait ಅನುಷ್ಠಾನಗಳು
//!
//! ಚೂರುಗಳಿಗಾಗಿ ಸಾಮಾನ್ಯ traits ನ ಹಲವಾರು ಅನುಷ್ಠಾನಗಳಿವೆ.ಕೆಲವು ಉದಾಹರಣೆಗಳಲ್ಲಿ ಇವು ಸೇರಿವೆ:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], ಚೂರುಗಳಿಗೆ ಅದರ ಅಂಶ ಪ್ರಕಾರ [`Eq`] ಅಥವಾ [`Ord`].
//! * [`Hash`] - ಅಂಶ ಪ್ರಕಾರ [`Hash`] ಚೂರುಗಳಿಗಾಗಿ.
//!
//! ## Iteration
//!
//! ಚೂರುಗಳು `IntoIterator` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತವೆ.ಪುನರಾವರ್ತಕವು ಸ್ಲೈಸ್ ಅಂಶಗಳಿಗೆ ಉಲ್ಲೇಖಗಳನ್ನು ನೀಡುತ್ತದೆ.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! ರೂಪಾಂತರಿತ ಸ್ಲೈಸ್ ಅಂಶಗಳಿಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳನ್ನು ನೀಡುತ್ತದೆ:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! ಈ ಪುನರಾವರ್ತಕವು ಸ್ಲೈಸ್‌ನ ಅಂಶಗಳಿಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳನ್ನು ನೀಡುತ್ತದೆ, ಆದ್ದರಿಂದ ಸ್ಲೈಸ್‌ನ ಅಂಶ ಪ್ರಕಾರವು `i32` ಆಗಿದ್ದರೆ, ಪುನರಾವರ್ತಕದ ಅಂಶ ಪ್ರಕಾರವು `&mut i32` ಆಗಿದೆ.
//!
//!
//! * [`.iter`] ಮತ್ತು [`.iter_mut`] ಡೀಫಾಲ್ಟ್ ಪುನರಾವರ್ತಕಗಳನ್ನು ಹಿಂದಿರುಗಿಸುವ ಸ್ಪಷ್ಟ ವಿಧಾನಗಳಾಗಿವೆ.
//! * ಪುನರಾವರ್ತಕಗಳನ್ನು ಹಿಂದಿರುಗಿಸುವ ಹೆಚ್ಚಿನ ವಿಧಾನಗಳು [`.split`], [`.splitn`], [`.chunks`], [`.windows`] ಮತ್ತು ಹೆಚ್ಚಿನವು.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// ಈ ಮಾಡ್ಯೂಲ್‌ನಲ್ಲಿನ ಅನೇಕ ಬಳಕೆಗಳನ್ನು ಪರೀಕ್ಷಾ ಸಂರಚನೆಯಲ್ಲಿ ಮಾತ್ರ ಬಳಸಲಾಗುತ್ತದೆ.
// ಅವುಗಳನ್ನು ಸರಿಪಡಿಸುವುದಕ್ಕಿಂತ ಬಳಕೆಯಾಗದ_ ಆಮದುಗಳ ಎಚ್ಚರಿಕೆಯನ್ನು ಆಫ್ ಮಾಡುವುದು ಸ್ವಚ್ er ವಾಗಿದೆ.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// ಮೂಲ ಸ್ಲೈಸ್ ವಿಸ್ತರಣೆ ವಿಧಾನಗಳು
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) ಎನ್ಬಿ ಪರೀಕ್ಷಿಸುವಾಗ `vec!` ಮ್ಯಾಕ್ರೋ ಅನುಷ್ಠಾನಕ್ಕೆ ಅಗತ್ಯವಿದೆ, ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ ಈ ಫೈಲ್‌ನಲ್ಲಿನ `hack` ಮಾಡ್ಯೂಲ್ ನೋಡಿ.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) NB ಪರೀಕ್ಷಿಸುವಾಗ `Vec::clone` ಅನುಷ್ಠಾನಕ್ಕೆ ಅಗತ್ಯವಿದೆ, ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ ಈ ಫೈಲ್‌ನಲ್ಲಿ `hack` ಮಾಡ್ಯೂಲ್ ನೋಡಿ.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): cfg(test) `impl [T]` ಲಭ್ಯವಿಲ್ಲದ ಕಾರಣ, ಈ ಮೂರು ಕಾರ್ಯಗಳು ವಾಸ್ತವವಾಗಿ `impl [T]` ನಲ್ಲಿರುವ ವಿಧಾನಗಳು ಆದರೆ `core::slice::SliceExt` ನಲ್ಲಿಲ್ಲ, ನಾವು `test_permutations` ಪರೀಕ್ಷೆಗೆ ಈ ಕಾರ್ಯಗಳನ್ನು ಪೂರೈಸಬೇಕಾಗಿದೆ
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // ನಾವು ಇದನ್ನು ಇನ್ಲೈನ್ ಗುಣಲಕ್ಷಣವನ್ನು ಸೇರಿಸಬಾರದು ಏಕೆಂದರೆ ಇದನ್ನು ಹೆಚ್ಚಾಗಿ `vec!` ಮ್ಯಾಕ್ರೋದಲ್ಲಿ ಬಳಸಲಾಗುತ್ತದೆ ಮತ್ತು ಪರಿಪೂರ್ಣ ಹಿಂಜರಿಕೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
    // ಚರ್ಚೆ ಮತ್ತು ಪರಿಪೂರ್ಣ ಫಲಿತಾಂಶಗಳಿಗಾಗಿ #71204 ನೋಡಿ.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // ಕೆಳಗಿನ ಲೂಪ್‌ನಲ್ಲಿ ವಸ್ತುಗಳನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ ಎಂದು ಗುರುತಿಸಲಾಗಿದೆ
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) ಬೌಂಡ್ಸ್ ಚೆಕ್ ಅನ್ನು ತೆಗೆದುಹಾಕಲು ಎಲ್ಎಲ್ವಿಎಂಗೆ ಅವಶ್ಯಕವಾಗಿದೆ ಮತ್ತು ಜಿಪ್ಗಿಂತ ಉತ್ತಮವಾದ ಕೋಡೆಜೆನ್ ಹೊಂದಿದೆ.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // ವೆಕ್ ಅನ್ನು ಈ ಉದ್ದಕ್ಕೆ ನಿಗದಿಪಡಿಸಲಾಗಿದೆ ಮತ್ತು ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // `s` ಸಾಮರ್ಥ್ಯದೊಂದಿಗೆ ಮೇಲೆ ಹಂಚಿಕೆ ಮಾಡಲಾಗಿದೆ, ಮತ್ತು ಕೆಳಗಿನ ptr::copy_to_non_overlapping ನಲ್ಲಿ `s.len()` ಗೆ ಪ್ರಾರಂಭಿಸಿ.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// ಸ್ಲೈಸ್ ಅನ್ನು ವಿಂಗಡಿಸುತ್ತದೆ.
    ///
    /// ಈ ರೀತಿಯು ಸ್ಥಿರವಾಗಿರುತ್ತದೆ (ಅಂದರೆ, ಸಮಾನ ಅಂಶಗಳನ್ನು ಮರುಕ್ರಮಗೊಳಿಸುವುದಿಲ್ಲ) ಮತ್ತು *O*(*n*\*log(* n*)) ಕೆಟ್ಟ ಪ್ರಕರಣ.
    ///
    /// ಅನ್ವಯಿಸಿದಾಗ, ಅಸ್ಥಿರ ವಿಂಗಡಣೆಗೆ ಆದ್ಯತೆ ನೀಡಲಾಗುತ್ತದೆ ಏಕೆಂದರೆ ಇದು ಸಾಮಾನ್ಯವಾಗಿ ಸ್ಥಿರ ವಿಂಗಡಣೆಗಿಂತ ವೇಗವಾಗಿರುತ್ತದೆ ಮತ್ತು ಇದು ಸಹಾಯಕ ಮೆಮೊರಿಯನ್ನು ನಿಯೋಜಿಸುವುದಿಲ್ಲ.
    /// [`sort_unstable`](slice::sort_unstable) ನೋಡಿ.
    ///
    /// # ಪ್ರಸ್ತುತ ಅನುಷ್ಠಾನ
    ///
    /// ಪ್ರಸ್ತುತ ಅಲ್ಗಾರಿದಮ್ [timsort](https://en.wikipedia.org/wiki/Timsort) ನಿಂದ ಸ್ಫೂರ್ತಿ ಪಡೆದ ಹೊಂದಾಣಿಕೆಯ, ಪುನರಾವರ್ತನೆಯ ವಿಲೀನ ವಿಧವಾಗಿದೆ.
    /// ಸ್ಲೈಸ್ ಸುಮಾರು ವಿಂಗಡಿಸಲಾದ ಅಥವಾ ಎರಡು ಅಥವಾ ಹೆಚ್ಚಿನ ವಿಂಗಡಿಸಲಾದ ಅನುಕ್ರಮಗಳನ್ನು ಒಂದರ ನಂತರ ಒಂದರಂತೆ ಜೋಡಿಸುವ ಸಂದರ್ಭಗಳಲ್ಲಿ ಇದನ್ನು ಅತ್ಯಂತ ವೇಗವಾಗಿ ವಿನ್ಯಾಸಗೊಳಿಸಲಾಗಿದೆ.
    ///
    ///
    /// ಅಲ್ಲದೆ, ಇದು `self` ನ ಅರ್ಧದಷ್ಟು ಗಾತ್ರದ ತಾತ್ಕಾಲಿಕ ಸಂಗ್ರಹಣೆಯನ್ನು ನಿಯೋಜಿಸುತ್ತದೆ, ಆದರೆ ಸಣ್ಣ ಚೂರುಗಳಿಗೆ ಬದಲಾಗಿ ಹಂಚಿಕೆಯಾಗದ ಅಳವಡಿಕೆ ವಿಂಗಡಣೆಯನ್ನು ಬಳಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// ತುಂಡು ತುಲನಾತ್ಮಕ ಕ್ರಿಯೆಯೊಂದಿಗೆ ವಿಂಗಡಿಸುತ್ತದೆ.
    ///
    /// ಈ ರೀತಿಯು ಸ್ಥಿರವಾಗಿರುತ್ತದೆ (ಅಂದರೆ, ಸಮಾನ ಅಂಶಗಳನ್ನು ಮರುಕ್ರಮಗೊಳಿಸುವುದಿಲ್ಲ) ಮತ್ತು *O*(*n*\*log(* n*)) ಕೆಟ್ಟ ಪ್ರಕರಣ.
    ///
    /// ತುಲನಾತ್ಮಕ ಕಾರ್ಯವು ಸ್ಲೈಸ್‌ನಲ್ಲಿರುವ ಅಂಶಗಳಿಗೆ ಒಟ್ಟು ಆದೇಶವನ್ನು ವ್ಯಾಖ್ಯಾನಿಸಬೇಕು.ಆದೇಶವು ಒಟ್ಟು ಇಲ್ಲದಿದ್ದರೆ, ಅಂಶಗಳ ಕ್ರಮವನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿಲ್ಲ.
    /// ಆದೇಶವು ಒಟ್ಟು ಆದೇಶವಾಗಿದ್ದರೆ (ಎಲ್ಲಾ `a`, `b` ಮತ್ತು `c` ಗೆ):
    ///
    /// * ಒಟ್ಟು ಮತ್ತು ಆಂಟಿಸ್ಮಿಮೆಟ್ರಿಕ್: ನಿಖರವಾಗಿ `a < b`, `a == b` ಅಥವಾ `a > b` ನಲ್ಲಿ ಒಂದು ನಿಜ, ಮತ್ತು
    /// * ಅಸ್ಥಿರ, `a < b` ಮತ್ತು `b < c` `a < c` ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ.`==` ಮತ್ತು `>` ಎರಡಕ್ಕೂ ಅದೇ ಹಿಡಿದಿರಬೇಕು.
    ///
    /// ಉದಾಹರಣೆಗೆ, [`f64`] [`Ord`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸದ ಕಾರಣ `NaN != NaN`, ಸ್ಲೈಸ್ `NaN` ಅನ್ನು ಹೊಂದಿಲ್ಲ ಎಂದು ನಮಗೆ ತಿಳಿದಾಗ ನಾವು `partial_cmp` ಅನ್ನು ನಮ್ಮ ರೀತಿಯ ಕಾರ್ಯವಾಗಿ ಬಳಸಬಹುದು.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// ಅನ್ವಯಿಸಿದಾಗ, ಅಸ್ಥಿರ ವಿಂಗಡಣೆಗೆ ಆದ್ಯತೆ ನೀಡಲಾಗುತ್ತದೆ ಏಕೆಂದರೆ ಇದು ಸಾಮಾನ್ಯವಾಗಿ ಸ್ಥಿರ ವಿಂಗಡಣೆಗಿಂತ ವೇಗವಾಗಿರುತ್ತದೆ ಮತ್ತು ಇದು ಸಹಾಯಕ ಮೆಮೊರಿಯನ್ನು ನಿಯೋಜಿಸುವುದಿಲ್ಲ.
    /// [`sort_unstable_by`](slice::sort_unstable_by) ನೋಡಿ.
    ///
    /// # ಪ್ರಸ್ತುತ ಅನುಷ್ಠಾನ
    ///
    /// ಪ್ರಸ್ತುತ ಅಲ್ಗಾರಿದಮ್ [timsort](https://en.wikipedia.org/wiki/Timsort) ನಿಂದ ಸ್ಫೂರ್ತಿ ಪಡೆದ ಹೊಂದಾಣಿಕೆಯ, ಪುನರಾವರ್ತನೆಯ ವಿಲೀನ ವಿಧವಾಗಿದೆ.
    /// ಸ್ಲೈಸ್ ಸುಮಾರು ವಿಂಗಡಿಸಲಾದ ಅಥವಾ ಎರಡು ಅಥವಾ ಹೆಚ್ಚಿನ ವಿಂಗಡಿಸಲಾದ ಅನುಕ್ರಮಗಳನ್ನು ಒಂದರ ನಂತರ ಒಂದರಂತೆ ಜೋಡಿಸುವ ಸಂದರ್ಭಗಳಲ್ಲಿ ಇದನ್ನು ಅತ್ಯಂತ ವೇಗವಾಗಿ ವಿನ್ಯಾಸಗೊಳಿಸಲಾಗಿದೆ.
    ///
    /// ಅಲ್ಲದೆ, ಇದು `self` ನ ಅರ್ಧದಷ್ಟು ಗಾತ್ರದ ತಾತ್ಕಾಲಿಕ ಸಂಗ್ರಹಣೆಯನ್ನು ನಿಯೋಜಿಸುತ್ತದೆ, ಆದರೆ ಸಣ್ಣ ಚೂರುಗಳಿಗೆ ಬದಲಾಗಿ ಹಂಚಿಕೆಯಾಗದ ಅಳವಡಿಕೆ ವಿಂಗಡಣೆಯನ್ನು ಬಳಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // ರಿವರ್ಸ್ ವಿಂಗಡಣೆ
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// ಕೀ ಹೊರತೆಗೆಯುವ ಕಾರ್ಯದೊಂದಿಗೆ ಸ್ಲೈಸ್ ಅನ್ನು ವಿಂಗಡಿಸುತ್ತದೆ.
    ///
    /// ಈ ರೀತಿಯು ಸ್ಥಿರವಾಗಿರುತ್ತದೆ (ಅಂದರೆ, ಸಮಾನ ಅಂಶಗಳನ್ನು ಮರುಕ್ರಮಗೊಳಿಸುವುದಿಲ್ಲ) ಮತ್ತು *O*(*m*\* * n *\* log(*n*)) ಕೆಟ್ಟ ಪ್ರಕರಣ, ಅಲ್ಲಿ ಪ್ರಮುಖ ಕಾರ್ಯ *O*(*m*).
    ///
    /// ದುಬಾರಿ ಪ್ರಮುಖ ಕಾರ್ಯಗಳಿಗಾಗಿ (ಉದಾ
    /// ಸರಳ ಆಸ್ತಿ ಪ್ರವೇಶಗಳು ಅಥವಾ ಮೂಲ ಕಾರ್ಯಾಚರಣೆಗಳಲ್ಲದ ಕಾರ್ಯಗಳು), [`sort_by_cached_key`](slice::sort_by_cached_key) ಗಮನಾರ್ಹವಾಗಿ ವೇಗವಾಗಿರಬಹುದು, ಏಕೆಂದರೆ ಇದು ಅಂಶ ಕೀಗಳನ್ನು ಮರುಸಂಪರ್ಕಿಸುವುದಿಲ್ಲ.
    ///
    ///
    /// ಅನ್ವಯಿಸಿದಾಗ, ಅಸ್ಥಿರ ವಿಂಗಡಣೆಗೆ ಆದ್ಯತೆ ನೀಡಲಾಗುತ್ತದೆ ಏಕೆಂದರೆ ಇದು ಸಾಮಾನ್ಯವಾಗಿ ಸ್ಥಿರ ವಿಂಗಡಣೆಗಿಂತ ವೇಗವಾಗಿರುತ್ತದೆ ಮತ್ತು ಇದು ಸಹಾಯಕ ಮೆಮೊರಿಯನ್ನು ನಿಯೋಜಿಸುವುದಿಲ್ಲ.
    /// [`sort_unstable_by_key`](slice::sort_unstable_by_key) ನೋಡಿ.
    ///
    /// # ಪ್ರಸ್ತುತ ಅನುಷ್ಠಾನ
    ///
    /// ಪ್ರಸ್ತುತ ಅಲ್ಗಾರಿದಮ್ [timsort](https://en.wikipedia.org/wiki/Timsort) ನಿಂದ ಸ್ಫೂರ್ತಿ ಪಡೆದ ಹೊಂದಾಣಿಕೆಯ, ಪುನರಾವರ್ತನೆಯ ವಿಲೀನ ವಿಧವಾಗಿದೆ.
    /// ಸ್ಲೈಸ್ ಸುಮಾರು ವಿಂಗಡಿಸಲಾದ ಅಥವಾ ಎರಡು ಅಥವಾ ಹೆಚ್ಚಿನ ವಿಂಗಡಿಸಲಾದ ಅನುಕ್ರಮಗಳನ್ನು ಒಂದರ ನಂತರ ಒಂದರಂತೆ ಜೋಡಿಸುವ ಸಂದರ್ಭಗಳಲ್ಲಿ ಇದನ್ನು ಅತ್ಯಂತ ವೇಗವಾಗಿ ವಿನ್ಯಾಸಗೊಳಿಸಲಾಗಿದೆ.
    ///
    /// ಅಲ್ಲದೆ, ಇದು `self` ನ ಅರ್ಧದಷ್ಟು ಗಾತ್ರದ ತಾತ್ಕಾಲಿಕ ಸಂಗ್ರಹಣೆಯನ್ನು ನಿಯೋಜಿಸುತ್ತದೆ, ಆದರೆ ಸಣ್ಣ ಚೂರುಗಳಿಗೆ ಬದಲಾಗಿ ಹಂಚಿಕೆಯಾಗದ ಅಳವಡಿಕೆ ವಿಂಗಡಣೆಯನ್ನು ಬಳಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// ಕೀ ಹೊರತೆಗೆಯುವ ಕಾರ್ಯದೊಂದಿಗೆ ಸ್ಲೈಸ್ ಅನ್ನು ವಿಂಗಡಿಸುತ್ತದೆ.
    ///
    /// ವಿಂಗಡಣೆಯ ಸಮಯದಲ್ಲಿ, ಕೀ ಕಾರ್ಯವನ್ನು ಪ್ರತಿ ಅಂಶಕ್ಕೆ ಒಮ್ಮೆ ಮಾತ್ರ ಕರೆಯಲಾಗುತ್ತದೆ.
    ///
    /// ಈ ರೀತಿಯು ಸ್ಥಿರವಾಗಿರುತ್ತದೆ (ಅಂದರೆ, ಸಮಾನ ಅಂಶಗಳನ್ನು ಮರುಕ್ರಮಗೊಳಿಸುವುದಿಲ್ಲ) ಮತ್ತು *O*(*m*\* * n *+* n *\* log(*n*)) ಕೆಟ್ಟ ಪ್ರಕರಣ, ಅಲ್ಲಿ ಪ್ರಮುಖ ಕಾರ್ಯವು *O*(*m*) .
    ///
    /// ಸರಳವಾದ ಪ್ರಮುಖ ಕಾರ್ಯಗಳಿಗಾಗಿ (ಉದಾ., ಆಸ್ತಿ ಪ್ರವೇಶ ಅಥವಾ ಮೂಲ ಕಾರ್ಯಾಚರಣೆಗಳು), [`sort_by_key`](slice::sort_by_key) ವೇಗವಾಗಿರುತ್ತದೆ.
    ///
    /// # ಪ್ರಸ್ತುತ ಅನುಷ್ಠಾನ
    ///
    /// ಪ್ರಸ್ತುತ ಅಲ್ಗಾರಿದಮ್ ಆರ್ಸನ್ ಪೀಟರ್ಸ್ ಅವರಿಂದ [pattern-defeating quicksort][pdqsort] ಅನ್ನು ಆಧರಿಸಿದೆ, ಇದು ಯಾದೃಚ್ ized ಿಕ ಕ್ವಿಕ್ಸೋರ್ಟ್‌ನ ವೇಗದ ಸರಾಸರಿ ಪ್ರಕರಣವನ್ನು ಹೆಪ್ಸೋರ್ಟ್‌ನ ವೇಗದ ಕೆಟ್ಟ ಪ್ರಕರಣದೊಂದಿಗೆ ಸಂಯೋಜಿಸುತ್ತದೆ, ಆದರೆ ಕೆಲವು ಮಾದರಿಗಳೊಂದಿಗೆ ಚೂರುಗಳ ಮೇಲೆ ರೇಖೀಯ ಸಮಯವನ್ನು ಸಾಧಿಸುತ್ತದೆ.
    /// ಕ್ಷೀಣಗೊಳ್ಳುವ ಪ್ರಕರಣಗಳನ್ನು ತಪ್ಪಿಸಲು ಇದು ಕೆಲವು ಯಾದೃಚ್ ization ಿಕೀಕರಣವನ್ನು ಬಳಸುತ್ತದೆ, ಆದರೆ ಯಾವಾಗಲೂ ನಿರ್ಣಾಯಕ ನಡವಳಿಕೆಯನ್ನು ಒದಗಿಸಲು ಸ್ಥಿರವಾದ seed ನೊಂದಿಗೆ.
    ///
    /// ಕೆಟ್ಟ ಸಂದರ್ಭದಲ್ಲಿ, ಅಲ್ಗಾರಿದಮ್ ಸ್ಲೈಸ್‌ನ ಉದ್ದವನ್ನು `Vec<(K, usize)>` ನಲ್ಲಿ ತಾತ್ಕಾಲಿಕ ಸಂಗ್ರಹಣೆಯನ್ನು ನಿಯೋಜಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // ಹಂಚಿಕೆಯನ್ನು ಕಡಿಮೆ ಮಾಡಲು, ನಮ್ಮ vector ಅನ್ನು ಸಾಧ್ಯವಾದಷ್ಟು ಸಣ್ಣ ಪ್ರಕಾರದಿಂದ ಸೂಚಿಕೆ ಮಾಡಲು ಸಹಾಯಕ ಮ್ಯಾಕ್ರೋ.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // `indices` ನ ಅಂಶಗಳು ಅನನ್ಯವಾಗಿವೆ, ಏಕೆಂದರೆ ಅವುಗಳು ಸೂಚ್ಯಂಕವಾಗಿರುತ್ತವೆ, ಆದ್ದರಿಂದ ಯಾವುದೇ ರೀತಿಯ ಮೂಲ ಸ್ಲೈಸ್‌ಗೆ ಸಂಬಂಧಿಸಿದಂತೆ ಸ್ಥಿರವಾಗಿರುತ್ತದೆ.
                // ನಾವು ಇಲ್ಲಿ `sort_unstable` ಅನ್ನು ಬಳಸುತ್ತೇವೆ ಏಕೆಂದರೆ ಇದಕ್ಕೆ ಕಡಿಮೆ ಮೆಮೊರಿ ಹಂಚಿಕೆ ಅಗತ್ಯವಿರುತ್ತದೆ.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// `self` ಅನ್ನು ಹೊಸ `Vec` ಗೆ ನಕಲಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // ಇಲ್ಲಿ, `s` ಮತ್ತು `x` ಅನ್ನು ಸ್ವತಂತ್ರವಾಗಿ ಮಾರ್ಪಡಿಸಬಹುದು.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// ಹಂಚಿಕೆದಾರರೊಂದಿಗೆ `self` ಅನ್ನು ಹೊಸ `Vec` ಗೆ ನಕಲಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // ಇಲ್ಲಿ, `s` ಮತ್ತು `x` ಅನ್ನು ಸ್ವತಂತ್ರವಾಗಿ ಮಾರ್ಪಡಿಸಬಹುದು.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ ಈ ಫೈಲ್‌ನಲ್ಲಿ `hack` ಮಾಡ್ಯೂಲ್ ನೋಡಿ.
        hack::to_vec(self, alloc)
    }

    /// `self` ಅನ್ನು ತದ್ರೂಪುಗಳು ಅಥವಾ ಹಂಚಿಕೆ ಇಲ್ಲದೆ vector ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ಪರಿಣಾಮವಾಗಿ ಬರುವ vector ಅನ್ನು `Vec ಮೂಲಕ ಮತ್ತೆ ಪೆಟ್ಟಿಗೆಯಾಗಿ ಪರಿವರ್ತಿಸಬಹುದು<T>`into_boxed_slice` ವಿಧಾನ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` ಇದನ್ನು ಇನ್ನು ಮುಂದೆ ಬಳಸಲಾಗುವುದಿಲ್ಲ ಏಕೆಂದರೆ ಇದನ್ನು `x` ಆಗಿ ಪರಿವರ್ತಿಸಲಾಗಿದೆ.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ ಈ ಫೈಲ್‌ನಲ್ಲಿ `hack` ಮಾಡ್ಯೂಲ್ ನೋಡಿ.
        hack::into_vec(self)
    }

    /// ಸ್ಲೈಸ್ `n` ಬಾರಿ ಪುನರಾವರ್ತಿಸುವ ಮೂಲಕ vector ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// ಸಾಮರ್ಥ್ಯವು ಉಕ್ಕಿ ಹರಿಯುತ್ತಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// ಉಕ್ಕಿ ಹರಿಯುವಾಗ panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // `n` ಶೂನ್ಯಕ್ಕಿಂತ ದೊಡ್ಡದಾಗಿದ್ದರೆ, ಅದನ್ನು `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` ಎಂದು ವಿಭಜಿಸಬಹುದು.
        // `2^expn` ಇದು `n` ನ ಎಡಭಾಗದ '1' ಬಿಟ್‌ನಿಂದ ಪ್ರತಿನಿಧಿಸಲ್ಪಡುವ ಸಂಖ್ಯೆ, ಮತ್ತು `rem` ಎಂಬುದು `n` ನ ಉಳಿದ ಭಾಗವಾಗಿದೆ.
        //
        //

        // `set_len()` ಅನ್ನು ಪ್ರವೇಶಿಸಲು `Vec` ಅನ್ನು ಬಳಸುವುದು.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` `buf` `expn`-times ಅನ್ನು ದ್ವಿಗುಣಗೊಳಿಸುವ ಮೂಲಕ ಪುನರಾವರ್ತನೆ ಮಾಡಲಾಗುತ್ತದೆ.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // `m > 0` ಆಗಿದ್ದರೆ, ಎಡಭಾಗದ '1' ವರೆಗೆ ಉಳಿದಿರುವ ಬಿಟ್‌ಗಳಿವೆ.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` `self.len() * n` ಸಾಮರ್ಥ್ಯವನ್ನು ಹೊಂದಿದೆ.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) ಮೊದಲ `rem` ಪುನರಾವರ್ತನೆಗಳನ್ನು `buf` ನಿಂದ ನಕಲಿಸುವ ಮೂಲಕ ಪುನರಾವರ್ತನೆ ಮಾಡಲಾಗುತ್ತದೆ.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // ಇದು `2^expn > rem` ರಿಂದ ಅತಿಕ್ರಮಿಸುವುದಿಲ್ಲ.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` `buf.capacity()` (`= self.len() * n`) ಗೆ ಸಮನಾಗಿರುತ್ತದೆ.
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// `T` ನ ಸ್ಲೈಸ್ ಅನ್ನು ಒಂದೇ ಮೌಲ್ಯ `Self::Output` ಆಗಿ ಚಪ್ಪಟೆಗೊಳಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// `T` ನ ಸ್ಲೈಸ್ ಅನ್ನು ಒಂದೇ ಮೌಲ್ಯ `Self::Output` ಗೆ ಚಪ್ಪಟೆಗೊಳಿಸುತ್ತದೆ, ಪ್ರತಿಯೊಂದರ ನಡುವೆ ನಿರ್ದಿಷ್ಟ ವಿಭಜಕವನ್ನು ಇರಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// `T` ನ ಸ್ಲೈಸ್ ಅನ್ನು ಒಂದೇ ಮೌಲ್ಯ `Self::Output` ಗೆ ಚಪ್ಪಟೆಗೊಳಿಸುತ್ತದೆ, ಪ್ರತಿಯೊಂದರ ನಡುವೆ ನಿರ್ದಿಷ್ಟ ವಿಭಜಕವನ್ನು ಇರಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// ಈ ಸ್ಲೈಸ್‌ನ ನಕಲನ್ನು ಹೊಂದಿರುವ vector ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಲ್ಲಿ ಪ್ರತಿ ಬೈಟ್ ಅನ್ನು ಅದರ ASCII ಮೇಲಿನ ಕೇಸ್‌ಗೆ ಸಮನಾಗಿ ಮ್ಯಾಪ್ ಮಾಡಲಾಗುತ್ತದೆ.
    ///
    ///
    /// ASCII ಅಕ್ಷರಗಳು 'a' ರಿಂದ 'z' ಅನ್ನು 'A' ನಿಂದ 'Z' ಗೆ ಮ್ಯಾಪ್ ಮಾಡಲಾಗಿದೆ, ಆದರೆ ASCII ಅಲ್ಲದ ಅಕ್ಷರಗಳು ಬದಲಾಗುವುದಿಲ್ಲ.
    ///
    /// ಸ್ಥಳದಲ್ಲಿ ಮೌಲ್ಯವನ್ನು ದೊಡ್ಡದಾಗಿಸಲು, [`make_ascii_uppercase`] ಬಳಸಿ.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// ಈ ಸ್ಲೈಸ್‌ನ ನಕಲನ್ನು ಹೊಂದಿರುವ vector ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಲ್ಲಿ ಪ್ರತಿ ಬೈಟ್ ಅನ್ನು ಅದರ ASCII ಲೋವರ್ ಕೇಸ್ ಸಮಾನಕ್ಕೆ ಮ್ಯಾಪ್ ಮಾಡಲಾಗುತ್ತದೆ.
    ///
    ///
    /// ASCII ಅಕ್ಷರಗಳು 'A' ರಿಂದ 'Z' ಅನ್ನು 'a' ನಿಂದ 'z' ಗೆ ಮ್ಯಾಪ್ ಮಾಡಲಾಗಿದೆ, ಆದರೆ ASCII ಅಲ್ಲದ ಅಕ್ಷರಗಳು ಬದಲಾಗುವುದಿಲ್ಲ.
    ///
    /// ಸ್ಥಳದಲ್ಲಿ ಮೌಲ್ಯವನ್ನು ಕಡಿಮೆ ಮಾಡಲು, [`make_ascii_lowercase`] ಬಳಸಿ.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// ನಿರ್ದಿಷ್ಟ ರೀತಿಯ ಡೇಟಾದ ಮೇಲೆ ಚೂರುಗಳಿಗಾಗಿ ವಿಸ್ತರಣೆ traits
////////////////////////////////////////////////////////////////////////////////

/// [`[ಟಿ]: : ಕಾನ್ಕಾಟ್`](ಸ್ಲೈಸ್::ಕಾನ್ಕಾಟ್) ಗಾಗಿ trait ಸಹಾಯಕ.
///
/// Note: ಈ trait ನಲ್ಲಿ `Item` ಪ್ರಕಾರದ ನಿಯತಾಂಕವನ್ನು ಬಳಸಲಾಗುವುದಿಲ್ಲ, ಆದರೆ ಇದು ಹೆಚ್ಚು ಸಾಮಾನ್ಯವಾಗಲು impls ಅನ್ನು ಅನುಮತಿಸುತ್ತದೆ.
/// ಇದು ಇಲ್ಲದೆ, ನಾವು ಈ ದೋಷವನ್ನು ಪಡೆಯುತ್ತೇವೆ:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// ಏಕೆಂದರೆ ಅನೇಕ `Borrow<[_]>` ಇಂಪ್ಲ್‌ಗಳೊಂದಿಗೆ `V` ಪ್ರಕಾರಗಳು ಅಸ್ತಿತ್ವದಲ್ಲಿರಬಹುದು, ಉದಾಹರಣೆಗೆ ಅನೇಕ `T` ಪ್ರಕಾರಗಳು ಅನ್ವಯವಾಗುತ್ತವೆ:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// ಒಗ್ಗೂಡಿಸುವಿಕೆಯ ನಂತರದ ಪ್ರಕಾರ
    type Output;

    /// [`[ಟಿ]: : ಕಾನ್ಕಾಟ್`](ಸ್ಲೈಸ್::ಕಾನ್ಕಾಟ್) ಅನುಷ್ಠಾನ
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// [`[ಟಿ]: : ಸೇರ್ಪಡೆ`](ಸ್ಲೈಸ್::ಸೇರ್ಪಡೆ) ಗಾಗಿ ಸಹಾಯಕ trait
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// ಒಗ್ಗೂಡಿಸುವಿಕೆಯ ನಂತರದ ಪ್ರಕಾರ
    type Output;

    /// [`[ಟಿ]: : ಸೇರ್ಪಡೆ`](ಸ್ಲೈಸ್::ಸೇರ್ಪಡೆ) ಅನುಷ್ಠಾನ
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// ಚೂರುಗಳಿಗಾಗಿ ಸ್ಟ್ಯಾಂಡರ್ಡ್ trait ಅನುಷ್ಠಾನಗಳು
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // ತಿದ್ದಿ ಬರೆಯಲಾಗದ ಯಾವುದನ್ನಾದರೂ ಗುರಿಯಲ್ಲಿ ಬಿಡಿ
        target.truncate(self.len());

        // target.len ಮೇಲಿನ ಮೊಟಕುಗೊಳಿಸುವಿಕೆಯಿಂದಾಗಿ <= self.len, ಆದ್ದರಿಂದ ಇಲ್ಲಿ ಚೂರುಗಳು ಯಾವಾಗಲೂ ಪರಿಮಿತಿಯಲ್ಲಿರುತ್ತವೆ.
        //
        let (init, tail) = self.split_at(target.len());

        // ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯಗಳ allocations/resources ಅನ್ನು ಮರುಬಳಕೆ ಮಾಡಿ.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// `v[0]` ಅನ್ನು ಪೂರ್ವ-ವಿಂಗಡಿಸಲಾದ ಅನುಕ್ರಮ `v[1..]` ಗೆ ಸೇರಿಸುತ್ತದೆ ಇದರಿಂದ ಇಡೀ `v[..]` ವಿಂಗಡಿಸಲ್ಪಡುತ್ತದೆ.
///
/// ಇದು ಅಳವಡಿಕೆ ವಿಂಗಡಣೆಯ ಅವಿಭಾಜ್ಯ ಸಬ್‌ರುಟೀನ್ ಆಗಿದೆ.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // ಇಲ್ಲಿ ಅಳವಡಿಕೆಯನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ಮೂರು ಮಾರ್ಗಗಳಿವೆ:
            //
            // 1. ಮೊದಲನೆಯದು ಅಂತಿಮ ಗಮ್ಯಸ್ಥಾನವನ್ನು ತಲುಪುವವರೆಗೆ ಪಕ್ಕದ ಅಂಶಗಳನ್ನು ವಿನಿಮಯ ಮಾಡಿಕೊಳ್ಳಿ.
            //    ಆದಾಗ್ಯೂ, ಈ ರೀತಿಯಾಗಿ ನಾವು ಅಗತ್ಯಕ್ಕಿಂತ ಹೆಚ್ಚಿನದನ್ನು ಡೇಟಾವನ್ನು ನಕಲಿಸುತ್ತೇವೆ.
            //    ಅಂಶಗಳು ದೊಡ್ಡ ರಚನೆಗಳಾಗಿದ್ದರೆ (ನಕಲಿಸಲು ದುಬಾರಿಯಾಗಿದೆ), ಈ ವಿಧಾನವು ನಿಧಾನವಾಗಿರುತ್ತದೆ.
            //
            // 2. ಮೊದಲ ಅಂಶಕ್ಕೆ ಸರಿಯಾದ ಸ್ಥಳ ದೊರೆಯುವವರೆಗೆ ಪುನರಾವರ್ತಿಸಿ.
            // ನಂತರ ಅದರ ನಂತರದ ಸ್ಥಳಗಳನ್ನು ಸ್ಥಳಾಂತರಿಸಲು ಸ್ಥಳಾಂತರಿಸಿ ಮತ್ತು ಅಂತಿಮವಾಗಿ ಅದನ್ನು ಉಳಿದ ರಂಧ್ರಕ್ಕೆ ಇರಿಸಿ.
            // ಇದು ಉತ್ತಮ ವಿಧಾನ.
            //
            // 3. ಮೊದಲ ಅಂಶವನ್ನು ತಾತ್ಕಾಲಿಕ ವೇರಿಯೇಬಲ್ ಆಗಿ ನಕಲಿಸಿ.ಅದಕ್ಕೆ ಸರಿಯಾದ ಸ್ಥಳ ದೊರೆಯುವವರೆಗೂ ಪುನರಾವರ್ತಿಸಿ.
            // ನಾವು ಹೋಗುತ್ತಿರುವಾಗ, ಹಾದುಹೋಗುವ ಪ್ರತಿಯೊಂದು ಅಂಶವನ್ನು ಅದರ ಹಿಂದಿನ ಸ್ಲಾಟ್‌ಗೆ ನಕಲಿಸಿ.
            // ಅಂತಿಮವಾಗಿ, ತಾತ್ಕಾಲಿಕ ವೇರಿಯೇಬಲ್ನಿಂದ ಡೇಟಾವನ್ನು ಉಳಿದ ರಂಧ್ರಕ್ಕೆ ನಕಲಿಸಿ.
            // ಈ ವಿಧಾನವು ತುಂಬಾ ಒಳ್ಳೆಯದು.
            // ಮಾನದಂಡಗಳು 2 ನೇ ವಿಧಾನಕ್ಕಿಂತ ಸ್ವಲ್ಪ ಉತ್ತಮ ಕಾರ್ಯಕ್ಷಮತೆಯನ್ನು ಪ್ರದರ್ಶಿಸಿದವು.
            //
            // ಎಲ್ಲಾ ವಿಧಾನಗಳನ್ನು ಮಾನದಂಡವಾಗಿ ಗುರುತಿಸಲಾಗಿದೆ, ಮತ್ತು 3 ನೇ ಫಲಿತಾಂಶವು ಉತ್ತಮ ಫಲಿತಾಂಶಗಳನ್ನು ತೋರಿಸಿದೆ.ಆದ್ದರಿಂದ ನಾವು ಅದನ್ನು ಆರಿಸಿದ್ದೇವೆ.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // ಅಳವಡಿಕೆ ಪ್ರಕ್ರಿಯೆಯ ಮಧ್ಯಂತರ ಸ್ಥಿತಿಯನ್ನು ಯಾವಾಗಲೂ `hole` ನಿಂದ ಟ್ರ್ಯಾಕ್ ಮಾಡಲಾಗುತ್ತದೆ, ಇದು ಎರಡು ಉದ್ದೇಶಗಳನ್ನು ಪೂರೈಸುತ್ತದೆ:
            // 1. `is_less` ನಲ್ಲಿ panics ನಿಂದ `v` ನ ಸಮಗ್ರತೆಯನ್ನು ರಕ್ಷಿಸುತ್ತದೆ.
            // 2. `v` ನಲ್ಲಿ ಉಳಿದ ರಂಧ್ರವನ್ನು ಕೊನೆಯಲ್ಲಿ ತುಂಬುತ್ತದೆ.
            //
            // Panic ಸುರಕ್ಷತೆ:
            //
            // ಪ್ರಕ್ರಿಯೆಯ ಸಮಯದಲ್ಲಿ ಯಾವುದೇ ಸಮಯದಲ್ಲಿ `is_less` panics ಇದ್ದರೆ, `hole` ಕೈಬಿಡುತ್ತದೆ ಮತ್ತು `v` ನಲ್ಲಿನ ರಂಧ್ರವನ್ನು `tmp` ನೊಂದಿಗೆ ತುಂಬುತ್ತದೆ, ಇದರಿಂದಾಗಿ `v` ಆರಂಭದಲ್ಲಿ ನಿಖರವಾಗಿ ಒಮ್ಮೆ ಹಿಡಿದಿರುವ ಪ್ರತಿಯೊಂದು ವಸ್ತುವನ್ನು ಇನ್ನೂ ಹೊಂದಿದೆ ಎಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` ಕೈಬಿಡಲಾಗುತ್ತದೆ ಮತ್ತು ಹೀಗಾಗಿ `tmp` ಅನ್ನು `v` ನಲ್ಲಿ ಉಳಿದ ರಂಧ್ರಕ್ಕೆ ನಕಲಿಸುತ್ತದೆ.
        }
    }

    // ಕೈಬಿಟ್ಟಾಗ, `src` ನಿಂದ `dest` ಗೆ ಪ್ರತಿಗಳು.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// ಕಡಿಮೆಯಾಗದ ರನ್ಗಳನ್ನು `v[..mid]` ಮತ್ತು `v[mid..]` ಅನ್ನು `buf` ಅನ್ನು ತಾತ್ಕಾಲಿಕ ಸಂಗ್ರಹವಾಗಿ ವಿಲೀನಗೊಳಿಸುತ್ತದೆ ಮತ್ತು ಫಲಿತಾಂಶವನ್ನು `v[..]` ಗೆ ಸಂಗ್ರಹಿಸುತ್ತದೆ.
///
/// # Safety
///
/// ಎರಡು ಚೂರುಗಳು ಖಾಲಿಯಾಗಿರಬಾರದು ಮತ್ತು `mid` ಪರಿಮಿತಿಯಲ್ಲಿರಬೇಕು.
/// ಕಡಿಮೆ ಸ್ಲೈಸ್‌ನ ನಕಲನ್ನು ಹಿಡಿದಿಡಲು ಬಫರ್ `buf` ಸಾಕಷ್ಟು ಉದ್ದವಾಗಿರಬೇಕು.
/// ಅಲ್ಲದೆ, `T` ಶೂನ್ಯ ಗಾತ್ರದ ಪ್ರಕಾರವಾಗಿರಬಾರದು.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // ವಿಲೀನ ಪ್ರಕ್ರಿಯೆಯು ಮೊದಲು ಕಡಿಮೆ ಓಟವನ್ನು `buf` ಗೆ ನಕಲಿಸುತ್ತದೆ.
    // ನಂತರ ಅದು ಹೊಸದಾಗಿ ನಕಲಿಸಿದ ರನ್ ಮತ್ತು ಮುಂದೆ ಓಡುವಿಕೆಯನ್ನು (ಅಥವಾ ಹಿಂದಕ್ಕೆ) ಪತ್ತೆಹಚ್ಚುತ್ತದೆ, ಅವುಗಳ ಮುಂದಿನ ಅಪ್ರಜ್ಞಾಪೂರ್ವಕ ಅಂಶಗಳನ್ನು ಹೋಲಿಸುತ್ತದೆ ಮತ್ತು ಕಡಿಮೆ (ಅಥವಾ ಹೆಚ್ಚಿನದನ್ನು) `v` ಗೆ ನಕಲಿಸುತ್ತದೆ.
    //
    // ಕಡಿಮೆ ಓಟವನ್ನು ಸಂಪೂರ್ಣವಾಗಿ ಸೇವಿಸಿದ ತಕ್ಷಣ, ಪ್ರಕ್ರಿಯೆಯನ್ನು ಮಾಡಲಾಗುತ್ತದೆ.ದೀರ್ಘಾವಧಿಯ ಓಟವನ್ನು ಮೊದಲು ಸೇವಿಸಿದರೆ, ಕಡಿಮೆ ಓಟದಲ್ಲಿ ಉಳಿದಿರುವದನ್ನು ನಾವು `v` ನಲ್ಲಿ ಉಳಿದ ರಂಧ್ರಕ್ಕೆ ನಕಲಿಸಬೇಕು.
    //
    // ಪ್ರಕ್ರಿಯೆಯ ಮಧ್ಯಂತರ ಸ್ಥಿತಿಯನ್ನು ಯಾವಾಗಲೂ `hole` ನಿಂದ ಟ್ರ್ಯಾಕ್ ಮಾಡಲಾಗುತ್ತದೆ, ಇದು ಎರಡು ಉದ್ದೇಶಗಳನ್ನು ಪೂರೈಸುತ್ತದೆ:
    // 1. `is_less` ನಲ್ಲಿ panics ನಿಂದ `v` ನ ಸಮಗ್ರತೆಯನ್ನು ರಕ್ಷಿಸುತ್ತದೆ.
    // 2. ದೀರ್ಘಾವಧಿಯ ಓಟವನ್ನು ಮೊದಲು ಸೇವಿಸಿದರೆ `v` ನಲ್ಲಿ ಉಳಿದ ರಂಧ್ರವನ್ನು ತುಂಬುತ್ತದೆ.
    //
    // Panic ಸುರಕ್ಷತೆ:
    //
    // ಪ್ರಕ್ರಿಯೆಯ ಸಮಯದಲ್ಲಿ ಯಾವುದೇ ಸಮಯದಲ್ಲಿ `is_less` panics ಇದ್ದರೆ, `hole` ಕೈಬಿಡುತ್ತದೆ ಮತ್ತು `v` ನಲ್ಲಿ ರಂಧ್ರವನ್ನು `buf` ನಲ್ಲಿ ಅಪ್ರಜ್ಞಾಪೂರ್ವಕ ಶ್ರೇಣಿಯೊಂದಿಗೆ ತುಂಬುತ್ತದೆ, ಇದರಿಂದಾಗಿ `v` ಆರಂಭದಲ್ಲಿ ನಿಖರವಾಗಿ ಒಮ್ಮೆ ಹಿಡಿದಿರುವ ಪ್ರತಿಯೊಂದು ವಸ್ತುವನ್ನು ಇನ್ನೂ ಹೊಂದಿದೆ ಎಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // ಎಡ ರನ್ ಚಿಕ್ಕದಾಗಿದೆ.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // ಆರಂಭದಲ್ಲಿ, ಈ ಪಾಯಿಂಟರ್‌ಗಳು ತಮ್ಮ ಸರಣಿಗಳ ಪ್ರಾರಂಭವನ್ನು ಸೂಚಿಸುತ್ತವೆ.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // ಕಡಿಮೆ ಭಾಗವನ್ನು ಸೇವಿಸಿ.
            // ಸಮಾನವಾಗಿದ್ದರೆ, ಸ್ಥಿರತೆಯನ್ನು ಕಾಪಾಡಿಕೊಳ್ಳಲು ಎಡ ಓಟಕ್ಕೆ ಆದ್ಯತೆ ನೀಡಿ.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // ಸರಿಯಾದ ರನ್ ಕಡಿಮೆ.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // ಆರಂಭದಲ್ಲಿ, ಈ ಪಾಯಿಂಟರ್‌ಗಳು ತಮ್ಮ ಸರಣಿಗಳ ತುದಿಗಳನ್ನು ದಾಟಿವೆ.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // ಹೆಚ್ಚಿನ ಭಾಗವನ್ನು ಸೇವಿಸಿ.
            // ಸಮಾನವಾಗಿದ್ದರೆ, ಸ್ಥಿರತೆಯನ್ನು ಕಾಪಾಡಿಕೊಳ್ಳಲು ಸರಿಯಾದ ಓಟಕ್ಕೆ ಆದ್ಯತೆ ನೀಡಿ.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // ಅಂತಿಮವಾಗಿ, `hole` ಕೈಬಿಡುತ್ತದೆ.
    // ಕಡಿಮೆ ಓಟವನ್ನು ಸಂಪೂರ್ಣವಾಗಿ ಸೇವಿಸದಿದ್ದರೆ, ಅದರ ಯಾವುದೇ ಅವಶೇಷಗಳನ್ನು ಈಗ `v` ನ ರಂಧ್ರಕ್ಕೆ ನಕಲಿಸಲಾಗುತ್ತದೆ.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // ಕೈಬಿಟ್ಟಾಗ, `start..end` ಶ್ರೇಣಿಯನ್ನು `dest..` ಗೆ ನಕಲಿಸುತ್ತದೆ.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` ಶೂನ್ಯ-ಗಾತ್ರದ ಪ್ರಕಾರವಲ್ಲ, ಆದ್ದರಿಂದ ಅದರ ಗಾತ್ರದಿಂದ ಭಾಗಿಸುವುದು ಸರಿಯಾಗಿದೆ.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// ಈ ವಿಲೀನ ವಿಂಗಡಣೆಯು ಟಿಮ್‌ಸೋರ್ಟ್‌ನಿಂದ ಕೆಲವು (ಆದರೆ ಎಲ್ಲವಲ್ಲ) ವಿಚಾರಗಳನ್ನು ಎರವಲು ಪಡೆಯುತ್ತದೆ, ಇದನ್ನು ವಿವರವಾಗಿ [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) ನಲ್ಲಿ ವಿವರಿಸಲಾಗಿದೆ.
///
///
/// ಅಲ್ಗಾರಿದಮ್ ಕಟ್ಟುನಿಟ್ಟಾಗಿ ಅವರೋಹಣ ಮತ್ತು ಅವರೋಹಣವಲ್ಲದ ನಂತರದ ಪರಿಣಾಮಗಳನ್ನು ಗುರುತಿಸುತ್ತದೆ, ಇದನ್ನು ನೈಸರ್ಗಿಕ ರನ್ಗಳು ಎಂದು ಕರೆಯಲಾಗುತ್ತದೆ.ವಿಲೀನಗೊಳ್ಳಲು ಇನ್ನೂ ಬಾಕಿ ಉಳಿದಿರುವ ರನ್ ಗಳ ಸಂಗ್ರಹವಿದೆ.
/// ಹೊಸದಾಗಿ ಕಂಡುಬರುವ ಪ್ರತಿಯೊಂದು ಓಟವನ್ನು ಸ್ಟ್ಯಾಕ್‌ಗೆ ತಳ್ಳಲಾಗುತ್ತದೆ, ಮತ್ತು ನಂತರ ಈ ಎರಡು ಅಸ್ಥಿರಗಳು ತೃಪ್ತಿಗೊಳ್ಳುವವರೆಗೆ ಕೆಲವು ಜೋಡಿ ಪಕ್ಕದ ರನ್‌ಗಳನ್ನು ವಿಲೀನಗೊಳಿಸಲಾಗುತ್ತದೆ:
///
/// 1. `1..runs.len()` ನಲ್ಲಿನ ಪ್ರತಿ `i` ಗೆ: `runs[i - 1].len > runs[i].len`
/// 2. `2..runs.len()` ನಲ್ಲಿನ ಪ್ರತಿ `i` ಗೆ: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// ಒಟ್ಟು ಚಾಲನೆಯಲ್ಲಿರುವ ಸಮಯ *O*(*n*\*log(* n*)) ಕೆಟ್ಟ ಪ್ರಕರಣ ಎಂದು ಅಸ್ಥಿರತೆಗಳು ಖಚಿತಪಡಿಸುತ್ತವೆ.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // ಈ ಉದ್ದದ ಚೂರುಗಳನ್ನು ಅಳವಡಿಕೆ ವಿಂಗಡಣೆಯನ್ನು ಬಳಸಿಕೊಂಡು ವಿಂಗಡಿಸಲಾಗುತ್ತದೆ.
    const MAX_INSERTION: usize = 20;
    // ಕನಿಷ್ಠ ಈ ಹಲವು ಅಂಶಗಳನ್ನು ವಿಸ್ತರಿಸಲು ಅಳವಡಿಕೆ ವಿಂಗಡಣೆಯನ್ನು ಬಳಸಿಕೊಂಡು ಬಹಳ ಕಡಿಮೆ ರನ್ಗಳನ್ನು ವಿಸ್ತರಿಸಲಾಗುತ್ತದೆ.
    const MIN_RUN: usize = 10;

    // ವಿಂಗಡಣೆಯು ಶೂನ್ಯ-ಗಾತ್ರದ ಪ್ರಕಾರಗಳಲ್ಲಿ ಯಾವುದೇ ಅರ್ಥಪೂರ್ಣ ನಡವಳಿಕೆಯನ್ನು ಹೊಂದಿಲ್ಲ.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // ಹಂಚಿಕೆಗಳನ್ನು ತಪ್ಪಿಸಲು ಸಣ್ಣ ಶ್ರೇಣಿಗಳನ್ನು ಅಳವಡಿಕೆ ವಿಂಗಡಣೆಯ ಮೂಲಕ ಸ್ಥಳದಲ್ಲಿ ವಿಂಗಡಿಸಲಾಗುತ್ತದೆ.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // ಸ್ಕ್ರ್ಯಾಚ್ ಮೆಮೊರಿಯಾಗಿ ಬಳಸಲು ಬಫರ್ ಅನ್ನು ನಿಯೋಜಿಸಿ.ನಾವು ಉದ್ದ 0 ಅನ್ನು ಇಡುತ್ತೇವೆ ಆದ್ದರಿಂದ `is_less` panics ಆಗಿದ್ದರೆ ಪ್ರತಿಗಳಲ್ಲಿ ಚಾಲನೆಯಲ್ಲಿರುವ dtors ಅನ್ನು ಅಪಾಯಕ್ಕೆ ತೆಗೆದುಕೊಳ್ಳದೆ ನಾವು `v` ನ ವಿಷಯಗಳ ಆಳವಿಲ್ಲದ ಪ್ರತಿಗಳನ್ನು ಇಡಬಹುದು.
    //
    // ಎರಡು ವಿಂಗಡಿಸಲಾದ ರನ್ಗಳನ್ನು ವಿಲೀನಗೊಳಿಸುವಾಗ, ಈ ಬಫರ್ ಕಡಿಮೆ ಓಟದ ನಕಲನ್ನು ಹೊಂದಿರುತ್ತದೆ, ಅದು ಯಾವಾಗಲೂ ಹೆಚ್ಚಿನ `len / 2` ನಲ್ಲಿ ಉದ್ದವನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // `v` ನಲ್ಲಿ ನೈಸರ್ಗಿಕ ರನ್ಗಳನ್ನು ಗುರುತಿಸಲು, ನಾವು ಅದನ್ನು ಹಿಂದಕ್ಕೆ ಸಾಗಿಸುತ್ತೇವೆ.
    // ಅದು ವಿಚಿತ್ರ ನಿರ್ಧಾರದಂತೆ ಕಾಣಿಸಬಹುದು, ಆದರೆ ವಿಲೀನಗಳು ಹೆಚ್ಚಾಗಿ (forwards) ವಿರುದ್ಧ ದಿಕ್ಕಿನಲ್ಲಿ ಹೋಗುತ್ತವೆ ಎಂಬ ಅಂಶವನ್ನು ಪರಿಗಣಿಸಿ.
    // ಮಾನದಂಡಗಳ ಪ್ರಕಾರ, ಹಿಂದಕ್ಕೆ ವಿಲೀನಗೊಳ್ಳುವುದಕ್ಕಿಂತ ಮುಂದಕ್ಕೆ ವಿಲೀನಗೊಳ್ಳುವುದು ಸ್ವಲ್ಪ ವೇಗವಾಗಿರುತ್ತದೆ.
    // ತೀರ್ಮಾನಕ್ಕೆ, ಹಿಂದಕ್ಕೆ ಹಾದುಹೋಗುವ ಮೂಲಕ ರನ್ಗಳನ್ನು ಗುರುತಿಸುವುದು ಕಾರ್ಯಕ್ಷಮತೆಯನ್ನು ಸುಧಾರಿಸುತ್ತದೆ.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // ಮುಂದಿನ ನೈಸರ್ಗಿಕ ಓಟವನ್ನು ಹುಡುಕಿ, ಮತ್ತು ಅದು ಕಟ್ಟುನಿಟ್ಟಾಗಿ ಅವರೋಹಣವಾಗಿದ್ದರೆ ಅದನ್ನು ಹಿಮ್ಮುಖಗೊಳಿಸಿ.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // ಇದು ತುಂಬಾ ಚಿಕ್ಕದಾಗಿದ್ದರೆ ಇನ್ನೂ ಕೆಲವು ಅಂಶಗಳನ್ನು ಚಾಲನೆಯಲ್ಲಿ ಸೇರಿಸಿ.
        // ಸಣ್ಣ ಅನುಕ್ರಮಗಳಲ್ಲಿ ವಿಲೀನ ವಿಂಗಡಣೆಗಿಂತ ಅಳವಡಿಕೆ ವಿಂಗಡಣೆ ವೇಗವಾಗಿರುತ್ತದೆ, ಆದ್ದರಿಂದ ಇದು ಕಾರ್ಯಕ್ಷಮತೆಯನ್ನು ಗಮನಾರ್ಹವಾಗಿ ಸುಧಾರಿಸುತ್ತದೆ.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // ಈ ಓಟವನ್ನು ಸ್ಟ್ಯಾಕ್‌ಗೆ ತಳ್ಳಿರಿ.
        runs.push(Run { start, len: end - start });
        end = start;

        // ಅಸ್ಥಿರತೆಯನ್ನು ಪೂರೈಸಲು ಕೆಲವು ಜೋಡಿ ಪಕ್ಕದ ರನ್ಗಳನ್ನು ವಿಲೀನಗೊಳಿಸಿ.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // ಅಂತಿಮವಾಗಿ, ನಿಖರವಾಗಿ ಒಂದು ರನ್ ಸ್ಟ್ಯಾಕ್‌ನಲ್ಲಿ ಉಳಿಯಬೇಕು.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // ರನ್ಗಳ ಸ್ಟಾಕ್ ಅನ್ನು ಪರಿಶೀಲಿಸುತ್ತದೆ ಮತ್ತು ವಿಲೀನಗೊಳ್ಳಲು ಮುಂದಿನ ಜೋಡಿ ರನ್ಗಳನ್ನು ಗುರುತಿಸುತ್ತದೆ.
    // ಹೆಚ್ಚು ನಿರ್ದಿಷ್ಟವಾಗಿ ಹೇಳುವುದಾದರೆ, `Some(r)` ಅನ್ನು ಹಿಂತಿರುಗಿಸಿದರೆ, ಇದರರ್ಥ `runs[r]` ಮತ್ತು `runs[r + 1]` ಅನ್ನು ಮುಂದಿನ ವಿಲೀನಗೊಳಿಸಬೇಕು.
    // ಅಲ್ಗಾರಿದಮ್ ಬದಲಿಗೆ ಹೊಸ ಓಟವನ್ನು ನಿರ್ಮಿಸುವುದನ್ನು ಮುಂದುವರಿಸಿದರೆ, `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    //
    // ಇಲ್ಲಿ ವಿವರಿಸಿದಂತೆ ಟಿಮ್‌ಸೋರ್ಟ್ ಅದರ ದೋಷಯುಕ್ತ ಅನುಷ್ಠಾನಗಳಿಗೆ ಕುಖ್ಯಾತವಾಗಿದೆ:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // ಕಥೆಯ ಸಾರಾಂಶ ಹೀಗಿದೆ: ನಾವು ಸ್ಟಾಕ್‌ನಲ್ಲಿ ಅಗ್ರ ನಾಲ್ಕು ರನ್‌ಗಳಲ್ಲಿ ಅಸ್ಥಿರತೆಯನ್ನು ಜಾರಿಗೊಳಿಸಬೇಕು.
    // ಕೇವಲ ಮೂರು ಸ್ಥಾನಗಳಲ್ಲಿ ಅವುಗಳನ್ನು ಜಾರಿಗೊಳಿಸುವುದು ಸಾಕಾಗುವುದಿಲ್ಲ.
    //
    // ಈ ಕಾರ್ಯವು ಮೊದಲ ನಾಲ್ಕು ರನ್‌ಗಳಿಗೆ ಅಸ್ಥಿರತೆಯನ್ನು ಸರಿಯಾಗಿ ಪರಿಶೀಲಿಸುತ್ತದೆ.
    // ಹೆಚ್ಚುವರಿಯಾಗಿ, ಉನ್ನತ ರನ್ ಸೂಚ್ಯಂಕ 0 ರಿಂದ ಪ್ರಾರಂಭವಾದರೆ, ವಿಂಗಡಣೆಯನ್ನು ಪೂರ್ಣಗೊಳಿಸುವ ಸಲುವಾಗಿ, ಸ್ಟಾಕ್ ಸಂಪೂರ್ಣವಾಗಿ ಕುಸಿಯುವವರೆಗೆ ಅದು ಯಾವಾಗಲೂ ವಿಲೀನ ಕಾರ್ಯಾಚರಣೆಯನ್ನು ಬಯಸುತ್ತದೆ.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}