//! `alloc` crate ನ prelude ನ ಮೊದಲ ಆವೃತ್ತಿ.
//!
//! ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ [module-level documentation](../index.html) ನೋಡಿ.

#![unstable(feature = "alloc_prelude", issue = "58935")]

#[unstable(feature = "alloc_prelude", issue = "58935")]
pub use crate::borrow::ToOwned;
#[unstable(feature = "alloc_prelude", issue = "58935")]
pub use crate::boxed::Box;
#[unstable(feature = "alloc_prelude", issue = "58935")]
pub use crate::string::{String, ToString};
#[unstable(feature = "alloc_prelude", issue = "58935")]
pub use crate::vec::Vec;