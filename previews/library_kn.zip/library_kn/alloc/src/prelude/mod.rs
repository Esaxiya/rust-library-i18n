//! ಹಂಚಿಕೆ Prelude
//!
//! ಮಾಡ್ಯೂಲ್‌ಗಳ ಮೇಲ್ಭಾಗಕ್ಕೆ ಗ್ಲೋಬ್ ಆಮದನ್ನು ಸೇರಿಸುವ ಮೂಲಕ `alloc` crate ನ ಸಾಮಾನ್ಯವಾಗಿ ಬಳಸುವ ವಸ್ತುಗಳ ಆಮದನ್ನು ನಿವಾರಿಸುವುದು ಈ ಮಾಡ್ಯೂಲ್‌ನ ಉದ್ದೇಶ:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;