#![stable(feature = "rust1", since = "1.0.0")]

//! ಥ್ರೆಡ್-ಸುರಕ್ಷಿತ ಉಲ್ಲೇಖ-ಎಣಿಕೆಯ ಪಾಯಿಂಟರ್‌ಗಳು.
//!
//! ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ [`Arc<T>`][Arc] ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// `Arc` ಗೆ ಮಾಡಬಹುದಾದ ಉಲ್ಲೇಖಗಳ ಪ್ರಮಾಣಕ್ಕೆ ಮೃದುವಾದ ಮಿತಿ.
///
/// ಈ ಮಿತಿಯನ್ನು ಮೀರಿದರೆ ನಿಮ್ಮ ಪ್ರೋಗ್ರಾಂ ಅನ್ನು _exactly_ `MAX_REFCOUNT + 1` ಉಲ್ಲೇಖಗಳಲ್ಲಿ ಸ್ಥಗಿತಗೊಳಿಸುತ್ತದೆ (ಅಗತ್ಯವಿಲ್ಲದಿದ್ದರೂ).
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ಥ್ರೆಡ್‌ಸಾನೈಟೈಸರ್ ಮೆಮೊರಿ ಬೇಲಿಗಳನ್ನು ಬೆಂಬಲಿಸುವುದಿಲ್ಲ.
// ಆರ್ಕ್/ದುರ್ಬಲ ಅನುಷ್ಠಾನದಲ್ಲಿ ತಪ್ಪು ಸಕಾರಾತ್ಮಕ ವರದಿಗಳನ್ನು ತಪ್ಪಿಸಲು ಬದಲಾಗಿ ಸಿಂಕ್ರೊನೈಸೇಶನ್ಗಾಗಿ ಪರಮಾಣು ಲೋಡ್‌ಗಳನ್ನು ಬಳಸಿ.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// ಥ್ರೆಡ್-ಸುರಕ್ಷಿತ ಉಲ್ಲೇಖ-ಎಣಿಕೆಯ ಪಾಯಿಂಟರ್.'Arc' ಎಂದರೆ 'ಪರಮಾಣು ಉಲ್ಲೇಖ ಎಣಿಕೆ'.
///
/// `Arc<T>` ಪ್ರಕಾರವು ರಾಶಿಯಲ್ಲಿ ಹಂಚಿಕೆಯಾದ `T` ಪ್ರಕಾರದ ಮೌಲ್ಯದ ಹಂಚಿಕೆಯ ಮಾಲೀಕತ್ವವನ್ನು ಒದಗಿಸುತ್ತದೆ.`Arc` ನಲ್ಲಿ [`clone`][clone] ಅನ್ನು ಪ್ರಾರಂಭಿಸುವುದರಿಂದ ಹೊಸ `Arc` ನಿದರ್ಶನವನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ, ಇದು ರಾಶಿಯ ಮೇಲಿನ `Arc` ನಂತೆ ಅದೇ ಹಂಚಿಕೆಯನ್ನು ಸೂಚಿಸುತ್ತದೆ, ಆದರೆ ಉಲ್ಲೇಖದ ಸಂಖ್ಯೆಯನ್ನು ಹೆಚ್ಚಿಸುತ್ತದೆ.
/// ನಿರ್ದಿಷ್ಟ ಹಂಚಿಕೆಯ ಕೊನೆಯ `Arc` ಪಾಯಿಂಟರ್ ನಾಶವಾದಾಗ, ಆ ಹಂಚಿಕೆಯಲ್ಲಿ ಸಂಗ್ರಹವಾಗಿರುವ ಮೌಲ್ಯವನ್ನು (ಇದನ್ನು ಸಾಮಾನ್ಯವಾಗಿ "inner value" ಎಂದು ಕರೆಯಲಾಗುತ್ತದೆ) ಕೈಬಿಡಲಾಗುತ್ತದೆ.
///
/// Rust ನಲ್ಲಿ ಹಂಚಿದ ಉಲ್ಲೇಖಗಳು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ರೂಪಾಂತರವನ್ನು ಅನುಮತಿಸುವುದಿಲ್ಲ, ಮತ್ತು `Arc` ಇದಕ್ಕೆ ಹೊರತಾಗಿಲ್ಲ: ನೀವು ಸಾಮಾನ್ಯವಾಗಿ `Arc` ಒಳಗೆ ಯಾವುದನ್ನಾದರೂ ಬದಲಾಯಿಸಬಹುದಾದ ಉಲ್ಲೇಖವನ್ನು ಪಡೆಯಲು ಸಾಧ್ಯವಿಲ್ಲ.ನೀವು `Arc` ಮೂಲಕ ರೂಪಾಂತರಗೊಳ್ಳಬೇಕಾದರೆ, [`Mutex`][mutex], [`RwLock`][rwlock], ಅಥವಾ [`Atomic`][atomic] ಪ್ರಕಾರಗಳಲ್ಲಿ ಒಂದನ್ನು ಬಳಸಿ.
///
/// ## ಥ್ರೆಡ್ ಸುರಕ್ಷತೆ
///
/// [`Rc<T>`] ಗಿಂತ ಭಿನ್ನವಾಗಿ, `Arc<T>` ಅದರ ಉಲ್ಲೇಖ ಎಣಿಕೆಗಾಗಿ ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬಳಸುತ್ತದೆ.ಇದರರ್ಥ ಅದು ಥ್ರೆಡ್-ಸುರಕ್ಷಿತವಾಗಿದೆ.ಅನಾನುಕೂಲವೆಂದರೆ ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳು ಸಾಮಾನ್ಯ ಮೆಮೊರಿ ಪ್ರವೇಶಕ್ಕಿಂತ ಹೆಚ್ಚು ದುಬಾರಿಯಾಗಿದೆ.ನೀವು ಎಳೆಗಳ ನಡುವೆ ಉಲ್ಲೇಖ-ಎಣಿಕೆ ಹಂಚಿಕೆಗಳನ್ನು ಹಂಚಿಕೊಳ್ಳದಿದ್ದರೆ, ಕಡಿಮೆ ಓವರ್ಹೆಡ್ಗಾಗಿ [`Rc<T>`] ಅನ್ನು ಪರಿಗಣಿಸಿ.
/// [`Rc<T>`] ಸುರಕ್ಷಿತ ಡೀಫಾಲ್ಟ್ ಆಗಿದೆ, ಏಕೆಂದರೆ ಎಳೆಗಳ ನಡುವೆ [`Rc<T>`] ಕಳುಹಿಸುವ ಯಾವುದೇ ಪ್ರಯತ್ನವನ್ನು ಕಂಪೈಲರ್ ಹಿಡಿಯುತ್ತದೆ.
/// ಆದಾಗ್ಯೂ, ಗ್ರಂಥಾಲಯ ಗ್ರಾಹಕರಿಗೆ ಹೆಚ್ಚಿನ ನಮ್ಯತೆಯನ್ನು ನೀಡುವ ಸಲುವಾಗಿ ಗ್ರಂಥಾಲಯವು `Arc<T>` ಅನ್ನು ಆಯ್ಕೆ ಮಾಡಬಹುದು.
///
/// `Arc<T>` `T` [`Send`] ಮತ್ತು [`Sync`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವವರೆಗೆ [`Send`] ಮತ್ತು [`Sync`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
/// ಥ್ರೆಡ್-ಸುರಕ್ಷಿತವಾಗಿಸಲು ನೀವು `Arc<T>` ನಲ್ಲಿ ಥ್ರೆಡ್-ಸುರಕ್ಷಿತವಲ್ಲದ `T` ಅನ್ನು ಏಕೆ ಹಾಕಬಾರದು?ಇದು ಮೊದಲಿಗೆ ಸ್ವಲ್ಪ ಪ್ರತಿ-ಅರ್ಥಗರ್ಭಿತವಾಗಬಹುದು: ಎಲ್ಲಾ ನಂತರ, `Arc<T>` ಥ್ರೆಡ್ ಸುರಕ್ಷತೆಯ ಅಂಶವಲ್ಲವೇ?ಮುಖ್ಯ ವಿಷಯವೆಂದರೆ: ಒಂದೇ ಡೇಟಾದ ಬಹು ಮಾಲೀಕತ್ವವನ್ನು ಹೊಂದಲು `Arc<T>` ಥ್ರೆಡ್ ಅನ್ನು ಸುರಕ್ಷಿತಗೊಳಿಸುತ್ತದೆ, ಆದರೆ ಇದು ಅದರ ಡೇಟಾಗೆ ಥ್ರೆಡ್ ಸುರಕ್ಷತೆಯನ್ನು ಸೇರಿಸುವುದಿಲ್ಲ.
///
/// `ಆರ್ಕ್ <` [`ರೆಫ್ಸೆಲ್ ಅನ್ನು ಪರಿಗಣಿಸಿ<T>`]`>`.
/// [`RefCell<T>`] [`Sync`] ಅಲ್ಲ, ಮತ್ತು `Arc<T>` ಯಾವಾಗಲೂ [`Send`] ಆಗಿದ್ದರೆ, `ಆರ್ಕ್ <` [`ರೆಫ್‌ಸೆಲ್<T>`]`>`ಹಾಗೆಯೇ ಇರುತ್ತದೆ.
/// ಆದರೆ ನಂತರ ನಮಗೆ ಸಮಸ್ಯೆ ಇದೆ:
/// [`RefCell<T>`] ಥ್ರೆಡ್ ಸುರಕ್ಷಿತವಲ್ಲ;ಇದು ಪರಮಾಣು ರಹಿತ ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬಳಸಿಕೊಂಡು ಎರವಲು ಪಡೆಯುವ ಸಂಖ್ಯೆಯನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡುತ್ತದೆ.
///
/// ಕೊನೆಯಲ್ಲಿ, ಇದರರ್ಥ ನೀವು `Arc<T>` ಅನ್ನು ಕೆಲವು ರೀತಿಯ [`std::sync`] ಪ್ರಕಾರದೊಂದಿಗೆ ಜೋಡಿಸಬೇಕಾಗಬಹುದು, ಸಾಮಾನ್ಯವಾಗಿ [`Mutex<T>`][mutex].
///
/// ## `Weak` ನೊಂದಿಗೆ ಚಕ್ರಗಳನ್ನು ಮುರಿಯುವುದು
///
/// [`downgrade`][downgrade] ವಿಧಾನವನ್ನು ಮಾಲೀಕತ್ವವಿಲ್ಲದ [`Weak`] ಪಾಯಿಂಟರ್ ರಚಿಸಲು ಬಳಸಬಹುದು.[`Weak`] ಪಾಯಿಂಟರ್ `Arc` ಗೆ [`ಅಪ್‌ಗ್ರೇಡ್`][ಅಪ್‌ಗ್ರೇಡ್] ಆಗಿರಬಹುದು, ಆದರೆ ಹಂಚಿಕೆಯಲ್ಲಿ ಸಂಗ್ರಹವಾಗಿರುವ ಮೌಲ್ಯವನ್ನು ಈಗಾಗಲೇ ಕೈಬಿಟ್ಟರೆ ಇದು [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
/// ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, `Weak` ಪಾಯಿಂಟರ್‌ಗಳು ಹಂಚಿಕೆಯೊಳಗಿನ ಮೌಲ್ಯವನ್ನು ಜೀವಂತವಾಗಿರಿಸುವುದಿಲ್ಲ;ಆದಾಗ್ಯೂ, ಅವರು ಹಂಚಿಕೆಯನ್ನು (ಮೌಲ್ಯದ ಹಿಮ್ಮೇಳ ಅಂಗಡಿ) ಜೀವಂತವಾಗಿರಿಸುತ್ತಾರೆ.
///
/// `Arc` ಪಾಯಿಂಟರ್‌ಗಳ ನಡುವಿನ ಚಕ್ರವನ್ನು ಎಂದಿಗೂ ಡಿಲೊಲೊಕೇಟ್ ಮಾಡಲಾಗುವುದಿಲ್ಲ.
/// ಈ ಕಾರಣಕ್ಕಾಗಿ, ಚಕ್ರಗಳನ್ನು ಮುರಿಯಲು [`Weak`] ಅನ್ನು ಬಳಸಲಾಗುತ್ತದೆ.ಉದಾಹರಣೆಗೆ, ಒಂದು ಮರವು ಪೋಷಕ ನೋಡ್‌ಗಳಿಂದ ಮಕ್ಕಳಿಗೆ ಬಲವಾದ `Arc` ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಹೊಂದಿರಬಹುದು ಮತ್ತು ಮಕ್ಕಳಿಂದ [`Weak`] ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ತಮ್ಮ ಪೋಷಕರಿಗೆ ಹಿಂತಿರುಗಿಸಬಹುದು.
///
/// # ಕ್ಲೋನಿಂಗ್ ಉಲ್ಲೇಖಗಳು
///
/// ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ ಉಲ್ಲೇಖ-ಎಣಿಸಿದ ಪಾಯಿಂಟರ್‌ನಿಂದ ಹೊಸ ಉಲ್ಲೇಖವನ್ನು ರಚಿಸುವುದು [`Arc<T>`][Arc] ಮತ್ತು [`Weak<T>`][Weak] ಗಾಗಿ ಜಾರಿಗೆ ತರಲಾದ `Clone` trait ಬಳಸಿ ಮಾಡಲಾಗುತ್ತದೆ.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // ಕೆಳಗಿನ ಎರಡು ಸಿಂಟ್ಯಾಕ್ಸ್‌ಗಳು ಸಮಾನವಾಗಿವೆ.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, ಮತ್ತು foo ಎಲ್ಲವೂ ಒಂದೇ ಮೆಮೊರಿ ಸ್ಥಳವನ್ನು ಸೂಚಿಸುವ ಚಾಪಗಳು
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` `T` ಗೆ ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಅಪನಗದೀಕರಣಗಳು ([`Deref`][deref] trait ಮೂಲಕ), ಆದ್ದರಿಂದ ನೀವು `Arc<T>` ಪ್ರಕಾರದ ಮೌಲ್ಯದ ಮೇಲೆ `T` ವಿಧಾನಗಳನ್ನು ಕರೆಯಬಹುದು.`ಟಿ` ವಿಧಾನಗಳೊಂದಿಗೆ ಹೆಸರು ಘರ್ಷಣೆಯನ್ನು ತಪ್ಪಿಸಲು, `Arc<T>` ನ ವಿಧಾನಗಳು ಸಂಬಂಧಿತ ಕಾರ್ಯಗಳಾಗಿವೆ, ಇದನ್ನು [fully qualified syntax] ಬಳಸಿ ಕರೆಯಲಾಗುತ್ತದೆ:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `ಆರ್ಕ್<T>`Clone` ನಂತಹ traits ನ ಅನುಷ್ಠಾನಗಳನ್ನು ಸಹ ಸಂಪೂರ್ಣ ಅರ್ಹ ಸಿಂಟ್ಯಾಕ್ಸ್ ಬಳಸಿ ಕರೆಯಬಹುದು.
/// ಕೆಲವು ಜನರು ಸಂಪೂರ್ಣ ಅರ್ಹ ಸಿಂಟ್ಯಾಕ್ಸ್ ಅನ್ನು ಬಳಸಲು ಬಯಸುತ್ತಾರೆ, ಆದರೆ ಇತರರು ವಿಧಾನ-ಕರೆ ಸಿಂಟ್ಯಾಕ್ಸ್ ಅನ್ನು ಬಳಸಲು ಬಯಸುತ್ತಾರೆ.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // ವಿಧಾನ-ಕರೆ ಸಿಂಟ್ಯಾಕ್ಸ್
/// let arc2 = arc.clone();
/// // ಸಂಪೂರ್ಣ ಅರ್ಹ ಸಿಂಟ್ಯಾಕ್ಸ್
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] `T` ಗೆ ಸ್ವಯಂ-ವಿರೂಪಗೊಳ್ಳುವುದಿಲ್ಲ, ಏಕೆಂದರೆ ಆಂತರಿಕ ಮೌಲ್ಯವನ್ನು ಈಗಾಗಲೇ ಕೈಬಿಡಲಾಗಿದೆ.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// ಎಳೆಗಳ ನಡುವೆ ಕೆಲವು ಬದಲಾಯಿಸಲಾಗದ ಡೇಟಾವನ್ನು ಹಂಚಿಕೊಳ್ಳಲಾಗುತ್ತಿದೆ:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// ನಾವು ** ಈ ಪರೀಕ್ಷೆಗಳನ್ನು ಇಲ್ಲಿ ನಡೆಸುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
// ಥ್ರೆಡ್ ಮುಖ್ಯ ಥ್ರೆಡ್ ಅನ್ನು ಮೀರಿಸಿದರೆ ಮತ್ತು ಅದೇ ಸಮಯದಲ್ಲಿ ನಿರ್ಗಮಿಸಿದರೆ (ಏನಾದರೂ ಡೆಡ್‌ಲಾಕ್‌ಗಳು) windows ಬಿಲ್ಡರ್‌ಗಳು ಅತೃಪ್ತರಾಗುತ್ತಾರೆ, ಆದ್ದರಿಂದ ನಾವು ಈ ಪರೀಕ್ಷೆಗಳನ್ನು ನಡೆಸದಿರುವ ಮೂಲಕ ಇದನ್ನು ಸಂಪೂರ್ಣವಾಗಿ ತಪ್ಪಿಸುತ್ತೇವೆ.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// ರೂಪಾಂತರಿತ [`AtomicUsize`] ಅನ್ನು ಹಂಚಿಕೊಳ್ಳಲಾಗುತ್ತಿದೆ:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// ಸಾಮಾನ್ಯವಾಗಿ ಉಲ್ಲೇಖ ಎಣಿಕೆಯ ಹೆಚ್ಚಿನ ಉದಾಹರಣೆಗಳಿಗಾಗಿ [`rc` documentation][rc_examples] ನೋಡಿ.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` ಇದು [`Arc`] ನ ಒಂದು ಆವೃತ್ತಿಯಾಗಿದ್ದು ಅದು ನಿರ್ವಹಿಸಿದ ಹಂಚಿಕೆಗೆ ಮಾಲೀಕತ್ವ ರಹಿತ ಉಲ್ಲೇಖವನ್ನು ಹೊಂದಿದೆ.
/// `Weak` ಪಾಯಿಂಟರ್‌ನಲ್ಲಿ [`upgrade`] ಗೆ ಕರೆ ಮಾಡುವ ಮೂಲಕ ಹಂಚಿಕೆಯನ್ನು ಪ್ರವೇಶಿಸಬಹುದು, ಅದು [`ಆಯ್ಕೆ`]`<`[`ಆರ್ಕ್`] `ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ<T>>`.
///
/// `Weak` ಉಲ್ಲೇಖವು ಮಾಲೀಕತ್ವದ ಕಡೆಗೆ ಎಣಿಸದ ಕಾರಣ, ಹಂಚಿಕೆಯಲ್ಲಿ ಸಂಗ್ರಹವಾಗಿರುವ ಮೌಲ್ಯವನ್ನು ಕೈಬಿಡುವುದನ್ನು ಇದು ತಡೆಯುವುದಿಲ್ಲ, ಮತ್ತು `Weak` ಸ್ವತಃ ಇನ್ನೂ ಇರುವ ಮೌಲ್ಯದ ಬಗ್ಗೆ ಯಾವುದೇ ಭರವಸೆ ನೀಡುವುದಿಲ್ಲ.
///
/// [`ಅಪ್‌ಗ್ರೇಡ್`] ಡಿ ಮಾಡಿದಾಗ ಅದು [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಬಹುದು.
/// ಆದಾಗ್ಯೂ, `Weak` ಉಲ್ಲೇಖ * ಹಂಚಿಕೆಯನ್ನು (ಬ್ಯಾಕಿಂಗ್ ಸ್ಟೋರ್) ಡಿಲೊಲೊಕೇಟ್ ಮಾಡುವುದನ್ನು ತಡೆಯುತ್ತದೆ.
///
/// `Weak` ಪಾಯಿಂಟರ್ ಅದರ ಆಂತರಿಕ ಮೌಲ್ಯವನ್ನು ಕೈಬಿಡುವುದನ್ನು ತಡೆಯದೆ [`Arc`] ನಿರ್ವಹಿಸುವ ಹಂಚಿಕೆಗೆ ತಾತ್ಕಾಲಿಕ ಉಲ್ಲೇಖವನ್ನು ಇರಿಸಲು ಉಪಯುಕ್ತವಾಗಿದೆ.
/// [`Arc`] ಪಾಯಿಂಟರ್‌ಗಳ ನಡುವಿನ ವೃತ್ತಾಕಾರದ ಉಲ್ಲೇಖಗಳನ್ನು ತಡೆಯಲು ಸಹ ಇದನ್ನು ಬಳಸಲಾಗುತ್ತದೆ, ಏಕೆಂದರೆ ಪರಸ್ಪರ ಮಾಲೀಕತ್ವದ ಉಲ್ಲೇಖಗಳು [`Arc`] ಅನ್ನು ಕೈಬಿಡಲು ಎಂದಿಗೂ ಅನುಮತಿಸುವುದಿಲ್ಲ.
/// ಉದಾಹರಣೆಗೆ, ಒಂದು ಮರವು ಪೋಷಕ ನೋಡ್‌ಗಳಿಂದ ಮಕ್ಕಳಿಗೆ ಬಲವಾದ [`Arc`] ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಹೊಂದಿರಬಹುದು ಮತ್ತು ಮಕ್ಕಳಿಂದ `Weak` ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಅವರ ಪೋಷಕರಿಗೆ ಹಿಂತಿರುಗಿಸಬಹುದು.
///
/// `Weak` ಪಾಯಿಂಟರ್ ಪಡೆಯುವ ವಿಶಿಷ್ಟ ಮಾರ್ಗವೆಂದರೆ [`Arc::downgrade`] ಗೆ ಕರೆ ಮಾಡುವುದು.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // ಎನ್ಯುಮ್‌ಗಳಲ್ಲಿ ಈ ಪ್ರಕಾರದ ಗಾತ್ರವನ್ನು ಅತ್ಯುತ್ತಮವಾಗಿಸಲು ಇದು ಎಕ್ಸ್‌00 ಎಕ್ಸ್ ಆಗಿದೆ, ಆದರೆ ಇದು ಮಾನ್ಯ ಪಾಯಿಂಟರ್ ಆಗಿರಬೇಕಾಗಿಲ್ಲ.
    //
    // `Weak::new` ಇದನ್ನು `usize::MAX` ಗೆ ಹೊಂದಿಸುತ್ತದೆ ಇದರಿಂದ ರಾಶಿಯಲ್ಲಿ ಜಾಗವನ್ನು ನಿಯೋಜಿಸುವ ಅಗತ್ಯವಿಲ್ಲ.
    // ನಿಜವಾದ ಪಾಯಿಂಟರ್ ಎಂದಿಗೂ ಹೊಂದಿರದ ಮೌಲ್ಯವಲ್ಲ ಏಕೆಂದರೆ ಆರ್‌ಸಿಬಾಕ್ಸ್ ಕನಿಷ್ಠ 2 ಹೊಂದಾಣಿಕೆಯನ್ನು ಹೊಂದಿದೆ.
    // `T: Sized` ಇದ್ದಾಗ ಮಾತ್ರ ಇದು ಸಾಧ್ಯ;ಗಾತ್ರೀಕರಿಸದ `T` ಎಂದಿಗೂ ತೂಗಾಡುವುದಿಲ್ಲ.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// ಸಂಭವನೀಯ ಕ್ಷೇತ್ರ-ಮರುಕ್ರಮಗೊಳಿಸುವಿಕೆಯ ವಿರುದ್ಧ ಇದು repr(C) ರಿಂದ future-ಪ್ರೂಫ್ ಆಗಿದೆ, ಇದು ಸುರಕ್ಷಿತ [into|from]_raw() ಟ್ರಾನ್ಸ್‌ಮ್ಯೂಟಬಲ್ ಆಂತರಿಕ ಪ್ರಕಾರಗಳಿಗೆ ಅಡ್ಡಿಪಡಿಸುತ್ತದೆ.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // usize::MAX ಮೌಲ್ಯವು ತಾತ್ಕಾಲಿಕವಾಗಿ "locking" ಗಾಗಿ ದುರ್ಬಲ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಅಪ್‌ಗ್ರೇಡ್ ಮಾಡುವ ಅಥವಾ ಬಲವಾದವುಗಳನ್ನು ಡೌನ್‌ಗ್ರೇಡ್ ಮಾಡುವ ಸಾಮರ್ಥ್ಯಕ್ಕಾಗಿ ಸೆಂಟಿನೆಲ್ ಆಗಿ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ;`make_mut` ಮತ್ತು `get_mut` ನಲ್ಲಿ ರೇಸ್ ತಪ್ಪಿಸಲು ಇದನ್ನು ಬಳಸಲಾಗುತ್ತದೆ.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// ಹೊಸ `Arc<T>` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // ದುರ್ಬಲ ಪಾಯಿಂಟರ್ ಎಣಿಕೆಯನ್ನು 1 ಎಂದು ಪ್ರಾರಂಭಿಸಿ, ಇದು ಎಲ್ಲಾ ಬಲವಾದ ಪಾಯಿಂಟರ್‌ಗಳು (kinda) ಹೊಂದಿರುವ ದುರ್ಬಲ ಪಾಯಿಂಟರ್ ಆಗಿದೆ, ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ std/rc.rs ನೋಡಿ
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// ಸ್ವತಃ ದುರ್ಬಲ ಉಲ್ಲೇಖವನ್ನು ಬಳಸಿಕೊಂಡು ಹೊಸ `Arc<T>` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    /// ಈ ಕಾರ್ಯವು ಹಿಂದಿರುಗುವ ಮೊದಲು ದುರ್ಬಲ ಉಲ್ಲೇಖವನ್ನು ಅಪ್‌ಗ್ರೇಡ್ ಮಾಡಲು ಪ್ರಯತ್ನಿಸುವುದರಿಂದ `None` ಮೌಲ್ಯಕ್ಕೆ ಕಾರಣವಾಗುತ್ತದೆ.
    /// ಆದಾಗ್ಯೂ, ದುರ್ಬಲ ಉಲ್ಲೇಖವನ್ನು ಮುಕ್ತವಾಗಿ ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮಾಡಬಹುದು ಮತ್ತು ನಂತರದ ಸಮಯದಲ್ಲಿ ಬಳಕೆಗಾಗಿ ಸಂಗ್ರಹಿಸಬಹುದು.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // ಒಂದೇ ದುರ್ಬಲ ಉಲ್ಲೇಖದೊಂದಿಗೆ "uninitialized" ಸ್ಥಿತಿಯಲ್ಲಿ ಒಳಭಾಗವನ್ನು ನಿರ್ಮಿಸಿ.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // ದುರ್ಬಲ ಪಾಯಿಂಟರ್‌ನ ಮಾಲೀಕತ್ವವನ್ನು ನಾವು ಬಿಟ್ಟುಕೊಡುವುದಿಲ್ಲ ಎಂಬುದು ಮುಖ್ಯ, ಇಲ್ಲದಿದ್ದರೆ `data_fn` ಹಿಂದಿರುಗುವ ಹೊತ್ತಿಗೆ ಮೆಮೊರಿಯನ್ನು ಮುಕ್ತಗೊಳಿಸಬಹುದು.
        // ನಾವು ನಿಜವಾಗಿಯೂ ಮಾಲೀಕತ್ವವನ್ನು ರವಾನಿಸಲು ಬಯಸಿದರೆ, ನಾವು ನಮಗಾಗಿ ಹೆಚ್ಚುವರಿ ದುರ್ಬಲ ಪಾಯಿಂಟರ್ ಅನ್ನು ರಚಿಸಬಹುದು, ಆದರೆ ಇದು ದುರ್ಬಲ ಉಲ್ಲೇಖ ಎಣಿಕೆಗೆ ಹೆಚ್ಚುವರಿ ನವೀಕರಣಗಳಿಗೆ ಕಾರಣವಾಗುತ್ತದೆ, ಅದು ಅಗತ್ಯವಿಲ್ಲದಿರಬಹುದು.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // ಈಗ ನಾವು ಆಂತರಿಕ ಮೌಲ್ಯವನ್ನು ಸರಿಯಾಗಿ ಪ್ರಾರಂಭಿಸಬಹುದು ಮತ್ತು ನಮ್ಮ ದುರ್ಬಲ ಉಲ್ಲೇಖವನ್ನು ಬಲವಾದ ಉಲ್ಲೇಖವಾಗಿ ಪರಿವರ್ತಿಸಬಹುದು.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // ಡೇಟಾ ಕ್ಷೇತ್ರಕ್ಕೆ ಮೇಲಿನ ಬರಹವು ಶೂನ್ಯೇತರ ಬಲವಾದ ಎಣಿಕೆಯನ್ನು ಗಮನಿಸುವ ಯಾವುದೇ ಎಳೆಗಳಿಗೆ ಗೋಚರಿಸಬೇಕು.
            // ಆದ್ದರಿಂದ `Weak::upgrade` ನಲ್ಲಿ `compare_exchange_weak` ನೊಂದಿಗೆ ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡಲು ನಮಗೆ ಕನಿಷ್ಠ "Release" ಆದೇಶದ ಅಗತ್ಯವಿದೆ.
            //
            // "Acquire" ಆದೇಶ ಅಗತ್ಯವಿಲ್ಲ.
            // `data_fn` ನ ಸಂಭವನೀಯ ನಡವಳಿಕೆಗಳನ್ನು ಪರಿಗಣಿಸುವಾಗ, ನವೀಕರಿಸಲಾಗದ `Weak` ಅನ್ನು ಉಲ್ಲೇಖಿಸಿ ಅದು ಏನು ಮಾಡಬಹುದೆಂದು ನಾವು ನೋಡಬೇಕಾಗಿದೆ:
            //
            // - ಇದು `Weak` ಅನ್ನು * ಕ್ಲೋನ್ ಮಾಡಬಹುದು, ದುರ್ಬಲ ಉಲ್ಲೇಖ ಸಂಖ್ಯೆಯನ್ನು ಹೆಚ್ಚಿಸುತ್ತದೆ.
            // - ಅದು ಆ ತದ್ರೂಪುಗಳನ್ನು ಬಿಡಬಹುದು, ದುರ್ಬಲ ಉಲ್ಲೇಖ ಸಂಖ್ಯೆಯನ್ನು ಕಡಿಮೆ ಮಾಡುತ್ತದೆ (ಆದರೆ ಎಂದಿಗೂ ಶೂನ್ಯಕ್ಕೆ).
            //
            // ಈ ಅಡ್ಡಪರಿಣಾಮಗಳು ಯಾವುದೇ ರೀತಿಯಲ್ಲಿ ನಮ್ಮ ಮೇಲೆ ಪರಿಣಾಮ ಬೀರುವುದಿಲ್ಲ ಮತ್ತು ಸುರಕ್ಷಿತ ಕೋಡ್‌ನಿಂದ ಮಾತ್ರ ಬೇರೆ ಯಾವುದೇ ಅಡ್ಡಪರಿಣಾಮಗಳು ಸಾಧ್ಯವಿಲ್ಲ.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // ಬಲವಾದ ಉಲ್ಲೇಖಗಳು ಒಟ್ಟಾಗಿ ಹಂಚಿಕೆಯ ದುರ್ಬಲ ಉಲ್ಲೇಖವನ್ನು ಹೊಂದಿರಬೇಕು, ಆದ್ದರಿಂದ ನಮ್ಮ ಹಳೆಯ ದುರ್ಬಲ ಉಲ್ಲೇಖಕ್ಕಾಗಿ ವಿನಾಶಕವನ್ನು ಚಲಾಯಿಸಬೇಡಿ.
        //
        mem::forget(weak);
        strong
    }

    /// ಪ್ರಾರಂಭಿಸದ ವಿಷಯಗಳೊಂದಿಗೆ ಹೊಸ `Arc` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ಮುಂದೂಡಲ್ಪಟ್ಟ ಪ್ರಾರಂಭ:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// ಮೆಮೊರಿಯನ್ನು `0` ಬೈಟ್‌ಗಳಿಂದ ತುಂಬಿಸುವುದರೊಂದಿಗೆ, ಪ್ರಾರಂಭಿಸದ ವಿಷಯಗಳೊಂದಿಗೆ ಹೊಸ `Arc` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    ///
    ///
    /// ಈ ವಿಧಾನದ ಸರಿಯಾದ ಮತ್ತು ತಪ್ಪಾದ ಬಳಕೆಯ ಉದಾಹರಣೆಗಳಿಗಾಗಿ [`MaybeUninit::zeroed`][zeroed] ನೋಡಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// ಹೊಸ `Pin<Arc<T>>` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    /// `T` `Unpin` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸದಿದ್ದರೆ, `data` ಅನ್ನು ಮೆಮೊರಿಯಲ್ಲಿ ಪಿನ್ ಮಾಡಲಾಗುತ್ತದೆ ಮತ್ತು ಸರಿಸಲು ಸಾಧ್ಯವಾಗುವುದಿಲ್ಲ.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// ಹೊಸ `Arc<T>` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ, ಹಂಚಿಕೆ ವಿಫಲವಾದರೆ ದೋಷವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // ದುರ್ಬಲ ಪಾಯಿಂಟರ್ ಎಣಿಕೆಯನ್ನು 1 ಎಂದು ಪ್ರಾರಂಭಿಸಿ, ಇದು ಎಲ್ಲಾ ಬಲವಾದ ಪಾಯಿಂಟರ್‌ಗಳು (kinda) ಹೊಂದಿರುವ ದುರ್ಬಲ ಪಾಯಿಂಟರ್ ಆಗಿದೆ, ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ std/rc.rs ನೋಡಿ
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// ಪ್ರಾರಂಭಿಸದ ವಿಷಯಗಳೊಂದಿಗೆ ಹೊಸ `Arc` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ, ಹಂಚಿಕೆ ವಿಫಲವಾದರೆ ದೋಷವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // ಮುಂದೂಡಲ್ಪಟ್ಟ ಪ್ರಾರಂಭ:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// ಪ್ರಾರಂಭಿಸದ ವಿಷಯಗಳೊಂದಿಗೆ ಹೊಸ `Arc` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ, ಮೆಮೊರಿಯು `0` ಬೈಟ್‌ಗಳಿಂದ ತುಂಬಿರುತ್ತದೆ, ಹಂಚಿಕೆ ವಿಫಲವಾದರೆ ದೋಷವನ್ನು ನೀಡುತ್ತದೆ.
    ///
    ///
    /// ಈ ವಿಧಾನದ ಸರಿಯಾದ ಮತ್ತು ತಪ್ಪಾದ ಬಳಕೆಯ ಉದಾಹರಣೆಗಳಿಗಾಗಿ [`MaybeUninit::zeroed`][zeroed] ನೋಡಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// `Arc` ನಿಖರವಾಗಿ ಒಂದು ಬಲವಾದ ಉಲ್ಲೇಖವನ್ನು ಹೊಂದಿದ್ದರೆ ಆಂತರಿಕ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಇಲ್ಲದಿದ್ದರೆ, ರವಾನಿಸಲಾದ ಅದೇ `Arc` ನೊಂದಿಗೆ [`Err`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    ///
    /// ಅತ್ಯುತ್ತಮ ದುರ್ಬಲ ಉಲ್ಲೇಖಗಳು ಇದ್ದರೂ ಇದು ಯಶಸ್ವಿಯಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // ಸೂಚ್ಯ ಬಲವಾದ-ದುರ್ಬಲ ಉಲ್ಲೇಖವನ್ನು ಸ್ವಚ್ up ಗೊಳಿಸಲು ದುರ್ಬಲ ಪಾಯಿಂಟರ್ ಮಾಡಿ
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// ಪ್ರಾರಂಭಿಸದ ವಿಷಯಗಳೊಂದಿಗೆ ಹೊಸ ಪರಮಾಣು ಉಲ್ಲೇಖ-ಎಣಿಕೆಯ ಸ್ಲೈಸ್ ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ಮುಂದೂಡಲ್ಪಟ್ಟ ಪ್ರಾರಂಭ:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// ಹೊಸ ಪರಮಾಣು ಉಲ್ಲೇಖ-ಎಣಿಕೆಯ ಸ್ಲೈಸ್ ಅನ್ನು ಪ್ರಾರಂಭಿಸದ ವಿಷಯಗಳೊಂದಿಗೆ ನಿರ್ಮಿಸುತ್ತದೆ, ಮೆಮೊರಿಯನ್ನು `0` ಬೈಟ್‌ಗಳಿಂದ ತುಂಬಿಸಲಾಗುತ್ತದೆ.
    ///
    ///
    /// ಈ ವಿಧಾನದ ಸರಿಯಾದ ಮತ್ತು ತಪ್ಪಾದ ಬಳಕೆಯ ಉದಾಹರಣೆಗಳಿಗಾಗಿ [`MaybeUninit::zeroed`][zeroed] ನೋಡಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// `Arc<T>` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] ನಂತೆ, ಆಂತರಿಕ ಮೌಲ್ಯವು ನಿಜವಾಗಿಯೂ ಪ್ರಾರಂಭಿಕ ಸ್ಥಿತಿಯಲ್ಲಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸುವುದು ಕರೆ ಮಾಡುವವರಿಗೆ ಬಿಟ್ಟದ್ದು.
    ///
    /// ವಿಷಯವನ್ನು ಇನ್ನೂ ಸಂಪೂರ್ಣವಾಗಿ ಪ್ರಾರಂಭಿಸದಿದ್ದಾಗ ಇದನ್ನು ಕರೆಯುವುದು ತಕ್ಷಣದ ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ಮುಂದೂಡಲ್ಪಟ್ಟ ಪ್ರಾರಂಭ:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// `Arc<[T]>` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] ನಂತೆ, ಆಂತರಿಕ ಮೌಲ್ಯವು ನಿಜವಾಗಿಯೂ ಪ್ರಾರಂಭಿಕ ಸ್ಥಿತಿಯಲ್ಲಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸುವುದು ಕರೆ ಮಾಡುವವರಿಗೆ ಬಿಟ್ಟದ್ದು.
    ///
    /// ವಿಷಯವನ್ನು ಇನ್ನೂ ಸಂಪೂರ್ಣವಾಗಿ ಪ್ರಾರಂಭಿಸದಿದ್ದಾಗ ಇದನ್ನು ಕರೆಯುವುದು ತಕ್ಷಣದ ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ಮುಂದೂಡಲ್ಪಟ್ಟ ಪ್ರಾರಂಭ:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// `Arc` ಅನ್ನು ಬಳಸುತ್ತದೆ, ಸುತ್ತಿದ ಪಾಯಿಂಟರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಮೆಮೊರಿ ಸೋರಿಕೆಯನ್ನು ತಪ್ಪಿಸಲು ಪಾಯಿಂಟರ್ ಅನ್ನು [`Arc::from_raw`] ಬಳಸಿ ಮತ್ತೆ `Arc` ಗೆ ಪರಿವರ್ತಿಸಬೇಕು.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// ಡೇಟಾಗೆ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಒದಗಿಸುತ್ತದೆ.
    ///
    /// ಎಣಿಕೆಗಳು ಯಾವುದೇ ರೀತಿಯಲ್ಲಿ ಪರಿಣಾಮ ಬೀರುವುದಿಲ್ಲ ಮತ್ತು `Arc` ಅನ್ನು ಸೇವಿಸುವುದಿಲ್ಲ.
    /// `Arc` ನಲ್ಲಿ ಬಲವಾದ ಎಣಿಕೆಗಳು ಇರುವವರೆಗೂ ಪಾಯಿಂಟರ್ ಮಾನ್ಯವಾಗಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // ಸುರಕ್ಷತೆ: ಇದು Deref::deref ಅಥವಾ RcBoxPtr::inner ಮೂಲಕ ಹೋಗಲು ಸಾಧ್ಯವಿಲ್ಲ ಏಕೆಂದರೆ
        // ಉದಾ. raw/mut ಮೂಲವನ್ನು ಉಳಿಸಿಕೊಳ್ಳಲು ಇದು ಅಗತ್ಯವಾಗಿರುತ್ತದೆ
        // `get_mut` `from_raw` ಮೂಲಕ Rc ಅನ್ನು ಮರುಪಡೆಯಲಾದ ನಂತರ ಪಾಯಿಂಟರ್ ಮೂಲಕ ಬರೆಯಬಹುದು.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ನಿಂದ `Arc<T>` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    ///
    /// ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಅನ್ನು ಈ ಹಿಂದೆ [`Arc<U>::into_raw`][into_raw] ಗೆ ಕರೆಯಿಂದ ಹಿಂತಿರುಗಿಸಿರಬೇಕು, ಅಲ್ಲಿ `U` `T` ನಂತೆಯೇ ಒಂದೇ ಗಾತ್ರ ಮತ್ತು ಜೋಡಣೆಯನ್ನು ಹೊಂದಿರಬೇಕು.
    /// `U` `T` ಆಗಿದ್ದರೆ ಇದು ಕ್ಷುಲ್ಲಕ ಸತ್ಯ.
    /// `U` `T` ಅಲ್ಲ ಆದರೆ ಒಂದೇ ಗಾತ್ರ ಮತ್ತು ಜೋಡಣೆಯನ್ನು ಹೊಂದಿದ್ದರೆ, ಇದು ಮೂಲತಃ ವಿಭಿನ್ನ ಪ್ರಕಾರಗಳ ಉಲ್ಲೇಖಗಳನ್ನು ರವಾನಿಸುವಂತಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    /// ಈ ಸಂದರ್ಭದಲ್ಲಿ ಯಾವ ನಿರ್ಬಂಧಗಳು ಅನ್ವಯವಾಗುತ್ತವೆ ಎಂಬುದರ ಕುರಿತು ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ [`mem::transmute`][transmute] ನೋಡಿ.
    ///
    /// `from_raw` ನ ಬಳಕೆದಾರರು `T` ನ ನಿರ್ದಿಷ್ಟ ಮೌಲ್ಯವನ್ನು ಒಮ್ಮೆ ಮಾತ್ರ ಕೈಬಿಡಲಾಗಿದೆಯೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು.
    ///
    /// ಈ ಕಾರ್ಯವು ಅಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ಹಿಂದಿರುಗಿದ `Arc<T>` ಅನ್ನು ಎಂದಿಗೂ ಪ್ರವೇಶಿಸದಿದ್ದರೂ ಸಹ, ಅಸಮರ್ಪಕ ಬಳಕೆಯು ಮೆಮೊರಿ ಅಸುರಕ್ಷಿತತೆಗೆ ಕಾರಣವಾಗಬಹುದು.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // ಸೋರಿಕೆಯನ್ನು ತಡೆಗಟ್ಟಲು `Arc` ಗೆ ಹಿಂತಿರುಗಿ.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Arc::from_raw(x_ptr)` ಗೆ ಹೆಚ್ಚಿನ ಕರೆಗಳು ಮೆಮೊರಿ-ಅಸುರಕ್ಷಿತವಾಗಿರುತ್ತದೆ.
    /// }
    ///
    /// // `x` ಮೇಲಿನ ವ್ಯಾಪ್ತಿಯಿಂದ ಹೊರಬಂದಾಗ ಮೆಮೊರಿಯನ್ನು ಮುಕ್ತಗೊಳಿಸಲಾಯಿತು, ಆದ್ದರಿಂದ `x_ptr` ಈಗ ತೂಗಾಡುತ್ತಿದೆ!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // ಮೂಲ ಆರ್ಕ್ಇನ್ನರ್ ಅನ್ನು ಕಂಡುಹಿಡಿಯಲು ಆಫ್‌ಸೆಟ್ ಅನ್ನು ಹಿಮ್ಮುಖಗೊಳಿಸಿ.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// ಈ ಹಂಚಿಕೆಗೆ ಹೊಸ [`Weak`] ಪಾಯಿಂಟರ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // ಈ ವಿಶ್ರಾಂತಿ ಸರಿ ಏಕೆಂದರೆ ನಾವು ಕೆಳಗಿನ ಸಿಎಎಸ್‌ನಲ್ಲಿನ ಮೌಲ್ಯವನ್ನು ಪರಿಶೀಲಿಸುತ್ತಿದ್ದೇವೆ.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // ದುರ್ಬಲ ಕೌಂಟರ್ ಪ್ರಸ್ತುತ "locked" ಆಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸಿ;ಹಾಗಿದ್ದಲ್ಲಿ, ಸ್ಪಿನ್ ಮಾಡಿ.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: ಈ ಕೋಡ್ ಪ್ರಸ್ತುತ ಉಕ್ಕಿ ಹರಿಯುವ ಸಾಧ್ಯತೆಯನ್ನು ನಿರ್ಲಕ್ಷಿಸುತ್ತದೆ
            // usize::MAX ಗೆ;ಸಾಮಾನ್ಯವಾಗಿ ಉಕ್ಕಿ ಹರಿಯುವುದನ್ನು ಎದುರಿಸಲು ಆರ್ಸಿ ಮತ್ತು ಆರ್ಕ್ ಎರಡನ್ನೂ ಸರಿಹೊಂದಿಸಬೇಕಾಗುತ್ತದೆ.
            //

            // Clone() ಯಂತಲ್ಲದೆ, `is_unique` ನಿಂದ ಬರುವ ಬರಹದೊಂದಿಗೆ ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡಲು ಇದು ಅಕ್ವೈರ್ ರೀಡ್ ಆಗಿರಬೇಕು, ಇದರಿಂದಾಗಿ ಈ ಬರಹಕ್ಕೆ ಮುಂಚಿನ ಘಟನೆಗಳು ಈ ಓದುವ ಮೊದಲು ಸಂಭವಿಸುತ್ತವೆ.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // ನಾವು ತೂಗಾಡುತ್ತಿರುವ ದುರ್ಬಲತೆಯನ್ನು ರಚಿಸುವುದಿಲ್ಲ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// ಈ ಹಂಚಿಕೆಗೆ [`Weak`] ಪಾಯಿಂಟರ್‌ಗಳ ಸಂಖ್ಯೆಯನ್ನು ಪಡೆಯುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// ಈ ವಿಧಾನವು ಸ್ವತಃ ಸುರಕ್ಷಿತವಾಗಿದೆ, ಆದರೆ ಅದನ್ನು ಸರಿಯಾಗಿ ಬಳಸುವುದರಿಂದ ಹೆಚ್ಚುವರಿ ಕಾಳಜಿಯ ಅಗತ್ಯವಿರುತ್ತದೆ.
    /// ಮತ್ತೊಂದು ಥ್ರೆಡ್ ಯಾವುದೇ ಸಮಯದಲ್ಲಿ ದುರ್ಬಲ ಎಣಿಕೆಯನ್ನು ಬದಲಾಯಿಸಬಹುದು, ಈ ವಿಧಾನವನ್ನು ಕರೆಯುವುದು ಮತ್ತು ಫಲಿತಾಂಶದ ಮೇಲೆ ಕಾರ್ಯನಿರ್ವಹಿಸುವುದು ಸೇರಿದಂತೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // ಈ ಪ್ರತಿಪಾದನೆಯು ನಿರ್ಣಾಯಕವಾಗಿದೆ ಏಕೆಂದರೆ ನಾವು ಎಳೆಗಳ ನಡುವೆ `Arc` ಅಥವಾ `Weak` ಅನ್ನು ಹಂಚಿಕೊಂಡಿಲ್ಲ.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // ಪ್ರಸ್ತುತ ದುರ್ಬಲ ಎಣಿಕೆ ಲಾಕ್ ಆಗಿದ್ದರೆ, ಲಾಕ್ ತೆಗೆದುಕೊಳ್ಳುವ ಮೊದಲು ಎಣಿಕೆಯ ಮೌಲ್ಯವು 0 ಆಗಿತ್ತು.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// ಈ ಹಂಚಿಕೆಗೆ ಬಲವಾದ (`Arc`) ಪಾಯಿಂಟರ್‌ಗಳ ಸಂಖ್ಯೆಯನ್ನು ಪಡೆಯುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// ಈ ವಿಧಾನವು ಸ್ವತಃ ಸುರಕ್ಷಿತವಾಗಿದೆ, ಆದರೆ ಅದನ್ನು ಸರಿಯಾಗಿ ಬಳಸುವುದರಿಂದ ಹೆಚ್ಚುವರಿ ಕಾಳಜಿಯ ಅಗತ್ಯವಿರುತ್ತದೆ.
    /// ಮತ್ತೊಂದು ಥ್ರೆಡ್ ಈ ವಿಧಾನವನ್ನು ಕರೆಯುವುದು ಮತ್ತು ಫಲಿತಾಂಶದ ಮೇಲೆ ಕಾರ್ಯನಿರ್ವಹಿಸುವುದು ಸೇರಿದಂತೆ ಯಾವುದೇ ಸಮಯದಲ್ಲಿ ಬಲವಾದ ಎಣಿಕೆಯನ್ನು ಬದಲಾಯಿಸಬಹುದು.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // ಈ ಸಮರ್ಥನೆಯು ನಿರ್ಣಾಯಕವಾಗಿದೆ ಏಕೆಂದರೆ ನಾವು ಎಳೆಗಳ ನಡುವೆ `Arc` ಅನ್ನು ಹಂಚಿಕೊಂಡಿಲ್ಲ.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// ಒದಗಿಸಿದ ಪಾಯಿಂಟರ್‌ಗೆ ಸಂಬಂಧಿಸಿದ `Arc<T>` ನಲ್ಲಿ ಬಲವಾದ ಉಲ್ಲೇಖ ಸಂಖ್ಯೆಯನ್ನು ಒಂದರಿಂದ ಹೆಚ್ಚಿಸುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// ಪಾಯಿಂಟರ್ ಅನ್ನು `Arc::into_raw` ಮೂಲಕ ಪಡೆಯಬೇಕು ಮತ್ತು ಸಂಬಂಧಿತ `Arc` ನಿದರ್ಶನವು ಮಾನ್ಯವಾಗಿರಬೇಕು (ಅಂದರೆ
    /// ಈ ವಿಧಾನದ ಅವಧಿಗೆ ಬಲವಾದ ಎಣಿಕೆ ಕನಿಷ್ಠ 1 ಆಗಿರಬೇಕು.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // ಈ ಸಮರ್ಥನೆಯು ನಿರ್ಣಾಯಕವಾಗಿದೆ ಏಕೆಂದರೆ ನಾವು ಎಳೆಗಳ ನಡುವೆ `Arc` ಅನ್ನು ಹಂಚಿಕೊಂಡಿಲ್ಲ.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // ಆರ್ಕ್ ಅನ್ನು ಉಳಿಸಿಕೊಳ್ಳಿ, ಆದರೆ ಹಸ್ತಚಾಲಿತವಾಗಿ ಡ್ರಾಪ್ ಮಾಡುವ ಮೂಲಕ ರಿಫ್ಕೌಂಟ್ ಅನ್ನು ಸ್ಪರ್ಶಿಸಬೇಡಿ
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // ಈಗ ರಿಫ್ಕೌಂಟ್ ಹೆಚ್ಚಿಸಿ, ಆದರೆ ಹೊಸ ರಿಫ್ಕೌಂಟ್ ಅನ್ನು ಬಿಡಬೇಡಿ
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// ಒದಗಿಸಿದ ಪಾಯಿಂಟರ್‌ಗೆ ಸಂಬಂಧಿಸಿದ `Arc<T>` ನಲ್ಲಿನ ಬಲವಾದ ಉಲ್ಲೇಖ ಸಂಖ್ಯೆಯನ್ನು ಒಂದರಿಂದ ಕಡಿಮೆ ಮಾಡುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// ಪಾಯಿಂಟರ್ ಅನ್ನು `Arc::into_raw` ಮೂಲಕ ಪಡೆಯಬೇಕು ಮತ್ತು ಸಂಬಂಧಿತ `Arc` ನಿದರ್ಶನವು ಮಾನ್ಯವಾಗಿರಬೇಕು (ಅಂದರೆ
    /// ಈ ವಿಧಾನವನ್ನು ಪ್ರಾರಂಭಿಸುವಾಗ ಬಲವಾದ ಎಣಿಕೆ ಕನಿಷ್ಠ 1 ಆಗಿರಬೇಕು.
    /// ಅಂತಿಮ `Arc` ಮತ್ತು ಹಿಮ್ಮೇಳ ಸಂಗ್ರಹಣೆಯನ್ನು ಬಿಡುಗಡೆ ಮಾಡಲು ಈ ವಿಧಾನವನ್ನು ಬಳಸಬಹುದು, ಆದರೆ ಅಂತಿಮ `Arc` ಬಿಡುಗಡೆಯಾದ ನಂತರ ** ಅನ್ನು ಕರೆಯಬಾರದು.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // ಆ ಸಮರ್ಥನೆಗಳು ನಿರ್ಣಾಯಕವಾಗಿವೆ ಏಕೆಂದರೆ ನಾವು `Arc` ಅನ್ನು ಎಳೆಗಳ ನಡುವೆ ಹಂಚಿಕೊಂಡಿಲ್ಲ.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // ಈ ಅಸುರಕ್ಷಿತತೆಯು ಸರಿಯಾಗಿದೆ ಏಕೆಂದರೆ ಈ ಚಾಪವು ಜೀವಂತವಾಗಿರುವಾಗ ಆಂತರಿಕ ಪಾಯಿಂಟರ್ ಮಾನ್ಯವಾಗಿದೆ ಎಂದು ನಮಗೆ ಖಾತ್ರಿಯಿದೆ.
        // ಇದಲ್ಲದೆ, `ArcInner` ರಚನೆಯು ಸ್ವತಃ `Sync` ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ ಏಕೆಂದರೆ ಆಂತರಿಕ ಡೇಟಾವು `Sync` ಆಗಿದೆ, ಆದ್ದರಿಂದ ನಾವು ಈ ವಿಷಯಗಳಿಗೆ ಬದಲಾಯಿಸಲಾಗದ ಪಾಯಿಂಟರ್ ಅನ್ನು ನೀಡುತ್ತಿದ್ದೇವೆ.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // `drop` ನ ಇನ್ಲೈನ್ ಮಾಡದ ಭಾಗ.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // ಬಾಕ್ಸ್ ಹಂಚಿಕೆಯನ್ನು ನಾವು ಮುಕ್ತಗೊಳಿಸದಿದ್ದರೂ ಸಹ, ಈ ಸಮಯದಲ್ಲಿ ಡೇಟಾವನ್ನು ನಾಶಮಾಡಿ (ಇನ್ನೂ ದುರ್ಬಲ ಪಾಯಿಂಟರ್‌ಗಳು ಸುತ್ತಲೂ ಇರಬಹುದು).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // ಎಲ್ಲಾ ಬಲವಾದ ಉಲ್ಲೇಖಗಳಿಂದ ಒಟ್ಟಾಗಿ ಹೊಂದಿರುವ ದುರ್ಬಲ ರೆಫ್ ಅನ್ನು ಬಿಡಿ
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// ಎರಡು `ಆರ್ಕ್'ಗಳು ಒಂದೇ ಹಂಚಿಕೆಗೆ ಸೂಚಿಸಿದರೆ ([`ptr::eq`] ಗೆ ಹೋಲುವ ಧಾಟಿಯಲ್ಲಿ) `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// ಮೌಲ್ಯವು ವಿನ್ಯಾಸವನ್ನು ಒದಗಿಸಿರುವ ಸಂಭಾವ್ಯ-ಗಾತ್ರದ ಆಂತರಿಕ ಮೌಲ್ಯಕ್ಕೆ ಸಾಕಷ್ಟು ಸ್ಥಳಾವಕಾಶದೊಂದಿಗೆ `ArcInner<T>` ಅನ್ನು ನಿಯೋಜಿಸುತ್ತದೆ.
    ///
    /// `mem_to_arcinner` ಕಾರ್ಯವನ್ನು ಡೇಟಾ ಪಾಯಿಂಟರ್‌ನೊಂದಿಗೆ ಕರೆಯಲಾಗುತ್ತದೆ ಮತ್ತು `ArcInner<T>` ಗಾಗಿ ಒಂದು (ಸಂಭಾವ್ಯ ಕೊಬ್ಬು)-ಪಾಯಿಂಟರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸಬೇಕು.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // ಕೊಟ್ಟಿರುವ ಮೌಲ್ಯ ವಿನ್ಯಾಸವನ್ನು ಬಳಸಿಕೊಂಡು ವಿನ್ಯಾಸವನ್ನು ಲೆಕ್ಕಹಾಕಿ.
        // ಹಿಂದೆ, `&*(ptr as* const ArcInner<T>)` ಅಭಿವ್ಯಕ್ತಿಯಲ್ಲಿ ವಿನ್ಯಾಸವನ್ನು ಲೆಕ್ಕಹಾಕಲಾಗಿತ್ತು, ಆದರೆ ಇದು ತಪ್ಪಾಗಿ ವಿನ್ಯಾಸಗೊಳಿಸಲಾದ ಉಲ್ಲೇಖವನ್ನು ರಚಿಸಿದೆ (#54908 ನೋಡಿ).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// ಮೌಲ್ಯವು ವಿನ್ಯಾಸವನ್ನು ಒದಗಿಸಿರುವ ಸಂಭಾವ್ಯ-ಗಾತ್ರದ ಆಂತರಿಕ ಮೌಲ್ಯಕ್ಕೆ ಸಾಕಷ್ಟು ಸ್ಥಳಾವಕಾಶದೊಂದಿಗೆ `ArcInner<T>` ಅನ್ನು ನಿಯೋಜಿಸುತ್ತದೆ, ಹಂಚಿಕೆ ವಿಫಲವಾದರೆ ದೋಷವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// `mem_to_arcinner` ಕಾರ್ಯವನ್ನು ಡೇಟಾ ಪಾಯಿಂಟರ್‌ನೊಂದಿಗೆ ಕರೆಯಲಾಗುತ್ತದೆ ಮತ್ತು `ArcInner<T>` ಗಾಗಿ ಒಂದು (ಸಂಭಾವ್ಯ ಕೊಬ್ಬು)-ಪಾಯಿಂಟರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸಬೇಕು.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // ಕೊಟ್ಟಿರುವ ಮೌಲ್ಯ ವಿನ್ಯಾಸವನ್ನು ಬಳಸಿಕೊಂಡು ವಿನ್ಯಾಸವನ್ನು ಲೆಕ್ಕಹಾಕಿ.
        // ಹಿಂದೆ, `&*(ptr as* const ArcInner<T>)` ಅಭಿವ್ಯಕ್ತಿಯಲ್ಲಿ ವಿನ್ಯಾಸವನ್ನು ಲೆಕ್ಕಹಾಕಲಾಗಿತ್ತು, ಆದರೆ ಇದು ತಪ್ಪಾಗಿ ವಿನ್ಯಾಸಗೊಳಿಸಲಾದ ಉಲ್ಲೇಖವನ್ನು ರಚಿಸಿದೆ (#54908 ನೋಡಿ).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // ಆರ್ಕ್ಇನ್ನರ್ ಅನ್ನು ಪ್ರಾರಂಭಿಸಿ
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// ಗಾತ್ರೀಕರಿಸದ ಆಂತರಿಕ ಮೌಲ್ಯಕ್ಕೆ ಸಾಕಷ್ಟು ಸ್ಥಳಾವಕಾಶವಿರುವ `ArcInner<T>` ಅನ್ನು ನಿಯೋಜಿಸುತ್ತದೆ.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // ಕೊಟ್ಟಿರುವ ಮೌಲ್ಯವನ್ನು ಬಳಸಿಕೊಂಡು `ArcInner<T>` ಗಾಗಿ ನಿಯೋಜಿಸಿ.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // ಮೌಲ್ಯವನ್ನು ಬೈಟ್‌ಗಳಾಗಿ ನಕಲಿಸಿ
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // ಹಂಚಿಕೆಯನ್ನು ಅದರ ವಿಷಯಗಳನ್ನು ಬಿಡದೆ ಮುಕ್ತಗೊಳಿಸಿ
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// ನಿರ್ದಿಷ್ಟ ಉದ್ದದೊಂದಿಗೆ `ArcInner<[T]>` ಅನ್ನು ನಿಯೋಜಿಸುತ್ತದೆ.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// ಸ್ಲೈಸ್‌ನಿಂದ ಹೊಸದಾಗಿ ನಿಯೋಜಿಸಲಾದ ಆರ್ಕ್ <\[ಟಿ\]> ಗೆ ಅಂಶಗಳನ್ನು ನಕಲಿಸಿ
    ///
    /// ಅಸುರಕ್ಷಿತ ಏಕೆಂದರೆ ಕರೆ ಮಾಡುವವರು ಮಾಲೀಕತ್ವವನ್ನು ತೆಗೆದುಕೊಳ್ಳಬೇಕು ಅಥವಾ `T: Copy` ಅನ್ನು ಬಂಧಿಸಬೇಕು.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// ನಿರ್ದಿಷ್ಟ ಗಾತ್ರದ್ದಾಗಿರುವ ಇಟರೇಟರ್‌ನಿಂದ `Arc<[T]>` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    ///
    /// ಗಾತ್ರವು ತಪ್ಪಾಗಿರಬೇಕು ಎಂದು ವರ್ತನೆಯನ್ನು ವಿವರಿಸಲಾಗುವುದಿಲ್ಲ.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // ಟಿ ಅಂಶಗಳನ್ನು ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮಾಡುವಾಗ Panic ಗಾರ್ಡ್.
        // panic ನ ಸಂದರ್ಭದಲ್ಲಿ, ಹೊಸ ಆರ್ಕ್‌ಇನ್ನರ್‌ಗೆ ಬರೆಯಲಾದ ಅಂಶಗಳನ್ನು ಕೈಬಿಡಲಾಗುತ್ತದೆ, ನಂತರ ಮೆಮೊರಿ ಮುಕ್ತವಾಗುತ್ತದೆ.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // ಮೊದಲ ಅಂಶಕ್ಕೆ ಪಾಯಿಂಟರ್
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // ಎಲ್ಲಾ ಸ್ಪಷ್ಟವಾಗಿದೆ.ಗಾರ್ಡ್ ಅನ್ನು ಮರೆತುಬಿಡಿ ಆದ್ದರಿಂದ ಅದು ಹೊಸ ಆರ್ಕ್ಇನ್ನರ್ ಅನ್ನು ಮುಕ್ತಗೊಳಿಸುವುದಿಲ್ಲ.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// ವಿಶೇಷತೆ trait ಅನ್ನು `From<&[T]>` ಗಾಗಿ ಬಳಸಲಾಗುತ್ತದೆ.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// `Arc` ಪಾಯಿಂಟರ್‌ನ ತದ್ರೂಪಿ ಮಾಡುತ್ತದೆ.
    ///
    /// ಇದು ಅದೇ ಹಂಚಿಕೆಗೆ ಮತ್ತೊಂದು ಪಾಯಿಂಟರ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ, ಇದು ಬಲವಾದ ಉಲ್ಲೇಖ ಸಂಖ್ಯೆಯನ್ನು ಹೆಚ್ಚಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // ಆರಾಮವಾಗಿರುವ ಆದೇಶವನ್ನು ಬಳಸುವುದು ಇಲ್ಲಿ ಸರಿಯಾಗಿದೆ, ಏಕೆಂದರೆ ಮೂಲ ಉಲ್ಲೇಖದ ಜ್ಞಾನವು ಇತರ ಎಳೆಗಳನ್ನು ವಸ್ತುವನ್ನು ತಪ್ಪಾಗಿ ಅಳಿಸುವುದನ್ನು ತಡೆಯುತ್ತದೆ.
        //
        // [Boost documentation][1] ನಲ್ಲಿ ವಿವರಿಸಿದಂತೆ, ಉಲ್ಲೇಖ ಕೌಂಟರ್ ಅನ್ನು ಹೆಚ್ಚಿಸುವುದನ್ನು ಯಾವಾಗಲೂ ಮೆಮೊರಿ_ಆರ್ಡರ್_ರೆಲ್ಯಾಕ್ಸ್ಡ್‌ನೊಂದಿಗೆ ಮಾಡಬಹುದು: ವಸ್ತುವಿನ ಹೊಸ ಉಲ್ಲೇಖಗಳು ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ ಉಲ್ಲೇಖದಿಂದ ಮಾತ್ರ ರೂಪುಗೊಳ್ಳಬಹುದು, ಮತ್ತು ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ ಉಲ್ಲೇಖವನ್ನು ಒಂದು ಥ್ರೆಡ್‌ನಿಂದ ಇನ್ನೊಂದಕ್ಕೆ ರವಾನಿಸುವುದರಿಂದ ಈಗಾಗಲೇ ಅಗತ್ಯವಿರುವ ಯಾವುದೇ ಸಿಂಕ್ರೊನೈಸೇಶನ್ ಅನ್ನು ಒದಗಿಸಬೇಕು.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // ಹೇಗಾದರೂ ಯಾರಾದರೂ `ಮೆಮ್: : ಮರೆತುಹೋಗುವ ಆರ್ಕ್ಸ್ ಆಗಿದ್ದರೆ ನಾವು ಬೃಹತ್ ಮರುಪಾವತಿಗಳ ವಿರುದ್ಧ ಕಾಪಾಡಿಕೊಳ್ಳಬೇಕು.
        // ನಾವು ಇದನ್ನು ಮಾಡದಿದ್ದರೆ ಎಣಿಕೆ ಉಕ್ಕಿ ಹರಿಯಬಹುದು ಮತ್ತು ಬಳಕೆದಾರರು ಉಚಿತವಾಗಿ ಬಳಸುತ್ತಾರೆ.
        // ~2 ಶತಕೋಟಿ ಎಳೆಗಳು ಇಲ್ಲ ಎಂಬ umption ಹೆಯ ಮೇರೆಗೆ ನಾವು ಏಕಕಾಲದಲ್ಲಿ ಉಲ್ಲೇಖದ ಸಂಖ್ಯೆಯನ್ನು ಹೆಚ್ಚಿಸುತ್ತೇವೆ.
        //
        // ಈ branch ಅನ್ನು ಯಾವುದೇ ವಾಸ್ತವಿಕ ಕಾರ್ಯಕ್ರಮದಲ್ಲಿ ಎಂದಿಗೂ ತೆಗೆದುಕೊಳ್ಳಲಾಗುವುದಿಲ್ಲ.
        //
        // ಅಂತಹ ಕಾರ್ಯಕ್ರಮವು ನಂಬಲಾಗದಷ್ಟು ಕ್ಷೀಣಿಸುತ್ತಿರುವುದರಿಂದ ನಾವು ಅದನ್ನು ಸ್ಥಗಿತಗೊಳಿಸುತ್ತೇವೆ ಮತ್ತು ಅದನ್ನು ಬೆಂಬಲಿಸಲು ನಾವು ಹೆದರುವುದಿಲ್ಲ.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// ಕೊಟ್ಟಿರುವ `Arc` ಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಮಾಡುತ್ತದೆ.
    ///
    /// ಒಂದೇ ಹಂಚಿಕೆಗೆ ಇತರ `Arc` ಅಥವಾ [`Weak`] ಪಾಯಿಂಟರ್‌ಗಳು ಇದ್ದರೆ, ನಂತರ `make_mut` ಹೊಸ ಹಂಚಿಕೆಯನ್ನು ರಚಿಸುತ್ತದೆ ಮತ್ತು ಅನನ್ಯ ಮಾಲೀಕತ್ವವನ್ನು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ಆಂತರಿಕ ಮೌಲ್ಯದ ಮೇಲೆ [`clone`][clone] ಅನ್ನು ಆಹ್ವಾನಿಸುತ್ತದೆ.
    /// ಇದನ್ನು ಕ್ಲೋನ್-ಆನ್-ರೈಟ್ ಎಂದೂ ಕರೆಯಲಾಗುತ್ತದೆ.
    ///
    /// ಇದು [`Rc::make_mut`] ನ ವರ್ತನೆಯಿಂದ ಭಿನ್ನವಾಗಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ ಅದು ಉಳಿದ ಯಾವುದೇ `Weak` ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಬೇರ್ಪಡಿಸುತ್ತದೆ.
    ///
    /// [`get_mut`][get_mut] ಅನ್ನು ಸಹ ನೋಡಿ, ಅದು ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿಗಿಂತ ವಿಫಲಗೊಳ್ಳುತ್ತದೆ.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // ಯಾವುದನ್ನೂ ಕ್ಲೋನ್ ಮಾಡುವುದಿಲ್ಲ
    /// let mut other_data = Arc::clone(&data); // ಆಂತರಿಕ ಡೇಟಾವನ್ನು ಕ್ಲೋನ್ ಮಾಡುವುದಿಲ್ಲ
    /// *Arc::make_mut(&mut data) += 1;         // ಆಂತರಿಕ ಡೇಟಾವನ್ನು ಕ್ಲೋನ್ ಮಾಡುತ್ತದೆ
    /// *Arc::make_mut(&mut data) += 1;         // ಯಾವುದನ್ನೂ ಕ್ಲೋನ್ ಮಾಡುವುದಿಲ್ಲ
    /// *Arc::make_mut(&mut other_data) *= 2;   // ಯಾವುದನ್ನೂ ಕ್ಲೋನ್ ಮಾಡುವುದಿಲ್ಲ
    ///
    /// // ಈಗ `data` ಮತ್ತು `other_data` ವಿಭಿನ್ನ ಹಂಚಿಕೆಗಳಿಗೆ ಸೂಚಿಸುತ್ತವೆ.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // ನಾವು ಬಲವಾದ ಉಲ್ಲೇಖ ಮತ್ತು ದುರ್ಬಲ ಉಲ್ಲೇಖ ಎರಡನ್ನೂ ಹೊಂದಿದ್ದೇವೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
        // ಆದ್ದರಿಂದ, ನಮ್ಮ ಬಲವಾದ ಉಲ್ಲೇಖವನ್ನು ಮಾತ್ರ ಬಿಡುಗಡೆ ಮಾಡುವುದರಿಂದ, ಮೆಮೊರಿಯನ್ನು ಡಿಲೊಕೊಲೇಟ್ ಮಾಡಲು ಕಾರಣವಾಗುವುದಿಲ್ಲ.
        //
        // X001 ಗೆ ಬಿಡುಗಡೆಯ ಬರಹಗಳ ಮೊದಲು (ಅಂದರೆ, ಇಳಿಕೆಗಳು) ಸಂಭವಿಸುವ `weak` ಗೆ ಯಾವುದೇ ಬರಹಗಳನ್ನು ನಾವು ನೋಡುತ್ತೇವೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ಸ್ವಾಧೀನಪಡಿಸಿಕೊಳ್ಳಿ.
        // ನಾವು ದುರ್ಬಲ ಎಣಿಕೆಯನ್ನು ಹೊಂದಿರುವುದರಿಂದ, ಆರ್ಕ್‌ಇನ್ನರ್ ಅನ್ನು ಸ್ವತಃ ಸ್ಥಳಾಂತರಿಸಲು ಯಾವುದೇ ಅವಕಾಶವಿಲ್ಲ.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // ಮತ್ತೊಂದು ಬಲವಾದ ಪಾಯಿಂಟರ್ ಅಸ್ತಿತ್ವದಲ್ಲಿದೆ, ಆದ್ದರಿಂದ ನಾವು ಕ್ಲೋನ್ ಮಾಡಬೇಕು.
            // ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮೌಲ್ಯವನ್ನು ನೇರವಾಗಿ ಬರೆಯಲು ಅನುಮತಿಸಲು ಮೆಮೊರಿಯನ್ನು ಮೊದಲೇ ನಿಯೋಜಿಸಿ.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // ಮೇಲಿನವುಗಳಲ್ಲಿ ವಿಶ್ರಾಂತಿ ಸಾಕು ಏಕೆಂದರೆ ಇದು ಮೂಲಭೂತವಾಗಿ ಆಪ್ಟಿಮೈಸೇಶನ್ ಆಗಿದೆ: ದುರ್ಬಲ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಕೈಬಿಡುವುದರೊಂದಿಗೆ ನಾವು ಯಾವಾಗಲೂ ಓಡುತ್ತಿದ್ದೇವೆ.
            // ಕೆಟ್ಟ ಪ್ರಕರಣ, ನಾವು ಹೊಸ ಆರ್ಕ್ ಅನ್ನು ಅನಗತ್ಯವಾಗಿ ಹಂಚಿಕೆ ಮಾಡುತ್ತೇವೆ.
            //

            // ನಾವು ಕೊನೆಯ ಬಲವಾದ ರೆಫ್ ಅನ್ನು ತೆಗೆದುಹಾಕಿದ್ದೇವೆ, ಆದರೆ ಹೆಚ್ಚುವರಿ ದುರ್ಬಲ ರೆಫ್‌ಗಳು ಉಳಿದಿವೆ.
            // ನಾವು ವಿಷಯಗಳನ್ನು ಹೊಸ ಆರ್ಕ್‌ಗೆ ಸರಿಸುತ್ತೇವೆ ಮತ್ತು ಇತರ ದುರ್ಬಲ ಉಲ್ಲೇಖಗಳನ್ನು ಅಮಾನ್ಯಗೊಳಿಸುತ್ತೇವೆ.
            //

            // `weak` ಅನ್ನು ಓದಲು usize::MAX (ಅಂದರೆ, ಲಾಕ್ ಮಾಡಲಾಗಿದೆ) ನೀಡಲು ಸಾಧ್ಯವಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಏಕೆಂದರೆ ದುರ್ಬಲ ಎಣಿಕೆಯನ್ನು ಬಲವಾದ ಉಲ್ಲೇಖದೊಂದಿಗೆ ಥ್ರೆಡ್‌ನಿಂದ ಮಾತ್ರ ಲಾಕ್ ಮಾಡಬಹುದು.
            //
            //

            // ನಮ್ಮದೇ ಆದ ದುರ್ಬಲ ಪಾಯಿಂಟರ್ ಅನ್ನು ಮೆಟೀರಿಯಲೈಸ್ ಮಾಡಿ, ಇದರಿಂದ ಅದು ಆರ್ಕ್ಇನ್ನರ್ ಅನ್ನು ಅಗತ್ಯವಿರುವಂತೆ ಸ್ವಚ್ up ಗೊಳಿಸಬಹುದು.
            //
            let _weak = Weak { ptr: this.ptr };

            // ಡೇಟಾವನ್ನು ಕದಿಯಬಹುದು, ಉಳಿದಿರುವುದು ದುರ್ಬಲವಾಗಿದೆ
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // ನಾವು ಎರಡೂ ರೀತಿಯ ಏಕೈಕ ಉಲ್ಲೇಖವಾಗಿದ್ದೇವೆ;ಬಲವಾದ ರೆಫ್ ಎಣಿಕೆಯನ್ನು ಬ್ಯಾಕ್ ಅಪ್ ಮಾಡಿ.
            //
            this.inner().strong.store(1, Release);
        }

        // `get_mut()` ನಂತೆ, ಅಸುರಕ್ಷಿತತೆಯು ಸರಿಯಾಗಿದೆ ಏಕೆಂದರೆ ನಮ್ಮ ಉಲ್ಲೇಖವು ಪ್ರಾರಂಭವಾಗಲು ಅನನ್ಯವಾಗಿತ್ತು ಅಥವಾ ವಿಷಯಗಳನ್ನು ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮಾಡಿದ ನಂತರ ಒಂದಾಗಿದೆ.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// ಒಂದೇ ಹಂಚಿಕೆಗೆ ಬೇರೆ `Arc` ಅಥವಾ [`Weak`] ಪಾಯಿಂಟರ್‌ಗಳು ಇಲ್ಲದಿದ್ದರೆ, ಕೊಟ್ಟಿರುವ `Arc` ಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಏಕೆಂದರೆ ಹಂಚಿದ ಮೌಲ್ಯವನ್ನು ಪರಿವರ್ತಿಸುವುದು ಸುರಕ್ಷಿತವಲ್ಲ.
    ///
    /// [`make_mut`][make_mut] ಅನ್ನು ಸಹ ನೋಡಿ, ಇದು ಇತರ ಪಾಯಿಂಟರ್‌ಗಳು ಇದ್ದಾಗ ಆಂತರಿಕ ಮೌಲ್ಯವನ್ನು [`clone`][clone] ಮಾಡುತ್ತದೆ.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // ಈ ಅಸುರಕ್ಷಿತತೆಯು ಸರಿಯಾಗಿದೆ ಏಕೆಂದರೆ ಹಿಂದಿರುಗಿದ ಪಾಯಿಂಟರ್ *ಮಾತ್ರ* ಪಾಯಿಂಟರ್ ಎಂದು ನಾವು ಖಾತರಿಪಡಿಸುತ್ತೇವೆ ಅದು ಎಂದಿಗೂ ಟಿ ಗೆ ಹಿಂತಿರುಗುತ್ತದೆ.
            // ನಮ್ಮ ಉಲ್ಲೇಖದ ಎಣಿಕೆ ಈ ಹಂತದಲ್ಲಿ 1 ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ, ಮತ್ತು ನಮಗೆ ಆರ್ಕ್ ಸ್ವತಃ `mut` ಆಗಿರಬೇಕು, ಆದ್ದರಿಂದ ನಾವು ಆಂತರಿಕ ಡೇಟಾಗೆ ಸಂಭವನೀಯ ಉಲ್ಲೇಖವನ್ನು ಮಾತ್ರ ಹಿಂದಿರುಗಿಸುತ್ತಿದ್ದೇವೆ.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// ಯಾವುದೇ ಪರಿಶೀಲನೆಯಿಲ್ಲದೆ, ಕೊಟ್ಟಿರುವ `Arc` ಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [`get_mut`] ಅನ್ನು ಸಹ ನೋಡಿ, ಅದು ಸುರಕ್ಷಿತವಾಗಿದೆ ಮತ್ತು ಸೂಕ್ತವಾದ ತಪಾಸಣೆ ಮಾಡುತ್ತದೆ.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// ಅದೇ ಹಂಚಿಕೆಗೆ ಬೇರೆ ಯಾವುದೇ `Arc` ಅಥವಾ [`Weak`] ಪಾಯಿಂಟರ್‌ಗಳು ಹಿಂತಿರುಗಿದ ಸಾಲದ ಅವಧಿಗೆ ಡಿಫರೆನ್ಸ್ ಮಾಡಬಾರದು.
    ///
    /// ಅಂತಹ ಯಾವುದೇ ಪಾಯಿಂಟರ್‌ಗಳು ಅಸ್ತಿತ್ವದಲ್ಲಿಲ್ಲದಿದ್ದರೆ ಇದು ಕ್ಷುಲ್ಲಕ ಸಂಗತಿಯಾಗಿದೆ, ಉದಾಹರಣೆಗೆ `Arc::new` ನಂತರ ತಕ್ಷಣ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // "count" ಕ್ಷೇತ್ರಗಳನ್ನು ಒಳಗೊಂಡ ಉಲ್ಲೇಖವನ್ನು * ರಚಿಸದಿರಲು ನಾವು ಜಾಗರೂಕರಾಗಿರುತ್ತೇವೆ, ಏಕೆಂದರೆ ಇದು ಉಲ್ಲೇಖ ಎಣಿಕೆಗಳಿಗೆ ಏಕಕಾಲಿಕ ಪ್ರವೇಶದೊಂದಿಗೆ ಅಲಿಯಾಸ್ ಆಗಿರುತ್ತದೆ (ಉದಾ.
        // `Weak` ನಿಂದ).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// ಆಧಾರವಾಗಿರುವ ಡೇಟಾಗೆ ಇದು ಅನನ್ಯ ಉಲ್ಲೇಖ (ದುರ್ಬಲ ಉಲ್ಲೇಖಗಳು ಸೇರಿದಂತೆ) ಎಂಬುದನ್ನು ನಿರ್ಧರಿಸಿ.
    ///
    ///
    /// ಇದಕ್ಕೆ ದುರ್ಬಲ ರೆಫ್ ಎಣಿಕೆ ಲಾಕ್ ಮಾಡುವ ಅಗತ್ಯವಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    fn is_unique(&mut self) -> bool {
        // ನಾವು ಏಕೈಕ ದುರ್ಬಲ ಪಾಯಿಂಟರ್ ಹೋಲ್ಡರ್ ಆಗಿ ಕಾಣಿಸಿಕೊಂಡರೆ ದುರ್ಬಲ ಪಾಯಿಂಟರ್ ಎಣಿಕೆಯನ್ನು ಲಾಕ್ ಮಾಡಿ.
        //
        // `weak` ಎಣಿಕೆ (`Weak::drop` ಮೂಲಕ, ಬಿಡುಗಡೆಯನ್ನು ಬಳಸುವ) ಇಳಿಕೆಗೆ ಮುಂಚಿತವಾಗಿ `strong` ಗೆ (ನಿರ್ದಿಷ್ಟವಾಗಿ `Weak::upgrade` ನಲ್ಲಿ) ಯಾವುದೇ ಬರಹಗಳೊಂದಿಗಿನ ಸಂಬಂಧವನ್ನು ಇಲ್ಲಿ ಸ್ವಾಧೀನಪಡಿಸಿಕೊಳ್ಳುವ ಲೇಬಲ್ ಖಚಿತಪಡಿಸುತ್ತದೆ.
        // ನವೀಕರಿಸಿದ ದುರ್ಬಲ ರೆಫ್ ಅನ್ನು ಎಂದಿಗೂ ಕೈಬಿಡದಿದ್ದರೆ, ಇಲ್ಲಿ ಸಿಎಎಸ್ ವಿಫಲಗೊಳ್ಳುತ್ತದೆ ಆದ್ದರಿಂದ ನಾವು ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡಲು ಹೆದರುವುದಿಲ್ಲ.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // `drop` ನಲ್ಲಿನ `strong` ಕೌಂಟರ್‌ನ ಇಳಿಕೆಯೊಂದಿಗೆ ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡಲು ಇದು `Acquire` ಆಗಿರಬೇಕು-ಯಾವುದಾದರೂ ಆದರೆ ಕೊನೆಯ ಉಲ್ಲೇಖವನ್ನು ಕೈಬಿಟ್ಟಾಗ ಮಾತ್ರ ಪ್ರವೇಶ.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // ಇಲ್ಲಿ ಬಿಡುಗಡೆಯ ಬರಹವು `downgrade` ನಲ್ಲಿನ ಓದುವಿಕೆಯೊಂದಿಗೆ ಸಿಂಕ್ರೊನೈಸ್ ಆಗುತ್ತದೆ, `strong` ನ ಮೇಲಿನ ಓದುವಿಕೆ ಬರವಣಿಗೆಯ ನಂತರ ಸಂಭವಿಸದಂತೆ ಪರಿಣಾಮಕಾರಿಯಾಗಿ ತಡೆಯುತ್ತದೆ.
            //
            //
            self.inner().weak.store(1, Release); // ಲಾಕ್ ಅನ್ನು ಬಿಡುಗಡೆ ಮಾಡಿ
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// `Arc` ಅನ್ನು ಇಳಿಯುತ್ತದೆ.
    ///
    /// ಇದು ಬಲವಾದ ಉಲ್ಲೇಖ ಸಂಖ್ಯೆಯನ್ನು ಕಡಿಮೆ ಮಾಡುತ್ತದೆ.
    /// ಬಲವಾದ ಉಲ್ಲೇಖ ಎಣಿಕೆ ಶೂನ್ಯವನ್ನು ತಲುಪಿದರೆ, ಇತರ ಉಲ್ಲೇಖಗಳು (ಯಾವುದಾದರೂ ಇದ್ದರೆ) [`Weak`], ಆದ್ದರಿಂದ ನಾವು ಆಂತರಿಕ ಮೌಲ್ಯವನ್ನು `drop` ಮಾಡುತ್ತೇವೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // ಯಾವುದನ್ನೂ ಮುದ್ರಿಸುವುದಿಲ್ಲ
    /// drop(foo2);   // "dropped!" ಅನ್ನು ಮುದ್ರಿಸುತ್ತದೆ
    /// ```
    #[inline]
    fn drop(&mut self) {
        // `fetch_sub` ಈಗಾಗಲೇ ಪರಮಾಣು ಆಗಿರುವುದರಿಂದ, ನಾವು ವಸ್ತುವನ್ನು ಅಳಿಸಲು ಹೋಗದ ಹೊರತು ನಾವು ಇತರ ಎಳೆಗಳೊಂದಿಗೆ ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡುವ ಅಗತ್ಯವಿಲ್ಲ.
        // ಇದೇ ತರ್ಕವು ಕೆಳಗಿನ `fetch_sub` ಗೆ `weak` ಎಣಿಕೆಗೆ ಅನ್ವಯಿಸುತ್ತದೆ.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // ಡೇಟಾದ ಬಳಕೆಯನ್ನು ಮರುಕ್ರಮಗೊಳಿಸುವುದನ್ನು ಮತ್ತು ಡೇಟಾವನ್ನು ಅಳಿಸುವುದನ್ನು ತಡೆಯಲು ಈ ಬೇಲಿ ಅಗತ್ಯವಿದೆ.
        // ಇದನ್ನು `Release` ಎಂದು ಗುರುತಿಸಲಾಗಿರುವುದರಿಂದ, ಉಲ್ಲೇಖದ ಎಣಿಕೆ ಕಡಿಮೆಯಾಗುವುದು ಈ `Acquire` ಬೇಲಿಯೊಂದಿಗೆ ಸಿಂಕ್ರೊನೈಸ್ ಆಗುತ್ತದೆ.
        // ಇದರರ್ಥ ದತ್ತಾಂಶದ ಬಳಕೆಯು ಉಲ್ಲೇಖದ ಸಂಖ್ಯೆಯನ್ನು ಕಡಿಮೆ ಮಾಡುವ ಮೊದಲು ಸಂಭವಿಸುತ್ತದೆ, ಇದು ಈ ಬೇಲಿಯ ಮೊದಲು ಸಂಭವಿಸುತ್ತದೆ, ಇದು ಡೇಟಾವನ್ನು ಅಳಿಸುವ ಮೊದಲು ಸಂಭವಿಸುತ್ತದೆ.
        //
        // [Boost documentation][1] ನಲ್ಲಿ ವಿವರಿಸಿದಂತೆ,
        //
        // > ಒಂದರಲ್ಲಿ ವಸ್ತುವಿನ ಯಾವುದೇ ಪ್ರವೇಶವನ್ನು ಜಾರಿಗೊಳಿಸುವುದು ಮುಖ್ಯ
        // > ಥ್ರೆಡ್ (ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ ಉಲ್ಲೇಖದ ಮೂಲಕ)*ಅಳಿಸುವ ಮೊದಲು* ಸಂಭವಿಸುತ್ತದೆ
        // > ಬೇರೆ ಥ್ರೆಡ್‌ನಲ್ಲಿರುವ ವಸ್ತು.ಇದನ್ನು "release" ನಿಂದ ಸಾಧಿಸಲಾಗುತ್ತದೆ
        // > ಉಲ್ಲೇಖವನ್ನು ಕೈಬಿಟ್ಟ ನಂತರ ಕಾರ್ಯಾಚರಣೆ (ವಸ್ತುವಿಗೆ ಯಾವುದೇ ಪ್ರವೇಶ
        // > ಈ ಉಲ್ಲೇಖದ ಮೂಲಕ ಸ್ಪಷ್ಟವಾಗಿ ಮೊದಲು ಸಂಭವಿಸಬೇಕು), ಮತ್ತು ಒಂದು
        // > "acquire" ವಸ್ತುವನ್ನು ಅಳಿಸುವ ಮೊದಲು ಕಾರ್ಯಾಚರಣೆ.
        //
        // ನಿರ್ದಿಷ್ಟವಾಗಿ ಹೇಳುವುದಾದರೆ, ಆರ್ಕ್‌ನ ವಿಷಯಗಳು ಸಾಮಾನ್ಯವಾಗಿ ಬದಲಾಗದಿದ್ದರೂ, ಮ್ಯೂಟೆಕ್ಸ್‌ನಂತಹ ಒಳಾಂಗಣವನ್ನು ಬರೆಯಲು ಸಾಧ್ಯವಿದೆ<T>.
        // ಮ್ಯೂಟೆಕ್ಸ್ ಅನ್ನು ಅಳಿಸಿದಾಗ ಅದನ್ನು ಸ್ವಾಧೀನಪಡಿಸಿಕೊಳ್ಳದ ಕಾರಣ, ಥ್ರೆಡ್‌ನಲ್ಲಿ ಬರೆಯಲು ನಾವು ಅದರ ಸಿಂಕ್ರೊನೈಸೇಶನ್ ತರ್ಕವನ್ನು ಅವಲಂಬಿಸಲಾಗುವುದಿಲ್ಲ. ಥ್ರೆಡ್ ಬಿ ಯಲ್ಲಿ ಚಾಲನೆಯಲ್ಲಿರುವ ಡಿಸ್ಟ್ರಕ್ಟರ್‌ಗೆ ಗೋಚರಿಸುತ್ತದೆ.
        //
        //
        // ಇಲ್ಲಿ ಅಕ್ವೈರ್ ಬೇಲಿಯನ್ನು ಬಹುಶಃ ಅಕ್ವೈರ್ ಲೋಡ್‌ನೊಂದಿಗೆ ಬದಲಾಯಿಸಬಹುದೆಂದು ಗಮನಿಸಿ, ಇದು ಹೆಚ್ಚು ಸ್ಪರ್ಧಾತ್ಮಕ ಸಂದರ್ಭಗಳಲ್ಲಿ ಕಾರ್ಯಕ್ಷಮತೆಯನ್ನು ಸುಧಾರಿಸುತ್ತದೆ.[2] ನೋಡಿ.
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Arc<dyn Any + Send + Sync>` ಅನ್ನು ಕಾಂಕ್ರೀಟ್ ಪ್ರಕಾರಕ್ಕೆ ಇಳಿಸುವ ಪ್ರಯತ್ನ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// ಯಾವುದೇ ಮೆಮೊರಿಯನ್ನು ನಿಯೋಜಿಸದೆ ಹೊಸ `Weak<T>` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    /// ರಿಟರ್ನ್ ಮೌಲ್ಯದಲ್ಲಿ [`upgrade`] ಗೆ ಕರೆ ಮಾಡುವುದು ಯಾವಾಗಲೂ [`None`] ಅನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// ಡೇಟಾ ಕ್ಷೇತ್ರದ ಬಗ್ಗೆ ಯಾವುದೇ ಸಮರ್ಥನೆಗಳನ್ನು ನೀಡದೆ ಉಲ್ಲೇಖ ಎಣಿಕೆಗಳನ್ನು ಪ್ರವೇಶಿಸಲು ಅನುಮತಿಸುವ ಸಹಾಯಕ ಪ್ರಕಾರ.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// ಈ `Weak<T>` ಸೂಚಿಸಿದ `T` ವಸ್ತುವಿಗೆ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಕೆಲವು ಬಲವಾದ ಉಲ್ಲೇಖಗಳಿದ್ದರೆ ಮಾತ್ರ ಪಾಯಿಂಟರ್ ಮಾನ್ಯವಾಗಿರುತ್ತದೆ.
    /// ಪಾಯಿಂಟರ್ ತೂಗಾಡುತ್ತಿರುವ, ಜೋಡಿಸದ ಅಥವಾ [`null`] ಇಲ್ಲದಿದ್ದರೆ ಇರಬಹುದು.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // ಎರಡೂ ಒಂದೇ ವಸ್ತುವನ್ನು ಸೂಚಿಸುತ್ತವೆ
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // ಇಲ್ಲಿ ಬಲವಾದವರು ಅದನ್ನು ಜೀವಂತವಾಗಿರಿಸುತ್ತಾರೆ, ಆದ್ದರಿಂದ ನಾವು ಇನ್ನೂ ವಸ್ತುವನ್ನು ಪ್ರವೇಶಿಸಬಹುದು.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // ಆದರೆ ಇನ್ನೊಂದಿಲ್ಲ.
    /// // ನಾವು weak.as_ptr() ಮಾಡಬಹುದು, ಆದರೆ ಪಾಯಿಂಟರ್ ಅನ್ನು ಪ್ರವೇಶಿಸುವುದು ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
    /// // assert_eq! ("ಹಲೋ", ಅಸುರಕ್ಷಿತ {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // ಪಾಯಿಂಟರ್ ತೂಗಾಡುತ್ತಿದ್ದರೆ, ನಾವು ನೇರವಾಗಿ ಸೆಂಟಿನೆಲ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತೇವೆ.
            // ಇದು ಮಾನ್ಯ ಪೇಲೋಡ್ ವಿಳಾಸವಾಗಿರಬಾರದು, ಏಕೆಂದರೆ ಪೇಲೋಡ್ ಕನಿಷ್ಠ ಆರ್ಕ್ಇನ್ನರ್ (usize) ನಂತೆ ಜೋಡಿಸಲ್ಪಟ್ಟಿರುತ್ತದೆ.
            ptr as *const T
        } else {
            // ಸುರಕ್ಷತೆ: is_dangling ಸುಳ್ಳನ್ನು ಹಿಂತಿರುಗಿಸಿದರೆ, ನಂತರ ಪಾಯಿಂಟರ್ ಡಿಫರೆನ್ಸೆಬಲ್ ಆಗಿದೆ.
            // ಈ ಸಮಯದಲ್ಲಿ ಪೇಲೋಡ್ ಅನ್ನು ಕೈಬಿಡಬಹುದು, ಮತ್ತು ನಾವು ಮೂಲವನ್ನು ಕಾಪಾಡಿಕೊಳ್ಳಬೇಕು, ಆದ್ದರಿಂದ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಕುಶಲತೆಯನ್ನು ಬಳಸಿ.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// `Weak<T>` ಅನ್ನು ಬಳಸುತ್ತದೆ ಮತ್ತು ಅದನ್ನು ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ಇದು ದುರ್ಬಲ ಪಾಯಿಂಟರ್ ಅನ್ನು ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ, ಆದರೆ ಒಂದು ದುರ್ಬಲ ಉಲ್ಲೇಖದ ಮಾಲೀಕತ್ವವನ್ನು ಇನ್ನೂ ಕಾಪಾಡಿಕೊಳ್ಳುತ್ತದೆ (ಈ ಕಾರ್ಯಾಚರಣೆಯಿಂದ ದುರ್ಬಲ ಎಣಿಕೆಯನ್ನು ಮಾರ್ಪಡಿಸಲಾಗಿಲ್ಲ).
    /// ಇದನ್ನು [`from_raw`] ನೊಂದಿಗೆ `Weak<T>` ಗೆ ಹಿಂತಿರುಗಿಸಬಹುದು.
    ///
    /// [`as_ptr`] ನಂತೆ ಪಾಯಿಂಟರ್‌ನ ಗುರಿಯನ್ನು ಪ್ರವೇಶಿಸುವ ಅದೇ ನಿರ್ಬಂಧಗಳು ಅನ್ವಯಿಸುತ್ತವೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// ಈ ಹಿಂದೆ [`into_raw`] ರಚಿಸಿದ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಅನ್ನು ಮತ್ತೆ `Weak<T>` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ಬಲವಾದ ಉಲ್ಲೇಖವನ್ನು ಸುರಕ್ಷಿತವಾಗಿ ಪಡೆಯಲು (ನಂತರ [`upgrade`] ಗೆ ಕರೆ ಮಾಡುವ ಮೂಲಕ) ಅಥವಾ `Weak<T>` ಅನ್ನು ಬಿಡುವುದರ ಮೂಲಕ ದುರ್ಬಲ ಎಣಿಕೆಯನ್ನು ನಿವಾರಿಸಲು ಇದನ್ನು ಬಳಸಬಹುದು.
    ///
    /// ಇದು ಒಂದು ದುರ್ಬಲ ಉಲ್ಲೇಖದ ಮಾಲೀಕತ್ವವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ ([`new`] ರಚಿಸಿದ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಹೊರತುಪಡಿಸಿ, ಇವುಗಳು ಯಾವುದನ್ನೂ ಹೊಂದಿಲ್ಲವಾದ್ದರಿಂದ; ವಿಧಾನವು ಅವುಗಳ ಮೇಲೆ ಇನ್ನೂ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ).
    ///
    /// # Safety
    ///
    /// ಪಾಯಿಂಟರ್ [`into_raw`] ನಿಂದ ಹುಟ್ಟಿಕೊಂಡಿರಬೇಕು ಮತ್ತು ಅದರ ಸಂಭಾವ್ಯ ದುರ್ಬಲ ಉಲ್ಲೇಖವನ್ನು ಇನ್ನೂ ಹೊಂದಿರಬೇಕು.
    ///
    /// ಇದನ್ನು ಕರೆಯುವ ಸಮಯದಲ್ಲಿ ಬಲವಾದ ಎಣಿಕೆ 0 ಆಗಿರಲು ಅನುಮತಿಸಲಾಗಿದೆ.
    /// ಅದೇನೇ ಇದ್ದರೂ, ಇದು ಪ್ರಸ್ತುತ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ನಂತೆ ಪ್ರತಿನಿಧಿಸಲ್ಪಟ್ಟಿರುವ ಒಂದು ದುರ್ಬಲ ಉಲ್ಲೇಖದ ಮಾಲೀಕತ್ವವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ (ಈ ಕಾರ್ಯಾಚರಣೆಯಿಂದ ದುರ್ಬಲ ಎಣಿಕೆ ಮಾರ್ಪಡಿಸಲಾಗಿಲ್ಲ) ಮತ್ತು ಆದ್ದರಿಂದ ಇದನ್ನು [`into_raw`] ಗೆ ಹಿಂದಿನ ಕರೆಯೊಂದಿಗೆ ಜೋಡಿಸಬೇಕು.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // ಕೊನೆಯ ದುರ್ಬಲ ಎಣಿಕೆ ಕಡಿಮೆ ಮಾಡಿ.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // ಇನ್ಪುಟ್ ಪಾಯಿಂಟರ್ ಅನ್ನು ಹೇಗೆ ಪಡೆಯಲಾಗಿದೆ ಎಂಬುದರ ಕುರಿತು ಸಂದರ್ಭಕ್ಕಾಗಿ Weak::as_ptr ನೋಡಿ.

        let ptr = if is_dangling(ptr as *mut T) {
            // ಇದು ತೂಗಾಡುತ್ತಿರುವ ದುರ್ಬಲ.
            ptr as *mut ArcInner<T>
        } else {
            // ಇಲ್ಲದಿದ್ದರೆ, ಪಾಯಿಂಟರ್ ದುರ್ಬಲವಾದ ದುರ್ಬಲತೆಯಿಂದ ಬಂದಿದೆ ಎಂದು ನಮಗೆ ಖಾತ್ರಿಯಿದೆ.
            // ಸುರಕ್ಷತೆ: ಡೇಟಾ_ಆಫ್ಸೆಟ್ ಕರೆ ಮಾಡಲು ಸುರಕ್ಷಿತವಾಗಿದೆ, ಏಕೆಂದರೆ ಪಿಟಿಆರ್ ನಿಜವಾದ (ಸಂಭಾವ್ಯವಾಗಿ ಕೈಬಿಡಲಾಗಿದೆ) ಟಿ.
            let offset = unsafe { data_offset(ptr) };
            // ಹೀಗಾಗಿ, ಇಡೀ ಆರ್‌ಸಿಬಾಕ್ಸ್ ಪಡೆಯಲು ನಾವು ಆಫ್‌ಸೆಟ್ ಅನ್ನು ಹಿಮ್ಮುಖಗೊಳಿಸುತ್ತೇವೆ.
            // ಸುರಕ್ಷತೆ: ಪಾಯಿಂಟರ್ ದುರ್ಬಲದಿಂದ ಹುಟ್ಟಿಕೊಂಡಿದೆ, ಆದ್ದರಿಂದ ಈ ಆಫ್‌ಸೆಟ್ ಸುರಕ್ಷಿತವಾಗಿದೆ.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // ಸುರಕ್ಷತೆ: ನಾವು ಈಗ ಮೂಲ ದುರ್ಬಲ ಪಾಯಿಂಟರ್ ಅನ್ನು ಮರುಪಡೆಯಿದ್ದೇವೆ, ಆದ್ದರಿಂದ ದುರ್ಬಲತೆಯನ್ನು ರಚಿಸಬಹುದು.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// `Weak` ಪಾಯಿಂಟರ್ ಅನ್ನು [`Arc`] ಗೆ ಅಪ್‌ಗ್ರೇಡ್ ಮಾಡಲು ಪ್ರಯತ್ನಿಸುತ್ತದೆ, ಯಶಸ್ವಿಯಾದರೆ ಆಂತರಿಕ ಮೌಲ್ಯವನ್ನು ಬಿಡುವುದನ್ನು ವಿಳಂಬಗೊಳಿಸುತ್ತದೆ.
    ///
    ///
    /// ಆಂತರಿಕ ಮೌಲ್ಯವನ್ನು ಕೈಬಿಟ್ಟರೆ [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // ಎಲ್ಲಾ ಬಲವಾದ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ನಾಶಮಾಡಿ.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // ಫೆಚ್_ಅಡ್ ಬದಲಿಗೆ ಬಲವಾದ ಎಣಿಕೆಯನ್ನು ಹೆಚ್ಚಿಸಲು ನಾವು ಸಿಎಎಸ್ ಲೂಪ್ ಅನ್ನು ಬಳಸುತ್ತೇವೆ ಏಕೆಂದರೆ ಈ ಕಾರ್ಯವು ಉಲ್ಲೇಖದ ಸಂಖ್ಯೆಯನ್ನು ಶೂನ್ಯದಿಂದ ಒಂದಕ್ಕೆ ತೆಗೆದುಕೊಳ್ಳಬಾರದು.
        //
        //
        let inner = self.inner()?;

        // ವಿಶ್ರಾಂತಿ ಲೋಡ್ ಏಕೆಂದರೆ ನಾವು ಗಮನಿಸಬಹುದಾದ 0 ರ ಯಾವುದೇ ಬರಹವು ಕ್ಷೇತ್ರವನ್ನು ಶಾಶ್ವತವಾಗಿ ಶೂನ್ಯ ಸ್ಥಿತಿಯಲ್ಲಿ ಬಿಡುತ್ತದೆ (ಆದ್ದರಿಂದ 0 ನ "stale" ಓದುವಿಕೆ ಉತ್ತಮವಾಗಿರುತ್ತದೆ), ಮತ್ತು ಯಾವುದೇ ಇತರ ಮೌಲ್ಯವನ್ನು ಕೆಳಗಿನ ಸಿಎಎಸ್ ಮೂಲಕ ದೃ is ೀಕರಿಸಲಾಗುತ್ತದೆ.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // ನಾವು ಇದನ್ನು ಏಕೆ ಮಾಡುತ್ತೇವೆ (`mem::forget` ಗಾಗಿ) `Arc::clone` ನಲ್ಲಿ ಕಾಮೆಂಟ್‌ಗಳನ್ನು ನೋಡಿ.
            if n > MAX_REFCOUNT {
                abort();
            }

            // ವೈಫಲ್ಯ ಪ್ರಕರಣಕ್ಕೆ ವಿಶ್ರಾಂತಿ ಉತ್ತಮವಾಗಿದೆ ಏಕೆಂದರೆ ಹೊಸ ರಾಜ್ಯದ ಬಗ್ಗೆ ನಮಗೆ ಯಾವುದೇ ನಿರೀಕ್ಷೆಗಳಿಲ್ಲ.
            // `Arc::new_cyclic` ನೊಂದಿಗೆ ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡಲು ಯಶಸ್ಸಿನ ಸಂದರ್ಭದಲ್ಲಿ ಸ್ವಾಧೀನಪಡಿಸಿಕೊಳ್ಳುವುದು ಅವಶ್ಯಕವಾಗಿದೆ, `Weak` ಉಲ್ಲೇಖಗಳನ್ನು ಈಗಾಗಲೇ ರಚಿಸಿದ ನಂತರ ಆಂತರಿಕ ಮೌಲ್ಯವನ್ನು ಪ್ರಾರಂಭಿಸಬಹುದು.
            // ಅಂತಹ ಸಂದರ್ಭದಲ್ಲಿ, ಸಂಪೂರ್ಣ ಪ್ರಾರಂಭಿಕ ಮೌಲ್ಯವನ್ನು ಗಮನಿಸಲು ನಾವು ನಿರೀಕ್ಷಿಸುತ್ತೇವೆ.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // ಶೂನ್ಯವನ್ನು ಮೇಲೆ ಪರಿಶೀಲಿಸಲಾಗಿದೆ
                Err(old) => n = old,
            }
        }
    }

    /// ಈ ಹಂಚಿಕೆಯನ್ನು ಸೂಚಿಸುವ ಬಲವಾದ (`Arc`) ಪಾಯಿಂಟರ್‌ಗಳ ಸಂಖ್ಯೆಯನ್ನು ಪಡೆಯುತ್ತದೆ.
    ///
    /// [`Weak::new`] ಬಳಸಿ `self` ಅನ್ನು ರಚಿಸಿದ್ದರೆ, ಇದು 0 ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// ಈ ಹಂಚಿಕೆಯನ್ನು ಸೂಚಿಸುವ `Weak` ಪಾಯಿಂಟರ್‌ಗಳ ಸಂಖ್ಯೆಯ ಅಂದಾಜು ಪಡೆಯುತ್ತದೆ.
    ///
    /// [`Weak::new`] ಅನ್ನು [`Weak::new`] ಬಳಸಿ ರಚಿಸಿದ್ದರೆ ಅಥವಾ ಉಳಿದಿರುವ ಬಲವಾದ ಪಾಯಿಂಟರ್‌ಗಳು ಇಲ್ಲದಿದ್ದರೆ, ಇದು 0 ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Accuracy
    ///
    /// ಅನುಷ್ಠಾನದ ವಿವರಗಳ ಕಾರಣದಿಂದಾಗಿ, ಇತರ ಎಳೆಗಳು ಯಾವುದೇ `ಆರ್ಕ್'ಗಳನ್ನು ಕುಶಲತೆಯಿಂದ ನಿರ್ವಹಿಸುವಾಗ ಅಥವಾ ಅದೇ ಹಂಚಿಕೆಯನ್ನು ಸೂಚಿಸುವ` ದುರ್ಬಲ'ಗಳನ್ನು ಹಿಂತಿರುಗಿಸಿದಾಗ ಹಿಂದಿರುಗಿದ ಮೌಲ್ಯವು ಎರಡೂ ದಿಕ್ಕಿನಲ್ಲಿ 1 ರಿಂದ ಆಫ್ ಆಗಬಹುದು.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // ದುರ್ಬಲ ಎಣಿಕೆಯನ್ನು ಓದಿದ ನಂತರ ಕನಿಷ್ಠ ಒಂದು ಬಲವಾದ ಪಾಯಿಂಟರ್ ಇದೆ ಎಂದು ನಾವು ಗಮನಿಸಿದ್ದರಿಂದ, ದುರ್ಬಲ ಎಣಿಕೆಯನ್ನು ನಾವು ಗಮನಿಸಿದಾಗ ಸೂಚ್ಯ ದುರ್ಬಲ ಉಲ್ಲೇಖ (ಯಾವುದೇ ಬಲವಾದ ಉಲ್ಲೇಖಗಳು ಜೀವಂತವಾಗಿದ್ದಾಗಲೂ ಇರುತ್ತವೆ) ಇನ್ನೂ ತಿಳಿದಿದೆ ಮತ್ತು ಆದ್ದರಿಂದ ಅದನ್ನು ಸುರಕ್ಷಿತವಾಗಿ ಕಳೆಯಬಹುದು.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// ಪಾಯಿಂಟರ್ ತೂಗಾಡುತ್ತಿರುವಾಗ ಮತ್ತು ಹಂಚಿಕೆಯಾದ `ArcInner` ಇಲ್ಲದಿದ್ದಾಗ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, (ಅಂದರೆ, ಈ `Weak` ಅನ್ನು `Weak::new` ನಿಂದ ರಚಿಸಿದಾಗ).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // ಕ್ಷೇತ್ರವು ಏಕಕಾಲದಲ್ಲಿ ರೂಪಾಂತರಗೊಳ್ಳುವುದರಿಂದ, "data" ಕ್ಷೇತ್ರವನ್ನು ಒಳಗೊಂಡ ಉಲ್ಲೇಖವನ್ನು * ರಚಿಸದಿರಲು ನಾವು ಜಾಗರೂಕರಾಗಿರುತ್ತೇವೆ (ಉದಾಹರಣೆಗೆ, ಕೊನೆಯ `Arc` ಅನ್ನು ಕೈಬಿಟ್ಟರೆ, ಡೇಟಾ ಕ್ಷೇತ್ರವನ್ನು ಸ್ಥಳದಲ್ಲಿ ಬಿಡಲಾಗುತ್ತದೆ).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// ಎರಡು `ದುರ್ಬಲ'ಗಳು ಒಂದೇ ಹಂಚಿಕೆಗೆ ([`ptr::eq`] ನಂತೆಯೇ) ಸೂಚಿಸಿದರೆ ಅಥವಾ ಎರಡೂ ಯಾವುದೇ ಹಂಚಿಕೆಗೆ ಸೂಚಿಸದಿದ್ದರೆ (ಏಕೆಂದರೆ ಅವುಗಳನ್ನು `Weak::new()`) ನೊಂದಿಗೆ ರಚಿಸಲಾಗಿದೆ) `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Notes
    ///
    /// ಇದು ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಹೋಲಿಸುವ ಕಾರಣ, ಯಾವುದೇ ಹಂಚಿಕೆಗೆ ಅವರು ಸೂಚಿಸದಿದ್ದರೂ ಸಹ, `Weak::new()` ಪರಸ್ಪರ ಸಮಾನವಾಗಿರುತ್ತದೆ ಎಂದರ್ಥ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` ಅನ್ನು ಹೋಲಿಸುವುದು.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// ಒಂದೇ ಹಂಚಿಕೆಯನ್ನು ಸೂಚಿಸುವ `Weak` ಪಾಯಿಂಟರ್‌ನ ತದ್ರೂಪಿ ಮಾಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // ಇದು ಏಕೆ ಸಡಿಲಗೊಂಡಿದೆ ಎಂದು Arc::clone() ನಲ್ಲಿ ಕಾಮೆಂಟ್‌ಗಳನ್ನು ನೋಡಿ.
        // ಇದು ಫೆಚ್_ಅಡ್ (ಲಾಕ್ ಅನ್ನು ನಿರ್ಲಕ್ಷಿಸಿ) ಅನ್ನು ಬಳಸಬಹುದು ಏಕೆಂದರೆ ದುರ್ಬಲ ಎಣಿಕೆ ಮಾತ್ರ ಲಾಕ್ ಆಗಿದ್ದು, ಅಲ್ಲಿ *ಬೇರೆ* ದುರ್ಬಲ ಪಾಯಿಂಟರ್‌ಗಳು ಅಸ್ತಿತ್ವದಲ್ಲಿಲ್ಲ.
        //
        // (ಆದ್ದರಿಂದ ನಾವು ಈ ಸಂದರ್ಭದಲ್ಲಿ ಈ ಕೋಡ್ ಅನ್ನು ಚಲಾಯಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // ನಾವು ಇದನ್ನು ಏಕೆ ಮಾಡುತ್ತೇವೆ (mem::forget ಗಾಗಿ) Arc::clone() ನಲ್ಲಿ ಕಾಮೆಂಟ್‌ಗಳನ್ನು ನೋಡಿ.
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// ಮೆಮೊರಿಯನ್ನು ನಿಯೋಜಿಸದೆ ಹೊಸ `Weak<T>` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    /// ರಿಟರ್ನ್ ಮೌಲ್ಯದಲ್ಲಿ [`upgrade`] ಗೆ ಕರೆ ಮಾಡುವುದು ಯಾವಾಗಲೂ [`None`] ಅನ್ನು ನೀಡುತ್ತದೆ.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` ಪಾಯಿಂಟರ್ ಅನ್ನು ಬಿಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // ಯಾವುದನ್ನೂ ಮುದ್ರಿಸುವುದಿಲ್ಲ
    /// drop(foo);        // "dropped!" ಅನ್ನು ಮುದ್ರಿಸುತ್ತದೆ
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // ನಾವು ಕೊನೆಯ ದುರ್ಬಲ ಪಾಯಿಂಟರ್ ಎಂದು ನಾವು ಕಂಡುಕೊಂಡರೆ, ಡೇಟಾವನ್ನು ಸಂಪೂರ್ಣವಾಗಿ ಡಿಲೊಲೊಕೇಟ್ ಮಾಡುವ ಸಮಯ.ಮೆಮೊರಿ ಆದೇಶಗಳ ಬಗ್ಗೆ Arc::drop() ನಲ್ಲಿ ಚರ್ಚೆಯನ್ನು ನೋಡಿ
        //
        // ಇಲ್ಲಿ ಲಾಕ್ ಮಾಡಲಾದ ಸ್ಥಿತಿಯನ್ನು ಪರಿಶೀಲಿಸುವುದು ಅನಿವಾರ್ಯವಲ್ಲ, ಏಕೆಂದರೆ ನಿಖರವಾಗಿ ಒಂದು ದುರ್ಬಲ ರೆಫ್ ಇದ್ದರೆ ಮಾತ್ರ ದುರ್ಬಲ ಎಣಿಕೆಯನ್ನು ಲಾಕ್ ಮಾಡಬಹುದು, ಅಂದರೆ ಡ್ರಾಪ್ ತರುವಾಯ ಉಳಿದಿರುವ ದುರ್ಬಲ ರೆಫ್‌ನಲ್ಲಿ ಮಾತ್ರ ಚಲಿಸಬಲ್ಲದು, ಅದು ಲಾಕ್ ಬಿಡುಗಡೆಯಾದ ನಂತರವೇ ಸಂಭವಿಸಬಹುದು.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// ನಾವು ಈ ವಿಶೇಷತೆಯನ್ನು ಇಲ್ಲಿ ಮಾಡುತ್ತಿದ್ದೇವೆ ಮತ್ತು `&T` ನಲ್ಲಿ ಹೆಚ್ಚು ಸಾಮಾನ್ಯ ಆಪ್ಟಿಮೈಸೇಶನ್ ಆಗಿ ಅಲ್ಲ, ಏಕೆಂದರೆ ಇದು ರೆಫ್‌ಗಳಲ್ಲಿನ ಎಲ್ಲಾ ಸಮಾನತೆ ಪರಿಶೀಲನೆಗಳಿಗೆ ವೆಚ್ಚವನ್ನು ಸೇರಿಸುತ್ತದೆ.
/// `ಆರ್ಕ್'ಗಳನ್ನು ದೊಡ್ಡ ಮೌಲ್ಯಗಳನ್ನು ಸಂಗ್ರಹಿಸಲು ಬಳಸಲಾಗುತ್ತದೆ, ಅದು ಕ್ಲೋನ್ ಮಾಡಲು ನಿಧಾನವಾಗಿರುತ್ತದೆ, ಆದರೆ ಸಮಾನತೆಯನ್ನು ಪರೀಕ್ಷಿಸಲು ಭಾರವಾಗಿರುತ್ತದೆ, ಇದರಿಂದಾಗಿ ಈ ವೆಚ್ಚವು ಹೆಚ್ಚು ಸುಲಭವಾಗಿ ತೀರಿಸಲ್ಪಡುತ್ತದೆ.
///
/// ಇದು ಎರಡು `&ಟಿ`ಗಳಿಗಿಂತ ಎರಡು ಎಕ್ಸ್‌00 ಎಕ್ಸ್ ಕ್ಲೋನ್‌ಗಳನ್ನು ಹೊಂದುವ ಸಾಧ್ಯತೆಯಿದೆ.
///
/// `PartialEq` ಆಗಿ `T: Eq` ಉದ್ದೇಶಪೂರ್ವಕವಾಗಿ ಅಪ್ರಚಲಿತವಾಗಿದ್ದಾಗ ಮಾತ್ರ ನಾವು ಇದನ್ನು ಮಾಡಬಹುದು.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// ಎರಡು `ಆರ್ಕ್‌'ಗಳಿಗೆ ಸಮಾನತೆ.
    ///
    /// ವಿಭಿನ್ನ ಹಂಚಿಕೆಯಲ್ಲಿ ಸಂಗ್ರಹಿಸಲಾಗಿದ್ದರೂ ಸಹ, ಅವುಗಳ ಆಂತರಿಕ ಮೌಲ್ಯಗಳು ಸಮಾನವಾಗಿದ್ದರೆ ಎರಡು `ಆರ್ಕ್'ಗಳು ಸಮಾನವಾಗಿರುತ್ತದೆ.
    ///
    /// `T` ಸಹ `Eq` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದರೆ (ಸಮಾನತೆಯ ಪ್ರತಿಫಲಿತತೆಯನ್ನು ಸೂಚಿಸುತ್ತದೆ), ಒಂದೇ ಹಂಚಿಕೆಯನ್ನು ಸೂಚಿಸುವ ಎರಡು `ಆರ್ಕ್'ಗಳು ಯಾವಾಗಲೂ ಸಮಾನವಾಗಿರುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// ಎರಡು `ಆರ್ಕ್‌'ಗಳಿಗೆ ಅಸಮಾನತೆ.
    ///
    /// ಆಂತರಿಕ ಮೌಲ್ಯಗಳು ಅಸಮಾನವಾಗಿದ್ದರೆ ಎರಡು `ಆರ್ಕ್'ಗಳು ಅಸಮಾನವಾಗಿವೆ.
    ///
    /// `T` ಸಹ `Eq` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದರೆ (ಸಮಾನತೆಯ ಪ್ರತಿಫಲಿತತೆಯನ್ನು ಸೂಚಿಸುತ್ತದೆ), ಒಂದೇ ಮೌಲ್ಯವನ್ನು ಸೂಚಿಸುವ ಎರಡು `ಆರ್ಕ್'ಗಳು ಎಂದಿಗೂ ಅಸಮಾನವಾಗಿರುವುದಿಲ್ಲ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// ಎರಡು `ಆರ್ಕ್‌'ಗಳಿಗೆ ಭಾಗಶಃ ಹೋಲಿಕೆ.
    ///
    /// ಇಬ್ಬರನ್ನು ತಮ್ಮ ಆಂತರಿಕ ಮೌಲ್ಯಗಳಿಗೆ `partial_cmp()` ಗೆ ಕರೆ ಮಾಡುವ ಮೂಲಕ ಹೋಲಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// ಎರಡು `ಆರ್ಕ್‌'ಗಳಿಗೆ ಹೋಲಿಕೆಗಿಂತ ಕಡಿಮೆ.
    ///
    /// ಇಬ್ಬರನ್ನು ತಮ್ಮ ಆಂತರಿಕ ಮೌಲ್ಯಗಳಿಗೆ `<` ಗೆ ಕರೆ ಮಾಡುವ ಮೂಲಕ ಹೋಲಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// ಎರಡು `ಆರ್ಕ್‌'ಗಳಿಗೆ ಹೋಲಿಕೆ 'ಕಡಿಮೆ ಅಥವಾ ಸಮ'.
    ///
    /// ಇಬ್ಬರನ್ನು ತಮ್ಮ ಆಂತರಿಕ ಮೌಲ್ಯಗಳಿಗೆ `<=` ಗೆ ಕರೆ ಮಾಡುವ ಮೂಲಕ ಹೋಲಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// ಎರಡು `ಆರ್ಕ್‌'ಗಳಿಗೆ ಹೋಲಿಕೆಗಿಂತ ದೊಡ್ಡದಾಗಿದೆ.
    ///
    /// ಇಬ್ಬರನ್ನು ತಮ್ಮ ಆಂತರಿಕ ಮೌಲ್ಯಗಳಿಗೆ `>` ಗೆ ಕರೆ ಮಾಡುವ ಮೂಲಕ ಹೋಲಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// ಎರಡು `ಆರ್ಕ್‌'ಗಳಿಗೆ ಹೋಲಿಕೆ 'ಗಿಂತ ದೊಡ್ಡದು ಅಥವಾ ಸಮ'.
    ///
    /// ಇಬ್ಬರನ್ನು ತಮ್ಮ ಆಂತರಿಕ ಮೌಲ್ಯಗಳಿಗೆ `>=` ಗೆ ಕರೆ ಮಾಡುವ ಮೂಲಕ ಹೋಲಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// ಎರಡು `ಆರ್ಕ್‌'ಗಳಿಗೆ ಹೋಲಿಕೆ.
    ///
    /// ಇಬ್ಬರನ್ನು ತಮ್ಮ ಆಂತರಿಕ ಮೌಲ್ಯಗಳಿಗೆ `cmp()` ಗೆ ಕರೆ ಮಾಡುವ ಮೂಲಕ ಹೋಲಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// `T` ಗಾಗಿ `Default` ಮೌಲ್ಯದೊಂದಿಗೆ ಹೊಸ `Arc<T>` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// ಉಲ್ಲೇಖ-ಎಣಿಸಿದ ಸ್ಲೈಸ್ ಅನ್ನು ನಿಯೋಜಿಸಿ ಮತ್ತು `v` ನ ವಸ್ತುಗಳನ್ನು ಕ್ಲೋನ್ ಮಾಡುವ ಮೂಲಕ ಅದನ್ನು ಭರ್ತಿ ಮಾಡಿ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// ಉಲ್ಲೇಖ-ಎಣಿಸಿದ `str` ಅನ್ನು ನಿಗದಿಪಡಿಸಿ ಮತ್ತು `v` ಅನ್ನು ಅದರಲ್ಲಿ ನಕಲಿಸಿ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// ಉಲ್ಲೇಖ-ಎಣಿಸಿದ `str` ಅನ್ನು ನಿಗದಿಪಡಿಸಿ ಮತ್ತು `v` ಅನ್ನು ಅದರಲ್ಲಿ ನಕಲಿಸಿ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// ಪೆಟ್ಟಿಗೆಯ ವಸ್ತುವನ್ನು ಹೊಸ, ಉಲ್ಲೇಖ-ಎಣಿಕೆ ಹಂಚಿಕೆಗೆ ಸರಿಸಿ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// ಉಲ್ಲೇಖ-ಎಣಿಸಿದ ಸ್ಲೈಸ್ ಅನ್ನು ನಿಯೋಜಿಸಿ ಮತ್ತು `v` ನ ವಸ್ತುಗಳನ್ನು ಅದರೊಳಗೆ ಸರಿಸಿ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Vec ಅನ್ನು ಅದರ ಸ್ಮರಣೆಯನ್ನು ಮುಕ್ತಗೊಳಿಸಲು ಅನುಮತಿಸಿ, ಆದರೆ ಅದರ ವಿಷಯಗಳನ್ನು ನಾಶಪಡಿಸಬೇಡಿ
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// `Iterator` ನಲ್ಲಿನ ಪ್ರತಿಯೊಂದು ಅಂಶವನ್ನು ತೆಗೆದುಕೊಂಡು ಅದನ್ನು `Arc<[T]>` ಗೆ ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// # ಕಾರ್ಯಕ್ಷಮತೆಯ ಗುಣಲಕ್ಷಣಗಳು
    ///
    /// ## ಸಾಮಾನ್ಯ ಪ್ರಕರಣ
    ///
    /// ಸಾಮಾನ್ಯ ಸಂದರ್ಭದಲ್ಲಿ, `Arc<[T]>` ಗೆ ಸಂಗ್ರಹಿಸುವುದನ್ನು ಮೊದಲು `Vec<T>` ಗೆ ಸಂಗ್ರಹಿಸುವ ಮೂಲಕ ಮಾಡಲಾಗುತ್ತದೆ.ಅಂದರೆ, ಈ ಕೆಳಗಿನವುಗಳನ್ನು ಬರೆಯುವಾಗ:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ಇದು ನಾವು ಬರೆದಂತೆ ವರ್ತಿಸುತ್ತದೆ:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // ಮೊದಲ ಹಂಚಿಕೆ ಇಲ್ಲಿ ನಡೆಯುತ್ತದೆ.
    ///     .into(); // `Arc<[T]>` ಗಾಗಿ ಎರಡನೇ ಹಂಚಿಕೆ ಇಲ್ಲಿ ನಡೆಯುತ್ತದೆ.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ಇದು `Vec<T>` ಅನ್ನು ನಿರ್ಮಿಸಲು ಅಗತ್ಯವಿರುವಷ್ಟು ಬಾರಿ ನಿಗದಿಪಡಿಸುತ್ತದೆ ಮತ್ತು ನಂತರ `Vec<T>` ಅನ್ನು `Arc<[T]>` ಆಗಿ ಪರಿವರ್ತಿಸಲು ಇದು ಒಮ್ಮೆ ಹಂಚುತ್ತದೆ.
    ///
    ///
    /// ## ತಿಳಿದಿರುವ ಉದ್ದದ ಪುನರಾವರ್ತಕರು
    ///
    /// ನಿಮ್ಮ `Iterator` `TrustedLen` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದಾಗ ಮತ್ತು ನಿಖರವಾದ ಗಾತ್ರದಲ್ಲಿದ್ದಾಗ, `Arc<[T]>` ಗಾಗಿ ಒಂದೇ ಹಂಚಿಕೆಯನ್ನು ಮಾಡಲಾಗುತ್ತದೆ.ಉದಾಹರಣೆಗೆ:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // ಒಂದೇ ಹಂಚಿಕೆ ಇಲ್ಲಿ ನಡೆಯುತ್ತದೆ.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// ವಿಶೇಷತೆ trait ಅನ್ನು `Arc<[T]>` ಗೆ ಸಂಗ್ರಹಿಸಲು ಬಳಸಲಾಗುತ್ತದೆ.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // `TrustedLen` ಪುನರಾವರ್ತಕಕ್ಕೆ ಇದೇ ಪರಿಸ್ಥಿತಿ.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // ಸುರಕ್ಷತೆ: ಪುನರಾವರ್ತಕವು ನಿಖರವಾದ ಉದ್ದವನ್ನು ಹೊಂದಿದೆ ಮತ್ತು ನಾವು ಹೊಂದಿದ್ದೇವೆ ಎಂದು ನಾವು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // ಸಾಮಾನ್ಯ ಅನುಷ್ಠಾನಕ್ಕೆ ಹಿಂತಿರುಗಿ.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// ಪಾಯಿಂಟರ್‌ನ ಹಿಂದಿನ ಪೇಲೋಡ್‌ಗಾಗಿ `ArcInner` ಒಳಗೆ ಆಫ್‌ಸೆಟ್ ಪಡೆಯಿರಿ.
///
/// # Safety
///
/// ಪಾಯಿಂಟರ್ ಹಿಂದೆ ಟಿ ಯ ಮಾನ್ಯ ಉದಾಹರಣೆಯನ್ನು ಸೂಚಿಸಬೇಕು (ಮತ್ತು ಮಾನ್ಯ ಮೆಟಾಡೇಟಾವನ್ನು ಹೊಂದಿರಬೇಕು), ಆದರೆ ಟಿ ಅನ್ನು ಕೈಬಿಡಲು ಅನುಮತಿಸಲಾಗಿದೆ.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // ಗಾತ್ರೀಕರಿಸದ ಮೌಲ್ಯವನ್ನು ಆರ್ಕ್‌ಇನ್ನರ್‌ನ ಅಂತ್ಯಕ್ಕೆ ಜೋಡಿಸಿ.
    // ಆರ್ಸಿಬಾಕ್ಸ್ ಎಕ್ಸ್ 00 ಎಕ್ಸ್ ಆಗಿರುವುದರಿಂದ, ಇದು ಯಾವಾಗಲೂ ಮೆಮೊರಿಯಲ್ಲಿ ಕೊನೆಯ ಕ್ಷೇತ್ರವಾಗಿರುತ್ತದೆ.
    // ಸುರಕ್ಷತೆ: ಚೂರುಗಳು, trait ವಸ್ತುಗಳು,
    // ಮತ್ತು ಬಾಹ್ಯ ಪ್ರಕಾರಗಳು, align_of_val_raw ನ ಅವಶ್ಯಕತೆಗಳನ್ನು ಪೂರೈಸಲು ಪ್ರಸ್ತುತ ಇನ್ಪುಟ್ ಸುರಕ್ಷತೆಯ ಅವಶ್ಯಕತೆ ಸಾಕು;ಇದು std ನ ಹೊರಗಡೆ ಅವಲಂಬಿಸದ ಭಾಷೆಯ ಅನುಷ್ಠಾನ ವಿವರವಾಗಿದೆ.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}