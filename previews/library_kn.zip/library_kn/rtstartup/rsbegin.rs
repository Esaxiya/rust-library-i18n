// rsbegin.o ಮತ್ತು rsend.o ಅನ್ನು "compiler runtime startup objects" ಎಂದು ಕರೆಯಲಾಗುತ್ತದೆ.
// ಕಂಪೈಲರ್ ರನ್ಟೈಮ್ ಅನ್ನು ಸರಿಯಾಗಿ ಪ್ರಾರಂಭಿಸಲು ಅಗತ್ಯವಿರುವ ಕೋಡ್ ಅನ್ನು ಅವು ಒಳಗೊಂಡಿರುತ್ತವೆ.
//
// ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದಾದ ಅಥವಾ ಡೈಲಿಬ್ ಇಮೇಜ್ ಅನ್ನು ಲಿಂಕ್ ಮಾಡಿದಾಗ, ಎಲ್ಲಾ ಬಳಕೆದಾರ ಕೋಡ್ ಮತ್ತು ಲೈಬ್ರರಿಗಳು ಈ ಎರಡು ಆಬ್ಜೆಕ್ಟ್ ಫೈಲ್‌ಗಳ ನಡುವೆ "sandwiched" ಆಗಿರುತ್ತವೆ, ಆದ್ದರಿಂದ rsbegin.o ನಿಂದ ಕೋಡ್ ಅಥವಾ ಡೇಟಾವು ಚಿತ್ರದ ಆಯಾ ವಿಭಾಗಗಳಲ್ಲಿ ಪ್ರಥಮವಾಗುತ್ತದೆ, ಆದರೆ rsend.o ನಿಂದ ಕೋಡ್ ಮತ್ತು ಡೇಟಾ ಕೊನೆಯದಾಗಿರುತ್ತದೆ.
// ಈ ಪರಿಣಾಮವನ್ನು ಚಿಹ್ನೆಗಳನ್ನು ಆರಂಭದಲ್ಲಿ ಅಥವಾ ವಿಭಾಗದ ಕೊನೆಯಲ್ಲಿ ಇರಿಸಲು ಮತ್ತು ಅಗತ್ಯವಿರುವ ಯಾವುದೇ ಹೆಡರ್ ಅಥವಾ ಅಡಿಟಿಪ್ಪಣಿಗಳನ್ನು ಸೇರಿಸಲು ಬಳಸಬಹುದು.
//
// ನಿಜವಾದ ಮಾಡ್ಯೂಲ್ ಎಂಟ್ರಿ ಪಾಯಿಂಟ್ ಸಿ ರನ್ಟೈಮ್ ಸ್ಟಾರ್ಟ್ಅಪ್ ಆಬ್ಜೆಕ್ಟ್ನಲ್ಲಿದೆ (ಸಾಮಾನ್ಯವಾಗಿ ಇದನ್ನು `crtX.o` ಎಂದು ಕರೆಯಲಾಗುತ್ತದೆ), ನಂತರ ಇದು ಇತರ ರನ್ಟೈಮ್ ಘಟಕಗಳ ಪ್ರಾರಂಭಿಕ ಕಾಲ್ಬ್ಯಾಕ್ಗಳನ್ನು ಆಹ್ವಾನಿಸುತ್ತದೆ (ಮತ್ತೊಂದು ವಿಶೇಷ ಇಮೇಜ್ ವಿಭಾಗದ ಮೂಲಕ ನೋಂದಾಯಿಸಲಾಗಿದೆ).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // ಸ್ಟಾಕ್ ಫ್ರೇಮ್‌ನ ಆರಂಭದ ಗುರುತುಗಳು ಮಾಹಿತಿ ವಿಭಾಗವನ್ನು ಬಿಚ್ಚಿಡುತ್ತವೆ
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // ಅನ್‌ವೈಂಡರ್‌ನ ಆಂತರಿಕ ಪುಸ್ತಕ-ಕೀಪಿಂಗ್‌ಗಾಗಿ ಸ್ಥಳವನ್ನು ಸ್ಕ್ರಾಚ್ ಮಾಡಿ.
    // ಇದನ್ನು 00 GCC/untind-dw2-fde.h ನಲ್ಲಿ `struct object` ಎಂದು ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿದೆ.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // ಮಾಹಿತಿ registration/deregistration ವಾಡಿಕೆಯಂತೆ ಬಿಚ್ಚಿ.
    // Libpanic_unwind ನ ಡಾಕ್ಸ್ ನೋಡಿ.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // ಮಾಡ್ಯೂಲ್ ಪ್ರಾರಂಭದಲ್ಲಿ ಬಿಚ್ಚುವ ಮಾಹಿತಿಯನ್ನು ನೋಂದಾಯಿಸಿ
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // ಸ್ಥಗಿತಗೊಳಿಸುವಿಕೆಯಲ್ಲಿ ನೋಂದಾಯಿಸಬೇಡಿ
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-ನಿರ್ದಿಷ್ಟ init/uninit ವಾಡಿಕೆಯ ನೋಂದಣಿ
    pub mod mingw_init {
        // ಮಿನ್‌ಜಿಡಬ್ಲ್ಯೂನ ಆರಂಭಿಕ ವಸ್ತುಗಳು (crt0.o/dllcrt0.o) ಆರಂಭಿಕ ಮತ್ತು ನಿರ್ಗಮನದ ಸಮಯದಲ್ಲಿ .ctors ಮತ್ತು .dtors ವಿಭಾಗಗಳಲ್ಲಿ ಜಾಗತಿಕ ಕನ್‌ಸ್ಟ್ರಕ್ಟರ್‌ಗಳನ್ನು ಆಹ್ವಾನಿಸುತ್ತದೆ.
        // ಡಿಎಲ್‌ಎಲ್‌ಗಳ ಸಂದರ್ಭದಲ್ಲಿ, ಡಿಎಲ್‌ಎಲ್ ಅನ್ನು ಲೋಡ್ ಮಾಡಿದಾಗ ಮತ್ತು ಇಳಿಸಿದಾಗ ಇದನ್ನು ಮಾಡಲಾಗುತ್ತದೆ.
        //
        // ಲಿಂಕರ್ ವಿಭಾಗಗಳನ್ನು ವಿಂಗಡಿಸುತ್ತದೆ, ಇದು ನಮ್ಮ ಕಾಲ್‌ಬ್ಯಾಕ್‌ಗಳು ಪಟ್ಟಿಯ ಕೊನೆಯಲ್ಲಿವೆ ಎಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ.
        // ಕನ್‌ಸ್ಟ್ರಕ್ಟರ್‌ಗಳನ್ನು ಹಿಮ್ಮುಖ ಕ್ರಮದಲ್ಲಿ ನಡೆಸಲಾಗುತ್ತಿರುವುದರಿಂದ, ನಮ್ಮ ಕಾಲ್‌ಬ್ಯಾಕ್‌ಗಳು ಕಾರ್ಯಗತಗೊಂಡ ಮೊದಲ ಮತ್ತು ಕೊನೆಯವುಗಳಾಗಿವೆ ಎಂದು ಇದು ಖಾತ್ರಿಗೊಳಿಸುತ್ತದೆ.
        //
        //

        #[link_section = ".ctors.65535"] // .ಕ್ಟರ್ಸ್. *: ಸಿ ಇನಿಶಿಯಲೈಸೇಶನ್ ಕಾಲ್ಬ್ಯಾಕ್
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: ಸಿ ಮುಕ್ತಾಯ ಕಾಲ್ಬ್ಯಾಕ್
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}