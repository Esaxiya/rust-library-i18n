use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr ಕಾಲ್ಬ್ಯಾಕ್ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ, ಅದು ಪ್ರಕ್ರಿಯೆಗೆ ಲಿಂಕ್ ಮಾಡಲಾಗಿರುವ ಪ್ರತಿ DSO ಗಾಗಿ dl_phdr_info ಪಾಯಿಂಟರ್ ಅನ್ನು ಸ್ವೀಕರಿಸುತ್ತದೆ.
    // dl_iterate_phdr ಪುನರಾವರ್ತನೆಯ ಪ್ರಾರಂಭದಿಂದ ಮುಗಿಸುವವರೆಗೆ ಡೈನಾಮಿಕ್ ಲಿಂಕರ್ ಅನ್ನು ಲಾಕ್ ಮಾಡಲಾಗಿದೆ ಎಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ.
    // ಕಾಲ್ಬ್ಯಾಕ್ ಶೂನ್ಯೇತರ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸಿದರೆ ಪುನರಾವರ್ತನೆಯನ್ನು ಮೊದಲೇ ಕೊನೆಗೊಳಿಸಲಾಗುತ್ತದೆ.
    // 'data' ಪ್ರತಿ ಕರೆಯಲ್ಲಿನ ಕಾಲ್‌ಬ್ಯಾಕ್‌ಗೆ ಮೂರನೇ ವಾದವಾಗಿ ರವಾನಿಸಲಾಗುವುದು.
    // 'size' dl_phdr_info ನ ಗಾತ್ರವನ್ನು ನೀಡುತ್ತದೆ.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// ನಾವು ಬಿಲ್ಡ್ ಐಡಿ ಮತ್ತು ಕೆಲವು ಮೂಲಭೂತ ಪ್ರೋಗ್ರಾಂ ಹೆಡರ್ ಡೇಟಾವನ್ನು ಪಾರ್ಸ್ ಮಾಡಬೇಕಾಗಿದೆ, ಅಂದರೆ ನಮಗೆ ಇಎಲ್ಎಫ್ ಸ್ಪೆಕ್‌ನಿಂದ ಸ್ವಲ್ಪ ವಿಷಯ ಬೇಕಾಗುತ್ತದೆ.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// ಈಗ ನಾವು ಫ್ಯೂಷಿಯಾದ ಪ್ರಸ್ತುತ ಡೈನಾಮಿಕ್ ಲಿಂಕರ್ ಬಳಸುವ dl_phdr_info ಪ್ರಕಾರದ ರಚನೆಯನ್ನು ಪುನರಾವರ್ತಿಸಬೇಕು.
// ಕ್ರೋಮಿಯಂ ಈ ಎಬಿಐ ಗಡಿಯನ್ನು ಮತ್ತು ಕ್ರ್ಯಾಶ್‌ಪ್ಯಾಡ್ ಅನ್ನು ಸಹ ಹೊಂದಿದೆ.
// ಅಂತಿಮವಾಗಿ ನಾವು ಈ ಪ್ರಕರಣಗಳನ್ನು ಯಕ್ಷಿಣಿ-ಹುಡುಕಾಟವನ್ನು ಬಳಸಲು ಸರಿಸಲು ಬಯಸುತ್ತೇವೆ ಆದರೆ ಅದನ್ನು ನಾವು ಎಸ್‌ಡಿಕೆ ಯಲ್ಲಿ ಒದಗಿಸಬೇಕಾಗಿದೆ ಮತ್ತು ಅದನ್ನು ಇನ್ನೂ ಮಾಡಲಾಗಿಲ್ಲ.
//
// ಆದ್ದರಿಂದ ನಾವು (ಮತ್ತು ಅವರು) ಈ ವಿಧಾನವನ್ನು ಬಳಸುವುದರಿಂದ ಸಿಲುಕಿಕೊಂಡಿದ್ದೇವೆ, ಅದು ಫ್ಯೂಷಿಯಾ ಲಿಬಿಸಿಯೊಂದಿಗೆ ಬಿಗಿಯಾದ ಜೋಡಣೆಯನ್ನು ಉಂಟುಮಾಡುತ್ತದೆ.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // E_phoff ಮತ್ತು e_phnum ಮಾನ್ಯವಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸಲು ನಮಗೆ ಯಾವುದೇ ಮಾರ್ಗವಿಲ್ಲ.
    // ಲಿಬಿಸಿ ಇದನ್ನು ನಮಗೆ ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು ಆದ್ದರಿಂದ ಇಲ್ಲಿ ಸ್ಲೈಸ್ ರೂಪಿಸುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// ಗುರಿ ವಾಸ್ತುಶಿಲ್ಪದ ಅಂತ್ಯದಲ್ಲಿ ಎಲ್ಫ್_ಪಿಹೆಚ್ಡಿಆರ್ 64-ಬಿಟ್ ಇಎಲ್ಎಫ್ ಪ್ರೋಗ್ರಾಂ ಹೆಡರ್ ಅನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// ಪಿಎಚ್‌ಡಿಆರ್ ಮಾನ್ಯ ಇಎಲ್‌ಎಫ್ ಪ್ರೋಗ್ರಾಂ ಹೆಡರ್ ಮತ್ತು ಅದರ ವಿಷಯಗಳನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // P_addr ಅಥವಾ p_memsz ಮಾನ್ಯವಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸಲು ನಮಗೆ ಯಾವುದೇ ಮಾರ್ಗವಿಲ್ಲ.
    // ಫುಚ್ಸಿಯಾದ ಲಿಬಿಸಿ ಟಿಪ್ಪಣಿಗಳನ್ನು ಮೊದಲು ಪಾರ್ಸ್ ಮಾಡುತ್ತದೆ ಆದರೆ ಇಲ್ಲಿರುವ ಕಾರಣ ಈ ಶೀರ್ಷಿಕೆಗಳು ಮಾನ್ಯವಾಗಿರಬೇಕು.
    //
    // ನೋಟ್‌ಇಟರ್‌ಗೆ ಆಧಾರವಾಗಿರುವ ಡೇಟಾವು ಮಾನ್ಯವಾಗಿರಬೇಕಾಗಿಲ್ಲ ಆದರೆ ಇದಕ್ಕೆ ಮಿತಿಗಳು ಮಾನ್ಯವಾಗಿರಬೇಕು.
    // ಇಲ್ಲಿ ನಮಗೆ ಈ ರೀತಿಯಾಗಿದೆ ಎಂದು ಲಿಬಿಸಿ ಖಚಿತಪಡಿಸಿದೆ ಎಂದು ನಾವು ನಂಬುತ್ತೇವೆ.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// ಬಿಲ್ಡ್ ಐಡಿಗಳಿಗಾಗಿ ಟಿಪ್ಪಣಿ ಪ್ರಕಾರ.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr ಗುರಿಯ ಅಂತ್ಯದಲ್ಲಿ ELF ಟಿಪ್ಪಣಿ ಹೆಡರ್ ಅನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// ಟಿಪ್ಪಣಿ ELF ಟಿಪ್ಪಣಿಯನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ (ಹೆಡರ್ + ವಿಷಯಗಳು).
// ಈ ಹೆಸರನ್ನು u8 ಸ್ಲೈಸ್ ಆಗಿ ಬಿಡಲಾಗಿದೆ ಏಕೆಂದರೆ ಅದು ಯಾವಾಗಲೂ ಶೂನ್ಯವಾಗಿ ಕೊನೆಗೊಳ್ಳುವುದಿಲ್ಲ ಮತ್ತು rust ಬೈಟ್‌ಗಳು ಎರಡೂ ರೀತಿಯಲ್ಲಿ ಹೊಂದಿಕೆಯಾಗಿದೆಯೆ ಎಂದು ಪರಿಶೀಲಿಸಲು ಸಾಕಷ್ಟು ಸುಲಭಗೊಳಿಸುತ್ತದೆ.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// ಟಿಪ್ಪಣಿ ವಿಭಾಗದ ಮೇಲೆ ಸುರಕ್ಷಿತವಾಗಿ ಪುನರಾವರ್ತಿಸಲು ನೋಟ್‌ಇಟರ್ ನಿಮಗೆ ಅನುಮತಿಸುತ್ತದೆ.
// ದೋಷ ಸಂಭವಿಸಿದ ತಕ್ಷಣ ಅದು ಕೊನೆಗೊಳ್ಳುತ್ತದೆ ಅಥವಾ ಹೆಚ್ಚಿನ ಟಿಪ್ಪಣಿಗಳಿಲ್ಲ.
// ಅಮಾನ್ಯ ಡೇಟಾದ ಮೇಲೆ ನೀವು ಪುನರಾವರ್ತಿಸಿದರೆ ಅದು ಯಾವುದೇ ಟಿಪ್ಪಣಿಗಳು ಕಂಡುಬಂದಿಲ್ಲ.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // ಇದು ಪಾಯಿಂಟರ್ ಮತ್ತು ಗಾತ್ರವು ಮಾನ್ಯ ಶ್ರೇಣಿಯ ಬೈಟ್‌ಗಳನ್ನು ಸೂಚಿಸುತ್ತದೆ, ಅದು ಎಲ್ಲವನ್ನೂ ಓದಬಹುದು.
    // ಈ ಬೈಟ್‌ಗಳ ವಿಷಯಗಳು ಯಾವುದಾದರೂ ಆಗಿರಬಹುದು ಆದರೆ ಇದು ಸುರಕ್ಷಿತವಾಗಿರಲು ಶ್ರೇಣಿ ಮಾನ್ಯವಾಗಿರಬೇಕು.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to 'x' ಅನ್ನು 'to'-byte ಜೋಡಣೆಗೆ ಜೋಡಿಸುತ್ತದೆ 'to' 2 ರ ಶಕ್ತಿ ಎಂದು uming ಹಿಸಿ.
// ಇದು ಸಿ/ಸಿ ++ ಇಎಲ್ಎಫ್ ಪಾರ್ಸಿಂಗ್ ಕೋಡ್‌ನಲ್ಲಿ ಪ್ರಮಾಣಿತ ಮಾದರಿಯನ್ನು ಅನುಸರಿಸುತ್ತದೆ (x + to, 1)&-to ಅನ್ನು ಬಳಸಲಾಗುತ್ತದೆ.
// Rust ಬಳಕೆಯನ್ನು ನಿರಾಕರಿಸಲು ನಿಮಗೆ ಅನುಮತಿಸುವುದಿಲ್ಲ ಆದ್ದರಿಂದ ನಾನು ಬಳಸುತ್ತೇನೆ
// ಅದನ್ನು ಮರುಸೃಷ್ಟಿಸಲು 2 ರ ಪೂರಕ ಪರಿವರ್ತನೆ.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 ಸ್ಲೈಸ್‌ನಿಂದ ಸಂಖ್ಯೆ ಬೈಟ್‌ಗಳನ್ನು ಬಳಸುತ್ತದೆ (ಇದ್ದರೆ) ಮತ್ತು ಅಂತಿಮ ಸ್ಲೈಸ್ ಸರಿಯಾಗಿ ಜೋಡಿಸಲ್ಪಟ್ಟಿರುವುದನ್ನು ಖಚಿತಪಡಿಸುತ್ತದೆ.
// ವಿನಂತಿಸಿದ ಬೈಟ್‌ಗಳ ಸಂಖ್ಯೆ ತುಂಬಾ ದೊಡ್ಡದಾಗಿದ್ದರೆ ಅಥವಾ ಸಾಕಷ್ಟು ಬೈಟ್ಗಳು ಅಸ್ತಿತ್ವದಲ್ಲಿಲ್ಲದ ಕಾರಣ ಸ್ಲೈಸ್ ಅನ್ನು ನಂತರ ಮರುರೂಪಿಸಲು ಸಾಧ್ಯವಾಗದಿದ್ದರೆ, ಯಾವುದನ್ನೂ ಹಿಂತಿರುಗಿಸಲಾಗುವುದಿಲ್ಲ ಮತ್ತು ಸ್ಲೈಸ್ ಅನ್ನು ಮಾರ್ಪಡಿಸಲಾಗಿಲ್ಲ.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// ಈ ಕಾರ್ಯವು ಯಾವುದೇ ನೈಜ ಅಸ್ಥಿರತೆಗಳನ್ನು ಹೊಂದಿಲ್ಲ, ಬಹುಶಃ ಕರೆ ಮಾಡುವವರು 'bytes' ಅನ್ನು ಕಾರ್ಯಕ್ಷಮತೆಗಾಗಿ ಜೋಡಿಸಬೇಕು (ಮತ್ತು ಕೆಲವು ವಾಸ್ತುಶಿಲ್ಪಗಳ ನಿಖರತೆ) ಹೊರತುಪಡಿಸಿ.
// Elf_Nhdr ಕ್ಷೇತ್ರಗಳಲ್ಲಿನ ಮೌಲ್ಯಗಳು ಅಸಂಬದ್ಧವಾಗಿರಬಹುದು ಆದರೆ ಈ ಕಾರ್ಯವು ಅಂತಹ ಯಾವುದೇ ವಿಷಯವನ್ನು ಖಚಿತಪಡಿಸುವುದಿಲ್ಲ.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // ಸಾಕಷ್ಟು ಸ್ಥಳಾವಕಾಶ ಇರುವವರೆಗೆ ಇದು ಸುರಕ್ಷಿತವಾಗಿದೆ ಮತ್ತು ಮೇಲಿನ ಹೇಳಿಕೆಯಲ್ಲಿ ಇದು ಅಸುರಕ್ಷಿತವಾಗಿರಬಾರದು ಎಂದು ನಾವು ದೃ confirmed ಪಡಿಸಿದ್ದೇವೆ.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Sice_of: : ಎಂಬುದನ್ನು ಗಮನಿಸಿ<Elf_Nhdr>() ಯಾವಾಗಲೂ 4-ಬೈಟ್ ಅನ್ನು ಹೊಂದಿಸಲಾಗಿದೆ.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // ನಾವು ಅಂತ್ಯವನ್ನು ತಲುಪಿದ್ದೀರಾ ಎಂದು ಪರಿಶೀಲಿಸಿ.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // ನಾವು nhdr ಅನ್ನು ಪರಿವರ್ತಿಸುತ್ತೇವೆ ಆದರೆ ಫಲಿತಾಂಶದ ರಚನೆಯನ್ನು ನಾವು ಎಚ್ಚರಿಕೆಯಿಂದ ಪರಿಗಣಿಸುತ್ತೇವೆ.
        // ನಾವು ನೇಮ್ಜ್ ಅಥವಾ ಡೆಸ್ಕ್ಜ್ ಅನ್ನು ನಂಬುವುದಿಲ್ಲ ಮತ್ತು ಪ್ರಕಾರವನ್ನು ಆಧರಿಸಿ ನಾವು ಯಾವುದೇ ಅಸುರಕ್ಷಿತ ನಿರ್ಧಾರಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುವುದಿಲ್ಲ.
        //
        // ಆದ್ದರಿಂದ ನಾವು ಸಂಪೂರ್ಣ ಕಸವನ್ನು ಹೊರಹಾಕಿದರೂ ನಾವು ಇನ್ನೂ ಸುರಕ್ಷಿತವಾಗಿರಬೇಕು.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// ಒಂದು ವಿಭಾಗವು ಕಾರ್ಯಗತಗೊಳ್ಳುತ್ತದೆ ಎಂದು ಸೂಚಿಸುತ್ತದೆ.
const PERM_X: u32 = 0b00000001;
/// ಒಂದು ವಿಭಾಗವನ್ನು ಬರೆಯಬಹುದಾದದು ಎಂದು ಸೂಚಿಸುತ್ತದೆ.
const PERM_W: u32 = 0b00000010;
/// ಒಂದು ವಿಭಾಗವನ್ನು ಓದಬಲ್ಲದು ಎಂದು ಸೂಚಿಸುತ್ತದೆ.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// ರನ್ಟೈಮ್ನಲ್ಲಿ ಇಎಲ್ಎಫ್ ವಿಭಾಗವನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
struct Segment {
    /// ಈ ವಿಭಾಗದ ವಿಷಯಗಳ ಚಾಲನಾಸಮಯ ವರ್ಚುವಲ್ ವಿಳಾಸವನ್ನು ನೀಡುತ್ತದೆ.
    addr: usize,
    /// ಈ ವಿಭಾಗದ ವಿಷಯಗಳ ಮೆಮೊರಿ ಗಾತ್ರವನ್ನು ನೀಡುತ್ತದೆ.
    size: usize,
    /// ಈ ವಿಭಾಗದ ಮಾಡ್ಯೂಲ್ ವರ್ಚುವಲ್ ವಿಳಾಸವನ್ನು ELF ಫೈಲ್‌ನೊಂದಿಗೆ ನೀಡುತ್ತದೆ.
    mod_rel_addr: usize,
    /// ELF ಫೈಲ್‌ನಲ್ಲಿ ಕಂಡುಬರುವ ಅನುಮತಿಗಳನ್ನು ನೀಡುತ್ತದೆ.
    /// ಆದಾಗ್ಯೂ, ಈ ಅನುಮತಿಗಳು ಚಾಲನಾಸಮಯದಲ್ಲಿ ಇರುವ ಅನುಮತಿಗಳ ಅಗತ್ಯವಿಲ್ಲ.
    flags: Perm,
}

/// ಡಿಎಸ್ಒನಿಂದ ವಿಭಾಗಗಳ ಮೇಲೆ ಒಂದು ಪುನರಾವರ್ತನೆಯನ್ನು ಅನುಮತಿಸುತ್ತದೆ.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// ELF DSO (ಡೈನಾಮಿಕ್ ಹಂಚಿದ ವಸ್ತು) ಅನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
/// ಈ ಪ್ರಕಾರವು ತನ್ನದೇ ಆದ ನಕಲನ್ನು ಮಾಡುವ ಬದಲು ನಿಜವಾದ ಡಿಎಸ್‌ಒನಲ್ಲಿ ಸಂಗ್ರಹವಾಗಿರುವ ಡೇಟಾವನ್ನು ಉಲ್ಲೇಖಿಸುತ್ತದೆ.
struct Dso<'a> {
    /// ಹೆಸರು ಖಾಲಿಯಾಗಿದ್ದರೂ ಡೈನಾಮಿಕ್ ಲಿಂಕರ್ ಯಾವಾಗಲೂ ನಮಗೆ ಹೆಸರನ್ನು ನೀಡುತ್ತದೆ.
    /// ಮುಖ್ಯ ಕಾರ್ಯಗತಗೊಳ್ಳುವ ಸಂದರ್ಭದಲ್ಲಿ ಈ ಹೆಸರು ಖಾಲಿಯಾಗಿರುತ್ತದೆ.
    /// ಹಂಚಿದ ವಸ್ತುವಿನ ಸಂದರ್ಭದಲ್ಲಿ ಅದು ಸೋನೇಮ್ ಆಗಿರುತ್ತದೆ (DT_SONAME ನೋಡಿ).
    name: &'a str,
    /// ಫುಚ್ಸಿಯಾದಲ್ಲಿ ಎಲ್ಲಾ ಬೈನರಿಗಳು ಬಿಲ್ಡ್ ಐಡಿಗಳನ್ನು ಹೊಂದಿವೆ ಆದರೆ ಇದು ಕಟ್ಟುನಿಟ್ಟಾದ ಅವಶ್ಯಕತೆಯಲ್ಲ.
    /// ಬಿಲ್ಡ್_ಐಡಿ ಇಲ್ಲದಿದ್ದರೆ ಡಿಎಸ್ಒ ಮಾಹಿತಿಯನ್ನು ನಿಜವಾದ ಇಎಲ್ಎಫ್ ಫೈಲ್‌ನೊಂದಿಗೆ ಹೊಂದಿಸಲು ಯಾವುದೇ ಮಾರ್ಗವಿಲ್ಲ, ಆದ್ದರಿಂದ ಪ್ರತಿ ಡಿಎಸ್‌ಒಗೆ ಇಲ್ಲಿ ಒಂದನ್ನು ಹೊಂದಿರಬೇಕು.
    ///
    /// ಬಿಲ್ಡ್_ಐಡಿ ಇಲ್ಲದ ಡಿಎಸ್‌ಒಗಳನ್ನು ನಿರ್ಲಕ್ಷಿಸಲಾಗುತ್ತದೆ.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// ಈ ಡಿಎಸ್‌ಒದಲ್ಲಿನ ವಿಭಾಗಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// ಈ ದೋಷಗಳು ಪ್ರತಿ ಡಿಎಸ್‌ಒ ಬಗ್ಗೆ ಮಾಹಿತಿಯನ್ನು ಪಾರ್ಸ್ ಮಾಡುವಾಗ ಉದ್ಭವಿಸುವ ಸಮಸ್ಯೆಗಳನ್ನು ಎನ್‌ಕೋಡ್ ಮಾಡುತ್ತದೆ.
///
enum Error {
    /// ನೇಮ್ ಎರರ್ ಎಂದರೆ ಸಿ ಶೈಲಿಯ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು rust ಸ್ಟ್ರಿಂಗ್ ಆಗಿ ಪರಿವರ್ತಿಸುವಾಗ ದೋಷ ಸಂಭವಿಸಿದೆ.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError ಎಂದರೆ ನಾವು ಬಿಲ್ಡ್ ID ಅನ್ನು ಕಂಡುಹಿಡಿಯಲಿಲ್ಲ.
    /// ಡಿಎಸ್‌ಒಗೆ ಬಿಲ್ಡ್ ಐಡಿ ಇಲ್ಲದಿರುವುದರಿಂದ ಅಥವಾ ಬಿಲ್ಡ್ ಐಡಿ ಹೊಂದಿರುವ ವಿಭಾಗವು ವಿರೂಪಗೊಂಡಿದ್ದರಿಂದಾಗಿರಬಹುದು.
    ///
    BuildIDError,
}

/// ಡೈನಾಮಿಕ್ ಲಿಂಕರ್‌ನಿಂದ ಪ್ರಕ್ರಿಯೆಗೆ ಲಿಂಕ್ ಮಾಡಲಾದ ಪ್ರತಿ ಡಿಎಸ್‌ಒಗೆ 'dso' ಅಥವಾ 'error' ಕರೆಗಳು.
///
///
/// # Arguments
///
/// * `visitor` - ಫೊರಾಚ್ ಡಿಎಸ್ಒ ಎಂಬ ಈಟ್ಸ್ ವಿಧಾನಗಳಲ್ಲಿ ಒಂದನ್ನು ಹೊಂದಿರುವ ಡಿಸೊಪ್ರಿಂಟರ್.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr info.name ಮಾನ್ಯವಾದ ಸ್ಥಳಕ್ಕೆ ಸೂಚಿಸುತ್ತದೆ ಎಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// ಈ ಕಾರ್ಯವು ಡಿಎಸ್ಒನಲ್ಲಿರುವ ಎಲ್ಲಾ ಮಾಹಿತಿಗಾಗಿ ಫ್ಯೂಷಿಯಾ ಸಿಂಬಲೈಜರ್ ಮಾರ್ಕ್ಅಪ್ ಅನ್ನು ಮುದ್ರಿಸುತ್ತದೆ.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}