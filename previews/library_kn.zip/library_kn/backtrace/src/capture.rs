use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// ಒಡೆತನದ ಮತ್ತು ಸ್ವಯಂ-ಒಳಗೊಂಡಿರುವ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ನ ಪ್ರಾತಿನಿಧ್ಯ.
///
/// ಪ್ರೋಗ್ರಾಂನಲ್ಲಿ ವಿವಿಧ ಹಂತಗಳಲ್ಲಿ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಅನ್ನು ಸೆರೆಹಿಡಿಯಲು ಈ ರಚನೆಯನ್ನು ಬಳಸಬಹುದು ಮತ್ತು ನಂತರ ಆ ಸಮಯದಲ್ಲಿ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಏನೆಂದು ಪರೀಕ್ಷಿಸಲು ಬಳಸಲಾಗುತ್ತದೆ.
///
///
/// `Backtrace` ಅದರ `Debug` ಅನುಷ್ಠಾನದ ಮೂಲಕ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ಗಳ ಸುಂದರ ಮುದ್ರಣವನ್ನು ಬೆಂಬಲಿಸುತ್ತದೆ.
///
/// # ಅಗತ್ಯವಿರುವ ವೈಶಿಷ್ಟ್ಯಗಳು
///
/// ಈ ಕಾರ್ಯಕ್ಕೆ `backtrace` crate ನ `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗುತ್ತದೆ.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // ಇಲ್ಲಿರುವ ಚೌಕಟ್ಟುಗಳನ್ನು ಸ್ಟಾಕ್‌ನ ಮೇಲಿನಿಂದ ಕೆಳಕ್ಕೆ ಪಟ್ಟಿ ಮಾಡಲಾಗಿದೆ
    frames: Vec<BacktraceFrame>,
    // `Backtrace::new` ಮತ್ತು `backtrace::trace` ನಂತಹ ಫ್ರೇಮ್‌ಗಳನ್ನು ಬಿಟ್ಟುಬಿಡುವುದು ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ನ ನಿಜವಾದ ಪ್ರಾರಂಭ ಎಂದು ನಾವು ನಂಬುವ ಸೂಚ್ಯಂಕ.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ನಲ್ಲಿ ಫ್ರೇಮ್‌ನ ಸೆರೆಹಿಡಿಯಲಾದ ಆವೃತ್ತಿ.
///
/// ಈ ಪ್ರಕಾರವನ್ನು `Backtrace::frames` ನಿಂದ ಪಟ್ಟಿಯಾಗಿ ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ಸೆರೆಹಿಡಿಯಲಾದ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ನಲ್ಲಿ ಒಂದು ಸ್ಟಾಕ್ ಫ್ರೇಮ್ ಅನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
///
/// # ಅಗತ್ಯವಿರುವ ವೈಶಿಷ್ಟ್ಯಗಳು
///
/// ಈ ಕಾರ್ಯಕ್ಕೆ `backtrace` crate ನ `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗುತ್ತದೆ.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ನಲ್ಲಿ ಚಿಹ್ನೆಯ ಸೆರೆಹಿಡಿಯಲಾದ ಆವೃತ್ತಿ.
///
/// ಈ ಪ್ರಕಾರವನ್ನು `BacktraceFrame::symbols` ನಿಂದ ಪಟ್ಟಿಯಾಗಿ ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ನಲ್ಲಿರುವ ಚಿಹ್ನೆಗಾಗಿ ಮೆಟಾಡೇಟಾವನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
///
/// # ಅಗತ್ಯವಿರುವ ವೈಶಿಷ್ಟ್ಯಗಳು
///
/// ಈ ಕಾರ್ಯಕ್ಕೆ `backtrace` crate ನ `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗುತ್ತದೆ.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// ಈ ಕಾರ್ಯದ ಕಾಲ್‌ಸೈಟ್‌ನಲ್ಲಿ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಅನ್ನು ಸೆರೆಹಿಡಿಯುತ್ತದೆ, ಒಡೆತನದ ಪ್ರಾತಿನಿಧ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// Rust ನಲ್ಲಿ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಅನ್ನು ವಸ್ತುವಾಗಿ ಪ್ರತಿನಿಧಿಸಲು ಈ ಕಾರ್ಯವು ಉಪಯುಕ್ತವಾಗಿದೆ.ಈ ಹಿಂತಿರುಗಿದ ಮೌಲ್ಯವನ್ನು ಎಳೆಗಳಾದ್ಯಂತ ಕಳುಹಿಸಬಹುದು ಮತ್ತು ಬೇರೆಡೆ ಮುದ್ರಿಸಬಹುದು, ಮತ್ತು ಈ ಮೌಲ್ಯದ ಉದ್ದೇಶವು ಸಂಪೂರ್ಣವಾಗಿ ಸ್ವಯಂ ಒಳಗೊಂಡಿರುತ್ತದೆ.
    ///
    /// ಕೆಲವು ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಪೂರ್ಣ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಅನ್ನು ಪಡೆದುಕೊಳ್ಳುವುದು ಮತ್ತು ಅದನ್ನು ಪರಿಹರಿಸುವುದು ಅತ್ಯಂತ ದುಬಾರಿಯಾಗಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    /// ನಿಮ್ಮ ಅಪ್ಲಿಕೇಶನ್‌ಗೆ ವೆಚ್ಚವು ಹೆಚ್ಚು ಇದ್ದರೆ, ಬದಲಿಗೆ `Backtrace::new_unresolved()` ಅನ್ನು ಬಳಸಲು ಶಿಫಾರಸು ಮಾಡಲಾಗಿದೆ, ಇದು ಚಿಹ್ನೆಯ ರೆಸಲ್ಯೂಶನ್ ಹಂತವನ್ನು ತಪ್ಪಿಸುತ್ತದೆ (ಇದು ಸಾಮಾನ್ಯವಾಗಿ ಹೆಚ್ಚು ಸಮಯ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ) ಮತ್ತು ನಂತರದ ದಿನಾಂಕಕ್ಕೆ ಮುಂದೂಡಲು ಅನುವು ಮಾಡಿಕೊಡುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # ಅಗತ್ಯವಿರುವ ವೈಶಿಷ್ಟ್ಯಗಳು
    ///
    /// ಈ ಕಾರ್ಯಕ್ಕೆ `backtrace` crate ನ `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗುತ್ತದೆ.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // ತೆಗೆದುಹಾಕಲು ಇಲ್ಲಿ ಫ್ರೇಮ್ ಇದೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ಬಯಸುತ್ತೇನೆ
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// ಇದು ಯಾವುದೇ ಚಿಹ್ನೆಗಳನ್ನು ಪರಿಹರಿಸುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಹೊರತುಪಡಿಸಿ `new` ಗೆ ಹೋಲುತ್ತದೆ, ಇದು ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಅನ್ನು ವಿಳಾಸಗಳ ಪಟ್ಟಿಯಾಗಿ ಸೆರೆಹಿಡಿಯುತ್ತದೆ.
    ///
    /// ನಂತರದ ಸಮಯದಲ್ಲಿ ಈ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ನ ಚಿಹ್ನೆಗಳನ್ನು ಓದಬಲ್ಲ ಹೆಸರುಗಳಾಗಿ ಪರಿಹರಿಸಲು `resolve` ಕಾರ್ಯವನ್ನು ಕರೆಯಬಹುದು.
    /// ಈ ಕಾರ್ಯವು ಅಸ್ತಿತ್ವದಲ್ಲಿದೆ ಏಕೆಂದರೆ ರೆಸಲ್ಯೂಶನ್ ಪ್ರಕ್ರಿಯೆಯು ಕೆಲವೊಮ್ಮೆ ಗಮನಾರ್ಹ ಸಮಯವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ ಆದರೆ ಯಾವುದೇ ಒಂದು ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಅನ್ನು ವಿರಳವಾಗಿ ಮುದ್ರಿಸಬಹುದು.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // ಚಿಹ್ನೆ ಹೆಸರುಗಳಿಲ್ಲ
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // ಚಿಹ್ನೆಯ ಹೆಸರುಗಳು ಈಗ ಅಸ್ತಿತ್ವದಲ್ಲಿವೆ
    /// ```
    ///
    /// # ಅಗತ್ಯವಿರುವ ವೈಶಿಷ್ಟ್ಯಗಳು
    ///
    /// ಈ ಕಾರ್ಯಕ್ಕೆ `backtrace` crate ನ `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗುತ್ತದೆ.
    ///
    ///
    ///
    #[inline(never)] // ತೆಗೆದುಹಾಕಲು ಇಲ್ಲಿ ಫ್ರೇಮ್ ಇದೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ಬಯಸುತ್ತೇನೆ
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// ಈ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಸೆರೆಹಿಡಿಯಲ್ಪಟ್ಟಾಗ ಫ್ರೇಮ್‌ಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಸ್ಲೈಸ್‌ನ ಮೊದಲ ಪ್ರವೇಶವು `Backtrace::new` ಕಾರ್ಯವಾಗಿದೆ, ಮತ್ತು ಕೊನೆಯ ಫ್ರೇಮ್ ಈ ಥ್ರೆಡ್ ಅಥವಾ ಮುಖ್ಯ ಕಾರ್ಯವು ಹೇಗೆ ಪ್ರಾರಂಭವಾಯಿತು ಎಂಬುದರ ಬಗ್ಗೆ ಏನಾದರೂ ಆಗಿರಬಹುದು.
    ///
    ///
    /// # ಅಗತ್ಯವಿರುವ ವೈಶಿಷ್ಟ್ಯಗಳು
    ///
    /// ಈ ಕಾರ್ಯಕ್ಕೆ `backtrace` crate ನ `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗುತ್ತದೆ.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// ಈ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಅನ್ನು `new_unresolved` ನಿಂದ ರಚಿಸಿದ್ದರೆ, ಈ ಕಾರ್ಯವು ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ನಲ್ಲಿರುವ ಎಲ್ಲಾ ವಿಳಾಸಗಳನ್ನು ಅವುಗಳ ಸಾಂಕೇತಿಕ ಹೆಸರುಗಳಿಗೆ ಪರಿಹರಿಸುತ್ತದೆ.
    ///
    ///
    /// ಈ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಅನ್ನು ಈ ಹಿಂದೆ ಪರಿಹರಿಸಿದ್ದರೆ ಅಥವಾ `new` ಮೂಲಕ ರಚಿಸಿದ್ದರೆ, ಈ ಕಾರ್ಯವು ಏನನ್ನೂ ಮಾಡುವುದಿಲ್ಲ.
    ///
    /// # ಅಗತ್ಯವಿರುವ ವೈಶಿಷ್ಟ್ಯಗಳು
    ///
    /// ಈ ಕಾರ್ಯಕ್ಕೆ `backtrace` crate ನ `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗುತ್ತದೆ.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// `Frame::ip` ನಂತೆಯೇ
    ///
    /// # ಅಗತ್ಯವಿರುವ ವೈಶಿಷ್ಟ್ಯಗಳು
    ///
    /// ಈ ಕಾರ್ಯಕ್ಕೆ `backtrace` crate ನ `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗುತ್ತದೆ.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// `Frame::symbol_address` ನಂತೆಯೇ
    ///
    /// # ಅಗತ್ಯವಿರುವ ವೈಶಿಷ್ಟ್ಯಗಳು
    ///
    /// ಈ ಕಾರ್ಯಕ್ಕೆ `backtrace` crate ನ `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗುತ್ತದೆ.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// `Frame::module_base_address` ನಂತೆಯೇ
    ///
    /// # ಅಗತ್ಯವಿರುವ ವೈಶಿಷ್ಟ್ಯಗಳು
    ///
    /// ಈ ಕಾರ್ಯಕ್ಕೆ `backtrace` crate ನ `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗುತ್ತದೆ.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// ಈ ಫ್ರೇಮ್ ಅನುಗುಣವಾದ ಚಿಹ್ನೆಗಳ ಪಟ್ಟಿಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಸಾಮಾನ್ಯವಾಗಿ ಪ್ರತಿ ಫ್ರೇಮ್‌ಗೆ ಕೇವಲ ಒಂದು ಚಿಹ್ನೆ ಇರುತ್ತದೆ, ಆದರೆ ಕೆಲವೊಮ್ಮೆ ಹಲವಾರು ಕಾರ್ಯಗಳನ್ನು ಒಂದು ಫ್ರೇಮ್‌ಗೆ ಇನ್‌ಲೈನ್ ಮಾಡಿದರೆ ಅನೇಕ ಚಿಹ್ನೆಗಳನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    /// ಪಟ್ಟಿ ಮಾಡಲಾದ ಮೊದಲ ಚಿಹ್ನೆ "innermost function", ಆದರೆ ಕೊನೆಯ ಚಿಹ್ನೆಯು ಹೊರಗಿನ (ಕೊನೆಯ ಕಾಲರ್) ಆಗಿದೆ.
    ///
    /// ಈ ಫ್ರೇಮ್ ಬಗೆಹರಿಸದ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ನಿಂದ ಬಂದಿದ್ದರೆ ಇದು ಖಾಲಿ ಪಟ್ಟಿಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    /// # ಅಗತ್ಯವಿರುವ ವೈಶಿಷ್ಟ್ಯಗಳು
    ///
    /// ಈ ಕಾರ್ಯಕ್ಕೆ `backtrace` crate ನ `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗುತ್ತದೆ.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// `Symbol::name` ನಂತೆಯೇ
    ///
    /// # ಅಗತ್ಯವಿರುವ ವೈಶಿಷ್ಟ್ಯಗಳು
    ///
    /// ಈ ಕಾರ್ಯಕ್ಕೆ `backtrace` crate ನ `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗುತ್ತದೆ.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// `Symbol::addr` ನಂತೆಯೇ
    ///
    /// # ಅಗತ್ಯವಿರುವ ವೈಶಿಷ್ಟ್ಯಗಳು
    ///
    /// ಈ ಕಾರ್ಯಕ್ಕೆ `backtrace` crate ನ `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗುತ್ತದೆ.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// `Symbol::filename` ನಂತೆಯೇ
    ///
    /// # ಅಗತ್ಯವಿರುವ ವೈಶಿಷ್ಟ್ಯಗಳು
    ///
    /// ಈ ಕಾರ್ಯಕ್ಕೆ `backtrace` crate ನ `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗುತ್ತದೆ.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// `Symbol::lineno` ನಂತೆಯೇ
    ///
    /// # ಅಗತ್ಯವಿರುವ ವೈಶಿಷ್ಟ್ಯಗಳು
    ///
    /// ಈ ಕಾರ್ಯಕ್ಕೆ `backtrace` crate ನ `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗುತ್ತದೆ.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// `Symbol::colno` ನಂತೆಯೇ
    ///
    /// # ಅಗತ್ಯವಿರುವ ವೈಶಿಷ್ಟ್ಯಗಳು
    ///
    /// ಈ ಕಾರ್ಯಕ್ಕೆ `backtrace` crate ನ `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗುತ್ತದೆ.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // ಮಾರ್ಗಗಳನ್ನು ಮುದ್ರಿಸುವಾಗ ನಾವು cwd ಅಸ್ತಿತ್ವದಲ್ಲಿದ್ದರೆ ಅದನ್ನು ತೆಗೆದುಹಾಕಲು ಪ್ರಯತ್ನಿಸುತ್ತೇವೆ, ಇಲ್ಲದಿದ್ದರೆ ನಾವು ಮಾರ್ಗವನ್ನು ಹಾಗೆಯೇ ಮುದ್ರಿಸುತ್ತೇವೆ.
        // ನಾವು ಇದನ್ನು ಸಣ್ಣ ಸ್ವರೂಪಕ್ಕಾಗಿ ಮಾತ್ರ ಮಾಡುತ್ತೇವೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಏಕೆಂದರೆ ಅದು ತುಂಬಿದ್ದರೆ ನಾವು ಎಲ್ಲವನ್ನೂ ಮುದ್ರಿಸಲು ಬಯಸುತ್ತೇವೆ.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}