#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ಗಳಿಗಾಗಿ ಫಾರ್ಮ್ಯಾಟರ್.
///
/// ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಸ್ವತಃ ಎಲ್ಲಿಂದ ಬರುತ್ತದೆ ಎಂಬುದನ್ನು ಲೆಕ್ಕಿಸದೆ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಅನ್ನು ಮುದ್ರಿಸಲು ಈ ಪ್ರಕಾರವನ್ನು ಬಳಸಬಹುದು.
/// ನೀವು `Backtrace` ಪ್ರಕಾರವನ್ನು ಹೊಂದಿದ್ದರೆ, ಅದರ `Debug` ಅನುಷ್ಠಾನವು ಈಗಾಗಲೇ ಈ ಮುದ್ರಣ ಸ್ವರೂಪವನ್ನು ಬಳಸುತ್ತದೆ.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// ನಾವು ಮುದ್ರಿಸಬಹುದಾದ ಮುದ್ರಣದ ಶೈಲಿಗಳು
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// ಸಂಬಂಧಿತ ಮಾಹಿತಿಯನ್ನು ಮಾತ್ರ ಒಳಗೊಂಡಿರುವ ಟೆರ್ಸರ್ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಅನ್ನು ಮುದ್ರಿಸುತ್ತದೆ
    Short,
    /// ಸಾಧ್ಯವಿರುವ ಎಲ್ಲ ಮಾಹಿತಿಯನ್ನು ಒಳಗೊಂಡಿರುವ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಅನ್ನು ಮುದ್ರಿಸುತ್ತದೆ
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// ಹೊಸ `BacktraceFmt` ಅನ್ನು ರಚಿಸಿ ಅದು ಒದಗಿಸಿದ `fmt` ಗೆ output ಟ್‌ಪುಟ್ ಬರೆಯುತ್ತದೆ.
    ///
    /// `format` ಆರ್ಗ್ಯುಮೆಂಟ್ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಅನ್ನು ಮುದ್ರಿಸಿದ ಶೈಲಿಯನ್ನು ನಿಯಂತ್ರಿಸುತ್ತದೆ, ಮತ್ತು `print_path` ಆರ್ಗ್ಯುಮೆಂಟ್ ಫೈಲ್ ಹೆಸರುಗಳ `BytesOrWideString` ನಿದರ್ಶನಗಳನ್ನು ಮುದ್ರಿಸಲು ಬಳಸಲಾಗುತ್ತದೆ.
    /// ಈ ಪ್ರಕಾರವು ಫೈಲ್ ಹೆಸರುಗಳ ಯಾವುದೇ ಮುದ್ರಣವನ್ನು ಮಾಡುವುದಿಲ್ಲ, ಆದರೆ ಹಾಗೆ ಮಾಡಲು ಈ ಕಾಲ್ಬ್ಯಾಕ್ ಅಗತ್ಯವಿದೆ.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ಗೆ ಮುದ್ರಿಸಬೇಕಾದ ಮುನ್ನುಡಿಯನ್ನು ಮುದ್ರಿಸುತ್ತದೆ.
    ///
    /// ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ಗಳನ್ನು ನಂತರ ಸಂಪೂರ್ಣವಾಗಿ ಸಂಕೇತಿಸಲು ಕೆಲವು ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಇದು ಅಗತ್ಯವಾಗಿರುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ ಇದು `BacktraceFmt` ಅನ್ನು ರಚಿಸಿದ ನಂತರ ನೀವು ಕರೆಯುವ ಮೊದಲ ವಿಧಾನವಾಗಿರಬೇಕು.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ .ಟ್‌ಪುಟ್‌ಗೆ ಫ್ರೇಮ್ ಅನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///
    /// ಈ ಬದ್ಧತೆಯು `BacktraceFrameFmt` ನ RAII ನಿದರ್ಶನವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಇದನ್ನು ವಾಸ್ತವವಾಗಿ ಫ್ರೇಮ್ ಅನ್ನು ಮುದ್ರಿಸಲು ಬಳಸಬಹುದು, ಮತ್ತು ವಿನಾಶದ ಮೇಲೆ ಅದು ಫ್ರೇಮ್ ಕೌಂಟರ್ ಅನ್ನು ಹೆಚ್ಚಿಸುತ್ತದೆ.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ .ಟ್‌ಪುಟ್ ಅನ್ನು ಪೂರ್ಣಗೊಳಿಸುತ್ತದೆ.
    ///
    /// ಇದು ಪ್ರಸ್ತುತ ನೋ-ಆಪ್ ಆದರೆ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಸ್ವರೂಪಗಳೊಂದಿಗೆ future ಹೊಂದಾಣಿಕೆಗಾಗಿ ಸೇರಿಸಲಾಗಿದೆ.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // future ಸೇರ್ಪಡೆಗಳನ್ನು ಅನುಮತಿಸಲು ಈ hook ಸೇರಿದಂತೆ ಪ್ರಸ್ತುತ ಯಾವುದೇ ಆಪ್ ಇಲ್ಲ.
        Ok(())
    }
}

/// ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ನ ಕೇವಲ ಒಂದು ಫ್ರೇಮ್‌ಗಾಗಿ ಫಾರ್ಮ್ಯಾಟರ್.
///
/// ಈ ಪ್ರಕಾರವನ್ನು `BacktraceFmt::frame` ಕಾರ್ಯದಿಂದ ರಚಿಸಲಾಗಿದೆ.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// ಈ ಫ್ರೇಮ್ ಫಾರ್ಮ್ಯಾಟರ್ನೊಂದಿಗೆ `BacktraceFrame` ಅನ್ನು ಮುದ್ರಿಸುತ್ತದೆ.
    ///
    /// ಇದು `BacktraceFrame` ಒಳಗೆ ಎಲ್ಲಾ `BacktraceSymbol` ನಿದರ್ಶನಗಳನ್ನು ಪುನರಾವರ್ತಿತವಾಗಿ ಮುದ್ರಿಸುತ್ತದೆ.
    ///
    /// # ಅಗತ್ಯವಿರುವ ವೈಶಿಷ್ಟ್ಯಗಳು
    ///
    /// ಈ ಕಾರ್ಯಕ್ಕೆ `backtrace` crate ನ `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗುತ್ತದೆ.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// `BacktraceFrame` ಒಳಗೆ `BacktraceSymbol` ಅನ್ನು ಮುದ್ರಿಸುತ್ತದೆ.
    ///
    /// # ಅಗತ್ಯವಿರುವ ವೈಶಿಷ್ಟ್ಯಗಳು
    ///
    /// ಈ ಕಾರ್ಯಕ್ಕೆ `backtrace` crate ನ `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗುತ್ತದೆ.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: ನಾವು ಯಾವುದನ್ನೂ ಮುದ್ರಿಸುವುದನ್ನು ಕೊನೆಗೊಳಿಸುವುದಿಲ್ಲ ಎಂಬುದು ಉತ್ತಮವಲ್ಲ
            // utf8 ಅಲ್ಲದ ಫೈಲ್ ಹೆಸರುಗಳೊಂದಿಗೆ.
            // ಅದೃಷ್ಟವಶಾತ್ ಬಹುತೇಕ ಎಲ್ಲವೂ utf8 ಆದ್ದರಿಂದ ಇದು ತುಂಬಾ ಕೆಟ್ಟದಾಗಿರಬಾರದು.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// ಕಚ್ಚಾ ಪತ್ತೆಯಾದ `Frame` ಮತ್ತು `Symbol` ಅನ್ನು ಮುದ್ರಿಸುತ್ತದೆ, ಸಾಮಾನ್ಯವಾಗಿ ಈ crate ನ ಕಚ್ಚಾ ಕಾಲ್‌ಬ್ಯಾಕ್‌ಗಳಿಂದ.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ .ಟ್‌ಪುಟ್‌ಗೆ ಕಚ್ಚಾ ಚೌಕಟ್ಟನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///
    /// ಈ ವಿಧಾನವು ಹಿಂದಿನದಕ್ಕಿಂತ ಭಿನ್ನವಾಗಿ, ವಿಭಿನ್ನ ಸ್ಥಳಗಳಿಂದ ಮೂಲವಾಗಿದ್ದರೆ ಕಚ್ಚಾ ವಾದಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    /// ಇದನ್ನು ಒಂದು ಫ್ರೇಮ್‌ಗೆ ಹಲವು ಬಾರಿ ಕರೆಯಬಹುದು ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// ಕಾಲಮ್ ಮಾಹಿತಿಯನ್ನು ಒಳಗೊಂಡಂತೆ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ output ಟ್‌ಪುಟ್‌ಗೆ ಕಚ್ಚಾ ಫ್ರೇಮ್ ಅನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///
    /// ಈ ವಿಧಾನವು ಹಿಂದಿನಂತೆ, ವಿಭಿನ್ನ ಸ್ಥಳಗಳಿಂದ ಮೂಲವಾಗಿದ್ದರೆ ಕಚ್ಚಾ ವಾದಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    /// ಇದನ್ನು ಒಂದು ಫ್ರೇಮ್‌ಗೆ ಹಲವು ಬಾರಿ ಕರೆಯಬಹುದು ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // ಒಂದು ಪ್ರಕ್ರಿಯೆಯಲ್ಲಿ ಫ್ಯೂಷಿಯಾಗೆ ಸಂಕೇತಿಸಲು ಸಾಧ್ಯವಾಗುವುದಿಲ್ಲ ಆದ್ದರಿಂದ ಇದು ವಿಶೇಷ ಸ್ವರೂಪವನ್ನು ಹೊಂದಿದ್ದು ಅದನ್ನು ನಂತರ ಸಂಕೇತಿಸಲು ಬಳಸಬಹುದು.
        // ನಮ್ಮ ಸ್ವಂತ ಸ್ವರೂಪದಲ್ಲಿ ವಿಳಾಸಗಳನ್ನು ಮುದ್ರಿಸುವ ಬದಲು ಅದನ್ನು ಮುದ್ರಿಸಿ.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // "null" ಫ್ರೇಮ್‌ಗಳನ್ನು ಮುದ್ರಿಸುವ ಅಗತ್ಯವಿಲ್ಲ, ಇದರರ್ಥ ಮೂಲತಃ ಸಿಸ್ಟಂ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಸೂಪರ್ ದೂರದವರೆಗೆ ಪತ್ತೆಹಚ್ಚಲು ಸ್ವಲ್ಪ ಉತ್ಸುಕವಾಗಿದೆ.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // ಎಸ್‌ಜಿಎಕ್ಸ್ ಎನ್‌ಕ್ಲೇವ್‌ನಲ್ಲಿ ಟಿಸಿಬಿ ಗಾತ್ರವನ್ನು ಕಡಿಮೆ ಮಾಡಲು, ಚಿಹ್ನೆ ರೆಸಲ್ಯೂಶನ್ ಕಾರ್ಯವನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ನಾವು ಬಯಸುವುದಿಲ್ಲ.
        // ಬದಲಾಗಿ, ವಿಳಾಸದ ಆಫ್‌ಸೆಟ್ ಅನ್ನು ನಾವು ಇಲ್ಲಿ ಮುದ್ರಿಸಬಹುದು, ಅದನ್ನು ನಂತರ ಕಾರ್ಯವನ್ನು ಸರಿಪಡಿಸಲು ಮ್ಯಾಪ್ ಮಾಡಬಹುದು.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // ಫ್ರೇಮ್‌ನ ಸೂಚ್ಯಂಕ ಮತ್ತು ಫ್ರೇಮ್‌ನ ಐಚ್ al ಿಕ ಸೂಚನಾ ಪಾಯಿಂಟರ್ ಅನ್ನು ಮುದ್ರಿಸಿ.
        // ನಾವು ಈ ಫ್ರೇಮ್‌ನ ಮೊದಲ ಚಿಹ್ನೆಯನ್ನು ಮೀರಿದ್ದರೆ ನಾವು ಸೂಕ್ತವಾದ ಜಾಗವನ್ನು ಮುದ್ರಿಸುತ್ತೇವೆ.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // ಮುಂದೆ ನಾವು ಪೂರ್ಣ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಆಗಿದ್ದರೆ ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ ಪರ್ಯಾಯ ಫಾರ್ಮ್ಯಾಟಿಂಗ್ ಬಳಸಿ ಚಿಹ್ನೆಯ ಹೆಸರನ್ನು ಬರೆಯಿರಿ.
        // ಇಲ್ಲಿ ನಾವು ಹೆಸರಿಲ್ಲದ ಚಿಹ್ನೆಗಳನ್ನು ಸಹ ನಿರ್ವಹಿಸುತ್ತೇವೆ,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // ಮತ್ತು ಕೊನೆಯದಾಗಿ, ಅವರು ಲಭ್ಯವಿದ್ದರೆ filename/line ಸಂಖ್ಯೆಯನ್ನು ಮುದ್ರಿಸಿ.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line ಚಿಹ್ನೆಯ ಹೆಸರಿನಲ್ಲಿ ಸಾಲುಗಳಲ್ಲಿ ಮುದ್ರಿಸಲಾಗುತ್ತದೆ, ಆದ್ದರಿಂದ ನಮ್ಮನ್ನು ಬಲಕ್ಕೆ ಜೋಡಿಸಲು ಕೆಲವು ಸೂಕ್ತವಾದ ಜಾಗಗಳನ್ನು ಮುದ್ರಿಸಿ.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // ಫೈಲ್ ಹೆಸರನ್ನು ಮುದ್ರಿಸಲು ಮತ್ತು ನಂತರ ಸಾಲಿನ ಸಂಖ್ಯೆಯನ್ನು ಮುದ್ರಿಸಲು ನಮ್ಮ ಆಂತರಿಕ ಕಾಲ್‌ಬ್ಯಾಕ್‌ಗೆ ಪ್ರತಿನಿಧಿಸಿ.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // ಲಭ್ಯವಿದ್ದರೆ ಕಾಲಮ್ ಸಂಖ್ಯೆಯನ್ನು ಸೇರಿಸಿ.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // ನಾವು ಫ್ರೇಮ್‌ನ ಮೊದಲ ಚಿಹ್ನೆಯ ಬಗ್ಗೆ ಮಾತ್ರ ಕಾಳಜಿ ವಹಿಸುತ್ತೇವೆ
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}