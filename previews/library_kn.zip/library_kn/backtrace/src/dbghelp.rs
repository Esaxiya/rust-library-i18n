//! Windows ನಲ್ಲಿ dbghelp ಬೈಂಡಿಂಗ್‌ಗಳನ್ನು ನಿರ್ವಹಿಸಲು ಸಹಾಯ ಮಾಡುವ ಮಾಡ್ಯೂಲ್
//!
//! Windows ನಲ್ಲಿನ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ಗಳು (ಕನಿಷ್ಠ MSVC ಗಾಗಿ) ಹೆಚ್ಚಾಗಿ `dbghelp.dll` ಮತ್ತು ಅದು ಒಳಗೊಂಡಿರುವ ವಿವಿಧ ಕಾರ್ಯಗಳ ಮೂಲಕ ನಡೆಸಲ್ಪಡುತ್ತವೆ.
//! ಈ ಕಾರ್ಯಗಳನ್ನು ಪ್ರಸ್ತುತ `dbghelp.dll` ಗೆ ಸ್ಥಿರವಾಗಿ ಲಿಂಕ್ ಮಾಡುವ ಬದಲು *ಕ್ರಿಯಾತ್ಮಕವಾಗಿ* ಲೋಡ್ ಮಾಡಲಾಗಿದೆ.
//! ಇದನ್ನು ಪ್ರಸ್ತುತ ಸ್ಟ್ಯಾಂಡರ್ಡ್ ಲೈಬ್ರರಿಯಿಂದ ಮಾಡಲಾಗುತ್ತದೆ (ಮತ್ತು ಅಲ್ಲಿ ಸಿದ್ಧಾಂತದಲ್ಲಿ ಇದು ಅಗತ್ಯವಾಗಿರುತ್ತದೆ), ಆದರೆ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ಗಳು ಸಾಮಾನ್ಯವಾಗಿ ಸಾಕಷ್ಟು ಐಚ್ .ಿಕವಾಗಿರುವುದರಿಂದ ಗ್ರಂಥಾಲಯದ ಸ್ಥಿರ ಡಿಎಲ್ ಅವಲಂಬನೆಗಳನ್ನು ಕಡಿಮೆ ಮಾಡಲು ಸಹಾಯ ಮಾಡುವ ಪ್ರಯತ್ನವಾಗಿದೆ.
//!
//! ಹೀಗೆ ಹೇಳಬೇಕೆಂದರೆ, `dbghelp.dll` ಯಾವಾಗಲೂ ಯಶಸ್ವಿಯಾಗಿ Windows ನಲ್ಲಿ ಲೋಡ್ ಆಗುತ್ತದೆ.
//!
//! ಗಮನಿಸಿ, ನಾವು ಈ ಎಲ್ಲಾ ಬೆಂಬಲವನ್ನು ಕ್ರಿಯಾತ್ಮಕವಾಗಿ ಲೋಡ್ ಮಾಡುತ್ತಿರುವುದರಿಂದ ನಾವು ನಿಜವಾಗಿಯೂ `winapi` ನಲ್ಲಿ ಕಚ್ಚಾ ವ್ಯಾಖ್ಯಾನಗಳನ್ನು ಬಳಸಲಾಗುವುದಿಲ್ಲ, ಆದರೆ ಫಂಕ್ಷನ್ ಪಾಯಿಂಟರ್ ಪ್ರಕಾರಗಳನ್ನು ನಾವೇ ವ್ಯಾಖ್ಯಾನಿಸಬೇಕು ಮತ್ತು ಅದನ್ನು ಬಳಸಬೇಕಾಗುತ್ತದೆ.
//! ವಿನಾಪಿಯನ್ನು ನಕಲು ಮಾಡುವ ವ್ಯವಹಾರದಲ್ಲಿರಲು ನಾವು ನಿಜವಾಗಿಯೂ ಬಯಸುವುದಿಲ್ಲ, ಆದ್ದರಿಂದ ನಮ್ಮಲ್ಲಿ Cargo ವೈಶಿಷ್ಟ್ಯ `verify-winapi` ಇದೆ, ಅದು ಎಲ್ಲಾ ಬೈಂಡಿಂಗ್‌ಗಳು ವಿನಾಪಿಯಲ್ಲಿರುವವರಿಗೆ ಹೊಂದಿಕೆಯಾಗುತ್ತದೆ ಮತ್ತು ಈ ವೈಶಿಷ್ಟ್ಯವನ್ನು CI ನಲ್ಲಿ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗಿದೆ.
//!
//! ಅಂತಿಮವಾಗಿ, `dbghelp.dll` ಗಾಗಿ dll ಅನ್ನು ಎಂದಿಗೂ ಇಳಿಸಲಾಗುವುದಿಲ್ಲ ಮತ್ತು ಅದು ಪ್ರಸ್ತುತ ಉದ್ದೇಶಪೂರ್ವಕವಾಗಿದೆ ಎಂಬುದನ್ನು ನೀವು ಇಲ್ಲಿ ಗಮನಿಸಬಹುದು.
//! ನಾವು ಜಾಗತಿಕವಾಗಿ ಅದನ್ನು ಸಂಗ್ರಹಿಸಬಹುದು ಮತ್ತು API ಗೆ ಕರೆಗಳ ನಡುವೆ ಬಳಸಬಹುದು, ದುಬಾರಿ loads/unloads ಅನ್ನು ತಪ್ಪಿಸಬಹುದು ಎಂಬುದು ಆಲೋಚನೆ.
//! ಲೀಕ್ ಡಿಟೆಕ್ಟರ್‌ಗಳಿಗೆ ಇದು ಸಮಸ್ಯೆಯಾಗಿದ್ದರೆ ಅಥವಾ ನಾವು ಅಲ್ಲಿಗೆ ಬಂದಾಗ ಸೇತುವೆಯನ್ನು ದಾಟಬಹುದು.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// ವಿನಾಪಿಯಲ್ಲಿಯೇ ಇರದಂತೆ `SymGetOptions` ಮತ್ತು `SymSetOptions` ಸುತ್ತಲೂ ಕೆಲಸ ಮಾಡಿ.
// ಇಲ್ಲದಿದ್ದರೆ ನಾವು ವಿನಾಪಿ ವಿರುದ್ಧ ಎರಡು ಬಾರಿ ಪರಿಶೀಲಿಸುವಾಗ ಮಾತ್ರ ಇದನ್ನು ಬಳಸಲಾಗುತ್ತದೆ.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // ವಿನಾಪಿಯಲ್ಲಿ ಇನ್ನೂ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿಲ್ಲ
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // ಇದನ್ನು ವಿನಾಪಿಯಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿದೆ, ಆದರೆ ಇದು ತಪ್ಪಾಗಿದೆ (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // ವಿನಾಪಿಯಲ್ಲಿ ಇನ್ನೂ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿಲ್ಲ
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// ಈ ಮ್ಯಾಕ್ರೋವನ್ನು `Dbghelp` ರಚನೆಯನ್ನು ವ್ಯಾಖ್ಯಾನಿಸಲು ಬಳಸಲಾಗುತ್ತದೆ, ಅದು ಆಂತರಿಕವಾಗಿ ನಾವು ಲೋಡ್ ಮಾಡಬಹುದಾದ ಎಲ್ಲಾ ಕಾರ್ಯ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಹೊಂದಿರುತ್ತದೆ.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// `dbghelp.dll` ಗಾಗಿ ಲೋಡ್ ಮಾಡಲಾದ ಡಿಎಲ್ಎಲ್
            dll: HMODULE,

            // ನಾವು ಬಳಸಬಹುದಾದ ಪ್ರತಿಯೊಂದು ಕಾರ್ಯಕ್ಕೂ ಪ್ರತಿಯೊಂದು ಕಾರ್ಯ ಪಾಯಿಂಟರ್
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // ಆರಂಭದಲ್ಲಿ ನಾವು ಡಿಎಲ್‌ಎಲ್ ಅನ್ನು ಲೋಡ್ ಮಾಡಿಲ್ಲ
            dll: 0 as *mut _,
            // ಪ್ರಾರಂಭದಲ್ಲಿ ಎಲ್ಲಾ ಕಾರ್ಯಗಳನ್ನು ಕ್ರಿಯಾತ್ಮಕವಾಗಿ ಲೋಡ್ ಮಾಡಬೇಕೆಂದು ಹೇಳಲು ಶೂನ್ಯಕ್ಕೆ ಹೊಂದಿಸಲಾಗಿದೆ.
            //
            $($name: 0,)*
        };

        // ಪ್ರತಿ ಕಾರ್ಯ ಪ್ರಕಾರಕ್ಕೆ ಅನುಕೂಲಕರ ಟೈಪ್‌ಡೆಫ್.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll` ತೆರೆಯಲು ಪ್ರಯತ್ನಿಸುತ್ತದೆ.
            /// ಅದು ಕಾರ್ಯನಿರ್ವಹಿಸಿದರೆ ಯಶಸ್ಸನ್ನು ನೀಡುತ್ತದೆ ಅಥವಾ `LoadLibraryW` ವಿಫಲವಾದರೆ ದೋಷವನ್ನು ನೀಡುತ್ತದೆ.
            ///
            /// ಲೈಬ್ರರಿಯನ್ನು ಈಗಾಗಲೇ ಲೋಡ್ ಮಾಡಿದ್ದರೆ Panics.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // ನಾವು ಬಳಸಲು ಬಯಸುವ ಪ್ರತಿಯೊಂದು ವಿಧಾನದ ಕಾರ್ಯ.
            // ಇದನ್ನು ಕರೆಯುವಾಗ ಸಂಗ್ರಹಿಸಿದ ಕಾರ್ಯ ಪಾಯಿಂಟರ್ ಅನ್ನು ಓದುತ್ತದೆ ಅಥವಾ ಅದನ್ನು ಲೋಡ್ ಮಾಡುತ್ತದೆ ಮತ್ತು ಲೋಡ್ ಮಾಡಿದ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
            // ಲೋಡ್ಗಳು ಯಶಸ್ವಿಯಾಗಲು ಪ್ರತಿಪಾದಿಸಲಾಗುತ್ತದೆ.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // ಡಿಬಿಹೆಲ್ಪ್ ಕಾರ್ಯಗಳನ್ನು ಉಲ್ಲೇಖಿಸಲು ಸ್ವಚ್ clean ಗೊಳಿಸುವ ಲಾಕ್‌ಗಳನ್ನು ಬಳಸಲು ಅನುಕೂಲಕರ ಪ್ರಾಕ್ಸಿ.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// ಈ crate ನಿಂದ `dbghelp` API ಕಾರ್ಯಗಳನ್ನು ಪ್ರವೇಶಿಸಲು ಅಗತ್ಯವಿರುವ ಎಲ್ಲಾ ಬೆಂಬಲವನ್ನು ಪ್ರಾರಂಭಿಸಿ.
///
///
/// ಈ ಕಾರ್ಯವು **ಸುರಕ್ಷಿತ** ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಇದು ಆಂತರಿಕವಾಗಿ ತನ್ನದೇ ಆದ ಸಿಂಕ್ರೊನೈಸೇಶನ್ ಅನ್ನು ಹೊಂದಿದೆ.
/// ಈ ಕಾರ್ಯವನ್ನು ಪುನರಾವರ್ತಿತವಾಗಿ ಅನೇಕ ಬಾರಿ ಕರೆಯುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // ಈ ಕಾರ್ಯವನ್ನು ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡುವುದು ನಾವು ಮೊದಲು ಮಾಡಬೇಕಾಗಿರುವುದು.ಇದನ್ನು ಇತರ ಎಳೆಗಳಿಂದ ಏಕಕಾಲದಲ್ಲಿ ಅಥವಾ ಪುನರಾವರ್ತಿತವಾಗಿ ಒಂದು ಥ್ರೆಡ್‌ನಲ್ಲಿ ಕರೆಯಬಹುದು.
        // ಅದಕ್ಕಿಂತಲೂ ಇದು ಚಾತುರ್ಯದದ್ದಾಗಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ ಏಕೆಂದರೆ ನಾವು ಇಲ್ಲಿ ಬಳಸುತ್ತಿರುವ `dbghelp`,*ಸಹ* ಈ ಪ್ರಕ್ರಿಯೆಯಲ್ಲಿ ಇತರ ಎಲ್ಲ ಕರೆ ಮಾಡುವವರೊಂದಿಗೆ `dbghelp` ಗೆ ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡಬೇಕಾಗಿದೆ.
        //
        // ಒಂದೇ ಪ್ರಕ್ರಿಯೆಯಲ್ಲಿ `dbghelp` ಗೆ ಅನೇಕ ಕರೆಗಳು ಸಾಮಾನ್ಯವಾಗಿ ಇರುವುದಿಲ್ಲ ಮತ್ತು ನಾವು ಅದನ್ನು ಮಾತ್ರ ಪ್ರವೇಶಿಸುತ್ತಿದ್ದೇವೆ ಎಂದು ನಾವು ಸುರಕ್ಷಿತವಾಗಿ can ಹಿಸಬಹುದು.
        // ಹೇಗಾದರೂ, ನಾವು ಚಿಂತಿಸಬೇಕಾದ ಒಂದು ಪ್ರಾಥಮಿಕ ಇತರ ಬಳಕೆದಾರರು ವಿಪರ್ಯಾಸವೆಂದರೆ ನಾವೇ, ಆದರೆ ಪ್ರಮಾಣಿತ ಗ್ರಂಥಾಲಯದಲ್ಲಿ.
        // Rust ಸ್ಟ್ಯಾಂಡರ್ಡ್ ಲೈಬ್ರರಿ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಬೆಂಬಲಕ್ಕಾಗಿ ಈ crate ಅನ್ನು ಅವಲಂಬಿಸಿರುತ್ತದೆ, ಮತ್ತು ಈ crate crates.io ನಲ್ಲಿಯೂ ಅಸ್ತಿತ್ವದಲ್ಲಿದೆ.
        // ಇದರರ್ಥ ಸ್ಟ್ಯಾಂಡರ್ಡ್ ಲೈಬ್ರರಿ panic ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಅನ್ನು ಮುದ್ರಿಸುತ್ತಿದ್ದರೆ ಅದು crates.io ನಿಂದ ಬರುವ ಈ crate ನೊಂದಿಗೆ ಓಡಬಹುದು ಮತ್ತು ಇದು ಸೆಗ್‌ಫಾಲ್ಟ್‌ಗಳಿಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
        //
        // ಈ ಸಿಂಕ್ರೊನೈಸೇಶನ್ ಸಮಸ್ಯೆಯನ್ನು ಪರಿಹರಿಸಲು ಸಹಾಯ ಮಾಡಲು ನಾವು ಇಲ್ಲಿ ವಿಂಡೋಸ್-ನಿರ್ದಿಷ್ಟ ಟ್ರಿಕ್ ಅನ್ನು ಬಳಸುತ್ತೇವೆ (ಇದು ಸಿಂಕ್ರೊನೈಸೇಶನ್ ಬಗ್ಗೆ ವಿಂಡೋಸ್-ನಿರ್ದಿಷ್ಟ ನಿರ್ಬಂಧವಾಗಿದೆ).
        // ಈ ಕರೆಯನ್ನು ರಕ್ಷಿಸಲು ನಾವು ಮ್ಯೂಟೆಕ್ಸ್ ಹೆಸರಿನ *ಸೆಷನ್-ಲೋಕಲ್* ಅನ್ನು ರಚಿಸುತ್ತೇವೆ.
        // ಇಲ್ಲಿರುವ ಉದ್ದೇಶವೆಂದರೆ ಸ್ಟ್ಯಾಂಡರ್ಡ್ ಲೈಬ್ರರಿ ಮತ್ತು ಈ crate ಇಲ್ಲಿ ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡಲು Rust-ಮಟ್ಟದ API ಗಳನ್ನು ಹಂಚಿಕೊಳ್ಳಬೇಕಾಗಿಲ್ಲ ಆದರೆ ಅವುಗಳು ಒಂದಕ್ಕೊಂದು ಸಿಂಕ್ರೊನೈಸ್ ಆಗುತ್ತಿದೆಯೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ತೆರೆಮರೆಯಲ್ಲಿ ಕೆಲಸ ಮಾಡಬಹುದು.
        //
        // ಈ ಕಾರ್ಯವನ್ನು ಸ್ಟ್ಯಾಂಡರ್ಡ್ ಲೈಬ್ರರಿಯ ಮೂಲಕ ಅಥವಾ crates.io ಮೂಲಕ ಕರೆಯುವಾಗ ಅದೇ ಮ್ಯೂಟೆಕ್ಸ್ ಅನ್ನು ಸ್ವಾಧೀನಪಡಿಸಿಕೊಳ್ಳಲಾಗುತ್ತಿದೆ ಎಂದು ನಾವು ಖಚಿತವಾಗಿ ಹೇಳಬಹುದು.
        //
        // ಆದ್ದರಿಂದ ನಾವು ಇಲ್ಲಿ ಮಾಡುವ ಮೊದಲ ಕೆಲಸವೆಂದರೆ ನಾವು ಪರಮಾಣುವಾಗಿ `HANDLE` ಅನ್ನು ರಚಿಸುತ್ತೇವೆ, ಅದು Windows ನಲ್ಲಿ ಹೆಸರಿಸಲಾದ ಮ್ಯೂಟೆಕ್ಸ್ ಆಗಿದೆ.
        // ಈ ಕಾರ್ಯವನ್ನು ನಿರ್ದಿಷ್ಟವಾಗಿ ಹಂಚಿಕೊಳ್ಳುವ ಇತರ ಎಳೆಗಳೊಂದಿಗೆ ನಾವು ಸ್ವಲ್ಪ ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡುತ್ತೇವೆ ಮತ್ತು ಈ ಕಾರ್ಯದ ಪ್ರತಿ ನಿದರ್ಶನಕ್ಕೆ ಕೇವಲ ಒಂದು ಹ್ಯಾಂಡಲ್ ಅನ್ನು ರಚಿಸಲಾಗಿದೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳುತ್ತೇವೆ.
        // ಹ್ಯಾಂಡಲ್ ಅನ್ನು ಜಾಗತಿಕವಾಗಿ ಸಂಗ್ರಹಿಸಿದ ನಂತರ ಅದನ್ನು ಎಂದಿಗೂ ಮುಚ್ಚಲಾಗುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
        //
        // ನಾವು ನಿಜವಾಗಿಯೂ ಲಾಕ್‌ಗೆ ಹೋದ ನಂತರ ನಾವು ಅದನ್ನು ಪಡೆದುಕೊಳ್ಳುತ್ತೇವೆ ಮತ್ತು ನಾವು ಹಸ್ತಾಂತರಿಸುವ ನಮ್ಮ `Init` ಹ್ಯಾಂಡಲ್ ಅಂತಿಮವಾಗಿ ಅದನ್ನು ಕೈಬಿಡುವ ಜವಾಬ್ದಾರಿಯನ್ನು ಹೊಂದಿರುತ್ತದೆ.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // ಸರಿ, ಓಹ್!ಈಗ ನಾವೆಲ್ಲರೂ ಸುರಕ್ಷಿತವಾಗಿ ಸಿಂಕ್ರೊನೈಸ್ ಆಗಿದ್ದೇವೆ, ನಿಜವಾಗಿ ಎಲ್ಲವನ್ನೂ ಪ್ರಕ್ರಿಯೆಗೊಳಿಸಲು ಪ್ರಾರಂಭಿಸೋಣ.
        // ಮೊದಲಿಗೆ ನಾವು ಈ ಪ್ರಕ್ರಿಯೆಯಲ್ಲಿ `dbghelp.dll` ಅನ್ನು ಲೋಡ್ ಮಾಡಲಾಗಿದೆಯೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು.
        // ಸ್ಥಿರ ಅವಲಂಬನೆಯನ್ನು ತಪ್ಪಿಸಲು ನಾವು ಇದನ್ನು ಕ್ರಿಯಾತ್ಮಕವಾಗಿ ಮಾಡುತ್ತೇವೆ.
        // ವಿಲಕ್ಷಣವಾದ ಲಿಂಕ್ ಮಾಡುವ ಸಮಸ್ಯೆಗಳ ಸುತ್ತ ಕೆಲಸ ಮಾಡಲು ಇದನ್ನು ಐತಿಹಾಸಿಕವಾಗಿ ಮಾಡಲಾಗಿದೆ ಮತ್ತು ಇದು ಬೈನರಿಗಳನ್ನು ಸ್ವಲ್ಪ ಹೆಚ್ಚು ಪೋರ್ಟಬಲ್ ಮಾಡುವ ಉದ್ದೇಶವನ್ನು ಹೊಂದಿದೆ ಏಕೆಂದರೆ ಇದು ಹೆಚ್ಚಾಗಿ ಡೀಬಗ್ ಮಾಡುವ ಉಪಯುಕ್ತತೆಯಾಗಿದೆ.
        //
        //
        // ನಾವು `dbghelp.dll` ಅನ್ನು ತೆರೆದ ನಂತರ ನಾವು ಅದರಲ್ಲಿ ಕೆಲವು ಪ್ರಾರಂಭಿಕ ಕಾರ್ಯಗಳನ್ನು ಕರೆಯಬೇಕಾಗಿದೆ, ಮತ್ತು ಅದನ್ನು ಹೆಚ್ಚು ಕೆಳಗೆ ವಿವರಿಸಲಾಗಿದೆ.
        // ನಾವು ಇದನ್ನು ಒಮ್ಮೆ ಮಾತ್ರ ಮಾಡುತ್ತೇವೆ, ಆದ್ದರಿಂದ ನಾವು ಇನ್ನೂ ಮುಗಿದಿದ್ದೇವೆ ಅಥವಾ ಇಲ್ಲವೇ ಎಂಬುದನ್ನು ಸೂಚಿಸುವ ಜಾಗತಿಕ ಬೂಲಿಯನ್ ಅನ್ನು ನಾವು ಪಡೆದುಕೊಂಡಿದ್ದೇವೆ.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // `SYMOPT_DEFERRED_LOADS` ಧ್ವಜವನ್ನು ಹೊಂದಿಸಲಾಗಿದೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ, ಏಕೆಂದರೆ ಈ ಬಗ್ಗೆ MSVC ಯ ಸ್ವಂತ ಡಾಕ್ಸ್ ಪ್ರಕಾರ: "This is the fastest, most efficient way to use the symbol handler.", ಆದ್ದರಿಂದ ಅದನ್ನು ಮಾಡೋಣ!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // MSVC ಯೊಂದಿಗೆ ಚಿಹ್ನೆಗಳನ್ನು ವಾಸ್ತವವಾಗಿ ಪ್ರಾರಂಭಿಸಿ.ಇದು ವಿಫಲವಾಗಬಹುದು ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಆದರೆ ನಾವು ಅದನ್ನು ನಿರ್ಲಕ್ಷಿಸುತ್ತೇವೆ.
        // ಇದಕ್ಕಾಗಿ ಒಂದು ಟನ್ ಮುಂಚಿನ ಕಲೆ ಇಲ್ಲ, ಆದರೆ ಎಲ್ಎಲ್ವಿಎಂ ಆಂತರಿಕವಾಗಿ ಇಲ್ಲಿ ಹಿಂತಿರುಗುವ ಮೌಲ್ಯವನ್ನು ನಿರ್ಲಕ್ಷಿಸಿದಂತೆ ತೋರುತ್ತದೆ ಮತ್ತು ಎಲ್ಎಲ್ವಿಎಂನಲ್ಲಿನ ಸ್ಯಾನಿಟೈಜರ್ ಲೈಬ್ರರಿಗಳಲ್ಲಿ ಇದು ವಿಫಲವಾದರೆ ಭಯಾನಕ ಎಚ್ಚರಿಕೆಯನ್ನು ಮುದ್ರಿಸುತ್ತದೆ ಆದರೆ ದೀರ್ಘಾವಧಿಯಲ್ಲಿ ಅದನ್ನು ನಿರ್ಲಕ್ಷಿಸುತ್ತದೆ.
        //
        //
        // Rust ಗೆ ಇದು ಸಾಕಷ್ಟು ಬರುತ್ತದೆ, ಸ್ಟ್ಯಾಂಡರ್ಡ್ ಲೈಬ್ರರಿ ಮತ್ತು crates.io ನಲ್ಲಿನ ಈ crate ಎರಡೂ `SymInitializeW` ಗೆ ಸ್ಪರ್ಧಿಸಲು ಬಯಸುತ್ತವೆ.
        // ಸ್ಟ್ಯಾಂಡರ್ಡ್ ಲೈಬ್ರರಿ ಐತಿಹಾಸಿಕವಾಗಿ ಹೆಚ್ಚಿನ ಸಮಯವನ್ನು ಸ್ವಚ್ clean ಗೊಳಿಸಲು ಪ್ರಾರಂಭಿಸಲು ಬಯಸಿದೆ, ಆದರೆ ಈಗ ಅದು ಈ crate ಅನ್ನು ಬಳಸುತ್ತಿದೆ ಎಂದರೆ ಇದರರ್ಥ ಯಾರಾದರೂ ಮೊದಲು ಪ್ರಾರಂಭಕ್ಕೆ ಹೋಗುತ್ತಾರೆ ಮತ್ತು ಇನ್ನೊಬ್ಬರು ಆ ಪ್ರಾರಂಭವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತಾರೆ.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}