//! ಚಾಲನಾಸಮಯದಲ್ಲಿ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಪಡೆಯಲು ಗ್ರಂಥಾಲಯ
//!
//! ಈ ಗ್ರಂಥಾಲಯವು ಸ್ಟ್ಯಾಂಡರ್ಡ್ ಲೈಬ್ರರಿಯ `RUST_BACKTRACE=1` ಬೆಂಬಲವನ್ನು ಪೂರಕವಾಗಿ ರನ್‌ಟೈಮ್‌ನಲ್ಲಿ ಪ್ರೋಗ್ರಾಮಿಕ್ ಆಗಿ ಸ್ವಾಧೀನಪಡಿಸಿಕೊಳ್ಳಲು ಅನುಮತಿಸುತ್ತದೆ.
//! ಈ ಲೈಬ್ರರಿಯಿಂದ ಉತ್ಪತ್ತಿಯಾಗುವ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ಗಳನ್ನು ಪಾರ್ಸ್ ಮಾಡುವ ಅಗತ್ಯವಿಲ್ಲ, ಉದಾಹರಣೆಗೆ, ಮತ್ತು ಅನೇಕ ಬ್ಯಾಕೆಂಡ್ ಅನುಷ್ಠಾನಗಳ ಕ್ರಿಯಾತ್ಮಕತೆಯನ್ನು ಬಹಿರಂಗಪಡಿಸುತ್ತದೆ.
//!
//! # Usage
//!
//! ಮೊದಲಿಗೆ, ಇದನ್ನು ನಿಮ್ಮ Cargo.toml ಗೆ ಸೇರಿಸಿ
//!
//! ```toml
//! [dependencies]
//! backtrace = "0.3"
//! ```
//!
//! Next:
//!
//! ```
//! fn main() {
//! # // ಇಲ್ಲಿ ಅಸುರಕ್ಷಿತವಾಗಿದೆ ಆದ್ದರಿಂದ ಪರೀಕ್ಷೆಯು no_std ನಲ್ಲಿ ಹಾದುಹೋಗುತ್ತದೆ.
//! # #[cfg(feature = "std")] {
//!     backtrace::trace(|frame| {
//!         let ip = frame.ip();
//!         let symbol_address = frame.symbol_address();
//!
//!         // ಈ ಸೂಚನಾ ಪಾಯಿಂಟರ್ ಅನ್ನು ಚಿಹ್ನೆಯ ಹೆಸರಿಗೆ ಪರಿಹರಿಸಿ
//!         backtrace::resolve_frame(frame, |symbol| {
//!             if let Some(name) = symbol.name() {
//!                 // ...
//!             }
//!             if let Some(filename) = symbol.filename() {
//!                 // ...
//!             }
//!         });
//!
//!         true // ಮುಂದಿನ ಫ್ರೇಮ್‌ಗೆ ಮುಂದುವರಿಯಿರಿ
//!     });
//! }
//! # }
//! ```
//!
//!
//!

#![doc(html_root_url = "https://docs.rs/backtrace")]
#![deny(missing_docs)]
#![no_std]
#![cfg_attr(
    all(feature = "std", target_env = "sgx", target_vendor = "fortanix"),
    feature(sgx_platform)
)]
#![warn(rust_2018_idioms)]
// ನಾವು libstd ನ ಭಾಗವಾಗಿ ನಿರ್ಮಿಸುತ್ತಿರುವಾಗ, ಈ crate ಅನ್ನು ಮರದಿಂದ ಹೊರಗೆ ಅಭಿವೃದ್ಧಿಪಡಿಸಿದಂತೆ ಎಲ್ಲಾ ಎಚ್ಚರಿಕೆಗಳನ್ನು ಅಪ್ರಸ್ತುತವಾಗಿದ್ದರಿಂದ ಅವುಗಳನ್ನು ಮೌನಗೊಳಿಸಿ.
//
#![cfg_attr(backtrace_in_libstd, allow(warnings))]
#![cfg_attr(not(feature = "std"), allow(dead_code))]

#[cfg(feature = "std")]
#[macro_use]
extern crate std;

// ಇದನ್ನು ಇದೀಗ ಗಿಮ್ಲಿಗೆ ಮಾತ್ರ ಬಳಸಲಾಗುತ್ತದೆ, ಇದನ್ನು ಕೆಲವು ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಬಳಸಲಾಗುತ್ತದೆ, ಆದ್ದರಿಂದ ಇದು ಇತರ ಕಾನ್ಫಿಗರೇಶನ್‌ಗಳಲ್ಲಿ ಬಳಕೆಯಾಗದಿದ್ದರೆ ಚಿಂತಿಸಬೇಡಿ.
//
#[allow(unused_extern_crates)]
extern crate alloc;

pub use self::backtrace::{trace_unsynchronized, Frame};
mod backtrace;

pub use self::symbolize::resolve_frame_unsynchronized;
pub use self::symbolize::{resolve_unsynchronized, Symbol, SymbolName};
mod symbolize;

pub use self::types::BytesOrWideString;
mod types;

#[cfg(feature = "std")]
pub use self::symbolize::clear_symbol_cache;

mod print;
pub use print::{BacktraceFmt, BacktraceFrameFmt, PrintFmt};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        pub use self::backtrace::trace;
        pub use self::symbolize::{resolve, resolve_frame};
        pub use self::capture::{Backtrace, BacktraceFrame, BacktraceSymbol};
        mod capture;
    }
}

#[allow(dead_code)]
struct Bomb {
    enabled: bool,
}

#[allow(dead_code)]
impl Drop for Bomb {
    fn drop(&mut self) {
        if self.enabled {
            panic!("cannot panic during the backtrace function");
        }
    }
}

#[allow(dead_code)]
#[cfg(feature = "std")]
mod lock {
    use std::boxed::Box;
    use std::cell::Cell;
    use std::sync::{Mutex, MutexGuard, Once};

    pub struct LockGuard(Option<MutexGuard<'static, ()>>);

    static mut LOCK: *mut Mutex<()> = 0 as *mut _;
    static INIT: Once = Once::new();
    thread_local!(static LOCK_HELD: Cell<bool> = Cell::new(false));

    impl Drop for LockGuard {
        fn drop(&mut self) {
            if self.0.is_some() {
                LOCK_HELD.with(|slot| {
                    assert!(slot.get());
                    slot.set(false);
                });
            }
        }
    }

    pub fn lock() -> LockGuard {
        if LOCK_HELD.with(|l| l.get()) {
            return LockGuard(None);
        }
        LOCK_HELD.with(|s| s.set(true));
        unsafe {
            INIT.call_once(|| {
                LOCK = Box::into_raw(Box::new(Mutex::new(())));
            });
            LockGuard(Some((*LOCK).lock().unwrap()))
        }
    }
}

#[cfg(all(windows, not(target_vendor = "uwp")))]
mod dbghelp;
#[cfg(windows)]
mod windows;