//! libunwind/gcc_s/etc API ಗಳನ್ನು ಬಳಸಿಕೊಂಡು ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಬೆಂಬಲ.
//!
//! ಈ ಮಾಡ್ಯೂಲ್ ಲಿಬನ್‌ವಿಂಡ್-ಶೈಲಿಯ API ಗಳನ್ನು ಬಳಸಿಕೊಂಡು ಸ್ಟಾಕ್ ಅನ್ನು ಬಿಚ್ಚುವ ಸಾಮರ್ಥ್ಯವನ್ನು ಹೊಂದಿದೆ.
//! ಲಿಬನ್‌ವಿಂಡ್ ತರಹದ ಎಪಿಐನ ಸಂಪೂರ್ಣ ಅನುಷ್ಠಾನವಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಮತ್ತು ಇದು ಸುಲಭವಾಗಿ ಮೆಚ್ಚದ ಬದಲು ಏಕಕಾಲದಲ್ಲಿ ಹೊಂದಾಣಿಕೆಯಾಗಲು ಪ್ರಯತ್ನಿಸುತ್ತಿದೆ.
//!
//!
//! ಲಿಬನ್‌ವಿಂಡ್ API ಅನ್ನು `_Unwind_Backtrace` ನಿಂದ ನಡೆಸಲಾಗುತ್ತದೆ ಮತ್ತು ಪ್ರಾಯೋಗಿಕವಾಗಿ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಉತ್ಪಾದಿಸುವಲ್ಲಿ ಇದು ಅತ್ಯಂತ ವಿಶ್ವಾಸಾರ್ಹವಾಗಿದೆ.
//! ಅದು ಹೇಗೆ ಮಾಡುತ್ತದೆ ಎಂಬುದು ಸಂಪೂರ್ಣವಾಗಿ ಸ್ಪಷ್ಟವಾಗಿಲ್ಲ (ಫ್ರೇಮ್ ಪಾಯಿಂಟರ್ಸ್? ಇಹ್_ಫ್ರೇಮ್ ಮಾಹಿತಿ? ಎರಡೂ?) ಆದರೆ ಅದು ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತಿದೆ!
//!
//! ಈ ಮಾಡ್ಯೂಲ್ನ ಹೆಚ್ಚಿನ ಸಂಕೀರ್ಣತೆಯು ಲಿಬನ್ವಿಂಡ್ ಅನುಷ್ಠಾನಗಳಲ್ಲಿ ವಿವಿಧ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್ ವ್ಯತ್ಯಾಸಗಳನ್ನು ನಿರ್ವಹಿಸುತ್ತಿದೆ.
//! ಇಲ್ಲದಿದ್ದರೆ ಇದು ಲಿಬನ್‌ವಿಂಡ್ API ಗಳಿಗೆ ಬಂಧಿಸುವ ಸಾಕಷ್ಟು ಸರಳವಾದ Rust ಆಗಿದೆ.
//!
//! ಪ್ರಸ್ತುತ ಎಲ್ಲಾ ವಿಂಡೋಸ್ ಅಲ್ಲದ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಿಗೆ ಇದು ಡೀಫಾಲ್ಟ್ ಬಿಚ್ಚುವ API ಆಗಿದೆ.
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// ಕಚ್ಚಾ ಲಿಬನ್‌ವಿಂಡ್ ಪಾಯಿಂಟರ್‌ನೊಂದಿಗೆ ಇದು ಕೇವಲ ಓದಲು ಮಾತ್ರ ಥ್ರೆಡ್‌ಸೇಫ್ ಶೈಲಿಯಲ್ಲಿ ಮಾತ್ರ ಪ್ರವೇಶವಾಗಿರಬೇಕು, ಆದ್ದರಿಂದ ಇದು `Sync` ಆಗಿದೆ.
// `Clone` ಮೂಲಕ ಇತರ ಎಳೆಗಳಿಗೆ ಕಳುಹಿಸುವಾಗ ನಾವು ಯಾವಾಗಲೂ ಆಂತರಿಕ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಉಳಿಸಿಕೊಳ್ಳದ ಆವೃತ್ತಿಗೆ ಬದಲಾಯಿಸುತ್ತೇವೆ, ಆದ್ದರಿಂದ ನಾವು `Send` ಆಗಿರಬೇಕು.
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // OSX `_Unwind_FindEnclosingFunction` ನಲ್ಲಿ ಒಂದು ಪಾಯಿಂಟರ್ ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ ಎಂದು ತೋರುತ್ತದೆ ... ಅಸ್ಪಷ್ಟವಾಗಿದೆ.
        // ಯಾವುದೇ ಕಾರಣಕ್ಕೂ ಇದು ಯಾವಾಗಲೂ ಸುತ್ತುವರಿಯುವ ಕಾರ್ಯವಲ್ಲ.
        // ಇಲ್ಲಿ ಏನು ನಡೆಯುತ್ತಿದೆ ಎಂಬುದು ನನಗೆ ಸಂಪೂರ್ಣವಾಗಿ ಸ್ಪಷ್ಟವಾಗಿಲ್ಲ, ಆದ್ದರಿಂದ ಇದೀಗ ಇದನ್ನು ನಿರಾಶಾಗೊಳಿಸಿ ಮತ್ತು ಯಾವಾಗಲೂ ಐಪಿ ಹಿಂತಿರುಗಿ.
        //
        // ಈ ಷರತ್ತಿನಿಂದಾಗಿ `skip_inner_frames.rs` ಪರೀಕ್ಷೆಯನ್ನು OSX ನಲ್ಲಿ ಬಿಟ್ಟುಬಿಡಲಾಗಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಮತ್ತು ಇದನ್ನು ಸರಿಪಡಿಸಿದರೆ ಸಿದ್ಧಾಂತದಲ್ಲಿನ ಪರೀಕ್ಷೆಯನ್ನು OSX ನಲ್ಲಿ ಚಲಾಯಿಸಬಹುದು!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ಗಳಿಗಾಗಿ ಬಳಸುವ ಲೈಬ್ರರಿ ಇಂಟರ್ಫೇಸ್ ಅನ್ನು ಬಿಚ್ಚಿ
///
/// ಐಒಎಸ್ ಅವೆಲ್ಲವನ್ನೂ ಬಳಸುವುದಿಲ್ಲ ಆದರೆ ಹೆಚ್ಚಿನ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್-ನಿರ್ದಿಷ್ಟ ಸಂರಚನೆಗಳನ್ನು ಸೇರಿಸುವುದರಿಂದ ಕೋಡ್ ಅನ್ನು ಹೆಚ್ಚು ಮಾಲಿನ್ಯಗೊಳಿಸುತ್ತದೆ ಎಂದು ಡೆಡ್ ಕೋಡ್ ಅನ್ನು ಇಲ್ಲಿ ಅನುಮತಿಸಲಾಗಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // ARM EABI ನಿಂದ ಮಾತ್ರ ಬಳಸಲಾಗುತ್ತದೆ
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // ಐಒಎಸ್ನಲ್ಲಿ ಸ್ಥಳೀಯ _ಅನ್ವೈಂಡ್_ಬ್ಯಾಕ್ಟ್ರೇಸ್ ಇಲ್ಲ
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // GCC 4.2.0 ರಿಂದ ಲಭ್ಯವಿದೆ, ನಮ್ಮ ಉದ್ದೇಶಕ್ಕಾಗಿ ಉತ್ತಮವಾಗಿರಬೇಕು
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // ಈ ಕಾರ್ಯವು ತಪ್ಪಾದ ಹೆಸರು: ಈ ಫ್ರೇಮ್‌ನ ಕ್ಯಾನೊನಿಕಲ್ ಫ್ರೇಮ್ ವಿಳಾಸವನ್ನು (ಅಕಾ ಕಾಲರ್ ಫ್ರೇಮ್‌ನ ಎಸ್‌ಪಿ) ಪಡೆಯುವ ಬದಲು ಅದು ಈ ಫ್ರೇಮ್‌ನ ಎಸ್‌ಪಿಯನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x ಪಕ್ಷಪಾತದ ಸಿಎಫ್‌ಎ ಮೌಲ್ಯವನ್ನು ಬಳಸುತ್ತದೆ, ಆದ್ದರಿಂದ ನಾವು _ಅನ್‌ವಿಂಡ್_ಜೆಟ್‌ಸಿಎಫ್‌ಎ ಅನ್ನು ಅವಲಂಬಿಸುವ ಬದಲು ಸ್ಟಾಕ್ ಪಾಯಿಂಟರ್ ರಿಜಿಸ್ಟರ್ ಎಕ್ಸ್‌00 ಎಕ್ಸ್ ಪಡೆಯಲು _ಅನ್‌ವಿಂಡ್_ಜೆಟ್‌ಜಿಆರ್ ಅನ್ನು ಬಳಸಬೇಕಾಗುತ್ತದೆ.
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // android ಮತ್ತು ತೋಳಿನಲ್ಲಿ, `_Unwind_GetIP` ಕಾರ್ಯ ಮತ್ತು ಇತರರ ಗುಂಪೊಂದು ಮ್ಯಾಕ್ರೋಗಳಾಗಿವೆ, ಆದ್ದರಿಂದ ನಾವು ಮ್ಯಾಕ್ರೋಗಳ ವಿಸ್ತರಣೆಯನ್ನು ಹೊಂದಿರುವ ಕಾರ್ಯಗಳನ್ನು ವ್ಯಾಖ್ಯಾನಿಸುತ್ತೇವೆ.
    //
    //
    // TODO: ನೀವು ಕಂಡುಕೊಂಡರೆ ಈ ಮ್ಯಾಕ್ರೋಗಳನ್ನು ವ್ಯಾಖ್ಯಾನಿಸುವ ಹೆಡರ್ ಫೈಲ್‌ಗೆ ಲಿಂಕ್ ಮಾಡಿ.
    // (ನಾನು, ಫಿಟ್‌ಜೆನ್, ಈ ಕೆಲವು ಮ್ಯಾಕ್ರೋ ವಿಸ್ತರಣೆಗಳನ್ನು ಮೂಲತಃ ಎರವಲು ಪಡೆದ ಹೆಡರ್ ಫೈಲ್ ಅನ್ನು ಕಂಡುಹಿಡಿಯಲಾಗುವುದಿಲ್ಲ.)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 ತೋಳಿನ ಸ್ಟಾಕ್ ಪಾಯಿಂಟರ್ ಆಗಿದೆ.
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // ಈ ಕಾರ್ಯವು Android ಅಥವಾ ARM/Linux ನಲ್ಲಿಯೂ ಅಸ್ತಿತ್ವದಲ್ಲಿಲ್ಲ, ಆದ್ದರಿಂದ ಇದನ್ನು ಯಾವುದೇ ಆಪ್ ಮಾಡಬೇಡಿ.
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}