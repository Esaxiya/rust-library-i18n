use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// ವಿಳಾಸವನ್ನು ಚಿಹ್ನೆಗೆ ಪರಿಹರಿಸಿ, ಚಿಹ್ನೆಯನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಮುಚ್ಚುವಿಕೆಗೆ ರವಾನಿಸಿ.
///
/// ಈ ಕಾರ್ಯವು ಸ್ಥಳೀಯ ಚಿಹ್ನೆ ಕೋಷ್ಟಕ, ಡೈನಾಮಿಕ್ ಚಿಹ್ನೆ ಕೋಷ್ಟಕ, ಅಥವಾ DWARF ಡೀಬಗ್ ಮಾಹಿತಿ (ಸಕ್ರಿಯ ಅನುಷ್ಠಾನವನ್ನು ಅವಲಂಬಿಸಿ) ನಂತಹ ಪ್ರದೇಶಗಳಲ್ಲಿ ಕೊಟ್ಟಿರುವ ವಿಳಾಸವನ್ನು ನೀಡುತ್ತದೆ.
///
///
/// ರೆಸಲ್ಯೂಶನ್ ನಿರ್ವಹಿಸಲು ಸಾಧ್ಯವಾಗದಿದ್ದರೆ ಮುಚ್ಚುವಿಕೆಯನ್ನು ಕರೆಯಲಾಗುವುದಿಲ್ಲ, ಮತ್ತು ಇನ್ಲೈನ್ ಮಾಡಿದ ಕಾರ್ಯಗಳ ಸಂದರ್ಭದಲ್ಲಿ ಇದನ್ನು ಒಂದಕ್ಕಿಂತ ಹೆಚ್ಚು ಬಾರಿ ಕರೆಯಬಹುದು.
///
/// ನೀಡಲಾದ ಚಿಹ್ನೆಗಳು ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ `addr` ನಲ್ಲಿ ಮರಣದಂಡನೆಯನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತವೆ, ಆ ವಿಳಾಸಕ್ಕಾಗಿ file/line ಜೋಡಿಗಳನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ (ಲಭ್ಯವಿದ್ದರೆ).
///
/// ನೀವು `Frame` ಹೊಂದಿದ್ದರೆ ಈ ಬದಲು `resolve_frame` ಕಾರ್ಯವನ್ನು ಬಳಸಲು ಶಿಫಾರಸು ಮಾಡಲಾಗಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
///
/// # ಅಗತ್ಯವಿರುವ ವೈಶಿಷ್ಟ್ಯಗಳು
///
/// ಈ ಕಾರ್ಯಕ್ಕೆ `backtrace` crate ನ `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗುತ್ತದೆ.
///
/// # Panics
///
/// ಈ ಕಾರ್ಯವು ಎಂದಿಗೂ panic ಗೆ ಶ್ರಮಿಸುವುದಿಲ್ಲ, ಆದರೆ `cb` panics ಅನ್ನು ಒದಗಿಸಿದರೆ ಕೆಲವು ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳು ಪ್ರಕ್ರಿಯೆಯನ್ನು ಸ್ಥಗಿತಗೊಳಿಸಲು ಡಬಲ್ panic ಅನ್ನು ಒತ್ತಾಯಿಸುತ್ತದೆ.
/// ಕೆಲವು ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳು ಸಿ ಲೈಬ್ರರಿಯನ್ನು ಬಳಸುತ್ತವೆ, ಅದು ಆಂತರಿಕವಾಗಿ ಕಾಲ್‌ಬ್ಯಾಕ್‌ಗಳನ್ನು ಬಳಸುತ್ತದೆ, ಅದನ್ನು ತಪ್ಪಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ, ಆದ್ದರಿಂದ `cb` ನಿಂದ ಭಯಭೀತರಾಗುವುದು ಪ್ರಕ್ರಿಯೆಯನ್ನು ಸ್ಥಗಿತಗೊಳಿಸುತ್ತದೆ.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // ಮೇಲಿನ ಚೌಕಟ್ಟನ್ನು ಮಾತ್ರ ನೋಡಿ
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// ಹಿಂದಿನ ಕ್ಯಾಪ್ಚರ್ ಫ್ರೇಮ್ ಅನ್ನು ಚಿಹ್ನೆಗೆ ಪರಿಹರಿಸಿ, ಚಿಹ್ನೆಯನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಮುಚ್ಚುವಿಕೆಗೆ ರವಾನಿಸಿ.
///
/// ಈ ಫಂಕ್ಟಿನ್ `resolve` ನಂತೆಯೇ ಅದೇ ಕಾರ್ಯವನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ ಹೊರತು ಅದು ವಿಳಾಸದ ಬದಲು `Frame` ಅನ್ನು ಆರ್ಗ್ಯುಮೆಂಟ್ ಆಗಿ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
/// ಬ್ಯಾಕ್‌ಟ್ರೇಸಿಂಗ್‌ನ ಕೆಲವು ಪ್ಲಾಟ್‌ಫಾರ್ಮ್ ಅನುಷ್ಠಾನಗಳಿಗೆ ಇದು ಹೆಚ್ಚು ನಿಖರವಾದ ಚಿಹ್ನೆ ಮಾಹಿತಿ ಅಥವಾ ಇನ್ಲೈನ್ ಫ್ರೇಮ್‌ಗಳ ಬಗ್ಗೆ ಮಾಹಿತಿಯನ್ನು ಒದಗಿಸಲು ಅನುವು ಮಾಡಿಕೊಡುತ್ತದೆ.
///
/// ನಿಮಗೆ ಸಾಧ್ಯವಾದರೆ ಇದನ್ನು ಬಳಸಲು ಶಿಫಾರಸು ಮಾಡಲಾಗಿದೆ.
///
/// # ಅಗತ್ಯವಿರುವ ವೈಶಿಷ್ಟ್ಯಗಳು
///
/// ಈ ಕಾರ್ಯಕ್ಕೆ `backtrace` crate ನ `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗುತ್ತದೆ.
///
/// # Panics
///
/// ಈ ಕಾರ್ಯವು ಎಂದಿಗೂ panic ಗೆ ಶ್ರಮಿಸುವುದಿಲ್ಲ, ಆದರೆ `cb` panics ಅನ್ನು ಒದಗಿಸಿದರೆ ಕೆಲವು ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳು ಪ್ರಕ್ರಿಯೆಯನ್ನು ಸ್ಥಗಿತಗೊಳಿಸಲು ಡಬಲ್ panic ಅನ್ನು ಒತ್ತಾಯಿಸುತ್ತದೆ.
/// ಕೆಲವು ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳು ಸಿ ಲೈಬ್ರರಿಯನ್ನು ಬಳಸುತ್ತವೆ, ಅದು ಆಂತರಿಕವಾಗಿ ಕಾಲ್‌ಬ್ಯಾಕ್‌ಗಳನ್ನು ಬಳಸುತ್ತದೆ, ಅದನ್ನು ತಪ್ಪಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ, ಆದ್ದರಿಂದ `cb` ನಿಂದ ಭಯಭೀತರಾಗುವುದು ಪ್ರಕ್ರಿಯೆಯನ್ನು ಸ್ಥಗಿತಗೊಳಿಸುತ್ತದೆ.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // ಮೇಲಿನ ಚೌಕಟ್ಟನ್ನು ಮಾತ್ರ ನೋಡಿ
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// ಸ್ಟಾಕ್ ಫ್ರೇಮ್‌ಗಳಿಂದ ಐಪಿ ಮೌಲ್ಯಗಳು ಸಾಮಾನ್ಯವಾಗಿ (always?) ಸೂಚನೆಯಾಗಿರುತ್ತವೆ *ಕರೆ ನಂತರ* ನಿಜವಾದ ಸ್ಟಾಕ್ ಟ್ರೇಸ್.
// ಇದನ್ನು ಸಂಕೇತಿಸುವುದರಿಂದ filename/line ಸಂಖ್ಯೆ ಒಂದು ಮುಂದಿದೆ ಮತ್ತು ಅದು ಕಾರ್ಯದ ಅಂತ್ಯದ ಸಮೀಪದಲ್ಲಿದ್ದರೆ ಅದು ಅನೂರ್ಜಿತವಾಗುತ್ತದೆ.
//
// ಎಲ್ಲಾ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಇದು ಮೂಲತಃ ಯಾವಾಗಲೂ ಕಂಡುಬರುತ್ತದೆ, ಆದ್ದರಿಂದ ನಾವು ಸೂಚನೆಯನ್ನು ಹಿಂತಿರುಗಿಸುವ ಬದಲು ಹಿಂದಿನ ಕರೆ ಸೂಚನೆಗೆ ಪರಿಹರಿಸಲು ಪರಿಹರಿಸಿದ ಐಪಿಯಿಂದ ಒಂದನ್ನು ಯಾವಾಗಲೂ ಕಳೆಯುತ್ತೇವೆ.
//
//
// ತಾತ್ತ್ವಿಕವಾಗಿ ನಾವು ಇದನ್ನು ಮಾಡುವುದಿಲ್ಲ.
// ತಾತ್ತ್ವಿಕವಾಗಿ ನಮಗೆ ಇಲ್ಲಿ `resolve` API ಗಳ ಕರೆ ಮಾಡುವವರು -1 ಅನ್ನು ಹಸ್ತಚಾಲಿತವಾಗಿ ಮಾಡಲು ಅಗತ್ಯವಿರುತ್ತದೆ ಮತ್ತು *ಹಿಂದಿನ* ಸೂಚನೆಗಾಗಿ ಸ್ಥಳ ಮಾಹಿತಿಯನ್ನು ಅವರು ಬಯಸುತ್ತಾರೆ, ಆದರೆ ಪ್ರಸ್ತುತವಲ್ಲ.
// ತಾತ್ತ್ವಿಕವಾಗಿ ನಾವು ಮುಂದಿನ ಸೂಚನೆಯ ವಿಳಾಸ ಅಥವಾ ಪ್ರಸ್ತುತವಾಗಿದ್ದರೆ ನಾವು `Frame` ಅನ್ನು ಸಹ ಬಹಿರಂಗಪಡಿಸುತ್ತೇವೆ.
//
// ಇದೀಗ ಇದು ಬಹಳ ಮುಖ್ಯವಾದ ಕಾಳಜಿಯಾಗಿದ್ದರೂ ನಾವು ಆಂತರಿಕವಾಗಿ ಯಾವಾಗಲೂ ಒಂದನ್ನು ಕಳೆಯುತ್ತೇವೆ.
// ಗ್ರಾಹಕರು ಕೆಲಸ ಮಾಡುತ್ತಿರಬೇಕು ಮತ್ತು ಉತ್ತಮ ಫಲಿತಾಂಶಗಳನ್ನು ಪಡೆಯಬೇಕು, ಆದ್ದರಿಂದ ನಾವು ಸಾಕಷ್ಟು ಉತ್ತಮವಾಗಿರಬೇಕು.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// `resolve` ನಂತೆಯೇ, ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡದ ಕಾರಣ ಮಾತ್ರ ಅಸುರಕ್ಷಿತವಾಗಿದೆ.
///
/// ಈ ಕಾರ್ಯವು ಸಿಂಕ್ರೊನೈಸೇಶನ್ ಗ್ಯಾರೆಂಟಿಗಳನ್ನು ಹೊಂದಿಲ್ಲ ಆದರೆ ಈ crate ನ `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಕಂಪೈಲ್ ಮಾಡದಿದ್ದಾಗ ಲಭ್ಯವಿದೆ.
/// ಹೆಚ್ಚಿನ ದಸ್ತಾವೇಜನ್ನು ಮತ್ತು ಉದಾಹರಣೆಗಳಿಗಾಗಿ `resolve` ಕಾರ್ಯವನ್ನು ನೋಡಿ.
///
/// # Panics
///
/// `cb` ಪ್ಯಾನಿಕ್ನಲ್ಲಿ ಕೇವಿಯಟ್ಗಳಿಗಾಗಿ `resolve` ನಲ್ಲಿ ಮಾಹಿತಿಯನ್ನು ನೋಡಿ.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// `resolve_frame` ನಂತೆಯೇ, ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡದ ಕಾರಣ ಮಾತ್ರ ಅಸುರಕ್ಷಿತವಾಗಿದೆ.
///
/// ಈ ಕಾರ್ಯವು ಸಿಂಕ್ರೊನೈಸೇಶನ್ ಗ್ಯಾರೆಂಟಿಗಳನ್ನು ಹೊಂದಿಲ್ಲ ಆದರೆ ಈ crate ನ `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಕಂಪೈಲ್ ಮಾಡದಿದ್ದಾಗ ಲಭ್ಯವಿದೆ.
/// ಹೆಚ್ಚಿನ ದಸ್ತಾವೇಜನ್ನು ಮತ್ತು ಉದಾಹರಣೆಗಳಿಗಾಗಿ `resolve_frame` ಕಾರ್ಯವನ್ನು ನೋಡಿ.
///
/// # Panics
///
/// `cb` ಪ್ಯಾನಿಕ್ನಲ್ಲಿ ಕೇವಿಯಟ್ಗಳಿಗಾಗಿ `resolve_frame` ನಲ್ಲಿ ಮಾಹಿತಿಯನ್ನು ನೋಡಿ.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// ಫೈಲ್‌ನಲ್ಲಿ ಚಿಹ್ನೆಯ ರೆಸಲ್ಯೂಶನ್ ಅನ್ನು ಪ್ರತಿನಿಧಿಸುವ trait.
///
/// ಈ trait ಅನ್ನು `backtrace::resolve` ಕಾರ್ಯಕ್ಕೆ ನೀಡಲಾದ ಮುಚ್ಚುವಿಕೆಗೆ trait ವಸ್ತುವಾಗಿ ನೀಡಲಾಗುತ್ತದೆ, ಮತ್ತು ಇದರ ಹಿಂದೆ ಯಾವ ಅನುಷ್ಠಾನವಿದೆ ಎಂದು ತಿಳಿದಿಲ್ಲವಾದ್ದರಿಂದ ಇದನ್ನು ವಾಸ್ತವಿಕವಾಗಿ ರವಾನಿಸಲಾಗುತ್ತದೆ.
///
///
/// ಒಂದು ಚಿಹ್ನೆಯು ಒಂದು ಕಾರ್ಯದ ಬಗ್ಗೆ ಸಂದರ್ಭೋಚಿತ ಮಾಹಿತಿಯನ್ನು ನೀಡಬಹುದು, ಉದಾಹರಣೆಗೆ ಹೆಸರು, ಫೈಲ್ ಹೆಸರು, ಸಾಲು ಸಂಖ್ಯೆ, ನಿಖರವಾದ ವಿಳಾಸ, ಇತ್ಯಾದಿ.
/// ಎಲ್ಲಾ ಮಾಹಿತಿಯು ಯಾವಾಗಲೂ ಚಿಹ್ನೆಯಲ್ಲಿ ಲಭ್ಯವಿರುವುದಿಲ್ಲ, ಆದಾಗ್ಯೂ, ಎಲ್ಲಾ ವಿಧಾನಗಳು `Option` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತವೆ.
///
///
pub struct Symbol {
    // TODO: ಈ ಜೀವಿತಾವಧಿಯನ್ನು ಅಂತಿಮವಾಗಿ `Symbol` ಗೆ ಮುಂದುವರಿಸಬೇಕಾಗಿದೆ,
    // ಆದರೆ ಅದು ಪ್ರಸ್ತುತ ಬ್ರೇಕಿಂಗ್ ಬದಲಾವಣೆಯಾಗಿದೆ.
    // ಇದೀಗ ಇದು ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ `Symbol` ಅನ್ನು ಎಂದಿಗೂ ಉಲ್ಲೇಖದಿಂದ ಹಸ್ತಾಂತರಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮಾಡಲಾಗುವುದಿಲ್ಲ.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// ಈ ಕಾರ್ಯದ ಹೆಸರನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಚಿಹ್ನೆಯ ಹೆಸರಿನ ಬಗ್ಗೆ ವಿವಿಧ ಗುಣಲಕ್ಷಣಗಳನ್ನು ಪ್ರಶ್ನಿಸಲು ಹಿಂದಿರುಗಿದ ರಚನೆಯನ್ನು ಬಳಸಬಹುದು:
    ///
    ///
    /// * `Display` ಅನುಷ್ಠಾನವು ಡಿಮ್ಯಾಂಗಲ್ಡ್ ಚಿಹ್ನೆಯನ್ನು ಮುದ್ರಿಸುತ್ತದೆ.
    /// * ಚಿಹ್ನೆಯ ಕಚ್ಚಾ `str` ಮೌಲ್ಯವನ್ನು ಪ್ರವೇಶಿಸಬಹುದು (ಅದು ಮಾನ್ಯ utf-8 ಆಗಿದ್ದರೆ).
    /// * ಚಿಹ್ನೆಯ ಹೆಸರಿಗಾಗಿ ಕಚ್ಚಾ ಬೈಟ್‌ಗಳನ್ನು ಪ್ರವೇಶಿಸಬಹುದು.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// ಈ ಕಾರ್ಯದ ಆರಂಭಿಕ ವಿಳಾಸವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// ಕಚ್ಚಾ ಫೈಲ್ ಹೆಸರನ್ನು ಸ್ಲೈಸ್ ಆಗಿ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಇದು ಮುಖ್ಯವಾಗಿ `no_std` ಪರಿಸರಕ್ಕೆ ಉಪಯುಕ್ತವಾಗಿದೆ.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// ಈ ಚಿಹ್ನೆಯು ಪ್ರಸ್ತುತ ಕಾರ್ಯಗತಗೊಳ್ಳುತ್ತಿರುವ ಕಾಲಮ್ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಗಿಮ್ಲಿ ಮಾತ್ರ ಪ್ರಸ್ತುತ ಇಲ್ಲಿ ಮೌಲ್ಯವನ್ನು ಒದಗಿಸುತ್ತದೆ ಮತ್ತು ನಂತರವೂ `filename` `Some` ಅನ್ನು ಹಿಂದಿರುಗಿಸಿದರೆ ಮಾತ್ರ, ಮತ್ತು ಅದು ಅದೇ ರೀತಿಯ ಎಚ್ಚರಿಕೆಗಳಿಗೆ ಒಳಪಟ್ಟಿರುತ್ತದೆ.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// ಈ ಚಿಹ್ನೆಯು ಪ್ರಸ್ತುತ ಕಾರ್ಯಗತಗೊಳ್ಳುತ್ತಿರುವ ರೇಖೆಯ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `filename` `Some` ಅನ್ನು ಹಿಂದಿರುಗಿಸಿದರೆ ಈ ರಿಟರ್ನ್ ಮೌಲ್ಯವು ಸಾಮಾನ್ಯವಾಗಿ `Some` ಆಗಿರುತ್ತದೆ ಮತ್ತು ಇದರ ಪರಿಣಾಮವಾಗಿ ಇದೇ ರೀತಿಯ ಎಚ್ಚರಿಕೆಗಳಿಗೆ ಒಳಪಟ್ಟಿರುತ್ತದೆ.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// ಈ ಕಾರ್ಯವನ್ನು ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ಫೈಲ್ ಹೆಸರನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಇದು ಪ್ರಸ್ತುತ ಲಿಬ್‌ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಅಥವಾ ಗಿಮ್ಲಿಯನ್ನು ಬಳಸುವಾಗ ಮಾತ್ರ ಲಭ್ಯವಿದೆ (ಉದಾ
    /// unix ಪ್ಲಾಟ್‌ಫಾರ್ಮ್‌ಗಳು ಇತರ) ಮತ್ತು ಬೈನರಿ ಅನ್ನು ಡೀಬಗ್‌ಇನ್‌ಫೊದೊಂದಿಗೆ ಸಂಕಲಿಸಿದಾಗ.
    /// ಈ ಎರಡೂ ಷರತ್ತುಗಳನ್ನು ಪೂರೈಸದಿದ್ದರೆ ಇದು `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # ಅಗತ್ಯವಿರುವ ವೈಶಿಷ್ಟ್ಯಗಳು
    ///
    /// ಈ ಕಾರ್ಯಕ್ಕೆ `backtrace` crate ನ `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು `std` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗುತ್ತದೆ.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // ಮ್ಯಾಂಗಲ್ಡ್ ಚಿಹ್ನೆಯನ್ನು Rust ಎಂದು ಪಾರ್ಸ್ ಮಾಡುವುದು ವಿಫಲವಾದರೆ ಪಾರ್ಸ್ ಮಾಡಿದ C++ ಚಿಹ್ನೆ ಇರಬಹುದು.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // ಈ ಶೂನ್ಯ ಗಾತ್ರವನ್ನು ಉಳಿಸಿಕೊಳ್ಳಲು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ, ಇದರಿಂದಾಗಿ `cpp_demangle` ವೈಶಿಷ್ಟ್ಯವನ್ನು ನಿಷ್ಕ್ರಿಯಗೊಳಿಸಿದಾಗ ಯಾವುದೇ ವೆಚ್ಚವಿಲ್ಲ.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// ಡಿಮ್ಯಾಂಗಲ್ಡ್ ಹೆಸರು, ಕಚ್ಚಾ ಬೈಟ್‌ಗಳು, ಕಚ್ಚಾ ದಾರ ಇತ್ಯಾದಿಗಳಿಗೆ ದಕ್ಷತಾಶಾಸ್ತ್ರದ ಪ್ರವೇಶಗಳನ್ನು ಒದಗಿಸಲು ಚಿಹ್ನೆಯ ಹೆಸರಿನ ಸುತ್ತ ಒಂದು ಹೊದಿಕೆ.
///
// `cpp_demangle` ವೈಶಿಷ್ಟ್ಯವನ್ನು ಸಕ್ರಿಯಗೊಳಿಸದಿದ್ದಾಗ ಡೆಡ್ ಕೋಡ್ ಅನ್ನು ಅನುಮತಿಸಿ.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// ಕಚ್ಚಾ ಆಧಾರವಾಗಿರುವ ಬೈಟ್‌ಗಳಿಂದ ಹೊಸ ಚಿಹ್ನೆಯ ಹೆಸರನ್ನು ರಚಿಸುತ್ತದೆ.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// ಚಿಹ್ನೆಯು ಮಾನ್ಯ utf-8 ಆಗಿದ್ದರೆ ಕಚ್ಚಾ (mangled) ಚಿಹ್ನೆಯ ಹೆಸರನ್ನು `str` ಎಂದು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ನೀವು ಡಿಮ್ಯಾಂಗಲ್ಡ್ ಆವೃತ್ತಿಯನ್ನು ಬಯಸಿದರೆ `Display` ಅನುಷ್ಠಾನವನ್ನು ಬಳಸಿ.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// ಕಚ್ಚಾ ಚಿಹ್ನೆಯ ಹೆಸರನ್ನು ಬೈಟ್‌ಗಳ ಪಟ್ಟಿಯಾಗಿ ಹಿಂತಿರುಗಿಸುತ್ತದೆ
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // ಡಿಮ್ಯಾಂಗಲ್ಡ್ ಚಿಹ್ನೆಯು ನಿಜವಾಗಿ ಮಾನ್ಯವಾಗಿಲ್ಲದಿದ್ದರೆ ಇದನ್ನು ಮುದ್ರಿಸಬಹುದು, ಆದ್ದರಿಂದ ದೋಷವನ್ನು ಹೊರಕ್ಕೆ ಪ್ರಚಾರ ಮಾಡದಿರುವ ಮೂಲಕ ಇಲ್ಲಿ ಮನೋಹರವಾಗಿ ನಿರ್ವಹಿಸಿ.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// ವಿಳಾಸಗಳನ್ನು ಸಂಕೇತಿಸಲು ಬಳಸಿದ ಸಂಗ್ರಹಿಸಿದ ಮೆಮೊರಿಯನ್ನು ಪುನಃ ಪಡೆದುಕೊಳ್ಳುವ ಪ್ರಯತ್ನ.
///
/// ಈ ವಿಧಾನವು ಜಾಗತಿಕವಾಗಿ ಅಥವಾ ಥ್ರೆಡ್‌ನಲ್ಲಿ ಸಂಗ್ರಹವಾಗಿರುವ ಯಾವುದೇ ಜಾಗತಿಕ ದತ್ತಾಂಶ ರಚನೆಗಳನ್ನು ಬಿಡುಗಡೆ ಮಾಡಲು ಪ್ರಯತ್ನಿಸುತ್ತದೆ, ಅದು ಸಾಮಾನ್ಯವಾಗಿ ಪಾರ್ಸ್ ಮಾಡಿದ DWARF ಮಾಹಿತಿಯನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ ಅಥವಾ ಅಂತಹುದೇ.
///
///
/// # Caveats
///
/// ಈ ಕಾರ್ಯವು ಯಾವಾಗಲೂ ಲಭ್ಯವಿದ್ದರೂ ಅದು ಹೆಚ್ಚಿನ ಅನುಷ್ಠಾನಗಳಲ್ಲಿ ಏನನ್ನೂ ಮಾಡುವುದಿಲ್ಲ.
/// Dbghelp ಅಥವಾ libbacktrace ನಂತಹ ಗ್ರಂಥಾಲಯಗಳು ರಾಜ್ಯವನ್ನು ಸ್ಥಳಾಂತರಿಸಲು ಮತ್ತು ನಿಯೋಜಿಸಲಾದ ಮೆಮೊರಿಯನ್ನು ನಿರ್ವಹಿಸಲು ಸೌಲಭ್ಯಗಳನ್ನು ಒದಗಿಸುವುದಿಲ್ಲ.
/// ಸದ್ಯಕ್ಕೆ ಈ crate ನ `gimli-symbolize` ವೈಶಿಷ್ಟ್ಯವು ಈ ಕಾರ್ಯವು ಯಾವುದೇ ಪರಿಣಾಮವನ್ನು ಬೀರುವ ಏಕೈಕ ವೈಶಿಷ್ಟ್ಯವಾಗಿದೆ.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}