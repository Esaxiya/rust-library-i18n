//! crates.io ನಲ್ಲಿ `gimli` crate ಅನ್ನು ಬಳಸಿಕೊಂಡು ಸಂಕೇತೀಕರಣಕ್ಕೆ ಬೆಂಬಲ
//!
//! Rust ಗಾಗಿ ಇದು ಡೀಫಾಲ್ಟ್ ಸಂಕೇತೀಕರಣ ಅನುಷ್ಠಾನವಾಗಿದೆ.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'ಸ್ಥಿರ ಜೀವಿತಾವಧಿಯು ಸ್ವಯಂ-ಉಲ್ಲೇಖಿತ ರಚನೆಗಳಿಗೆ ಬೆಂಬಲದ ಕೊರತೆಯನ್ನು ಹ್ಯಾಕ್ ಮಾಡುವುದು ಸುಳ್ಳು.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // ಚಿಹ್ನೆಗಳು `map` ಮತ್ತು `stash` ಅನ್ನು ಮಾತ್ರ ಎರವಲು ಪಡೆಯುವುದರಿಂದ 'ಸ್ಥಿರ ಜೀವಿತಾವಧಿಗೆ ಪರಿವರ್ತಿಸಿ ಮತ್ತು ನಾವು ಅವುಗಳನ್ನು ಕೆಳಗೆ ಸಂರಕ್ಷಿಸುತ್ತಿದ್ದೇವೆ.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Windows ನಲ್ಲಿ ಸ್ಥಳೀಯ ಗ್ರಂಥಾಲಯಗಳನ್ನು ಲೋಡ್ ಮಾಡಲು, ಇಲ್ಲಿರುವ ವಿವಿಧ ತಂತ್ರಗಳಿಗಾಗಿ rust-lang/rust#71060 ಕುರಿತು ಕೆಲವು ಚರ್ಚೆಯನ್ನು ನೋಡಿ.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW ಗ್ರಂಥಾಲಯಗಳು ಪ್ರಸ್ತುತ ASLR (rust-lang/rust#16514) ಅನ್ನು ಬೆಂಬಲಿಸುವುದಿಲ್ಲ, ಆದರೆ DLL ಗಳನ್ನು ವಿಳಾಸ ಸ್ಥಳದಲ್ಲಿ ಇನ್ನೂ ಸ್ಥಳಾಂತರಿಸಬಹುದು.
            // ಡೀಬಗ್ ಮಾಹಿತಿಯಲ್ಲಿನ ವಿಳಾಸಗಳು ಈ ಲೈಬ್ರರಿಯನ್ನು ಅದರ "image base" ನಲ್ಲಿ ಲೋಡ್ ಮಾಡಿದ್ದರೆ, ಅದು ಅದರ COFF ಫೈಲ್ ಹೆಡರ್ಗಳಲ್ಲಿನ ಕ್ಷೇತ್ರವಾಗಿದೆ.
            // ಡೀಬಗ್‌ಇನ್‌ಫೊ ಪಟ್ಟಿ ಮಾಡಿದಂತೆ ತೋರುತ್ತಿರುವುದರಿಂದ ನಾವು ಚಿಹ್ನೆ ಟೇಬಲ್ ಮತ್ತು ಸ್ಟೋರ್ ವಿಳಾಸಗಳನ್ನು ಪಾರ್ಸ್ ಮಾಡಿ "image base" ನಲ್ಲಿ ಲೈಬ್ರರಿಯನ್ನು ಲೋಡ್ ಮಾಡಿದಂತೆ.
            //
            // ಆದಾಗ್ಯೂ, "image base" ನಲ್ಲಿ ಲೈಬ್ರರಿಯನ್ನು ಲೋಡ್ ಮಾಡಲಾಗುವುದಿಲ್ಲ.
            // (ಬಹುಶಃ ಬೇರೆ ಯಾವುದನ್ನಾದರೂ ಅಲ್ಲಿ ಲೋಡ್ ಮಾಡಬಹುದು?) ಇಲ್ಲಿಯೇ `bias` ಕ್ಷೇತ್ರ ಕಾರ್ಯರೂಪಕ್ಕೆ ಬರುತ್ತದೆ, ಮತ್ತು ನಾವು ಇಲ್ಲಿ `bias` ಮೌಲ್ಯವನ್ನು ಕಂಡುಹಿಡಿಯಬೇಕು.ದುರದೃಷ್ಟವಶಾತ್ ಲೋಡ್ ಮಾಡಲಾದ ಮಾಡ್ಯೂಲ್ನಿಂದ ಇದನ್ನು ಹೇಗೆ ಪಡೆಯುವುದು ಎಂಬುದು ಸ್ಪಷ್ಟವಾಗಿಲ್ಲ.
            // ನಮ್ಮಲ್ಲಿರುವುದು ನಿಜವಾದ ಲೋಡ್ ವಿಳಾಸ (`modBaseAddr`) ಆಗಿದೆ.
            //
            // ಇದೀಗ ಸ್ವಲ್ಪ ಕಾಪ್-as ಟ್ ಆಗಿ ನಾವು ಫೈಲ್ ಅನ್ನು ಎಂಮ್ಯಾಪ್ ಮಾಡುತ್ತೇವೆ, ಫೈಲ್ ಹೆಡರ್ ಮಾಹಿತಿಯನ್ನು ಓದಿ, ನಂತರ ಎಂಮ್ಯಾಪ್ ಅನ್ನು ಬಿಡಿ.ಇದು ವ್ಯರ್ಥವಾಗಿದೆ ಏಕೆಂದರೆ ನಾವು ಬಹುಶಃ ನಂತರ ಎಂಮ್ಯಾಪ್ ಅನ್ನು ಮತ್ತೆ ತೆರೆಯುತ್ತೇವೆ, ಆದರೆ ಇದು ಇದೀಗ ಸಾಕಷ್ಟು ಉತ್ತಮವಾಗಿ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ.
            //
            // ಒಮ್ಮೆ ನಾವು `image_base` (ಅಪೇಕ್ಷಿತ ಲೋಡ್ ಸ್ಥಳ) ಮತ್ತು `base_addr` (ನಿಜವಾದ ಲೋಡ್ ಸ್ಥಳ) ಅನ್ನು ಹೊಂದಿದ್ದರೆ ನಾವು `bias` ಅನ್ನು ಭರ್ತಿ ಮಾಡಬಹುದು (ನಿಜವಾದ ಮತ್ತು ಅಪೇಕ್ಷಿತ ನಡುವಿನ ವ್ಯತ್ಯಾಸ) ಮತ್ತು ನಂತರ ಪ್ರತಿ ವಿಭಾಗದ ನಿಗದಿತ ವಿಳಾಸವು `image_base` ಆಗಿರುತ್ತದೆ ಏಕೆಂದರೆ ಅದು ಫೈಲ್ ಹೇಳುತ್ತದೆ.
            //
            //
            // ಇದೀಗ ELF/MachO ಗಿಂತ ಭಿನ್ನವಾಗಿ ನಾವು ಪ್ರತಿ ಲೈಬ್ರರಿಗೆ ಒಂದು ವಿಭಾಗವನ್ನು ಮಾಡಬಹುದು, `modBaseSize` ಅನ್ನು ಸಂಪೂರ್ಣ ಗಾತ್ರವಾಗಿ ಬಳಸಬಹುದು.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS ಮ್ಯಾಕ್-ಒ ಫೈಲ್ ಫಾರ್ಮ್ಯಾಟ್ ಅನ್ನು ಬಳಸುತ್ತದೆ ಮತ್ತು ಅಪ್ಲಿಕೇಶನ್‌ನ ಭಾಗವಾಗಿರುವ ಸ್ಥಳೀಯ ಲೈಬ್ರರಿಗಳ ಪಟ್ಟಿಯನ್ನು ಲೋಡ್ ಮಾಡಲು ಡಿವೈಎಲ್ಡಿ-ನಿರ್ದಿಷ್ಟ ಎಪಿಐಗಳನ್ನು ಬಳಸುತ್ತದೆ.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // ಈ ಗ್ರಂಥಾಲಯದ ಹೆಸರನ್ನು ಪಡೆದುಕೊಳ್ಳಿ ಅದು ಅದನ್ನು ಎಲ್ಲಿ ಲೋಡ್ ಮಾಡಬೇಕೆಂಬುದರ ಮಾರ್ಗಕ್ಕೆ ಅನುರೂಪವಾಗಿದೆ.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // ಈ ಲೈಬ್ರರಿಯ ಇಮೇಜ್ ಹೆಡರ್ ಅನ್ನು ಲೋಡ್ ಮಾಡಿ ಮತ್ತು ಎಲ್ಲಾ ಲೋಡ್ ಆಜ್ಞೆಗಳನ್ನು ಪಾರ್ಸ್ ಮಾಡಲು `object` ಗೆ ಪ್ರತಿನಿಧಿಸಿ ಆದ್ದರಿಂದ ನಾವು ಇಲ್ಲಿ ಒಳಗೊಂಡಿರುವ ಎಲ್ಲಾ ವಿಭಾಗಗಳನ್ನು ಕಂಡುಹಿಡಿಯಬಹುದು.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // ವಿಭಾಗಗಳನ್ನು ಪುನರಾವರ್ತಿಸಿ ಮತ್ತು ನಾವು ಕಂಡುಕೊಂಡ ವಿಭಾಗಗಳಿಗೆ ತಿಳಿದಿರುವ ಪ್ರದೇಶಗಳನ್ನು ನೋಂದಾಯಿಸಿ.
            // ಹೆಚ್ಚುವರಿಯಾಗಿ ಪ್ರಕ್ರಿಯೆಗೊಳಿಸಲು ಪಠ್ಯ ವಿಭಾಗದ ಮಾಹಿತಿಯನ್ನು ರೆಕಾರ್ಡ್ ಮಾಡಿ, ಕೆಳಗಿನ ಕಾಮೆಂಟ್‌ಗಳನ್ನು ನೋಡಿ.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // ಈ ಲೈಬ್ರರಿಗಾಗಿ "slide" ಅನ್ನು ನಿರ್ಧರಿಸಿ, ಅದು ಮೆಮೊರಿ ಆಬ್ಜೆಕ್ಟ್‌ಗಳಲ್ಲಿ ಎಲ್ಲಿ ಲೋಡ್ ಆಗುತ್ತದೆ ಎಂಬುದನ್ನು ಕಂಡುಹಿಡಿಯಲು ನಾವು ಬಳಸುವ ಪಕ್ಷಪಾತವಾಗಿದೆ.
            // ಇದು ಸ್ವಲ್ಪ ವಿಲಕ್ಷಣವಾದ ಗಣನೆಯಾಗಿದೆ ಮತ್ತು ಕಾಡಿನಲ್ಲಿ ಕೆಲವು ವಿಷಯಗಳನ್ನು ಪ್ರಯತ್ನಿಸುವ ಮತ್ತು ಯಾವ ಕೋಲುಗಳನ್ನು ನೋಡಿದ ಪರಿಣಾಮವಾಗಿದೆ.
            //
            // ಸಾಮಾನ್ಯ ಆಲೋಚನೆಯೆಂದರೆ, `bias` ಜೊತೆಗೆ ಒಂದು ವಿಭಾಗದ `stated_virtual_memory_address` ನಿಜವಾದ ವಿಳಾಸ ಜಾಗದಲ್ಲಿ ವಿಭಾಗವು ವಾಸಿಸುವ ಸ್ಥಳವಾಗಲಿದೆ.
            // ಆದರೂ ನಾವು ಅವಲಂಬಿಸಿರುವ ಇನ್ನೊಂದು ವಿಷಯವೆಂದರೆ ನಿಜವಾದ ವಿಳಾಸ ಮೈನಸ್ `bias` ಎಂಬುದು ಚಿಹ್ನೆ ಕೋಷ್ಟಕ ಮತ್ತು ಡೀಬಗಿನ್‌ಫೊದಲ್ಲಿ ಹುಡುಕುವ ಸೂಚ್ಯಂಕವಾಗಿದೆ.
            //
            // ಸಿಸ್ಟಮ್ ಲೋಡ್ ಮಾಡಲಾದ ಗ್ರಂಥಾಲಯಗಳಿಗೆ ಈ ಲೆಕ್ಕಾಚಾರಗಳು ತಪ್ಪಾಗಿವೆ ಎಂದು ಅದು ತಿರುಗುತ್ತದೆ.ಸ್ಥಳೀಯ ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದಾದವರಿಗೆ, ಅದು ಸರಿಯಾಗಿದೆ.
            // ಎಲ್‌ಎಲ್‌ಡಿಬಿಯ ಮೂಲದಿಂದ ಕೆಲವು ತರ್ಕವನ್ನು ಎತ್ತುವ ಮೂಲಕ ಇದು ಫೈಲ್ ಆಫ್‌ಸೆಟ್ 0 ನಿಂದ ಲೋಡ್ ಮಾಡದ ಮೊದಲ ಎಕ್ಸ್‌00 ಎಕ್ಸ್ ವಿಭಾಗಕ್ಕೆ ಕೆಲವು ವಿಶೇಷ-ಕವಚವನ್ನು ಹೊಂದಿದೆ.
            // ಇದು ಇದ್ದಾಗ ಯಾವುದೇ ಕಾರಣಕ್ಕಾಗಿ ಚಿಹ್ನೆಯ ಕೋಷ್ಟಕವು ಗ್ರಂಥಾಲಯದ ಕೇವಲ vmaddr ಸ್ಲೈಡ್‌ಗೆ ಸಂಬಂಧಿಸಿದೆ ಎಂದು ಅರ್ಥೈಸುತ್ತದೆ.
            // ಅದು *ಇಲ್ಲದಿದ್ದರೆ* ಚಿಹ್ನೆಯ ಕೋಷ್ಟಕವು vmaddr ಸ್ಲೈಡ್‌ಗೆ ಮತ್ತು ವಿಭಾಗದ ಹೇಳಲಾದ ವಿಳಾಸಕ್ಕೆ ಸಂಬಂಧಿಸಿದೆ.
            //
            // ಫೈಲ್ ಆಫ್‌ಸೆಟ್ ಶೂನ್ಯದಲ್ಲಿ ನಾವು ಪಠ್ಯ ವಿಭಾಗವನ್ನು ಕಂಡುಹಿಡಿಯದಿದ್ದರೆ ಈ ಪರಿಸ್ಥಿತಿಯನ್ನು ನಿಭಾಯಿಸಲು ನಾವು ಮೊದಲ ಪಠ್ಯ ವಿಭಾಗಗಳ ಹೇಳಿದ ವಿಳಾಸದಿಂದ ಪಕ್ಷಪಾತವನ್ನು ಹೆಚ್ಚಿಸುತ್ತೇವೆ ಮತ್ತು ಎಲ್ಲಾ ಪ್ರಮಾಣಿತ ವಿಳಾಸಗಳನ್ನು ಆ ಮೊತ್ತದಿಂದ ಕಡಿಮೆ ಮಾಡುತ್ತೇವೆ.
            //
            // ಆ ರೀತಿಯಲ್ಲಿ ಚಿಹ್ನೆಯ ಕೋಷ್ಟಕವು ಯಾವಾಗಲೂ ಗ್ರಂಥಾಲಯದ ಪಕ್ಷಪಾತ ಮೊತ್ತಕ್ಕೆ ಹೋಲಿಸಿದರೆ ಗೋಚರಿಸುತ್ತದೆ.
            // ಚಿಹ್ನೆ ಕೋಷ್ಟಕದ ಮೂಲಕ ಸಂಕೇತಿಸಲು ಇದು ಸರಿಯಾದ ಫಲಿತಾಂಶಗಳನ್ನು ತೋರುತ್ತಿದೆ.
            //
            // ಪ್ರಾಮಾಣಿಕವಾಗಿ ಇದು ಸರಿಯಾಗಿದೆಯೆ ಅಥವಾ ಇದನ್ನು ಹೇಗೆ ಮಾಡಬೇಕೆಂದು ಸೂಚಿಸುವ ಬೇರೆ ಏನಾದರೂ ಇದ್ದರೆ ನನಗೆ ಸಂಪೂರ್ಣವಾಗಿ ತಿಳಿದಿಲ್ಲ.
            // ಇದೀಗ ಇದು ಸಾಕಷ್ಟು (?) ಉತ್ತಮವಾಗಿ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತಿದೆ ಎಂದು ತೋರುತ್ತದೆಯಾದರೂ ಮತ್ತು ಅಗತ್ಯವಿದ್ದರೆ ನಾವು ಇದನ್ನು ಕಾಲಾನಂತರದಲ್ಲಿ ತಿರುಚಲು ಸಾಧ್ಯವಾಗುತ್ತದೆ.
            //
            // ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ #318 ನೋಡಿ
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // ಇತರ Unix (ಉದಾ
        // ಲಿನಕ್ಸ್) ಪ್ಲಾಟ್‌ಫಾರ್ಮ್‌ಗಳು ಇಎಲ್‌ಎಫ್ ಅನ್ನು ಆಬ್ಜೆಕ್ಟ್ ಫೈಲ್ ಫಾರ್ಮ್ಯಾಟ್‌ನಂತೆ ಬಳಸುತ್ತವೆ ಮತ್ತು ಸ್ಥಳೀಯ ಗ್ರಂಥಾಲಯಗಳನ್ನು ಲೋಡ್ ಮಾಡಲು ಸಾಮಾನ್ಯವಾಗಿ ಎಕ್ಸ್‌00 ಎಕ್ಸ್ ಎಂಬ ಎಪಿಐ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತವೆ.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` ಮಾನ್ಯವಾದ ಪಾಯಿಂಟರ್‌ಗಳಾಗಿರಬೇಕು.
        // `vec` `std::Vec` ಗೆ ಮಾನ್ಯ ಪಾಯಿಂಟರ್ ಆಗಿರಬೇಕು.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 ಡೀಬಗ್ ಮಾಹಿತಿಯನ್ನು ಸ್ಥಳೀಯವಾಗಿ ಬೆಂಬಲಿಸುವುದಿಲ್ಲ, ಆದರೆ ಬಿಲ್ಡ್ ಸಿಸ್ಟಮ್ ಡೀಬಗ್ ಮಾಹಿತಿಯನ್ನು `romfs:/debug_info.elf` ಮಾರ್ಗದಲ್ಲಿ ಇರಿಸುತ್ತದೆ.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // ಉಳಿದಂತೆ ELF ಅನ್ನು ಬಳಸಬೇಕು, ಆದರೆ ಸ್ಥಳೀಯ ಗ್ರಂಥಾಲಯಗಳನ್ನು ಹೇಗೆ ಲೋಡ್ ಮಾಡುವುದು ಎಂದು ತಿಳಿದಿಲ್ಲ.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// ಲೋಡ್ ಮಾಡಲಾದ ಎಲ್ಲಾ ತಿಳಿದಿರುವ ಹಂಚಿದ ಗ್ರಂಥಾಲಯಗಳು.
    libraries: Vec<Library>,

    /// ಪಾರ್ಸ್ ಮಾಡಿದ ಕುಬ್ಜ ಮಾಹಿತಿಯನ್ನು ನಾವು ಉಳಿಸಿಕೊಳ್ಳುವ ಮ್ಯಾಪಿಂಗ್ ಸಂಗ್ರಹ.
    ///
    /// ಈ ಪಟ್ಟಿಯು ಅದರ ಸಂಪೂರ್ಣ ಜೀವಿತಾವಧಿಗೆ ಸ್ಥಿರ ಸಾಮರ್ಥ್ಯವನ್ನು ಹೊಂದಿದೆ ಅದು ಎಂದಿಗೂ ಹೆಚ್ಚಾಗುವುದಿಲ್ಲ.
    /// ಪ್ರತಿ ಜೋಡಿಯ `usize` ಅಂಶವು `libraries` ಗೆ ಸೂಚ್ಯಂಕವಾಗಿದೆ, ಅಲ್ಲಿ `usize::max_value()` ಪ್ರಸ್ತುತ ಕಾರ್ಯಗತಗೊಳ್ಳುವಿಕೆಯನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
    ///
    /// `Mapping` ಅನುಗುಣವಾದ ಪಾರ್ಸ್ಡ್ ಡ್ವಾರ್ಫ್ ಮಾಹಿತಿಯಾಗಿದೆ.
    ///
    /// ಇದು ಮೂಲತಃ ಎಲ್‌ಆರ್‌ಯು ಸಂಗ್ರಹವಾಗಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ ಮತ್ತು ನಾವು ವಿಳಾಸಗಳನ್ನು ಸಂಕೇತಿಸುವಾಗ ನಾವು ಇಲ್ಲಿ ವಿಷಯಗಳನ್ನು ಬದಲಾಯಿಸುತ್ತೇವೆ.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// ಈ ಲೈಬ್ರರಿಯ ಭಾಗಗಳನ್ನು ಮೆಮೊರಿಗೆ ಲೋಡ್ ಮಾಡಲಾಗಿದೆ ಮತ್ತು ಅವುಗಳನ್ನು ಎಲ್ಲಿ ಲೋಡ್ ಮಾಡಲಾಗುತ್ತದೆ.
    segments: Vec<LibrarySegment>,
    /// ಈ ಲೈಬ್ರರಿಯ "bias", ಸಾಮಾನ್ಯವಾಗಿ ಅದನ್ನು ಮೆಮೊರಿಗೆ ಲೋಡ್ ಮಾಡಲಾಗುತ್ತದೆ.
    /// ವಿಭಾಗವನ್ನು ಲೋಡ್ ಮಾಡಲಾದ ನಿಜವಾದ ವರ್ಚುವಲ್ ಮೆಮೊರಿ ವಿಳಾಸವನ್ನು ಪಡೆಯಲು ಈ ವಿಭಾಗವನ್ನು ಪ್ರತಿ ವಿಭಾಗದ ನಿಗದಿತ ವಿಳಾಸಕ್ಕೆ ಸೇರಿಸಲಾಗುತ್ತದೆ.
    /// ಹೆಚ್ಚುವರಿಯಾಗಿ ಈ ಪಕ್ಷಪಾತವನ್ನು ನೈಜ ವರ್ಚುವಲ್ ಮೆಮೊರಿ ವಿಳಾಸಗಳಿಂದ ಸೂಚ್ಯಂಕಕ್ಕೆ ಡೀಬಗಿನ್‌ಫೊ ಮತ್ತು ಚಿಹ್ನೆ ಕೋಷ್ಟಕಕ್ಕೆ ಕಳೆಯಲಾಗುತ್ತದೆ.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// ಆಬ್ಜೆಕ್ಟ್ ಫೈಲ್‌ನಲ್ಲಿ ಈ ವಿಭಾಗದ ಹೇಳಲಾದ ವಿಳಾಸ.
    /// ಇದು ವಾಸ್ತವವಾಗಿ ವಿಭಾಗವನ್ನು ಲೋಡ್ ಮಾಡಿದ ಸ್ಥಳವಲ್ಲ, ಆದರೆ ಈ ವಿಳಾಸ ಮತ್ತು ಒಳಗೊಂಡಿರುವ ಲೈಬ್ರರಿಯ `bias` ಅನ್ನು ಎಲ್ಲಿ ಕಂಡುಹಿಡಿಯಬೇಕು.
    ///
    stated_virtual_memory_address: usize,
    /// ಮೆಮೊರಿಯಲ್ಲಿ ths ವಿಭಾಗದ ಗಾತ್ರ.
    len: usize,
}

// ಅಸುರಕ್ಷಿತ ಏಕೆಂದರೆ ಇದನ್ನು ಬಾಹ್ಯವಾಗಿ ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡಬೇಕಾಗುತ್ತದೆ
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // ಅಸುರಕ್ಷಿತ ಏಕೆಂದರೆ ಇದನ್ನು ಬಾಹ್ಯವಾಗಿ ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡಬೇಕಾಗುತ್ತದೆ
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // ಡೀಬಗ್ ಮಾಹಿತಿ ಮ್ಯಾಪಿಂಗ್‌ಗಳಿಗಾಗಿ ಬಹಳ ಚಿಕ್ಕದಾದ, ಸರಳವಾದ LRU ಸಂಗ್ರಹ.
        //
        // ಹಿಟ್ ದರವು ತುಂಬಾ ಹೆಚ್ಚಿರಬೇಕು, ಏಕೆಂದರೆ ವಿಶಿಷ್ಟವಾದ ಸ್ಟಾಕ್ ಅನೇಕ ಹಂಚಿದ ಲೈಬ್ರರಿಗಳ ನಡುವೆ ದಾಟುವುದಿಲ್ಲ.
        //
        // `addr2line::Context` ರಚನೆಗಳು ರಚಿಸಲು ಸಾಕಷ್ಟು ದುಬಾರಿಯಾಗಿದೆ.
        // ಇದರ ವೆಚ್ಚವನ್ನು ನಂತರದ `locate` ಪ್ರಶ್ನೆಗಳಿಂದ ಭೋಗ್ಯ ಮಾಡುವ ನಿರೀಕ್ಷೆಯಿದೆ, ಇದು ಉತ್ತಮವಾದ ವೇಗವನ್ನು ಪಡೆಯಲು `addr2line: : ಸನ್ನಿವೇಶವನ್ನು ನಿರ್ಮಿಸುವಾಗ ನಿರ್ಮಿಸಲಾದ ರಚನೆಗಳ ಮೇಲೆ ಪ್ರಭಾವ ಬೀರುತ್ತದೆ.
        //
        // ನಮ್ಮಲ್ಲಿ ಈ ಸಂಗ್ರಹವಿಲ್ಲದಿದ್ದರೆ, ಆ ಭೋಗ್ಯವು ಎಂದಿಗೂ ಸಂಭವಿಸುವುದಿಲ್ಲ, ಮತ್ತು ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ಗಳನ್ನು ಸಂಕೇತಿಸುವುದು ssssllllooooowwww ಆಗಿರುತ್ತದೆ.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // ಮೊದಲಿಗೆ, ಈ `lib` ನಲ್ಲಿ `addr` (ಸ್ಥಳಾಂತರವನ್ನು ನಿರ್ವಹಿಸುವುದು) ಹೊಂದಿರುವ ಯಾವುದೇ ವಿಭಾಗವಿದೆಯೇ ಎಂದು ಪರೀಕ್ಷಿಸಿ.ಈ ಚೆಕ್ ಹಾದು ಹೋದರೆ ನಾವು ಕೆಳಗೆ ಮುಂದುವರಿಯಬಹುದು ಮತ್ತು ವಿಳಾಸವನ್ನು ಅನುವಾದಿಸಬಹುದು.
                //
                // ಓವರ್‌ಫ್ಲೋ ಪರಿಶೀಲನೆಗಳನ್ನು ತಪ್ಪಿಸಲು ನಾವು ಇಲ್ಲಿ `wrapping_add` ಅನ್ನು ಬಳಸುತ್ತಿದ್ದೇವೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.ಎಸ್‌ವಿಎಂಎ + ಬಯಾಸ್ ಕಂಪ್ಯೂಟೇಶನ್ ಉಕ್ಕಿ ಹರಿಯುವುದನ್ನು ಕಾಡಿನಲ್ಲಿ ನೋಡಲಾಗಿದೆ.
                // ಇದು ಸ್ವಲ್ಪ ವಿಚಿತ್ರವಾಗಿ ತೋರುತ್ತದೆ ಆದರೆ ಅದು ಬಾಹ್ಯಾಕಾಶಕ್ಕೆ ಸೂಚಿಸುವ ಸಾಧ್ಯತೆ ಇರುವುದರಿಂದ ಆ ಭಾಗಗಳನ್ನು ನಿರ್ಲಕ್ಷಿಸುವುದರ ಹೊರತಾಗಿ ನಾವು ಇದರ ಬಗ್ಗೆ ದೊಡ್ಡ ಮೊತ್ತವನ್ನು ಮಾಡಲಾಗುವುದಿಲ್ಲ.
                //
                // ಇದು ಮೂಲತಃ rust-lang/backtrace-rs#329 ನಲ್ಲಿ ಬಂದಿತು.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // `lib` ನಲ್ಲಿ `addr` ಇದೆ ಎಂದು ಈಗ ನಮಗೆ ತಿಳಿದಿದೆ, ಹೇಳಲಾದ ವೈರುಟಲ್ ಮೆಮೊರಿ ವಿಳಾಸವನ್ನು ಕಂಡುಹಿಡಿಯಲು ನಾವು ಪಕ್ಷಪಾತದೊಂದಿಗೆ ಸರಿದೂಗಿಸಬಹುದು.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // ಅಸ್ಥಿರ: ಈ ಷರತ್ತುಬದ್ಧ ಆರಂಭಿಕ ಮರಳುವಿಕೆಯಿಲ್ಲದೆ ಪೂರ್ಣಗೊಂಡ ನಂತರ
        // ದೋಷದಿಂದ, ಈ ಮಾರ್ಗದ ಸಂಗ್ರಹ ನಮೂದು ಸೂಚ್ಯಂಕ 0 ರಲ್ಲಿದೆ.

        if let Some(idx) = idx {
            // ಮ್ಯಾಪಿಂಗ್ ಈಗಾಗಲೇ ಸಂಗ್ರಹದಲ್ಲಿದ್ದಾಗ, ಅದನ್ನು ಮುಂಭಾಗಕ್ಕೆ ಸರಿಸಿ.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // ಮ್ಯಾಪಿಂಗ್ ಸಂಗ್ರಹದಲ್ಲಿ ಇಲ್ಲದಿದ್ದಾಗ, ಹೊಸ ಮ್ಯಾಪಿಂಗ್ ಅನ್ನು ರಚಿಸಿ, ಅದನ್ನು ಸಂಗ್ರಹದ ಮುಂಭಾಗಕ್ಕೆ ಸೇರಿಸಿ ಮತ್ತು ಅಗತ್ಯವಿದ್ದರೆ ಹಳೆಯ ಸಂಗ್ರಹ ನಮೂದನ್ನು ಹೊರಹಾಕಿ.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // `'static` ಜೀವಿತಾವಧಿಯನ್ನು ಸೋರಿಕೆ ಮಾಡಬೇಡಿ, ಅದನ್ನು ನಾವೇ ಸ್ಕೋಪ್ ಮಾಡಿದ್ದೇವೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // ದುರದೃಷ್ಟವಶಾತ್ ನಾವು ಇಲ್ಲಿಗೆ ಬೇಕಾಗಿರುವುದರಿಂದ `sym` ನ ಜೀವಿತಾವಧಿಯನ್ನು `'static` ಗೆ ವಿಸ್ತರಿಸಿ, ಆದರೆ ಇದು ಎಂದಿಗೂ ಒಂದು ಉಲ್ಲೇಖವಾಗಿ ಹೊರಟಿದೆ, ಆದ್ದರಿಂದ ಈ ಚೌಕಟ್ಟನ್ನು ಮೀರಿ ಯಾವುದೇ ಉಲ್ಲೇಖವನ್ನು ಮುಂದುವರಿಸಬಾರದು.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // ಅಂತಿಮವಾಗಿ, ಸಂಗ್ರಹಿಸಿದ ಮ್ಯಾಪಿಂಗ್ ಪಡೆಯಿರಿ ಅಥವಾ ಈ ಫೈಲ್‌ಗಾಗಿ ಹೊಸ ಮ್ಯಾಪಿಂಗ್ ರಚಿಸಿ, ಮತ್ತು ಈ ವಿಳಾಸಕ್ಕಾಗಿ file/line/name ಅನ್ನು ಕಂಡುಹಿಡಿಯಲು DWARF ಮಾಹಿತಿಯನ್ನು ಮೌಲ್ಯಮಾಪನ ಮಾಡಿ.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// ಈ ಚಿಹ್ನೆಗಾಗಿ ನಾವು ಫ್ರೇಮ್ ಮಾಹಿತಿಯನ್ನು ಕಂಡುಹಿಡಿಯಲು ಸಾಧ್ಯವಾಯಿತು, ಮತ್ತು `addr2line` ನ ಫ್ರೇಮ್ ಆಂತರಿಕವಾಗಿ ಎಲ್ಲಾ ಅಸಹ್ಯಕರ ವಿವರಗಳನ್ನು ಹೊಂದಿದೆ.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// ಡೀಬಗ್ ಮಾಹಿತಿಯನ್ನು ಕಂಡುಹಿಡಿಯಲಾಗಲಿಲ್ಲ, ಆದರೆ ನಾವು ಅದನ್ನು ಯಕ್ಷಿಣಿ ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದಾದ ಚಿಹ್ನೆ ಕೋಷ್ಟಕದಲ್ಲಿ ಕಂಡುಕೊಂಡಿದ್ದೇವೆ.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}