//! ಲಿಬ್‌ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ನಲ್ಲಿ DWARF-ಪಾರ್ಸಿಂಗ್ ಕೋಡ್ ಅನ್ನು ಬಳಸುವ ಸಾಂಕೇತಿಕ ತಂತ್ರ.
//!
//! ಲಿಬ್‌ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಸಿ ಲೈಬ್ರರಿ, ಸಾಮಾನ್ಯವಾಗಿ gcc ನೊಂದಿಗೆ ವಿತರಿಸಲ್ಪಡುತ್ತದೆ, ಇದು ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಅನ್ನು ಉತ್ಪಾದಿಸುವುದನ್ನು ಬೆಂಬಲಿಸುತ್ತದೆ (ಇದನ್ನು ನಾವು ನಿಜವಾಗಿ ಬಳಸುವುದಿಲ್ಲ) ಆದರೆ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಅನ್ನು ಸಂಕೇತಿಸುತ್ತದೆ ಮತ್ತು ಇನ್ಲೈನ್ ಮಾಡಿದ ಫ್ರೇಮ್‌ಗಳು ಮತ್ತು ವಾಟ್‌ನೋಟ್‌ನಂತಹ ವಿಷಯಗಳ ಬಗ್ಗೆ ಕುಬ್ಜ ಡೀಬಗ್ ಮಾಹಿತಿಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
//!
//!
//! ಇಲ್ಲಿ ಹಲವಾರು ಕಾಳಜಿಗಳಿಂದಾಗಿ ಇದು ತುಲನಾತ್ಮಕವಾಗಿ ಜಟಿಲವಾಗಿದೆ, ಆದರೆ ಮೂಲ ಕಲ್ಪನೆ ಹೀಗಿದೆ:
//!
//! * ಮೊದಲು ನಾವು `backtrace_syminfo` ಎಂದು ಕರೆಯುತ್ತೇವೆ.ಇದು ನಮಗೆ ಸಾಧ್ಯವಾದರೆ ಡೈನಾಮಿಕ್ ಚಿಹ್ನೆ ಕೋಷ್ಟಕದಿಂದ ಚಿಹ್ನೆಯ ಮಾಹಿತಿಯನ್ನು ಪಡೆಯುತ್ತದೆ.
//! * ಮುಂದೆ ನಾವು `backtrace_pcinfo` ಎಂದು ಕರೆಯುತ್ತೇವೆ.ಇದು ಲಭ್ಯವಿದ್ದರೆ ಡೀಬಗ್‌ಇನ್‌ಫೋ ಕೋಷ್ಟಕಗಳನ್ನು ಪಾರ್ಸ್ ಮಾಡುತ್ತದೆ ಮತ್ತು ಇನ್ಲೈನ್ ಫ್ರೇಮ್‌ಗಳು, ಫೈಲ್ ಹೆಸರುಗಳು, ಸಾಲು ಸಂಖ್ಯೆಗಳು ಇತ್ಯಾದಿಗಳ ಬಗ್ಗೆ ಮಾಹಿತಿಯನ್ನು ಪಡೆದುಕೊಳ್ಳಲು ನಮಗೆ ಅನುಮತಿಸುತ್ತದೆ.
//!
//! ಕುಬ್ಜ ಕೋಷ್ಟಕಗಳನ್ನು ಲಿಬ್‌ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ಗೆ ಸೇರಿಸುವ ಬಗ್ಗೆ ಸಾಕಷ್ಟು ತಂತ್ರಗಳಿವೆ, ಆದರೆ ಇದು ಪ್ರಪಂಚದ ಅಂತ್ಯವಲ್ಲ ಮತ್ತು ಕೆಳಗೆ ಓದುವಾಗ ಸಾಕಷ್ಟು ಸ್ಪಷ್ಟವಾಗಿದೆ.
//!
//! ಇದು MSVC ಅಲ್ಲದ ಮತ್ತು OSX ಅಲ್ಲದ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಿಗೆ ಡೀಫಾಲ್ಟ್ ಸಂಕೇತೀಕರಣ ತಂತ್ರವಾಗಿದೆ.ಲಿಬ್‌ಸ್ಟಡ್‌ನಲ್ಲಿ ಇದು ಒಎಸ್‌ಎಕ್ಸ್‌ನ ಡೀಫಾಲ್ಟ್ ತಂತ್ರವಾಗಿದೆ.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // ಸಾಧ್ಯವಾದರೆ ಡೀಬಗ್‌ಇನ್‌ಫೊದಿಂದ ಬರುವ `function` ಹೆಸರನ್ನು ಆದ್ಯತೆ ನೀಡಿ ಮತ್ತು ಉದಾಹರಣೆಗೆ ಇನ್ಲೈನ್ ಫ್ರೇಮ್‌ಗಳಿಗೆ ಹೆಚ್ಚು ನಿಖರವಾಗಿರಬಹುದು.
                // ಅದು ಇಲ್ಲದಿದ್ದರೆ `symname` ನಲ್ಲಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಚಿಹ್ನೆ ಟೇಬಲ್ ಹೆಸರಿಗೆ ಹಿಂತಿರುಗಿ.
                //
                // ಕೆಲವೊಮ್ಮೆ `function` ಸ್ವಲ್ಪ ಕಡಿಮೆ ನಿಖರತೆಯನ್ನು ಅನುಭವಿಸಬಹುದು ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಉದಾಹರಣೆಗೆ X002 ನ `try<i32,closure>` isntead ಎಂದು ಪಟ್ಟಿ ಮಾಡಲಾಗಿದೆ.
                //
                // ಏಕೆ ಎಂಬುದು ನಿಜವಾಗಿಯೂ ಸ್ಪಷ್ಟವಾಗಿಲ್ಲ, ಆದರೆ ಒಟ್ಟಾರೆಯಾಗಿ `function` ಹೆಸರು ಹೆಚ್ಚು ನಿಖರವಾಗಿ ತೋರುತ್ತದೆ.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // ಸದ್ಯಕ್ಕೆ ಏನನ್ನೂ ಮಾಡಬೇಡಿ
}

/// `data` ಪಾಯಿಂಟರ್‌ನ ಪ್ರಕಾರವನ್ನು `syminfo_cb` ಗೆ ರವಾನಿಸಲಾಗಿದೆ
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // ನಾವು ಪರಿಹರಿಸಲು ಪ್ರಾರಂಭಿಸಿದಾಗ `backtrace_syminfo` ನಿಂದ ಈ ಕಾಲ್ಬ್ಯಾಕ್ ಅನ್ನು ಆಹ್ವಾನಿಸಿದ ನಂತರ ನಾವು `backtrace_pcinfo` ಗೆ ಕರೆ ಮಾಡಲು ಮತ್ತಷ್ಟು ಹೋಗುತ್ತೇವೆ.
    // `backtrace_pcinfo` ಕಾರ್ಯವು ಡೀಬಗ್ ಮಾಹಿತಿಯನ್ನು ಸಮಾಲೋಚಿಸುತ್ತದೆ ಮತ್ತು file/line ಮಾಹಿತಿ ಮತ್ತು ಇನ್ಲೈನ್ ಫ್ರೇಮ್‌ಗಳನ್ನು ಮರುಪಡೆಯುವಂತಹ ಕೆಲಸಗಳನ್ನು ಮಾಡಲು ಪ್ರಯತ್ನಿಸುತ್ತದೆ.
    // ಡೀಬಗ್ ಮಾಹಿತಿ ಇಲ್ಲದಿದ್ದರೆ `backtrace_pcinfo` ವಿಫಲವಾಗಬಹುದು ಅಥವಾ ಹೆಚ್ಚಿನದನ್ನು ಮಾಡಲಾಗುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಆದ್ದರಿಂದ ಅದು ಸಂಭವಿಸಿದಲ್ಲಿ ನಾವು `syminfo_cb` ನಿಂದ ಕನಿಷ್ಠ ಒಂದು ಚಿಹ್ನೆಯೊಂದಿಗೆ ಕಾಲ್ಬ್ಯಾಕ್ ಅನ್ನು ಕರೆಯುವುದು ಖಚಿತ.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `data` ಪಾಯಿಂಟರ್‌ನ ಪ್ರಕಾರವನ್ನು `pcinfo_cb` ಗೆ ರವಾನಿಸಲಾಗಿದೆ
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// ಲಿಬ್‌ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ API ರಾಜ್ಯವನ್ನು ರಚಿಸಲು ಬೆಂಬಲಿಸುತ್ತದೆ, ಆದರೆ ಇದು ರಾಜ್ಯವನ್ನು ನಾಶಮಾಡುವುದನ್ನು ಬೆಂಬಲಿಸುವುದಿಲ್ಲ.
// ನಾನು ವೈಯಕ್ತಿಕವಾಗಿ ಇದನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತೇನೆ ಎಂದರೆ ರಾಜ್ಯವನ್ನು ಸೃಷ್ಟಿಸಬೇಕು ಮತ್ತು ನಂತರ ಶಾಶ್ವತವಾಗಿ ಬದುಕಬೇಕು.
//
// ಈ ಸ್ಥಿತಿಯನ್ನು ಸ್ವಚ್ ans ಗೊಳಿಸುವ at_exit() ಹ್ಯಾಂಡ್ಲರ್ ಅನ್ನು ನೋಂದಾಯಿಸಲು ನಾನು ಇಷ್ಟಪಡುತ್ತೇನೆ, ಆದರೆ ಲಿಬ್‌ಬ್ಯಾಕ್ಟ್ರೇಸ್ ಹಾಗೆ ಮಾಡಲು ಯಾವುದೇ ಮಾರ್ಗವನ್ನು ಒದಗಿಸುವುದಿಲ್ಲ.
//
// ಈ ನಿರ್ಬಂಧಗಳೊಂದಿಗೆ, ಈ ಕಾರ್ಯವು ಸ್ಥಿರವಾಗಿ ಸಂಗ್ರಹಿಸಿದ ಸ್ಥಿತಿಯನ್ನು ಹೊಂದಿದೆ, ಇದನ್ನು ಮೊದಲ ಬಾರಿಗೆ ವಿನಂತಿಸಿದಾಗ ಲೆಕ್ಕಹಾಕಲಾಗುತ್ತದೆ.
//
// ಬ್ಯಾಕ್‌ಟ್ರೇಸಿಂಗ್ ಎಲ್ಲವೂ ಸರಣಿಯಾಗಿ ನಡೆಯುತ್ತದೆ ಎಂಬುದನ್ನು ನೆನಪಿಡಿ (ಒಂದು ಜಾಗತಿಕ ಲಾಕ್).
//
// ಇಲ್ಲಿ ಸಿಂಕ್ರೊನೈಸೇಶನ್ ಕೊರತೆಯು `resolve` ಅನ್ನು ಬಾಹ್ಯವಾಗಿ ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡುವ ಅವಶ್ಯಕತೆಯಿಂದಾಗಿ ಗಮನಿಸಿ.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // ಲಿಬ್‌ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ನ ಥ್ರೆಡ್‌ಸೇಫ್ ಸಾಮರ್ಥ್ಯಗಳನ್ನು ನಾವು ಯಾವಾಗಲೂ ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡಿದ ಶೈಲಿಯಲ್ಲಿ ಕರೆಯುವುದರಿಂದ ವ್ಯಾಯಾಮ ಮಾಡಬೇಡಿ.
        //
        0,
        error_cb,
        ptr::null_mut(), // ಹೆಚ್ಚುವರಿ ಡೇಟಾ ಇಲ್ಲ
    );

    return STATE;

    // ಲಿಬ್‌ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಕಾರ್ಯನಿರ್ವಹಿಸಲು ಅದು ಪ್ರಸ್ತುತ ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದಾದ DWARF ಡೀಬಗ್ ಮಾಹಿತಿಯನ್ನು ಕಂಡುಹಿಡಿಯಬೇಕು ಎಂಬುದನ್ನು ಗಮನಿಸಿ.ಇದು ಸಾಮಾನ್ಯವಾಗಿ ಹಲವಾರು ಕಾರ್ಯವಿಧಾನಗಳ ಮೂಲಕ ಮಾಡುತ್ತದೆ, ಆದರೆ ಇವುಗಳಿಗೆ ಸೀಮಿತವಾಗಿಲ್ಲ:
    //
    // * /proc/self/exe ಬೆಂಬಲಿತ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ
    // * ರಾಜ್ಯವನ್ನು ರಚಿಸುವಾಗ ಫೈಲ್ ಹೆಸರು ಸ್ಪಷ್ಟವಾಗಿ ರವಾನಿಸಲಾಗಿದೆ
    //
    // ಲಿಬ್‌ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಲೈಬ್ರರಿ ಸಿ ಕೋಡ್‌ನ ದೊಡ್ಡ ವಾಡ್ ಆಗಿದೆ.ಇದು ಸ್ವಾಭಾವಿಕವಾಗಿ ಇದರರ್ಥ ಮೆಮೊರಿ ಸುರಕ್ಷತಾ ದೋಷಗಳನ್ನು ಹೊಂದಿದೆ, ವಿಶೇಷವಾಗಿ ದೋಷಪೂರಿತ ಡೀಬಗಿನ್‌ಫೊವನ್ನು ನಿರ್ವಹಿಸುವಾಗ.
    // ಲಿಬ್ಸ್ಟ್ ಐತಿಹಾಸಿಕವಾಗಿ ಇವುಗಳಲ್ಲಿ ಸಾಕಷ್ಟು ತೊಡಗಿದೆ.
    //
    // /proc/self/exe ಅನ್ನು ಬಳಸಿದರೆ, ಲಿಬ್‌ಬ್ಯಾಕ್ಟ್ರೇಸ್ "mostly correct" ಎಂದು ನಾವು as ಹಿಸಿದಂತೆ ನಾವು ಸಾಮಾನ್ಯವಾಗಿ ಇವುಗಳನ್ನು ನಿರ್ಲಕ್ಷಿಸಬಹುದು ಮತ್ತು ಇಲ್ಲದಿದ್ದರೆ "attempted to be correct" ಡ್ವಾರ್ಫ್ ಡೀಬಗ್ ಮಾಹಿತಿಯೊಂದಿಗೆ ವಿಲಕ್ಷಣವಾದ ಕೆಲಸಗಳನ್ನು ಮಾಡುವುದಿಲ್ಲ.
    //
    //
    // ನಾವು ಫೈಲ್ ಹೆಸರಿನಲ್ಲಿ ಹಾದು ಹೋದರೆ, ಕೆಲವು ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ (ಬಿಎಸ್‌ಡಿಗಳಂತೆ) ಸಾಧ್ಯವಿದೆ, ಅಲ್ಲಿ ದುರುದ್ದೇಶಪೂರಿತ ನಟನು ಆ ಸ್ಥಳದಲ್ಲಿ ಅನಿಯಂತ್ರಿತ ಫೈಲ್ ಅನ್ನು ಇರಿಸಲು ಕಾರಣವಾಗಬಹುದು.
    // ಇದರರ್ಥ ನಾವು ಫೈಲ್ ಹೆಸರಿನ ಬಗ್ಗೆ ಲಿಬ್‌ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ಗೆ ಹೇಳಿದರೆ ಅದು ಅನಿಯಂತ್ರಿತ ಫೈಲ್ ಅನ್ನು ಬಳಸುತ್ತಿರಬಹುದು, ಬಹುಶಃ ಸೆಗ್‌ಫಾಲ್ಟ್‌ಗಳಿಗೆ ಕಾರಣವಾಗಬಹುದು.
    // ನಾವು ಲಿಬ್‌ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ಗೆ ಏನನ್ನೂ ಹೇಳದಿದ್ದರೆ ಅದು /proc/self/exe ನಂತಹ ಮಾರ್ಗಗಳನ್ನು ಬೆಂಬಲಿಸದ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಏನನ್ನೂ ಮಾಡುವುದಿಲ್ಲ!
    //
    // ಫೈಲ್ ಹೆಸರಿನಲ್ಲಿ * ರವಾನಿಸದಿರಲು ನಾವು ಸಾಧ್ಯವಾದಷ್ಟು ಪ್ರಯತ್ನಿಸುತ್ತೇವೆ, ಆದರೆ ನಾವು /proc/self/exe ಅನ್ನು ಬೆಂಬಲಿಸದ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿರಬೇಕು.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // ಆದರ್ಶಪ್ರಾಯವಾಗಿ ನಾವು `std::env::current_exe` ಅನ್ನು ಬಳಸುತ್ತೇವೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಆದರೆ ನಮಗೆ ಇಲ್ಲಿ `std` ಅಗತ್ಯವಿಲ್ಲ.
            //
            // ಪ್ರಸ್ತುತ ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದಾದ ಮಾರ್ಗವನ್ನು ಸ್ಥಿರ ಪ್ರದೇಶಕ್ಕೆ ಲೋಡ್ ಮಾಡಲು `_NSGetExecutablePath` ಬಳಸಿ (ಅದು ತುಂಬಾ ಚಿಕ್ಕದಾಗಿದ್ದರೆ ಬಿಟ್ಟುಬಿಡಿ).
            //
            //
            // ಭ್ರಷ್ಟ ಕಾರ್ಯಗತಗೊಳ್ಳುವವರ ಮೇಲೆ ಸಾಯದಂತೆ ನಾವು ಇಲ್ಲಿ ಲಿಬ್‌ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಅನ್ನು ಗಂಭೀರವಾಗಿ ನಂಬುತ್ತಿದ್ದೇವೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಆದರೆ ಅದು ಖಂಡಿತವಾಗಿಯೂ ಮಾಡುತ್ತದೆ ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows ಫೈಲ್‌ಗಳನ್ನು ತೆರೆಯುವ ವಿಧಾನವನ್ನು ಹೊಂದಿದೆ, ಅದು ತೆರೆದ ನಂತರ ಅದನ್ನು ಅಳಿಸಲಾಗುವುದಿಲ್ಲ.
            // ಅದು ಸಾಮಾನ್ಯವಾಗಿ ನಮಗೆ ಇಲ್ಲಿ ಬೇಕಾಗಿರುವುದು, ಏಕೆಂದರೆ ನಾವು ಅದನ್ನು ಲಿಬ್‌ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ಗೆ ಹಸ್ತಾಂತರಿಸಿದ ನಂತರ ನಮ್ಮ ಕಾರ್ಯಗತಗೊಳ್ಳುವಿಕೆಯು ನಮ್ಮಿಂದ ಬದಲಾಗುತ್ತಿಲ್ಲ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ನಾವು ಬಯಸುತ್ತೇವೆ, ಅನಿಯಂತ್ರಿತ ಡೇಟಾವನ್ನು ಲಿಬ್‌ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ಗೆ ರವಾನಿಸುವ ಸಾಮರ್ಥ್ಯವನ್ನು ಆಶಾದಾಯಕವಾಗಿ ತಗ್ಗಿಸುತ್ತದೆ (ಇದು ತಪ್ಪಾಗಿ ನಿರ್ವಹಿಸಲ್ಪಡಬಹುದು).
            //
            //
            // ನಮ್ಮದೇ ಆದ ಚಿತ್ರದ ಮೇಲೆ ಒಂದು ರೀತಿಯ ಲಾಕ್ ಪಡೆಯಲು ಪ್ರಯತ್ನಿಸಲು ನಾವು ಇಲ್ಲಿ ಸ್ವಲ್ಪ ನೃತ್ಯ ಮಾಡುತ್ತೇವೆ:
            //
            // * ಪ್ರಸ್ತುತ ಪ್ರಕ್ರಿಯೆಗೆ ಹ್ಯಾಂಡಲ್ ಪಡೆಯಿರಿ, ಅದರ ಫೈಲ್ ಹೆಸರನ್ನು ಲೋಡ್ ಮಾಡಿ.
            // * ಸರಿಯಾದ ಧ್ವಜಗಳೊಂದಿಗೆ ಫೈಲ್ ಅನ್ನು ಆ ಫೈಲ್ ಹೆಸರಿಗೆ ತೆರೆಯಿರಿ.
            // * ಪ್ರಸ್ತುತ ಪ್ರಕ್ರಿಯೆಯ ಫೈಲ್ ಹೆಸರನ್ನು ಮರುಲೋಡ್ ಮಾಡಿ, ಅದು ಒಂದೇ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ
            //
            // ಎಲ್ಲಾ ಪಾಸ್ಗಳು ನಾವು ಸಿದ್ಧಾಂತದಲ್ಲಿ ನಿಜವಾಗಿಯೂ ನಮ್ಮ ಪ್ರಕ್ರಿಯೆಯ ಫೈಲ್ ಅನ್ನು ತೆರೆದಿದ್ದೇವೆ ಮತ್ತು ಅದು ಬದಲಾಗುವುದಿಲ್ಲ ಎಂದು ನಮಗೆ ಖಾತ್ರಿಯಿದೆ.FWIW ಇದರ ಒಂದು ಗುಂಪನ್ನು ಐತಿಹಾಸಿಕವಾಗಿ libstd ನಿಂದ ನಕಲಿಸಲಾಗಿದೆ, ಆದ್ದರಿಂದ ಇದು ಏನಾಗುತ್ತಿದೆ ಎಂಬುದರ ಕುರಿತು ನನ್ನ ಅತ್ಯುತ್ತಮ ವ್ಯಾಖ್ಯಾನವಾಗಿದೆ.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // ಇದು ಸ್ಥಿರ ಸ್ಮರಣೆಯಲ್ಲಿ ವಾಸಿಸುತ್ತದೆ ಆದ್ದರಿಂದ ನಾವು ಅದನ್ನು ಹಿಂದಿರುಗಿಸಬಹುದು ..
                static mut BUF: [i8; N] = [0; N];
                // ... ಮತ್ತು ಇದು ತಾತ್ಕಾಲಿಕವಾಗಿರುವುದರಿಂದ ಇದು ಸ್ಟಾಕ್‌ನಲ್ಲಿ ವಾಸಿಸುತ್ತದೆ
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // ಉದ್ದೇಶಪೂರ್ವಕವಾಗಿ ಇಲ್ಲಿ `handle` ಅನ್ನು ಸೋರಿಕೆ ಮಾಡಿ ಏಕೆಂದರೆ ಅದನ್ನು ತೆರೆದಿರುವುದು ಈ ಫೈಲ್ ಹೆಸರಿನಲ್ಲಿ ನಮ್ಮ ಲಾಕ್ ಅನ್ನು ಕಾಪಾಡುತ್ತದೆ.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // ಶೂನ್ಯ-ಅಂತ್ಯಗೊಂಡ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸಲು ನಾವು ಬಯಸುತ್ತೇವೆ, ಆದ್ದರಿಂದ ಎಲ್ಲವನ್ನೂ ಭರ್ತಿ ಮಾಡಿದ್ದರೆ ಮತ್ತು ಅದು ಒಟ್ಟು ಉದ್ದಕ್ಕೆ ಸಮನಾಗಿದ್ದರೆ ಅದನ್ನು ವೈಫಲ್ಯಕ್ಕೆ ಸಮನಾಗಿರುತ್ತದೆ.
                //
                //
                // ಇಲ್ಲದಿದ್ದರೆ ಯಶಸ್ಸನ್ನು ಹಿಂದಿರುಗಿಸುವಾಗ ನಲ್ ಬೈಟ್ ಅನ್ನು ಸ್ಲೈಸ್‌ನಲ್ಲಿ ಸೇರಿಸಲಾಗಿದೆಯೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ದೋಷಗಳನ್ನು ಪ್ರಸ್ತುತ ಕಂಬಳಿ ಅಡಿಯಲ್ಲಿ ಅಳಿಸಲಾಗಿದೆ
    let state = init_state();
    if state.is_null() {
        return;
    }

    // `backtrace_syminfo` API ಗೆ ಕರೆ ಮಾಡಿ (ಕೋಡ್ ಓದುವುದರಿಂದ) `syminfo_cb` ಅನ್ನು ನಿಖರವಾಗಿ ಒಮ್ಮೆ ಕರೆಯಬೇಕು (ಅಥವಾ ದೋಷದಿಂದ ಬಹುಶಃ ವಿಫಲಗೊಳ್ಳುತ್ತದೆ).
    // ನಾವು ನಂತರ `syminfo_cb` ಒಳಗೆ ಹೆಚ್ಚು ನಿಭಾಯಿಸುತ್ತೇವೆ.
    //
    // ಬೈನರಿಯಲ್ಲಿ ಯಾವುದೇ ಡೀಬಗ್ ಮಾಹಿತಿ ಇಲ್ಲದಿದ್ದರೂ ಸಹ `syminfo` ಚಿಹ್ನೆ ಕೋಷ್ಟಕವನ್ನು ಸಂಪರ್ಕಿಸುತ್ತದೆ, ಚಿಹ್ನೆಯ ಹೆಸರುಗಳನ್ನು ಕಂಡುಹಿಡಿಯುವುದರಿಂದ ನಾವು ಇದನ್ನು ಮಾಡುತ್ತೇವೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}