// ಇದೀಗ Linux ನಲ್ಲಿ ಮಾತ್ರ ಬಳಸಲಾಗುತ್ತದೆ, ಆದ್ದರಿಂದ ಬೇರೆಡೆ ಡೆಡ್ ಕೋಡ್ ಅನ್ನು ಅನುಮತಿಸಿ
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// ಬೈಟ್ ಬಫರ್‌ಗಳಿಗಾಗಿ ಸರಳ ಅರೇನಾ ಹಂಚಿಕೆ.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಗಾತ್ರದ ಬಫರ್ ಅನ್ನು ನಿಯೋಜಿಸುತ್ತದೆ ಮತ್ತು ಅದಕ್ಕೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ನೀಡುತ್ತದೆ.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // ಸುರಕ್ಷತೆ: ಇದುವರೆಗೆ ರೂಪಾಂತರವನ್ನು ನಿರ್ಮಿಸುವ ಏಕೈಕ ಕಾರ್ಯವಾಗಿದೆ
        // `self.buffers` ಗೆ ಉಲ್ಲೇಖ.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // ಸುರಕ್ಷತೆ: ನಾವು ಎಂದಿಗೂ `self.buffers` ನಿಂದ ಅಂಶಗಳನ್ನು ತೆಗೆದುಹಾಕುವುದಿಲ್ಲ, ಆದ್ದರಿಂದ ಉಲ್ಲೇಖ
        // ಯಾವುದೇ ಬಫರ್‌ನೊಳಗಿನ ಡೇಟಾಗೆ `self` ಇರುವವರೆಗೂ ಜೀವಿಸುತ್ತದೆ.
        &mut buffers[i]
    }
}