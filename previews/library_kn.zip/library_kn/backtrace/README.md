# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Rust ಗಾಗಿ ಚಾಲನಾಸಮಯದಲ್ಲಿ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ಗಳನ್ನು ಪಡೆಯಲು ಒಂದು ಗ್ರಂಥಾಲಯ.
ಈ ಗ್ರಂಥಾಲಯವು ಕೆಲಸ ಮಾಡಲು ಪ್ರೋಗ್ರಾಮಿಕ್ ಇಂಟರ್ಫೇಸ್ ಅನ್ನು ಒದಗಿಸುವ ಮೂಲಕ ಸ್ಟ್ಯಾಂಡರ್ಡ್ ಲೈಬ್ರರಿಯ ಬೆಂಬಲವನ್ನು ಹೆಚ್ಚಿಸುವ ಗುರಿಯನ್ನು ಹೊಂದಿದೆ, ಆದರೆ ಇದು ಪ್ರಸ್ತುತ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಅನ್ನು ಲಿಬ್‌ಸ್ಟಡ್‌ನ panics ನಂತಹ ಸುಲಭವಾಗಿ ಮುದ್ರಿಸುವುದನ್ನು ಸಹ ಬೆಂಬಲಿಸುತ್ತದೆ.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

ಬ್ಯಾಕ್‌ಟ್ರೇಸ್ ಅನ್ನು ಸೆರೆಹಿಡಿಯಲು ಮತ್ತು ನಂತರದ ಸಮಯದವರೆಗೆ ಅದರೊಂದಿಗೆ ವ್ಯವಹರಿಸಲು ಮುಂದೂಡಲು, ನೀವು ಉನ್ನತ ಮಟ್ಟದ `Backtrace` ಪ್ರಕಾರವನ್ನು ಬಳಸಬಹುದು.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

ಆದಾಗ್ಯೂ, ನಿಜವಾದ ಪತ್ತೆಹಚ್ಚುವ ಕಾರ್ಯಕ್ಕೆ ನೀವು ಹೆಚ್ಚು ಕಚ್ಚಾ ಪ್ರವೇಶವನ್ನು ಬಯಸಿದರೆ, ನೀವು ನೇರವಾಗಿ `trace` ಮತ್ತು `resolve` ಕಾರ್ಯಗಳನ್ನು ಬಳಸಬಹುದು.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // ಈ ಸೂಚನಾ ಪಾಯಿಂಟರ್ ಅನ್ನು ಚಿಹ್ನೆಯ ಹೆಸರಿಗೆ ಪರಿಹರಿಸಿ
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // ಮುಂದಿನ ಫ್ರೇಮ್‌ಗೆ ಮುಂದುವರಿಯಿರಿ
    });
}
```

# License

ಈ ಯೋಜನೆಯು ಎರಡರ ಅಡಿಯಲ್ಲಿ ಪರವಾನಗಿ ಪಡೆದಿದೆ

 * Apache ಪರವಾನಗಿ, ಆವೃತ್ತಿ 2.0, ([LICENSE-APACHE](LICENSE-APACHE) ಅಥವಾ http://www.apache.org/licenses/LICENSE-2.0)
 * MIT ಪರವಾನಗಿ ([LICENSE-MIT](LICENSE-MIT) ಅಥವಾ http://opensource.org/licenses/MIT)

ನಿಮ್ಮ ಆಯ್ಕೆಯಲ್ಲಿ.

### Contribution

ನೀವು ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಸ್ಪಷ್ಟವಾಗಿ ಹೇಳದಿದ್ದಲ್ಲಿ, Apache-2.0 ಪರವಾನಗಿಯಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಿರುವಂತೆ ನೀವು ಬ್ಯಾಕ್‌ಟ್ರೇಸ್-ಆರ್ಎಸ್ನಲ್ಲಿ ಸೇರಿಸಲು ಉದ್ದೇಶಪೂರ್ವಕವಾಗಿ ಸಲ್ಲಿಸಿದ ಯಾವುದೇ ಕೊಡುಗೆಯನ್ನು ಯಾವುದೇ ಹೆಚ್ಚುವರಿ ನಿಯಮಗಳು ಅಥವಾ ಷರತ್ತುಗಳಿಲ್ಲದೆ ಮೇಲಿನಂತೆ ದ್ವಿ ಪರವಾನಗಿ ನೀಡಲಾಗುತ್ತದೆ.







