use backtrace::Backtrace;

// ಈ ಪರೀಕ್ಷೆಯು ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ, ಇದು ಫ್ರೇಮ್‌ಗಳಿಗಾಗಿ ಕಾರ್ಯನಿರ್ವಹಿಸುವ `symbol_address` ಕಾರ್ಯವನ್ನು ಹೊಂದಿರುತ್ತದೆ ಅದು ಚಿಹ್ನೆಯ ಆರಂಭಿಕ ವಿಳಾಸವನ್ನು ವರದಿ ಮಾಡುತ್ತದೆ.
// ಪರಿಣಾಮವಾಗಿ ಇದನ್ನು ಕೆಲವು ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗಿದೆ.
//
const ENABLED: bool = cfg!(all(
    // Windows ನಿಜವಾಗಿಯೂ ಪರೀಕ್ಷಿಸಲಾಗಿಲ್ಲ, ಮತ್ತು ಒಎಸ್ಎಕ್ಸ್ ವಾಸ್ತವವಾಗಿ ಸುತ್ತುವರಿದ ಚೌಕಟ್ಟನ್ನು ಕಂಡುಹಿಡಿಯುವುದನ್ನು ಬೆಂಬಲಿಸುವುದಿಲ್ಲ, ಆದ್ದರಿಂದ ಇದನ್ನು ನಿಷ್ಕ್ರಿಯಗೊಳಿಸಿ
    //
    target_os = "linux",
    // ARM ನಲ್ಲಿ ಸುತ್ತುವರಿದ ಕಾರ್ಯವನ್ನು ಕಂಡುಹಿಡಿಯುವುದು ಕೇವಲ ಐಪಿ ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}