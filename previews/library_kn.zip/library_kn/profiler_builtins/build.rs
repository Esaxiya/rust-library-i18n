//! `compiler-rt` ಲೈಬ್ರರಿಯ ಪ್ರೊಫೈಲರ್ ಭಾಗವನ್ನು ಕಂಪೈಲ್ ಮಾಡುತ್ತದೆ.
//!
//! ವಿವರಗಳಿಗಾಗಿ libcompiler_builtins crate ಗಾಗಿ build.rs ನೋಡಿ.

use std::env;
use std::path::Path;

fn main() {
    let target = env::var("TARGET").expect("TARGET was not set");
    let cfg = &mut cc::Build::new();

    // FIXME: `rerun-if-changed` ನಿರ್ದೇಶನಗಳನ್ನು ಪ್ರಸ್ತುತ ಹೊರಸೂಸಲಾಗುವುದಿಲ್ಲ ಮತ್ತು ಬಿಲ್ಡ್ ಸ್ಕ್ರಿಪ್ಟ್
    // ಈ ಮೂಲ ಫೈಲ್‌ಗಳಲ್ಲಿನ ಬದಲಾವಣೆಗಳು ಅಥವಾ ಅವುಗಳಲ್ಲಿ ಸೇರಿಸಲಾದ ಹೆಡರ್‌ಗಳನ್ನು ಮರು ಚಾಲನೆ ಮಾಡುವುದಿಲ್ಲ.
    let mut profile_sources = vec![
        "GCDAProfiling.c",
        "InstrProfiling.c",
        "InstrProfilingBuffer.c",
        "InstrProfilingFile.c",
        "InstrProfilingMerge.c",
        "InstrProfilingMergeFile.c",
        "InstrProfilingNameVar.c",
        "InstrProfilingPlatformDarwin.c",
        "InstrProfilingPlatformFuchsia.c",
        "InstrProfilingPlatformLinux.c",
        "InstrProfilingPlatformOther.c",
        "InstrProfilingPlatformWindows.c",
        "InstrProfilingUtil.c",
        "InstrProfilingValue.c",
        "InstrProfilingVersionVar.c",
        "InstrProfilingWriter.c",
        // ಈ ಫೈಲ್ ಅನ್ನು ಎಲ್ಎಲ್ವಿಎಂ 10 ರಲ್ಲಿ ಮರುಹೆಸರಿಸಲಾಗಿದೆ.
        "InstrProfilingRuntime.cc",
        "InstrProfilingRuntime.cpp",
        // ಈ ಫೈಲ್‌ಗಳನ್ನು ಎಲ್‌ಎಲ್‌ವಿಎಂ 11 ರಲ್ಲಿ ಸೇರಿಸಲಾಗಿದೆ.
        "InstrProfilingInternal.c",
        "InstrProfilingBiasVar.c",
    ];

    if target.contains("msvc") {
        // ಎಂಎಸ್‌ವಿಸಿಯಲ್ಲಿ ಹೆಚ್ಚುವರಿ ಗ್ರಂಥಾಲಯಗಳನ್ನು ಎಳೆಯಬೇಡಿ
        cfg.flag("/Zl");
        profile_sources.push("WindowsMMap.c");
        cfg.define("strdup", Some("_strdup"));
        cfg.define("open", Some("_open"));
        cfg.define("fdopen", Some("_fdopen"));
        cfg.define("getpid", Some("_getpid"));
        cfg.define("fileno", Some("_fileno"));
    } else {
        // gcc ನ ವಿವಿಧ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಆಫ್ ಮಾಡಿ ಮತ್ತು ಹೆಚ್ಚಾಗಿ, ಕಂಪೈಲರ್-ಆರ್ಟಿಯ ಬಿಲ್ಡ್ ಸಿಸ್ಟಮ್ ಅನ್ನು ಈಗಾಗಲೇ ನಕಲಿಸಲಾಗುತ್ತಿದೆ
        //
        cfg.flag("-fno-builtin");
        cfg.flag("-fomit-frame-pointer");
        cfg.define("VISIBILITY_HIDDEN", None);
        if !target.contains("windows") {
            cfg.flag("-fvisibility=hidden");
            cfg.define("COMPILER_RT_HAS_UNAME", Some("1"));
        } else {
            profile_sources.push("WindowsMMap.c");
        }
    }

    // fnctl() ಲಭ್ಯವಿರುವುದರಿಂದ ನಾವು ಇದನ್ನು ನಿರ್ಮಿಸುತ್ತಿರುವ ಯುನಿಕ್ಸ್‌ಗಳು ಎಂದು ume ಹಿಸಿ
    if env::var_os("CARGO_CFG_UNIX").is_some() {
        cfg.define("COMPILER_RT_HAS_FCNTL_LCK", Some("1"));
    }

    // COMPILER_RT_HAS_ATOMICS ಅನ್ನು ಯಾವಾಗ ಹೊಂದಿಸಬೇಕೆಂಬುದಕ್ಕೆ ಇದು ಉತ್ತಮ ಹ್ಯೂರಿಸ್ಟಿಕ್ ಆಗಿರಬೇಕು
    //
    if env::var_os("CARGO_CFG_TARGET_HAS_ATOMIC")
        .map(|features| features.to_string_lossy().to_lowercase().contains("ptr"))
        .unwrap_or(false)
    {
        cfg.define("COMPILER_RT_HAS_ATOMICS", Some("1"));
    }

    // ನಾವು ಚಲಾಯಿಸಲು ಹೋದರೆ ಇದು ಅಸ್ತಿತ್ವದಲ್ಲಿರಬೇಕು ಎಂಬುದನ್ನು ಗಮನಿಸಿ (ಇಲ್ಲದಿದ್ದರೆ ನಾವು ಪ್ರೊಫೈಲರ್ ಬಿಲ್ಡಿನ್‌ಗಳನ್ನು ನಿರ್ಮಿಸುವುದಿಲ್ಲ).
    //
    let root = Path::new("../../src/llvm-project/compiler-rt");

    let src_root = root.join("lib").join("profile");
    for src in profile_sources {
        let path = src_root.join(src);
        if path.exists() {
            cfg.file(path);
        }
    }

    cfg.include(root.join("include"));
    cfg.warnings(false);
    cfg.compile("profiler-rt");
}