`core::arch` - Rust ನ ಕೋರ್ ಲೈಬ್ರರಿ ಆರ್ಕಿಟೆಕ್ಚರ್-ನಿರ್ದಿಷ್ಟ ಆಂತರಿಕತೆ
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` ಮಾಡ್ಯೂಲ್ ವಾಸ್ತುಶಿಲ್ಪ-ಅವಲಂಬಿತ ಆಂತರಿಕತೆಯನ್ನು (ಉದಾ: SIMD) ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.

# Usage 

`core::arch` `libcore` ನ ಭಾಗವಾಗಿ ಲಭ್ಯವಿದೆ ಮತ್ತು ಇದನ್ನು `libstd` ನಿಂದ ಮರು-ರಫ್ತು ಮಾಡಲಾಗುತ್ತದೆ.ಈ crate ಗಿಂತ `core::arch` ಅಥವಾ `std::arch` ಮೂಲಕ ಬಳಸಲು ಆದ್ಯತೆ ನೀಡಿ.
ಅಸ್ಥಿರ ವೈಶಿಷ್ಟ್ಯಗಳು ಹೆಚ್ಚಾಗಿ ರಾತ್ರಿಯ Rust ನಲ್ಲಿ `feature(stdsimd)` ಮೂಲಕ ಲಭ್ಯವಿದೆ.

ಈ crate ಮೂಲಕ `core::arch` ಅನ್ನು ಬಳಸುವುದಕ್ಕೆ ರಾತ್ರಿಯ Rust ಅಗತ್ಯವಿದೆ, ಮತ್ತು ಇದು ಆಗಾಗ್ಗೆ ಮುರಿಯಬಹುದು (ಮತ್ತು ಮಾಡುತ್ತದೆ).ಈ crate ಮೂಲಕ ನೀವು ಅದನ್ನು ಬಳಸುವುದನ್ನು ಪರಿಗಣಿಸಬೇಕಾದ ಏಕೈಕ ಸಂದರ್ಭಗಳು:

* ನೀವು `core::arch` ಅನ್ನು ಮರು ಕಂಪೈಲ್ ಮಾಡಬೇಕಾದರೆ, ಉದಾ., `libcore`/`libstd` ಗಾಗಿ ಸಕ್ರಿಯಗೊಳಿಸದ ನಿರ್ದಿಷ್ಟ ಗುರಿ-ವೈಶಿಷ್ಟ್ಯಗಳೊಂದಿಗೆ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗಿದೆ.
Note: ಪ್ರಮಾಣಿತವಲ್ಲದ ಗುರಿಗಾಗಿ ನೀವು ಅದನ್ನು ಮರು ಕಂಪೈಲ್ ಮಾಡಬೇಕಾದರೆ, ದಯವಿಟ್ಟು ಈ crate ಅನ್ನು ಬಳಸುವ ಬದಲು `xargo` ಅನ್ನು ಬಳಸಲು ಮತ್ತು `libcore`/`libstd` ಅನ್ನು ಮರು ಕಂಪೈಲ್ ಮಾಡಲು ಆದ್ಯತೆ ನೀಡಿ.
  
* ಅಸ್ಥಿರವಾದ Rust ವೈಶಿಷ್ಟ್ಯಗಳ ಹಿಂದೆ ಸಹ ಲಭ್ಯವಿಲ್ಲದ ಕೆಲವು ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಬಳಸುವುದು.ಇವುಗಳನ್ನು ಕನಿಷ್ಠ ಮಟ್ಟದಲ್ಲಿಡಲು ನಾವು ಪ್ರಯತ್ನಿಸುತ್ತೇವೆ.
ನೀವು ಈ ಕೆಲವು ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಬಳಸಬೇಕಾದರೆ, ದಯವಿಟ್ಟು ಸಮಸ್ಯೆಯನ್ನು ತೆರೆಯಿರಿ ಇದರಿಂದ ನಾವು ಅವುಗಳನ್ನು ರಾತ್ರಿಯ Rust ನಲ್ಲಿ ಬಹಿರಂಗಪಡಿಸಬಹುದು ಮತ್ತು ನೀವು ಅವುಗಳನ್ನು ಅಲ್ಲಿಂದ ಬಳಸಬಹುದು.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` ಪ್ರಾಥಮಿಕವಾಗಿ MIT ಪರವಾನಗಿ ಮತ್ತು Apache ಪರವಾನಗಿ (ಆವೃತ್ತಿ 2.0) ಎರಡರ ನಿಯಮಗಳ ಅಡಿಯಲ್ಲಿ ವಿತರಿಸಲಾಗುತ್ತದೆ, ಭಾಗಗಳನ್ನು ವಿವಿಧ ಬಿಎಸ್‌ಡಿ ತರಹದ ಪರವಾನಗಿಗಳಿಂದ ಒಳಗೊಂಡಿದೆ.

ವಿವರಗಳಿಗಾಗಿ LICENSE-APACHE, ಮತ್ತು LICENSE-MIT ನೋಡಿ.

# Contribution

ನೀವು ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಸ್ಪಷ್ಟವಾಗಿ ಹೇಳದಿದ್ದಲ್ಲಿ, X0Apache0Z-2.0 ಪರವಾನಗಿಯಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಿರುವಂತೆ ನೀವು `core_arch` ಗೆ ಸೇರಿಸಲು ಉದ್ದೇಶಪೂರ್ವಕವಾಗಿ ಸಲ್ಲಿಸಿದ ಯಾವುದೇ ಕೊಡುಗೆಯನ್ನು ಯಾವುದೇ ಹೆಚ್ಚುವರಿ ನಿಯಮಗಳು ಅಥವಾ ಷರತ್ತುಗಳಿಲ್ಲದೆ ಮೇಲಿನಂತೆ ದ್ವಿ ಪರವಾನಗಿ ನೀಡಲಾಗುತ್ತದೆ.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












