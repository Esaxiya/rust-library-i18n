use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // ನಮ್ಮ `#[assert_instr]` ಟಿಪ್ಪಣಿಗಳನ್ನು ಹೇಳಲು ಬಳಸಲಾಗುತ್ತದೆ ಎಲ್ಲಾ ಸಿಮ್ಡ್ ಆಂತರಿಕಗಳು ಅವುಗಳ ಕೋಡೆಜೆನ್ ಅನ್ನು ಪರೀಕ್ಷಿಸಲು ಲಭ್ಯವಿದೆ, ಏಕೆಂದರೆ ಕೆಲವು ಹೆಚ್ಚುವರಿ `-Ctarget-feature=+unimplemented-simd128` ನ ಹಿಂದೆ ಇರುವುದರಿಂದ ಅದು `#[target_feature]` ನಲ್ಲಿ ಯಾವುದೇ ಸಮಾನತೆಯನ್ನು ಹೊಂದಿಲ್ಲ.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}