//! `#[assert_instr]` ಮ್ಯಾಕ್ರೋ ಅನುಷ್ಠಾನ
//!
//! `stdarch` crate ಅನ್ನು ಪರೀಕ್ಷಿಸುವಾಗ ಈ ಮ್ಯಾಕ್ರೋವನ್ನು ಬಳಸಲಾಗುತ್ತದೆ ಮತ್ತು ಪರೀಕ್ಷಾ ಪ್ರಕರಣಗಳನ್ನು ಉತ್ಪಾದಿಸಲು ಇದನ್ನು ಬಳಸಲಾಗುತ್ತದೆ, ಅವುಗಳು ಕಾರ್ಯಗಳನ್ನು ಒಳಗೊಂಡಿರುತ್ತವೆ ಎಂದು ನಾವು ನಿರೀಕ್ಷಿಸುತ್ತಿರುವ ಸೂಚನೆಗಳನ್ನು ಒಳಗೊಂಡಿರುತ್ತವೆ.
//!
//! ಇಲ್ಲಿ ಕಾರ್ಯವಿಧಾನದ ಮ್ಯಾಕ್ರೋ ತುಲನಾತ್ಮಕವಾಗಿ ಸರಳವಾಗಿದೆ, ಇದು ಕೇವಲ `#[test]` ಕಾರ್ಯವನ್ನು ಮೂಲ token ಸ್ಟ್ರೀಮ್‌ಗೆ ಸೇರಿಸುತ್ತದೆ, ಅದು ಕಾರ್ಯವು ಸಂಬಂಧಿತ ಸೂಚನೆಯನ್ನು ಹೊಂದಿದೆ ಎಂದು ಪ್ರತಿಪಾದಿಸುತ್ತದೆ.
//!
//!
//!
//!

extern crate proc_macro;
extern crate proc_macro2;
#[macro_use]
extern crate quote;
extern crate syn;

use proc_macro2::TokenStream;
use quote::ToTokens;

#[proc_macro_attribute]
pub fn assert_instr(
    attr: proc_macro::TokenStream,
    item: proc_macro::TokenStream,
) -> proc_macro::TokenStream {
    let invoc = match syn::parse::<Invoc>(attr) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let item = match syn::parse::<syn::Item>(item) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let func = match item {
        syn::Item::Fn(ref f) => f,
        _ => panic!("must be attached to a function"),
    };

    let instr = &invoc.instr;
    let name = &func.sig.ident;

    // ಎವಿಎಕ್ಸ್ ಶಕ್ತಗೊಂಡ x86 ಗುರಿಗಳಿಗಾಗಿ assert_instr ಅನ್ನು ನಿಷ್ಕ್ರಿಯಗೊಳಿಸಿ, ಇದು ನಾವು ಪರೀಕ್ಷಿಸುತ್ತಿರುವ ವಿಭಿನ್ನ ಆಂತರಿಕತೆಯನ್ನು LLVM ಉತ್ಪಾದಿಸಲು ಕಾರಣವಾಗುತ್ತದೆ.
    //
    //
    let disable_assert_instr = std::env::var("STDARCH_DISABLE_ASSERT_INSTR").is_ok();

    // ಸೂಚನಾ ಪರೀಕ್ಷೆಗಳನ್ನು ನಿಷ್ಕ್ರಿಯಗೊಳಿಸಿದ್ದರೆ ಈ ಶಿಮ್ ಅನ್ನು ಹೊರಸೂಸುವುದನ್ನು ತಪ್ಪಿಸಿ, ನಮ್ಮ ಗುಣಲಕ್ಷಣವಿಲ್ಲದೆ ಮೂಲ ಐಟಂ ಅನ್ನು ಹಿಂತಿರುಗಿಸಿ.
    //
    if !cfg!(optimized) || disable_assert_instr {
        return (quote! { #item }).into();
    }

    let instr_str = instr
        .replace('.', "_")
        .replace('/', "_")
        .replace(':', "_")
        .replace(char::is_whitespace, "");
    let assert_name = syn::Ident::new(&format!("assert_{}_{}", name, instr_str), name.span());
    // ಈ ಹೆಸರನ್ನು ನಂತರ ಡಿಸ್ಅಸೆಂಬಲ್‌ನಲ್ಲಿ ಕಂಡುಹಿಡಿಯಲು ನಮಗೆ ಸಾಕಷ್ಟು ಅನನ್ಯವಾಗಿರಬೇಕು:
    let shim_name = syn::Ident::new(
        &format!("stdarch_test_shim_{}_{}", name, instr_str),
        name.span(),
    );
    let mut inputs = Vec::new();
    let mut input_vals = Vec::new();
    let ret = &func.sig.output;
    for arg in func.sig.inputs.iter() {
        let capture = match *arg {
            syn::FnArg::Typed(ref c) => c,
            ref v => panic!(
                "arguments must not have patterns: `{:?}`",
                v.clone().into_token_stream()
            ),
        };
        let ident = match *capture.pat {
            syn::Pat::Ident(ref i) => &i.ident,
            _ => panic!("must have bare arguments"),
        };
        if let Some(&(_, ref tokens)) = invoc.args.iter().find(|a| *ident == a.0) {
            input_vals.push(quote! { #tokens });
        } else {
            inputs.push(capture);
            input_vals.push(quote! { #ident });
        }
    }

    let attrs = func
        .attrs
        .iter()
        .filter(|attr| {
            attr.path
                .segments
                .first()
                .expect("attr.path.segments.first() failed")
                .ident
                .to_string()
                .starts_with("target")
        })
        .collect::<Vec<_>>();
    let attrs = Append(&attrs);

    // ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ Unix (ನನ್ನ ಪ್ರಕಾರ?) ನಲ್ಲಿ ಏನಾಗುತ್ತದೆ ಎಂಬಂತೆ ರೆಜಿಸ್ಟರ್‌ಗಳಲ್ಲಿ SIMD ಮೌಲ್ಯಗಳನ್ನು ಹಾದುಹೋಗುವ Windows ನಲ್ಲಿ ABI ಅನ್ನು ಬಳಸಿ.
    //
    let abi = if cfg!(windows) {
        syn::LitStr::new("vectorcall", proc_macro2::Span::call_site())
    } else {
        syn::LitStr::new("C", proc_macro2::Span::call_site())
    };
    let shim_name_str = format!("{}{}", shim_name, assert_name);
    let to_test = quote! {
        #attrs
        #[no_mangle]
        #[inline(never)]
        pub unsafe extern #abi fn #shim_name(#(#inputs),*) #ret {
            // ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಆಪ್ಟಿಮೈಸ್ಡ್ ಮೋಡ್‌ನಲ್ಲಿರುವ ಕಂಪೈಲರ್ "mergefunc" ಎಂಬ ಪಾಸ್ ಅನ್ನು ಚಲಾಯಿಸುತ್ತದೆ, ಅಲ್ಲಿ ಅದು ಒಂದೇ ರೀತಿ ಕಾಣುವ ಕಾರ್ಯಗಳನ್ನು ವಿಲೀನಗೊಳಿಸುತ್ತದೆ.
            // ಕೆಲವು ಆಂತರಿಕಗಳು ಒಂದೇ ರೀತಿಯ ಕೋಡ್ ಅನ್ನು ಉತ್ಪಾದಿಸುತ್ತವೆ ಮತ್ತು ಅವುಗಳನ್ನು ಒಟ್ಟಿಗೆ ಮಡಚಲಾಗುತ್ತದೆ, ಅಂದರೆ ಒಬ್ಬರು ಇನ್ನೊಂದಕ್ಕೆ ಹಾರಿದ್ದಾರೆ.
            // ಈ ಕಾರ್ಯದ ಡಿಸ್ಅಸೆಂಬಲ್ ಬಗ್ಗೆ ನಮ್ಮ ಪರಿಶೀಲನೆಯನ್ನು ಇದು ಗೊಂದಲಗೊಳಿಸುತ್ತದೆ ಮತ್ತು ನಾವು ಅದರ ದೊಡ್ಡ ಅಭಿಮಾನಿಯಲ್ಲ.
            //
            // ಈ ಪಾಸ್ ಅನ್ನು ತಡೆಯಲು ಮತ್ತು ಕಾರ್ಯಗಳನ್ನು ವಿಲೀನಗೊಳ್ಳದಂತೆ ತಡೆಯಲು ನಾವು ಕೋಡೆಜೆನ್ ವಿಷಯದಲ್ಲಿ ಆಶಾದಾಯಕವಾಗಿ ತುಂಬಾ ಬಿಗಿಯಾದ ಕೆಲವು ಕೋಡ್ ಅನ್ನು ರಚಿಸುತ್ತೇವೆ ಆದರೆ ಕೋಡ್ ಅನ್ನು ಮಡಚದಂತೆ ತಡೆಯಲು ಅನನ್ಯವಾಗಿದೆ.
            //
            //
            // Wasm32 ನಲ್ಲಿ ಇದೀಗ ಇದನ್ನು ತಪ್ಪಿಸಲಾಗಿದೆ ಏಕೆಂದರೆ ಈ ಕಾರ್ಯಗಳು ಇನ್ಲೈನ್ ಆಗಿಲ್ಲವಾದ್ದರಿಂದ ಇದು ನಮ್ಮ ಪರೀಕ್ಷೆಗಳನ್ನು ಮುರಿಯುತ್ತದೆ ಏಕೆಂದರೆ ಪ್ರತಿಯೊಂದು ಆಂತರಿಕವು ಕಾರ್ಯಗಳನ್ನು ಕರೆಯುವಂತೆ ಕಾಣುತ್ತದೆ.
            // ಹೇಗಾದರೂ wasm32 ನಲ್ಲಿ ವಿಲೀನಗೊಳ್ಳಲು ಕಾರ್ಯಗಳು ಸಾಕಷ್ಟು ಹೋಲುವಂತಿಲ್ಲ.
            // ಈ ದೋಷವನ್ನು rust-lang/rust#74320 ನಲ್ಲಿ ಟ್ರ್ಯಾಕ್ ಮಾಡಲಾಗಿದೆ.
            //
            //
            //
            //
            //
            //
            //
            #[cfg(not(target_arch = "wasm32"))]
            ::stdarch_test::_DONT_DEDUP.store(
                std::mem::transmute(#shim_name_str.as_bytes().as_ptr()),
                std::sync::atomic::Ordering::Relaxed,
            );
            #name(#(#input_vals),*)
        }
    };

    let tokens: TokenStream = quote! {
        #[test]
        #[allow(non_snake_case)]
        fn #assert_name() {
            #to_test

            ::stdarch_test::assert(#shim_name as usize,
                                   stringify!(#shim_name),
                                   #instr);
        }
    };

    let tokens: TokenStream = quote! {
        #item
        #tokens
    };
    tokens.into()
}

struct Invoc {
    instr: String,
    args: Vec<(syn::Ident, syn::Expr)>,
}

impl syn::parse::Parse for Invoc {
    fn parse(input: syn::parse::ParseStream) -> syn::Result<Self> {
        use syn::{ext::IdentExt, Token};

        let mut instr = String::new();
        while !input.is_empty() {
            if input.parse::<Token![,]>().is_ok() {
                break;
            }
            if let Ok(ident) = syn::Ident::parse_any(input) {
                instr.push_str(&ident.to_string());
                continue;
            }
            if input.parse::<Token![.]>().is_ok() {
                instr.push('.');
                continue;
            }
            if let Ok(s) = input.parse::<syn::LitStr>() {
                instr.push_str(&s.value());
                continue;
            }
            println!("{:?}", input.cursor().token_stream());
            return Err(input.error("expected an instruction"));
        }
        if instr.is_empty() {
            return Err(input.error("expected an instruction before comma"));
        }
        let mut args = Vec::new();
        while !input.is_empty() {
            let name = input.parse::<syn::Ident>()?;
            input.parse::<Token![=]>()?;
            let expr = input.parse::<syn::Expr>()?;
            args.push((name, expr));

            if input.parse::<Token![,]>().is_err() {
                if !input.is_empty() {
                    return Err(input.error("extra tokens at end"));
                }
                break;
            }
        }
        Ok(Self { instr, args })
    }
}

struct Append<T>(T);

impl<T> quote::ToTokens for Append<T>
where
    T: Clone + IntoIterator,
    T::Item: quote::ToTokens,
{
    fn to_tokens(&self, tokens: &mut proc_macro2::TokenStream) {
        for item in self.0.clone() {
            item.to_tokens(tokens);
        }
    }
}