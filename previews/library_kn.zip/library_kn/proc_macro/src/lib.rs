//! ಹೊಸ ಮ್ಯಾಕ್ರೋಗಳನ್ನು ವ್ಯಾಖ್ಯಾನಿಸುವಾಗ ಮ್ಯಾಕ್ರೋ ಲೇಖಕರಿಗೆ ಬೆಂಬಲ ಗ್ರಂಥಾಲಯ.
//!
//! ಸ್ಟ್ಯಾಂಡರ್ಡ್ ವಿತರಣೆಯಿಂದ ಒದಗಿಸಲಾದ ಈ ಗ್ರಂಥಾಲಯವು ಕಾರ್ಯ-ರೀತಿಯ ಮ್ಯಾಕ್ರೋ `#[proc_macro]`, ಮ್ಯಾಕ್ರೋ ಗುಣಲಕ್ಷಣಗಳು `#[proc_macro_attribute]` ಮತ್ತು ಕಸ್ಟಮ್ ವ್ಯುತ್ಪನ್ನ ಗುಣಲಕ್ಷಣಗಳಾದ##[proc_macro_derive] `ನಂತಹ ಕಾರ್ಯವಿಧಾನವಾಗಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ಮ್ಯಾಕ್ರೋ ವ್ಯಾಖ್ಯಾನಗಳ ಇಂಟರ್ಫೇಸ್‌ಗಳಲ್ಲಿ ಸೇವಿಸುವ ಪ್ರಕಾರಗಳನ್ನು ಒದಗಿಸುತ್ತದೆ.
//!
//!
//! ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ [the book] ನೋಡಿ.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// ಪ್ರಸ್ತುತ ಚಾಲನೆಯಲ್ಲಿರುವ ಪ್ರೋಗ್ರಾಂಗೆ proc_macro ಅನ್ನು ಪ್ರವೇಶಿಸಲಾಗಿದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುತ್ತದೆ.
///
/// Proc_macro crate ಅನ್ನು ಕಾರ್ಯವಿಧಾನದ ಮ್ಯಾಕ್ರೋಗಳ ಅನುಷ್ಠಾನದ ಒಳಗೆ ಬಳಸಲು ಮಾತ್ರ ಉದ್ದೇಶಿಸಲಾಗಿದೆ.ಬಿಲ್ಡ್ ಸ್ಕ್ರಿಪ್ಟ್ ಅಥವಾ ಯುನಿಟ್ ಟೆಸ್ಟ್ ಅಥವಾ ಸಾಮಾನ್ಯ Rust ಬೈನರಿಯಂತಹ ಕಾರ್ಯವಿಧಾನದ ಮ್ಯಾಕ್ರೊದ ಹೊರಗಿನಿಂದ ಆಹ್ವಾನಿಸಿದರೆ ಈ crate panic ನಲ್ಲಿನ ಎಲ್ಲಾ ಕಾರ್ಯಗಳು.
///
/// ಮ್ಯಾಕ್ರೋ ಮತ್ತು ಮ್ಯಾಕ್ರೋ ಅಲ್ಲದ ಬಳಕೆಯ ಸಂದರ್ಭಗಳನ್ನು ಬೆಂಬಲಿಸಲು ವಿನ್ಯಾಸಗೊಳಿಸಲಾದ Rust ಲೈಬ್ರರಿಗಳನ್ನು ಪರಿಗಣಿಸಿ, ಪ್ರೊಕ್_ಮಾಕ್ರೊದ API ಅನ್ನು ಬಳಸಲು ಅಗತ್ಯವಾದ ಮೂಲಸೌಕರ್ಯಗಳು ಪ್ರಸ್ತುತ ಲಭ್ಯವಿದೆಯೇ ಎಂದು ಕಂಡುಹಿಡಿಯಲು `proc_macro::is_available()` ಭಯಭೀತವಲ್ಲದ ಮಾರ್ಗವನ್ನು ಒದಗಿಸುತ್ತದೆ.
/// ಕಾರ್ಯವಿಧಾನದ ಮ್ಯಾಕ್ರೋ ಒಳಗಿನಿಂದ ಆಹ್ವಾನಿಸಿದರೆ ನಿಜ, ಬೇರೆ ಯಾವುದೇ ಬೈನರಿಗಳಿಂದ ಆಹ್ವಾನಿಸಿದರೆ ಸುಳ್ಳು.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// ಈ crate ಒದಗಿಸಿದ ಮುಖ್ಯ ಪ್ರಕಾರ, tokens ನ ಅಮೂರ್ತ ಸ್ಟ್ರೀಮ್ ಅನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ, ಅಥವಾ ಹೆಚ್ಚು ನಿರ್ದಿಷ್ಟವಾಗಿ, token ಮರಗಳ ಅನುಕ್ರಮ.
/// ಆ ಪ್ರಕಾರವು ಆ token ಮರಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಿಸಲು ಇಂಟರ್ಫೇಸ್‌ಗಳನ್ನು ಒದಗಿಸುತ್ತದೆ ಮತ್ತು ಇದಕ್ಕೆ ವಿರುದ್ಧವಾಗಿ, ಹಲವಾರು token ಮರಗಳನ್ನು ಒಂದೇ ಸ್ಟ್ರೀಮ್‌ಗೆ ಸಂಗ್ರಹಿಸುತ್ತದೆ.
///
///
/// ಇದು `#[proc_macro]`, `#[proc_macro_attribute]` ಮತ್ತು `#[proc_macro_derive]` ವ್ಯಾಖ್ಯಾನಗಳ ಇನ್ಪುಟ್ ಮತ್ತು output ಟ್ಪುಟ್ ಎರಡೂ ಆಗಿದೆ.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// `TokenStream::from_str` ನಿಂದ ದೋಷ ಮರಳಿದೆ.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// token ಮರಗಳನ್ನು ಹೊಂದಿರದ ಖಾಲಿ `TokenStream` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// ಈ `TokenStream` ಖಾಲಿಯಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು tokens ಗೆ ಮುರಿಯಲು ಮತ್ತು ಆ tokens ಅನ್ನು token ಸ್ಟ್ರೀಮ್‌ಗೆ ಪಾರ್ಸ್ ಮಾಡಲು ಪ್ರಯತ್ನಿಸುತ್ತದೆ.
/// ಹಲವಾರು ಕಾರಣಗಳಿಗಾಗಿ ವಿಫಲವಾಗಬಹುದು, ಉದಾಹರಣೆಗೆ, ಸ್ಟ್ರಿಂಗ್ ಅಸಮತೋಲಿತ ಡಿಲಿಮಿಟರ್ ಅಥವಾ ಭಾಷೆಯಲ್ಲಿ ಅಸ್ತಿತ್ವದಲ್ಲಿರದ ಅಕ್ಷರಗಳನ್ನು ಹೊಂದಿದ್ದರೆ.
///
/// ಪಾರ್ಸ್ ಮಾಡಿದ ಸ್ಟ್ರೀಮ್‌ನಲ್ಲಿರುವ ಎಲ್ಲಾ tokens `Span::call_site()` ವ್ಯಾಪ್ತಿಯನ್ನು ಪಡೆಯುತ್ತದೆ.
///
/// NOTE: ಕೆಲವು ದೋಷಗಳು `LexError` ಅನ್ನು ಹಿಂದಿರುಗಿಸುವ ಬದಲು panics ಗೆ ಕಾರಣವಾಗಬಹುದು.ಈ ದೋಷಗಳನ್ನು ನಂತರ `ಲೆಕ್ಸ್ ಎರರ್'ಗೆ ಬದಲಾಯಿಸುವ ಹಕ್ಕನ್ನು ನಾವು ಕಾಯ್ದಿರಿಸಿದ್ದೇವೆ.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, ಸೇತುವೆ `to_string` ಅನ್ನು ಮಾತ್ರ ಒದಗಿಸುತ್ತದೆ, ಅದರ ಆಧಾರದ ಮೇಲೆ `fmt::Display` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿ (ಇವೆರಡರ ನಡುವಿನ ಸಾಮಾನ್ಯ ಸಂಬಂಧದ ಹಿಮ್ಮುಖ).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// X0token0Z ಸ್ಟ್ರೀಮ್ ಅನ್ನು ಸ್ಟ್ರಿಂಗ್‌ನಂತೆ ಮುದ್ರಿಸುತ್ತದೆ, ಅದು ನಷ್ಟವಿಲ್ಲದೆ ಮತ್ತೆ ಅದೇ token ಸ್ಟ್ರೀಮ್‌ಗೆ (ಮಾಡ್ಯುಲೋ ಸ್ಪ್ಯಾನ್‌ಗಳು) ಪರಿವರ್ತಿಸಲ್ಪಡುತ್ತದೆ, ಬಹುಶಃ `ಟೋಕನ್‌ಟ್ರೀ: : X`X `Delimiter::None` ಡಿಲಿಮಿಟರ್‌ಗಳು ಮತ್ತು negative ಣಾತ್ಮಕ ಸಂಖ್ಯಾ ಅಕ್ಷರಗಳನ್ನು ಹೊಂದಿರುವ ಗುಂಪು ಹೊರತುಪಡಿಸಿ.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// ಡೀಬಗ್ ಮಾಡಲು ಅನುಕೂಲಕರ ರೂಪದಲ್ಲಿ token ಅನ್ನು ಮುದ್ರಿಸುತ್ತದೆ.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// ಒಂದೇ token ಮರವನ್ನು ಹೊಂದಿರುವ token ಸ್ಟ್ರೀಮ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// ಒಂದೇ ಸ್ಟ್ರೀಮ್‌ನಲ್ಲಿ ಹಲವಾರು token ಮರಗಳನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// token ಸ್ಟ್ರೀಮ್‌ಗಳಲ್ಲಿನ "flattening" ಕಾರ್ಯಾಚರಣೆ, ಅನೇಕ token ಸ್ಟ್ರೀಮ್‌ಗಳಿಂದ token ಮರಗಳನ್ನು ಒಂದೇ ಸ್ಟ್ರೀಮ್‌ಗೆ ಸಂಗ್ರಹಿಸುತ್ತದೆ.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) ಆಪ್ಟಿಮೈಸ್ಡ್ ಅನುಷ್ಠಾನ if/when ಅನ್ನು ಬಳಸಿ.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// ಇಟರೇಟರ್‌ಗಳಂತಹ `TokenStream` ಪ್ರಕಾರಕ್ಕಾಗಿ ಸಾರ್ವಜನಿಕ ಅನುಷ್ಠಾನದ ವಿವರಗಳು.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// `ಟೋಕನ್‌ಸ್ಟ್ರೀಮ್` ನ` ಟೋಕನ್‌ಟ್ರೀ'ಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ.
    /// ಪುನರಾವರ್ತನೆಯು "shallow" ಆಗಿದೆ, ಉದಾ., ಪುನರಾವರ್ತಕವು ವಿಂಗಡಿಸಲಾದ ಗುಂಪುಗಳಾಗಿ ಮರುಕಳಿಸುವುದಿಲ್ಲ ಮತ್ತು ಇಡೀ ಗುಂಪುಗಳನ್ನು token ಮರಗಳಾಗಿ ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` ಅನಿಯಂತ್ರಿತ tokens ಅನ್ನು ಸ್ವೀಕರಿಸುತ್ತದೆ ಮತ್ತು ಇನ್ಪುಟ್ ಅನ್ನು ವಿವರಿಸುವ `TokenStream` ಗೆ ವಿಸ್ತರಿಸುತ್ತದೆ.
/// ಉದಾಹರಣೆಗೆ, `quote!(a + b)` ಒಂದು ಅಭಿವ್ಯಕ್ತಿಯನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ, ಅದು ಮೌಲ್ಯಮಾಪನ ಮಾಡಿದಾಗ, `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// ಅನ್ಕೋಟಿಂಗ್ ಅನ್ನು `$` ನೊಂದಿಗೆ ಮಾಡಲಾಗುತ್ತದೆ, ಮತ್ತು ಮುಂದಿನ ಮುಂದಿನ ಗುರುತನ್ನು ಉಲ್ಲೇಖಿಸದ ಪದವಾಗಿ ತೆಗೆದುಕೊಳ್ಳುವ ಮೂಲಕ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ.
/// `$` ಅನ್ನು ಉಲ್ಲೇಖಿಸಲು, `$$` ಬಳಸಿ.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// ಮ್ಯಾಕ್ರೋ ವಿಸ್ತರಣೆ ಮಾಹಿತಿಯೊಂದಿಗೆ ಮೂಲ ಕೋಡ್‌ನ ಪ್ರದೇಶ.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// `self` ಸ್ಪ್ಯಾನ್‌ನಲ್ಲಿ ಕೊಟ್ಟಿರುವ `message` ನೊಂದಿಗೆ ಹೊಸ `Diagnostic` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// ಮ್ಯಾಕ್ರೋ ಡೆಫಿನಿಷನ್ ಸೈಟ್‌ನಲ್ಲಿ ಪರಿಹರಿಸುವ ಒಂದು ಸ್ಪ್ಯಾನ್.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// ಪ್ರಸ್ತುತ ಕಾರ್ಯವಿಧಾನದ ಸ್ಥೂಲ ಆವಾಹನೆಯ ಅವಧಿ.
    /// ಈ ಸ್ಪ್ಯಾನ್‌ನೊಂದಿಗೆ ರಚಿಸಲಾದ ಐಡೆಂಟಿಫೈಯರ್‌ಗಳನ್ನು ಮ್ಯಾಕ್ರೋ ಕಾಲ್ ಲೊಕೇಶನ್‌ನಲ್ಲಿ (ಕಾಲ್-ಸೈಟ್ ನೈರ್ಮಲ್ಯ) ನೇರವಾಗಿ ಬರೆಯಲಾಗಿದೆಯೆಂದು ಪರಿಹರಿಸಲಾಗುವುದು ಮತ್ತು ಮ್ಯಾಕ್ರೋ ಕಾಲ್ ಸೈಟ್‌ನಲ್ಲಿರುವ ಇತರ ಕೋಡ್‌ಗಳನ್ನು ಸಹ ಅವುಗಳನ್ನು ಉಲ್ಲೇಖಿಸಲು ಸಾಧ್ಯವಾಗುತ್ತದೆ.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// `macro_rules` ನೈರ್ಮಲ್ಯವನ್ನು ಪ್ರತಿನಿಧಿಸುವ ಒಂದು ಸ್ಪ್ಯಾನ್, ಮತ್ತು ಕೆಲವೊಮ್ಮೆ ಮ್ಯಾಕ್ರೋ ಡೆಫಿನಿಷನ್ ಸೈಟ್‌ನಲ್ಲಿ (ಸ್ಥಳೀಯ ಅಸ್ಥಿರಗಳು, ಲೇಬಲ್‌ಗಳು, `$crate`) ಮತ್ತು ಕೆಲವೊಮ್ಮೆ ಮ್ಯಾಕ್ರೋ ಕಾಲ್ ಸೈಟ್‌ನಲ್ಲಿ (ಉಳಿದಂತೆ) ಪರಿಹರಿಸುತ್ತದೆ.
    ///
    /// ಸ್ಪ್ಯಾನ್ ಸ್ಥಳವನ್ನು ಕರೆ-ಸೈಟ್‌ನಿಂದ ತೆಗೆದುಕೊಳ್ಳಲಾಗಿದೆ.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// ಈ ಸ್ಪ್ಯಾನ್ ಸೂಚಿಸುವ ಮೂಲ ಮೂಲ ಫೈಲ್.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// ಹಿಂದಿನ ಮ್ಯಾಕ್ರೋ ವಿಸ್ತರಣೆಯಲ್ಲಿ tokens ಗಾಗಿ `Span`, ಯಾವುದಾದರೂ ಇದ್ದರೆ `self` ಅನ್ನು ಉತ್ಪಾದಿಸಲಾಗಿದೆ.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// `self` ನಿಂದ ಉತ್ಪತ್ತಿಯಾದ ಮೂಲ ಮೂಲ ಕೋಡ್‌ನ ಅವಧಿ.
    /// ಈ `Span` ಅನ್ನು ಇತರ ಮ್ಯಾಕ್ರೋ ವಿಸ್ತರಣೆಗಳಿಂದ ಉತ್ಪಾದಿಸದಿದ್ದರೆ, ರಿಟರ್ನ್ ಮೌಲ್ಯವು `*self` ನಂತೆಯೇ ಇರುತ್ತದೆ.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// ಈ ಸ್ಪ್ಯಾನ್‌ಗಾಗಿ ಮೂಲ ಫೈಲ್‌ನಲ್ಲಿ ಆರಂಭಿಕ line/column ಅನ್ನು ಪಡೆಯುತ್ತದೆ.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// ಈ ಸ್ಪ್ಯಾನ್‌ಗಾಗಿ ಮೂಲ ಫೈಲ್‌ನಲ್ಲಿ ಅಂತ್ಯಗೊಳ್ಳುವ line/column ಅನ್ನು ಪಡೆಯುತ್ತದೆ.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// `self` ಮತ್ತು `other` ಅನ್ನು ಒಳಗೊಂಡ ಹೊಸ ಸ್ಪ್ಯಾನ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// `self` ಮತ್ತು `other` ವಿಭಿನ್ನ ಫೈಲ್‌ಗಳಿಂದ ಬಂದಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// `self` ನಂತೆಯೇ ಅದೇ line/column ಮಾಹಿತಿಯೊಂದಿಗೆ ಹೊಸ ಸ್ಪ್ಯಾನ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ ಆದರೆ ಅದು `other` ನಲ್ಲಿದ್ದಂತೆ ಚಿಹ್ನೆಗಳನ್ನು ಪರಿಹರಿಸುತ್ತದೆ.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// `self` ನಂತೆಯೇ ಅದೇ ಹೆಸರಿನ ರೆಸಲ್ಯೂಶನ್ ನಡವಳಿಕೆಯೊಂದಿಗೆ ಆದರೆ `other` ನ line/column ಮಾಹಿತಿಯೊಂದಿಗೆ ಹೊಸ ಸ್ಪ್ಯಾನ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// ಅವುಗಳು ಸಮಾನವಾಗಿದೆಯೇ ಎಂದು ನೋಡಲು ಸ್ಪ್ಯಾನ್‌ಗಳಿಗೆ ಹೋಲಿಸುತ್ತದೆ.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// ಸ್ಪ್ಯಾನ್‌ನ ಹಿಂದೆ ಮೂಲ ಪಠ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಇದು ಸ್ಥಳಗಳು ಮತ್ತು ಕಾಮೆಂಟ್‌ಗಳನ್ನು ಒಳಗೊಂಡಂತೆ ಮೂಲ ಮೂಲ ಕೋಡ್ ಅನ್ನು ಸಂರಕ್ಷಿಸುತ್ತದೆ.
    /// ಸ್ಪ್ಯಾನ್ ನಿಜವಾದ ಮೂಲ ಕೋಡ್‌ಗೆ ಅನುಗುಣವಾಗಿದ್ದರೆ ಮಾತ್ರ ಅದು ಫಲಿತಾಂಶವನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// Note: ಮ್ಯಾಕ್ರೊದ ಗಮನಿಸಬಹುದಾದ ಫಲಿತಾಂಶವು tokens ಅನ್ನು ಮಾತ್ರ ಅವಲಂಬಿಸಿರಬೇಕು ಮತ್ತು ಈ ಮೂಲ ಪಠ್ಯವನ್ನು ಅವಲಂಬಿಸಿಲ್ಲ.
    ///
    /// ಈ ಕಾರ್ಯದ ಫಲಿತಾಂಶವು ರೋಗನಿರ್ಣಯಕ್ಕೆ ಮಾತ್ರ ಬಳಸಬೇಕಾದ ಅತ್ಯುತ್ತಮ ಪ್ರಯತ್ನವಾಗಿದೆ.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// ಡೀಬಗ್ ಮಾಡಲು ಅನುಕೂಲಕರ ರೂಪದಲ್ಲಿ ಸ್ಪ್ಯಾನ್ ಅನ್ನು ಮುದ್ರಿಸುತ್ತದೆ.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// `Span` ನ ಪ್ರಾರಂಭ ಅಥವಾ ಅಂತ್ಯವನ್ನು ಪ್ರತಿನಿಧಿಸುವ ಸಾಲು-ಕಾಲಮ್ ಜೋಡಿ.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// ಸ್ಪ್ಯಾನ್ (inclusive) ಪ್ರಾರಂಭವಾಗುವ ಅಥವಾ ಕೊನೆಗೊಳ್ಳುವ ಮೂಲ ಫೈಲ್‌ನಲ್ಲಿ 1-ಸೂಚ್ಯಂಕದ ಸಾಲು.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// ಸ್ಪ್ಯಾನ್ (inclusive) ಪ್ರಾರಂಭವಾಗುವ ಅಥವಾ ಕೊನೆಗೊಳ್ಳುವ ಮೂಲ ಫೈಲ್‌ನಲ್ಲಿ 0-ಸೂಚ್ಯಂಕ ಕಾಲಮ್ (UTF-8 ಅಕ್ಷರಗಳಲ್ಲಿ).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// ನಿರ್ದಿಷ್ಟ `Span` ನ ಮೂಲ ಫೈಲ್.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// ಈ ಮೂಲ ಫೈಲ್‌ಗೆ ಮಾರ್ಗವನ್ನು ಪಡೆಯುತ್ತದೆ.
    ///
    /// ### Note
    /// ಈ `SourceFile` ಗೆ ಸಂಬಂಧಿಸಿದ ಕೋಡ್ ಸ್ಪ್ಯಾನ್ ಅನ್ನು ಬಾಹ್ಯ ಮ್ಯಾಕ್ರೋ, ಈ ಮ್ಯಾಕ್ರೊದಿಂದ ರಚಿಸಿದ್ದರೆ, ಇದು ಫೈಲ್‌ಸಿಸ್ಟಂನಲ್ಲಿ ನಿಜವಾದ ಮಾರ್ಗವಾಗಿರಬಾರದು.
    /// ಪರಿಶೀಲಿಸಲು [`is_real`] ಬಳಸಿ.
    ///
    /// `is_real` `true` ಅನ್ನು ಹಿಂದಿರುಗಿಸಿದರೂ ಸಹ, `--remap-path-prefix` ಆಜ್ಞಾ ಸಾಲಿನಲ್ಲಿ ಹಾದುಹೋದರೆ, ಕೊಟ್ಟಿರುವ ಮಾರ್ಗವು ನಿಜವಾಗಿ ಮಾನ್ಯವಾಗಿಲ್ಲದಿರಬಹುದು.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// ಈ ಮೂಲ ಫೈಲ್ ನಿಜವಾದ ಮೂಲ ಫೈಲ್ ಆಗಿದ್ದರೆ ಮತ್ತು ಬಾಹ್ಯ ಮ್ಯಾಕ್ರೋ ವಿಸ್ತರಣೆಯಿಂದ ಉತ್ಪತ್ತಿಯಾಗದಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // ಇಂಟರ್ಕ್ರೇಟ್ ವ್ಯಾಪ್ತಿಗಳನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವವರೆಗೆ ಇದು ಹ್ಯಾಕ್ ಆಗಿದೆ ಮತ್ತು ಬಾಹ್ಯ ಮ್ಯಾಕ್ರೋಗಳಲ್ಲಿ ಉತ್ಪತ್ತಿಯಾಗುವ ಸ್ಪ್ಯಾನ್‌ಗಳಿಗಾಗಿ ನಾವು ನಿಜವಾದ ಮೂಲ ಫೈಲ್‌ಗಳನ್ನು ಹೊಂದಬಹುದು.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// ಒಂದೇ token ಅಥವಾ token ಮರಗಳ ವಿಂಗಡಿಸಲಾದ ಅನುಕ್ರಮ (ಉದಾ., `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// ಬ್ರಾಕೆಟ್ ಡಿಲಿಮಿಟರ್ಗಳಿಂದ ಆವೃತವಾದ token ಸ್ಟ್ರೀಮ್.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// ಗುರುತಿಸುವಿಕೆ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// ಒಂದೇ ವಿರಾಮ ಚಿಹ್ನೆ (`+`, `,`, `$`, ಇತ್ಯಾದಿ).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// ಅಕ್ಷರಶಃ ಅಕ್ಷರ (`'a'`), ಸ್ಟ್ರಿಂಗ್ (`"hello"`), ಸಂಖ್ಯೆ (`2.3`), ಇತ್ಯಾದಿ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// ಈ ಮರದ ವ್ಯಾಪ್ತಿಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಒಳಗೊಂಡಿರುವ token ನ `span` ವಿಧಾನಕ್ಕೆ ಅಥವಾ ಬೇರ್ಪಡಿಸಿದ ಸ್ಟ್ರೀಮ್‌ಗೆ ನಿಯೋಜಿಸುತ್ತದೆ.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// *ಈ token* ಗಾಗಿ ಮಾತ್ರ ಸ್ಪ್ಯಾನ್ ಅನ್ನು ಕಾನ್ಫಿಗರ್ ಮಾಡುತ್ತದೆ.
    ///
    /// ಈ token ಒಂದು `Group` ಆಗಿದ್ದರೆ ಈ ವಿಧಾನವು ಪ್ರತಿಯೊಂದು ಆಂತರಿಕ tokens ನ ವ್ಯಾಪ್ತಿಯನ್ನು ಕಾನ್ಫಿಗರ್ ಮಾಡುವುದಿಲ್ಲ, ಇದು ಪ್ರತಿ ರೂಪಾಂತರದ `set_span` ವಿಧಾನಕ್ಕೆ ಸರಳವಾಗಿ ನಿಯೋಜಿಸುತ್ತದೆ.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// ಡೀಬಗ್ ಮಾಡಲು ಅನುಕೂಲಕರ ರೂಪದಲ್ಲಿ token ಮರವನ್ನು ಮುದ್ರಿಸುತ್ತದೆ.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // ಇವುಗಳಲ್ಲಿ ಪ್ರತಿಯೊಂದೂ ವ್ಯುತ್ಪನ್ನ ಡೀಬಗ್‌ನಲ್ಲಿನ ಸ್ಟ್ರಕ್ಟ್ ಪ್ರಕಾರದಲ್ಲಿ ಹೆಸರನ್ನು ಹೊಂದಿದೆ, ಆದ್ದರಿಂದ ಹೆಚ್ಚುವರಿ ಪದರದ ಇಂಡೈರೆಕ್ಷನ್‌ನೊಂದಿಗೆ ತಲೆಕೆಡಿಸಿಕೊಳ್ಳಬೇಡಿ
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, ಸೇತುವೆ `to_string` ಅನ್ನು ಮಾತ್ರ ಒದಗಿಸುತ್ತದೆ, ಅದರ ಆಧಾರದ ಮೇಲೆ `fmt::Display` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿ (ಇವೆರಡರ ನಡುವಿನ ಸಾಮಾನ್ಯ ಸಂಬಂಧದ ಹಿಮ್ಮುಖ).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// X0token0Z ಮರವನ್ನು ಸ್ಟ್ರಿಂಗ್‌ನಂತೆ ಮುದ್ರಿಸುತ್ತದೆ, ಅದು ನಷ್ಟವಿಲ್ಲದೆ ಪರಿವರ್ತಿಸಬಹುದಾದ ಅದೇ token ಮರಕ್ಕೆ (ಮಾಡ್ಯುಲೋ ಸ್ಪ್ಯಾನ್‌ಗಳು), ಬಹುಶಃ `ಟೋಕನ್‌ಟ್ರೀ: : X`X `Delimiter::None` ಡಿಲಿಮಿಟರ್‌ಗಳು ಮತ್ತು negative ಣಾತ್ಮಕ ಸಂಖ್ಯಾ ಅಕ್ಷರಗಳನ್ನು ಹೊರತುಪಡಿಸಿ.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// ವಿಂಗಡಿಸಲಾದ token ಸ್ಟ್ರೀಮ್.
///
/// `Group` ಆಂತರಿಕವಾಗಿ `TokenStream` ಅನ್ನು ಹೊಂದಿದೆ, ಅದು `ಡಿಲಿಮಿಟರ್'ಗಳಿಂದ ಆವೃತವಾಗಿದೆ.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// token ಮರಗಳ ಅನುಕ್ರಮವನ್ನು ಹೇಗೆ ವಿಂಗಡಿಸಲಾಗಿದೆ ಎಂಬುದನ್ನು ವಿವರಿಸುತ್ತದೆ.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// ಒಂದು ಸೂಚ್ಯ ಡಿಲಿಮಿಟರ್, ಉದಾಹರಣೆಗೆ, "macro variable" `$var` ನಿಂದ ಬರುವ tokens ಸುತ್ತಲೂ ಕಾಣಿಸಿಕೊಳ್ಳಬಹುದು.
    /// `$var * 3` ನಂತಹ ಸಂದರ್ಭಗಳಲ್ಲಿ ಆಪರೇಟರ್ ಆದ್ಯತೆಗಳನ್ನು ಸಂರಕ್ಷಿಸುವುದು ಮುಖ್ಯ, ಅಲ್ಲಿ `$var` `1 + 2` ಆಗಿದೆ.
    /// ಸೂಚ್ಯ ಡಿಲಿಮಿಟರ್‌ಗಳು ಸ್ಟ್ರಿಂಗ್ ಮೂಲಕ token ಸ್ಟ್ರೀಮ್‌ನ ರೌಂಡ್‌ಟ್ರಿಪ್‌ನಿಂದ ಬದುಕುಳಿಯುವುದಿಲ್ಲ.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// ಕೊಟ್ಟಿರುವ ಡಿಲಿಮಿಟರ್ ಮತ್ತು token ಸ್ಟ್ರೀಮ್‌ನೊಂದಿಗೆ ಹೊಸ `Group` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// ಈ ಕನ್‌ಸ್ಟ್ರಕ್ಟರ್ ಈ ಗುಂಪಿನ ಅವಧಿಯನ್ನು `Span::call_site()` ಗೆ ಹೊಂದಿಸುತ್ತದೆ.
    /// ವ್ಯಾಪ್ತಿಯನ್ನು ಬದಲಾಯಿಸಲು ನೀವು ಕೆಳಗಿನ `set_span` ವಿಧಾನವನ್ನು ಬಳಸಬಹುದು.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// ಈ `Group` ನ ಡಿಲಿಮಿಟರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// ಈ `Group` ನಲ್ಲಿ ವಿಂಗಡಿಸಲಾದ tokens ನ `TokenStream` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಹಿಂತಿರುಗಿದ token ಸ್ಟ್ರೀಮ್ ಮೇಲೆ ಹಿಂತಿರುಗಿದ ಡಿಲಿಮಿಟರ್ ಅನ್ನು ಒಳಗೊಂಡಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// ಈ token ಸ್ಟ್ರೀಮ್‌ನ ಡಿಲಿಮಿಟರ್‌ಗಳಿಗಾಗಿ ಸ್ಪ್ಯಾನ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಇದು ಸಂಪೂರ್ಣ `Group` ಅನ್ನು ವ್ಯಾಪಿಸಿದೆ.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ಈ ಗುಂಪಿನ ಆರಂಭಿಕ ಡಿಲಿಮಿಟರ್‌ಗೆ ಸೂಚಿಸುವ ಸ್ಪ್ಯಾನ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// ಈ ಗುಂಪಿನ ಮುಕ್ತಾಯದ ಡಿಲಿಮಿಟರ್‌ಗೆ ಸೂಚಿಸುವ ಸ್ಪ್ಯಾನ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// ಈ `ಗ್ರೂಪ್'ನ ಡಿಲಿಮಿಟರ್ಗಳಿಗಾಗಿ ಸ್ಪ್ಯಾನ್ ಅನ್ನು ಕಾನ್ಫಿಗರ್ ಮಾಡುತ್ತದೆ, ಆದರೆ ಅದರ ಆಂತರಿಕ tokens ಅಲ್ಲ.
    ///
    /// ಈ ವಿಧಾನವು ಈ ಗುಂಪಿನಿಂದ ವ್ಯಾಪಿಸಿರುವ ಎಲ್ಲಾ ಆಂತರಿಕ tokens ನ ವ್ಯಾಪ್ತಿಯನ್ನು ** ಹೊಂದಿಸುವುದಿಲ್ಲ, ಆದರೆ ಇದು `Group` ಮಟ್ಟದಲ್ಲಿ ಡಿಲಿಮಿಟರ್ tokens ನ ವ್ಯಾಪ್ತಿಯನ್ನು ಮಾತ್ರ ಹೊಂದಿಸುತ್ತದೆ.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, ಸೇತುವೆ `to_string` ಅನ್ನು ಮಾತ್ರ ಒದಗಿಸುತ್ತದೆ, ಅದರ ಆಧಾರದ ಮೇಲೆ `fmt::Display` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿ (ಇವೆರಡರ ನಡುವಿನ ಸಾಮಾನ್ಯ ಸಂಬಂಧದ ಹಿಮ್ಮುಖ).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// `Delimiter::None` ಡಿಲಿಮಿಟರ್‌ಗಳೊಂದಿಗಿನ `ಟೋಕನ್‌ಟ್ರೀ: : ಗ್ರೂಪ್`ಗಳನ್ನು ಹೊರತುಪಡಿಸಿ, ಗುಂಪನ್ನು ಅದೇ ಗುಂಪಿಗೆ (ಮಾಡ್ಯುಲೋ ಸ್ಪ್ಯಾನ್‌ಗಳು) ನಷ್ಟವಿಲ್ಲದೆ ಪರಿವರ್ತಿಸಬಹುದಾದ ಸ್ಟ್ರಿಂಗ್‌ನಂತೆ ಮುದ್ರಿಸುತ್ತದೆ.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` ಎಂಬುದು `+`, `-` ಅಥವಾ `#` ನಂತಹ ಒಂದೇ ವಿರಾಮ ಚಿಹ್ನೆಯಾಗಿದೆ.
///
/// `+=` ನಂತಹ ಮಲ್ಟಿ-ಕ್ಯಾರೆಕ್ಟರ್ ಆಪರೇಟರ್‌ಗಳನ್ನು `Punct` ನ ಎರಡು ನಿದರ್ಶನಗಳಾಗಿ ಪ್ರತಿನಿಧಿಸಲಾಗುತ್ತದೆ.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// `Punct` ಅನ್ನು ತಕ್ಷಣವೇ ಮತ್ತೊಂದು `Punct` ಅನುಸರಿಸುತ್ತದೆಯೇ ಅಥವಾ ಇನ್ನೊಂದು token ಅಥವಾ ಜಾಗಗಳನ್ನು ಅನುಸರಿಸುತ್ತದೆಯೇ.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// ಉದಾ, `+` ಎಂಬುದು `+ =`, `+ident` ಅಥವಾ `+()` ನಲ್ಲಿ `Alone` ಆಗಿದೆ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// ಉದಾ, `+` ಎಂಬುದು `+=` ಅಥವಾ `'#` ನಲ್ಲಿ `Joint` ಆಗಿದೆ.
    /// ಹೆಚ್ಚುವರಿಯಾಗಿ, ಜೀವಿತಾವಧಿ `'ident` ಅನ್ನು ರೂಪಿಸಲು ಏಕ ಉಲ್ಲೇಖ `'` ಗುರುತಿಸುವಿಕೆಗಳೊಂದಿಗೆ ಸೇರಬಹುದು.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// ಕೊಟ್ಟಿರುವ ಅಕ್ಷರ ಮತ್ತು ಅಂತರದಿಂದ ಹೊಸ `Punct` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    /// `ch` ಆರ್ಗ್ಯುಮೆಂಟ್ ಭಾಷೆಯಿಂದ ಅನುಮತಿಸಲಾದ ಮಾನ್ಯ ವಿರಾಮ ಚಿಹ್ನೆಯಾಗಿರಬೇಕು, ಇಲ್ಲದಿದ್ದರೆ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
    ///
    /// ಹಿಂತಿರುಗಿದ `Punct` `Span::call_site()` ನ ಡೀಫಾಲ್ಟ್ ಸ್ಪ್ಯಾನ್ ಅನ್ನು ಹೊಂದಿರುತ್ತದೆ, ಅದನ್ನು ಕೆಳಗಿನ `set_span` ವಿಧಾನದೊಂದಿಗೆ ಮತ್ತಷ್ಟು ಕಾನ್ಫಿಗರ್ ಮಾಡಬಹುದು.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// ಈ ವಿರಾಮ ಚಿಹ್ನೆಯ ಮೌಲ್ಯವನ್ನು `char` ಎಂದು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// ಈ ವಿರಾಮಚಿಹ್ನೆಯ ಅಕ್ಷರಗಳ ಅಂತರವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಇದು ತಕ್ಷಣವೇ token ಸ್ಟ್ರೀಮ್‌ನಲ್ಲಿ ಮತ್ತೊಂದು `Punct` ಅನ್ನು ಅನುಸರಿಸುತ್ತದೆಯೇ ಎಂದು ಸೂಚಿಸುತ್ತದೆ, ಆದ್ದರಿಂದ ಅವುಗಳನ್ನು ಬಹು-ಅಕ್ಷರ ಆಪರೇಟರ್ (`Joint`) ಗೆ ಸಂಭಾವ್ಯವಾಗಿ ಸಂಯೋಜಿಸಬಹುದು, ಅಥವಾ ಅದನ್ನು ಇತರ token ಅಥವಾ ವೈಟ್‌ಸ್ಪೇಸ್ (`Alone`) ಅನುಸರಿಸುತ್ತದೆ ಆದ್ದರಿಂದ ಆಪರೇಟರ್ ಖಂಡಿತವಾಗಿಯೂ ಹೊಂದಿದೆ ಕೊನೆಗೊಂಡಿತು.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// ಈ ವಿರಾಮಚಿಹ್ನೆಯ ಅಕ್ಷರಕ್ಕಾಗಿ ಸ್ಪ್ಯಾನ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ಈ ವಿರಾಮಚಿಹ್ನೆಯ ಅಕ್ಷರಕ್ಕಾಗಿ ಸ್ಪ್ಯಾನ್ ಅನ್ನು ಕಾನ್ಫಿಗರ್ ಮಾಡಿ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, ಸೇತುವೆ `to_string` ಅನ್ನು ಮಾತ್ರ ಒದಗಿಸುತ್ತದೆ, ಅದರ ಆಧಾರದ ಮೇಲೆ `fmt::Display` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿ (ಇವೆರಡರ ನಡುವಿನ ಸಾಮಾನ್ಯ ಸಂಬಂಧದ ಹಿಮ್ಮುಖ).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// ವಿರಾಮಚಿಹ್ನೆಯ ಅಕ್ಷರವನ್ನು ಸ್ಟ್ರಿಂಗ್‌ನಂತೆ ಮುದ್ರಿಸುತ್ತದೆ, ಅದು ನಷ್ಟವಿಲ್ಲದೆ ಮತ್ತೆ ಅದೇ ಅಕ್ಷರಕ್ಕೆ ಪರಿವರ್ತಿಸಲ್ಪಡುತ್ತದೆ.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// ಗುರುತಿಸುವಿಕೆ (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// ಕೊಟ್ಟಿರುವ `string` ಮತ್ತು ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ `span` ನೊಂದಿಗೆ ಹೊಸ `Ident` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    /// `string` ಆರ್ಗ್ಯುಮೆಂಟ್ ಭಾಷೆಯಿಂದ ಅನುಮತಿಸಲಾದ ಮಾನ್ಯ ಗುರುತಿಸುವಿಕೆಯಾಗಿರಬೇಕು (ಕೀವರ್ಡ್ಗಳು ಸೇರಿದಂತೆ, ಉದಾ. `self` ಅಥವಾ `fn`).ಇಲ್ಲದಿದ್ದರೆ, ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
    ///
    /// ಪ್ರಸ್ತುತ rustc ನಲ್ಲಿರುವ `span`, ಈ ಗುರುತಿಸುವಿಕೆಗಾಗಿ ನೈರ್ಮಲ್ಯ ಮಾಹಿತಿಯನ್ನು ಕಾನ್ಫಿಗರ್ ಮಾಡುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    /// ಈ ಸಮಯದ ಪ್ರಕಾರ, `Span::call_site()` ಸ್ಪಷ್ಟವಾಗಿ "call-site" ನೈರ್ಮಲ್ಯವನ್ನು ಆರಿಸಿಕೊಳ್ಳುತ್ತದೆ ಅಂದರೆ ಈ ಸ್ಪ್ಯಾನ್‌ನೊಂದಿಗೆ ರಚಿಸಲಾದ ಗುರುತಿಸುವಿಕೆಗಳನ್ನು ಮ್ಯಾಕ್ರೋ ಕರೆಯ ಸ್ಥಳದಲ್ಲಿ ನೇರವಾಗಿ ಬರೆಯಲಾಗಿದೆಯೆಂದು ಪರಿಹರಿಸಲಾಗುವುದು, ಮತ್ತು ಮ್ಯಾಕ್ರೋ ಕಾಲ್ ಸೈಟ್‌ನಲ್ಲಿನ ಇತರ ಕೋಡ್ ಅನ್ನು ಉಲ್ಲೇಖಿಸಲು ಸಾಧ್ಯವಾಗುತ್ತದೆ ಅವುಗಳು ಸಹ.
    ///
    ///
    /// `Span::def_site()` ನಂತಹ ನಂತರದ ವ್ಯಾಪ್ತಿಗಳು "definition-site" ನೈರ್ಮಲ್ಯವನ್ನು ಆಯ್ಕೆ ಮಾಡಲು ಅನುಮತಿಸುತ್ತದೆ ಅಂದರೆ ಈ ಸ್ಪ್ಯಾನ್‌ನೊಂದಿಗೆ ರಚಿಸಲಾದ ಗುರುತಿಸುವಿಕೆಗಳು ಮ್ಯಾಕ್ರೋ ವ್ಯಾಖ್ಯಾನದ ಸ್ಥಳದಲ್ಲಿ ಪರಿಹರಿಸಲ್ಪಡುತ್ತವೆ ಮತ್ತು ಮ್ಯಾಕ್ರೋ ಕಾಲ್ ಸೈಟ್‌ನಲ್ಲಿನ ಇತರ ಕೋಡ್‌ಗಳು ಅವುಗಳನ್ನು ಉಲ್ಲೇಖಿಸಲು ಸಾಧ್ಯವಾಗುವುದಿಲ್ಲ.
    ///
    /// ನೈರ್ಮಲ್ಯದ ಪ್ರಸ್ತುತ ಪ್ರಾಮುಖ್ಯತೆಯಿಂದಾಗಿ, ಈ ಕನ್‌ಸ್ಟ್ರಕ್ಟರ್, ಇತರ tokens ಗಿಂತ ಭಿನ್ನವಾಗಿ, ನಿರ್ಮಾಣದಲ್ಲಿ `Span` ಅನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸುವ ಅಗತ್ಯವಿದೆ.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// `Ident::new` ನಂತೆಯೇ, ಆದರೆ ಕಚ್ಚಾ ಗುರುತಿಸುವಿಕೆ (`r#ident`) ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    /// `string` ಆರ್ಗ್ಯುಮೆಂಟ್ ಭಾಷೆಯಿಂದ ಅನುಮತಿಸಲಾದ ಮಾನ್ಯ ಗುರುತಿಸುವಿಕೆಯಾಗಿರುತ್ತದೆ (ಕೀವರ್ಡ್ಗಳು ಸೇರಿದಂತೆ, ಉದಾ. `fn`).
    /// ಮಾರ್ಗ ವಿಭಾಗಗಳಲ್ಲಿ ಬಳಸಬಹುದಾದ ಕೀವರ್ಡ್ಗಳು (ಉದಾ
    /// `self`, `ಸೂಪರ್`) ಬೆಂಬಲಿಸುವುದಿಲ್ಲ, ಮತ್ತು ಇದು panic ಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// ಈ `Ident` ನ ವ್ಯಾಪ್ತಿಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, [`to_string`](Self::to_string) ನಿಂದ ಹಿಂತಿರುಗಿಸಲಾದ ಸಂಪೂರ್ಣ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಒಳಗೊಂಡಿದೆ.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ಈ `Ident` ನ ವ್ಯಾಪ್ತಿಯನ್ನು ಕಾನ್ಫಿಗರ್ ಮಾಡುತ್ತದೆ, ಬಹುಶಃ ಅದರ ನೈರ್ಮಲ್ಯ ಸಂದರ್ಭವನ್ನು ಬದಲಾಯಿಸುತ್ತದೆ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, ಸೇತುವೆ `to_string` ಅನ್ನು ಮಾತ್ರ ಒದಗಿಸುತ್ತದೆ, ಅದರ ಆಧಾರದ ಮೇಲೆ `fmt::Display` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿ (ಇವೆರಡರ ನಡುವಿನ ಸಾಮಾನ್ಯ ಸಂಬಂಧದ ಹಿಮ್ಮುಖ).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// ಗುರುತಿಸುವಿಕೆಯನ್ನು ಸ್ಟ್ರಿಂಗ್‌ನಂತೆ ಮುದ್ರಿಸುತ್ತದೆ, ಅದು ನಷ್ಟವಿಲ್ಲದೆ ಮತ್ತೆ ಅದೇ ಗುರುತಿಸುವಿಕೆಗೆ ಪರಿವರ್ತಿಸಲ್ಪಡುತ್ತದೆ.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// ಅಕ್ಷರಶಃ ಸ್ಟ್ರಿಂಗ್ (`"hello"`), ಬೈಟ್ ಸ್ಟ್ರಿಂಗ್ (`b"hello"`), ಅಕ್ಷರ (`'a'`), ಬೈಟ್ ಅಕ್ಷರ (`b'a'`), ಪ್ರತ್ಯಯದೊಂದಿಗೆ ಅಥವಾ ಇಲ್ಲದೆ ಒಂದು ಪೂರ್ಣಾಂಕ ಅಥವಾ ತೇಲುವ ಪಾಯಿಂಟ್ ಸಂಖ್ಯೆ (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// `true` ಮತ್ತು `false` ನಂತಹ ಬೂಲಿಯನ್ ಅಕ್ಷರಗಳು ಇಲ್ಲಿ ಸೇರಿಲ್ಲ, ಅವು `ಐಡೆಂಟ್` ಗಳು.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಮೌಲ್ಯದೊಂದಿಗೆ ಹೊಸ ಪ್ರತ್ಯಯ ಪೂರ್ಣಾಂಕ ಅಕ್ಷರಶಃ ರಚಿಸುತ್ತದೆ.
        ///
        /// ಈ ಕಾರ್ಯವು `1u32` ನಂತಹ ಪೂರ್ಣಾಂಕವನ್ನು ರಚಿಸುತ್ತದೆ, ಅಲ್ಲಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಪೂರ್ಣಾಂಕ ಮೌಲ್ಯವು token ನ ಮೊದಲ ಭಾಗವಾಗಿದೆ ಮತ್ತು ಅವಿಭಾಜ್ಯವು ಕೊನೆಯಲ್ಲಿ ಪ್ರತ್ಯಯವಾಗಿರುತ್ತದೆ.
        /// Negative ಣಾತ್ಮಕ ಸಂಖ್ಯೆಗಳಿಂದ ರಚಿಸಲಾದ ಅಕ್ಷರಗಳು `TokenStream` ಅಥವಾ ತಂತಿಗಳ ಮೂಲಕ ರೌಂಡ್-ಟ್ರಿಪ್‌ಗಳನ್ನು ಉಳಿದುಕೊಂಡಿಲ್ಲ ಮತ್ತು ಅವುಗಳನ್ನು ಎರಡು tokens (`-` ಮತ್ತು ಧನಾತ್ಮಕ ಅಕ್ಷರಶಃ)ಗಳಾಗಿ ವಿಂಗಡಿಸಬಹುದು.
        ///
        ///
        /// ಈ ವಿಧಾನದ ಮೂಲಕ ರಚಿಸಲಾದ ಲಿಟರಲ್‌ಗಳು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ `Span::call_site()` ಸ್ಪ್ಯಾನ್ ಅನ್ನು ಹೊಂದಿರುತ್ತವೆ, ಇದನ್ನು ಕೆಳಗಿನ `set_span` ವಿಧಾನದೊಂದಿಗೆ ಕಾನ್ಫಿಗರ್ ಮಾಡಬಹುದು.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಮೌಲ್ಯದೊಂದಿಗೆ ಹೊಸ ಸಂಯೋಜಿಸದ ಪೂರ್ಣಾಂಕ ಅಕ್ಷರಶಃ ರಚಿಸುತ್ತದೆ.
        ///
        /// ಈ ಕಾರ್ಯವು `1` ನಂತಹ ಪೂರ್ಣಾಂಕವನ್ನು ರಚಿಸುತ್ತದೆ, ಅಲ್ಲಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಪೂರ್ಣಾಂಕ ಮೌಲ್ಯವು token ನ ಮೊದಲ ಭಾಗವಾಗಿದೆ.
        /// ಈ token ನಲ್ಲಿ ಯಾವುದೇ ಪ್ರತ್ಯಯವನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿಲ್ಲ, ಅಂದರೆ `Literal::i8_unsuffixed(1)` ನಂತಹ ಆಹ್ವಾನಗಳು `Literal::u32_unsuffixed(1)` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ.
        /// Negative ಣಾತ್ಮಕ ಸಂಖ್ಯೆಗಳಿಂದ ರಚಿಸಲಾದ ಅಕ್ಷರಗಳು `TokenStream` ಅಥವಾ ತಂತಿಗಳ ಮೂಲಕ ರೌಂಟ್ರಿಪ್‌ಗಳನ್ನು ಉಳಿಸುವುದಿಲ್ಲ ಮತ್ತು ಅವುಗಳನ್ನು ಎರಡು tokens (`-` ಮತ್ತು ಧನಾತ್ಮಕ ಅಕ್ಷರಶಃ)ಗಳಾಗಿ ವಿಂಗಡಿಸಬಹುದು.
        ///
        ///
        /// ಈ ವಿಧಾನದ ಮೂಲಕ ರಚಿಸಲಾದ ಲಿಟರಲ್‌ಗಳು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ `Span::call_site()` ಸ್ಪ್ಯಾನ್ ಅನ್ನು ಹೊಂದಿರುತ್ತವೆ, ಇದನ್ನು ಕೆಳಗಿನ `set_span` ವಿಧಾನದೊಂದಿಗೆ ಕಾನ್ಫಿಗರ್ ಮಾಡಬಹುದು.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// ಹೊಸ ಅನ್‌ಫಿಕ್ಸ್ಡ್ ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಅಕ್ಷರಶಃ ರಚಿಸುತ್ತದೆ.
    ///
    /// ಈ ಕನ್‌ಸ್ಟ್ರಕ್ಟರ್ `Literal::i8_unsuffixed` ನಂತಹವುಗಳಿಗೆ ಹೋಲುತ್ತದೆ, ಅಲ್ಲಿ ಫ್ಲೋಟ್‌ನ ಮೌಲ್ಯವನ್ನು ನೇರವಾಗಿ token ಗೆ ಹೊರಸೂಸಲಾಗುತ್ತದೆ ಆದರೆ ಯಾವುದೇ ಪ್ರತ್ಯಯವನ್ನು ಬಳಸಲಾಗುವುದಿಲ್ಲ, ಆದ್ದರಿಂದ ಇದನ್ನು ಕಂಪೈಲರ್‌ನಲ್ಲಿ `f64` ಎಂದು er ಹಿಸಬಹುದು.
    ///
    /// Negative ಣಾತ್ಮಕ ಸಂಖ್ಯೆಗಳಿಂದ ರಚಿಸಲಾದ ಅಕ್ಷರಗಳು `TokenStream` ಅಥವಾ ತಂತಿಗಳ ಮೂಲಕ ರೌಂಟ್ರಿಪ್‌ಗಳನ್ನು ಉಳಿಸುವುದಿಲ್ಲ ಮತ್ತು ಅವುಗಳನ್ನು ಎರಡು tokens (`-` ಮತ್ತು ಧನಾತ್ಮಕ ಅಕ್ಷರಶಃ)ಗಳಾಗಿ ವಿಂಗಡಿಸಬಹುದು.
    ///
    /// # Panics
    ///
    /// ಈ ಕಾರ್ಯಕ್ಕೆ ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಫ್ಲೋಟ್ ಸೀಮಿತವಾಗಿದೆ, ಉದಾಹರಣೆಗೆ ಅದು ಅನಂತ ಅಥವಾ NaN ಆಗಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// ಹೊಸ ಪ್ರತ್ಯಯ ಫ್ಲೋಟಿಂಗ್-ಪಾಯಿಂಟ್ ಅಕ್ಷರಶಃ ರಚಿಸುತ್ತದೆ.
    ///
    /// ಈ ಕನ್‌ಸ್ಟ್ರಕ್ಟರ್ `1.0f32` ನಂತಹ ಅಕ್ಷರಶಃ ರಚಿಸುತ್ತದೆ, ಅಲ್ಲಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಮೌಲ್ಯವು token ನ ಹಿಂದಿನ ಭಾಗವಾಗಿದೆ ಮತ್ತು `f32` ಎಂಬುದು token ನ ಪ್ರತ್ಯಯವಾಗಿದೆ.
    /// ಈ token ಅನ್ನು ಯಾವಾಗಲೂ ಕಂಪೈಲರ್‌ನಲ್ಲಿ `f32` ಎಂದು er ಹಿಸಲಾಗುತ್ತದೆ.
    /// Negative ಣಾತ್ಮಕ ಸಂಖ್ಯೆಗಳಿಂದ ರಚಿಸಲಾದ ಅಕ್ಷರಗಳು `TokenStream` ಅಥವಾ ತಂತಿಗಳ ಮೂಲಕ ರೌಂಟ್ರಿಪ್‌ಗಳನ್ನು ಉಳಿಸುವುದಿಲ್ಲ ಮತ್ತು ಅವುಗಳನ್ನು ಎರಡು tokens (`-` ಮತ್ತು ಧನಾತ್ಮಕ ಅಕ್ಷರಶಃ)ಗಳಾಗಿ ವಿಂಗಡಿಸಬಹುದು.
    ///
    ///
    /// # Panics
    ///
    /// ಈ ಕಾರ್ಯಕ್ಕೆ ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಫ್ಲೋಟ್ ಸೀಮಿತವಾಗಿದೆ, ಉದಾಹರಣೆಗೆ ಅದು ಅನಂತ ಅಥವಾ NaN ಆಗಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// ಹೊಸ ಅನ್‌ಫಿಕ್ಸ್ಡ್ ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಅಕ್ಷರಶಃ ರಚಿಸುತ್ತದೆ.
    ///
    /// ಈ ಕನ್‌ಸ್ಟ್ರಕ್ಟರ್ `Literal::i8_unsuffixed` ನಂತಹವುಗಳಿಗೆ ಹೋಲುತ್ತದೆ, ಅಲ್ಲಿ ಫ್ಲೋಟ್‌ನ ಮೌಲ್ಯವನ್ನು ನೇರವಾಗಿ token ಗೆ ಹೊರಸೂಸಲಾಗುತ್ತದೆ ಆದರೆ ಯಾವುದೇ ಪ್ರತ್ಯಯವನ್ನು ಬಳಸಲಾಗುವುದಿಲ್ಲ, ಆದ್ದರಿಂದ ಇದನ್ನು ಕಂಪೈಲರ್‌ನಲ್ಲಿ `f64` ಎಂದು er ಹಿಸಬಹುದು.
    ///
    /// Negative ಣಾತ್ಮಕ ಸಂಖ್ಯೆಗಳಿಂದ ರಚಿಸಲಾದ ಅಕ್ಷರಗಳು `TokenStream` ಅಥವಾ ತಂತಿಗಳ ಮೂಲಕ ರೌಂಟ್ರಿಪ್‌ಗಳನ್ನು ಉಳಿಸುವುದಿಲ್ಲ ಮತ್ತು ಅವುಗಳನ್ನು ಎರಡು tokens (`-` ಮತ್ತು ಧನಾತ್ಮಕ ಅಕ್ಷರಶಃ)ಗಳಾಗಿ ವಿಂಗಡಿಸಬಹುದು.
    ///
    /// # Panics
    ///
    /// ಈ ಕಾರ್ಯಕ್ಕೆ ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಫ್ಲೋಟ್ ಸೀಮಿತವಾಗಿದೆ, ಉದಾಹರಣೆಗೆ ಅದು ಅನಂತ ಅಥವಾ NaN ಆಗಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// ಹೊಸ ಪ್ರತ್ಯಯ ಫ್ಲೋಟಿಂಗ್-ಪಾಯಿಂಟ್ ಅಕ್ಷರಶಃ ರಚಿಸುತ್ತದೆ.
    ///
    /// ಈ ಕನ್‌ಸ್ಟ್ರಕ್ಟರ್ `1.0f64` ನಂತಹ ಅಕ್ಷರಶಃ ರಚಿಸುತ್ತದೆ, ಅಲ್ಲಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಮೌಲ್ಯವು token ನ ಹಿಂದಿನ ಭಾಗವಾಗಿದೆ ಮತ್ತು `f64` ಎಂಬುದು token ನ ಪ್ರತ್ಯಯವಾಗಿದೆ.
    /// ಈ token ಅನ್ನು ಯಾವಾಗಲೂ ಕಂಪೈಲರ್‌ನಲ್ಲಿ `f64` ಎಂದು er ಹಿಸಲಾಗುತ್ತದೆ.
    /// Negative ಣಾತ್ಮಕ ಸಂಖ್ಯೆಗಳಿಂದ ರಚಿಸಲಾದ ಅಕ್ಷರಗಳು `TokenStream` ಅಥವಾ ತಂತಿಗಳ ಮೂಲಕ ರೌಂಟ್ರಿಪ್‌ಗಳನ್ನು ಉಳಿಸುವುದಿಲ್ಲ ಮತ್ತು ಅವುಗಳನ್ನು ಎರಡು tokens (`-` ಮತ್ತು ಧನಾತ್ಮಕ ಅಕ್ಷರಶಃ)ಗಳಾಗಿ ವಿಂಗಡಿಸಬಹುದು.
    ///
    ///
    /// # Panics
    ///
    /// ಈ ಕಾರ್ಯಕ್ಕೆ ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಫ್ಲೋಟ್ ಸೀಮಿತವಾಗಿದೆ, ಉದಾಹರಣೆಗೆ ಅದು ಅನಂತ ಅಥವಾ NaN ಆಗಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// ಸ್ಟ್ರಿಂಗ್ ಅಕ್ಷರಶಃ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// ಅಕ್ಷರ ಅಕ್ಷರಶಃ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// ಬೈಟ್ ಸ್ಟ್ರಿಂಗ್ ಅಕ್ಷರಶಃ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// ಈ ಅಕ್ಷರಶಃ ಒಳಗೊಳ್ಳುವ ಅವಧಿಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ಈ ಅಕ್ಷರಶಃ ಸಂಬಂಧಿಸಿದ ಅವಧಿಯನ್ನು ಕಾನ್ಫಿಗರ್ ಮಾಡುತ್ತದೆ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// `Span` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ ಅದು `self.span()` ನ ಉಪವಿಭಾಗವಾಗಿದ್ದು, `range` ವ್ಯಾಪ್ತಿಯಲ್ಲಿ ಮೂಲ ಬೈಟ್‌ಗಳನ್ನು ಮಾತ್ರ ಹೊಂದಿರುತ್ತದೆ.
    /// ಟ್ರಿಮ್ ಮಾಡಲಾದ ಸ್ಪ್ಯಾನ್ `self` ನ ಗಡಿಯಿಂದ ಹೊರಗಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    // FIXME(SergioBenitez): ಬೈಟ್ ಶ್ರೇಣಿ ಮೂಲದ UTF-8 ಗಡಿಯಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ ಮತ್ತು ಕೊನೆಗೊಳ್ಳುತ್ತದೆ ಎಂದು ಪರಿಶೀಲಿಸಿ.
    // ಇಲ್ಲದಿದ್ದರೆ, ಮೂಲ ಪಠ್ಯವನ್ನು ಮುದ್ರಿಸಿದಾಗ panic ಬೇರೆಡೆ ಸಂಭವಿಸುವ ಸಾಧ್ಯತೆಯಿದೆ.
    // FIXME(SergioBenitez): `self.span()` ನಿಜವಾಗಿ ಏನು ನಕ್ಷೆ ಮಾಡುತ್ತದೆ ಎಂಬುದನ್ನು ಬಳಕೆದಾರರಿಗೆ ತಿಳಿಯಲು ಯಾವುದೇ ಮಾರ್ಗವಿಲ್ಲ, ಆದ್ದರಿಂದ ಈ ವಿಧಾನವನ್ನು ಪ್ರಸ್ತುತ ಕುರುಡಾಗಿ ಮಾತ್ರ ಕರೆಯಬಹುದು.
    // ಉದಾಹರಣೆಗೆ, 'c' ಅಕ್ಷರಕ್ಕಾಗಿ `to_string()` "'\u{63}'" ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ;ಮೂಲ ಪಠ್ಯವು 'c' ಆಗಿದೆಯೇ ಅಥವಾ ಅದು '\u{63}' ಆಗಿದೆಯೇ ಎಂದು ಬಳಕೆದಾರರಿಗೆ ತಿಳಿಯಲು ಯಾವುದೇ ಮಾರ್ಗವಿಲ್ಲ.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) `Option::cloned` ಗೆ ಹೋಲುತ್ತದೆ, ಆದರೆ `Bound<&T>` ಗೆ.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, ಸೇತುವೆ `to_string` ಅನ್ನು ಮಾತ್ರ ಒದಗಿಸುತ್ತದೆ, ಅದರ ಆಧಾರದ ಮೇಲೆ `fmt::Display` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿ (ಇವೆರಡರ ನಡುವಿನ ಸಾಮಾನ್ಯ ಸಂಬಂಧದ ಹಿಮ್ಮುಖ).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// ಅಕ್ಷರಶಃ ಸ್ಟ್ರಿಂಗ್‌ನಂತೆ ಮುದ್ರಿಸುತ್ತದೆ, ಅದು ನಷ್ಟವಿಲ್ಲದೆ ಮತ್ತೆ ಅದೇ ಅಕ್ಷರಕ್ಕೆ ಪರಿವರ್ತಿಸಲ್ಪಡುತ್ತದೆ (ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಲಿಟರಲ್‌ಗಳಿಗೆ ಸಂಭವನೀಯ ರೌಂಡಿಂಗ್ ಹೊರತುಪಡಿಸಿ).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// ಪರಿಸರ ಅಸ್ಥಿರಗಳಿಗೆ ಟ್ರ್ಯಾಕ್ ಮಾಡಲಾಗಿದೆ.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// ಪರಿಸರ ವೇರಿಯಬಲ್ ಅನ್ನು ಹಿಂಪಡೆಯಿರಿ ಮತ್ತು ಅವಲಂಬನೆ ಮಾಹಿತಿಯನ್ನು ನಿರ್ಮಿಸಲು ಅದನ್ನು ಸೇರಿಸಿ.
    /// ಕಂಪೈಲರ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಬಿಲ್ಡ್ ಸಿಸ್ಟಮ್ ಕಂಪೈಲ್ ಸಮಯದಲ್ಲಿ ವೇರಿಯಬಲ್ ಅನ್ನು ಪ್ರವೇಶಿಸಿದೆ ಎಂದು ತಿಳಿಯುತ್ತದೆ ಮತ್ತು ಆ ವೇರಿಯೇಬಲ್ನ ಮೌಲ್ಯವು ಬದಲಾದಾಗ ಬಿಲ್ಡ್ ಅನ್ನು ಮರು ಚಾಲನೆ ಮಾಡಲು ಸಾಧ್ಯವಾಗುತ್ತದೆ.
    ///
    /// ಅವಲಂಬನೆ ಟ್ರ್ಯಾಕಿಂಗ್ ಜೊತೆಗೆ ಈ ಕಾರ್ಯವು ಪ್ರಮಾಣಿತ ಗ್ರಂಥಾಲಯದಿಂದ `env::var` ಗೆ ಸಮನಾಗಿರಬೇಕು, ಹೊರತುಪಡಿಸಿ ವಾದವು UTF-8 ಆಗಿರಬೇಕು.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}