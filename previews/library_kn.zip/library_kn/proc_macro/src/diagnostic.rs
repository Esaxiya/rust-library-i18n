use crate::Span;

/// ರೋಗನಿರ್ಣಯದ ಮಟ್ಟವನ್ನು ಪ್ರತಿನಿಧಿಸುವ ಎನಮ್.
#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
#[derive(Copy, Clone, Debug)]
#[non_exhaustive]
pub enum Level {
    /// ದೋಷ.
    Error,
    /// ಒಂದು ಎಚ್ಚರಿಕೆ.
    Warning,
    /// ಒಂದು ಟಿಪ್ಪಣಿ.
    Note,
    /// ಸಹಾಯ ಸಂದೇಶ.
    Help,
}

/// Trait ಅನ್ನು `ಸ್ಪ್ಯಾನ್'ಗಳ ಗುಂಪಾಗಿ ಪರಿವರ್ತಿಸಬಹುದಾದ ಪ್ರಕಾರಗಳಿಂದ ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗಿದೆ.
#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub trait MultiSpan {
    /// `self` ಅನ್ನು `Vec<Span>` ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    fn into_spans(self) -> Vec<Span>;
}

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl MultiSpan for Span {
    fn into_spans(self) -> Vec<Span> {
        vec![self]
    }
}

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl MultiSpan for Vec<Span> {
    fn into_spans(self) -> Vec<Span> {
        self
    }
}

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl<'a> MultiSpan for &'a [Span] {
    fn into_spans(self) -> Vec<Span> {
        self.to_vec()
    }
}

/// ರೋಗನಿರ್ಣಯದ ಸಂದೇಶ ಮತ್ತು ಸಂಬಂಧಿತ ಮಕ್ಕಳ ಸಂದೇಶಗಳನ್ನು ಪ್ರತಿನಿಧಿಸುವ ರಚನೆ.
///
#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
#[derive(Clone, Debug)]
pub struct Diagnostic {
    level: Level,
    message: String,
    spans: Vec<Span>,
    children: Vec<Diagnostic>,
}

macro_rules! diagnostic_child_methods {
    ($spanned:ident, $regular:ident, $level:expr) => {
        /// ಕೊಟ್ಟಿರುವ `spans` ಮತ್ತು `message` ನೊಂದಿಗೆ ಈ ವಿಧಾನದ ಹೆಸರಿನಿಂದ ಗುರುತಿಸಲ್ಪಟ್ಟ ಮಟ್ಟದೊಂದಿಗೆ `self` ಗೆ ಹೊಸ ಮಕ್ಕಳ ರೋಗನಿರ್ಣಯ ಸಂದೇಶವನ್ನು ಸೇರಿಸುತ್ತದೆ.
        ///
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $spanned<S, T>(mut self, spans: S, message: T) -> Diagnostic
        where
            S: MultiSpan,
            T: Into<String>,
        {
            self.children.push(Diagnostic::spanned(spans, $level, message));
            self
        }

        /// ಕೊಟ್ಟಿರುವ `message` ನೊಂದಿಗೆ ಈ ವಿಧಾನದ ಹೆಸರಿನಿಂದ ಗುರುತಿಸಲ್ಪಟ್ಟ ಮಟ್ಟದೊಂದಿಗೆ `self` ಗೆ ಹೊಸ ಮಕ್ಕಳ ರೋಗನಿರ್ಣಯ ಸಂದೇಶವನ್ನು ಸೇರಿಸುತ್ತದೆ.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $regular<T: Into<String>>(mut self, message: T) -> Diagnostic {
            self.children.push(Diagnostic::new($level, message));
            self
        }
    };
}

/// `Diagnostic` ನ ಮಕ್ಕಳ ರೋಗನಿರ್ಣಯದ ಮೇಲೆ ಇಟರೇಟರ್.
#[derive(Debug, Clone)]
#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub struct Children<'a>(std::slice::Iter<'a, Diagnostic>);

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl<'a> Iterator for Children<'a> {
    type Item = &'a Diagnostic;

    fn next(&mut self) -> Option<Self::Item> {
        self.0.next()
    }
}

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl Diagnostic {
    /// ಕೊಟ್ಟಿರುವ `level` ಮತ್ತು `message` ನೊಂದಿಗೆ ಹೊಸ ರೋಗನಿರ್ಣಯವನ್ನು ರಚಿಸುತ್ತದೆ.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn new<T: Into<String>>(level: Level, message: T) -> Diagnostic {
        Diagnostic { level, message: message.into(), spans: vec![], children: vec![] }
    }

    /// ಕೊಟ್ಟಿರುವ X001 ನ ಸೆಟ್ ಅನ್ನು ಸೂಚಿಸುವ `level` ಮತ್ತು `message` ನೊಂದಿಗೆ ಹೊಸ ರೋಗನಿರ್ಣಯವನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn spanned<S, T>(spans: S, level: Level, message: T) -> Diagnostic
    where
        S: MultiSpan,
        T: Into<String>,
    {
        Diagnostic { level, message: message.into(), spans: spans.into_spans(), children: vec![] }
    }

    diagnostic_child_methods!(span_error, error, Level::Error);
    diagnostic_child_methods!(span_warning, warning, Level::Warning);
    diagnostic_child_methods!(span_note, note, Level::Note);
    diagnostic_child_methods!(span_help, help, Level::Help);

    /// `self` ಗಾಗಿ ರೋಗನಿರ್ಣಯದ `level` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn level(&self) -> Level {
        self.level
    }

    /// `self` ನಿಂದ `level` ಗೆ ಮಟ್ಟವನ್ನು ಹೊಂದಿಸುತ್ತದೆ.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn set_level(&mut self, level: Level) {
        self.level = level;
    }

    /// `self` ನಲ್ಲಿ ಸಂದೇಶವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn message(&self) -> &str {
        &self.message
    }

    /// ಸಂದೇಶವನ್ನು `self` ನಿಂದ `message` ಗೆ ಹೊಂದಿಸುತ್ತದೆ.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn set_message<T: Into<String>>(&mut self, message: T) {
        self.message = message.into();
    }

    /// `self` ನಲ್ಲಿ `ಸ್ಪ್ಯಾನ್'ಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn spans(&self) -> &[Span] {
        &self.spans
    }

    /// `ಸ್ಪ್ಯಾನ್'ಗಳನ್ನು `self` ನಿಂದ `spans` ಗೆ ಹೊಂದಿಸುತ್ತದೆ.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn set_spans<S: MultiSpan>(&mut self, spans: S) {
        self.spans = spans.into_spans();
    }

    /// `self` ನ ಮಕ್ಕಳ ರೋಗನಿರ್ಣಯದ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn children(&self) -> Children<'_> {
        Children(self.children.iter())
    }

    /// ರೋಗನಿರ್ಣಯವನ್ನು ಹೊರಸೂಸಿರಿ.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn emit(self) {
        fn to_internal(spans: Vec<Span>) -> crate::bridge::client::MultiSpan {
            let mut multi_span = crate::bridge::client::MultiSpan::new();
            for span in spans {
                multi_span.push(span.0);
            }
            multi_span
        }

        let mut diag = crate::bridge::client::Diagnostic::new(
            self.level,
            &self.message[..],
            to_internal(self.spans),
        );
        for c in self.children {
            diag.sub(c.level, &c.message[..], to_internal(c.spans));
        }
        diag.emit();
    }
}