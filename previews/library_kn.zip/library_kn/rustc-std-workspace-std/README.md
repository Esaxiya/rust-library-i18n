# `rustc-std-workspace-std` crate

`rustc-std-workspace-core` crate ಗಾಗಿ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.