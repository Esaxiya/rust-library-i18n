//! ಇದು ifmt ಬಳಸುವ ಆಂತರಿಕ ಮಾಡ್ಯೂಲ್ ಆಗಿದೆ!ಚಾಲನಾಸಮಯ.ಈ ರಚನೆಗಳನ್ನು ಸಮಯಕ್ಕಿಂತ ಮುಂಚಿತವಾಗಿ ಫಾರ್ಮ್ಯಾಟ್ ತಂತಿಗಳನ್ನು ಪೂರ್ವ ಕಂಪೈಲ್ ಮಾಡಲು ಸ್ಥಿರ ಸರಣಿಗಳಿಗೆ ಹೊರಸೂಸಲಾಗುತ್ತದೆ.
//!
//! ಈ ವ್ಯಾಖ್ಯಾನಗಳು ಅವುಗಳ `ct` ಸಮಾನಗಳಿಗೆ ಹೋಲುತ್ತವೆ, ಆದರೆ ಇವುಗಳನ್ನು ಸ್ಥಿರವಾಗಿ ಹಂಚಿಕೆ ಮಾಡಬಹುದಾಗಿದೆ ಮತ್ತು ಚಾಲನಾಸಮಯಕ್ಕೆ ಸ್ವಲ್ಪ ಹೊಂದುವಂತೆ ಮಾಡಲಾಗುತ್ತದೆ
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// ಫಾರ್ಮ್ಯಾಟಿಂಗ್ ನಿರ್ದೇಶನದ ಭಾಗವಾಗಿ ವಿನಂತಿಸಬಹುದಾದ ಸಂಭಾವ್ಯ ಜೋಡಣೆಗಳು.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// ವಿಷಯಗಳನ್ನು ಎಡ-ಜೋಡಿಸಬೇಕು ಎಂಬ ಸೂಚನೆ.
    Left,
    /// ವಿಷಯಗಳನ್ನು ಸರಿಯಾಗಿ ಜೋಡಿಸಬೇಕು ಎಂಬ ಸೂಚನೆ.
    Right,
    /// ವಿಷಯಗಳನ್ನು ಕೇಂದ್ರಕ್ಕೆ ಹೊಂದಿಸಬೇಕು ಎಂಬ ಸೂಚನೆ.
    Center,
    /// ಯಾವುದೇ ಜೋಡಣೆಯನ್ನು ವಿನಂತಿಸಲಾಗಿಲ್ಲ.
    Unknown,
}

/// [width](https://doc.rust-lang.org/std/fmt/#width) ಮತ್ತು [precision](https://doc.rust-lang.org/std/fmt/#precision) ನಿರ್ದಿಷ್ಟಪಡಿಸುವವರು ಬಳಸುತ್ತಾರೆ.
#[derive(Copy, Clone)]
pub enum Count {
    /// ಅಕ್ಷರಶಃ ಸಂಖ್ಯೆಯೊಂದಿಗೆ ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿದೆ, ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ
    Is(usize),
    /// `$` ಮತ್ತು `*` ಸಿಂಟ್ಯಾಕ್ಸ್‌ಗಳನ್ನು ಬಳಸಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿದೆ, ಸೂಚ್ಯಂಕವನ್ನು `args` ಗೆ ಸಂಗ್ರಹಿಸುತ್ತದೆ
    Param(usize),
    /// ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿಲ್ಲ
    Implied,
}