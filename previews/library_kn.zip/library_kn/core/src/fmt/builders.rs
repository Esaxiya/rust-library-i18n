#![allow(unused_imports)]

use crate::fmt::{self, Debug, Formatter};

struct PadAdapter<'buf, 'state> {
    buf: &'buf mut (dyn fmt::Write + 'buf),
    state: &'state mut PadAdapterState,
}

struct PadAdapterState {
    on_newline: bool,
}

impl Default for PadAdapterState {
    fn default() -> Self {
        PadAdapterState { on_newline: true }
    }
}

impl<'buf, 'state> PadAdapter<'buf, 'state> {
    fn wrap<'slot, 'fmt: 'buf + 'slot>(
        fmt: &'fmt mut fmt::Formatter<'_>,
        slot: &'slot mut Option<Self>,
        state: &'state mut PadAdapterState,
    ) -> fmt::Formatter<'slot> {
        fmt.wrap_buf(move |buf| {
            *slot = Some(PadAdapter { buf, state });
            slot.as_mut().unwrap()
        })
    }
}

impl fmt::Write for PadAdapter<'_, '_> {
    fn write_str(&mut self, mut s: &str) -> fmt::Result {
        while !s.is_empty() {
            if self.state.on_newline {
                self.buf.write_str("    ")?;
            }

            let split = match s.find('\n') {
                Some(pos) => {
                    self.state.on_newline = true;
                    pos + 1
                }
                None => {
                    self.state.on_newline = false;
                    s.len()
                }
            };
            self.buf.write_str(&s[..split])?;
            s = &s[split..];
        }

        Ok(())
    }
}

/// [`fmt::Debug`](Debug) ಅನುಷ್ಠಾನಗಳಿಗೆ ಸಹಾಯ ಮಾಡುವ ಒಂದು ರಚನೆ.
///
/// ನಿಮ್ಮ [`Debug::fmt`] ಅನುಷ್ಠಾನದ ಭಾಗವಾಗಿ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಿದ ರಚನೆಯನ್ನು output ಟ್‌ಪುಟ್ ಮಾಡಲು ನೀವು ಬಯಸಿದಾಗ ಇದು ಉಪಯುಕ್ತವಾಗಿರುತ್ತದೆ.
///
///
/// ಇದನ್ನು [`Formatter::debug_struct`] ವಿಧಾನದಿಂದ ನಿರ್ಮಿಸಬಹುದು.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// struct Foo {
///     bar: i32,
///     baz: String,
/// }
///
/// impl fmt::Debug for Foo {
///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
///         fmt.debug_struct("Foo")
///            .field("bar", &self.bar)
///            .field("baz", &self.baz)
///            .finish()
///     }
/// }
///
/// assert_eq!(
///     format!("{:?}", Foo { bar: 10, baz: "Hello World".to_string() }),
///     "Foo { bar: 10, baz: \"Hello World\" }",
/// );
/// ```
#[must_use = "must eventually call `finish()` on Debug builders"]
#[allow(missing_debug_implementations)]
#[stable(feature = "debug_builders", since = "1.2.0")]
pub struct DebugStruct<'a, 'b: 'a> {
    fmt: &'a mut fmt::Formatter<'b>,
    result: fmt::Result,
    has_fields: bool,
}

pub(super) fn debug_struct_new<'a, 'b>(
    fmt: &'a mut fmt::Formatter<'b>,
    name: &str,
) -> DebugStruct<'a, 'b> {
    let result = fmt.write_str(name);
    DebugStruct { fmt, result, has_fields: false }
}

impl<'a, 'b: 'a> DebugStruct<'a, 'b> {
    /// ರಚಿಸಿದ struct ಟ್‌ಪುಟ್‌ಗೆ ಹೊಸ ಕ್ಷೇತ್ರವನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Bar {
    ///     bar: i32,
    ///     another: String,
    /// }
    ///
    /// impl fmt::Debug for Bar {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_struct("Bar")
    ///            .field("bar", &self.bar) // ನಾವು `bar` ಕ್ಷೇತ್ರವನ್ನು ಸೇರಿಸುತ್ತೇವೆ.
    ///            .field("another", &self.another) // ನಾವು `another` ಕ್ಷೇತ್ರವನ್ನು ಸೇರಿಸುತ್ತೇವೆ.
    ///            // ನಾವು ಅಸ್ತಿತ್ವದಲ್ಲಿಲ್ಲದ ಕ್ಷೇತ್ರವನ್ನು ಸಹ ಸೇರಿಸುತ್ತೇವೆ (ಏಕೆಂದರೆ ಏಕೆ?).
    ///            .field("not_existing_field", &1)
    ///            .finish() // ನಾವು ಹೋಗುವುದು ಒಳ್ಳೆಯದು!
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Bar { bar: 10, another: "Hello World".to_string() }),
    ///     "Bar { bar: 10, another: \"Hello World\", not_existing_field: 1 }",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn field(&mut self, name: &str, value: &dyn fmt::Debug) -> &mut Self {
        self.result = self.result.and_then(|_| {
            if self.is_pretty() {
                if !self.has_fields {
                    self.fmt.write_str(" {\n")?;
                }
                let mut slot = None;
                let mut state = Default::default();
                let mut writer = PadAdapter::wrap(&mut self.fmt, &mut slot, &mut state);
                writer.write_str(name)?;
                writer.write_str(": ")?;
                value.fmt(&mut writer)?;
                writer.write_str(",\n")
            } else {
                let prefix = if self.has_fields { ", " } else { " { " };
                self.fmt.write_str(prefix)?;
                self.fmt.write_str(name)?;
                self.fmt.write_str(": ")?;
                value.fmt(self.fmt)
            }
        });

        self.has_fields = true;
        self
    }

    /// ಡೀಬಗ್ ಪ್ರಾತಿನಿಧ್ಯದಲ್ಲಿ ತೋರಿಸದ ಇತರ ಕೆಲವು ಕ್ಷೇತ್ರಗಳಿವೆ ಎಂದು ಓದುಗರಿಗೆ ಸೂಚಿಸುವ ರಚನೆಯನ್ನು ಸಮಗ್ರವಲ್ಲದ ಎಂದು ಗುರುತಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(debug_non_exhaustive)]
    /// use std::fmt;
    ///
    /// struct Bar {
    ///     bar: i32,
    ///     hidden: f32,
    /// }
    ///
    /// impl fmt::Debug for Bar {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_struct("Bar")
    ///            .field("bar", &self.bar)
    ///            .finish_non_exhaustive() // ಕೆಲವು ಇತರ field(s) ಅಸ್ತಿತ್ವದಲ್ಲಿದೆ ಎಂದು ತೋರಿಸಿ.
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Bar { bar: 10, hidden: 1.0 }),
    ///     "Bar { bar: 10, .. }",
    /// );
    /// ```
    #[unstable(feature = "debug_non_exhaustive", issue = "67364")]
    pub fn finish_non_exhaustive(&mut self) -> fmt::Result {
        self.result = self.result.and_then(|_| {
            // ಸಮಗ್ರವಲ್ಲದ ಚುಕ್ಕೆಗಳನ್ನು ಎಳೆಯಿರಿ (`..`), ಮತ್ತು ಅಗತ್ಯವಿದ್ದರೆ ಬ್ರೇಸ್ ತೆರೆಯಿರಿ (ಯಾವುದೇ ಕ್ಷೇತ್ರಗಳಿಲ್ಲ).
            if self.is_pretty() {
                if !self.has_fields {
                    self.fmt.write_str(" {\n")?;
                }
                let mut slot = None;
                let mut state = Default::default();
                let mut writer = PadAdapter::wrap(&mut self.fmt, &mut slot, &mut state);
                writer.write_str("..\n")?;
            } else {
                if self.has_fields {
                    self.fmt.write_str(", ..")?;
                } else {
                    self.fmt.write_str(" { ..")?;
                }
            }
            if self.is_pretty() {
                self.fmt.write_str("}")?
            } else {
                self.fmt.write_str(" }")?;
            }
            Ok(())
        });
        self.result
    }

    /// Output ಟ್‌ಪುಟ್ ಮುಗಿಸುತ್ತದೆ ಮತ್ತು ಎದುರಾದ ಯಾವುದೇ ದೋಷವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Bar {
    ///     bar: i32,
    ///     baz: String,
    /// }
    ///
    /// impl fmt::Debug for Bar {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_struct("Bar")
    ///            .field("bar", &self.bar)
    ///            .field("baz", &self.baz)
    ///            .finish() // ನೀವು ಅದನ್ನು "finish" ಗೆ ಕರೆ ಮಾಡಬೇಕಾಗಿದೆ
    ///                      // struct ಫಾರ್ಮ್ಯಾಟಿಂಗ್.
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Bar { bar: 10, baz: "Hello World".to_string() }),
    ///     "Bar { bar: 10, baz: \"Hello World\" }",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn finish(&mut self) -> fmt::Result {
        if self.has_fields {
            self.result = self.result.and_then(|_| {
                if self.is_pretty() { self.fmt.write_str("}") } else { self.fmt.write_str(" }") }
            });
        }
        self.result
    }

    fn is_pretty(&self) -> bool {
        self.fmt.alternate()
    }
}

/// [`fmt::Debug`](Debug) ಅನುಷ್ಠಾನಗಳಿಗೆ ಸಹಾಯ ಮಾಡುವ ಒಂದು ರಚನೆ.
///
/// ನಿಮ್ಮ [`Debug::fmt`] ಅನುಷ್ಠಾನದ ಭಾಗವಾಗಿ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಿದ ಟಪಲ್ ಅನ್ನು output ಟ್ಪುಟ್ ಮಾಡಲು ನೀವು ಬಯಸಿದಾಗ ಇದು ಉಪಯುಕ್ತವಾಗಿದೆ.
///
///
/// ಇದನ್ನು [`Formatter::debug_tuple`] ವಿಧಾನದಿಂದ ನಿರ್ಮಿಸಬಹುದು.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// struct Foo(i32, String);
///
/// impl fmt::Debug for Foo {
///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
///         fmt.debug_tuple("Foo")
///            .field(&self.0)
///            .field(&self.1)
///            .finish()
///     }
/// }
///
/// assert_eq!(
///     format!("{:?}", Foo(10, "Hello World".to_string())),
///     "Foo(10, \"Hello World\")",
/// );
/// ```
#[must_use = "must eventually call `finish()` on Debug builders"]
#[allow(missing_debug_implementations)]
#[stable(feature = "debug_builders", since = "1.2.0")]
pub struct DebugTuple<'a, 'b: 'a> {
    fmt: &'a mut fmt::Formatter<'b>,
    result: fmt::Result,
    fields: usize,
    empty_name: bool,
}

pub(super) fn debug_tuple_new<'a, 'b>(
    fmt: &'a mut fmt::Formatter<'b>,
    name: &str,
) -> DebugTuple<'a, 'b> {
    let result = fmt.write_str(name);
    DebugTuple { fmt, result, fields: 0, empty_name: name.is_empty() }
}

impl<'a, 'b: 'a> DebugTuple<'a, 'b> {
    /// ರಚಿಸಲಾದ ಟಪಲ್ ಸ್ಟ್ರಕ್ಟ್‌ಪುಟ್‌ಗೆ ಹೊಸ ಕ್ಷೇತ್ರವನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32, String);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///            .field(&self.0) // ನಾವು ಮೊದಲ ಕ್ಷೇತ್ರವನ್ನು ಸೇರಿಸುತ್ತೇವೆ.
    ///            .field(&self.1) // ನಾವು ಎರಡನೇ ಕ್ಷೇತ್ರವನ್ನು ಸೇರಿಸುತ್ತೇವೆ.
    ///            .finish() // ನಾವು ಹೋಗುವುದು ಒಳ್ಳೆಯದು!
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(10, "Hello World".to_string())),
    ///     "Foo(10, \"Hello World\")",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn field(&mut self, value: &dyn fmt::Debug) -> &mut Self {
        self.result = self.result.and_then(|_| {
            if self.is_pretty() {
                if self.fields == 0 {
                    self.fmt.write_str("(\n")?;
                }
                let mut slot = None;
                let mut state = Default::default();
                let mut writer = PadAdapter::wrap(&mut self.fmt, &mut slot, &mut state);
                value.fmt(&mut writer)?;
                writer.write_str(",\n")
            } else {
                let prefix = if self.fields == 0 { "(" } else { ", " };
                self.fmt.write_str(prefix)?;
                value.fmt(self.fmt)
            }
        });

        self.fields += 1;
        self
    }

    /// Output ಟ್‌ಪುಟ್ ಮುಗಿಸುತ್ತದೆ ಮತ್ತು ಎದುರಾದ ಯಾವುದೇ ದೋಷವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32, String);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///            .field(&self.0)
    ///            .field(&self.1)
    ///            .finish() // ನೀವು ಅದನ್ನು "finish" ಗೆ ಕರೆ ಮಾಡಬೇಕಾಗಿದೆ
    ///                      // ಟಪಲ್ ಫಾರ್ಮ್ಯಾಟಿಂಗ್.
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(10, "Hello World".to_string())),
    ///     "Foo(10, \"Hello World\")",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn finish(&mut self) -> fmt::Result {
        if self.fields > 0 {
            self.result = self.result.and_then(|_| {
                if self.fields == 1 && self.empty_name && !self.is_pretty() {
                    self.fmt.write_str(",")?;
                }
                self.fmt.write_str(")")
            });
        }
        self.result
    }

    fn is_pretty(&self) -> bool {
        self.fmt.alternate()
    }
}

struct DebugInner<'a, 'b: 'a> {
    fmt: &'a mut fmt::Formatter<'b>,
    result: fmt::Result,
    has_fields: bool,
}

impl<'a, 'b: 'a> DebugInner<'a, 'b> {
    fn entry(&mut self, entry: &dyn fmt::Debug) {
        self.result = self.result.and_then(|_| {
            if self.is_pretty() {
                if !self.has_fields {
                    self.fmt.write_str("\n")?;
                }
                let mut slot = None;
                let mut state = Default::default();
                let mut writer = PadAdapter::wrap(&mut self.fmt, &mut slot, &mut state);
                entry.fmt(&mut writer)?;
                writer.write_str(",\n")
            } else {
                if self.has_fields {
                    self.fmt.write_str(", ")?
                }
                entry.fmt(self.fmt)
            }
        });

        self.has_fields = true;
    }

    fn is_pretty(&self) -> bool {
        self.fmt.alternate()
    }
}

/// [`fmt::Debug`](Debug) ಅನುಷ್ಠಾನಗಳಿಗೆ ಸಹಾಯ ಮಾಡುವ ಒಂದು ರಚನೆ.
///
/// ನಿಮ್ಮ [`Debug::fmt`] ಅನುಷ್ಠಾನದ ಭಾಗವಾಗಿ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಲಾದ ಐಟಂಗಳ output ಟ್‌ಪುಟ್ ಮಾಡಲು ನೀವು ಬಯಸಿದಾಗ ಇದು ಉಪಯುಕ್ತವಾಗಿರುತ್ತದೆ.
///
///
/// ಇದನ್ನು [`Formatter::debug_set`] ವಿಧಾನದಿಂದ ನಿರ್ಮಿಸಬಹುದು.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// struct Foo(Vec<i32>);
///
/// impl fmt::Debug for Foo {
///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
///         fmt.debug_set().entries(self.0.iter()).finish()
///     }
/// }
///
/// assert_eq!(
///     format!("{:?}", Foo(vec![10, 11])),
///     "{10, 11}",
/// );
/// ```
#[must_use = "must eventually call `finish()` on Debug builders"]
#[allow(missing_debug_implementations)]
#[stable(feature = "debug_builders", since = "1.2.0")]
pub struct DebugSet<'a, 'b: 'a> {
    inner: DebugInner<'a, 'b>,
}

pub(super) fn debug_set_new<'a, 'b>(fmt: &'a mut fmt::Formatter<'b>) -> DebugSet<'a, 'b> {
    let result = fmt.write_str("{");
    DebugSet { inner: DebugInner { fmt, result, has_fields: false } }
}

impl<'a, 'b: 'a> DebugSet<'a, 'b> {
    /// ಸೆಟ್ .ಟ್‌ಪುಟ್‌ಗೆ ಹೊಸ ನಮೂದನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>, Vec<u32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_set()
    ///            .entry(&self.0) // ಮೊದಲ "entry" ಅನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///            .entry(&self.1) // ಎರಡನೇ "entry" ಅನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///            .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![10, 11], vec![12, 13])),
    ///     "{[10, 11], [12, 13]}",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn entry(&mut self, entry: &dyn fmt::Debug) -> &mut Self {
        self.inner.entry(entry);
        self
    }

    /// ಸೆಟ್ .ಟ್‌ಪುಟ್‌ಗೆ ನಮೂದುಗಳ ಪುನರಾವರ್ತಕದ ವಿಷಯಗಳನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>, Vec<u32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_set()
    ///            .entries(self.0.iter()) // ಮೊದಲ "entry" ಅನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///            .entries(self.1.iter()) // ಎರಡನೇ "entry" ಅನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///            .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![10, 11], vec![12, 13])),
    ///     "{10, 11, 12, 13}",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn entries<D, I>(&mut self, entries: I) -> &mut Self
    where
        D: fmt::Debug,
        I: IntoIterator<Item = D>,
    {
        for entry in entries {
            self.entry(&entry);
        }
        self
    }

    /// Output ಟ್‌ಪುಟ್ ಮುಗಿಸುತ್ತದೆ ಮತ್ತು ಎದುರಾದ ಯಾವುದೇ ದೋಷವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_set()
    ///            .entries(self.0.iter())
    ///            .finish() // Struct ಫಾರ್ಮ್ಯಾಟಿಂಗ್ ಅನ್ನು ಕೊನೆಗೊಳಿಸುತ್ತದೆ.
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![10, 11])),
    ///     "{10, 11}",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn finish(&mut self) -> fmt::Result {
        self.inner.result.and_then(|_| self.inner.fmt.write_str("}"))
    }
}

/// [`fmt::Debug`](Debug) ಅನುಷ್ಠಾನಗಳಿಗೆ ಸಹಾಯ ಮಾಡುವ ಒಂದು ರಚನೆ.
///
/// ನಿಮ್ಮ [`Debug::fmt`] ಅನುಷ್ಠಾನದ ಭಾಗವಾಗಿ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಲಾದ ಐಟಂಗಳ ಪಟ್ಟಿಯನ್ನು output ಟ್‌ಪುಟ್ ಮಾಡಲು ನೀವು ಬಯಸಿದಾಗ ಇದು ಉಪಯುಕ್ತವಾಗಿರುತ್ತದೆ.
///
///
/// ಇದನ್ನು [`Formatter::debug_list`] ವಿಧಾನದಿಂದ ನಿರ್ಮಿಸಬಹುದು.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// struct Foo(Vec<i32>);
///
/// impl fmt::Debug for Foo {
///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
///         fmt.debug_list().entries(self.0.iter()).finish()
///     }
/// }
///
/// assert_eq!(
///     format!("{:?}", Foo(vec![10, 11])),
///     "[10, 11]",
/// );
/// ```
#[must_use = "must eventually call `finish()` on Debug builders"]
#[allow(missing_debug_implementations)]
#[stable(feature = "debug_builders", since = "1.2.0")]
pub struct DebugList<'a, 'b: 'a> {
    inner: DebugInner<'a, 'b>,
}

pub(super) fn debug_list_new<'a, 'b>(fmt: &'a mut fmt::Formatter<'b>) -> DebugList<'a, 'b> {
    let result = fmt.write_str("[");
    DebugList { inner: DebugInner { fmt, result, has_fields: false } }
}

impl<'a, 'b: 'a> DebugList<'a, 'b> {
    /// ಪಟ್ಟಿ .ಟ್‌ಪುಟ್‌ಗೆ ಹೊಸ ನಮೂದನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>, Vec<u32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_list()
    ///            .entry(&self.0) // ನಾವು ಮೊದಲ "entry" ಅನ್ನು ಸೇರಿಸುತ್ತೇವೆ.
    ///            .entry(&self.1) // ನಾವು ಎರಡನೇ "entry" ಅನ್ನು ಸೇರಿಸುತ್ತೇವೆ.
    ///            .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![10, 11], vec![12, 13])),
    ///     "[[10, 11], [12, 13]]",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn entry(&mut self, entry: &dyn fmt::Debug) -> &mut Self {
        self.inner.entry(entry);
        self
    }

    /// ಪಟ್ಟಿ .ಟ್‌ಪುಟ್‌ಗೆ ನಮೂದುಗಳ ಪುನರಾವರ್ತಕನ ವಿಷಯಗಳನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>, Vec<u32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_list()
    ///            .entries(self.0.iter())
    ///            .entries(self.1.iter())
    ///            .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![10, 11], vec![12, 13])),
    ///     "[10, 11, 12, 13]",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn entries<D, I>(&mut self, entries: I) -> &mut Self
    where
        D: fmt::Debug,
        I: IntoIterator<Item = D>,
    {
        for entry in entries {
            self.entry(&entry);
        }
        self
    }

    /// Output ಟ್‌ಪುಟ್ ಮುಗಿಸುತ್ತದೆ ಮತ್ತು ಎದುರಾದ ಯಾವುದೇ ದೋಷವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_list()
    ///            .entries(self.0.iter())
    ///            .finish() // Struct ಫಾರ್ಮ್ಯಾಟಿಂಗ್ ಅನ್ನು ಕೊನೆಗೊಳಿಸುತ್ತದೆ.
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![10, 11])),
    ///     "[10, 11]",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn finish(&mut self) -> fmt::Result {
        self.inner.result.and_then(|_| self.inner.fmt.write_str("]"))
    }
}

/// [`fmt::Debug`](Debug) ಅನುಷ್ಠಾನಗಳಿಗೆ ಸಹಾಯ ಮಾಡುವ ಒಂದು ರಚನೆ.
///
/// ನಿಮ್ಮ [`Debug::fmt`] ಅನುಷ್ಠಾನದ ಭಾಗವಾಗಿ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಿದ ನಕ್ಷೆಯನ್ನು output ಟ್‌ಪುಟ್ ಮಾಡಲು ನೀವು ಬಯಸಿದಾಗ ಇದು ಉಪಯುಕ್ತವಾಗಿರುತ್ತದೆ.
///
///
/// ಇದನ್ನು [`Formatter::debug_map`] ವಿಧಾನದಿಂದ ನಿರ್ಮಿಸಬಹುದು.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// struct Foo(Vec<(String, i32)>);
///
/// impl fmt::Debug for Foo {
///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
///     }
/// }
///
/// assert_eq!(
///     format!("{:?}", Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
///     "{\"A\": 10, \"B\": 11}",
/// );
/// ```
#[must_use = "must eventually call `finish()` on Debug builders"]
#[allow(missing_debug_implementations)]
#[stable(feature = "debug_builders", since = "1.2.0")]
pub struct DebugMap<'a, 'b: 'a> {
    fmt: &'a mut fmt::Formatter<'b>,
    result: fmt::Result,
    has_fields: bool,
    has_key: bool,
    // ಕೀಲಿಗಳು ಮತ್ತು ಮೌಲ್ಯಗಳ ನಡುವೆ ಹೊಸ ಲೈನ್‌ಗಳ ಸ್ಥಿತಿಯನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಲಾಗುತ್ತದೆ
    state: PadAdapterState,
}

pub(super) fn debug_map_new<'a, 'b>(fmt: &'a mut fmt::Formatter<'b>) -> DebugMap<'a, 'b> {
    let result = fmt.write_str("{");
    DebugMap { fmt, result, has_fields: false, has_key: false, state: Default::default() }
}

impl<'a, 'b: 'a> DebugMap<'a, 'b> {
    /// ನಕ್ಷೆಯ .ಟ್‌ಪುಟ್‌ಗೆ ಹೊಸ ನಮೂದನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_map()
    ///            .entry(&"whole", &self.0) // ನಾವು "whole" ನಮೂದನ್ನು ಸೇರಿಸುತ್ತೇವೆ.
    ///            .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     "{\"whole\": [(\"A\", 10), (\"B\", 11)]}",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn entry(&mut self, key: &dyn fmt::Debug, value: &dyn fmt::Debug) -> &mut Self {
        self.key(key).value(value)
    }

    /// ನಕ್ಷೆಯ .ಟ್‌ಪುಟ್‌ಗೆ ಹೊಸ ಪ್ರವೇಶದ ಪ್ರಮುಖ ಭಾಗವನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///
    /// ಈ ವಿಧಾನವು `value` ನೊಂದಿಗೆ, `entry` ಗೆ ಪರ್ಯಾಯವಾಗಿದ್ದು, ಸಂಪೂರ್ಣ ಪ್ರವೇಶವನ್ನು ಮುಂಗಡವಾಗಿ ತಿಳಿದಿಲ್ಲದಿದ್ದಾಗ ಇದನ್ನು ಬಳಸಬಹುದು.
    ///
    /// ಬಳಸಲು ಸಾಧ್ಯವಾದಾಗ `entry` ವಿಧಾನವನ್ನು ಆದ್ಯತೆ ನೀಡಿ.
    ///
    /// # Panics
    ///
    /// `key` `value` ಗೆ ಮೊದಲು ಕರೆ ಮಾಡಬೇಕು ಮತ್ತು `key` ಗೆ ಪ್ರತಿ ಕರೆಯನ್ನು `value` ಗೆ ಅನುಗುಣವಾದ ಕರೆ ಅನುಸರಿಸಬೇಕು.
    /// ಇಲ್ಲದಿದ್ದರೆ ಈ ವಿಧಾನವು panic ಆಗಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_map()
    ///            .key(&"whole").value(&self.0) // ನಾವು "whole" ನಮೂದನ್ನು ಸೇರಿಸುತ್ತೇವೆ.
    ///            .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     "{\"whole\": [(\"A\", 10), (\"B\", 11)]}",
    /// );
    /// ```
    #[stable(feature = "debug_map_key_value", since = "1.42.0")]
    pub fn key(&mut self, key: &dyn fmt::Debug) -> &mut Self {
        self.result = self.result.and_then(|_| {
            assert!(
                !self.has_key,
                "attempted to begin a new map entry \
                                    without completing the previous one"
            );

            if self.is_pretty() {
                if !self.has_fields {
                    self.fmt.write_str("\n")?;
                }
                let mut slot = None;
                self.state = Default::default();
                let mut writer = PadAdapter::wrap(&mut self.fmt, &mut slot, &mut self.state);
                key.fmt(&mut writer)?;
                writer.write_str(": ")?;
            } else {
                if self.has_fields {
                    self.fmt.write_str(", ")?
                }
                key.fmt(self.fmt)?;
                self.fmt.write_str(": ")?;
            }

            self.has_key = true;
            Ok(())
        });

        self
    }

    /// ನಕ್ಷೆಯ .ಟ್‌ಪುಟ್‌ಗೆ ಹೊಸ ಪ್ರವೇಶದ ಮೌಲ್ಯದ ಭಾಗವನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///
    /// ಈ ವಿಧಾನವು `key` ನೊಂದಿಗೆ, `entry` ಗೆ ಪರ್ಯಾಯವಾಗಿದ್ದು, ಸಂಪೂರ್ಣ ಪ್ರವೇಶವನ್ನು ಮುಂಗಡವಾಗಿ ತಿಳಿದಿಲ್ಲದಿದ್ದಾಗ ಇದನ್ನು ಬಳಸಬಹುದು.
    ///
    /// ಬಳಸಲು ಸಾಧ್ಯವಾದಾಗ `entry` ವಿಧಾನವನ್ನು ಆದ್ಯತೆ ನೀಡಿ.
    ///
    /// # Panics
    ///
    /// `key` `value` ಗೆ ಮೊದಲು ಕರೆ ಮಾಡಬೇಕು ಮತ್ತು `key` ಗೆ ಪ್ರತಿ ಕರೆಯನ್ನು `value` ಗೆ ಅನುಗುಣವಾದ ಕರೆ ಅನುಸರಿಸಬೇಕು.
    /// ಇಲ್ಲದಿದ್ದರೆ ಈ ವಿಧಾನವು panic ಆಗಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_map()
    ///            .key(&"whole").value(&self.0) // ನಾವು "whole" ನಮೂದನ್ನು ಸೇರಿಸುತ್ತೇವೆ.
    ///            .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     "{\"whole\": [(\"A\", 10), (\"B\", 11)]}",
    /// );
    /// ```
    #[stable(feature = "debug_map_key_value", since = "1.42.0")]
    pub fn value(&mut self, value: &dyn fmt::Debug) -> &mut Self {
        self.result = self.result.and_then(|_| {
            assert!(self.has_key, "attempted to format a map value before its key");

            if self.is_pretty() {
                let mut slot = None;
                let mut writer = PadAdapter::wrap(&mut self.fmt, &mut slot, &mut self.state);
                value.fmt(&mut writer)?;
                writer.write_str(",\n")?;
            } else {
                value.fmt(self.fmt)?;
            }

            self.has_key = false;
            Ok(())
        });

        self.has_fields = true;
        self
    }

    /// ನಕ್ಷೆಗಳ .ಟ್‌ಪುಟ್‌ಗೆ ನಮೂದುಗಳ ಪುನರಾವರ್ತಕದ ವಿಷಯಗಳನ್ನು ಸೇರಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_map()
    ///            // ನಾವು ನಮ್ಮ ವೆಕ್ ಅನ್ನು ನಕ್ಷೆ ಮಾಡುತ್ತೇವೆ ಆದ್ದರಿಂದ ಪ್ರತಿ ನಮೂದುಗಳ ಮೊದಲ ಕ್ಷೇತ್ರವು "key" ಆಗುತ್ತದೆ.
    /////
    ///            .entries(self.0.iter().map(|&(ref k, ref v)| (k, v)))
    ///            .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     "{\"A\": 10, \"B\": 11}",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn entries<K, V, I>(&mut self, entries: I) -> &mut Self
    where
        K: fmt::Debug,
        V: fmt::Debug,
        I: IntoIterator<Item = (K, V)>,
    {
        for (k, v) in entries {
            self.entry(&k, &v);
        }
        self
    }

    /// Output ಟ್‌ಪುಟ್ ಮುಗಿಸುತ್ತದೆ ಮತ್ತು ಎದುರಾದ ಯಾವುದೇ ದೋಷವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// `key` `value` ಗೆ ಮೊದಲು ಕರೆ ಮಾಡಬೇಕು ಮತ್ತು `key` ಗೆ ಪ್ರತಿ ಕರೆಯನ್ನು `value` ಗೆ ಅನುಗುಣವಾದ ಕರೆ ಅನುಸರಿಸಬೇಕು.
    /// ಇಲ್ಲದಿದ್ದರೆ ಈ ವಿಧಾನವು panic ಆಗಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_map()
    ///            .entries(self.0.iter().map(|&(ref k, ref v)| (k, v)))
    ///            .finish() // Struct ಫಾರ್ಮ್ಯಾಟಿಂಗ್ ಅನ್ನು ಕೊನೆಗೊಳಿಸುತ್ತದೆ.
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     "{\"A\": 10, \"B\": 11}",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn finish(&mut self) -> fmt::Result {
        self.result.and_then(|_| {
            assert!(!self.has_key, "attempted to finish a map with a partial entry");

            self.fmt.write_str("}")
        })
    }

    fn is_pretty(&self) -> bool {
        self.fmt.alternate()
    }
}