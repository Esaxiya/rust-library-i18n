//! ತಂತಿಗಳನ್ನು ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಲು ಮತ್ತು ಮುದ್ರಿಸಲು ಉಪಯುಕ್ತತೆಗಳು.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// `Formatter::align` ನಿಂದ ಹಿಂತಿರುಗಿಸಲಾದ ಸಂಭಾವ್ಯ ಜೋಡಣೆಗಳು
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// ವಿಷಯಗಳನ್ನು ಎಡ-ಜೋಡಿಸಬೇಕು ಎಂಬ ಸೂಚನೆ.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// ವಿಷಯಗಳನ್ನು ಸರಿಯಾಗಿ ಜೋಡಿಸಬೇಕು ಎಂಬ ಸೂಚನೆ.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// ವಿಷಯಗಳನ್ನು ಕೇಂದ್ರಕ್ಕೆ ಹೊಂದಿಸಬೇಕು ಎಂಬ ಸೂಚನೆ.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// ಫಾರ್ಮ್ಯಾಟರ್ ವಿಧಾನಗಳಿಂದ ಹಿಂತಿರುಗಿದ ಪ್ರಕಾರ.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// ಸಂದೇಶವನ್ನು ಸ್ಟ್ರೀಮ್‌ಗೆ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡುವುದರಿಂದ ಹಿಂತಿರುಗಿಸಲಾದ ದೋಷ ಪ್ರಕಾರ.
///
/// ದೋಷ ಸಂಭವಿಸಿದ ಹೊರತಾಗಿ ದೋಷದ ಪ್ರಸರಣವನ್ನು ಈ ಪ್ರಕಾರವು ಬೆಂಬಲಿಸುವುದಿಲ್ಲ.
/// ಯಾವುದೇ ಹೆಚ್ಚುವರಿ ಮಾಹಿತಿಯನ್ನು ಇತರ ವಿಧಾನಗಳ ಮೂಲಕ ರವಾನಿಸಲು ವ್ಯವಸ್ಥೆ ಮಾಡಬೇಕು.
///
/// ನೆನಪಿಡುವ ಒಂದು ಪ್ರಮುಖ ವಿಷಯವೆಂದರೆ, `fmt::Error` ಪ್ರಕಾರವನ್ನು [`std::io::Error`] ಅಥವಾ [`std::error::Error`] ನೊಂದಿಗೆ ಗೊಂದಲಗೊಳಿಸಬಾರದು, ಅದು ನಿಮಗೆ ಸಹ ವ್ಯಾಪ್ತಿಯಲ್ಲಿರಬಹುದು.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// ಯೂನಿಕೋಡ್-ಸ್ವೀಕರಿಸುವ ಬಫರ್‌ಗಳು ಅಥವಾ ಸ್ಟ್ರೀಮ್‌ಗಳಿಗೆ ಬರೆಯಲು ಅಥವಾ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಲು trait.
///
/// ಈ trait ಯುಟಿಎಫ್-8-ಎನ್ಕೋಡ್ ಮಾಡಿದ ಡೇಟಾವನ್ನು ಮಾತ್ರ ಸ್ವೀಕರಿಸುತ್ತದೆ ಮತ್ತು ಇದು [flushable] ಅಲ್ಲ.
/// ನೀವು ಯುನಿಕೋಡ್ ಅನ್ನು ಮಾತ್ರ ಸ್ವೀಕರಿಸಲು ಬಯಸಿದರೆ ಮತ್ತು ನಿಮಗೆ ಫ್ಲಶಿಂಗ್ ಅಗತ್ಯವಿಲ್ಲದಿದ್ದರೆ, ನೀವು ಈ trait ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಬೇಕು;
/// ಇಲ್ಲದಿದ್ದರೆ ನೀವು [`std::io::Write`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಬೇಕು.
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// ಈ ಬರಹಗಾರನಿಗೆ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಬರೆಯುತ್ತಾರೆ, ಬರಹ ಯಶಸ್ವಿಯಾಗಿದೆಯೆ ಎಂದು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಸಂಪೂರ್ಣ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಯಶಸ್ವಿಯಾಗಿ ಬರೆಯಲಾಗಿದ್ದರೆ ಮಾತ್ರ ಈ ವಿಧಾನವು ಯಶಸ್ವಿಯಾಗಬಹುದು, ಮತ್ತು ಎಲ್ಲಾ ಡೇಟಾವನ್ನು ಬರೆಯುವವರೆಗೆ ಅಥವಾ ದೋಷ ಸಂಭವಿಸುವವರೆಗೆ ಈ ವಿಧಾನವು ಹಿಂತಿರುಗುವುದಿಲ್ಲ.
    ///
    ///
    /// # Errors
    ///
    /// ಈ ಕಾರ್ಯವು [`Error`] ನ ಉದಾಹರಣೆಯನ್ನು ದೋಷದಿಂದ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// ಈ ಬರಹಗಾರನಿಗೆ [`char`] ಬರೆಯುತ್ತದೆ, ಬರಹ ಯಶಸ್ವಿಯಾಗಿದೆಯೆ ಎಂದು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಒಂದೇ [`char`] ಅನ್ನು ಒಂದಕ್ಕಿಂತ ಹೆಚ್ಚು ಬೈಟ್‌ಗಳಂತೆ ಎನ್‌ಕೋಡ್ ಮಾಡಬಹುದು.
    /// ಸಂಪೂರ್ಣ ಬೈಟ್ ಅನುಕ್ರಮವನ್ನು ಯಶಸ್ವಿಯಾಗಿ ಬರೆಯಲಾಗಿದ್ದರೆ ಮಾತ್ರ ಈ ವಿಧಾನವು ಯಶಸ್ವಿಯಾಗಬಹುದು, ಮತ್ತು ಎಲ್ಲಾ ಡೇಟಾವನ್ನು ಬರೆಯುವವರೆಗೆ ಅಥವಾ ದೋಷ ಸಂಭವಿಸುವವರೆಗೆ ಈ ವಿಧಾನವು ಹಿಂತಿರುಗುವುದಿಲ್ಲ.
    ///
    ///
    /// # Errors
    ///
    /// ಈ ಕಾರ್ಯವು [`Error`] ನ ಉದಾಹರಣೆಯನ್ನು ದೋಷದಿಂದ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// ಈ trait ನ ಅನುಷ್ಠಾನಕಾರರೊಂದಿಗೆ [`write!`] ಮ್ಯಾಕ್ರೋ ಬಳಕೆಗೆ ಅಂಟು.
    ///
    /// ಈ ವಿಧಾನವನ್ನು ಸಾಮಾನ್ಯವಾಗಿ ಕೈಯಾರೆ ಆಹ್ವಾನಿಸಬಾರದು, ಬದಲಿಗೆ [`write!`] ಮ್ಯಾಕ್ರೋ ಮೂಲಕ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// ಫಾರ್ಮ್ಯಾಟಿಂಗ್ಗಾಗಿ ಸಂರಚನೆ.
///
/// `Formatter` ಫಾರ್ಮ್ಯಾಟಿಂಗ್‌ಗೆ ಸಂಬಂಧಿಸಿದ ವಿವಿಧ ಆಯ್ಕೆಗಳನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
/// ಬಳಕೆದಾರರು ನೇರವಾಗಿ `ಫಾರ್ಮ್ಯಾಟರ್` ಅನ್ನು ನಿರ್ಮಿಸುವುದಿಲ್ಲ;[`Debug`] ಮತ್ತು [`Display`] ನಂತಹ ಎಲ್ಲಾ ಫಾರ್ಮ್ಯಾಟಿಂಗ್ traits ನ `fmt` ವಿಧಾನಕ್ಕೆ ಒಂದಕ್ಕೆ ರೂಪಾಂತರಗೊಳ್ಳುವ ಉಲ್ಲೇಖವನ್ನು ರವಾನಿಸಲಾಗುತ್ತದೆ.
///
///
/// `Formatter` ನೊಂದಿಗೆ ಸಂವಹನ ನಡೆಸಲು, ಫಾರ್ಮ್ಯಾಟಿಂಗ್‌ಗೆ ಸಂಬಂಧಿಸಿದ ವಿವಿಧ ಆಯ್ಕೆಗಳನ್ನು ಬದಲಾಯಿಸಲು ನೀವು ವಿವಿಧ ವಿಧಾನಗಳನ್ನು ಕರೆಯುತ್ತೀರಿ.
/// ಉದಾಹರಣೆಗಳಿಗಾಗಿ, ದಯವಿಟ್ಟು ಕೆಳಗಿನ `Formatter` ನಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ವಿಧಾನಗಳ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// ವಾದವು ಮೂಲಭೂತವಾಗಿ ಆಪ್ಟಿಮೈಸ್ಡ್ ಭಾಗಶಃ ಅನ್ವಯಿಕ ಫಾರ್ಮ್ಯಾಟಿಂಗ್ ಕಾರ್ಯವಾಗಿದೆ, ಇದು `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ.

extern "C" {
    type Opaque;
}

/// ಈ ರಚನೆಯು ಜೆನೆರಿಕ್ "argument" ಅನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ, ಇದನ್ನು Xprintf ಕುಟುಂಬ ಕಾರ್ಯಗಳಿಂದ ತೆಗೆದುಕೊಳ್ಳಲಾಗುತ್ತದೆ.ಕೊಟ್ಟಿರುವ ಮೌಲ್ಯವನ್ನು ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡುವ ಕಾರ್ಯವನ್ನು ಇದು ಒಳಗೊಂಡಿದೆ.
/// ಕಂಪೈಲ್ ಸಮಯದಲ್ಲಿ ಅದು ಕಾರ್ಯ ಮತ್ತು ಮೌಲ್ಯವು ಸರಿಯಾದ ಪ್ರಕಾರಗಳನ್ನು ಹೊಂದಿದೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲಾಗುತ್ತದೆ, ಮತ್ತು ನಂತರ ಈ ರಚನೆಯನ್ನು ಒಂದು ಪ್ರಕಾರಕ್ಕೆ ವಾದಗಳನ್ನು ಅಂಗೀಕೃತಗೊಳಿಸಲು ಬಳಸಲಾಗುತ್ತದೆ.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// ಫಾರ್ಮ್ಯಾಟಿಂಗ್ ಮೂಲಸೌಕರ್ಯದಲ್ಲಿ indices/counts ಗೆ ಸಂಬಂಧಿಸಿದ ಫಂಕ್ಷನ್ ಪಾಯಿಂಟರ್‌ಗೆ ಇದು ಒಂದೇ ಸ್ಥಿರ ಮೌಲ್ಯವನ್ನು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
//
// ಎಲ್‌ಎಲ್‌ವಿಎಂ ಐಆರ್‌ಗೆ ಪ್ರಸ್ತುತ ಕಡಿಮೆಗೊಳಿಸುವುದರೊಂದಿಗೆ ಕಾರ್ಯಗಳನ್ನು ಯಾವಾಗಲೂ ಹೆಸರಿಸದ_ಎಡಿಆರ್ ಎಂದು ಟ್ಯಾಗ್ ಮಾಡಲಾಗುವುದರಿಂದ, ಹೀಗೆ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ಕಾರ್ಯವು ಸರಿಯಾಗುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಆದ್ದರಿಂದ ಅವುಗಳ ವಿಳಾಸವನ್ನು ಎಲ್‌ಎಲ್‌ವಿಎಂಗೆ ಮುಖ್ಯವೆಂದು ಪರಿಗಣಿಸಲಾಗುವುದಿಲ್ಲ ಮತ್ತು ಅಂತಹ_ಯುಸೈಜ್ ಎರಕಹೊಯ್ದವನ್ನು ತಪ್ಪಾಗಿ ಕಂಪೈಲ್ ಮಾಡಬಹುದಿತ್ತು.
//
// ಪ್ರಾಯೋಗಿಕವಾಗಿ, ನಾವು ಎಂದಿಗೂ ಬಳಕೆಯಾಗದ ಡೇಟಾವನ್ನು (ಫಾರ್ಮ್ಯಾಟಿಂಗ್ ಆರ್ಗ್ಯುಮೆಂಟ್‌ಗಳ ಸ್ಥಿರ ಪೀಳಿಗೆಯ ವಿಷಯವಾಗಿ) as_usize ಎಂದು ಕರೆಯುವುದಿಲ್ಲ, ಆದ್ದರಿಂದ ಇದು ಕೇವಲ ಹೆಚ್ಚುವರಿ ಪರಿಶೀಲನೆಯಾಗಿದೆ.
//
// `USIZE_MARKER` ನಲ್ಲಿನ ಫಂಕ್ಷನ್ ಪಾಯಿಂಟರ್ `&usize` ಅನ್ನು ಅವರ ಮೊದಲ ಆರ್ಗ್ಯುಮೆಂಟ್ ಆಗಿ ತೆಗೆದುಕೊಳ್ಳುವ ಫಂಕ್ಷನ್‌ಗಳಿಗೆ ಅನುಗುಣವಾದ *ಮಾತ್ರ* ವಿಳಾಸವನ್ನು ಹೊಂದಿದೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ನಾವು ಬಯಸುತ್ತೇವೆ.
// ಅಂಗೀಕರಿಸಿದ ಉಲ್ಲೇಖದಿಂದ ನಾವು ಸುರಕ್ಷಿತವಾಗಿ ಬಳಕೆಯನ್ನು ಸಿದ್ಧಪಡಿಸಬಹುದು ಮತ್ತು ಈ ವಿಳಾಸವು ಬಳಕೆಯಾಗದ ತೆಗೆದುಕೊಳ್ಳುವ ಕಾರ್ಯವನ್ನು ಸೂಚಿಸುವುದಿಲ್ಲ ಎಂದು ಇಲ್ಲಿರುವ read_volatile ಖಚಿತಪಡಿಸುತ್ತದೆ.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // ಸುರಕ್ಷತೆ: ಪಿಟಿಆರ್ ಒಂದು ಉಲ್ಲೇಖವಾಗಿದೆ
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // ಸುರಕ್ಷತೆ: `mem::transmute(x)` ಸುರಕ್ಷಿತವಾಗಿದೆ
        //     1. `&'b T` ಇದು `'b` ನೊಂದಿಗೆ ಹುಟ್ಟಿದ ಜೀವಿತಾವಧಿಯನ್ನು ಉಳಿಸುತ್ತದೆ (ಆದ್ದರಿಂದ ಮಿತಿಯಿಲ್ಲದ ಜೀವಿತಾವಧಿಯನ್ನು ಹೊಂದಿರದಂತೆ)
        //     2.
        //     `&'b T` ಮತ್ತು `&'b Opaque` ಒಂದೇ ರೀತಿಯ ಮೆಮೊರಿ ವಿನ್ಯಾಸವನ್ನು ಹೊಂದಿರುತ್ತದೆ (`T` `Sized` ಆಗಿರುವಾಗ, ಇಲ್ಲಿರುವಂತೆ) `fn(&T, &mut Formatter<'_>) -> Result` ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ `fn(&T, &mut Formatter<'_>) -> Result` ಮತ್ತು `fn(&Opaque, &mut Formatter<'_>) -> Result` ಒಂದೇ ಎಬಿಐ ಅನ್ನು ಹೊಂದಿರುತ್ತವೆ (`T` ಎಲ್ಲಿಯವರೆಗೆ `Sized` ಆಗಿರುತ್ತದೆ)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // ಸುರಕ್ಷತೆ: `formatter` ಕ್ಷೇತ್ರವನ್ನು USIZE_MARKER ಗೆ ಮಾತ್ರ ಹೊಂದಿಸಲಾಗಿದೆ
            // ಮೌಲ್ಯವು ಬಳಕೆಯಾಗಿದೆ, ಆದ್ದರಿಂದ ಇದು ಸುರಕ್ಷಿತವಾಗಿದೆ
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// ಫಾರ್ಮ್ಯಾಟ್_ಆರ್ಗ್ಸ್‌ನ v1 ಸ್ವರೂಪದಲ್ಲಿ ಧ್ವಜಗಳು ಲಭ್ಯವಿದೆ
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// ಫಾರ್ಮ್ಯಾಟ್_ಆರ್ಗ್ಸ್! () ಮ್ಯಾಕ್ರೋವನ್ನು ಬಳಸುವಾಗ, ಆರ್ಗ್ಯುಮೆಂಟ್ಸ್ ರಚನೆಯನ್ನು ರಚಿಸಲು ಈ ಕಾರ್ಯವನ್ನು ಬಳಸಲಾಗುತ್ತದೆ.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// ಪ್ರಮಾಣಿತವಲ್ಲದ ಫಾರ್ಮ್ಯಾಟಿಂಗ್ ನಿಯತಾಂಕಗಳನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಲು ಈ ಕಾರ್ಯವನ್ನು ಬಳಸಲಾಗುತ್ತದೆ.
    /// ಮಾನ್ಯ ವಾದಗಳ ರಚನೆಯನ್ನು ನಿರ್ಮಿಸಲು `pieces` ರಚನೆಯು ಕನಿಷ್ಠ `fmt` ವರೆಗೆ ಇರಬೇಕು.
    /// ಅಲ್ಲದೆ, `fmt` ಒಳಗೆ `fmt` ಅಥವಾ `CountIsNextParam` ಆಗಿರುವ ಯಾವುದೇ `Count` `argumentusize` ನೊಂದಿಗೆ ರಚಿಸಲಾದ ಆರ್ಗ್ಯುಮೆಂಟ್ ಅನ್ನು ಸೂಚಿಸಬೇಕಾಗುತ್ತದೆ.
    ///
    /// ಆದಾಗ್ಯೂ, ಹಾಗೆ ಮಾಡಲು ವಿಫಲವಾದರೆ ಅಸುರಕ್ಷಿತತೆಗೆ ಕಾರಣವಾಗುವುದಿಲ್ಲ, ಆದರೆ ಅಮಾನ್ಯತೆಯನ್ನು ನಿರ್ಲಕ್ಷಿಸುತ್ತದೆ.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಿದ ಪಠ್ಯದ ಉದ್ದವನ್ನು ಅಂದಾಜು ಮಾಡುತ್ತದೆ.
    ///
    /// `format!` ಬಳಸುವಾಗ ಆರಂಭಿಕ `String` ಸಾಮರ್ಥ್ಯವನ್ನು ಹೊಂದಿಸಲು ಇದನ್ನು ಬಳಸಲು ಉದ್ದೇಶಿಸಲಾಗಿದೆ.
    /// Note: ಇದು ಕಡಿಮೆ ಅಥವಾ ಮೇಲಿನ ಬೌಂಡ್ ಅಲ್ಲ.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // ಫಾರ್ಮ್ಯಾಟ್ ಸ್ಟ್ರಿಂಗ್ ಆರ್ಗ್ಯುಮೆಂಟ್‌ನೊಂದಿಗೆ ಪ್ರಾರಂಭವಾಗಿದ್ದರೆ, ತುಣುಕುಗಳ ಉದ್ದವು ಮಹತ್ವದ್ದಾಗಿರದ ಹೊರತು ಯಾವುದನ್ನೂ ಪೂರ್ವ ನಿಯೋಜಿಸಬೇಡಿ.
            //
            //
            0
        } else {
            // ಕೆಲವು ವಾದಗಳಿವೆ, ಆದ್ದರಿಂದ ಯಾವುದೇ ಹೆಚ್ಚುವರಿ ಪುಶ್ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಮರುಹಂಚಿಕೆ ಮಾಡುತ್ತದೆ.
            //
            // ಅದನ್ನು ತಪ್ಪಿಸಲು, ನಾವು ಇಲ್ಲಿ "pre-doubling" ಸಾಮರ್ಥ್ಯವನ್ನು ಹೊಂದಿದ್ದೇವೆ.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// ಈ ರಚನೆಯು ಫಾರ್ಮ್ಯಾಟ್ ಸ್ಟ್ರಿಂಗ್ ಮತ್ತು ಅದರ ವಾದಗಳ ಸುರಕ್ಷಿತವಾಗಿ ಪೂರ್ವ ಸಿದ್ಧಪಡಿಸಿದ ಆವೃತ್ತಿಯನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
/// ರನ್ಟೈಮ್ನಲ್ಲಿ ಇದನ್ನು ಉತ್ಪಾದಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ ಏಕೆಂದರೆ ಇದನ್ನು ಸುರಕ್ಷಿತವಾಗಿ ಮಾಡಲು ಸಾಧ್ಯವಿಲ್ಲ, ಆದ್ದರಿಂದ ಯಾವುದೇ ನಿರ್ಮಾಣಕಾರರನ್ನು ನೀಡಲಾಗುವುದಿಲ್ಲ ಮತ್ತು ಮಾರ್ಪಾಡುಗಳನ್ನು ತಡೆಯಲು ಕ್ಷೇತ್ರಗಳು ಖಾಸಗಿಯಾಗಿರುತ್ತವೆ.
///
///
/// [`format_args!`] ಮ್ಯಾಕ್ರೋ ಈ ರಚನೆಯ ಉದಾಹರಣೆಯನ್ನು ಸುರಕ್ಷಿತವಾಗಿ ರಚಿಸುತ್ತದೆ.
/// ಮ್ಯಾಕ್ರೋ ಫಾರ್ಮ್ಯಾಟ್ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಕಂಪೈಲ್ ಸಮಯದಲ್ಲಿ ಮೌಲ್ಯೀಕರಿಸುತ್ತದೆ ಆದ್ದರಿಂದ [`write()`] ಮತ್ತು [`format()`] ಕಾರ್ಯಗಳ ಬಳಕೆಯನ್ನು ಸುರಕ್ಷಿತವಾಗಿ ನಿರ್ವಹಿಸಬಹುದು.
///
/// ಕೆಳಗೆ ನೋಡಿದಂತೆ `Debug` ಮತ್ತು `Display` ಸನ್ನಿವೇಶಗಳಲ್ಲಿ [`format_args!`] ಹಿಂದಿರುಗಿಸುವ `Arguments<'a>` ಅನ್ನು ನೀವು ಬಳಸಬಹುದು.
/// ಉದಾಹರಣೆಯು `Debug` ಮತ್ತು `Display` ಸ್ವರೂಪವನ್ನು ಒಂದೇ ವಿಷಯಕ್ಕೆ ತೋರಿಸುತ್ತದೆ: `format_args!` ನಲ್ಲಿ ಇಂಟರ್ಪೋಲೇಟೆಡ್ ಫಾರ್ಮ್ಯಾಟ್ ಸ್ಟ್ರಿಂಗ್.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // ಸ್ಟ್ರಿಂಗ್ ತುಣುಕುಗಳನ್ನು ಮುದ್ರಿಸಲು ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಿ.
    pieces: &'a [&'static str],

    // ಪ್ಲೇಸ್‌ಹೋಲ್ಡರ್ ಸ್ಪೆಕ್ಸ್, ಅಥವಾ ಎಲ್ಲಾ ಸ್ಪೆಕ್ಸ್ ಡೀಫಾಲ್ಟ್ ಆಗಿದ್ದರೆ `None` ("{}{}" ನಂತೆ).
    fmt: Option<&'a [rt::v1::Argument]>,

    // ಸ್ಟ್ರಿಂಗ್ ತುಣುಕುಗಳೊಂದಿಗೆ ಇಂಟರ್ಲೀವ್ ಮಾಡಲು ಇಂಟರ್ಪೋಲೇಷನ್ಗಾಗಿ ಡೈನಾಮಿಕ್ ಆರ್ಗ್ಯುಮೆಂಟ್ಸ್.
    // (ಪ್ರತಿಯೊಂದು ವಾದಕ್ಕೂ ಮೊದಲು ಸ್ಟ್ರಿಂಗ್ ತುಣುಕು ಇರುತ್ತದೆ.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಲು ಯಾವುದೇ ಆರ್ಗ್ಯುಮೆಂಟ್‌ಗಳಿಲ್ಲದಿದ್ದರೆ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಿದ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಪಡೆಯಿರಿ.
    ///
    /// ಅತ್ಯಂತ ಕ್ಷುಲ್ಲಕ ಸಂದರ್ಭದಲ್ಲಿ ಹಂಚಿಕೆಗಳನ್ನು ತಪ್ಪಿಸಲು ಇದನ್ನು ಬಳಸಬಹುದು.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` ಪ್ರೋಗ್ರಾಮರ್-ಎದುರಿಸುತ್ತಿರುವ, ಡೀಬಗ್ ಮಾಡುವ ಸಂದರ್ಭದಲ್ಲಿ output ಟ್‌ಪುಟ್ ಅನ್ನು ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಬೇಕು.
///
/// ಸಾಮಾನ್ಯವಾಗಿ ಹೇಳುವುದಾದರೆ, ನೀವು ಕೇವಲ `derive` `Debug` ಅನುಷ್ಠಾನವನ್ನು ಮಾಡಬೇಕು.
///
/// ಪರ್ಯಾಯ ಸ್ವರೂಪ ಸ್ಪೆಸಿಫೈಯರ್ `#?` ನೊಂದಿಗೆ ಬಳಸಿದಾಗ, output ಟ್‌ಪುಟ್ ಅನ್ನು ಸಾಕಷ್ಟು ಮುದ್ರಿಸಲಾಗುತ್ತದೆ.
///
/// ಫಾರ್ಮ್ಯಾಟರ್‌ಗಳ ಕುರಿತು ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ, [the module-level documentation][module] ನೋಡಿ.
///
/// [module]: ../../std/fmt/index.html
///
/// ಎಲ್ಲಾ ಕ್ಷೇತ್ರಗಳು `Debug` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದರೆ ಈ trait ಅನ್ನು `#[derive]` ನೊಂದಿಗೆ ಬಳಸಬಹುದು.
/// ಸ್ಟ್ರಕ್ಟ್‌ಗಳಿಗಾಗಿ `ಡಿರೈವ್` ಮಾಡಿದಾಗ, ಅದು `struct`, ನಂತರ `{`, ನಂತರ ಪ್ರತಿ ಕ್ಷೇತ್ರದ ಹೆಸರಿನ ಅಲ್ಪವಿರಾಮದಿಂದ ಬೇರ್ಪಟ್ಟ ಪಟ್ಟಿ ಮತ್ತು `Debug` ಮೌಲ್ಯ, ನಂತರ `}` ಅನ್ನು ಬಳಸುತ್ತದೆ.
/// `ಎನಮ್'ಗಳಿಗಾಗಿ, ಇದು ರೂಪಾಂತರದ ಹೆಸರನ್ನು ಬಳಸುತ್ತದೆ ಮತ್ತು ಅನ್ವಯಿಸಿದರೆ, `(`, ನಂತರ ಕ್ಷೇತ್ರಗಳ `Debug` ಮೌಲ್ಯಗಳು, ನಂತರ `)`.
///
/// # Stability
///
/// ಪಡೆದ `Debug` ಸ್ವರೂಪಗಳು ಸ್ಥಿರವಾಗಿಲ್ಲ, ಮತ್ತು ಆದ್ದರಿಂದ future Rust ಆವೃತ್ತಿಗಳೊಂದಿಗೆ ಬದಲಾಗಬಹುದು.
/// ಹೆಚ್ಚುವರಿಯಾಗಿ, ಸ್ಟ್ಯಾಂಡರ್ಡ್ ಲೈಬ್ರರಿಯಿಂದ ಒದಗಿಸಲಾದ ಪ್ರಕಾರಗಳ `Debug` ಅನುಷ್ಠಾನಗಳು (`libstd`, `libcore`, `liballoc`, ಇತ್ಯಾದಿ) ಸ್ಥಿರವಾಗಿಲ್ಲ, ಮತ್ತು future Rust ಆವೃತ್ತಿಗಳೊಂದಿಗೆ ಸಹ ಬದಲಾಗಬಹುದು.
///
///
/// # Examples
///
/// ಅನುಷ್ಠಾನವನ್ನು ಪಡೆಯುವುದು:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// ಹಸ್ತಚಾಲಿತವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸುವುದು:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// [`debug_struct`] ನಂತಹ ಹಸ್ತಚಾಲಿತ ಅನುಷ್ಠಾನಗಳಿಗೆ ನಿಮಗೆ ಸಹಾಯ ಮಾಡಲು [`Formatter`] struct ನಲ್ಲಿ ಹಲವಾರು ಸಹಾಯಕ ವಿಧಾನಗಳಿವೆ.
///
/// `Debug` `derive` ಅಥವಾ [`Formatter`] ನಲ್ಲಿ ಡೀಬಗ್ ಬಿಲ್ಡರ್ API ಅನ್ನು ಬಳಸುವ ಅನುಷ್ಠಾನಗಳು ಪರ್ಯಾಯ ಧ್ವಜವನ್ನು ಬಳಸಿಕೊಂಡು ಸಾಕಷ್ಟು ಮುದ್ರಣವನ್ನು ಬೆಂಬಲಿಸುತ್ತವೆ: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// `#?` ನೊಂದಿಗೆ ಸಾಕಷ್ಟು ಮುದ್ರಣ:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// ಕೊಟ್ಟಿರುವ ಫಾರ್ಮ್ಯಾಟರ್ ಬಳಸಿ ಮೌಲ್ಯವನ್ನು ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// trait `Debug` ಇಲ್ಲದೆ prelude ನಿಂದ ಮ್ಯಾಕ್ರೋ `Debug` ಅನ್ನು ಮರು ರಫ್ತು ಮಾಡಲು ಪ್ರತ್ಯೇಕ ಮಾಡ್ಯೂಲ್.
pub(crate) mod macros {
    /// trait `Debug` ನ ಇಂಪಲ್ ಅನ್ನು ಉತ್ಪಾದಿಸುವ ಮ್ಯಾಕ್ರೋ ಅನ್ನು ಪಡೆಯಿರಿ.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// ಖಾಲಿ ಸ್ವರೂಪಕ್ಕಾಗಿ trait ಅನ್ನು ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಿ, `{}`.
///
/// `Display` ಇದು [`Debug`] ಗೆ ಹೋಲುತ್ತದೆ, ಆದರೆ `Display` ಬಳಕೆದಾರ-ಮುಖದ output ಟ್‌ಪುಟ್‌ಗಾಗಿರುತ್ತದೆ ಮತ್ತು ಅದನ್ನು ಪಡೆಯಲಾಗುವುದಿಲ್ಲ.
///
///
/// ಫಾರ್ಮ್ಯಾಟರ್‌ಗಳ ಕುರಿತು ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ, [the module-level documentation][module] ನೋಡಿ.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ಒಂದು ಪ್ರಕಾರದಲ್ಲಿ `Display` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದು:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// ಕೊಟ್ಟಿರುವ ಫಾರ್ಮ್ಯಾಟರ್ ಬಳಸಿ ಮೌಲ್ಯವನ್ನು ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait ಅದರ output ಟ್‌ಪುಟ್ ಅನ್ನು base-8 ನಲ್ಲಿ ಒಂದು ಸಂಖ್ಯೆಯಂತೆ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಬೇಕು.
///
/// ಪ್ರಾಚೀನ ಸಹಿ ಮಾಡಿದ ಪೂರ್ಣಾಂಕಗಳಿಗಾಗಿ (`i8` ರಿಂದ `i128`, ಮತ್ತು `isize`), negative ಣಾತ್ಮಕ ಮೌಲ್ಯಗಳನ್ನು ಇಬ್ಬರ ಪೂರಕ ಪ್ರಾತಿನಿಧ್ಯವಾಗಿ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಲಾಗುತ್ತದೆ.
///
///
/// ಧ್ವಜ, `#`, X ಟ್‌ಪುಟ್‌ನ ಮುಂದೆ `0o` ಅನ್ನು ಸೇರಿಸುತ್ತದೆ.
///
/// ಫಾರ್ಮ್ಯಾಟರ್‌ಗಳ ಕುರಿತು ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ, [the module-level documentation][module] ನೋಡಿ.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` ನೊಂದಿಗೆ ಮೂಲ ಬಳಕೆ:
///
/// ```
/// let x = 42; // 42 ಆಕ್ಟಲ್‌ನಲ್ಲಿ '52' ಆಗಿದೆ
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// ಒಂದು ಪ್ರಕಾರದಲ್ಲಿ `Octal` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದು:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // i32 ನ ಅನುಷ್ಠಾನಕ್ಕೆ ಪ್ರತಿನಿಧಿ
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// ಕೊಟ್ಟಿರುವ ಫಾರ್ಮ್ಯಾಟರ್ ಬಳಸಿ ಮೌಲ್ಯವನ್ನು ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡುತ್ತದೆ.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait ಅದರ output ಟ್‌ಪುಟ್ ಅನ್ನು ಬೈನರಿನಲ್ಲಿ ಸಂಖ್ಯೆಯಾಗಿ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಬೇಕು.
///
/// ಪ್ರಾಚೀನ ಸಹಿ ಮಾಡಿದ ಪೂರ್ಣಾಂಕಗಳಿಗಾಗಿ ([`i8`] ರಿಂದ [`i128`], ಮತ್ತು [`isize`]), negative ಣಾತ್ಮಕ ಮೌಲ್ಯಗಳನ್ನು ಇಬ್ಬರ ಪೂರಕ ಪ್ರಾತಿನಿಧ್ಯವಾಗಿ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಲಾಗುತ್ತದೆ.
///
///
/// ಧ್ವಜ, `#`, X ಟ್‌ಪುಟ್‌ನ ಮುಂದೆ `0b` ಅನ್ನು ಸೇರಿಸುತ್ತದೆ.
///
/// ಫಾರ್ಮ್ಯಾಟರ್‌ಗಳ ಕುರಿತು ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ, [the module-level documentation][module] ನೋಡಿ.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// [`i32`] ನೊಂದಿಗೆ ಮೂಲ ಬಳಕೆ:
///
/// ```
/// let x = 42; // 42 ಬೈನರಿನಲ್ಲಿ '101010' ಆಗಿದೆ
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// ಒಂದು ಪ್ರಕಾರದಲ್ಲಿ `Binary` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದು:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // i32 ನ ಅನುಷ್ಠಾನಕ್ಕೆ ಪ್ರತಿನಿಧಿ
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// ಕೊಟ್ಟಿರುವ ಫಾರ್ಮ್ಯಾಟರ್ ಬಳಸಿ ಮೌಲ್ಯವನ್ನು ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡುತ್ತದೆ.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait ಅದರ output ಟ್‌ಪುಟ್ ಅನ್ನು ಹೆಕ್ಸಾಡೆಸಿಮಲ್‌ನಲ್ಲಿ ಒಂದು ಸಂಖ್ಯೆಯಂತೆ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಬೇಕು, `a` ಮೂಲಕ `f` ಮೂಲಕ ಲೋವರ್ ಕೇಸ್‌ನಲ್ಲಿ.
///
/// ಪ್ರಾಚೀನ ಸಹಿ ಮಾಡಿದ ಪೂರ್ಣಾಂಕಗಳಿಗಾಗಿ (`i8` ರಿಂದ `i128`, ಮತ್ತು `isize`), negative ಣಾತ್ಮಕ ಮೌಲ್ಯಗಳನ್ನು ಇಬ್ಬರ ಪೂರಕ ಪ್ರಾತಿನಿಧ್ಯವಾಗಿ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಲಾಗುತ್ತದೆ.
///
///
/// ಧ್ವಜ, `#`, X ಟ್‌ಪುಟ್‌ನ ಮುಂದೆ `0x` ಅನ್ನು ಸೇರಿಸುತ್ತದೆ.
///
/// ಫಾರ್ಮ್ಯಾಟರ್‌ಗಳ ಕುರಿತು ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ, [the module-level documentation][module] ನೋಡಿ.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` ನೊಂದಿಗೆ ಮೂಲ ಬಳಕೆ:
///
/// ```
/// let x = 42; // 42 ಹೆಕ್ಸ್ನಲ್ಲಿ '2a' ಆಗಿದೆ
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// ಒಂದು ಪ್ರಕಾರದಲ್ಲಿ `LowerHex` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದು:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // i32 ನ ಅನುಷ್ಠಾನಕ್ಕೆ ಪ್ರತಿನಿಧಿ
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// ಕೊಟ್ಟಿರುವ ಫಾರ್ಮ್ಯಾಟರ್ ಬಳಸಿ ಮೌಲ್ಯವನ್ನು ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡುತ್ತದೆ.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait ಅದರ output ಟ್‌ಪುಟ್ ಅನ್ನು ಹೆಕ್ಸಾಡೆಸಿಮಲ್‌ನಲ್ಲಿ ಒಂದು ಸಂಖ್ಯೆಯಂತೆ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಬೇಕು, `A` ಮೂಲಕ `F` ಮೂಲಕ ಮೇಲಿನ ಸಂದರ್ಭದಲ್ಲಿ.
///
/// ಪ್ರಾಚೀನ ಸಹಿ ಮಾಡಿದ ಪೂರ್ಣಾಂಕಗಳಿಗಾಗಿ (`i8` ರಿಂದ `i128`, ಮತ್ತು `isize`), negative ಣಾತ್ಮಕ ಮೌಲ್ಯಗಳನ್ನು ಇಬ್ಬರ ಪೂರಕ ಪ್ರಾತಿನಿಧ್ಯವಾಗಿ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಲಾಗುತ್ತದೆ.
///
///
/// ಧ್ವಜ, `#`, X ಟ್‌ಪುಟ್‌ನ ಮುಂದೆ `0x` ಅನ್ನು ಸೇರಿಸುತ್ತದೆ.
///
/// ಫಾರ್ಮ್ಯಾಟರ್‌ಗಳ ಕುರಿತು ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ, [the module-level documentation][module] ನೋಡಿ.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` ನೊಂದಿಗೆ ಮೂಲ ಬಳಕೆ:
///
/// ```
/// let x = 42; // 42 ಹೆಕ್ಸ್ನಲ್ಲಿ '2A' ಆಗಿದೆ
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// ಒಂದು ಪ್ರಕಾರದಲ್ಲಿ `UpperHex` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದು:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // i32 ನ ಅನುಷ್ಠಾನಕ್ಕೆ ಪ್ರತಿನಿಧಿ
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// ಕೊಟ್ಟಿರುವ ಫಾರ್ಮ್ಯಾಟರ್ ಬಳಸಿ ಮೌಲ್ಯವನ್ನು ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡುತ್ತದೆ.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait ಅದರ output ಟ್‌ಪುಟ್ ಅನ್ನು ಮೆಮೊರಿ ಸ್ಥಳವಾಗಿ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಬೇಕು.
/// ಇದನ್ನು ಸಾಮಾನ್ಯವಾಗಿ ಹೆಕ್ಸಾಡೆಸಿಮಲ್ ಎಂದು ಪ್ರಸ್ತುತಪಡಿಸಲಾಗುತ್ತದೆ.
///
/// ಫಾರ್ಮ್ಯಾಟರ್‌ಗಳ ಕುರಿತು ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ, [the module-level documentation][module] ನೋಡಿ.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `&i32` ನೊಂದಿಗೆ ಮೂಲ ಬಳಕೆ:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // ಇದು '0x7f06092ac6d0' ನಂತಹದನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ
/// ```
///
/// ಒಂದು ಪ್ರಕಾರದಲ್ಲಿ `Pointer` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದು:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // `*const T` ಗೆ ಪರಿವರ್ತಿಸಲು `as` ಅನ್ನು ಬಳಸಿ, ಅದು ನಾವು ಬಳಸಬಹುದಾದ ಪಾಯಿಂಟರ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// ಕೊಟ್ಟಿರುವ ಫಾರ್ಮ್ಯಾಟರ್ ಬಳಸಿ ಮೌಲ್ಯವನ್ನು ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡುತ್ತದೆ.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait ಅದರ ಉತ್ಪಾದನೆಯನ್ನು ವೈಜ್ಞಾನಿಕ ಸಂಕೇತಗಳಲ್ಲಿ ಲೋವರ್-ಕೇಸ್ `e` ನೊಂದಿಗೆ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಬೇಕು.
///
/// ಫಾರ್ಮ್ಯಾಟರ್‌ಗಳ ಕುರಿತು ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ, [the module-level documentation][module] ನೋಡಿ.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` ನೊಂದಿಗೆ ಮೂಲ ಬಳಕೆ:
///
/// ```
/// let x = 42.0; // 42.0 ವೈಜ್ಞಾನಿಕ ಸಂಕೇತದಲ್ಲಿ '4.2e1' ಆಗಿದೆ
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// ಒಂದು ಪ್ರಕಾರದಲ್ಲಿ `LowerExp` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದು:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // f64 ನ ಅನುಷ್ಠಾನಕ್ಕೆ ಪ್ರತಿನಿಧಿ
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// ಕೊಟ್ಟಿರುವ ಫಾರ್ಮ್ಯಾಟರ್ ಬಳಸಿ ಮೌಲ್ಯವನ್ನು ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡುತ್ತದೆ.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait ಅದರ ಉತ್ಪಾದನೆಯನ್ನು ವೈಜ್ಞಾನಿಕ ಸಂಕೇತಗಳಲ್ಲಿ ದೊಡ್ಡಕ್ಷರ `E` ನೊಂದಿಗೆ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಬೇಕು.
///
/// ಫಾರ್ಮ್ಯಾಟರ್‌ಗಳ ಕುರಿತು ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ, [the module-level documentation][module] ನೋಡಿ.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` ನೊಂದಿಗೆ ಮೂಲ ಬಳಕೆ:
///
/// ```
/// let x = 42.0; // 42.0 ವೈಜ್ಞಾನಿಕ ಸಂಕೇತದಲ್ಲಿ '4.2E1' ಆಗಿದೆ
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// ಒಂದು ಪ್ರಕಾರದಲ್ಲಿ `UpperExp` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದು:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // f64 ನ ಅನುಷ್ಠಾನಕ್ಕೆ ಪ್ರತಿನಿಧಿ
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// ಕೊಟ್ಟಿರುವ ಫಾರ್ಮ್ಯಾಟರ್ ಬಳಸಿ ಮೌಲ್ಯವನ್ನು ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡುತ್ತದೆ.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `write` ಕಾರ್ಯವು output ಟ್‌ಪುಟ್ ಸ್ಟ್ರೀಮ್ ಅನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ, ಮತ್ತು `Arguments` ಸ್ಟ್ರಕ್ಟ್‌ನ್ನು `format_args!` ಮ್ಯಾಕ್ರೊದೊಂದಿಗೆ ಪೂರ್ವ ಕಂಪೈಲ್ ಮಾಡಬಹುದು.
///
///
/// ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಫಾರ್ಮ್ಯಾಟ್ ಸ್ಟ್ರಿಂಗ್‌ಗೆ ಅನುಗುಣವಾಗಿ ಒದಗಿಸಲಾದ stream ಟ್‌ಪುಟ್ ಸ್ಟ್ರೀಮ್‌ಗೆ ವಾದಗಳನ್ನು ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಲಾಗುತ್ತದೆ.
///
/// # Examples
///
/// ಮೂಲ ಬಳಕೆ:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// [`write!`] ಅನ್ನು ಬಳಸುವುದು ಯೋಗ್ಯವಾಗಿದೆ ಎಂಬುದನ್ನು ದಯವಿಟ್ಟು ಗಮನಿಸಿ.ಉದಾಹರಣೆ:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // ಎಲ್ಲಾ ಆರ್ಗ್ಯುಮೆಂಟ್‌ಗಳಿಗೆ ನಾವು ಡೀಫಾಲ್ಟ್ ಫಾರ್ಮ್ಯಾಟಿಂಗ್ ನಿಯತಾಂಕಗಳನ್ನು ಬಳಸಬಹುದು.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // ಪ್ರತಿಯೊಂದು ಸ್ಪೆಕ್‌ಗೆ ಅನುಗುಣವಾದ ಆರ್ಗ್ಯುಮೆಂಟ್ ಇದ್ದು ಅದು ಸ್ಟ್ರಿಂಗ್ ಪೀಸ್‌ನಿಂದ ಮುಂಚಿತವಾಗಿರುತ್ತದೆ.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // ಸುರಕ್ಷತೆ: ಆರ್ಗ್ ಮತ್ತು ಎಕ್ಸ್ 00 ಎಕ್ಸ್ ಒಂದೇ ವಾದಗಳಿಂದ ಬಂದವು,
                // ಇದು ಸೂಚ್ಯಂಕಗಳು ಯಾವಾಗಲೂ ಮಿತಿಯಲ್ಲಿರುತ್ತವೆ ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // ಕೇವಲ ಒಂದು ಹಿಂದುಳಿದ ಸ್ಟ್ರಿಂಗ್ ತುಂಡು ಉಳಿದಿರಬಹುದು.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // ಸುರಕ್ಷತೆ: ಆರ್ಗ್ ಮತ್ತು ಆರ್ಗ್‌ಗಳು ಒಂದೇ ವಾದಗಳಿಂದ ಬಂದವು,
    // ಇದು ಸೂಚ್ಯಂಕಗಳು ಯಾವಾಗಲೂ ಮಿತಿಯಲ್ಲಿರುತ್ತವೆ ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // ಸರಿಯಾದ ವಾದವನ್ನು ಹೊರತೆಗೆಯಿರಿ
    debug_assert!(arg.position < args.len());
    // ಸುರಕ್ಷತೆ: ಆರ್ಗ್ ಮತ್ತು ಆರ್ಗ್‌ಗಳು ಒಂದೇ ವಾದಗಳಿಂದ ಬಂದವು,
    // ಅದರ ಸೂಚ್ಯಂಕವು ಯಾವಾಗಲೂ ಮಿತಿಯಲ್ಲಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
    let value = unsafe { args.get_unchecked(arg.position) };

    // ನಂತರ ವಾಸ್ತವವಾಗಿ ಕೆಲವು ಮುದ್ರಣವನ್ನು ಮಾಡಿ
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // ಸುರಕ್ಷತೆ: cnt ಮತ್ತು args ಒಂದೇ ವಾದಗಳಿಂದ ಬಂದವು,
            // ಈ ಸೂಚ್ಯಂಕವು ಯಾವಾಗಲೂ ಮಿತಿಯಲ್ಲಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// ಏನಾದರೂ ಮುಗಿದ ನಂತರ ಪ್ಯಾಡಿಂಗ್.`Formatter::padding` ನಿಂದ ಹಿಂತಿರುಗಿಸಲಾಗಿದೆ.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// ಈ ಪೋಸ್ಟ್ ಪ್ಯಾಡಿಂಗ್ ಬರೆಯಿರಿ.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // ಇದನ್ನು ಬದಲಾಯಿಸಲು ನಾವು ಬಯಸುತ್ತೇವೆ
            buf: wrap(self.buf),

            // ಮತ್ತು ಇವುಗಳನ್ನು ಸಂರಕ್ಷಿಸಿ
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // ಎಲ್ಲಾ ಫಾರ್ಮ್ಯಾಟಿಂಗ್ traits ಬಳಸಬಹುದಾದ ಫಾರ್ಮ್ಯಾಟಿಂಗ್ ಆರ್ಗ್ಯುಮೆಂಟ್‌ಗಳನ್ನು ಪ್ಯಾಡಿಂಗ್ ಮತ್ತು ಪ್ರಕ್ರಿಯೆಗೆ ಬಳಸುವ ಸಹಾಯಕ ವಿಧಾನಗಳು.
    //

    /// ಈಗಾಗಲೇ ಸ್ಟ್ರಿಂಗ್ ಆಗಿ ಹೊರಸೂಸಲ್ಪಟ್ಟ ಒಂದು ಪೂರ್ಣಾಂಕಕ್ಕಾಗಿ ಸರಿಯಾದ ಪ್ಯಾಡಿಂಗ್ ಅನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
    /// ಸ್ಟ್ರಿಂಗ್ ಪೂರ್ಣಾಂಕದ ಚಿಹ್ನೆಯನ್ನು *ಹೊಂದಿರಬಾರದು*, ಅದನ್ನು ಈ ವಿಧಾನದಿಂದ ಸೇರಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, ಮೂಲ ಪೂರ್ಣಾಂಕವು ಧನಾತ್ಮಕ ಅಥವಾ ಶೂನ್ಯವಾಗಿದೆಯೆ.
    /// * ಪೂರ್ವಪ್ರತ್ಯಯ, '#' ಅಕ್ಷರ (Alternate) ಅನ್ನು ಒದಗಿಸಿದರೆ, ಇದು ಸಂಖ್ಯೆಯ ಮುಂದೆ ಇರಿಸಲು ಪೂರ್ವಪ್ರತ್ಯಯವಾಗಿದೆ.
    ///
    /// * buf, ಸಂಖ್ಯೆಯನ್ನು ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಿದ ಬೈಟ್ ಅರೇ
    ///
    /// ಈ ಕಾರ್ಯವು ಒದಗಿಸಿದ ಧ್ವಜಗಳಿಗೆ ಮತ್ತು ಕನಿಷ್ಠ ಅಗಲಕ್ಕೆ ಸರಿಯಾಗಿ ಕಾರಣವಾಗುತ್ತದೆ.
    /// ಇದು ನಿಖರತೆಯನ್ನು ಗಣನೆಗೆ ತೆಗೆದುಕೊಳ್ಳುವುದಿಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // ನಾವು ಸಂಖ್ಯೆಯ .ಟ್‌ಪುಟ್‌ನಿಂದ "-" ಅನ್ನು ತೆಗೆದುಹಾಕಬೇಕಾಗಿದೆ.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // ಚಿಹ್ನೆ ಅಸ್ತಿತ್ವದಲ್ಲಿದ್ದರೆ ಅದನ್ನು ಬರೆಯುತ್ತದೆ, ಮತ್ತು ನಂತರ ಅದನ್ನು ವಿನಂತಿಸಿದರೆ ಪೂರ್ವಪ್ರತ್ಯಯ
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // ಈ ಹಂತದಲ್ಲಿ `width` ಕ್ಷೇತ್ರವು `min-width` ನಿಯತಾಂಕಕ್ಕಿಂತ ಹೆಚ್ಚಿನದಾಗಿದೆ.
        match self.width {
            // ಕನಿಷ್ಠ ಉದ್ದದ ಅವಶ್ಯಕತೆಗಳಿಲ್ಲದಿದ್ದರೆ ನಾವು ಬೈಟ್‌ಗಳನ್ನು ಬರೆಯಬಹುದು.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // ನಾವು ಕನಿಷ್ಟ ಅಗಲಕ್ಕಿಂತ ಹೆಚ್ಚಿದ್ದೀರಾ ಎಂದು ಪರಿಶೀಲಿಸಿ, ಹಾಗಿದ್ದಲ್ಲಿ ನಾವು ಬೈಟ್‌ಗಳನ್ನು ಸಹ ಬರೆಯಬಹುದು.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // ಫಿಲ್ ಅಕ್ಷರ ಶೂನ್ಯವಾಗಿದ್ದರೆ ಚಿಹ್ನೆ ಮತ್ತು ಪೂರ್ವಪ್ರತ್ಯಯವು ಪ್ಯಾಡಿಂಗ್‌ಗೆ ಹೋಗುತ್ತದೆ
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // ಇಲ್ಲದಿದ್ದರೆ, ಚಿಹ್ನೆ ಮತ್ತು ಪೂರ್ವಪ್ರತ್ಯಯವು ಪ್ಯಾಡಿಂಗ್ ನಂತರ ಹೋಗುತ್ತದೆ
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// ಈ ಕಾರ್ಯವು ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ ಮತ್ತು ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಫಾರ್ಮ್ಯಾಟಿಂಗ್ ಧ್ವಜಗಳನ್ನು ಅನ್ವಯಿಸಿದ ನಂತರ ಅದನ್ನು ಆಂತರಿಕ ಬಫರ್‌ಗೆ ಹೊರಸೂಸುತ್ತದೆ.
    /// ಜೆನೆರಿಕ್ ತಂತಿಗಳಿಗೆ ಗುರುತಿಸಲಾದ ಧ್ವಜಗಳು:
    ///
    /// * ಅಗಲ, ಹೊರಸೂಸಬೇಕಾದ ಕನಿಷ್ಠ ಅಗಲ
    /// * fill/align - ಒದಗಿಸಿದ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಪ್ಯಾಡ್ ಮಾಡಬೇಕಾದರೆ ಏನು ಹೊರಸೂಸಬೇಕು ಮತ್ತು ಅದನ್ನು ಎಲ್ಲಿ ಹೊರಸೂಸಬೇಕು
    /// * ನಿಖರತೆ, ಹೊರಸೂಸುವ ಗರಿಷ್ಠ ಉದ್ದ, ಈ ಉದ್ದಕ್ಕಿಂತ ಉದ್ದವಾಗಿದ್ದರೆ ಸ್ಟ್ರಿಂಗ್ ಮೊಟಕುಗೊಳ್ಳುತ್ತದೆ
    ///
    /// ಗಮನಾರ್ಹವಾಗಿ ಈ ಕಾರ್ಯವು `flag` ನಿಯತಾಂಕಗಳನ್ನು ನಿರ್ಲಕ್ಷಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // ಮುಂದೆ ವೇಗದ ಮಾರ್ಗವಿದೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // ಸ್ಟ್ರಿಂಗ್ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಲು `precision` ಕ್ಷೇತ್ರವನ್ನು `max-width` ಎಂದು ವ್ಯಾಖ್ಯಾನಿಸಬಹುದು.
        //
        let s = if let Some(max) = self.precision {
            // ನಮ್ಮ ಸ್ಟ್ರಿಂಗ್ ನಿಖರತೆಗಿಂತ ಉದ್ದವಾಗಿದ್ದರೆ, ನಾವು ಮೊಟಕುಗೊಳಿಸುವಿಕೆಯನ್ನು ಹೊಂದಿರಬೇಕು.
            // ಆದಾಗ್ಯೂ `fill`, `width` ಮತ್ತು `align` ನಂತಹ ಇತರ ಧ್ವಜಗಳು ಯಾವಾಗಲೂ ಕಾರ್ಯನಿರ್ವಹಿಸಬೇಕು.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // ಇಲ್ಲಿ LLVM ಗೆ `..i` panic `&s[..i]` ಆಗುವುದಿಲ್ಲ ಎಂದು ಸಾಬೀತುಪಡಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ, ಆದರೆ ಅದು panic ಸಾಧ್ಯವಿಲ್ಲ ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ.
                // `unsafe` ಅನ್ನು ತಪ್ಪಿಸಲು `get` + `unwrap_or` ಬಳಸಿ ಮತ್ತು ಇಲ್ಲದಿದ್ದರೆ ಇಲ್ಲಿ ಯಾವುದೇ panic-ಸಂಬಂಧಿತ ಕೋಡ್ ಅನ್ನು ಹೊರಸೂಸಬೇಡಿ.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // ಈ ಹಂತದಲ್ಲಿ `width` ಕ್ಷೇತ್ರವು `min-width` ನಿಯತಾಂಕಕ್ಕಿಂತ ಹೆಚ್ಚಿನದಾಗಿದೆ.
        match self.width {
            // ನಾವು ಗರಿಷ್ಠ ಉದ್ದದಲ್ಲಿದ್ದರೆ ಮತ್ತು ಕನಿಷ್ಠ ಉದ್ದದ ಅವಶ್ಯಕತೆಗಳಿಲ್ಲದಿದ್ದರೆ, ನಾವು ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಹೊರಸೂಸಬಹುದು
            //
            None => self.buf.write_str(s),
            // ನಾವು ಗರಿಷ್ಠ ಅಗಲದಲ್ಲಿದ್ದರೆ, ನಾವು ಕನಿಷ್ಟ ಅಗಲಕ್ಕಿಂತ ಹೆಚ್ಚಿದ್ದೀರಾ ಎಂದು ಪರಿಶೀಲಿಸಿ, ಹಾಗಿದ್ದರೆ ಅದು ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಹೊರಸೂಸುವಷ್ಟು ಸುಲಭ.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // ನಾವು ಗರಿಷ್ಠ ಮತ್ತು ಕನಿಷ್ಠ ಅಗಲ ಎರಡರ ಅಡಿಯಲ್ಲಿದ್ದರೆ, ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಸ್ಟ್ರಿಂಗ್ + ಕೆಲವು ಜೋಡಣೆಯೊಂದಿಗೆ ಕನಿಷ್ಠ ಅಗಲವನ್ನು ಭರ್ತಿ ಮಾಡಿ.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// ಪೂರ್ವ ಪ್ಯಾಡಿಂಗ್ ಅನ್ನು ಬರೆಯಿರಿ ಮತ್ತು ಅಲಿಖಿತ ಪೋಸ್ಟ್-ಪ್ಯಾಡಿಂಗ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸಿ.
    /// ಪ್ಯಾಡಿಂಗ್ ಮಾಡಲಾದ ವಿಷಯದ ನಂತರ ಪೋಸ್ಟ್-ಪ್ಯಾಡಿಂಗ್ ಅನ್ನು ಬರೆಯಲಾಗಿದೆಯೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ಕರೆ ಮಾಡುವವರು ಜವಾಬ್ದಾರರಾಗಿರುತ್ತಾರೆ.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಿದ ಭಾಗಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ ಮತ್ತು ಪ್ಯಾಡಿಂಗ್ ಅನ್ನು ಅನ್ವಯಿಸುತ್ತದೆ.
    /// ಕರೆ ಮಾಡುವವರು ಈಗಾಗಲೇ ಅಗತ್ಯವಿರುವ ನಿಖರತೆಯೊಂದಿಗೆ ಭಾಗಗಳನ್ನು ಪ್ರದರ್ಶಿಸಿದ್ದಾರೆ ಎಂದು umes ಹಿಸುತ್ತದೆ, ಇದರಿಂದ `self.precision` ಅನ್ನು ನಿರ್ಲಕ್ಷಿಸಬಹುದು.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // ಸೈನ್-ಅರಿವಿನ ಶೂನ್ಯ ಪ್ಯಾಡಿಂಗ್ಗಾಗಿ, ನಾವು ಮೊದಲು ಚಿಹ್ನೆಯನ್ನು ನಿರೂಪಿಸುತ್ತೇವೆ ಮತ್ತು ಮೊದಲಿನಿಂದಲೂ ನಮಗೆ ಯಾವುದೇ ಚಿಹ್ನೆ ಇಲ್ಲ ಎಂಬಂತೆ ವರ್ತಿಸುತ್ತೇವೆ.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // ಒಂದು ಚಿಹ್ನೆ ಯಾವಾಗಲೂ ಮೊದಲು ಹೋಗುತ್ತದೆ
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಿದ ಭಾಗಗಳಿಂದ ಚಿಹ್ನೆಯನ್ನು ತೆಗೆದುಹಾಕಿ
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // ಉಳಿದ ಭಾಗಗಳು ಸಾಮಾನ್ಯ ಪ್ಯಾಡಿಂಗ್ ಪ್ರಕ್ರಿಯೆಯ ಮೂಲಕ ಹೋಗುತ್ತವೆ.
            let len = formatted.len();
            let ret = if width <= len {
                // ಪ್ಯಾಡಿಂಗ್ ಇಲ್ಲ
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // ಇದು ಸಾಮಾನ್ಯ ಸಂದರ್ಭ ಮತ್ತು ನಾವು ಶಾರ್ಟ್‌ಕಟ್ ತೆಗೆದುಕೊಳ್ಳುತ್ತೇವೆ
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // ಸುರಕ್ಷತೆ: ಇದನ್ನು `flt2dec::Part::Num` ಮತ್ತು `flt2dec::Part::Copy` ಗೆ ಬಳಸಲಾಗುತ್ತದೆ.
            // ಪ್ರತಿ ಚಾರ್ `c` `b'0'` ಮತ್ತು `b'9'` ನಡುವೆ ಇರುವುದರಿಂದ `flt2dec::Part::Num` ಗೆ ಬಳಸುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ, ಅಂದರೆ `s` ಮಾನ್ಯ UTF-8 ಆಗಿದೆ.
            // `buf` ಸರಳ ASCII ಆಗಿರುವುದರಿಂದ `flt2dec::Part::Copy(buf)` ಗೆ ಬಳಸುವುದು ಪ್ರಾಯೋಗಿಕವಾಗಿ ಸುರಕ್ಷಿತವಾಗಿದೆ, ಆದರೆ `buf` ಗೆ `flt2dec::to_shortest_str` ಗೆ ಯಾರಾದರೂ ಕೆಟ್ಟ ಮೌಲ್ಯವನ್ನು ರವಾನಿಸಲು ಸಾಧ್ಯವಿದೆ ಏಕೆಂದರೆ ಇದು ಸಾರ್ವಜನಿಕ ಕಾರ್ಯವಾಗಿದೆ.
            //
            // FIXME: ಇದು ಯುಬಿಗೆ ಕಾರಣವಾಗಬಹುದೇ ಎಂದು ನಿರ್ಧರಿಸಿ.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 ಸೊನ್ನೆಗಳು
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// ಈ ಫಾರ್ಮ್ಯಾಟರ್‌ನಲ್ಲಿರುವ ಆಧಾರವಾಗಿರುವ ಬಫರ್‌ಗೆ ಕೆಲವು ಡೇಟಾವನ್ನು ಬರೆಯುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // ಇದು ಇದಕ್ಕೆ ಸಮಾನವಾಗಿದೆ:
    ///         // ಬರೆಯಿರಿ! (ಫಾರ್ಮ್ಯಾಟರ್, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// ಈ ಉದಾಹರಣೆಯಲ್ಲಿ ಕೆಲವು ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಿದ ಮಾಹಿತಿಯನ್ನು ಬರೆಯುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// ಫಾರ್ಮ್ಯಾಟಿಂಗ್ಗಾಗಿ ಧ್ವಜಗಳು
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// ಜೋಡಣೆ ಇದ್ದಾಗಲೆಲ್ಲಾ 'fill' ಆಗಿ ಅಕ್ಷರವನ್ನು ಬಳಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // ನಾವು ">" ನೊಂದಿಗೆ ಬಲಕ್ಕೆ ಜೋಡಣೆಯನ್ನು ಹೊಂದಿಸಿದ್ದೇವೆ.
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// ಯಾವ ರೀತಿಯ ಜೋಡಣೆಯನ್ನು ವಿನಂತಿಸಲಾಗಿದೆ ಎಂಬುದನ್ನು ಸೂಚಿಸುವ ಧ್ವಜ.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// Output ಟ್‌ಪುಟ್ ಇರಬೇಕೆಂದು ಐಚ್ ally ಿಕವಾಗಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಪೂರ್ಣಾಂಕ ಅಗಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // ನಾವು ಅಗಲವನ್ನು ಪಡೆದರೆ, ನಾವು ಅದನ್ನು ಬಳಸುತ್ತೇವೆ
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // ಇಲ್ಲದಿದ್ದರೆ ನಾವು ವಿಶೇಷ ಏನನ್ನೂ ಮಾಡುವುದಿಲ್ಲ
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// ಸಂಖ್ಯಾ ಪ್ರಕಾರಗಳಿಗೆ ಐಚ್ ally ಿಕವಾಗಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ನಿಖರತೆ.
    /// ಪರ್ಯಾಯವಾಗಿ, ಸ್ಟ್ರಿಂಗ್ ಪ್ರಕಾರಗಳಿಗೆ ಗರಿಷ್ಠ ಅಗಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // ನಾವು ನಿಖರತೆಯನ್ನು ಸ್ವೀಕರಿಸಿದರೆ, ನಾವು ಅದನ್ನು ಬಳಸುತ್ತೇವೆ.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // ಇಲ್ಲದಿದ್ದರೆ ನಾವು 2 ಕ್ಕೆ ಡೀಫಾಲ್ಟ್ ಆಗುತ್ತೇವೆ.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// `+` ಧ್ವಜವನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// `-` ಧ್ವಜವನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // ನಿಮಗೆ ಮೈನಸ್ ಚಿಹ್ನೆ ಬೇಕೇ?ಒಂದನ್ನು ಹೊಂದಿರಿ!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// `#` ಧ್ವಜವನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// `0` ಧ್ವಜವನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // ಫಾರ್ಮ್ಯಾಟರ್ ಆಯ್ಕೆಗಳನ್ನು ನಾವು ನಿರ್ಲಕ್ಷಿಸುತ್ತೇವೆ.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: ಈ ಎರಡು ಧ್ವಜಗಳಿಗೆ ನಾವು ಯಾವ ಸಾರ್ವಜನಿಕ API ಅನ್ನು ಬಯಸುತ್ತೇವೆ ಎಂಬುದನ್ನು ನಿರ್ಧರಿಸಿ.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// ಸ್ಟ್ರಕ್ಟ್‌ಗಳಿಗಾಗಿ [`fmt::Debug`] ಅನುಷ್ಠಾನಗಳ ರಚನೆಗೆ ಸಹಾಯ ಮಾಡಲು ವಿನ್ಯಾಸಗೊಳಿಸಲಾದ [`DebugStruct`] ಬಿಲ್ಡರ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// ಟಪಲ್ ಸ್ಟ್ರಕ್ಟ್‌ಗಳಿಗಾಗಿ `fmt::Debug` ಅನುಷ್ಠಾನಗಳ ರಚನೆಗೆ ಸಹಾಯ ಮಾಡಲು ವಿನ್ಯಾಸಗೊಳಿಸಲಾದ `DebugTuple` ಬಿಲ್ಡರ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// ಪಟ್ಟಿ ತರಹದ ರಚನೆಗಳಿಗಾಗಿ `fmt::Debug` ಅನುಷ್ಠಾನಗಳ ರಚನೆಗೆ ಸಹಾಯ ಮಾಡಲು ವಿನ್ಯಾಸಗೊಳಿಸಲಾದ `DebugList` ಬಿಲ್ಡರ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// ಸೆಟ್ ತರಹದ ರಚನೆಗಳಿಗಾಗಿ `fmt::Debug` ಅನುಷ್ಠಾನಗಳ ರಚನೆಗೆ ಸಹಾಯ ಮಾಡಲು ವಿನ್ಯಾಸಗೊಳಿಸಲಾದ `DebugSet` ಬಿಲ್ಡರ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// ಈ ಹೆಚ್ಚು ಸಂಕೀರ್ಣ ಉದಾಹರಣೆಯಲ್ಲಿ, ಮ್ಯಾಚ್ ಶಸ್ತ್ರಾಸ್ತ್ರಗಳ ಪಟ್ಟಿಯನ್ನು ನಿರ್ಮಿಸಲು ನಾವು [`format_args!`] ಮತ್ತು `.debug_set()` ಅನ್ನು ಬಳಸುತ್ತೇವೆ:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// ನಕ್ಷೆಯಂತಹ ರಚನೆಗಳಿಗಾಗಿ `fmt::Debug` ಅನುಷ್ಠಾನಗಳನ್ನು ರಚಿಸಲು ಸಹಾಯ ಮಾಡಲು ವಿನ್ಯಾಸಗೊಳಿಸಲಾದ `DebugMap` ಬಿಲ್ಡರ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// ಕೋರ್ ಫಾರ್ಮ್ಯಾಟಿಂಗ್ traits ನ ಅನುಷ್ಠಾನಗಳು

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // ಚಾರ್ ತಪ್ಪಿಸಿಕೊಳ್ಳುವ ಅಗತ್ಯವಿದ್ದರೆ, ಇಲ್ಲಿಯವರೆಗೆ ಬ್ಯಾಕ್‌ಲಾಗ್ ಅನ್ನು ಫ್ಲಶ್ ಮಾಡಿ ಮತ್ತು ಬರೆಯಿರಿ, ಇಲ್ಲದಿದ್ದರೆ ಬಿಟ್ಟುಬಿಡಿ
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // ಪರ್ಯಾಯ ಧ್ವಜವನ್ನು ಈಗಾಗಲೇ ಲೋವರ್‌ಹೆಕ್ಸ್ ವಿಶೇಷವೆಂದು ಪರಿಗಣಿಸಿದೆ-ಇದು 0x ನೊಂದಿಗೆ ಪೂರ್ವಪ್ರತ್ಯಯ ಮಾಡಬೇಕೆ ಎಂದು ಸೂಚಿಸುತ್ತದೆ.
        // ಶೂನ್ಯ ವಿಸ್ತರಣೆಯಾಗಬೇಕೋ ಬೇಡವೋ ಎಂದು ಕೆಲಸ ಮಾಡಲು ನಾವು ಇದನ್ನು ಬಳಸುತ್ತೇವೆ ಮತ್ತು ನಂತರ ಪೂರ್ವಪ್ರತ್ಯಯವನ್ನು ಪಡೆಯಲು ಬೇಷರತ್ತಾಗಿ ಅದನ್ನು ಹೊಂದಿಸುತ್ತೇವೆ.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// ವಿವಿಧ ಕೋರ್ ಪ್ರಕಾರಗಳಿಗೆ Display/Debug ಅನುಷ್ಠಾನ

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // ರೆಫ್ಸೆಲ್ ಅನ್ನು ಪರಸ್ಪರ ಎರವಲು ಪಡೆಯಲಾಗಿದೆ ಆದ್ದರಿಂದ ನಾವು ಅದರ ಮೌಲ್ಯವನ್ನು ಇಲ್ಲಿ ನೋಡಲು ಸಾಧ್ಯವಿಲ್ಲ.
                // ಬದಲಿಗೆ ಪ್ಲೇಸ್‌ಹೋಲ್ಡರ್ ತೋರಿಸಿ.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// ಪರೀಕ್ಷೆಗಳು ಇಲ್ಲಿ ಇರಬೇಕೆಂದು ನೀವು ನಿರೀಕ್ಷಿಸಿದರೆ, core/tests/fmt.rs ಫೈಲ್ ಅನ್ನು ನೋಡಿ, ಇಲ್ಲಿ ಎಲ್ಲಾ rt::Piece ರಚನೆಗಳನ್ನು ರಚಿಸುವುದಕ್ಕಿಂತ ಇದು ತುಂಬಾ ಸುಲಭ.
//
// ಹಂಚಿಕೆ ಅಗತ್ಯವಿರುವವರಿಗೆ crate ಹಂಚಿಕೆಯಲ್ಲಿ ಪರೀಕ್ಷೆಗಳಿವೆ.