use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// ಕಂಪೈಲರ್ ಅನ್ನು ಸ್ವಯಂಚಾಲಿತವಾಗಿ `ಟಿ` ನ ಡಿಸ್ಟ್ರಕ್ಟರ್ ಎಂದು ಕರೆಯುವುದನ್ನು ತಡೆಯುವ ಹೊದಿಕೆ.
/// ಈ ಹೊದಿಕೆಯು 0-ವೆಚ್ಚವಾಗಿದೆ.
///
/// `ManuallyDrop<T>` `T` ನಂತೆಯೇ ಅದೇ ಲೇ layout ಟ್ ಆಪ್ಟಿಮೈಸೇಶನ್‌ಗಳಿಗೆ ಒಳಪಟ್ಟಿರುತ್ತದೆ.
/// ಇದರ ಪರಿಣಾಮವಾಗಿ, ಕಂಪೈಲರ್ ಅದರ ವಿಷಯಗಳ ಬಗ್ಗೆ ಮಾಡುವ ump ಹೆಗಳ ಮೇಲೆ ಇದು ಯಾವುದೇ ಪರಿಣಾಮ ಬೀರುವುದಿಲ್ಲ.
/// ಉದಾಹರಣೆಗೆ, [`mem::zeroed`] ನೊಂದಿಗೆ `ManuallyDrop<&mut T>` ಅನ್ನು ಪ್ರಾರಂಭಿಸುವುದು ವಿವರಿಸಲಾಗದ ವರ್ತನೆಯಾಗಿದೆ.
/// ನೀವು ಪ್ರಾರಂಭಿಸದ ಡೇಟಾವನ್ನು ನಿರ್ವಹಿಸಬೇಕಾದರೆ, ಬದಲಿಗೆ [`MaybeUninit<T>`] ಬಳಸಿ.
///
/// `ManuallyDrop<T>` ಒಳಗೆ ಮೌಲ್ಯವನ್ನು ಪ್ರವೇಶಿಸುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
/// ಇದರರ್ಥ `ManuallyDrop<T>` ಅವರ ವಿಷಯವನ್ನು ಕೈಬಿಡಲಾಗಿದೆ ಸಾರ್ವಜನಿಕ ಸುರಕ್ಷಿತ API ಮೂಲಕ ಅದನ್ನು ಬಹಿರಂಗಪಡಿಸಬಾರದು.
/// ಇದಕ್ಕೆ ಅನುಗುಣವಾಗಿ, `ManuallyDrop::drop` ಅಸುರಕ್ಷಿತವಾಗಿದೆ.
///
/// # `ManuallyDrop` ಮತ್ತು ಡ್ರಾಪ್ ಆರ್ಡರ್.
///
/// Rust ಉತ್ತಮವಾಗಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ [drop order] ಮೌಲ್ಯಗಳನ್ನು ಹೊಂದಿದೆ.
/// ಕ್ಷೇತ್ರಗಳು ಅಥವಾ ಸ್ಥಳೀಯರನ್ನು ನಿರ್ದಿಷ್ಟ ಕ್ರಮದಲ್ಲಿ ಕೈಬಿಡಲಾಗಿದೆಯೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು, ಸೂಚನೆಗಳನ್ನು ಮರುಕ್ರಮಗೊಳಿಸಿ, ಅಂದರೆ ಸೂಚ್ಯ ಡ್ರಾಪ್ ಆದೇಶವು ಸರಿಯಾದದು.
///
/// ಡ್ರಾಪ್ ಕ್ರಮವನ್ನು ನಿಯಂತ್ರಿಸಲು `ManuallyDrop` ಅನ್ನು ಬಳಸಲು ಸಾಧ್ಯವಿದೆ, ಆದರೆ ಇದಕ್ಕೆ ಅಸುರಕ್ಷಿತ ಕೋಡ್ ಅಗತ್ಯವಿರುತ್ತದೆ ಮತ್ತು ಬಿಚ್ಚುವಿಕೆಯ ಉಪಸ್ಥಿತಿಯಲ್ಲಿ ಸರಿಯಾಗಿ ಮಾಡಲು ಕಷ್ಟವಾಗುತ್ತದೆ.
///
///
/// ಉದಾಹರಣೆಗೆ, ನಿರ್ದಿಷ್ಟ ಕ್ಷೇತ್ರವನ್ನು ಇತರರ ನಂತರ ಕೈಬಿಡಲಾಗಿದೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ನೀವು ಬಯಸಿದರೆ, ಅದನ್ನು ರಚನೆಯ ಕೊನೆಯ ಕ್ಷೇತ್ರವನ್ನಾಗಿ ಮಾಡಿ:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children` ನಂತರ ಕೈಬಿಡಲಾಗುತ್ತದೆ.
///     // Rust ಘೋಷಣೆಯ ಕ್ರಮದಲ್ಲಿ ಕ್ಷೇತ್ರಗಳನ್ನು ಕೈಬಿಡಲಾಗಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// ಹಸ್ತಚಾಲಿತವಾಗಿ ಕೈಬಿಡಬೇಕಾದ ಮೌಲ್ಯವನ್ನು ಕಟ್ಟಿಕೊಳ್ಳಿ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // ನೀವು ಇನ್ನೂ ಸುರಕ್ಷಿತವಾಗಿ ಮೌಲ್ಯದ ಮೇಲೆ ಕಾರ್ಯನಿರ್ವಹಿಸಬಹುದು
    /// assert_eq!(*x, "Hello");
    /// // ಆದರೆ `Drop` ಇಲ್ಲಿ ಚಾಲನೆಯಾಗುವುದಿಲ್ಲ
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// `ManuallyDrop` ಪಾತ್ರೆಯಿಂದ ಮೌಲ್ಯವನ್ನು ಹೊರತೆಗೆಯುತ್ತದೆ.
    ///
    /// ಇದು ಮೌಲ್ಯವನ್ನು ಮತ್ತೆ ಕೈಬಿಡಲು ಅನುಮತಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // ಇದು `Box` ಅನ್ನು ಇಳಿಯುತ್ತದೆ.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// `ManuallyDrop<T>` ಕಂಟೇನರ್‌ನಿಂದ ಮೌಲ್ಯವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    ///
    /// ಈ ವಿಧಾನವು ಪ್ರಾಥಮಿಕವಾಗಿ ಡ್ರಾಪ್‌ನಲ್ಲಿ ಮೌಲ್ಯಗಳನ್ನು ಹೊರಹಾಕಲು ಉದ್ದೇಶಿಸಲಾಗಿದೆ.
    /// ಮೌಲ್ಯವನ್ನು ಹಸ್ತಚಾಲಿತವಾಗಿ ಬಿಡಲು [`ManuallyDrop::drop`] ಬಳಸುವ ಬದಲು, ನೀವು ಮೌಲ್ಯವನ್ನು ತೆಗೆದುಕೊಳ್ಳಲು ಈ ವಿಧಾನವನ್ನು ಬಳಸಬಹುದು ಮತ್ತು ಅದನ್ನು ಬಯಸಿದಂತೆ ಬಳಸಬಹುದು.
    ///
    /// ಸಾಧ್ಯವಾದಾಗಲೆಲ್ಲಾ, ಬದಲಿಗೆ [`into_inner`][`ManuallyDrop::into_inner`] ಅನ್ನು ಬಳಸುವುದು ಯೋಗ್ಯವಾಗಿದೆ, ಇದು `ManuallyDrop<T>` ನ ವಿಷಯವನ್ನು ನಕಲು ಮಾಡುವುದನ್ನು ತಡೆಯುತ್ತದೆ.
    ///
    ///
    /// # Safety
    ///
    /// ಈ ಕಾರ್ಯವು ಹೆಚ್ಚಿನ ಬಳಕೆಯನ್ನು ತಡೆಯದೆ ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯವನ್ನು ಶಬ್ದಾರ್ಥವಾಗಿ ಚಲಿಸುತ್ತದೆ, ಈ ಪಾತ್ರೆಯ ಸ್ಥಿತಿಯು ಬದಲಾಗದೆ ಉಳಿಯುತ್ತದೆ.
    /// ಈ `ManuallyDrop` ಅನ್ನು ಮತ್ತೆ ಬಳಸದಂತೆ ನೋಡಿಕೊಳ್ಳುವುದು ನಿಮ್ಮ ಜವಾಬ್ದಾರಿಯಾಗಿದೆ.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // ಸುರಕ್ಷತೆ: ನಾವು ಉಲ್ಲೇಖದಿಂದ ಓದುತ್ತಿದ್ದೇವೆ, ಅದು ಖಾತರಿಪಡಿಸುತ್ತದೆ
        // ಓದಲು ಮಾನ್ಯವಾಗಿರಬೇಕು.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯವನ್ನು ಹಸ್ತಚಾಲಿತವಾಗಿ ಇಳಿಯುತ್ತದೆ.ಇದು ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯಕ್ಕೆ ಪಾಯಿಂಟರ್‌ನೊಂದಿಗೆ [`ptr::drop_in_place`] ಅನ್ನು ಕರೆಯುವುದಕ್ಕೆ ಸಮನಾಗಿರುತ್ತದೆ.
    /// ಅದರಂತೆ, ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯವು ಪ್ಯಾಕ್ ಮಾಡಲಾದ ರಚನೆಯಾಗಿರದಿದ್ದರೆ, ಮೌಲ್ಯವನ್ನು ಚಲಿಸದೆ ಡಿಸ್ಟ್ರಕ್ಟರ್ ಅನ್ನು ಸ್ಥಳದಲ್ಲಿ ಕರೆಯಲಾಗುತ್ತದೆ, ಮತ್ತು ಆದ್ದರಿಂದ [pinned] ಡೇಟಾವನ್ನು ಸುರಕ್ಷಿತವಾಗಿ ಬಿಡಲು ಬಳಸಬಹುದು.
    ///
    /// ನೀವು ಮೌಲ್ಯದ ಮಾಲೀಕತ್ವವನ್ನು ಹೊಂದಿದ್ದರೆ, ನೀವು ಬದಲಿಗೆ [`ManuallyDrop::into_inner`] ಅನ್ನು ಬಳಸಬಹುದು.
    ///
    /// # Safety
    ///
    /// ಈ ಕಾರ್ಯವು ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯದ ವಿನಾಶಕವನ್ನು ನಡೆಸುತ್ತದೆ.
    /// ಡಿಸ್ಟ್ರಕ್ಟರ್ ಮಾಡಿದ ಬದಲಾವಣೆಗಳ ಹೊರತಾಗಿ, ಮೆಮೊರಿ ಬದಲಾಗದೆ ಉಳಿದಿದೆ, ಮತ್ತು ಕಂಪೈಲರ್ಗೆ ಸಂಬಂಧಿಸಿದಂತೆ, ಇನ್ನೂ `T` ಪ್ರಕಾರಕ್ಕೆ ಮಾನ್ಯವಾಗಿರುವ ಬಿಟ್-ಮಾದರಿಯನ್ನು ಹೊಂದಿದೆ.
    ///
    ///
    /// ಆದಾಗ್ಯೂ, ಈ "zombie" ಮೌಲ್ಯವನ್ನು ಸುರಕ್ಷಿತ ಕೋಡ್‌ಗೆ ಒಡ್ಡಬಾರದು ಮತ್ತು ಈ ಕಾರ್ಯವನ್ನು ಒಂದಕ್ಕಿಂತ ಹೆಚ್ಚು ಬಾರಿ ಕರೆಯಬಾರದು.
    /// ಮೌಲ್ಯವನ್ನು ಕೈಬಿಟ್ಟ ನಂತರ ಅದನ್ನು ಬಳಸಲು, ಅಥವಾ ಮೌಲ್ಯವನ್ನು ಅನೇಕ ಬಾರಿ ಬಿಡಿ, ವಿವರಿಸಲಾಗದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗಬಹುದು (`drop` ಏನು ಮಾಡುತ್ತದೆ ಎಂಬುದರ ಆಧಾರದ ಮೇಲೆ).
    /// ಇದನ್ನು ಸಾಮಾನ್ಯವಾಗಿ ಟೈಪ್ ಸಿಸ್ಟಮ್‌ನಿಂದ ತಡೆಯಲಾಗುತ್ತದೆ, ಆದರೆ `ManuallyDrop` ನ ಬಳಕೆದಾರರು ಕಂಪೈಲರ್‌ನ ಸಹಾಯವಿಲ್ಲದೆ ಆ ಖಾತರಿಗಳನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // ಸುರಕ್ಷತೆ: ನಾವು ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖದಿಂದ ಸೂಚಿಸಿದ ಮೌಲ್ಯವನ್ನು ಕೈಬಿಡುತ್ತಿದ್ದೇವೆ
        // ಇದು ಬರಹಗಳಿಗೆ ಮಾನ್ಯವಾಗಿರುತ್ತದೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.
        // `slot` ಅನ್ನು ಮತ್ತೆ ಕೈಬಿಡಲಾಗುವುದಿಲ್ಲ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳುವುದು ಕರೆ ಮಾಡುವವರ ಮೇಲಿದೆ.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}