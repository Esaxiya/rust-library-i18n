use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// `T` ನ ಪ್ರಾರಂಭಿಕವಲ್ಲದ ನಿದರ್ಶನಗಳನ್ನು ನಿರ್ಮಿಸಲು ಒಂದು ಹೊದಿಕೆ ಪ್ರಕಾರ.
///
/// # ಪ್ರಾರಂಭಿಕ ಅಸ್ಥಿರ
///
/// ಕಂಪೈಲರ್, ಸಾಮಾನ್ಯವಾಗಿ, ವೇರಿಯೇಬಲ್ ಪ್ರಕಾರದ ಅವಶ್ಯಕತೆಗಳಿಗೆ ಅನುಗುಣವಾಗಿ ವೇರಿಯೇಬಲ್ ಅನ್ನು ಸರಿಯಾಗಿ ಪ್ರಾರಂಭಿಸಲಾಗುತ್ತದೆ ಎಂದು umes ಹಿಸುತ್ತದೆ.ಉದಾಹರಣೆಗೆ, ಉಲ್ಲೇಖ ಪ್ರಕಾರದ ವೇರಿಯೇಬಲ್ ಅನ್ನು ಜೋಡಿಸಬೇಕು ಮತ್ತು NULL ಅಲ್ಲ.
/// ಇದು ಅಸ್ಥಿರವಾಗಿದ್ದು, ಅಸುರಕ್ಷಿತ ಕೋಡ್‌ನಲ್ಲಿಯೂ ಸಹ *ಯಾವಾಗಲೂ* ಎತ್ತಿಹಿಡಿಯಬೇಕು.
/// ಇದರ ಪರಿಣಾಮವಾಗಿ, ಉಲ್ಲೇಖ ಪ್ರಕಾರದ ವೇರಿಯೇಬಲ್ ಅನ್ನು ಶೂನ್ಯ-ಪ್ರಾರಂಭಿಸುವುದರಿಂದ ತತ್ಕ್ಷಣದ [undefined behavior][ub] ಗೆ ಕಾರಣವಾಗುತ್ತದೆ, ಆ ಉಲ್ಲೇಖವು ಮೆಮೊರಿಯನ್ನು ಪ್ರವೇಶಿಸಲು ಎಂದಾದರೂ ಬಳಸಲ್ಪಡುತ್ತದೆಯೇ ಎಂಬುದು ಮುಖ್ಯವಲ್ಲ:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // ಸ್ಪಷ್ಟೀಕರಿಸದ ನಡವಳಿಕೆ!⚠️
/// // `MaybeUninit<&i32>` ನೊಂದಿಗೆ ಸಮಾನ ಕೋಡ್:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // ಸ್ಪಷ್ಟೀಕರಿಸದ ನಡವಳಿಕೆ!⚠️
/// ```
///
/// ರನ್-ಟೈಮ್ ತಪಾಸಣೆಗಳನ್ನು ತೆಗೆದುಹಾಕುವುದು ಮತ್ತು `enum` ವಿನ್ಯಾಸವನ್ನು ಉತ್ತಮಗೊಳಿಸುವಂತಹ ವಿವಿಧ ಆಪ್ಟಿಮೈಸೇಶನ್ಗಳಿಗಾಗಿ ಕಂಪೈಲರ್ ಇದನ್ನು ಬಳಸಿಕೊಳ್ಳುತ್ತದೆ.
///
/// ಅಂತೆಯೇ, ಸಂಪೂರ್ಣವಾಗಿ ಪ್ರಾರಂಭಿಸದ ಮೆಮೊರಿ ಯಾವುದೇ ವಿಷಯವನ್ನು ಹೊಂದಿರಬಹುದು, ಆದರೆ `bool` ಯಾವಾಗಲೂ `true` ಅಥವಾ `false` ಆಗಿರಬೇಕು.ಆದ್ದರಿಂದ, ಪ್ರಾರಂಭಿಸದ `bool` ಅನ್ನು ರಚಿಸುವುದು ವಿವರಿಸಲಾಗದ ನಡವಳಿಕೆ:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // ಸ್ಪಷ್ಟೀಕರಿಸದ ನಡವಳಿಕೆ!⚠️
/// // `MaybeUninit<bool>` ನೊಂದಿಗೆ ಸಮಾನ ಕೋಡ್:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // ಸ್ಪಷ್ಟೀಕರಿಸದ ನಡವಳಿಕೆ!⚠️
/// ```
///
/// ಇದಲ್ಲದೆ, ಪ್ರಾರಂಭಿಸದ ಮೆಮೊರಿ ವಿಶೇಷವಾಗಿದ್ದು, ಅದು ಸ್ಥಿರ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿರುವುದಿಲ್ಲ ("fixed" ಅಂದರೆ "it won't change without being written to").ಒಂದೇ ಪ್ರಾರಂಭಿಸದ ಬೈಟ್ ಅನ್ನು ಅನೇಕ ಬಾರಿ ಓದುವುದರಿಂದ ವಿಭಿನ್ನ ಫಲಿತಾಂಶಗಳನ್ನು ನೀಡಬಹುದು.
/// ಆ ವೇರಿಯೇಬಲ್ ಒಂದು ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರವನ್ನು ಹೊಂದಿದ್ದರೂ ಸಹ, ವೇರಿಯೇಬಲ್ನಲ್ಲಿ ಪ್ರಾರಂಭಿಸದ ಡೇಟಾವನ್ನು ಹೊಂದಲು ಇದು ಸ್ಪಷ್ಟೀಕರಿಸದ ನಡವಳಿಕೆಯನ್ನು ಮಾಡುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ ಯಾವುದೇ *ಸ್ಥಿರ* ಬಿಟ್ ಮಾದರಿಯನ್ನು ಹೊಂದಬಹುದು:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // ಸ್ಪಷ್ಟೀಕರಿಸದ ನಡವಳಿಕೆ!⚠️
/// // `MaybeUninit<i32>` ನೊಂದಿಗೆ ಸಮಾನ ಕೋಡ್:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // ಸ್ಪಷ್ಟೀಕರಿಸದ ನಡವಳಿಕೆ!⚠️
/// ```
/// (ಪ್ರಾರಂಭಿಸದ ಪೂರ್ಣಾಂಕಗಳ ಸುತ್ತಲಿನ ನಿಯಮಗಳನ್ನು ಇನ್ನೂ ಅಂತಿಮಗೊಳಿಸಲಾಗಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಆದರೆ ಅವುಗಳು ಇರುವವರೆಗೂ ಅವುಗಳನ್ನು ತಪ್ಪಿಸುವುದು ಸೂಕ್ತವಾಗಿದೆ.)
///
/// ಅದರ ಮೇಲೆ, ಹೆಚ್ಚಿನ ಪ್ರಕಾರಗಳು ಹೆಚ್ಚುವರಿ ಅಸ್ಥಿರಗಳನ್ನು ಹೊಂದಿವೆ ಎಂಬುದನ್ನು ನೆನಪಿಡಿ.
/// ಉದಾಹರಣೆಗೆ, `1`-ಪ್ರಾರಂಭಿಸಿದ [`Vec<T>`] ಅನ್ನು ಪ್ರಾರಂಭಿಕವೆಂದು ಪರಿಗಣಿಸಲಾಗುತ್ತದೆ (ಪ್ರಸ್ತುತ ಅನುಷ್ಠಾನದಡಿಯಲ್ಲಿ; ಇದು ಸ್ಥಿರವಾದ ಖಾತರಿಯನ್ನು ರೂಪಿಸುವುದಿಲ್ಲ) ಏಕೆಂದರೆ ಕಂಪೈಲರ್ ಇದರ ಬಗ್ಗೆ ತಿಳಿದಿರುವ ಏಕೈಕ ಅವಶ್ಯಕತೆಯೆಂದರೆ ಡೇಟಾ ಪಾಯಿಂಟರ್ ಶೂನ್ಯವಾಗಿರಬೇಕು.
/// ಅಂತಹ `Vec<T>` ಅನ್ನು ರಚಿಸುವುದು *ತಕ್ಷಣದ* ಸ್ಪಷ್ಟೀಕರಿಸದ ನಡವಳಿಕೆಯನ್ನು ಉಂಟುಮಾಡುವುದಿಲ್ಲ, ಆದರೆ ಹೆಚ್ಚಿನ ಸುರಕ್ಷಿತ ಕಾರ್ಯಾಚರಣೆಗಳೊಂದಿಗೆ (ಅದನ್ನು ಬಿಡುವುದು ಸೇರಿದಂತೆ) ಸ್ಪಷ್ಟೀಕರಿಸದ ನಡವಳಿಕೆಯನ್ನು ಉಂಟುಮಾಡುತ್ತದೆ.
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` ಪ್ರಾರಂಭಿಸದ ಡೇಟಾವನ್ನು ಎದುರಿಸಲು ಅಸುರಕ್ಷಿತ ಕೋಡ್ ಅನ್ನು ಸಕ್ರಿಯಗೊಳಿಸಲು ಸಹಾಯ ಮಾಡುತ್ತದೆ.
/// ಇದು ಕಂಪೈಲರ್‌ಗೆ ಸಂಕೇತವಾಗಿದ್ದು, ಇಲ್ಲಿ ಡೇಟಾವನ್ನು *ಪ್ರಾರಂಭಿಸಲಾಗುವುದಿಲ್ಲ* ಎಂದು ಸೂಚಿಸುತ್ತದೆ:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // ಸ್ಪಷ್ಟವಾಗಿ ಪ್ರಾರಂಭಿಸದ ಉಲ್ಲೇಖವನ್ನು ರಚಿಸಿ.
/// // `MaybeUninit<T>` ಒಳಗೆ ಡೇಟಾ ಅಮಾನ್ಯವಾಗಬಹುದು ಎಂದು ಕಂಪೈಲರ್‌ಗೆ ತಿಳಿದಿದೆ ಮತ್ತು ಆದ್ದರಿಂದ ಇದು ಯುಬಿ ಅಲ್ಲ:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // ಅದನ್ನು ಮಾನ್ಯ ಮೌಲ್ಯಕ್ಕೆ ಹೊಂದಿಸಿ.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // ಪ್ರಾರಂಭಿಸಿದ ಡೇಟಾವನ್ನು ಹೊರತೆಗೆಯಿರಿ-`x` ಅನ್ನು ಸರಿಯಾಗಿ ಪ್ರಾರಂಭಿಸಿದ ನಂತರ * ಇದನ್ನು ಮಾತ್ರ ಅನುಮತಿಸಲಾಗುತ್ತದೆ!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// ಈ ಕೋಡ್‌ನಲ್ಲಿ ಯಾವುದೇ ತಪ್ಪಾದ ump ಹೆಗಳನ್ನು ಅಥವಾ ಆಪ್ಟಿಮೈಸೇಷನ್‌ಗಳನ್ನು ಮಾಡದಂತೆ ಕಂಪೈಲರ್‌ಗೆ ತಿಳಿದಿದೆ.
///
/// ನೀವು `MaybeUninit<T>` ಅನ್ನು `Option<T>` ನಂತೆ ಸ್ವಲ್ಪ ಯೋಚಿಸಬಹುದು ಆದರೆ ಯಾವುದೇ ರನ್-ಟೈಮ್ ಟ್ರ್ಯಾಕಿಂಗ್ ಇಲ್ಲದೆ ಮತ್ತು ಯಾವುದೇ ಸುರಕ್ಷತಾ ಪರಿಶೀಲನೆಗಳಿಲ್ಲದೆ.
///
/// ## out-pointers
///
/// "out-pointers" ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ನೀವು `MaybeUninit<T>` ಅನ್ನು ಬಳಸಬಹುದು: ಒಂದು ಫಂಕ್ಷನ್‌ನಿಂದ ಡೇಟಾವನ್ನು ಹಿಂದಿರುಗಿಸುವ ಬದಲು, ಫಲಿತಾಂಶವನ್ನು ಹಾಕಲು ಅದನ್ನು ಕೆಲವು (uninitialized) ಮೆಮೊರಿಗೆ ಪಾಯಿಂಟರ್ ಅನ್ನು ರವಾನಿಸಿ.
/// ಫಲಿತಾಂಶವನ್ನು ಹೇಗೆ ಸಂಗ್ರಹಿಸಲಾಗಿದೆ ಎಂಬುದನ್ನು ನಿಯಂತ್ರಿಸಲು ಕರೆ ಮಾಡುವವರಿಗೆ ಇದು ಮುಖ್ಯವಾದಾಗ ಇದು ಉಪಯುಕ್ತವಾಗಿರುತ್ತದೆ ಮತ್ತು ನೀವು ಅನಗತ್ಯ ಚಲನೆಗಳನ್ನು ತಪ್ಪಿಸಲು ಬಯಸುತ್ತೀರಿ.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` ಹಳೆಯ ವಿಷಯಗಳನ್ನು ಬಿಡುವುದಿಲ್ಲ, ಅದು ಮುಖ್ಯವಾಗಿದೆ.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // ಈಗ ನಮಗೆ ತಿಳಿದಿದೆ `v` ಅನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ!ಇದು vector ಅನ್ನು ಸರಿಯಾಗಿ ಕೈಬಿಡುವುದನ್ನು ಖಚಿತಪಡಿಸುತ್ತದೆ.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## ಎಲಿಮೆಂಟ್-ಬೈ-ಎಲಿಮೆಂಟ್ ಅನ್ನು ರಚಿಸಲಾಗುತ್ತಿದೆ
///
/// `MaybeUninit<T>` ಎಲಿಮೆಂಟ್-ಬೈ-ಎಲಿಮೆಂಟ್ ಅನ್ನು ದೊಡ್ಡ ಶ್ರೇಣಿಯನ್ನು ಪ್ರಾರಂಭಿಸಲು ಬಳಸಬಹುದು:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // `MaybeUninit` ನ ಪ್ರಾರಂಭಿಕ ಶ್ರೇಣಿಯನ್ನು ರಚಿಸಿ.
///     // `assume_init` ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ನಾವು ಇಲ್ಲಿ ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ ಎಂದು ಹೇಳಿಕೊಳ್ಳುತ್ತಿರುವ ಪ್ರಕಾರವು `ಬಹುಶಃ ಯುನಿನಿಟ್'ಗಳ ಗುಂಪಾಗಿದೆ, ಇದಕ್ಕೆ ಪ್ರಾರಂಭದ ಅಗತ್ಯವಿಲ್ಲ.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // `MaybeUninit` ಅನ್ನು ಬಿಡುವುದರಿಂದ ಏನೂ ಆಗುವುದಿಲ್ಲ.
///     // ಹೀಗಾಗಿ `ptr::write` ಬದಲಿಗೆ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ನಿಯೋಜನೆಯನ್ನು ಬಳಸುವುದರಿಂದ ಹಳೆಯ ಪ್ರಾರಂಭಿಕ ಮೌಲ್ಯವನ್ನು ಕೈಬಿಡಲಾಗುವುದಿಲ್ಲ.
/////
///     // ಈ ಲೂಪ್ ಸಮಯದಲ್ಲಿ panic ಇದ್ದರೆ, ನಮಗೆ ಮೆಮೊರಿ ಸೋರಿಕೆ ಇದೆ, ಆದರೆ ಯಾವುದೇ ಮೆಮೊರಿ ಸುರಕ್ಷತೆಯ ಸಮಸ್ಯೆ ಇಲ್ಲ.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // ಎಲ್ಲವನ್ನೂ ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ.
///     // ರಚನೆಯನ್ನು ಪ್ರಾರಂಭಿಕ ಪ್ರಕಾರಕ್ಕೆ ಪರಿವರ್ತಿಸಿ.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// ನೀವು ಭಾಗಶಃ ಪ್ರಾರಂಭಿಸಿದ ಅರೇಗಳೊಂದಿಗೆ ಸಹ ಕೆಲಸ ಮಾಡಬಹುದು, ಇದನ್ನು ಕಡಿಮೆ-ಮಟ್ಟದ ಡೇಟಾಸ್ಟ್ರಕ್ಚರ್‌ಗಳಲ್ಲಿ ಕಾಣಬಹುದು.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // `MaybeUninit` ನ ಪ್ರಾರಂಭಿಕ ಶ್ರೇಣಿಯನ್ನು ರಚಿಸಿ.
/// // `assume_init` ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ನಾವು ಇಲ್ಲಿ ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ ಎಂದು ಹೇಳಿಕೊಳ್ಳುತ್ತಿರುವ ಪ್ರಕಾರವು `ಬಹುಶಃ ಯುನಿನಿಟ್'ಗಳ ಗುಂಪಾಗಿದೆ, ಇದಕ್ಕೆ ಪ್ರಾರಂಭದ ಅಗತ್ಯವಿಲ್ಲ.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // ನಾವು ನಿಗದಿಪಡಿಸಿದ ಅಂಶಗಳ ಸಂಖ್ಯೆಯನ್ನು ಎಣಿಸಿ.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // ರಚನೆಯ ಪ್ರತಿಯೊಂದು ಐಟಂಗೆ, ನಾವು ಅದನ್ನು ನಿಯೋಜಿಸಿದರೆ ಬಿಡಿ.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## ಕ್ಷೇತ್ರದಿಂದ ಕ್ಷೇತ್ರಕ್ಕೆ ರಚನೆಯನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗುತ್ತಿದೆ
///
/// ಕ್ಷೇತ್ರಗಳ ಪ್ರಕಾರ ರಚನೆಗಳ ಕ್ಷೇತ್ರವನ್ನು ಪ್ರಾರಂಭಿಸಲು ನೀವು `MaybeUninit<T>`, ಮತ್ತು [`std::ptr::addr_of_mut`] ಮ್ಯಾಕ್ರೋವನ್ನು ಬಳಸಬಹುದು:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` ಕ್ಷೇತ್ರವನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗುತ್ತಿದೆ
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` ಕ್ಷೇತ್ರವನ್ನು ಪ್ರಾರಂಭಿಸುವುದು ಇಲ್ಲಿ panic ಇದ್ದರೆ, ನಂತರ `name` ಕ್ಷೇತ್ರದಲ್ಲಿನ `String` ಸೋರಿಕೆಯಾಗುತ್ತದೆ.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // ಎಲ್ಲಾ ಕ್ಷೇತ್ರಗಳನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ, ಆದ್ದರಿಂದ ನಾವು ಪ್ರಾರಂಭಿಕ ಫೂ ಪಡೆಯಲು `assume_init` ಅನ್ನು ಕರೆಯುತ್ತೇವೆ.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` `T` ನಂತೆಯೇ ಒಂದೇ ಗಾತ್ರ, ಜೋಡಣೆ ಮತ್ತು ಎಬಿಐ ಹೊಂದುವ ಭರವಸೆ ಇದೆ:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// ಆದಾಗ್ಯೂ *`MaybeUninit<T>` ಅನ್ನು ಹೊಂದಿರುವ* ಪ್ರಕಾರವು ಒಂದೇ ವಿನ್ಯಾಸವನ್ನು ಹೊಂದಿಲ್ಲ ಎಂದು ನೆನಪಿಡಿ;`T` ಮತ್ತು `U` ಒಂದೇ ಗಾತ್ರ ಮತ್ತು ಜೋಡಣೆಯನ್ನು ಹೊಂದಿದ್ದರೂ ಸಹ `Foo<T>` ನ ಕ್ಷೇತ್ರಗಳು `Foo<U>` ನಂತೆಯೇ ಒಂದೇ ಕ್ರಮವನ್ನು ಹೊಂದಿರುತ್ತವೆ ಎಂದು Rust ಸಾಮಾನ್ಯವಾಗಿ ಖಾತರಿಪಡಿಸುವುದಿಲ್ಲ.
///
/// ಇದಲ್ಲದೆ, ಯಾವುದೇ ಬಿಟ್ ಮೌಲ್ಯವು `MaybeUninit<T>` ಗೆ ಮಾನ್ಯವಾಗಿರುವುದರಿಂದ ಕಂಪೈಲರ್ non-zero/niche-filling ಆಪ್ಟಿಮೈಸೇಶನ್‌ಗಳನ್ನು ಅನ್ವಯಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ, ಇದರ ಪರಿಣಾಮವಾಗಿ ದೊಡ್ಡ ಗಾತ್ರ ಬರುತ್ತದೆ:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// `T` ಎಫ್‌ಎಫ್‌ಐ-ಸುರಕ್ಷಿತವಾಗಿದ್ದರೆ, ಎಕ್ಸ್‌00 ಎಕ್ಸ್ ಕೂಡ ಹಾಗೆಯೇ.
///
/// `MaybeUninit` `#[repr(transparent)]` ಆಗಿದ್ದರೆ (ಇದು ಒಂದೇ ಗಾತ್ರ, ಜೋಡಣೆ ಮತ್ತು ABI ಅನ್ನು `T` ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತದೆ ಎಂದು ಸೂಚಿಸುತ್ತದೆ), ಇದು ಹಿಂದಿನ ಯಾವುದೇ ಎಚ್ಚರಿಕೆಗಳನ್ನು * ಬದಲಾಯಿಸುವುದಿಲ್ಲ.
/// `Option<T>` ಮತ್ತು `Option<MaybeUninit<T>>` ಇನ್ನೂ ವಿಭಿನ್ನ ಗಾತ್ರಗಳನ್ನು ಹೊಂದಿರಬಹುದು, ಮತ್ತು `T` ಪ್ರಕಾರದ ಕ್ಷೇತ್ರವನ್ನು ಹೊಂದಿರುವ ಪ್ರಕಾರಗಳನ್ನು ಆ ಕ್ಷೇತ್ರವು `MaybeUninit<T>` ಆಗಿರುವುದಕ್ಕಿಂತ ವಿಭಿನ್ನವಾಗಿ ಹಾಕಬಹುದು (ಮತ್ತು ಗಾತ್ರ).
/// `MaybeUninit` ಇದು ಯೂನಿಯನ್ ಪ್ರಕಾರವಾಗಿದೆ, ಮತ್ತು ಯೂನಿಯನ್‌ಗಳಲ್ಲಿನ `#[repr(transparent)]` ಅಸ್ಥಿರವಾಗಿರುತ್ತದೆ ([the tracking issue](https://github.com/rust-lang/rust/issues/60405)) ನೋಡಿ.
/// ಕಾಲಾನಂತರದಲ್ಲಿ, ಒಕ್ಕೂಟಗಳಲ್ಲಿನ `#[repr(transparent)]` ನ ನಿಖರವಾದ ಖಾತರಿಗಳು ವಿಕಸನಗೊಳ್ಳಬಹುದು, ಮತ್ತು `MaybeUninit` `#[repr(transparent)]` ಆಗಿ ಉಳಿಯಬಹುದು ಅಥವಾ ಇರಬಹುದು.
/// `MaybeUninit<T>` `T` ನಂತೆಯೇ ಒಂದೇ ಗಾತ್ರ, ಜೋಡಣೆ ಮತ್ತು ಎಬಿಐ ಹೊಂದಿದೆ ಎಂದು *ಯಾವಾಗಲೂ* ಖಾತರಿಪಡಿಸುತ್ತದೆ;`MaybeUninit` ಖಾತರಿಪಡಿಸುವ ವಿಧಾನವು ವಿಕಸನಗೊಳ್ಳಬಹುದು.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// ಲ್ಯಾಂಗ್ ಐಟಂ ಆದ್ದರಿಂದ ನಾವು ಅದರಲ್ಲಿ ಇತರ ಪ್ರಕಾರಗಳನ್ನು ಕಟ್ಟಬಹುದು.ಜನರೇಟರ್‌ಗಳಿಗೆ ಇದು ಉಪಯುಕ್ತವಾಗಿದೆ.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // `T::clone()` ಗೆ ಕರೆ ಮಾಡುತ್ತಿಲ್ಲ, ಅದಕ್ಕಾಗಿ ನಾವು ಸಾಕಷ್ಟು ಪ್ರಾರಂಭಿಸಲ್ಪಟ್ಟಿದ್ದೇವೆ ಎಂದು ನಮಗೆ ತಿಳಿದಿಲ್ಲ.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// ನಿರ್ದಿಷ್ಟ ಮೌಲ್ಯದೊಂದಿಗೆ ಪ್ರಾರಂಭಿಸಲಾದ ಹೊಸ `MaybeUninit<T>` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    /// ಈ ಕಾರ್ಯದ ರಿಟರ್ನ್ ಮೌಲ್ಯದಲ್ಲಿ [`assume_init`] ಗೆ ಕರೆ ಮಾಡುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ.
    ///
    /// `MaybeUninit<T>` ಅನ್ನು ಬಿಡುವುದರಿಂದ `ಟಿ` ಡ್ರಾಪ್ ಕೋಡ್ ಅನ್ನು ಎಂದಿಗೂ ಕರೆಯುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    /// `T` ಅನ್ನು ಪ್ರಾರಂಭಿಸಿದರೆ ಅದು ಕೈಬಿಡುತ್ತದೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳುವುದು ನಿಮ್ಮ ಜವಾಬ್ದಾರಿಯಾಗಿದೆ.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// ಪ್ರಾರಂಭಿಸದ ಸ್ಥಿತಿಯಲ್ಲಿ ಹೊಸ `MaybeUninit<T>` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// `MaybeUninit<T>` ಅನ್ನು ಬಿಡುವುದರಿಂದ `ಟಿ` ಡ್ರಾಪ್ ಕೋಡ್ ಅನ್ನು ಎಂದಿಗೂ ಕರೆಯುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    /// `T` ಅನ್ನು ಪ್ರಾರಂಭಿಸಿದರೆ ಅದು ಕೈಬಿಡುತ್ತದೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳುವುದು ನಿಮ್ಮ ಜವಾಬ್ದಾರಿಯಾಗಿದೆ.
    ///
    /// ಕೆಲವು ಉದಾಹರಣೆಗಳಿಗಾಗಿ [type-level documentation][MaybeUninit] ನೋಡಿ.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// ಪ್ರಾರಂಭಿಸದ ಸ್ಥಿತಿಯಲ್ಲಿ, `MaybeUninit<T>` ಐಟಂಗಳ ಹೊಸ ಶ್ರೇಣಿಯನ್ನು ರಚಿಸಿ.
    ///
    /// Note: future Rust ಆವೃತ್ತಿಯಲ್ಲಿ ಅರೇ ಅಕ್ಷರಶಃ ಸಿಂಟ್ಯಾಕ್ಸ್ [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) ಅನ್ನು ಅನುಮತಿಸಿದಾಗ ಈ ವಿಧಾನವು ಅನಗತ್ಯವಾಗಬಹುದು.
    ///
    /// ಕೆಳಗಿನ ಉದಾಹರಣೆಯು ನಂತರ `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` ಅನ್ನು ಬಳಸಬಹುದು.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// ನಿಜವಾಗಿ ಓದಿದ ಡೇಟಾದ (ಬಹುಶಃ ಸಣ್ಣ) ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // ಸುರಕ್ಷತೆ: ಪ್ರಾರಂಭಿಸದ `[MaybeUninit<_>; LEN]` ಮಾನ್ಯವಾಗಿದೆ.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// ಮೆಮೊರಿಯನ್ನು `0` ಬೈಟ್‌ಗಳಿಂದ ತುಂಬಿಸುವುದರೊಂದಿಗೆ ಹೊಸ `MaybeUninit<T>` ಅನ್ನು ಪ್ರಾರಂಭಿಸದ ಸ್ಥಿತಿಯಲ್ಲಿ ರಚಿಸುತ್ತದೆ.ಇದು ಈಗಾಗಲೇ ಸರಿಯಾದ ಪ್ರಾರಂಭಕ್ಕಾಗಿ `T` ಅನ್ನು ಅವಲಂಬಿಸಿರುತ್ತದೆ.
    ///
    /// ಉದಾಹರಣೆಗೆ, `MaybeUninit<usize>::zeroed()` ಅನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ, ಆದರೆ `MaybeUninit<&'static i32>::zeroed()` ಏಕೆಂದರೆ ಉಲ್ಲೇಖಗಳು ಶೂನ್ಯವಾಗಿರಬಾರದು.
    ///
    /// `MaybeUninit<T>` ಅನ್ನು ಬಿಡುವುದರಿಂದ `ಟಿ` ಡ್ರಾಪ್ ಕೋಡ್ ಅನ್ನು ಎಂದಿಗೂ ಕರೆಯುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    /// `T` ಅನ್ನು ಪ್ರಾರಂಭಿಸಿದರೆ ಅದು ಕೈಬಿಡುತ್ತದೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳುವುದು ನಿಮ್ಮ ಜವಾಬ್ದಾರಿಯಾಗಿದೆ.
    ///
    /// # Example
    ///
    /// ಈ ಕಾರ್ಯದ ಸರಿಯಾದ ಬಳಕೆ: ಶೂನ್ಯದೊಂದಿಗೆ ಒಂದು ರಚನೆಯನ್ನು ಪ್ರಾರಂಭಿಸುವುದು, ಅಲ್ಲಿ struct ನ ಎಲ್ಲಾ ಕ್ಷೇತ್ರಗಳು ಬಿಟ್-ಪ್ಯಾಟರ್ನ್ 0 ಅನ್ನು ಮಾನ್ಯ ಮೌಲ್ಯವಾಗಿ ಹಿಡಿದಿಟ್ಟುಕೊಳ್ಳಬಹುದು.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// ಈ ಕಾರ್ಯದ *ತಪ್ಪಾದ* ಬಳಕೆ: `0` ಪ್ರಕಾರಕ್ಕೆ ಮಾನ್ಯ ಬಿಟ್-ಮಾದರಿಯಲ್ಲದಿದ್ದಾಗ `x.zeroed().assume_init()` ಗೆ ಕರೆ ಮಾಡುವುದು:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // ಜೋಡಿಯೊಳಗೆ, ನಾವು ಮಾನ್ಯ ತಾರತಮ್ಯವನ್ನು ಹೊಂದಿರದ `NotZero` ಅನ್ನು ರಚಿಸುತ್ತೇವೆ.
    /// // ಇದು ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆ.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // ಸುರಕ್ಷತೆ: ನಿಯೋಜಿಸಲಾದ ಮೆಮೊರಿಗೆ `u.as_mut_ptr()` ಅಂಕಗಳು.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// `MaybeUninit<T>` ಮೌಲ್ಯವನ್ನು ಹೊಂದಿಸುತ್ತದೆ.
    /// ಇದು ಹಿಂದಿನ ಯಾವುದೇ ಮೌಲ್ಯವನ್ನು ಕೈಬಿಡದೆ ತಿದ್ದಿ ಬರೆಯುತ್ತದೆ, ಆದ್ದರಿಂದ ನೀವು ಡಿಸ್ಟ್ರಕ್ಟರ್ ಅನ್ನು ಚಲಾಯಿಸುವುದನ್ನು ಬಿಟ್ಟುಬಿಡದ ಹೊರತು ಇದನ್ನು ಎರಡು ಬಾರಿ ಬಳಸದಂತೆ ಎಚ್ಚರವಹಿಸಿ.
    ///
    /// ನಿಮ್ಮ ಅನುಕೂಲಕ್ಕಾಗಿ, ಇದು `self` ನ (ಈಗ ಸುರಕ್ಷಿತವಾಗಿ ಪ್ರಾರಂಭಿಸಲಾದ) ವಿಷಯಗಳಿಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಸಹ ನೀಡುತ್ತದೆ.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // ಸುರಕ್ಷತೆ: ನಾವು ಈ ಮೌಲ್ಯವನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
        unsafe { self.assume_init_mut() }
    }

    /// ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯಕ್ಕೆ ಪಾಯಿಂಟರ್ ಪಡೆಯುತ್ತದೆ.
    /// `MaybeUninit<T>` ಅನ್ನು ಪ್ರಾರಂಭಿಸದ ಹೊರತು ಈ ಪಾಯಿಂಟರ್‌ನಿಂದ ಓದುವುದು ಅಥವಾ ಅದನ್ನು ಉಲ್ಲೇಖವಾಗಿ ಪರಿವರ್ತಿಸುವುದು ವಿವರಿಸಲಾಗದ ವರ್ತನೆಯಾಗಿದೆ.
    /// ಈ ಪಾಯಿಂಟರ್ (non-transitively) ಸೂಚಿಸುವ ಮೆಮೊರಿಗೆ ಬರೆಯುವುದು ವಿವರಿಸಲಾಗದ ನಡವಳಿಕೆ (`UnsafeCell<T>` ಒಳಗೆ ಹೊರತುಪಡಿಸಿ).
    ///
    /// # Examples
    ///
    /// ಈ ವಿಧಾನದ ಸರಿಯಾದ ಬಳಕೆ:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<T>` ಗೆ ಉಲ್ಲೇಖವನ್ನು ರಚಿಸಿ.ನಾವು ಇದನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದರಿಂದ ಇದು ಸರಿ.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// ಈ ವಿಧಾನದ *ತಪ್ಪಾದ* ಬಳಕೆ:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // ನಾವು ಪ್ರಾರಂಭಿಸದ vector ಗೆ ಉಲ್ಲೇಖವನ್ನು ರಚಿಸಿದ್ದೇವೆ!ಇದು ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆ.⚠️
    /// ```
    ///
    /// (ಪ್ರಾರಂಭಿಸದ ಡೇಟಾದ ಉಲ್ಲೇಖಗಳ ಸುತ್ತಲಿನ ನಿಯಮಗಳನ್ನು ಇನ್ನೂ ಅಂತಿಮಗೊಳಿಸಲಾಗಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಆದರೆ ಅವುಗಳು ಇರುವವರೆಗೂ ಅವುಗಳನ್ನು ತಪ್ಪಿಸುವುದು ಸೂಕ್ತವಾಗಿದೆ.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` ಮತ್ತು `ManuallyDrop` ಎರಡೂ `repr(transparent)` ಆಗಿರುವುದರಿಂದ ನಾವು ಪಾಯಿಂಟರ್ ಅನ್ನು ಬಿತ್ತರಿಸಬಹುದು.
        self as *const _ as *const T
    }

    /// ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯಕ್ಕೆ ರೂಪಾಂತರಿತ ಪಾಯಿಂಟರ್ ಅನ್ನು ಪಡೆಯುತ್ತದೆ.
    /// `MaybeUninit<T>` ಅನ್ನು ಪ್ರಾರಂಭಿಸದ ಹೊರತು ಈ ಪಾಯಿಂಟರ್‌ನಿಂದ ಓದುವುದು ಅಥವಾ ಅದನ್ನು ಉಲ್ಲೇಖವಾಗಿ ಪರಿವರ್ತಿಸುವುದು ವಿವರಿಸಲಾಗದ ವರ್ತನೆಯಾಗಿದೆ.
    ///
    /// # Examples
    ///
    /// ಈ ವಿಧಾನದ ಸರಿಯಾದ ಬಳಕೆ:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<Vec<u32>>` ಗೆ ಉಲ್ಲೇಖವನ್ನು ರಚಿಸಿ.
    /// // ನಾವು ಇದನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದರಿಂದ ಇದು ಸರಿ.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// ಈ ವಿಧಾನದ *ತಪ್ಪಾದ* ಬಳಕೆ:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // ನಾವು ಪ್ರಾರಂಭಿಸದ vector ಗೆ ಉಲ್ಲೇಖವನ್ನು ರಚಿಸಿದ್ದೇವೆ!ಇದು ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆ.⚠️
    /// ```
    ///
    /// (ಪ್ರಾರಂಭಿಸದ ಡೇಟಾದ ಉಲ್ಲೇಖಗಳ ಸುತ್ತಲಿನ ನಿಯಮಗಳನ್ನು ಇನ್ನೂ ಅಂತಿಮಗೊಳಿಸಲಾಗಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಆದರೆ ಅವುಗಳು ಇರುವವರೆಗೂ ಅವುಗಳನ್ನು ತಪ್ಪಿಸುವುದು ಸೂಕ್ತವಾಗಿದೆ.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` ಮತ್ತು `ManuallyDrop` ಎರಡೂ `repr(transparent)` ಆಗಿರುವುದರಿಂದ ನಾವು ಪಾಯಿಂಟರ್ ಅನ್ನು ಬಿತ್ತರಿಸಬಹುದು.
        self as *mut _ as *mut T
    }

    /// `MaybeUninit<T>` ಪಾತ್ರೆಯಿಂದ ಮೌಲ್ಯವನ್ನು ಹೊರತೆಗೆಯುತ್ತದೆ.ಡೇಟಾವನ್ನು ಕೈಬಿಡಲಾಗುವುದು ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ಇದು ಉತ್ತಮ ಮಾರ್ಗವಾಗಿದೆ, ಏಕೆಂದರೆ ಪರಿಣಾಮವಾಗಿ ಬರುವ `T` ಸಾಮಾನ್ಯ ಡ್ರಾಪ್ ನಿರ್ವಹಣೆಗೆ ಒಳಪಟ್ಟಿರುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` ನಿಜವಾಗಿಯೂ ಪ್ರಾರಂಭಿಕ ಸ್ಥಿತಿಯಲ್ಲಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸುವುದು ಕರೆ ಮಾಡುವವರಿಗೆ ಬಿಟ್ಟದ್ದು.ವಿಷಯವನ್ನು ಇನ್ನೂ ಸಂಪೂರ್ಣವಾಗಿ ಪ್ರಾರಂಭಿಸದಿದ್ದಾಗ ಇದನ್ನು ಕರೆಯುವುದು ತಕ್ಷಣದ ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
    /// [type-level documentation][inv] ಈ ಪ್ರಾರಂಭಿಕ ಬದಲಾವಣೆಯ ಬಗ್ಗೆ ಹೆಚ್ಚಿನ ಮಾಹಿತಿಯನ್ನು ಒಳಗೊಂಡಿದೆ.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// ಅದರ ಮೇಲೆ, ಹೆಚ್ಚಿನ ಪ್ರಕಾರಗಳು ಹೆಚ್ಚುವರಿ ಅಸ್ಥಿರಗಳನ್ನು ಹೊಂದಿವೆ ಎಂಬುದನ್ನು ನೆನಪಿಡಿ.
    /// ಉದಾಹರಣೆಗೆ, `1`-ಪ್ರಾರಂಭಿಸಿದ [`Vec<T>`] ಅನ್ನು ಪ್ರಾರಂಭಿಕವೆಂದು ಪರಿಗಣಿಸಲಾಗುತ್ತದೆ (ಪ್ರಸ್ತುತ ಅನುಷ್ಠಾನದಡಿಯಲ್ಲಿ; ಇದು ಸ್ಥಿರವಾದ ಖಾತರಿಯನ್ನು ರೂಪಿಸುವುದಿಲ್ಲ) ಏಕೆಂದರೆ ಕಂಪೈಲರ್ ಇದರ ಬಗ್ಗೆ ತಿಳಿದಿರುವ ಏಕೈಕ ಅವಶ್ಯಕತೆಯೆಂದರೆ ಡೇಟಾ ಪಾಯಿಂಟರ್ ಶೂನ್ಯವಾಗಿರಬೇಕು.
    ///
    /// ಅಂತಹ `Vec<T>` ಅನ್ನು ರಚಿಸುವುದು *ತಕ್ಷಣದ* ಸ್ಪಷ್ಟೀಕರಿಸದ ನಡವಳಿಕೆಯನ್ನು ಉಂಟುಮಾಡುವುದಿಲ್ಲ, ಆದರೆ ಹೆಚ್ಚಿನ ಸುರಕ್ಷಿತ ಕಾರ್ಯಾಚರಣೆಗಳೊಂದಿಗೆ (ಅದನ್ನು ಬಿಡುವುದು ಸೇರಿದಂತೆ) ಸ್ಪಷ್ಟೀಕರಿಸದ ನಡವಳಿಕೆಯನ್ನು ಉಂಟುಮಾಡುತ್ತದೆ.
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// ಈ ವಿಧಾನದ ಸರಿಯಾದ ಬಳಕೆ:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// ಈ ವಿಧಾನದ *ತಪ್ಪಾದ* ಬಳಕೆ:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` ಇನ್ನೂ ಪ್ರಾರಂಭಿಸಲಾಗಿಲ್ಲ, ಆದ್ದರಿಂದ ಈ ಕೊನೆಯ ಸಾಲು ವಿವರಿಸಲಾಗದ ವರ್ತನೆಗೆ ಕಾರಣವಾಯಿತು.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `self` ಅನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು.
        // ಇದರರ್ಥ `self` `value` ರೂಪಾಂತರವಾಗಿರಬೇಕು.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// `MaybeUninit<T>` ಪಾತ್ರೆಯಿಂದ ಮೌಲ್ಯವನ್ನು ಓದುತ್ತದೆ.ಪರಿಣಾಮವಾಗಿ `T` ಸಾಮಾನ್ಯ ಡ್ರಾಪ್ ನಿರ್ವಹಣೆಗೆ ಒಳಪಟ್ಟಿರುತ್ತದೆ.
    ///
    /// ಸಾಧ್ಯವಾದಾಗಲೆಲ್ಲಾ, ಬದಲಿಗೆ [`assume_init`] ಅನ್ನು ಬಳಸುವುದು ಯೋಗ್ಯವಾಗಿದೆ, ಇದು `MaybeUninit<T>` ನ ವಿಷಯವನ್ನು ನಕಲು ಮಾಡುವುದನ್ನು ತಡೆಯುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` ನಿಜವಾಗಿಯೂ ಪ್ರಾರಂಭಿಕ ಸ್ಥಿತಿಯಲ್ಲಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸುವುದು ಕರೆ ಮಾಡುವವರಿಗೆ ಬಿಟ್ಟದ್ದು.ವಿಷಯವನ್ನು ಇನ್ನೂ ಸಂಪೂರ್ಣವಾಗಿ ಪ್ರಾರಂಭಿಸದಿದ್ದಾಗ ಇದನ್ನು ಕರೆಯುವುದು ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
    /// [type-level documentation][inv] ಈ ಪ್ರಾರಂಭಿಕ ಬದಲಾವಣೆಯ ಬಗ್ಗೆ ಹೆಚ್ಚಿನ ಮಾಹಿತಿಯನ್ನು ಒಳಗೊಂಡಿದೆ.
    ///
    /// ಇದಲ್ಲದೆ, ಇದು ಅದೇ ಡೇಟಾದ ನಕಲನ್ನು `MaybeUninit<T>` ನಲ್ಲಿ ಬಿಟ್ಟುಬಿಡುತ್ತದೆ.
    /// ಡೇಟಾದ ಬಹು ಪ್ರತಿಗಳನ್ನು ಬಳಸುವಾಗ (`assume_init_read` ಅನ್ನು ಅನೇಕ ಬಾರಿ ಕರೆ ಮಾಡುವ ಮೂಲಕ, ಅಥವಾ ಮೊದಲು `assume_init_read` ಮತ್ತು ನಂತರ [`assume_init`] ಗೆ ಕರೆ ಮಾಡುವ ಮೂಲಕ), ಆ ಡೇಟಾವನ್ನು ನಿಜಕ್ಕೂ ನಕಲು ಮಾಡಬಹುದೆಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳುವುದು ನಿಮ್ಮ ಜವಾಬ್ದಾರಿಯಾಗಿದೆ.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ಈ ವಿಧಾನದ ಸರಿಯಾದ ಬಳಕೆ:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` `Copy` ಆಗಿದೆ, ಆದ್ದರಿಂದ ನಾವು ಅನೇಕ ಬಾರಿ ಓದಬಹುದು.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `None` ಮೌಲ್ಯವನ್ನು ನಕಲು ಮಾಡುವುದು ಸರಿಯಾಗಿದೆ, ಆದ್ದರಿಂದ ನಾವು ಅನೇಕ ಬಾರಿ ಓದಬಹುದು.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// ಈ ವಿಧಾನದ *ತಪ್ಪಾದ* ಬಳಕೆ:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // ನಾವು ಈಗ ಒಂದೇ vector ನ ಎರಡು ಪ್ರತಿಗಳನ್ನು ರಚಿಸಿದ್ದೇವೆ, ಅದು ಡಬಲ್-ಫ್ರೀಗೆ ಕಾರಣವಾಗುತ್ತದೆ both ಇವೆರಡೂ ಕೈಬಿಟ್ಟಾಗ!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `self` ಅನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು.
        // `self` ಅನ್ನು ಪ್ರಾರಂಭಿಸುವುದರಿಂದ `self.as_ptr()` ನಿಂದ ಓದುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯವನ್ನು ಸ್ಥಳದಲ್ಲಿ ಇರಿಸಿ.
    ///
    /// ನೀವು `MaybeUninit` ನ ಮಾಲೀಕತ್ವವನ್ನು ಹೊಂದಿದ್ದರೆ, ನೀವು ಬದಲಿಗೆ [`assume_init`] ಅನ್ನು ಬಳಸಬಹುದು.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` ನಿಜವಾಗಿಯೂ ಪ್ರಾರಂಭಿಕ ಸ್ಥಿತಿಯಲ್ಲಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸುವುದು ಕರೆ ಮಾಡುವವರಿಗೆ ಬಿಟ್ಟದ್ದು.ವಿಷಯವನ್ನು ಇನ್ನೂ ಸಂಪೂರ್ಣವಾಗಿ ಪ್ರಾರಂಭಿಸದಿದ್ದಾಗ ಇದನ್ನು ಕರೆಯುವುದು ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
    ///
    /// ಅದರ ಮೇಲೆ, `T` ಪ್ರಕಾರದ ಎಲ್ಲಾ ಹೆಚ್ಚುವರಿ ಅಸ್ಥಿರತೆಗಳನ್ನು ತೃಪ್ತಿಪಡಿಸಬೇಕು, ಏಕೆಂದರೆ `T` (ಅಥವಾ ಅದರ ಸದಸ್ಯರು) ನ `Drop` ಅನುಷ್ಠಾನವು ಇದನ್ನು ಅವಲಂಬಿಸಬಹುದು.
    /// ಉದಾಹರಣೆಗೆ, `1`-ಪ್ರಾರಂಭಿಸಿದ [`Vec<T>`] ಅನ್ನು ಪ್ರಾರಂಭಿಕವೆಂದು ಪರಿಗಣಿಸಲಾಗುತ್ತದೆ (ಪ್ರಸ್ತುತ ಅನುಷ್ಠಾನದಡಿಯಲ್ಲಿ; ಇದು ಸ್ಥಿರವಾದ ಖಾತರಿಯನ್ನು ರೂಪಿಸುವುದಿಲ್ಲ) ಏಕೆಂದರೆ ಕಂಪೈಲರ್ ಇದರ ಬಗ್ಗೆ ತಿಳಿದಿರುವ ಏಕೈಕ ಅವಶ್ಯಕತೆಯೆಂದರೆ ಡೇಟಾ ಪಾಯಿಂಟರ್ ಶೂನ್ಯವಾಗಿರಬೇಕು.
    ///
    /// ಅಂತಹ `Vec<T>` ಅನ್ನು ಬಿಡುವುದು ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `self` ಅನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು ಮತ್ತು
        // `T` ನ ಎಲ್ಲಾ ಅಸ್ಥಿರತೆಗಳನ್ನು ಪೂರೈಸುತ್ತದೆ.
        // ಒಂದು ವೇಳೆ ಸ್ಥಳದಲ್ಲಿ ಮೌಲ್ಯವನ್ನು ಬಿಡುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯಕ್ಕೆ ಹಂಚಿದ ಉಲ್ಲೇಖವನ್ನು ಪಡೆಯುತ್ತದೆ.
    ///
    /// ನಾವು ಪ್ರಾರಂಭಿಸಿದ `MaybeUninit` ಅನ್ನು ಪ್ರವೇಶಿಸಲು ಬಯಸಿದಾಗ ಇದು ಉಪಯುಕ್ತವಾಗಿರುತ್ತದೆ ಆದರೆ `MaybeUninit` ನ ಮಾಲೀಕತ್ವವನ್ನು ಹೊಂದಿಲ್ಲ (`.assume_init()`) ಬಳಕೆಯನ್ನು ತಡೆಯುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// ವಿಷಯವನ್ನು ಇನ್ನೂ ಸಂಪೂರ್ಣವಾಗಿ ಪ್ರಾರಂಭಿಸದಿದ್ದಾಗ ಇದನ್ನು ಕರೆಯುವುದು ಸ್ಪಷ್ಟೀಕರಿಸದ ನಡವಳಿಕೆಯನ್ನು ಉಂಟುಮಾಡುತ್ತದೆ: `MaybeUninit<T>` ನಿಜವಾಗಿಯೂ ಪ್ರಾರಂಭಿಕ ಸ್ಥಿತಿಯಲ್ಲಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸುವುದು ಕರೆಗಾರನಿಗೆ ಬಿಟ್ಟದ್ದು.
    ///
    ///
    /// # Examples
    ///
    /// ### ಈ ವಿಧಾನದ ಸರಿಯಾದ ಬಳಕೆ:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x` ಅನ್ನು ಪ್ರಾರಂಭಿಸಿ:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // ಈಗ ನಮ್ಮ `MaybeUninit<_>` ಅನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ ಎಂದು ತಿಳಿದುಬಂದಿದೆ, ಇದಕ್ಕೆ ಹಂಚಿದ ಉಲ್ಲೇಖವನ್ನು ರಚಿಸುವುದು ಸರಿಯಾಗಿದೆ:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // ಸುರಕ್ಷತೆ: `x` ಅನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### ಈ ವಿಧಾನದ *ತಪ್ಪಾದ* ಬಳಕೆಗಳು:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // ನಾವು ಪ್ರಾರಂಭಿಸದ vector ಗೆ ಉಲ್ಲೇಖವನ್ನು ರಚಿಸಿದ್ದೇವೆ!ಇದು ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆ.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `Cell::set` ಬಳಸಿ `MaybeUninit` ಅನ್ನು ಪ್ರಾರಂಭಿಸಿ:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // ಪ್ರಾರಂಭಿಸದ `Cell<bool>` ಗೆ ಉಲ್ಲೇಖ: ಯುಬಿ!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `self` ಅನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು.
        // ಇದರರ್ಥ `self` `value` ರೂಪಾಂತರವಾಗಿರಬೇಕು.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯಕ್ಕೆ ರೂಪಾಂತರಿತ (unique) ಉಲ್ಲೇಖವನ್ನು ಪಡೆಯುತ್ತದೆ.
    ///
    /// ನಾವು ಪ್ರಾರಂಭಿಸಿದ `MaybeUninit` ಅನ್ನು ಪ್ರವೇಶಿಸಲು ಬಯಸಿದಾಗ ಇದು ಉಪಯುಕ್ತವಾಗಿರುತ್ತದೆ ಆದರೆ `MaybeUninit` ನ ಮಾಲೀಕತ್ವವನ್ನು ಹೊಂದಿಲ್ಲ (`.assume_init()`) ಬಳಕೆಯನ್ನು ತಡೆಯುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// ವಿಷಯವನ್ನು ಇನ್ನೂ ಸಂಪೂರ್ಣವಾಗಿ ಪ್ರಾರಂಭಿಸದಿದ್ದಾಗ ಇದನ್ನು ಕರೆಯುವುದು ಸ್ಪಷ್ಟೀಕರಿಸದ ನಡವಳಿಕೆಯನ್ನು ಉಂಟುಮಾಡುತ್ತದೆ: `MaybeUninit<T>` ನಿಜವಾಗಿಯೂ ಪ್ರಾರಂಭಿಕ ಸ್ಥಿತಿಯಲ್ಲಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸುವುದು ಕರೆಗಾರನಿಗೆ ಬಿಟ್ಟದ್ದು.
    /// ಉದಾಹರಣೆಗೆ, `MaybeUninit` ಅನ್ನು ಪ್ರಾರಂಭಿಸಲು `.assume_init_mut()` ಅನ್ನು ಬಳಸಲಾಗುವುದಿಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ### ಈ ವಿಧಾನದ ಸರಿಯಾದ ಬಳಕೆ:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// ಇನ್ಪುಟ್ ಬಫರ್ನ *ಎಲ್ಲ* ಬೈಟ್‌ಗಳನ್ನು ಪ್ರಾರಂಭಿಸುತ್ತದೆ.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf` ಅನ್ನು ಪ್ರಾರಂಭಿಸಿ:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // `buf` ಅನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ ಎಂದು ಈಗ ನಮಗೆ ತಿಳಿದಿದೆ, ಆದ್ದರಿಂದ ನಾವು ಅದನ್ನು `.assume_init()` ಮಾಡಬಹುದು.
    /// // ಆದಾಗ್ಯೂ, `.assume_init()` ಅನ್ನು ಬಳಸುವುದರಿಂದ 2048 ಬೈಟ್‌ಗಳ `memcpy` ಅನ್ನು ಪ್ರಚೋದಿಸಬಹುದು.
    /// // ನಮ್ಮ ಬಫರ್ ಅನ್ನು ನಕಲಿಸದೆ ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ ಎಂದು ಪ್ರತಿಪಾದಿಸಲು, ನಾವು `&mut MaybeUninit<[u8; 2048]>` ಅನ್ನು `&mut [u8; 2048]` ಗೆ ಅಪ್‌ಗ್ರೇಡ್ ಮಾಡುತ್ತೇವೆ:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // ಸುರಕ್ಷತೆ: `buf` ಅನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // ಈಗ ನಾವು `buf` ಅನ್ನು ಸಾಮಾನ್ಯ ಸ್ಲೈಸ್‌ನಂತೆ ಬಳಸಬಹುದು:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### ಈ ವಿಧಾನದ *ತಪ್ಪಾದ* ಬಳಕೆಗಳು:
    ///
    /// ಮೌಲ್ಯವನ್ನು ಪ್ರಾರಂಭಿಸಲು ನೀವು `.assume_init_mut()` ಅನ್ನು ಬಳಸಲಾಗುವುದಿಲ್ಲ:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // ನಾವು ಪ್ರಾರಂಭಿಸದ `bool` ಗೆ (mutable) ಉಲ್ಲೇಖವನ್ನು ರಚಿಸಿದ್ದೇವೆ!
    ///     // ಇದು ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆ.⚠️
    /// }
    /// ```
    ///
    /// ಉದಾಹರಣೆಗೆ, ನೀವು ಪ್ರಾರಂಭಿಸದ ಬಫರ್‌ಗೆ [`Read`] ಮಾಡಲು ಸಾಧ್ಯವಿಲ್ಲ:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) ಪ್ರಾರಂಭಿಸದ ಮೆಮೊರಿಗೆ ಉಲ್ಲೇಖ!
    ///                             // ಇದು ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆ.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// ಕ್ಷೇತ್ರ-ಮೂಲಕ-ಕ್ಷೇತ್ರ ಕ್ರಮೇಣ ಪ್ರಾರಂಭವನ್ನು ಮಾಡಲು ನೀವು ನೇರ ಕ್ಷೇತ್ರ ಪ್ರವೇಶವನ್ನು ಬಳಸಲಾಗುವುದಿಲ್ಲ:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ಪ್ರಾರಂಭಿಸದ ಮೆಮೊರಿಗೆ ಉಲ್ಲೇಖ!
    ///                  // ಇದು ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆ.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ಪ್ರಾರಂಭಿಸದ ಮೆಮೊರಿಗೆ ಉಲ್ಲೇಖ!
    ///                  // ಇದು ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆ.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): ನಾವು ಪ್ರಸ್ತುತ ಮೇಲಿನದನ್ನು ತಪ್ಪಾಗಿ ಅವಲಂಬಿಸಿದ್ದೇವೆ, ಅಂದರೆ, ನಾವು ಪ್ರಾರಂಭಿಸದ ಡೇಟಾಗೆ ಉಲ್ಲೇಖಗಳನ್ನು ಹೊಂದಿದ್ದೇವೆ (ಉದಾ., `libcore/fmt/float.rs` ನಲ್ಲಿ).
    // ಸ್ಥಿರೀಕರಣದ ಮೊದಲು ನಾವು ನಿಯಮಗಳ ಬಗ್ಗೆ ಅಂತಿಮ ನಿರ್ಧಾರ ತೆಗೆದುಕೊಳ್ಳಬೇಕು.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `self` ಅನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು.
        // ಇದರರ್ಥ `self` `value` ರೂಪಾಂತರವಾಗಿರಬೇಕು.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// `MaybeUninit` ಕಂಟೇನರ್‌ಗಳ ಒಂದು ಶ್ರೇಣಿಯಿಂದ ಮೌಲ್ಯಗಳನ್ನು ಹೊರತೆಗೆಯುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// ರಚನೆಯ ಎಲ್ಲಾ ಅಂಶಗಳು ಪ್ರಾರಂಭಿಕ ಸ್ಥಿತಿಯಲ್ಲಿವೆ ಎಂದು ಖಾತರಿಪಡಿಸುವುದು ಕರೆ ಮಾಡುವವರಿಗೆ ಬಿಟ್ಟದ್ದು.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // ಸುರಕ್ಷತೆ: ನಾವು ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದಂತೆ ಈಗ ಸುರಕ್ಷಿತವಾಗಿದೆ
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * ರಚನೆಯ ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ ಎಂದು ಕರೆ ಮಾಡುವವರು ಖಾತರಿಪಡಿಸುತ್ತಾರೆ
        // * `MaybeUninit<T>` ಮತ್ತು ಟಿ ಒಂದೇ ವಿನ್ಯಾಸವನ್ನು ಹೊಂದುವ ಭರವಸೆ ಇದೆ
        // * ಬಹುಶಃ ಯುನಿಂಟ್ ಇಳಿಯುವುದಿಲ್ಲ, ಆದ್ದರಿಂದ ಯಾವುದೇ ಡಬಲ್-ಫ್ರೀಗಳಿಲ್ಲ ಮತ್ತು ಆದ್ದರಿಂದ ಪರಿವರ್ತನೆ ಸುರಕ್ಷಿತವಾಗಿದೆ
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ ಎಂದು uming ಹಿಸಿ, ಅವರಿಗೆ ಒಂದು ಸ್ಲೈಸ್ ಪಡೆಯಿರಿ.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` ಅಂಶಗಳು ನಿಜವಾಗಿಯೂ ಪ್ರಾರಂಭಿಕ ಸ್ಥಿತಿಯಲ್ಲಿವೆ ಎಂದು ಖಾತರಿಪಡಿಸುವುದು ಕರೆ ಮಾಡುವವರಿಗೆ ಬಿಟ್ಟದ್ದು.
    ///
    /// ವಿಷಯವನ್ನು ಇನ್ನೂ ಸಂಪೂರ್ಣವಾಗಿ ಪ್ರಾರಂಭಿಸದಿದ್ದಾಗ ಇದನ್ನು ಕರೆಯುವುದು ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
    ///
    /// ಹೆಚ್ಚಿನ ವಿವರಗಳು ಮತ್ತು ಉದಾಹರಣೆಗಳಿಗಾಗಿ [`assume_init_ref`] ನೋಡಿ.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // ಸುರಕ್ಷತೆ: `*const [T]` ಗೆ ಸ್ಲೈಸ್ ಬಿತ್ತರಿಸುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ಕರೆ ಮಾಡುವವರು ಅದನ್ನು ಖಾತರಿಪಡಿಸುತ್ತಾರೆ
        // `slice` ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ, ಮತ್ತು `ಮೇಬೂನಿನಿಟ್` `T` ನಂತೆಯೇ ವಿನ್ಯಾಸವನ್ನು ಹೊಂದಿರುವುದು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
        // ಪಡೆದ ಪಾಯಿಂಟರ್ ಮಾನ್ಯವಾಗಿರುತ್ತದೆ ಏಕೆಂದರೆ ಇದು `slice` ಒಡೆತನದ ಮೆಮೊರಿಯನ್ನು ಉಲ್ಲೇಖಿಸುತ್ತದೆ ಮತ್ತು ಇದು ಒಂದು ಉಲ್ಲೇಖವಾಗಿದೆ ಮತ್ತು ಆದ್ದರಿಂದ ಓದಲು ಮಾನ್ಯವಾಗಿರುತ್ತದೆ.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ ಎಂದು uming ಹಿಸಿ, ಅವರಿಗೆ ರೂಪಾಂತರಿತ ಸ್ಲೈಸ್ ಪಡೆಯಿರಿ.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` ಅಂಶಗಳು ನಿಜವಾಗಿಯೂ ಪ್ರಾರಂಭಿಕ ಸ್ಥಿತಿಯಲ್ಲಿವೆ ಎಂದು ಖಾತರಿಪಡಿಸುವುದು ಕರೆ ಮಾಡುವವರಿಗೆ ಬಿಟ್ಟದ್ದು.
    ///
    /// ವಿಷಯವನ್ನು ಇನ್ನೂ ಸಂಪೂರ್ಣವಾಗಿ ಪ್ರಾರಂಭಿಸದಿದ್ದಾಗ ಇದನ್ನು ಕರೆಯುವುದು ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
    ///
    /// ಹೆಚ್ಚಿನ ವಿವರಗಳು ಮತ್ತು ಉದಾಹರಣೆಗಳಿಗಾಗಿ [`assume_init_mut`] ನೋಡಿ.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // ಸುರಕ್ಷತೆ: `slice_get_ref` ಗಾಗಿ ಸುರಕ್ಷತಾ ಟಿಪ್ಪಣಿಗಳನ್ನು ಹೋಲುತ್ತದೆ, ಆದರೆ ನಮ್ಮಲ್ಲಿ ಒಂದು ಇದೆ
        // ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವು ಬರಹಗಳಿಗೆ ಮಾನ್ಯವಾಗಿರುತ್ತದೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// ರಚನೆಯ ಮೊದಲ ಅಂಶಕ್ಕೆ ಪಾಯಿಂಟರ್ ಪಡೆಯುತ್ತದೆ.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// ರಚನೆಯ ಮೊದಲ ಅಂಶಕ್ಕೆ ರೂಪಾಂತರಿತ ಪಾಯಿಂಟರ್ ಅನ್ನು ಪಡೆಯುತ್ತದೆ.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// `src` ನಿಂದ `this` ಗೆ ಅಂಶಗಳನ್ನು ನಕಲಿಸುತ್ತದೆ, `this` ನ ಈಗ ಪ್ರಾರಂಭಿಸದ ವಿಷಯಗಳಿಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// `T` `Copy` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸದಿದ್ದರೆ, [`write_slice_cloned`] ಬಳಸಿ
    ///
    /// ಇದು [`slice::copy_from_slice`] ಗೆ ಹೋಲುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// ಎರಡು ಚೂರುಗಳು ವಿಭಿನ್ನ ಉದ್ದಗಳನ್ನು ಹೊಂದಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // ಸುರಕ್ಷತೆ: ನಾವು ಲೆನ್‌ನ ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ಬಿಡಿ ಸಾಮರ್ಥ್ಯಕ್ಕೆ ನಕಲಿಸಿದ್ದೇವೆ
    /// // ವೆಕ್ನ ಮೊದಲ src.len() ಅಂಶಗಳು ಈಗ ಮಾನ್ಯವಾಗಿವೆ.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // ಸುರಕ್ಷತೆ: &[ಟಿ] ಮತ್ತು&[ಬಹುಶಃ ಯುನಿನಿಟ್<T>] ಒಂದೇ ವಿನ್ಯಾಸವನ್ನು ಹೊಂದಿದೆ
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // ಸುರಕ್ಷತೆ: ಮಾನ್ಯ ಅಂಶಗಳನ್ನು ಇದೀಗ `this` ಗೆ ನಕಲಿಸಲಾಗಿದೆ ಆದ್ದರಿಂದ ಅದನ್ನು ನಿಷ್ಕ್ರಿಯಗೊಳಿಸಲಾಗಿದೆ
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// `src` ನಿಂದ `this` ಗೆ ಅಂಶಗಳನ್ನು ಕ್ಲೋನ್ ಮಾಡುತ್ತದೆ, ಈಗ `this` ನ ಪ್ರಾರಂಭವಿಲ್ಲದ ವಿಷಯಗಳಿಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ನೀಡುತ್ತದೆ.
    /// ಈಗಾಗಲೇ ಪ್ರಾರಂಭಿಸದ ಯಾವುದೇ ಅಂಶಗಳನ್ನು ಕೈಬಿಡಲಾಗುವುದಿಲ್ಲ.
    ///
    /// `T` `Copy` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದರೆ, [`write_slice`] ಬಳಸಿ
    ///
    /// ಇದು [`slice::clone_from_slice`] ಗೆ ಹೋಲುತ್ತದೆ ಆದರೆ ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ ಅಂಶಗಳನ್ನು ಬಿಡುವುದಿಲ್ಲ.
    ///
    /// # Panics
    ///
    /// ಎರಡು ಚೂರುಗಳು ವಿಭಿನ್ನ ಉದ್ದಗಳನ್ನು ಹೊಂದಿದ್ದರೆ ಅಥವಾ `Clone` panics ನ ಅನುಷ್ಠಾನವನ್ನು ಹೊಂದಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
    ///
    /// panic ಇದ್ದರೆ, ಈಗಾಗಲೇ ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮಾಡಲಾದ ಅಂಶಗಳನ್ನು ಕೈಬಿಡಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // ಸುರಕ್ಷತೆ: ನಾವು ಲೆನ್‌ನ ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ಬಿಡಿ ಸಾಮರ್ಥ್ಯಕ್ಕೆ ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮಾಡಿದ್ದೇವೆ
    /// // ವೆಕ್ನ ಮೊದಲ src.len() ಅಂಶಗಳು ಈಗ ಮಾನ್ಯವಾಗಿವೆ.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // Copy_from_slice ನಂತೆ ಇದು ಸ್ಲೈಸ್‌ನಲ್ಲಿ ಕ್ಲೋನ್_ಫ್ರಾಮ್_ಸ್ಲೈಸ್ ಎಂದು ಕರೆಯುವುದಿಲ್ಲ, ಏಕೆಂದರೆ `MaybeUninit<T: Clone>` ಕ್ಲೋನ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದಿಲ್ಲ.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // ಸುರಕ್ಷತೆ: ಈ ಕಚ್ಚಾ ಸ್ಲೈಸ್ ಪ್ರಾರಂಭಿಕ ವಸ್ತುಗಳನ್ನು ಮಾತ್ರ ಹೊಂದಿರುತ್ತದೆ
                // ಅದಕ್ಕಾಗಿಯೇ, ಅದನ್ನು ಬಿಡಲು ಅನುಮತಿಸಲಾಗಿದೆ.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: ನಾವು ಅವುಗಳನ್ನು ಒಂದೇ ಉದ್ದಕ್ಕೆ ಸ್ಪಷ್ಟವಾಗಿ ಕತ್ತರಿಸಬೇಕಾಗಿದೆ
        // ಬೌಂಡ್ಸ್ ಚೆಕಿಂಗ್ ಅನ್ನು ಎಲೈಡ್ ಮಾಡಲು, ಮತ್ತು ಆಪ್ಟಿಮೈಜರ್ ಸರಳ ಸಂದರ್ಭಗಳಲ್ಲಿ ಮೆಮ್‌ಕ್ಪಿಯನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ (ಉದಾಹರಣೆಗೆ ಟಿ=ಎಕ್ಸ್‌00 ಎಕ್ಸ್).
        //
        let len = this.len();
        let src = &src[..len];

        // ಗಾರ್ಡ್ ಅಗತ್ಯವಿದೆ b/c panic ತದ್ರೂಪಿ ಸಮಯದಲ್ಲಿ ಸಂಭವಿಸಬಹುದು
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // ಸುರಕ್ಷತೆ: ಮಾನ್ಯ ಅಂಶಗಳನ್ನು ಇದೀಗ `this` ಗೆ ಬರೆಯಲಾಗಿದೆ ಆದ್ದರಿಂದ ಅದನ್ನು ನಿಷ್ಕ್ರಿಯಗೊಳಿಸಲಾಗಿದೆ
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}