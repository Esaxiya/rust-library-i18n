//! 32-ಬಿಟ್ ಸಹಿ ಮಾಡಿದ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರದ ಸ್ಥಿರಾಂಕಗಳು.
//!
//! *[See also the `i32` primitive type][i32].*
//!
//! ಹೊಸ ಕೋಡ್ ಸಂಬಂಧಿತ ಸ್ಥಿರಾಂಕಗಳನ್ನು ನೇರವಾಗಿ ಪ್ರಾಚೀನ ಪ್ರಕಾರದಲ್ಲಿ ಬಳಸಬೇಕು.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i32`"
)]

int_module! { i32 }