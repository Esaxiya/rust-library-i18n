//! 128-ಬಿಟ್ ಸಹಿ ಮಾಡಿದ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರದ ಸ್ಥಿರಾಂಕಗಳು.
//!
//! *[See also the `i128` primitive type][i128].*
//!
//! ಹೊಸ ಕೋಡ್ ಸಂಬಂಧಿತ ಸ್ಥಿರಾಂಕಗಳನ್ನು ನೇರವಾಗಿ ಪ್ರಾಚೀನ ಪ್ರಕಾರದಲ್ಲಿ ಬಳಸಬೇಕು.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i128`"
)]

int_module! { i128, #[stable(feature = "i128", since="1.26.0")] }