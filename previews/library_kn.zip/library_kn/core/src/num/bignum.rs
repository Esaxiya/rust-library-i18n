//! ಕಸ್ಟಮ್ ಅನಿಯಂತ್ರಿತ-ನಿಖರ ಸಂಖ್ಯೆ (bignum) ಅನುಷ್ಠಾನ.
//!
//! ಸ್ಟಾಕ್ ಮೆಮೊರಿಯ ವೆಚ್ಚದಲ್ಲಿ ರಾಶಿ ಹಂಚಿಕೆಯನ್ನು ತಪ್ಪಿಸಲು ಇದನ್ನು ವಿನ್ಯಾಸಗೊಳಿಸಲಾಗಿದೆ.
//! ಹೆಚ್ಚು ಬಳಸಿದ ಬಿಗ್ನಮ್ ಪ್ರಕಾರ, `Big32x40`, 32 × 40=1,280 ಬಿಟ್‌ಗಳಿಂದ ಸೀಮಿತವಾಗಿದೆ ಮತ್ತು ಇದು 160 ಬೈಟ್‌ಗಳ ಸ್ಟಾಕ್ ಮೆಮೊರಿಯನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
//! ಸಾಧ್ಯವಿರುವ ಎಲ್ಲ ಸೀಮಿತ `f64` ಮೌಲ್ಯಗಳನ್ನು ರೌಂಡ್-ಟ್ರಿಪ್ಪಿಂಗ್ ಮಾಡಲು ಇದು ಸಾಕಷ್ಟು ಹೆಚ್ಚು.
//!
//! ತಾತ್ವಿಕವಾಗಿ ವಿಭಿನ್ನ ಒಳಹರಿವುಗಳಿಗಾಗಿ ಅನೇಕ ಬಿಗ್ನಮ್ ಪ್ರಕಾರಗಳನ್ನು ಹೊಂದಲು ಸಾಧ್ಯವಿದೆ, ಆದರೆ ಕೋಡ್ ಉಬ್ಬಿಕೊಳ್ಳುವುದನ್ನು ತಪ್ಪಿಸಲು ನಾವು ಹಾಗೆ ಮಾಡುವುದಿಲ್ಲ.
//!
//! ಪ್ರತಿಯೊಂದು ಬಿಗ್ನಮ್ ಅನ್ನು ನಿಜವಾದ ಬಳಕೆಗಳಿಗಾಗಿ ಇನ್ನೂ ಟ್ರ್ಯಾಕ್ ಮಾಡಲಾಗಿದೆ, ಆದ್ದರಿಂದ ಇದು ಸಾಮಾನ್ಯವಾಗಿ ಅಪ್ರಸ್ತುತವಾಗುತ್ತದೆ.
//!

// ಈ ಮಾಡ್ಯೂಲ್ dec2flt ಮತ್ತು flt2dec ಗೆ ಮಾತ್ರ, ಮತ್ತು ಕೋರೆಟೆಸ್ಟ್‌ಗಳ ಕಾರಣದಿಂದಾಗಿ ಸಾರ್ವಜನಿಕವಾಗಿದೆ.
// ಇದು ಎಂದಿಗೂ ಸ್ಥಿರಗೊಳ್ಳುವ ಉದ್ದೇಶವನ್ನು ಹೊಂದಿಲ್ಲ.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// ಬಿಗ್ನಮ್‌ಗಳಿಗೆ ಅಗತ್ಯವಿರುವ ಅಂಕಗಣಿತದ ಕಾರ್ಯಾಚರಣೆಗಳು.
pub trait FullOps: Sized {
    /// `(carry', v')` ಅಂದರೆ `carry' * 2^W + v' = self + other + carry` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಇಲ್ಲಿ `W` ಎಂಬುದು `Self` ನಲ್ಲಿನ ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆ.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// `(carry', v')` ಅಂದರೆ `carry'*2^W + v' = self* other + carry` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಇಲ್ಲಿ `W` ಎಂಬುದು `Self` ನಲ್ಲಿನ ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆ.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// `(carry', v')` ಅಂದರೆ `carry'*2^W + v' = self* other + other2 + carry` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಇಲ್ಲಿ `W` ಎಂಬುದು `Self` ನಲ್ಲಿನ ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆ.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// `borrow *2^W + self = quo* other + rem` ಮತ್ತು `0 <= rem < other` ನಂತಹ `(quo, rem)` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಇಲ್ಲಿ `W` ಎಂಬುದು `Self` ನಲ್ಲಿನ ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆ.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // ಇದು ಉಕ್ಕಿ ಹರಿಯಲು ಸಾಧ್ಯವಿಲ್ಲ;output ಟ್ಪುಟ್ `0` ಮತ್ತು `2 * 2^nbits - 1` ನಡುವೆ ಇರುತ್ತದೆ.
                    // FIXME: ಎಲ್‌ಎಲ್‌ವಿಎಂ ಇದನ್ನು ಎಡಿಸಿ ಅಥವಾ ಅಂತಹುದೇ ಆಗಿ ಉತ್ತಮಗೊಳಿಸುತ್ತದೆ?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // ಇದು ಉಕ್ಕಿ ಹರಿಯಲು ಸಾಧ್ಯವಿಲ್ಲ;
                    // output ಟ್ಪುಟ್ `0` ಮತ್ತು `2^nbits * (2^nbits - 1)` ನಡುವೆ ಇರುತ್ತದೆ.
                    // FIXME: ಎಲ್‌ಎಲ್‌ವಿಎಂ ಇದನ್ನು ಎಡಿಸಿ ಅಥವಾ ಅಂತಹುದೇ ಆಗಿ ಉತ್ತಮಗೊಳಿಸುತ್ತದೆ?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // ಇದು ಉಕ್ಕಿ ಹರಿಯಲು ಸಾಧ್ಯವಿಲ್ಲ;
                    // output ಟ್ಪುಟ್ `0` ಮತ್ತು `2^nbits * (2^nbits - 1)` ನಡುವೆ ಇರುತ್ತದೆ.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // ಇದು ಉಕ್ಕಿ ಹರಿಯಲು ಸಾಧ್ಯವಿಲ್ಲ;output ಟ್ಪುಟ್ `0` ಮತ್ತು `other * (2^nbits - 1)` ನಡುವೆ ಇರುತ್ತದೆ.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // ಇದನ್ನು ಸಕ್ರಿಯಗೊಳಿಸಲು RFC #521 ನೋಡಿ.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// ಅಂಕೆಗಳಲ್ಲಿ ಪ್ರತಿನಿಧಿಸಬಹುದಾದ 5 ಅಧಿಕಾರಗಳ ಪಟ್ಟಿ.ನಿರ್ದಿಷ್ಟವಾಗಿ ಹೇಳುವುದಾದರೆ, ಐದು ಶಕ್ತಿಗಳಿರುವ ಅತಿದೊಡ್ಡ {u8, u16, u32} ಮೌಲ್ಯ, ಮತ್ತು ಅನುಗುಣವಾದ ಘಾತಾಂಕ.
/// `mul_pow5` ನಲ್ಲಿ ಬಳಸಲಾಗುತ್ತದೆ.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// ಸ್ಟಾಕ್-ನಿಯೋಜಿಸಲಾದ ಅನಿಯಂತ್ರಿತ-ನಿಖರತೆ (ನಿರ್ದಿಷ್ಟ ಮಿತಿಯವರೆಗೆ) ಪೂರ್ಣಾಂಕ.
        ///
        /// ನಿರ್ದಿಷ್ಟ ಪ್ರಕಾರದ ("digit") ನ ಸ್ಥಿರ-ಗಾತ್ರದ ರಚನೆಯಿಂದ ಇದನ್ನು ಬೆಂಬಲಿಸಲಾಗುತ್ತದೆ.
        /// ರಚನೆಯು ತುಂಬಾ ದೊಡ್ಡದಲ್ಲವಾದರೂ (ಸಾಮಾನ್ಯವಾಗಿ ಕೆಲವು ನೂರು ಬೈಟ್‌ಗಳು), ಅದನ್ನು ಅಜಾಗರೂಕತೆಯಿಂದ ನಕಲಿಸುವುದು ಕಾರ್ಯಕ್ಷಮತೆಯ ಹಿಟ್‌ಗೆ ಕಾರಣವಾಗಬಹುದು.
        ///
        /// ಆದ್ದರಿಂದ ಇದು ಉದ್ದೇಶಪೂರ್ವಕವಾಗಿ `Copy` ಅಲ್ಲ.
        ///
        /// ಉಕ್ಕಿ ಹರಿಯುವ ಸಂದರ್ಭದಲ್ಲಿ ಬಿಗ್ನಮ್‌ಗಳು panic ಗೆ ಲಭ್ಯವಿರುವ ಎಲ್ಲಾ ಕಾರ್ಯಾಚರಣೆಗಳು.
        /// ಸಾಕಷ್ಟು ದೊಡ್ಡ ಬಿಗ್ನಮ್ ಪ್ರಕಾರಗಳನ್ನು ಬಳಸಲು ಕರೆ ಮಾಡುವವರು ಜವಾಬ್ದಾರರಾಗಿರುತ್ತಾರೆ.
        pub struct $name {
            /// ಒಂದು ಪ್ಲಸ್ ಬಳಕೆಯಲ್ಲಿರುವ ಗರಿಷ್ಠ "digit" ಗೆ ಆಫ್‌ಸೆಟ್.
            /// ಇದು ಕಡಿಮೆಯಾಗುವುದಿಲ್ಲ, ಆದ್ದರಿಂದ ಗಣನೆಯ ಕ್ರಮದ ಬಗ್ಗೆ ತಿಳಿದಿರಲಿ.
            /// `base[size..]` ಶೂನ್ಯವಾಗಿರಬೇಕು.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` `a + b *2^W + c* 2^(2W) + ...` ಅನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ, ಅಲ್ಲಿ `W` ಎಂಬುದು ಅಂಕಿಯ ಪ್ರಕಾರದ ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆ.
            base: [$ty; $n],
        }

        impl $name {
            /// ಒಂದು ಅಂಕಿಯಿಂದ ಬಿಗ್ನಮ್ ಮಾಡುತ್ತದೆ.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// `u64` ಮೌಲ್ಯದಿಂದ ಬಿಗ್ನಮ್ ಮಾಡುತ್ತದೆ.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// ಆಂತರಿಕ ಅಂಕೆಗಳನ್ನು ಸ್ಲೈಸ್ `[a, b, c, ...]` ಎಂದು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಂದರೆ ಸಂಖ್ಯಾ ಮೌಲ್ಯವು `a + b *2^W + c* 2^(2W) + ...` ಆಗಿದ್ದು, `W` ಎಂಬುದು ಅಂಕಿಯ ಪ್ರಕಾರದ ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆ.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// `I`-th ಬಿಟ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಲ್ಲಿ ಬಿಟ್ 0 ಕಡಿಮೆ ಮಹತ್ವದ್ದಾಗಿದೆ.
            /// ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, ತೂಕ `2^i` ನೊಂದಿಗೆ ಬಿಟ್.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// ಬಿಗ್ನಮ್ ಶೂನ್ಯವಾಗಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// ಈ ಮೌಲ್ಯವನ್ನು ಪ್ರತಿನಿಧಿಸಲು ಅಗತ್ಯವಾದ ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
            /// ಶೂನ್ಯಕ್ಕೆ 0 ಬಿಟ್‌ಗಳ ಅಗತ್ಯವಿದೆ ಎಂದು ಪರಿಗಣಿಸಲಾಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
            pub fn bit_length(&self) -> usize {
                // ಶೂನ್ಯವಾಗಿರುವ ಅತ್ಯಂತ ಗಮನಾರ್ಹವಾದ ಅಂಕೆಗಳನ್ನು ಬಿಟ್ಟುಬಿಡಿ.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // ಶೂನ್ಯೇತರ ಅಂಕೆಗಳಿಲ್ಲ, ಅಂದರೆ, ಸಂಖ್ಯೆ ಶೂನ್ಯವಾಗಿರುತ್ತದೆ.
                    return 0;
                }
                // ಇದನ್ನು leading_zeros() ಮತ್ತು ಬಿಟ್ ಶಿಫ್ಟ್‌ಗಳೊಂದಿಗೆ ಹೊಂದುವಂತೆ ಮಾಡಬಹುದು, ಆದರೆ ಅದು ಬಹುಶಃ ಜಗಳಕ್ಕೆ ಯೋಗ್ಯವಾಗಿಲ್ಲ.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// `other` ಅನ್ನು ಸ್ವತಃ ಸೇರಿಸುತ್ತದೆ ಮತ್ತು ತನ್ನದೇ ಆದ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ನೀಡುತ್ತದೆ.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// `other` ಅನ್ನು ಸ್ವತಃ ತಾನೇ ಕಳೆಯುತ್ತದೆ ಮತ್ತು ತನ್ನದೇ ಆದ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ನೀಡುತ್ತದೆ.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// ಅಂಕಿ-ಗಾತ್ರದ `other` ನಿಂದ ಸ್ವತಃ ಗುಣಿಸುತ್ತದೆ ಮತ್ತು ತನ್ನದೇ ಆದ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ನೀಡುತ್ತದೆ.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// `2^bits` ನಿಂದ ಸ್ವತಃ ಗುಣಿಸುತ್ತದೆ ಮತ್ತು ತನ್ನದೇ ಆದ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ನೀಡುತ್ತದೆ.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // `digits * digitbits` ಬಿಟ್‌ಗಳಿಂದ ಬದಲಾಯಿಸಿ
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // `bits` ಬಿಟ್‌ಗಳಿಂದ ಬದಲಾಯಿಸಿ
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [.. ಅಂಕೆಗಳು] ಶೂನ್ಯವಾಗಿದೆ, ಸ್ಥಳಾಂತರಿಸುವ ಅಗತ್ಯವಿಲ್ಲ
                }

                self.size = sz;
                self
            }

            /// `5^e` ನಿಂದ ಸ್ವತಃ ಗುಣಿಸುತ್ತದೆ ಮತ್ತು ತನ್ನದೇ ಆದ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ನೀಡುತ್ತದೆ.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // 2 ^ n ನಲ್ಲಿ ನಿಖರವಾಗಿ n ಹಿಂದುಳಿದಿರುವ ಸೊನ್ನೆಗಳಿವೆ, ಮತ್ತು ಕೇವಲ ಸಂಬಂಧಿತ ಅಂಕಿಯ ಗಾತ್ರಗಳು ಸತತ ಎರಡು ಶಕ್ತಿಗಳಾಗಿವೆ, ಆದ್ದರಿಂದ ಇದು ಟೇಬಲ್‌ಗೆ ಸೂಕ್ತವಾದ ಸೂಚ್ಯಂಕವಾಗಿದೆ.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // ಸಾಧ್ಯವಾದಷ್ಟು ದೊಡ್ಡ ಏಕ-ಅಂಕಿಯ ಶಕ್ತಿಯೊಂದಿಗೆ ಗುಣಿಸಿ ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... ನಂತರ ಉಳಿದವನ್ನು ಮುಗಿಸಿ.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` ವಿವರಿಸಿದ ಸಂಖ್ಯೆಯಿಂದ ಸ್ವತಃ ಗುಣಿಸುತ್ತದೆ (ಇಲ್ಲಿ `W` ಎಂಬುದು ಅಂಕಿಯ ಪ್ರಕಾರದ ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆ) ಮತ್ತು ತನ್ನದೇ ಆದ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ನೀಡುತ್ತದೆ.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // ಆಂತರಿಕ ದಿನಚರಿ.aa.len() <= bb.len() ಇದ್ದಾಗ ಉತ್ತಮವಾಗಿ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ.
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// ಅಂಕಿ-ಗಾತ್ರದ `other` ನಿಂದ ಸ್ವತಃ ವಿಭಜಿಸುತ್ತದೆ ಮತ್ತು ತನ್ನದೇ ಆದ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು *ಮತ್ತು* ಉಳಿದವನ್ನು ನೀಡುತ್ತದೆ.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// ಮತ್ತೊಂದು ಬಿಗ್ನಮ್‌ನಿಂದ ಸ್ವಯಂ ಭಾಗಿಸಿ, `q` ಅನ್ನು ಅಂಶದೊಂದಿಗೆ ಮತ್ತು `r` ಅನ್ನು ಉಳಿದ ಭಾಗಗಳೊಂದಿಗೆ ತಿದ್ದಿ ಬರೆಯುತ್ತದೆ.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // ಸ್ಟುಪಿಡ್ ನಿಧಾನ base-2 ಉದ್ದ ವಿಭಾಗವನ್ನು ತೆಗೆದುಕೊಳ್ಳಲಾಗಿದೆ
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME ದೀರ್ಘ ವಿಭಾಗಕ್ಕಾಗಿ ಹೆಚ್ಚಿನ ಬೇಸ್ ($ty) ಅನ್ನು ಬಳಸುತ್ತದೆ.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // Q ನ 1 ಬಿಟ್ `i` ಅನ್ನು ಹೊಂದಿಸಿ.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// `Big32x40` ಗಾಗಿ ಅಂಕಿಯ ಪ್ರಕಾರ.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// ಇದನ್ನು ಪರೀಕ್ಷೆಗೆ ಮಾತ್ರ ಬಳಸಲಾಗುತ್ತದೆ.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}