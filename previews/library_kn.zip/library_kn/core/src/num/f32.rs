//! `f32` ಏಕ-ನಿಖರ ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಪ್ರಕಾರಕ್ಕೆ ನಿರ್ದಿಷ್ಟವಾದ ಸ್ಥಿರಾಂಕಗಳು.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! `consts` ಉಪ-ಮಾಡ್ಯೂಲ್‌ನಲ್ಲಿ ಗಣಿತದ ಮಹತ್ವದ ಸಂಖ್ಯೆಗಳನ್ನು ಒದಗಿಸಲಾಗಿದೆ.
//!
//! ಈ ಮಾಡ್ಯೂಲ್‌ನಲ್ಲಿ ನೇರವಾಗಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ಸ್ಥಿರಾಂಕಗಳಿಗಾಗಿ (`consts` ಉಪ-ಮಾಡ್ಯೂಲ್‌ನಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಿದಂತೆ ಭಿನ್ನವಾಗಿ), ಹೊಸ ಕೋಡ್ ಬದಲಿಗೆ `f32` ಪ್ರಕಾರದಲ್ಲಿ ನೇರವಾಗಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ಸಂಯೋಜಿತ ಸ್ಥಿರಾಂಕಗಳನ್ನು ಬಳಸಬೇಕು.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// `f32` ನ ಆಂತರಿಕ ಪ್ರಾತಿನಿಧ್ಯದ ರಾಡಿಕ್ಸ್ ಅಥವಾ ಬೇಸ್.
/// ಬದಲಿಗೆ [`f32::RADIX`] ಬಳಸಿ.
///
/// # Examples
///
/// ```rust
/// // ಅಸಮ್ಮತಿಸಿದ ದಾರಿ
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // ಉದ್ದೇಶಿತ ಮಾರ್ಗ
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// ಮೂಲ 2 ರಲ್ಲಿ ಗಮನಾರ್ಹ ಅಂಕೆಗಳ ಸಂಖ್ಯೆ.
/// ಬದಲಿಗೆ [`f32::MANTISSA_DIGITS`] ಬಳಸಿ.
///
/// # Examples
///
/// ```rust
/// // ಅಸಮ್ಮತಿಸಿದ ದಾರಿ
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // ಉದ್ದೇಶಿತ ಮಾರ್ಗ
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// ಮೂಲ 10 ರಲ್ಲಿನ ಗಮನಾರ್ಹ ಅಂಕಿಗಳ ಅಂದಾಜು ಸಂಖ್ಯೆ.
/// ಬದಲಿಗೆ [`f32::DIGITS`] ಬಳಸಿ.
///
/// # Examples
///
/// ```rust
/// // ಅಸಮ್ಮತಿಸಿದ ದಾರಿ
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // ಉದ್ದೇಶಿತ ಮಾರ್ಗ
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] `f32` ಗಾಗಿ ಮೌಲ್ಯ.
/// ಬದಲಿಗೆ [`f32::EPSILON`] ಬಳಸಿ.
///
/// ಇದು `1.0` ಮತ್ತು ಮುಂದಿನ ದೊಡ್ಡ ಪ್ರತಿನಿಧಿಸಬಹುದಾದ ಸಂಖ್ಯೆಯ ನಡುವಿನ ವ್ಯತ್ಯಾಸವಾಗಿದೆ.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // ಅಸಮ್ಮತಿಸಿದ ದಾರಿ
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // ಉದ್ದೇಶಿತ ಮಾರ್ಗ
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// ಸಣ್ಣ ಸೀಮಿತ `f32` ಮೌಲ್ಯ.
/// ಬದಲಿಗೆ [`f32::MIN`] ಬಳಸಿ.
///
/// # Examples
///
/// ```rust
/// // ಅಸಮ್ಮತಿಸಿದ ದಾರಿ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // ಉದ್ದೇಶಿತ ಮಾರ್ಗ
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// ಸಣ್ಣ ಧನಾತ್ಮಕ ಸಾಮಾನ್ಯ `f32` ಮೌಲ್ಯ.
/// ಬದಲಿಗೆ [`f32::MIN_POSITIVE`] ಬಳಸಿ.
///
/// # Examples
///
/// ```rust
/// // ಅಸಮ್ಮತಿಸಿದ ದಾರಿ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // ಉದ್ದೇಶಿತ ಮಾರ್ಗ
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// ಅತಿದೊಡ್ಡ ಸೀಮಿತ `f32` ಮೌಲ್ಯ.
/// ಬದಲಿಗೆ [`f32::MAX`] ಬಳಸಿ.
///
/// # Examples
///
/// ```rust
/// // ಅಸಮ್ಮತಿಸಿದ ದಾರಿ
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // ಉದ್ದೇಶಿತ ಮಾರ್ಗ
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// 2 ಘಾತಕದ ಕನಿಷ್ಠ ಸಾಮಾನ್ಯ ಶಕ್ತಿಗಿಂತ ಒಂದು ದೊಡ್ಡದು.
/// ಬದಲಿಗೆ [`f32::MIN_EXP`] ಬಳಸಿ.
///
/// # Examples
///
/// ```rust
/// // ಅಸಮ್ಮತಿಸಿದ ದಾರಿ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // ಉದ್ದೇಶಿತ ಮಾರ್ಗ
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// 2 ಘಾತಕದ ಗರಿಷ್ಠ ಸಂಭವನೀಯ ಶಕ್ತಿ.
/// ಬದಲಿಗೆ [`f32::MAX_EXP`] ಬಳಸಿ.
///
/// # Examples
///
/// ```rust
/// // ಅಸಮ್ಮತಿಸಿದ ದಾರಿ
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // ಉದ್ದೇಶಿತ ಮಾರ್ಗ
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// 10 ಘಾತಕದ ಕನಿಷ್ಠ ಸಾಮಾನ್ಯ ಶಕ್ತಿ.
/// ಬದಲಿಗೆ [`f32::MIN_10_EXP`] ಬಳಸಿ.
///
/// # Examples
///
/// ```rust
/// // ಅಸಮ್ಮತಿಸಿದ ದಾರಿ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // ಉದ್ದೇಶಿತ ಮಾರ್ಗ
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// 10 ಘಾತಕದ ಗರಿಷ್ಠ ಸಂಭವನೀಯ ಶಕ್ತಿ.
/// ಬದಲಿಗೆ [`f32::MAX_10_EXP`] ಬಳಸಿ.
///
/// # Examples
///
/// ```rust
/// // ಅಸಮ್ಮತಿಸಿದ ದಾರಿ
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // ಉದ್ದೇಶಿತ ಮಾರ್ಗ
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// ಸಂಖ್ಯೆ (NaN) ಅಲ್ಲ.
/// ಬದಲಿಗೆ [`f32::NAN`] ಬಳಸಿ.
///
/// # Examples
///
/// ```rust
/// // ಅಸಮ್ಮತಿಸಿದ ದಾರಿ
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // ಉದ್ದೇಶಿತ ಮಾರ್ಗ
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// ಇನ್ಫಿನಿಟಿ ಎಕ್ಸ್ 00 ಎಕ್ಸ್.
/// ಬದಲಿಗೆ [`f32::INFINITY`] ಬಳಸಿ.
///
/// # Examples
///
/// ```rust
/// // ಅಸಮ್ಮತಿಸಿದ ದಾರಿ
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // ಉದ್ದೇಶಿತ ಮಾರ್ಗ
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// ನಕಾರಾತ್ಮಕ ಅನಂತ (−∞).
/// ಬದಲಿಗೆ [`f32::NEG_INFINITY`] ಬಳಸಿ.
///
/// # Examples
///
/// ```rust
/// // ಅಸಮ್ಮತಿಸಿದ ದಾರಿ
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // ಉದ್ದೇಶಿತ ಮಾರ್ಗ
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// ಮೂಲ ಗಣಿತ ಸ್ಥಿರಾಂಕಗಳು.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: cmath ನಿಂದ ಗಣಿತದ ಸ್ಥಿರಾಂಕಗಳೊಂದಿಗೆ ಬದಲಾಯಿಸಿ.

    /// ಆರ್ಕಿಮಿಡಿಸ್ನ ಸ್ಥಿರ (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// ಪೂರ್ಣ ವಲಯ ಸ್ಥಿರ (τ)
    ///
    /// 2π ಗೆ ಸಮಾನ.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// ಯೂಲರ್ ಸಂಖ್ಯೆ (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// `f32` ನ ಆಂತರಿಕ ಪ್ರಾತಿನಿಧ್ಯದ ರಾಡಿಕ್ಸ್ ಅಥವಾ ಬೇಸ್.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// ಮೂಲ 2 ರಲ್ಲಿ ಗಮನಾರ್ಹ ಅಂಕೆಗಳ ಸಂಖ್ಯೆ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// ಮೂಲ 10 ರಲ್ಲಿನ ಗಮನಾರ್ಹ ಅಂಕಿಗಳ ಅಂದಾಜು ಸಂಖ್ಯೆ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] `f32` ಗಾಗಿ ಮೌಲ್ಯ.
    ///
    /// ಇದು `1.0` ಮತ್ತು ಮುಂದಿನ ದೊಡ್ಡ ಪ್ರತಿನಿಧಿಸಬಹುದಾದ ಸಂಖ್ಯೆಯ ನಡುವಿನ ವ್ಯತ್ಯಾಸವಾಗಿದೆ.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// ಸಣ್ಣ ಸೀಮಿತ `f32` ಮೌಲ್ಯ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// ಸಣ್ಣ ಧನಾತ್ಮಕ ಸಾಮಾನ್ಯ `f32` ಮೌಲ್ಯ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// ಅತಿದೊಡ್ಡ ಸೀಮಿತ `f32` ಮೌಲ್ಯ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// 2 ಘಾತಕದ ಕನಿಷ್ಠ ಸಾಮಾನ್ಯ ಶಕ್ತಿಗಿಂತ ಒಂದು ದೊಡ್ಡದು.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// 2 ಘಾತಕದ ಗರಿಷ್ಠ ಸಂಭವನೀಯ ಶಕ್ತಿ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// 10 ಘಾತಕದ ಕನಿಷ್ಠ ಸಾಮಾನ್ಯ ಶಕ್ತಿ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// 10 ಘಾತಕದ ಗರಿಷ್ಠ ಸಂಭವನೀಯ ಶಕ್ತಿ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// ಸಂಖ್ಯೆ (NaN) ಅಲ್ಲ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// ಇನ್ಫಿನಿಟಿ ಎಕ್ಸ್ 00 ಎಕ್ಸ್.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// ನಕಾರಾತ್ಮಕ ಅನಂತ (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// ಈ ಮೌಲ್ಯವು `NaN` ಆಗಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): ಪೋರ್ಟಬಿಲಿಟಿ ಬಗ್ಗೆ ಕಳವಳದಿಂದಾಗಿ ಎಕ್ಸ್‌00 ಎಕ್ಸ್ ಸಾರ್ವಜನಿಕವಾಗಿ ಲಿಬ್‌ಕೋರ್‌ನಲ್ಲಿ ಲಭ್ಯವಿಲ್ಲ, ಆದ್ದರಿಂದ ಈ ಅನುಷ್ಠಾನವು ಆಂತರಿಕವಾಗಿ ಖಾಸಗಿ ಬಳಕೆಗಾಗಿರುತ್ತದೆ.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// ಈ ಮೌಲ್ಯವು ಸಕಾರಾತ್ಮಕ ಅನಂತ ಅಥವಾ negative ಣಾತ್ಮಕ ಅನಂತವಾಗಿದ್ದರೆ ಮತ್ತು `false` ಇಲ್ಲದಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// ಈ ಸಂಖ್ಯೆ ಅನಂತ ಅಥವಾ `NaN` ಆಗಿಲ್ಲದಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // NaN ಅನ್ನು ಪ್ರತ್ಯೇಕವಾಗಿ ನಿರ್ವಹಿಸುವ ಅಗತ್ಯವಿಲ್ಲ: ಸ್ವಯಂ NaN ಆಗಿದ್ದರೆ, ಹೋಲಿಕೆ ನಿಜವಲ್ಲ, ನಿಖರವಾಗಿ ಬಯಸಿದಂತೆ.
        //
        self.abs_private() < Self::INFINITY
    }

    /// ಸಂಖ್ಯೆ [subnormal] ಆಗಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // `0` ಮತ್ತು `min` ನಡುವಿನ ಮೌಲ್ಯಗಳು ಸಬ್ನಾರ್ಮಲ್.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// ಸಂಖ್ಯೆ ಶೂನ್ಯ, ಅನಂತ, [subnormal], ಅಥವಾ `NaN` ಆಗಿಲ್ಲದಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // `0` ಮತ್ತು `min` ನಡುವಿನ ಮೌಲ್ಯಗಳು ಸಬ್ನಾರ್ಮಲ್.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// ಸಂಖ್ಯೆಯ ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ವರ್ಗವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಕೇವಲ ಒಂದು ಆಸ್ತಿಯನ್ನು ಪರೀಕ್ಷಿಸಲು ಹೋದರೆ, ಬದಲಿಗೆ ನಿರ್ದಿಷ್ಟ ಮುನ್ಸೂಚನೆಯನ್ನು ಬಳಸುವುದು ಸಾಮಾನ್ಯವಾಗಿ ವೇಗವಾಗಿರುತ್ತದೆ.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// `+0.0`, ಧನಾತ್ಮಕ ಚಿಹ್ನೆ ಬಿಟ್ ಮತ್ತು ಧನಾತ್ಮಕ ಅನಂತತೆಯೊಂದಿಗೆ `NaN`ಗಳು ಸೇರಿದಂತೆ `self` ಧನಾತ್ಮಕ ಚಿಹ್ನೆಯನ್ನು ಹೊಂದಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// X002, X ಣಾತ್ಮಕ ಚಿಹ್ನೆ ಹೊಂದಿದ್ದರೆ `self`, negative ಣಾತ್ಮಕ ಚಿಹ್ನೆ ಬಿಟ್ ಮತ್ತು negative ಣಾತ್ಮಕ ಅನಂತತೆಯೊಂದಿಗೆ `NaN`ಗಳು.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // ಐಇಇಇ 754 ಹೇಳುತ್ತದೆ: ಎಕ್ಸ್ ನಕಾರಾತ್ಮಕ ಚಿಹ್ನೆಯನ್ನು ಹೊಂದಿದ್ದರೆ ಮಾತ್ರ ಎಕ್ಸ್ 00 ಎಕ್ಸ್ ನಿಜ.
        // isSignMinus ಸೊನ್ನೆಗಳು ಮತ್ತು NaN ಗಳಿಗೆ ಅನ್ವಯಿಸುತ್ತದೆ.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// ಒಂದು ಸಂಖ್ಯೆಯ ಪರಸ್ಪರ (inverse) ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// ರೇಡಿಯನ್‌ಗಳನ್ನು ಡಿಗ್ರಿಗಳಿಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // ಉತ್ತಮ ನಿಖರತೆಗಾಗಿ ಸ್ಥಿರವನ್ನು ಬಳಸಿ.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// ಡಿಗ್ರಿಗಳನ್ನು ರೇಡಿಯನ್‌ಗಳಾಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// ಎರಡು ಸಂಖ್ಯೆಗಳ ಗರಿಷ್ಠವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// ವಾದಗಳಲ್ಲಿ ಒಂದು NaN ಆಗಿದ್ದರೆ, ಇನ್ನೊಂದು ವಾದವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// ಎರಡು ಸಂಖ್ಯೆಗಳ ಕನಿಷ್ಠವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// ವಾದಗಳಲ್ಲಿ ಒಂದು NaN ಆಗಿದ್ದರೆ, ಇನ್ನೊಂದು ವಾದವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// ಮೌಲ್ಯವು ಸೀಮಿತವಾಗಿದೆ ಮತ್ತು ಆ ಪ್ರಕಾರಕ್ಕೆ ಹೊಂದಿಕೊಳ್ಳುತ್ತದೆ ಎಂದು uming ಹಿಸಿಕೊಂಡು ಶೂನ್ಯದ ಕಡೆಗೆ ಸುತ್ತುತ್ತದೆ ಮತ್ತು ಯಾವುದೇ ಪ್ರಾಚೀನ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಕ್ಕೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// ಮೌಲ್ಯವು ಕಡ್ಡಾಯವಾಗಿರಬೇಕು:
    ///
    /// * `NaN` ಆಗಿರಬಾರದು
    /// * ಅನಂತವಾಗಿರಬಾರದು
    /// * ಅದರ ಭಾಗಶಃ ಭಾಗವನ್ನು ಮೊಟಕುಗೊಳಿಸಿದ ನಂತರ ರಿಟರ್ನ್ ಪ್ರಕಾರ `Int` ನಲ್ಲಿ ಪ್ರತಿನಿಧಿಸಬಹುದಾಗಿದೆ
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `FloatToInt::to_int_unchecked` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// `u32` ಗೆ ಕಚ್ಚಾ ಪರಿವರ್ತನೆ.
    ///
    /// ಇದು ಪ್ರಸ್ತುತ ಎಲ್ಲಾ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ `transmute::<f32, u32>(self)` ಗೆ ಹೋಲುತ್ತದೆ.
    ///
    /// ಈ ಕಾರ್ಯಾಚರಣೆಯ ಒಯ್ಯಬಲ್ಲತೆಯ ಕುರಿತು ಕೆಲವು ಚರ್ಚೆಗಾಗಿ `from_bits` ನೋಡಿ (ಬಹುತೇಕ ಯಾವುದೇ ಸಮಸ್ಯೆಗಳಿಲ್ಲ).
    ///
    /// ಈ ಕಾರ್ಯವು `as` ಎರಕಹೊಯ್ದಕ್ಕಿಂತ ಭಿನ್ನವಾಗಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಇದು *ಸಂಖ್ಯಾ* ಮೌಲ್ಯವನ್ನು ಸಂರಕ್ಷಿಸಲು ಪ್ರಯತ್ನಿಸುತ್ತದೆ, ಆದರೆ ಬಿಟ್‌ವೈಸ್ ಮೌಲ್ಯವಲ್ಲ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() ಬಿತ್ತರಿಸುತ್ತಿಲ್ಲ!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // ಸುರಕ್ಷತೆ: `u32` ಸರಳ ಹಳೆಯ ಡೇಟಾಟೈಪ್ ಆದ್ದರಿಂದ ನಾವು ಯಾವಾಗಲೂ ಅದಕ್ಕೆ ಪರಿವರ್ತಿಸಬಹುದು
        unsafe { mem::transmute(self) }
    }

    /// `u32` ನಿಂದ ಕಚ್ಚಾ ಪರಿವರ್ತನೆ.
    ///
    /// ಇದು ಪ್ರಸ್ತುತ ಎಲ್ಲಾ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ `transmute::<u32, f32>(v)` ಗೆ ಹೋಲುತ್ತದೆ.
    /// ಎರಡು ಕಾರಣಗಳಿಗಾಗಿ ಇದು ನಂಬಲಾಗದಷ್ಟು ಪೋರ್ಟಬಲ್ ಆಗಿದೆ ಎಂದು ಅದು ತಿರುಗುತ್ತದೆ:
    ///
    /// * ಎಲ್ಲಾ ಬೆಂಬಲಿತ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಫ್ಲೋಟ್‌ಗಳು ಮತ್ತು ಇಂಟ್‌ಗಳು ಒಂದೇ ರೀತಿಯ ಮನೋಭಾವವನ್ನು ಹೊಂದಿವೆ.
    /// * ಐಇಇಇ-754 ಫ್ಲೋಟ್‌ಗಳ ಬಿಟ್ ವಿನ್ಯಾಸವನ್ನು ನಿಖರವಾಗಿ ಸೂಚಿಸುತ್ತದೆ.
    ///
    /// ಆದಾಗ್ಯೂ ಒಂದು ಎಚ್ಚರಿಕೆ ಇದೆ: ಐಇಇಇ-754 ರ 2008 ರ ಆವೃತ್ತಿಗೆ ಮೊದಲು, ನ್ಯಾನ್ ಸಿಗ್ನಲಿಂಗ್ ಬಿಟ್ ಅನ್ನು ಹೇಗೆ ವ್ಯಾಖ್ಯಾನಿಸುವುದು ಎಂಬುದನ್ನು ನಿರ್ದಿಷ್ಟವಾಗಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿಲ್ಲ.
    /// ಹೆಚ್ಚಿನ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್‌ಗಳು (ಮುಖ್ಯವಾಗಿ x86 ಮತ್ತು ARM) 2008 ರಲ್ಲಿ ಅಂತಿಮವಾಗಿ ಪ್ರಮಾಣೀಕರಿಸಲ್ಪಟ್ಟ ವ್ಯಾಖ್ಯಾನವನ್ನು ಆರಿಸಿಕೊಂಡವು, ಆದರೆ ಕೆಲವು ಮಾಡಲಿಲ್ಲ (ಮುಖ್ಯವಾಗಿ MIPS).
    /// ಪರಿಣಾಮವಾಗಿ, MIPS ನಲ್ಲಿನ ಎಲ್ಲಾ ಸಿಗ್ನಲಿಂಗ್ NaN ಗಳು x86 ನಲ್ಲಿ ಸ್ತಬ್ಧ NaN ಗಳು, ಮತ್ತು ಪ್ರತಿಯಾಗಿ.
    ///
    /// ಸಿಗ್ನಲಿಂಗ್-ನೆಸ್ ಅಡ್ಡ-ವೇದಿಕೆಯನ್ನು ಸಂರಕ್ಷಿಸಲು ಪ್ರಯತ್ನಿಸುವ ಬದಲು, ಈ ಅನುಷ್ಠಾನವು ನಿಖರವಾದ ಬಿಟ್‌ಗಳನ್ನು ಸಂರಕ್ಷಿಸಲು ಅನುಕೂಲಕರವಾಗಿದೆ.
    /// ಇದರರ್ಥ ಈ ವಿಧಾನದ ಫಲಿತಾಂಶವನ್ನು ನೆಟ್‌ವರ್ಕ್ ಮೂಲಕ x86 ಯಂತ್ರದಿಂದ MIPS ಒಂದಕ್ಕೆ ಕಳುಹಿಸಿದರೂ ಸಹ NaN ಗಳಲ್ಲಿ ಎನ್ಕೋಡ್ ಮಾಡಲಾದ ಯಾವುದೇ ಪೇಲೋಡ್‌ಗಳನ್ನು ಸಂರಕ್ಷಿಸಲಾಗುತ್ತದೆ.
    ///
    ///
    /// ಈ ವಿಧಾನದ ಫಲಿತಾಂಶಗಳನ್ನು ಉತ್ಪಾದಿಸಿದ ಅದೇ ವಾಸ್ತುಶಿಲ್ಪದಿಂದ ಮಾತ್ರ ಕುಶಲತೆಯಿಂದ ನಿರ್ವಹಿಸಿದರೆ, ಯಾವುದೇ ಪೋರ್ಟಬಿಲಿಟಿ ಕಾಳಜಿ ಇಲ್ಲ.
    ///
    /// ಇನ್ಪುಟ್ NaN ಅಲ್ಲದಿದ್ದರೆ, ಯಾವುದೇ ಪೋರ್ಟಬಿಲಿಟಿ ಕಾಳಜಿ ಇಲ್ಲ.
    ///
    /// ಸಿಗ್ನಲಿಂಗ್ ಬಗ್ಗೆ ನೀವು ಕಾಳಜಿ ವಹಿಸದಿದ್ದರೆ (ಸಾಧ್ಯತೆ), ನಂತರ ಯಾವುದೇ ಪೋರ್ಟಬಿಲಿಟಿ ಕಾಳಜಿ ಇಲ್ಲ.
    ///
    /// ಈ ಕಾರ್ಯವು `as` ಎರಕಹೊಯ್ದಕ್ಕಿಂತ ಭಿನ್ನವಾಗಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಇದು *ಸಂಖ್ಯಾ* ಮೌಲ್ಯವನ್ನು ಸಂರಕ್ಷಿಸಲು ಪ್ರಯತ್ನಿಸುತ್ತದೆ, ಆದರೆ ಬಿಟ್‌ವೈಸ್ ಮೌಲ್ಯವಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // ಸುರಕ್ಷತೆ: `u32` ಸರಳ ಹಳೆಯ ಡೇಟಾಟೈಪ್ ಆದ್ದರಿಂದ ನಾವು ಯಾವಾಗಲೂ ಅದರಿಂದ ಪರಿವರ್ತಿಸಬಹುದು
        // ಎಸ್‌ಎನ್‌ಎಎನ್‌ನೊಂದಿಗಿನ ಸುರಕ್ಷತಾ ಸಮಸ್ಯೆಗಳು ಅತಿಯಾಗಿ ಉಬ್ಬಿಕೊಂಡಿವೆ ಎಂದು ಅದು ತಿರುಗುತ್ತದೆ!ಹುರ್ರೇ!
        unsafe { mem::transmute(v) }
    }

    /// ಈ ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಸಂಖ್ಯೆಯ ಮೆಮೊರಿ ಪ್ರಾತಿನಿಧ್ಯವನ್ನು ಬಿಗ್-ಎಂಡಿಯನ್ (network) ಬೈಟ್ ಕ್ರಮದಲ್ಲಿ ಬೈಟ್ ಅರೇ ಆಗಿ ಹಿಂತಿರುಗಿ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// ಈ ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಸಂಖ್ಯೆಯ ಮೆಮೊರಿ ಪ್ರಾತಿನಿಧ್ಯವನ್ನು ಸ್ವಲ್ಪ-ಎಂಡಿಯನ್ ಬೈಟ್ ಕ್ರಮದಲ್ಲಿ ಬೈಟ್ ಅರೇ ಆಗಿ ಹಿಂತಿರುಗಿ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// ಈ ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಸಂಖ್ಯೆಯ ಮೆಮೊರಿ ಪ್ರಾತಿನಿಧ್ಯವನ್ನು ಸ್ಥಳೀಯ ಬೈಟ್ ಕ್ರಮದಲ್ಲಿ ಬೈಟ್ ಅರೇ ಆಗಿ ಹಿಂತಿರುಗಿ.
    ///
    /// ಟಾರ್ಗೆಟ್ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್‌ನ ಸ್ಥಳೀಯ ಎಂಡಿಯನೆಸ್ ಅನ್ನು ಬಳಸಿದಂತೆ, ಪೋರ್ಟಬಲ್ ಕೋಡ್ ಸೂಕ್ತವಾದಂತೆ [`to_be_bytes`] ಅಥವಾ [`to_le_bytes`] ಅನ್ನು ಬಳಸಬೇಕು.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// ಈ ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಸಂಖ್ಯೆಯ ಮೆಮೊರಿ ಪ್ರಾತಿನಿಧ್ಯವನ್ನು ಸ್ಥಳೀಯ ಬೈಟ್ ಕ್ರಮದಲ್ಲಿ ಬೈಟ್ ಅರೇ ಆಗಿ ಹಿಂತಿರುಗಿ.
    ///
    ///
    /// [`to_ne_bytes`] ಸಾಧ್ಯವಾದಾಗಲೆಲ್ಲಾ ಇದನ್ನು ಆದ್ಯತೆ ನೀಡಬೇಕು.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // ಸುರಕ್ಷತೆ: `f32` ಸರಳ ಹಳೆಯ ಡೇಟಾಟೈಪ್ ಆದ್ದರಿಂದ ನಾವು ಯಾವಾಗಲೂ ಅದಕ್ಕೆ ಪರಿವರ್ತಿಸಬಹುದು
        unsafe { &*(self as *const Self as *const _) }
    }

    /// ದೊಡ್ಡ ಎಂಡಿಯನ್‌ನಲ್ಲಿ ಬೈಟ್ ಅರೇ ಆಗಿ ಅದರ ಪ್ರಾತಿನಿಧ್ಯದಿಂದ ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಮೌಲ್ಯವನ್ನು ರಚಿಸಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// ಸ್ವಲ್ಪ ಎಂಡಿಯನ್‌ನಲ್ಲಿ ಬೈಟ್ ಅರೇ ಆಗಿ ಅದರ ಪ್ರಾತಿನಿಧ್ಯದಿಂದ ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಮೌಲ್ಯವನ್ನು ರಚಿಸಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// ಸ್ಥಳೀಯ ಎಂಡಿಯನ್‌ನಲ್ಲಿ ಬೈಟ್ ಅರೇ ಆಗಿ ಅದರ ಪ್ರಾತಿನಿಧ್ಯದಿಂದ ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಮೌಲ್ಯವನ್ನು ರಚಿಸಿ.
    ///
    /// ಟಾರ್ಗೆಟ್ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್‌ನ ಸ್ಥಳೀಯ ಎಂಡಿಯೆನೆಸ್ ಅನ್ನು ಬಳಸಿದಂತೆ, ಪೋರ್ಟಬಲ್ ಕೋಡ್ ಬದಲಾಗಿ [`from_be_bytes`] ಅಥವಾ [`from_le_bytes`] ಅನ್ನು ಬಳಸಲು ಬಯಸುತ್ತದೆ.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// ಸ್ವಯಂ ಮತ್ತು ಇತರ ಮೌಲ್ಯಗಳ ನಡುವೆ ಆದೇಶವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಸಂಖ್ಯೆಗಳ ನಡುವಿನ ಪ್ರಮಾಣಿತ ಭಾಗಶಃ ಹೋಲಿಕೆಗಿಂತ ಭಿನ್ನವಾಗಿ, ಈ ಹೋಲಿಕೆ ಯಾವಾಗಲೂ ಐಇಇಇ 754 (2008 ಪರಿಷ್ಕರಣೆ) ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಸ್ಟ್ಯಾಂಡರ್ಡ್‌ನಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಿದಂತೆ ಟೋಟಲ್ ಆರ್ಡರ್ ಪ್ರಿಡಿಕೇಟ್‌ಗೆ ಅನುಗುಣವಾಗಿ ಆದೇಶವನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ.
    /// ಮೌಲ್ಯಗಳನ್ನು ಈ ಕೆಳಗಿನ ಕ್ರಮದಲ್ಲಿ ಆದೇಶಿಸಲಾಗಿದೆ:
    /// - ನಕಾರಾತ್ಮಕ ಸ್ತಬ್ಧ NaN
    /// - ನಕಾರಾತ್ಮಕ ಸಿಗ್ನಲಿಂಗ್ NaN
    /// - ನಕಾರಾತ್ಮಕ ಅನಂತ
    /// - ನಕಾರಾತ್ಮಕ ಸಂಖ್ಯೆಗಳು
    /// - ನಕಾರಾತ್ಮಕ ಸಬ್ನಾರ್ಮಲ್ ಸಂಖ್ಯೆಗಳು
    /// - ನಕಾರಾತ್ಮಕ ಶೂನ್ಯ
    /// - ಧನಾತ್ಮಕ ಶೂನ್ಯ
    /// - ಧನಾತ್ಮಕ ಸಬ್ನಾರ್ಮಲ್ ಸಂಖ್ಯೆಗಳು
    /// - ಧನಾತ್ಮಕ ಸಂಖ್ಯೆಗಳು
    /// - ಧನಾತ್ಮಕ ಅನಂತ
    /// - ಸಕಾರಾತ್ಮಕ ಸಿಗ್ನಲಿಂಗ್ NaN
    /// - ಸಕಾರಾತ್ಮಕ ಸ್ತಬ್ಧ NaN
    ///
    /// ಈ ಕಾರ್ಯವು ಯಾವಾಗಲೂ `f32` ನ [`PartialOrd`] ಮತ್ತು [`PartialEq`] ಅನುಷ್ಠಾನಗಳೊಂದಿಗೆ ಒಪ್ಪುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.ನಿರ್ದಿಷ್ಟವಾಗಿ ಹೇಳುವುದಾದರೆ, ಅವರು ನಕಾರಾತ್ಮಕ ಮತ್ತು ಸಕಾರಾತ್ಮಕ ಶೂನ್ಯವನ್ನು ಸಮಾನವೆಂದು ಪರಿಗಣಿಸುತ್ತಾರೆ, ಆದರೆ `total_cmp` ಅದನ್ನು ಪರಿಗಣಿಸುವುದಿಲ್ಲ.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // ನಿರಾಕರಣೆಗಳ ಸಂದರ್ಭದಲ್ಲಿ, ಎರಡು ಪೂರಕ ಪೂರ್ಣಾಂಕಗಳಂತೆ ಒಂದೇ ರೀತಿಯ ವಿನ್ಯಾಸವನ್ನು ಸಾಧಿಸಲು ಚಿಹ್ನೆಯನ್ನು ಹೊರತುಪಡಿಸಿ ಎಲ್ಲಾ ಬಿಟ್‌ಗಳನ್ನು ತಿರುಗಿಸಿ
        //
        // ಇದು ಏಕೆ ಕೆಲಸ ಮಾಡುತ್ತದೆ?ಐಇಇಇ 754 ಫ್ಲೋಟ್‌ಗಳು ಮೂರು ಕ್ಷೇತ್ರಗಳನ್ನು ಒಳಗೊಂಡಿವೆ:
        // ಸೈನ್ ಬಿಟ್, ಘಾತಾಂಕ ಮತ್ತು ಮಂಟಿಸ್ಸಾ.ಒಟ್ಟಾರೆಯಾಗಿ ಘಾತಾಂಕ ಮತ್ತು ಮಂಟಿಸ್ಸಾ ಕ್ಷೇತ್ರಗಳ ಸಮೂಹವು ಅವುಗಳ ಬಿಟ್‌ವೈಸ್ ಕ್ರಮವು ಪರಿಮಾಣವನ್ನು ವ್ಯಾಖ್ಯಾನಿಸುವ ಸಂಖ್ಯಾ ಪರಿಮಾಣಕ್ಕೆ ಸಮಾನವಾಗಿರುತ್ತದೆ ಎಂಬ ಆಸ್ತಿಯನ್ನು ಹೊಂದಿದೆ.
        // ಪ್ರಮಾಣವನ್ನು ಸಾಮಾನ್ಯವಾಗಿ NaN ಮೌಲ್ಯಗಳಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗುವುದಿಲ್ಲ, ಆದರೆ IEEE 754 totalOrder NaN ಮೌಲ್ಯಗಳನ್ನು ಬಿಟ್‌ವೈಸ್ ಕ್ರಮವನ್ನು ಅನುಸರಿಸಲು ವ್ಯಾಖ್ಯಾನಿಸುತ್ತದೆ.ಇದು ಡಾಕ್ ಕಾಮೆಂಟ್‌ನಲ್ಲಿ ವಿವರಿಸಿದ ಆದೇಶಕ್ಕೆ ಕಾರಣವಾಗುತ್ತದೆ.
        // ಆದಾಗ್ಯೂ, negative ಣಾತ್ಮಕ ಮತ್ತು ಸಕಾರಾತ್ಮಕ ಸಂಖ್ಯೆಗಳಿಗೆ ಪರಿಮಾಣದ ಪ್ರಾತಿನಿಧ್ಯವು ಒಂದೇ ಆಗಿರುತ್ತದೆ-ಸೈನ್ ಬಿಟ್ ಮಾತ್ರ ವಿಭಿನ್ನವಾಗಿರುತ್ತದೆ.
        // ಫ್ಲೋಟ್‌ಗಳನ್ನು ಸಹಿ ಮಾಡಿದ ಪೂರ್ಣಾಂಕಗಳಾಗಿ ಸುಲಭವಾಗಿ ಹೋಲಿಸಲು, negative ಣಾತ್ಮಕ ಸಂಖ್ಯೆಗಳ ಸಂದರ್ಭದಲ್ಲಿ ನಾವು ಘಾತಾಂಕ ಮತ್ತು ಮಂಟಿಸ್ಸಾ ಬಿಟ್‌ಗಳನ್ನು ತಿರುಗಿಸಬೇಕಾಗುತ್ತದೆ.
        // ನಾವು ಸಂಖ್ಯೆಗಳನ್ನು "two's complement" ಫಾರ್ಮ್‌ಗೆ ಪರಿಣಾಮಕಾರಿಯಾಗಿ ಪರಿವರ್ತಿಸುತ್ತೇವೆ.
        //
        // ಫ್ಲಿಪ್ಪಿಂಗ್ ಮಾಡಲು, ನಾವು ಅದರ ವಿರುದ್ಧ ಮುಖವಾಡ ಮತ್ತು XOR ಅನ್ನು ನಿರ್ಮಿಸುತ್ತೇವೆ.
        // ನಕಾರಾತ್ಮಕ ಸಹಿ ಮಾಡಿದ ಮೌಲ್ಯಗಳಿಂದ ನಾವು "all-ones except for the sign bit" ಮುಖವಾಡವನ್ನು ಶಾಖೆಯಿಲ್ಲದೆ ಲೆಕ್ಕ ಹಾಕುತ್ತೇವೆ: ಬಲ ವರ್ಗಾವಣೆಯು ಪೂರ್ಣಾಂಕವನ್ನು ಸೈನ್-ವಿಸ್ತರಿಸುತ್ತದೆ, ಆದ್ದರಿಂದ ನಾವು ಮುಖವಾಡವನ್ನು ಸೈನ್ ಬಿಟ್‌ಗಳೊಂದಿಗೆ "fill" ಮಾಡುತ್ತೇವೆ, ತದನಂತರ ಒಂದು ಶೂನ್ಯ ಬಿಟ್ ಅನ್ನು ತಳ್ಳಲು ಸಹಿ ಮಾಡದಿರುವಂತೆ ಪರಿವರ್ತಿಸುತ್ತೇವೆ.
        //
        // ಸಕಾರಾತ್ಮಕ ಮೌಲ್ಯಗಳಲ್ಲಿ, ಮುಖವಾಡವು ಎಲ್ಲಾ ಸೊನ್ನೆಗಳಾಗಿರುತ್ತದೆ, ಆದ್ದರಿಂದ ಇದು ಯಾವುದೇ ಆಪ್ ಅಲ್ಲ.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// ಮೌಲ್ಯವನ್ನು NaN ಆಗದ ಹೊರತು ನಿರ್ದಿಷ್ಟ ಮಧ್ಯಂತರಕ್ಕೆ ನಿರ್ಬಂಧಿಸಿ.
    ///
    /// `self` `max` ಗಿಂತ ಹೆಚ್ಚಿದ್ದರೆ `max` ಮತ್ತು `self` `min` ಗಿಂತ ಕಡಿಮೆಯಿದ್ದರೆ `min` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಇಲ್ಲದಿದ್ದರೆ ಇದು `self` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಆರಂಭಿಕ ಮೌಲ್ಯವು NaN ಆಗಿದ್ದರೆ ಈ ಕಾರ್ಯವು NaN ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    /// # Panics
    ///
    /// `min > max`, `min` NaN ಆಗಿದ್ದರೆ ಅಥವಾ `max` NaN ಆಗಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}