//! ಆಂತರಿಕ ಬಳಕೆಗೆ ಮಾತ್ರ ವಿಸ್ತೃತ ನಿಖರತೆ "soft float".

// ಈ ಮಾಡ್ಯೂಲ್ dec2flt ಮತ್ತು flt2dec ಗೆ ಮಾತ್ರ, ಮತ್ತು ಕೋರೆಟೆಸ್ಟ್‌ಗಳ ಕಾರಣದಿಂದಾಗಿ ಸಾರ್ವಜನಿಕವಾಗಿದೆ.
// ಇದು ಎಂದಿಗೂ ಸ್ಥಿರಗೊಳ್ಳುವ ಉದ್ದೇಶವನ್ನು ಹೊಂದಿಲ್ಲ.
#![doc(hidden)]
#![unstable(
    feature = "core_private_diy_float",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

/// ಕಸ್ಟಮ್ 64-ಬಿಟ್ ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಪ್ರಕಾರ, ಇದು `f * 2^e` ಅನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
#[derive(Copy, Clone, Debug)]
#[doc(hidden)]
pub struct Fp {
    /// ಪೂರ್ಣಾಂಕ ಮಂಟಿಸ್ಸಾ.
    pub f: u64,
    /// ಬೇಸ್ 2 ರಲ್ಲಿ ಘಾತಾಂಕ.
    pub e: i16,
}

impl Fp {
    /// ಸ್ವತಃ ಮತ್ತು `other` ನ ಸರಿಯಾಗಿ ದುಂಡಾದ ಉತ್ಪನ್ನವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    pub fn mul(&self, other: &Fp) -> Fp {
        const MASK: u64 = 0xffffffff;
        let a = self.f >> 32;
        let b = self.f & MASK;
        let c = other.f >> 32;
        let d = other.f & MASK;
        let ac = a * c;
        let bc = b * c;
        let ad = a * d;
        let bd = b * d;
        let tmp = (bd >> 32) + (ad & MASK) + (bc & MASK) + (1 << 31) /* round */;
        let f = ac + (ad >> 32) + (bc >> 32) + (tmp >> 32);
        let e = self.e + other.e + 64;
        Fp { f, e }
    }

    /// ಸ್ವತಃ ಸಾಧಾರಣಗೊಳಿಸುತ್ತದೆ ಇದರಿಂದ ಉಂಟಾಗುವ ಮಂಟಿಸ್ಸಾ ಕನಿಷ್ಠ `2^63` ಆಗಿರುತ್ತದೆ.
    pub fn normalize(&self) -> Fp {
        let mut f = self.f;
        let mut e = self.e;
        if f >> (64 - 32) == 0 {
            f <<= 32;
            e -= 32;
        }
        if f >> (64 - 16) == 0 {
            f <<= 16;
            e -= 16;
        }
        if f >> (64 - 8) == 0 {
            f <<= 8;
            e -= 8;
        }
        if f >> (64 - 4) == 0 {
            f <<= 4;
            e -= 4;
        }
        if f >> (64 - 2) == 0 {
            f <<= 2;
            e -= 2;
        }
        if f >> (64 - 1) == 0 {
            f <<= 1;
            e -= 1;
        }
        debug_assert!(f >= (1 >> 63));
        Fp { f, e }
    }

    /// ಹಂಚಿದ ಘಾತಾಂಕವನ್ನು ಹೊಂದಲು ಸ್ವತಃ ಸಾಮಾನ್ಯಗೊಳಿಸುತ್ತದೆ.
    /// ಇದು ಘಾತಾಂಕವನ್ನು ಮಾತ್ರ ಕಡಿಮೆ ಮಾಡುತ್ತದೆ (ಮತ್ತು ಆದ್ದರಿಂದ ಮಂಟಿಸ್ಸಾವನ್ನು ಹೆಚ್ಚಿಸುತ್ತದೆ).
    pub fn normalize_to(&self, e: i16) -> Fp {
        let edelta = self.e - e;
        assert!(edelta >= 0);
        let edelta = edelta as usize;
        assert_eq!(self.f << edelta >> edelta, self.f);
        Fp { f: self.f << edelta, e }
    }
}