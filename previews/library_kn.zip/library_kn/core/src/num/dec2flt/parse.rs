//! ರೂಪದ ದಶಮಾಂಶ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಮೌಲ್ಯೀಕರಿಸುವುದು ಮತ್ತು ಕೊಳೆಯುವುದು:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, ಸ್ಟ್ಯಾಂಡರ್ಡ್ ಫ್ಲೋಟಿಂಗ್-ಪಾಯಿಂಟ್ ಸಿಂಟ್ಯಾಕ್ಸ್, ಎರಡು ಹೊರತುಪಡಿಸಿ: ಯಾವುದೇ ಚಿಹ್ನೆ ಇಲ್ಲ, ಮತ್ತು "inf" ಮತ್ತು "NaN" ಅನ್ನು ನಿರ್ವಹಿಸುವುದಿಲ್ಲ.ಇವುಗಳನ್ನು ಡ್ರೈವರ್ ಫಂಕ್ಷನ್ (super::dec2flt) ನಿರ್ವಹಿಸುತ್ತದೆ.
//!
//! ಮಾನ್ಯ ಒಳಹರಿವುಗಳನ್ನು ಗುರುತಿಸುವುದು ತುಲನಾತ್ಮಕವಾಗಿ ಸುಲಭವಾಗಿದ್ದರೂ, ಈ ಮಾಡ್ಯೂಲ್ ಅಸಂಖ್ಯಾತ ಅಮಾನ್ಯ ವ್ಯತ್ಯಾಸಗಳನ್ನು ತಿರಸ್ಕರಿಸಬೇಕಾಗುತ್ತದೆ, ಎಂದಿಗೂ panic, ಮತ್ತು ಇತರ ಮಾಡ್ಯೂಲ್‌ಗಳು panic (ಅಥವಾ ಓವರ್‌ಫ್ಲೋ) ಅನ್ನು ಅವಲಂಬಿಸದ ಹಲವಾರು ಪರಿಶೀಲನೆಗಳನ್ನು ಮಾಡಬೇಕಾಗುತ್ತದೆ.
//!
//! ವಿಷಯಗಳನ್ನು ಇನ್ನಷ್ಟು ಹದಗೆಡಿಸಲು, ಇನ್‌ಪುಟ್‌ನ ಮೇಲೆ ಒಂದೇ ಪಾಸ್‌ನಲ್ಲಿ ನಡೆಯುವ ಎಲ್ಲವೂ.
//! ಆದ್ದರಿಂದ, ಯಾವುದನ್ನಾದರೂ ಮಾರ್ಪಡಿಸುವಾಗ ಜಾಗರೂಕರಾಗಿರಿ ಮತ್ತು ಇತರ ಮಾಡ್ಯೂಲ್‌ಗಳೊಂದಿಗೆ ಎರಡು ಬಾರಿ ಪರಿಶೀಲಿಸಿ.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// ದಶಮಾಂಶ ದಾರದ ಆಸಕ್ತಿದಾಯಕ ಭಾಗಗಳು.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// ದಶಮಾಂಶ ಘಾತಾಂಕ, 18 ಕ್ಕಿಂತ ಕಡಿಮೆ ದಶಮಾಂಶ ಅಂಕೆಗಳನ್ನು ಹೊಂದಿರುತ್ತದೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// ಇನ್ಪುಟ್ ಸ್ಟ್ರಿಂಗ್ ಮಾನ್ಯ ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಸಂಖ್ಯೆಯಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ ಮತ್ತು ಹಾಗಿದ್ದಲ್ಲಿ, ಅವಿಭಾಜ್ಯ ಭಾಗ, ಭಾಗಶಃ ಭಾಗ ಮತ್ತು ಅದರಲ್ಲಿರುವ ಘಾತಾಂಕವನ್ನು ಪತ್ತೆ ಮಾಡಿ.
/// ಚಿಹ್ನೆಗಳನ್ನು ನಿರ್ವಹಿಸುವುದಿಲ್ಲ.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // 'e' ಮೊದಲು ಅಂಕೆಗಳಿಲ್ಲ
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // ಬಿಂದುವಿಗೆ ಮೊದಲು ಅಥವಾ ನಂತರ ನಮಗೆ ಕನಿಷ್ಠ ಒಂದು ಅಂಕೆ ಬೇಕಾಗುತ್ತದೆ.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // ಭಾಗಶಃ ಭಾಗದ ನಂತರ ಜಂಕ್ ಅನ್ನು ಹಿಂಬಾಲಿಸುವುದು
            }
        }
        _ => Invalid, // ಮೊದಲ ಅಂಕಿಯ ಸ್ಟ್ರಿಂಗ್ ನಂತರ ಜಂಕ್ ಹಿಂದುಳಿದಿದೆ
    }
}

/// ಮೊದಲ ಅಂಕಿಯಲ್ಲದ ಅಕ್ಷರಕ್ಕೆ ದಶಮಾಂಶ ಅಂಕೆಗಳನ್ನು ಕೊರೆಯುತ್ತದೆ.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// ಘಾತಾಂಕ ಹೊರತೆಗೆಯುವಿಕೆ ಮತ್ತು ದೋಷ ಪರಿಶೀಲನೆ.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // ಘಾತಕದ ನಂತರ ಜಂಕ್ ಅನ್ನು ಹಿಂಬಾಲಿಸುವುದು
    }
    if number.is_empty() {
        return Invalid; // ಖಾಲಿ ಘಾತಾಂಕ
    }
    // ಈ ಸಮಯದಲ್ಲಿ, ನಾವು ಖಂಡಿತವಾಗಿಯೂ ಅಂಕೆಗಳ ಮಾನ್ಯ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಹೊಂದಿದ್ದೇವೆ.`i64` ಗೆ ಹಾಕಲು ಇದು ತುಂಬಾ ಉದ್ದವಾಗಬಹುದು, ಆದರೆ ಅದು ದೊಡ್ಡದಾಗಿದ್ದರೆ, ಇನ್ಪುಟ್ ಖಂಡಿತವಾಗಿಯೂ ಶೂನ್ಯ ಅಥವಾ ಅನಂತವಾಗಿರುತ್ತದೆ.
    // ದಶಮಾಂಶ ಅಂಕೆಗಳಲ್ಲಿನ ಪ್ರತಿ ಶೂನ್ಯವು ಘಾತಾಂಕವನ್ನು +/-1 ರಿಂದ ಮಾತ್ರ ಸರಿಹೊಂದಿಸುವುದರಿಂದ, exp=10 ^ 18 ನಲ್ಲಿ ಇನ್ಪುಟ್ 17 ಎಕ್ಸಬೈಟ್ (!) ಸೊನ್ನೆಗಳಾಗಿರಬೇಕು, ಅದು ದೂರದಿಂದಲೂ ಸೀಮಿತವಾಗಲು ಹತ್ತಿರವಾಗುವುದು.
    //
    // ಇದು ನಾವು ಪೂರೈಸಬೇಕಾದ ಬಳಕೆಯ ಸಂದರ್ಭವಲ್ಲ.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}