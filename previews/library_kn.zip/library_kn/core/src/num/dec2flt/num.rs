//! ವಿಧಾನಗಳಾಗಿ ಬದಲಾಗಲು ಹೆಚ್ಚು ಅರ್ಥವಿಲ್ಲದ ಬಿಗ್ನಮ್‌ಗಳ ಉಪಯುಕ್ತತೆ ಕಾರ್ಯಗಳು.

// ಸರಿಪಡಿಸಿ ಈ ಮಾಡ್ಯೂಲ್‌ನ ಹೆಸರು ಸ್ವಲ್ಪ ದುರದೃಷ್ಟಕರ, ಏಕೆಂದರೆ ಇತರ ಮಾಡ್ಯೂಲ್‌ಗಳು ಸಹ `core::num` ಅನ್ನು ಆಮದು ಮಾಡಿಕೊಳ್ಳುತ್ತವೆ.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// `ones_place` ಗಿಂತ ಕಡಿಮೆ ಪ್ರಾಮುಖ್ಯತೆ ಹೊಂದಿರುವ ಎಲ್ಲಾ ಬಿಟ್‌ಗಳನ್ನು ಮೊಟಕುಗೊಳಿಸುವುದರಿಂದ ಸಾಪೇಕ್ಷ ದೋಷವನ್ನು ಕಡಿಮೆ, ಸಮಾನ ಅಥವಾ 0.5 ULP ಗಿಂತ ಹೆಚ್ಚಿನದನ್ನು ಪರಿಚಯಿಸುತ್ತದೆಯೇ ಎಂದು ಪರೀಕ್ಷಿಸಿ.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // ಉಳಿದಿರುವ ಎಲ್ಲಾ ಬಿಟ್‌ಗಳು ಶೂನ್ಯವಾಗಿದ್ದರೆ, ಅದು= 0.5 ULP, ಇಲ್ಲದಿದ್ದರೆ> 0.5 ಹೆಚ್ಚಿನ ಬಿಟ್‌ಗಳಿಲ್ಲದಿದ್ದರೆ (ಅರ್ಧ_ಬಿಟ್==0), ಕೆಳಗಿನವುಗಳು ಸರಿಯಾಗಿ ಸಮನಾಗಿರುತ್ತವೆ.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// ಕೇವಲ ದಶಮಾಂಶ ಅಂಕೆಗಳನ್ನು ಹೊಂದಿರುವ ASCII ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು `u64` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
///
/// ಓವರ್‌ಫ್ಲೋ ಅಥವಾ ಅಮಾನ್ಯ ಅಕ್ಷರಗಳಿಗಾಗಿ ತಪಾಸಣೆ ಮಾಡುವುದಿಲ್ಲ, ಆದ್ದರಿಂದ ಕರೆ ಮಾಡುವವರು ಜಾಗರೂಕರಾಗಿರದಿದ್ದರೆ, ಫಲಿತಾಂಶವು ನಕಲಿ ಮತ್ತು panic ಮಾಡಬಹುದು (ಆದರೂ ಇದು `unsafe` ಆಗುವುದಿಲ್ಲ).
/// ಹೆಚ್ಚುವರಿಯಾಗಿ, ಖಾಲಿ ತಂತಿಗಳನ್ನು ಶೂನ್ಯವೆಂದು ಪರಿಗಣಿಸಲಾಗುತ್ತದೆ.
/// ಈ ಕಾರ್ಯವು ಅಸ್ತಿತ್ವದಲ್ಲಿದೆ
///
/// 1. `&[u8]` ನಲ್ಲಿ `FromStr` ಅನ್ನು ಬಳಸುವುದಕ್ಕೆ `from_utf8_unchecked` ಅಗತ್ಯವಿದೆ, ಅದು ಕೆಟ್ಟದು, ಮತ್ತು
/// 2. `integral.parse()` ಮತ್ತು `fractional.parse()` ನ ಫಲಿತಾಂಶಗಳನ್ನು ಒಟ್ಟಿಗೆ ಜೋಡಿಸುವುದು ಈ ಸಂಪೂರ್ಣ ಕಾರ್ಯಕ್ಕಿಂತ ಹೆಚ್ಚು ಜಟಿಲವಾಗಿದೆ.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// ASCII ಅಂಕೆಗಳ ದಾರವನ್ನು ಬಿಗ್ನಮ್ ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
///
/// `from_str_unchecked` ನಂತೆ, ಈ ಕಾರ್ಯವು ಅಂಕಿಯಲ್ಲದವರನ್ನು ಕಳೆ ಮಾಡಲು ಪಾರ್ಸರ್ ಅನ್ನು ಅವಲಂಬಿಸಿದೆ.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// ಬಿಗ್ನಮ್ ಅನ್ನು 64 ಬಿಟ್ ಪೂರ್ಣಾಂಕಕ್ಕೆ ಬಿಚ್ಚಿಡುತ್ತದೆ.ಸಂಖ್ಯೆ ತುಂಬಾ ದೊಡ್ಡದಾಗಿದ್ದರೆ Panics.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// ಬಿಟ್‌ಗಳ ಶ್ರೇಣಿಯನ್ನು ಹೊರತೆಗೆಯುತ್ತದೆ.

/// ಸೂಚ್ಯಂಕ 0 ಅತ್ಯಂತ ಗಮನಾರ್ಹವಾದ ಬಿಟ್ ಮತ್ತು ಶ್ರೇಣಿಯು ಎಂದಿನಂತೆ ಅರ್ಧ-ತೆರೆದಿರುತ್ತದೆ.
/// ರಿಟರ್ನ್ ಪ್ರಕಾರಕ್ಕೆ ಹೊಂದಿಕೊಳ್ಳುವುದಕ್ಕಿಂತ ಹೆಚ್ಚಿನ ಬಿಟ್‌ಗಳನ್ನು ಹೊರತೆಗೆಯಲು ಕೇಳಿದರೆ Panics.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}