//! ಧನಾತ್ಮಕ ಐಇಇಇ 754 ಫ್ಲೋಟ್‌ಗಳಲ್ಲಿ ಬಿಟ್ ಫಿಡ್ಲಿಂಗ್.ನಕಾರಾತ್ಮಕ ಸಂಖ್ಯೆಗಳು ಇಲ್ಲ ಮತ್ತು ನಿರ್ವಹಿಸಬೇಕಾಗಿಲ್ಲ.
//! ಸಾಮಾನ್ಯ ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಸಂಖ್ಯೆಗಳು (frac, exp) ನಂತೆ ಅಂಗೀಕೃತ ಪ್ರಾತಿನಿಧ್ಯವನ್ನು ಹೊಂದಿವೆ, ಅಂದರೆ ಮೌಲ್ಯವು 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)), ಅಲ್ಲಿ N ಎಂಬುದು ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆ.
//!
//! ಸಬ್ನಾರ್ಮಲ್ಗಳು ಸ್ವಲ್ಪ ವಿಭಿನ್ನ ಮತ್ತು ವಿಲಕ್ಷಣವಾಗಿವೆ, ಆದರೆ ಅದೇ ತತ್ವವು ಅನ್ವಯಿಸುತ್ತದೆ.
//!
//! ಆದಾಗ್ಯೂ, ಇಲ್ಲಿ ನಾವು ಅವುಗಳನ್ನು (ಸಕಾರಾತ್ಮಕ, ಎಫ್) ಧನಾತ್ಮಕವಾಗಿ ಪ್ರತಿನಿಧಿಸುತ್ತೇವೆ, ಅಂದರೆ ಮೌಲ್ಯವು ಎಫ್ *
//! 2 <sup>ಇ</sup> ."hidden bit" ಅನ್ನು ಸ್ಪಷ್ಟಪಡಿಸುವುದರ ಜೊತೆಗೆ, ಇದು ಮಂಟಿಸ್ಸಾ ಶಿಫ್ಟ್ ಎಂದು ಕರೆಯಲ್ಪಡುವ ಘಾತಾಂಕವನ್ನು ಬದಲಾಯಿಸುತ್ತದೆ.
//!
//! ಇನ್ನೊಂದು ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, ಸಾಮಾನ್ಯವಾಗಿ ಫ್ಲೋಟ್‌ಗಳನ್ನು (1) ಎಂದು ಬರೆಯಲಾಗುತ್ತದೆ ಆದರೆ ಇಲ್ಲಿ ಅವುಗಳನ್ನು (2) ಎಂದು ಬರೆಯಲಾಗುತ್ತದೆ:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! ನಾವು (1) ಅನ್ನು **ಭಾಗಶಃ ಪ್ರಾತಿನಿಧ್ಯ** ಮತ್ತು (2) ಅನ್ನು **ಅವಿಭಾಜ್ಯ ಪ್ರಾತಿನಿಧ್ಯ** ಎಂದು ಕರೆಯುತ್ತೇವೆ.
//!
//! ಈ ಮಾಡ್ಯೂಲ್‌ನಲ್ಲಿನ ಅನೇಕ ಕಾರ್ಯಗಳು ಸಾಮಾನ್ಯ ಸಂಖ್ಯೆಗಳನ್ನು ಮಾತ್ರ ನಿರ್ವಹಿಸುತ್ತವೆ.Dec2flt ವಾಡಿಕೆಯು ಸಂಪ್ರದಾಯಬದ್ಧವಾಗಿ ಸಾರ್ವತ್ರಿಕವಾಗಿ ಸರಿಯಾದ ನಿಧಾನ ಮಾರ್ಗವನ್ನು (ಅಲ್ಗಾರಿದಮ್ M) ಬಹಳ ಕಡಿಮೆ ಮತ್ತು ದೊಡ್ಡ ಸಂಖ್ಯೆಯಲ್ಲಿ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
//! ಆ ಅಲ್ಗಾರಿದಮ್‌ಗೆ ಕೇವಲ next_float() ಅಗತ್ಯವಿದೆ ಅದು ಸಬ್‌ನಾರ್ಮಲ್‌ಗಳು ಮತ್ತು ಸೊನ್ನೆಗಳನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// `f32` ಮತ್ತು `f64` ಗಾಗಿ ಎಲ್ಲಾ ಪರಿವರ್ತನೆ ಕೋಡ್ ಅನ್ನು ಮೂಲತಃ ನಕಲು ಮಾಡುವುದನ್ನು ತಪ್ಪಿಸಲು ಸಹಾಯಕ trait.
///
/// ಇದು ಏಕೆ ಅಗತ್ಯ ಎಂದು ಪೋಷಕ ಮಾಡ್ಯೂಲ್ನ ಡಾಕ್ ಕಾಮೆಂಟ್ ನೋಡಿ.
///
/// **ಎಂದಿಗೂ** ಅನ್ನು ಇತರ ಪ್ರಕಾರಗಳಿಗೆ ಕಾರ್ಯಗತಗೊಳಿಸಬಾರದು ಅಥವಾ dec2flt ಮಾಡ್ಯೂಲ್‌ನ ಹೊರಗೆ ಬಳಸಬಾರದು.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// `to_bits` ಮತ್ತು `from_bits` ಬಳಸುವ ಪ್ರಕಾರ.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// ಒಂದು ಪೂರ್ಣಾಂಕಕ್ಕೆ ಕಚ್ಚಾ ರೂಪಾಂತರವನ್ನು ಮಾಡುತ್ತದೆ.
    fn to_bits(self) -> Self::Bits;

    /// ಪೂರ್ಣಾಂಕದಿಂದ ಕಚ್ಚಾ ರೂಪಾಂತರವನ್ನು ಮಾಡುತ್ತದೆ.
    fn from_bits(v: Self::Bits) -> Self;

    /// ಈ ಸಂಖ್ಯೆ ಸೇರುವ ವರ್ಗವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    fn classify(self) -> FpCategory;

    /// ಮಂಟಿಸ್ಸಾ, ಘಾತಾಂಕ ಮತ್ತು ಚಿಹ್ನೆಯನ್ನು ಪೂರ್ಣಾಂಕಗಳಾಗಿ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    fn integer_decode(self) -> (u64, i16, i8);

    /// ಫ್ಲೋಟ್ ಅನ್ನು ಡಿಕೋಡ್ ಮಾಡುತ್ತದೆ.
    fn unpack(self) -> Unpacked;

    /// ನಿಖರವಾಗಿ ಪ್ರತಿನಿಧಿಸಬಹುದಾದ ಸಣ್ಣ ಪೂರ್ಣಾಂಕದಿಂದ ಪ್ರಸಾರವಾಗುತ್ತದೆ.
    /// Panic ಪೂರ್ಣಾಂಕವನ್ನು ಪ್ರತಿನಿಧಿಸಲಾಗದಿದ್ದರೆ, ಈ ಮಾಡ್ಯೂಲ್‌ನಲ್ಲಿರುವ ಇತರ ಕೋಡ್ ಅದನ್ನು ಎಂದಿಗೂ ಸಂಭವಿಸದಂತೆ ನೋಡಿಕೊಳ್ಳುತ್ತದೆ.
    fn from_int(x: u64) -> Self;

    /// ಪೂರ್ವ-ಕಂಪ್ಯೂಟೆಡ್ ಟೇಬಲ್‌ನಿಂದ 10 <sup>ಇ</sup> ಮೌಲ್ಯವನ್ನು ಪಡೆಯುತ್ತದೆ.
    /// `e >= CEIL_LOG5_OF_MAX_SIG` ಗಾಗಿ Panics.
    fn short_fast_pow10(e: usize) -> Self;

    /// ಹೆಸರು ಏನು ಹೇಳುತ್ತದೆ.
    /// ಆಂತರಿಕತೆಯನ್ನು ಕಣ್ಕಟ್ಟು ಮಾಡುವುದು ಮತ್ತು ಎಲ್ಎಲ್ವಿಎಂ ಸ್ಥಿರವು ಅದನ್ನು ಮಡಿಸುತ್ತದೆ ಎಂದು ಆಶಿಸುವುದಕ್ಕಿಂತ ಹಾರ್ಡ್ ಕೋಡ್ ಮಾಡಲು ಸುಲಭವಾಗಿದೆ.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // ಉಕ್ಕಿ ಅಥವಾ ಶೂನ್ಯವನ್ನು ಉತ್ಪಾದಿಸಲಾಗದ ಒಳಹರಿವಿನ ದಶಮಾಂಶ ಅಂಕೆಗಳ ಮೇಲೆ ಸಂಪ್ರದಾಯವಾದಿ
    /// ಸಬ್ನಾರ್ಮಲ್ಸ್.ಬಹುಶಃ ಗರಿಷ್ಠ ಸಾಮಾನ್ಯ ಮೌಲ್ಯದ ದಶಮಾಂಶ ಘಾತಾಂಕ, ಆದ್ದರಿಂದ ಈ ಹೆಸರು.
    const MAX_NORMAL_DIGITS: usize;

    /// ಅತ್ಯಂತ ಮಹತ್ವದ ದಶಮಾಂಶ ಅಂಕಿಯು ಇದಕ್ಕಿಂತ ಹೆಚ್ಚಿನ ಸ್ಥಳ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿರುವಾಗ, ಈ ಸಂಖ್ಯೆ ಖಂಡಿತವಾಗಿಯೂ ಅನಂತಕ್ಕೆ ದುಂಡಾಗಿರುತ್ತದೆ.
    ///
    const INF_CUTOFF: i64;

    /// ಅತ್ಯಂತ ಮಹತ್ವದ ದಶಮಾಂಶ ಅಂಕಿಯು ಇದಕ್ಕಿಂತ ಕಡಿಮೆ ಸ್ಥಳ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿರುವಾಗ, ಸಂಖ್ಯೆಯು ಖಂಡಿತವಾಗಿಯೂ ಶೂನ್ಯಕ್ಕೆ ದುಂಡಾಗಿರುತ್ತದೆ.
    ///
    const ZERO_CUTOFF: i64;

    /// ಘಾತಾಂಕದಲ್ಲಿನ ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆ.
    const EXP_BITS: u8;

    /// ಗುಪ್ತ ಬಿಟ್ ಸೇರಿದಂತೆ * ಮಹತ್ವದಲ್ಲಿರುವ ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆ.
    const SIG_BITS: u8;

    /// ಗುಪ್ತ ಬಿಟ್ ಅನ್ನು ಹೊರತುಪಡಿಸಿ * ಮಹತ್ವದ ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆ.
    const EXPLICIT_SIG_BITS: u8;

    /// ಭಾಗಶಃ ಪ್ರಾತಿನಿಧ್ಯದಲ್ಲಿ ಗರಿಷ್ಠ ಕಾನೂನು ಘಾತಾಂಕ.
    const MAX_EXP: i16;

    /// ಭಾಗಶಃ ಪ್ರಾತಿನಿಧ್ಯದಲ್ಲಿ ಕನಿಷ್ಠ ಕಾನೂನು ಘಾತಾಂಕ, ಸಬ್‌ನಾರ್ಮಲ್‌ಗಳನ್ನು ಹೊರತುಪಡಿಸಿ.
    const MIN_EXP: i16;

    /// `MAX_EXP` ಅವಿಭಾಜ್ಯ ಪ್ರಾತಿನಿಧ್ಯಕ್ಕಾಗಿ, ಅಂದರೆ, ಶಿಫ್ಟ್ ಅನ್ನು ಅನ್ವಯಿಸಲಾಗಿದೆ.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` ಎನ್ಕೋಡ್ ಮಾಡಲಾಗಿದೆ (ಅಂದರೆ, ಆಫ್‌ಸೆಟ್ ಪಕ್ಷಪಾತದೊಂದಿಗೆ)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` ಅವಿಭಾಜ್ಯ ಪ್ರಾತಿನಿಧ್ಯಕ್ಕಾಗಿ, ಅಂದರೆ, ಶಿಫ್ಟ್ ಅನ್ನು ಅನ್ವಯಿಸಲಾಗಿದೆ.
    const MIN_EXP_INT: i16;

    /// ಅವಿಭಾಜ್ಯ ಪ್ರಾತಿನಿಧ್ಯದಲ್ಲಿ ಗರಿಷ್ಠ ಸಾಮಾನ್ಯೀಕರಿಸಿದ ಮಹತ್ವ.
    const MAX_SIG: u64;

    /// ಅವಿಭಾಜ್ಯ ಪ್ರಾತಿನಿಧ್ಯದಲ್ಲಿ ಕನಿಷ್ಠ ಸಾಮಾನ್ಯೀಕರಿಸಿದ ಮಹತ್ವ.
    const MIN_SIG: u64;
}

// ಹೆಚ್ಚಾಗಿ #34344 ಗಾಗಿ ಪರಿಹಾರೋಪಾಯ.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// ಮಂಟಿಸ್ಸಾ, ಘಾತಾಂಕ ಮತ್ತು ಚಿಹ್ನೆಯನ್ನು ಪೂರ್ಣಾಂಕಗಳಾಗಿ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // ಘಾತೀಯ ಪಕ್ಷಪಾತ + ಮಂಟಿಸ್ಸಾ ಶಿಫ್ಟ್
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // ಎಲ್ಲಾ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ `as` ಸರಿಯಾಗಿ ಸುತ್ತುತ್ತದೆಯೇ ಎಂದು rkruppe ಖಚಿತವಾಗಿಲ್ಲ.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// ಮಂಟಿಸ್ಸಾ, ಘಾತಾಂಕ ಮತ್ತು ಚಿಹ್ನೆಯನ್ನು ಪೂರ್ಣಾಂಕಗಳಾಗಿ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // ಘಾತೀಯ ಪಕ್ಷಪಾತ + ಮಂಟಿಸ್ಸಾ ಶಿಫ್ಟ್
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // ಎಲ್ಲಾ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ `as` ಸರಿಯಾಗಿ ಸುತ್ತುತ್ತದೆಯೇ ಎಂದು rkruppe ಖಚಿತವಾಗಿಲ್ಲ.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// `Fp` ಅನ್ನು ಹತ್ತಿರದ ಯಂತ್ರ ಫ್ಲೋಟ್ ಪ್ರಕಾರಕ್ಕೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
/// ಅಸಹಜ ಫಲಿತಾಂಶಗಳನ್ನು ನಿರ್ವಹಿಸುವುದಿಲ್ಲ.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 ಬಿಟ್ ಆಗಿದೆ, ಆದ್ದರಿಂದ xe 63 ರ ಮಂಟಿಸ್ಸಾ ಶಿಫ್ಟ್ ಅನ್ನು ಹೊಂದಿದೆ
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// 64-ಬಿಟ್ ಪ್ರಾಮುಖ್ಯತೆಯನ್ನು T::SIG_BITS ಬಿಟ್‌ಗಳಿಗೆ ಅರ್ಧದಿಂದ ಸಮವಾಗಿ ಸುತ್ತಿಕೊಳ್ಳಿ.
/// ಘಾತೀಯ ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // ಮಂಟಿಸ್ಸಾ ಶಿಫ್ಟ್ ಹೊಂದಿಸಿ
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// ಸಾಮಾನ್ಯೀಕರಿಸಿದ ಸಂಖ್ಯೆಗಳಿಗೆ `RawFloat::unpack()` ನ ವಿಲೋಮ.
/// ಪ್ರಾಮುಖ್ಯತೆ ಅಥವಾ ಘಾತಾಂಕವು ಸಾಮಾನ್ಯೀಕರಿಸಿದ ಸಂಖ್ಯೆಗಳಿಗೆ ಮಾನ್ಯವಾಗಿಲ್ಲದಿದ್ದರೆ Panics.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // ಗುಪ್ತ ಬಿಟ್ ತೆಗೆದುಹಾಕಿ
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // ಘಾತೀಯ ಪಕ್ಷಪಾತ ಮತ್ತು ಮಂಟಿಸ್ಸಾ ಶಿಫ್ಟ್‌ಗಾಗಿ ಘಾತಾಂಕವನ್ನು ಹೊಂದಿಸಿ
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // ಸೈನ್ ಬಿಟ್ ಅನ್ನು 0 ("+") ನಲ್ಲಿ ಬಿಡಿ, ನಮ್ಮ ಸಂಖ್ಯೆಗಳೆಲ್ಲವೂ ಸಕಾರಾತ್ಮಕವಾಗಿವೆ
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// ಸಬ್ನಾರ್ಮಲ್ ಅನ್ನು ನಿರ್ಮಿಸಿ.0 ರ ಮಂಟಿಸ್ಸಾವನ್ನು ಅನುಮತಿಸಲಾಗಿದೆ ಮತ್ತು ಶೂನ್ಯವನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // ಎನ್ಕೋಡೆಡ್ ಘಾತಾಂಕ 0, ಸೈನ್ ಬಿಟ್ 0, ಆದ್ದರಿಂದ ನಾವು ಬಿಟ್‌ಗಳನ್ನು ಮರು ವ್ಯಾಖ್ಯಾನಿಸಬೇಕು.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// ಎಫ್‌ಪಿ ಯೊಂದಿಗೆ ಬಿಗ್ನಮ್ ಅನ್ನು ಅಂದಾಜು ಮಾಡಿ.0.5 ULP ಯೊಳಗೆ ಅರ್ಧದಿಂದ ಸಮವಾಗಿ ರೌಂಡ್ಸ್.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // ಸೂಚ್ಯಂಕ `start` ಗೆ ಮುಂಚಿತವಾಗಿ ನಾವು ಎಲ್ಲಾ ಬಿಟ್‌ಗಳನ್ನು ಕತ್ತರಿಸುತ್ತೇವೆ, ಅಂದರೆ, ನಾವು `start` ಪ್ರಮಾಣದಿಂದ ಬಲ-ಬಲಕ್ಕೆ ಬದಲಾಯಿಸುತ್ತೇವೆ, ಆದ್ದರಿಂದ ಇದು ನಮಗೆ ಅಗತ್ಯವಿರುವ ಘಾತಾಂಕವೂ ಆಗಿದೆ.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // ಮೊಟಕುಗೊಳಿಸಿದ ಬಿಟ್‌ಗಳನ್ನು ಅವಲಂಬಿಸಿ ರೌಂಡ್ (half-to-even).
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// ಅತಿದೊಡ್ಡ ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಸಂಖ್ಯೆಯನ್ನು ಆರ್ಗ್ಯುಮೆಂಟ್ಗಿಂತ ಕಟ್ಟುನಿಟ್ಟಾಗಿ ಚಿಕ್ಕದಾಗಿದೆ.
/// ಸಬ್‌ನಾರ್ಮಲ್‌ಗಳು, ಶೂನ್ಯ ಅಥವಾ ಘಾತೀಯ ಒಳಹರಿವನ್ನು ನಿರ್ವಹಿಸುವುದಿಲ್ಲ.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// ಆರ್ಗ್ಯುಮೆಂಟ್ಗಿಂತ ಕಟ್ಟುನಿಟ್ಟಾಗಿ ದೊಡ್ಡದಾದ ಚಿಕ್ಕ ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಸಂಖ್ಯೆಯನ್ನು ಹುಡುಕಿ.
// ಈ ಕಾರ್ಯಾಚರಣೆಯು ಸ್ಯಾಚುರೇಟಿಂಗ್ ಆಗಿದೆ, ಅಂದರೆ, next_float(inf) ==inf.
// ಈ ಮಾಡ್ಯೂಲ್‌ನಲ್ಲಿನ ಹೆಚ್ಚಿನ ಕೋಡ್‌ಗಿಂತ ಭಿನ್ನವಾಗಿ, ಈ ಕಾರ್ಯವು ಶೂನ್ಯ, ಸಬ್‌ನಾರ್ಮಲ್‌ಗಳು ಮತ್ತು ಅನಂತಗಳನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
// ಆದಾಗ್ಯೂ, ಇಲ್ಲಿರುವ ಎಲ್ಲಾ ಇತರ ಕೋಡ್‌ಗಳಂತೆ, ಇದು NaN ಮತ್ತು negative ಣಾತ್ಮಕ ಸಂಖ್ಯೆಗಳೊಂದಿಗೆ ವ್ಯವಹರಿಸುವುದಿಲ್ಲ.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // ಇದು ನಿಜವೆಂದು ತುಂಬಾ ಒಳ್ಳೆಯದು ಎಂದು ತೋರುತ್ತದೆ, ಆದರೆ ಇದು ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ.
        // 0.0 ಅನ್ನು ಎಲ್ಲಾ ಶೂನ್ಯ ಪದವಾಗಿ ಎನ್ಕೋಡ್ ಮಾಡಲಾಗಿದೆ.ಸಬ್‌ನಾರ್ಮಲ್‌ಗಳು 0x000 ಮೀ ... ಮೀ ಇಲ್ಲಿ ಮೀ ಮಂಟಿಸ್ಸಾ.
        // ನಿರ್ದಿಷ್ಟವಾಗಿ ಹೇಳುವುದಾದರೆ, ಚಿಕ್ಕದಾದ ಸಬ್ನಾರ್ಮಲ್ 0x0 ... 01 ಮತ್ತು ದೊಡ್ಡದು 0x000F ... F.
        // ಚಿಕ್ಕದಾದ ಸಾಮಾನ್ಯ ಸಂಖ್ಯೆ 0x0010 ... 0, ಆದ್ದರಿಂದ ಈ ಮೂಲೆಯ ಪ್ರಕರಣವೂ ಸಹ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ.
        // ಹೆಚ್ಚಳವು ಮಂಟಿಸಾವನ್ನು ಉಕ್ಕಿ ಹರಿಯುತ್ತಿದ್ದರೆ, ಕ್ಯಾರಿ ಬಿಟ್ ನಮಗೆ ಬೇಕಾದಂತೆ ಘಾತಾಂಕವನ್ನು ಹೆಚ್ಚಿಸುತ್ತದೆ ಮತ್ತು ಮಂಟಿಸ್ಸಾ ಬಿಟ್‌ಗಳು ಶೂನ್ಯವಾಗುತ್ತವೆ.
        // ಗುಪ್ತ ಬಿಟ್ ಸಮಾವೇಶದ ಕಾರಣ, ಇದು ಕೂಡ ನಮಗೆ ಬೇಕಾಗಿರುವುದು!
        // ಅಂತಿಮವಾಗಿ, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}