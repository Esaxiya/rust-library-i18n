macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// ಈ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರದಿಂದ ಪ್ರತಿನಿಧಿಸಬಹುದಾದ ಚಿಕ್ಕ ಮೌಲ್ಯ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// ಈ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರದಿಂದ ಪ್ರತಿನಿಧಿಸಬಹುದಾದ ದೊಡ್ಡ ಮೌಲ್ಯ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// ಬಿಟ್‌ಗಳಲ್ಲಿ ಈ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರದ ಗಾತ್ರ.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// ನಿರ್ದಿಷ್ಟ ತಳದಲ್ಲಿ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಪೂರ್ಣಾಂಕಕ್ಕೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
        ///
        /// ಸ್ಟ್ರಿಂಗ್ ಐಚ್ al ಿಕ `+` ಚಿಹ್ನೆ ಮತ್ತು ನಂತರ ಅಂಕೆಗಳು ಎಂದು ನಿರೀಕ್ಷಿಸಲಾಗಿದೆ.
        ///
        /// ಮುನ್ನಡೆ ಮತ್ತು ಹಿಂದುಳಿದಿರುವ ಜಾಗವು ದೋಷವನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
        /// `radix` ಗೆ ಅನುಗುಣವಾಗಿ ಅಂಕೆಗಳು ಈ ಅಕ್ಷರಗಳ ಉಪವಿಭಾಗವಾಗಿದೆ:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// `radix` 2 ರಿಂದ 36 ರ ವ್ಯಾಪ್ತಿಯಲ್ಲಿಲ್ಲದಿದ್ದರೆ ಈ ಕಾರ್ಯ panics.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// `self` ನ ಬೈನರಿ ಪ್ರಾತಿನಿಧ್ಯದಲ್ಲಿರುವವರ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// `self` ನ ಬೈನರಿ ಪ್ರಾತಿನಿಧ್ಯದಲ್ಲಿನ ಸೊನ್ನೆಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// `self` ನ ಬೈನರಿ ಪ್ರಾತಿನಿಧ್ಯದಲ್ಲಿ ಪ್ರಮುಖ ಸೊನ್ನೆಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// `self` ನ ಬೈನರಿ ಪ್ರಾತಿನಿಧ್ಯದಲ್ಲಿ ಹಿಂದುಳಿದ ಸೊನ್ನೆಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// `self` ನ ಬೈನರಿ ಪ್ರಾತಿನಿಧ್ಯದಲ್ಲಿ ಪ್ರಮುಖವಾದವರ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// `self` ನ ಬೈನರಿ ಪ್ರಾತಿನಿಧ್ಯದಲ್ಲಿ ಹಿಂದುಳಿದವರ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// ಮೊಟಕುಗೊಳಿಸಿದ ಬಿಟ್‌ಗಳನ್ನು ಫಲಿತಾಂಶದ ಪೂರ್ಣಾಂಕದ ಕೊನೆಯಲ್ಲಿ ಸುತ್ತಿ, ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಮೊತ್ತವಾದ `n` ನಿಂದ ಬಿಟ್‌ಗಳನ್ನು ಎಡಕ್ಕೆ ಬದಲಾಯಿಸುತ್ತದೆ.
        ///
        ///
        /// ಇದು `<<` ಶಿಫ್ಟಿಂಗ್ ಆಪರೇಟರ್ನ ಅದೇ ಕಾರ್ಯಾಚರಣೆಯಲ್ಲ ಎಂಬುದನ್ನು ದಯವಿಟ್ಟು ಗಮನಿಸಿ!
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// ಮೊಟಕುಗೊಳಿಸಿದ ಬಿಟ್‌ಗಳನ್ನು ಫಲಿತಾಂಶದ ಪೂರ್ಣಾಂಕದ ಆರಂಭಕ್ಕೆ ಸುತ್ತಿ, ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಮೊತ್ತವಾದ `n` ಮೂಲಕ ಬಿಟ್‌ಗಳನ್ನು ಬಲಕ್ಕೆ ಬದಲಾಯಿಸುತ್ತದೆ.
        ///
        ///
        /// ಇದು `>>` ಶಿಫ್ಟಿಂಗ್ ಆಪರೇಟರ್ನ ಅದೇ ಕಾರ್ಯಾಚರಣೆಯಲ್ಲ ಎಂಬುದನ್ನು ದಯವಿಟ್ಟು ಗಮನಿಸಿ!
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// ಪೂರ್ಣಾಂಕದ ಬೈಟ್ ಕ್ರಮವನ್ನು ಹಿಮ್ಮುಖಗೊಳಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// m= n.swap_bytes() ಅನ್ನು ಬಿಡಿ;
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// ಪೂರ್ಣಾಂಕದಲ್ಲಿನ ಬಿಟ್‌ಗಳ ಕ್ರಮವನ್ನು ಹಿಮ್ಮುಖಗೊಳಿಸುತ್ತದೆ.
        /// ಕಡಿಮೆ ಮಹತ್ವದ ಬಿಟ್ ಅತ್ಯಂತ ಮಹತ್ವದ ಬಿಟ್ ಆಗುತ್ತದೆ, ಎರಡನೆಯ ಕನಿಷ್ಠ-ಮಹತ್ವದ ಬಿಟ್ ಎರಡನೇ ಅತ್ಯಂತ ಮಹತ್ವದ ಬಿಟ್ ಆಗುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// m= n.reverse_bits() ಅನ್ನು ಬಿಡಿ;
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// ದೊಡ್ಡ ಪೂರ್ಣಾಂಕದಿಂದ ಗುರಿಯ ಅಂತ್ಯಕ್ಕೆ ಪೂರ್ಣಾಂಕವನ್ನು ಪರಿವರ್ತಿಸುತ್ತದೆ.
        ///
        /// ದೊಡ್ಡ ಎಂಡಿಯನ್‌ನಲ್ಲಿ ಇದು ನೋ-ಆಪ್ ಆಗಿದೆ.
        /// ಸ್ವಲ್ಪ ಎಂಡಿಯನ್‌ನಲ್ಲಿ ಬೈಟ್‌ಗಳನ್ನು ಬದಲಾಯಿಸಲಾಗುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } else {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// ಪೂರ್ಣಾಂಕವನ್ನು ಸ್ವಲ್ಪ ಎಂಡಿಯನ್‌ನಿಂದ ಗುರಿಯ ಅಂತ್ಯಕ್ಕೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
        ///
        /// ಸ್ವಲ್ಪ ಎಂಡಿಯನ್‌ನಲ್ಲಿ ಇದು ನೋ-ಆಪ್ ಆಗಿದೆ.
        /// ದೊಡ್ಡ ಎಂಡಿಯನ್‌ನಲ್ಲಿ ಬೈಟ್‌ಗಳನ್ನು ಬದಲಾಯಿಸಲಾಗುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } else {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// `self` ಅನ್ನು ಗುರಿಯ ಅಂತ್ಯದಿಂದ ದೊಡ್ಡ ಎಂಡಿಯನ್‌ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
        ///
        /// ದೊಡ್ಡ ಎಂಡಿಯನ್‌ನಲ್ಲಿ ಇದು ನೋ-ಆಪ್ ಆಗಿದೆ.
        /// ಸ್ವಲ್ಪ ಎಂಡಿಯನ್‌ನಲ್ಲಿ ಬೈಟ್‌ಗಳನ್ನು ಬದಲಾಯಿಸಲಾಗುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } else { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // ಅಥವಾ ಇರಬಾರದು?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// `self` ಅನ್ನು ಗುರಿಯ ಅಂತ್ಯದಿಂದ ಸ್ವಲ್ಪ ಎಂಡಿಯನ್‌ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
        ///
        /// ಸ್ವಲ್ಪ ಎಂಡಿಯನ್‌ನಲ್ಲಿ ಇದು ನೋ-ಆಪ್ ಆಗಿದೆ.
        /// ದೊಡ್ಡ ಎಂಡಿಯನ್‌ನಲ್ಲಿ ಬೈಟ್‌ಗಳನ್ನು ಬದಲಾಯಿಸಲಾಗುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } else { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// ಪೂರ್ಣಾಂಕ ಸೇರ್ಪಡೆ ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
        /// `self + rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಓವರ್‌ಫ್ಲೋ ಸಂಭವಿಸಿದಲ್ಲಿ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ಪರಿಶೀಲಿಸದ ಪೂರ್ಣಾಂಕ ಸೇರ್ಪಡೆ.`self + rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ ಎಂದು uming ಹಿಸಿ.
        /// ಇದು ಯಾವಾಗ ವಿವರಿಸಲಾಗದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `unchecked_add` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// ಪೂರ್ಣಾಂಕ ವ್ಯವಕಲನವನ್ನು ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
        /// `self - rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಓವರ್‌ಫ್ಲೋ ಸಂಭವಿಸಿದಲ್ಲಿ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ಪರಿಶೀಲಿಸದ ಪೂರ್ಣಾಂಕ ವ್ಯವಕಲನ.`self - rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ ಎಂದು uming ಹಿಸಿ.
        /// ಇದು ಯಾವಾಗ ವಿವರಿಸಲಾಗದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `unchecked_sub` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// ಪೂರ್ಣಾಂಕ ಗುಣಾಕಾರವನ್ನು ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
        /// `self * rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಓವರ್‌ಫ್ಲೋ ಸಂಭವಿಸಿದಲ್ಲಿ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ಪರಿಶೀಲಿಸದ ಪೂರ್ಣಾಂಕ ಗುಣಾಕಾರ.`self * rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ ಎಂದು uming ಹಿಸಿ.
        /// ಇದು ಯಾವಾಗ ವಿವರಿಸಲಾಗದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `unchecked_mul` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// ಪೂರ್ಣಾಂಕ ವಿಭಾಗವನ್ನು ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
        /// `self / rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, `rhs == 0` ಆಗಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // ಸುರಕ್ಷತೆ: ಡಿವ್ ಬೈ ಶೂನ್ಯವನ್ನು ಮೇಲೆ ಪರಿಶೀಲಿಸಲಾಗಿದೆ ಮತ್ತು ಸಹಿ ಮಾಡದ ಪ್ರಕಾರಗಳಿಗೆ ಬೇರೆ ಇಲ್ಲ
                // ವಿಭಾಗಕ್ಕಾಗಿ ವೈಫಲ್ಯ ವಿಧಾನಗಳು
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// ಪರಿಶೀಲಿಸಿದ ಯೂಕ್ಲಿಡಿಯನ್ ವಿಭಾಗ.
        /// `self.div_euclid(rhs)` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, `rhs == 0` ಆಗಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// ಪರಿಶೀಲಿಸಿದ ಪೂರ್ಣಾಂಕ ಉಳಿದಿದೆ.
        /// `self % rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, `rhs == 0` ಆಗಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // ಸುರಕ್ಷತೆ: ಡಿವ್ ಬೈ ಶೂನ್ಯವನ್ನು ಮೇಲೆ ಪರಿಶೀಲಿಸಲಾಗಿದೆ ಮತ್ತು ಸಹಿ ಮಾಡದ ಪ್ರಕಾರಗಳಿಗೆ ಬೇರೆ ಇಲ್ಲ
                // ವಿಭಾಗಕ್ಕಾಗಿ ವೈಫಲ್ಯ ವಿಧಾನಗಳು
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// ಪರಿಶೀಲಿಸಿದ ಯೂಕ್ಲಿಡಿಯನ್ ಮಾಡ್ಯುಲೋ.
        /// `self.rem_euclid(rhs)` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, `rhs == 0` ಆಗಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// ನಿರಾಕರಣೆ ಪರಿಶೀಲಿಸಲಾಗಿದೆ.`-self` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, `ಸ್ವಯಂ==ಹೊರತು `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ
        /// 0`.
        ///
        /// ಯಾವುದೇ ಸಕಾರಾತ್ಮಕ ಪೂರ್ಣಾಂಕವನ್ನು ನಿರಾಕರಿಸುವುದರಿಂದ ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ಪರಿಶೀಲಿಸಿದ ಶಿಫ್ಟ್ ಎಡಕ್ಕೆ.
        /// `self << rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, `rhs` `self` ನಲ್ಲಿನ ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆಗಿಂತ ದೊಡ್ಡದಾಗಿದ್ದರೆ ಅಥವಾ ಸಮನಾಗಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ಶಿಫ್ಟ್ ಬಲವನ್ನು ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
        /// `self >> rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, `rhs` `self` ನಲ್ಲಿನ ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆಗಿಂತ ದೊಡ್ಡದಾಗಿದ್ದರೆ ಅಥವಾ ಸಮನಾಗಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ಪರಿಶೀಲಿಸಿದ ಘಾತಾಂಕ.
        /// `self.pow(exp)` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಓವರ್‌ಫ್ಲೋ ಸಂಭವಿಸಿದಲ್ಲಿ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // exp!=0 ರಿಂದ, ಅಂತಿಮವಾಗಿ exp 1 ಆಗಿರಬೇಕು.
            // ಘಾತಕದ ಅಂತಿಮ ಬಿಟ್ ಅನ್ನು ಪ್ರತ್ಯೇಕವಾಗಿ ನಿಭಾಯಿಸಿ, ಏಕೆಂದರೆ ನಂತರ ಬೇಸ್ ಅನ್ನು ವರ್ಗೀಕರಿಸುವುದು ಅನಿವಾರ್ಯವಲ್ಲ ಮತ್ತು ಅನಗತ್ಯ ಉಕ್ಕಿ ಹರಿಯಲು ಕಾರಣವಾಗಬಹುದು.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// ಪೂರ್ಣಾಂಕ ಸೇರ್ಪಡೆ.
        /// `self + rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ತುಂಬಿ ಹರಿಯುವ ಬದಲು ಸಂಖ್ಯಾ ಗಡಿಗಳಲ್ಲಿ ಸ್ಯಾಚುರೇಟಿಂಗ್ ಮಾಡುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// ಸ್ಯಾಚುರೇಟಿಂಗ್ ಪೂರ್ಣಾಂಕ ವ್ಯವಕಲನ.
        /// `self - rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ತುಂಬಿ ಹರಿಯುವ ಬದಲು ಸಂಖ್ಯಾ ಗಡಿಗಳಲ್ಲಿ ಸ್ಯಾಚುರೇಟಿಂಗ್ ಮಾಡುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// ಪೂರ್ಣಾಂಕ ಗುಣಾಕಾರ.
        /// `self * rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ತುಂಬಿ ಹರಿಯುವ ಬದಲು ಸಂಖ್ಯಾ ಗಡಿಗಳಲ್ಲಿ ಸ್ಯಾಚುರೇಟಿಂಗ್ ಮಾಡುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// ಪೂರ್ಣಾಂಕ ಘಾತಾಂಕವನ್ನು ಸ್ಯಾಚುರೇಟಿಂಗ್.
        /// `self.pow(exp)` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ತುಂಬಿ ಹರಿಯುವ ಬದಲು ಸಂಖ್ಯಾ ಗಡಿಗಳಲ್ಲಿ ಸ್ಯಾಚುರೇಟಿಂಗ್ ಮಾಡುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// (modular) ಸೇರ್ಪಡೆ ಸುತ್ತಿ.
        /// `self + rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಪ್ರಕಾರದ ಗಡಿಯಲ್ಲಿ ಸುತ್ತಿಕೊಳ್ಳುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// (modular) ವ್ಯವಕಲನವನ್ನು ಸುತ್ತುವುದು.
        /// `self - rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಪ್ರಕಾರದ ಗಡಿಯಲ್ಲಿ ಸುತ್ತಿಕೊಳ್ಳುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// (modular) ಗುಣಾಕಾರವನ್ನು ಸುತ್ತುವುದು.
        /// `self * rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಪ್ರಕಾರದ ಗಡಿಯಲ್ಲಿ ಸುತ್ತಿಕೊಳ್ಳುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ಈ ಉದಾಹರಣೆಯನ್ನು ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳ ನಡುವೆ ಹಂಚಿಕೊಳ್ಳಲಾಗಿದೆ ಎಂಬುದನ್ನು ದಯವಿಟ್ಟು ಗಮನಿಸಿ.
        /// `u8` ಅನ್ನು ಇಲ್ಲಿ ಏಕೆ ಬಳಸಲಾಗಿದೆ ಎಂಬುದನ್ನು ಇದು ವಿವರಿಸುತ್ತದೆ.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// (modular) ವಿಭಾಗವನ್ನು ಸುತ್ತುವುದು.`self / rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
        /// ಸಹಿ ಮಾಡದ ಪ್ರಕಾರಗಳ ಮೇಲೆ ಸುತ್ತುವ ವಿಭಾಗವು ಸಾಮಾನ್ಯ ವಿಭಾಗವಾಗಿದೆ.
        /// ಸುತ್ತುವಿಕೆಯು ಎಂದಿಗೂ ಸಂಭವಿಸುವುದಿಲ್ಲ.
        /// ಈ ಕಾರ್ಯವು ಅಸ್ತಿತ್ವದಲ್ಲಿದೆ, ಇದರಿಂದಾಗಿ ಎಲ್ಲಾ ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಸುತ್ತುವ ಕಾರ್ಯಾಚರಣೆಗಳಲ್ಲಿ ಪರಿಗಣಿಸಲಾಗುತ್ತದೆ.
        ///
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// ಯೂಕ್ಲಿಡಿಯನ್ ವಿಭಾಗವನ್ನು ಸುತ್ತುವುದು.`self.div_euclid(rhs)` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
        /// ಸಹಿ ಮಾಡದ ಪ್ರಕಾರಗಳ ಮೇಲೆ ಸುತ್ತುವ ವಿಭಾಗವು ಸಾಮಾನ್ಯ ವಿಭಾಗವಾಗಿದೆ.
        /// ಸುತ್ತುವಿಕೆಯು ಎಂದಿಗೂ ಸಂಭವಿಸುವುದಿಲ್ಲ.
        /// ಈ ಕಾರ್ಯವು ಅಸ್ತಿತ್ವದಲ್ಲಿದೆ, ಇದರಿಂದಾಗಿ ಎಲ್ಲಾ ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಸುತ್ತುವ ಕಾರ್ಯಾಚರಣೆಗಳಲ್ಲಿ ಪರಿಗಣಿಸಲಾಗುತ್ತದೆ.
        /// ಧನಾತ್ಮಕ ಪೂರ್ಣಾಂಕಗಳಿಗೆ, ವಿಭಜನೆಯ ಎಲ್ಲಾ ಸಾಮಾನ್ಯ ವ್ಯಾಖ್ಯಾನಗಳು ಸಮಾನವಾಗಿರುವುದರಿಂದ, ಇದು `self.wrapping_div(rhs)` ಗೆ ನಿಖರವಾಗಿ ಸಮಾನವಾಗಿರುತ್ತದೆ.
        ///
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// ಉಳಿದ (modular) ಅನ್ನು ಸುತ್ತುತ್ತದೆ.`self % rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
        /// ಸಹಿ ಮಾಡದ ಪ್ರಕಾರಗಳ ಮೇಲೆ ಸುತ್ತಿದ ಉಳಿದ ಲೆಕ್ಕಾಚಾರವು ಸಾಮಾನ್ಯ ಉಳಿದ ಲೆಕ್ಕಾಚಾರವಾಗಿದೆ.
        ///
        /// ಸುತ್ತುವಿಕೆಯು ಎಂದಿಗೂ ಸಂಭವಿಸುವುದಿಲ್ಲ.
        /// ಈ ಕಾರ್ಯವು ಅಸ್ತಿತ್ವದಲ್ಲಿದೆ, ಇದರಿಂದಾಗಿ ಎಲ್ಲಾ ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಸುತ್ತುವ ಕಾರ್ಯಾಚರಣೆಗಳಲ್ಲಿ ಪರಿಗಣಿಸಲಾಗುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// ಯೂಕ್ಲಿಡಿಯನ್ ಮಾಡ್ಯುಲೊವನ್ನು ಸುತ್ತುವುದು.`self.rem_euclid(rhs)` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
        /// ಸಹಿ ಮಾಡದ ಪ್ರಕಾರಗಳ ಮೇಲೆ ಸುತ್ತಿದ ಮಾಡ್ಯುಲೋ ಲೆಕ್ಕಾಚಾರವು ಸಾಮಾನ್ಯ ಉಳಿದ ಲೆಕ್ಕಾಚಾರವಾಗಿದೆ.
        /// ಸುತ್ತುವಿಕೆಯು ಎಂದಿಗೂ ಸಂಭವಿಸುವುದಿಲ್ಲ.
        /// ಈ ಕಾರ್ಯವು ಅಸ್ತಿತ್ವದಲ್ಲಿದೆ, ಇದರಿಂದಾಗಿ ಎಲ್ಲಾ ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಸುತ್ತುವ ಕಾರ್ಯಾಚರಣೆಗಳಲ್ಲಿ ಪರಿಗಣಿಸಲಾಗುತ್ತದೆ.
        /// ಧನಾತ್ಮಕ ಪೂರ್ಣಾಂಕಗಳಿಗೆ, ವಿಭಜನೆಯ ಎಲ್ಲಾ ಸಾಮಾನ್ಯ ವ್ಯಾಖ್ಯಾನಗಳು ಸಮಾನವಾಗಿರುವುದರಿಂದ, ಇದು `self.wrapping_rem(rhs)` ಗೆ ನಿಖರವಾಗಿ ಸಮಾನವಾಗಿರುತ್ತದೆ.
        ///
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// (modular) ನಿರಾಕರಣೆಯನ್ನು ಸುತ್ತುವುದು.
        /// `-self` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಪ್ರಕಾರದ ಗಡಿಯಲ್ಲಿ ಸುತ್ತಿಕೊಳ್ಳುತ್ತದೆ.
        ///
        /// ಸಹಿ ಮಾಡದ ಪ್ರಕಾರಗಳು negative ಣಾತ್ಮಕ ಸಮಾನತೆಯನ್ನು ಹೊಂದಿರದ ಕಾರಣ ಈ ಕಾರ್ಯದ ಎಲ್ಲಾ ಅಪ್ಲಿಕೇಶನ್‌ಗಳು ಸುತ್ತುತ್ತವೆ (`-0` ಹೊರತುಪಡಿಸಿ).
        /// ಅನುಗುಣವಾದ ಸಹಿ ಪ್ರಕಾರದ ಗರಿಷ್ಠಕ್ಕಿಂತ ಚಿಕ್ಕದಾದ ಮೌಲ್ಯಗಳಿಗೆ ಫಲಿತಾಂಶವು ಅನುಗುಣವಾದ ಸಹಿ ಮಾಡಿದ ಮೌಲ್ಯವನ್ನು ಬಿತ್ತರಿಸುವಂತೆಯೇ ಇರುತ್ತದೆ.
        ///
        /// ಯಾವುದೇ ದೊಡ್ಡ ಮೌಲ್ಯಗಳು `MAX + 1 - (val - MAX - 1)` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ, ಅಲ್ಲಿ `MAX` ಅನುಗುಣವಾದ ಸಹಿ ಪ್ರಕಾರದ ಗರಿಷ್ಠವಾಗಿರುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ಈ ಉದಾಹರಣೆಯನ್ನು ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳ ನಡುವೆ ಹಂಚಿಕೊಳ್ಳಲಾಗಿದೆ ಎಂಬುದನ್ನು ದಯವಿಟ್ಟು ಗಮನಿಸಿ.
        /// `i8` ಅನ್ನು ಇಲ್ಲಿ ಏಕೆ ಬಳಸಲಾಗಿದೆ ಎಂಬುದನ್ನು ಇದು ವಿವರಿಸುತ್ತದೆ.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-ಮುಕ್ತ ಬಿಟ್‌ವೈಸ್ ಶಿಫ್ಟ್-ಎಡ;
        /// `self << mask(rhs)` ಅನ್ನು ನೀಡುತ್ತದೆ, ಅಲ್ಲಿ `mask` ಯಾವುದೇ ಉನ್ನತ-ಕ್ರಮಾಂಕದ `rhs` ಅನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ, ಅದು ಶಿಫ್ಟ್ ಪ್ರಕಾರದ ಬಿಟ್‌ವಿಡ್ತ್ ಅನ್ನು ಮೀರುತ್ತದೆ.
        ///
        /// ಇದು ತಿರುಗುವ-ಎಡಕ್ಕೆ ಸಮನಾಗಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ;ಸುತ್ತುವ ಶಿಫ್ಟ್-ಎಡದ RHS ಅನ್ನು LHS ನಿಂದ ಹೊರಹಾಕಿದ ಬಿಟ್‌ಗಳನ್ನು ಇನ್ನೊಂದು ತುದಿಗೆ ಹಿಂದಿರುಗಿಸುವ ಬದಲು ಪ್ರಕಾರದ ವ್ಯಾಪ್ತಿಗೆ ಸೀಮಿತಗೊಳಿಸಲಾಗಿದೆ.
        /// ಪ್ರಾಚೀನ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳು ಎಲ್ಲಾ [`rotate_left`](Self::rotate_left) ಕಾರ್ಯವನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತವೆ, ಅದು ನಿಮಗೆ ಬೇಕಾಗಿರಬಹುದು.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // ಸುರಕ್ಷತೆ: ಪ್ರಕಾರದ ಬಿಟ್‌ಸೈಜ್‌ನಿಂದ ಮರೆಮಾಚುವಿಕೆಯು ನಾವು ಸ್ಥಳಾಂತರಗೊಳ್ಳದಂತೆ ನೋಡಿಕೊಳ್ಳುತ್ತದೆ
            // ಮಿತಿ ಮೀರಿದೆ
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-ಮುಕ್ತ ಬಿಟ್‌ವೈಸ್ ಶಿಫ್ಟ್-ಬಲ;
        /// `self >> mask(rhs)` ಅನ್ನು ನೀಡುತ್ತದೆ, ಅಲ್ಲಿ `mask` ಯಾವುದೇ ಉನ್ನತ-ಕ್ರಮಾಂಕದ `rhs` ಅನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ, ಅದು ಶಿಫ್ಟ್ ಪ್ರಕಾರದ ಬಿಟ್‌ವಿಡ್ತ್ ಅನ್ನು ಮೀರುತ್ತದೆ.
        ///
        /// ಇದು ತಿರುಗುವ-ಬಲಕ್ಕೆ ಸಮನಾಗಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ;ಸುತ್ತುವ ಶಿಫ್ಟ್-ಬಲದ RHS ಅನ್ನು LHS ನಿಂದ ಸ್ಥಳಾಂತರಿಸಿದ ಬಿಟ್‌ಗಳನ್ನು ಇನ್ನೊಂದು ತುದಿಗೆ ಹಿಂತಿರುಗಿಸುವ ಬದಲು ಪ್ರಕಾರದ ವ್ಯಾಪ್ತಿಗೆ ಸೀಮಿತಗೊಳಿಸಲಾಗಿದೆ.
        /// ಪ್ರಾಚೀನ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳು ಎಲ್ಲಾ [`rotate_right`](Self::rotate_right) ಕಾರ್ಯವನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತವೆ, ಅದು ನಿಮಗೆ ಬೇಕಾಗಿರಬಹುದು.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // ಸುರಕ್ಷತೆ: ಪ್ರಕಾರದ ಬಿಟ್‌ಸೈಜ್‌ನಿಂದ ಮರೆಮಾಚುವಿಕೆಯು ನಾವು ಸ್ಥಳಾಂತರಗೊಳ್ಳದಂತೆ ನೋಡಿಕೊಳ್ಳುತ್ತದೆ
            // ಮಿತಿ ಮೀರಿದೆ
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// (modular) ಘಾತಾಂಕವನ್ನು ಸುತ್ತುವುದು.
        /// `self.pow(exp)` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಪ್ರಕಾರದ ಗಡಿಯಲ್ಲಿ ಸುತ್ತಿಕೊಳ್ಳುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // exp!=0 ರಿಂದ, ಅಂತಿಮವಾಗಿ exp 1 ಆಗಿರಬೇಕು.
            // ಘಾತಕದ ಅಂತಿಮ ಬಿಟ್ ಅನ್ನು ಪ್ರತ್ಯೇಕವಾಗಿ ನಿಭಾಯಿಸಿ, ಏಕೆಂದರೆ ನಂತರ ಬೇಸ್ ಅನ್ನು ವರ್ಗೀಕರಿಸುವುದು ಅನಿವಾರ್ಯವಲ್ಲ ಮತ್ತು ಅನಗತ್ಯ ಉಕ್ಕಿ ಹರಿಯಲು ಕಾರಣವಾಗಬಹುದು.
            //
            //
            acc.wrapping_mul(base)
        }

        /// `self` + `rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ
        ///
        /// ಅಂಕಗಣಿತದ ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆಯೇ ಎಂದು ಸೂಚಿಸುವ ಬೂಲಿಯನ್ ಜೊತೆಗೆ ಸೇರ್ಪಡೆಯ ಒಂದು ಟಪಲ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        /// ಉಕ್ಕಿ ಹರಿಯುವುದಾದರೆ ಸುತ್ತಿದ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self`, `rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ
        ///
        /// ಅಂಕಗಣಿತದ ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆಯೇ ಎಂದು ಸೂಚಿಸುವ ಬೂಲಿಯನ್ ಜೊತೆಗೆ ವ್ಯವಕಲನದ ಟಪಲ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        /// ಉಕ್ಕಿ ಹರಿಯುವುದಾದರೆ ಸುತ್ತಿದ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` ಮತ್ತು `rhs` ನ ಗುಣಾಕಾರವನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
        ///
        /// ಅಂಕಗಣಿತದ ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆಯೇ ಎಂದು ಸೂಚಿಸುವ ಬೂಲಿಯನ್ ಜೊತೆಗೆ ಗುಣಾಕಾರದ ಒಂದು ಟಪಲ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        /// ಉಕ್ಕಿ ಹರಿಯುವುದಾದರೆ ಸುತ್ತಿದ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ಈ ಉದಾಹರಣೆಯನ್ನು ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳ ನಡುವೆ ಹಂಚಿಕೊಳ್ಳಲಾಗಿದೆ ಎಂಬುದನ್ನು ದಯವಿಟ್ಟು ಗಮನಿಸಿ.
        /// `u32` ಅನ್ನು ಇಲ್ಲಿ ಏಕೆ ಬಳಸಲಾಗಿದೆ ಎಂಬುದನ್ನು ಇದು ವಿವರಿಸುತ್ತದೆ.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` ಅನ್ನು `rhs` ನಿಂದ ಭಾಗಿಸಿದಾಗ ವಿಭಜಕವನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
        ///
        /// ಅಂಕಗಣಿತದ ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆಯೇ ಎಂದು ಸೂಚಿಸುವ ಬೂಲಿಯನ್ ಜೊತೆಗೆ ವಿಭಜಕದ ಟಪಲ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        /// ಸಹಿ ಮಾಡದ ಪೂರ್ಣಾಂಕಗಳಿಗೆ ಓವರ್‌ಫ್ಲೋ ಎಂದಿಗೂ ಸಂಭವಿಸುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಆದ್ದರಿಂದ ಎರಡನೇ ಮೌಲ್ಯವು ಯಾವಾಗಲೂ `false` ಆಗಿರುತ್ತದೆ.
        ///
        /// # Panics
        ///
        /// `rhs` 0 ಆಗಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// ಯೂಕ್ಲಿಡಿಯನ್ ವಿಭಾಗ `self.div_euclid(rhs)` ನ ಅಂಶವನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
        ///
        /// ಅಂಕಗಣಿತದ ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆಯೇ ಎಂದು ಸೂಚಿಸುವ ಬೂಲಿಯನ್ ಜೊತೆಗೆ ವಿಭಜಕದ ಟಪಲ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        /// ಸಹಿ ಮಾಡದ ಪೂರ್ಣಾಂಕಗಳಿಗೆ ಓವರ್‌ಫ್ಲೋ ಎಂದಿಗೂ ಸಂಭವಿಸುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಆದ್ದರಿಂದ ಎರಡನೇ ಮೌಲ್ಯವು ಯಾವಾಗಲೂ `false` ಆಗಿರುತ್ತದೆ.
        /// ಧನಾತ್ಮಕ ಪೂರ್ಣಾಂಕಗಳಿಗೆ, ವಿಭಜನೆಯ ಎಲ್ಲಾ ಸಾಮಾನ್ಯ ವ್ಯಾಖ್ಯಾನಗಳು ಸಮಾನವಾಗಿರುವುದರಿಂದ, ಇದು `self.overflowing_div(rhs)` ಗೆ ನಿಖರವಾಗಿ ಸಮಾನವಾಗಿರುತ್ತದೆ.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 ಆಗಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// `self` ಅನ್ನು `rhs` ನಿಂದ ಭಾಗಿಸಿದಾಗ ಉಳಿದವನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
        ///
        /// ಅಂಕಗಣಿತದ ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆಯೇ ಎಂದು ಸೂಚಿಸುವ ಬೂಲಿಯನ್ ಜೊತೆಗೆ ವಿಭಜಿಸಿದ ನಂತರ ಉಳಿದ ಒಂದು ತುಂಡನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        /// ಸಹಿ ಮಾಡದ ಪೂರ್ಣಾಂಕಗಳಿಗೆ ಓವರ್‌ಫ್ಲೋ ಎಂದಿಗೂ ಸಂಭವಿಸುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಆದ್ದರಿಂದ ಎರಡನೇ ಮೌಲ್ಯವು ಯಾವಾಗಲೂ `false` ಆಗಿರುತ್ತದೆ.
        ///
        /// # Panics
        ///
        /// `rhs` 0 ಆಗಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// ಉಳಿದ `self.rem_euclid(rhs)` ಅನ್ನು ಯೂಕ್ಲಿಡಿಯನ್ ವಿಭಾಗದಂತೆ ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
        ///
        /// ಅಂಕಗಣಿತದ ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆಯೇ ಎಂದು ಸೂಚಿಸುವ ಬೂಲಿಯನ್ ಜೊತೆಗೆ ವಿಭಜಿಸಿದ ನಂತರ ಮಾಡ್ಯುಲೋನ ಟಪಲ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        /// ಸಹಿ ಮಾಡದ ಪೂರ್ಣಾಂಕಗಳಿಗೆ ಓವರ್‌ಫ್ಲೋ ಎಂದಿಗೂ ಸಂಭವಿಸುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಆದ್ದರಿಂದ ಎರಡನೇ ಮೌಲ್ಯವು ಯಾವಾಗಲೂ `false` ಆಗಿರುತ್ತದೆ.
        /// ಧನಾತ್ಮಕ ಪೂರ್ಣಾಂಕಗಳಿಗೆ, ವಿಭಜನೆಯ ಎಲ್ಲಾ ಸಾಮಾನ್ಯ ವ್ಯಾಖ್ಯಾನಗಳು ಸಮಾನವಾಗಿರುವುದರಿಂದ, ಈ ಕಾರ್ಯಾಚರಣೆಯು `self.overflowing_rem(rhs)` ಗೆ ನಿಖರವಾಗಿ ಸಮಾನವಾಗಿರುತ್ತದೆ.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 ಆಗಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// ತುಂಬಿ ಹರಿಯುವ ಶೈಲಿಯಲ್ಲಿ ಸ್ವಯಂ ನಿರಾಕರಣೆ.
        ///
        /// ಈ ಸಹಿ ಮಾಡದ ಮೌಲ್ಯದ ನಿರಾಕರಣೆಯನ್ನು ಪ್ರತಿನಿಧಿಸುವ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸಲು ಸುತ್ತುವ ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬಳಸಿಕೊಂಡು `!self + 1` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        /// ಸಕಾರಾತ್ಮಕ ಸಹಿ ಮಾಡದ ಮೌಲ್ಯಗಳಿಗೆ ಉಕ್ಕಿ ಹರಿಯುವುದು ಯಾವಾಗಲೂ ಸಂಭವಿಸುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಆದರೆ 0 ಅನ್ನು ನಿರಾಕರಿಸುವುದು ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// `rhs` ಬಿಟ್‌ಗಳಿಂದ ಸ್ವಯಂ ಎಡಕ್ಕೆ ಬದಲಾಗುತ್ತದೆ.
        ///
        /// ಶಿಫ್ಟ್ ಮೌಲ್ಯವು ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆಗಿಂತ ದೊಡ್ಡದಾಗಿದೆಯೆ ಅಥವಾ ಸಮನಾಗಿತ್ತೆ ಎಂದು ಸೂಚಿಸುವ ಬೂಲಿಯನ್ ಜೊತೆಗೆ ಸ್ವಯಂ ವರ್ಗಾವಣೆಗೊಂಡ ಆವೃತ್ತಿಯ ಟಪಲ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        /// ಶಿಫ್ಟ್ ಮೌಲ್ಯವು ತುಂಬಾ ದೊಡ್ಡದಾಗಿದ್ದರೆ, ಮೌಲ್ಯವನ್ನು (N-1) ಮರೆಮಾಚಲಾಗುತ್ತದೆ, ಅಲ್ಲಿ N ಎಂಬುದು ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆ, ಮತ್ತು ಈ ಮೌಲ್ಯವನ್ನು ನಂತರ ಶಿಫ್ಟ್ ನಿರ್ವಹಿಸಲು ಬಳಸಲಾಗುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// `rhs` ಬಿಟ್‌ಗಳಿಂದ ಸ್ವಯಂ ಬಲವನ್ನು ಬದಲಾಯಿಸುತ್ತದೆ.
        ///
        /// ಶಿಫ್ಟ್ ಮೌಲ್ಯವು ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆಗಿಂತ ದೊಡ್ಡದಾಗಿದೆಯೆ ಅಥವಾ ಸಮನಾಗಿತ್ತೆ ಎಂದು ಸೂಚಿಸುವ ಬೂಲಿಯನ್ ಜೊತೆಗೆ ಸ್ವಯಂ ವರ್ಗಾವಣೆಗೊಂಡ ಆವೃತ್ತಿಯ ಟಪಲ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        /// ಶಿಫ್ಟ್ ಮೌಲ್ಯವು ತುಂಬಾ ದೊಡ್ಡದಾಗಿದ್ದರೆ, ಮೌಲ್ಯವನ್ನು (N-1) ಮರೆಮಾಚಲಾಗುತ್ತದೆ, ಅಲ್ಲಿ N ಎಂಬುದು ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆ, ಮತ್ತು ಈ ಮೌಲ್ಯವನ್ನು ನಂತರ ಶಿಫ್ಟ್ ನಿರ್ವಹಿಸಲು ಬಳಸಲಾಗುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// `exp` ನ ಶಕ್ತಿಗೆ ಸ್ವಯಂ ಹೆಚ್ಚಿಸುತ್ತದೆ, ವರ್ಗೀಕರಣದ ಮೂಲಕ ಘಾತಾಂಕವನ್ನು ಬಳಸುತ್ತದೆ.
        ///
        /// ಓವರ್‌ಫ್ಲೋ ಸಂಭವಿಸಿದೆಯೇ ಎಂಬುದನ್ನು ಸೂಚಿಸುವ bool ಜೊತೆಗೆ ಘಾತಾಂಕದ ಟಪಲ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, ನಿಜ));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // ಉಕ್ಕಿ ಹರಿಯುವ_ಮುಲ್ ಫಲಿತಾಂಶಗಳನ್ನು ಸಂಗ್ರಹಿಸಲು ಸ್ಥಳವನ್ನು ಸ್ಕ್ರ್ಯಾಚ್ ಮಾಡಿ.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // exp!=0 ರಿಂದ, ಅಂತಿಮವಾಗಿ exp 1 ಆಗಿರಬೇಕು.
            // ಘಾತಕದ ಅಂತಿಮ ಬಿಟ್ ಅನ್ನು ಪ್ರತ್ಯೇಕವಾಗಿ ನಿಭಾಯಿಸಿ, ಏಕೆಂದರೆ ನಂತರ ಬೇಸ್ ಅನ್ನು ವರ್ಗೀಕರಿಸುವುದು ಅನಿವಾರ್ಯವಲ್ಲ ಮತ್ತು ಅನಗತ್ಯ ಉಕ್ಕಿ ಹರಿಯಲು ಕಾರಣವಾಗಬಹುದು.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// `exp` ನ ಶಕ್ತಿಗೆ ಸ್ವಯಂ ಹೆಚ್ಚಿಸುತ್ತದೆ, ವರ್ಗೀಕರಣದ ಮೂಲಕ ಘಾತಾಂಕವನ್ನು ಬಳಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // exp!=0 ರಿಂದ, ಅಂತಿಮವಾಗಿ exp 1 ಆಗಿರಬೇಕು.
            // ಘಾತಕದ ಅಂತಿಮ ಬಿಟ್ ಅನ್ನು ಪ್ರತ್ಯೇಕವಾಗಿ ನಿಭಾಯಿಸಿ, ಏಕೆಂದರೆ ನಂತರ ಬೇಸ್ ಅನ್ನು ವರ್ಗೀಕರಿಸುವುದು ಅನಿವಾರ್ಯವಲ್ಲ ಮತ್ತು ಅನಗತ್ಯ ಉಕ್ಕಿ ಹರಿಯಲು ಕಾರಣವಾಗಬಹುದು.
            //
            //
            acc * base
        }

        /// ಯೂಕ್ಲಿಡಿಯನ್ ವಿಭಾಗವನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
        ///
        /// ಧನಾತ್ಮಕ ಪೂರ್ಣಾಂಕಗಳಿಗೆ, ವಿಭಜನೆಯ ಎಲ್ಲಾ ಸಾಮಾನ್ಯ ವ್ಯಾಖ್ಯಾನಗಳು ಸಮಾನವಾಗಿರುವುದರಿಂದ, ಇದು `self / rhs` ಗೆ ನಿಖರವಾಗಿ ಸಮಾನವಾಗಿರುತ್ತದೆ.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 ಆಗಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// `self (mod rhs)` ನ ಕನಿಷ್ಠ ಉಳಿದವನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
        ///
        /// ಧನಾತ್ಮಕ ಪೂರ್ಣಾಂಕಗಳಿಗೆ, ವಿಭಜನೆಯ ಎಲ್ಲಾ ಸಾಮಾನ್ಯ ವ್ಯಾಖ್ಯಾನಗಳು ಸಮಾನವಾಗಿರುವುದರಿಂದ, ಇದು `self % rhs` ಗೆ ನಿಖರವಾಗಿ ಸಮಾನವಾಗಿರುತ್ತದೆ.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 ಆಗಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// ಕೆಲವು `k` ಗಾಗಿ `self == 2^k` ಇದ್ದರೆ ಮಾತ್ರ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // ಎರಡು ಮುಂದಿನ ಶಕ್ತಿಗಿಂತ ಒಂದನ್ನು ಕಡಿಮೆ ನೀಡುತ್ತದೆ.
        // (8u8 ಗೆ ಎರಡು ಮುಂದಿನ ಶಕ್ತಿ 8u8 ಮತ್ತು 6u8 ಗೆ ಅದು 8u8 ಆಗಿದೆ)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // ಈ ವಿಧಾನವು ಉಕ್ಕಿ ಹರಿಯಲು ಸಾಧ್ಯವಿಲ್ಲ, ಏಕೆಂದರೆ `next_power_of_two` ಓವರ್‌ಫ್ಲೋ ಪ್ರಕರಣಗಳಲ್ಲಿ ಅದು ಪ್ರಕಾರದ ಗರಿಷ್ಠ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ ಮತ್ತು 0 ಕ್ಕೆ 0 ಅನ್ನು ಹಿಂತಿರುಗಿಸಬಹುದು.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // ಸುರಕ್ಷತೆ: ಏಕೆಂದರೆ `p > 0`, ಇದು ಸಂಪೂರ್ಣವಾಗಿ ಪ್ರಮುಖ ಸೊನ್ನೆಗಳನ್ನು ಒಳಗೊಂಡಿರುವುದಿಲ್ಲ.
            // ಇದರರ್ಥ ಶಿಫ್ಟ್ ಯಾವಾಗಲೂ ಪರಿಮಿತಿಯಲ್ಲಿರುತ್ತದೆ, ಮತ್ತು ಕೆಲವು ಪ್ರೊಸೆಸರ್‌ಗಳು (ಇಂಟೆಲ್ ಪ್ರಿ-ಹ್ಯಾಸ್‌ವೆಲ್‌ನಂತಹವು) ವಾದವು ಶೂನ್ಯವಲ್ಲದಿದ್ದಾಗ ಹೆಚ್ಚು ಪರಿಣಾಮಕಾರಿ ಸಿಟಿಎಲ್ಜ್ ಆಂತರಿಕತೆಯನ್ನು ಹೊಂದಿರುತ್ತದೆ.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// `self` ಗಿಂತ ದೊಡ್ಡದಾದ ಅಥವಾ ಸಮನಾದ ಎರಡು ಸಣ್ಣ ಶಕ್ತಿಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        /// ರಿಟರ್ನ್ ಮೌಲ್ಯವು ಉಕ್ಕಿ ಹರಿಯುವಾಗ (ಅಂದರೆ, ಟೈಪ್ `uN` ಗಾಗಿ `self > (1 << (N-1))`), ಇದು ಡೀಬಗ್ ಮೋಡ್‌ನಲ್ಲಿ panics ಮತ್ತು ರಿಟರ್ನ್ ಮೌಲ್ಯವನ್ನು ಬಿಡುಗಡೆ ಮೋಡ್‌ನಲ್ಲಿ 0 ಗೆ ಸುತ್ತಿಡಲಾಗುತ್ತದೆ (ವಿಧಾನವು 0 ಅನ್ನು ಹಿಂದಿರುಗಿಸುವ ಏಕೈಕ ಪರಿಸ್ಥಿತಿ).
        ///
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// `n` ಗಿಂತ ದೊಡ್ಡದಾದ ಅಥವಾ ಸಮನಾದ ಎರಡು ಸಣ್ಣ ಶಕ್ತಿಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        /// ಎರಡರ ಮುಂದಿನ ಶಕ್ತಿಯು ಪ್ರಕಾರದ ಗರಿಷ್ಠ ಮೌಲ್ಯಕ್ಕಿಂತ ಹೆಚ್ಚಿದ್ದರೆ, `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ ಎರಡರ ಶಕ್ತಿಯನ್ನು `Some` ನಲ್ಲಿ ಸುತ್ತಿಡಲಾಗುತ್ತದೆ.
        ///
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// `n` ಗಿಂತ ದೊಡ್ಡದಾದ ಅಥವಾ ಸಮನಾದ ಎರಡು ಸಣ್ಣ ಶಕ್ತಿಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        /// ಎರಡರ ಮುಂದಿನ ಶಕ್ತಿಯು ಪ್ರಕಾರದ ಗರಿಷ್ಠ ಮೌಲ್ಯಕ್ಕಿಂತ ಹೆಚ್ಚಿದ್ದರೆ, ರಿಟರ್ನ್ ಮೌಲ್ಯವನ್ನು `0` ಗೆ ಸುತ್ತಿಡಲಾಗುತ್ತದೆ.
        ///
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// ಬಿಗ್-ಎಂಡಿಯನ್ (network) ಬೈಟ್ ಕ್ರಮದಲ್ಲಿ ಬೈಟ್ ಅರೇ ಆಗಿ ಈ ಪೂರ್ಣಾಂಕದ ಮೆಮೊರಿ ಪ್ರಾತಿನಿಧ್ಯವನ್ನು ಹಿಂತಿರುಗಿ.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// ಕಡಿಮೆ-ಎಂಡಿಯನ್ ಬೈಟ್ ಕ್ರಮದಲ್ಲಿ ಬೈಟ್ ಅರೇ ಆಗಿ ಈ ಪೂರ್ಣಾಂಕದ ಮೆಮೊರಿ ಪ್ರಾತಿನಿಧ್ಯವನ್ನು ಹಿಂತಿರುಗಿ.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// ಸ್ಥಳೀಯ ಪೂರ್ಣ ಬೈಟ್ ಕ್ರಮದಲ್ಲಿ ಬೈಟ್ ಅರೇ ಆಗಿ ಈ ಪೂರ್ಣಾಂಕದ ಮೆಮೊರಿ ಪ್ರಾತಿನಿಧ್ಯವನ್ನು ಹಿಂತಿರುಗಿ.
        ///
        /// ಟಾರ್ಗೆಟ್ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್‌ನ ಸ್ಥಳೀಯ ಎಂಡಿಯನೆಸ್ ಅನ್ನು ಬಳಸಿದಂತೆ, ಪೋರ್ಟಬಲ್ ಕೋಡ್ ಸೂಕ್ತವಾದಂತೆ [`to_be_bytes`] ಅಥವಾ [`to_le_bytes`] ಅನ್ನು ಬಳಸಬೇಕು.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     ಬೈಟ್‌ಗಳು, cfg ಆಗಿದ್ದರೆ! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } else {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // ಸುರಕ್ಷತೆ: ಪೂರ್ಣಾಂಕವು ಸರಳ ಹಳೆಯ ಡೇಟಾಟೈಪ್‌ಗಳಾಗಿರುವುದರಿಂದ ನಾವು ಯಾವಾಗಲೂ ಮಾಡಬಹುದು
        // ಅವುಗಳನ್ನು ಬೈಟ್‌ಗಳ ಸರಣಿಗಳಿಗೆ ಪರಿವರ್ತಿಸಿ
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // ಸುರಕ್ಷತೆ: ಪೂರ್ಣಾಂಕಗಳು ಸರಳ ಹಳೆಯ ಡೇಟಾಟೈಪ್‌ಗಳಾಗಿವೆ ಆದ್ದರಿಂದ ನಾವು ಅವುಗಳನ್ನು ಯಾವಾಗಲೂ ಪರಿವರ್ತಿಸಬಹುದು
            // ಬೈಟ್‌ಗಳ ಸರಣಿಗಳು
            unsafe { mem::transmute(self) }
        }

        /// ಸ್ಥಳೀಯ ಪೂರ್ಣ ಬೈಟ್ ಕ್ರಮದಲ್ಲಿ ಬೈಟ್ ಅರೇ ಆಗಿ ಈ ಪೂರ್ಣಾಂಕದ ಮೆಮೊರಿ ಪ್ರಾತಿನಿಧ್ಯವನ್ನು ಹಿಂತಿರುಗಿ.
        ///
        ///
        /// [`to_ne_bytes`] ಸಾಧ್ಯವಾದಾಗಲೆಲ್ಲಾ ಇದನ್ನು ಆದ್ಯತೆ ನೀಡಬೇಕು.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// ಬೈಟ್‌ಗಳು= num.as_ne_bytes() ಅನ್ನು ಬಿಡಿ;
        /// assert_eq!(
        ///     ಬೈಟ್‌ಗಳು, cfg ಆಗಿದ್ದರೆ! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } else {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // ಸುರಕ್ಷತೆ: ಪೂರ್ಣಾಂಕಗಳು ಸರಳ ಹಳೆಯ ಡೇಟಾಟೈಪ್‌ಗಳಾಗಿವೆ ಆದ್ದರಿಂದ ನಾವು ಅವುಗಳನ್ನು ಯಾವಾಗಲೂ ಪರಿವರ್ತಿಸಬಹುದು
            // ಬೈಟ್‌ಗಳ ಸರಣಿಗಳು
            unsafe { &*(self as *const Self as *const _) }
        }

        /// ದೊಡ್ಡ ಎಂಡಿಯನ್‌ನಲ್ಲಿ ಬೈಟ್ ಅರೇ ಆಗಿ ಅದರ ಪ್ರಾತಿನಿಧ್ಯದಿಂದ ಸ್ಥಳೀಯ ಎಂಡಿಯನ್ ಪೂರ್ಣಾಂಕ ಮೌಲ್ಯವನ್ನು ರಚಿಸಿ.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto ಬಳಸಿ;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ಇನ್ಪುಟ್=ಉಳಿದ;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// ಸ್ವಲ್ಪ ಎಂಡಿಯನ್‌ನಲ್ಲಿ ಬೈಟ್ ಅರೇ ಆಗಿ ಅದರ ಪ್ರಾತಿನಿಧ್ಯದಿಂದ ಸ್ಥಳೀಯ ಎಂಡಿಯನ್ ಪೂರ್ಣಾಂಕ ಮೌಲ್ಯವನ್ನು ರಚಿಸಿ.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto ಬಳಸಿ;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ಇನ್ಪುಟ್=ಉಳಿದ;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// ಸ್ಥಳೀಯ ಎಂಡಿಯಾನ್‌ನಲ್ಲಿ ಬೈಟ್ ಅರೇ ಆಗಿ ಅದರ ಮೆಮೊರಿ ಪ್ರಾತಿನಿಧ್ಯದಿಂದ ಸ್ಥಳೀಯ ಎಂಡಿಯನ್ ಪೂರ್ಣಾಂಕ ಮೌಲ್ಯವನ್ನು ರಚಿಸಿ.
        ///
        /// ಟಾರ್ಗೆಟ್ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್‌ನ ಸ್ಥಳೀಯ ಎಂಡಿಯೆನೆಸ್ ಅನ್ನು ಬಳಸಿದಂತೆ, ಪೋರ್ಟಬಲ್ ಕೋಡ್ ಬದಲಾಗಿ [`from_be_bytes`] ಅಥವಾ [`from_le_bytes`] ಅನ್ನು ಬಳಸಲು ಬಯಸುತ್ತದೆ.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } else {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto ಬಳಸಿ;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ಇನ್ಪುಟ್=ಉಳಿದ;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // ಸುರಕ್ಷತೆ: ಪೂರ್ಣಾಂಕವು ಸರಳ ಹಳೆಯ ಡೇಟಾಟೈಪ್‌ಗಳಾಗಿರುವುದರಿಂದ ನಾವು ಯಾವಾಗಲೂ ಮಾಡಬಹುದು
        // ಅವರಿಗೆ ಪರಿವರ್ತಿಸಿ
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // ಸುರಕ್ಷತೆ: ಪೂರ್ಣಾಂಕಗಳು ಸರಳ ಹಳೆಯ ಡೇಟಾಟೈಪ್‌ಗಳಾಗಿವೆ, ಆದ್ದರಿಂದ ನಾವು ಅವರಿಗೆ ಯಾವಾಗಲೂ ಪರಿವರ್ತಿಸಬಹುದು
            unsafe { mem::transmute(bytes) }
        }

        /// ಹೊಸ ಕೋಡ್ ಬಳಸಲು ಆದ್ಯತೆ ನೀಡಬೇಕು
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// ಈ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರದಿಂದ ಪ್ರತಿನಿಧಿಸಬಹುದಾದ ಚಿಕ್ಕ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// ಹೊಸ ಕೋಡ್ ಬಳಸಲು ಆದ್ಯತೆ ನೀಡಬೇಕು
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// ಈ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರದಿಂದ ಪ್ರತಿನಿಧಿಸಬಹುದಾದ ದೊಡ್ಡ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}