macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// ಈ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರದಿಂದ ಪ್ರತಿನಿಧಿಸಬಹುದಾದ ಚಿಕ್ಕ ಮೌಲ್ಯ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// ಈ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರದಿಂದ ಪ್ರತಿನಿಧಿಸಬಹುದಾದ ದೊಡ್ಡ ಮೌಲ್ಯ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// ಬಿಟ್‌ಗಳಲ್ಲಿ ಈ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರದ ಗಾತ್ರ.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// ನಿರ್ದಿಷ್ಟ ತಳದಲ್ಲಿ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಪೂರ್ಣಾಂಕಕ್ಕೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
        ///
        /// ಸ್ಟ್ರಿಂಗ್ ಐಚ್ al ಿಕ `+` ಅಥವಾ `-` ಚಿಹ್ನೆ ಮತ್ತು ನಂತರ ಅಂಕೆಗಳು ಎಂದು ನಿರೀಕ್ಷಿಸಲಾಗಿದೆ.
        /// ಮುನ್ನಡೆ ಮತ್ತು ಹಿಂದುಳಿದಿರುವ ಜಾಗವು ದೋಷವನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
        /// `radix` ಗೆ ಅನುಗುಣವಾಗಿ ಅಂಕೆಗಳು ಈ ಅಕ್ಷರಗಳ ಉಪವಿಭಾಗವಾಗಿದೆ:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// `radix` 2 ರಿಂದ 36 ರ ವ್ಯಾಪ್ತಿಯಲ್ಲಿಲ್ಲದಿದ್ದರೆ ಈ ಕಾರ್ಯ panics.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// `self` ನ ಬೈನರಿ ಪ್ರಾತಿನಿಧ್ಯದಲ್ಲಿರುವವರ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// `self` ನ ಬೈನರಿ ಪ್ರಾತಿನಿಧ್ಯದಲ್ಲಿನ ಸೊನ್ನೆಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// `self` ನ ಬೈನರಿ ಪ್ರಾತಿನಿಧ್ಯದಲ್ಲಿ ಪ್ರಮುಖ ಸೊನ್ನೆಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// `self` ನ ಬೈನರಿ ಪ್ರಾತಿನಿಧ್ಯದಲ್ಲಿ ಹಿಂದುಳಿದ ಸೊನ್ನೆಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// `self` ನ ಬೈನರಿ ಪ್ರಾತಿನಿಧ್ಯದಲ್ಲಿ ಪ್ರಮುಖವಾದವರ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// `self` ನ ಬೈನರಿ ಪ್ರಾತಿನಿಧ್ಯದಲ್ಲಿ ಹಿಂದುಳಿದವರ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// ಮೊಟಕುಗೊಳಿಸಿದ ಬಿಟ್‌ಗಳನ್ನು ಫಲಿತಾಂಶದ ಪೂರ್ಣಾಂಕದ ಕೊನೆಯಲ್ಲಿ ಸುತ್ತಿ, ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಮೊತ್ತವಾದ `n` ನಿಂದ ಬಿಟ್‌ಗಳನ್ನು ಎಡಕ್ಕೆ ಬದಲಾಯಿಸುತ್ತದೆ.
        ///
        ///
        /// ಇದು `<<` ಶಿಫ್ಟಿಂಗ್ ಆಪರೇಟರ್ನ ಅದೇ ಕಾರ್ಯಾಚರಣೆಯಲ್ಲ ಎಂಬುದನ್ನು ದಯವಿಟ್ಟು ಗಮನಿಸಿ!
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// ಮೊಟಕುಗೊಳಿಸಿದ ಬಿಟ್‌ಗಳನ್ನು ಫಲಿತಾಂಶದ ಪೂರ್ಣಾಂಕದ ಆರಂಭಕ್ಕೆ ಸುತ್ತಿ, ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಮೊತ್ತವಾದ `n` ಮೂಲಕ ಬಿಟ್‌ಗಳನ್ನು ಬಲಕ್ಕೆ ಬದಲಾಯಿಸುತ್ತದೆ.
        ///
        ///
        /// ಇದು `>>` ಶಿಫ್ಟಿಂಗ್ ಆಪರೇಟರ್ನ ಅದೇ ಕಾರ್ಯಾಚರಣೆಯಲ್ಲ ಎಂಬುದನ್ನು ದಯವಿಟ್ಟು ಗಮನಿಸಿ!
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// ಪೂರ್ಣಾಂಕದ ಬೈಟ್ ಕ್ರಮವನ್ನು ಹಿಮ್ಮುಖಗೊಳಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// m= n.swap_bytes() ಅನ್ನು ಬಿಡಿ;
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// ಪೂರ್ಣಾಂಕದಲ್ಲಿನ ಬಿಟ್‌ಗಳ ಕ್ರಮವನ್ನು ಹಿಮ್ಮುಖಗೊಳಿಸುತ್ತದೆ.
        /// ಕಡಿಮೆ ಮಹತ್ವದ ಬಿಟ್ ಅತ್ಯಂತ ಮಹತ್ವದ ಬಿಟ್ ಆಗುತ್ತದೆ, ಎರಡನೆಯ ಕನಿಷ್ಠ-ಮಹತ್ವದ ಬಿಟ್ ಎರಡನೇ ಅತ್ಯಂತ ಮಹತ್ವದ ಬಿಟ್ ಆಗುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// m= n.reverse_bits() ಅನ್ನು ಬಿಡಿ;
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// ದೊಡ್ಡ ಪೂರ್ಣಾಂಕದಿಂದ ಗುರಿಯ ಅಂತ್ಯಕ್ಕೆ ಪೂರ್ಣಾಂಕವನ್ನು ಪರಿವರ್ತಿಸುತ್ತದೆ.
        ///
        /// ದೊಡ್ಡ ಎಂಡಿಯನ್‌ನಲ್ಲಿ ಇದು ನೋ-ಆಪ್ ಆಗಿದೆ.ಸ್ವಲ್ಪ ಎಂಡಿಯನ್‌ನಲ್ಲಿ ಬೈಟ್‌ಗಳನ್ನು ಬದಲಾಯಿಸಲಾಗುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } else {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// ಪೂರ್ಣಾಂಕವನ್ನು ಸ್ವಲ್ಪ ಎಂಡಿಯನ್‌ನಿಂದ ಗುರಿಯ ಅಂತ್ಯಕ್ಕೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
        ///
        /// ಸ್ವಲ್ಪ ಎಂಡಿಯನ್‌ನಲ್ಲಿ ಇದು ನೋ-ಆಪ್ ಆಗಿದೆ.ದೊಡ್ಡ ಎಂಡಿಯನ್‌ನಲ್ಲಿ ಬೈಟ್‌ಗಳನ್ನು ಬದಲಾಯಿಸಲಾಗುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } else {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// `self` ಅನ್ನು ಗುರಿಯ ಅಂತ್ಯದಿಂದ ದೊಡ್ಡ ಎಂಡಿಯನ್‌ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
        ///
        /// ದೊಡ್ಡ ಎಂಡಿಯನ್‌ನಲ್ಲಿ ಇದು ನೋ-ಆಪ್ ಆಗಿದೆ.ಸ್ವಲ್ಪ ಎಂಡಿಯನ್‌ನಲ್ಲಿ ಬೈಟ್‌ಗಳನ್ನು ಬದಲಾಯಿಸಲಾಗುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } else { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // ಅಥವಾ ಇರಬಾರದು?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// `self` ಅನ್ನು ಗುರಿಯ ಅಂತ್ಯದಿಂದ ಸ್ವಲ್ಪ ಎಂಡಿಯನ್‌ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
        ///
        /// ಸ್ವಲ್ಪ ಎಂಡಿಯನ್‌ನಲ್ಲಿ ಇದು ನೋ-ಆಪ್ ಆಗಿದೆ.ದೊಡ್ಡ ಎಂಡಿಯನ್‌ನಲ್ಲಿ ಬೈಟ್‌ಗಳನ್ನು ಬದಲಾಯಿಸಲಾಗುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } else { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// ಪೂರ್ಣಾಂಕ ಸೇರ್ಪಡೆ ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
        /// `self + rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಓವರ್‌ಫ್ಲೋ ಸಂಭವಿಸಿದಲ್ಲಿ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ಪರಿಶೀಲಿಸದ ಪೂರ್ಣಾಂಕ ಸೇರ್ಪಡೆ.`self + rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ ಎಂದು uming ಹಿಸಿ.
        /// ಇದು ಯಾವಾಗ ವಿವರಿಸಲಾಗದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `unchecked_add` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// ಪೂರ್ಣಾಂಕ ವ್ಯವಕಲನವನ್ನು ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
        /// `self - rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಓವರ್‌ಫ್ಲೋ ಸಂಭವಿಸಿದಲ್ಲಿ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ಪರಿಶೀಲಿಸದ ಪೂರ್ಣಾಂಕ ವ್ಯವಕಲನ.`self - rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ ಎಂದು uming ಹಿಸಿ.
        /// ಇದು ಯಾವಾಗ ವಿವರಿಸಲಾಗದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `unchecked_sub` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// ಪೂರ್ಣಾಂಕ ಗುಣಾಕಾರವನ್ನು ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
        /// `self * rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಓವರ್‌ಫ್ಲೋ ಸಂಭವಿಸಿದಲ್ಲಿ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ಪರಿಶೀಲಿಸದ ಪೂರ್ಣಾಂಕ ಗುಣಾಕಾರ.`self * rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ ಎಂದು uming ಹಿಸಿ.
        /// ಇದು ಯಾವಾಗ ವಿವರಿಸಲಾಗದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `unchecked_mul` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// ಪೂರ್ಣಾಂಕ ವಿಭಾಗವನ್ನು ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
        /// `self / rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, `rhs == 0` ಆಗಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ ಅಥವಾ ವಿಭಾಗವು ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // ಸುರಕ್ಷತೆ: ಡಿವ್ ಅನ್ನು ಶೂನ್ಯದಿಂದ ಮತ್ತು INT_MIN ನಿಂದ ಮೇಲೆ ಪರಿಶೀಲಿಸಲಾಗಿದೆ
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// ಪರಿಶೀಲಿಸಿದ ಯೂಕ್ಲಿಡಿಯನ್ ವಿಭಾಗ.
        /// `self.div_euclid(rhs)` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, `rhs == 0` ಆಗಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ ಅಥವಾ ವಿಭಾಗವು ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// ಪರಿಶೀಲಿಸಿದ ಪೂರ್ಣಾಂಕ ಉಳಿದಿದೆ.
        /// `self % rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, `rhs == 0` ಆಗಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ ಅಥವಾ ವಿಭಾಗವು ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆ.
        ///
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // ಸುರಕ್ಷತೆ: ಡಿವ್ ಅನ್ನು ಶೂನ್ಯದಿಂದ ಮತ್ತು INT_MIN ನಿಂದ ಮೇಲೆ ಪರಿಶೀಲಿಸಲಾಗಿದೆ
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// ಉಳಿದ ಯೂಕ್ಲಿಡಿಯನ್ ಅನ್ನು ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
        /// `self.rem_euclid(rhs)` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, `rhs == 0` ಆಗಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ ಅಥವಾ ವಿಭಾಗವು ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// ನಿರಾಕರಣೆ ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
        /// `-self` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, `self == MIN` ಆಗಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ಪರಿಶೀಲಿಸಿದ ಶಿಫ್ಟ್ ಎಡಕ್ಕೆ.
        /// `self << rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, `rhs` `self` ನಲ್ಲಿನ ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆಗಿಂತ ದೊಡ್ಡದಾಗಿದ್ದರೆ ಅಥವಾ ಸಮನಾಗಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ಶಿಫ್ಟ್ ಬಲವನ್ನು ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
        /// `self >> rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, `rhs` `self` ನಲ್ಲಿನ ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆಗಿಂತ ದೊಡ್ಡದಾಗಿದ್ದರೆ ಅಥವಾ ಸಮನಾಗಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ಸಂಪೂರ್ಣ ಮೌಲ್ಯವನ್ನು ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
        /// `self.abs()` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, `self == MIN` ಆಗಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
        ///
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// ಪರಿಶೀಲಿಸಿದ ಘಾತಾಂಕ.
        /// `self.pow(exp)` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಓವರ್‌ಫ್ಲೋ ಸಂಭವಿಸಿದಲ್ಲಿ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // exp!=0 ರಿಂದ, ಅಂತಿಮವಾಗಿ exp 1 ಆಗಿರಬೇಕು.
            // ಘಾತಕದ ಅಂತಿಮ ಬಿಟ್ ಅನ್ನು ಪ್ರತ್ಯೇಕವಾಗಿ ನಿಭಾಯಿಸಿ, ಏಕೆಂದರೆ ನಂತರ ಬೇಸ್ ಅನ್ನು ವರ್ಗೀಕರಿಸುವುದು ಅನಿವಾರ್ಯವಲ್ಲ ಮತ್ತು ಅನಗತ್ಯ ಉಕ್ಕಿ ಹರಿಯಲು ಕಾರಣವಾಗಬಹುದು.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// ಪೂರ್ಣಾಂಕ ಸೇರ್ಪಡೆ.
        /// `self + rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ತುಂಬಿ ಹರಿಯುವ ಬದಲು ಸಂಖ್ಯಾ ಗಡಿಗಳಲ್ಲಿ ಸ್ಯಾಚುರೇಟಿಂಗ್ ಮಾಡುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// ಸ್ಯಾಚುರೇಟಿಂಗ್ ಪೂರ್ಣಾಂಕ ವ್ಯವಕಲನ.
        /// `self - rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ತುಂಬಿ ಹರಿಯುವ ಬದಲು ಸಂಖ್ಯಾ ಗಡಿಗಳಲ್ಲಿ ಸ್ಯಾಚುರೇಟಿಂಗ್ ಮಾಡುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// ಪೂರ್ಣಾಂಕ ನಿರಾಕರಣೆಯನ್ನು ಸ್ಯಾಚುರೇಟಿಂಗ್.
        /// `-self` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಉಕ್ಕಿ ಹರಿಯುವ ಬದಲು `self == MIN` ಆಗಿದ್ದರೆ `MAX` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// ಸಂಪೂರ್ಣ ಮೌಲ್ಯವನ್ನು ಸ್ಯಾಚುರೇಟಿಂಗ್.
        /// `self.abs()` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಉಕ್ಕಿ ಹರಿಯುವ ಬದಲು `self == MIN` ಆಗಿದ್ದರೆ `MAX` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// ಪೂರ್ಣಾಂಕ ಗುಣಾಕಾರ.
        /// `self * rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ತುಂಬಿ ಹರಿಯುವ ಬದಲು ಸಂಖ್ಯಾ ಗಡಿಗಳಲ್ಲಿ ಸ್ಯಾಚುರೇಟಿಂಗ್ ಮಾಡುತ್ತದೆ.
        ///
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// ಪೂರ್ಣಾಂಕ ಘಾತಾಂಕವನ್ನು ಸ್ಯಾಚುರೇಟಿಂಗ್.
        /// `self.pow(exp)` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ತುಂಬಿ ಹರಿಯುವ ಬದಲು ಸಂಖ್ಯಾ ಗಡಿಗಳಲ್ಲಿ ಸ್ಯಾಚುರೇಟಿಂಗ್ ಮಾಡುತ್ತದೆ.
        ///
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// (modular) ಸೇರ್ಪಡೆ ಸುತ್ತಿ.
        /// `self + rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಪ್ರಕಾರದ ಗಡಿಯಲ್ಲಿ ಸುತ್ತಿಕೊಳ್ಳುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// (modular) ವ್ಯವಕಲನವನ್ನು ಸುತ್ತುವುದು.
        /// `self - rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಪ್ರಕಾರದ ಗಡಿಯಲ್ಲಿ ಸುತ್ತಿಕೊಳ್ಳುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// (modular) ಗುಣಾಕಾರವನ್ನು ಸುತ್ತುವುದು.
        /// `self * rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಪ್ರಕಾರದ ಗಡಿಯಲ್ಲಿ ಸುತ್ತಿಕೊಳ್ಳುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// (modular) ವಿಭಾಗವನ್ನು ಸುತ್ತುವುದು.`self / rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಪ್ರಕಾರದ ಗಡಿಯಲ್ಲಿ ಸುತ್ತಿಕೊಳ್ಳುತ್ತದೆ.
        ///
        /// ಸಹಿ ಮಾಡಿದ ಪ್ರಕಾರದ ಮೇಲೆ `MIN / -1` ಅನ್ನು ಭಾಗಿಸಿದಾಗ ಅಂತಹ ಸುತ್ತುವಿಕೆ ಸಂಭವಿಸಬಹುದು (ಇಲ್ಲಿ `MIN` ಎಂಬುದು ಪ್ರಕಾರದ ಕನಿಷ್ಠ ಮೌಲ್ಯವಾಗಿದೆ);ಇದು `-MIN` ಗೆ ಸಮನಾಗಿರುತ್ತದೆ, ಇದು ಧನಾತ್ಮಕ ಮೌಲ್ಯವು ಪ್ರಕಾರದಲ್ಲಿ ಪ್ರತಿನಿಧಿಸಲು ತುಂಬಾ ದೊಡ್ಡದಾಗಿದೆ.
        /// ಅಂತಹ ಸಂದರ್ಭದಲ್ಲಿ, ಈ ಕಾರ್ಯವು `MIN` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Panics
        ///
        /// `rhs` 0 ಆಗಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// ಯೂಕ್ಲಿಡಿಯನ್ ವಿಭಾಗವನ್ನು ಸುತ್ತುವುದು.
        /// `self.div_euclid(rhs)` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಪ್ರಕಾರದ ಗಡಿಯಲ್ಲಿ ಸುತ್ತಿಕೊಳ್ಳುತ್ತದೆ.
        ///
        /// ಸುತ್ತುವ ಪ್ರಕಾರವು `MIN / -1` ನಲ್ಲಿ ಸಹಿ ಮಾಡಿದ ಪ್ರಕಾರದಲ್ಲಿ ಮಾತ್ರ ಸಂಭವಿಸುತ್ತದೆ (ಇಲ್ಲಿ `MIN` ಎಂಬುದು ಪ್ರಕಾರದ ಕನಿಷ್ಠ ಮೌಲ್ಯವಾಗಿದೆ).
        /// ಇದು `-MIN` ಗೆ ಸಮನಾಗಿರುತ್ತದೆ, ಇದು ಧನಾತ್ಮಕ ಮೌಲ್ಯವು ಪ್ರಕಾರದಲ್ಲಿ ಪ್ರತಿನಿಧಿಸಲು ತುಂಬಾ ದೊಡ್ಡದಾಗಿದೆ.
        /// ಈ ಸಂದರ್ಭದಲ್ಲಿ, ಈ ವಿಧಾನವು `MIN` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Panics
        ///
        /// `rhs` 0 ಆಗಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// ಉಳಿದ (modular) ಅನ್ನು ಸುತ್ತುತ್ತದೆ.`self % rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಪ್ರಕಾರದ ಗಡಿಯಲ್ಲಿ ಸುತ್ತಿಕೊಳ್ಳುತ್ತದೆ.
        ///
        /// ಅಂತಹ ಸುತ್ತು-ಸುತ್ತಲೂ ಗಣಿತದ ಪ್ರಕಾರ ಎಂದಿಗೂ ಸಂಭವಿಸುವುದಿಲ್ಲ;ಅನುಷ್ಠಾನ ಕಲಾಕೃತಿಗಳು `MIN / -1` ಗೆ ಸಹಿ ಮಾಡಿದ ಪ್ರಕಾರದಲ್ಲಿ `x % y` ಅನ್ನು ಅಮಾನ್ಯಗೊಳಿಸುತ್ತದೆ (ಇಲ್ಲಿ `MIN` the ಣಾತ್ಮಕ ಕನಿಷ್ಠ ಮೌಲ್ಯವಾಗಿದೆ).
        ///
        /// ಅಂತಹ ಸಂದರ್ಭದಲ್ಲಿ, ಈ ಕಾರ್ಯವು `0` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Panics
        ///
        /// `rhs` 0 ಆಗಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// ಉಳಿದ ಯೂಕ್ಲಿಡಿಯನ್ ಸುತ್ತಿ.`self.rem_euclid(rhs)` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಪ್ರಕಾರದ ಗಡಿಯಲ್ಲಿ ಸುತ್ತಿಕೊಳ್ಳುತ್ತದೆ.
        ///
        /// ಸುತ್ತುವ ಪ್ರಕಾರವು `MIN % -1` ನಲ್ಲಿ ಸಹಿ ಮಾಡಿದ ಪ್ರಕಾರದಲ್ಲಿ ಮಾತ್ರ ಸಂಭವಿಸುತ್ತದೆ (ಇಲ್ಲಿ `MIN` ಎಂಬುದು ಪ್ರಕಾರದ ಕನಿಷ್ಠ ಮೌಲ್ಯವಾಗಿದೆ).
        /// ಈ ಸಂದರ್ಭದಲ್ಲಿ, ಈ ವಿಧಾನವು 0 ಅನ್ನು ನೀಡುತ್ತದೆ.
        ///
        /// # Panics
        ///
        /// `rhs` 0 ಆಗಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// (modular) ನಿರಾಕರಣೆಯನ್ನು ಸುತ್ತುವುದು.`-self` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಪ್ರಕಾರದ ಗಡಿಯಲ್ಲಿ ಸುತ್ತಿಕೊಳ್ಳುತ್ತದೆ.
        ///
        /// ಸಹಿ ಮಾಡಿದ ಪ್ರಕಾರದ ಮೇಲೆ `MIN` ಅನ್ನು ನಿರಾಕರಿಸಿದಾಗ ಅಂತಹ ಸುತ್ತುವಿಕೆಯು ಸಂಭವಿಸುವ ಏಕೈಕ ಸಂದರ್ಭವಾಗಿದೆ (ಇಲ್ಲಿ `MIN` ಎಂಬುದು ಪ್ರಕಾರದ ಕನಿಷ್ಠ ಮೌಲ್ಯವಾಗಿದೆ);ಇದು ಸಕಾರಾತ್ಮಕ ಮೌಲ್ಯವಾಗಿದ್ದು ಅದು ಪ್ರಕಾರವನ್ನು ಪ್ರತಿನಿಧಿಸಲು ತುಂಬಾ ದೊಡ್ಡದಾಗಿದೆ.
        /// ಅಂತಹ ಸಂದರ್ಭದಲ್ಲಿ, ಈ ಕಾರ್ಯವು `MIN` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-ಮುಕ್ತ ಬಿಟ್‌ವೈಸ್ ಶಿಫ್ಟ್-ಎಡ;`self << mask(rhs)` ಅನ್ನು ನೀಡುತ್ತದೆ, ಅಲ್ಲಿ `mask` ಯಾವುದೇ ಉನ್ನತ-ಕ್ರಮಾಂಕದ `rhs` ಅನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ, ಅದು ಶಿಫ್ಟ್ ಪ್ರಕಾರದ ಬಿಟ್‌ವಿಡ್ತ್ ಅನ್ನು ಮೀರುತ್ತದೆ.
        ///
        /// ಇದು ತಿರುಗುವ-ಎಡಕ್ಕೆ ಸಮನಾಗಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ;ಸುತ್ತುವ ಶಿಫ್ಟ್-ಎಡದ RHS ಅನ್ನು LHS ನಿಂದ ಹೊರಹಾಕಿದ ಬಿಟ್‌ಗಳನ್ನು ಇನ್ನೊಂದು ತುದಿಗೆ ಹಿಂದಿರುಗಿಸುವ ಬದಲು ಪ್ರಕಾರದ ವ್ಯಾಪ್ತಿಗೆ ಸೀಮಿತಗೊಳಿಸಲಾಗಿದೆ.
        ///
        /// ಪ್ರಾಚೀನ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳು ಎಲ್ಲಾ [`rotate_left`](Self::rotate_left) ಕಾರ್ಯವನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತವೆ, ಅದು ನಿಮಗೆ ಬೇಕಾಗಿರಬಹುದು.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // ಸುರಕ್ಷತೆ: ಪ್ರಕಾರದ ಬಿಟ್‌ಸೈಜ್‌ನಿಂದ ಮರೆಮಾಚುವಿಕೆಯು ನಾವು ಸ್ಥಳಾಂತರಗೊಳ್ಳದಂತೆ ನೋಡಿಕೊಳ್ಳುತ್ತದೆ
            // ಮಿತಿ ಮೀರಿದೆ
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-ಮುಕ್ತ ಬಿಟ್‌ವೈಸ್ ಶಿಫ್ಟ್-ಬಲ;`self >> mask(rhs)` ಅನ್ನು ನೀಡುತ್ತದೆ, ಅಲ್ಲಿ `mask` ಯಾವುದೇ ಉನ್ನತ-ಕ್ರಮಾಂಕದ `rhs` ಅನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ, ಅದು ಶಿಫ್ಟ್ ಪ್ರಕಾರದ ಬಿಟ್‌ವಿಡ್ತ್ ಅನ್ನು ಮೀರುತ್ತದೆ.
        ///
        /// ಇದು ತಿರುಗುವ-ಬಲಕ್ಕೆ ಸಮನಾಗಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ;ಸುತ್ತುವ ಶಿಫ್ಟ್-ಬಲದ RHS ಅನ್ನು LHS ನಿಂದ ಸ್ಥಳಾಂತರಿಸಿದ ಬಿಟ್‌ಗಳನ್ನು ಇನ್ನೊಂದು ತುದಿಗೆ ಹಿಂತಿರುಗಿಸುವ ಬದಲು ಪ್ರಕಾರದ ವ್ಯಾಪ್ತಿಗೆ ಸೀಮಿತಗೊಳಿಸಲಾಗಿದೆ.
        ///
        /// ಪ್ರಾಚೀನ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳು ಎಲ್ಲಾ [`rotate_right`](Self::rotate_right) ಕಾರ್ಯವನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತವೆ, ಅದು ನಿಮಗೆ ಬೇಕಾಗಿರಬಹುದು.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // ಸುರಕ್ಷತೆ: ಪ್ರಕಾರದ ಬಿಟ್‌ಸೈಜ್‌ನಿಂದ ಮರೆಮಾಚುವಿಕೆಯು ನಾವು ಸ್ಥಳಾಂತರಗೊಳ್ಳದಂತೆ ನೋಡಿಕೊಳ್ಳುತ್ತದೆ
            // ಮಿತಿ ಮೀರಿದೆ
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// (modular) ಸಂಪೂರ್ಣ ಮೌಲ್ಯವನ್ನು ಸುತ್ತುವುದು.`self.abs()` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಪ್ರಕಾರದ ಗಡಿಯಲ್ಲಿ ಸುತ್ತಿಕೊಳ್ಳುತ್ತದೆ.
        ///
        /// ಒಂದು ರೀತಿಯ negative ಣಾತ್ಮಕ ಕನಿಷ್ಠ ಮೌಲ್ಯದ ಸಂಪೂರ್ಣ ಮೌಲ್ಯವನ್ನು ಒಬ್ಬರು ತೆಗೆದುಕೊಂಡಾಗ ಮಾತ್ರ ಅಂತಹ ಸುತ್ತುವಿಕೆ ಸಂಭವಿಸಬಹುದು;ಇದು ಸಕಾರಾತ್ಮಕ ಮೌಲ್ಯವಾಗಿದ್ದು ಅದು ಪ್ರಕಾರವನ್ನು ಪ್ರತಿನಿಧಿಸಲು ತುಂಬಾ ದೊಡ್ಡದಾಗಿದೆ.
        /// ಅಂತಹ ಸಂದರ್ಭದಲ್ಲಿ, ಈ ಕಾರ್ಯವು `MIN` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// ಯಾವುದೇ ಸುತ್ತುವ ಅಥವಾ ಭಯಪಡದೆ `self` ನ ಸಂಪೂರ್ಣ ಮೌಲ್ಯವನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
        ///
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// (modular) ಘಾತಾಂಕವನ್ನು ಸುತ್ತುವುದು.
        /// `self.pow(exp)` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಪ್ರಕಾರದ ಗಡಿಯಲ್ಲಿ ಸುತ್ತಿಕೊಳ್ಳುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // exp!=0 ರಿಂದ, ಅಂತಿಮವಾಗಿ exp 1 ಆಗಿರಬೇಕು.
            // ಘಾತಕದ ಅಂತಿಮ ಬಿಟ್ ಅನ್ನು ಪ್ರತ್ಯೇಕವಾಗಿ ನಿಭಾಯಿಸಿ, ಏಕೆಂದರೆ ನಂತರ ಬೇಸ್ ಅನ್ನು ವರ್ಗೀಕರಿಸುವುದು ಅನಿವಾರ್ಯವಲ್ಲ ಮತ್ತು ಅನಗತ್ಯ ಉಕ್ಕಿ ಹರಿಯಲು ಕಾರಣವಾಗಬಹುದು.
            //
            //
            acc.wrapping_mul(base)
        }

        /// `self` + `rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ
        ///
        /// ಅಂಕಗಣಿತದ ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆಯೇ ಎಂದು ಸೂಚಿಸುವ ಬೂಲಿಯನ್ ಜೊತೆಗೆ ಸೇರ್ಪಡೆಯ ಒಂದು ಟಪಲ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        /// ಉಕ್ಕಿ ಹರಿಯುವುದಾದರೆ ಸುತ್ತಿದ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self`, `rhs` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ
        ///
        /// ಅಂಕಗಣಿತದ ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆಯೇ ಎಂದು ಸೂಚಿಸುವ ಬೂಲಿಯನ್ ಜೊತೆಗೆ ವ್ಯವಕಲನದ ಟಪಲ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        /// ಉಕ್ಕಿ ಹರಿಯುವುದಾದರೆ ಸುತ್ತಿದ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` ಮತ್ತು `rhs` ನ ಗುಣಾಕಾರವನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
        ///
        /// ಅಂಕಗಣಿತದ ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆಯೇ ಎಂದು ಸೂಚಿಸುವ ಬೂಲಿಯನ್ ಜೊತೆಗೆ ಗುಣಾಕಾರದ ಒಂದು ಟಪಲ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        /// ಉಕ್ಕಿ ಹರಿಯುವುದಾದರೆ ಸುತ್ತಿದ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, ನಿಜ));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` ಅನ್ನು `rhs` ನಿಂದ ಭಾಗಿಸಿದಾಗ ವಿಭಜಕವನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
        ///
        /// ಅಂಕಗಣಿತದ ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆಯೇ ಎಂದು ಸೂಚಿಸುವ ಬೂಲಿಯನ್ ಜೊತೆಗೆ ವಿಭಜಕದ ಟಪಲ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        /// ಉಕ್ಕಿ ಹರಿಯುವುದಾದರೆ ಸ್ವಯಂ ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
        ///
        /// # Panics
        ///
        /// `rhs` 0 ಆಗಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// ಯೂಕ್ಲಿಡಿಯನ್ ವಿಭಾಗ `self.div_euclid(rhs)` ನ ಅಂಶವನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
        ///
        /// ಅಂಕಗಣಿತದ ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆಯೇ ಎಂದು ಸೂಚಿಸುವ ಬೂಲಿಯನ್ ಜೊತೆಗೆ ವಿಭಜಕದ ಟಪಲ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        /// ಉಕ್ಕಿ ಹರಿಯುವುದಾದರೆ `self` ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
        ///
        /// # Panics
        ///
        /// `rhs` 0 ಆಗಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// `self` ಅನ್ನು `rhs` ನಿಂದ ಭಾಗಿಸಿದಾಗ ಉಳಿದವನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
        ///
        /// ಅಂಕಗಣಿತದ ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆಯೇ ಎಂದು ಸೂಚಿಸುವ ಬೂಲಿಯನ್ ಜೊತೆಗೆ ವಿಭಜಿಸಿದ ನಂತರ ಉಳಿದ ಒಂದು ತುಂಡನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        /// ಉಕ್ಕಿ ಹರಿಯುವುದಾದರೆ 0 ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
        ///
        /// # Panics
        ///
        /// `rhs` 0 ಆಗಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// ಉಳಿದಿರುವ ಯೂಕ್ಲಿಡಿಯನ್.`self.rem_euclid(rhs)` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
        ///
        /// ಅಂಕಗಣಿತದ ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆಯೇ ಎಂದು ಸೂಚಿಸುವ ಬೂಲಿಯನ್ ಜೊತೆಗೆ ವಿಭಜಿಸಿದ ನಂತರ ಉಳಿದ ಒಂದು ತುಂಡನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        /// ಉಕ್ಕಿ ಹರಿಯುವುದಾದರೆ 0 ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
        ///
        /// # Panics
        ///
        /// `rhs` 0 ಆಗಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// ಸ್ವಯಂ ಮೌಲ್ಯಗಳು, ಇದು ಕನಿಷ್ಠ ಮೌಲ್ಯಕ್ಕೆ ಸಮನಾಗಿದ್ದರೆ ತುಂಬಿ ಹರಿಯುತ್ತದೆ.
        ///
        /// ಉಕ್ಕಿ ಹರಿಯಿದೆಯೆ ಎಂದು ಸೂಚಿಸುವ ಬೂಲಿಯನ್ ಜೊತೆಗೆ ಸ್ವಯಂ ನಿರಾಕರಿಸಿದ ಆವೃತ್ತಿಯ ಟಪಲ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        /// `self` ಕನಿಷ್ಠ ಮೌಲ್ಯವಾಗಿದ್ದರೆ (ಉದಾ., `i32` ಪ್ರಕಾರದ ಮೌಲ್ಯಗಳಿಗೆ `i32::MIN`), ನಂತರ ಕನಿಷ್ಠ ಮೌಲ್ಯವನ್ನು ಮತ್ತೆ ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ಉಕ್ಕಿ ಹರಿಯುವುದಕ್ಕಾಗಿ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
        ///
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// `rhs` ಬಿಟ್‌ಗಳಿಂದ ಸ್ವಯಂ ಎಡಕ್ಕೆ ಬದಲಾಗುತ್ತದೆ.
        ///
        /// ಶಿಫ್ಟ್ ಮೌಲ್ಯವು ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆಗಿಂತ ದೊಡ್ಡದಾಗಿದೆಯೆ ಅಥವಾ ಸಮನಾಗಿತ್ತೆ ಎಂದು ಸೂಚಿಸುವ ಬೂಲಿಯನ್ ಜೊತೆಗೆ ಸ್ವಯಂ ವರ್ಗಾವಣೆಗೊಂಡ ಆವೃತ್ತಿಯ ಟಪಲ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        /// ಶಿಫ್ಟ್ ಮೌಲ್ಯವು ತುಂಬಾ ದೊಡ್ಡದಾಗಿದ್ದರೆ, ಮೌಲ್ಯವನ್ನು (N-1) ಮರೆಮಾಚಲಾಗುತ್ತದೆ, ಅಲ್ಲಿ N ಎಂಬುದು ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆ, ಮತ್ತು ಈ ಮೌಲ್ಯವನ್ನು ನಂತರ ಶಿಫ್ಟ್ ನಿರ್ವಹಿಸಲು ಬಳಸಲಾಗುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10, ನಿಜ));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// `rhs` ಬಿಟ್‌ಗಳಿಂದ ಸ್ವಯಂ ಬಲವನ್ನು ಬದಲಾಯಿಸುತ್ತದೆ.
        ///
        /// ಶಿಫ್ಟ್ ಮೌಲ್ಯವು ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆಗಿಂತ ದೊಡ್ಡದಾಗಿದೆಯೆ ಅಥವಾ ಸಮನಾಗಿತ್ತೆ ಎಂದು ಸೂಚಿಸುವ ಬೂಲಿಯನ್ ಜೊತೆಗೆ ಸ್ವಯಂ ವರ್ಗಾವಣೆಗೊಂಡ ಆವೃತ್ತಿಯ ಟಪಲ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        /// ಶಿಫ್ಟ್ ಮೌಲ್ಯವು ತುಂಬಾ ದೊಡ್ಡದಾಗಿದ್ದರೆ, ಮೌಲ್ಯವನ್ನು (N-1) ಮರೆಮಾಚಲಾಗುತ್ತದೆ, ಅಲ್ಲಿ N ಎಂಬುದು ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆ, ಮತ್ತು ಈ ಮೌಲ್ಯವನ್ನು ನಂತರ ಶಿಫ್ಟ್ ನಿರ್ವಹಿಸಲು ಬಳಸಲಾಗುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1, ನಿಜ));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// `self` ನ ಸಂಪೂರ್ಣ ಮೌಲ್ಯವನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
        ///
        /// ಓವರ್‌ಫ್ಲೋ ಸಂಭವಿಸಿದೆಯೇ ಎಂದು ಸೂಚಿಸುವ ಬೂಲಿಯನ್ ಜೊತೆಗೆ ಸ್ವಯಂ ಸಂಪೂರ್ಣ ಆವೃತ್ತಿಯ ಟಪಲ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        /// ಸ್ವಯಂ ಕನಿಷ್ಠ ಮೌಲ್ಯವಾಗಿದ್ದರೆ
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// ನಂತರ ಕನಿಷ್ಟ ಮೌಲ್ಯವನ್ನು ಮತ್ತೆ ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ಉಕ್ಕಿ ಹರಿಯುವುದಕ್ಕಾಗಿ ನಿಜವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
        ///
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// `exp` ನ ಶಕ್ತಿಗೆ ಸ್ವಯಂ ಹೆಚ್ಚಿಸುತ್ತದೆ, ವರ್ಗೀಕರಣದ ಮೂಲಕ ಘಾತಾಂಕವನ್ನು ಬಳಸುತ್ತದೆ.
        ///
        /// ಓವರ್‌ಫ್ಲೋ ಸಂಭವಿಸಿದೆಯೇ ಎಂಬುದನ್ನು ಸೂಚಿಸುವ bool ಜೊತೆಗೆ ಘಾತಾಂಕದ ಟಪಲ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, ನಿಜ));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // ಉಕ್ಕಿ ಹರಿಯುವ_ಮುಲ್ ಫಲಿತಾಂಶಗಳನ್ನು ಸಂಗ್ರಹಿಸಲು ಸ್ಥಳವನ್ನು ಸ್ಕ್ರ್ಯಾಚ್ ಮಾಡಿ.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // exp!=0 ರಿಂದ, ಅಂತಿಮವಾಗಿ exp 1 ಆಗಿರಬೇಕು.
            // ಘಾತಕದ ಅಂತಿಮ ಬಿಟ್ ಅನ್ನು ಪ್ರತ್ಯೇಕವಾಗಿ ನಿಭಾಯಿಸಿ, ಏಕೆಂದರೆ ನಂತರ ಬೇಸ್ ಅನ್ನು ವರ್ಗೀಕರಿಸುವುದು ಅನಿವಾರ್ಯವಲ್ಲ ಮತ್ತು ಅನಗತ್ಯ ಉಕ್ಕಿ ಹರಿಯಲು ಕಾರಣವಾಗಬಹುದು.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// `exp` ನ ಶಕ್ತಿಗೆ ಸ್ವಯಂ ಹೆಚ್ಚಿಸುತ್ತದೆ, ವರ್ಗೀಕರಣದ ಮೂಲಕ ಘಾತಾಂಕವನ್ನು ಬಳಸುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // exp!=0 ರಿಂದ, ಅಂತಿಮವಾಗಿ exp 1 ಆಗಿರಬೇಕು.
            // ಘಾತಕದ ಅಂತಿಮ ಬಿಟ್ ಅನ್ನು ಪ್ರತ್ಯೇಕವಾಗಿ ನಿಭಾಯಿಸಿ, ಏಕೆಂದರೆ ನಂತರ ಬೇಸ್ ಅನ್ನು ವರ್ಗೀಕರಿಸುವುದು ಅನಿವಾರ್ಯವಲ್ಲ ಮತ್ತು ಅನಗತ್ಯ ಉಕ್ಕಿ ಹರಿಯಲು ಕಾರಣವಾಗಬಹುದು.
            //
            //
            acc * base
        }

        /// `rhs` ನಿಂದ `self` ನ ಯೂಕ್ಲಿಡಿಯನ್ ವಿಭಾಗದ ಅಂಶವನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
        ///
        /// ಇದು `n`, `0 <= self.rem_euclid(rhs) < rhs` ನೊಂದಿಗೆ `self = n * rhs + self.rem_euclid(rhs)` ನಂತಹ ಪೂರ್ಣಾಂಕ `n` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
        ///
        ///
        /// ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, ಫಲಿತಾಂಶವು `self / rhs` ಅನ್ನು ಪೂರ್ಣಾಂಕ `n` ಗೆ ದುಂಡಾದ `self >= n * rhs` ಆಗಿದೆ.
        /// `self > 0` ಆಗಿದ್ದರೆ, ಇದು ಶೂನ್ಯದ ಕಡೆಗೆ ಸುತ್ತಿಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ (Rust ನಲ್ಲಿ ಡೀಫಾಲ್ಟ್);
        /// `self < 0` ಆಗಿದ್ದರೆ, ಇದು +/-ಅನಂತದ ಕಡೆಗೆ ಸುತ್ತಲು ಸಮಾನವಾಗಿರುತ್ತದೆ.
        ///
        /// # Panics
        ///
        /// `rhs` 0 ಆಗಿದ್ದರೆ ಅಥವಾ ವಿಭಾಗವು ಉಕ್ಕಿ ಹರಿಯುವುದಾದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// ಬಿ=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b), -1);//7>= -4*-1 assert_eq!((-a).div_euclid(b), -2);//-7>=4 *-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// `self (mod rhs)` ನ ಕನಿಷ್ಠ ನಾನ್ ನೆಗೆಟಿವ್ ಉಳಿದವನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
        ///
        /// ಇದನ್ನು ಯೂಕ್ಲಿಡಿಯನ್ ವಿಭಾಗದ ಅಲ್ಗಾರಿದಮ್ ಮಾಡಿದಂತೆ ಮಾಡಲಾಗುತ್ತದೆ-`r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r`, ಮತ್ತು `0 <= r < abs(rhs)` ನೀಡಲಾಗಿದೆ.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 ಆಗಿದ್ದರೆ ಅಥವಾ ವಿಭಾಗವು ಉಕ್ಕಿ ಹರಿಯುವುದಾದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// ಬಿ=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// `self` ನ ಸಂಪೂರ್ಣ ಮೌಲ್ಯವನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
        ///
        /// # ಉಕ್ಕಿ ಹರಿಯುವ ವರ್ತನೆ
        ///
        /// ನ ಸಂಪೂರ್ಣ ಮೌಲ್ಯ
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// ಎಂದು ಪ್ರತಿನಿಧಿಸಲಾಗುವುದಿಲ್ಲ
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// ಮತ್ತು ಅದನ್ನು ಲೆಕ್ಕಹಾಕಲು ಪ್ರಯತ್ನಿಸುವುದರಿಂದ ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆ.
        /// ಇದರರ್ಥ ಡೀಬಗ್ ಮೋಡ್‌ನಲ್ಲಿರುವ ಕೋಡ್ ಈ ಸಂದರ್ಭದಲ್ಲಿ panic ಅನ್ನು ಪ್ರಚೋದಿಸುತ್ತದೆ ಮತ್ತು ಆಪ್ಟಿಮೈಸ್ಡ್ ಕೋಡ್ ಹಿಂತಿರುಗುತ್ತದೆ
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// panic ಇಲ್ಲದೆ.
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // ಮೇಲಿನ#[ಇನ್ಲೈನ್] ಎಂದರೆ ವ್ಯವಕಲನದ ಓವರ್‌ಫ್ಲೋ ಸೆಮ್ಯಾಂಟಿಕ್ಸ್ ನಾವು ಇನ್‌ಲೈನ್ ಆಗಿರುವ crate ಅನ್ನು ಅವಲಂಬಿಸಿರುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// `self` ನ ಚಿಹ್ನೆಯನ್ನು ಪ್ರತಿನಿಧಿಸುವ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        ///  - `0` ಸಂಖ್ಯೆ ಶೂನ್ಯವಾಗಿದ್ದರೆ
        ///  - `1` ಸಂಖ್ಯೆ ಸಕಾರಾತ್ಮಕವಾಗಿದ್ದರೆ
        ///  - `-1` ಸಂಖ್ಯೆ .ಣಾತ್ಮಕವಾಗಿದ್ದರೆ
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// `self` ಧನಾತ್ಮಕವಾಗಿದ್ದರೆ `true` ಮತ್ತು ಸಂಖ್ಯೆ ಶೂನ್ಯ ಅಥವಾ .ಣಾತ್ಮಕವಾಗಿದ್ದರೆ `false` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// `self` negative ಣಾತ್ಮಕವಾಗಿದ್ದರೆ `true` ಮತ್ತು ಸಂಖ್ಯೆ ಶೂನ್ಯ ಅಥವಾ ಧನಾತ್ಮಕವಾಗಿದ್ದರೆ `false` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        ///
        ///
        /// # Examples
        ///
        /// ಮೂಲ ಬಳಕೆ:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// ಬಿಗ್-ಎಂಡಿಯನ್ (network) ಬೈಟ್ ಕ್ರಮದಲ್ಲಿ ಬೈಟ್ ಅರೇ ಆಗಿ ಈ ಪೂರ್ಣಾಂಕದ ಮೆಮೊರಿ ಪ್ರಾತಿನಿಧ್ಯವನ್ನು ಹಿಂತಿರುಗಿ.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// ಕಡಿಮೆ-ಎಂಡಿಯನ್ ಬೈಟ್ ಕ್ರಮದಲ್ಲಿ ಬೈಟ್ ಅರೇ ಆಗಿ ಈ ಪೂರ್ಣಾಂಕದ ಮೆಮೊರಿ ಪ್ರಾತಿನಿಧ್ಯವನ್ನು ಹಿಂತಿರುಗಿ.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// ಸ್ಥಳೀಯ ಪೂರ್ಣ ಬೈಟ್ ಕ್ರಮದಲ್ಲಿ ಬೈಟ್ ಅರೇ ಆಗಿ ಈ ಪೂರ್ಣಾಂಕದ ಮೆಮೊರಿ ಪ್ರಾತಿನಿಧ್ಯವನ್ನು ಹಿಂತಿರುಗಿ.
        ///
        /// ಟಾರ್ಗೆಟ್ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್‌ನ ಸ್ಥಳೀಯ ಎಂಡಿಯನೆಸ್ ಅನ್ನು ಬಳಸಿದಂತೆ, ಪೋರ್ಟಬಲ್ ಕೋಡ್ ಸೂಕ್ತವಾದಂತೆ [`to_be_bytes`] ಅಥವಾ [`to_le_bytes`] ಅನ್ನು ಬಳಸಬೇಕು.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     ಬೈಟ್‌ಗಳು, cfg ಆಗಿದ್ದರೆ! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } else {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // ಸುರಕ್ಷತೆ: ಪೂರ್ಣಾಂಕವು ಸರಳ ಹಳೆಯ ಡೇಟಾಟೈಪ್‌ಗಳಾಗಿರುವುದರಿಂದ ನಾವು ಯಾವಾಗಲೂ ಮಾಡಬಹುದು
        // ಅವುಗಳನ್ನು ಬೈಟ್‌ಗಳ ಸರಣಿಗಳಿಗೆ ಪರಿವರ್ತಿಸಿ
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // ಸುರಕ್ಷತೆ: ಪೂರ್ಣಾಂಕಗಳು ಸರಳ ಹಳೆಯ ಡೇಟಾಟೈಪ್‌ಗಳಾಗಿವೆ ಆದ್ದರಿಂದ ನಾವು ಅವುಗಳನ್ನು ಯಾವಾಗಲೂ ಪರಿವರ್ತಿಸಬಹುದು
            // ಬೈಟ್‌ಗಳ ಸರಣಿಗಳು
            unsafe { mem::transmute(self) }
        }

        /// ಸ್ಥಳೀಯ ಪೂರ್ಣ ಬೈಟ್ ಕ್ರಮದಲ್ಲಿ ಬೈಟ್ ಅರೇ ಆಗಿ ಈ ಪೂರ್ಣಾಂಕದ ಮೆಮೊರಿ ಪ್ರಾತಿನಿಧ್ಯವನ್ನು ಹಿಂತಿರುಗಿ.
        ///
        ///
        /// [`to_ne_bytes`] ಸಾಧ್ಯವಾದಾಗಲೆಲ್ಲಾ ಇದನ್ನು ಆದ್ಯತೆ ನೀಡಬೇಕು.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// ಬೈಟ್‌ಗಳು= num.as_ne_bytes() ಅನ್ನು ಬಿಡಿ;
        /// assert_eq!(
        ///     ಬೈಟ್‌ಗಳು, cfg ಆಗಿದ್ದರೆ! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } else {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // ಸುರಕ್ಷತೆ: ಪೂರ್ಣಾಂಕಗಳು ಸರಳ ಹಳೆಯ ಡೇಟಾಟೈಪ್‌ಗಳಾಗಿವೆ ಆದ್ದರಿಂದ ನಾವು ಅವುಗಳನ್ನು ಯಾವಾಗಲೂ ಪರಿವರ್ತಿಸಬಹುದು
            // ಬೈಟ್‌ಗಳ ಸರಣಿಗಳು
            unsafe { &*(self as *const Self as *const _) }
        }

        /// ದೊಡ್ಡ ಎಂಡಿಯನ್‌ನಲ್ಲಿ ಬೈಟ್ ಅರೇ ಆಗಿ ಅದರ ಪ್ರಾತಿನಿಧ್ಯದಿಂದ ಒಂದು ಪೂರ್ಣಾಂಕ ಮೌಲ್ಯವನ್ನು ರಚಿಸಿ.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto ಬಳಸಿ;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ಇನ್ಪುಟ್=ಉಳಿದ;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// ಸ್ವಲ್ಪ ಎಂಡಿಯನ್‌ನಲ್ಲಿ ಬೈಟ್ ಅರೇ ಆಗಿ ಅದರ ಪ್ರಾತಿನಿಧ್ಯದಿಂದ ಒಂದು ಪೂರ್ಣಾಂಕ ಮೌಲ್ಯವನ್ನು ರಚಿಸಿ.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto ಬಳಸಿ;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ಇನ್ಪುಟ್=ಉಳಿದ;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// ಸ್ಥಳೀಯ ಎಂಡಿಯನೆಸ್‌ನಲ್ಲಿ ಬೈಟ್ ಅರೇ ಆಗಿ ಅದರ ಮೆಮೊರಿ ಪ್ರಾತಿನಿಧ್ಯದಿಂದ ಒಂದು ಪೂರ್ಣಾಂಕ ಮೌಲ್ಯವನ್ನು ರಚಿಸಿ.
        ///
        /// ಟಾರ್ಗೆಟ್ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್‌ನ ಸ್ಥಳೀಯ ಎಂಡಿಯೆನೆಸ್ ಅನ್ನು ಬಳಸಿದಂತೆ, ಪೋರ್ಟಬಲ್ ಕೋಡ್ ಬದಲಾಗಿ [`from_be_bytes`] ಅಥವಾ [`from_le_bytes`] ಅನ್ನು ಬಳಸಲು ಬಯಸುತ್ತದೆ.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } else {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto ಬಳಸಿ;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ಇನ್ಪುಟ್=ಉಳಿದ;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // ಸುರಕ್ಷತೆ: ಪೂರ್ಣಾಂಕವು ಸರಳ ಹಳೆಯ ಡೇಟಾಟೈಪ್‌ಗಳಾಗಿರುವುದರಿಂದ ನಾವು ಯಾವಾಗಲೂ ಮಾಡಬಹುದು
        // ಅವರಿಗೆ ಪರಿವರ್ತಿಸಿ
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // ಸುರಕ್ಷತೆ: ಪೂರ್ಣಾಂಕಗಳು ಸರಳ ಹಳೆಯ ಡೇಟಾಟೈಪ್‌ಗಳಾಗಿವೆ, ಆದ್ದರಿಂದ ನಾವು ಅವರಿಗೆ ಯಾವಾಗಲೂ ಪರಿವರ್ತಿಸಬಹುದು
            unsafe { mem::transmute(bytes) }
        }

        /// ಹೊಸ ಕೋಡ್ ಬಳಸಲು ಆದ್ಯತೆ ನೀಡಬೇಕು
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// ಈ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರದಿಂದ ಪ್ರತಿನಿಧಿಸಬಹುದಾದ ಚಿಕ್ಕ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// ಹೊಸ ಕೋಡ್ ಬಳಸಲು ಆದ್ಯತೆ ನೀಡಬೇಕು
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// ಈ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರದಿಂದ ಪ್ರತಿನಿಧಿಸಬಹುದಾದ ದೊಡ್ಡ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}