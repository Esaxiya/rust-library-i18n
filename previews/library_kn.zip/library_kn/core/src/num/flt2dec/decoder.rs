//! ಫ್ಲೋಟಿಂಗ್-ಪಾಯಿಂಟ್ ಮೌಲ್ಯವನ್ನು ಪ್ರತ್ಯೇಕ ಭಾಗಗಳು ಮತ್ತು ದೋಷ ಶ್ರೇಣಿಗಳಾಗಿ ಡಿಕೋಡ್ ಮಾಡುತ್ತದೆ.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// ಡಿಕೋಡ್ ಮಾಡದ ಸಹಿ ಮಾಡದ ಸೀಮಿತ ಮೌಲ್ಯ, ಅಂದರೆ:
///
/// - ಮೂಲ ಮೌಲ್ಯವು `mant * 2^exp` ಗೆ ಸಮನಾಗಿರುತ್ತದೆ.
///
/// - `(mant - minus)*2^exp` ನಿಂದ `(mant + plus)* 2^exp` ವರೆಗಿನ ಯಾವುದೇ ಸಂಖ್ಯೆಯು ಮೂಲ ಮೌಲ್ಯಕ್ಕೆ ಸುತ್ತಿಕೊಳ್ಳುತ್ತದೆ.
/// `inclusive` `true` ಆಗಿದ್ದಾಗ ಮಾತ್ರ ಶ್ರೇಣಿ ಸೇರಿದೆ.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// ಸ್ಕೇಲ್ಡ್ ಮಂಟಿಸ್ಸಾ.
    pub mant: u64,
    /// ಕಡಿಮೆ ದೋಷ ಶ್ರೇಣಿ.
    pub minus: u64,
    /// ಮೇಲಿನ ದೋಷ ಶ್ರೇಣಿ.
    pub plus: u64,
    /// ಬೇಸ್ 2 ರಲ್ಲಿ ಹಂಚಿದ ಘಾತಾಂಕ.
    pub exp: i16,
    /// ದೋಷ ಶ್ರೇಣಿ ಒಳಗೊಂಡಿರುವಾಗ ನಿಜ.
    ///
    /// ಐಇಇಇ 754 ರಲ್ಲಿ, ಮೂಲ ಮಂಟಿಸಾ ಸಮವಾಗಿದ್ದಾಗ ಇದು ನಿಜ.
    pub inclusive: bool,
}

/// ಡಿಕೋಡ್ ಮಾಡದ ಸಹಿ.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// ಅನಂತಗಳು, ಧನಾತ್ಮಕ ಅಥವಾ .ಣಾತ್ಮಕ.
    Infinite,
    /// ಶೂನ್ಯ, ಧನಾತ್ಮಕ ಅಥವಾ .ಣಾತ್ಮಕ.
    Zero,
    /// ಮತ್ತಷ್ಟು ಡಿಕೋಡ್ ಮಾಡಿದ ಕ್ಷೇತ್ರಗಳೊಂದಿಗೆ ಸೀಮಿತ ಸಂಖ್ಯೆಗಳು.
    Finite(Decoded),
}

/// ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಪ್ರಕಾರವು `ಡಿಕೋಡ್` ಆಗಿರಬಹುದು.
pub trait DecodableFloat: RawFloat + Copy {
    /// ಕನಿಷ್ಠ ಧನಾತ್ಮಕ ಸಾಮಾನ್ಯ ಮೌಲ್ಯ.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// ಕೊಟ್ಟಿರುವ ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಸಂಖ್ಯೆಯಿಂದ ಚಿಹ್ನೆ (negative ಣಾತ್ಮಕವಾಗಿದ್ದಾಗ ನಿಜ) ಮತ್ತು `FullDecoded` ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // ನೆರೆಹೊರೆಯವರು: (ಮಂತ್, 2, ಎಕ್ಸ್‌ಪ್ರೆಸ್)-(ಮಂತ್, ಎಕ್ಸ್‌ಪ್ರೆಸ್)-(ಮಂತ್ + 2, ಎಕ್ಸ್‌ಪ್ರೆಸ್)
            // Float::integer_decode ಯಾವಾಗಲೂ ಘಾತಾಂಕವನ್ನು ಸಂರಕ್ಷಿಸುತ್ತದೆ, ಆದ್ದರಿಂದ ಮಂಟಿಸ್ಸಾವನ್ನು ಸಬ್‌ನಾರ್ಮಲ್‌ಗಳಿಗೆ ಅಳೆಯಲಾಗುತ್ತದೆ.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // ನೆರೆಹೊರೆಯವರು: (ಗರಿಷ್ಠ, ಎಕ್ಸ್‌ಪ್ರೆಸ್, 1)-(ಅಲ್ಪಸಂಖ್ಯಾತ, ಎಕ್ಸ್‌ಪ್ರೆಸ್)-(ಅಲ್ಪಸಂಖ್ಯಾತ + 1, ಎಕ್ಸ್‌ಪ್ರೆಸ್)
                // ಅಲ್ಲಿ ಗರಿಷ್ಠ=ಅಲ್ಪಸಂಖ್ಯಾತ * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // ನೆರೆಹೊರೆಯವರು: (ಮಂತ್, 1, ಎಕ್ಸ್‌ಪ್ರೆಸ್)-(ಮಂತ್, ಎಕ್ಸ್‌ಪ್ರೆಸ್)-(ಮಂತ್ + 1, ಎಕ್ಸ್‌ಪ್ರೆಸ್)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}