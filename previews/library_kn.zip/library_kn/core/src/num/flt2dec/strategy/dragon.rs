//! "ಫ್ಲೋಟಿಂಗ್-ಪಾಯಿಂಟ್ ಸಂಖ್ಯೆಗಳನ್ನು ಮುದ್ರಿಸುವುದು ತ್ವರಿತವಾಗಿ ಮತ್ತು ನಿಖರವಾಗಿ" [^ 1] ನ ಚಿತ್ರ 3 ರ ಬಹುತೇಕ ನೇರ (ಆದರೆ ಸ್ವಲ್ಪ ಹೊಂದುವಂತೆ) Rust ಅನುವಾದ.
//!
//!
//! [^1]: Burger, ಆರ್ಜಿ ಮತ್ತು ಡೈಬ್ವಿಗ್, ಆರ್ಕೆ 1996. ಫ್ಲೋಟಿಂಗ್-ಪಾಯಿಂಟ್ ಸಂಖ್ಯೆಗಳನ್ನು ಮುದ್ರಿಸುವುದು
//!   ತ್ವರಿತವಾಗಿ ಮತ್ತು ನಿಖರವಾಗಿ.SIGPLAN ಅಲ್ಲ.31, 5 (ಮೇ. 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// 10 ^ (2 ^ n) ಗೆ `ಡಿಜಿ'ಗಳ ಪೂರ್ವನಿರ್ಧರಿತ ಸರಣಿಗಳು
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// `x < 16 * scale` ಇದ್ದಾಗ ಮಾತ್ರ ಬಳಸಬಹುದಾಗಿದೆ;`scaleN` `scale.mul_small(N)` ಆಗಿರಬೇಕು
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// ಡ್ರ್ಯಾಗನ್‌ಗಾಗಿ ಕಡಿಮೆ ಮೋಡ್ ಅನುಷ್ಠಾನ.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // ಫಾರ್ಮ್ಯಾಟ್‌ಗೆ `v` ಸಂಖ್ಯೆ ಎಂದು ತಿಳಿದುಬಂದಿದೆ:
    // - `mant * 2^exp` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ;
    // - ಮೂಲ ಪ್ರಕಾರದಲ್ಲಿ `(mant - 2 *minus)* 2^exp` ನಿಂದ ಮೊದಲು;ಮತ್ತು
    // - ಮೂಲ ಪ್ರಕಾರದಲ್ಲಿ `(mant + 2 *plus)* 2^exp` ನಂತರ.
    //
    // ನಿಸ್ಸಂಶಯವಾಗಿ, `minus` ಮತ್ತು `plus` ಶೂನ್ಯವಾಗಿರಬಾರದು.(ಅನಂತತೆಗಳಿಗಾಗಿ, ನಾವು ವ್ಯಾಪ್ತಿಯ ಹೊರಗಿನ ಮೌಲ್ಯಗಳನ್ನು ಬಳಸುತ್ತೇವೆ.) ಕನಿಷ್ಠ ಒಂದು ಅಂಕಿಯಾದರೂ ಉತ್ಪತ್ತಿಯಾಗುತ್ತದೆ ಎಂದು ನಾವು ume ಹಿಸುತ್ತೇವೆ, ಅಂದರೆ, `mant` ಕೂಡ ಶೂನ್ಯವಾಗಿರಬಾರದು.
    //
    // ಇದರರ್ಥ `low = (mant - minus)*2^exp` ಮತ್ತು `high = (mant + plus)* 2^exp` ನಡುವಿನ ಯಾವುದೇ ಸಂಖ್ಯೆಯು ಈ ನಿಖರವಾದ ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಸಂಖ್ಯೆಗೆ ನಕ್ಷೆ ಮಾಡುತ್ತದೆ, ಮೂಲ ಮಂಟಿಸ್ಸಾ ಸಮನಾಗಿದ್ದಾಗ (ಅಂದರೆ, `!mant_was_odd`) ಗಡಿಗಳನ್ನು ಒಳಗೊಂಡಿರುತ್ತದೆ.
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` `if d.inclusive {a <= b} else {a < b}` ಆಗಿದೆ
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // `10^(k_0-1) < high <= 10^(k_0+1)` ಅನ್ನು ತೃಪ್ತಿಪಡಿಸುವ ಮೂಲ ಒಳಹರಿವಿನಿಂದ `k_0` ಅನ್ನು ಅಂದಾಜು ಮಾಡಿ.
    // ಬಿಗಿಯಾದ ಬೌಂಡ್ `k` ತೃಪ್ತಿಕರವಾದ `10^(k-1) < high <= 10^k` ಅನ್ನು ನಂತರ ಲೆಕ್ಕಹಾಕಲಾಗುತ್ತದೆ.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // `{mant, plus, minus} * 2^exp` ಅನ್ನು ಭಾಗಶಃ ರೂಪಕ್ಕೆ ಪರಿವರ್ತಿಸಿ ಇದರಿಂದ:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // `mant` ಅನ್ನು `10^k` ನಿಂದ ಭಾಗಿಸಿ.ಈಗ `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // `mant + plus > scale` (ಅಥವಾ `>=`) ಇದ್ದಾಗ ಫಿಕ್ಸಪ್ ಮಾಡಿ.
    // ನಾವು ವಾಸ್ತವವಾಗಿ `scale` ಅನ್ನು ಮಾರ್ಪಡಿಸುತ್ತಿಲ್ಲ, ಏಕೆಂದರೆ ನಾವು ಆರಂಭಿಕ ಗುಣಾಕಾರವನ್ನು ಬಿಟ್ಟುಬಿಡಬಹುದು.
    // ಈಗ `scale < mant + plus <= scale * 10` ಮತ್ತು ನಾವು ಅಂಕೆಗಳನ್ನು ರಚಿಸಲು ಸಿದ್ಧರಿದ್ದೇವೆ.
    //
    // `scale - plus < mant < scale` ಇದ್ದಾಗ `d[0]` * ಶೂನ್ಯವಾಗಬಹುದು ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    // ಈ ಸಂದರ್ಭದಲ್ಲಿ ರೌಂಡಿಂಗ್-ಅಪ್ ಸ್ಥಿತಿ (ಕೆಳಗಿನ `up`) ತಕ್ಷಣವೇ ಪ್ರಚೋದಿಸಲ್ಪಡುತ್ತದೆ.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // `scale` ಅನ್ನು 10 ರಿಂದ ಸ್ಕೇಲಿಂಗ್ ಮಾಡಲು ಸಮಾನವಾಗಿರುತ್ತದೆ
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // ಅಂಕೆ ಉತ್ಪಾದನೆಗೆ ಸಂಗ್ರಹ `(2, 4, 8) * scale`.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // ಅಸ್ಥಿರತೆಗಳು, ಅಲ್ಲಿ `d[0..n-1]` ಇಲ್ಲಿಯವರೆಗೆ ಉತ್ಪತ್ತಿಯಾಗುವ ಅಂಕೆಗಳು:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (ಹೀಗೆ `mant / scale < 10`) ಅಲ್ಲಿ `d[i..j]` ಎಂಬುದು `d [i] * 10 ^ (ji) + ಗೆ ಸಂಕ್ಷಿಪ್ತ ರೂಪವಾಗಿದೆ ...
        // + d [j-1] * 10 + d[j]`.

        // ಒಂದು ಅಂಕಿಯನ್ನು ರಚಿಸಿ: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // ಇದು ಮಾರ್ಪಡಿಸಿದ ಡ್ರ್ಯಾಗನ್ ಅಲ್ಗಾರಿದಮ್ನ ಸರಳೀಕೃತ ವಿವರಣೆಯಾಗಿದೆ.
        // ಅನೇಕ ಮಧ್ಯಂತರ ವ್ಯುತ್ಪನ್ನಗಳು ಮತ್ತು ಸಂಪೂರ್ಣತೆಯ ವಾದಗಳನ್ನು ಅನುಕೂಲಕ್ಕಾಗಿ ಬಿಟ್ಟುಬಿಡಲಾಗಿದೆ.
        //
        // ನಾವು `n` ಅನ್ನು ನವೀಕರಿಸಿದಂತೆ ಮಾರ್ಪಡಿಸಿದ ಅಸ್ಥಿರತೆಗಳೊಂದಿಗೆ ಪ್ರಾರಂಭಿಸಿ:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // `d[0..n-1]` ಎಂಬುದು `low` ಮತ್ತು `high` ನಡುವಿನ ಕಡಿಮೆ ಪ್ರಾತಿನಿಧ್ಯವಾಗಿದೆ ಎಂದು ume ಹಿಸಿ, ಅಂದರೆ, `d[0..n-1]` ಈ ಕೆಳಗಿನ ಎರಡನ್ನೂ ತೃಪ್ತಿಪಡಿಸುತ್ತದೆ ಆದರೆ `d[0..n-2]` ಮಾಡುವುದಿಲ್ಲ:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (ಬೈಜೆಕ್ಟಿವಿಟಿ: ಅಂಕೆಗಳು `v` ಗೆ ಸುತ್ತಿನಲ್ಲಿ);ಮತ್ತು
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (ಕೊನೆಯ ಅಂಕೆ ಸರಿಯಾಗಿದೆ).
        //
        // ಎರಡನೇ ಸ್ಥಿತಿಯು `2 * mant <= scale` ಗೆ ಸರಳಗೊಳಿಸುತ್ತದೆ.
        // `mant`, `low` ಮತ್ತು `high` ಪರಿಭಾಷೆಯಲ್ಲಿ ಅಸ್ಥಿರತೆಗಳನ್ನು ಪರಿಹರಿಸುವುದು ಮೊದಲ ಸ್ಥಿತಿಯ ಸರಳ ಆವೃತ್ತಿಯನ್ನು ನೀಡುತ್ತದೆ: `-plus < mant < minus`.
        // `-plus < 0 <= mant` ರಿಂದ, `mant < minus` ಮತ್ತು `2 * mant <= scale` ಇದ್ದಾಗ ನಮಗೆ ಸರಿಯಾದ ಕಡಿಮೆ ಪ್ರಾತಿನಿಧ್ಯವಿದೆ.
        // (ಮೂಲ ಮಂಟಿಸ್ಸಾ ಸಮವಾಗಿದ್ದಾಗ ಹಿಂದಿನದು `mant <= minus` ಆಗುತ್ತದೆ.)
        //
        // ಎರಡನೆಯದು ಹಿಡಿಸದಿದ್ದಾಗ (`2 * ಮಂತ್> ಸ್ಕೇಲ್`), ನಾವು ಕೊನೆಯ ಅಂಕಿಯನ್ನು ಹೆಚ್ಚಿಸಬೇಕಾಗಿದೆ.
        // ಆ ಸ್ಥಿತಿಯನ್ನು ಮರುಸ್ಥಾಪಿಸಲು ಇದು ಸಾಕು: ಅಂಕಿಯ ಪೀಳಿಗೆಯು `0 <= v / 10^(k-n) - d[0..n-1] < 1` ಗೆ ಖಾತರಿ ನೀಡುತ್ತದೆ ಎಂದು ನಮಗೆ ಈಗಾಗಲೇ ತಿಳಿದಿದೆ.
        // ಈ ಸಂದರ್ಭದಲ್ಲಿ, ಮೊದಲ ಸ್ಥಿತಿಯು `-plus < mant - scale < minus` ಆಗುತ್ತದೆ.
        // ಪೀಳಿಗೆಯ ನಂತರ `mant < scale` ರಿಂದ, ನಾವು `scale < mant + plus` ಅನ್ನು ಹೊಂದಿದ್ದೇವೆ.
        // (ಮತ್ತೆ, ಮೂಲ ಮಂಟಿಸ್ಸಾ ಸಮವಾಗಿದ್ದಾಗ ಇದು `scale <= mant + plus` ಆಗುತ್ತದೆ.)
        //
        // ಸಂಕ್ಷಿಪ್ತವಾಗಿ:
        // - `mant < minus` (ಅಥವಾ `<=`) ಇರುವಾಗ `down` ಅನ್ನು ನಿಲ್ಲಿಸಿ ಮತ್ತು ಸುತ್ತಿನಲ್ಲಿ (ಅಂಕೆಗಳನ್ನು ಹಾಗೆಯೇ ಇರಿಸಿ).
        // - `scale < mant + plus` (ಅಥವಾ `<=`) ಇದ್ದಾಗ `up` ಅನ್ನು ನಿಲ್ಲಿಸಿ ಮತ್ತು ಸುತ್ತಿನಲ್ಲಿ (ಕೊನೆಯ ಅಂಕೆ ಹೆಚ್ಚಿಸಿ).
        // - ಇಲ್ಲದಿದ್ದರೆ ಉತ್ಪಾದಿಸುತ್ತಲೇ ಇರಿ.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // ನಮಗೆ ಕಡಿಮೆ ಪ್ರಾತಿನಿಧ್ಯವಿದೆ, ಪೂರ್ಣಾಂಕಕ್ಕೆ ಮುಂದುವರಿಯಿರಿ

        // ಅಸ್ಥಿರಗಳನ್ನು ಪುನಃಸ್ಥಾಪಿಸಿ.
        // ಇದು ಅಲ್ಗಾರಿದಮ್ ಅನ್ನು ಯಾವಾಗಲೂ ಕೊನೆಗೊಳಿಸುತ್ತದೆ: `minus` ಮತ್ತು `plus` ಯಾವಾಗಲೂ ಹೆಚ್ಚಾಗುತ್ತದೆ, ಆದರೆ `mant` ಅನ್ನು ಕ್ಲಿಪ್ ಮಾಡ್ಯುಲೋ `scale` ಮತ್ತು `scale` ಅನ್ನು ನಿವಾರಿಸಲಾಗಿದೆ.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // ನಾನು) ರೌಂಡಿಂಗ್-ಅಪ್ ಸ್ಥಿತಿಯನ್ನು ಮಾತ್ರ ಪ್ರಚೋದಿಸಿದಾಗ ಅಥವಾ II) ಎರಡೂ ಷರತ್ತುಗಳನ್ನು ಪ್ರಚೋದಿಸಿದಾಗ ಮತ್ತು ಟೈ ಬ್ರೇಕಿಂಗ್ ಅನ್ನು ಪೂರ್ಣಗೊಳಿಸಲು ಆದ್ಯತೆ ನೀಡಿದಾಗ ರೌಂಡಿಂಗ್ ಸಂಭವಿಸುತ್ತದೆ.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // ಪೂರ್ಣಾಂಕವು ಉದ್ದವನ್ನು ಬದಲಾಯಿಸಿದರೆ, ಘಾತಾಂಕವೂ ಬದಲಾಗಬೇಕು.
        // ಈ ಸ್ಥಿತಿಯನ್ನು ಪೂರೈಸುವುದು ತುಂಬಾ ಕಷ್ಟ ಎಂದು ತೋರುತ್ತದೆ (ಬಹುಶಃ ಅಸಾಧ್ಯ), ಆದರೆ ನಾವು ಇಲ್ಲಿ ಸುರಕ್ಷಿತವಾಗಿ ಮತ್ತು ಸ್ಥಿರವಾಗಿರುತ್ತೇವೆ.
        //
        // ಸುರಕ್ಷತೆ: ನಾವು ಆ ಸ್ಮರಣೆಯನ್ನು ಮೇಲೆ ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // ಸುರಕ್ಷತೆ: ನಾವು ಆ ಸ್ಮರಣೆಯನ್ನು ಮೇಲೆ ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// ಡ್ರ್ಯಾಗನ್‌ಗಾಗಿ ನಿಖರ ಮತ್ತು ಸ್ಥಿರ ಮೋಡ್ ಅನುಷ್ಠಾನ.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // `10^(k_0-1) < v <= 10^(k_0+1)` ಅನ್ನು ತೃಪ್ತಿಪಡಿಸುವ ಮೂಲ ಒಳಹರಿವಿನಿಂದ `k_0` ಅನ್ನು ಅಂದಾಜು ಮಾಡಿ.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // `mant` ಅನ್ನು `10^k` ನಿಂದ ಭಾಗಿಸಿ.ಈಗ `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // `mant + plus >= scale` ಇದ್ದಾಗ ಫಿಕ್ಸ್ಅಪ್, ಅಲ್ಲಿ `plus / scale = 10^-buf.len() / 2`.
    // ಸ್ಥಿರ ಗಾತ್ರದ ಬಿಗ್ನಮ್ ಅನ್ನು ಉಳಿಸಿಕೊಳ್ಳಲು, ನಾವು ನಿಜವಾಗಿ `mant + floor(plus) >= scale` ಅನ್ನು ಬಳಸುತ್ತೇವೆ.
    // ನಾವು ವಾಸ್ತವವಾಗಿ `scale` ಅನ್ನು ಮಾರ್ಪಡಿಸುತ್ತಿಲ್ಲ, ಏಕೆಂದರೆ ನಾವು ಆರಂಭಿಕ ಗುಣಾಕಾರವನ್ನು ಬಿಟ್ಟುಬಿಡಬಹುದು.
    // ಮತ್ತೆ ಕಡಿಮೆ ಅಲ್ಗಾರಿದಮ್‌ನೊಂದಿಗೆ, `d[0]` ಶೂನ್ಯವಾಗಬಹುದು ಆದರೆ ಅಂತಿಮವಾಗಿ ಅದನ್ನು ಪೂರ್ಣಗೊಳಿಸಲಾಗುತ್ತದೆ.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // `scale` ಅನ್ನು 10 ರಿಂದ ಸ್ಕೇಲಿಂಗ್ ಮಾಡಲು ಸಮಾನವಾಗಿರುತ್ತದೆ
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // ನಾವು ಕೊನೆಯ-ಅಂಕಿಯ ಮಿತಿಯೊಂದಿಗೆ ಕೆಲಸ ಮಾಡುತ್ತಿದ್ದರೆ, ಡಬಲ್ ರೌಂಡಿಂಗ್ ಅನ್ನು ತಪ್ಪಿಸಲು ನಾವು ನಿಜವಾದ ರೆಂಡರಿಂಗ್‌ಗೆ ಮೊದಲು ಬಫರ್ ಅನ್ನು ಕಡಿಮೆ ಮಾಡಬೇಕಾಗುತ್ತದೆ.
    //
    // ಪೂರ್ಣಗೊಳ್ಳುವಾಗ ನಾವು ಮತ್ತೆ ಬಫರ್ ಅನ್ನು ದೊಡ್ಡದಾಗಿಸಬೇಕು ಎಂಬುದನ್ನು ಗಮನಿಸಿ!
    let mut len = if k < limit {
        // ಓಹ್, ನಾವು *ಒಂದು* ಅಂಕಿಯನ್ನು ಸಹ ಉತ್ಪಾದಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ.
        // ನಾವು 9.5 ನಂತಹದನ್ನು ಪಡೆದುಕೊಂಡಿದ್ದೇವೆ ಮತ್ತು ಅದನ್ನು 10 ಕ್ಕೆ ದುಂಡಾದಾಗ ಇದು ಸಾಧ್ಯ.
        // `k == limit` ಸಂಭವಿಸಿದಾಗ ಮತ್ತು ನಿಖರವಾಗಿ ಒಂದು ಅಂಕಿಯನ್ನು ಉತ್ಪಾದಿಸಬೇಕಾದ ನಂತರದ ರೌಂಡಿಂಗ್-ಅಪ್ ಪ್ರಕರಣವನ್ನು ಹೊರತುಪಡಿಸಿ, ನಾವು ಖಾಲಿ ಬಫರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತೇವೆ.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // ಅಂಕೆ ಉತ್ಪಾದನೆಗೆ ಸಂಗ್ರಹ `(2, 4, 8) * scale`.
        // (ಇದು ದುಬಾರಿಯಾಗಬಹುದು, ಆದ್ದರಿಂದ ಬಫರ್ ಖಾಲಿಯಾಗಿರುವಾಗ ಅವುಗಳನ್ನು ಲೆಕ್ಕಿಸಬೇಡಿ.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // ಕೆಳಗಿನ ಅಂಕೆಗಳು ಎಲ್ಲಾ ಸೊನ್ನೆಗಳು, ನಾವು ಇಲ್ಲಿ ನಿಲ್ಲಿಸುತ್ತೇವೆ * ಪೂರ್ಣಾಂಕವನ್ನು ಮಾಡಲು ಪ್ರಯತ್ನಿಸಬೇಡಿ!ಬದಲಿಗೆ, ಉಳಿದ ಅಂಕೆಗಳನ್ನು ಭರ್ತಿ ಮಾಡಿ.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // ಸುರಕ್ಷತೆ: ನಾವು ಆ ಸ್ಮರಣೆಯನ್ನು ಮೇಲೆ ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // ಈ ಕೆಳಗಿನ ಅಂಕೆಗಳು ನಿಖರವಾಗಿ 5000 ಆಗಿದ್ದರೆ ನಾವು ಅಂಕೆಗಳ ಮಧ್ಯದಲ್ಲಿ ನಿಲ್ಲಿಸಿದರೆ ..., ಮೊದಲಿನ ಅಂಕೆಗಳನ್ನು ಪರಿಶೀಲಿಸಿ ಮತ್ತು ಸಮವಾಗಿ ಸುತ್ತಲು ಪ್ರಯತ್ನಿಸಿ (ಅಂದರೆ, ಮೊದಲಿನ ಅಂಕೆ ಸಮವಾಗಿದ್ದಾಗ ಪೂರ್ಣಗೊಳ್ಳುವುದನ್ನು ತಪ್ಪಿಸಿ).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // ಸುರಕ್ಷತೆ: `buf[len-1]` ಅನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // ಪೂರ್ಣಾಂಕವು ಉದ್ದವನ್ನು ಬದಲಾಯಿಸಿದರೆ, ಘಾತಾಂಕವೂ ಬದಲಾಗಬೇಕು.
        // ಆದರೆ ನಮಗೆ ನಿರ್ದಿಷ್ಟ ಸಂಖ್ಯೆಯ ಅಂಕೆಗಳನ್ನು ಕೋರಲಾಗಿದೆ, ಆದ್ದರಿಂದ ಬಫರ್ ಅನ್ನು ಬದಲಾಯಿಸಬೇಡಿ ...
        // ಸುರಕ್ಷತೆ: ನಾವು ಆ ಸ್ಮರಣೆಯನ್ನು ಮೇಲೆ ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... ಬದಲಿಗೆ ಸ್ಥಿರ ನಿಖರತೆಯನ್ನು ನಾವು ವಿನಂತಿಸದ ಹೊರತು.
            // ಮೂಲ ಬಫರ್ ಖಾಲಿಯಾಗಿದ್ದರೆ, `k == limit` (edge ಕೇಸ್) ಇದ್ದಾಗ ಮಾತ್ರ ಹೆಚ್ಚುವರಿ ಅಂಕಿಯನ್ನು ಸೇರಿಸಬಹುದು ಎಂದು ನಾವು ಪರಿಶೀಲಿಸಬೇಕಾಗಿದೆ.
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // ಸುರಕ್ಷತೆ: ನಾವು ಆ ಸ್ಮರಣೆಯನ್ನು ಮೇಲೆ ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}