/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// ಇದನ್ನು ವ್ಯಾಪಕವಾಗಿ ದಾಖಲಿಸಲಾಗಿದ್ದರೂ, ಇದು ತಾತ್ವಿಕವಾಗಿ ಖಾಸಗಿಯಾಗಿದೆ, ಇದನ್ನು ಪರೀಕ್ಷೆಗೆ ಮಾತ್ರ ಸಾರ್ವಜನಿಕಗೊಳಿಸಲಾಗುತ್ತದೆ.
// ನಮ್ಮನ್ನು ಬಹಿರಂಗಪಡಿಸಬೇಡಿ.
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// ಅಂಕಿಯ-ಪೀಳಿಗೆಯ ಕ್ರಮಾವಳಿಗಳು.
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// ಕಡಿಮೆ ಮೋಡ್‌ಗೆ ಅಗತ್ಯವಾದ ಕನಿಷ್ಠ ಗಾತ್ರದ ಬಫರ್.
///
/// ವ್ಯುತ್ಪನ್ನಗೊಳಿಸಲು ಇದು ಸ್ವಲ್ಪ ಕ್ಷುಲ್ಲಕವಾಗಿದೆ, ಆದರೆ ಇದು ಕಡಿಮೆ ಫಲಿತಾಂಶದೊಂದಿಗೆ ಅಲ್ಗಾರಿದಮ್‌ಗಳನ್ನು ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡುವುದರಿಂದ ಗಮನಾರ್ಹವಾದ ದಶಮಾಂಶ ಅಂಕೆಗಳ ಗರಿಷ್ಠ ಸಂಖ್ಯೆ.
///
/// ನಿಖರವಾದ ಸೂತ್ರವು `ceil(# bits in mantissa * log_10 2 + 1)` ಆಗಿದೆ.
pub const MAX_SIG_DIGITS: usize = 17;

/// `d` ದಶಮಾಂಶ ಅಂಕೆಗಳನ್ನು ಹೊಂದಿರುವಾಗ, ಕೊನೆಯ ಅಂಕಿಯನ್ನು ಹೆಚ್ಚಿಸಿ ಮತ್ತು ಕ್ಯಾರಿಯನ್ನು ಪ್ರಚಾರ ಮಾಡಿ.
/// ಉದ್ದವು ಬದಲಾಗಲು ಕಾರಣವಾದಾಗ ಮುಂದಿನ ಅಂಕಿಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // d [i + 1..n] ಎಲ್ಲಾ ನೈನ್ಗಳು
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 ಹೆಚ್ಚಿದ ಘಾತಾಂಕದೊಂದಿಗೆ 1000..000 ಗೆ ಸುತ್ತುಗಳು
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // ಖಾಲಿ ಬಫರ್ ಸುತ್ತುತ್ತದೆ (ಸ್ವಲ್ಪ ವಿಚಿತ್ರವಾದ ಆದರೆ ಸಮಂಜಸವಾದ)
            Some(b'1')
        }
    }
}

/// ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಿದ ಭಾಗಗಳು.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// ಶೂನ್ಯ ಅಂಕೆಗಳ ಸಂಖ್ಯೆಯನ್ನು ನೀಡಲಾಗಿದೆ.
    Zero(usize),
    /// 5 ಅಂಕೆಗಳವರೆಗಿನ ಅಕ್ಷರಶಃ ಸಂಖ್ಯೆ.
    Num(u16),
    /// ಕೊಟ್ಟಿರುವ ಬೈಟ್‌ಗಳ ಶಬ್ದಕೋಶದ ಪ್ರತಿ.
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// ಕೊಟ್ಟಿರುವ ಭಾಗದ ನಿಖರವಾದ ಬೈಟ್ ಉದ್ದವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// ಸರಬರಾಜು ಮಾಡಿದ ಬಫರ್‌ಗೆ ಒಂದು ಭಾಗವನ್ನು ಬರೆಯುತ್ತದೆ.
    /// ಲಿಖಿತ ಬೈಟ್‌ಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಥವಾ ಬಫರ್ ಸಾಕಷ್ಟಿಲ್ಲದಿದ್ದರೆ `None`.
    /// (ಇದು ಇನ್ನೂ ಬಫರ್‌ನಲ್ಲಿ ಭಾಗಶಃ ಬರೆದ ಬೈಟ್‌ಗಳನ್ನು ಬಿಡಬಹುದು; ಅದನ್ನು ಅವಲಂಬಿಸಬೇಡಿ.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// ಒಂದು ಅಥವಾ ಹೆಚ್ಚಿನ ಭಾಗಗಳನ್ನು ಹೊಂದಿರುವ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಿದ ಫಲಿತಾಂಶ.
/// ಇದನ್ನು ಬೈಟ್ ಬಫರ್‌ಗೆ ಬರೆಯಬಹುದು ಅಥವಾ ನಿಯೋಜಿಸಲಾದ ಸ್ಟ್ರಿಂಗ್‌ಗೆ ಪರಿವರ್ತಿಸಬಹುದು.
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// `""`, `"-"` ಅಥವಾ `"+"` ಚಿಹ್ನೆಯನ್ನು ಪ್ರತಿನಿಧಿಸುವ ಬೈಟ್ ಸ್ಲೈಸ್.
    pub sign: &'static str,
    /// ಚಿಹ್ನೆ ಮತ್ತು ಐಚ್ al ಿಕ ಶೂನ್ಯ ಪ್ಯಾಡಿಂಗ್ ನಂತರ ಪ್ರದರ್ಶಿಸಬೇಕಾದ ಭಾಗಗಳನ್ನು ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಲಾಗಿದೆ.
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// ಸಂಯೋಜಿತ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಿದ ಫಲಿತಾಂಶದ ನಿಖರವಾದ ಬೈಟ್ ಉದ್ದವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// ಎಲ್ಲಾ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಿದ ಭಾಗಗಳನ್ನು ಸರಬರಾಜು ಮಾಡಿದ ಬಫರ್‌ಗೆ ಬರೆಯುತ್ತದೆ.
    /// ಲಿಖಿತ ಬೈಟ್‌ಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಥವಾ ಬಫರ್ ಸಾಕಷ್ಟಿಲ್ಲದಿದ್ದರೆ `None`.
    /// (ಇದು ಇನ್ನೂ ಬಫರ್‌ನಲ್ಲಿ ಭಾಗಶಃ ಬರೆದ ಬೈಟ್‌ಗಳನ್ನು ಬಿಡಬಹುದು; ಅದನ್ನು ಅವಲಂಬಿಸಬೇಡಿ.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// ಕನಿಷ್ಠ ಕೊಟ್ಟಿರುವ ಭಾಗಶಃ ಅಂಕೆಗಳೊಂದಿಗೆ ದಶಮಾಂಶ ಅಂಕಿಗಳಾದ `0.<...buf...> * 10^exp` ಅನ್ನು ದಶಮಾಂಶ ರೂಪಕ್ಕೆ ನೀಡಿದ ಸ್ವರೂಪಗಳು.
///
/// ಫಲಿತಾಂಶವನ್ನು ಸರಬರಾಜು ಮಾಡಿದ ಭಾಗಗಳ ಶ್ರೇಣಿಗೆ ಸಂಗ್ರಹಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ಲಿಖಿತ ಭಾಗಗಳ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
///
/// `frac_digits` `buf` ನಲ್ಲಿನ ನಿಜವಾದ ಭಾಗಶಃ ಅಂಕೆಗಳ ಸಂಖ್ಯೆಗಿಂತ ಕಡಿಮೆಯಿರಬಹುದು;
/// ಅದನ್ನು ನಿರ್ಲಕ್ಷಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ಪೂರ್ಣ ಅಂಕೆಗಳನ್ನು ಮುದ್ರಿಸಲಾಗುತ್ತದೆ.ಪ್ರದರ್ಶಿತ ಅಂಕೆಗಳ ನಂತರ ಹೆಚ್ಚುವರಿ ಸೊನ್ನೆಗಳನ್ನು ಮುದ್ರಿಸಲು ಮಾತ್ರ ಇದನ್ನು ಬಳಸಲಾಗುತ್ತದೆ.
/// ಆದ್ದರಿಂದ 0 ರ `frac_digits` ಎಂದರೆ ಅದು ಕೊಟ್ಟಿರುವ ಅಂಕೆಗಳನ್ನು ಮಾತ್ರ ಮುದ್ರಿಸುತ್ತದೆ ಮತ್ತು ಬೇರೇನೂ ಇಲ್ಲ.
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // ಕೊನೆಯ ಅಂಕಿಯ ಸ್ಥಾನದ ಮೇಲೆ ನಿರ್ಬಂಧವಿದ್ದರೆ, `buf` ಅನ್ನು ವರ್ಚುವಲ್ ಸೊನ್ನೆಗಳೊಂದಿಗೆ ಎಡ-ಪ್ಯಾಡ್ ಎಂದು is ಹಿಸಲಾಗಿದೆ.
    // ವರ್ಚುವಲ್ ಸೊನ್ನೆಗಳ ಸಂಖ್ಯೆ, `nzeroes`, `max(0, exp + frac_digits - buf.len())` ಗೆ ಸಮನಾಗಿರುತ್ತದೆ, ಇದರಿಂದಾಗಿ ಕೊನೆಯ ಅಂಕಿಯ `exp - buf.len() - nzeroes` ನ ಸ್ಥಾನವು `-frac_digits` ಗಿಂತ ಹೆಚ್ಚಿಲ್ಲ:
    //
    //
    //                       |<-virtual->|
    //       | <----ಬಫ್----> |ಸೊನ್ನೆಗಳು |exp
    //    0. 1 2 3 4 5 6 7 8 9 _ _ _ _ _ _ x 10
    //    |                  |           |
    // 10 ^ exp 10^(exp-buf.len()) 10^(exp-buf.len()-nzeroes)
    //
    // `nzeroes` ಉಕ್ಕಿ ಹರಿಯುವುದನ್ನು ತಪ್ಪಿಸಲು ಪ್ರತಿಯೊಂದು ಪ್ರಕರಣಕ್ಕೂ ಪ್ರತ್ಯೇಕವಾಗಿ ಲೆಕ್ಕಹಾಕಲಾಗುತ್ತದೆ.
    //

    if exp <= 0 {
        // ಪ್ರದರ್ಶಿಸಲಾದ ಅಂಕೆಗಳ ಮೊದಲು ದಶಮಾಂಶ ಬಿಂದು: [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // ಸುರಕ್ಷತೆ: ನಾವು `..4` ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // ಸುರಕ್ಷತೆ: ನಾವು `..3` ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // ದಶಮಾಂಶ ಬಿಂದುವು ಪ್ರದರ್ಶಿಸಲಾದ ಅಂಕೆಗಳ ಒಳಗೆ ಇದೆ: [12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // ಸುರಕ್ಷತೆ: ನಾವು `..4` ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // ಸುರಕ್ಷತೆ: ನಾವು `..3` ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // ಪ್ರದರ್ಶಿತ ಅಂಕೆಗಳ ನಂತರ ದಶಮಾಂಶ ಬಿಂದು: [1234][____0000] ಅಥವಾ [1234][__][.][__].
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // ಸುರಕ್ಷತೆ: ನಾವು `..4` ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // ಸುರಕ್ಷತೆ: ನಾವು `..2` ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// ಕೊಟ್ಟಿರುವ ದಶಮಾಂಶ ಅಂಕೆಗಳು `0.<...buf...> * 10^exp` ಅನ್ನು ಘಾತೀಯ ರೂಪಕ್ಕೆ ಕನಿಷ್ಠ ನಿರ್ದಿಷ್ಟ ಸಂಖ್ಯೆಯ ಅಂಕೆಗಳೊಂದಿಗೆ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡುತ್ತದೆ.
///
/// `upper` `true` ಆಗಿದ್ದಾಗ, ಘಾತಾಂಕವನ್ನು `E` ನಿಂದ ಪೂರ್ವಪ್ರತ್ಯಯ ಮಾಡಲಾಗುತ್ತದೆ;ಇಲ್ಲದಿದ್ದರೆ ಅದು `e`.
/// ಫಲಿತಾಂಶವನ್ನು ಸರಬರಾಜು ಮಾಡಿದ ಭಾಗಗಳ ಶ್ರೇಣಿಗೆ ಸಂಗ್ರಹಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ಲಿಖಿತ ಭಾಗಗಳ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
///
/// `min_digits` `buf` ನಲ್ಲಿನ ನಿಜವಾದ ಮಹತ್ವದ ಅಂಕೆಗಳ ಸಂಖ್ಯೆಗಿಂತ ಕಡಿಮೆಯಿರಬಹುದು;
/// ಅದನ್ನು ನಿರ್ಲಕ್ಷಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ಪೂರ್ಣ ಅಂಕೆಗಳನ್ನು ಮುದ್ರಿಸಲಾಗುತ್ತದೆ.ಪ್ರದರ್ಶಿತ ಅಂಕೆಗಳ ನಂತರ ಹೆಚ್ಚುವರಿ ಸೊನ್ನೆಗಳನ್ನು ಮುದ್ರಿಸಲು ಮಾತ್ರ ಇದನ್ನು ಬಳಸಲಾಗುತ್ತದೆ.
/// ಹೀಗಾಗಿ, `min_digits == 0` ಎಂದರೆ ಅದು ಕೊಟ್ಟಿರುವ ಅಂಕೆಗಳನ್ನು ಮಾತ್ರ ಮುದ್ರಿಸುತ್ತದೆ ಮತ್ತು ಬೇರೇನೂ ಇಲ್ಲ.
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 x 10 ^ exp= 1.234 x 10 ^ (exp-1)
    let exp = exp as i32 - 1; // ಎಕ್ಸ್‌ಪ್ರೆಸ್ ಎಕ್ಸ್‌00 ಎಕ್ಸ್ ಆಗಿರುವಾಗ ಒಳಹರಿವು ತಪ್ಪಿಸಿ
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // ಸುರಕ್ಷತೆ: ನಾವು `..n + 2` ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// ಫಾರ್ಮ್ಯಾಟಿಂಗ್ ಆಯ್ಕೆಗಳಿಗೆ ಸಹಿ ಮಾಡಿ.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// 00 ಣಾತ್ಮಕ ಶೂನ್ಯೇತರ ಮೌಲ್ಯಗಳಿಗೆ ಮಾತ್ರ `-` ಅನ್ನು ಮುದ್ರಿಸುತ್ತದೆ.
    Minus, // -inf -1 0 0 1 inf nan
    /// ಯಾವುದೇ ನಕಾರಾತ್ಮಕ ಮೌಲ್ಯಗಳಿಗೆ ಮಾತ್ರ (ನಕಾರಾತ್ಮಕ ಶೂನ್ಯವನ್ನು ಒಳಗೊಂಡಂತೆ) `-` ಅನ್ನು ಮುದ್ರಿಸುತ್ತದೆ.
    MinusRaw, // -inf -1 -0 0 1 inf nan
    /// 00 ಣಾತ್ಮಕ ಶೂನ್ಯೇತರ ಮೌಲ್ಯಗಳಿಗೆ `-` ಅಥವಾ ಇಲ್ಲದಿದ್ದರೆ `+` ಅನ್ನು ಮುದ್ರಿಸುತ್ತದೆ.
    MinusPlus, // -inf -1 +0 +0 +1 + inf nan
    /// ಯಾವುದೇ negative ಣಾತ್ಮಕ ಮೌಲ್ಯಗಳಿಗೆ (ನಕಾರಾತ್ಮಕ ಶೂನ್ಯವನ್ನು ಒಳಗೊಂಡಂತೆ) `-` ಅಥವಾ `+` ಅನ್ನು ಮುದ್ರಿಸುತ್ತದೆ.
    MinusPlusRaw, // -inf -1 -0 +0 +1 + inf nan
}

/// ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಬೇಕಾದ ಚಿಹ್ನೆಗೆ ಅನುಗುಣವಾದ ಸ್ಥಿರ ಬೈಟ್ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
/// ಇದು `""`, `"+"` ಅಥವಾ `"-"` ಆಗಿರಬಹುದು.
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// ಕೊಟ್ಟಿರುವ ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಸಂಖ್ಯೆಯನ್ನು ದಶಮಾಂಶ ರೂಪಕ್ಕೆ ಕನಿಷ್ಠ ಸಂಖ್ಯೆಯ ಭಾಗಶಃ ಅಂಕೆಗಳೊಂದಿಗೆ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡುತ್ತದೆ.
/// ಕೊಟ್ಟಿರುವ ಬೈಟ್ ಬಫರ್ ಅನ್ನು ಸ್ಕ್ರಾಚ್ ಆಗಿ ಬಳಸುವಾಗ ಫಲಿತಾಂಶವನ್ನು ಸರಬರಾಜು ಮಾಡಲಾದ ಭಾಗಗಳ ಶ್ರೇಣಿಗೆ ಸಂಗ್ರಹಿಸಲಾಗುತ್ತದೆ.
/// `upper` ಪ್ರಸ್ತುತ ಬಳಕೆಯಾಗದಿದ್ದರೂ ಸೀಮಿತವಲ್ಲದ ಮೌಲ್ಯಗಳಾದ `inf` ಮತ್ತು `nan` ಅನ್ನು ಬದಲಾಯಿಸುವ future ನಿರ್ಧಾರಕ್ಕೆ ಬಿಡಲಾಗಿದೆ.
///
/// ಪ್ರದರ್ಶಿಸಬೇಕಾದ ಮೊದಲ ಭಾಗವು ಯಾವಾಗಲೂ `Part::Sign` ಆಗಿದೆ (ಯಾವುದೇ ಚಿಹ್ನೆಯನ್ನು ಪ್ರದರ್ಶಿಸದಿದ್ದರೆ ಅದು ಖಾಲಿ ಸ್ಟ್ರಿಂಗ್ ಆಗಿರಬಹುದು).
///
/// `format_shortest` ಆಧಾರವಾಗಿರುವ ಅಂಕಿಯ-ಪೀಳಿಗೆಯ ಕಾರ್ಯವಾಗಿರಬೇಕು.
/// ಅದು ಪ್ರಾರಂಭಿಸಿದ ಬಫರ್‌ನ ಭಾಗವನ್ನು ಅದು ಹಿಂದಿರುಗಿಸಬೇಕು.
/// ಇದಕ್ಕಾಗಿ ನೀವು ಬಹುಶಃ `strategy::grisu::format_shortest` ಅನ್ನು ಬಯಸುತ್ತೀರಿ.
///
/// `frac_digits` `v` ನಲ್ಲಿನ ನಿಜವಾದ ಭಾಗಶಃ ಅಂಕೆಗಳ ಸಂಖ್ಯೆಗಿಂತ ಕಡಿಮೆಯಿರಬಹುದು;
/// ಅದನ್ನು ನಿರ್ಲಕ್ಷಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ಪೂರ್ಣ ಅಂಕೆಗಳನ್ನು ಮುದ್ರಿಸಲಾಗುತ್ತದೆ.ಪ್ರದರ್ಶಿತ ಅಂಕೆಗಳ ನಂತರ ಹೆಚ್ಚುವರಿ ಸೊನ್ನೆಗಳನ್ನು ಮುದ್ರಿಸಲು ಮಾತ್ರ ಇದನ್ನು ಬಳಸಲಾಗುತ್ತದೆ.
/// ಆದ್ದರಿಂದ 0 ರ `frac_digits` ಎಂದರೆ ಅದು ಕೊಟ್ಟಿರುವ ಅಂಕೆಗಳನ್ನು ಮಾತ್ರ ಮುದ್ರಿಸುತ್ತದೆ ಮತ್ತು ಬೇರೇನೂ ಇಲ್ಲ.
///
/// ಬೈಟ್ ಬಫರ್ ಕನಿಷ್ಠ `MAX_SIG_DIGITS` ಬೈಟ್‌ಗಳಷ್ಟು ಉದ್ದವಿರಬೇಕು.
/// `frac_digits = 10` ನೊಂದಿಗೆ `[+][0.][0000][2][0000]` ನಂತಹ ಕೆಟ್ಟ ಪ್ರಕರಣದಿಂದಾಗಿ ಕನಿಷ್ಠ 4 ಭಾಗಗಳು ಲಭ್ಯವಿರಬೇಕು.
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // ಸುರಕ್ಷತೆ: ನಾವು `..1` ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // ಸುರಕ್ಷತೆ: ನಾವು `..1` ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // ಸುರಕ್ಷತೆ: ನಾವು `..2` ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // ಸುರಕ್ಷತೆ: ನಾವು `..1` ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// ಕೊಟ್ಟಿರುವ ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಸಂಖ್ಯೆಯನ್ನು ದಶಮಾಂಶ ರೂಪಕ್ಕೆ ಅಥವಾ ಘಾತೀಯ ರೂಪಕ್ಕೆ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡುತ್ತದೆ, ಇದರ ಪರಿಣಾಮವಾಗಿ ಘಾತಾಂಕವನ್ನು ಅವಲಂಬಿಸಿರುತ್ತದೆ.
/// ಕೊಟ್ಟಿರುವ ಬೈಟ್ ಬಫರ್ ಅನ್ನು ಸ್ಕ್ರಾಚ್ ಆಗಿ ಬಳಸುವಾಗ ಫಲಿತಾಂಶವನ್ನು ಸರಬರಾಜು ಮಾಡಲಾದ ಭಾಗಗಳ ಶ್ರೇಣಿಗೆ ಸಂಗ್ರಹಿಸಲಾಗುತ್ತದೆ.
/// `upper` ಸೀಮಿತವಲ್ಲದ ಮೌಲ್ಯಗಳ (`inf` ಮತ್ತು `nan`) ಅಥವಾ ಘಾತೀಯ ಪೂರ್ವಪ್ರತ್ಯಯದ (`e` ಅಥವಾ `E`) ಪ್ರಕರಣವನ್ನು ನಿರ್ಧರಿಸಲು ಬಳಸಲಾಗುತ್ತದೆ.
/// ಪ್ರದರ್ಶಿಸಬೇಕಾದ ಮೊದಲ ಭಾಗವು ಯಾವಾಗಲೂ `Part::Sign` ಆಗಿದೆ (ಯಾವುದೇ ಚಿಹ್ನೆಯನ್ನು ಪ್ರದರ್ಶಿಸದಿದ್ದರೆ ಅದು ಖಾಲಿ ಸ್ಟ್ರಿಂಗ್ ಆಗಿರಬಹುದು).
///
/// `format_shortest` ಆಧಾರವಾಗಿರುವ ಅಂಕಿಯ-ಪೀಳಿಗೆಯ ಕಾರ್ಯವಾಗಿರಬೇಕು.
/// ಅದು ಪ್ರಾರಂಭಿಸಿದ ಬಫರ್‌ನ ಭಾಗವನ್ನು ಅದು ಹಿಂದಿರುಗಿಸಬೇಕು.
/// ಇದಕ್ಕಾಗಿ ನೀವು ಬಹುಶಃ `strategy::grisu::format_shortest` ಅನ್ನು ಬಯಸುತ್ತೀರಿ.
///
/// `dec_bounds` ಒಂದು ಟಪಲ್ `(lo, hi)` ಆಗಿದೆ, ಅಂದರೆ `10^lo <= V < 10^hi` ಇದ್ದಾಗ ಮಾತ್ರ ಸಂಖ್ಯೆಯನ್ನು ದಶಮಾಂಶವಾಗಿ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಲಾಗುತ್ತದೆ.
/// ನಿಜವಾದ `v` ಬದಲಿಗೆ ಇದು *ಸ್ಪಷ್ಟ*`V` ಎಂಬುದನ್ನು ಗಮನಿಸಿ!ಆದ್ದರಿಂದ ಘಾತೀಯ ರೂಪದಲ್ಲಿ ಯಾವುದೇ ಮುದ್ರಿತ ಘಾತಾಂಕವು ಈ ವ್ಯಾಪ್ತಿಯಲ್ಲಿರಲು ಸಾಧ್ಯವಿಲ್ಲ, ಯಾವುದೇ ಗೊಂದಲವನ್ನು ತಪ್ಪಿಸುತ್ತದೆ.
///
///
/// ಬೈಟ್ ಬಫರ್ ಕನಿಷ್ಠ `MAX_SIG_DIGITS` ಬೈಟ್‌ಗಳಷ್ಟು ಉದ್ದವಿರಬೇಕು.
/// `[+][1][.][2345][e][-][6]` ನಂತಹ ಕೆಟ್ಟ ಪ್ರಕರಣದಿಂದಾಗಿ ಕನಿಷ್ಠ 6 ಭಾಗಗಳು ಲಭ್ಯವಿರಬೇಕು.
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // ಸುರಕ್ಷತೆ: ನಾವು `..1` ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // ಸುರಕ್ಷತೆ: ನಾವು `..1` ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // ಸುರಕ್ಷತೆ: ನಾವು `..1` ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// ಕೊಟ್ಟಿರುವ ಡಿಕೋಡ್ ಘಾತಾಂಕದಿಂದ ಲೆಕ್ಕಹಾಕಲಾದ ಗರಿಷ್ಠ ಬಫರ್ ಗಾತ್ರಕ್ಕೆ ಬದಲಾಗಿ ಕಚ್ಚಾ ಅಂದಾಜು (ಮೇಲಿನ ಬೌಂಡ್) ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
///
/// ನಿಖರವಾದ ಮಿತಿ:
///
/// - `exp < 0` ಇದ್ದಾಗ, ಗರಿಷ್ಠ ಉದ್ದ `ceil(log_10 (5^-exp * (2^64 - 1)))` ಆಗಿದೆ.
/// - `exp >= 0` ಇದ್ದಾಗ, ಗರಿಷ್ಠ ಉದ್ದ `ceil(log_10 (2^exp * (2^64 - 1)))` ಆಗಿದೆ.
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` ಇದು `ceil(log_10 (2^64 - 1)) + ceil(exp *log_10 x)` ಗಿಂತ ಕಡಿಮೆಯಿದೆ, ಇದು `20 + (1 + exp* log_10 x)` ಗಿಂತ ಕಡಿಮೆಯಿರುತ್ತದೆ.
/// `log_10 2 < 5/16` ಮತ್ತು `log_10 5 < 12/16` ಎಂಬ ಸತ್ಯಗಳನ್ನು ನಾವು ಬಳಸುತ್ತೇವೆ, ಅದು ನಮ್ಮ ಉದ್ದೇಶಗಳಿಗಾಗಿ ಸಾಕು.
///
/// ನಮಗೆ ಇದು ಏಕೆ ಬೇಕು?ಕೊನೆಯ ಅಂಕಿಯ ನಿರ್ಬಂಧದಿಂದ ಸೀಮಿತವಾಗದ ಹೊರತು `format_exact` ಕಾರ್ಯಗಳು ಸಂಪೂರ್ಣ ಬಫರ್ ಅನ್ನು ತುಂಬುತ್ತವೆ, ಆದರೆ ವಿನಂತಿಸಿದ ಅಂಕೆಗಳ ಸಂಖ್ಯೆ ಹಾಸ್ಯಾಸ್ಪದವಾಗಿ ದೊಡ್ಡದಾಗಿದೆ (ಅಂದರೆ, 30,000 ಅಂಕೆಗಳು).
///
/// ಬಹುಪಾಲು ಬಫರ್ ಸೊನ್ನೆಗಳಿಂದ ತುಂಬಿರುತ್ತದೆ, ಆದ್ದರಿಂದ ನಾವು ಎಲ್ಲಾ ಬಫರ್ ಅನ್ನು ಮೊದಲೇ ನಿಯೋಜಿಸಲು ಬಯಸುವುದಿಲ್ಲ.
/// ಪರಿಣಾಮವಾಗಿ, ಯಾವುದೇ ವಾದಗಳಿಗೆ,
/// `f64` ಗೆ 826 ಬೈಟ್‌ಗಳ ಬಫರ್ ಸಾಕಾಗಬೇಕು.ಕೆಟ್ಟ ಪ್ರಕರಣಕ್ಕೆ ನಿಜವಾದ ಸಂಖ್ಯೆಯೊಂದಿಗೆ ಇದನ್ನು ಹೋಲಿಕೆ ಮಾಡಿ: 770 ಬೈಟ್‌ಗಳು (ಯಾವಾಗ `exp = -1074`).
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಸಂಖ್ಯೆಯನ್ನು ನಿಖರವಾಗಿ ಕೊಟ್ಟಿರುವ ಗಮನಾರ್ಹ ಅಂಕೆಗಳೊಂದಿಗೆ ಘಾತೀಯ ರೂಪಕ್ಕೆ ನೀಡಿದ ಸ್ವರೂಪಗಳು.
/// ಕೊಟ್ಟಿರುವ ಬೈಟ್ ಬಫರ್ ಅನ್ನು ಸ್ಕ್ರಾಚ್ ಆಗಿ ಬಳಸುವಾಗ ಫಲಿತಾಂಶವನ್ನು ಸರಬರಾಜು ಮಾಡಲಾದ ಭಾಗಗಳ ಶ್ರೇಣಿಗೆ ಸಂಗ್ರಹಿಸಲಾಗುತ್ತದೆ.
/// `upper` ಘಾತೀಯ ಪೂರ್ವಪ್ರತ್ಯಯದ (`e` ಅಥವಾ `E`) ಪ್ರಕರಣವನ್ನು ನಿರ್ಧರಿಸಲು ಬಳಸಲಾಗುತ್ತದೆ.
/// ಪ್ರದರ್ಶಿಸಬೇಕಾದ ಮೊದಲ ಭಾಗವು ಯಾವಾಗಲೂ `Part::Sign` ಆಗಿದೆ (ಯಾವುದೇ ಚಿಹ್ನೆಯನ್ನು ಪ್ರದರ್ಶಿಸದಿದ್ದರೆ ಅದು ಖಾಲಿ ಸ್ಟ್ರಿಂಗ್ ಆಗಿರಬಹುದು).
///
/// `format_exact` ಆಧಾರವಾಗಿರುವ ಅಂಕಿಯ-ಪೀಳಿಗೆಯ ಕಾರ್ಯವಾಗಿರಬೇಕು.
/// ಅದು ಪ್ರಾರಂಭಿಸಿದ ಬಫರ್‌ನ ಭಾಗವನ್ನು ಅದು ಹಿಂದಿರುಗಿಸಬೇಕು.
/// ಇದಕ್ಕಾಗಿ ನೀವು ಬಹುಶಃ `strategy::grisu::format_exact` ಅನ್ನು ಬಯಸುತ್ತೀರಿ.
///
/// `ndigits` ತುಂಬಾ ದೊಡ್ಡದಾಗದಿದ್ದರೆ ಬೈಟ್ ಬಫರ್ ಕನಿಷ್ಠ `ndigits` ಬೈಟ್‌ಗಳಷ್ಟು ಉದ್ದವಾಗಿರಬೇಕು, ನಿಗದಿತ ಸಂಖ್ಯೆಯ ಅಂಕೆಗಳನ್ನು ಮಾತ್ರ ಎಂದಿಗೂ ಬರೆಯಲಾಗುವುದಿಲ್ಲ.
/// (`f64` ಗಾಗಿ ಟಿಪ್ಪಿಂಗ್ ಪಾಯಿಂಟ್ ಸುಮಾರು 800, ಆದ್ದರಿಂದ 1000 ಬೈಟ್‌ಗಳು ಸಾಕು.) `[+][1][.][2345][e][-][6]` ನಂತಹ ಕೆಟ್ಟ ಪ್ರಕರಣದಿಂದಾಗಿ ಕನಿಷ್ಠ 6 ಭಾಗಗಳು ಲಭ್ಯವಿರಬೇಕು.
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // ಸುರಕ್ಷತೆ: ನಾವು `..1` ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // ಸುರಕ್ಷತೆ: ನಾವು `..1` ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // ಸುರಕ್ಷತೆ: ನಾವು `..3` ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // ಸುರಕ್ಷತೆ: ನಾವು `..1` ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಸಂಖ್ಯೆಯನ್ನು ದಶಮಾಂಶ ರೂಪಕ್ಕೆ ನೀಡಿದ ಸ್ವರೂಪಗಳು ನಿಖರವಾಗಿ ಕೊಟ್ಟಿರುವ ಭಾಗಶಃ ಅಂಕೆಗಳೊಂದಿಗೆ.
/// ಕೊಟ್ಟಿರುವ ಬೈಟ್ ಬಫರ್ ಅನ್ನು ಸ್ಕ್ರಾಚ್ ಆಗಿ ಬಳಸುವಾಗ ಫಲಿತಾಂಶವನ್ನು ಸರಬರಾಜು ಮಾಡಲಾದ ಭಾಗಗಳ ಶ್ರೇಣಿಗೆ ಸಂಗ್ರಹಿಸಲಾಗುತ್ತದೆ.
/// `upper` ಪ್ರಸ್ತುತ ಬಳಕೆಯಾಗದಿದ್ದರೂ ಸೀಮಿತವಲ್ಲದ ಮೌಲ್ಯಗಳಾದ `inf` ಮತ್ತು `nan` ಅನ್ನು ಬದಲಾಯಿಸುವ future ನಿರ್ಧಾರಕ್ಕೆ ಬಿಡಲಾಗಿದೆ.
/// ಪ್ರದರ್ಶಿಸಬೇಕಾದ ಮೊದಲ ಭಾಗವು ಯಾವಾಗಲೂ `Part::Sign` ಆಗಿದೆ (ಯಾವುದೇ ಚಿಹ್ನೆಯನ್ನು ಪ್ರದರ್ಶಿಸದಿದ್ದರೆ ಅದು ಖಾಲಿ ಸ್ಟ್ರಿಂಗ್ ಆಗಿರಬಹುದು).
///
/// `format_exact` ಆಧಾರವಾಗಿರುವ ಅಂಕಿಯ-ಪೀಳಿಗೆಯ ಕಾರ್ಯವಾಗಿರಬೇಕು.
/// ಅದು ಪ್ರಾರಂಭಿಸಿದ ಬಫರ್‌ನ ಭಾಗವನ್ನು ಅದು ಹಿಂದಿರುಗಿಸಬೇಕು.
/// ಇದಕ್ಕಾಗಿ ನೀವು ಬಹುಶಃ `strategy::grisu::format_exact` ಅನ್ನು ಬಯಸುತ್ತೀರಿ.
///
/// `frac_digits` ತುಂಬಾ ದೊಡ್ಡದಾಗಿದ್ದರೆ ಬೈಟ್ ಬಫರ್ output ಟ್‌ಪುಟ್‌ಗೆ ಸಾಕಷ್ಟು ಇರಬೇಕು, ನಿಗದಿತ ಸಂಖ್ಯೆಯ ಅಂಕೆಗಳನ್ನು ಮಾತ್ರ ಎಂದಿಗೂ ಬರೆಯಲಾಗುವುದಿಲ್ಲ.
/// (`f64` ಗಾಗಿ ಟಿಪ್ಪಿಂಗ್ ಪಾಯಿಂಟ್ ಸುಮಾರು 800, ಮತ್ತು 1000 ಬೈಟ್‌ಗಳು ಸಾಕಷ್ಟು ಇರಬೇಕು.) `frac_digits = 10` ನೊಂದಿಗೆ `[+][0.][0000][2][0000]` ನಂತಹ ಕೆಟ್ಟ ಪ್ರಕರಣದಿಂದಾಗಿ ಕನಿಷ್ಠ 4 ಭಾಗಗಳು ಲಭ್ಯವಿರಬೇಕು.
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // ಸುರಕ್ಷತೆ: ನಾವು `..1` ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // ಸುರಕ್ಷತೆ: ನಾವು `..1` ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // ಸುರಕ್ಷತೆ: ನಾವು `..2` ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // ಸುರಕ್ಷತೆ: ನಾವು `..1` ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // `frac_digits` ಹಾಸ್ಯಾಸ್ಪದವಾಗಿ ದೊಡ್ಡದಾಗಿದೆ *.
            // `format_exact` ಈ ಸಂದರ್ಭದಲ್ಲಿ ಅಂಕಿಗಳನ್ನು ರೆಂಡರಿಂಗ್ ಮಾಡುವುದನ್ನು ಕೊನೆಗೊಳಿಸುತ್ತದೆ, ಏಕೆಂದರೆ ನಾವು `maxlen` ನಿಂದ ಕಟ್ಟುನಿಟ್ಟಾಗಿ ಸೀಮಿತರಾಗಿದ್ದೇವೆ.
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // ನಿರ್ಬಂಧವನ್ನು ಪೂರೈಸಲಾಗಲಿಲ್ಲ, ಆದ್ದರಿಂದ ಇದು `exp` ಇರಲಿ ಶೂನ್ಯದಂತೆ ನಿರೂಪಿಸಬೇಕು.
                // ಅಂತಿಮ ರೌಂಡಿಂಗ್-ಅಪ್ ನಂತರ ಮಾತ್ರ ನಿರ್ಬಂಧವನ್ನು ಪೂರೈಸಲಾಗಿದೆ ಎಂಬ ಪ್ರಕರಣವನ್ನು ಇದು ಒಳಗೊಂಡಿಲ್ಲ;ಇದು `exp = limit + 1` ನೊಂದಿಗೆ ನಿಯಮಿತ ಪ್ರಕರಣವಾಗಿದೆ.
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // ಸುರಕ್ಷತೆ: ನಾವು `..2` ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // ಸುರಕ್ಷತೆ: ನಾವು `..1` ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}