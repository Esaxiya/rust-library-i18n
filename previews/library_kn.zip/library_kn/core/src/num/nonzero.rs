//! ಶೂನ್ಯಕ್ಕೆ ಸಮನಾಗಿರಬಾರದು ಎಂದು ತಿಳಿದಿರುವ ಪೂರ್ಣಾಂಕದ ವ್ಯಾಖ್ಯಾನಗಳು.

use crate::fmt;
use crate::ops::{BitOr, BitOrAssign, Div, Rem};
use crate::str::FromStr;

use super::from_str_radix;
use super::{IntErrorKind, ParseIntError};
use crate::intrinsics;

macro_rules! impl_nonzero_fmt {
    ( #[$stability: meta] ( $( $Trait: ident ),+ ) for $Ty: ident ) => {
        $(
            #[$stability]
            impl fmt::$Trait for $Ty {
                #[inline]
                fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                    self.get().fmt(f)
                }
            }
        )+
    }
}

macro_rules! nonzero_integers {
    ( $( #[$stability: meta] $Ty: ident($Int: ty); )+ ) => {
        $(
            /// ಶೂನ್ಯಕ್ಕೆ ಸಮನಾಗಿರಬಾರದು ಎಂದು ತಿಳಿದಿರುವ ಒಂದು ಪೂರ್ಣಾಂಕ.
            ///
            /// ಇದು ಕೆಲವು ಮೆಮೊರಿ ಲೇ layout ಟ್ ಆಪ್ಟಿಮೈಸೇಶನ್ ಅನ್ನು ಶಕ್ತಗೊಳಿಸುತ್ತದೆ.
            #[doc = concat!("For example, `Option<", stringify!($Ty), ">` is the same size as `", stringify!($Int), "`:")]
            /// ```rust
            /// std::mem::size_of ಬಳಸಿ;
            #[doc = concat!("assert_eq!(size_of::<Option<core::num::", stringify!($Ty), ">>(), size_of::<", stringify!($Int), ">());")]
            /// ```
            #[$stability]
            #[derive(Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
            #[repr(transparent)]
            #[rustc_layout_scalar_valid_range_start(1)]
            #[rustc_nonnull_optimization_guaranteed]
            pub struct $Ty($Int);

            impl $Ty {
                /// ಮೌಲ್ಯವನ್ನು ಪರಿಶೀಲಿಸದೆ ಶೂನ್ಯೇತರವನ್ನು ರಚಿಸುತ್ತದೆ.
                ///
                /// # Safety
                ///
                /// ಮೌಲ್ಯವು ಶೂನ್ಯವಾಗಿರಬಾರದು.
                #[$stability]
                #[rustc_const_stable(feature = "nonzero", since = "1.34.0")]
                #[inline]
                pub const unsafe fn new_unchecked(n: $Int) -> Self {
                    // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರಿಂದ ಇದು ಸುರಕ್ಷಿತವಾಗಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.
                    unsafe { Self(n) }
                }

                /// ಕೊಟ್ಟಿರುವ ಮೌಲ್ಯವು ಶೂನ್ಯವಾಗಿಲ್ಲದಿದ್ದರೆ ಶೂನ್ಯೇತರವನ್ನು ರಚಿಸುತ್ತದೆ.
                #[$stability]
                #[rustc_const_stable(feature = "const_nonzero_int_methods", since = "1.47.0")]
                #[inline]
                pub const fn new(n: $Int) -> Option<Self> {
                    if n != 0 {
                        // ಸುರಕ್ಷತೆ: ಯಾವುದೇ `0` ಇಲ್ಲ ಎಂದು ನಾವು ಪರಿಶೀಲಿಸಿದ್ದೇವೆ
                        Some(unsafe { Self(n) })
                    } else {
                        None
                    }
                }

                /// ಮೌಲ್ಯವನ್ನು ಪ್ರಾಚೀನ ಪ್ರಕಾರವಾಗಿ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
                #[$stability]
                #[inline]
                #[rustc_const_stable(feature = "nonzero", since = "1.34.0")]
                pub const fn get(self) -> $Int {
                    self.0
                }

            }

            #[stable(feature = "from_nonzero", since = "1.31.0")]
            impl From<$Ty> for $Int {
                #[doc = concat!("Converts a `", stringify!($Ty), "` into an `", stringify!($Int), "`")]
                #[inline]
                fn from(nonzero: $Ty) -> Self {
                    nonzero.0
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr for $Ty {
                type Output = Self;
                #[inline]
                fn bitor(self, rhs: Self) -> Self::Output {
                    // ಸುರಕ್ಷತೆ: `self` ಮತ್ತು `rhs` ಎರಡೂ ನಾನ್ಜೆರೋ ಆಗಿರುವುದರಿಂದ, ದಿ
                    // ಬಿಟ್‌ವೈಸ್‌ನ ಫಲಿತಾಂಶ-ಅಥವಾ ನಾನ್‌ಜೆರೋ ಆಗಿರುತ್ತದೆ.
                    unsafe { $Ty::new_unchecked(self.get() | rhs.get()) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr<$Int> for $Ty {
                type Output = Self;
                #[inline]
                fn bitor(self, rhs: $Int) -> Self::Output {
                    // ಸುರಕ್ಷತೆ: `self` ನಾನ್ಜೆರೋ ಆಗಿರುವುದರಿಂದ, ಇದರ ಫಲಿತಾಂಶ
                    // ಬಿಟ್‌ವೈಸ್-ಅಥವಾ `rhs` ಮೌಲ್ಯವನ್ನು ಲೆಕ್ಕಿಸದೆ ನಾನ್‌ಜೆರೋ ಆಗಿರುತ್ತದೆ.
                    //
                    unsafe { $Ty::new_unchecked(self.get() | rhs) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr<$Ty> for $Int {
                type Output = $Ty;
                #[inline]
                fn bitor(self, rhs: $Ty) -> Self::Output {
                    // ಸುರಕ್ಷತೆ: `rhs` ನಾನ್ಜೆರೋ ಆಗಿರುವುದರಿಂದ, ಇದರ ಫಲಿತಾಂಶ
                    // ಬಿಟ್‌ವೈಸ್-ಅಥವಾ `self` ಮೌಲ್ಯವನ್ನು ಲೆಕ್ಕಿಸದೆ ನಾನ್‌ಜೆರೋ ಆಗಿರುತ್ತದೆ.
                    //
                    unsafe { $Ty::new_unchecked(self | rhs.get()) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOrAssign for $Ty {
                #[inline]
                fn bitor_assign(&mut self, rhs: Self) {
                    *self = *self | rhs;
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOrAssign<$Int> for $Ty {
                #[inline]
                fn bitor_assign(&mut self, rhs: $Int) {
                    *self = *self | rhs;
                }
            }

            impl_nonzero_fmt! {
                #[$stability] (Debug, Display, Binary, Octal, LowerHex, UpperHex) for $Ty
            }
        )+
    }
}

nonzero_integers! {
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU8(u8);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU16(u16);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU32(u32);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU64(u64);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU128(u128);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroUsize(usize);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI8(i8);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI16(i16);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI32(i32);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI64(i64);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI128(i128);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroIsize(isize);
}

macro_rules! from_str_radix_nzint_impl {
    ($($t:ty)*) => {$(
        #[stable(feature = "nonzero_parse", since = "1.35.0")]
        impl FromStr for $t {
            type Err = ParseIntError;
            fn from_str(src: &str) -> Result<Self, Self::Err> {
                Self::new(from_str_radix(src, 10)?)
                    .ok_or(ParseIntError {
                        kind: IntErrorKind::Zero
                    })
            }
        }
    )*}
}

from_str_radix_nzint_impl! { NonZeroU8 NonZeroU16 NonZeroU32 NonZeroU64 NonZeroU128 NonZeroUsize
NonZeroI8 NonZeroI16 NonZeroI32 NonZeroI64 NonZeroI128 NonZeroIsize }

macro_rules! nonzero_leading_trailing_zeros {
    ( $( $Ty: ident($Uint: ty) , $LeadingTestExpr:expr ;)+ ) => {
        $(
            impl $Ty {
                /// `self` ನ ಬೈನರಿ ಪ್ರಾತಿನಿಧ್ಯದಲ್ಲಿ ಪ್ರಮುಖ ಸೊನ್ನೆಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
                ///
                /// ಅನೇಕ ವಾಸ್ತುಶಿಲ್ಪಗಳಲ್ಲಿ, ಈ ಕಾರ್ಯವು ಆಧಾರವಾಗಿರುವ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರದಲ್ಲಿ `leading_zeros()` ಗಿಂತ ಉತ್ತಮವಾಗಿ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ, ಏಕೆಂದರೆ ಶೂನ್ಯದ ವಿಶೇಷ ನಿರ್ವಹಣೆಯನ್ನು ತಪ್ಪಿಸಬಹುದು.
                ///
                /// # Examples
                ///
                /// ಮೂಲ ಬಳಕೆ:
                ///
                /// ```
                /// #![feature(nonzero_leading_trailing_zeros)]
                #[doc = concat!("let n = std::num::", stringify!($Ty), "::new(", stringify!($LeadingTestExpr), ").unwrap();")]
                /// assert_eq!(n.leading_zeros(), 0);
                /// ```
                #[unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[rustc_const_unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[inline]
                pub const fn leading_zeros(self) -> u32 {
                    // ಸುರಕ್ಷತೆ: `self` ಶೂನ್ಯವಾಗಿರಲು ಸಾಧ್ಯವಿಲ್ಲದ ಕಾರಣ ctlz_nonzero ಎಂದು ಕರೆಯುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ
                    unsafe { intrinsics::ctlz_nonzero(self.0 as $Uint) as u32 }
                }

                /// `self` ನ ಬೈನರಿ ಪ್ರಾತಿನಿಧ್ಯದಲ್ಲಿ ಹಿಂದುಳಿದ ಸೊನ್ನೆಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
                ///
                /// ಅನೇಕ ವಾಸ್ತುಶಿಲ್ಪಗಳಲ್ಲಿ, ಈ ಕಾರ್ಯವು ಆಧಾರವಾಗಿರುವ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರದಲ್ಲಿ `trailing_zeros()` ಗಿಂತ ಉತ್ತಮವಾಗಿ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ, ಏಕೆಂದರೆ ಶೂನ್ಯದ ವಿಶೇಷ ನಿರ್ವಹಣೆಯನ್ನು ತಪ್ಪಿಸಬಹುದು.
                ///
                ///
                /// # Examples
                ///
                /// ಮೂಲ ಬಳಕೆ:
                ///
                /// ```
                /// #![feature(nonzero_leading_trailing_zeros)]
                #[doc = concat!("let n = std::num::", stringify!($Ty), "::new(0b0101000).unwrap();")]
                /// assert_eq!(n.trailing_zeros(), 3);
                /// ```
                #[unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[rustc_const_unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[inline]
                pub const fn trailing_zeros(self) -> u32 {
                    // ಸುರಕ್ಷತೆ: `self` ಶೂನ್ಯವಾಗಿರಲು ಸಾಧ್ಯವಿಲ್ಲದ ಕಾರಣ cttz_nonzero ಎಂದು ಕರೆಯುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ
                    unsafe { intrinsics::cttz_nonzero(self.0 as $Uint) as u32 }
                }

            }
        )+
    }
}

nonzero_leading_trailing_zeros! {
    NonZeroU8(u8), u8::MAX;
    NonZeroU16(u16), u16::MAX;
    NonZeroU32(u32), u32::MAX;
    NonZeroU64(u64), u64::MAX;
    NonZeroU128(u128), u128::MAX;
    NonZeroUsize(usize), usize::MAX;
    NonZeroI8(u8), -1i8;
    NonZeroI16(u16), -1i16;
    NonZeroI32(u32), -1i32;
    NonZeroI64(u64), -1i64;
    NonZeroI128(u128), -1i128;
    NonZeroIsize(usize), -1isize;
}

macro_rules! nonzero_integers_div {
    ( $( $Ty: ident($Int: ty); )+ ) => {
        $(
            #[stable(feature = "nonzero_div", since = "1.51.0")]
            impl Div<$Ty> for $Int {
                type Output = $Int;
                /// ಈ ಕಾರ್ಯಾಚರಣೆಯು ಶೂನ್ಯದ ಕಡೆಗೆ ಸುತ್ತುತ್ತದೆ, ನಿಖರ ಫಲಿತಾಂಶದ ಯಾವುದೇ ಭಾಗ ಭಾಗವನ್ನು ಮೊಟಕುಗೊಳಿಸುತ್ತದೆ ಮತ್ತು panic ಗೆ ಸಾಧ್ಯವಿಲ್ಲ.
                ///
                #[inline]
                fn div(self, other: $Ty) -> $Int {
                    // ಸುರಕ್ಷತೆ: `other` ನಾನ್ಜೆರೋ ಆಗಿರುವುದರಿಂದ ಶೂನ್ಯದಿಂದ ಡಿವ್ ಅನ್ನು ಪರಿಶೀಲಿಸಲಾಗುತ್ತದೆ,
                    // ಮತ್ತು MIN/-1 ಅನ್ನು ಪರಿಶೀಲಿಸಲಾಗುತ್ತದೆ ಏಕೆಂದರೆ `self` ಸಹಿ ಮಾಡದ ಇಂಟ್ ಆಗಿದೆ.
                    unsafe { crate::intrinsics::unchecked_div(self, other.get()) }
                }
            }

            #[stable(feature = "nonzero_div", since = "1.51.0")]
            impl Rem<$Ty> for $Int {
                type Output = $Int;
                /// ಈ ಕಾರ್ಯಾಚರಣೆಯು `n % d == n - (n / d) * d` ಅನ್ನು ತೃಪ್ತಿಪಡಿಸುತ್ತದೆ ಮತ್ತು panic ಅನ್ನು ಸಾಧ್ಯವಿಲ್ಲ.
                #[inline]
                fn rem(self, other: $Ty) -> $Int {
                    // ಸುರಕ್ಷತೆ: `other` ನಾನ್ಜೆರೋ ಆಗಿರುವುದರಿಂದ ಶೂನ್ಯದಿಂದ ರೆಮ್ ಅನ್ನು ಪರಿಶೀಲಿಸಲಾಗುತ್ತದೆ,
                    // ಮತ್ತು MIN/-1 ಅನ್ನು ಪರಿಶೀಲಿಸಲಾಗುತ್ತದೆ ಏಕೆಂದರೆ `self` ಸಹಿ ಮಾಡದ ಇಂಟ್ ಆಗಿದೆ.
                    unsafe { crate::intrinsics::unchecked_rem(self, other.get()) }
                }
            }
        )+
    }
}

nonzero_integers_div! {
    NonZeroU8(u8);
    NonZeroU16(u16);
    NonZeroU32(u32);
    NonZeroU64(u64);
    NonZeroU128(u128);
    NonZeroUsize(usize);
}

macro_rules! nonzero_unsigned_is_power_of_two {
    ( $( $Ty: ident )+ ) => {
        $(
            impl $Ty {

                /// ಕೆಲವು `k` ಗಾಗಿ `self == (1 << k)` ಇದ್ದರೆ ಮಾತ್ರ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
                ///
                /// ಅನೇಕ ವಾಸ್ತುಶಿಲ್ಪಗಳಲ್ಲಿ, ಈ ಕಾರ್ಯವು ಆಧಾರವಾಗಿರುವ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರದಲ್ಲಿ `is_power_of_two()` ಗಿಂತ ಉತ್ತಮವಾಗಿ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ, ಏಕೆಂದರೆ ಶೂನ್ಯದ ವಿಶೇಷ ನಿರ್ವಹಣೆಯನ್ನು ತಪ್ಪಿಸಬಹುದು.
                ///
                ///
                /// # Examples
                ///
                /// ಮೂಲ ಬಳಕೆ:
                ///
                /// ```
                /// #![feature(nonzero_is_power_of_two)]
                ///
                #[doc = concat!("let eight = std::num::", stringify!($Ty), "::new(8).unwrap();")]
                /// assert!(eight.is_power_of_two());
                #[doc = concat!("let ten = std::num::", stringify!($Ty), "::new(10).unwrap();")]
                /// assert!(!ten.is_power_of_two());
                /// ```
                #[unstable(feature = "nonzero_is_power_of_two", issue = "81106")]
                #[inline]
                pub const fn is_power_of_two(self) -> bool {
                    // LLVM 11 ಇಲ್ಲಿ ಕಂಡುಬರುವ ಅನುಷ್ಠಾನಕ್ಕೆ `unchecked_sub(x, 1) & x == 0` ಅನ್ನು ಸಾಮಾನ್ಯಗೊಳಿಸುತ್ತದೆ.
                    // ಮೂಲ x86-64 ಗುರಿಯಲ್ಲಿ, ಇದು ಶೂನ್ಯ ಪರಿಶೀಲನೆಗಾಗಿ 3 ಸೂಚನೆಗಳನ್ನು ಉಳಿಸುತ್ತದೆ.
                    // BMI1 ನೊಂದಿಗೆ x86_64 ನಲ್ಲಿ, ನಾನ್‌ಜೆರೋ ಆಗಿರುವುದರಿಂದ ಅದು `BLSR` ಗೆ ಕೋಡೆಜೆನ್ ಅನ್ನು ಅನುಮತಿಸುತ್ತದೆ, ಇದು ಆಧಾರವಾಗಿರುವ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರದ `POPCNT` ಅನುಷ್ಠಾನಕ್ಕೆ ಹೋಲಿಸಿದರೆ ಸೂಚನೆಯನ್ನು ಉಳಿಸುತ್ತದೆ.
                    //

                    intrinsics::ctpop(self.get()) < 2
                }

            }
        )+
    }
}

nonzero_unsigned_is_power_of_two! { NonZeroU8 NonZeroU16 NonZeroU32 NonZeroU64 NonZeroU128 NonZeroUsize }