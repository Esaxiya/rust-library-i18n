//! ಅವಿಭಾಜ್ಯ ಪ್ರಕಾರಗಳಿಗೆ ಪರಿವರ್ತಿಸಲು ದೋಷ ಪ್ರಕಾರಗಳು.

use crate::convert::Infallible;
use crate::fmt;

/// ಪರಿಶೀಲಿಸಿದ ಸಮಗ್ರ ಪ್ರಕಾರದ ಪರಿವರ್ತನೆ ವಿಫಲವಾದಾಗ ದೋಷ ಪ್ರಕಾರ ಮರಳಿದೆ.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // `Infallible` `!` ಗೆ ಅಲಿಯಾಸ್ ಆಗಿರುವಾಗ ಮೇಲಿನ `From<Infallible> for TryFromIntError` ನಂತಹ ಕೋಡ್ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತಿದೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ಒತ್ತಾಯಕ್ಕಿಂತ ಹೆಚ್ಚಾಗಿ ಹೊಂದಾಣಿಕೆ ಮಾಡಿ.
        //
        //
        match never {}
    }
}

/// ಪೂರ್ಣಾಂಕವನ್ನು ಪಾರ್ಸ್ ಮಾಡುವಾಗ ಹಿಂತಿರುಗಿಸಬಹುದಾದ ದೋಷ.
///
/// ಈ ದೋಷವನ್ನು [`i8::from_str_radix`] ನಂತಹ ಪ್ರಾಚೀನ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳಲ್ಲಿನ `from_str_radix()` ಕಾರ್ಯಗಳಿಗಾಗಿ ದೋಷ ಪ್ರಕಾರವಾಗಿ ಬಳಸಲಾಗುತ್ತದೆ.
///
/// # ಸಂಭಾವ್ಯ ಕಾರಣಗಳು
///
/// ಇತರ ಕಾರಣಗಳ ಪೈಕಿ, `ParseIntError` ಅನ್ನು ಸ್ಟ್ರಿಂಗ್‌ನಲ್ಲಿ ಜಾಗವನ್ನು ಮುನ್ನಡೆಸುವ ಅಥವಾ ಹಿಂದುಳಿದಿರುವ ಕಾರಣ ಎಸೆಯಬಹುದು, ಉದಾ., ಅದನ್ನು ಪ್ರಮಾಣಿತ ಇನ್‌ಪುಟ್‌ನಿಂದ ಪಡೆದಾಗ.
///
/// [`str::trim()`] ವಿಧಾನವನ್ನು ಬಳಸುವುದರಿಂದ ಪಾರ್ಸ್ ಮಾಡುವ ಮೊದಲು ಯಾವುದೇ ಜಾಗವಿಲ್ಲ ಉಳಿದಿಲ್ಲ ಎಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// ಪೂರ್ಣಾಂಕವನ್ನು ಪಾರ್ಸ್ ಮಾಡುವುದು ವಿಫಲಗೊಳ್ಳಲು ಕಾರಣವಾಗುವ ವಿವಿಧ ರೀತಿಯ ದೋಷಗಳನ್ನು ಸಂಗ್ರಹಿಸಲು ಎನಮ್.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// ಪಾರ್ಸ್ ಮಾಡಲಾದ ಮೌಲ್ಯವು ಖಾಲಿಯಾಗಿದೆ.
    ///
    /// ಇತರ ಕಾರಣಗಳಲ್ಲಿ, ಖಾಲಿ ದಾರವನ್ನು ಪಾರ್ಸ್ ಮಾಡುವಾಗ ಈ ರೂಪಾಂತರವನ್ನು ನಿರ್ಮಿಸಲಾಗುತ್ತದೆ.
    Empty,
    /// ಅದರ ಸನ್ನಿವೇಶದಲ್ಲಿ ಅಮಾನ್ಯ ಅಂಕೆ ಹೊಂದಿದೆ.
    ///
    /// ಇತರ ಕಾರಣಗಳಲ್ಲಿ, ಎಎಸ್ಸಿಐಐ ಅಲ್ಲದ ಚಾರ್ ಅನ್ನು ಹೊಂದಿರುವ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಪಾರ್ಸ್ ಮಾಡುವಾಗ ಈ ರೂಪಾಂತರವನ್ನು ನಿರ್ಮಿಸಲಾಗುತ್ತದೆ.
    ///
    /// `+` ಅಥವಾ `-` ಅನ್ನು ಸ್ಟ್ರಿಂಗ್‌ನೊಳಗೆ ತನ್ನದೇ ಆದ ಮೇಲೆ ಅಥವಾ ಸಂಖ್ಯೆಯ ಮಧ್ಯದಲ್ಲಿ ತಪ್ಪಾಗಿ ಇರಿಸಿದಾಗ ಈ ರೂಪಾಂತರವನ್ನು ಸಹ ನಿರ್ಮಿಸಲಾಗಿದೆ.
    ///
    ///
    InvalidDigit,
    /// ಗುರಿ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರದಲ್ಲಿ ಸಂಗ್ರಹಿಸಲು ಪೂರ್ಣಾಂಕವು ತುಂಬಾ ದೊಡ್ಡದಾಗಿದೆ.
    PosOverflow,
    /// ಗುರಿ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರದಲ್ಲಿ ಸಂಗ್ರಹಿಸಲು ಪೂರ್ಣಾಂಕವು ತುಂಬಾ ಚಿಕ್ಕದಾಗಿದೆ.
    NegOverflow,
    /// ಮೌಲ್ಯವು ಶೂನ್ಯವಾಗಿತ್ತು
    ///
    /// ಪಾರ್ಸಿಂಗ್ ಸ್ಟ್ರಿಂಗ್ ಶೂನ್ಯ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿರುವಾಗ ಈ ರೂಪಾಂತರವನ್ನು ಹೊರಸೂಸಲಾಗುತ್ತದೆ, ಇದು ಶೂನ್ಯೇತರ ಪ್ರಕಾರಗಳಿಗೆ ಕಾನೂನುಬಾಹಿರವಾಗಿರುತ್ತದೆ.
    ///
    Zero,
}

impl ParseIntError {
    /// ಪೂರ್ಣಾಂಕವನ್ನು ವಿಫಲಗೊಳಿಸುವ ಪಾರ್ಸ್ ಮಾಡುವ ವಿವರವಾದ ಕಾರಣವನ್ನು ನೀಡುತ್ತದೆ.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}