#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! ಕಂಪೈಲರ್ ಅಂತರ್ನಿರ್ಮಿತ ಪ್ರಕಾರಗಳ ವಿನ್ಯಾಸಕ್ಕಾಗಿ ರಚನಾತ್ಮಕ ವ್ಯಾಖ್ಯಾನಗಳನ್ನು ಒಳಗೊಂಡಿದೆ.
//!
//! ಕಚ್ಚಾ ಪ್ರಾತಿನಿಧ್ಯಗಳನ್ನು ನೇರವಾಗಿ ನಿರ್ವಹಿಸಲು ಅವುಗಳನ್ನು ಅಸುರಕ್ಷಿತ ಕೋಡ್‌ನಲ್ಲಿ ಪರಿವರ್ತನೆಗಳ ಗುರಿಗಳಾಗಿ ಬಳಸಬಹುದು.
//!
//!
//! ಅವರ ವ್ಯಾಖ್ಯಾನವು ಯಾವಾಗಲೂ `rustc_middle::ty::layout` ನಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ಎಬಿಐಗೆ ಹೊಂದಿಕೆಯಾಗಬೇಕು.
//!

/// `&dyn SomeTrait` ನಂತಹ trait ವಸ್ತುವಿನ ಪ್ರಾತಿನಿಧ್ಯ.
///
/// ಈ ರಚನೆಯು `&dyn SomeTrait` ಮತ್ತು `Box<dyn AnotherTrait>` ನಂತಹ ಪ್ರಕಾರಗಳಂತೆಯೇ ಇರುತ್ತದೆ.
///
/// `TraitObject` ವಿನ್ಯಾಸಗಳನ್ನು ಹೊಂದಿಸಲು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ, ಆದರೆ ಇದು trait ವಸ್ತುಗಳ ಪ್ರಕಾರವಲ್ಲ (ಉದಾ., ಕ್ಷೇತ್ರಗಳು `&dyn SomeTrait` ನಲ್ಲಿ ನೇರವಾಗಿ ಪ್ರವೇಶಿಸಲಾಗುವುದಿಲ್ಲ) ಅಥವಾ ಆ ವಿನ್ಯಾಸವನ್ನು ನಿಯಂತ್ರಿಸುವುದಿಲ್ಲ (ವ್ಯಾಖ್ಯಾನವನ್ನು ಬದಲಾಯಿಸುವುದರಿಂದ `&dyn SomeTrait` ನ ವಿನ್ಯಾಸವನ್ನು ಬದಲಾಯಿಸುವುದಿಲ್ಲ).
///
/// ಕಡಿಮೆ ಮಟ್ಟದ ವಿವರಗಳನ್ನು ಕುಶಲತೆಯಿಂದ ನಿರ್ವಹಿಸಬೇಕಾದ ಅಸುರಕ್ಷಿತ ಕೋಡ್‌ನಿಂದ ಮಾತ್ರ ಇದನ್ನು ವಿನ್ಯಾಸಗೊಳಿಸಲಾಗಿದೆ.
///
/// ಎಲ್ಲಾ trait ವಸ್ತುಗಳನ್ನು ಸಾಮಾನ್ಯವಾಗಿ ಉಲ್ಲೇಖಿಸಲು ಯಾವುದೇ ಮಾರ್ಗವಿಲ್ಲ, ಆದ್ದರಿಂದ ಈ ಪ್ರಕಾರದ ಮೌಲ್ಯಗಳನ್ನು ರಚಿಸುವ ಏಕೈಕ ಮಾರ್ಗವೆಂದರೆ [`std::mem::transmute`][transmute] ನಂತಹ ಕಾರ್ಯಗಳು.
/// ಅಂತೆಯೇ, `TraitObject` ಮೌಲ್ಯದಿಂದ ನಿಜವಾದ trait ವಸ್ತುವನ್ನು ರಚಿಸುವ ಏಕೈಕ ಮಾರ್ಗವೆಂದರೆ `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// ಹೊಂದಿಕೆಯಾಗದ ಪ್ರಕಾರಗಳೊಂದಿಗೆ trait ವಸ್ತುವನ್ನು ಸಂಶ್ಲೇಷಿಸುವುದು-ಅಲ್ಲಿ ಡೇಟಾ ಪಾಯಿಂಟರ್ ಪಾಯಿಂಟ್‌ಗಳ ಮೌಲ್ಯದ ಪ್ರಕಾರಕ್ಕೆ vtable ಹೊಂದಿಕೆಯಾಗುವುದಿಲ್ಲ-ಇದು ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗಬಹುದು.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // ಉದಾಹರಣೆ trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // ಕಂಪೈಲರ್ trait ಆಬ್ಜೆಕ್ಟ್ ಮಾಡಲು ಅವಕಾಶ ಮಾಡಿಕೊಡಿ
/// let object: &dyn Foo = &value;
///
/// // ಕಚ್ಚಾ ಪ್ರಾತಿನಿಧ್ಯವನ್ನು ನೋಡಿ
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // ಡೇಟಾ ಪಾಯಿಂಟರ್ `value` ನ ವಿಳಾಸವಾಗಿದೆ
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // ಹೊಸ ವಸ್ತುವನ್ನು ನಿರ್ಮಿಸಿ, ಬೇರೆ `i32` ಗೆ ಸೂಚಿಸಿ, `object` ನಿಂದ `i32` vtable ಅನ್ನು ಬಳಸಲು ಜಾಗರೂಕರಾಗಿರಿ
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // ನಾವು `other_value` ನಿಂದ ನೇರವಾಗಿ trait ವಸ್ತುವನ್ನು ನಿರ್ಮಿಸಿದಂತೆಯೇ ಅದು ಕಾರ್ಯನಿರ್ವಹಿಸಬೇಕು
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}