//! ಪ್ರಕಾರಗಳ ನಡುವಿನ ಪರಿವರ್ತನೆಗಳಿಗಾಗಿ Traits.
//!
//! ಈ ಮಾಡ್ಯೂಲ್‌ನಲ್ಲಿನ traits ಒಂದು ಪ್ರಕಾರದಿಂದ ಮತ್ತೊಂದು ಪ್ರಕಾರಕ್ಕೆ ಪರಿವರ್ತಿಸುವ ಮಾರ್ಗವನ್ನು ಒದಗಿಸುತ್ತದೆ.
//! ಪ್ರತಿಯೊಂದು trait ವಿಭಿನ್ನ ಉದ್ದೇಶವನ್ನು ಪೂರೈಸುತ್ತದೆ:
//!
//! - ಅಗ್ಗದ ಉಲ್ಲೇಖದಿಂದ ಉಲ್ಲೇಖದ ಪರಿವರ್ತನೆಗಳಿಗಾಗಿ [`AsRef`] trait ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿ
//! - ಅಗ್ಗದ ರೂಪಾಂತರದಿಂದ ಪರಿವರ್ತಿಸಬಹುದಾದ ಪರಿವರ್ತನೆಗಳಿಗಾಗಿ [`AsMut`] trait ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿ
//! - ಮೌಲ್ಯದಿಂದ ಮೌಲ್ಯದ ಪರಿವರ್ತನೆಗಳನ್ನು ಸೇವಿಸಲು [`From`] trait ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿ
//! - ಪ್ರಸ್ತುತ crate ಹೊರಗಿನ ಪ್ರಕಾರಗಳಿಗೆ ಮೌಲ್ಯದಿಂದ ಮೌಲ್ಯಕ್ಕೆ ಪರಿವರ್ತನೆಗಳನ್ನು ಬಳಸುವುದಕ್ಕಾಗಿ [`Into`] trait ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿ
//! - [`TryFrom`] ಮತ್ತು [`TryInto`] traits [`From`] ಮತ್ತು [`Into`] ನಂತೆ ವರ್ತಿಸುತ್ತದೆ, ಆದರೆ ಪರಿವರ್ತನೆ ವಿಫಲವಾದಾಗ ಅದನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಬೇಕು.
//!
//! ಈ ಮಾಡ್ಯೂಲ್‌ನಲ್ಲಿನ traits ಅನ್ನು ಸಾಮಾನ್ಯವಾಗಿ ಜೆನೆರಿಕ್ ಕಾರ್ಯಗಳಿಗಾಗಿ trait bounds ಆಗಿ ಬಳಸಲಾಗುತ್ತದೆ, ಉದಾಹರಣೆಗೆ ಅನೇಕ ಪ್ರಕಾರಗಳ ವಾದಗಳನ್ನು ಬೆಂಬಲಿಸಲಾಗುತ್ತದೆ.ಉದಾಹರಣೆಗಳಿಗಾಗಿ ಪ್ರತಿ trait ನ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
//!
//! ಗ್ರಂಥಾಲಯದ ಲೇಖಕರಾಗಿ, ನೀವು ಯಾವಾಗಲೂ [`Into<U>`][`Into`] ಅಥವಾ [`TryInto<U>`][`TryInto`] ಗಿಂತ [`From<T>`][`From`] ಅಥವಾ [`TryFrom<T>`][`TryFrom`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ಆದ್ಯತೆ ನೀಡಬೇಕು, ಏಕೆಂದರೆ [`From`] ಮತ್ತು [`TryFrom`] ಹೆಚ್ಚಿನ ನಮ್ಯತೆಯನ್ನು ಒದಗಿಸುತ್ತದೆ ಮತ್ತು ಸಮಾನವಾದ [`Into`] ಅಥವಾ [`TryInto`] ಅನುಷ್ಠಾನಗಳನ್ನು ಉಚಿತವಾಗಿ ನೀಡುತ್ತವೆ, ಪ್ರಮಾಣಿತ ಗ್ರಂಥಾಲಯದಲ್ಲಿ ಕಂಬಳಿ ಅನುಷ್ಠಾನಕ್ಕೆ ಧನ್ಯವಾದಗಳು.
//! Rust 1.41 ಗೆ ಮೊದಲು ಆವೃತ್ತಿಯನ್ನು ಟಾರ್ಗೆಟ್ ಮಾಡುವಾಗ, ಪ್ರಸ್ತುತ crate ನ ಹೊರಗಿನ ಪ್ರಕಾರಕ್ಕೆ ಪರಿವರ್ತಿಸುವಾಗ [`Into`] ಅಥವಾ [`TryInto`] ಅನ್ನು ನೇರವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸುವುದು ಅಗತ್ಯವಾಗಿರುತ್ತದೆ.
//!
//! # ಸಾಮಾನ್ಯ ಅನುಷ್ಠಾನಗಳು
//!
//! - [`AsRef`] ಮತ್ತು ಆಂತರಿಕ ಪ್ರಕಾರವು ಒಂದು ಉಲ್ಲೇಖವಾಗಿದ್ದರೆ [`AsMut`] ಸ್ವಯಂ-ಅಪನಗದೀಕರಣ
//! - [`ಇಂದ`]`<U>ಗಾಗಿ ಟಿ` ಎಂದರೆ [`ಒಳಗೆ`]`</u><T><U>U` ಗಾಗಿ</u>
//! - [`ಟ್ರೈಫ್ರಾಮ್`]`<U>ಗಾಗಿ ಟಿ` ಸೂಚಿಸುತ್ತದೆ [`ಟ್ರೈಇಂಟೊ`]`</u><T><U>U` ಗಾಗಿ</u>
//! - [`From`] ಮತ್ತು [`Into`] ರಿಫ್ಲೆಕ್ಸಿವ್ ಆಗಿದೆ, ಇದರರ್ಥ ಎಲ್ಲಾ ಪ್ರಕಾರಗಳು ತಮ್ಮನ್ನು `into` ಮತ್ತು `from` ಅನ್ನು ಸ್ವತಃ ಮಾಡಬಹುದು
//!
//! ಬಳಕೆಯ ಉದಾಹರಣೆಗಳಿಗಾಗಿ ಪ್ರತಿ trait ನೋಡಿ.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// ಗುರುತಿನ ಕಾರ್ಯ.
///
/// ಈ ಕಾರ್ಯದ ಬಗ್ಗೆ ಗಮನಿಸಬೇಕಾದ ಎರಡು ವಿಷಯಗಳು:
///
/// - ಇದು ಯಾವಾಗಲೂ `|x| x` ನಂತಹ ಮುಚ್ಚುವಿಕೆಗೆ ಸಮನಾಗಿರುವುದಿಲ್ಲ, ಏಕೆಂದರೆ ಮುಚ್ಚುವಿಕೆಯು `x` ಅನ್ನು ಬೇರೆ ಪ್ರಕಾರಕ್ಕೆ ಒತ್ತಾಯಿಸುತ್ತದೆ.
///
/// - ಇದು ಇನ್ಪುಟ್ `x` ಅನ್ನು ಕಾರ್ಯಕ್ಕೆ ರವಾನಿಸುತ್ತದೆ.
///
/// ಇನ್ಪುಟ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುವ ಕಾರ್ಯವನ್ನು ಹೊಂದಿರುವುದು ವಿಚಿತ್ರವೆನಿಸಿದರೂ, ಕೆಲವು ಆಸಕ್ತಿದಾಯಕ ಉಪಯೋಗಗಳಿವೆ.
///
///
/// # Examples
///
/// ಇತರ, ಆಸಕ್ತಿದಾಯಕ, ಕಾರ್ಯಗಳ ಅನುಕ್ರಮದಲ್ಲಿ ಏನನ್ನೂ ಮಾಡಲು `identity` ಅನ್ನು ಬಳಸುವುದು:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // ಒಂದನ್ನು ಸೇರಿಸುವುದು ಆಸಕ್ತಿದಾಯಕ ಕಾರ್ಯ ಎಂದು ನಟಿಸೋಣ.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// ಷರತ್ತುಬದ್ಧವಾಗಿ `identity` ಅನ್ನು "do nothing" ಬೇಸ್ ಕೇಸ್‌ನಂತೆ ಬಳಸುವುದು:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // ಹೆಚ್ಚು ಆಸಕ್ತಿದಾಯಕ ವಿಷಯವನ್ನು ಮಾಡಿ ...
///
/// let _results = do_stuff(42);
/// ```
///
/// `Option<T>` ನ ಪುನರಾವರ್ತಕದ `Some` ರೂಪಾಂತರಗಳನ್ನು ಇರಿಸಿಕೊಳ್ಳಲು `identity` ಅನ್ನು ಬಳಸುವುದು:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// ಅಗ್ಗದ ಉಲ್ಲೇಖದಿಂದ ಉಲ್ಲೇಖಕ್ಕೆ ಪರಿವರ್ತನೆ ಮಾಡಲು ಬಳಸಲಾಗುತ್ತದೆ.
///
/// ಈ trait [`AsMut`] ಗೆ ಹೋಲುತ್ತದೆ, ಇದನ್ನು ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳ ನಡುವೆ ಪರಿವರ್ತಿಸಲು ಬಳಸಲಾಗುತ್ತದೆ.
/// ನೀವು ದುಬಾರಿ ಪರಿವರ್ತನೆ ಮಾಡಬೇಕಾದರೆ [`From`] ಅನ್ನು `&T` ಪ್ರಕಾರದೊಂದಿಗೆ ಕಾರ್ಯಗತಗೊಳಿಸುವುದು ಅಥವಾ ಕಸ್ಟಮ್ ಕಾರ್ಯವನ್ನು ಬರೆಯುವುದು ಉತ್ತಮ.
///
/// `AsRef` [`Borrow`] ನಂತೆಯೇ ಒಂದೇ ಸಹಿಯನ್ನು ಹೊಂದಿದೆ, ಆದರೆ [`Borrow`] ಕೆಲವು ಅಂಶಗಳಲ್ಲಿ ಭಿನ್ನವಾಗಿರುತ್ತದೆ:
///
/// - `AsRef` ಗಿಂತ ಭಿನ್ನವಾಗಿ, [`Borrow`] ಯಾವುದೇ `T` ಗಾಗಿ ಕಂಬಳಿ ಇಂಪ್ಲ್ ಅನ್ನು ಹೊಂದಿದೆ, ಮತ್ತು ಇದನ್ನು ಉಲ್ಲೇಖ ಅಥವಾ ಮೌಲ್ಯವನ್ನು ಸ್ವೀಕರಿಸಲು ಬಳಸಬಹುದು.
/// - [`Borrow`] ಎರವಲು ಪಡೆದ ಮೌಲ್ಯಕ್ಕಾಗಿ [`Hash`], [`Eq`] ಮತ್ತು [`Ord`] ಸಹ ಮಾಲೀಕತ್ವದ ಮೌಲ್ಯಕ್ಕೆ ಸಮನಾಗಿರಬೇಕು.
/// ಈ ಕಾರಣಕ್ಕಾಗಿ, ನೀವು ರಚನೆಯ ಒಂದೇ ಕ್ಷೇತ್ರವನ್ನು ಮಾತ್ರ ಎರವಲು ಪಡೆಯಲು ಬಯಸಿದರೆ ನೀವು `AsRef` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು, ಆದರೆ [`Borrow`] ಅಲ್ಲ.
///
/// **Note: ಈ trait ವಿಫಲವಾಗಬಾರದು **.ಪರಿವರ್ತನೆ ವಿಫಲವಾದರೆ, [`Option<T>`] ಅಥವಾ [`Result<T, E>`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುವ ಮೀಸಲಾದ ವಿಧಾನವನ್ನು ಬಳಸಿ.
///
/// # ಸಾಮಾನ್ಯ ಅನುಷ್ಠಾನಗಳು
///
/// - `AsRef` ಆಂತರಿಕ ಪ್ರಕಾರವು ಒಂದು ಉಲ್ಲೇಖ ಅಥವಾ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವಾಗಿದ್ದರೆ ಸ್ವಯಂ-ವಿರೂಪಗಳು (ಉದಾ: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// trait bounds ಅನ್ನು ಬಳಸುವ ಮೂಲಕ ನಾವು ನಿರ್ದಿಷ್ಟ ಪ್ರಕಾರದ `T` ಗೆ ಪರಿವರ್ತಿಸುವವರೆಗೆ ವಿವಿಧ ಪ್ರಕಾರಗಳ ವಾದಗಳನ್ನು ಸ್ವೀಕರಿಸಬಹುದು.
///
/// ಉದಾಹರಣೆಗೆ: `AsRef<str>` ತೆಗೆದುಕೊಳ್ಳುವ ಜೆನೆರಿಕ್ ಕಾರ್ಯವನ್ನು ರಚಿಸುವ ಮೂಲಕ ನಾವು [`&str`] ಗೆ ಪರಿವರ್ತಿಸಬಹುದಾದ ಎಲ್ಲಾ ಉಲ್ಲೇಖಗಳನ್ನು ವಾದವಾಗಿ ಸ್ವೀಕರಿಸಲು ಬಯಸುತ್ತೇವೆ ಎಂದು ನಾವು ವ್ಯಕ್ತಪಡಿಸುತ್ತೇವೆ.
/// [`String`] ಮತ್ತು [`&str`] ಎರಡೂ `AsRef<str>` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದರಿಂದ ನಾವು ಎರಡನ್ನೂ ಇನ್ಪುಟ್ ಆರ್ಗ್ಯುಮೆಂಟ್ ಆಗಿ ಸ್ವೀಕರಿಸಬಹುದು.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// ಪರಿವರ್ತನೆ ಮಾಡುತ್ತದೆ.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// ಅಗ್ಗದ ರೂಪಾಂತರಿತದಿಂದ ರೂಪಾಂತರಗೊಳ್ಳುವ ಉಲ್ಲೇಖ ಪರಿವರ್ತನೆ ಮಾಡಲು ಬಳಸಲಾಗುತ್ತದೆ.
///
/// ಈ trait [`AsRef`] ಗೆ ಹೋಲುತ್ತದೆ ಆದರೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳ ನಡುವೆ ಪರಿವರ್ತಿಸಲು ಬಳಸಲಾಗುತ್ತದೆ.
/// ನೀವು ದುಬಾರಿ ಪರಿವರ್ತನೆ ಮಾಡಬೇಕಾದರೆ [`From`] ಅನ್ನು `&mut T` ಪ್ರಕಾರದೊಂದಿಗೆ ಕಾರ್ಯಗತಗೊಳಿಸುವುದು ಅಥವಾ ಕಸ್ಟಮ್ ಕಾರ್ಯವನ್ನು ಬರೆಯುವುದು ಉತ್ತಮ.
///
/// **Note: ಈ trait ವಿಫಲವಾಗಬಾರದು **.ಪರಿವರ್ತನೆ ವಿಫಲವಾದರೆ, [`Option<T>`] ಅಥವಾ [`Result<T, E>`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುವ ಮೀಸಲಾದ ವಿಧಾನವನ್ನು ಬಳಸಿ.
///
/// # ಸಾಮಾನ್ಯ ಅನುಷ್ಠಾನಗಳು
///
/// - `AsMut` ಆಂತರಿಕ ಪ್ರಕಾರವು ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವಾಗಿದ್ದರೆ ಸ್ವಯಂ-ವಿರೂಪಗಳು (ಉದಾ: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// ಜೆನೆರಿಕ್ ಕಾರ್ಯಕ್ಕಾಗಿ `AsMut` ಅನ್ನು trait bound ಆಗಿ ಬಳಸುವುದರಿಂದ ನಾವು `&mut T` ಪ್ರಕಾರಕ್ಕೆ ಪರಿವರ್ತಿಸಬಹುದಾದ ಎಲ್ಲಾ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳನ್ನು ಸ್ವೀಕರಿಸಬಹುದು.
/// [`Box<T>`] `AsMut<T>` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದರಿಂದ ನಾವು `add_one` ಕಾರ್ಯವನ್ನು ಬರೆಯಬಹುದು ಅದು `&mut u64` ಗೆ ಪರಿವರ್ತಿಸಬಹುದಾದ ಎಲ್ಲಾ ಆರ್ಗ್ಯುಮೆಂಟ್‌ಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
/// [`Box<T>`] `AsMut<T>` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದರಿಂದ, `add_one` `&mut Box<u64>` ಪ್ರಕಾರದ ವಾದಗಳನ್ನು ಸಹ ಸ್ವೀಕರಿಸುತ್ತದೆ:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// ಪರಿವರ್ತನೆ ಮಾಡುತ್ತದೆ.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// ಇನ್ಪುಟ್ ಮೌಲ್ಯವನ್ನು ಬಳಸುವ ಮೌಲ್ಯದಿಂದ ಮೌಲ್ಯಕ್ಕೆ ಪರಿವರ್ತನೆ.[`From`] ಗೆ ವಿರುದ್ಧವಾಗಿದೆ.
///
/// ಒಬ್ಬರು [`Into`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದನ್ನು ತಪ್ಪಿಸಬೇಕು ಮತ್ತು ಬದಲಿಗೆ [`From`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಬೇಕು.
/// [`From`] ಅನ್ನು ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸುವುದರಿಂದ ಸ್ಟ್ಯಾಂಡರ್ಡ್ ಲೈಬ್ರರಿಯಲ್ಲಿ ಕಂಬಳಿ ಅನುಷ್ಠಾನಕ್ಕೆ [`Into`] ಧನ್ಯವಾದಗಳು ಅನುಷ್ಠಾನವನ್ನು ಒದಗಿಸುತ್ತದೆ.
///
/// [`Into`] ಅನ್ನು ಮಾತ್ರ ಕಾರ್ಯಗತಗೊಳಿಸುವ ಪ್ರಕಾರಗಳನ್ನು ಸಹ ಬಳಸಬಹುದೆಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ಜೆನೆರಿಕ್ ಕಾರ್ಯದಲ್ಲಿ trait bounds ಅನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸುವಾಗ [`From`] ಗಿಂತ [`Into`] ಅನ್ನು ಬಳಸಲು ಆದ್ಯತೆ ನೀಡಿ.
///
/// **Note: ಈ trait ವಿಫಲವಾಗಬಾರದು **.ಪರಿವರ್ತನೆ ವಿಫಲವಾದರೆ, [`TryInto`] ಬಳಸಿ.
///
/// # ಸಾಮಾನ್ಯ ಅನುಷ್ಠಾನಗಳು
///
/// - [`ಇಂದ`]`<T>U` ಎಂದರೆ `Into<U> for T` ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ
/// - [`Into`] ರಿಫ್ಲೆಕ್ಸಿವ್ ಆಗಿದೆ, ಇದರರ್ಥ `Into<T> for T` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗಿದೆ
///
/// # Rust ನ ಹಳೆಯ ಆವೃತ್ತಿಗಳಲ್ಲಿ ಬಾಹ್ಯ ಪ್ರಕಾರಗಳಿಗೆ ಪರಿವರ್ತನೆಗಾಗಿ [`Into`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದು
///
/// Rust 1.41 ಗೆ ಮೊದಲು, ಗಮ್ಯಸ್ಥಾನ ಪ್ರಕಾರವು ಪ್ರಸ್ತುತ crate ನ ಭಾಗವಾಗಿರದಿದ್ದರೆ ನಿಮಗೆ [`From`] ಅನ್ನು ನೇರವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ.
/// ಉದಾಹರಣೆಗೆ, ಈ ಕೋಡ್ ತೆಗೆದುಕೊಳ್ಳಿ:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// ಭಾಷೆಯ ಹಳೆಯ ಆವೃತ್ತಿಗಳಲ್ಲಿ ಕಂಪೈಲ್ ಮಾಡಲು ಇದು ವಿಫಲಗೊಳ್ಳುತ್ತದೆ ಏಕೆಂದರೆ Rust ನ ಅನಾಥ ನಿಯಮಗಳು ಸ್ವಲ್ಪ ಹೆಚ್ಚು ಕಟ್ಟುನಿಟ್ಟಾಗಿರುತ್ತವೆ.
/// ಇದನ್ನು ಬೈಪಾಸ್ ಮಾಡಲು, ನೀವು ನೇರವಾಗಿ [`Into`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// [`Into`] [`From`] ಅನುಷ್ಠಾನವನ್ನು ಒದಗಿಸುವುದಿಲ್ಲ ಎಂದು ಅರ್ಥಮಾಡಿಕೊಳ್ಳುವುದು ಬಹಳ ಮುಖ್ಯ ([`From`] [`Into`] ನೊಂದಿಗೆ ಮಾಡುವಂತೆ).
/// ಆದ್ದರಿಂದ, ನೀವು ಯಾವಾಗಲೂ [`From`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ಪ್ರಯತ್ನಿಸಬೇಕು ಮತ್ತು [`From`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ಸಾಧ್ಯವಾಗದಿದ್ದರೆ [`Into`] ಗೆ ಹಿಂತಿರುಗಿ.
///
/// # Examples
///
/// [`String`] [`ಒಳಗೆ`]`<`[`ವೆಕ್`] `<` [`u8`]`>>`:
///
/// ನಿರ್ದಿಷ್ಟ ಪ್ರಕಾರದ `T` ಗೆ ಪರಿವರ್ತಿಸಬಹುದಾದ ಎಲ್ಲಾ ಆರ್ಗ್ಯುಮೆಂಟ್‌ಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳಲು ನಾವು ಸಾಮಾನ್ಯ ಕಾರ್ಯವನ್ನು ಬಯಸುತ್ತೇವೆ ಎಂದು ವ್ಯಕ್ತಪಡಿಸಲು, ನಾವು [`ಒಳಗೆ`]`ನ trait bound ಅನ್ನು ಬಳಸಬಹುದು.<T>`.
///
/// ಉದಾಹರಣೆಗೆ: `is_hello` ಕಾರ್ಯವು [`Vec`]`<`[`u8`] `>` ಆಗಿ ಪರಿವರ್ತಿಸಬಹುದಾದ ಎಲ್ಲಾ ಆರ್ಗ್ಯುಮೆಂಟ್‌ಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// ಪರಿವರ್ತನೆ ಮಾಡುತ್ತದೆ.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// ಇನ್ಪುಟ್ ಮೌಲ್ಯವನ್ನು ಸೇವಿಸುವಾಗ ಮೌಲ್ಯದಿಂದ ಮೌಲ್ಯಕ್ಕೆ ಪರಿವರ್ತನೆಗಳನ್ನು ಮಾಡಲು ಬಳಸಲಾಗುತ್ತದೆ.ಇದು [`Into`] ನ ಪರಸ್ಪರ.
///
/// `From` ಅನ್ನು [`Into`] ಗಿಂತ ಕಾರ್ಯಗತಗೊಳಿಸಲು ಯಾವಾಗಲೂ ಆದ್ಯತೆ ನೀಡಬೇಕು ಏಕೆಂದರೆ `From` ಅನ್ನು ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸುವುದರಿಂದ [`Into`] ನ ಅನುಷ್ಠಾನವು ಸ್ಟ್ಯಾಂಡರ್ಡ್ ಲೈಬ್ರರಿಯಲ್ಲಿ ಕಂಬಳಿ ಅನುಷ್ಠಾನಕ್ಕೆ ಧನ್ಯವಾದಗಳು.
///
///
/// Rust 1.41 ಗೆ ಮೊದಲು ಆವೃತ್ತಿಯನ್ನು ಟಾರ್ಗೆಟ್ ಮಾಡುವಾಗ ಮತ್ತು ಪ್ರಸ್ತುತ crate ನ ಹೊರಗಿನ ಪ್ರಕಾರಕ್ಕೆ ಪರಿವರ್ತಿಸುವಾಗ ಮಾತ್ರ [`Into`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿ.
/// `From` Rust ನ ಅನಾಥ ನಿಯಮಗಳಿಂದಾಗಿ ಹಿಂದಿನ ಆವೃತ್ತಿಗಳಲ್ಲಿ ಈ ರೀತಿಯ ಪರಿವರ್ತನೆಗಳನ್ನು ಮಾಡಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ.
/// ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ [`Into`] ನೋಡಿ.
///
/// ಜೆನೆರಿಕ್ ಕಾರ್ಯದಲ್ಲಿ trait bounds ಅನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸುವಾಗ `From` ಅನ್ನು ಬಳಸುವುದಕ್ಕಿಂತ [`Into`] ಅನ್ನು ಬಳಸಲು ಆದ್ಯತೆ ನೀಡಿ.
/// ಈ ರೀತಿಯಾಗಿ, [`Into`] ಅನ್ನು ನೇರವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸುವ ಪ್ರಕಾರಗಳನ್ನು ವಾದಗಳಾಗಿಯೂ ಬಳಸಬಹುದು.
///
/// ದೋಷ ನಿರ್ವಹಣೆಯನ್ನು ನಿರ್ವಹಿಸುವಾಗ `From` ಸಹ ತುಂಬಾ ಉಪಯುಕ್ತವಾಗಿದೆ.ವಿಫಲಗೊಳ್ಳುವ ಸಾಮರ್ಥ್ಯವನ್ನು ಹೊಂದಿರುವ ಕಾರ್ಯವನ್ನು ನಿರ್ಮಿಸುವಾಗ, ರಿಟರ್ನ್ ಪ್ರಕಾರವು ಸಾಮಾನ್ಯವಾಗಿ `Result<T, E>` ರೂಪದಲ್ಲಿರುತ್ತದೆ.
/// `From` trait ಬಹು ದೋಷ ಪ್ರಕಾರಗಳನ್ನು ಸುತ್ತುವರಿಯುವ ಒಂದೇ ದೋಷ ಪ್ರಕಾರವನ್ನು ಹಿಂತಿರುಗಿಸಲು ಒಂದು ಕಾರ್ಯವನ್ನು ಅನುಮತಿಸುವ ಮೂಲಕ ದೋಷ ನಿರ್ವಹಣೆಯನ್ನು ಸರಳಗೊಳಿಸುತ್ತದೆ.ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ "Examples" ವಿಭಾಗ ಮತ್ತು [the book][book] ನೋಡಿ.
///
/// **Note: ಈ trait ವಿಫಲವಾಗಬಾರದು **.ಪರಿವರ್ತನೆ ವಿಫಲವಾದರೆ, [`TryFrom`] ಬಳಸಿ.
///
/// # ಸಾಮಾನ್ಯ ಅನುಷ್ಠಾನಗಳು
///
/// - `From<T> for U` T`<U>ಗಾಗಿ</u> [`ಒಳಗೆ`]` <U>ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ</u>
/// - `From` ರಿಫ್ಲೆಕ್ಸಿವ್ ಆಗಿದೆ, ಇದರರ್ಥ `From<T> for T` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗಿದೆ
///
/// # Examples
///
/// [`String`] `From<&str>` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ:
///
/// `&str` ನಿಂದ ಸ್ಟ್ರಿಂಗ್‌ಗೆ ಸ್ಪಷ್ಟ ಪರಿವರ್ತನೆ ಈ ಕೆಳಗಿನಂತೆ ಮಾಡಲಾಗುತ್ತದೆ:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// ದೋಷ ನಿರ್ವಹಣೆಯನ್ನು ನಿರ್ವಹಿಸುವಾಗ ನಿಮ್ಮ ಸ್ವಂತ ದೋಷ ಪ್ರಕಾರಕ್ಕಾಗಿ `From` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ಇದು ಸಾಮಾನ್ಯವಾಗಿ ಉಪಯುಕ್ತವಾಗಿರುತ್ತದೆ.
/// ಆಧಾರವಾಗಿರುವ ದೋಷ ಪ್ರಕಾರಗಳನ್ನು ನಮ್ಮ ಸ್ವಂತ ಕಸ್ಟಮ್ ದೋಷ ಪ್ರಕಾರಕ್ಕೆ ಪರಿವರ್ತಿಸುವ ಮೂಲಕ ಅದು ಆಧಾರವಾಗಿರುವ ದೋಷ ಪ್ರಕಾರವನ್ನು ಒಳಗೊಳ್ಳುತ್ತದೆ, ಮೂಲ ಕಾರಣದ ಮಾಹಿತಿಯನ್ನು ಕಳೆದುಕೊಳ್ಳದೆ ನಾವು ಒಂದೇ ದೋಷ ಪ್ರಕಾರವನ್ನು ಹಿಂತಿರುಗಿಸಬಹುದು.
/// '?' ಆಪರೇಟರ್ ಸ್ವಯಂಚಾಲಿತವಾಗಿ `Into<CliError>::into` ಗೆ ಕರೆ ಮಾಡುವ ಮೂಲಕ ಆಧಾರವಾಗಿರುವ ದೋಷ ಪ್ರಕಾರವನ್ನು ನಮ್ಮ ಕಸ್ಟಮ್ ದೋಷ ಪ್ರಕಾರಕ್ಕೆ ಪರಿವರ್ತಿಸುತ್ತದೆ, ಇದು `From` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವಾಗ ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಒದಗಿಸಲಾಗುತ್ತದೆ.
/// ಕಂಪೈಲರ್ ನಂತರ `Into` ನ ಯಾವ ಅನುಷ್ಠಾನವನ್ನು ಬಳಸಬೇಕೆಂದು inf ಹಿಸುತ್ತದೆ.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// ಪರಿವರ್ತನೆ ಮಾಡುತ್ತದೆ.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// `self` ಅನ್ನು ಬಳಸುವ ಪ್ರಯತ್ನಿಸಿದ ಪರಿವರ್ತನೆ, ಅದು ದುಬಾರಿಯಾಗಬಹುದು ಅಥವಾ ಇರಬಹುದು.
///
/// ಗ್ರಂಥಾಲಯದ ಲೇಖಕರು ಸಾಮಾನ್ಯವಾಗಿ ಈ trait ಅನ್ನು ನೇರವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸಬಾರದು, ಆದರೆ [`TryFrom`] trait ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ಆದ್ಯತೆ ನೀಡಬೇಕು, ಇದು ಹೆಚ್ಚಿನ ನಮ್ಯತೆಯನ್ನು ನೀಡುತ್ತದೆ ಮತ್ತು ಸಮಾನವಾದ `TryInto` ಅನುಷ್ಠಾನವನ್ನು ಉಚಿತವಾಗಿ ನೀಡುತ್ತದೆ, ಪ್ರಮಾಣಿತ ಗ್ರಂಥಾಲಯದಲ್ಲಿ ಕಂಬಳಿ ಅನುಷ್ಠಾನಕ್ಕೆ ಧನ್ಯವಾದಗಳು.
/// ಈ ಕುರಿತು ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ, [`Into`] ಗಾಗಿ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
///
/// # `TryInto` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗುತ್ತಿದೆ
///
/// ಇದು [`Into`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವಂತೆಯೇ ಅದೇ ನಿರ್ಬಂಧಗಳು ಮತ್ತು ತಾರ್ಕಿಕತೆಯನ್ನು ಅನುಭವಿಸುತ್ತದೆ, ವಿವರಗಳಿಗಾಗಿ ಅಲ್ಲಿ ನೋಡಿ.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// ಪರಿವರ್ತನೆ ದೋಷದ ಸಂದರ್ಭದಲ್ಲಿ ಪ್ರಕಾರವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗಿದೆ.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// ಪರಿವರ್ತನೆ ಮಾಡುತ್ತದೆ.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// ಕೆಲವು ಸಂದರ್ಭಗಳಲ್ಲಿ ನಿಯಂತ್ರಿತ ರೀತಿಯಲ್ಲಿ ವಿಫಲಗೊಳ್ಳುವ ಸರಳ ಮತ್ತು ಸುರಕ್ಷಿತ ಪ್ರಕಾರದ ಪರಿವರ್ತನೆಗಳು.ಇದು [`TryInto`] ನ ಪರಸ್ಪರ.
///
/// ನೀವು ಒಂದು ರೀತಿಯ ಪರಿವರ್ತನೆ ಮಾಡುವಾಗ ಇದು ಉಪಯುಕ್ತವಾಗಿರುತ್ತದೆ, ಅದು ಕ್ಷುಲ್ಲಕವಾಗಿ ಯಶಸ್ವಿಯಾಗಬಹುದು ಆದರೆ ವಿಶೇಷ ನಿರ್ವಹಣೆ ಅಗತ್ಯವಿರುತ್ತದೆ.
/// ಉದಾಹರಣೆಗೆ, [`From`] trait ಅನ್ನು ಬಳಸಿಕೊಂಡು [`i64`] ಅನ್ನು [`i32`] ಆಗಿ ಪರಿವರ್ತಿಸಲು ಯಾವುದೇ ಮಾರ್ಗವಿಲ್ಲ, ಏಕೆಂದರೆ [`i64`] ನಲ್ಲಿ [`i32`] ಪ್ರತಿನಿಧಿಸಲಾಗದ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿರಬಹುದು ಮತ್ತು ಆದ್ದರಿಂದ ಪರಿವರ್ತನೆಯು ಡೇಟಾವನ್ನು ಕಳೆದುಕೊಳ್ಳುತ್ತದೆ.
///
/// ಇದನ್ನು [`i64`] ಅನ್ನು [`i32`] ಗೆ ಮೊಟಕುಗೊಳಿಸುವ ಮೂಲಕ ನಿರ್ವಹಿಸಬಹುದು (ಮೂಲಭೂತವಾಗಿ [`i64`] ನ ಮೌಲ್ಯ ಮಾಡ್ಯುಲೋ [`i32::MAX`] ಅನ್ನು ನೀಡುತ್ತದೆ) ಅಥವಾ [`i32::MAX`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುವ ಮೂಲಕ ಅಥವಾ ಬೇರೆ ಯಾವುದಾದರೂ ವಿಧಾನದಿಂದ.
/// [`From`] trait ಪರಿಪೂರ್ಣ ಪರಿವರ್ತನೆಗಳಿಗಾಗಿ ಉದ್ದೇಶಿಸಲಾಗಿದೆ, ಆದ್ದರಿಂದ `TryFrom` trait ಒಂದು ರೀತಿಯ ಪರಿವರ್ತನೆ ಕೆಟ್ಟದಾಗಬಹುದು ಎಂದು ಪ್ರೋಗ್ರಾಮರ್‌ಗೆ ತಿಳಿಸುತ್ತದೆ ಮತ್ತು ಅದನ್ನು ಹೇಗೆ ನಿರ್ವಹಿಸಬೇಕು ಎಂಬುದನ್ನು ನಿರ್ಧರಿಸಲು ಅವರಿಗೆ ಅನುಮತಿಸುತ್ತದೆ.
///
/// # ಸಾಮಾನ್ಯ ಅನುಷ್ಠಾನಗಳು
///
/// - `TryFrom<T> for U` T`<U>ಗಾಗಿ</u> [`tryInto`]` <U>ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ</u>
/// - [`try_from`] ರಿಫ್ಲೆಕ್ಸಿವ್ ಆಗಿದೆ, ಇದರರ್ಥ `TryFrom<T> for T` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗಿದೆ ಮತ್ತು ವಿಫಲಗೊಳ್ಳಲು ಸಾಧ್ಯವಿಲ್ಲ-`T` ಪ್ರಕಾರದ ಮೌಲ್ಯದ ಮೇಲೆ `T::try_from()` ಗೆ ಕರೆ ಮಾಡಲು ಸಂಬಂಧಿಸಿದ `Error` ಪ್ರಕಾರವು [`Infallible`] ಆಗಿದೆ.
/// [`!`] ಪ್ರಕಾರವನ್ನು ಸ್ಥಿರಗೊಳಿಸಿದಾಗ [`Infallible`] ಮತ್ತು [`!`] ಸಮಾನವಾಗಿರುತ್ತದೆ.
///
/// `TryFrom<T>` ಈ ಕೆಳಗಿನಂತೆ ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// ವಿವರಿಸಿದಂತೆ, [`i32`] `ಟ್ರೈಫ್ರಾಮ್ <` [`i64`]`>`ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // `big_number` ಅನ್ನು ಮೌನವಾಗಿ ಮೊಟಕುಗೊಳಿಸುತ್ತದೆ, ವಾಸ್ತವದ ನಂತರ ಮೊಟಕುಗೊಳಿಸುವಿಕೆಯನ್ನು ಕಂಡುಹಿಡಿಯುವುದು ಮತ್ತು ನಿರ್ವಹಿಸುವುದು ಅಗತ್ಯವಾಗಿರುತ್ತದೆ.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // `big_number` `i32` ನಲ್ಲಿ ಹೊಂದಿಕೊಳ್ಳಲು ತುಂಬಾ ದೊಡ್ಡದಾದ ಕಾರಣ ದೋಷವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// ಪರಿವರ್ತನೆ ದೋಷದ ಸಂದರ್ಭದಲ್ಲಿ ಪ್ರಕಾರವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗಿದೆ.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// ಪರಿವರ್ತನೆ ಮಾಡುತ್ತದೆ.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// ಜೆನೆರಿಕ್ IMPLS
////////////////////////////////////////////////////////////////////////////////

// ಮೇಲೆ ಎತ್ತುವಂತೆ&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// &mut ಗಿಂತ ಲಿಫ್ಟ್‌ಗಳಂತೆ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): &/&mut ಗಾಗಿ ಮೇಲಿನ impls ಅನ್ನು ಈ ಕೆಳಗಿನ ಸಾಮಾನ್ಯ ಒಂದರೊಂದಿಗೆ ಬದಲಾಯಿಸಿ:
// // ಡೆರೆಫ್ ಮೇಲೆ ಎತ್ತುವಂತೆ
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U :? ಗಾತ್ರ <U>> D {fn as_ref(&self)-> &U</u> for <U>ಗಾಗಿ AsRef</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut &mut ಗಿಂತ ಮೇಲಕ್ಕೆತ್ತುತ್ತದೆ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): &mut ಗಾಗಿ ಮೇಲಿನ impl ಅನ್ನು ಈ ಕೆಳಗಿನ ಸಾಮಾನ್ಯದೊಂದಿಗೆ ಬದಲಾಯಿಸಿ:
// // ಅಸ್ಮಟ್ ಡೆರೆಫ್ಮಟ್ ಮೇಲೆ ಎತ್ತುತ್ತದೆ
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U :? ಗಾತ್ರ <U>> D {fn as_mut(&mut self) ಗಾಗಿ AsMut-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// ನಿಂದ ಸೂಚಿಸುತ್ತದೆ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// ಇಂದ (ಮತ್ತು ಹೀಗೆ) ಪ್ರತಿಫಲಿತವಾಗಿದೆ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **ಸ್ಥಿರತೆ ಟಿಪ್ಪಣಿ:** ಈ impl ಇನ್ನೂ ಅಸ್ತಿತ್ವದಲ್ಲಿಲ್ಲ, ಆದರೆ ಅದನ್ನು future ನಲ್ಲಿ ಸೇರಿಸಲು ನಾವು "reserving space" ಆಗಿದ್ದೇವೆ.
/// ವಿವರಗಳಿಗಾಗಿ [rust-lang/rust#64715][#64715] ನೋಡಿ.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): ಬದಲಿಗೆ ತತ್ವಬದ್ಧ ಫಿಕ್ಸ್ ಮಾಡಿ.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// ಟ್ರೈಫ್ರಾಮ್ ಟ್ರೈಇಂಟೊವನ್ನು ಸೂಚಿಸುತ್ತದೆ
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// ದೋಷರಹಿತ ಪರಿವರ್ತನೆಗಳು ಜನವಸತಿ ದೋಷ ಪ್ರಕಾರದೊಂದಿಗೆ ತಪ್ಪಾದ ಪರಿವರ್ತನೆಗಳಿಗೆ ಶಬ್ದಾರ್ಥವಾಗಿ ಸಮಾನವಾಗಿವೆ.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS ಅನ್ನು ಕಾಂಕ್ರೀಟ್ ಮಾಡಿ
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// ದೋಷವಿಲ್ಲದ ದೋಷದ ಪ್ರಕಾರ
////////////////////////////////////////////////////////////////////////////////

/// ಎಂದಿಗೂ ಸಂಭವಿಸದ ದೋಷಗಳಿಗಾಗಿ ದೋಷ ಪ್ರಕಾರ.
///
/// ಈ ಎನಮ್ ಯಾವುದೇ ರೂಪಾಂತರವನ್ನು ಹೊಂದಿರದ ಕಾರಣ, ಈ ಪ್ರಕಾರದ ಮೌಲ್ಯವು ಎಂದಿಗೂ ಅಸ್ತಿತ್ವದಲ್ಲಿಲ್ಲ.
/// ಫಲಿತಾಂಶವು ಯಾವಾಗಲೂ [`Ok`] ಎಂದು ಸೂಚಿಸಲು, [`Result`] ಬಳಸುವ ಮತ್ತು ದೋಷ ಪ್ರಕಾರವನ್ನು ನಿಯತಾಂಕಗೊಳಿಸುವ ಜೆನೆರಿಕ್ API ಗಳಿಗೆ ಇದು ಉಪಯುಕ್ತವಾಗಿರುತ್ತದೆ.
///
/// ಉದಾಹರಣೆಗೆ, ರಿವರ್ಸ್ [`Into`] ಅನುಷ್ಠಾನ ಇರುವ ಎಲ್ಲ ಪ್ರಕಾರಗಳಿಗೆ [`TryFrom`] trait ([`Result`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುವ ಪರಿವರ್ತನೆ) ಒಂದು ಕಂಬಳಿ ಅನುಷ್ಠಾನವನ್ನು ಹೊಂದಿದೆ.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future ಹೊಂದಾಣಿಕೆ
///
/// ಈ ಎನಮ್ [the `!`“never”type][never] ನಂತೆಯೇ ಪಾತ್ರವನ್ನು ಹೊಂದಿದೆ, ಇದು Rust ನ ಈ ಆವೃತ್ತಿಯಲ್ಲಿ ಅಸ್ಥಿರವಾಗಿದೆ.
/// `!` ಅನ್ನು ಸ್ಥಿರಗೊಳಿಸಿದಾಗ, ನಾವು `Infallible` ಅನ್ನು ಅದಕ್ಕೆ ಅಲಿಯಾಸ್ ಮಾಡಲು ಯೋಜಿಸುತ್ತೇವೆ:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …ಮತ್ತು ಅಂತಿಮವಾಗಿ `Infallible` ಅನ್ನು ಅಸಮ್ಮತಿಸುತ್ತದೆ.
///
/// ಆದಾಗ್ಯೂ, `!` ಅನ್ನು ಪೂರ್ಣ ಪ್ರಮಾಣದ ಪ್ರಕಾರವಾಗಿ ಸ್ಥಿರಗೊಳಿಸುವ ಮೊದಲು `!` ಸಿಂಟ್ಯಾಕ್ಸ್ ಅನ್ನು ಬಳಸಬಹುದಾದ ಒಂದು ಪ್ರಕರಣವಿದೆ: ಒಂದು ಕಾರ್ಯದ ರಿಟರ್ನ್ ಪ್ರಕಾರದ ಸ್ಥಾನದಲ್ಲಿ.
/// ನಿರ್ದಿಷ್ಟವಾಗಿ, ಎರಡು ವಿಭಿನ್ನ ಫಂಕ್ಷನ್ ಪಾಯಿಂಟರ್ ಪ್ರಕಾರಗಳಿಗೆ ಇದು ಅನುಷ್ಠಾನವಾಗಿದೆ:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// `Infallible` ಎನಮ್ ಆಗಿರುವುದರಿಂದ, ಈ ಕೋಡ್ ಮಾನ್ಯವಾಗಿದೆ.
/// ಆದಾಗ್ಯೂ, `Infallible` vern type ಗೆ ಅಲಿಯಾಸ್ ಆದಾಗ, ಎರಡು `impl` ಗಳು ಅತಿಕ್ರಮಿಸಲು ಪ್ರಾರಂಭವಾಗುತ್ತದೆ ಮತ್ತು ಆದ್ದರಿಂದ ಭಾಷೆಯ trait ಸುಸಂಬದ್ಧ ನಿಯಮಗಳಿಂದ ಇದನ್ನು ಅನುಮತಿಸಲಾಗುವುದಿಲ್ಲ.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}