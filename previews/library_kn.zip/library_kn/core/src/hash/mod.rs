//! ಜೆನೆರಿಕ್ ಹ್ಯಾಶಿಂಗ್ ಬೆಂಬಲ.
//!
//! ಈ ಮಾಡ್ಯೂಲ್ ಮೌಲ್ಯದ [hash] ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡಲು ಸಾಮಾನ್ಯ ಮಾರ್ಗವನ್ನು ಒದಗಿಸುತ್ತದೆ.
//! ಹ್ಯಾಶ್‌ಗಳನ್ನು ಸಾಮಾನ್ಯವಾಗಿ [`HashMap`] ಮತ್ತು [`HashSet`] ನೊಂದಿಗೆ ಬಳಸಲಾಗುತ್ತದೆ.
//!
//! [hash]: https://en.wikipedia.org/wiki/Hash_function
//! [`HashMap`]: ../../std/collections/struct.HashMap.html
//! [`HashSet`]: ../../std/collections/struct.HashSet.html
//!
//! ಹ್ಯಾಶ್ ಮಾಡಬಹುದಾದ ಪ್ರಕಾರವನ್ನು ಮಾಡಲು ಸರಳ ಮಾರ್ಗವೆಂದರೆ `#[derive(Hash)]` ಅನ್ನು ಬಳಸುವುದು:
//!
//! # Examples
//!
//! ```rust
//! use std::collections::hash_map::DefaultHasher;
//! use std::hash::{Hash, Hasher};
//!
//! #[derive(Hash)]
//! struct Person {
//!     id: u32,
//!     name: String,
//!     phone: u64,
//! }
//!
//! let person1 = Person {
//!     id: 5,
//!     name: "Janet".to_string(),
//!     phone: 555_666_7777,
//! };
//! let person2 = Person {
//!     id: 5,
//!     name: "Bob".to_string(),
//!     phone: 555_666_7777,
//! };
//!
//! assert!(calculate_hash(&person1) != calculate_hash(&person2));
//!
//! fn calculate_hash<T: Hash>(t: &T) -> u64 {
//!     let mut s = DefaultHasher::new();
//!     t.hash(&mut s);
//!     s.finish()
//! }
//! ```
//!
//! ಮೌಲ್ಯವನ್ನು ಹೇಗೆ ಹ್ಯಾಶ್ ಮಾಡಲಾಗಿದೆ ಎಂಬುದರ ಕುರಿತು ನಿಮಗೆ ಹೆಚ್ಚಿನ ನಿಯಂತ್ರಣ ಬೇಕಾದರೆ, ನೀವು [`Hash`] trait ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಬೇಕು:
//!
//!
//! ```rust
//! use std::collections::hash_map::DefaultHasher;
//! use std::hash::{Hash, Hasher};
//!
//! struct Person {
//!     id: u32,
//!     # #[allow(dead_code)]
//!     name: String,
//!     phone: u64,
//! }
//!
//! impl Hash for Person {
//!     fn hash<H: Hasher>(&self, state: &mut H) {
//!         self.id.hash(state);
//!         self.phone.hash(state);
//!     }
//! }
//!
//! let person1 = Person {
//!     id: 5,
//!     name: "Janet".to_string(),
//!     phone: 555_666_7777,
//! };
//! let person2 = Person {
//!     id: 5,
//!     name: "Bob".to_string(),
//!     phone: 555_666_7777,
//! };
//!
//! assert_eq!(calculate_hash(&person1), calculate_hash(&person2));
//!
//! fn calculate_hash<T: Hash>(t: &T) -> u64 {
//!     let mut s = DefaultHasher::new();
//!     t.hash(&mut s);
//!     s.finish()
//! }
//! ```

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::marker;

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use self::sip::SipHasher;

#[unstable(feature = "hashmap_internals", issue = "none")]
#[allow(deprecated)]
#[doc(hidden)]
pub use self::sip::SipHasher13;

mod sip;

/// ಹ್ಯಾಶ್ ಮಾಡಬಹುದಾದ ಪ್ರಕಾರ.
///
/// `Hash` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಪ್ರಕಾರಗಳು [`Hasher`] ನ ಉದಾಹರಣೆಯೊಂದಿಗೆ [`ಹ್ಯಾಶ್`] ಎಡ್ ಆಗಲು ಸಾಧ್ಯವಾಗುತ್ತದೆ.
///
/// ## `Hash` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗುತ್ತಿದೆ
///
/// ಎಲ್ಲಾ ಕ್ಷೇತ್ರಗಳು `Hash` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದರೆ ನೀವು `Hash` ಅನ್ನು `#[derive(Hash)]` ನೊಂದಿಗೆ ಪಡೆಯಬಹುದು.
/// ಪರಿಣಾಮವಾಗಿ ಬರುವ ಹ್ಯಾಶ್ ಪ್ರತಿ ಕ್ಷೇತ್ರದಲ್ಲಿ [`hash`] ಗೆ ಕರೆ ಮಾಡುವುದರಿಂದ ಮೌಲ್ಯಗಳ ಸಂಯೋಜನೆಯಾಗಿರುತ್ತದೆ.
///
/// ```
/// #[derive(Hash)]
/// struct Rustacean {
///     name: String,
///     country: String,
/// }
/// ```
///
/// ಮೌಲ್ಯವನ್ನು ಹೇಗೆ ಹ್ಯಾಶ್ ಮಾಡಲಾಗಿದೆ ಎಂಬುದರ ಕುರಿತು ನಿಮಗೆ ಹೆಚ್ಚಿನ ನಿಯಂತ್ರಣ ಬೇಕಾದರೆ, ನೀವು ಖಂಡಿತವಾಗಿಯೂ `Hash` trait ಅನ್ನು ನೀವೇ ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು:
///
/// ```
/// use std::hash::{Hash, Hasher};
///
/// struct Person {
///     id: u32,
///     name: String,
///     phone: u64,
/// }
///
/// impl Hash for Person {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         self.id.hash(state);
///         self.phone.hash(state);
///     }
/// }
/// ```
///
/// ## `Hash` ಮತ್ತು `Eq`
///
/// `Hash` ಮತ್ತು [`Eq`] ಎರಡನ್ನೂ ಕಾರ್ಯಗತಗೊಳಿಸುವಾಗ, ಈ ಕೆಳಗಿನ ಆಸ್ತಿಯನ್ನು ಹೊಂದಿರುವುದು ಬಹಳ ಮುಖ್ಯ:
///
/// ```text
/// k1 == k2 -> hash(k1) == hash(k2)
/// ```
///
/// ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, ಎರಡು ಕೀಲಿಗಳು ಸಮಾನವಾಗಿದ್ದರೆ, ಅವುಗಳ ಹ್ಯಾಶ್‌ಗಳು ಸಹ ಸಮಾನವಾಗಿರಬೇಕು.
/// [`HashMap`] ಮತ್ತು [`HashSet`] ಎರಡೂ ಈ ನಡವಳಿಕೆಯನ್ನು ಅವಲಂಬಿಸಿವೆ.
///
/// ಅದೃಷ್ಟವಶಾತ್, `#[derive(PartialEq, Eq, Hash)]` ನೊಂದಿಗೆ [`Eq`] ಮತ್ತು `Hash` ಎರಡನ್ನೂ ಪಡೆಯುವಾಗ ಈ ಆಸ್ತಿಯನ್ನು ಎತ್ತಿಹಿಡಿಯುವ ಬಗ್ಗೆ ನೀವು ಚಿಂತಿಸಬೇಕಾಗಿಲ್ಲ.
///
///
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
/// [`HashSet`]: ../../std/collections/struct.HashSet.html
/// [`hash`]: Hash::hash
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Hash {
    /// ಕೊಟ್ಟಿರುವ [`Hasher`] ಗೆ ಈ ಮೌಲ್ಯವನ್ನು ಫೀಡ್ ಮಾಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::{Hash, Hasher};
    ///
    /// let mut hasher = DefaultHasher::new();
    /// 7920.hash(&mut hasher);
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn hash<H: Hasher>(&self, state: &mut H);

    /// ಕೊಟ್ಟಿರುವ [`Hasher`] ಗೆ ಈ ಪ್ರಕಾರದ ಸ್ಲೈಸ್ ಅನ್ನು ಫೀಡ್ ಮಾಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::{Hash, Hasher};
    ///
    /// let mut hasher = DefaultHasher::new();
    /// let numbers = [6, 28, 496, 8128];
    /// Hash::hash_slice(&numbers, &mut hasher);
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "hash_slice", since = "1.3.0")]
    fn hash_slice<H: Hasher>(data: &[Self], state: &mut H)
    where
        Self: Sized,
    {
        for piece in data {
            piece.hash(state);
        }
    }
}

// trait `Hash` ಇಲ್ಲದೆ prelude ನಿಂದ ಮ್ಯಾಕ್ರೋ `Hash` ಅನ್ನು ಮರು ರಫ್ತು ಮಾಡಲು ಪ್ರತ್ಯೇಕ ಮಾಡ್ಯೂಲ್.
pub(crate) mod macros {
    /// trait `Hash` ನ impl ಅನ್ನು ಉತ್ಪಾದಿಸುವ ಮ್ಯಾಕ್ರೋ ಅನ್ನು ಪಡೆಯಿರಿ.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Hash($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Hash;

/// ಬೈಟ್‌ಗಳ ಅನಿಯಂತ್ರಿತ ಸ್ಟ್ರೀಮ್ ಅನ್ನು ಹ್ಯಾಶಿಂಗ್ ಮಾಡಲು trait.
///
/// `Hasher` ನ ನಿದರ್ಶನಗಳು ಸಾಮಾನ್ಯವಾಗಿ ಡೇಟಾವನ್ನು ಹ್ಯಾಶಿಂಗ್ ಮಾಡುವಾಗ ಬದಲಾದ ಸ್ಥಿತಿಯನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತವೆ.
///
/// `Hasher` ರಚಿತವಾದ ಹ್ಯಾಶ್ ಅನ್ನು ([`finish`] ನೊಂದಿಗೆ) ಹಿಂಪಡೆಯಲು ಸಾಕಷ್ಟು ಮೂಲ ಇಂಟರ್ಫೇಸ್ ಅನ್ನು ಒದಗಿಸುತ್ತದೆ, ಮತ್ತು ಪೂರ್ಣಾಂಕಗಳನ್ನು ಮತ್ತು ಬೈಟ್‌ಗಳ ಚೂರುಗಳನ್ನು ಒಂದು ಉದಾಹರಣೆಯಾಗಿ ಬರೆಯುವುದು ([`write`] ಮತ್ತು [`write_u8`] ಇತ್ಯಾದಿಗಳೊಂದಿಗೆ).
/// ಹೆಚ್ಚಿನ ಸಮಯ, `Hasher` ನಿದರ್ಶನಗಳನ್ನು [`Hash`] trait ನೊಂದಿಗೆ ಬಳಸಲಾಗುತ್ತದೆ.
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::Hasher;
///
/// let mut hasher = DefaultHasher::new();
///
/// hasher.write_u32(1989);
/// hasher.write_u8(11);
/// hasher.write_u8(9);
/// hasher.write(b"Huh?");
///
/// println!("Hash is {:x}!", hasher.finish());
/// ```
///
/// [`finish`]: Hasher::finish
/// [`write`]: Hasher::write
/// [`write_u8`]: Hasher::write_u8
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Hasher {
    /// ಇಲ್ಲಿಯವರೆಗೆ ಬರೆದ ಮೌಲ್ಯಗಳಿಗೆ ಹ್ಯಾಶ್ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಅದರ ಹೆಸರಿನ ಹೊರತಾಗಿಯೂ, ವಿಧಾನವು ಹ್ಯಾಶರ್ನ ಆಂತರಿಕ ಸ್ಥಿತಿಯನ್ನು ಮರುಹೊಂದಿಸುವುದಿಲ್ಲ.
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದಿಂದ ಹೆಚ್ಚುವರಿ [`ಬರೆಯಿರಿ] ಗಳು ಮುಂದುವರಿಯುತ್ತವೆ.
    /// ನೀವು ಹೊಸ ಹ್ಯಾಶ್ ಮೌಲ್ಯವನ್ನು ಪ್ರಾರಂಭಿಸಬೇಕಾದರೆ, ನೀವು ಹೊಸ ಹ್ಯಾಶರ್ ಅನ್ನು ರಚಿಸಬೇಕಾಗುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::Hasher;
    ///
    /// let mut hasher = DefaultHasher::new();
    /// hasher.write(b"Cool!");
    ///
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    ///
    /// [`write`]: Hasher::write
    #[stable(feature = "rust1", since = "1.0.0")]
    fn finish(&self) -> u64;

    /// ಈ `Hasher` ಗೆ ಕೆಲವು ಡೇಟಾವನ್ನು ಬರೆಯುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::Hasher;
    ///
    /// let mut hasher = DefaultHasher::new();
    /// let data = [0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef];
    ///
    /// hasher.write(&data);
    ///
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write(&mut self, bytes: &[u8]);

    /// ಈ ಹ್ಯಾಶರ್‌ಗೆ ಒಂದೇ `u8` ಅನ್ನು ಬರೆಯುತ್ತದೆ.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u8(&mut self, i: u8) {
        self.write(&[i])
    }
    /// ಈ ಹ್ಯಾಶರ್‌ಗೆ ಒಂದೇ `u16` ಅನ್ನು ಬರೆಯುತ್ತದೆ.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u16(&mut self, i: u16) {
        self.write(&i.to_ne_bytes())
    }
    /// ಈ ಹ್ಯಾಶರ್‌ಗೆ ಒಂದೇ `u32` ಅನ್ನು ಬರೆಯುತ್ತದೆ.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u32(&mut self, i: u32) {
        self.write(&i.to_ne_bytes())
    }
    /// ಈ ಹ್ಯಾಶರ್‌ಗೆ ಒಂದೇ `u64` ಅನ್ನು ಬರೆಯುತ್ತದೆ.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u64(&mut self, i: u64) {
        self.write(&i.to_ne_bytes())
    }
    /// ಈ ಹ್ಯಾಶರ್‌ಗೆ ಒಂದೇ `u128` ಅನ್ನು ಬರೆಯುತ್ತದೆ.
    #[inline]
    #[stable(feature = "i128", since = "1.26.0")]
    fn write_u128(&mut self, i: u128) {
        self.write(&i.to_ne_bytes())
    }
    /// ಈ ಹ್ಯಾಶರ್‌ಗೆ ಒಂದೇ `usize` ಅನ್ನು ಬರೆಯುತ್ತದೆ.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_usize(&mut self, i: usize) {
        self.write(&i.to_ne_bytes())
    }

    /// ಈ ಹ್ಯಾಶರ್‌ಗೆ ಒಂದೇ `i8` ಅನ್ನು ಬರೆಯುತ್ತದೆ.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i8(&mut self, i: i8) {
        self.write_u8(i as u8)
    }
    /// ಈ ಹ್ಯಾಶರ್‌ಗೆ ಒಂದೇ `i16` ಅನ್ನು ಬರೆಯುತ್ತದೆ.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i16(&mut self, i: i16) {
        self.write_u16(i as u16)
    }
    /// ಈ ಹ್ಯಾಶರ್‌ಗೆ ಒಂದೇ `i32` ಅನ್ನು ಬರೆಯುತ್ತದೆ.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i32(&mut self, i: i32) {
        self.write_u32(i as u32)
    }
    /// ಈ ಹ್ಯಾಶರ್‌ಗೆ ಒಂದೇ `i64` ಅನ್ನು ಬರೆಯುತ್ತದೆ.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i64(&mut self, i: i64) {
        self.write_u64(i as u64)
    }
    /// ಈ ಹ್ಯಾಶರ್‌ಗೆ ಒಂದೇ `i128` ಅನ್ನು ಬರೆಯುತ್ತದೆ.
    #[inline]
    #[stable(feature = "i128", since = "1.26.0")]
    fn write_i128(&mut self, i: i128) {
        self.write_u128(i as u128)
    }
    /// ಈ ಹ್ಯಾಶರ್‌ಗೆ ಒಂದೇ `isize` ಅನ್ನು ಬರೆಯುತ್ತದೆ.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_isize(&mut self, i: isize) {
        self.write_usize(i as usize)
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<H: Hasher + ?Sized> Hasher for &mut H {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

/// [`Hasher`] ನ ನಿದರ್ಶನಗಳನ್ನು ರಚಿಸಲು trait.
///
/// ಪ್ರತಿ ಕೀಲಿಗಾಗಿ [`ಹ್ಯಾಶರ್] ಗಳನ್ನು ರಚಿಸಲು `BuildHasher` ಅನ್ನು ಸಾಮಾನ್ಯವಾಗಿ ಬಳಸಲಾಗುತ್ತದೆ (ಉದಾ. [`HashMap`] ನಿಂದ), ಅವುಗಳು ಒಂದರಿಂದ ಸ್ವತಂತ್ರವಾಗಿ ಹ್ಯಾಶ್ ಆಗುತ್ತವೆ, ಏಕೆಂದರೆ [` ಹ್ಯಾಶರ್] ಸ್ಥಿತಿಯನ್ನು ಹೊಂದಿರುತ್ತದೆ.
///
///
/// `BuildHasher` ನ ಪ್ರತಿಯೊಂದು ನಿದರ್ಶನಕ್ಕೂ, [`build_hasher`] ನಿಂದ ರಚಿಸಲಾದ [`ಹ್ಯಾಶರ್`] ಗಳು ಒಂದೇ ಆಗಿರಬೇಕು.
/// ಅಂದರೆ, ಪ್ರತಿ ಹ್ಯಾಶರ್‌ಗೆ ಒಂದೇ ರೀತಿಯ ಬೈಟ್‌ಗಳನ್ನು ನೀಡಿದರೆ, ಅದೇ output ಟ್‌ಪುಟ್ ಸಹ ಉತ್ಪತ್ತಿಯಾಗುತ್ತದೆ.
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::RandomState;
/// use std::hash::{BuildHasher, Hasher};
///
/// let s = RandomState::new();
/// let mut hasher_1 = s.build_hasher();
/// let mut hasher_2 = s.build_hasher();
///
/// hasher_1.write_u32(8128);
/// hasher_2.write_u32(8128);
///
/// assert_eq!(hasher_1.finish(), hasher_2.finish());
/// ```
///
/// [`build_hasher`]: BuildHasher::build_hasher
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
///
#[stable(since = "1.7.0", feature = "build_hasher")]
pub trait BuildHasher {
    /// ರಚಿಸಲಾಗುವ ಹ್ಯಾಶರ್ ಪ್ರಕಾರ.
    #[stable(since = "1.7.0", feature = "build_hasher")]
    type Hasher: Hasher;

    /// ಹೊಸ ಹ್ಯಾಶರ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// ಒಂದೇ ಸಂದರ್ಭದಲ್ಲಿ `build_hasher` ಗೆ ಪ್ರತಿ ಕರೆ ಒಂದೇ ರೀತಿಯ [`ಹ್ಯಾಶರ್`] ಗಳನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::RandomState;
    /// use std::hash::BuildHasher;
    ///
    /// let s = RandomState::new();
    /// let new_s = s.build_hasher();
    /// ```
    #[stable(since = "1.7.0", feature = "build_hasher")]
    fn build_hasher(&self) -> Self::Hasher;
}

/// [`Hasher`] ಮತ್ತು [`Default`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಪ್ರಕಾರಗಳಿಗಾಗಿ ಡೀಫಾಲ್ಟ್ [`BuildHasher`] ನಿದರ್ಶನವನ್ನು ರಚಿಸಲು ಬಳಸಲಾಗುತ್ತದೆ.
///
/// `BuildHasherDefault<H>` `H` ಪ್ರಕಾರವು [`Hasher`] ಮತ್ತು [`Default`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದಾಗ ಬಳಸಬಹುದು, ಮತ್ತು ನಿಮಗೆ ಅನುಗುಣವಾದ [`BuildHasher`] ನಿದರ್ಶನ ಬೇಕಾಗುತ್ತದೆ, ಆದರೆ ಯಾವುದನ್ನೂ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿಲ್ಲ.
///
///
/// ಯಾವುದೇ `BuildHasherDefault` [zero-sized] ಆಗಿದೆ.ಇದನ್ನು [`default`][method.default] ನೊಂದಿಗೆ ರಚಿಸಬಹುದು.
/// [`HashMap`] ಅಥವಾ [`HashSet`] ನೊಂದಿಗೆ `BuildHasherDefault` ಅನ್ನು ಬಳಸುವಾಗ, ಇದನ್ನು ಮಾಡಬೇಕಾಗಿಲ್ಲ, ಏಕೆಂದರೆ ಅವುಗಳು ಸೂಕ್ತವಾದ [`Default`] ನಿದರ್ಶನಗಳನ್ನು ಸ್ವತಃ ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತವೆ.
///
/// # Examples
///
/// ಕಸ್ಟಮ್ [`BuildHasher`] ಅನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಲು `BuildHasherDefault` ಅನ್ನು ಬಳಸುವುದು
/// [`HashMap`]:
///
/// ```
/// use std::collections::HashMap;
/// use std::hash::{BuildHasherDefault, Hasher};
///
/// #[derive(Default)]
/// struct MyHasher;
///
/// impl Hasher for MyHasher {
///     fn write(&mut self, bytes: &[u8]) {
///         // ನಿಮ್ಮ ಹ್ಯಾಶಿಂಗ್ ಅಲ್ಗಾರಿದಮ್ ಇಲ್ಲಿಗೆ ಹೋಗುತ್ತದೆ!
///        unimplemented!()
///     }
///
///     fn finish(&self) -> u64 {
///         // ನಿಮ್ಮ ಹ್ಯಾಶಿಂಗ್ ಅಲ್ಗಾರಿದಮ್ ಇಲ್ಲಿಗೆ ಹೋಗುತ್ತದೆ!
///         unimplemented!()
///     }
/// }
///
/// type MyBuildHasher = BuildHasherDefault<MyHasher>;
///
/// let hash_map = HashMap::<u32, u32, MyBuildHasher>::default();
/// ```
///
/// [method.default]: BuildHasherDefault::default
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
/// [`HashSet`]: ../../std/collections/struct.HashSet.html
/// [zero-sized]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#zero-sized-types-zsts
///
///
///
///
#[stable(since = "1.7.0", feature = "build_hasher")]
pub struct BuildHasherDefault<H>(marker::PhantomData<H>);

#[stable(since = "1.9.0", feature = "core_impl_debug")]
impl<H> fmt::Debug for BuildHasherDefault<H> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("BuildHasherDefault")
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H: Default + Hasher> BuildHasher for BuildHasherDefault<H> {
    type Hasher = H;

    fn build_hasher(&self) -> H {
        H::default()
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H> Clone for BuildHasherDefault<H> {
    fn clone(&self) -> BuildHasherDefault<H> {
        BuildHasherDefault(marker::PhantomData)
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H> Default for BuildHasherDefault<H> {
    fn default() -> BuildHasherDefault<H> {
        BuildHasherDefault(marker::PhantomData)
    }
}

#[stable(since = "1.29.0", feature = "build_hasher_eq")]
impl<H> PartialEq for BuildHasherDefault<H> {
    fn eq(&self, _other: &BuildHasherDefault<H>) -> bool {
        true
    }
}

#[stable(since = "1.29.0", feature = "build_hasher_eq")]
impl<H> Eq for BuildHasherDefault<H> {}

mod impls {
    use crate::mem;
    use crate::slice;

    use super::*;

    macro_rules! impl_write {
        ($(($ty:ident, $meth:ident),)*) => {$(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Hash for $ty {
                #[inline]
                fn hash<H: Hasher>(&self, state: &mut H) {
                    state.$meth(*self)
                }

                #[inline]
                fn hash_slice<H: Hasher>(data: &[$ty], state: &mut H) {
                    let newlen = data.len() * mem::size_of::<$ty>();
                    let ptr = data.as_ptr() as *const u8;
                    // ಸುರಕ್ಷತೆ: ಈ ಮ್ಯಾಕ್ರೋವನ್ನು ಮಾತ್ರ ಬಳಸುವುದರಿಂದ `ptr` ಮಾನ್ಯವಾಗಿದೆ ಮತ್ತು ಜೋಡಿಸಲಾಗಿದೆ
                    // ಪ್ಯಾಡಿಂಗ್ ಇಲ್ಲದ ಸಂಖ್ಯಾ ಆದಿಮಗಳಿಗೆ.
                    // ಹೊಸ ಸ್ಲೈಸ್ `data` ನಲ್ಲಿ ಮಾತ್ರ ವ್ಯಾಪಿಸಿದೆ ಮತ್ತು ಅದು ಎಂದಿಗೂ ರೂಪಾಂತರಗೊಳ್ಳುವುದಿಲ್ಲ, ಮತ್ತು ಅದರ ಒಟ್ಟು ಗಾತ್ರವು ಮೂಲ `data` ನಂತೆಯೇ ಇರುತ್ತದೆ ಆದ್ದರಿಂದ ಅದು `isize::MAX` ಗಿಂತ ಹೆಚ್ಚಿರಬಾರದು.
                    //
                    state.write(unsafe { slice::from_raw_parts(ptr, newlen) })
                }
            }
        )*}
    }

    impl_write! {
        (u8, write_u8),
        (u16, write_u16),
        (u32, write_u32),
        (u64, write_u64),
        (usize, write_usize),
        (i8, write_i8),
        (i16, write_i16),
        (i32, write_i32),
        (i64, write_i64),
        (isize, write_isize),
        (u128, write_u128),
        (i128, write_i128),
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for bool {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write_u8(*self as u8)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for char {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write_u32(*self as u32)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for str {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write(self.as_bytes());
            state.write_u8(0xff)
        }
    }

    #[stable(feature = "never_hash", since = "1.29.0")]
    impl Hash for ! {
        #[inline]
        fn hash<H: Hasher>(&self, _: &mut H) {
            *self
        }
    }

    macro_rules! impl_hash_tuple {
        () => (
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Hash for () {
                #[inline]
                fn hash<H: Hasher>(&self, _state: &mut H) {}
            }
        );

        ( $($name:ident)+) => (
            #[stable(feature = "rust1", since = "1.0.0")]
            impl<$($name: Hash),+> Hash for ($($name,)+) where last_type!($($name,)+): ?Sized {
                #[allow(non_snake_case)]
                #[inline]
                fn hash<S: Hasher>(&self, state: &mut S) {
                    let ($(ref $name,)+) = *self;
                    $($name.hash(state);)+
                }
            }
        );
    }

    macro_rules! last_type {
        ($a:ident,) => { $a };
        ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
    }

    impl_hash_tuple! {}
    impl_hash_tuple! { A }
    impl_hash_tuple! { A B }
    impl_hash_tuple! { A B C }
    impl_hash_tuple! { A B C D }
    impl_hash_tuple! { A B C D E }
    impl_hash_tuple! { A B C D E F }
    impl_hash_tuple! { A B C D E F G }
    impl_hash_tuple! { A B C D E F G H }
    impl_hash_tuple! { A B C D E F G H I }
    impl_hash_tuple! { A B C D E F G H I J }
    impl_hash_tuple! { A B C D E F G H I J K }
    impl_hash_tuple! { A B C D E F G H I J K L }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: Hash> Hash for [T] {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            self.len().hash(state);
            Hash::hash_slice(self, state)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized + Hash> Hash for &T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            (**self).hash(state);
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized + Hash> Hash for &mut T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            (**self).hash(state);
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Hash for *const T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            #[cfg(not(bootstrap))]
            {
                let (address, metadata) = self.to_raw_parts();
                state.write_usize(address as usize);
                metadata.hash(state);
            }
            #[cfg(bootstrap)]
            {
                if mem::size_of::<Self>() == mem::size_of::<usize>() {
                    // ತೆಳುವಾದ ಪಾಯಿಂಟರ್
                    state.write_usize(*self as *const () as usize);
                } else {
                    // ಫ್ಯಾಟ್ ಪಾಯಿಂಟರ್ ಸುರಕ್ಷತೆ: ನಾವು `self` ಆಕ್ರಮಿಸಿಕೊಂಡಿರುವ ಮೆಮೊರಿಯನ್ನು ಪ್ರವೇಶಿಸುತ್ತಿದ್ದೇವೆ ಅದು ಮಾನ್ಯ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.
                    // ಕೊಬ್ಬಿನ ಪಾಯಿಂಟರ್ ಅನ್ನು `(usize, usize)` ನಿಂದ ಪ್ರತಿನಿಧಿಸಬಹುದು ಎಂದು ಇದು umes ಹಿಸುತ್ತದೆ, ಇದು `std` ನಲ್ಲಿ ಮಾಡಲು ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ಇದನ್ನು `rustc` ನಲ್ಲಿ ಕೊಬ್ಬು ಪಾಯಿಂಟರ್‌ಗಳ ಅನುಷ್ಠಾನದೊಂದಿಗೆ ರವಾನಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ಸಿಂಕ್ ಮಾಡಲಾಗುತ್ತದೆ.
                    //
                    //
                    //
                    //
                    let (a, b) = unsafe { *(self as *const Self as *const (usize, usize)) };
                    state.write_usize(a);
                    state.write_usize(b);
                }
            }
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Hash for *mut T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            #[cfg(not(bootstrap))]
            {
                let (address, metadata) = self.to_raw_parts();
                state.write_usize(address as usize);
                metadata.hash(state);
            }
            #[cfg(bootstrap)]
            {
                if mem::size_of::<Self>() == mem::size_of::<usize>() {
                    // ತೆಳುವಾದ ಪಾಯಿಂಟರ್
                    state.write_usize(*self as *const () as usize);
                } else {
                    // ಫ್ಯಾಟ್ ಪಾಯಿಂಟರ್ ಸುರಕ್ಷತೆ: ನಾವು `self` ಆಕ್ರಮಿಸಿಕೊಂಡಿರುವ ಮೆಮೊರಿಯನ್ನು ಪ್ರವೇಶಿಸುತ್ತಿದ್ದೇವೆ ಅದು ಮಾನ್ಯ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.
                    // ಕೊಬ್ಬಿನ ಪಾಯಿಂಟರ್ ಅನ್ನು `(usize, usize)` ನಿಂದ ಪ್ರತಿನಿಧಿಸಬಹುದು ಎಂದು ಇದು umes ಹಿಸುತ್ತದೆ, ಇದು `std` ನಲ್ಲಿ ಮಾಡಲು ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ಇದನ್ನು `rustc` ನಲ್ಲಿ ಕೊಬ್ಬು ಪಾಯಿಂಟರ್‌ಗಳ ಅನುಷ್ಠಾನದೊಂದಿಗೆ ರವಾನಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ಸಿಂಕ್ ಮಾಡಲಾಗುತ್ತದೆ.
                    //
                    //
                    //
                    //
                    let (a, b) = unsafe { *(self as *const Self as *const (usize, usize)) };
                    state.write_usize(a);
                    state.write_usize(b);
                }
            }
        }
    }
}