//! ಸಿಪ್ ಹ್ಯಾಶ್ನ ಅನುಷ್ಠಾನ.

#![allow(deprecated)] // ಈ ಮಾಡ್ಯೂಲ್‌ನಲ್ಲಿರುವ ಪ್ರಕಾರಗಳನ್ನು ಅಸಮ್ಮತಿಸಲಾಗಿದೆ

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// ಸಿಪ್ ಹ್ಯಾಶ್ 1-3ರ ಅನುಷ್ಠಾನ.
///
/// ಇದು ಪ್ರಸ್ತುತ ಸ್ಟ್ಯಾಂಡರ್ಡ್ ಲೈಬ್ರರಿಯಿಂದ ಬಳಸಲ್ಪಡುವ ಡೀಫಾಲ್ಟ್ ಹ್ಯಾಶಿಂಗ್ ಕಾರ್ಯವಾಗಿದೆ (ಉದಾ., `collections::HashMap` ಇದನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಬಳಸುತ್ತದೆ).
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// ಸಿಪ್ ಹ್ಯಾಶ್ 2-4 ರ ಅನುಷ್ಠಾನ.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// ಸಿಪ್ ಹ್ಯಾಶ್ 2-4 ರ ಅನುಷ್ಠಾನ.
///
/// See: <https://131002.net/siphash/>
///
/// ಸಿಪ್ ಹ್ಯಾಶ್ ಸಾಮಾನ್ಯ ಉದ್ದೇಶದ ಹ್ಯಾಶಿಂಗ್ ಕಾರ್ಯವಾಗಿದೆ: ಇದು ಉತ್ತಮ ವೇಗದಲ್ಲಿ ಚಲಿಸುತ್ತದೆ (ಸ್ಪೂಕಿ ಮತ್ತು ಸಿಟಿಯೊಂದಿಗೆ ಸ್ಪರ್ಧಾತ್ಮಕವಾಗಿದೆ) ಮತ್ತು ಬಲವಾದ _keyed_ ಹ್ಯಾಶಿಂಗ್ ಅನ್ನು ಅನುಮತಿಸುತ್ತದೆ.
///
/// [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html) ನಂತಹ ಬಲವಾದ RNG ಯಿಂದ ನಿಮ್ಮ ಹ್ಯಾಶ್ ಕೋಷ್ಟಕಗಳನ್ನು ಕೀಲಿಯಾಗಿಸಲು ಇದು ನಿಮ್ಮನ್ನು ಅನುಮತಿಸುತ್ತದೆ.
///
/// ಸಿಪ್ ಹ್ಯಾಶ್ ಅಲ್ಗಾರಿದಮ್ ಅನ್ನು ಸಾಮಾನ್ಯವಾಗಿ ಪ್ರಬಲವೆಂದು ಪರಿಗಣಿಸಲಾಗಿದ್ದರೂ, ಇದು ಕ್ರಿಪ್ಟೋಗ್ರಾಫಿಕ್ ಉದ್ದೇಶಗಳಿಗಾಗಿ ಉದ್ದೇಶಿಸಿಲ್ಲ.
/// ಅಂತೆಯೇ, ಈ ಅನುಷ್ಠಾನದ ಎಲ್ಲಾ ಕ್ರಿಪ್ಟೋಗ್ರಾಫಿಕ್ ಉಪಯೋಗಗಳು _strongly discouraged_.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // ನಾವು ಎಷ್ಟು ಬೈಟ್‌ಗಳನ್ನು ಪ್ರಕ್ರಿಯೆಗೊಳಿಸಿದ್ದೇವೆ
    state: State,  // ಹ್ಯಾಶ್ ರಾಜ್ಯ
    tail: u64,     // ಸಂಸ್ಕರಿಸದ ಬೈಟ್‌ಗಳು ಲೆ
    ntail: usize,  // ಬಾಲದಲ್ಲಿ ಎಷ್ಟು ಬೈಟ್‌ಗಳು ಮಾನ್ಯವಾಗಿವೆ
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 ಮತ್ತು v1, v3 ಅಲ್ಗಾರಿದಮ್‌ನಲ್ಲಿ ಜೋಡಿಯಾಗಿ ತೋರಿಸುತ್ತವೆ, ಮತ್ತು ಸಿಪ್‌ಹ್ಯಾಶ್‌ನ ಸಿಮ್ಡ್ ಅನುಷ್ಠಾನಗಳು v02 ಮತ್ತು v13 ನ vectors ಅನ್ನು ಬಳಸುತ್ತವೆ.
    //
    // ಅವುಗಳನ್ನು ಈ ಕ್ರಮದಲ್ಲಿ ರಚನೆಯಲ್ಲಿ ಇರಿಸುವ ಮೂಲಕ, ಕಂಪೈಲರ್ ಸ್ವತಃ ಕೆಲವು ಸಿಮ್ಡ್ ಆಪ್ಟಿಮೈಸೇಶನ್‌ಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳಬಹುದು.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// LE ಕ್ರಮದಲ್ಲಿ, ಬೈಟ್ ಸ್ಟ್ರೀಮ್‌ನಿಂದ ಅಪೇಕ್ಷಿತ ಪ್ರಕಾರದ ಪೂರ್ಣಾಂಕವನ್ನು ಲೋಡ್ ಮಾಡುತ್ತದೆ.
/// ಬಹುಶಃ ಜೋಡಿಸದ ವಿಳಾಸದಿಂದ ಅದನ್ನು ಲೋಡ್ ಮಾಡಲು ಕಂಪೈಲರ್ ಅತ್ಯಂತ ಪರಿಣಾಮಕಾರಿ ಮಾರ್ಗವನ್ನು ರಚಿಸಲು `copy_nonoverlapping` ಅನ್ನು ಬಳಸುತ್ತದೆ.
///
///
/// ಅಸುರಕ್ಷಿತ ಏಕೆಂದರೆ: i..i+size_of(int_ty) ನಲ್ಲಿ ಪರಿಶೀಲಿಸದ ಸೂಚಿಕೆ
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// ಬೈಟ್ ಸ್ಲೈಸ್‌ನ 7 ಬೈಟ್‌ಗಳವರೆಗೆ u64 ಅನ್ನು ಲೋಡ್ ಮಾಡುತ್ತದೆ.
/// ಇದು ವಿಕಾರವಾಗಿ ಕಾಣುತ್ತದೆ ಆದರೆ ಸಂಭವಿಸುವ `copy_nonoverlapping` ಕರೆಗಳು (`load_int_le!` ಮೂಲಕ) ಎಲ್ಲವೂ ಸ್ಥಿರ ಗಾತ್ರವನ್ನು ಹೊಂದಿವೆ ಮತ್ತು `memcpy` ಗೆ ಕರೆ ಮಾಡುವುದನ್ನು ತಪ್ಪಿಸಿ, ಇದು ವೇಗಕ್ಕೆ ಒಳ್ಳೆಯದು.
///
///
/// ಅಸುರಕ್ಷಿತ ಏಕೆಂದರೆ: ಪ್ರಾರಂಭದಲ್ಲಿ ಪರಿಶೀಲಿಸದ ಸೂಚಿಕೆ..ಸ್ಟಾರ್ಟ್ + ಲೆನ್
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // X ಟ್ಪುಟ್ u64 ನಲ್ಲಿ ಪ್ರಸ್ತುತ ಬೈಟ್ ಸೂಚ್ಯಂಕ (ಎಲ್ಎಸ್ಬಿಯಿಂದ)
    let mut out = 0;
    if i + 3 < len {
        // ಸುರಕ್ಷತೆ: `i` `len` ಗಿಂತ ಹೆಚ್ಚಿರಬಾರದು ಮತ್ತು ಕರೆ ಮಾಡುವವರು ಖಾತರಿಪಡಿಸಬೇಕು
        // ಸೂಚ್ಯಂಕ ಪ್ರಾರಂಭ..ಸ್ಟಾರ್ಟ್ + ಲೆನ್ ಮಿತಿಯಲ್ಲಿದೆ.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // ಸುರಕ್ಷತೆ: ಮೇಲಿನಂತೆಯೇ.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // ಸುರಕ್ಷತೆ: ಮೇಲಿನಂತೆಯೇ.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// 0 ಗೆ ಹೊಂದಿಸಲಾದ ಎರಡು ಆರಂಭಿಕ ಕೀಲಿಗಳೊಂದಿಗೆ ಹೊಸ `SipHasher` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// ಒದಗಿಸಿದ ಕೀಲಿಗಳನ್ನು ಕೀಲಿ ಮಾಡಿದ `SipHasher` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// 0 ಗೆ ಹೊಂದಿಸಲಾದ ಎರಡು ಆರಂಭಿಕ ಕೀಲಿಗಳೊಂದಿಗೆ ಹೊಸ `SipHasher13` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// ಒದಗಿಸಿದ ಕೀಲಿಗಳನ್ನು ಕೀಲಿ ಮಾಡಿದ `SipHasher13` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: ಯಾವುದೇ ಪೂರ್ಣಾಂಕ ಹ್ಯಾಶಿಂಗ್ ವಿಧಾನಗಳನ್ನು (`write_u *`, `write_i*`) ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿಲ್ಲ
    // ಈ ಪ್ರಕಾರಕ್ಕಾಗಿ.
    // ನಾವು ಅವುಗಳನ್ನು ಸೇರಿಸಬಹುದು, librustc_data_structures/sip128.rs ನಲ್ಲಿ `short_write` ಅನುಷ್ಠಾನವನ್ನು ನಕಲಿಸಬಹುದು ಮತ್ತು `SipHasher`, `SipHasher13` ಮತ್ತು `DefaultHasher` ಗೆ `write_u *`/`write_i*` ವಿಧಾನಗಳನ್ನು ಸೇರಿಸಬಹುದು.
    //
    // ಕೆಲವು ಮಾನದಂಡಗಳಲ್ಲಿ ಕಂಪೈಲ್ ವೇಗವನ್ನು ಸ್ವಲ್ಪ ನಿಧಾನಗೊಳಿಸುವ ವೆಚ್ಚದಲ್ಲಿ, ಆ ಹ್ಯಾಶರ್‌ಗಳಿಂದ ಪೂರ್ಣಾಂಕ ಹ್ಯಾಶಿಂಗ್ ಅನ್ನು ಇದು ಹೆಚ್ಚು ವೇಗಗೊಳಿಸುತ್ತದೆ.
    // ವಿವರಗಳಿಗಾಗಿ #69152 ನೋಡಿ.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // ಸುರಕ್ಷತೆ: `cmp::min(length, needed)` `length` ಗಿಂತ ಹೆಚ್ಚಿಲ್ಲ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // ಬಫರ್ಡ್ ಬಾಲವನ್ನು ಈಗ ಫ್ಲಶ್ ಮಾಡಲಾಗಿದೆ, ಹೊಸ ಇನ್ಪುಟ್ ಅನ್ನು ಪ್ರಕ್ರಿಯೆಗೊಳಿಸಿ.
        let len = length - needed;
        let left = len & 0x7; // ಲೆನ್% 8

        let mut i = needed;
        while i < len - left {
            // ಸುರಕ್ಷತೆ: ಏಕೆಂದರೆ `len - left` 8 ವರ್ಷದೊಳಗಿನ ದೊಡ್ಡ ಗುಣಾಕಾರವಾಗಿದೆ
            // `len`, ಮತ್ತು `i` `needed` ನಿಂದ ಪ್ರಾರಂಭವಾಗುವುದರಿಂದ `len` `length - needed` ಆಗಿದ್ದರೆ, `i + 8` `length` ಗಿಂತ ಕಡಿಮೆ ಅಥವಾ ಸಮನಾಗಿರುತ್ತದೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // ಸುರಕ್ಷತೆ: `i` ಈಗ `needed + len.div_euclid(8) * 8` ಆಗಿದೆ,
        // ಆದ್ದರಿಂದ `i + left` = `needed + len` = `length`, ಇದು ವ್ಯಾಖ್ಯಾನದಿಂದ `msg.len()` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// 0 ಗೆ ಹೊಂದಿಸಲಾದ ಎರಡು ಆರಂಭಿಕ ಕೀಲಿಗಳೊಂದಿಗೆ `Hasher<S>` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}