//! # Rust ಕೋರ್ ಲೈಬ್ರರಿ
//!
//! Rust ಕೋರ್ ಲೈಬ್ರರಿ [The Rust Standard Library](../std/index.html) ನ ಅವಲಂಬನೆ-ಮುಕ್ತ [^ ಉಚಿತ] ಅಡಿಪಾಯವಾಗಿದೆ.
//! ಇದು ಭಾಷೆ ಮತ್ತು ಅದರ ಗ್ರಂಥಾಲಯಗಳ ನಡುವಿನ ಪೋರ್ಟಬಲ್ ಅಂಟು, ಎಲ್ಲಾ Rust ಕೋಡ್‌ನ ಆಂತರಿಕ ಮತ್ತು ಪ್ರಾಚೀನ ಬಿಲ್ಡಿಂಗ್ ಬ್ಲಾಕ್‌ಗಳನ್ನು ವ್ಯಾಖ್ಯಾನಿಸುತ್ತದೆ.
//!
//! ಇದು ಯಾವುದೇ ಅಪ್‌ಸ್ಟ್ರೀಮ್ ಲೈಬ್ರರಿಗಳಿಗೆ, ಸಿಸ್ಟಮ್ ಲೈಬ್ರರಿಗಳಿಗೆ ಮತ್ತು ಯಾವುದೇ ಲಿಬಿಸಿಗಳಿಗೆ ಲಿಂಕ್ ಮಾಡುವುದಿಲ್ಲ.
//!
//! [^free]: Strictly ಮಾತನಾಡುವಾಗ, ಕೆಲವು ಚಿಹ್ನೆಗಳು ಬೇಕಾಗುತ್ತವೆ ಆದರೆ
//!          ಅವು ಯಾವಾಗಲೂ ಅಗತ್ಯವಿಲ್ಲ.
//!
//! ಕೋರ್ ಲೈಬ್ರರಿ *ಕನಿಷ್ಠ*: ಇದು ರಾಶಿ ಹಂಚಿಕೆಯ ಬಗ್ಗೆ ಸಹ ತಿಳಿದಿಲ್ಲ, ಅಥವಾ ಇದು ಏಕಕಾಲೀನ ಅಥವಾ I/O ಅನ್ನು ಒದಗಿಸುವುದಿಲ್ಲ.
//! ಈ ವಿಷಯಗಳಿಗೆ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್ ಏಕೀಕರಣದ ಅಗತ್ಯವಿರುತ್ತದೆ ಮತ್ತು ಈ ಗ್ರಂಥಾಲಯವು ಪ್ಲಾಟ್‌ಫಾರ್ಮ್-ಅಜ್ಞೇಯತಾವಾದಿ.
//!
//! # ಕೋರ್ ಲೈಬ್ರರಿಯನ್ನು ಹೇಗೆ ಬಳಸುವುದು
//!
//! ಈ ಎಲ್ಲಾ ವಿವರಗಳನ್ನು ಪ್ರಸ್ತುತ ಸ್ಥಿರವೆಂದು ಪರಿಗಣಿಸಲಾಗುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ದಯವಿಟ್ಟು ಗಮನಿಸಿ.
//!
//!
//!
// FIXME: ಇಂಟರ್ಫೇಸ್ ನೆಲೆಗೊಂಡಾಗ ಹೆಚ್ಚಿನ ವಿವರಗಳೊಂದಿಗೆ ನನ್ನನ್ನು ಭರ್ತಿ ಮಾಡಿ
//! ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ ಕೆಲವು ಚಿಹ್ನೆಗಳ on ಹೆಯ ಮೇಲೆ ಈ ಗ್ರಂಥಾಲಯವನ್ನು ನಿರ್ಮಿಸಲಾಗಿದೆ:
//!
//! * `memcpy`, `memcmp`, `memset`, ಇವುಗಳು ಕೋರ್ ಮೆಮೊರಿ ವಾಡಿಕೆಯಾಗಿದ್ದು, ಇವುಗಳನ್ನು ಹೆಚ್ಚಾಗಿ LLVM ನಿಂದ ಉತ್ಪಾದಿಸಲಾಗುತ್ತದೆ.
//! ಹೆಚ್ಚುವರಿಯಾಗಿ, ಈ ಕಾರ್ಯಗಳಿಗೆ ಈ ಗ್ರಂಥಾಲಯವು ಸ್ಪಷ್ಟ ಕರೆಗಳನ್ನು ಮಾಡಬಹುದು.
//! ಅವರ ಸಹಿಗಳು ಸಿ ಯಲ್ಲಿ ಕಂಡುಬರುವಂತೆಯೇ ಇರುತ್ತವೆ.
//!   ಈ ಕಾರ್ಯಗಳನ್ನು ಹೆಚ್ಚಾಗಿ ಸಿಸ್ಟಮ್ ಲಿಬಿಸಿ ಒದಗಿಸುತ್ತದೆ, ಆದರೆ ಇದನ್ನು ಎಕ್ಸ್‌00 ಎಕ್ಸ್ ಸಹ ಒದಗಿಸಬಹುದು.
//!
//!
//! * `rust_begin_panic` - ಈ ಕಾರ್ಯವು ನಾಲ್ಕು ಆರ್ಗ್ಯುಮೆಂಟ್‌ಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ, ಒಂದು `fmt::Arguments`, `&'static str`, ಮತ್ತು ಎರಡು `u32` ಗಳು.
//! ಈ ನಾಲ್ಕು ವಾದಗಳು panic ಸಂದೇಶವನ್ನು, panic ಅನ್ನು ಆಹ್ವಾನಿಸಿದ ಫೈಲ್ ಮತ್ತು ಫೈಲ್‌ನೊಳಗಿನ ಸಾಲು ಮತ್ತು ಕಾಲಮ್ ಅನ್ನು ನಿರ್ದೇಶಿಸುತ್ತದೆ.
//! ಈ panic ಕಾರ್ಯವನ್ನು ವ್ಯಾಖ್ಯಾನಿಸುವುದು ಈ ಕೋರ್ ಲೈಬ್ರರಿಯ ಗ್ರಾಹಕರಿಗೆ ಬಿಟ್ಟದ್ದು;ಇದು ಎಂದಿಗೂ ಹಿಂತಿರುಗುವುದಿಲ್ಲ.
//! ಇದಕ್ಕೆ `panic_impl` ಹೆಸರಿನ `lang` ಗುಣಲಕ್ಷಣದ ಅಗತ್ಯವಿದೆ.
//!
//! * `rust_eh_personality` - ಕಂಪೈಲರ್ನ ವೈಫಲ್ಯ ಕಾರ್ಯವಿಧಾನಗಳಿಂದ ಬಳಸಲಾಗುತ್ತದೆ.
//! ಇದನ್ನು ಹೆಚ್ಚಾಗಿ GCC ನ ವ್ಯಕ್ತಿತ್ವ ಕಾರ್ಯಕ್ಕೆ ಮ್ಯಾಪ್ ಮಾಡಲಾಗುತ್ತದೆ, ಆದರೆ panic ಅನ್ನು ಪ್ರಚೋದಿಸದ crates ಅನ್ನು ಈ ಕಾರ್ಯವನ್ನು ಎಂದಿಗೂ ಕರೆಯಲಾಗುವುದಿಲ್ಲ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬಹುದು.
//! `lang` ಗುಣಲಕ್ಷಣವನ್ನು `eh_personality` ಎಂದು ಕರೆಯಲಾಗುತ್ತದೆ.
//!
//!
//!

// ಲಿಬ್‌ಕೋರ್ ಅನೇಕ ಮೂಲಭೂತ ಲ್ಯಾಂಗ್ ವಸ್ತುಗಳನ್ನು ವ್ಯಾಖ್ಯಾನಿಸುವುದರಿಂದ, ಎಲ್ಲಾ ಪರೀಕ್ಷೆಗಳು ವಿಲಕ್ಷಣ ಸಮಸ್ಯೆಗಳನ್ನು ತಪ್ಪಿಸಲು ಪ್ರತ್ಯೇಕ crate, libcoretest ನಲ್ಲಿ ವಾಸಿಸುತ್ತವೆ.
//
// ಇಲ್ಲಿ ನಾವು ಸ್ಪಷ್ಟವಾಗಿ#[cfg]-ಪರೀಕ್ಷಿಸುವಾಗ ಈ ಸಂಪೂರ್ಣ crate ಅನ್ನು ಹೊರಹಾಕುತ್ತೇವೆ.
// ನಾವು ಇದನ್ನು ಮಾಡದಿದ್ದರೆ, ರಚಿತವಾದ ಪರೀಕ್ಷಾ ಕಲಾಕೃತಿ ಮತ್ತು ಲಿಂಕ್ಡ್ ಲಿಬ್ಟೆಸ್ಟ್ (ಇದು ಲಿಬ್‌ಕೋರ್ ಅನ್ನು ಪರಿವರ್ತಕವಾಗಿ ಒಳಗೊಂಡಿರುತ್ತದೆ) ಎರಡೂ ಒಂದೇ ರೀತಿಯ ಲ್ಯಾಂಗ್ ಐಟಂಗಳನ್ನು ವ್ಯಾಖ್ಯಾನಿಸುತ್ತದೆ, ಮತ್ತು ಇದು E0152 "found duplicate lang item" ದೋಷಕ್ಕೆ ಕಾರಣವಾಗುತ್ತದೆ.
//
// ವಿವರಗಳಿಗಾಗಿ #50466 ನಲ್ಲಿ ಚರ್ಚೆ ನೋಡಿ.
//
// ಈ ಸಿಎಫ್‌ಜಿ ಡಾಕ್ ಪರೀಕ್ಷೆಗಳ ಮೇಲೆ ಪರಿಣಾಮ ಬೀರುವುದಿಲ್ಲ.
//
//
#![cfg(not(test))]
#![stable(feature = "core", since = "1.6.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![no_core]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(asm)]
#![feature(cfg_target_has_atomic)]
#![feature(const_heap)]
#![feature(const_alloc_layout)]
#![feature(const_assert_type)]
#![feature(const_discriminant)]
#![feature(const_cell_into_inner)]
#![feature(const_intrinsic_copy)]
#![feature(const_intrinsic_forget)]
#![feature(const_float_classify)]
#![feature(const_float_bits_conv)]
#![feature(const_int_unchecked_arith)]
#![feature(const_mut_refs)]
#![feature(const_refs_to_cell)]
#![feature(const_cttz)]
#![feature(const_panic)]
#![feature(const_pin)]
#![feature(const_fn)]
#![feature(const_fn_union)]
#![feature(const_impl_trait)]
#![feature(const_fn_floating_point_arithmetic)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(const_option)]
#![feature(const_precise_live_drops)]
#![feature(const_ptr_offset)]
#![feature(const_ptr_offset_from)]
#![feature(const_ptr_read)]
#![feature(const_ptr_write)]
#![feature(const_raw_ptr_comparison)]
#![feature(const_raw_ptr_deref)]
#![feature(const_slice_from_raw_parts)]
#![feature(const_slice_ptr_len)]
#![feature(const_size_of_val)]
#![feature(const_swap)]
#![feature(const_align_of_val)]
#![feature(const_type_id)]
#![feature(const_type_name)]
#![feature(const_likely)]
#![feature(const_unreachable_unchecked)]
#![feature(const_maybe_uninit_assume_init)]
#![feature(const_maybe_uninit_as_ptr)]
#![feature(custom_inner_attributes)]
#![feature(decl_macro)]
#![feature(doc_cfg)]
#![feature(doc_spotlight)]
#![feature(duration_consts_2)]
#![feature(duration_saturating_ops)]
#![feature(extended_key_value_attributes)]
#![feature(extern_types)]
#![feature(fundamental)]
#![feature(intra_doc_pointers)]
#![feature(intrinsics)]
#![feature(lang_items)]
#![feature(link_llvm_intrinsics)]
#![feature(llvm_asm)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(exhaustive_patterns)]
#![feature(no_core)]
#![feature(auto_traits)]
#![feature(or_patterns)]
#![feature(prelude_import)]
#![cfg_attr(not(bootstrap), feature(ptr_metadata))]
#![feature(repr_simd, platform_intrinsics)]
#![feature(rustc_attrs)]
#![feature(simd_ffi)]
#![feature(min_specialization)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(stmt_expr_attributes)]
#![feature(str_split_as_str)]
#![feature(str_split_inclusive_as_str)]
#![feature(trait_alias)]
#![feature(transparent_unions)]
#![feature(try_blocks)]
#![feature(unboxed_closures)]
#![feature(unsized_fn_params)]
#![feature(unwind_attributes)]
#![feature(variant_count)]
#![feature(tbm_target_feature)]
#![feature(sse4a_target_feature)]
#![feature(arm_target_feature)]
#![feature(powerpc_target_feature)]
#![feature(mips_target_feature)]
#![feature(aarch64_target_feature)]
#![feature(wasm_target_feature)]
#![feature(avx512_target_feature)]
#![feature(cmpxchg16b_target_feature)]
#![feature(rtm_target_feature)]
#![feature(f16c_target_feature)]
#![feature(hexagon_target_feature)]
#![feature(const_fn_transmute)]
#![feature(abi_unadjusted)]
#![feature(adx_target_feature)]
#![feature(external_doc)]
#![feature(associated_type_bounds)]
#![feature(const_caller_location)]
#![feature(slice_ptr_get)]
#![feature(no_niche)] // rust-lang/rust#68303
#![feature(int_error_matching)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![deny(unsafe_op_in_unsafe_fn)]

#[prelude_import]
#[allow(unused)]
use prelude::v1::*;

#[cfg(not(test))] // #65860 ನೋಡಿ
#[macro_use]
mod macros;

#[macro_use]
mod internal_macros;

#[path = "num/shells/int_macros.rs"]
#[macro_use]
mod int_macros;

#[path = "num/shells/i128.rs"]
pub mod i128;
#[path = "num/shells/i16.rs"]
pub mod i16;
#[path = "num/shells/i32.rs"]
pub mod i32;
#[path = "num/shells/i64.rs"]
pub mod i64;
#[path = "num/shells/i8.rs"]
pub mod i8;
#[path = "num/shells/isize.rs"]
pub mod isize;

#[path = "num/shells/u128.rs"]
pub mod u128;
#[path = "num/shells/u16.rs"]
pub mod u16;
#[path = "num/shells/u32.rs"]
pub mod u32;
#[path = "num/shells/u64.rs"]
pub mod u64;
#[path = "num/shells/u8.rs"]
pub mod u8;
#[path = "num/shells/usize.rs"]
pub mod usize;

#[path = "num/f32.rs"]
pub mod f32;
#[path = "num/f64.rs"]
pub mod f64;

#[macro_use]
pub mod num;

/* The libcore prelude, not as all-encompassing as the libstd prelude */

pub mod prelude;

/* Core modules for ownership management */

pub mod hint;
pub mod intrinsics;
pub mod mem;
pub mod ptr;

/* Core language traits */

pub mod borrow;
pub mod clone;
pub mod cmp;
pub mod convert;
pub mod default;
pub mod marker;
pub mod ops;

/* Core types and methods on primitives */

pub mod any;
pub mod array;
pub mod ascii;
pub mod cell;
pub mod char;
pub mod ffi;
pub mod iter;
#[unstable(feature = "once_cell", issue = "74465")]
pub mod lazy;
pub mod option;
pub mod panic;
pub mod panicking;
pub mod pin;
pub mod raw;
pub mod result;
#[unstable(feature = "async_stream", issue = "79024")]
pub mod stream;
pub mod sync;

pub mod fmt;
pub mod hash;
pub mod slice;
pub mod str;
pub mod time;

pub mod unicode;

/* Async */
pub mod future;
pub mod task;

/* Heap memory allocator trait */
#[allow(missing_docs)]
pub mod alloc;

// note: ಸಾರ್ವಜನಿಕವಾಗಿರಬೇಕಾಗಿಲ್ಲ
mod bool;
mod tuple;
mod unit;

#[stable(feature = "core_primitive", since = "1.43.0")]
pub mod primitive;

// `core_arch` crate ನಲ್ಲಿ ನೇರವಾಗಿ ಲಿಬ್‌ಕೋರ್‌ಗೆ ಎಳೆಯಿರಿ.`core_arch` ನ ವಿಷಯಗಳು ವಿಭಿನ್ನ ಭಂಡಾರದಲ್ಲಿವೆ: rust-lang/stdarch.
//
// `core_arch` ಲಿಬ್‌ಕೋರ್‌ನ ಮೇಲೆ ಅವಲಂಬಿತವಾಗಿರುತ್ತದೆ, ಆದರೆ ಈ ಮಾಡ್ಯೂಲ್‌ನ ವಿಷಯಗಳನ್ನು ಇಲ್ಲಿ ನೇರವಾಗಿ ಎಳೆಯುವ ರೀತಿಯಲ್ಲಿ ಹೊಂದಿಸಲಾಗಿದೆ, ಅಂದರೆ crate ಈ crate ಅನ್ನು ಅದರ ಲಿಬ್‌ಕೋರ್‌ನಂತೆ ಬಳಸುತ್ತದೆ.
//
//
//
#[path = "../../stdarch/crates/core_arch/src/mod.rs"]
#[allow(
    missing_docs,
    missing_debug_implementations,
    dead_code,
    unused_imports,
    unsafe_op_in_unsafe_fn
)]
#[cfg_attr(bootstrap, allow(non_autolinks))]
#[cfg_attr(not(bootstrap), allow(rustdoc::non_autolinks))]
// FIXME: ಕ್ಲಾಶಿಂಗ್_ಎಕ್ಸ್ಟರ್ನ್_ಡೆಕ್ಲರೇಶನ್ಸ್ ನಂತರ ಈ ಟಿಪ್ಪಣಿಯನ್ನು rust-lang/stdarch ಗೆ ಸರಿಸಬೇಕು
// ವಿಲೀನಗೊಂಡಿದೆ.lint ಅನ್ನು ಇನ್ನೂ ವ್ಯಾಖ್ಯಾನಿಸದ ಕಾರಣ ಬೂಟ್ ಸ್ಟ್ರಾಪ್ ವಿಫಲವಾದ ಕಾರಣ ಇದು ಪ್ರಸ್ತುತ ಸಾಧ್ಯವಿಲ್ಲ.
#[allow(clashing_extern_declarations)]
#[unstable(feature = "stdsimd", issue = "48556")]
mod core_arch;

#[stable(feature = "simd_arch", since = "1.27.0")]
pub use core_arch::arch;