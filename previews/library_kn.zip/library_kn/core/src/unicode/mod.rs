#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// `char` ಮತ್ತು `str` ವಿಧಾನಗಳ ಯುನಿಕೋಡ್ ಭಾಗಗಳನ್ನು ಆಧರಿಸಿದ [Unicode](http://www.unicode.org/) ನ ಆವೃತ್ತಿ.
///
/// ಯೂನಿಕೋಡ್‌ನ ಹೊಸ ಆವೃತ್ತಿಗಳನ್ನು ನಿಯಮಿತವಾಗಿ ಬಿಡುಗಡೆ ಮಾಡಲಾಗುತ್ತದೆ ಮತ್ತು ತರುವಾಯ ಯುನಿಕೋಡ್‌ಗೆ ಅನುಗುಣವಾಗಿ ಪ್ರಮಾಣಿತ ಗ್ರಂಥಾಲಯದಲ್ಲಿನ ಎಲ್ಲಾ ವಿಧಾನಗಳನ್ನು ನವೀಕರಿಸಲಾಗುತ್ತದೆ.
/// ಆದ್ದರಿಂದ ಕೆಲವು `char` ಮತ್ತು `str` ವಿಧಾನಗಳ ವರ್ತನೆ ಮತ್ತು ಕಾಲಾನಂತರದಲ್ಲಿ ಈ ಸ್ಥಿರ ಬದಲಾವಣೆಗಳ ಮೌಲ್ಯ.
/// ಇದನ್ನು * ಬ್ರೇಕಿಂಗ್ ಬದಲಾವಣೆ ಎಂದು ಪರಿಗಣಿಸಲಾಗುವುದಿಲ್ಲ.
///
/// ಆವೃತ್ತಿ ಸಂಖ್ಯೆಯ ಯೋಜನೆಯನ್ನು [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) ನಲ್ಲಿ ವಿವರಿಸಲಾಗಿದೆ.
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// ಲಿಬಾಲೋಕ್‌ನಲ್ಲಿ ಬಳಸಲು, ಲಿಬ್‌ಸ್ಟಡ್‌ನಲ್ಲಿ ಮರು-ರಫ್ತು ಮಾಡಲಾಗುವುದಿಲ್ಲ.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;