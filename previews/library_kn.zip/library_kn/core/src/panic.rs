//! ಸ್ಟ್ಯಾಂಡರ್ಡ್ ಲೈಬ್ರರಿಯಲ್ಲಿ Panic ಬೆಂಬಲ.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// panic ಬಗ್ಗೆ ಮಾಹಿತಿಯನ್ನು ಒದಗಿಸುವ ಒಂದು ರಚನೆ.
///
/// `PanicInfo` ರಚನೆಯನ್ನು [`set_hook`] ಕಾರ್ಯದಿಂದ ಹೊಂದಿಸಲಾದ panic hook ಗೆ ರವಾನಿಸಲಾಗಿದೆ.
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// panic ಗೆ ಸಂಬಂಧಿಸಿದ ಪೇಲೋಡ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಇದು ಸಾಮಾನ್ಯವಾಗಿ, ಆದರೆ ಯಾವಾಗಲೂ ಅಲ್ಲ, `&'static str` ಅಥವಾ [`String`] ಆಗಿರುತ್ತದೆ.
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// `core` crate ನಿಂದ (`std` ನಿಂದ ಅಲ್ಲ) `panic!` ಮ್ಯಾಕ್ರೋವನ್ನು ಫಾರ್ಮ್ಯಾಟಿಂಗ್ ಸ್ಟ್ರಿಂಗ್ ಮತ್ತು ಕೆಲವು ಹೆಚ್ಚುವರಿ ಆರ್ಗ್ಯುಮೆಂಟ್‌ಗಳೊಂದಿಗೆ ಬಳಸಿದ್ದರೆ, ಆ ಸಂದೇಶವನ್ನು [`fmt::write`] ನೊಂದಿಗೆ ಬಳಸಲು ಸಿದ್ಧವಾಗಿದೆ
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// ಲಭ್ಯವಿದ್ದರೆ panic ಹುಟ್ಟಿದ ಸ್ಥಳದ ಬಗ್ಗೆ ಮಾಹಿತಿಯನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// ಈ ವಿಧಾನವು ಪ್ರಸ್ತುತ ಯಾವಾಗಲೂ [`Some`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಆದರೆ ಇದು future ಆವೃತ್ತಿಗಳಲ್ಲಿ ಬದಲಾಗಬಹುದು.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: ಕೆಲವೊಮ್ಮೆ ಯಾವುದನ್ನೂ ಹಿಂತಿರುಗಿಸಲು ಇದನ್ನು ಬದಲಾಯಿಸಿದರೆ,
        // std::panicking::default_hook ಮತ್ತು std::panicking::begin_panic_fmt ನಲ್ಲಿ ಆ ಪ್ರಕರಣವನ್ನು ನಿಭಾಯಿಸಿ.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: ನಾವು downcast_ref: : ಅನ್ನು ಬಳಸಲಾಗುವುದಿಲ್ಲ<String>() ಇಲ್ಲಿ
        // ಲಿಬ್‌ಕೋರ್‌ನಲ್ಲಿ ಸ್ಟ್ರಿಂಗ್ ಲಭ್ಯವಿಲ್ಲದ ಕಾರಣ!
        // `std::panic!` ಅನ್ನು ಅನೇಕ ಆರ್ಗ್ಯುಮೆಂಟ್‌ಗಳೊಂದಿಗೆ ಕರೆಯುವಾಗ ಪೇಲೋಡ್ ಒಂದು ಸ್ಟ್ರಿಂಗ್ ಆಗಿದೆ, ಆದರೆ ಆ ಸಂದರ್ಭದಲ್ಲಿ ಸಂದೇಶವು ಸಹ ಲಭ್ಯವಿದೆ.
        //

        self.location.fmt(formatter)
    }
}

/// panic ನ ಸ್ಥಳದ ಬಗ್ಗೆ ಮಾಹಿತಿಯನ್ನು ಹೊಂದಿರುವ ಒಂದು ರಚನೆ.
///
/// ಈ ರಚನೆಯನ್ನು [`PanicInfo::location()`] ನಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// ಸಮಾನತೆ ಮತ್ತು ಆದೇಶಕ್ಕಾಗಿ ಹೋಲಿಕೆಗಳನ್ನು ಫೈಲ್, ಲೈನ್, ನಂತರ ಕಾಲಮ್ ಆದ್ಯತೆಯಲ್ಲಿ ಮಾಡಲಾಗುತ್ತದೆ.
/// ಫೈಲ್‌ಗಳನ್ನು `Path` ಅಲ್ಲ, ತಂತಿಗಳಾಗಿ ಹೋಲಿಸಲಾಗುತ್ತದೆ, ಅದು ಅನಿರೀಕ್ಷಿತವಾಗಿರಬಹುದು.
/// ಹೆಚ್ಚಿನ ಚರ್ಚೆಗಾಗಿ [`ಸ್ಥಳ: : ಫೈಲ್`] ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// ಈ ಕಾರ್ಯದ ಕರೆ ಮಾಡುವವರ ಮೂಲ ಸ್ಥಳವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಆ ಫಂಕ್ಷನ್‌ನ ಕಾಲರ್ ಅನ್ನು ಟಿಪ್ಪಣಿ ಮಾಡಿದರೆ, ಅದರ ಕರೆ ಸ್ಥಳವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ, ಮತ್ತು ಟ್ರ್ಯಾಕ್ ಮಾಡದ ಫಂಕ್ಷನ್ ಬಾಡಿ ಒಳಗೆ ಮೊದಲ ಕರೆಗೆ ಸ್ಟಾಕ್ ಅನ್ನು ಮೇಲಕ್ಕೆತ್ತಿ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// ಇದನ್ನು ಕರೆಯಲಾಗುವ [`Location`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// ಈ ಕಾರ್ಯದ ವ್ಯಾಖ್ಯಾನದಿಂದ [`Location`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // ಅದೇ ಟ್ರ್ಯಾಕ್ ಮಾಡದ ಕಾರ್ಯವನ್ನು ಬೇರೆ ಸ್ಥಳದಲ್ಲಿ ಚಲಾಯಿಸುವುದರಿಂದ ನಮಗೆ ಅದೇ ಫಲಿತಾಂಶ ಸಿಗುತ್ತದೆ
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // ಟ್ರ್ಯಾಕ್ ಮಾಡಲಾದ ಕಾರ್ಯವನ್ನು ಬೇರೆ ಸ್ಥಳದಲ್ಲಿ ಚಲಾಯಿಸುವುದರಿಂದ ವಿಭಿನ್ನ ಮೌಲ್ಯವನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// panic ಹುಟ್ಟಿಕೊಂಡ ಮೂಲ ಫೈಲ್ ಹೆಸರನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # `&str`, `&Path` ಅಲ್ಲ
    ///
    /// ಹಿಂದಿರುಗಿದ ಹೆಸರು ಕಂಪೈಲಿಂಗ್ ಸಿಸ್ಟಮ್‌ನಲ್ಲಿನ ಮೂಲ ಮಾರ್ಗವನ್ನು ಸೂಚಿಸುತ್ತದೆ, ಆದರೆ ಇದನ್ನು ನೇರವಾಗಿ `&Path` ಎಂದು ಪ್ರತಿನಿಧಿಸಲು ಮಾನ್ಯವಾಗಿಲ್ಲ.
    /// ಕಂಪೈಲ್ ಮಾಡಲಾದ ಕೋಡ್ ಬೇರೆ ಸಿಸ್ಟಂನಲ್ಲಿ ವಿಷಯಗಳನ್ನು ಒದಗಿಸುವ ಸಿಸ್ಟಮ್ಗಿಂತ ವಿಭಿನ್ನ `Path` ಅನುಷ್ಠಾನದೊಂದಿಗೆ ಕಾರ್ಯನಿರ್ವಹಿಸಬಹುದು ಮತ್ತು ಈ ಲೈಬ್ರರಿಯು ಪ್ರಸ್ತುತ ಬೇರೆ "host path" ಪ್ರಕಾರವನ್ನು ಹೊಂದಿಲ್ಲ.
    ///
    /// ಮಾಡ್ಯೂಲ್ ಸಿಸ್ಟಮ್‌ನಲ್ಲಿನ ಅನೇಕ ಮಾರ್ಗಗಳ ಮೂಲಕ (ಸಾಮಾನ್ಯವಾಗಿ `#[path = "..."]` ಗುಣಲಕ್ಷಣವನ್ನು ಬಳಸುವುದು ಅಥವಾ ಅಂತಹುದೇ) "the same" ಫೈಲ್ ಅನ್ನು ತಲುಪಿದಾಗ ಅತ್ಯಂತ ಆಶ್ಚರ್ಯಕರ ವರ್ತನೆ ಸಂಭವಿಸುತ್ತದೆ, ಇದು ಈ ಕಾರ್ಯದಿಂದ ವಿಭಿನ್ನ ಮೌಲ್ಯಗಳನ್ನು ಹಿಂತಿರುಗಿಸಲು ಒಂದೇ ಕೋಡ್‌ನಂತೆ ಕಂಡುಬರುತ್ತದೆ.
    ///
    ///
    /// # Cross-compilation
    ///
    /// ಹೋಸ್ಟ್ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್ ಮತ್ತು ಟಾರ್ಗೆಟ್ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್ ಭಿನ್ನವಾಗಿರುವಾಗ ಈ ಮೌಲ್ಯವು `Path::new` ಅಥವಾ ಅಂತಹುದೇ ಕನ್‌ಸ್ಟ್ರಕ್ಟರ್‌ಗಳಿಗೆ ರವಾನಿಸಲು ಸೂಕ್ತವಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// panic ಹುಟ್ಟಿದ ಸಾಲಿನ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// panic ಹುಟ್ಟಿದ ಕಾಲಮ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// ಡೇಟಾವನ್ನು libstd ನಿಂದ `panic_unwind` ಮತ್ತು ಇತರ panic ರನ್ಟೈಮ್‌ಗಳಿಗೆ ರವಾನಿಸಲು libstd ಬಳಸುವ ಆಂತರಿಕ trait.
/// ಯಾವುದೇ ಸಮಯದಲ್ಲಿ ಶೀಘ್ರದಲ್ಲೇ ಸ್ಥಿರಗೊಳ್ಳುವ ಉದ್ದೇಶವನ್ನು ಹೊಂದಿಲ್ಲ, ಬಳಸಬೇಡಿ.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// ವಿಷಯಗಳ ಸಂಪೂರ್ಣ ಮಾಲೀಕತ್ವವನ್ನು ತೆಗೆದುಕೊಳ್ಳಿ.
    /// ರಿಟರ್ನ್ ಪ್ರಕಾರವು ವಾಸ್ತವವಾಗಿ `Box<dyn Any + Send>` ಆಗಿದೆ, ಆದರೆ ನಾವು ಲಿಬ್‌ಕೋರ್‌ನಲ್ಲಿ `Box` ಅನ್ನು ಬಳಸಲಾಗುವುದಿಲ್ಲ.
    ///
    /// ಈ ವಿಧಾನವನ್ನು ಕರೆದ ನಂತರ, `self` ನಲ್ಲಿ ಕೆಲವು ನಕಲಿ ಡೀಫಾಲ್ಟ್ ಮೌಲ್ಯ ಮಾತ್ರ ಉಳಿದಿದೆ.
    /// ಈ ವಿಧಾನವನ್ನು ಎರಡು ಬಾರಿ ಕರೆಯುವುದು, ಅಥವಾ ಈ ವಿಧಾನವನ್ನು ಕರೆದ ನಂತರ `get` ಗೆ ಕರೆ ಮಾಡುವುದು ದೋಷ.
    ///
    /// panic ರನ್ಟೈಮ್ (`__rust_start_panic`) ಕೇವಲ ಎರವಲು ಪಡೆದ `dyn BoxMeUp` ಅನ್ನು ಪಡೆಯುವುದರಿಂದ ವಾದವನ್ನು ಎರವಲು ಪಡೆಯಲಾಗಿದೆ.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// ವಿಷಯಗಳನ್ನು ಎರವಲು ಪಡೆದುಕೊಳ್ಳಿ.
    fn get(&mut self) -> &(dyn Any + Send);
}