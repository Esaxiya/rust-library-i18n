//! ಲಿಬ್ಕೋರ್ prelude
//!
//! ಈ ಮಾಡ್ಯೂಲ್ ಲಿಬ್‌ಕೋರ್‌ನ ಬಳಕೆದಾರರಿಗಾಗಿ ಉದ್ದೇಶಿಸಲಾಗಿದೆ, ಅದು ಲಿಬ್‌ಸ್ಟಡ್‌ಗೆ ಲಿಂಕ್ ಆಗುವುದಿಲ್ಲ.
//! ಸ್ಟ್ಯಾಂಡರ್ಡ್ ಲೈಬ್ರರಿಯ prelude ಮಾದರಿಯಲ್ಲಿಯೇ `#![no_std]` ಅನ್ನು ಬಳಸಿದಾಗ ಈ ಮಾಡ್ಯೂಲ್ ಅನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಆಮದು ಮಾಡಿಕೊಳ್ಳಲಾಗುತ್ತದೆ.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// ಕೋರ್ prelude ನ 2015 ಆವೃತ್ತಿ.
///
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ [module-level documentation](self) ನೋಡಿ.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// ಕೋರ್ prelude ನ 2018 ಆವೃತ್ತಿ.
///
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ [module-level documentation](self) ನೋಡಿ.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// ಕೋರ್ prelude ನ 2021 ಆವೃತ್ತಿ.
///
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ [module-level documentation](self) ನೋಡಿ.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: ಹೆಚ್ಚಿನ ವಿಷಯಗಳನ್ನು ಸೇರಿಸಿ.
}