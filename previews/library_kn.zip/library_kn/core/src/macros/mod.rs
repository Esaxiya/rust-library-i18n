#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // ಕರೆ ಮಾಡುವವರ ಆವೃತ್ತಿಯನ್ನು ಅವಲಂಬಿಸಿ `$crate::panic::panic_2015` ಅಥವಾ `$crate::panic::panic_2021` ಗೆ ವಿಸ್ತರಿಸುತ್ತದೆ.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// ಎರಡು ಅಭಿವ್ಯಕ್ತಿಗಳು ಪರಸ್ಪರ ಸಮಾನವಾಗಿವೆ ಎಂದು ಪ್ರತಿಪಾದಿಸುತ್ತದೆ ([`PartialEq`] ಬಳಸಿ).
///
/// panic ನಲ್ಲಿ, ಈ ಮ್ಯಾಕ್ರೊ ಅಭಿವ್ಯಕ್ತಿಗಳ ಮೌಲ್ಯಗಳನ್ನು ಅವುಗಳ ಡೀಬಗ್ ಪ್ರಾತಿನಿಧ್ಯಗಳೊಂದಿಗೆ ಮುದ್ರಿಸುತ್ತದೆ.
///
///
/// [`assert!`] ನಂತೆ, ಈ ಮ್ಯಾಕ್ರೋ ಎರಡನೇ ರೂಪವನ್ನು ಹೊಂದಿದೆ, ಅಲ್ಲಿ ಕಸ್ಟಮ್ panic ಸಂದೇಶವನ್ನು ಒದಗಿಸಬಹುದು.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // ಕೆಳಗಿನ ರೆಬರೋಗಳು ಉದ್ದೇಶಪೂರ್ವಕವಾಗಿವೆ.
                    // ಅವುಗಳಿಲ್ಲದೆ, ಮೌಲ್ಯಗಳನ್ನು ಹೋಲಿಸುವ ಮೊದಲೇ ಸಾಲಕ್ಕಾಗಿ ಸ್ಟಾಕ್ ಸ್ಲಾಟ್ ಅನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗುತ್ತದೆ, ಇದು ಗಮನಾರ್ಹ ನಿಧಾನಕ್ಕೆ ಕಾರಣವಾಗುತ್ತದೆ.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // ಕೆಳಗಿನ ರೆಬರೋಗಳು ಉದ್ದೇಶಪೂರ್ವಕವಾಗಿವೆ.
                    // ಅವುಗಳಿಲ್ಲದೆ, ಮೌಲ್ಯಗಳನ್ನು ಹೋಲಿಸುವ ಮೊದಲೇ ಸಾಲಕ್ಕಾಗಿ ಸ್ಟಾಕ್ ಸ್ಲಾಟ್ ಅನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗುತ್ತದೆ, ಇದು ಗಮನಾರ್ಹ ನಿಧಾನಕ್ಕೆ ಕಾರಣವಾಗುತ್ತದೆ.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// ಎರಡು ಅಭಿವ್ಯಕ್ತಿಗಳು ಒಂದಕ್ಕೊಂದು ಸಮನಾಗಿರುವುದಿಲ್ಲ ([`PartialEq`] ಬಳಸಿ).
///
/// panic ನಲ್ಲಿ, ಈ ಮ್ಯಾಕ್ರೊ ಅಭಿವ್ಯಕ್ತಿಗಳ ಮೌಲ್ಯಗಳನ್ನು ಅವುಗಳ ಡೀಬಗ್ ಪ್ರಾತಿನಿಧ್ಯಗಳೊಂದಿಗೆ ಮುದ್ರಿಸುತ್ತದೆ.
///
///
/// [`assert!`] ನಂತೆ, ಈ ಮ್ಯಾಕ್ರೋ ಎರಡನೇ ರೂಪವನ್ನು ಹೊಂದಿದೆ, ಅಲ್ಲಿ ಕಸ್ಟಮ್ panic ಸಂದೇಶವನ್ನು ಒದಗಿಸಬಹುದು.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // ಕೆಳಗಿನ ರೆಬರೋಗಳು ಉದ್ದೇಶಪೂರ್ವಕವಾಗಿವೆ.
                    // ಅವುಗಳಿಲ್ಲದೆ, ಮೌಲ್ಯಗಳನ್ನು ಹೋಲಿಸುವ ಮೊದಲೇ ಸಾಲಕ್ಕಾಗಿ ಸ್ಟಾಕ್ ಸ್ಲಾಟ್ ಅನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗುತ್ತದೆ, ಇದು ಗಮನಾರ್ಹ ನಿಧಾನಕ್ಕೆ ಕಾರಣವಾಗುತ್ತದೆ.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // ಕೆಳಗಿನ ರೆಬರೋಗಳು ಉದ್ದೇಶಪೂರ್ವಕವಾಗಿವೆ.
                    // ಅವುಗಳಿಲ್ಲದೆ, ಮೌಲ್ಯಗಳನ್ನು ಹೋಲಿಸುವ ಮೊದಲೇ ಸಾಲಕ್ಕಾಗಿ ಸ್ಟಾಕ್ ಸ್ಲಾಟ್ ಅನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗುತ್ತದೆ, ಇದು ಗಮನಾರ್ಹ ನಿಧಾನಕ್ಕೆ ಕಾರಣವಾಗುತ್ತದೆ.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// ರನ್ಟೈಮ್ನಲ್ಲಿ ಬೂಲಿಯನ್ ಅಭಿವ್ಯಕ್ತಿ `true` ಎಂದು ಪ್ರತಿಪಾದಿಸುತ್ತದೆ.
///
/// ಒದಗಿಸಿದ ಅಭಿವ್ಯಕ್ತಿಯನ್ನು ರನ್ಟೈಮ್ನಲ್ಲಿ `true` ಗೆ ಮೌಲ್ಯಮಾಪನ ಮಾಡಲು ಸಾಧ್ಯವಾಗದಿದ್ದರೆ ಇದು [`panic!`] ಮ್ಯಾಕ್ರೋವನ್ನು ಆಹ್ವಾನಿಸುತ್ತದೆ.
///
/// [`assert!`] ನಂತೆ, ಈ ಮ್ಯಾಕ್ರೋ ಎರಡನೇ ಆವೃತ್ತಿಯನ್ನು ಸಹ ಹೊಂದಿದೆ, ಅಲ್ಲಿ ಕಸ್ಟಮ್ panic ಸಂದೇಶವನ್ನು ಒದಗಿಸಬಹುದು.
///
/// # Uses
///
/// [`assert!`] ಗಿಂತ ಭಿನ್ನವಾಗಿ, `debug_assert!` ಹೇಳಿಕೆಗಳನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಆಪ್ಟಿಮೈಸ್ ಮಾಡದ ನಿರ್ಮಾಣಗಳಲ್ಲಿ ಮಾತ್ರ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗುತ್ತದೆ.
/// `-C debug-assertions` ಅನ್ನು ಕಂಪೈಲರ್‌ಗೆ ರವಾನಿಸದ ಹೊರತು ಆಪ್ಟಿಮೈಸ್ಡ್ ಬಿಲ್ಡ್ `debug_assert!` ಹೇಳಿಕೆಗಳನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದಿಲ್ಲ.
/// ಬಿಡುಗಡೆಯ ನಿರ್ಮಾಣದಲ್ಲಿ ಇರುವುದಕ್ಕೆ ತುಂಬಾ ದುಬಾರಿಯಾದ ಆದರೆ ಅಭಿವೃದ್ಧಿಯ ಸಮಯದಲ್ಲಿ ಸಹಾಯಕವಾಗಬಲ್ಲ ಚೆಕ್‌ಗಳಿಗೆ ಇದು `debug_assert!` ಉಪಯುಕ್ತವಾಗಿದೆ.
/// `debug_assert!` ಅನ್ನು ವಿಸ್ತರಿಸುವ ಫಲಿತಾಂಶವು ಯಾವಾಗಲೂ ಟೈಪ್ ಚೆಕ್ ಆಗಿದೆ.
///
/// ಪರಿಶೀಲಿಸದ ಪ್ರತಿಪಾದನೆಯು ಅಸಮಂಜಸ ಸ್ಥಿತಿಯಲ್ಲಿರುವ ಪ್ರೋಗ್ರಾಂ ಅನ್ನು ಚಾಲನೆಯಲ್ಲಿಡಲು ಅನುಮತಿಸುತ್ತದೆ, ಇದು ಅನಿರೀಕ್ಷಿತ ಪರಿಣಾಮಗಳನ್ನು ಉಂಟುಮಾಡಬಹುದು ಆದರೆ ಇದು ಸುರಕ್ಷಿತ ಕೋಡ್‌ನಲ್ಲಿ ಮಾತ್ರ ಸಂಭವಿಸುವವರೆಗೆ ಅಸುರಕ್ಷಿತತೆಯನ್ನು ಪರಿಚಯಿಸುವುದಿಲ್ಲ.
///
/// ಆದಾಗ್ಯೂ, ಪ್ರತಿಪಾದನೆಗಳ ಕಾರ್ಯಕ್ಷಮತೆಯ ವೆಚ್ಚವನ್ನು ಸಾಮಾನ್ಯವಾಗಿ ಅಳೆಯಲಾಗುವುದಿಲ್ಲ.
/// [`assert!`] ಅನ್ನು `debug_assert!` ನೊಂದಿಗೆ ಬದಲಾಯಿಸುವುದನ್ನು ಸಂಪೂರ್ಣ ಪ್ರೊಫೈಲಿಂಗ್ ನಂತರ ಮಾತ್ರ ಪ್ರೋತ್ಸಾಹಿಸಲಾಗುತ್ತದೆ, ಮತ್ತು ಹೆಚ್ಚು ಮುಖ್ಯವಾಗಿ, ಸುರಕ್ಷಿತ ಕೋಡ್‌ನಲ್ಲಿ ಮಾತ್ರ!
///
/// # Examples
///
/// ```
/// // ಈ ಪ್ರತಿಪಾದನೆಗಳಿಗಾಗಿ panic ಸಂದೇಶವು ನೀಡಿದ ಅಭಿವ್ಯಕ್ತಿಯ ಸ್ಟ್ರೈಫೈಡ್ ಮೌಲ್ಯವಾಗಿದೆ.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // ಬಹಳ ಸರಳವಾದ ಕಾರ್ಯ
/// debug_assert!(some_expensive_computation());
///
/// // ಕಸ್ಟಮ್ ಸಂದೇಶದೊಂದಿಗೆ ಪ್ರತಿಪಾದಿಸಿ
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// ಎರಡು ಅಭಿವ್ಯಕ್ತಿಗಳು ಪರಸ್ಪರ ಸಮಾನವಾಗಿವೆ ಎಂದು ಪ್ರತಿಪಾದಿಸುತ್ತದೆ.
///
/// panic ನಲ್ಲಿ, ಈ ಮ್ಯಾಕ್ರೊ ಅಭಿವ್ಯಕ್ತಿಗಳ ಮೌಲ್ಯಗಳನ್ನು ಅವುಗಳ ಡೀಬಗ್ ಪ್ರಾತಿನಿಧ್ಯಗಳೊಂದಿಗೆ ಮುದ್ರಿಸುತ್ತದೆ.
///
/// [`assert_eq!`] ಗಿಂತ ಭಿನ್ನವಾಗಿ, `debug_assert_eq!` ಹೇಳಿಕೆಗಳನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಆಪ್ಟಿಮೈಸ್ ಮಾಡದ ನಿರ್ಮಾಣಗಳಲ್ಲಿ ಮಾತ್ರ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗುತ್ತದೆ.
/// `-C debug-assertions` ಅನ್ನು ಕಂಪೈಲರ್‌ಗೆ ರವಾನಿಸದ ಹೊರತು ಆಪ್ಟಿಮೈಸ್ಡ್ ಬಿಲ್ಡ್ `debug_assert_eq!` ಹೇಳಿಕೆಗಳನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದಿಲ್ಲ.
/// ಬಿಡುಗಡೆಯ ನಿರ್ಮಾಣದಲ್ಲಿ ಇರುವುದಕ್ಕೆ ತುಂಬಾ ದುಬಾರಿಯಾದ ಆದರೆ ಅಭಿವೃದ್ಧಿಯ ಸಮಯದಲ್ಲಿ ಸಹಾಯಕವಾಗಬಲ್ಲ ಚೆಕ್‌ಗಳಿಗೆ ಇದು `debug_assert_eq!` ಉಪಯುಕ್ತವಾಗಿದೆ.
///
/// `debug_assert_eq!` ಅನ್ನು ವಿಸ್ತರಿಸುವ ಫಲಿತಾಂಶವು ಯಾವಾಗಲೂ ಟೈಪ್ ಚೆಕ್ ಆಗಿದೆ.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// ಎರಡು ಅಭಿವ್ಯಕ್ತಿಗಳು ಪರಸ್ಪರ ಸಮಾನವಾಗಿಲ್ಲ ಎಂದು ಪ್ರತಿಪಾದಿಸುತ್ತದೆ.
///
/// panic ನಲ್ಲಿ, ಈ ಮ್ಯಾಕ್ರೊ ಅಭಿವ್ಯಕ್ತಿಗಳ ಮೌಲ್ಯಗಳನ್ನು ಅವುಗಳ ಡೀಬಗ್ ಪ್ರಾತಿನಿಧ್ಯಗಳೊಂದಿಗೆ ಮುದ್ರಿಸುತ್ತದೆ.
///
/// [`assert_ne!`] ಗಿಂತ ಭಿನ್ನವಾಗಿ, `debug_assert_ne!` ಹೇಳಿಕೆಗಳನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಆಪ್ಟಿಮೈಸ್ ಮಾಡದ ನಿರ್ಮಾಣಗಳಲ್ಲಿ ಮಾತ್ರ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗುತ್ತದೆ.
/// `-C debug-assertions` ಅನ್ನು ಕಂಪೈಲರ್‌ಗೆ ರವಾನಿಸದ ಹೊರತು ಆಪ್ಟಿಮೈಸ್ಡ್ ಬಿಲ್ಡ್ `debug_assert_ne!` ಹೇಳಿಕೆಗಳನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದಿಲ್ಲ.
/// ಬಿಡುಗಡೆಯ ನಿರ್ಮಾಣದಲ್ಲಿ ಇರುವುದಕ್ಕೆ ತುಂಬಾ ದುಬಾರಿಯಾದ ಆದರೆ ಅಭಿವೃದ್ಧಿಯ ಸಮಯದಲ್ಲಿ ಸಹಾಯಕವಾಗಬಲ್ಲ ಚೆಕ್‌ಗಳಿಗೆ ಇದು `debug_assert_ne!` ಉಪಯುಕ್ತವಾಗಿದೆ.
///
/// `debug_assert_ne!` ಅನ್ನು ವಿಸ್ತರಿಸುವ ಫಲಿತಾಂಶವು ಯಾವಾಗಲೂ ಟೈಪ್ ಚೆಕ್ ಆಗಿದೆ.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// ಕೊಟ್ಟಿರುವ ಅಭಿವ್ಯಕ್ತಿ ನಿರ್ದಿಷ್ಟ ನಮೂನೆಗಳಿಗೆ ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
///
/// `match` ಅಭಿವ್ಯಕ್ತಿಯಂತೆ, ಮಾದರಿಯನ್ನು ಐಚ್ ally ಿಕವಾಗಿ `if` ಮತ್ತು ಮಾದರಿಯಿಂದ ಬಂಧಿಸಲ್ಪಟ್ಟ ಹೆಸರುಗಳಿಗೆ ಪ್ರವೇಶವನ್ನು ಹೊಂದಿರುವ ಗಾರ್ಡ್ ಅಭಿವ್ಯಕ್ತಿ ಅನುಸರಿಸಬಹುದು.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// ಫಲಿತಾಂಶವನ್ನು ಬಿಚ್ಚಿಡುತ್ತದೆ ಅಥವಾ ಅದರ ದೋಷವನ್ನು ಪ್ರಚಾರ ಮಾಡುತ್ತದೆ.
///
/// `try!` ಅನ್ನು ಬದಲಿಸಲು `?` ಆಪರೇಟರ್ ಅನ್ನು ಸೇರಿಸಲಾಗಿದೆ ಮತ್ತು ಅದನ್ನು ಬಳಸಬೇಕು.
/// ಇದಲ್ಲದೆ, `try` ಎಂಬುದು Rust 2018 ರಲ್ಲಿ ಕಾಯ್ದಿರಿಸಿದ ಪದವಾಗಿದೆ, ಆದ್ದರಿಂದ ನೀವು ಅದನ್ನು ಬಳಸಬೇಕಾದರೆ, ನೀವು [raw-identifier syntax][ris] ಅನ್ನು ಬಳಸಬೇಕಾಗುತ್ತದೆ: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` ನೀಡಿರುವ [`Result`] ಗೆ ಹೊಂದಿಕೆಯಾಗುತ್ತದೆ.`Ok` ರೂಪಾಂತರದ ಸಂದರ್ಭದಲ್ಲಿ, ಅಭಿವ್ಯಕ್ತಿ ಸುತ್ತಿದ ಮೌಲ್ಯದ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿರುತ್ತದೆ.
///
/// `Err` ರೂಪಾಂತರದ ಸಂದರ್ಭದಲ್ಲಿ, ಅದು ಆಂತರಿಕ ದೋಷವನ್ನು ಹಿಂಪಡೆಯುತ್ತದೆ.`try!` ನಂತರ `From` ಬಳಸಿ ಪರಿವರ್ತನೆ ಮಾಡುತ್ತದೆ.
/// ಇದು ವಿಶೇಷ ದೋಷಗಳು ಮತ್ತು ಹೆಚ್ಚು ಸಾಮಾನ್ಯವಾದವುಗಳ ನಡುವೆ ಸ್ವಯಂಚಾಲಿತ ಪರಿವರ್ತನೆಯನ್ನು ಒದಗಿಸುತ್ತದೆ.
/// ಪರಿಣಾಮವಾಗಿ ದೋಷವನ್ನು ತಕ್ಷಣವೇ ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
///
/// ಆರಂಭಿಕ ರಿಟರ್ನ್ ಕಾರಣ, X001 ಅನ್ನು ಹಿಂದಿರುಗಿಸುವ ಕಾರ್ಯಗಳಲ್ಲಿ ಮಾತ್ರ `try!` ಅನ್ನು ಬಳಸಬಹುದು.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // ತ್ವರಿತವಾಗಿ ಹಿಂದಿರುಗುವ ದೋಷಗಳ ಆದ್ಯತೆಯ ವಿಧಾನ
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // ತ್ವರಿತವಾಗಿ ಹಿಂದಿರುಗುವ ದೋಷಗಳ ಹಿಂದಿನ ವಿಧಾನ
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // ಇದು ಇದಕ್ಕೆ ಸಮಾನವಾಗಿದೆ:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಿದ ಡೇಟಾವನ್ನು ಬಫರ್‌ಗೆ ಬರೆಯುತ್ತದೆ.
///
/// ಈ ಮ್ಯಾಕ್ರೋ 'writer', ಫಾರ್ಮ್ಯಾಟ್ ಸ್ಟ್ರಿಂಗ್ ಮತ್ತು ವಾದಗಳ ಪಟ್ಟಿಯನ್ನು ಸ್ವೀಕರಿಸುತ್ತದೆ.
/// ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಸ್ವರೂಪ ಸ್ಟ್ರಿಂಗ್‌ಗೆ ಅನುಗುಣವಾಗಿ ವಾದಗಳನ್ನು ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಲಾಗುತ್ತದೆ ಮತ್ತು ಫಲಿತಾಂಶವನ್ನು ಬರಹಗಾರರಿಗೆ ರವಾನಿಸಲಾಗುತ್ತದೆ.
/// ಬರಹಗಾರನು `write_fmt` ವಿಧಾನದೊಂದಿಗೆ ಯಾವುದೇ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿರಬಹುದು;ಸಾಮಾನ್ಯವಾಗಿ ಇದು [`fmt::Write`] ಅಥವಾ [`io::Write`] trait ನ ಅನುಷ್ಠಾನದಿಂದ ಬರುತ್ತದೆ.
/// ಮ್ಯಾಕ್ರೋ `write_fmt` ವಿಧಾನವು ಹಿಂದಿರುಗಿಸುವದನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ;ಸಾಮಾನ್ಯವಾಗಿ [`fmt::Result`], ಅಥವಾ [`io::Result`].
///
/// ಫಾರ್ಮ್ಯಾಟ್ ಸ್ಟ್ರಿಂಗ್ ಸಿಂಟ್ಯಾಕ್ಸ್ ಕುರಿತು ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ [`std::fmt`] ನೋಡಿ.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// ಮಾಡ್ಯೂಲ್ `std::fmt::Write` ಮತ್ತು `std::io::Write` ಎರಡನ್ನೂ ಆಮದು ಮಾಡಿಕೊಳ್ಳಬಹುದು ಮತ್ತು ಕಾರ್ಯಗತಗೊಳಿಸುವ ವಸ್ತುಗಳ ಮೇಲೆ `write!` ಗೆ ಕರೆ ಮಾಡಬಹುದು, ಏಕೆಂದರೆ ವಸ್ತುಗಳು ಸಾಮಾನ್ಯವಾಗಿ ಎರಡನ್ನೂ ಕಾರ್ಯಗತಗೊಳಿಸುವುದಿಲ್ಲ.
///
/// ಆದಾಗ್ಯೂ, ಮಾಡ್ಯೂಲ್ traits ಅರ್ಹತೆಯನ್ನು ಆಮದು ಮಾಡಿಕೊಳ್ಳಬೇಕು ಆದ್ದರಿಂದ ಅವರ ಹೆಸರುಗಳು ಸಂಘರ್ಷಗೊಳ್ಳುವುದಿಲ್ಲ:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt ಅನ್ನು ಬಳಸುತ್ತದೆ
///     write!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt ಅನ್ನು ಬಳಸುತ್ತದೆ
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: ಈ ಮ್ಯಾಕ್ರೋವನ್ನು `no_std` ಸೆಟಪ್‌ಗಳಲ್ಲಿಯೂ ಬಳಸಬಹುದು.
/// `no_std` ಸೆಟಪ್‌ನಲ್ಲಿ ನೀವು ಘಟಕಗಳ ಅನುಷ್ಠಾನ ವಿವರಗಳಿಗೆ ಜವಾಬ್ದಾರರಾಗಿರುತ್ತೀರಿ.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಿದ ಡೇಟಾವನ್ನು ಬಫರ್‌ಗೆ ಬರೆಯಿರಿ, ಹೊಸ ಲೈನ್ ಅನ್ನು ಸೇರಿಸಲಾಗುತ್ತದೆ.
///
/// ಎಲ್ಲಾ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ, ಹೊಸ ಲೈನ್ ಕೇವಲ LINE ಫೀಡ್ ಅಕ್ಷರ (`\n`/`U+000A`) ಆಗಿದೆ (ಹೆಚ್ಚುವರಿ CARRIAGE RETURN (`\r`/`U+000D`) ಇಲ್ಲ.
///
/// ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ, [`write!`] ನೋಡಿ.ಫಾರ್ಮ್ಯಾಟ್ ಸ್ಟ್ರಿಂಗ್ ಸಿಂಟ್ಯಾಕ್ಸ್ ಬಗ್ಗೆ ಮಾಹಿತಿಗಾಗಿ, [`std::fmt`] ನೋಡಿ.
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// ಮಾಡ್ಯೂಲ್ `std::fmt::Write` ಮತ್ತು `std::io::Write` ಎರಡನ್ನೂ ಆಮದು ಮಾಡಿಕೊಳ್ಳಬಹುದು ಮತ್ತು ಕಾರ್ಯಗತಗೊಳಿಸುವ ವಸ್ತುಗಳ ಮೇಲೆ `write!` ಗೆ ಕರೆ ಮಾಡಬಹುದು, ಏಕೆಂದರೆ ವಸ್ತುಗಳು ಸಾಮಾನ್ಯವಾಗಿ ಎರಡನ್ನೂ ಕಾರ್ಯಗತಗೊಳಿಸುವುದಿಲ್ಲ.
/// ಆದಾಗ್ಯೂ, ಮಾಡ್ಯೂಲ್ traits ಅರ್ಹತೆಯನ್ನು ಆಮದು ಮಾಡಿಕೊಳ್ಳಬೇಕು ಆದ್ದರಿಂದ ಅವರ ಹೆಸರುಗಳು ಸಂಘರ್ಷಗೊಳ್ಳುವುದಿಲ್ಲ:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt ಅನ್ನು ಬಳಸುತ್ತದೆ
///     writeln!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt ಅನ್ನು ಬಳಸುತ್ತದೆ
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// ತಲುಪಲಾಗದ ಕೋಡ್ ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ.
///
/// ಕೆಲವು ಕೋಡ್ ಅನ್ನು ತಲುಪಲಾಗುವುದಿಲ್ಲ ಎಂದು ಕಂಪೈಲರ್ ನಿರ್ಧರಿಸಲು ಸಾಧ್ಯವಾಗದ ಯಾವುದೇ ಸಮಯದಲ್ಲಿ ಇದು ಉಪಯುಕ್ತವಾಗಿರುತ್ತದೆ.ಉದಾಹರಣೆಗೆ:
///
/// * ಕಾವಲು ಪರಿಸ್ಥಿತಿಗಳೊಂದಿಗೆ ಶಸ್ತ್ರಾಸ್ತ್ರಗಳನ್ನು ಹೊಂದಿಸಿ.
/// * ಕ್ರಿಯಾತ್ಮಕವಾಗಿ ಕೊನೆಗೊಳ್ಳುವ ಕುಣಿಕೆಗಳು.
/// * ಕ್ರಿಯಾತ್ಮಕವಾಗಿ ಕೊನೆಗೊಳ್ಳುವ ಇಟರೇಟರ್ಗಳು.
///
/// ಕೋಡ್ ತಲುಪಲಾಗುವುದಿಲ್ಲ ಎಂಬ ನಿರ್ಣಯವು ತಪ್ಪೆಂದು ಸಾಬೀತಾದರೆ, ಪ್ರೋಗ್ರಾಂ ತಕ್ಷಣವೇ [`panic!`] ನೊಂದಿಗೆ ಕೊನೆಗೊಳ್ಳುತ್ತದೆ.
///
/// ಈ ಮ್ಯಾಕ್ರೊದ ಅಸುರಕ್ಷಿತ ಪ್ರತಿರೂಪವೆಂದರೆ [`unreachable_unchecked`] ಕಾರ್ಯ, ಇದು ಕೋಡ್ ತಲುಪಿದರೆ ವಿವರಿಸಲಾಗದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// ಇದು ಯಾವಾಗಲೂ [`panic!`] ಆಗಿರುತ್ತದೆ.
///
/// # Examples
///
/// ಶಸ್ತ್ರಾಸ್ತ್ರಗಳನ್ನು ಹೊಂದಿಸಿ:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // ಕಾಮೆಂಟ್ ಮಾಡಿದರೆ ಕಂಪೈಲ್ ದೋಷ
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // x/3 ನ ಅತ್ಯಂತ ಬಡ ಅನುಷ್ಠಾನಗಳಲ್ಲಿ ಒಂದಾಗಿದೆ
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// "not implemented" ಸಂದೇಶದೊಂದಿಗೆ ಪ್ಯಾನಿಕ್ ಮಾಡುವ ಮೂಲಕ ಅನುಷ್ಠಾನಗೊಳಿಸದ ಕೋಡ್ ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ.
///
/// ಇದು ನಿಮ್ಮ ಕೋಡ್ ಅನ್ನು ಟೈಪ್-ಚೆಕ್ ಮಾಡಲು ಅನುಮತಿಸುತ್ತದೆ, ನೀವು trait ಅನ್ನು ಮೂಲಮಾದರಿ ಅಥವಾ ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತಿದ್ದರೆ ಅದು ಉಪಯುಕ್ತವಾಗಿದೆ, ಅದು ಬಹು ವಿಧಾನಗಳ ಅಗತ್ಯವಿರುತ್ತದೆ.
///
/// `unimplemented!` ಮತ್ತು [`todo!`] ನಡುವಿನ ವ್ಯತ್ಯಾಸವೆಂದರೆ `todo!` ನಂತರ ಕಾರ್ಯವನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಉದ್ದೇಶವನ್ನು ತಿಳಿಸುತ್ತದೆ ಮತ್ತು ಸಂದೇಶವು "not yet implemented" ಆಗಿದ್ದರೆ, `unimplemented!` ಅಂತಹ ಯಾವುದೇ ಹಕ್ಕುಗಳನ್ನು ನೀಡುವುದಿಲ್ಲ.
/// ಇದರ ಸಂದೇಶ "not implemented" ಆಗಿದೆ.
/// ಕೆಲವು ಐಡಿಇಗಳು `ಟೊಡೊ!` ರು ಎಂದು ಗುರುತಿಸುತ್ತವೆ.
///
/// # Panics
///
/// ಇದು ಯಾವಾಗಲೂ [`panic!`] ಆಗಿರುತ್ತದೆ ಏಕೆಂದರೆ `unimplemented!` ಎಂಬುದು ಸ್ಥಿರ, ನಿರ್ದಿಷ್ಟ ಸಂದೇಶದೊಂದಿಗೆ `panic!` ಗೆ ಸಂಕ್ಷಿಪ್ತ ರೂಪವಾಗಿದೆ.
///
/// `panic!` ನಂತೆ, ಈ ಮ್ಯಾಕ್ರೋ ಕಸ್ಟಮ್ ಮೌಲ್ಯಗಳನ್ನು ಪ್ರದರ್ಶಿಸಲು ಎರಡನೇ ರೂಪವನ್ನು ಹೊಂದಿದೆ.
///
/// # Examples
///
/// ನಮ್ಮಲ್ಲಿ trait `Foo` ಇದೆ ಎಂದು ಹೇಳಿ:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// ನಾವು 'MyStruct' ಗಾಗಿ `Foo` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ಬಯಸುತ್ತೇವೆ, ಆದರೆ ಕೆಲವು ಕಾರಣಗಳಿಂದಾಗಿ ಇದು `bar()` ಕಾರ್ಯವನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ಮಾತ್ರ ಅರ್ಥಪೂರ್ಣವಾಗಿದೆ.
/// `baz()` ಮತ್ತು `Foo` ನ ನಮ್ಮ ಅನುಷ್ಠಾನದಲ್ಲಿ `qux()` ಅನ್ನು ಇನ್ನೂ ವ್ಯಾಖ್ಯಾನಿಸಬೇಕಾಗಿದೆ, ಆದರೆ ನಮ್ಮ ಕೋಡ್ ಅನ್ನು ಕಂಪೈಲ್ ಮಾಡಲು ಅನುಮತಿಸಲು ನಾವು `unimplemented!` ಅನ್ನು ಅವುಗಳ ವ್ಯಾಖ್ಯಾನಗಳಲ್ಲಿ ಬಳಸಬಹುದು.
///
/// ಅನುಷ್ಠಾನಗೊಳಿಸದ ವಿಧಾನಗಳನ್ನು ತಲುಪಿದರೆ ನಮ್ಮ ಪ್ರೋಗ್ರಾಂ ಚಾಲನೆಯಲ್ಲಿ ನಿಲ್ಲುವಂತೆ ನಾವು ಇನ್ನೂ ಬಯಸುತ್ತೇವೆ.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // ಇದು `baz` ಗೆ `MyStruct` ಗೆ ಯಾವುದೇ ಅರ್ಥವಿಲ್ಲ, ಆದ್ದರಿಂದ ನಮಗೆ ಇಲ್ಲಿ ಯಾವುದೇ ತರ್ಕವಿಲ್ಲ.
/////
///         // ಇದು "thread 'main' panicked at 'not implemented'" ಅನ್ನು ಪ್ರದರ್ಶಿಸುತ್ತದೆ.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // ನಾವು ಇಲ್ಲಿ ಕೆಲವು ತರ್ಕಗಳನ್ನು ಹೊಂದಿದ್ದೇವೆ, ಅನುಷ್ಠಾನಗೊಳಿಸದವರಿಗೆ ನಾವು ಸಂದೇಶವನ್ನು ಸೇರಿಸಬಹುದು!ನಮ್ಮ ಲೋಪವನ್ನು ಪ್ರದರ್ಶಿಸಲು.
///         // ಇದು ಪ್ರದರ್ಶಿಸುತ್ತದೆ: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// ಅಪೂರ್ಣ ಕೋಡ್ ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ.
///
/// ನೀವು ಮೂಲಮಾದರಿ ಮಾಡುತ್ತಿದ್ದರೆ ಮತ್ತು ನಿಮ್ಮ ಕೋಡ್ ಟೈಪ್ ಚೆಕ್ ಹೊಂದಲು ಬಯಸುತ್ತಿದ್ದರೆ ಇದು ಉಪಯುಕ್ತವಾಗಿರುತ್ತದೆ.
///
/// [`unimplemented!`] ಮತ್ತು `todo!` ನಡುವಿನ ವ್ಯತ್ಯಾಸವೆಂದರೆ `todo!` ನಂತರ ಕಾರ್ಯವನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಉದ್ದೇಶವನ್ನು ತಿಳಿಸುತ್ತದೆ ಮತ್ತು ಸಂದೇಶವು "not yet implemented" ಆಗಿದ್ದರೆ, `unimplemented!` ಅಂತಹ ಯಾವುದೇ ಹಕ್ಕುಗಳನ್ನು ನೀಡುವುದಿಲ್ಲ.
/// ಇದರ ಸಂದೇಶ "not implemented" ಆಗಿದೆ.
/// ಕೆಲವು ಐಡಿಇಗಳು `ಟೊಡೊ!` ರು ಎಂದು ಗುರುತಿಸುತ್ತವೆ.
///
/// # Panics
///
/// ಇದು ಯಾವಾಗಲೂ [`panic!`] ಆಗಿರುತ್ತದೆ.
///
/// # Examples
///
/// ಕೆಲವು ಪ್ರಗತಿಯ ಕೋಡ್‌ನ ಉದಾಹರಣೆ ಇಲ್ಲಿದೆ.ನಮ್ಮಲ್ಲಿ trait `Foo` ಇದೆ:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// ನಮ್ಮ ಪ್ರಕಾರಗಳಲ್ಲಿ `Foo` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ನಾವು ಬಯಸುತ್ತೇವೆ, ಆದರೆ ನಾವು ಮೊದಲು ಕೇವಲ `bar()` ನಲ್ಲಿ ಕೆಲಸ ಮಾಡಲು ಬಯಸುತ್ತೇವೆ.ನಮ್ಮ ಕೋಡ್ ಕಂಪೈಲ್ ಮಾಡಲು, ನಾವು `baz()` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಬೇಕಾಗಿದೆ, ಆದ್ದರಿಂದ ನಾವು `todo!` ಅನ್ನು ಬಳಸಬಹುದು:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // ಅನುಷ್ಠಾನ ಇಲ್ಲಿಗೆ ಹೋಗುತ್ತದೆ
///     }
///
///     fn baz(&self) {
///         // ಸದ್ಯಕ್ಕೆ baz() ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಬಗ್ಗೆ ಚಿಂತಿಸಬೇಡಿ
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // ನಾವು baz() ಅನ್ನು ಸಹ ಬಳಸುತ್ತಿಲ್ಲ, ಆದ್ದರಿಂದ ಇದು ಉತ್ತಮವಾಗಿದೆ.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// ಅಂತರ್ನಿರ್ಮಿತ ಮ್ಯಾಕ್ರೋಗಳ ವ್ಯಾಖ್ಯಾನಗಳು.
///
/// ಹೆಚ್ಚಿನ ಮ್ಯಾಕ್ರೋ ಗುಣಲಕ್ಷಣಗಳನ್ನು (ಸ್ಥಿರತೆ, ಗೋಚರತೆ, ಇತ್ಯಾದಿ) ಇಲ್ಲಿ ಮೂಲ ಕೋಡ್‌ನಿಂದ ತೆಗೆದುಕೊಳ್ಳಲಾಗಿದೆ, ವಿಸ್ತರಣಾ ಕಾರ್ಯಗಳನ್ನು ಹೊರತುಪಡಿಸಿ ಮ್ಯಾಕ್ರೋ ಇನ್‌ಪುಟ್‌ಗಳನ್ನು p ಟ್‌ಪುಟ್‌ಗಳಾಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ, ಆ ಕಾರ್ಯಗಳನ್ನು ಕಂಪೈಲರ್ ಒದಗಿಸುತ್ತದೆ.
///
///
pub(crate) mod builtin {

    /// ಎದುರಾದಾಗ ಕೊಟ್ಟಿರುವ ದೋಷ ಸಂದೇಶದೊಂದಿಗೆ ಸಂಕಲನ ವಿಫಲಗೊಳ್ಳಲು ಕಾರಣವಾಗುತ್ತದೆ.
    ///
    /// ತಪ್ಪಾದ ಪರಿಸ್ಥಿತಿಗಳಿಗೆ ಉತ್ತಮ ದೋಷ ಸಂದೇಶಗಳನ್ನು ಒದಗಿಸಲು crate ಷರತ್ತುಬದ್ಧ ಸಂಕಲನ ತಂತ್ರವನ್ನು ಬಳಸಿದಾಗ ಈ ಮ್ಯಾಕ್ರೋವನ್ನು ಬಳಸಬೇಕು.
    ///
    /// ಇದು [`panic!`] ನ ಕಂಪೈಲರ್-ಮಟ್ಟದ ರೂಪವಾಗಿದೆ, ಆದರೆ *ರನ್ಟೈಮ್* ಗಿಂತ *ಸಂಕಲನ* ಸಮಯದಲ್ಲಿ ದೋಷವನ್ನು ಹೊರಸೂಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಅಂತಹ ಎರಡು ಉದಾಹರಣೆಗಳೆಂದರೆ ಮ್ಯಾಕ್ರೋಗಳು ಮತ್ತು `#[cfg]` ಪರಿಸರಗಳು.
    ///
    /// ಮ್ಯಾಕ್ರೋ ಅಮಾನ್ಯ ಮೌಲ್ಯಗಳನ್ನು ರವಾನಿಸಿದರೆ ಉತ್ತಮ ಕಂಪೈಲರ್ ದೋಷವನ್ನು ಹೊರಸೂಸುತ್ತದೆ.
    /// ಅಂತಿಮ branch ಇಲ್ಲದಿದ್ದರೆ, ಕಂಪೈಲರ್ ಇನ್ನೂ ದೋಷವನ್ನು ಹೊರಸೂಸುತ್ತದೆ, ಆದರೆ ದೋಷದ ಸಂದೇಶವು ಎರಡು ಮಾನ್ಯ ಮೌಲ್ಯಗಳನ್ನು ಉಲ್ಲೇಖಿಸುವುದಿಲ್ಲ.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// ಹಲವಾರು ವೈಶಿಷ್ಟ್ಯಗಳಲ್ಲಿ ಒಂದು ಲಭ್ಯವಿಲ್ಲದಿದ್ದರೆ ಕಂಪೈಲರ್ ದೋಷವನ್ನು ಹೊರಸೂಸಿರಿ.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ಇತರ ಸ್ಟ್ರಿಂಗ್-ಫಾರ್ಮ್ಯಾಟಿಂಗ್ ಮ್ಯಾಕ್ರೋಗಳಿಗಾಗಿ ನಿಯತಾಂಕಗಳನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    ///
    /// ಹಾದುಹೋಗುವ ಪ್ರತಿಯೊಂದು ಹೆಚ್ಚುವರಿ ವಾದಕ್ಕೂ `{}` ಹೊಂದಿರುವ ಫಾರ್ಮ್ಯಾಟಿಂಗ್ ಸ್ಟ್ರಿಂಗ್ ಅಕ್ಷರಶಃ ತೆಗೆದುಕೊಳ್ಳುವ ಮೂಲಕ ಈ ಮ್ಯಾಕ್ರೋ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ.
    /// `format_args!` output ಟ್ಪುಟ್ ಅನ್ನು ಸ್ಟ್ರಿಂಗ್ ಎಂದು ವ್ಯಾಖ್ಯಾನಿಸಬಹುದು ಮತ್ತು ಆರ್ಗ್ಯುಮೆಂಟ್ಗಳನ್ನು ಒಂದೇ ಪ್ರಕಾರಕ್ಕೆ ಅಂಗೀಕರಿಸುತ್ತದೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ಹೆಚ್ಚುವರಿ ನಿಯತಾಂಕಗಳನ್ನು ಸಿದ್ಧಪಡಿಸುತ್ತದೆ.
    /// [`Display`] trait ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಯಾವುದೇ ಮೌಲ್ಯವನ್ನು `format_args!` ಗೆ ರವಾನಿಸಬಹುದು, ಯಾವುದೇ [`Debug`] ಅನುಷ್ಠಾನವನ್ನು ಫಾರ್ಮ್ಯಾಟಿಂಗ್ ಸ್ಟ್ರಿಂಗ್‌ನೊಳಗೆ `{:?}` ಗೆ ರವಾನಿಸಬಹುದು.
    ///
    ///
    /// ಈ ಮ್ಯಾಕ್ರೋ [`fmt::Arguments`] ಪ್ರಕಾರದ ಮೌಲ್ಯವನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ.ಉಪಯುಕ್ತ ಪುನರ್ನಿರ್ದೇಶನವನ್ನು ನಿರ್ವಹಿಸಲು ಈ ಮೌಲ್ಯವನ್ನು [`std::fmt`] ಒಳಗೆ ಮ್ಯಾಕ್ರೋಗಳಿಗೆ ರವಾನಿಸಬಹುದು.
    /// ಎಲ್ಲಾ ಇತರ ಫಾರ್ಮ್ಯಾಟಿಂಗ್ ಮ್ಯಾಕ್ರೋಗಳು ([`ಫಾರ್ಮ್ಯಾಟ್!`], [`write!`], [`println!`], ಇತ್ಯಾದಿ) ಇದರ ಮೂಲಕ ಪ್ರಾಕ್ಸಿ ಆಗುತ್ತವೆ.
    /// `format_args!`, ಅದರ ಪಡೆದ ಮ್ಯಾಕ್ರೋಗಳಿಗಿಂತ ಭಿನ್ನವಾಗಿ, ರಾಶಿ ಹಂಚಿಕೆಯನ್ನು ತಪ್ಪಿಸುತ್ತದೆ.
    ///
    /// ಕೆಳಗೆ ನೋಡಿದಂತೆ `Debug` ಮತ್ತು `Display` ಸನ್ನಿವೇಶಗಳಲ್ಲಿ `format_args!` ಹಿಂದಿರುಗಿಸುವ [`fmt::Arguments`] ಮೌಲ್ಯವನ್ನು ನೀವು ಬಳಸಬಹುದು.
    /// ಉದಾಹರಣೆಯು `Debug` ಮತ್ತು `Display` ಸ್ವರೂಪವನ್ನು ಒಂದೇ ವಿಷಯಕ್ಕೆ ತೋರಿಸುತ್ತದೆ: `format_args!` ನಲ್ಲಿ ಇಂಟರ್ಪೋಲೇಟೆಡ್ ಫಾರ್ಮ್ಯಾಟ್ ಸ್ಟ್ರಿಂಗ್.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ, [`std::fmt`] ನಲ್ಲಿ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// `format_args` ನಂತೆಯೇ, ಆದರೆ ಕೊನೆಯಲ್ಲಿ ಹೊಸ ಲೈನ್ ಅನ್ನು ಸೇರಿಸುತ್ತದೆ.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// ಕಂಪೈಲ್ ಸಮಯದಲ್ಲಿ ಪರಿಸರ ವೇರಿಯಬಲ್ ಅನ್ನು ಪರಿಶೀಲಿಸುತ್ತದೆ.
    ///
    /// ಈ ಮ್ಯಾಕ್ರೋ ಕಂಪೈಲ್ ಸಮಯದಲ್ಲಿ ಹೆಸರಿಸಲಾದ ಪರಿಸರ ವೇರಿಯೇಬಲ್ನ ಮೌಲ್ಯಕ್ಕೆ ವಿಸ್ತರಿಸುತ್ತದೆ, ಇದು `&'static str` ಪ್ರಕಾರದ ಅಭಿವ್ಯಕ್ತಿಯನ್ನು ನೀಡುತ್ತದೆ.
    ///
    ///
    /// ಪರಿಸರ ವೇರಿಯಬಲ್ ಅನ್ನು ವ್ಯಾಖ್ಯಾನಿಸದಿದ್ದರೆ, ನಂತರ ಸಂಕಲನ ದೋಷವನ್ನು ಹೊರಸೂಸಲಾಗುತ್ತದೆ.
    /// ಕಂಪೈಲ್ ದೋಷವನ್ನು ಹೊರಸೂಸದಿರಲು, ಬದಲಿಗೆ [`option_env!`] ಮ್ಯಾಕ್ರೋ ಬಳಸಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// ಎರಡನೇ ನಿಯತಾಂಕವಾಗಿ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಹಾದುಹೋಗುವ ಮೂಲಕ ನೀವು ದೋಷ ಸಂದೇಶವನ್ನು ಗ್ರಾಹಕೀಯಗೊಳಿಸಬಹುದು:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// `documentation` ಪರಿಸರ ವೇರಿಯಬಲ್ ಅನ್ನು ವ್ಯಾಖ್ಯಾನಿಸದಿದ್ದರೆ, ನೀವು ಈ ಕೆಳಗಿನ ದೋಷವನ್ನು ಪಡೆಯುತ್ತೀರಿ:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ಕಂಪೈಲ್ ಸಮಯದಲ್ಲಿ ಪರಿಸರ ವೇರಿಯಬಲ್ ಅನ್ನು ಐಚ್ ally ಿಕವಾಗಿ ಪರಿಶೀಲಿಸುತ್ತದೆ.
    ///
    /// ಕಂಪೈಲ್ ಸಮಯದಲ್ಲಿ ಹೆಸರಿಸಲಾದ ಪರಿಸರ ವೇರಿಯೇಬಲ್ ಇದ್ದರೆ, ಇದು `Option<&'static str>` ಪ್ರಕಾರದ ಅಭಿವ್ಯಕ್ತಿಯಾಗಿ ವಿಸ್ತರಿಸುತ್ತದೆ, ಇದರ ಮೌಲ್ಯವು ಪರಿಸರ ವೇರಿಯೇಬಲ್ನ ಮೌಲ್ಯದ `Some` ಆಗಿದೆ.
    /// ಪರಿಸರ ವೇರಿಯಬಲ್ ಇಲ್ಲದಿದ್ದರೆ, ಇದು `None` ಗೆ ವಿಸ್ತರಿಸುತ್ತದೆ.
    /// ಈ ಪ್ರಕಾರದ ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ [`Option<T>`][Option] ನೋಡಿ.
    ///
    /// ಪರಿಸರ ವೇರಿಯೇಬಲ್ ಇದೆಯೋ ಇಲ್ಲವೋ ಎಂಬುದನ್ನು ಲೆಕ್ಕಿಸದೆ ಈ ಮ್ಯಾಕ್ರೋವನ್ನು ಬಳಸುವಾಗ ಕಂಪೈಲ್ ಸಮಯ ದೋಷವನ್ನು ಎಂದಿಗೂ ಹೊರಸೂಸಲಾಗುವುದಿಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ಗುರುತಿಸುವಿಕೆಗಳನ್ನು ಒಂದು ಗುರುತಿಸುವಿಕೆಯಾಗಿ ಸಂಯೋಜಿಸುತ್ತದೆ.
    ///
    /// ಈ ಮ್ಯಾಕ್ರೋ ಯಾವುದೇ ಅಲ್ಪವಿರಾಮದಿಂದ ಬೇರ್ಪಟ್ಟ ಗುರುತಿಸುವಿಕೆಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ, ಮತ್ತು ಅವೆಲ್ಲವನ್ನೂ ಒಂದಾಗಿ ಜೋಡಿಸುತ್ತದೆ, ಇದು ಹೊಸ ಗುರುತಿಸುವಿಕೆಯ ಅಭಿವ್ಯಕ್ತಿಯನ್ನು ನೀಡುತ್ತದೆ.
    /// ನೈರ್ಮಲ್ಯವು ಈ ಮ್ಯಾಕ್ರೊ ಸ್ಥಳೀಯ ಅಸ್ಥಿರಗಳನ್ನು ಸೆರೆಹಿಡಿಯಲು ಸಾಧ್ಯವಾಗುವುದಿಲ್ಲ ಎಂದು ಗಮನಿಸಿ.
    /// ಅಲ್ಲದೆ, ಸಾಮಾನ್ಯ ನಿಯಮದಂತೆ, ಮ್ಯಾಕ್ರೋಗಳನ್ನು ಐಟಂ, ಹೇಳಿಕೆ ಅಥವಾ ಅಭಿವ್ಯಕ್ತಿ ಸ್ಥಾನದಲ್ಲಿ ಮಾತ್ರ ಅನುಮತಿಸಲಾಗುತ್ತದೆ.
    /// ಇದರರ್ಥ ನೀವು ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ ಅಸ್ಥಿರಗಳು, ಕಾರ್ಯಗಳು ಅಥವಾ ಮಾಡ್ಯೂಲ್‌ಗಳನ್ನು ಉಲ್ಲೇಖಿಸಲು ಈ ಮ್ಯಾಕ್ರೋವನ್ನು ಬಳಸುವಾಗ, ಅದರೊಂದಿಗೆ ಹೊಸದನ್ನು ವ್ಯಾಖ್ಯಾನಿಸಲು ನಿಮಗೆ ಸಾಧ್ಯವಿಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (ಹೊಸ, ವಿನೋದ, ಹೆಸರು) { }//ಈ ರೀತಿಯಲ್ಲಿ ಬಳಸಲಾಗುವುದಿಲ್ಲ!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ಅಕ್ಷರಶಃ ಸ್ಥಿರ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ಗೆ ಒಗ್ಗೂಡಿಸುತ್ತದೆ.
    ///
    /// ಈ ಮ್ಯಾಕ್ರೋ ಯಾವುದೇ ಅಲ್ಪವಿರಾಮದಿಂದ ಬೇರ್ಪಟ್ಟ ಅಕ್ಷರಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ, ಇದು `&'static str` ಪ್ರಕಾರದ ಅಭಿವ್ಯಕ್ತಿಯನ್ನು ನೀಡುತ್ತದೆ, ಇದು ಎಡದಿಂದ ಬಲಕ್ಕೆ ಒಗ್ಗೂಡಿಸಿದ ಎಲ್ಲಾ ಅಕ್ಷರಗಳನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
    ///
    ///
    /// ಇಂಟಿಜರ್ ಮತ್ತು ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಅಕ್ಷರಗಳನ್ನು ಒಗ್ಗೂಡಿಸುವ ಸಲುವಾಗಿ ಸ್ಟ್ರಿಂಗ್ ಮಾಡಲಾಗಿದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ಅದನ್ನು ಆಹ್ವಾನಿಸಿದ ಸಾಲು ಸಂಖ್ಯೆಗೆ ವಿಸ್ತರಿಸುತ್ತದೆ.
    ///
    /// [`column!`] ಮತ್ತು [`file!`] ನೊಂದಿಗೆ, ಈ ಮ್ಯಾಕ್ರೋಗಳು ಡೆವಲಪರ್‌ಗಳಿಗೆ ಮೂಲದೊಳಗಿನ ಸ್ಥಳದ ಬಗ್ಗೆ ಡೀಬಗ್ ಮಾಡುವ ಮಾಹಿತಿಯನ್ನು ಒದಗಿಸುತ್ತವೆ.
    ///
    /// ವಿಸ್ತರಿತ ಅಭಿವ್ಯಕ್ತಿ `u32` ಪ್ರಕಾರವನ್ನು ಹೊಂದಿದೆ ಮತ್ತು ಇದು 1-ಆಧಾರಿತವಾಗಿದೆ, ಆದ್ದರಿಂದ ಪ್ರತಿ ಫೈಲ್‌ನ ಮೊದಲ ಸಾಲು 1 ಕ್ಕೆ, ಎರಡನೆಯದು 2 ರಿಂದ ಇತ್ಯಾದಿಗಳಿಗೆ ಮೌಲ್ಯಮಾಪನ ಮಾಡುತ್ತದೆ.
    /// ಇದು ಸಾಮಾನ್ಯ ಕಂಪೈಲರ್‌ಗಳು ಅಥವಾ ಜನಪ್ರಿಯ ಸಂಪಾದಕರ ದೋಷ ಸಂದೇಶಗಳಿಗೆ ಅನುಗುಣವಾಗಿರುತ್ತದೆ.
    /// ಹಿಂತಿರುಗಿದ ರೇಖೆಯು `line!` ಆಹ್ವಾನದ ರೇಖೆಯಾಗಿದೆ *ಅಗತ್ಯವಿಲ್ಲ*, ಆದರೆ `line!` ಮ್ಯಾಕ್ರೊದ ಆಹ್ವಾನಕ್ಕೆ ಕಾರಣವಾಗುವ ಮೊದಲ ಮ್ಯಾಕ್ರೋ ಆಹ್ವಾನ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// ಅದನ್ನು ಆಹ್ವಾನಿಸಿದ ಕಾಲಮ್ ಸಂಖ್ಯೆಗೆ ವಿಸ್ತರಿಸುತ್ತದೆ.
    ///
    /// [`line!`] ಮತ್ತು [`file!`] ನೊಂದಿಗೆ, ಈ ಮ್ಯಾಕ್ರೋಗಳು ಡೆವಲಪರ್‌ಗಳಿಗೆ ಮೂಲದೊಳಗಿನ ಸ್ಥಳದ ಬಗ್ಗೆ ಡೀಬಗ್ ಮಾಡುವ ಮಾಹಿತಿಯನ್ನು ಒದಗಿಸುತ್ತವೆ.
    ///
    /// ವಿಸ್ತರಿತ ಅಭಿವ್ಯಕ್ತಿ `u32` ಪ್ರಕಾರವನ್ನು ಹೊಂದಿದೆ ಮತ್ತು ಇದು 1-ಆಧಾರಿತವಾಗಿದೆ, ಆದ್ದರಿಂದ ಪ್ರತಿ ಸಾಲಿನ ಮೊದಲ ಕಾಲಮ್ 1 ಕ್ಕೆ, ಎರಡನೆಯದು 2 ರಿಂದ ಇತ್ಯಾದಿಗಳಿಗೆ ಮೌಲ್ಯಮಾಪನ ಮಾಡುತ್ತದೆ.
    /// ಇದು ಸಾಮಾನ್ಯ ಕಂಪೈಲರ್‌ಗಳು ಅಥವಾ ಜನಪ್ರಿಯ ಸಂಪಾದಕರ ದೋಷ ಸಂದೇಶಗಳಿಗೆ ಅನುಗುಣವಾಗಿರುತ್ತದೆ.
    /// ಹಿಂತಿರುಗಿದ ಕಾಲಮ್ `column!` ಆಹ್ವಾನ ರೇಖೆಯ *ಅಗತ್ಯವಿಲ್ಲ*, ಆದರೆ `column!` ಮ್ಯಾಕ್ರೊದ ಆಹ್ವಾನಕ್ಕೆ ಕಾರಣವಾಗುವ ಮೊದಲ ಮ್ಯಾಕ್ರೋ ಆಹ್ವಾನ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// ಅದನ್ನು ಆಹ್ವಾನಿಸಿದ ಫೈಲ್ ಹೆಸರಿಗೆ ವಿಸ್ತರಿಸುತ್ತದೆ.
    ///
    /// [`line!`] ಮತ್ತು [`column!`] ನೊಂದಿಗೆ, ಈ ಮ್ಯಾಕ್ರೋಗಳು ಡೆವಲಪರ್‌ಗಳಿಗೆ ಮೂಲದೊಳಗಿನ ಸ್ಥಳದ ಬಗ್ಗೆ ಡೀಬಗ್ ಮಾಡುವ ಮಾಹಿತಿಯನ್ನು ಒದಗಿಸುತ್ತವೆ.
    ///
    /// ವಿಸ್ತರಿತ ಅಭಿವ್ಯಕ್ತಿ `&'static str` ಪ್ರಕಾರವನ್ನು ಹೊಂದಿದೆ, ಮತ್ತು ಹಿಂತಿರುಗಿದ ಫೈಲ್ `file!` ಮ್ಯಾಕ್ರೊದ ಆಹ್ವಾನವಲ್ಲ, ಆದರೆ `file!` ಮ್ಯಾಕ್ರೋನ ಆಹ್ವಾನಕ್ಕೆ ಕಾರಣವಾಗುವ ಮೊದಲ ಮ್ಯಾಕ್ರೋ ಆಹ್ವಾನವಾಗಿದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// ಅದರ ವಾದಗಳನ್ನು ಗಟ್ಟಿಗೊಳಿಸುತ್ತದೆ.
    ///
    /// ಈ ಮ್ಯಾಕ್ರೋ `&'static str` ಪ್ರಕಾರದ ಅಭಿವ್ಯಕ್ತಿಯನ್ನು ನೀಡುತ್ತದೆ, ಇದು ಮ್ಯಾಕ್ರೋಗೆ ರವಾನಿಸಲಾದ ಎಲ್ಲಾ tokens ನ ಸ್ಟ್ರೈಫಿಕೇಶನ್ ಆಗಿದೆ.
    /// ಮ್ಯಾಕ್ರೋ ಇನ್ವಾಕೇಶನ್‌ನ ಸಿಂಟ್ಯಾಕ್ಸ್‌ನಲ್ಲಿ ಯಾವುದೇ ನಿರ್ಬಂಧಗಳನ್ನು ಇರಿಸಲಾಗಿಲ್ಲ.
    ///
    /// tokens ಇನ್ಪುಟ್ನ ವಿಸ್ತರಿತ ಫಲಿತಾಂಶಗಳು future ನಲ್ಲಿ ಬದಲಾಗಬಹುದು ಎಂಬುದನ್ನು ಗಮನಿಸಿ.ನೀವು .ಟ್‌ಪುಟ್ ಅನ್ನು ಅವಲಂಬಿಸಿದರೆ ನೀವು ಜಾಗರೂಕರಾಗಿರಬೇಕು.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// UTF-8 ಎನ್ಕೋಡ್ ಮಾಡಿದ ಫೈಲ್ ಅನ್ನು ಸ್ಟ್ರಿಂಗ್ ಆಗಿ ಒಳಗೊಂಡಿದೆ.
    ///
    /// ಫೈಲ್ ಪ್ರಸ್ತುತ ಫೈಲ್‌ಗೆ ಸಂಬಂಧಿಸಿದೆ (ಮಾಡ್ಯೂಲ್‌ಗಳು ಹೇಗೆ ಕಂಡುಬರುತ್ತವೆ ಎಂಬುದರಂತೆಯೇ).
    /// ಒದಗಿಸಿದ ಮಾರ್ಗವನ್ನು ಕಂಪೈಲ್ ಸಮಯದಲ್ಲಿ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್-ನಿರ್ದಿಷ್ಟ ರೀತಿಯಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗುತ್ತದೆ.
    /// ಆದ್ದರಿಂದ, ಉದಾಹರಣೆಗೆ, Windows ಬ್ಯಾಕ್‌ಸ್ಲ್ಯಾಶ್‌ಗಳನ್ನು ಹೊಂದಿರುವ Windows ಮಾರ್ಗವನ್ನು ಹೊಂದಿರುವ ಆಹ್ವಾನವು Unix ನಲ್ಲಿ ಸರಿಯಾಗಿ ಕಂಪೈಲ್ ಮಾಡುವುದಿಲ್ಲ.
    ///
    ///
    /// ಈ ಮ್ಯಾಕ್ರೋ ಫೈಲ್‌ನ ವಿಷಯಗಳಾದ `&'static str` ಪ್ರಕಾರದ ಅಭಿವ್ಯಕ್ತಿಯನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಈ ಕೆಳಗಿನ ವಿಷಯಗಳೊಂದಿಗೆ ಒಂದೇ ಡೈರೆಕ್ಟರಿಯಲ್ಲಿ ಎರಡು ಫೈಲ್‌ಗಳಿವೆ ಎಂದು ume ಹಿಸಿ:
    ///
    /// ಫೈಲ್ 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// ಫೈಲ್ 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs' ಅನ್ನು ಕಂಪೈಲ್ ಮಾಡುವುದು ಮತ್ತು ಪರಿಣಾಮವಾಗಿ ಬೈನರಿ ಚಾಲನೆ ಮಾಡುವುದರಿಂದ "adiós" ಅನ್ನು ಮುದ್ರಿಸುತ್ತದೆ.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ಬೈಟ್ ರಚನೆಯ ಉಲ್ಲೇಖವಾಗಿ ಫೈಲ್ ಅನ್ನು ಒಳಗೊಂಡಿದೆ.
    ///
    /// ಫೈಲ್ ಪ್ರಸ್ತುತ ಫೈಲ್‌ಗೆ ಸಂಬಂಧಿಸಿದೆ (ಮಾಡ್ಯೂಲ್‌ಗಳು ಹೇಗೆ ಕಂಡುಬರುತ್ತವೆ ಎಂಬುದರಂತೆಯೇ).
    /// ಒದಗಿಸಿದ ಮಾರ್ಗವನ್ನು ಕಂಪೈಲ್ ಸಮಯದಲ್ಲಿ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್-ನಿರ್ದಿಷ್ಟ ರೀತಿಯಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗುತ್ತದೆ.
    /// ಆದ್ದರಿಂದ, ಉದಾಹರಣೆಗೆ, Windows ಬ್ಯಾಕ್‌ಸ್ಲ್ಯಾಶ್‌ಗಳನ್ನು ಹೊಂದಿರುವ Windows ಮಾರ್ಗವನ್ನು ಹೊಂದಿರುವ ಆಹ್ವಾನವು Unix ನಲ್ಲಿ ಸರಿಯಾಗಿ ಕಂಪೈಲ್ ಮಾಡುವುದಿಲ್ಲ.
    ///
    ///
    /// ಈ ಮ್ಯಾಕ್ರೋ ಫೈಲ್‌ನ ವಿಷಯಗಳಾದ `&'static [u8; N]` ಪ್ರಕಾರದ ಅಭಿವ್ಯಕ್ತಿಯನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಈ ಕೆಳಗಿನ ವಿಷಯಗಳೊಂದಿಗೆ ಒಂದೇ ಡೈರೆಕ್ಟರಿಯಲ್ಲಿ ಎರಡು ಫೈಲ್‌ಗಳಿವೆ ಎಂದು ume ಹಿಸಿ:
    ///
    /// ಫೈಲ್ 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// ಫೈಲ್ 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs' ಅನ್ನು ಕಂಪೈಲ್ ಮಾಡುವುದು ಮತ್ತು ಪರಿಣಾಮವಾಗಿ ಬೈನರಿ ಚಾಲನೆ ಮಾಡುವುದರಿಂದ "adiós" ಅನ್ನು ಮುದ್ರಿಸುತ್ತದೆ.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ಪ್ರಸ್ತುತ ಮಾಡ್ಯೂಲ್ ಮಾರ್ಗವನ್ನು ಪ್ರತಿನಿಧಿಸುವ ಸ್ಟ್ರಿಂಗ್‌ಗೆ ವಿಸ್ತರಿಸುತ್ತದೆ.
    ///
    /// ಪ್ರಸ್ತುತ ಮಾಡ್ಯೂಲ್ ಮಾರ್ಗವನ್ನು crate root ಗೆ ಹಿಂತಿರುಗಿಸುವ ಮಾಡ್ಯೂಲ್‌ಗಳ ಕ್ರಮಾನುಗತವೆಂದು ಭಾವಿಸಬಹುದು.
    /// ಹಿಂದಿರುಗಿದ ಮಾರ್ಗದ ಮೊದಲ ಅಂಶವೆಂದರೆ ಪ್ರಸ್ತುತ ಸಂಕಲಿಸಲಾಗುತ್ತಿರುವ crate ನ ಹೆಸರು.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// ಕಂಪೈಲ್ ಸಮಯದಲ್ಲಿ ಸಂರಚನಾ ಧ್ವಜಗಳ ಬೂಲಿಯನ್ ಸಂಯೋಜನೆಯನ್ನು ಮೌಲ್ಯಮಾಪನ ಮಾಡುತ್ತದೆ.
    ///
    /// `#[cfg]` ಗುಣಲಕ್ಷಣದ ಜೊತೆಗೆ, ಸಂರಚನಾ ಧ್ವಜಗಳ ಬೂಲಿಯನ್ ಅಭಿವ್ಯಕ್ತಿ ಮೌಲ್ಯಮಾಪನವನ್ನು ಅನುಮತಿಸಲು ಈ ಮ್ಯಾಕ್ರೋವನ್ನು ಒದಗಿಸಲಾಗಿದೆ.
    /// ಇದು ಆಗಾಗ್ಗೆ ಕಡಿಮೆ ನಕಲಿ ಕೋಡ್‌ಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
    ///
    /// ಈ ಮ್ಯಾಕ್ರೋಗೆ ನೀಡಲಾದ ಸಿಂಟ್ಯಾಕ್ಸ್ [`cfg`] ಗುಣಲಕ್ಷಣದಂತೆಯೇ ಸಿಂಟ್ಯಾಕ್ಸ್ ಆಗಿದೆ.
    ///
    /// `cfg!`, `#[cfg]` ಗಿಂತ ಭಿನ್ನವಾಗಿ, ಯಾವುದೇ ಕೋಡ್ ಅನ್ನು ತೆಗೆದುಹಾಕುವುದಿಲ್ಲ ಮತ್ತು ನಿಜ ಅಥವಾ ತಪ್ಪು ಎಂದು ಮಾತ್ರ ಮೌಲ್ಯಮಾಪನ ಮಾಡುತ್ತದೆ.
    /// ಉದಾಹರಣೆಗೆ, `cfg!` ಮೌಲ್ಯಮಾಪನ ಮಾಡುತ್ತಿದ್ದರೂ, if/else ಅಭಿವ್ಯಕ್ತಿಯ ಎಲ್ಲಾ ಬ್ಲಾಕ್‌ಗಳು ಸ್ಥಿತಿಗೆ `cfg!` ಅನ್ನು ಬಳಸುವಾಗ ಮಾನ್ಯವಾಗಿರಬೇಕು.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// ಸಂದರ್ಭಕ್ಕೆ ಅನುಗುಣವಾಗಿ ಫೈಲ್ ಅನ್ನು ಅಭಿವ್ಯಕ್ತಿ ಅಥವಾ ಐಟಂ ಆಗಿ ಪಾರ್ಸ್ ಮಾಡುತ್ತದೆ.
    ///
    /// ಫೈಲ್ ಪ್ರಸ್ತುತ ಫೈಲ್‌ಗೆ ಸಂಬಂಧಿಸಿದೆ (ಮಾಡ್ಯೂಲ್‌ಗಳು ಹೇಗೆ ಕಂಡುಬರುತ್ತವೆ ಎಂಬುದರಂತೆಯೇ).ಒದಗಿಸಿದ ಮಾರ್ಗವನ್ನು ಕಂಪೈಲ್ ಸಮಯದಲ್ಲಿ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್-ನಿರ್ದಿಷ್ಟ ರೀತಿಯಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗುತ್ತದೆ.
    /// ಆದ್ದರಿಂದ, ಉದಾಹರಣೆಗೆ, Windows ಬ್ಯಾಕ್‌ಸ್ಲ್ಯಾಶ್‌ಗಳನ್ನು ಹೊಂದಿರುವ Windows ಮಾರ್ಗವನ್ನು ಹೊಂದಿರುವ ಆಹ್ವಾನವು Unix ನಲ್ಲಿ ಸರಿಯಾಗಿ ಕಂಪೈಲ್ ಮಾಡುವುದಿಲ್ಲ.
    ///
    /// ಈ ಮ್ಯಾಕ್ರೋವನ್ನು ಬಳಸುವುದು ಸಾಮಾನ್ಯವಾಗಿ ಕೆಟ್ಟ ಆಲೋಚನೆಯಾಗಿದೆ, ಏಕೆಂದರೆ ಫೈಲ್ ಅನ್ನು ಅಭಿವ್ಯಕ್ತಿಯಾಗಿ ಪಾರ್ಸ್ ಮಾಡಿದರೆ, ಅದನ್ನು ಸುತ್ತಮುತ್ತಲಿನ ಕೋಡ್‌ನಲ್ಲಿ ಆರೋಗ್ಯಕರವಾಗಿ ಇಡಲಾಗುವುದು.
    /// ಪ್ರಸ್ತುತ ಫೈಲ್‌ನಲ್ಲಿ ಒಂದೇ ಹೆಸರನ್ನು ಹೊಂದಿರುವ ಅಸ್ಥಿರ ಅಥವಾ ಕಾರ್ಯಗಳು ಇದ್ದಲ್ಲಿ ಫೈಲ್ ನಿರೀಕ್ಷಿಸಿದಕ್ಕಿಂತ ಭಿನ್ನವಾಗಿರುವ ಅಸ್ಥಿರ ಅಥವಾ ಕಾರ್ಯಗಳು ಇದಕ್ಕೆ ಕಾರಣವಾಗಬಹುದು.
    ///
    ///
    /// # Examples
    ///
    /// ಈ ಕೆಳಗಿನ ವಿಷಯಗಳೊಂದಿಗೆ ಒಂದೇ ಡೈರೆಕ್ಟರಿಯಲ್ಲಿ ಎರಡು ಫೈಲ್‌ಗಳಿವೆ ಎಂದು ume ಹಿಸಿ:
    ///
    /// ಫೈಲ್ 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// ಫೈಲ್ 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' ಅನ್ನು ಕಂಪೈಲ್ ಮಾಡುವುದು ಮತ್ತು ಪರಿಣಾಮವಾಗಿ ಬೈನರಿ ಚಾಲನೆ ಮಾಡುವುದರಿಂದ "🙈🙊🙉🙈🙊🙉" ಅನ್ನು ಮುದ್ರಿಸುತ್ತದೆ.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ರನ್ಟೈಮ್ನಲ್ಲಿ ಬೂಲಿಯನ್ ಅಭಿವ್ಯಕ್ತಿ `true` ಎಂದು ಪ್ರತಿಪಾದಿಸುತ್ತದೆ.
    ///
    /// ಒದಗಿಸಿದ ಅಭಿವ್ಯಕ್ತಿಯನ್ನು ರನ್ಟೈಮ್ನಲ್ಲಿ `true` ಗೆ ಮೌಲ್ಯಮಾಪನ ಮಾಡಲು ಸಾಧ್ಯವಾಗದಿದ್ದರೆ ಇದು [`panic!`] ಮ್ಯಾಕ್ರೋವನ್ನು ಆಹ್ವಾನಿಸುತ್ತದೆ.
    ///
    /// # Uses
    ///
    /// ಡೀಬಗ್ ಮತ್ತು ಬಿಡುಗಡೆ ಬಿಲ್ಡ್ ಎರಡರಲ್ಲೂ ಪ್ರತಿಪಾದನೆಗಳನ್ನು ಯಾವಾಗಲೂ ಪರಿಶೀಲಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ಅದನ್ನು ನಿಷ್ಕ್ರಿಯಗೊಳಿಸಲಾಗುವುದಿಲ್ಲ.
    /// ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಬಿಡುಗಡೆ ನಿರ್ಮಾಣಗಳಲ್ಲಿ ಸಕ್ರಿಯಗೊಳಿಸದ ಪ್ರತಿಪಾದನೆಗಳಿಗಾಗಿ [`debug_assert!`] ನೋಡಿ.
    ///
    /// ರನ್-ಟೈಮ್ ಅಸ್ಥಿರಗಳನ್ನು ಜಾರಿಗೊಳಿಸಲು ಅಸುರಕ್ಷಿತ ಕೋಡ್ `assert!` ಅನ್ನು ಅವಲಂಬಿಸಬಹುದು, ಅದು ಉಲ್ಲಂಘನೆಯಾದರೆ ಅಸುರಕ್ಷಿತತೆಗೆ ಕಾರಣವಾಗಬಹುದು.
    ///
    /// `assert!` ನ ಇತರ ಬಳಕೆ-ಪ್ರಕರಣಗಳು ಸುರಕ್ಷಿತ ಕೋಡ್‌ನಲ್ಲಿ ರನ್-ಟೈಮ್ ಅಸ್ಥಿರಗಳನ್ನು ಪರೀಕ್ಷಿಸುವುದು ಮತ್ತು ಜಾರಿಗೊಳಿಸುವುದು (ಇದರ ಉಲ್ಲಂಘನೆಯು ಅಸುರಕ್ಷಿತತೆಗೆ ಕಾರಣವಾಗುವುದಿಲ್ಲ).
    ///
    ///
    /// # ಕಸ್ಟಮ್ ಸಂದೇಶಗಳು
    ///
    /// ಈ ಮ್ಯಾಕ್ರೋ ಎರಡನೇ ರೂಪವನ್ನು ಹೊಂದಿದೆ, ಅಲ್ಲಿ ಕಸ್ಟಮ್ panic ಸಂದೇಶವನ್ನು ಫಾರ್ಮ್ಯಾಟಿಂಗ್ಗಾಗಿ ಆರ್ಗ್ಯುಮೆಂಟ್‌ಗಳೊಂದಿಗೆ ಅಥವಾ ಇಲ್ಲದೆ ಒದಗಿಸಬಹುದು.
    /// ಈ ಫಾರ್ಮ್‌ಗಾಗಿ ಸಿಂಟ್ಯಾಕ್ಸ್‌ಗಾಗಿ [`std::fmt`] ನೋಡಿ.
    /// ಪ್ರತಿಪಾದನೆಯು ವಿಫಲವಾದರೆ ಮಾತ್ರ ಸ್ವರೂಪ ವಾದಗಳಾಗಿ ಬಳಸಲಾಗುವ ಅಭಿವ್ಯಕ್ತಿಗಳನ್ನು ಮೌಲ್ಯಮಾಪನ ಮಾಡಲಾಗುತ್ತದೆ.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // ಈ ಪ್ರತಿಪಾದನೆಗಳಿಗಾಗಿ panic ಸಂದೇಶವು ನೀಡಿದ ಅಭಿವ್ಯಕ್ತಿಯ ಸ್ಟ್ರೈಫೈಡ್ ಮೌಲ್ಯವಾಗಿದೆ.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // ಬಹಳ ಸರಳವಾದ ಕಾರ್ಯ
    ///
    /// assert!(some_computation());
    ///
    /// // ಕಸ್ಟಮ್ ಸಂದೇಶದೊಂದಿಗೆ ಪ್ರತಿಪಾದಿಸಿ
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// ಇನ್ಲೈನ್ ಜೋಡಣೆ.
    ///
    /// ಬಳಕೆಗಾಗಿ [unstable book] ಓದಿ.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// ಎಲ್ಎಲ್ವಿಎಂ ಶೈಲಿಯ ಇನ್ಲೈನ್ ಜೋಡಣೆ.
    ///
    /// ಬಳಕೆಗಾಗಿ [unstable book] ಓದಿ.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// ಮಾಡ್ಯೂಲ್-ಮಟ್ಟದ ಇನ್ಲೈನ್ ಜೋಡಣೆ.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// ಮುದ್ರಣಗಳು tokens ಅನ್ನು ಪ್ರಮಾಣಿತ .ಟ್‌ಪುಟ್‌ಗೆ ರವಾನಿಸಿದವು.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// ಇತರ ಮ್ಯಾಕ್ರೋಗಳನ್ನು ಡೀಬಗ್ ಮಾಡಲು ಬಳಸುವ ಟ್ರೇಸಿಂಗ್ ಕಾರ್ಯವನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುತ್ತದೆ ಅಥವಾ ನಿಷ್ಕ್ರಿಯಗೊಳಿಸುತ್ತದೆ.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// ವ್ಯುತ್ಪನ್ನ ಮ್ಯಾಕ್ರೋಗಳನ್ನು ಅನ್ವಯಿಸಲು ಬಳಸುವ ಗುಣಲಕ್ಷಣ ಮ್ಯಾಕ್ರೋ.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// ಯುನಿಟ್ ಟೆಸ್ಟ್ ಆಗಿ ಪರಿವರ್ತಿಸಲು ಫಂಕ್ಷನ್ಗೆ ಗುಣಲಕ್ಷಣ ಮ್ಯಾಕ್ರೋ ಅನ್ವಯಿಸಲಾಗಿದೆ.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// ಬೆಂಚ್‌ಮಾರ್ಕ್ ಪರೀಕ್ಷೆಯಾಗಿ ಪರಿವರ್ತಿಸಲು ಗುಣಲಕ್ಷಣ ಮ್ಯಾಕ್ರೋವನ್ನು ಒಂದು ಕಾರ್ಯಕ್ಕೆ ಅನ್ವಯಿಸಲಾಗಿದೆ.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` ಮತ್ತು `#[bench]` ಮ್ಯಾಕ್ರೋಗಳ ಅನುಷ್ಠಾನದ ವಿವರ.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// ಸ್ಥೂಲಕ್ಕೆ ಜಾಗತಿಕ ಹಂಚಿಕೆಯಾಗಿ ನೋಂದಾಯಿಸಲು ಗುಣಲಕ್ಷಣ ಮ್ಯಾಕ್ರೋ ಅನ್ವಯಿಸಲಾಗಿದೆ.
    ///
    /// [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html) ಸಹ ನೋಡಿ.
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// ಹಾದುಹೋದ ಮಾರ್ಗವನ್ನು ಪ್ರವೇಶಿಸಬಹುದಾದರೆ ಅದನ್ನು ಅನ್ವಯಿಸುವ ಐಟಂ ಅನ್ನು ಇಡುತ್ತದೆ ಮತ್ತು ಅದನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// ಇದು ಅನ್ವಯಿಸಲಾದ ಕೋಡ್ ತುಣುಕಿನಲ್ಲಿರುವ ಎಲ್ಲಾ `#[cfg]` ಮತ್ತು `#[cfg_attr]` ಗುಣಲಕ್ಷಣಗಳನ್ನು ವಿಸ್ತರಿಸುತ್ತದೆ.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` ಕಂಪೈಲರ್ನ ಅಸ್ಥಿರ ಅನುಷ್ಠಾನ ವಿವರ, ಬಳಸಬೇಡಿ.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` ಕಂಪೈಲರ್ನ ಅಸ್ಥಿರ ಅನುಷ್ಠಾನ ವಿವರ, ಬಳಸಬೇಡಿ.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}