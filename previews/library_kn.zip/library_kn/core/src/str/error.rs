//! utf8 ದೋಷ ಪ್ರಕಾರವನ್ನು ವ್ಯಾಖ್ಯಾನಿಸುತ್ತದೆ.

use crate::fmt;

/// [`u8`] ನ ಅನುಕ್ರಮವನ್ನು ಸ್ಟ್ರಿಂಗ್ ಎಂದು ವ್ಯಾಖ್ಯಾನಿಸಲು ಪ್ರಯತ್ನಿಸುವಾಗ ಉಂಟಾಗುವ ದೋಷಗಳು.
///
/// ಅಂತೆಯೇ, [`ಸ್ಟ್ರಿಂಗ್`] ಮತ್ತು [`&ಸ್ಟ್ರ`] ಗಳ ಕಾರ್ಯಗಳು ಮತ್ತು ವಿಧಾನಗಳ `from_utf8` ಕುಟುಂಬವು ಈ ದೋಷವನ್ನು ಬಳಸಿಕೊಳ್ಳುತ್ತದೆ, ಉದಾಹರಣೆಗೆ.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// ರಾಶಿ ಮೆಮೊರಿಯನ್ನು ನಿಯೋಜಿಸದೆ `String::from_utf8_lossy` ಗೆ ಹೋಲುವ ಕ್ರಿಯಾತ್ಮಕತೆಯನ್ನು ರಚಿಸಲು ಈ ದೋಷ ಪ್ರಕಾರದ ವಿಧಾನಗಳನ್ನು ಬಳಸಬಹುದು:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// ಮಾನ್ಯ UTF-8 ಅನ್ನು ಪರಿಶೀಲಿಸಿದ ನಿರ್ದಿಷ್ಟ ಸ್ಟ್ರಿಂಗ್‌ನಲ್ಲಿ ಸೂಚಿಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಇದು `from_utf8(&input[..index])` `Ok(_)` ಅನ್ನು ಹಿಂದಿರುಗಿಸುವ ಗರಿಷ್ಠ ಸೂಚ್ಯಂಕವಾಗಿದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::str;
    ///
    /// // vector ನಲ್ಲಿ ಕೆಲವು ಅಮಾನ್ಯ ಬೈಟ್‌ಗಳು
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 Utf8 ದೋಷವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // ಎರಡನೇ ಬೈಟ್ ಇಲ್ಲಿ ಅಮಾನ್ಯವಾಗಿದೆ
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// ವೈಫಲ್ಯದ ಬಗ್ಗೆ ಹೆಚ್ಚಿನ ಮಾಹಿತಿಯನ್ನು ಒದಗಿಸುತ್ತದೆ:
    ///
    /// * `None`: ಇನ್ಪುಟ್ನ ಅಂತ್ಯವು ಅನಿರೀಕ್ಷಿತವಾಗಿ ತಲುಪಿದೆ.
    ///   `self.valid_up_to()` ಇನ್ಪುಟ್ನ ಅಂತ್ಯದಿಂದ 1 ರಿಂದ 3 ಬೈಟ್ಗಳು.
    ///   ಒಂದು ಬೈಟ್ ಸ್ಟ್ರೀಮ್ (ಫೈಲ್ ಅಥವಾ ನೆಟ್‌ವರ್ಕ್ ಸಾಕೆಟ್ ನಂತಹ) ಹೆಚ್ಚಳವಾಗಿ ಡಿಕೋಡ್ ಆಗುತ್ತಿದ್ದರೆ, ಇದು ಮಾನ್ಯ `char` ಆಗಿರಬಹುದು, ಇದರ UTF-8 ಬೈಟ್ ಅನುಕ್ರಮವು ಅನೇಕ ಭಾಗಗಳನ್ನು ವ್ಯಾಪಿಸಿದೆ.
    ///
    ///
    /// * `Some(len)`: ಅನಿರೀಕ್ಷಿತ ಬೈಟ್ ಎದುರಾಗಿದೆ.
    ///   `valid_up_to()` ನೀಡಿದ ಸೂಚ್ಯಂಕದಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುವ ಅಮಾನ್ಯ ಬೈಟ್ ಅನುಕ್ರಮವು ಒದಗಿಸಲಾದ ಉದ್ದವಾಗಿದೆ.
    ///   ನಷ್ಟದ ಡಿಕೋಡಿಂಗ್ ಸಂದರ್ಭದಲ್ಲಿ ಆ ಅನುಕ್ರಮದ ನಂತರ ([`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] ಸೇರಿಸಿದ ನಂತರ) ಡಿಕೋಡಿಂಗ್ ಪುನರಾರಂಭಗೊಳ್ಳಬೇಕು.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// [`from_str`] ಅನ್ನು ಬಳಸಿಕೊಂಡು `bool` ಅನ್ನು ಪಾರ್ಸ್ ಮಾಡುವಾಗ ದೋಷ ಮರಳಿದೆ
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}