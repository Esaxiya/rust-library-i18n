//! ಬೈಟ್‌ಗಳ ಸ್ಲೈಸ್‌ನಿಂದ `str` ಅನ್ನು ರಚಿಸುವ ಮಾರ್ಗಗಳು.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// ಬೈಟ್‌ಗಳ ಸ್ಲೈಸ್ ಅನ್ನು ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
///
/// ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ([`&str`]) ಅನ್ನು ಬೈಟ್‌ಗಳು ([`u8`]) ನಿಂದ ಮಾಡಲಾಗಿದೆ, ಮತ್ತು ಬೈಟ್ ಸ್ಲೈಸ್ ([`&[u8]`][byteslice]) ಅನ್ನು ಬೈಟ್‌ಗಳಿಂದ ಮಾಡಲಾಗಿದೆ, ಆದ್ದರಿಂದ ಈ ಕಾರ್ಯವು ಎರಡರ ನಡುವೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
/// ಎಲ್ಲಾ ಬೈಟ್ ಚೂರುಗಳು ಮಾನ್ಯ ಸ್ಟ್ರಿಂಗ್ ಚೂರುಗಳಲ್ಲ, ಆದಾಗ್ಯೂ: [`&str`] ಗೆ ಅದು ಮಾನ್ಯ UTF-8 ಎಂದು ಅಗತ್ಯವಿದೆ.
/// `from_utf8()` ಬೈಟ್‌ಗಳು ಮಾನ್ಯ UTF-8 ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ಪರಿಶೀಲಿಸುತ್ತದೆ, ತದನಂತರ ಪರಿವರ್ತನೆ ಮಾಡುತ್ತದೆ.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// ಬೈಟ್ ಸ್ಲೈಸ್ ಮಾನ್ಯ UTF-8 ಎಂದು ನಿಮಗೆ ಖಚಿತವಾಗಿದ್ದರೆ, ಮತ್ತು ಸಿಂಧುತ್ವ ಪರಿಶೀಲನೆಯ ಓವರ್ಹೆಡ್ ಅನ್ನು ನೀವು ಅನುಭವಿಸಲು ಬಯಸುವುದಿಲ್ಲವಾದರೆ, ಈ ಕಾರ್ಯದ ಅಸುರಕ್ಷಿತ ಆವೃತ್ತಿಯಿದೆ, [`from_utf8_unchecked`], ಅದೇ ನಡವಳಿಕೆಯನ್ನು ಹೊಂದಿದೆ ಆದರೆ ಚೆಕ್ ಅನ್ನು ಬಿಟ್ಟುಬಿಡುತ್ತದೆ.
///
///
/// ನಿಮಗೆ `&str` ಬದಲಿಗೆ `String` ಅಗತ್ಯವಿದ್ದರೆ, [`String::from_utf8`][string] ಅನ್ನು ಪರಿಗಣಿಸಿ.
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// ಏಕೆಂದರೆ ನೀವು `[u8; N]` ಅನ್ನು ಸ್ಟ್ಯಾಕ್-ನಿಯೋಜಿಸಬಹುದು, ಮತ್ತು ನೀವು ಅದರ [`&[u8]`][byteslice] ಅನ್ನು ತೆಗೆದುಕೊಳ್ಳಬಹುದು, ಈ ಕಾರ್ಯವು ಸ್ಟಾಕ್-ನಿಯೋಜಿತ ಸ್ಟ್ರಿಂಗ್ ಹೊಂದಲು ಒಂದು ಮಾರ್ಗವಾಗಿದೆ.ಕೆಳಗಿನ ಉದಾಹರಣೆಗಳ ವಿಭಾಗದಲ್ಲಿ ಇದಕ್ಕೆ ಉದಾಹರಣೆ ಇದೆ.
///
/// [byteslice]: slice
///
/// # Errors
///
/// ಒದಗಿಸಿದ ಸ್ಲೈಸ್ ಏಕೆ UTF-8 ಅಲ್ಲ ಎಂಬ ವಿವರಣೆಯೊಂದಿಗೆ ಸ್ಲೈಸ್ UTF-8 ಅಲ್ಲದಿದ್ದರೆ `Err` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
///
/// # Examples
///
/// ಮೂಲ ಬಳಕೆ:
///
/// ```
/// use std::str;
///
/// // ಕೆಲವು ಬೈಟ್‌ಗಳು, vector ನಲ್ಲಿ
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // ಈ ಬೈಟ್‌ಗಳು ಮಾನ್ಯವಾಗಿವೆ ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ, ಆದ್ದರಿಂದ `unwrap()` ಅನ್ನು ಬಳಸಿ.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// ತಪ್ಪಾದ ಬೈಟ್‌ಗಳು:
///
/// ```
/// use std::str;
///
/// // vector ನಲ್ಲಿ ಕೆಲವು ಅಮಾನ್ಯ ಬೈಟ್‌ಗಳು
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// ಹಿಂತಿರುಗಿಸಬಹುದಾದ ದೋಷಗಳ ಬಗೆಗಿನ ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ [`Utf8Error`] ಗಾಗಿ ಡಾಕ್ಸ್ ನೋಡಿ.
///
/// ಎ "stack allocated string":
///
/// ```
/// use std::str;
///
/// // ಕೆಲವು ಬೈಟ್‌ಗಳು, ಸ್ಟಾಕ್-ನಿಯೋಜಿತ ಶ್ರೇಣಿಯಲ್ಲಿ
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // ಈ ಬೈಟ್‌ಗಳು ಮಾನ್ಯವಾಗಿವೆ ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ, ಆದ್ದರಿಂದ `unwrap()` ಅನ್ನು ಬಳಸಿ.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // ಸುರಕ್ಷತೆ: ಕೇವಲ valid ರ್ಜಿತಗೊಳಿಸುವಿಕೆ.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// ರೂಪಾಂತರಗೊಳ್ಳುವ ಬೈಟ್‌ಗಳ ಸ್ಲೈಸ್ ಅನ್ನು ರೂಪಾಂತರಿತ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
///
/// # Examples
///
/// ಮೂಲ ಬಳಕೆ:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" ರೂಪಾಂತರಿತ vector ಆಗಿ
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // ಈ ಬೈಟ್‌ಗಳು ಮಾನ್ಯವೆಂದು ನಮಗೆ ತಿಳಿದಿರುವಂತೆ, ನಾವು `unwrap()` ಅನ್ನು ಬಳಸಬಹುದು
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// ತಪ್ಪಾದ ಬೈಟ್‌ಗಳು:
///
/// ```
/// use std::str;
///
/// // ರೂಪಾಂತರಿತ vector ನಲ್ಲಿ ಕೆಲವು ಅಮಾನ್ಯ ಬೈಟ್‌ಗಳು
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// ಹಿಂತಿರುಗಿಸಬಹುದಾದ ದೋಷಗಳ ಬಗೆಗಿನ ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ [`Utf8Error`] ಗಾಗಿ ಡಾಕ್ಸ್ ನೋಡಿ.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // ಸುರಕ್ಷತೆ: ಕೇವಲ valid ರ್ಜಿತಗೊಳಿಸುವಿಕೆ.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// ಸ್ಟ್ರಿಂಗ್ ಮಾನ್ಯ UTF-8 ಅನ್ನು ಹೊಂದಿದೆಯೆ ಎಂದು ಪರಿಶೀಲಿಸದೆ ಬೈಟ್‌ಗಳ ಸ್ಲೈಸ್ ಅನ್ನು ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
///
/// ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ ಸುರಕ್ಷಿತ ಆವೃತ್ತಿ, [`from_utf8`] ನೋಡಿ.
///
/// # Safety
///
/// ಈ ಕಾರ್ಯವು ಅಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ಅದು ರವಾನಿಸಿದ ಬೈಟ್‌ಗಳು ಮಾನ್ಯ UTF-8 ಎಂದು ಪರಿಶೀಲಿಸುವುದಿಲ್ಲ.
/// ಈ ನಿರ್ಬಂಧವನ್ನು ಉಲ್ಲಂಘಿಸಿದರೆ, ವಿವರಿಸಲಾಗದ ನಡವಳಿಕೆಯ ಫಲಿತಾಂಶಗಳು, ಉಳಿದ Rust [`&str`] ಗಳು ಮಾನ್ಯ UTF-8 ಎಂದು umes ಹಿಸುತ್ತದೆ.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// ಮೂಲ ಬಳಕೆ:
///
/// ```
/// use std::str;
///
/// // ಕೆಲವು ಬೈಟ್‌ಗಳು, vector ನಲ್ಲಿ
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `v` ಬೈಟ್‌ಗಳು ಮಾನ್ಯ UTF-8 ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು.
    // ಒಂದೇ ವಿನ್ಯಾಸವನ್ನು ಹೊಂದಿರುವ `&str` ಮತ್ತು `&[u8]` ಅನ್ನು ಸಹ ಅವಲಂಬಿಸಿದೆ.
    unsafe { mem::transmute(v) }
}

/// ಸ್ಟ್ರಿಂಗ್ ಮಾನ್ಯ UTF-8 ಅನ್ನು ಹೊಂದಿದೆಯೆ ಎಂದು ಪರಿಶೀಲಿಸದೆ ಬೈಟ್‌ಗಳ ಸ್ಲೈಸ್ ಅನ್ನು ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ;ರೂಪಾಂತರಿತ ಆವೃತ್ತಿ.
///
///
/// ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ ಬದಲಾಯಿಸಲಾಗದ ಆವೃತ್ತಿ, [`from_utf8_unchecked()`] ನೋಡಿ.
///
/// # Examples
///
/// ಮೂಲ ಬಳಕೆ:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು ಬೈಟ್‌ಗಳು `v` ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು
    // ಮಾನ್ಯ UTF-8, ಆದ್ದರಿಂದ `*mut str` ಗೆ ಎರಕಹೊಯ್ದವು ಸುರಕ್ಷಿತವಾಗಿದೆ.
    // ಅಲ್ಲದೆ, ಪಾಯಿಂಟರ್ ಡಿಫರೆನ್ಸ್ ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ಆ ಪಾಯಿಂಟರ್ ಒಂದು ಉಲ್ಲೇಖದಿಂದ ಬಂದಿದ್ದು ಅದು ಬರಹಗಳಿಗೆ ಮಾನ್ಯವಾಗಿರುತ್ತದೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}