use crate::char;
use crate::fmt::{self, Write};
use crate::mem;

use super::from_utf8_unchecked;
use super::validations::utf8_char_width;

/// ನಷ್ಟದ UTF-8 ಸ್ಟ್ರಿಂಗ್.
#[unstable(feature = "str_internals", issue = "none")]
pub struct Utf8Lossy {
    bytes: [u8],
}

impl Utf8Lossy {
    pub fn from_str(s: &str) -> &Utf8Lossy {
        Utf8Lossy::from_bytes(s.as_bytes())
    }

    pub fn from_bytes(bytes: &[u8]) -> &Utf8Lossy {
        // ಸುರಕ್ಷತೆ: ಎರಡೂ ಒಂದೇ ಮೆಮೊರಿ ವಿನ್ಯಾಸವನ್ನು ಬಳಸುತ್ತವೆ, ಮತ್ತು UTF-8 ಸರಿಯಾಗಿರುವುದು ಅಗತ್ಯವಿಲ್ಲ.
        unsafe { mem::transmute(bytes) }
    }

    pub fn chunks(&self) -> Utf8LossyChunksIter<'_> {
        Utf8LossyChunksIter { source: &self.bytes }
    }
}

/// ನಷ್ಟದ UTF-8 ಸ್ಟ್ರಿಂಗ್ ಮೇಲೆ ಇಟರೇಟರ್
#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_debug_implementations)]
pub struct Utf8LossyChunksIter<'a> {
    source: &'a [u8],
}

#[unstable(feature = "str_internals", issue = "none")]
#[derive(PartialEq, Eq, Debug)]
pub struct Utf8LossyChunk<'a> {
    /// ಮಾನ್ಯ ಅಕ್ಷರಗಳ ಅನುಕ್ರಮ.
    /// ಮುರಿದ UTF-8 ಅಕ್ಷರಗಳ ನಡುವೆ ಖಾಲಿಯಾಗಿರಬಹುದು.
    pub valid: &'a str,
    /// ಏಕ ಮುರಿದ ಚಾರ್, ಯಾವುದೂ ಇಲ್ಲದಿದ್ದರೆ ಖಾಲಿ.
    /// ಖಾಲಿ iff ಇಟರೇಟರ್ ಐಟಂ ಕೊನೆಯದು.
    pub broken: &'a [u8],
}

impl<'a> Iterator for Utf8LossyChunksIter<'a> {
    type Item = Utf8LossyChunk<'a>;

    fn next(&mut self) -> Option<Utf8LossyChunk<'a>> {
        if self.source.is_empty() {
            return None;
        }

        const TAG_CONT_U8: u8 = 128;
        fn safe_get(xs: &[u8], i: usize) -> u8 {
            *xs.get(i).unwrap_or(&0)
        }

        let mut i = 0;
        while i < self.source.len() {
            let i_ = i;

            // ಸುರಕ್ಷತೆ: `i` `0` ನಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ, `self.source.len()` ಗಿಂತ ಕಡಿಮೆಯಿದೆ, ಮತ್ತು
            // ಮಾತ್ರ ಹೆಚ್ಚಾಗುತ್ತದೆ, ಆದ್ದರಿಂದ `0 <= i < self.source.len()`.
            let byte = unsafe { *self.source.get_unchecked(i) };
            i += 1;

            if byte < 128 {
            } else {
                let w = utf8_char_width(byte);

                macro_rules! error {
                    () => {{
                        // ಸುರಕ್ಷತೆ: ಮೂಲವು ಮಾನ್ಯ UTF-8 ಎಂದು ನಾವು `i` ವರೆಗೆ ಪರಿಶೀಲಿಸಿದ್ದೇವೆ.
                        unsafe {
                            let r = Utf8LossyChunk {
                                valid: from_utf8_unchecked(&self.source[0..i_]),
                                broken: &self.source[i_..i],
                            };
                            self.source = &self.source[i..];
                            return Some(r);
                        }
                    }};
                }

                match w {
                    2 => {
                        if safe_get(self.source, i) & 192 != TAG_CONT_U8 {
                            error!();
                        }
                        i += 1;
                    }
                    3 => {
                        match (byte, safe_get(self.source, i)) {
                            (0xE0, 0xA0..=0xBF) => (),
                            (0xE1..=0xEC, 0x80..=0xBF) => (),
                            (0xED, 0x80..=0x9F) => (),
                            (0xEE..=0xEF, 0x80..=0xBF) => (),
                            _ => {
                                error!();
                            }
                        }
                        i += 1;
                        if safe_get(self.source, i) & 192 != TAG_CONT_U8 {
                            error!();
                        }
                        i += 1;
                    }
                    4 => {
                        match (byte, safe_get(self.source, i)) {
                            (0xF0, 0x90..=0xBF) => (),
                            (0xF1..=0xF3, 0x80..=0xBF) => (),
                            (0xF4, 0x80..=0x8F) => (),
                            _ => {
                                error!();
                            }
                        }
                        i += 1;
                        if safe_get(self.source, i) & 192 != TAG_CONT_U8 {
                            error!();
                        }
                        i += 1;
                        if safe_get(self.source, i) & 192 != TAG_CONT_U8 {
                            error!();
                        }
                        i += 1;
                    }
                    _ => {
                        error!();
                    }
                }
            }
        }

        let r = Utf8LossyChunk {
            // ಸುರಕ್ಷತೆ: ಸಂಪೂರ್ಣ ಮೂಲವು ಮಾನ್ಯ UTF-8 ಎಂದು ನಾವು ಪರಿಶೀಲಿಸಿದ್ದೇವೆ.
            valid: unsafe { from_utf8_unchecked(self.source) },
            broken: &[],
        };
        self.source = &[];
        Some(r)
    }
}

impl fmt::Display for Utf8Lossy {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // ನಾವು ಖಾಲಿ ಸ್ಟ್ರಿಂಗ್ ಆಗಿದ್ದರೆ ನಮ್ಮ ಪುನರಾವರ್ತಕವು ನಿಜವಾಗಿ ಏನನ್ನೂ ನೀಡುವುದಿಲ್ಲ, ಆದ್ದರಿಂದ ಫಾರ್ಮ್ಯಾಟಿಂಗ್ ಅನ್ನು ಹಸ್ತಚಾಲಿತವಾಗಿ ನಿರ್ವಹಿಸಿ
        //
        if self.bytes.is_empty() {
            return "".fmt(f);
        }

        for Utf8LossyChunk { valid, broken } in self.chunks() {
            // ನಾವು ಸಂಪೂರ್ಣ ಭಾಗವನ್ನು ಮಾನ್ಯ ಸ್ಟ್ರಿಂಗ್ ಆಗಿ ಯಶಸ್ವಿಯಾಗಿ ಡಿಕೋಡ್ ಮಾಡಿದರೆ, ನಾವು ಸ್ಟ್ರಿಂಗ್‌ನ ನೇರ ಫಾರ್ಮ್ಯಾಟಿಂಗ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸಬಹುದು, ಅದು ಸಾಧ್ಯವಾದರೆ ವಿವಿಧ ಫಾರ್ಮ್ಯಾಟಿಂಗ್ ಧ್ವಜಗಳನ್ನು ಸಹ ಗೌರವಿಸುತ್ತದೆ.
            //
            //
            if valid.len() == self.bytes.len() {
                assert!(broken.is_empty());
                return valid.fmt(f);
            }

            f.write_str(valid)?;
            if !broken.is_empty() {
                f.write_char(char::REPLACEMENT_CHARACTER)?;
            }
        }
        Ok(())
    }
}

impl fmt::Debug for Utf8Lossy {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_char('"')?;

        for Utf8LossyChunk { valid, broken } in self.chunks() {
            // ಮಾನ್ಯ ಭಾಗ.
            // ಇಲ್ಲಿ ನಾವು UTF-8 ಅನ್ನು ಮತ್ತೆ ಭಾಗಶಃ ಪಾರ್ಸ್ ಮಾಡುತ್ತೇವೆ ಅದು ಸಬ್‌ಪ್ಟಿಮಲ್ ಆಗಿದೆ.
            {
                let mut from = 0;
                for (i, c) in valid.char_indices() {
                    let esc = c.escape_debug();
                    // ಚಾರ್ ತಪ್ಪಿಸಿಕೊಳ್ಳುವ ಅಗತ್ಯವಿದ್ದರೆ, ಇಲ್ಲಿಯವರೆಗೆ ಬ್ಯಾಕ್‌ಲಾಗ್ ಅನ್ನು ಫ್ಲಶ್ ಮಾಡಿ ಮತ್ತು ಬರೆಯಿರಿ, ಇಲ್ಲದಿದ್ದರೆ ಬಿಟ್ಟುಬಿಡಿ
                    if esc.len() != 1 {
                        f.write_str(&valid[from..i])?;
                        for c in esc {
                            f.write_char(c)?;
                        }
                        from = i + c.len_utf8();
                    }
                }
                f.write_str(&valid[from..])?;
            }

            // ಹೆಕ್ಸ್ ಎಸ್ಕೇಪ್ ಆಗಿ ಸ್ಟ್ರಿಂಗ್ನ ಮುರಿದ ಭಾಗಗಳು.
            for &b in broken {
                write!(f, "\\x{:02x}", b)?;
            }
        }

        f.write_char('"')
    }
}