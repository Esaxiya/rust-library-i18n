//! UTF-8 ation ರ್ಜಿತಗೊಳಿಸುವಿಕೆಗೆ ಸಂಬಂಧಿಸಿದ ಕಾರ್ಯಾಚರಣೆಗಳು.

use crate::mem;

use super::Utf8Error;

/// ಮೊದಲ ಬೈಟ್‌ಗಾಗಿ ಆರಂಭಿಕ ಕೋಡ್‌ಪಾಯಿಂಟ್ ಸಂಚಯಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
/// ಮೊದಲ ಬೈಟ್ ವಿಶೇಷವಾಗಿದೆ, ಅಗಲ 2 ಕ್ಕೆ ಕೆಳಗಿನ 5 ಬಿಟ್‌ಗಳು, ಅಗಲ 3 ಕ್ಕೆ 4 ಬಿಟ್‌ಗಳು ಮತ್ತು ಅಗಲ 4 ಕ್ಕೆ 3 ಬಿಟ್‌ಗಳನ್ನು ಮಾತ್ರ ಬಯಸುತ್ತವೆ.
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// ಮುಂದುವರಿಕೆ ಬೈಟ್ `byte` ನೊಂದಿಗೆ ನವೀಕರಿಸಿದ `ch` ನ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// ಬೈಟ್ UTF-8 ಮುಂದುವರಿಕೆ ಬೈಟ್ ಆಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ (ಅಂದರೆ, `10` ಬಿಟ್‌ಗಳೊಂದಿಗೆ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ).
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// ಬೈಟ್ ಪುನರಾವರ್ತಕದಿಂದ ಮುಂದಿನ ಕೋಡ್ ಪಾಯಿಂಟ್ ಅನ್ನು ಓದುತ್ತದೆ (ಯುಟಿಎಫ್-8 ತರಹದ ಎನ್ಕೋಡಿಂಗ್ ಅನ್ನು uming ಹಿಸಿ).
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // ಡಿಕೋಡ್ UTF-8
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // ಮಲ್ಟಿಬೈಟ್ ಪ್ರಕರಣವು ಬೈಟ್ ಸಂಯೋಜನೆಯಿಂದ ಡಿಕೋಡ್ ಅನ್ನು ಅನುಸರಿಸುತ್ತದೆ: [[[x y] z] w]
    //
    // NOTE: ಕಾರ್ಯಕ್ಷಮತೆ ಇಲ್ಲಿ ನಿಖರವಾದ ಸೂತ್ರೀಕರಣಕ್ಕೆ ಸೂಕ್ಷ್ಮವಾಗಿರುತ್ತದೆ
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] w] ಪ್ರಕರಣ
        // 0xE0 ನಲ್ಲಿ 5 ನೇ ಬಿಟ್ .. 0xEF ಯಾವಾಗಲೂ ಸ್ಪಷ್ಟವಾಗಿರುತ್ತದೆ, ಆದ್ದರಿಂದ `init` ಇನ್ನೂ ಮಾನ್ಯವಾಗಿರುತ್ತದೆ
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] ಕೇಸ್ `init` ನ ಕಡಿಮೆ 3 ಬಿಟ್‌ಗಳನ್ನು ಮಾತ್ರ ಬಳಸಿ
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// ಬೈಟ್ ಪುನರಾವರ್ತಕದಿಂದ ಕೊನೆಯ ಕೋಡ್ ಪಾಯಿಂಟ್ ಅನ್ನು ಓದುತ್ತದೆ (ಯುಟಿಎಫ್-8 ತರಹದ ಎನ್ಕೋಡಿಂಗ್ ಅನ್ನು uming ಹಿಸಿ).
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // ಡಿಕೋಡ್ UTF-8
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // ಮಲ್ಟಿಬೈಟ್ ಪ್ರಕರಣವು ಬೈಟ್ ಸಂಯೋಜನೆಯಿಂದ ಡಿಕೋಡ್ ಅನ್ನು ಅನುಸರಿಸುತ್ತದೆ: [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// u64 ಅನ್ನು ಬಳಕೆಗೆ ಹೊಂದಿಸಲು ಮೊಟಕುಗೊಳಿಸುವಿಕೆಯನ್ನು ಬಳಸಿ
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// `x` ಪದದಲ್ಲಿನ ಯಾವುದೇ ಬೈಟ್ ನಾನಾಸ್ಕಿ (>=128) ಆಗಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// ಇದು ಮಾನ್ಯ UTF-8 ಅನುಕ್ರಮ ಎಂದು `v` ಪರಿಶೀಲಿಸುತ್ತದೆ, ಆ ಸಂದರ್ಭದಲ್ಲಿ `Ok(())` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಥವಾ ಅದು ಅಮಾನ್ಯವಾಗಿದ್ದರೆ, `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // ನಮಗೆ ಡೇಟಾ ಅಗತ್ಯವಿದೆ, ಆದರೆ ಯಾವುದೂ ಇರಲಿಲ್ಲ: ದೋಷ!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // 2-ಬೈಟ್ ಎನ್‌ಕೋಡಿಂಗ್ ಕೋಡ್‌ಪಾಯಿಂಟ್‌ಗಳಿಗೆ\u {0080} ರಿಂದ\u {07ff} ಮೊದಲ C2 80 ಕೊನೆಯ ಡಿಎಫ್ ಬಿಎಫ್
            // 3-ಬೈಟ್ ಎನ್‌ಕೋಡಿಂಗ್ ಕೋಡ್‌ಪಾಯಿಂಟ್‌ಗಳಿಗೆ\u {0800} ರಿಂದ\u {ffff} ಮೊದಲ E0 A0 80 ಕೊನೆಯ ಇಎಫ್ ಬಿಎಫ್ ಬಿಎಫ್ ಬಾಡಿಗೆ ಕೋಡ್ ಪಾಯಿಂಟ್‌ಗಳನ್ನು ಹೊರತುಪಡಿಸಿ\u {d800} ರಿಂದ\u {dfff} ED A0 80 ರಿಂದ ED BF BF
            // 4-ಬೈಟ್ ಎನ್‌ಕೋಡಿಂಗ್ ಕೋಡ್‌ಪಾಯಿಂಟ್‌ಗಳಿಗೆ\u {1000} 0 ರಿಂದ\u {10ff} ff ಮೊದಲ F0 90 80 80 ಕೊನೆಯ F4 8F BF BF
            //
            // RFC ಯಿಂದ UTF-8 ಸಿಂಟ್ಯಾಕ್ಸ್ ಬಳಸಿ
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=% x00-7F UTF8-2=% xC2-DF UTF8-ಬಾಲ UTF8-3= %xE0% xA0-BF UTF8-ಬಾಲ/% xE1-EC 2( UTF8-tail )/%xED% x80-9F UTF8-ಬಾಲ/% xEE-EF 2( UTF8-tail ) UTF8-4= %xF0% x90-BF 2( UTF8-tail )/% xF1-F3 3( UTF8-tail )/%xF4% x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // Ascii ಪ್ರಕರಣ, ತ್ವರಿತವಾಗಿ ಮುಂದಕ್ಕೆ ಹೋಗಲು ಪ್ರಯತ್ನಿಸಿ.
            // ಪಾಯಿಂಟರ್ ಅನ್ನು ಜೋಡಿಸಿದಾಗ, ಆಸಿ ಅಲ್ಲದ ಬೈಟ್ ಹೊಂದಿರುವ ಪದವನ್ನು ನಾವು ಕಂಡುಕೊಳ್ಳುವವರೆಗೆ ಪ್ರತಿ ಪುನರಾವರ್ತನೆಗೆ 2 ಪದಗಳ ಡೇಟಾವನ್ನು ಓದಿ.
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // ಸುರಕ್ಷತೆ: `align - index` ಮತ್ತು `ascii_block_size` ಆಗಿರುವುದರಿಂದ
                    // `usize_bytes`, `block = ptr.add(index)` ನ ಗುಣಾಕಾರಗಳು ಯಾವಾಗಲೂ `usize` ನೊಂದಿಗೆ ಜೋಡಿಸಲ್ಪಟ್ಟಿರುತ್ತವೆ ಆದ್ದರಿಂದ `block` ಮತ್ತು `block.offset(1)` ಎರಡನ್ನೂ ಅಪನಗದೀಕರಣ ಮಾಡುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ.
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // ನಾನಸ್ಕಿ ಬೈಟ್ ಇದ್ದರೆ ಮುರಿಯಿರಿ
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // ವರ್ಡ್‌ವೈಸ್ ಲೂಪ್ ನಿಲ್ಲಿಸಿದ ಸ್ಥಳದಿಂದ ಹೆಜ್ಜೆ ಹಾಕಿ
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// ಮೊದಲ ಬೈಟ್ ನೀಡಿದರೆ, ಈ UTF-8 ಅಕ್ಷರದಲ್ಲಿ ಎಷ್ಟು ಬೈಟ್‌ಗಳಿವೆ ಎಂಬುದನ್ನು ನಿರ್ಧರಿಸುತ್ತದೆ.
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// ಮುಂದುವರಿಕೆ ಬೈಟ್‌ನ ಮೌಲ್ಯ ಬಿಟ್‌ಗಳ ಮುಖವಾಡ.
const CONT_MASK: u8 = 0b0011_1111;
/// ಮುಂದುವರಿಕೆ ಬೈಟ್‌ನ ಟ್ಯಾಗ್ ಬಿಟ್‌ಗಳ ಮೌಲ್ಯ (ಟ್ಯಾಗ್ ಮಾಸ್ಕ್ !CONT_MASK ಆಗಿದೆ).
const TAG_CONT_U8: u8 = 0b1000_0000;

// `&str` ಅನ್ನು ಉದ್ದಕ್ಕೆ ಮೊಟಕುಗೊಳಿಸಿ `max` ಗೆ ಸಮನಾಗಿರುತ್ತದೆ, ಅದು ಮೊಟಕುಗೊಂಡಿದ್ದರೆ `true` ರಿಟರ್ನ್, ಮತ್ತು ಹೊಸ str.
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}