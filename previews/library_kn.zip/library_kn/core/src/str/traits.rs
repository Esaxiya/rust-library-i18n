//! `str` ಗಾಗಿ Trait ಅನುಷ್ಠಾನಗಳು.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// ತಂತಿಗಳ ಆದೇಶವನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
///
/// ತಂತಿಗಳನ್ನು ಅವುಗಳ ಬೈಟ್ ಮೌಲ್ಯಗಳಿಂದ [lexicographically](Ord#lexicographical-comparison) ಗೆ ಆದೇಶಿಸಲಾಗುತ್ತದೆ.
/// ಇದು ಕೋಡ್ ಪಟ್ಟಿಯಲ್ಲಿನ ಸ್ಥಾನಗಳ ಆಧಾರದ ಮೇಲೆ ಯುನಿಕೋಡ್ ಕೋಡ್ ಪಾಯಿಂಟ್‌ಗಳನ್ನು ಆದೇಶಿಸುತ್ತದೆ.
/// ಇದು "alphabetical" ಆದೇಶದಂತೆಯೇ ಇರಬೇಕಾಗಿಲ್ಲ, ಇದು ಭಾಷೆ ಮತ್ತು ಸ್ಥಳದಿಂದ ಬದಲಾಗುತ್ತದೆ.
/// ಸಾಂಸ್ಕೃತಿಕವಾಗಿ ಅಂಗೀಕರಿಸಲ್ಪಟ್ಟ ಮಾನದಂಡಗಳಿಗೆ ಅನುಗುಣವಾಗಿ ತಂತಿಗಳನ್ನು ವಿಂಗಡಿಸಲು `str` ಪ್ರಕಾರದ ವ್ಯಾಪ್ತಿಯಿಂದ ಹೊರಗಿರುವ ಲೊಕೇಲ್-ನಿರ್ದಿಷ್ಟ ಡೇಟಾ ಅಗತ್ಯವಿದೆ.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// ತಂತಿಗಳ ಮೇಲೆ ಹೋಲಿಕೆ ಕಾರ್ಯಾಚರಣೆಯನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
///
/// ತಂತಿಗಳನ್ನು [lexicographically](Ord#lexicographical-comparison) ಅನ್ನು ಅವುಗಳ ಬೈಟ್ ಮೌಲ್ಯಗಳಿಂದ ಹೋಲಿಸಲಾಗುತ್ತದೆ.
/// ಇದು ಕೋಡ್ ಪಟ್ಟಿಯಲ್ಲಿನ ಸ್ಥಾನಗಳ ಆಧಾರದ ಮೇಲೆ ಯೂನಿಕೋಡ್ ಕೋಡ್ ಪಾಯಿಂಟ್‌ಗಳನ್ನು ಹೋಲಿಸುತ್ತದೆ.
/// ಇದು "alphabetical" ಆದೇಶದಂತೆಯೇ ಇರಬೇಕಾಗಿಲ್ಲ, ಇದು ಭಾಷೆ ಮತ್ತು ಸ್ಥಳದಿಂದ ಬದಲಾಗುತ್ತದೆ.
/// ಸಾಂಸ್ಕೃತಿಕವಾಗಿ ಅಂಗೀಕರಿಸಲ್ಪಟ್ಟ ಮಾನದಂಡಗಳಿಗೆ ಅನುಗುಣವಾಗಿ ತಂತಿಗಳನ್ನು ಹೋಲಿಸಲು `str` ಪ್ರಕಾರದ ವ್ಯಾಪ್ತಿಯಿಂದ ಹೊರಗಿರುವ ಲೊಕೇಲ್-ನಿರ್ದಿಷ್ಟ ಡೇಟಾ ಅಗತ್ಯವಿದೆ.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// ಸಿಂಟ್ಯಾಕ್ಸ್ `&self[..]` ಅಥವಾ `&mut self[..]` ನೊಂದಿಗೆ ಸಬ್ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸಿಂಗ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
///
/// ಇಡೀ ಸ್ಟ್ರಿಂಗ್‌ನ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಂದರೆ, `&self` ಅಥವಾ `&mut self` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.`&ಸ್ವಯಂ [0 .. ಗೆ ಸಮ.
/// ಲೆನ್] `ಅಥವಾ`&ಮಟ್ ಸೆಲ್ಫ್ [0 ..
/// len]`.
/// ಇತರ ಸೂಚ್ಯಂಕ ಕಾರ್ಯಾಚರಣೆಗಳಂತೆ, ಇದು ಎಂದಿಗೂ panic ಆಗುವುದಿಲ್ಲ.
///
/// ಈ ಕಾರ್ಯಾಚರಣೆ *O*(1).
///
/// 1.20.0 ಗೆ ಮೊದಲು, ಈ ಸೂಚಿಕೆ ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು `Index` ಮತ್ತು `IndexMut` ನ ನೇರ ಅನುಷ್ಠಾನದಿಂದ ಇನ್ನೂ ಬೆಂಬಲಿಸಲಾಗಿದೆ.
///
/// `&self[0 .. len]` ಅಥವಾ `&mut self[0 .. len]` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// ಸಿಂಟ್ಯಾಕ್ಸ್ `&self[begin .. end]` ಅಥವಾ `&mut self[begin .. end]` ನೊಂದಿಗೆ ಸಬ್ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸಿಂಗ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
///
/// ಕೊಟ್ಟಿರುವ ಸ್ಟ್ರಿಂಗ್‌ನ ಸ್ಲೈಸ್ ಅನ್ನು ಬೈಟ್ ಶ್ರೇಣಿಯಿಂದ ಹಿಂತಿರುಗಿಸುತ್ತದೆ [`ಪ್ರಾರಂಭ`, `end`).
///
/// ಈ ಕಾರ್ಯಾಚರಣೆ *O*(1).
///
/// 1.20.0 ಗೆ ಮೊದಲು, ಈ ಸೂಚಿಕೆ ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು `Index` ಮತ್ತು `IndexMut` ನ ನೇರ ಅನುಷ್ಠಾನದಿಂದ ಇನ್ನೂ ಬೆಂಬಲಿಸಲಾಗಿದೆ.
///
/// # Panics
///
/// `begin` ಅಥವಾ `end` ಒಂದು ಪಾತ್ರದ ಆರಂಭಿಕ ಬೈಟ್ ಆಫ್‌ಸೆಟ್ ಅನ್ನು ಸೂಚಿಸದಿದ್ದರೆ (`is_char_boundary` ನಿಂದ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿದೆ), `begin > end` ಆಗಿದ್ದರೆ ಅಥವಾ `end > len` ಆಗಿದ್ದರೆ Panics.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // ಇವುಗಳು panic:
/// // ಬೈಟ್ 2 `ö` ನಲ್ಲಿದೆ:
/// // &ರು [2 ..3];
///
/// // ಬೈಟ್ 8 `老`&s ನಲ್ಲಿದೆ [1 ..
/// // 8];
///
/// // ಬೈಟ್ 100 ಸ್ಟ್ರಿಂಗ್&ಗಳ ಹೊರಗಿದೆ [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // ಸುರಕ್ಷತೆ: `start` ಮತ್ತು `end` ಚಾರ್ ಗಡಿಯಲ್ಲಿವೆ ಎಂದು ಇದೀಗ ಪರಿಶೀಲಿಸಲಾಗಿದೆ,
            // ಮತ್ತು ನಾವು ಸುರಕ್ಷಿತ ಉಲ್ಲೇಖದಲ್ಲಿ ಸಾಗುತ್ತಿದ್ದೇವೆ, ಆದ್ದರಿಂದ ರಿಟರ್ನ್ ಮೌಲ್ಯವೂ ಒಂದಾಗಿರುತ್ತದೆ.
            // ನಾವು ಚಾರ್ ಗಡಿಗಳನ್ನು ಸಹ ಪರಿಶೀಲಿಸಿದ್ದೇವೆ, ಆದ್ದರಿಂದ ಇದು ಮಾನ್ಯ UTF-8 ಆಗಿದೆ.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // ಸುರಕ್ಷತೆ: `start` ಮತ್ತು `end` ಚಾರ್ ಗಡಿಯಲ್ಲಿದೆ ಎಂದು ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
            // ಪಾಯಿಂಟರ್ ಅನನ್ಯವಾಗಿದೆ ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ ಏಕೆಂದರೆ ನಾವು ಅದನ್ನು `slice` ನಿಂದ ಪಡೆದುಕೊಂಡಿದ್ದೇವೆ.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `self` `slice` ನ ಪರಿಮಿತಿಯಲ್ಲಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತದೆ
        // ಇದು `add` ಗಾಗಿ ಎಲ್ಲಾ ಷರತ್ತುಗಳನ್ನು ಪೂರೈಸುತ್ತದೆ.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // ಸುರಕ್ಷತೆ: `get_unchecked` ಗಾಗಿ ಕಾಮೆಂಟ್‌ಗಳನ್ನು ನೋಡಿ.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // ಸೂಚ್ಯಂಕವು [0, .len()] ಮೇಲಿನಂತೆ `get` ಅನ್ನು ಮರುಬಳಕೆ ಮಾಡಲು ಸಾಧ್ಯವಿಲ್ಲ ಎಂದು is_char_boundary ಪರಿಶೀಲಿಸುತ್ತದೆ, ಏಕೆಂದರೆ NLL ತೊಂದರೆ
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // ಸುರಕ್ಷತೆ: `start` ಮತ್ತು `end` ಚಾರ್ ಗಡಿಯಲ್ಲಿವೆ ಎಂದು ಇದೀಗ ಪರಿಶೀಲಿಸಲಾಗಿದೆ,
            // ಮತ್ತು ನಾವು ಸುರಕ್ಷಿತ ಉಲ್ಲೇಖದಲ್ಲಿ ಸಾಗುತ್ತಿದ್ದೇವೆ, ಆದ್ದರಿಂದ ರಿಟರ್ನ್ ಮೌಲ್ಯವೂ ಒಂದಾಗಿರುತ್ತದೆ.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// ಸಿಂಟ್ಯಾಕ್ಸ್ `&self[.. end]` ಅಥವಾ `&mut self[.. end]` ನೊಂದಿಗೆ ಸಬ್ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸಿಂಗ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
///
/// ಬೈಟ್ ಶ್ರೇಣಿಯಿಂದ [`0`, `end`) ಕೊಟ್ಟಿರುವ ಸ್ಟ್ರಿಂಗ್‌ನ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
/// `&self[0 .. end]` ಅಥವಾ `&mut self[0 .. end]` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ.
///
/// ಈ ಕಾರ್ಯಾಚರಣೆ *O*(1).
///
/// 1.20.0 ಗೆ ಮೊದಲು, ಈ ಸೂಚಿಕೆ ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು `Index` ಮತ್ತು `IndexMut` ನ ನೇರ ಅನುಷ್ಠಾನದಿಂದ ಇನ್ನೂ ಬೆಂಬಲಿಸಲಾಗಿದೆ.
///
/// # Panics
///
/// `end` ಒಂದು ಪಾತ್ರದ ಆರಂಭಿಕ ಬೈಟ್ ಆಫ್‌ಸೆಟ್‌ಗೆ (`is_char_boundary` ನಿಂದ ವ್ಯಾಖ್ಯಾನಿಸಿದಂತೆ) ಸೂಚಿಸದಿದ್ದರೆ ಅಥವಾ `end > len` ಆಗಿದ್ದರೆ Panics.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // ಸುರಕ್ಷತೆ: `end` ಚಾರ್ ಗಡಿಯಲ್ಲಿದೆ ಎಂದು ಪರಿಶೀಲಿಸಲಾಗಿದೆ,
            // ಮತ್ತು ನಾವು ಸುರಕ್ಷಿತ ಉಲ್ಲೇಖದಲ್ಲಿ ಸಾಗುತ್ತಿದ್ದೇವೆ, ಆದ್ದರಿಂದ ರಿಟರ್ನ್ ಮೌಲ್ಯವೂ ಒಂದಾಗಿರುತ್ತದೆ.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // ಸುರಕ್ಷತೆ: `end` ಚಾರ್ ಗಡಿಯಲ್ಲಿದೆ ಎಂದು ಪರಿಶೀಲಿಸಲಾಗಿದೆ,
            // ಮತ್ತು ನಾವು ಸುರಕ್ಷಿತ ಉಲ್ಲೇಖದಲ್ಲಿ ಸಾಗುತ್ತಿದ್ದೇವೆ, ಆದ್ದರಿಂದ ರಿಟರ್ನ್ ಮೌಲ್ಯವೂ ಒಂದಾಗಿರುತ್ತದೆ.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // ಸುರಕ್ಷತೆ: `end` ಚಾರ್ ಗಡಿಯಲ್ಲಿದೆ ಎಂದು ಪರಿಶೀಲಿಸಲಾಗಿದೆ,
            // ಮತ್ತು ನಾವು ಸುರಕ್ಷಿತ ಉಲ್ಲೇಖದಲ್ಲಿ ಸಾಗುತ್ತಿದ್ದೇವೆ, ಆದ್ದರಿಂದ ರಿಟರ್ನ್ ಮೌಲ್ಯವೂ ಒಂದಾಗಿರುತ್ತದೆ.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// ಸಿಂಟ್ಯಾಕ್ಸ್ `&self[begin ..]` ಅಥವಾ `&mut self[begin ..]` ನೊಂದಿಗೆ ಸಬ್ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸಿಂಗ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
///
/// ಕೊಟ್ಟಿರುವ ಸ್ಟ್ರಿಂಗ್‌ನ ಸ್ಲೈಸ್ ಅನ್ನು ಬೈಟ್ ಶ್ರೇಣಿಯಿಂದ ಹಿಂತಿರುಗಿಸುತ್ತದೆ [`ಪ್ರಾರಂಭ`, `len`).`&ಸ್ವಯಂ [ಪ್ರಾರಂಭ ..
/// ಲೆನ್] `ಅಥವಾ`&ಮಟ್ ಸೆಲ್ಫ್ [ಪ್ರಾರಂಭ ..
/// len]`.
///
/// ಈ ಕಾರ್ಯಾಚರಣೆ *O*(1).
///
/// 1.20.0 ಗೆ ಮೊದಲು, ಈ ಸೂಚಿಕೆ ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು `Index` ಮತ್ತು `IndexMut` ನ ನೇರ ಅನುಷ್ಠಾನದಿಂದ ಇನ್ನೂ ಬೆಂಬಲಿಸಲಾಗಿದೆ.
///
/// # Panics
///
/// `begin` ಒಂದು ಪಾತ್ರದ ಆರಂಭಿಕ ಬೈಟ್ ಆಫ್‌ಸೆಟ್‌ಗೆ (`is_char_boundary` ನಿಂದ ವ್ಯಾಖ್ಯಾನಿಸಿದಂತೆ) ಸೂಚಿಸದಿದ್ದರೆ ಅಥವಾ `begin > len` ಆಗಿದ್ದರೆ Panics.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // ಸುರಕ್ಷತೆ: `start` ಚಾರ್ ಗಡಿಯಲ್ಲಿದೆ ಎಂದು ಪರಿಶೀಲಿಸಲಾಗಿದೆ,
            // ಮತ್ತು ನಾವು ಸುರಕ್ಷಿತ ಉಲ್ಲೇಖದಲ್ಲಿ ಸಾಗುತ್ತಿದ್ದೇವೆ, ಆದ್ದರಿಂದ ರಿಟರ್ನ್ ಮೌಲ್ಯವೂ ಒಂದಾಗಿರುತ್ತದೆ.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // ಸುರಕ್ಷತೆ: `start` ಚಾರ್ ಗಡಿಯಲ್ಲಿದೆ ಎಂದು ಪರಿಶೀಲಿಸಲಾಗಿದೆ,
            // ಮತ್ತು ನಾವು ಸುರಕ್ಷಿತ ಉಲ್ಲೇಖದಲ್ಲಿ ಸಾಗುತ್ತಿದ್ದೇವೆ, ಆದ್ದರಿಂದ ರಿಟರ್ನ್ ಮೌಲ್ಯವೂ ಒಂದಾಗಿರುತ್ತದೆ.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `self` `slice` ನ ಪರಿಮಿತಿಯಲ್ಲಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತದೆ
        // ಇದು `add` ಗಾಗಿ ಎಲ್ಲಾ ಷರತ್ತುಗಳನ್ನು ಪೂರೈಸುತ್ತದೆ.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // ಸುರಕ್ಷತೆ: `get_unchecked` ಗೆ ಹೋಲುತ್ತದೆ.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // ಸುರಕ್ಷತೆ: `start` ಚಾರ್ ಗಡಿಯಲ್ಲಿದೆ ಎಂದು ಪರಿಶೀಲಿಸಲಾಗಿದೆ,
            // ಮತ್ತು ನಾವು ಸುರಕ್ಷಿತ ಉಲ್ಲೇಖದಲ್ಲಿ ಸಾಗುತ್ತಿದ್ದೇವೆ, ಆದ್ದರಿಂದ ರಿಟರ್ನ್ ಮೌಲ್ಯವೂ ಒಂದಾಗಿರುತ್ತದೆ.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// ಸಿಂಟ್ಯಾಕ್ಸ್ `&self[begin ..= end]` ಅಥವಾ `&mut self[begin ..= end]` ನೊಂದಿಗೆ ಸಬ್ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸಿಂಗ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
///
/// ನಿರ್ದಿಷ್ಟ ಸ್ಟ್ರಿಂಗ್‌ನ ಸ್ಲೈಸ್ ಅನ್ನು ಬೈಟ್ ಶ್ರೇಣಿ [`begin`, `end`] ನಿಂದ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.`&self [begin .. end + 1]` ಅಥವಾ `&mut self[begin .. end + 1]` ಗೆ ಸಮನಾಗಿರುತ್ತದೆ, `end` `usize` ಗೆ ಗರಿಷ್ಠ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿದ್ದರೆ ಹೊರತುಪಡಿಸಿ.
///
/// ಈ ಕಾರ್ಯಾಚರಣೆ *O*(1).
///
/// # Panics
///
/// `begin` ಒಂದು ಪಾತ್ರದ ಆರಂಭಿಕ ಬೈಟ್ ಆಫ್‌ಸೆಟ್‌ಗೆ ಸೂಚಿಸದಿದ್ದರೆ (`is_char_boundary` ನಿಂದ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿದೆ), `end` ಒಂದು ಪಾತ್ರದ ಅಂತ್ಯದ ಬೈಟ್ ಆಫ್‌ಸೆಟ್‌ಗೆ ಸೂಚಿಸದಿದ್ದರೆ (`end + 1` ಒಂದು ಆರಂಭಿಕ ಬೈಟ್ ಆಫ್‌ಸೆಟ್ ಅಥವಾ `len` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ), `begin > end` ಆಗಿದ್ದರೆ, ಅಥವಾ `end >= len` ಆಗಿದ್ದರೆ.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `get_unchecked` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `get_unchecked_mut` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// ಸಿಂಟ್ಯಾಕ್ಸ್ `&self[..= end]` ಅಥವಾ `&mut self[..= end]` ನೊಂದಿಗೆ ಸಬ್ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸಿಂಗ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
///
/// ಬೈಟ್ ಶ್ರೇಣಿ [0, `end`] ನಿಂದ ಕೊಟ್ಟಿರುವ ಸ್ಟ್ರಿಂಗ್‌ನ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
/// `end` ಗೆ `usize` ಗೆ ಗರಿಷ್ಠ ಮೌಲ್ಯವಿದ್ದರೆ ಹೊರತುಪಡಿಸಿ, `&self [0 .. end + 1]` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ.
///
/// ಈ ಕಾರ್ಯಾಚರಣೆ *O*(1).
///
/// # Panics
///
/// `end` ಒಂದು ಪಾತ್ರದ ಅಂತ್ಯದ ಬೈಟ್ ಆಫ್‌ಸೆಟ್‌ಗೆ ಸೂಚಿಸದಿದ್ದರೆ Panics (`end + 1` ಎಂಬುದು `is_char_boundary` ನಿಂದ ವ್ಯಾಖ್ಯಾನಿಸಲ್ಪಟ್ಟ ಆರಂಭಿಕ ಬೈಟ್ ಆಫ್‌ಸೆಟ್, ಅಥವಾ `len` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ), ಅಥವಾ `end >= len` ಆಗಿದ್ದರೆ.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `get_unchecked` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `get_unchecked_mut` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// ಸ್ಟ್ರಿಂಗ್‌ನಿಂದ ಮೌಲ್ಯವನ್ನು ಪಾರ್ಸ್ ಮಾಡಿ
///
/// [Fromstr`ನ [`from_str`] ವಿಧಾನವನ್ನು [`str`] ನ [`parse`] ವಿಧಾನದ ಮೂಲಕ ಸೂಚ್ಯವಾಗಿ ಬಳಸಲಾಗುತ್ತದೆ.
/// ಉದಾಹರಣೆಗಳಿಗಾಗಿ [`ಪಾರ್ಸ್`] ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` ಜೀವಮಾನದ ನಿಯತಾಂಕವನ್ನು ಹೊಂದಿಲ್ಲ, ಮತ್ತು ಆದ್ದರಿಂದ ನೀವು ಜೀವಮಾನದ ನಿಯತಾಂಕವನ್ನು ಹೊಂದಿರದ ಪ್ರಕಾರಗಳನ್ನು ಮಾತ್ರ ಪಾರ್ಸ್ ಮಾಡಬಹುದು.
///
/// ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, ನೀವು `i32` ಅನ್ನು `FromStr` ನೊಂದಿಗೆ ಪಾರ್ಸ್ ಮಾಡಬಹುದು, ಆದರೆ `&i32` ಅಲ್ಲ.
/// ನೀವು `i32` ಅನ್ನು ಒಳಗೊಂಡಿರುವ ಒಂದು ರಚನೆಯನ್ನು ಪಾರ್ಸ್ ಮಾಡಬಹುದು, ಆದರೆ `&i32` ಅನ್ನು ಒಳಗೊಂಡಿರುವಂತಹದ್ದಲ್ಲ.
///
/// # Examples
///
/// `FromStr` ಪ್ರಕಾರದ `FromStr` ನ ಮೂಲ ಅನುಷ್ಠಾನ:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// ಪಾರ್ಸಿಂಗ್‌ನಿಂದ ಹಿಂತಿರುಗಿಸಬಹುದಾದ ಸಂಬಂಧಿತ ದೋಷ.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// ಈ ಪ್ರಕಾರದ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸಲು ಸ್ಟ್ರಿಂಗ್ `s` ಅನ್ನು ಪಾರ್ಸ್ ಮಾಡುತ್ತದೆ.
    ///
    /// ಪಾರ್ಸಿಂಗ್ ಯಶಸ್ವಿಯಾದರೆ, [`Ok`] ಒಳಗೆ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸಿ, ಇಲ್ಲದಿದ್ದರೆ ಸ್ಟ್ರಿಂಗ್ ತಪ್ಪಾಗಿ ಫಾರ್ಮ್ಯಾಟ್ ಆಗಿರುವಾಗ [`Err`] ಒಳಗಿನ ನಿರ್ದಿಷ್ಟ ದೋಷವನ್ನು ಹಿಂತಿರುಗಿಸಿ.
    /// ದೋಷ ಪ್ರಕಾರವು trait ಅನುಷ್ಠಾನಕ್ಕೆ ನಿರ್ದಿಷ್ಟವಾಗಿದೆ.
    ///
    /// # Examples
    ///
    /// [`i32`] ನೊಂದಿಗೆ ಮೂಲ ಬಳಕೆ, ಇದು `FromStr` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಒಂದು ವಿಧ:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// ಸ್ಟ್ರಿಂಗ್‌ನಿಂದ `bool` ಅನ್ನು ಪಾರ್ಸ್ ಮಾಡಿ.
    ///
    /// `Result<bool, ParseBoolError>` ಅನ್ನು ನೀಡುತ್ತದೆ, ಏಕೆಂದರೆ `s` ವಾಸ್ತವವಾಗಿ ಪಾರ್ಸ್ ಆಗಿರಬಹುದು ಅಥವಾ ಇರಬಹುದು.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// ಗಮನಿಸಿ, ಅನೇಕ ಸಂದರ್ಭಗಳಲ್ಲಿ, `str` ನಲ್ಲಿನ `.parse()` ವಿಧಾನವು ಹೆಚ್ಚು ಸೂಕ್ತವಾಗಿದೆ.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}