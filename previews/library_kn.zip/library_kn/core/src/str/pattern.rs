//! ಸ್ಟ್ರಿಂಗ್ ಪ್ಯಾಟರ್ನ್ API.
//!
//! ಪ್ಯಾಟರ್ನ್ API ಸ್ಟ್ರಿಂಗ್ ಮೂಲಕ ಹುಡುಕುವಾಗ ವಿಭಿನ್ನ ಮಾದರಿಯ ಪ್ರಕಾರಗಳನ್ನು ಬಳಸುವ ಸಾಮಾನ್ಯ ಕಾರ್ಯವಿಧಾನವನ್ನು ಒದಗಿಸುತ್ತದೆ.
//!
//! ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ, traits [`Pattern`], [`Searcher`], [`ReverseSearcher`], ಮತ್ತು [`DoubleEndedSearcher`] ನೋಡಿ.
//!
//! ಈ API ಅಸ್ಥಿರವಾಗಿದ್ದರೂ, ಇದು [`str`] ಪ್ರಕಾರದ ಸ್ಥಿರ API ಗಳ ಮೂಲಕ ಬಹಿರಂಗಗೊಳ್ಳುತ್ತದೆ.
//!
//! # Examples
//!
//! [`Pattern`] [`&str`][`str`], [`char`], [`char`] ನ ಚೂರುಗಳು ಮತ್ತು `FnMut(char) -> bool` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಕಾರ್ಯಗಳು ಮತ್ತು ಮುಚ್ಚುವಿಕೆಗಳಿಗಾಗಿ ಸ್ಥಿರ API ನಲ್ಲಿ [implemented][pattern-impls] ಆಗಿದೆ.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // ಚಾರ್ ಪ್ಯಾಟರ್ನ್
//! assert_eq!(s.find('n'), Some(2));
//! // ಅಕ್ಷರಗಳ ಸ್ಲೈಸ್
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // ಮುಚ್ಚುವ ಮಾದರಿ
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// ಸ್ಟ್ರಿಂಗ್ ಮಾದರಿ.
///
/// [`&'a str`][str] ನಲ್ಲಿ ಹುಡುಕಲು ಅನುಷ್ಠಾನಗೊಳಿಸುವ ಪ್ರಕಾರವನ್ನು ಸ್ಟ್ರಿಂಗ್ ಮಾದರಿಯಾಗಿ ಬಳಸಬಹುದು ಎಂದು `Pattern<'a>` ವ್ಯಕ್ತಪಡಿಸುತ್ತದೆ.
///
/// ಉದಾಹರಣೆಗೆ, `'a'` ಮತ್ತು `"aa"` ಎರಡೂ `"baaaab"` ಸ್ಟ್ರಿಂಗ್‌ನಲ್ಲಿನ ಸೂಚ್ಯಂಕ `1` ನಲ್ಲಿ ಹೊಂದಿಕೆಯಾಗುವ ಮಾದರಿಗಳಾಗಿವೆ.
///
/// trait ಸ್ವತಃ ಸಂಯೋಜಿತ [`Searcher`] ಪ್ರಕಾರದ ಬಿಲ್ಡರ್ ಆಗಿ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ, ಇದು ಸ್ಟ್ರಿಂಗ್‌ನಲ್ಲಿ ಮಾದರಿಯ ಘಟನೆಗಳನ್ನು ಕಂಡುಹಿಡಿಯುವ ನಿಜವಾದ ಕೆಲಸವನ್ನು ಮಾಡುತ್ತದೆ.
///
///
/// ಮಾದರಿಯ ಪ್ರಕಾರವನ್ನು ಅವಲಂಬಿಸಿ, [`str::find`] ಮತ್ತು [`str::contains`] ನಂತಹ ವಿಧಾನಗಳ ವರ್ತನೆಯು ಬದಲಾಗಬಹುದು.
/// ಕೆಳಗಿನ ಕೋಷ್ಟಕವು ಅಂತಹ ಕೆಲವು ನಡವಳಿಕೆಗಳನ್ನು ವಿವರಿಸುತ್ತದೆ.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// ಈ ಮಾದರಿಗಾಗಿ ಸಂಯೋಜಿತ ಶೋಧಕ
    type Searcher: Searcher<'a>;

    /// ಹುಡುಕಲು `self` ಮತ್ತು `haystack` ನಿಂದ ಸಂಯೋಜಿತ ಶೋಧಕವನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// ಮಾದರಿಯು ಹುಲ್ಲುಗಾವಲಿನಲ್ಲಿ ಎಲ್ಲಿಯಾದರೂ ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// ಮಾದರಿಯು ಹುಲ್ಲುಗಾವಲಿನ ಮುಂಭಾಗದಲ್ಲಿ ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// ಮಾದರಿಯು ಹುಲ್ಲುಗಾವಲಿನ ಹಿಂಭಾಗದಲ್ಲಿ ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// ಹೊಂದಿಕೆಯಾದರೆ, ಬಣವೆ ಮುಂಭಾಗದಿಂದ ಮಾದರಿಯನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // ಸುರಕ್ಷತೆ: `Searcher` ಮಾನ್ಯ ಸೂಚ್ಯಂಕಗಳನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// ಹೊಂದಾಣಿಕೆಯಾಗಿದ್ದರೆ, ಬಣಬೆಯ ಹಿಂಭಾಗದಿಂದ ಮಾದರಿಯನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // ಸುರಕ್ಷತೆ: `Searcher` ಮಾನ್ಯ ಸೂಚ್ಯಂಕಗಳನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// [`Searcher::next()`] ಅಥವಾ [`ReverseSearcher::next_back()`] ಗೆ ಕರೆ ಮಾಡುವ ಫಲಿತಾಂಶ.
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// `haystack[a..b]` ನಲ್ಲಿ ಮಾದರಿಯ ಹೊಂದಾಣಿಕೆ ಕಂಡುಬಂದಿದೆ ಎಂದು ವ್ಯಕ್ತಪಡಿಸುತ್ತದೆ.
    ///
    Match(usize, usize),
    /// `haystack[a..b]` ಅನ್ನು ಮಾದರಿಯ ಸಂಭವನೀಯ ಹೊಂದಾಣಿಕೆ ಎಂದು ತಿರಸ್ಕರಿಸಲಾಗಿದೆ ಎಂದು ವ್ಯಕ್ತಪಡಿಸುತ್ತದೆ.
    ///
    /// ಎರಡು `ಹೊಂದಾಣಿಕೆ'ಗಳ ನಡುವೆ ಒಂದಕ್ಕಿಂತ ಹೆಚ್ಚು `Reject` ಇರಬಹುದು ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಅವುಗಳನ್ನು ಒಂದರೊಳಗೆ ಸಂಯೋಜಿಸುವ ಅಗತ್ಯವಿಲ್ಲ.
    ///
    ///
    Reject(usize, usize),
    /// ಹೇಸ್ಟಾಕ್ನ ಪ್ರತಿ ಬೈಟ್ಗೆ ಭೇಟಿ ನೀಡಲಾಗಿದೆ ಎಂದು ಪುನರಾವರ್ತಿಸುತ್ತದೆ, ಪುನರಾವರ್ತನೆ ಕೊನೆಗೊಳ್ಳುತ್ತದೆ.
    ///
    Done,
}

/// ಸ್ಟ್ರಿಂಗ್ ಮಾದರಿಗಾಗಿ ಶೋಧಕ.
///
/// ಈ trait ಸ್ಟ್ರಿಂಗ್‌ನ ಮುಂಭಾಗದ (left) ನಿಂದ ಪ್ರಾರಂಭವಾಗುವ ಮಾದರಿಯ ಅತಿಕ್ರಮಿಸದ ಪಂದ್ಯಗಳನ್ನು ಹುಡುಕುವ ವಿಧಾನಗಳನ್ನು ಒದಗಿಸುತ್ತದೆ.
///
/// ಇದನ್ನು [`Pattern`] trait ನ ಸಂಬಂಧಿತ `Searcher` ಪ್ರಕಾರಗಳಿಂದ ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗುತ್ತದೆ.
///
/// trait ಅನ್ನು ಅಸುರಕ್ಷಿತವೆಂದು ಗುರುತಿಸಲಾಗಿದೆ ಏಕೆಂದರೆ [`next()`][Searcher::next] ವಿಧಾನಗಳಿಂದ ಹಿಂತಿರುಗಿಸಲಾದ ಸೂಚ್ಯಂಕಗಳು ಬಣಬೆ ಸ್ಟ್ಯಾಕ್‌ನಲ್ಲಿ ಮಾನ್ಯ utf8 ಗಡಿಗಳಲ್ಲಿ ಮಲಗಬೇಕಾಗುತ್ತದೆ.
/// ಹೆಚ್ಚುವರಿ ಚಾಲನಾಸಮಯ ಪರಿಶೀಲನೆಗಳಿಲ್ಲದೆ ಈ trait ನ ಗ್ರಾಹಕರಿಗೆ ಬಣಬೆಗಳನ್ನು ತುಂಡು ಮಾಡಲು ಇದು ಅನುವು ಮಾಡಿಕೊಡುತ್ತದೆ.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// ಹುಡುಕಬೇಕಾದ ಆಧಾರವಾಗಿರುವ ಸ್ಟ್ರಿಂಗ್‌ಗಾಗಿ Getter
    ///
    /// ಯಾವಾಗಲೂ ಅದೇ [`&str`][str] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    fn haystack(&self) -> &'a str;

    /// ಮುಂದಿನ ಹುಡುಕಾಟ ಹಂತವನ್ನು ಮುಂಭಾಗದಿಂದ ಪ್ರಾರಂಭಿಸುತ್ತದೆ.
    ///
    /// - `haystack[a..b]` ಮಾದರಿಗೆ ಹೊಂದಿಕೆಯಾದರೆ [`Match(a, b)`][SearchStep::Match] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// - `haystack[a..b]` ಮಾದರಿಗೆ ಹೊಂದಿಕೆಯಾಗದಿದ್ದರೆ, ಭಾಗಶಃ ಸಹ [`Reject(a, b)`][SearchStep::Reject] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// - ಹೇಸ್ಟಾಕ್ನ ಪ್ರತಿ ಬೈಟ್ಗೆ ಭೇಟಿ ನೀಡಿದ್ದರೆ [`Done`][SearchStep::Done] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [`Done`][SearchStep::Done] ವರೆಗಿನ [`Match`][SearchStep::Match] ಮತ್ತು [`Reject`][SearchStep::Reject] ಮೌಲ್ಯಗಳ ಸ್ಟ್ರೀಮ್ ಪಕ್ಕದ, ಅತಿಕ್ರಮಿಸದ, ಇಡೀ ಬಣಬೆಗಳನ್ನು ಆವರಿಸುವ ಮತ್ತು utf8 ಗಡಿಗಳಲ್ಲಿ ಇಡುವ ಸೂಚ್ಯಂಕ ಶ್ರೇಣಿಗಳನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    ///
    ///
    /// [`Match`][SearchStep::Match] ಫಲಿತಾಂಶವು ಸಂಪೂರ್ಣ ಹೊಂದಾಣಿಕೆಯ ಮಾದರಿಯನ್ನು ಹೊಂದಿರಬೇಕು, ಆದಾಗ್ಯೂ [`Reject`][SearchStep::Reject] ಫಲಿತಾಂಶಗಳನ್ನು ಅನಿಯಂತ್ರಿತ ಅನೇಕ ಪಕ್ಕದ ತುಣುಕುಗಳಾಗಿ ವಿಂಗಡಿಸಬಹುದು.ಎರಡೂ ಶ್ರೇಣಿಗಳು ಶೂನ್ಯ ಉದ್ದವನ್ನು ಹೊಂದಿರಬಹುದು.
    ///
    /// ಉದಾಹರಣೆಯಾಗಿ, `"aaa"` ಮತ್ತು ಹೇಸ್ಟಾಕ್ `"cbaaaaab"` ಮಾದರಿಯು ಸ್ಟ್ರೀಮ್ ಅನ್ನು ಉತ್ಪಾದಿಸಬಹುದು
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// ಮುಂದಿನ [`Match`][SearchStep::Match] ಫಲಿತಾಂಶವನ್ನು ಹುಡುಕುತ್ತದೆ.[`next()`][Searcher::next] ನೋಡಿ.
    ///
    /// [`next()`][Searcher::next] ಗಿಂತ ಭಿನ್ನವಾಗಿ, ಈ ಮತ್ತು [`next_reject`][Searcher::next_reject] ನ ಹಿಂತಿರುಗಿದ ಶ್ರೇಣಿಗಳು ಅತಿಕ್ರಮಿಸುತ್ತವೆ ಎಂಬುದಕ್ಕೆ ಯಾವುದೇ ಗ್ಯಾರಂಟಿ ಇಲ್ಲ.
    /// ಇದು `(start_match, end_match)` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಲ್ಲಿ ಸ್ಟಾರ್ಟ್_ಮ್ಯಾಚ್ ಪಂದ್ಯವು ಎಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ ಎಂಬುದರ ಸೂಚ್ಯಂಕವಾಗಿದೆ, ಮತ್ತು ಎಂಡ್_ಮ್ಯಾಚ್ ಪಂದ್ಯದ ಅಂತ್ಯದ ನಂತರ ಸೂಚ್ಯಂಕವಾಗಿದೆ.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// ಮುಂದಿನ [`Reject`][SearchStep::Reject] ಫಲಿತಾಂಶವನ್ನು ಹುಡುಕುತ್ತದೆ.[`next()`][Searcher::next] ಮತ್ತು [`next_match()`][Searcher::next_match] ನೋಡಿ.
    ///
    /// [`next()`][Searcher::next] ಗಿಂತ ಭಿನ್ನವಾಗಿ, ಇದರ ಹಿಂದಿರುಗಿದ ಶ್ರೇಣಿಗಳು ಮತ್ತು [`next_match`][Searcher::next_match] ಅತಿಕ್ರಮಿಸುತ್ತದೆ ಎಂಬುದಕ್ಕೆ ಯಾವುದೇ ಗ್ಯಾರಂಟಿ ಇಲ್ಲ.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// ಸ್ಟ್ರಿಂಗ್ ಮಾದರಿಗಾಗಿ ಹಿಮ್ಮುಖ ಶೋಧಕ.
///
/// ಈ trait ಸ್ಟ್ರಿಂಗ್‌ನ ಹಿಂದಿನ (right) ನಿಂದ ಪ್ರಾರಂಭವಾಗುವ ಮಾದರಿಯ ಅತಿಕ್ರಮಿಸದ ಪಂದ್ಯಗಳನ್ನು ಹುಡುಕುವ ವಿಧಾನಗಳನ್ನು ಒದಗಿಸುತ್ತದೆ.
///
/// ಮಾದರಿಯು ಹಿಂದಿನಿಂದ ಹುಡುಕಲು ಬೆಂಬಲಿಸಿದರೆ ಅದನ್ನು [`Pattern`] trait ನ ಸಂಬಂಧಿತ [`Searcher`] ಪ್ರಕಾರಗಳಿಂದ ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗುತ್ತದೆ.
///
///
/// ಈ trait ನಿಂದ ಹಿಂತಿರುಗಿಸಲಾದ ಸೂಚ್ಯಂಕ ಶ್ರೇಣಿಗಳು ಹಿಮ್ಮುಖವಾಗಿ ಫಾರ್ವರ್ಡ್ ಹುಡುಕಾಟವನ್ನು ನಿಖರವಾಗಿ ಹೊಂದಿಸಲು ಅಗತ್ಯವಿಲ್ಲ.
///
/// ಈ trait ಅನ್ನು ಅಸುರಕ್ಷಿತವೆಂದು ಗುರುತಿಸಲು ಕಾರಣಕ್ಕಾಗಿ, ಅವುಗಳನ್ನು ಪೋಷಕ trait [`Searcher`] ನೋಡಿ.
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// ಹಿಂದಿನಿಂದ ಪ್ರಾರಂಭಿಸಿ ಮುಂದಿನ ಹುಡುಕಾಟ ಹಂತವನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
    ///
    /// - `haystack[a..b]` ಮಾದರಿಗೆ ಹೊಂದಿಕೆಯಾದರೆ [`Match(a, b)`][SearchStep::Match] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// - `haystack[a..b]` ಭಾಗಶಃ ಸಹ ಮಾದರಿಗೆ ಹೊಂದಿಕೆಯಾಗದಿದ್ದರೆ [`Reject(a, b)`][SearchStep::Reject] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// - ಹೇಸ್ಟಾಕ್ನ ಪ್ರತಿ ಬೈಟ್ಗೆ ಭೇಟಿ ನೀಡಿದ್ದರೆ [`Done`][SearchStep::Done] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ
    ///
    /// [`Done`][SearchStep::Done] ವರೆಗಿನ [`Match`][SearchStep::Match] ಮತ್ತು [`Reject`][SearchStep::Reject] ಮೌಲ್ಯಗಳ ಸ್ಟ್ರೀಮ್ ಪಕ್ಕದ, ಅತಿಕ್ರಮಿಸದ, ಇಡೀ ಬಣಬೆಗಳನ್ನು ಆವರಿಸುವ ಮತ್ತು utf8 ಗಡಿಗಳಲ್ಲಿ ಇಡುವ ಸೂಚ್ಯಂಕ ಶ್ರೇಣಿಗಳನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    ///
    ///
    /// [`Match`][SearchStep::Match] ಫಲಿತಾಂಶವು ಸಂಪೂರ್ಣ ಹೊಂದಾಣಿಕೆಯ ಮಾದರಿಯನ್ನು ಹೊಂದಿರಬೇಕು, ಆದಾಗ್ಯೂ [`Reject`][SearchStep::Reject] ಫಲಿತಾಂಶಗಳನ್ನು ಅನಿಯಂತ್ರಿತ ಅನೇಕ ಪಕ್ಕದ ತುಣುಕುಗಳಾಗಿ ವಿಂಗಡಿಸಬಹುದು.ಎರಡೂ ಶ್ರೇಣಿಗಳು ಶೂನ್ಯ ಉದ್ದವನ್ನು ಹೊಂದಿರಬಹುದು.
    ///
    /// ಉದಾಹರಣೆಯಾಗಿ, `"aaa"` ಮತ್ತು ಹೇಸ್ಟಾಕ್ `"cbaaaaab"` ಮಾದರಿಯು `[Reject(7, 8), Match(4, 7), Reject(1, 4), ಸ್ಟ್ರೀಮ್ ಅನ್ನು ಉತ್ಪಾದಿಸಬಹುದು. Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// ಮುಂದಿನ [`Match`][SearchStep::Match] ಫಲಿತಾಂಶವನ್ನು ಹುಡುಕುತ್ತದೆ.
    /// [`next_back()`][ReverseSearcher::next_back] ನೋಡಿ.
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// ಮುಂದಿನ [`Reject`][SearchStep::Reject] ಫಲಿತಾಂಶವನ್ನು ಹುಡುಕುತ್ತದೆ.
    /// [`next_back()`][ReverseSearcher::next_back] ನೋಡಿ.
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// [`DoubleEndedIterator`] ಅನುಷ್ಠಾನಕ್ಕೆ [`ReverseSearcher`] ಅನ್ನು ಬಳಸಬಹುದು ಎಂದು ವ್ಯಕ್ತಪಡಿಸಲು ಮಾರ್ಕರ್ trait.
///
/// ಇದಕ್ಕಾಗಿ, [`Searcher`] ಮತ್ತು [`ReverseSearcher`] ನ impl ಈ ಷರತ್ತುಗಳನ್ನು ಅನುಸರಿಸಬೇಕು:
///
/// - `next()` ನ ಎಲ್ಲಾ ಫಲಿತಾಂಶಗಳು ಹಿಮ್ಮುಖ ಕ್ರಮದಲ್ಲಿ `next_back()` ಫಲಿತಾಂಶಗಳಿಗೆ ಹೋಲುತ್ತದೆ.
/// - `next()` ಮತ್ತು `next_back()` ಮೌಲ್ಯಗಳ ಶ್ರೇಣಿಯ ಎರಡು ತುದಿಗಳಂತೆ ವರ್ತಿಸಬೇಕಾಗಿದೆ, ಅಂದರೆ ಅವು "walk past each other" ಆಗುವುದಿಲ್ಲ.
///
/// # Examples
///
/// `char::Searcher` ಇದು `DoubleEndedSearcher` ಆಗಿದೆ ಏಕೆಂದರೆ [`char`] ಗಾಗಿ ಹುಡುಕಲು ಒಂದು ಸಮಯದಲ್ಲಿ ಒಂದನ್ನು ಮಾತ್ರ ನೋಡಬೇಕಾಗುತ್ತದೆ, ಅದು ಎರಡೂ ತುದಿಗಳಿಂದ ಒಂದೇ ರೀತಿ ವರ್ತಿಸುತ್ತದೆ.
///
/// `(&str)::Searcher` ಇದು `DoubleEndedSearcher` ಅಲ್ಲ ಏಕೆಂದರೆ ಹೇಸ್ಟಾಕ್ `"aaa"` ನಲ್ಲಿನ `"aa"` ಮಾದರಿಯು `"[aa]a"` ಅಥವಾ `"a[aa]"` ಆಗಿ ಹೊಂದಿಕೆಯಾಗುತ್ತದೆ, ಅದನ್ನು ಯಾವ ಕಡೆಯಿಂದ ಹುಡುಕಲಾಗುತ್ತದೆ ಎಂಬುದನ್ನು ಅವಲಂಬಿಸಿರುತ್ತದೆ.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// ಚಾರ್ಗಾಗಿ ಇಂಪ್ಲ್
/////////////////////////////////////////////////////////////////////////////

/// `<char as Pattern<'a>>::Searcher` ಗಾಗಿ ಸಂಯೋಜಿತ ಪ್ರಕಾರ.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // ಸುರಕ್ಷತಾ ಅಸ್ಥಿರತೆ: `finger`/`finger_back` `haystack` ನ ಮಾನ್ಯ utf8 ಬೈಟ್ ಸೂಚ್ಯಂಕವಾಗಿರಬೇಕು ಈ ಅಸ್ಥಿರತೆಯನ್ನು *ಮುಂದಿನ_ಮ್ಯಾಚ್ ಮತ್ತು ಮುಂದಿನ_ಮ್ಯಾಚ್_ಬ್ಯಾಕ್ ಒಳಗೆ* ಮುರಿಯಬಹುದು, ಆದರೆ ಅವು ಮಾನ್ಯ ಕೋಡ್ ಪಾಯಿಂಟ್ ಗಡಿಗಳಲ್ಲಿ ಬೆರಳುಗಳಿಂದ ನಿರ್ಗಮಿಸಬೇಕು.
    //
    //
    /// `finger` ಫಾರ್ವರ್ಡ್ ಹುಡುಕಾಟದ ಪ್ರಸ್ತುತ ಬೈಟ್ ಸೂಚ್ಯಂಕವಾಗಿದೆ.
    /// ಅದರ ಸೂಚ್ಯಂಕದಲ್ಲಿ ಬೈಟ್‌ಗೆ ಮೊದಲು ಅದು ಅಸ್ತಿತ್ವದಲ್ಲಿದೆ ಎಂದು g ಹಿಸಿ, ಅಂದರೆ
    /// `haystack[finger]` ಫಾರ್ವರ್ಡ್ ಹುಡುಕಾಟದ ಸಮಯದಲ್ಲಿ ನಾವು ಪರಿಶೀಲಿಸಬೇಕಾದ ಸ್ಲೈಸ್‌ನ ಮೊದಲ ಬೈಟ್ ಆಗಿದೆ
    ///
    finger: usize,
    /// `finger_back` ರಿವರ್ಸ್ ಹುಡುಕಾಟದ ಪ್ರಸ್ತುತ ಬೈಟ್ ಸೂಚ್ಯಂಕವಾಗಿದೆ.
    /// ಅದರ ಸೂಚ್ಯಂಕದಲ್ಲಿ ಬೈಟ್ ನಂತರ ಅದು ಅಸ್ತಿತ್ವದಲ್ಲಿದೆ ಎಂದು g ಹಿಸಿ, ಅಂದರೆ
    /// ಹೇಸ್ಟ್ಯಾಕ್ [ಫಿಂಗರ್_ಬ್ಯಾಕ್, 1] ಸ್ಲೈಸ್‌ನ ಕೊನೆಯ ಬೈಟ್ ಆಗಿದೆ, ಇದು ಫಾರ್ವರ್ಡ್ ಸರ್ಚಿಂಗ್ ಸಮಯದಲ್ಲಿ ನಾವು ಪರಿಶೀಲಿಸಬೇಕು (ಮತ್ತು next_back()) ಗೆ ಕರೆ ಮಾಡುವಾಗ ಪರಿಶೀಲಿಸಬೇಕಾದ ಮೊದಲ ಬೈಟ್.
    ///
    finger_back: usize,
    /// ಪಾತ್ರವನ್ನು ಹುಡುಕಲಾಗುತ್ತಿದೆ
    needle: char,

    // ಸುರಕ್ಷತಾ ಅಸ್ಥಿರತೆ: `utf8_size` 5 ಕ್ಕಿಂತ ಕಡಿಮೆಯಿರಬೇಕು
    /// utf8 ನಲ್ಲಿ ಎನ್ಕೋಡ್ ಮಾಡಿದಾಗ `needle` ಬೈಟ್‌ಗಳ ಸಂಖ್ಯೆ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    utf8_size: usize,
    /// `needle` ನ utf8 ಎನ್ಕೋಡ್ ಮಾಡಿದ ಪ್ರತಿ
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // ಸುರಕ್ಷತೆ: `get_unchecked` ನ 1-4 ಸುರಕ್ಷತೆಯ ಭರವಸೆ
        // 1. `self.finger` ಮತ್ತು `self.finger_back` ಅನ್ನು ಯುನಿಕೋಡ್ ಗಡಿಗಳಲ್ಲಿ ಇರಿಸಲಾಗುತ್ತದೆ (ಇದು ಅಸ್ಥಿರವಾಗಿದೆ)
        // 2. `self.finger >= 0` ಏಕೆಂದರೆ ಅದು 0 ರಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ ಮತ್ತು ಹೆಚ್ಚಾಗುತ್ತದೆ
        // 3. `self.finger < self.finger_back` ಏಕೆಂದರೆ ಇಲ್ಲದಿದ್ದರೆ `iter` ಚಾರ್ `SearchStep::Done` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ
        // 4.
        // `self.finger` ಬಣಬೆಯ ಅಂತ್ಯದ ಮೊದಲು ಬರುತ್ತದೆ ಏಕೆಂದರೆ `self.finger_back` ಕೊನೆಯಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ ಮತ್ತು ಕಡಿಮೆಯಾಗುತ್ತದೆ
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // utf-8 ನಂತೆ ಮರು-ಎನ್ಕೋಡಿಂಗ್ ಮಾಡದೆಯೇ ಪ್ರಸ್ತುತ ಅಕ್ಷರಗಳ ಬೈಟ್ ಆಫ್‌ಸೆಟ್ ಸೇರಿಸಿ
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // ಕೊನೆಯ ಅಕ್ಷರ ಕಂಡುಬಂದ ನಂತರ ಬಣಬೆ ಪಡೆಯಿರಿ
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // utf8 ಎನ್ಕೋಡ್ ಮಾಡಿದ ಸೂಜಿಯ ಕೊನೆಯ ಬೈಟ್ ಸುರಕ್ಷತೆ: ನಮ್ಮಲ್ಲಿ `utf8_size < 5` ಎಂಬ ಅಸ್ಥಿರತೆಯಿದೆ
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // ಹೊಸ ಬೆರಳು ನಾವು ಕಂಡುಕೊಂಡ ಬೈಟ್‌ನ ಸೂಚ್ಯಂಕವಾಗಿದೆ, ಜೊತೆಗೆ ಒಂದು, ಏಕೆಂದರೆ ನಾವು ಪಾತ್ರದ ಕೊನೆಯ ಬೈಟ್‌ಗಾಗಿ ನೆನಪಿಸಿಕೊಳ್ಳುತ್ತೇವೆ.
                //
                // ಇದು ಯಾವಾಗಲೂ ನಮಗೆ UTF8 ಗಡಿಯಲ್ಲಿ ಬೆರಳು ನೀಡುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
                // ನಮ್ಮ ಪಾತ್ರವನ್ನು ನಾವು *ಕಂಡುಹಿಡಿಯದಿದ್ದರೆ* ನಾವು 3-ಬೈಟ್ ಅಥವಾ 4-ಬೈಟ್ ಅಕ್ಷರಗಳ ಕೊನೆಯ ಬೈಟ್ಗೆ ಸೂಚ್ಯಂಕ ಮಾಡಿರಬಹುದು.
                // ನಾವು ಮುಂದಿನ ಮಾನ್ಯ ಆರಂಭಿಕ ಬೈಟ್‌ಗೆ ಹೋಗಲು ಸಾಧ್ಯವಿಲ್ಲ ಏಕೆಂದರೆ ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` ನಂತಹ ಅಕ್ಷರವು ಮೂರನೆಯದನ್ನು ಹುಡುಕುವಾಗ ಯಾವಾಗಲೂ ಎರಡನೇ ಬೈಟ್ ಅನ್ನು ಹುಡುಕುತ್ತದೆ.
                //
                //
                // ಆದಾಗ್ಯೂ, ಇದು ಸಂಪೂರ್ಣವಾಗಿ ಸರಿ.
                // self.finger UTF8 ಗಡಿಯಲ್ಲಿದೆ ಎಂಬ ಅಸ್ಥಿರತೆಯನ್ನು ನಾವು ಹೊಂದಿದ್ದರೂ, ಈ ಅಸ್ಥಿರತೆಯು ಈ ವಿಧಾನದ ಮೇಲೆ ಅವಲಂಬಿತವಾಗಿಲ್ಲ (ಇದು CharSearcher::next()) ನಲ್ಲಿ ಅವಲಂಬಿತವಾಗಿದೆ.
                //
                // ನಾವು ಸ್ಟ್ರಿಂಗ್‌ನ ಅಂತ್ಯವನ್ನು ತಲುಪಿದಾಗ ಅಥವಾ ನಾವು ಏನನ್ನಾದರೂ ಕಂಡುಕೊಂಡರೆ ಮಾತ್ರ ನಾವು ಈ ವಿಧಾನದಿಂದ ನಿರ್ಗಮಿಸುತ್ತೇವೆ.ನಾವು ಏನನ್ನಾದರೂ ಕಂಡುಕೊಂಡಾಗ `finger` ಅನ್ನು UTF8 ಗಡಿಗೆ ಹೊಂದಿಸಲಾಗುವುದು.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // ಏನೂ ಕಂಡುಬಂದಿಲ್ಲ, ನಿರ್ಗಮಿಸಿ
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // ಶೋಧಕ trait ನಿಂದ ಡೀಫಾಲ್ಟ್ ಅನುಷ್ಠಾನವನ್ನು ಬಳಸಲು ಮುಂದಿನ_ರೆಜೆಕ್ಟ್ ಅನ್ನು ಅನುಮತಿಸಿ
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // ಸುರಕ್ಷತೆ: ಮೇಲಿನ next() ಗಾಗಿ ಕಾಮೆಂಟ್ ನೋಡಿ
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // utf-8 ಎಂದು ಮರು-ಎನ್ಕೋಡಿಂಗ್ ಮಾಡದೆಯೇ ಪ್ರಸ್ತುತ ಅಕ್ಷರಗಳ ಬೈಟ್ ಆಫ್‌ಸೆಟ್ ಅನ್ನು ಕಳೆಯಿರಿ
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // ಕೊನೆಯದಾಗಿ ಹುಡುಕಿದ ಪಾತ್ರವನ್ನು ಒಳಗೊಂಡಂತೆ ಆದರೆ ಬಣಬೆ ಕಟ್ಟಿಕೊಳ್ಳಿ
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // utf8 ಎನ್ಕೋಡ್ ಮಾಡಿದ ಸೂಜಿಯ ಕೊನೆಯ ಬೈಟ್ ಸುರಕ್ಷತೆ: ನಮ್ಮಲ್ಲಿ `utf8_size < 5` ಎಂಬ ಅಸ್ಥಿರತೆಯಿದೆ
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // ನಾವು self.finger ನಿಂದ ಸರಿದೂಗಿಸಲಾದ ಸ್ಲೈಸ್ ಅನ್ನು ಹುಡುಕಿದ್ದೇವೆ, ಮೂಲ ಸೂಚ್ಯಂಕವನ್ನು ಮರುಪಡೆಯಲು self.finger ಅನ್ನು ಸೇರಿಸಿ
                //
                let index = self.finger + index;
                // ನಾವು ಹುಡುಕಲು ಬಯಸುವ ಬೈಟ್‌ನ ಸೂಚಿಯನ್ನು memrchr ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
                // ಎಎಸ್ಸಿಐಐ ಪಾತ್ರದ ಸಂದರ್ಭದಲ್ಲಿ, ನಮ್ಮ ಹೊಸ ಬೆರಳು ಇರಬೇಕೆಂದು ನಾವು ಬಯಸುತ್ತೇವೆ (ರಿವರ್ಸ್ ಪುನರಾವರ್ತನೆಯ ಮಾದರಿಯಲ್ಲಿ ಕಂಡುಬರುವ ಚಾರ್ "after").
                //
                // ಮಲ್ಟಿಬೈಟ್ ಅಕ್ಷರಗಳಿಗಾಗಿ, ಎಎಸ್ಸಿಐಐಗಿಂತ ಹೆಚ್ಚಿನ ಬೈಟ್‌ಗಳ ಸಂಖ್ಯೆಯನ್ನು ನಾವು ಬಿಟ್ಟುಬಿಡಬೇಕಾಗಿದೆ
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // ಅಕ್ಷರ ಕಂಡುಬರುವ ಮೊದಲು ಬೆರಳನ್ನು ಸರಿಸಿ (ಅಂದರೆ, ಅದರ ಪ್ರಾರಂಭ ಸೂಚ್ಯಂಕದಲ್ಲಿ)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // ನಾವು ಇಲ್ಲಿ ಫಿಂಗರ್_ಬ್ಯಾಕ್=ಸೂಚ್ಯಂಕ, ಗಾತ್ರ + 1 ಅನ್ನು ಬಳಸಲಾಗುವುದಿಲ್ಲ.
                // ವಿಭಿನ್ನ ಗಾತ್ರದ ಪಾತ್ರದ ಕೊನೆಯ ಚಾರ್ ಅನ್ನು ನಾವು ಕಂಡುಕೊಂಡರೆ (ಅಥವಾ ಬೇರೆ ಪಾತ್ರದ ಮಧ್ಯದ ಬೈಟ್) ನಾವು ಫಿಂಗರ್_ಬ್ಯಾಕ್ ಅನ್ನು `index` ಗೆ ಬಂಪ್ ಮಾಡಬೇಕಾಗಿದೆ.
                // ಇದು ಇದೇ ರೀತಿ `finger_back` ಗೆ ಇನ್ನು ಮುಂದೆ ಗಡಿಯಲ್ಲಿರಬಾರದು ಎಂಬ ಸಾಮರ್ಥ್ಯವನ್ನು ಹೊಂದಿದೆ, ಆದರೆ ನಾವು ಈ ಕಾರ್ಯವನ್ನು ಒಂದು ಗಡಿಯಲ್ಲಿ ಮಾತ್ರ ನಿರ್ಗಮಿಸುವುದರಿಂದ ಅಥವಾ ಹೇಸ್ಟಾಕ್ ಅನ್ನು ಸಂಪೂರ್ಣವಾಗಿ ಹುಡುಕಿದಾಗ ಇದು ಸರಿ.
                //
                //
                // ನೆಕ್ಸ್ಟ್_ಮ್ಯಾಚ್‌ಗಿಂತ ಭಿನ್ನವಾಗಿ ಇದು utf-8 ನಲ್ಲಿ ಪುನರಾವರ್ತಿತ ಬೈಟ್‌ಗಳ ಸಮಸ್ಯೆಯನ್ನು ಹೊಂದಿಲ್ಲ ಏಕೆಂದರೆ ನಾವು ಕೊನೆಯ ಬೈಟ್‌ಗಾಗಿ ಹುಡುಕುತ್ತಿದ್ದೇವೆ ಮತ್ತು ರಿವರ್ಸ್‌ನಲ್ಲಿ ಹುಡುಕುವಾಗ ಮಾತ್ರ ನಾವು ಕೊನೆಯ ಬೈಟ್ ಅನ್ನು ಕಂಡುಹಿಡಿಯಬಹುದು.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // ಏನೂ ಕಂಡುಬಂದಿಲ್ಲ, ನಿರ್ಗಮಿಸಿ
                return None;
            }
        }
    }

    // ಶೋಧಕ trait ನಿಂದ ಡೀಫಾಲ್ಟ್ ಅನುಷ್ಠಾನವನ್ನು ಬಳಸಲು next_reject_back ಅನ್ನು ಅನುಮತಿಸಿ
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// ನಿರ್ದಿಷ್ಟ [`char`] ಗೆ ಸಮಾನವಾದ ಅಕ್ಷರಗಳಿಗಾಗಿ ಹುಡುಕಾಟಗಳು.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// ಮಲ್ಟಿಚಾರ್ಇಕ್ ಹೊದಿಕೆಗಾಗಿ ಇಂಪ್ಲ್
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // ಪ್ರಸ್ತುತ ಚಾರ್ನ ಉದ್ದವನ್ನು ಕಂಡುಹಿಡಿಯಲು ಆಂತರಿಕ ಬೈಟ್ ಸ್ಲೈಸ್ ಇಟರೇಟರ್ನ ಉದ್ದಗಳನ್ನು ಹೋಲಿಕೆ ಮಾಡಿ
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // ಪ್ರಸ್ತುತ ಚಾರ್ನ ಉದ್ದವನ್ನು ಕಂಡುಹಿಡಿಯಲು ಆಂತರಿಕ ಬೈಟ್ ಸ್ಲೈಸ್ ಇಟರೇಟರ್ನ ಉದ್ದಗಳನ್ನು ಹೋಲಿಕೆ ಮಾಡಿ
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// &[ಚಾರ್] ಗಾಗಿ ಇಂಪ್ಲ್ ಮಾಡಿ
/////////////////////////////////////////////////////////////////////////////

// Todo: ಅರ್ಥದಲ್ಲಿನ ಅಸ್ಪಷ್ಟತೆಯಿಂದಾಗಿ ಬದಲಾಯಿಸಿ/ತೆಗೆದುಹಾಕಿ.

/// `<&[char] as Pattern<'a>>::Searcher` ಗಾಗಿ ಸಂಯೋಜಿತ ಪ್ರಕಾರ.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// ಸ್ಲೈಸ್‌ನಲ್ಲಿರುವ ಯಾವುದೇ [`ಚಾರ್`] ಗಳಿಗೆ ಸಮಾನವಾದ ಅಕ್ಷರಗಳಿಗಾಗಿ ಹುಡುಕಾಟಗಳು.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// F: FnMut(char)-> bool ಗಾಗಿ Impl
/////////////////////////////////////////////////////////////////////////////

/// `<F as Pattern<'a>>::Searcher` ಗಾಗಿ ಸಂಯೋಜಿತ ಪ್ರಕಾರ.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// ಕೊಟ್ಟಿರುವ ಮುನ್ಸೂಚನೆಗೆ ಹೊಂದಿಕೆಯಾಗುವ [`ಚಾರ್`] ಗಾಗಿ ಹುಡುಕಾಟಗಳು.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// &&str ಗಾಗಿ Impl
/////////////////////////////////////////////////////////////////////////////

/// `&str` impl ಗೆ ಪ್ರತಿನಿಧಿಗಳು.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// &str ಗಾಗಿ ಇಂಪ್ಲ್
/////////////////////////////////////////////////////////////////////////////

/// ಹಂಚಿಕೆ ಮಾಡದ ಸಬ್‌ಸ್ಟ್ರಿಂಗ್ ಹುಡುಕಾಟ.
///
/// ಪ್ರತಿ ಅಕ್ಷರ ಗಡಿಯಲ್ಲಿ ಖಾಲಿ ಪಂದ್ಯಗಳನ್ನು ಹಿಂದಿರುಗಿಸುವಂತೆ `""` ಮಾದರಿಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// ಮಾದರಿಯು ಹುಲ್ಲುಗಾವಲಿನ ಮುಂಭಾಗದಲ್ಲಿ ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// ಹೊಂದಿಕೆಯಾದರೆ, ಬಣವೆ ಮುಂಭಾಗದಿಂದ ಮಾದರಿಯನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // ಸುರಕ್ಷತೆ: ಅಸ್ತಿತ್ವದಲ್ಲಿದೆ ಎಂದು ಪೂರ್ವಪ್ರತ್ಯಯವನ್ನು ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// ಮಾದರಿಯು ಹುಲ್ಲುಗಾವಲಿನ ಹಿಂಭಾಗದಲ್ಲಿ ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// ಹೊಂದಾಣಿಕೆಯಾಗಿದ್ದರೆ, ಬಣಬೆಯ ಹಿಂಭಾಗದಿಂದ ಮಾದರಿಯನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // ಸುರಕ್ಷತೆ: ಅಸ್ತಿತ್ವದಲ್ಲಿದೆ ಎಂದು ಪ್ರತ್ಯಯವನ್ನು ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// ಟು ವೇ ಸಬ್ಸ್ಟ್ರಿಂಗ್ ಶೋಧಕ
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// `<&str as Pattern<'a>>::Searcher` ಗಾಗಿ ಸಂಯೋಜಿತ ಪ್ರಕಾರ.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // ಖಾಲಿ ಸೂಜಿ ಪ್ರತಿ ಚಾರ್ ಅನ್ನು ತಿರಸ್ಕರಿಸುತ್ತದೆ ಮತ್ತು ಅವುಗಳ ನಡುವಿನ ಪ್ರತಿಯೊಂದು ಖಾಲಿ ದಾರವನ್ನು ಹೊಂದಿಸುತ್ತದೆ
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // ಸರಿಯಾದ ಹೊಂದಾಣಿಕೆಯಾಗುವವರೆಗೂ ಚಾರ್ ಗಡಿಗಳಲ್ಲಿ ವಿಭಜಿಸುವ ಮಾನ್ಯ *ಹೊಂದಾಣಿಕೆ* ಸೂಚ್ಯಂಕಗಳನ್ನು ಟು ವೇಸರ್ಚರ್ ಉತ್ಪಾದಿಸುತ್ತದೆ ಮತ್ತು ಹುಲ್ಲುಗಾವಲು ಮತ್ತು ಸೂಜಿ ಮಾನ್ಯವಾಗಿರುತ್ತವೆ UTF-8 *ಅಲ್ಗಾರಿದಮ್‌ನಿಂದ ತಿರಸ್ಕರಿಸುತ್ತದೆ* ಯಾವುದೇ ಸೂಚ್ಯಂಕಗಳ ಮೇಲೆ ಬೀಳಬಹುದು, ಆದರೆ ನಾವು ಅವುಗಳನ್ನು ಮುಂದಿನ ಅಕ್ಷರಗಳ ಗಡಿಗೆ ಹಸ್ತಚಾಲಿತವಾಗಿ ನಡೆಸುತ್ತೇವೆ, ಆದ್ದರಿಂದ ಅವು utf-8 ಸುರಕ್ಷಿತವಾಗಿರುತ್ತವೆ.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // ಮುಂದಿನ ಚಾರ್ ಬೌಂಡರಿಗೆ ತೆರಳಿ
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // ಎರಡು ಪ್ರಕರಣಗಳನ್ನು ಪ್ರತ್ಯೇಕವಾಗಿ ಪರಿಣತಿಗೊಳಿಸಲು ಕಂಪೈಲರ್ ಅನ್ನು ಉತ್ತೇಜಿಸಲು `true` ಮತ್ತು `false` ಪ್ರಕರಣಗಳನ್ನು ಬರೆಯಿರಿ.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // ಮುಂದಿನ ಚಾರ್ ಬೌಂಡರಿಗೆ ತೆರಳಿ
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // `next_match` ನಂತೆ `true` ಮತ್ತು `false` ಅನ್ನು ಬರೆಯಿರಿ
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// ದ್ವಿಮುಖ ಸಬ್‌ಸ್ಟ್ರಿಂಗ್ ಹುಡುಕಾಟ ಅಲ್ಗಾರಿದಮ್‌ನ ಆಂತರಿಕ ಸ್ಥಿತಿ.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// ನಿರ್ಣಾಯಕ ಅಪವರ್ತನೀಕರಣ ಸೂಚ್ಯಂಕ
    crit_pos: usize,
    /// ವ್ಯತಿರಿಕ್ತ ಸೂಜಿಗೆ ನಿರ್ಣಾಯಕ ಅಪವರ್ತನೀಕರಣ ಸೂಚ್ಯಂಕ
    crit_pos_back: usize,
    period: usize,
    /// `byteset` ಒಂದು ವಿಸ್ತರಣೆಯಾಗಿದೆ (ದ್ವಿಮುಖ ಅಲ್ಗಾರಿದಮ್‌ನ ಭಾಗವಲ್ಲ);
    /// ಇದು 64-ಬಿಟ್ "fingerprint" ಆಗಿದೆ, ಅಲ್ಲಿ ಪ್ರತಿ ಸೆಟ್ ಬಿಟ್ `j` ಸೂಜಿಯಲ್ಲಿರುವ (ಬೈಟ್&63)==j ಗೆ ಅನುರೂಪವಾಗಿದೆ.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// ನಾವು ಈಗಾಗಲೇ ಹೊಂದಿಕೆಯಾಗುವ ಮೊದಲು ಸೂಜಿಗೆ ಸೂಚ್ಯಂಕ
    memory: usize,
    /// ಸೂಜಿಗೆ ಸೂಚ್ಯಂಕ ನಂತರ ನಾವು ಈಗಾಗಲೇ ಹೊಂದಿಕೆಯಾಗಿದ್ದೇವೆ
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // ಇಲ್ಲಿ ಏನು ನಡೆಯುತ್ತಿದೆ ಎಂಬುದರ ಬಗ್ಗೆ ನಿರ್ದಿಷ್ಟವಾಗಿ ಓದಬಲ್ಲ ವಿವರಣೆಯನ್ನು ಕ್ರೋಚೆಮೋರ್ ಮತ್ತು ರೈಟ್ಟರ್ ಅವರ ಪುಸ್ತಕ "Text Algorithms", ch 13 ನಲ್ಲಿ ಕಾಣಬಹುದು.
        // ನಿರ್ದಿಷ್ಟವಾಗಿ p ನಲ್ಲಿ "Algorithm CP" ಗಾಗಿ ಕೋಡ್ ನೋಡಿ.
        // 323.
        //
        // ಏನಾಗುತ್ತಿದೆ ಎಂದರೆ ನಾವು ಸೂಜಿಯ ಕೆಲವು ನಿರ್ಣಾಯಕ ಅಪವರ್ತನೀಕರಣವನ್ನು (ಯು, ವಿ) ಹೊಂದಿದ್ದೇವೆ ಮತ್ತು ಯು&ವಿ [.. ಅವಧಿಯ] ಪ್ರತ್ಯಯವಾಗಿದೆಯೇ ಎಂದು ನಾವು ನಿರ್ಧರಿಸಲು ಬಯಸುತ್ತೇವೆ.
        // ಅದು ಇದ್ದರೆ, ನಾವು "Algorithm CP1" ಅನ್ನು ಬಳಸುತ್ತೇವೆ.
        // ಇಲ್ಲದಿದ್ದರೆ ನಾವು "Algorithm CP2" ಅನ್ನು ಬಳಸುತ್ತೇವೆ, ಇದು ಸೂಜಿಯ ಅವಧಿ ದೊಡ್ಡದಾದಾಗ ಹೊಂದುವಂತೆ ಮಾಡುತ್ತದೆ.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // ಅಲ್ಪಾವಧಿಯ ಪ್ರಕರಣ-ಅವಧಿಯು ನಿಖರವಾದ ವ್ಯತಿರಿಕ್ತ ಸೂಜಿಗೆ ಪ್ರತ್ಯೇಕ ನಿರ್ಣಾಯಕ ಅಪವರ್ತನೀಕರಣವನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ x=u 'v' ಎಲ್ಲಿ | v '|<period(x).
            //
            // ಈಗಾಗಲೇ ತಿಳಿದಿರುವ ಅವಧಿಯಿಂದ ಇದನ್ನು ಹೆಚ್ಚಿಸಲಾಗಿದೆ.
            // X= "acba" ನಂತಹ ಪ್ರಕರಣವನ್ನು ನಿಖರವಾಗಿ ಫಾರ್ವರ್ಡ್ ಮಾಡಬಹುದು (ಕ್ರಿಟ್_ಪೋಸ್=1, ಅವಧಿ=3) ರಿವರ್ಸ್‌ನಲ್ಲಿ ಅಂದಾಜು ಅವಧಿಯೊಂದಿಗೆ ಅಪವರ್ತನೀಯವಾಗಿದ್ದರೆ (ಕ್ರಿಟ್_ಪೋಸ್=2, ಅವಧಿ=2).
            // ನಾವು ಕೊಟ್ಟಿರುವ ರಿವರ್ಸ್ ಫ್ಯಾಕ್ಟರೈಸೇಶನ್ ಅನ್ನು ಬಳಸುತ್ತೇವೆ ಆದರೆ ನಿಖರವಾದ ಅವಧಿಯನ್ನು ಇಡುತ್ತೇವೆ.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // ದೀರ್ಘಾವಧಿಯ ಪ್ರಕರಣ-ನಾವು ನಿಜವಾದ ಅವಧಿಗೆ ಅಂದಾಜು ಹೊಂದಿದ್ದೇವೆ ಮತ್ತು ಕಂಠಪಾಠವನ್ನು ಬಳಸಬೇಡಿ.
            //
            //
            // ಕಡಿಮೆ ಬೌಂಡ್ max(|u|, |v|) + 1 ಮೂಲಕ ಅವಧಿಯನ್ನು ಅಂದಾಜು ಮಾಡಿ.
            // ಫಾರ್ವರ್ಡ್ ಮತ್ತು ರಿವರ್ಸ್ ಸರ್ಚ್ ಎರಡಕ್ಕೂ ಬಳಸಲು ನಿರ್ಣಾಯಕ ಅಪವರ್ತನೀಕರಣವು ಪರಿಣಾಮಕಾರಿಯಾಗಿದೆ.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // ಅವಧಿ ಉದ್ದವಾಗಿದೆ ಎಂದು ಸೂಚಿಸಲು ನಕಲಿ ಮೌಲ್ಯ
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // ಎರಡು-ಮಾರ್ಗದ ಒಂದು ಮುಖ್ಯ ಆಲೋಚನೆಯೆಂದರೆ, ನಾವು ಸೂಜಿಯನ್ನು ಎರಡು ಭಾಗಗಳಾಗಿ (ಯು, ವಿ) ಅಪವರ್ತನಗೊಳಿಸುತ್ತೇವೆ ಮತ್ತು ಎಡದಿಂದ ಬಲಕ್ಕೆ ಸ್ಕ್ಯಾನ್ ಮಾಡುವ ಮೂಲಕ ಬಣಬೆಗಳಲ್ಲಿ ವಿ ಅನ್ನು ಕಂಡುಹಿಡಿಯಲು ಪ್ರಯತ್ನಿಸುತ್ತೇವೆ.
    // ವಿ ಹೊಂದಿಕೆಯಾದರೆ, ಬಲದಿಂದ ಎಡಕ್ಕೆ ಸ್ಕ್ಯಾನ್ ಮಾಡುವ ಮೂಲಕ ನಾವು ಯು ಅನ್ನು ಹೊಂದಿಸಲು ಪ್ರಯತ್ನಿಸುತ್ತೇವೆ.
    // ಹೊಂದಿಕೆಯಾಗದಿದ್ದಾಗ ನಾವು ಎಷ್ಟು ದೂರ ಹೋಗಬಹುದು (u, v) ಸೂಜಿಗೆ ನಿರ್ಣಾಯಕ ಅಂಶೀಕರಣವಾಗಿದೆ ಎಂಬ ಅಂಶವನ್ನು ಆಧರಿಸಿದೆ.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` `self.position` ಅನ್ನು ಅದರ ಕರ್ಸರ್ ಆಗಿ ಬಳಸುತ್ತದೆ
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // ಸ್ಥಾನದಲ್ಲಿ ಹುಡುಕಲು ನಮಗೆ ಸ್ಥಳವಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸಿ + ಚೂರುಗಳು ಐಸೈಜ್ ವ್ಯಾಪ್ತಿಯಿಂದ ಸುತ್ತುವರೆದಿದೆ ಎಂದು ನಾವು ಭಾವಿಸಿದರೆ ಸೂಜಿ_ಲ್ಯಾಸ್ಟ್ ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // ನಮ್ಮ ಸಬ್‌ಸ್ಟ್ರಿಂಗ್‌ಗೆ ಸಂಬಂಧವಿಲ್ಲದ ದೊಡ್ಡ ಭಾಗಗಳಿಂದ ತ್ವರಿತವಾಗಿ ಬಿಟ್ಟುಬಿಡಿ
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // ಸೂಜಿಯ ಬಲ ಭಾಗವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನೋಡಿ
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // ಸೂಜಿಯ ಎಡ ಭಾಗವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನೋಡಿ
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // ನಾವು ಪಂದ್ಯವನ್ನು ಕಂಡುಕೊಂಡಿದ್ದೇವೆ!
            let match_pos = self.position;

            // Note: ಅತಿಕ್ರಮಿಸುವ ಹೊಂದಾಣಿಕೆಗಳನ್ನು ಹೊಂದಲು needle.len() ಬದಲಿಗೆ self.period ಅನ್ನು ಸೇರಿಸಿ
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // ಅತಿಕ್ರಮಿಸುವ ಪಂದ್ಯಗಳಿಗಾಗಿ needle.len(), self.period ಗೆ ಹೊಂದಿಸಲಾಗಿದೆ
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `next()` ನಲ್ಲಿನ ಆಲೋಚನೆಗಳನ್ನು ಅನುಸರಿಸುತ್ತದೆ.
    //
    // ವ್ಯಾಖ್ಯಾನಗಳು ಸಮ್ಮಿತೀಯವಾಗಿದ್ದು, period(x) = period(reverse(x)) ಮತ್ತು local_period(u, v) = local_period(reverse(v), reverse(u)), ಆದ್ದರಿಂದ (u, v) ಒಂದು ನಿರ್ಣಾಯಕ ಅಪವರ್ತನೀಕರಣವಾಗಿದ್ದರೆ, (reverse(v), reverse(u)).
    //
    //
    // ರಿವರ್ಸ್ ಕೇಸ್‌ಗಾಗಿ ನಾವು x=u 'v' (ಫೀಲ್ಡ್ `crit_pos_back`) ಎಂಬ ನಿರ್ಣಾಯಕ ಅಪವರ್ತನೀಕರಣವನ್ನು ಲೆಕ್ಕ ಹಾಕಿದ್ದೇವೆ.ನಮಗೆ ಬೇಕು | ಯು |ಫಾರ್ವರ್ಡ್ ಕೇಸ್‌ಗಾಗಿ <period(x) ಮತ್ತು ಹೀಗೆ | v '|ಹಿಮ್ಮುಖಕ್ಕಾಗಿ <period(x).
    //
    // ಬಣಬೆ ಮೂಲಕ ಹಿಮ್ಮುಖವಾಗಿ ಹುಡುಕಲು, ಹಿಮ್ಮುಖ ಸೂಜಿಯೊಂದಿಗೆ ಹಿಮ್ಮುಖವಾದ ಬಣಬೆ ಮೂಲಕ ನಾವು ಮುಂದೆ ಹುಡುಕುತ್ತೇವೆ, ಮೊದಲು ಯು 'ಮತ್ತು ನಂತರ ವಿ' ಗೆ ಹೊಂದಿಕೆಯಾಗುತ್ತೇವೆ.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` `self.end` ಅನ್ನು ಅದರ ಕರ್ಸರ್ ಆಗಿ ಬಳಸುತ್ತದೆ-ಆದ್ದರಿಂದ `next()` ಮತ್ತು `next_back()` ಸ್ವತಂತ್ರವಾಗಿರುತ್ತವೆ.
        //
        let old_end = self.end;
        'search: loop {
            // ಕೊನೆಯಲ್ಲಿ ಹುಡುಕಲು ನಮಗೆ ಸ್ಥಳವಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸಿ, ಹೆಚ್ಚಿನ ಸ್ಥಳವಿಲ್ಲದಿದ್ದಾಗ needle.len() ಸುತ್ತಿಕೊಳ್ಳುತ್ತದೆ, ಆದರೆ ಸ್ಲೈಸ್ ಉದ್ದದ ಮಿತಿಗಳಿಂದಾಗಿ ಅದು ಎಂದಿಗೂ ಬಣಬೆ ಉದ್ದಕ್ಕೆ ಸುತ್ತಿಕೊಳ್ಳುವುದಿಲ್ಲ.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // ನಮ್ಮ ಸಬ್‌ಸ್ಟ್ರಿಂಗ್‌ಗೆ ಸಂಬಂಧವಿಲ್ಲದ ದೊಡ್ಡ ಭಾಗಗಳಿಂದ ತ್ವರಿತವಾಗಿ ಬಿಟ್ಟುಬಿಡಿ
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // ಸೂಜಿಯ ಎಡ ಭಾಗವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನೋಡಿ
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // ಸೂಜಿಯ ಬಲ ಭಾಗವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನೋಡಿ
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // ನಾವು ಪಂದ್ಯವನ್ನು ಕಂಡುಕೊಂಡಿದ್ದೇವೆ!
            let match_pos = self.end - needle.len();
            // Note: ಅತಿಕ್ರಮಿಸುವ ಹೊಂದಾಣಿಕೆಗಳನ್ನು ಹೊಂದಲು needle.len() ಬದಲಿಗೆ ಉಪ self.period
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `arr` ನ ಗರಿಷ್ಠ ಪ್ರತ್ಯಯವನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡಿ.
    //
    // ಗರಿಷ್ಠ ಪ್ರತ್ಯಯವು `arr` ನ ಸಂಭಾವ್ಯ ನಿರ್ಣಾಯಕ ಅಂಶೀಕರಣ (ಯು, ವಿ) ಆಗಿದೆ.
    //
    // ರಿಟರ್ನ್ಸ್ (`i`, `p`) ಅಲ್ಲಿ `i` ಎಂಬುದು v ನ ಆರಂಭಿಕ ಸೂಚ್ಯಂಕ ಮತ್ತು `p` ಎಂಬುದು v ನ ಅವಧಿಯಾಗಿದೆ.
    //
    // `order_greater` ಲೆಕ್ಸಿಕಲ್ ಆದೇಶವು `<` ಅಥವಾ `>` ಆಗಿದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುತ್ತದೆ.
    // ಎರಡೂ ಆದೇಶಗಳನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡಬೇಕು-ಅತಿದೊಡ್ಡ `i` ನೊಂದಿಗೆ ಆದೇಶವು ನಿರ್ಣಾಯಕ ಅಪವರ್ತನೀಕರಣವನ್ನು ನೀಡುತ್ತದೆ.
    //
    //
    // ದೀರ್ಘಾವಧಿಯ ಪ್ರಕರಣಗಳಿಗೆ, ಫಲಿತಾಂಶದ ಅವಧಿ ನಿಖರವಾಗಿಲ್ಲ (ಇದು ತುಂಬಾ ಚಿಕ್ಕದಾಗಿದೆ).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // ಕಾಗದದಲ್ಲಿ ನಾನು ಅನುರೂಪವಾಗಿದೆ
        let mut right = 1; // ಕಾಗದದಲ್ಲಿ ಜೆ ಗೆ ಅನುರೂಪವಾಗಿದೆ
        let mut offset = 0; // ಕಾಗದದಲ್ಲಿ k ಗೆ ಅನುರೂಪವಾಗಿದೆ, ಆದರೆ 0 ರಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ
        // 0 ಆಧಾರಿತ ಸೂಚ್ಯಂಕವನ್ನು ಹೊಂದಿಸಲು.
        let mut period = 1; // ಕಾಗದದಲ್ಲಿ p ಗೆ ಅನುರೂಪವಾಗಿದೆ

        while let Some(&a) = arr.get(right + offset) {
            // `left` `right` ಇದ್ದಾಗ ಒಳಬರುವಂತೆ ಇರುತ್ತದೆ.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // ಪ್ರತ್ಯಯ ಚಿಕ್ಕದಾಗಿದೆ, ಅವಧಿ ಇಲ್ಲಿಯವರೆಗೆ ಸಂಪೂರ್ಣ ಪೂರ್ವಪ್ರತ್ಯಯವಾಗಿದೆ.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // ಪ್ರಸ್ತುತ ಅವಧಿಯ ಪುನರಾವರ್ತನೆಯ ಮೂಲಕ ಮುನ್ನಡೆಯಿರಿ.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // ಪ್ರತ್ಯಯ ದೊಡ್ಡದಾಗಿದೆ, ಪ್ರಸ್ತುತ ಸ್ಥಳದಿಂದ ಪ್ರಾರಂಭಿಸಿ.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // `arr` ನ ಹಿಮ್ಮುಖದ ಗರಿಷ್ಠ ಪ್ರತ್ಯಯವನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡಿ.
    //
    // ಗರಿಷ್ಠ ಪ್ರತ್ಯಯವು `arr` ನ ಸಂಭಾವ್ಯ ನಿರ್ಣಾಯಕ ಅಪವರ್ತನೀಕರಣ (u ', v') ಆಗಿದೆ.
    //
    // `i` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಲ್ಲಿ `i` ಹಿಂದಿನಿಂದ v 'ನ ಆರಂಭಿಕ ಸೂಚ್ಯಂಕವಾಗಿದೆ;
    // `known_period` ಅವಧಿಯನ್ನು ತಲುಪಿದಾಗ ತಕ್ಷಣ ಮರಳುತ್ತದೆ.
    //
    // `order_greater` ಲೆಕ್ಸಿಕಲ್ ಆದೇಶವು `<` ಅಥವಾ `>` ಆಗಿದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುತ್ತದೆ.
    // ಎರಡೂ ಆದೇಶಗಳನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡಬೇಕು-ಅತಿದೊಡ್ಡ `i` ನೊಂದಿಗೆ ಆದೇಶವು ನಿರ್ಣಾಯಕ ಅಪವರ್ತನೀಕರಣವನ್ನು ನೀಡುತ್ತದೆ.
    //
    //
    // ದೀರ್ಘಾವಧಿಯ ಪ್ರಕರಣಗಳಿಗೆ, ಫಲಿತಾಂಶದ ಅವಧಿ ನಿಖರವಾಗಿಲ್ಲ (ಇದು ತುಂಬಾ ಚಿಕ್ಕದಾಗಿದೆ).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // ಕಾಗದದಲ್ಲಿ ನಾನು ಅನುರೂಪವಾಗಿದೆ
        let mut right = 1; // ಕಾಗದದಲ್ಲಿ ಜೆ ಗೆ ಅನುರೂಪವಾಗಿದೆ
        let mut offset = 0; // ಕಾಗದದಲ್ಲಿ k ಗೆ ಅನುರೂಪವಾಗಿದೆ, ಆದರೆ 0 ರಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ
        // 0 ಆಧಾರಿತ ಸೂಚ್ಯಂಕವನ್ನು ಹೊಂದಿಸಲು.
        let mut period = 1; // ಕಾಗದದಲ್ಲಿ p ಗೆ ಅನುರೂಪವಾಗಿದೆ
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // ಪ್ರತ್ಯಯ ಚಿಕ್ಕದಾಗಿದೆ, ಅವಧಿ ಇಲ್ಲಿಯವರೆಗೆ ಸಂಪೂರ್ಣ ಪೂರ್ವಪ್ರತ್ಯಯವಾಗಿದೆ.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // ಪ್ರಸ್ತುತ ಅವಧಿಯ ಪುನರಾವರ್ತನೆಯ ಮೂಲಕ ಮುನ್ನಡೆಯಿರಿ.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // ಪ್ರತ್ಯಯ ದೊಡ್ಡದಾಗಿದೆ, ಪ್ರಸ್ತುತ ಸ್ಥಳದಿಂದ ಪ್ರಾರಂಭಿಸಿ.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// ಎರಡು ವೇಸ್ಟ್ರಾಟಜಿ ಅಲ್ಗಾರಿದಮ್ ಅನ್ನು ಆದಷ್ಟು ಬೇಗನೆ ಹೊಂದಾಣಿಕೆಯಾಗದಂತೆ ಬಿಟ್ಟುಬಿಡಲು ಅಥವಾ ತಿರಸ್ಕರಿಸುವಿಕೆಯನ್ನು ತುಲನಾತ್ಮಕವಾಗಿ ತ್ವರಿತವಾಗಿ ಹೊರಸೂಸುವ ಮೋಡ್‌ನಲ್ಲಿ ಕೆಲಸ ಮಾಡಲು ಅನುಮತಿಸುತ್ತದೆ.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// ಸಾಧ್ಯವಾದಷ್ಟು ಬೇಗ ಮಧ್ಯಂತರಗಳನ್ನು ಹೊಂದಿಸಲು ಬಿಟ್ಟುಬಿಡಿ
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// ಹೊರಸೂಸುವಿಕೆಯನ್ನು ನಿಯಮಿತವಾಗಿ ಹೊರಸೂಸುತ್ತದೆ
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}