//! ಸ್ಟ್ರಿಂಗ್ ಕುಶಲತೆ.
//!
//! ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ, [`std::str`] ಮಾಡ್ಯೂಲ್ ನೋಡಿ.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. ಮಿತಿ ಮೀರಿದೆ
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. ಪ್ರಾರಂಭ <=ಅಂತ್ಯ
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. ಅಕ್ಷರ ಗಡಿ
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // ಪಾತ್ರವನ್ನು ಹುಡುಕಿ
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` ಲೆನ್ ಮತ್ತು ಚಾರ್ ಬೌಂಡರಿಗಿಂತ ಕಡಿಮೆಯಿರಬೇಕು
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// `self` ನ ಉದ್ದವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಉದ್ದವು ಬೈಟ್‌ಗಳಲ್ಲಿರುತ್ತದೆ, [`ಚಾರ್`] ಅಥವಾ ಗ್ರ್ಯಾಫೀಮ್‌ಗಳಲ್ಲ.
    /// ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, ದಾರದ ಉದ್ದವನ್ನು ಮನುಷ್ಯ ಪರಿಗಣಿಸುವಂತಿಲ್ಲ.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // ಅಲಂಕಾರಿಕ ಎಫ್!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// `self` ಶೂನ್ಯ ಬೈಟ್‌ಗಳ ಉದ್ದವನ್ನು ಹೊಂದಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// `ಇಂಡೆಕ್ಸ್`-ನೇ ಬೈಟ್ UTF-8 ಕೋಡ್ ಪಾಯಿಂಟ್ ಅನುಕ್ರಮದಲ್ಲಿನ ಮೊದಲ ಬೈಟ್ ಅಥವಾ ಸ್ಟ್ರಿಂಗ್‌ನ ಅಂತ್ಯ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ.
    ///
    ///
    /// ಸ್ಟ್ರಿಂಗ್‌ನ ಪ್ರಾರಂಭ ಮತ್ತು ಅಂತ್ಯ (`ಸೂಚ್ಯಂಕ== self.len()`) ಅನ್ನು ಗಡಿಗಳೆಂದು ಪರಿಗಣಿಸಿದಾಗ.
    ///
    /// `index` `self.len()` ಗಿಂತ ಹೆಚ್ಚಿದ್ದರೆ `false` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // `老` ನ ಪ್ರಾರಂಭ
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // `ö` ನ ಎರಡನೇ ಬೈಟ್
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // `老` ನ ಮೂರನೇ ಬೈಟ್
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 ಮತ್ತು ಲೆನ್ ಯಾವಾಗಲೂ ಸರಿ.
        // 0 ಗಾಗಿ ಸ್ಪಷ್ಟವಾಗಿ ಪರೀಕ್ಷಿಸಿ ಇದರಿಂದ ಅದು ಸುಲಭವಾಗಿ ಚೆಕ್ ಅನ್ನು ಉತ್ತಮಗೊಳಿಸುತ್ತದೆ ಮತ್ತು ಆ ಸಂದರ್ಭದಲ್ಲಿ ಓದುವ ಸ್ಟ್ರಿಂಗ್ ಡೇಟಾವನ್ನು ಬಿಟ್ಟುಬಿಡುತ್ತದೆ.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // ಇದು ಇದಕ್ಕೆ ಸಮಾನವಾದ ಬಿಟ್ ಮ್ಯಾಜಿಕ್ ಆಗಿದೆ: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಬೈಟ್ ಸ್ಲೈಸ್ ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    /// ಬೈಟ್ ಸ್ಲೈಸ್ ಅನ್ನು ಮತ್ತೆ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಆಗಿ ಪರಿವರ್ತಿಸಲು, [`from_utf8`] ಕಾರ್ಯವನ್ನು ಬಳಸಿ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // ಸುರಕ್ಷತೆ: ನಾವು ಒಂದೇ ರೀತಿಯ ವಿನ್ಯಾಸದೊಂದಿಗೆ ಎರಡು ಪ್ರಕಾರಗಳನ್ನು ಪರಿವರ್ತಿಸುವುದರಿಂದ ಸ್ಥಿರ ಧ್ವನಿ
        unsafe { mem::transmute(self) }
    }

    /// ರೂಪಾಂತರಿತ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ರೂಪಾಂತರಿತ ಬೈಟ್ ಸ್ಲೈಸ್‌ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// ಸಾಲವು ಮುಗಿಯುವ ಮೊದಲು ಮತ್ತು ಆಧಾರವಾಗಿರುವ `str` ಅನ್ನು ಬಳಸುವ ಮೊದಲು ಸ್ಲೈಸ್‌ನ ವಿಷಯವು ಮಾನ್ಯ UTF-8 ಎಂದು ಕರೆ ಮಾಡುವವರು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು.
    ///
    ///
    /// `str` ನ ವಿಷಯಗಳು ಮಾನ್ಯವಾಗಿಲ್ಲದ `str` ನ ಬಳಕೆ ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಯಾಗಿದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // ಸುರಕ್ಷತೆ: `str` ರಿಂದ `&str` ನಿಂದ `&[u8]` ಗೆ ಎರಕಹೊಯ್ದವು ಸುರಕ್ಷಿತವಾಗಿದೆ
        // `&[u8]` ನಂತೆಯೇ ಅದೇ ವಿನ್ಯಾಸವನ್ನು ಹೊಂದಿದೆ (libstd ಮಾತ್ರ ಈ ಖಾತರಿಯನ್ನು ನೀಡುತ್ತದೆ).
        // ಪಾಯಿಂಟರ್ ಡಿಫರೆನ್ಸ್ ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ಇದು ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖದಿಂದ ಬಂದಿದ್ದು ಅದು ಬರಹಗಳಿಗೆ ಮಾನ್ಯವಾಗಿರುತ್ತದೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ಸ್ಟ್ರಿಂಗ್ ಚೂರುಗಳು ಬೈಟ್‌ಗಳ ಸ್ಲೈಸ್ ಆಗಿರುವುದರಿಂದ, ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ [`u8`] ಗೆ ಸೂಚಿಸುತ್ತದೆ.
    /// ಈ ಪಾಯಿಂಟರ್ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನ ಮೊದಲ ಬೈಟ್‌ಗೆ ಸೂಚಿಸುತ್ತದೆ.
    ///
    /// ಹಿಂತಿರುಗಿದ ಪಾಯಿಂಟರ್ ಅನ್ನು ಎಂದಿಗೂ ಬರೆಯಲಾಗುವುದಿಲ್ಲ ಎಂದು ಕರೆ ಮಾಡುವವರು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು.
    /// ನೀವು ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನ ವಿಷಯಗಳನ್ನು ರೂಪಾಂತರಿಸಬೇಕಾದರೆ, [`as_mut_ptr`] ಬಳಸಿ.
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// ರೂಪಾಂತರಿತ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ಸ್ಟ್ರಿಂಗ್ ಚೂರುಗಳು ಬೈಟ್‌ಗಳ ಸ್ಲೈಸ್ ಆಗಿರುವುದರಿಂದ, ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ [`u8`] ಗೆ ಸೂಚಿಸುತ್ತದೆ.
    /// ಈ ಪಾಯಿಂಟರ್ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನ ಮೊದಲ ಬೈಟ್‌ಗೆ ಸೂಚಿಸುತ್ತದೆ.
    ///
    /// ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಮಾನ್ಯ UTF-8 ಆಗಿ ಉಳಿದಿರುವ ರೀತಿಯಲ್ಲಿ ಮಾತ್ರ ಮಾರ್ಪಾಡು ಆಗುತ್ತದೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳುವುದು ನಿಮ್ಮ ಜವಾಬ್ದಾರಿಯಾಗಿದೆ.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// `str` ನ ಸಬ್‌ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `str` ಅನ್ನು ಸೂಚಿಕೆ ಮಾಡಲು ಇದು ಭಯಪಡದ ಪರ್ಯಾಯವಾಗಿದೆ.
    /// ಸಮಾನ ಸೂಚ್ಯಂಕ ಕಾರ್ಯಾಚರಣೆಯು panic ಬಂದಾಗಲೆಲ್ಲಾ [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // ಸೂಚ್ಯಂಕಗಳು UTF-8 ಅನುಕ್ರಮ ಗಡಿಗಳಲ್ಲಿಲ್ಲ
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // ಮಿತಿ ಮೀರಿದೆ
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// `str` ನ ರೂಪಾಂತರಿತ ಸಬ್‌ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `str` ಅನ್ನು ಸೂಚಿಕೆ ಮಾಡಲು ಇದು ಭಯಪಡದ ಪರ್ಯಾಯವಾಗಿದೆ.
    /// ಸಮಾನ ಸೂಚ್ಯಂಕ ಕಾರ್ಯಾಚರಣೆಯು panic ಬಂದಾಗಲೆಲ್ಲಾ [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // ಸರಿಯಾದ ಉದ್ದ
    /// assert!(v.get_mut(0..5).is_some());
    /// // ಮಿತಿ ಮೀರಿದೆ
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// `str` ನ ಪರಿಶೀಲಿಸದ ಚಂದಾದಾರಿಕೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `str` ಅನ್ನು ಸೂಚಿಕೆ ಮಾಡಲು ಇದು ಪರೀಕ್ಷಿಸದ ಪರ್ಯಾಯವಾಗಿದೆ.
    ///
    /// # Safety
    ///
    /// ಈ ಪೂರ್ವಭಾವಿ ಷರತ್ತುಗಳು ತೃಪ್ತಿ ಹೊಂದಲು ಈ ಕಾರ್ಯದ ಕರೆ ಮಾಡುವವರು ಕಾರಣರು:
    ///
    /// * ಆರಂಭಿಕ ಸೂಚ್ಯಂಕವು ಅಂತ್ಯಗೊಳ್ಳುವ ಸೂಚಿಯನ್ನು ಮೀರಬಾರದು;
    /// * ಸೂಚ್ಯಂಕಗಳು ಮೂಲ ಸ್ಲೈಸ್‌ನ ಮಿತಿಯಲ್ಲಿರಬೇಕು;
    /// * ಸೂಚ್ಯಂಕಗಳು UTF-8 ಅನುಕ್ರಮ ಗಡಿಗಳಲ್ಲಿರಬೇಕು.
    ///
    /// ಅದು ವಿಫಲವಾದರೆ, ಹಿಂತಿರುಗಿದ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅಮಾನ್ಯ ಮೆಮೊರಿಯನ್ನು ಉಲ್ಲೇಖಿಸಬಹುದು ಅಥವಾ `str` ಪ್ರಕಾರದಿಂದ ಸಂವಹನಗೊಳ್ಳುವ ಅಸ್ಥಿರತೆಯನ್ನು ಉಲ್ಲಂಘಿಸಬಹುದು.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `get_unchecked` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು;
        // `self` ಸುರಕ್ಷಿತ ಉಲ್ಲೇಖವಾಗಿರುವುದರಿಂದ ಸ್ಲೈಸ್ ಡಿಫರೆನ್ಸೆಬಲ್ ಆಗಿದೆ.
        // ಹಿಂತಿರುಗಿದ ಪಾಯಿಂಟರ್ ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ `SliceIndex` ನ impls ಅದು ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು.
        unsafe { &*i.get_unchecked(self) }
    }

    /// `str` ನ ರೂಪಾಂತರಿತ, ಪರಿಶೀಲಿಸದ ಚಂದಾದಾರಿಕೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `str` ಅನ್ನು ಸೂಚಿಕೆ ಮಾಡಲು ಇದು ಪರೀಕ್ಷಿಸದ ಪರ್ಯಾಯವಾಗಿದೆ.
    ///
    /// # Safety
    ///
    /// ಈ ಪೂರ್ವಭಾವಿ ಷರತ್ತುಗಳು ತೃಪ್ತಿ ಹೊಂದಲು ಈ ಕಾರ್ಯದ ಕರೆ ಮಾಡುವವರು ಕಾರಣರು:
    ///
    /// * ಆರಂಭಿಕ ಸೂಚ್ಯಂಕವು ಅಂತ್ಯಗೊಳ್ಳುವ ಸೂಚಿಯನ್ನು ಮೀರಬಾರದು;
    /// * ಸೂಚ್ಯಂಕಗಳು ಮೂಲ ಸ್ಲೈಸ್‌ನ ಮಿತಿಯಲ್ಲಿರಬೇಕು;
    /// * ಸೂಚ್ಯಂಕಗಳು UTF-8 ಅನುಕ್ರಮ ಗಡಿಗಳಲ್ಲಿರಬೇಕು.
    ///
    /// ಅದು ವಿಫಲವಾದರೆ, ಹಿಂತಿರುಗಿದ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅಮಾನ್ಯ ಮೆಮೊರಿಯನ್ನು ಉಲ್ಲೇಖಿಸಬಹುದು ಅಥವಾ `str` ಪ್ರಕಾರದಿಂದ ಸಂವಹನಗೊಳ್ಳುವ ಅಸ್ಥಿರತೆಯನ್ನು ಉಲ್ಲಂಘಿಸಬಹುದು.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `get_unchecked_mut` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು;
        // `self` ಸುರಕ್ಷಿತ ಉಲ್ಲೇಖವಾಗಿರುವುದರಿಂದ ಸ್ಲೈಸ್ ಡಿಫರೆನ್ಸೆಬಲ್ ಆಗಿದೆ.
        // ಹಿಂತಿರುಗಿದ ಪಾಯಿಂಟರ್ ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ `SliceIndex` ನ impls ಅದು ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// ಸುರಕ್ಷತಾ ಪರಿಶೀಲನೆಗಳನ್ನು ಬೈಪಾಸ್ ಮಾಡುವ ಮೂಲಕ ಮತ್ತೊಂದು ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನಿಂದ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// ಇದನ್ನು ಸಾಮಾನ್ಯವಾಗಿ ಶಿಫಾರಸು ಮಾಡುವುದಿಲ್ಲ, ಎಚ್ಚರಿಕೆಯಿಂದ ಬಳಸಿ!ಸುರಕ್ಷಿತ ಪರ್ಯಾಯಕ್ಕಾಗಿ [`str`] ಮತ್ತು [`Index`] ನೋಡಿ.
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// ಈ ಹೊಸ ಸ್ಲೈಸ್ `begin` ನಿಂದ `end` ಗೆ ಹೋಗುತ್ತದೆ, ಇದರಲ್ಲಿ `begin` ಆದರೆ `end` ಹೊರತುಪಡಿಸಿ.
    ///
    /// ಬದಲಿಗೆ ರೂಪಾಂತರಿತ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಪಡೆಯಲು, [`slice_mut_unchecked`] ವಿಧಾನವನ್ನು ನೋಡಿ.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// ಈ ಕಾರ್ಯದ ಕರೆ ಮಾಡುವವರು ಮೂರು ಪೂರ್ವ ಷರತ್ತುಗಳನ್ನು ತೃಪ್ತಿಪಡಿಸುತ್ತಾರೆ:
    ///
    /// * `begin` `end` ಮೀರಬಾರದು.
    /// * `begin` ಮತ್ತು `end` ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನೊಳಗೆ ಬೈಟ್ ಸ್ಥಾನಗಳಾಗಿರಬೇಕು.
    /// * `begin` ಮತ್ತು `end` UTF-8 ಅನುಕ್ರಮ ಗಡಿಗಳಲ್ಲಿರಬೇಕು.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `get_unchecked` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು;
        // `self` ಸುರಕ್ಷಿತ ಉಲ್ಲೇಖವಾಗಿರುವುದರಿಂದ ಸ್ಲೈಸ್ ಡಿಫರೆನ್ಸೆಬಲ್ ಆಗಿದೆ.
        // ಹಿಂತಿರುಗಿದ ಪಾಯಿಂಟರ್ ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ `SliceIndex` ನ impls ಅದು ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// ಸುರಕ್ಷತಾ ಪರಿಶೀಲನೆಗಳನ್ನು ಬೈಪಾಸ್ ಮಾಡುವ ಮೂಲಕ ಮತ್ತೊಂದು ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನಿಂದ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    /// ಇದನ್ನು ಸಾಮಾನ್ಯವಾಗಿ ಶಿಫಾರಸು ಮಾಡುವುದಿಲ್ಲ, ಎಚ್ಚರಿಕೆಯಿಂದ ಬಳಸಿ!ಸುರಕ್ಷಿತ ಪರ್ಯಾಯಕ್ಕಾಗಿ [`str`] ಮತ್ತು [`IndexMut`] ನೋಡಿ.
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// ಈ ಹೊಸ ಸ್ಲೈಸ್ `begin` ನಿಂದ `end` ಗೆ ಹೋಗುತ್ತದೆ, ಇದರಲ್ಲಿ `begin` ಆದರೆ `end` ಹೊರತುಪಡಿಸಿ.
    ///
    /// ಬದಲಿಗೆ ಬದಲಾಯಿಸಲಾಗದ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಪಡೆಯಲು, [`slice_unchecked`] ವಿಧಾನವನ್ನು ನೋಡಿ.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// ಈ ಕಾರ್ಯದ ಕರೆ ಮಾಡುವವರು ಮೂರು ಪೂರ್ವ ಷರತ್ತುಗಳನ್ನು ತೃಪ್ತಿಪಡಿಸುತ್ತಾರೆ:
    ///
    /// * `begin` `end` ಮೀರಬಾರದು.
    /// * `begin` ಮತ್ತು `end` ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನೊಳಗೆ ಬೈಟ್ ಸ್ಥಾನಗಳಾಗಿರಬೇಕು.
    /// * `begin` ಮತ್ತು `end` UTF-8 ಅನುಕ್ರಮ ಗಡಿಗಳಲ್ಲಿರಬೇಕು.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `get_unchecked_mut` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು;
        // `self` ಸುರಕ್ಷಿತ ಉಲ್ಲೇಖವಾಗಿರುವುದರಿಂದ ಸ್ಲೈಸ್ ಡಿಫರೆನ್ಸೆಬಲ್ ಆಗಿದೆ.
        // ಹಿಂತಿರುಗಿದ ಪಾಯಿಂಟರ್ ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ `SliceIndex` ನ impls ಅದು ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// ಸೂಚ್ಯಂಕದಲ್ಲಿ ಒಂದು ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಎರಡು ಭಾಗಿಸಿ.
    ///
    /// `mid` ಎಂಬ ವಾದವು ಸ್ಟ್ರಿಂಗ್‌ನ ಪ್ರಾರಂಭದಿಂದ ಬೈಟ್ ಆಫ್‌ಸೆಟ್ ಆಗಿರಬೇಕು.
    /// ಇದು UTF-8 ಕೋಡ್ ಪಾಯಿಂಟ್‌ನ ಗಡಿಯಲ್ಲಿರಬೇಕು.
    ///
    /// ಹಿಂತಿರುಗಿದ ಎರಡು ಚೂರುಗಳು ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದಿಂದ `mid` ಗೆ ಮತ್ತು `mid` ನಿಂದ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನ ಅಂತ್ಯಕ್ಕೆ ಹೋಗುತ್ತವೆ.
    ///
    /// ಬದಲಿಗೆ ರೂಪಾಂತರಿತ ಸ್ಟ್ರಿಂಗ್ ಚೂರುಗಳನ್ನು ಪಡೆಯಲು, [`split_at_mut`] ವಿಧಾನವನ್ನು ನೋಡಿ.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// `mid` UTF-8 ಕೋಡ್ ಪಾಯಿಂಟ್ ಗಡಿಯಲ್ಲಿಲ್ಲದಿದ್ದರೆ ಅಥವಾ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನ ಕೊನೆಯ ಕೋಡ್ ಪಾಯಿಂಟ್‌ನ ಅಂತ್ಯವನ್ನು ಮೀರಿದ್ದರೆ Panics.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary ಸೂಚ್ಯಂಕವು [0, .len()]
        if self.is_char_boundary(mid) {
            // ಸುರಕ್ಷತೆ: `mid` ಚಾರ್ ಗಡಿಯಲ್ಲಿದೆ ಎಂದು ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// ಸೂಚ್ಯಂಕದಲ್ಲಿ ಒಂದು ರೂಪಾಂತರಿತ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಎರಡು ಭಾಗಿಸಿ.
    ///
    /// `mid` ಎಂಬ ವಾದವು ಸ್ಟ್ರಿಂಗ್‌ನ ಪ್ರಾರಂಭದಿಂದ ಬೈಟ್ ಆಫ್‌ಸೆಟ್ ಆಗಿರಬೇಕು.
    /// ಇದು UTF-8 ಕೋಡ್ ಪಾಯಿಂಟ್‌ನ ಗಡಿಯಲ್ಲಿರಬೇಕು.
    ///
    /// ಹಿಂತಿರುಗಿದ ಎರಡು ಚೂರುಗಳು ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದಿಂದ `mid` ಗೆ ಮತ್ತು `mid` ನಿಂದ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನ ಅಂತ್ಯಕ್ಕೆ ಹೋಗುತ್ತವೆ.
    ///
    /// ಬದಲಿಗೆ ಬದಲಾಯಿಸಲಾಗದ ಸ್ಟ್ರಿಂಗ್ ಚೂರುಗಳನ್ನು ಪಡೆಯಲು, [`split_at`] ವಿಧಾನವನ್ನು ನೋಡಿ.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// `mid` UTF-8 ಕೋಡ್ ಪಾಯಿಂಟ್ ಗಡಿಯಲ್ಲಿಲ್ಲದಿದ್ದರೆ ಅಥವಾ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನ ಕೊನೆಯ ಕೋಡ್ ಪಾಯಿಂಟ್‌ನ ಅಂತ್ಯವನ್ನು ಮೀರಿದ್ದರೆ Panics.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary ಸೂಚ್ಯಂಕವು [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // ಸುರಕ್ಷತೆ: `mid` ಚಾರ್ ಗಡಿಯಲ್ಲಿದೆ ಎಂದು ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನ [`ಚಾರ್`] ಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಮಾನ್ಯ UTF-8 ಅನ್ನು ಒಳಗೊಂಡಿರುವುದರಿಂದ, ನಾವು ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಮೂಲಕ [`char`] ನಿಂದ ಪುನರಾವರ್ತಿಸಬಹುದು.
    /// ಈ ವಿಧಾನವು ಅಂತಹ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [`char`] ಯುನಿಕೋಡ್ ಸ್ಕೇಲಾರ್ ಮೌಲ್ಯವನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ ಎಂಬುದನ್ನು ನೆನಪಿಟ್ಟುಕೊಳ್ಳುವುದು ಬಹಳ ಮುಖ್ಯ, ಮತ್ತು 'character' ಎಂದರೇನು ಎಂಬ ನಿಮ್ಮ ಕಲ್ಪನೆಗೆ ಹೊಂದಿಕೆಯಾಗುವುದಿಲ್ಲ.
    ///
    /// ಗ್ರ್ಯಾಫೀಮ್ ಕ್ಲಸ್ಟರ್‌ಗಳ ಮೇಲಿನ ಪುನರಾವರ್ತನೆಯು ನಿಮಗೆ ನಿಜವಾಗಿ ಬೇಕಾಗಿರಬಹುದು.
    /// ಈ ಕಾರ್ಯವನ್ನು Rust ನ ಸ್ಟ್ಯಾಂಡರ್ಡ್ ಲೈಬ್ರರಿಯಿಂದ ಒದಗಿಸಲಾಗಿಲ್ಲ, ಬದಲಿಗೆ crates.io ಅನ್ನು ಪರಿಶೀಲಿಸಿ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// ನೆನಪಿಡಿ, [`ಚಾರ್`] ಗಳು ಅಕ್ಷರಗಳ ಬಗ್ಗೆ ನಿಮ್ಮ ಅಂತಃಪ್ರಜ್ಞೆಗೆ ಹೊಂದಿಕೆಯಾಗುವುದಿಲ್ಲ:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // 'y̆' ಅಲ್ಲ
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನ [`ಚಾರ್`] ಗಳು ಮತ್ತು ಅವುಗಳ ಸ್ಥಾನಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಮಾನ್ಯ UTF-8 ಅನ್ನು ಒಳಗೊಂಡಿರುವುದರಿಂದ, ನಾವು ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಮೂಲಕ [`char`] ನಿಂದ ಪುನರಾವರ್ತಿಸಬಹುದು.
    /// ಈ ವಿಧಾನವು ಈ ಎರಡೂ [`ಚಾರ್`] ಗಳ ಪುನರಾವರ್ತಕವನ್ನು ಹಾಗೂ ಅವುಗಳ ಬೈಟ್ ಸ್ಥಾನಗಳನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಪುನರಾವರ್ತಕ ಟ್ಯುಪಲ್‌ಗಳನ್ನು ನೀಡುತ್ತದೆ.ಸ್ಥಾನವು ಮೊದಲನೆಯದು, [`char`] ಎರಡನೆಯದು.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// ನೆನಪಿಡಿ, [`ಚಾರ್`] ಗಳು ಅಕ್ಷರಗಳ ಬಗ್ಗೆ ನಿಮ್ಮ ಅಂತಃಪ್ರಜ್ಞೆಗೆ ಹೊಂದಿಕೆಯಾಗುವುದಿಲ್ಲ:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // ಅಲ್ಲ (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // ಇಲ್ಲಿ 3 ಅನ್ನು ಗಮನಿಸಿ, ಕೊನೆಯ ಅಕ್ಷರವು ಎರಡು ಬೈಟ್‌ಗಳನ್ನು ತೆಗೆದುಕೊಂಡಿತು
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನ ಬೈಟ್‌ಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ.
    ///
    /// ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಬೈಟ್‌ಗಳ ಅನುಕ್ರಮವನ್ನು ಒಳಗೊಂಡಿರುವುದರಿಂದ, ನಾವು ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಮೂಲಕ ಬೈಟ್ ಮೂಲಕ ಪುನರಾವರ್ತಿಸಬಹುದು.
    /// ಈ ವಿಧಾನವು ಅಂತಹ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// ಜಾಗದಿಂದ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ವಿಭಜಿಸುತ್ತದೆ.
    ///
    /// ಹಿಂದಿರುಗಿದ ಪುನರಾವರ್ತಕವು ಸ್ಟ್ರಿಂಗ್ ಚೂರುಗಳನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಅದು ಮೂಲ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನ ಉಪ-ಚೂರುಗಳಾಗಿರುತ್ತದೆ, ಇದನ್ನು ಯಾವುದೇ ಪ್ರಮಾಣದ ಜಾಗದಿಂದ ಬೇರ್ಪಡಿಸಲಾಗುತ್ತದೆ.
    ///
    ///
    /// 'Whitespace' ಯುನಿಕೋಡ್ ಪಡೆದ ಕೋರ್ ಪ್ರಾಪರ್ಟಿ `White_Space` ನ ನಿಯಮಗಳ ಪ್ರಕಾರ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿದೆ.
    /// ನೀವು ಬದಲಿಗೆ ASCII ಜಾಗದಲ್ಲಿ ಮಾತ್ರ ವಿಭಜಿಸಲು ಬಯಸಿದರೆ, [`split_ascii_whitespace`] ಬಳಸಿ.
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// ಎಲ್ಲಾ ರೀತಿಯ ಜಾಗವನ್ನು ಪರಿಗಣಿಸಲಾಗುತ್ತದೆ:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// ಎಎಸ್ಸಿಐಐ ಜಾಗದಿಂದ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ವಿಭಜಿಸುತ್ತದೆ.
    ///
    /// ಹಿಂದಿರುಗಿದ ಪುನರಾವರ್ತಕವು ಸ್ಟ್ರಿಂಗ್ ಚೂರುಗಳನ್ನು ಮೂಲ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನ ಉಪ-ಚೂರುಗಳಾಗಿ ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಇದನ್ನು ಯಾವುದೇ ಪ್ರಮಾಣದ ಎಎಸ್‌ಸಿಐಐ ಜಾಗದಿಂದ ಬೇರ್ಪಡಿಸಲಾಗುತ್ತದೆ.
    ///
    ///
    /// ಬದಲಿಗೆ ಯೂನಿಕೋಡ್ `Whitespace` ನಿಂದ ವಿಭಜಿಸಲು, [`split_whitespace`] ಬಳಸಿ.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// ಎಲ್ಲಾ ರೀತಿಯ ಎಎಸ್ಸಿಐಐ ಜಾಗಗಳನ್ನು ಪರಿಗಣಿಸಲಾಗುತ್ತದೆ:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// ಸ್ಟ್ರಿಂಗ್ ಚೂರುಗಳಂತೆ ಸ್ಟ್ರಿಂಗ್‌ನ ರೇಖೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ.
    ///
    /// ಲೈನ್‌ಗಳನ್ನು ಹೊಸ ಲೈನ್ (`\n`) ಅಥವಾ ಲೈನ್ ಫೀಡ್ (`\r\n`) ನೊಂದಿಗೆ ಕ್ಯಾರೇಜ್ ರಿಟರ್ನ್‌ನೊಂದಿಗೆ ಕೊನೆಗೊಳಿಸಲಾಗುತ್ತದೆ.
    ///
    /// ಅಂತಿಮ ಸಾಲಿನ ಅಂತ್ಯವು ಐಚ್ .ಿಕವಾಗಿರುತ್ತದೆ.
    /// ಅಂತಿಮ ಸಾಲಿನ ಅಂತ್ಯದೊಂದಿಗೆ ಕೊನೆಗೊಳ್ಳುವ ಸ್ಟ್ರಿಂಗ್ ಅಂತಿಮ ರೇಖೆಯ ಅಂತ್ಯವಿಲ್ಲದೆ ಅದೇ ಸಾಲುಗಳನ್ನು ಇಲ್ಲದಿದ್ದರೆ ಒಂದೇ ರೀತಿಯ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// ಅಂತಿಮ ಸಾಲಿನ ಅಂತ್ಯದ ಅಗತ್ಯವಿಲ್ಲ:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// ಸ್ಟ್ರಿಂಗ್‌ನ ರೇಖೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// UTF-16 ಎಂದು ಎನ್ಕೋಡ್ ಮಾಡಲಾದ ಸ್ಟ್ರಿಂಗ್ ಮೇಲೆ `u16` ನ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// ಕೊಟ್ಟಿರುವ ಮಾದರಿಯು ಈ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನ ಉಪ-ಸ್ಲೈಸ್‌ಗೆ ಹೊಂದಿಕೆಯಾದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `false` ಇಲ್ಲದಿದ್ದರೆ ಅದನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [pattern] ಒಂದು `&str`, [`char`], [`ಚಾರ್`] ನ ಸ್ಲೈಸ್ ಆಗಿರಬಹುದು ಅಥವಾ ಒಂದು ಪಾತ್ರವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುವ ಕಾರ್ಯ ಅಥವಾ ಮುಚ್ಚುವಿಕೆ ಆಗಿರಬಹುದು.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// ಕೊಟ್ಟಿರುವ ಮಾದರಿಯು ಈ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನ ಪೂರ್ವಪ್ರತ್ಯಯಕ್ಕೆ ಹೊಂದಿಕೆಯಾದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `false` ಇಲ್ಲದಿದ್ದರೆ ಅದನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [pattern] ಒಂದು `&str`, [`char`], [`ಚಾರ್`] ನ ಸ್ಲೈಸ್ ಆಗಿರಬಹುದು ಅಥವಾ ಒಂದು ಪಾತ್ರವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುವ ಕಾರ್ಯ ಅಥವಾ ಮುಚ್ಚುವಿಕೆ ಆಗಿರಬಹುದು.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// ಕೊಟ್ಟಿರುವ ಮಾದರಿಯು ಈ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನ ಪ್ರತ್ಯಯಕ್ಕೆ ಹೊಂದಿಕೆಯಾದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `false` ಇಲ್ಲದಿದ್ದರೆ ಅದನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [pattern] ಒಂದು `&str`, [`char`], [`ಚಾರ್`] ನ ಸ್ಲೈಸ್ ಆಗಿರಬಹುದು ಅಥವಾ ಒಂದು ಪಾತ್ರವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುವ ಕಾರ್ಯ ಅಥವಾ ಮುಚ್ಚುವಿಕೆ ಆಗಿರಬಹುದು.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// ಮಾದರಿಗೆ ಹೊಂದಿಕೆಯಾಗುವ ಈ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನ ಮೊದಲ ಅಕ್ಷರಗಳ ಬೈಟ್ ಸೂಚಿಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಮಾದರಿ ಹೊಂದಿಕೆಯಾಗದಿದ್ದರೆ [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [pattern] ಒಂದು `&str`, [`char`], [`ಚಾರ್`] ನ ಸ್ಲೈಸ್ ಆಗಿರಬಹುದು ಅಥವಾ ಒಂದು ಪಾತ್ರವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುವ ಕಾರ್ಯ ಅಥವಾ ಮುಚ್ಚುವಿಕೆ ಆಗಿರಬಹುದು.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ಸರಳ ಮಾದರಿಗಳು:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// ಪಾಯಿಂಟ್-ಮುಕ್ತ ಶೈಲಿ ಮತ್ತು ಮುಚ್ಚುವಿಕೆಗಳನ್ನು ಬಳಸಿಕೊಂಡು ಹೆಚ್ಚು ಸಂಕೀರ್ಣ ಮಾದರಿಗಳು:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// ಮಾದರಿಯನ್ನು ಕಂಡುಹಿಡಿಯುತ್ತಿಲ್ಲ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// ಈ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನಲ್ಲಿರುವ ಮಾದರಿಯ ಬಲಗಡೆಯ ಹೊಂದಾಣಿಕೆಯ ಮೊದಲ ಅಕ್ಷರಕ್ಕಾಗಿ ಬೈಟ್ ಸೂಚಿಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಮಾದರಿ ಹೊಂದಿಕೆಯಾಗದಿದ್ದರೆ [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [pattern] ಒಂದು `&str`, [`char`], [`ಚಾರ್`] ನ ಸ್ಲೈಸ್ ಆಗಿರಬಹುದು ಅಥವಾ ಒಂದು ಪಾತ್ರವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುವ ಕಾರ್ಯ ಅಥವಾ ಮುಚ್ಚುವಿಕೆ ಆಗಿರಬಹುದು.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ಸರಳ ಮಾದರಿಗಳು:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// ಮುಚ್ಚುವಿಕೆಯೊಂದಿಗೆ ಹೆಚ್ಚು ಸಂಕೀರ್ಣ ಮಾದರಿಗಳು:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// ಮಾದರಿಯನ್ನು ಕಂಡುಹಿಡಿಯುತ್ತಿಲ್ಲ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// ಈ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನ ಸಬ್‌ಸ್ಟ್ರಿಂಗ್‌ಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ, ಒಂದು ಮಾದರಿಯಿಂದ ಹೊಂದಿಕೆಯಾಗುವ ಅಕ್ಷರಗಳಿಂದ ಬೇರ್ಪಡಿಸಲಾಗಿದೆ.
    ///
    /// [pattern] ಒಂದು `&str`, [`char`], [`ಚಾರ್`] ನ ಸ್ಲೈಸ್ ಆಗಿರಬಹುದು ಅಥವಾ ಒಂದು ಪಾತ್ರವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುವ ಕಾರ್ಯ ಅಥವಾ ಮುಚ್ಚುವಿಕೆ ಆಗಿರಬಹುದು.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ಪುನರಾವರ್ತಕ ವರ್ತನೆ
    ///
    /// ಮಾದರಿಯು ಹಿಮ್ಮುಖ ಹುಡುಕಾಟವನ್ನು ಅನುಮತಿಸಿದರೆ ಮತ್ತು forward/reverse ಹುಡುಕಾಟವು ಅದೇ ಅಂಶಗಳನ್ನು ನೀಡುತ್ತದೆ. ಹಿಂತಿರುಗಿದ ಪುನರಾವರ್ತಕವು [`DoubleEndedIterator`] ಆಗಿರುತ್ತದೆ.
    /// ಇದು ನಿಜ, ಉದಾ, [`char`], ಆದರೆ `&str` ಗೆ ಅಲ್ಲ.
    ///
    /// ಮಾದರಿಯು ಹಿಮ್ಮುಖ ಹುಡುಕಾಟವನ್ನು ಅನುಮತಿಸಿದರೆ ಆದರೆ ಅದರ ಫಲಿತಾಂಶಗಳು ಫಾರ್ವರ್ಡ್ ಹುಡುಕಾಟದಿಂದ ಭಿನ್ನವಾಗಿರಬಹುದು, [`rsplit`] ವಿಧಾನವನ್ನು ಬಳಸಬಹುದು.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// ಸರಳ ಮಾದರಿಗಳು:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// ಮಾದರಿಯು ಅಕ್ಷರಗಳ ಸ್ಲೈಸ್ ಆಗಿದ್ದರೆ, ಯಾವುದೇ ಪಾತ್ರಗಳ ಪ್ರತಿಯೊಂದು ಘಟನೆಯ ಮೇಲೆ ವಿಭಜಿಸಿ:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// ಮುಚ್ಚುವಿಕೆಯನ್ನು ಬಳಸಿಕೊಂಡು ಹೆಚ್ಚು ಸಂಕೀರ್ಣವಾದ ಮಾದರಿ:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// ಸ್ಟ್ರಿಂಗ್ ಅನೇಕ ಅನುಕ್ರಮ ವಿಭಜಕಗಳನ್ನು ಹೊಂದಿದ್ದರೆ, ನೀವು output ಟ್‌ಪುಟ್‌ನಲ್ಲಿ ಖಾಲಿ ತಂತಿಗಳೊಂದಿಗೆ ಕೊನೆಗೊಳ್ಳುತ್ತೀರಿ:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// ಸತತ ವಿಭಜಕಗಳನ್ನು ಖಾಲಿ ದಾರದಿಂದ ಬೇರ್ಪಡಿಸಲಾಗುತ್ತದೆ.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// ಸ್ಟ್ರಿಂಗ್‌ನ ಪ್ರಾರಂಭ ಅಥವಾ ಕೊನೆಯಲ್ಲಿರುವ ವಿಭಜಕಗಳನ್ನು ಖಾಲಿ ತಂತಿಗಳಿಂದ ನೆರೆಯಲಾಗುತ್ತದೆ.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// ಖಾಲಿ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ವಿಭಜಕವಾಗಿ ಬಳಸಿದಾಗ, ಅದು ಸ್ಟ್ರಿಂಗ್‌ನ ಪ್ರತಿಯೊಂದು ಅಕ್ಷರವನ್ನು ಪ್ರತ್ಯೇಕಿಸುತ್ತದೆ, ಜೊತೆಗೆ ಸ್ಟ್ರಿಂಗ್‌ನ ಪ್ರಾರಂಭ ಮತ್ತು ಅಂತ್ಯ.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// ವೈಟ್‌ಸ್ಪೇಸ್ ಅನ್ನು ವಿಭಜಕವಾಗಿ ಬಳಸಿದಾಗ ಪರಸ್ಪರ ವಿಭಜಕಗಳು ಬಹುಶಃ ಆಶ್ಚರ್ಯಕರ ವರ್ತನೆಗೆ ಕಾರಣವಾಗಬಹುದು.ಈ ಕೋಡ್ ಸರಿಯಾಗಿದೆ:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// ಇದು _not_ ನಿಮಗೆ ನೀಡುತ್ತದೆ:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// ಈ ನಡವಳಿಕೆಗಾಗಿ [`split_whitespace`] ಬಳಸಿ.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// ಈ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನ ಸಬ್‌ಸ್ಟ್ರಿಂಗ್‌ಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ, ಒಂದು ಮಾದರಿಯಿಂದ ಹೊಂದಿಕೆಯಾಗುವ ಅಕ್ಷರಗಳಿಂದ ಬೇರ್ಪಡಿಸಲಾಗಿದೆ.
    /// ಆ `split_inclusive` ನಲ್ಲಿ `split` ನಿಂದ ಉತ್ಪತ್ತಿಯಾಗುವ ಪುನರಾವರ್ತಕದಿಂದ ಭಿನ್ನವಾಗಿದೆ, ಹೊಂದಿಕೆಯಾದ ಭಾಗವನ್ನು ಸಬ್‌ಸ್ಟ್ರಿಂಗ್‌ನ ಟರ್ಮಿನೇಟರ್ ಆಗಿ ಬಿಡುತ್ತದೆ.
    ///
    ///
    /// [pattern] ಒಂದು `&str`, [`char`], [`ಚಾರ್`] ನ ಸ್ಲೈಸ್ ಆಗಿರಬಹುದು ಅಥವಾ ಒಂದು ಪಾತ್ರವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುವ ಕಾರ್ಯ ಅಥವಾ ಮುಚ್ಚುವಿಕೆ ಆಗಿರಬಹುದು.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// ಸ್ಟ್ರಿಂಗ್‌ನ ಕೊನೆಯ ಅಂಶವು ಹೊಂದಿಕೆಯಾದರೆ, ಆ ಅಂಶವನ್ನು ಹಿಂದಿನ ಸಬ್‌ಸ್ಟ್ರಿಂಗ್‌ನ ಟರ್ಮಿನೇಟರ್ ಎಂದು ಪರಿಗಣಿಸಲಾಗುತ್ತದೆ.
    /// ಆ ತಲಾಧಾರವು ಪುನರಾವರ್ತಕರಿಂದ ಹಿಂತಿರುಗಿಸಲಾದ ಕೊನೆಯ ಐಟಂ ಆಗಿರುತ್ತದೆ.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// ಕೊಟ್ಟಿರುವ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನ ಸಬ್‌ಸ್ಟ್ರಿಂಗ್‌ಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ, ಒಂದು ಮಾದರಿಯಿಂದ ಹೊಂದಿಕೆಯಾಗುವ ಅಕ್ಷರಗಳಿಂದ ಬೇರ್ಪಡಿಸಿ ಹಿಮ್ಮುಖ ಕ್ರಮದಲ್ಲಿ ನೀಡಲಾಗುತ್ತದೆ.
    ///
    /// [pattern] ಒಂದು `&str`, [`char`], [`ಚಾರ್`] ನ ಸ್ಲೈಸ್ ಆಗಿರಬಹುದು ಅಥವಾ ಒಂದು ಪಾತ್ರವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುವ ಕಾರ್ಯ ಅಥವಾ ಮುಚ್ಚುವಿಕೆ ಆಗಿರಬಹುದು.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ಪುನರಾವರ್ತಕ ವರ್ತನೆ
    ///
    /// ಹಿಂತಿರುಗಿದ ಪುನರಾವರ್ತಕವು ಮಾದರಿಯು ಹಿಮ್ಮುಖ ಹುಡುಕಾಟವನ್ನು ಬೆಂಬಲಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು forward/reverse ಹುಡುಕಾಟವು ಅದೇ ಅಂಶಗಳನ್ನು ನೀಡಿದರೆ ಅದು [`DoubleEndedIterator`] ಆಗಿರುತ್ತದೆ.
    ///
    ///
    /// ಮುಂಭಾಗದಿಂದ ಪುನರಾವರ್ತಿಸಲು, [`split`] ವಿಧಾನವನ್ನು ಬಳಸಬಹುದು.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// ಸರಳ ಮಾದರಿಗಳು:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// ಮುಚ್ಚುವಿಕೆಯನ್ನು ಬಳಸಿಕೊಂಡು ಹೆಚ್ಚು ಸಂಕೀರ್ಣವಾದ ಮಾದರಿ:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// ಕೊಟ್ಟಿರುವ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನ ಸಬ್‌ಸ್ಟ್ರಿಂಗ್‌ಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ, ಒಂದು ಮಾದರಿಯಿಂದ ಹೊಂದಿಕೆಯಾಗುವ ಅಕ್ಷರಗಳಿಂದ ಬೇರ್ಪಡಿಸಲಾಗಿದೆ.
    ///
    /// [pattern] ಒಂದು `&str`, [`char`], [`ಚಾರ್`] ನ ಸ್ಲೈಸ್ ಆಗಿರಬಹುದು ಅಥವಾ ಒಂದು ಪಾತ್ರವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುವ ಕಾರ್ಯ ಅಥವಾ ಮುಚ್ಚುವಿಕೆ ಆಗಿರಬಹುದು.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] ಗೆ ಸಮನಾಗಿರುತ್ತದೆ, ಖಾಲಿ ಇದ್ದರೆ ಹಿಂದುಳಿದ ತಲಾಧಾರವನ್ನು ಬಿಟ್ಟುಬಿಡಲಾಗುತ್ತದೆ.
    ///
    /// [`split`]: str::split
    ///
    /// ಈ ವಿಧಾನವನ್ನು _separated_ ಗಿಂತ _terminated_ ಸ್ಟ್ರಿಂಗ್ ಡೇಟಾಗೆ ಬಳಸಬಹುದು.
    ///
    /// # ಪುನರಾವರ್ತಕ ವರ್ತನೆ
    ///
    /// ಮಾದರಿಯು ಹಿಮ್ಮುಖ ಹುಡುಕಾಟವನ್ನು ಅನುಮತಿಸಿದರೆ ಮತ್ತು forward/reverse ಹುಡುಕಾಟವು ಅದೇ ಅಂಶಗಳನ್ನು ನೀಡುತ್ತದೆ. ಹಿಂತಿರುಗಿದ ಪುನರಾವರ್ತಕವು [`DoubleEndedIterator`] ಆಗಿರುತ್ತದೆ.
    /// ಇದು ನಿಜ, ಉದಾ, [`char`], ಆದರೆ `&str` ಗೆ ಅಲ್ಲ.
    ///
    /// ಮಾದರಿಯು ಹಿಮ್ಮುಖ ಹುಡುಕಾಟವನ್ನು ಅನುಮತಿಸಿದರೆ ಆದರೆ ಅದರ ಫಲಿತಾಂಶಗಳು ಫಾರ್ವರ್ಡ್ ಹುಡುಕಾಟದಿಂದ ಭಿನ್ನವಾಗಿರಬಹುದು, [`rsplit_terminator`] ವಿಧಾನವನ್ನು ಬಳಸಬಹುದು.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// `self` ನ ಸಬ್‌ಸ್ಟ್ರಿಂಗ್‌ಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ, ಒಂದು ಮಾದರಿಯಿಂದ ಹೊಂದಿಕೆಯಾಗುವ ಅಕ್ಷರಗಳಿಂದ ಬೇರ್ಪಡಿಸಲಾಗಿದೆ ಮತ್ತು ಹಿಮ್ಮುಖ ಕ್ರಮದಲ್ಲಿ ಬರುತ್ತದೆ.
    ///
    /// [pattern] ಒಂದು `&str`, [`char`], [`ಚಾರ್`] ನ ಸ್ಲೈಸ್ ಆಗಿರಬಹುದು ಅಥವಾ ಒಂದು ಪಾತ್ರವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುವ ಕಾರ್ಯ ಅಥವಾ ಮುಚ್ಚುವಿಕೆ ಆಗಿರಬಹುದು.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] ಗೆ ಸಮನಾಗಿರುತ್ತದೆ, ಖಾಲಿ ಇದ್ದರೆ ಹಿಂದುಳಿದ ತಲಾಧಾರವನ್ನು ಬಿಟ್ಟುಬಿಡಲಾಗುತ್ತದೆ.
    ///
    /// [`split`]: str::split
    ///
    /// ಈ ವಿಧಾನವನ್ನು _separated_ ಗಿಂತ _terminated_ ಸ್ಟ್ರಿಂಗ್ ಡೇಟಾಗೆ ಬಳಸಬಹುದು.
    ///
    /// # ಪುನರಾವರ್ತಕ ವರ್ತನೆ
    ///
    /// ಹಿಂತಿರುಗಿದ ಪುನರಾವರ್ತಕವು ಮಾದರಿಯು ಹಿಮ್ಮುಖ ಹುಡುಕಾಟವನ್ನು ಬೆಂಬಲಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು forward/reverse ಹುಡುಕಾಟವು ಅದೇ ಅಂಶಗಳನ್ನು ನೀಡಿದರೆ ಅದು ಡಬಲ್ ಎಂಡ್ ಆಗಿರುತ್ತದೆ.
    ///
    ///
    /// ಮುಂಭಾಗದಿಂದ ಪುನರಾವರ್ತಿಸಲು, [`split_terminator`] ವಿಧಾನವನ್ನು ಬಳಸಬಹುದು.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// ಕೊಟ್ಟಿರುವ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನ ಸಬ್‌ಸ್ಟ್ರಿಂಗ್‌ಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ, ಒಂದು ಮಾದರಿಯಿಂದ ಬೇರ್ಪಡಿಸಲಾಗಿದೆ, ಹೆಚ್ಚಿನ `n` ವಸ್ತುಗಳನ್ನು ಹಿಂತಿರುಗಿಸಲು ನಿರ್ಬಂಧಿಸಲಾಗಿದೆ.
    ///
    /// `n` ಸಬ್‌ಸ್ಟ್ರಿಂಗ್‌ಗಳನ್ನು ಹಿಂತಿರುಗಿಸಿದರೆ, ಕೊನೆಯ ಸಬ್‌ಸ್ಟ್ರಿಂಗ್ (`n` ನೇ ಸಬ್‌ಸ್ಟ್ರಿಂಗ್) ಸ್ಟ್ರಿಂಗ್‌ನ ಉಳಿದ ಭಾಗವನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    ///
    /// [pattern] ಒಂದು `&str`, [`char`], [`ಚಾರ್`] ನ ಸ್ಲೈಸ್ ಆಗಿರಬಹುದು ಅಥವಾ ಒಂದು ಪಾತ್ರವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುವ ಕಾರ್ಯ ಅಥವಾ ಮುಚ್ಚುವಿಕೆ ಆಗಿರಬಹುದು.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ಪುನರಾವರ್ತಕ ವರ್ತನೆ
    ///
    /// ಹಿಂತಿರುಗಿದ ಪುನರಾವರ್ತಕವು ಡಬಲ್ ಎಂಡ್ ಆಗುವುದಿಲ್ಲ, ಏಕೆಂದರೆ ಅದು ಬೆಂಬಲಿಸಲು ಸಮರ್ಥವಾಗಿಲ್ಲ.
    ///
    /// ಮಾದರಿಯು ಹಿಮ್ಮುಖ ಹುಡುಕಾಟವನ್ನು ಅನುಮತಿಸಿದರೆ, [`rsplitn`] ವಿಧಾನವನ್ನು ಬಳಸಬಹುದು.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// ಸರಳ ಮಾದರಿಗಳು:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// ಮುಚ್ಚುವಿಕೆಯನ್ನು ಬಳಸಿಕೊಂಡು ಹೆಚ್ಚು ಸಂಕೀರ್ಣವಾದ ಮಾದರಿ:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// ಈ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನ ಸಬ್‌ಸ್ಟ್ರಿಂಗ್‌ಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ, ಒಂದು ಮಾದರಿಯಿಂದ ಬೇರ್ಪಡಿಸಲಾಗಿದೆ, ಸ್ಟ್ರಿಂಗ್‌ನ ತುದಿಯಿಂದ ಪ್ರಾರಂಭಿಸಿ, ಹೆಚ್ಚಿನ `n` ವಸ್ತುಗಳನ್ನು ಹಿಂತಿರುಗಿಸಲು ನಿರ್ಬಂಧಿಸಲಾಗಿದೆ.
    ///
    ///
    /// `n` ಸಬ್‌ಸ್ಟ್ರಿಂಗ್‌ಗಳನ್ನು ಹಿಂತಿರುಗಿಸಿದರೆ, ಕೊನೆಯ ಸಬ್‌ಸ್ಟ್ರಿಂಗ್ (`n` ನೇ ಸಬ್‌ಸ್ಟ್ರಿಂಗ್) ಸ್ಟ್ರಿಂಗ್‌ನ ಉಳಿದ ಭಾಗವನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    ///
    /// [pattern] ಒಂದು `&str`, [`char`], [`ಚಾರ್`] ನ ಸ್ಲೈಸ್ ಆಗಿರಬಹುದು ಅಥವಾ ಒಂದು ಪಾತ್ರವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುವ ಕಾರ್ಯ ಅಥವಾ ಮುಚ್ಚುವಿಕೆ ಆಗಿರಬಹುದು.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ಪುನರಾವರ್ತಕ ವರ್ತನೆ
    ///
    /// ಹಿಂತಿರುಗಿದ ಪುನರಾವರ್ತಕವು ಡಬಲ್ ಎಂಡ್ ಆಗುವುದಿಲ್ಲ, ಏಕೆಂದರೆ ಅದು ಬೆಂಬಲಿಸಲು ಸಮರ್ಥವಾಗಿಲ್ಲ.
    ///
    /// ಮುಂಭಾಗದಿಂದ ವಿಭಜಿಸಲು, [`splitn`] ವಿಧಾನವನ್ನು ಬಳಸಬಹುದು.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// ಸರಳ ಮಾದರಿಗಳು:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// ಮುಚ್ಚುವಿಕೆಯನ್ನು ಬಳಸಿಕೊಂಡು ಹೆಚ್ಚು ಸಂಕೀರ್ಣವಾದ ಮಾದರಿ:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// ನಿಗದಿತ ಡಿಲಿಮಿಟರ್ನ ಮೊದಲ ಘಟನೆಯ ಮೇಲೆ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ವಿಭಜಿಸುತ್ತದೆ ಮತ್ತು ಡಿಲಿಮಿಟರ್ ಮೊದಲು ಪೂರ್ವಪ್ರತ್ಯಯವನ್ನು ನೀಡುತ್ತದೆ ಮತ್ತು ಡಿಲಿಮಿಟರ್ ನಂತರ ಪ್ರತ್ಯಯವನ್ನು ನೀಡುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// ನಿಗದಿತ ಡಿಲಿಮಿಟರ್ನ ಕೊನೆಯ ಘಟನೆಯ ಮೇಲೆ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ವಿಭಜಿಸುತ್ತದೆ ಮತ್ತು ಡಿಲಿಮಿಟರ್ ಮೊದಲು ಪೂರ್ವಪ್ರತ್ಯಯವನ್ನು ನೀಡುತ್ತದೆ ಮತ್ತು ಡಿಲಿಮಿಟರ್ ನಂತರ ಪ್ರತ್ಯಯವನ್ನು ನೀಡುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// ಕೊಟ್ಟಿರುವ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನೊಳಗಿನ ಮಾದರಿಯ ಜೋಡಣೆಯ ಹೊಂದಾಣಿಕೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ.
    ///
    /// [pattern] ಒಂದು `&str`, [`char`], [`ಚಾರ್`] ನ ಸ್ಲೈಸ್ ಆಗಿರಬಹುದು ಅಥವಾ ಒಂದು ಪಾತ್ರವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುವ ಕಾರ್ಯ ಅಥವಾ ಮುಚ್ಚುವಿಕೆ ಆಗಿರಬಹುದು.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ಪುನರಾವರ್ತಕ ವರ್ತನೆ
    ///
    /// ಮಾದರಿಯು ಹಿಮ್ಮುಖ ಹುಡುಕಾಟವನ್ನು ಅನುಮತಿಸಿದರೆ ಮತ್ತು forward/reverse ಹುಡುಕಾಟವು ಅದೇ ಅಂಶಗಳನ್ನು ನೀಡುತ್ತದೆ. ಹಿಂತಿರುಗಿದ ಪುನರಾವರ್ತಕವು [`DoubleEndedIterator`] ಆಗಿರುತ್ತದೆ.
    /// ಇದು ನಿಜ, ಉದಾ, [`char`], ಆದರೆ `&str` ಗೆ ಅಲ್ಲ.
    ///
    /// ಮಾದರಿಯು ಹಿಮ್ಮುಖ ಹುಡುಕಾಟವನ್ನು ಅನುಮತಿಸಿದರೆ ಆದರೆ ಅದರ ಫಲಿತಾಂಶಗಳು ಫಾರ್ವರ್ಡ್ ಹುಡುಕಾಟದಿಂದ ಭಿನ್ನವಾಗಿರಬಹುದು, [`rmatches`] ವಿಧಾನವನ್ನು ಬಳಸಬಹುದು.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// ಈ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನೊಳಗಿನ ಒಂದು ಮಾದರಿಯ ಡಿಜಾಯಿಂಟ್ ಹೊಂದಾಣಿಕೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ, ಹಿಮ್ಮುಖ ಕ್ರಮದಲ್ಲಿ ನೀಡಲಾಗುತ್ತದೆ.
    ///
    /// [pattern] ಒಂದು `&str`, [`char`], [`ಚಾರ್`] ನ ಸ್ಲೈಸ್ ಆಗಿರಬಹುದು ಅಥವಾ ಒಂದು ಪಾತ್ರವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುವ ಕಾರ್ಯ ಅಥವಾ ಮುಚ್ಚುವಿಕೆ ಆಗಿರಬಹುದು.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ಪುನರಾವರ್ತಕ ವರ್ತನೆ
    ///
    /// ಹಿಂತಿರುಗಿದ ಪುನರಾವರ್ತಕವು ಮಾದರಿಯು ಹಿಮ್ಮುಖ ಹುಡುಕಾಟವನ್ನು ಬೆಂಬಲಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು forward/reverse ಹುಡುಕಾಟವು ಅದೇ ಅಂಶಗಳನ್ನು ನೀಡಿದರೆ ಅದು [`DoubleEndedIterator`] ಆಗಿರುತ್ತದೆ.
    ///
    ///
    /// ಮುಂಭಾಗದಿಂದ ಪುನರಾವರ್ತಿಸಲು, [`matches`] ವಿಧಾನವನ್ನು ಬಳಸಬಹುದು.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// ಈ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನೊಳಗಿನ ಮಾದರಿಯ ಡಿಜಾಯಿಂಟ್ ಹೊಂದಾಣಿಕೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ ಮತ್ತು ಪಂದ್ಯವು ಪ್ರಾರಂಭವಾಗುವ ಸೂಚ್ಯಂಕ.
    ///
    /// ಅತಿಕ್ರಮಿಸುವ `self` ಒಳಗೆ `pat` ನ ಪಂದ್ಯಗಳಿಗೆ, ಮೊದಲ ಪಂದ್ಯಕ್ಕೆ ಅನುಗುಣವಾದ ಸೂಚ್ಯಂಕಗಳನ್ನು ಮಾತ್ರ ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// [pattern] ಒಂದು `&str`, [`char`], [`ಚಾರ್`] ನ ಸ್ಲೈಸ್ ಆಗಿರಬಹುದು ಅಥವಾ ಒಂದು ಪಾತ್ರವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುವ ಕಾರ್ಯ ಅಥವಾ ಮುಚ್ಚುವಿಕೆ ಆಗಿರಬಹುದು.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ಪುನರಾವರ್ತಕ ವರ್ತನೆ
    ///
    /// ಮಾದರಿಯು ಹಿಮ್ಮುಖ ಹುಡುಕಾಟವನ್ನು ಅನುಮತಿಸಿದರೆ ಮತ್ತು forward/reverse ಹುಡುಕಾಟವು ಅದೇ ಅಂಶಗಳನ್ನು ನೀಡುತ್ತದೆ. ಹಿಂತಿರುಗಿದ ಪುನರಾವರ್ತಕವು [`DoubleEndedIterator`] ಆಗಿರುತ್ತದೆ.
    /// ಇದು ನಿಜ, ಉದಾ, [`char`], ಆದರೆ `&str` ಗೆ ಅಲ್ಲ.
    ///
    /// ಮಾದರಿಯು ಹಿಮ್ಮುಖ ಹುಡುಕಾಟವನ್ನು ಅನುಮತಿಸಿದರೆ ಆದರೆ ಅದರ ಫಲಿತಾಂಶಗಳು ಫಾರ್ವರ್ಡ್ ಹುಡುಕಾಟದಿಂದ ಭಿನ್ನವಾಗಿರಬಹುದು, [`rmatch_indices`] ವಿಧಾನವನ್ನು ಬಳಸಬಹುದು.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // ಮೊದಲ `aba` ಮಾತ್ರ
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// `self` ನೊಳಗಿನ ಒಂದು ಮಾದರಿಯ ಡಿಜಾಯಿಂಟ್ ಪಂದ್ಯಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ, ಪಂದ್ಯದ ಸೂಚ್ಯಂಕದೊಂದಿಗೆ ಹಿಮ್ಮುಖ ಕ್ರಮದಲ್ಲಿ ಫಲ ನೀಡುತ್ತದೆ.
    ///
    /// ಅತಿಕ್ರಮಿಸುವ `self` ಒಳಗೆ `pat` ನ ಪಂದ್ಯಗಳಿಗೆ, ಕೊನೆಯ ಪಂದ್ಯಕ್ಕೆ ಅನುಗುಣವಾದ ಸೂಚ್ಯಂಕಗಳನ್ನು ಮಾತ್ರ ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// [pattern] ಒಂದು `&str`, [`char`], [`ಚಾರ್`] ನ ಸ್ಲೈಸ್ ಆಗಿರಬಹುದು ಅಥವಾ ಒಂದು ಪಾತ್ರವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುವ ಕಾರ್ಯ ಅಥವಾ ಮುಚ್ಚುವಿಕೆ ಆಗಿರಬಹುದು.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ಪುನರಾವರ್ತಕ ವರ್ತನೆ
    ///
    /// ಹಿಂತಿರುಗಿದ ಪುನರಾವರ್ತಕವು ಮಾದರಿಯು ಹಿಮ್ಮುಖ ಹುಡುಕಾಟವನ್ನು ಬೆಂಬಲಿಸುವ ಅಗತ್ಯವಿದೆ, ಮತ್ತು forward/reverse ಹುಡುಕಾಟವು ಅದೇ ಅಂಶಗಳನ್ನು ನೀಡಿದರೆ ಅದು [`DoubleEndedIterator`] ಆಗಿರುತ್ತದೆ.
    ///
    ///
    /// ಮುಂಭಾಗದಿಂದ ಪುನರಾವರ್ತಿಸಲು, [`match_indices`] ವಿಧಾನವನ್ನು ಬಳಸಬಹುದು.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // ಕೊನೆಯ `aba` ಮಾತ್ರ
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// ಪ್ರಮುಖ ಮತ್ತು ಹಿಂದುಳಿದ ಜಾಗಗಳನ್ನು ತೆಗೆದುಹಾಕಿದ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// 'Whitespace' ಯುನಿಕೋಡ್ ಪಡೆದ ಕೋರ್ ಪ್ರಾಪರ್ಟಿ `White_Space` ನ ನಿಯಮಗಳ ಪ್ರಕಾರ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// ಪ್ರಮುಖ ಜಾಗಗಳನ್ನು ತೆಗೆದುಹಾಕಿದ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// 'Whitespace' ಯುನಿಕೋಡ್ ಪಡೆದ ಕೋರ್ ಪ್ರಾಪರ್ಟಿ `White_Space` ನ ನಿಯಮಗಳ ಪ್ರಕಾರ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿದೆ.
    ///
    /// # ಪಠ್ಯ ನಿರ್ದೇಶನ
    ///
    /// ಸ್ಟ್ರಿಂಗ್ ಎನ್ನುವುದು ಬೈಟ್‌ಗಳ ಅನುಕ್ರಮವಾಗಿದೆ.
    /// `start` ಈ ಸಂದರ್ಭದಲ್ಲಿ ಆ ಬೈಟ್ ಸ್ಟ್ರಿಂಗ್‌ನ ಮೊದಲ ಸ್ಥಾನ ಎಂದರ್ಥ;ಇಂಗ್ಲಿಷ್ ಅಥವಾ ರಷ್ಯನ್ ನಂತಹ ಎಡದಿಂದ ಬಲಕ್ಕೆ, ಇದು ಎಡಭಾಗವಾಗಿರುತ್ತದೆ, ಮತ್ತು ಅರೇಬಿಕ್ ಅಥವಾ ಹೀಬ್ರೂನಂತಹ ಬಲದಿಂದ ಎಡಕ್ಕೆ, ಇದು ಬಲಭಾಗವಾಗಿರುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// ಹಿಂದುಳಿದಿರುವ ಜಾಗವನ್ನು ತೆಗೆದುಹಾಕುವುದರೊಂದಿಗೆ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// 'Whitespace' ಯುನಿಕೋಡ್ ಪಡೆದ ಕೋರ್ ಪ್ರಾಪರ್ಟಿ `White_Space` ನ ನಿಯಮಗಳ ಪ್ರಕಾರ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿದೆ.
    ///
    /// # ಪಠ್ಯ ನಿರ್ದೇಶನ
    ///
    /// ಸ್ಟ್ರಿಂಗ್ ಎನ್ನುವುದು ಬೈಟ್‌ಗಳ ಅನುಕ್ರಮವಾಗಿದೆ.
    /// `end` ಈ ಸಂದರ್ಭದಲ್ಲಿ ಆ ಬೈಟ್ ಸ್ಟ್ರಿಂಗ್‌ನ ಕೊನೆಯ ಸ್ಥಾನ ಎಂದರ್ಥ;ಇಂಗ್ಲಿಷ್ ಅಥವಾ ರಷ್ಯನ್ ನಂತಹ ಎಡದಿಂದ ಬಲಕ್ಕೆ, ಇದು ಬಲಭಾಗವಾಗಿರುತ್ತದೆ ಮತ್ತು ಅರೇಬಿಕ್ ಅಥವಾ ಹೀಬ್ರೂನಂತಹ ಬಲದಿಂದ ಎಡಕ್ಕೆ, ಇದು ಎಡಭಾಗವಾಗಿರುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// ಪ್ರಮುಖ ಜಾಗಗಳನ್ನು ತೆಗೆದುಹಾಕಿದ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// 'Whitespace' ಯುನಿಕೋಡ್ ಪಡೆದ ಕೋರ್ ಪ್ರಾಪರ್ಟಿ `White_Space` ನ ನಿಯಮಗಳ ಪ್ರಕಾರ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿದೆ.
    ///
    /// # ಪಠ್ಯ ನಿರ್ದೇಶನ
    ///
    /// ಸ್ಟ್ರಿಂಗ್ ಎನ್ನುವುದು ಬೈಟ್‌ಗಳ ಅನುಕ್ರಮವಾಗಿದೆ.
    /// 'Left' ಈ ಸಂದರ್ಭದಲ್ಲಿ ಆ ಬೈಟ್ ಸ್ಟ್ರಿಂಗ್‌ನ ಮೊದಲ ಸ್ಥಾನ ಎಂದರ್ಥ;ಅರೇಬಿಕ್ ಅಥವಾ ಹೀಬ್ರೂನಂತಹ ಭಾಷೆಗೆ 'ಎಡದಿಂದ ಬಲಕ್ಕೆ' ಬದಲಾಗಿ 'ಬಲದಿಂದ ಎಡಕ್ಕೆ', ಇದು _right_ ಸೈಡ್ ಆಗಿರುತ್ತದೆ, ಎಡಕ್ಕೆ ಅಲ್ಲ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// ಹಿಂದುಳಿದಿರುವ ಜಾಗವನ್ನು ತೆಗೆದುಹಾಕುವುದರೊಂದಿಗೆ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// 'Whitespace' ಯುನಿಕೋಡ್ ಪಡೆದ ಕೋರ್ ಪ್ರಾಪರ್ಟಿ `White_Space` ನ ನಿಯಮಗಳ ಪ್ರಕಾರ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿದೆ.
    ///
    /// # ಪಠ್ಯ ನಿರ್ದೇಶನ
    ///
    /// ಸ್ಟ್ರಿಂಗ್ ಎನ್ನುವುದು ಬೈಟ್‌ಗಳ ಅನುಕ್ರಮವಾಗಿದೆ.
    /// 'Right' ಈ ಸಂದರ್ಭದಲ್ಲಿ ಆ ಬೈಟ್ ಸ್ಟ್ರಿಂಗ್‌ನ ಕೊನೆಯ ಸ್ಥಾನ ಎಂದರ್ಥ;ಅರೇಬಿಕ್ ಅಥವಾ ಹೀಬ್ರೂನಂತಹ ಭಾಷೆಗೆ 'ಎಡದಿಂದ ಬಲಕ್ಕೆ' ಬದಲಾಗಿ 'ಬಲದಿಂದ ಎಡಕ್ಕೆ', ಇದು _left_ ಸೈಡ್ ಆಗಿರುತ್ತದೆ, ಬಲವಲ್ಲ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// ಪದೇ ಪದೇ ತೆಗೆದುಹಾಕಲಾದ ಮಾದರಿಗೆ ಹೊಂದಿಕೆಯಾಗುವ ಎಲ್ಲಾ ಪೂರ್ವಪ್ರತ್ಯಯಗಳು ಮತ್ತು ಪ್ರತ್ಯಯಗಳೊಂದಿಗೆ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [pattern] ಒಂದು [`char`] ಆಗಿರಬಹುದು, [`ಚಾರ್`] ನ ಸ್ಲೈಸ್ ಅಥವಾ ಒಂದು ಪಾತ್ರವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುವ ಕಾರ್ಯ ಅಥವಾ ಮುಚ್ಚುವಿಕೆ.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ಸರಳ ಮಾದರಿಗಳು:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// ಮುಚ್ಚುವಿಕೆಯನ್ನು ಬಳಸಿಕೊಂಡು ಹೆಚ್ಚು ಸಂಕೀರ್ಣವಾದ ಮಾದರಿ:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // ಮೊದಲಿಗೆ ತಿಳಿದಿರುವ ಪಂದ್ಯವನ್ನು ನೆನಪಿಡಿ, ಅದನ್ನು ಕೆಳಗೆ ಸರಿಪಡಿಸಿ
            // ಕೊನೆಯ ಪಂದ್ಯವು ವಿಭಿನ್ನವಾಗಿದೆ
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // ಸುರಕ್ಷತೆ: `Searcher` ಮಾನ್ಯ ಸೂಚ್ಯಂಕಗಳನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
        unsafe { self.get_unchecked(i..j) }
    }

    /// ಪದೇ ಪದೇ ತೆಗೆದುಹಾಕಲಾದ ಮಾದರಿಗೆ ಹೊಂದಿಕೆಯಾಗುವ ಎಲ್ಲಾ ಪೂರ್ವಪ್ರತ್ಯಯಗಳೊಂದಿಗೆ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [pattern] ಒಂದು `&str`, [`char`], [`ಚಾರ್`] ನ ಸ್ಲೈಸ್ ಆಗಿರಬಹುದು ಅಥವಾ ಒಂದು ಪಾತ್ರವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುವ ಕಾರ್ಯ ಅಥವಾ ಮುಚ್ಚುವಿಕೆ ಆಗಿರಬಹುದು.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ಪಠ್ಯ ನಿರ್ದೇಶನ
    ///
    /// ಸ್ಟ್ರಿಂಗ್ ಎನ್ನುವುದು ಬೈಟ್‌ಗಳ ಅನುಕ್ರಮವಾಗಿದೆ.
    /// `start` ಈ ಸಂದರ್ಭದಲ್ಲಿ ಆ ಬೈಟ್ ಸ್ಟ್ರಿಂಗ್‌ನ ಮೊದಲ ಸ್ಥಾನ ಎಂದರ್ಥ;ಇಂಗ್ಲಿಷ್ ಅಥವಾ ರಷ್ಯನ್ ನಂತಹ ಎಡದಿಂದ ಬಲಕ್ಕೆ, ಇದು ಎಡಭಾಗವಾಗಿರುತ್ತದೆ, ಮತ್ತು ಅರೇಬಿಕ್ ಅಥವಾ ಹೀಬ್ರೂನಂತಹ ಬಲದಿಂದ ಎಡಕ್ಕೆ, ಇದು ಬಲಭಾಗವಾಗಿರುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // ಸುರಕ್ಷತೆ: `Searcher` ಮಾನ್ಯ ಸೂಚ್ಯಂಕಗಳನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// ತೆಗೆದುಹಾಕಲಾದ ಪೂರ್ವಪ್ರತ್ಯಯದೊಂದಿಗೆ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಸ್ಟ್ರಿಂಗ್ `prefix` ಮಾದರಿಯೊಂದಿಗೆ ಪ್ರಾರಂಭವಾದರೆ, ಪೂರ್ವಪ್ರತ್ಯಯದ ನಂತರ ಸಬ್‌ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಇದನ್ನು `Some` ನಲ್ಲಿ ಸುತ್ತಿಡಲಾಗುತ್ತದೆ.
    /// `trim_start_matches` ಗಿಂತ ಭಿನ್ನವಾಗಿ, ಈ ವಿಧಾನವು ನಿಖರವಾಗಿ ಒಮ್ಮೆ ಪೂರ್ವಪ್ರತ್ಯಯವನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ.
    ///
    /// ಸ್ಟ್ರಿಂಗ್ `prefix` ನೊಂದಿಗೆ ಪ್ರಾರಂಭವಾಗದಿದ್ದರೆ, `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [pattern] ಒಂದು `&str`, [`char`], [`ಚಾರ್`] ನ ಸ್ಲೈಸ್ ಆಗಿರಬಹುದು ಅಥವಾ ಒಂದು ಪಾತ್ರವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುವ ಕಾರ್ಯ ಅಥವಾ ಮುಚ್ಚುವಿಕೆ ಆಗಿರಬಹುದು.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// ತೆಗೆದುಹಾಕಲಾದ ಪ್ರತ್ಯಯದೊಂದಿಗೆ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಸ್ಟ್ರಿಂಗ್ `suffix` ಮಾದರಿಯೊಂದಿಗೆ ಕೊನೆಗೊಂಡರೆ, `Some` ನಲ್ಲಿ ಸುತ್ತಿ, ಪ್ರತ್ಯಯಕ್ಕೆ ಮೊದಲು ಸಬ್‌ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    /// `trim_end_matches` ಗಿಂತ ಭಿನ್ನವಾಗಿ, ಈ ವಿಧಾನವು ಪ್ರತ್ಯಯವನ್ನು ನಿಖರವಾಗಿ ಒಮ್ಮೆ ತೆಗೆದುಹಾಕುತ್ತದೆ.
    ///
    /// ಸ್ಟ್ರಿಂಗ್ `suffix` ನೊಂದಿಗೆ ಕೊನೆಗೊಳ್ಳದಿದ್ದರೆ, `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [pattern] ಒಂದು `&str`, [`char`], [`ಚಾರ್`] ನ ಸ್ಲೈಸ್ ಆಗಿರಬಹುದು ಅಥವಾ ಒಂದು ಪಾತ್ರವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುವ ಕಾರ್ಯ ಅಥವಾ ಮುಚ್ಚುವಿಕೆ ಆಗಿರಬಹುದು.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// ಪದೇ ಪದೇ ತೆಗೆದುಹಾಕಲಾದ ಮಾದರಿಗೆ ಹೊಂದಿಕೆಯಾಗುವ ಎಲ್ಲಾ ಪ್ರತ್ಯಯಗಳೊಂದಿಗೆ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [pattern] ಒಂದು `&str`, [`char`], [`ಚಾರ್`] ನ ಸ್ಲೈಸ್ ಆಗಿರಬಹುದು ಅಥವಾ ಒಂದು ಪಾತ್ರವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುವ ಕಾರ್ಯ ಅಥವಾ ಮುಚ್ಚುವಿಕೆ ಆಗಿರಬಹುದು.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ಪಠ್ಯ ನಿರ್ದೇಶನ
    ///
    /// ಸ್ಟ್ರಿಂಗ್ ಎನ್ನುವುದು ಬೈಟ್‌ಗಳ ಅನುಕ್ರಮವಾಗಿದೆ.
    /// `end` ಈ ಸಂದರ್ಭದಲ್ಲಿ ಆ ಬೈಟ್ ಸ್ಟ್ರಿಂಗ್‌ನ ಕೊನೆಯ ಸ್ಥಾನ ಎಂದರ್ಥ;ಇಂಗ್ಲಿಷ್ ಅಥವಾ ರಷ್ಯನ್ ನಂತಹ ಎಡದಿಂದ ಬಲಕ್ಕೆ, ಇದು ಬಲಭಾಗವಾಗಿರುತ್ತದೆ ಮತ್ತು ಅರೇಬಿಕ್ ಅಥವಾ ಹೀಬ್ರೂನಂತಹ ಬಲದಿಂದ ಎಡಕ್ಕೆ, ಇದು ಎಡಭಾಗವಾಗಿರುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಸರಳ ಮಾದರಿಗಳು:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// ಮುಚ್ಚುವಿಕೆಯನ್ನು ಬಳಸಿಕೊಂಡು ಹೆಚ್ಚು ಸಂಕೀರ್ಣವಾದ ಮಾದರಿ:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // ಸುರಕ್ಷತೆ: `Searcher` ಮಾನ್ಯ ಸೂಚ್ಯಂಕಗಳನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
        unsafe { self.get_unchecked(0..j) }
    }

    /// ಪದೇ ಪದೇ ತೆಗೆದುಹಾಕಲಾದ ಮಾದರಿಗೆ ಹೊಂದಿಕೆಯಾಗುವ ಎಲ್ಲಾ ಪೂರ್ವಪ್ರತ್ಯಯಗಳೊಂದಿಗೆ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [pattern] ಒಂದು `&str`, [`char`], [`ಚಾರ್`] ನ ಸ್ಲೈಸ್ ಆಗಿರಬಹುದು ಅಥವಾ ಒಂದು ಪಾತ್ರವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುವ ಕಾರ್ಯ ಅಥವಾ ಮುಚ್ಚುವಿಕೆ ಆಗಿರಬಹುದು.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ಪಠ್ಯ ನಿರ್ದೇಶನ
    ///
    /// ಸ್ಟ್ರಿಂಗ್ ಎನ್ನುವುದು ಬೈಟ್‌ಗಳ ಅನುಕ್ರಮವಾಗಿದೆ.
    /// 'Left' ಈ ಸಂದರ್ಭದಲ್ಲಿ ಆ ಬೈಟ್ ಸ್ಟ್ರಿಂಗ್‌ನ ಮೊದಲ ಸ್ಥಾನ ಎಂದರ್ಥ;ಅರೇಬಿಕ್ ಅಥವಾ ಹೀಬ್ರೂನಂತಹ ಭಾಷೆಗೆ 'ಎಡದಿಂದ ಬಲಕ್ಕೆ' ಬದಲಾಗಿ 'ಬಲದಿಂದ ಎಡಕ್ಕೆ', ಇದು _right_ ಸೈಡ್ ಆಗಿರುತ್ತದೆ, ಎಡಕ್ಕೆ ಅಲ್ಲ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// ಪದೇ ಪದೇ ತೆಗೆದುಹಾಕಲಾದ ಮಾದರಿಗೆ ಹೊಂದಿಕೆಯಾಗುವ ಎಲ್ಲಾ ಪ್ರತ್ಯಯಗಳೊಂದಿಗೆ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [pattern] ಒಂದು `&str`, [`char`], [`ಚಾರ್`] ನ ಸ್ಲೈಸ್ ಆಗಿರಬಹುದು ಅಥವಾ ಒಂದು ಪಾತ್ರವು ಹೊಂದಿಕೆಯಾಗುತ್ತದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುವ ಕಾರ್ಯ ಅಥವಾ ಮುಚ್ಚುವಿಕೆ ಆಗಿರಬಹುದು.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ಪಠ್ಯ ನಿರ್ದೇಶನ
    ///
    /// ಸ್ಟ್ರಿಂಗ್ ಎನ್ನುವುದು ಬೈಟ್‌ಗಳ ಅನುಕ್ರಮವಾಗಿದೆ.
    /// 'Right' ಈ ಸಂದರ್ಭದಲ್ಲಿ ಆ ಬೈಟ್ ಸ್ಟ್ರಿಂಗ್‌ನ ಕೊನೆಯ ಸ್ಥಾನ ಎಂದರ್ಥ;ಅರೇಬಿಕ್ ಅಥವಾ ಹೀಬ್ರೂನಂತಹ ಭಾಷೆಗೆ 'ಎಡದಿಂದ ಬಲಕ್ಕೆ' ಬದಲಾಗಿ 'ಬಲದಿಂದ ಎಡಕ್ಕೆ', ಇದು _left_ ಸೈಡ್ ಆಗಿರುತ್ತದೆ, ಬಲವಲ್ಲ.
    ///
    ///
    /// # Examples
    ///
    /// ಸರಳ ಮಾದರಿಗಳು:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// ಮುಚ್ಚುವಿಕೆಯನ್ನು ಬಳಸಿಕೊಂಡು ಹೆಚ್ಚು ಸಂಕೀರ್ಣವಾದ ಮಾದರಿ:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// ಈ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಮತ್ತೊಂದು ಪ್ರಕಾರಕ್ಕೆ ಪಾರ್ಸ್ ಮಾಡುತ್ತದೆ.
    ///
    /// `parse` ತುಂಬಾ ಸಾಮಾನ್ಯವಾದ ಕಾರಣ, ಇದು ಪ್ರಕಾರದ ಅನುಮಾನದೊಂದಿಗೆ ಸಮಸ್ಯೆಗಳನ್ನು ಉಂಟುಮಾಡಬಹುದು.
    /// ಅಂತೆಯೇ, 'turbofish' ಎಂದು ನೀವು ಪ್ರೀತಿಯಿಂದ ಕರೆಯಲ್ಪಡುವ ಸಿಂಟ್ಯಾಕ್ಸ್ ಅನ್ನು ನೀವು ನೋಡುವ ಕೆಲವೇ ಸಮಯಗಳಲ್ಲಿ `parse` ಒಂದಾಗಿದೆ: `::<>`.
    ///
    /// ನೀವು ಯಾವ ಪ್ರಕಾರವನ್ನು ಪಾರ್ಸ್ ಮಾಡಲು ಪ್ರಯತ್ನಿಸುತ್ತಿದ್ದೀರಿ ಎಂಬುದನ್ನು ನಿರ್ದಿಷ್ಟವಾಗಿ ಅರ್ಥಮಾಡಿಕೊಳ್ಳಲು ಇದು ಅನುಮಾನದ ಅಲ್ಗಾರಿದಮ್‌ಗೆ ಸಹಾಯ ಮಾಡುತ್ತದೆ.
    ///
    /// `parse` [`FromStr`] trait ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಯಾವುದೇ ಪ್ರಕಾರಕ್ಕೆ ಪಾರ್ಸ್ ಮಾಡಬಹುದು.
    ///

    /// # Errors
    ///
    /// ಈ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಅನ್ನು ಅಪೇಕ್ಷಿತ ಪ್ರಕಾರಕ್ಕೆ ಪಾರ್ಸ್ ಮಾಡಲು ಸಾಧ್ಯವಾಗದಿದ್ದರೆ [`Err`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// `four` ಅನ್ನು ಟಿಪ್ಪಣಿ ಮಾಡುವ ಬದಲು 'turbofish' ಅನ್ನು ಬಳಸುವುದು:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// ಪಾರ್ಸ್ ಮಾಡಲು ವಿಫಲವಾಗಿದೆ:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// ಈ ಸ್ಟ್ರಿಂಗ್‌ನಲ್ಲಿನ ಎಲ್ಲಾ ಅಕ್ಷರಗಳು ಎಎಸ್‌ಸಿಐಐ ವ್ಯಾಪ್ತಿಯಲ್ಲಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // ನಾವು ಪ್ರತಿ ಬೈಟ್ ಅನ್ನು ಇಲ್ಲಿ ಅಕ್ಷರವೆಂದು ಪರಿಗಣಿಸಬಹುದು: ಎಲ್ಲಾ ಮಲ್ಟಿಬೈಟ್ ಅಕ್ಷರಗಳು ಆಸ್ಕಿ ವ್ಯಾಪ್ತಿಯಲ್ಲಿಲ್ಲದ ಬೈಟ್‌ನಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತವೆ, ಆದ್ದರಿಂದ ನಾವು ಈಗಾಗಲೇ ಅಲ್ಲಿ ನಿಲ್ಲುತ್ತೇವೆ.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// ಎರಡು ತಂತಿಗಳು ಎಎಸ್ಸಿಐಐ ಕೇಸ್-ಸೆನ್ಸಿಟಿವ್ ಮ್ಯಾಚ್ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` ನಂತೆಯೇ, ಆದರೆ ತಾತ್ಕಾಲಿಕಗಳನ್ನು ನಿಯೋಜಿಸದೆ ಮತ್ತು ನಕಲಿಸದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// ಈ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಅದರ ಎಎಸ್ಸಿಐಐ ಮೇಲಿನ ಪ್ರಕರಣಕ್ಕೆ ಸಮನಾಗಿ ಸ್ಥಳಕ್ಕೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ASCII ಅಕ್ಷರಗಳು 'a' ರಿಂದ 'z' ಅನ್ನು 'A' ನಿಂದ 'Z' ಗೆ ಮ್ಯಾಪ್ ಮಾಡಲಾಗಿದೆ, ಆದರೆ ASCII ಅಲ್ಲದ ಅಕ್ಷರಗಳು ಬದಲಾಗುವುದಿಲ್ಲ.
    ///
    /// ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ ಒಂದನ್ನು ಮಾರ್ಪಡಿಸದೆ ಹೊಸ ದೊಡ್ಡ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸಲು, [`to_ascii_uppercase()`] ಬಳಸಿ.
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // ಸುರಕ್ಷತೆ: ಸುರಕ್ಷಿತ ಏಕೆಂದರೆ ನಾವು ಒಂದೇ ವಿನ್ಯಾಸದೊಂದಿಗೆ ಎರಡು ಪ್ರಕಾರಗಳನ್ನು ಪರಿವರ್ತಿಸುತ್ತೇವೆ.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// ಈ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಅದರ ಎಎಸ್ಸಿಐಐ ಲೋವರ್ ಕೇಸ್ ಸಮಾನ ಸ್ಥಳಕ್ಕೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ASCII ಅಕ್ಷರಗಳು 'A' ರಿಂದ 'Z' ಅನ್ನು 'a' ನಿಂದ 'z' ಗೆ ಮ್ಯಾಪ್ ಮಾಡಲಾಗಿದೆ, ಆದರೆ ASCII ಅಲ್ಲದ ಅಕ್ಷರಗಳು ಬದಲಾಗುವುದಿಲ್ಲ.
    ///
    /// ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ ಒಂದನ್ನು ಮಾರ್ಪಡಿಸದೆ ಹೊಸ ಕಡಿಮೆ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸಲು, [`to_ascii_lowercase()`] ಬಳಸಿ.
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // ಸುರಕ್ಷತೆ: ಸುರಕ್ಷಿತ ಏಕೆಂದರೆ ನಾವು ಒಂದೇ ವಿನ್ಯಾಸದೊಂದಿಗೆ ಎರಡು ಪ್ರಕಾರಗಳನ್ನು ಪರಿವರ್ತಿಸುತ್ತೇವೆ.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// `self` ನಲ್ಲಿನ ಪ್ರತಿ ಚಾರ್ ಅನ್ನು [`char::escape_debug`] ನೊಂದಿಗೆ ತಪ್ಪಿಸಿಕೊಳ್ಳುವ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿ.
    ///
    ///
    /// Note: ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಪ್ರಾರಂಭಿಸುವ ವಿಸ್ತೃತ ಗ್ರ್ಯಾಫೀಮ್ ಕೋಡ್‌ಪಾಯಿಂಟ್‌ಗಳು ಮಾತ್ರ ತಪ್ಪಿಸಿಕೊಳ್ಳುತ್ತವೆ.
    ///
    /// # Examples
    ///
    /// ಪುನರಾವರ್ತಕರಾಗಿ:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ಅನ್ನು ನೇರವಾಗಿ ಬಳಸುವುದು:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// ಎರಡೂ ಇದಕ್ಕೆ ಸಮಾನವಾಗಿವೆ:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// `to_string` ಬಳಸುವುದು:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// `self` ನಲ್ಲಿನ ಪ್ರತಿ ಚಾರ್ ಅನ್ನು [`char::escape_default`] ನೊಂದಿಗೆ ತಪ್ಪಿಸಿಕೊಳ್ಳುವ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿ.
    ///
    ///
    /// # Examples
    ///
    /// ಪುನರಾವರ್ತಕರಾಗಿ:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ಅನ್ನು ನೇರವಾಗಿ ಬಳಸುವುದು:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// ಎರಡೂ ಇದಕ್ಕೆ ಸಮಾನವಾಗಿವೆ:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// `to_string` ಬಳಸುವುದು:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// `self` ನಲ್ಲಿನ ಪ್ರತಿ ಚಾರ್ ಅನ್ನು [`char::escape_unicode`] ನೊಂದಿಗೆ ತಪ್ಪಿಸಿಕೊಳ್ಳುವ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿ.
    ///
    ///
    /// # Examples
    ///
    /// ಪುನರಾವರ್ತಕರಾಗಿ:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ಅನ್ನು ನೇರವಾಗಿ ಬಳಸುವುದು:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// ಎರಡೂ ಇದಕ್ಕೆ ಸಮಾನವಾಗಿವೆ:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// `to_string` ಬಳಸುವುದು:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// ಖಾಲಿ str ಅನ್ನು ರಚಿಸುತ್ತದೆ
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// ಖಾಲಿ ರೂಪಾಂತರಿತ str ಅನ್ನು ರಚಿಸುತ್ತದೆ
    #[inline]
    fn default() -> Self {
        // ಸುರಕ್ಷತೆ: ಖಾಲಿ ಸ್ಟ್ರಿಂಗ್ ಮಾನ್ಯ UTF-8 ಆಗಿದೆ.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// ಹೆಸರಿಸಬಹುದಾದ, ತದ್ರೂಪಿ ಮಾಡಬಹುದಾದ ಎಫ್ಎನ್ ಪ್ರಕಾರ
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // ಸುರಕ್ಷತೆ: ಸುರಕ್ಷಿತವಲ್ಲ
        unsafe { from_utf8_unchecked(bytes) }
    };
}