use crate::fmt;
use crate::future::Future;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// [`Poll`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುವ ಕಾರ್ಯವನ್ನು ಸುತ್ತುವ future ಅನ್ನು ರಚಿಸುತ್ತದೆ.
///
/// ಸುತ್ತಿದ ಕಾರ್ಯಕ್ಕೆ future ಪ್ರತಿನಿಧಿಗಳನ್ನು ಮತದಾನ ಮಾಡುವುದು.
///
/// # Examples
///
/// ```
/// #![feature(future_poll_fn)]
/// # async fn run() {
/// use core::future::poll_fn;
/// use std::task::{Context, Poll};
///
/// fn read_line(_cx: &mut Context<'_>) -> Poll<String> {
///     Poll::Ready("Hello, World!".into())
/// }
///
/// let read_future = poll_fn(read_line);
/// assert_eq!(read_future.await, "Hello, World!".to_owned());
/// # }
/// ```
#[unstable(feature = "future_poll_fn", issue = "72302")]
pub fn poll_fn<T, F>(f: F) -> PollFn<F>
where
    F: FnMut(&mut Context<'_>) -> Poll<T>,
{
    PollFn { f }
}

/// [`Poll`] ಹಿಂದಿರುಗಿಸುವ ಕಾರ್ಯವನ್ನು ಸುತ್ತುವ Future.
///
/// ಈ `struct` ಅನ್ನು [`poll_fn()`] ನಿಂದ ರಚಿಸಲಾಗಿದೆ.
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[unstable(feature = "future_poll_fn", issue = "72302")]
pub struct PollFn<F> {
    f: F,
}

#[unstable(feature = "future_poll_fn", issue = "72302")]
impl<F> Unpin for PollFn<F> {}

#[unstable(feature = "future_poll_fn", issue = "72302")]
impl<F> fmt::Debug for PollFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("PollFn").finish()
    }
}

#[unstable(feature = "future_poll_fn", issue = "72302")]
impl<T, F> Future for PollFn<F>
where
    F: FnMut(&mut Context<'_>) -> Poll<T>,
{
    type Output = T;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<T> {
        (&mut self.f)(cx)
    }
}