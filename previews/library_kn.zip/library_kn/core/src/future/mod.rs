#![stable(feature = "futures_api", since = "1.36.0")]

//! ಅಸಮಕಾಲಿಕ ಮೌಲ್ಯಗಳು.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// ಈ ಪ್ರಕಾರದ ಅಗತ್ಯವಿದೆ ಏಕೆಂದರೆ:
///
/// ಎ) ಜನರೇಟರ್‌ಗಳು `for<'a, 'b> Generator<&'a mut Context<'b>>` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ, ಆದ್ದರಿಂದ ನಾವು ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಅನ್ನು ರವಾನಿಸಬೇಕಾಗಿದೆ (<https://github.com/rust-lang/rust/issues/68923> ನೋಡಿ).
///
/// ಬೌ) ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ಗಳು ಮತ್ತು `NonNull` `Send` ಅಥವಾ `Sync` ಅಲ್ಲ, ಆದ್ದರಿಂದ ಅದು ಪ್ರತಿಯೊಂದು future non-Send/Sync ಅನ್ನು ಸಹ ಮಾಡುತ್ತದೆ, ಮತ್ತು ನಾವು ಅದನ್ನು ಬಯಸುವುದಿಲ್ಲ.
///
/// ಇದು `.await` ನ HIR ಅನ್ನು ಕಡಿಮೆ ಮಾಡುವುದನ್ನು ಸಹ ಸರಳಗೊಳಿಸುತ್ತದೆ.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// ಜನರೇಟರ್ ಅನ್ನು future ನಲ್ಲಿ ಕಟ್ಟಿಕೊಳ್ಳಿ.
///
/// ಈ ಕಾರ್ಯವು ಕೆಳಗೆ `GenFuture` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಆದರೆ ಉತ್ತಮ ದೋಷ ಸಂದೇಶಗಳನ್ನು ನೀಡಲು ಅದನ್ನು `impl Trait` ನಲ್ಲಿ ಮರೆಮಾಡುತ್ತದೆ (`GenFuture<[closure.....]>` ಗಿಂತ `impl Future`).
///
// ನಾವು `const async fn` ನಿಂದ ಚೇತರಿಸಿಕೊಂಡ ನಂತರ ಹೆಚ್ಚುವರಿ ದೋಷಗಳನ್ನು ತಪ್ಪಿಸಲು ಇದು `const` ಆಗಿದೆ
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // ಆಧಾರವಾಗಿರುವ ಜನರೇಟರ್‌ನಲ್ಲಿ ಸ್ವಯಂ-ಉಲ್ಲೇಖಿತ ಸಾಲಗಳನ್ನು ರಚಿಸಲು async/await futures ಸ್ಥಿರವಾಗಿದೆ ಎಂಬ ಅಂಶವನ್ನು ನಾವು ಅವಲಂಬಿಸಿದ್ದೇವೆ.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // ಸುರಕ್ಷತೆ: ಸುರಕ್ಷಿತ ಏಕೆಂದರೆ ನಾವು !Unpin + !Drop, ಮತ್ತು ಇದು ಕೇವಲ ಕ್ಷೇತ್ರ ಪ್ರಕ್ಷೇಪಣವಾಗಿದೆ.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // ಜನರೇಟರ್ ಅನ್ನು ಪುನರಾರಂಭಿಸಿ, `&mut Context` ಅನ್ನು `NonNull` ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಆಗಿ ಪರಿವರ್ತಿಸಿ.
            // `.await` ಇಳಿಸುವಿಕೆಯು ಅದನ್ನು ಸುರಕ್ಷಿತವಾಗಿ `&mut Context` ಗೆ ಬಿತ್ತರಿಸುತ್ತದೆ.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `cx.0` ಮಾನ್ಯ ಪಾಯಿಂಟರ್ ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು
    // ಇದು ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಕ್ಕಾಗಿ ಎಲ್ಲಾ ಅವಶ್ಯಕತೆಗಳನ್ನು ಪೂರೈಸುತ್ತದೆ.
    unsafe { &mut *cx.0.as_ptr().cast() }
}