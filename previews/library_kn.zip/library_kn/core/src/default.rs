//! ಅರ್ಥಪೂರ್ಣ ಡೀಫಾಲ್ಟ್ ಮೌಲ್ಯಗಳನ್ನು ಹೊಂದಿರುವ ಪ್ರಕಾರಗಳಿಗಾಗಿ `Default` trait.

#![stable(feature = "rust1", since = "1.0.0")]

/// ಒಂದು ಪ್ರಕಾರಕ್ಕೆ ಉಪಯುಕ್ತ ಡೀಫಾಲ್ಟ್ ಮೌಲ್ಯವನ್ನು ನೀಡಲು trait.
///
/// ಕೆಲವೊಮ್ಮೆ, ನೀವು ಕೆಲವು ರೀತಿಯ ಡೀಫಾಲ್ಟ್ ಮೌಲ್ಯಕ್ಕೆ ಮರಳಲು ಬಯಸುತ್ತೀರಿ, ಮತ್ತು ಅದು ಏನೆಂದು ವಿಶೇಷವಾಗಿ ಹೆದರುವುದಿಲ್ಲ.
/// ಇದು ಆಯ್ಕೆಗಳ ಗುಂಪನ್ನು ವ್ಯಾಖ್ಯಾನಿಸುವ `struct` ಗಳೊಂದಿಗೆ ಆಗಾಗ್ಗೆ ಬರುತ್ತದೆ:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// ಕೆಲವು ಡೀಫಾಲ್ಟ್ ಮೌಲ್ಯಗಳನ್ನು ನಾವು ಹೇಗೆ ವ್ಯಾಖ್ಯಾನಿಸಬಹುದು?ನೀವು `Default` ಅನ್ನು ಬಳಸಬಹುದು:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// ಈಗ, ನೀವು ಎಲ್ಲಾ ಡೀಫಾಲ್ಟ್ ಮೌಲ್ಯಗಳನ್ನು ಪಡೆಯುತ್ತೀರಿ.Rust ವಿವಿಧ ಪ್ರಾಚೀನ ಪ್ರಕಾರಗಳಿಗಾಗಿ `Default` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
///
/// ನೀವು ನಿರ್ದಿಷ್ಟ ಆಯ್ಕೆಯನ್ನು ಅತಿಕ್ರಮಿಸಲು ಬಯಸಿದರೆ, ಆದರೆ ಇತರ ಡೀಫಾಲ್ಟ್‌ಗಳನ್ನು ಇನ್ನೂ ಉಳಿಸಿಕೊಳ್ಳಿ:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// ಪ್ರಕಾರದ ಎಲ್ಲಾ ಕ್ಷೇತ್ರಗಳು `Default` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದರೆ ಈ trait ಅನ್ನು `#[derive]` ನೊಂದಿಗೆ ಬಳಸಬಹುದು.
/// `ವ್ಯುತ್ಪನ್ನ` ಮಾಡಿದಾಗ, ಅದು ಪ್ರತಿ ಕ್ಷೇತ್ರದ ಪ್ರಕಾರಕ್ಕೆ ಪೂರ್ವನಿಯೋಜಿತ ಮೌಲ್ಯವನ್ನು ಬಳಸುತ್ತದೆ.
///
/// ## `Default` ಅನ್ನು ನಾನು ಹೇಗೆ ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು?
///
/// ನಿಮ್ಮ ಪ್ರಕಾರದ ಮೌಲ್ಯವನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ನೀಡುವ `default()` ವಿಧಾನಕ್ಕಾಗಿ ಅನುಷ್ಠಾನವನ್ನು ಒದಗಿಸಿ:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// ಒಂದು ಪ್ರಕಾರಕ್ಕಾಗಿ "default value" ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಡೀಫಾಲ್ಟ್ ಮೌಲ್ಯಗಳು ಸಾಮಾನ್ಯವಾಗಿ ಕೆಲವು ರೀತಿಯ ಆರಂಭಿಕ ಮೌಲ್ಯ, ಗುರುತಿನ ಮೌಲ್ಯ ಅಥವಾ ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಅರ್ಥವಾಗುವಂತಹ ಯಾವುದಾದರೂ ಆಗಿರುತ್ತವೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಅಂತರ್ನಿರ್ಮಿತ ಡೀಫಾಲ್ಟ್ ಮೌಲ್ಯಗಳನ್ನು ಬಳಸುವುದು:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// ನಿಮ್ಮದೇ ಆದ:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// `Default` trait ಪ್ರಕಾರ ಪ್ರಕಾರದ ಡೀಫಾಲ್ಟ್ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿ.
///
/// ಹಿಂತಿರುಗುವ ಪ್ರಕಾರವನ್ನು ಸಂದರ್ಭದಿಂದ er ಹಿಸಲಾಗಿದೆ;ಇದು `Default::default()` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ ಆದರೆ ಟೈಪ್ ಮಾಡಲು ಕಡಿಮೆ.
///
/// ಉದಾಹರಣೆಗೆ:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// trait `Default` ನ impl ಅನ್ನು ಉತ್ಪಾದಿಸುವ ಮ್ಯಾಕ್ರೋ ಅನ್ನು ಪಡೆಯಿರಿ.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }