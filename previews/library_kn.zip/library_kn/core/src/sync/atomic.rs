//! ಪರಮಾಣು ಪ್ರಕಾರಗಳು
//!
//! ಪರಮಾಣು ಪ್ರಕಾರಗಳು ಎಳೆಗಳ ನಡುವೆ ಪ್ರಾಚೀನ ಹಂಚಿಕೆಯ-ಮೆಮೊರಿ ಸಂವಹನವನ್ನು ಒದಗಿಸುತ್ತವೆ ಮತ್ತು ಇತರ ಏಕಕಾಲೀನ ಪ್ರಕಾರಗಳ ಬಿಲ್ಡಿಂಗ್ ಬ್ಲಾಕ್‌ಗಳಾಗಿವೆ.
//!
//! ಈ ಮಾಡ್ಯೂಲ್ [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], ಸೇರಿದಂತೆ ಆಯ್ದ ಸಂಖ್ಯೆಯ ಪ್ರಾಚೀನ ಪ್ರಕಾರಗಳ ಪರಮಾಣು ಆವೃತ್ತಿಗಳನ್ನು ವ್ಯಾಖ್ಯಾನಿಸುತ್ತದೆ.
//! ಪರಮಾಣು ಪ್ರಕಾರಗಳು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಪ್ರಸ್ತುತಪಡಿಸುತ್ತವೆ, ಅದನ್ನು ಸರಿಯಾಗಿ ಬಳಸಿದಾಗ, ಎಳೆಗಳ ನಡುವೆ ನವೀಕರಣಗಳನ್ನು ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡುತ್ತದೆ.
//!
//! ಪ್ರತಿಯೊಂದು ವಿಧಾನವು [`Ordering`] ಅನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ, ಅದು ಆ ಕಾರ್ಯಾಚರಣೆಗೆ ಮೆಮೊರಿ ತಡೆಗೋಡೆಯ ಶಕ್ತಿಯನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.ಈ ಆದೇಶಗಳು [C++20 atomic orderings][1] ನಂತೆಯೇ ಇರುತ್ತವೆ.ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ [nomicon][2] ನೋಡಿ.
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! ಪರಮಾಣು ಅಸ್ಥಿರಗಳು ಎಳೆಗಳ ನಡುವೆ ಹಂಚಿಕೊಳ್ಳಲು ಸುರಕ್ಷಿತವಾಗಿದೆ (ಅವು [`Sync`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತವೆ) ಆದರೆ ಅವುಗಳು ಹಂಚಿಕೊಳ್ಳಲು ಯಾಂತ್ರಿಕ ವ್ಯವಸ್ಥೆಯನ್ನು ಒದಗಿಸುವುದಿಲ್ಲ ಮತ್ತು Rust ನ [threading model](../../../std/thread/index.html#the-threading-model) ಅನ್ನು ಅನುಸರಿಸುತ್ತವೆ.
//!
//! ಪರಮಾಣು ವೇರಿಯೇಬಲ್ ಅನ್ನು ಹಂಚಿಕೊಳ್ಳುವ ಸಾಮಾನ್ಯ ಮಾರ್ಗವೆಂದರೆ ಅದನ್ನು [`Arc`][arc] ಗೆ ಹಾಕುವುದು (ಪರಮಾಣು-ಉಲ್ಲೇಖ-ಎಣಿಸಿದ ಹಂಚಿದ ಪಾಯಿಂಟರ್).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! ಪರಮಾಣು ಪ್ರಕಾರಗಳನ್ನು ಸ್ಥಿರ ಅಸ್ಥಿರಗಳಲ್ಲಿ ಸಂಗ್ರಹಿಸಬಹುದು, [`AtomicBool::new`] ನಂತಹ ಸ್ಥಿರ ಇನಿಶಿಯಲೈಸರ್‌ಗಳನ್ನು ಬಳಸಿ ಪ್ರಾರಂಭಿಸಲಾಗುತ್ತದೆ.ಸೋಮಾರಿಯಾದ ಜಾಗತಿಕ ಪ್ರಾರಂಭಕ್ಕಾಗಿ ಪರಮಾಣು ಅಂಕಿಅಂಶಗಳನ್ನು ಹೆಚ್ಚಾಗಿ ಬಳಸಲಾಗುತ್ತದೆ.
//!
//! # Portability
//!
//! ಈ ಮಾಡ್ಯೂಲ್‌ನಲ್ಲಿರುವ ಎಲ್ಲಾ ಪರಮಾಣು ಪ್ರಕಾರಗಳು ಲಭ್ಯವಿದ್ದರೆ [lock-free] ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗುತ್ತದೆ.ಇದರರ್ಥ ಅವರು ಜಾಗತಿಕವಾಗಿ ಮ್ಯೂಟೆಕ್ಸ್ ಅನ್ನು ಸ್ವಾಧೀನಪಡಿಸಿಕೊಳ್ಳುವುದಿಲ್ಲ.ಪರಮಾಣು ಪ್ರಕಾರಗಳು ಮತ್ತು ಕಾರ್ಯಾಚರಣೆಗಳು ಕಾಯುವ ಮುಕ್ತ ಎಂದು ಖಾತರಿಪಡಿಸುವುದಿಲ್ಲ.
//! ಇದರರ್ಥ `fetch_or` ನಂತಹ ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಹೋಲಿಕೆ-ಮತ್ತು-ಸ್ವಾಪ್ ಲೂಪ್ನೊಂದಿಗೆ ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು.
//!
//! ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ದೊಡ್ಡ ಗಾತ್ರದ ಪರಮಾಣುಗಳೊಂದಿಗೆ ಸೂಚನಾ ಪದರದಲ್ಲಿ ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು.ಉದಾಹರಣೆಗೆ, ಕೆಲವು ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳು `AtomicI8` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು 4-ಬೈಟ್ ಪರಮಾಣು ಸೂಚನೆಗಳನ್ನು ಬಳಸುತ್ತವೆ.
//! ಈ ಎಮ್ಯುಲೇಶನ್ ಕೋಡ್‌ನ ನಿಖರತೆಯ ಮೇಲೆ ಪರಿಣಾಮ ಬೀರಬಾರದು ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಇದು ತಿಳಿದಿರಬೇಕಾದ ವಿಷಯ.
//!
//! ಈ ಮಾಡ್ಯೂಲ್‌ನಲ್ಲಿನ ಪರಮಾಣು ಪ್ರಕಾರಗಳು ಎಲ್ಲಾ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಲಭ್ಯವಿಲ್ಲದಿರಬಹುದು.ಇಲ್ಲಿ ಪರಮಾಣು ಪ್ರಕಾರಗಳು ವ್ಯಾಪಕವಾಗಿ ಲಭ್ಯವಿದೆ, ಆದರೆ ಸಾಮಾನ್ಯವಾಗಿ ಅಸ್ತಿತ್ವದಲ್ಲಿರುವದನ್ನು ಅವಲಂಬಿಸಬಹುದು.ಕೆಲವು ಗಮನಾರ್ಹ ಅಪವಾದಗಳು:
//!
//! * PowerPC ಮತ್ತು 32-ಬಿಟ್ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಹೊಂದಿರುವ MIPS ಪ್ಲಾಟ್‌ಫಾರ್ಮ್‌ಗಳು `AtomicU64` ಅಥವಾ `AtomicI64` ಪ್ರಕಾರಗಳನ್ನು ಹೊಂದಿಲ್ಲ.
//! * ARM Linux ಗಾಗಿರದ `armv5te` ನಂತಹ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್‌ಗಳು `load` ಮತ್ತು `store` ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಮಾತ್ರ ಒದಗಿಸುತ್ತವೆ, ಮತ್ತು `swap`, `fetch_add`, ಮುಂತಾದ (CAS) ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಹೋಲಿಕೆ ಮತ್ತು ಸ್ವಾಪ್ ಮಾಡುವುದನ್ನು ಬೆಂಬಲಿಸುವುದಿಲ್ಲ.
//! ಹೆಚ್ಚುವರಿಯಾಗಿ Linux ನಲ್ಲಿ, ಈ ಸಿಎಎಸ್ ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು [operating system support] ಮೂಲಕ ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗುತ್ತದೆ, ಇದು ಕಾರ್ಯಕ್ಷಮತೆಯ ದಂಡದೊಂದಿಗೆ ಬರಬಹುದು.
//! * ARM `thumbv6m` ಯೊಂದಿಗಿನ ಗುರಿಗಳು `load` ಮತ್ತು `store` ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಮಾತ್ರ ಒದಗಿಸುತ್ತವೆ, ಮತ್ತು `swap`, `fetch_add`, ಮುಂತಾದ (CAS) ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಹೋಲಿಕೆ ಮತ್ತು ಸ್ವಾಪ್ ಮಾಡುವುದನ್ನು ಬೆಂಬಲಿಸುವುದಿಲ್ಲ.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! ಕೆಲವು ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳಿಗೆ ಬೆಂಬಲವಿಲ್ಲದ future ಪ್ಲಾಟ್‌ಫಾರ್ಮ್‌ಗಳನ್ನು ಸೇರಿಸಬಹುದು ಎಂಬುದನ್ನು ಗಮನಿಸಿ.ಗರಿಷ್ಠ ಪೋರ್ಟಬಲ್ ಕೋಡ್ ಯಾವ ಪರಮಾಣು ಪ್ರಕಾರಗಳನ್ನು ಬಳಸಲಾಗುತ್ತದೆ ಎಂಬುದರ ಬಗ್ಗೆ ಜಾಗರೂಕರಾಗಿರಲು ಬಯಸುತ್ತದೆ.
//! `AtomicUsize` ಮತ್ತು `AtomicIsize` ಸಾಮಾನ್ಯವಾಗಿ ಹೆಚ್ಚು ಪೋರ್ಟಬಲ್ ಆಗಿರುತ್ತದೆ, ಆದರೆ ಆಗಲೂ ಅವು ಎಲ್ಲೆಡೆ ಲಭ್ಯವಿರುವುದಿಲ್ಲ.
//! ಉಲ್ಲೇಖಕ್ಕಾಗಿ, `std` ಲೈಬ್ರರಿಗೆ ಪಾಯಿಂಟರ್-ಗಾತ್ರದ ಪರಮಾಣುಗಳು ಬೇಕಾಗುತ್ತವೆ, ಆದರೂ `core` ಗೆ ಅಗತ್ಯವಿಲ್ಲ.
//!
//! ಪ್ರಸ್ತುತ ನೀವು ಪರಮಾಣುಗಳೊಂದಿಗೆ ಕೋಡ್‌ನಲ್ಲಿ ಷರತ್ತುಬದ್ಧವಾಗಿ ಕಂಪೈಲ್ ಮಾಡಲು `#[cfg(target_arch)]` ಅನ್ನು ಬಳಸಬೇಕಾಗುತ್ತದೆ.ಅಸ್ಥಿರವಾದ `#[cfg(target_has_atomic)]` ಇದೆ ಮತ್ತು ಅದನ್ನು future ನಲ್ಲಿ ಸ್ಥಿರಗೊಳಿಸಬಹುದು.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! ಸರಳ ಸ್ಪಿನ್‌ಲಾಕ್:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // ಲಾಕ್ ಅನ್ನು ಬಿಡುಗಡೆ ಮಾಡಲು ಇತರ ಥ್ರೆಡ್ಗಾಗಿ ಕಾಯಿರಿ
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! ಲೈವ್ ಎಳೆಗಳ ಜಾಗತಿಕ ಎಣಿಕೆ ಇರಿಸಿ:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// ಎಳೆಗಳ ನಡುವೆ ಸುರಕ್ಷಿತವಾಗಿ ಹಂಚಿಕೊಳ್ಳಬಹುದಾದ ಬೂಲಿಯನ್ ಪ್ರಕಾರ.
///
/// ಈ ಪ್ರಕಾರವು [`bool`] ನಂತೆಯೇ ಇನ್-ಮೆಮೊರಿ ಪ್ರಾತಿನಿಧ್ಯವನ್ನು ಹೊಂದಿದೆ.
///
/// **ಗಮನಿಸಿ**: ಈ ಪ್ರಕಾರವು ಪರಮಾಣು ಲೋಡ್‌ಗಳು ಮತ್ತು `u8` ನ ಮಳಿಗೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಲಭ್ಯವಿದೆ.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// `false` ಗೆ ಪ್ರಾರಂಭಿಸಲಾದ `AtomicBool` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// ಅಟಾಮಿಕ್‌ಬುಲ್‌ಗಾಗಿ ಕಳುಹಿಸುವುದನ್ನು ಸೂಚ್ಯವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗಿದೆ.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// ಎಳೆಗಳ ನಡುವೆ ಸುರಕ್ಷಿತವಾಗಿ ಹಂಚಿಕೊಳ್ಳಬಹುದಾದ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಪ್ರಕಾರ.
///
/// ಈ ಪ್ರಕಾರವು `*mut T` ನಂತೆಯೇ ಇನ್-ಮೆಮೊರಿ ಪ್ರಾತಿನಿಧ್ಯವನ್ನು ಹೊಂದಿದೆ.
///
/// **ಗಮನಿಸಿ**: ಪರಮಾಣು ಲೋಡ್‌ಗಳು ಮತ್ತು ಪಾಯಿಂಟರ್‌ಗಳ ಮಳಿಗೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಈ ಪ್ರಕಾರ ಲಭ್ಯವಿದೆ.
/// ಇದರ ಗಾತ್ರವು ಗುರಿ ಪಾಯಿಂಟರ್‌ನ ಗಾತ್ರವನ್ನು ಅವಲಂಬಿಸಿರುತ್ತದೆ.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// ಶೂನ್ಯ `AtomicPtr<T>` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// ಪರಮಾಣು ಮೆಮೊರಿ ಆದೇಶಗಳು
///
/// ಮೆಮೊರಿ ಆದೇಶಗಳು ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳು ಮೆಮೊರಿಯನ್ನು ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡುವ ವಿಧಾನವನ್ನು ಸೂಚಿಸುತ್ತವೆ.
/// ಅದರ ದುರ್ಬಲ [`Ordering::Relaxed`] ನಲ್ಲಿ, ಕಾರ್ಯಾಚರಣೆಯಿಂದ ನೇರವಾಗಿ ಸ್ಪರ್ಶಿಸಲಾದ ಮೆಮೊರಿಯನ್ನು ಮಾತ್ರ ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡಲಾಗುತ್ತದೆ.
/// ಮತ್ತೊಂದೆಡೆ, ಸ್ಟೋರ್-ಲೋಡ್ ಜೋಡಿ [`Ordering::SeqCst`] ಕಾರ್ಯಾಚರಣೆಗಳು ಇತರ ಮೆಮೊರಿಯನ್ನು ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡುತ್ತದೆ ಮತ್ತು ಹೆಚ್ಚುವರಿಯಾಗಿ ಎಲ್ಲಾ ಎಳೆಗಳಲ್ಲಿ ಅಂತಹ ಕಾರ್ಯಾಚರಣೆಗಳ ಒಟ್ಟು ಕ್ರಮವನ್ನು ಸಂರಕ್ಷಿಸುತ್ತದೆ.
///
///
/// Rust ನ ಮೆಮೊರಿ ಆದೇಶಗಳು [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ [nomicon] ನೋಡಿ.
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// ಯಾವುದೇ ಆದೇಶದ ನಿರ್ಬಂಧಗಳಿಲ್ಲ, ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳು ಮಾತ್ರ.
    ///
    /// C ++ 20 ನಲ್ಲಿ [`memory_order_relaxed`] ಗೆ ಅನುರೂಪವಾಗಿದೆ.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// ಅಂಗಡಿಯೊಂದಿಗೆ ಸೇರಿಕೊಂಡಾಗ, ಈ ಮೌಲ್ಯದ ಯಾವುದೇ ಲೋಡ್‌ಗೆ ಮೊದಲು [`Acquire`] (ಅಥವಾ ಬಲವಾದ) ಆದೇಶದೊಂದಿಗೆ ಎಲ್ಲಾ ಹಿಂದಿನ ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಆದೇಶಿಸಲಾಗುತ್ತದೆ.
    ///
    /// ನಿರ್ದಿಷ್ಟವಾಗಿ ಹೇಳುವುದಾದರೆ, ಈ ಮೌಲ್ಯದ [`Acquire`] (ಅಥವಾ ಬಲವಾದ) ಲೋಡ್ ಅನ್ನು ನಿರ್ವಹಿಸುವ ಎಲ್ಲಾ ಎಳೆಗಳಿಗೆ ಹಿಂದಿನ ಎಲ್ಲಾ ಬರಹಗಳು ಗೋಚರಿಸುತ್ತವೆ.
    ///
    /// ಲೋಡ್ ಮತ್ತು ಮಳಿಗೆಗಳನ್ನು ಸಂಯೋಜಿಸುವ ಕಾರ್ಯಾಚರಣೆಗಾಗಿ ಈ ಆದೇಶವನ್ನು ಬಳಸುವುದು [`Relaxed`] ಲೋಡ್ ಕಾರ್ಯಾಚರಣೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ!
    ///
    /// ಅಂಗಡಿಯನ್ನು ನಿರ್ವಹಿಸಬಲ್ಲ ಕಾರ್ಯಾಚರಣೆಗಳಿಗೆ ಮಾತ್ರ ಈ ಆದೇಶವು ಅನ್ವಯಿಸುತ್ತದೆ.
    ///
    /// C ++ 20 ನಲ್ಲಿ [`memory_order_release`] ಗೆ ಅನುರೂಪವಾಗಿದೆ.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// ಲೋಡ್‌ನೊಂದಿಗೆ ಸೇರಿಕೊಂಡಾಗ, ಲೋಡ್ ಮಾಡಲಾದ ಮೌಲ್ಯವನ್ನು [`Release`] (ಅಥವಾ ಬಲವಾದ) ಆದೇಶದೊಂದಿಗೆ ಅಂಗಡಿ ಕಾರ್ಯಾಚರಣೆಯಿಂದ ಬರೆಯಲಾಗಿದ್ದರೆ, ನಂತರದ ಎಲ್ಲಾ ಕಾರ್ಯಾಚರಣೆಗಳು ಆ ಅಂಗಡಿಯ ನಂತರ ಆದೇಶವಾಗುತ್ತವೆ.
    /// ನಿರ್ದಿಷ್ಟವಾಗಿ ಹೇಳುವುದಾದರೆ, ಎಲ್ಲಾ ನಂತರದ ಲೋಡ್‌ಗಳು ಅಂಗಡಿಯ ಮೊದಲು ಬರೆದ ಡೇಟಾವನ್ನು ನೋಡುತ್ತವೆ.
    ///
    /// ಲೋಡ್ ಮತ್ತು ಮಳಿಗೆಗಳನ್ನು ಸಂಯೋಜಿಸುವ ಕಾರ್ಯಾಚರಣೆಗಾಗಿ ಈ ಆದೇಶವನ್ನು ಬಳಸುವುದು [`Relaxed`] ಸ್ಟೋರ್ ಕಾರ್ಯಾಚರಣೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ!
    ///
    /// ಲೋಡ್ ಮಾಡಬಹುದಾದ ಕಾರ್ಯಾಚರಣೆಗಳಿಗೆ ಮಾತ್ರ ಈ ಆದೇಶವು ಅನ್ವಯಿಸುತ್ತದೆ.
    ///
    /// C ++ 20 ನಲ್ಲಿ [`memory_order_acquire`] ಗೆ ಅನುರೂಪವಾಗಿದೆ.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// [`Acquire`] ಮತ್ತು [`Release`] ಎರಡರ ಪರಿಣಾಮಗಳನ್ನು ಒಟ್ಟಿಗೆ ಹೊಂದಿದೆ:
    /// ಲೋಡ್‌ಗಳಿಗಾಗಿ ಇದು [`Acquire`] ಆದೇಶವನ್ನು ಬಳಸುತ್ತದೆ.ಮಳಿಗೆಗಳಿಗಾಗಿ ಇದು [`Release`] ಆದೇಶವನ್ನು ಬಳಸುತ್ತದೆ.
    ///
    /// `compare_and_swap` ನ ಸಂದರ್ಭದಲ್ಲಿ, ಕಾರ್ಯಾಚರಣೆಯು ಯಾವುದೇ ಅಂಗಡಿಯನ್ನು ನಿರ್ವಹಿಸದೆ ಕೊನೆಗೊಳ್ಳುವ ಸಾಧ್ಯತೆಯಿದೆ ಮತ್ತು ಆದ್ದರಿಂದ ಇದು ಕೇವಲ [`Acquire`] ಆದೇಶವನ್ನು ಹೊಂದಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    /// ಆದಾಗ್ಯೂ, `AcqRel` ಎಂದಿಗೂ [`Relaxed`] ಪ್ರವೇಶಗಳನ್ನು ನಿರ್ವಹಿಸುವುದಿಲ್ಲ.
    ///
    /// ಈ ಆದೇಶವು ಲೋಡ್‌ಗಳು ಮತ್ತು ಮಳಿಗೆಗಳನ್ನು ಸಂಯೋಜಿಸುವ ಕಾರ್ಯಾಚರಣೆಗಳಿಗೆ ಮಾತ್ರ ಅನ್ವಯಿಸುತ್ತದೆ.
    ///
    /// C ++ 20 ನಲ್ಲಿ [`memory_order_acq_rel`] ಗೆ ಅನುರೂಪವಾಗಿದೆ.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// ಎಲ್ಲಾ ಥ್ರೆಡ್‌ಗಳು ಎಲ್ಲಾ ಅನುಕ್ರಮ ಸ್ಥಿರ ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಒಂದೇ ಕ್ರಮದಲ್ಲಿ ನೋಡುತ್ತವೆ ಎಂಬ ಹೆಚ್ಚುವರಿ ಖಾತರಿಯೊಂದಿಗೆ [`ಪಡೆದುಕೊಳ್ಳಿ`]/[`ಬಿಡುಗಡೆ`]/[`ಅಕ್ರೆಲ್`](ಕ್ರಮವಾಗಿ ಲೋಡ್, ಸ್ಟೋರ್, ಮತ್ತು ಲೋಡ್-ವಿತ್-ಸ್ಟೋರ್ ಕಾರ್ಯಾಚರಣೆಗಳಿಗೆ). .
    ///
    ///
    /// C ++ 20 ನಲ್ಲಿ [`memory_order_seq_cst`] ಗೆ ಅನುರೂಪವಾಗಿದೆ.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] ಅನ್ನು `false` ಗೆ ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// ಹೊಸ `AtomicBool` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// ಆಧಾರವಾಗಿರುವ [`bool`] ಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಇದು ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ಇತರ ಯಾವುದೇ ಎಳೆಗಳು ಏಕಕಾಲದಲ್ಲಿ ಪರಮಾಣು ಡೇಟಾವನ್ನು ಪ್ರವೇಶಿಸುವುದಿಲ್ಲ ಎಂದು ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // ಸುರಕ್ಷತೆ: ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವು ಅನನ್ಯ ಮಾಲೀಕತ್ವವನ್ನು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// `&mut bool` ಗೆ ಪರಮಾಣು ಪ್ರವೇಶವನ್ನು ಪಡೆಯಿರಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // ಸುರಕ್ಷತೆ: ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವು ಅನನ್ಯ ಮಾಲೀಕತ್ವವನ್ನು ಖಾತರಿಪಡಿಸುತ್ತದೆ, ಮತ್ತು
        // `bool` ಮತ್ತು `Self` ಎರಡರ ಜೋಡಣೆ 1 ಆಗಿದೆ.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// ಪರಮಾಣುವನ್ನು ಬಳಸುತ್ತದೆ ಮತ್ತು ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಇದು ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ `self` ಅನ್ನು ಮೌಲ್ಯದಿಂದ ಹಾದುಹೋಗುವುದರಿಂದ ಬೇರೆ ಯಾವುದೇ ಎಳೆಗಳು ಏಕಕಾಲದಲ್ಲಿ ಪರಮಾಣು ಡೇಟಾವನ್ನು ಪ್ರವೇಶಿಸುವುದಿಲ್ಲ ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// bool ನಿಂದ ಮೌಲ್ಯವನ್ನು ಲೋಡ್ ಮಾಡುತ್ತದೆ.
    ///
    /// `load` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸುವ [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    /// ಸಂಭಾವ್ಯ ಮೌಲ್ಯಗಳು [`SeqCst`], [`Acquire`] ಮತ್ತು [`Relaxed`].
    ///
    /// # Panics
    ///
    /// `order` [`Release`] ಅಥವಾ [`AcqRel`] ಆಗಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // ಸುರಕ್ಷತೆ: ಯಾವುದೇ ಡೇಟಾ ರೇಸ್ಗಳನ್ನು ಪರಮಾಣು ಆಂತರಿಕ ಮತ್ತು ಕಚ್ಚಾ ತಡೆಯುತ್ತದೆ
        // ರವಾನಿಸಿದ ಪಾಯಿಂಟರ್ ಮಾನ್ಯವಾಗಿದೆ ಏಕೆಂದರೆ ನಾವು ಅದನ್ನು ಉಲ್ಲೇಖದಿಂದ ಪಡೆದುಕೊಂಡಿದ್ದೇವೆ.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// ಮೌಲ್ಯವನ್ನು bool ಗೆ ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// `store` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸುವ [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    /// ಸಂಭಾವ್ಯ ಮೌಲ್ಯಗಳು [`SeqCst`], [`Release`] ಮತ್ತು [`Relaxed`].
    ///
    /// # Panics
    ///
    /// `order` [`Acquire`] ಅಥವಾ [`AcqRel`] ಆಗಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // ಸುರಕ್ಷತೆ: ಯಾವುದೇ ಡೇಟಾ ರೇಸ್ಗಳನ್ನು ಪರಮಾಣು ಆಂತರಿಕ ಮತ್ತು ಕಚ್ಚಾ ತಡೆಯುತ್ತದೆ
        // ರವಾನಿಸಿದ ಪಾಯಿಂಟರ್ ಮಾನ್ಯವಾಗಿದೆ ಏಕೆಂದರೆ ನಾವು ಅದನ್ನು ಉಲ್ಲೇಖದಿಂದ ಪಡೆದುಕೊಂಡಿದ್ದೇವೆ.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// ಮೌಲ್ಯವನ್ನು bool ಗೆ ಸಂಗ್ರಹಿಸುತ್ತದೆ, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `swap` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸುವ [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.ಎಲ್ಲಾ ಆದೇಶ ವಿಧಾನಗಳು ಸಾಧ್ಯ.
    /// [`Acquire`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಅಂಗಡಿಯು ಈ ಕಾರ್ಯಾಚರಣೆಯ [`Relaxed`] ನ ಭಾಗವಾಗಿಸುತ್ತದೆ ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಲೋಡ್ ಭಾಗ [`Relaxed`] ಆಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    ///
    /// **Note:** ಈ ವಿಧಾನವು `u8` ನಲ್ಲಿ ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಲಭ್ಯವಿದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಆಂತರಿಕತೆಯಿಂದ ಡೇಟಾ ರೇಸ್‌ಗಳನ್ನು ತಡೆಯಲಾಗುತ್ತದೆ.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `current` ಮೌಲ್ಯದಂತೆಯೇ ಇದ್ದರೆ ಮೌಲ್ಯವನ್ನು [`bool`] ಗೆ ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// ರಿಟರ್ನ್ ಮೌಲ್ಯವು ಯಾವಾಗಲೂ ಹಿಂದಿನ ಮೌಲ್ಯವಾಗಿರುತ್ತದೆ.ಇದು `current` ಗೆ ಸಮನಾಗಿದ್ದರೆ, ನಂತರ ಮೌಲ್ಯವನ್ನು ನವೀಕರಿಸಲಾಗಿದೆ.
    ///
    /// `compare_and_swap` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸುವ [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್ ಅನ್ನು ಸಹ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    /// [`AcqRel`] ಅನ್ನು ಬಳಸುವಾಗಲೂ ಸಹ, ಕಾರ್ಯಾಚರಣೆಯು ವಿಫಲವಾಗಬಹುದು ಮತ್ತು ಆದ್ದರಿಂದ ಕೇವಲ `Acquire` ಲೋಡ್ ಅನ್ನು ನಿರ್ವಹಿಸಬಹುದು, ಆದರೆ `Release` ಶಬ್ದಾರ್ಥವನ್ನು ಹೊಂದಿರುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    /// [`Acquire`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಅದು ಸಂಭವಿಸಿದಲ್ಲಿ [`Relaxed`] ಈ ಕಾರ್ಯಾಚರಣೆಯ ಅಂಗಡಿಯನ್ನು ಮಾಡುತ್ತದೆ, ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಲೋಡ್ ಭಾಗ [`Relaxed`] ಆಗುತ್ತದೆ.
    ///
    /// **Note:** ಈ ವಿಧಾನವು `u8` ನಲ್ಲಿ ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಲಭ್ಯವಿದೆ.
    ///
    /// # `compare_exchange` ಮತ್ತು `compare_exchange_weak` ಗೆ ವಲಸೆ ಹೋಗುತ್ತಿದೆ
    ///
    /// `compare_and_swap` ಮೆಮೊರಿ ಆದೇಶಗಳಿಗಾಗಿ ಈ ಕೆಳಗಿನ ಮ್ಯಾಪಿಂಗ್‌ನೊಂದಿಗೆ `compare_exchange` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ:
    ///
    /// ಮೂಲ |ಯಶಸ್ಸು |ವೈಫಲ್ಯ
    /// -------- | ------- | -------
    /// ವಿಶ್ರಾಂತಿ |ವಿಶ್ರಾಂತಿ |ವಿಶ್ರಾಂತಿ ಪಡೆದುಕೊಳ್ಳಿ |ಪಡೆದುಕೊಳ್ಳಿ |ಬಿಡುಗಡೆಯನ್ನು ಪಡೆದುಕೊಳ್ಳಿ |ಬಿಡುಗಡೆ |ವಿಶ್ರಾಂತಿ ಅಕ್ರೆಲ್ |ಅಕ್ರೆಲ್ |SeqCst ಅನ್ನು ಪಡೆದುಕೊಳ್ಳಿ |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` ಹೋಲಿಕೆ ಯಶಸ್ವಿಯಾದಾಗಲೂ ವಿಪರೀತವಾಗಿ ವಿಫಲಗೊಳ್ಳಲು ಅನುಮತಿಸಲಾಗಿದೆ, ಇದು ಹೋಲಿಕೆ ಮತ್ತು ಸ್ವಾಪ್ ಅನ್ನು ಲೂಪ್‌ನಲ್ಲಿ ಬಳಸಿದಾಗ ಕಂಪೈಲರ್ ಉತ್ತಮ ಜೋಡಣೆ ಕೋಡ್ ಅನ್ನು ರಚಿಸಲು ಅನುಮತಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `current` ಮೌಲ್ಯದಂತೆಯೇ ಇದ್ದರೆ ಮೌಲ್ಯವನ್ನು [`bool`] ಗೆ ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// ರಿಟರ್ನ್ ಮೌಲ್ಯವು ಹೊಸ ಮೌಲ್ಯವನ್ನು ಬರೆಯಲಾಗಿದೆಯೆ ಮತ್ತು ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿದೆಯೆ ಎಂದು ಸೂಚಿಸುವ ಫಲಿತಾಂಶವಾಗಿದೆ.
    /// ಯಶಸ್ಸಿನ ನಂತರ ಈ ಮೌಲ್ಯವು `current` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.
    ///
    /// `compare_exchange` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸಲು ಎರಡು [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್‌ಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    /// `success` `current` ನೊಂದಿಗೆ ಹೋಲಿಕೆ ಯಶಸ್ವಿಯಾದರೆ ನಡೆಯುವ ರೀಡ್-ಮಾರ್ಪಡಿಸಿ-ಬರೆಯುವ ಕಾರ್ಯಾಚರಣೆಗೆ ಅಗತ್ಯವಾದ ಆದೇಶವನ್ನು ವಿವರಿಸುತ್ತದೆ.
    /// `failure` ಹೋಲಿಕೆ ವಿಫಲವಾದಾಗ ನಡೆಯುವ ಲೋಡ್ ಕಾರ್ಯಾಚರಣೆಗೆ ಅಗತ್ಯವಾದ ಆದೇಶವನ್ನು ವಿವರಿಸುತ್ತದೆ.
    /// [`Acquire`] ಅನ್ನು ಯಶಸ್ಸಿನ ಆದೇಶದಂತೆ ಬಳಸುವುದರಿಂದ ಅಂಗಡಿಯು [`Relaxed`] ನ ಅಂಗಡಿಯ ಭಾಗವಾಗಿಸುತ್ತದೆ, ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಯಶಸ್ವಿ ಲೋಡ್ [`Relaxed`] ಆಗುತ್ತದೆ.
    ///
    /// ವೈಫಲ್ಯ ಆದೇಶವು [`SeqCst`], [`Acquire`] ಅಥವಾ [`Relaxed`] ಆಗಿರಬಹುದು ಮತ್ತು ಯಶಸ್ಸಿನ ಆದೇಶಕ್ಕಿಂತ ಸಮನಾಗಿರಬೇಕು ಅಥವಾ ದುರ್ಬಲವಾಗಿರಬೇಕು.
    ///
    /// **Note:** ಈ ವಿಧಾನವು `u8` ನಲ್ಲಿ ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಲಭ್ಯವಿದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಆಂತರಿಕತೆಯಿಂದ ಡೇಟಾ ರೇಸ್‌ಗಳನ್ನು ತಡೆಯಲಾಗುತ್ತದೆ.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `current` ಮೌಲ್ಯದಂತೆಯೇ ಇದ್ದರೆ ಮೌಲ್ಯವನ್ನು [`bool`] ಗೆ ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// [`AtomicBool::compare_exchange`] ಗಿಂತ ಭಿನ್ನವಾಗಿ, ಹೋಲಿಕೆ ಯಶಸ್ವಿಯಾದಾಗಲೂ ಈ ಕಾರ್ಯವು ವಿಪರೀತವಾಗಿ ವಿಫಲಗೊಳ್ಳಲು ಅನುಮತಿಸಲಾಗಿದೆ, ಇದು ಕೆಲವು ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಹೆಚ್ಚು ಪರಿಣಾಮಕಾರಿಯಾದ ಕೋಡ್‌ಗೆ ಕಾರಣವಾಗಬಹುದು.
    ///
    /// ರಿಟರ್ನ್ ಮೌಲ್ಯವು ಹೊಸ ಮೌಲ್ಯವನ್ನು ಬರೆಯಲಾಗಿದೆಯೆ ಮತ್ತು ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿದೆಯೆ ಎಂದು ಸೂಚಿಸುವ ಫಲಿತಾಂಶವಾಗಿದೆ.
    ///
    /// `compare_exchange_weak` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸಲು ಎರಡು [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್‌ಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    /// `success` `current` ನೊಂದಿಗೆ ಹೋಲಿಕೆ ಯಶಸ್ವಿಯಾದರೆ ನಡೆಯುವ ರೀಡ್-ಮಾರ್ಪಡಿಸಿ-ಬರೆಯುವ ಕಾರ್ಯಾಚರಣೆಗೆ ಅಗತ್ಯವಾದ ಆದೇಶವನ್ನು ವಿವರಿಸುತ್ತದೆ.
    /// `failure` ಹೋಲಿಕೆ ವಿಫಲವಾದಾಗ ನಡೆಯುವ ಲೋಡ್ ಕಾರ್ಯಾಚರಣೆಗೆ ಅಗತ್ಯವಾದ ಆದೇಶವನ್ನು ವಿವರಿಸುತ್ತದೆ.
    /// [`Acquire`] ಅನ್ನು ಯಶಸ್ಸಿನ ಆದೇಶದಂತೆ ಬಳಸುವುದರಿಂದ ಅಂಗಡಿಯು [`Relaxed`] ನ ಅಂಗಡಿಯ ಭಾಗವಾಗಿಸುತ್ತದೆ, ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಯಶಸ್ವಿ ಲೋಡ್ [`Relaxed`] ಆಗುತ್ತದೆ.
    /// ವೈಫಲ್ಯ ಆದೇಶವು [`SeqCst`], [`Acquire`] ಅಥವಾ [`Relaxed`] ಆಗಿರಬಹುದು ಮತ್ತು ಯಶಸ್ಸಿನ ಆದೇಶಕ್ಕಿಂತ ಸಮನಾಗಿರಬೇಕು ಅಥವಾ ದುರ್ಬಲವಾಗಿರಬೇಕು.
    ///
    /// **Note:** ಈ ವಿಧಾನವು `u8` ನಲ್ಲಿ ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಲಭ್ಯವಿದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಆಂತರಿಕತೆಯಿಂದ ಡೇಟಾ ರೇಸ್‌ಗಳನ್ನು ತಡೆಯಲಾಗುತ್ತದೆ.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// ಬೂಲಿಯನ್ ಮೌಲ್ಯದೊಂದಿಗೆ ತಾರ್ಕಿಕ "and".
    ///
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯ ಮತ್ತು ಆರ್ಗ್ಯುಮೆಂಟ್ `val` ನಲ್ಲಿ ತಾರ್ಕಿಕ "and" ಕಾರ್ಯಾಚರಣೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ ಮತ್ತು ಫಲಿತಾಂಶಕ್ಕೆ ಹೊಸ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿಸುತ್ತದೆ.
    ///
    /// ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `fetch_and` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸುವ [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.ಎಲ್ಲಾ ಆದೇಶ ವಿಧಾನಗಳು ಸಾಧ್ಯ.
    /// [`Acquire`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಅಂಗಡಿಯು ಈ ಕಾರ್ಯಾಚರಣೆಯ [`Relaxed`] ನ ಭಾಗವಾಗಿಸುತ್ತದೆ ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಲೋಡ್ ಭಾಗ [`Relaxed`] ಆಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    ///
    /// **Note:** ಈ ವಿಧಾನವು `u8` ನಲ್ಲಿ ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಲಭ್ಯವಿದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಆಂತರಿಕತೆಯಿಂದ ಡೇಟಾ ರೇಸ್‌ಗಳನ್ನು ತಡೆಯಲಾಗುತ್ತದೆ.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// ಬೂಲಿಯನ್ ಮೌಲ್ಯದೊಂದಿಗೆ ತಾರ್ಕಿಕ "nand".
    ///
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯ ಮತ್ತು ಆರ್ಗ್ಯುಮೆಂಟ್ `val` ನಲ್ಲಿ ತಾರ್ಕಿಕ "nand" ಕಾರ್ಯಾಚರಣೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ ಮತ್ತು ಫಲಿತಾಂಶಕ್ಕೆ ಹೊಸ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿಸುತ್ತದೆ.
    ///
    /// ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `fetch_nand` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸುವ [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.ಎಲ್ಲಾ ಆದೇಶ ವಿಧಾನಗಳು ಸಾಧ್ಯ.
    /// [`Acquire`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಅಂಗಡಿಯು ಈ ಕಾರ್ಯಾಚರಣೆಯ [`Relaxed`] ನ ಭಾಗವಾಗಿಸುತ್ತದೆ ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಲೋಡ್ ಭಾಗ [`Relaxed`] ಆಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    ///
    /// **Note:** ಈ ವಿಧಾನವು `u8` ನಲ್ಲಿ ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಲಭ್ಯವಿದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // ನಾವು ಇಲ್ಲಿ ಪರಮಾಣು_ನಾಂಡ್ ಅನ್ನು ಬಳಸಲಾಗುವುದಿಲ್ಲ ಏಕೆಂದರೆ ಅದು ಅಮಾನ್ಯ ಮೌಲ್ಯದೊಂದಿಗೆ bool ಗೆ ಕಾರಣವಾಗಬಹುದು.
        // ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಯನ್ನು ಆಂತರಿಕವಾಗಿ 8-ಬಿಟ್ ಪೂರ್ಣಾಂಕದೊಂದಿಗೆ ಮಾಡಲಾಗುತ್ತದೆ, ಇದು ಮೇಲಿನ 7 ಬಿಟ್‌ಗಳನ್ನು ಹೊಂದಿಸುತ್ತದೆ.
        //
        // ಆದ್ದರಿಂದ ನಾವು ಬದಲಿಗೆ fetch_xor ಅಥವಾ swap ಅನ್ನು ಬಳಸುತ್ತೇವೆ.
        if val {
            // ! (x&true)== !x ನಾವು bool ಅನ್ನು ತಲೆಕೆಳಗಾಗಿಸಬೇಕು.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true ನಾವು bool ಅನ್ನು ನಿಜ ಎಂದು ಹೊಂದಿಸಬೇಕು.
            //
            self.swap(true, order)
        }
    }

    /// ಬೂಲಿಯನ್ ಮೌಲ್ಯದೊಂದಿಗೆ ತಾರ್ಕಿಕ "or".
    ///
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯ ಮತ್ತು ಆರ್ಗ್ಯುಮೆಂಟ್ `val` ನಲ್ಲಿ ತಾರ್ಕಿಕ "or" ಕಾರ್ಯಾಚರಣೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ ಮತ್ತು ಫಲಿತಾಂಶಕ್ಕೆ ಹೊಸ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿಸುತ್ತದೆ.
    ///
    /// ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `fetch_or` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸುವ [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.ಎಲ್ಲಾ ಆದೇಶ ವಿಧಾನಗಳು ಸಾಧ್ಯ.
    /// [`Acquire`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಅಂಗಡಿಯು ಈ ಕಾರ್ಯಾಚರಣೆಯ [`Relaxed`] ನ ಭಾಗವಾಗಿಸುತ್ತದೆ ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಲೋಡ್ ಭಾಗ [`Relaxed`] ಆಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    ///
    /// **Note:** ಈ ವಿಧಾನವು `u8` ನಲ್ಲಿ ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಲಭ್ಯವಿದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಆಂತರಿಕತೆಯಿಂದ ಡೇಟಾ ರೇಸ್‌ಗಳನ್ನು ತಡೆಯಲಾಗುತ್ತದೆ.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// ಬೂಲಿಯನ್ ಮೌಲ್ಯದೊಂದಿಗೆ ತಾರ್ಕಿಕ "xor".
    ///
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯ ಮತ್ತು ಆರ್ಗ್ಯುಮೆಂಟ್ `val` ನಲ್ಲಿ ತಾರ್ಕಿಕ "xor" ಕಾರ್ಯಾಚರಣೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ ಮತ್ತು ಫಲಿತಾಂಶಕ್ಕೆ ಹೊಸ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿಸುತ್ತದೆ.
    ///
    /// ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `fetch_xor` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸುವ [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.ಎಲ್ಲಾ ಆದೇಶ ವಿಧಾನಗಳು ಸಾಧ್ಯ.
    /// [`Acquire`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಅಂಗಡಿಯು ಈ ಕಾರ್ಯಾಚರಣೆಯ [`Relaxed`] ನ ಭಾಗವಾಗಿಸುತ್ತದೆ ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಲೋಡ್ ಭಾಗ [`Relaxed`] ಆಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    ///
    /// **Note:** ಈ ವಿಧಾನವು `u8` ನಲ್ಲಿ ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಲಭ್ಯವಿದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಆಂತರಿಕತೆಯಿಂದ ಡೇಟಾ ರೇಸ್‌ಗಳನ್ನು ತಡೆಯಲಾಗುತ್ತದೆ.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// ರೂಪಾಂತರಗೊಳ್ಳುವ ಪಾಯಿಂಟರ್ ಅನ್ನು ಆಧಾರವಾಗಿರುವ [`bool`] ಗೆ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಪರಮಾಣು ರಹಿತ ಓದುವಿಕೆ ಮತ್ತು ಬರೆಯುವಿಕೆಯು ಪೂರ್ಣಾಂಕದಲ್ಲಿ ಡೇಟಾ ರೇಸ್ ಆಗಿರಬಹುದು.
    /// ಈ ವಿಧಾನವು ಎಫ್‌ಎಫ್‌ಐಗೆ ಹೆಚ್ಚಾಗಿ ಉಪಯುಕ್ತವಾಗಿದೆ, ಅಲ್ಲಿ ಫಂಕ್ಷನ್ ಸಿಗ್ನೇಚರ್ `&AtomicBool` ಬದಲಿಗೆ `*mut bool` ಅನ್ನು ಬಳಸಬಹುದು.
    ///
    /// ಈ ಪರಮಾಣುವಿನ ಹಂಚಿಕೆಯ ಉಲ್ಲೇಖದಿಂದ `*mut` ಪಾಯಿಂಟರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ಪರಮಾಣು ಪ್ರಕಾರಗಳು ಆಂತರಿಕ ರೂಪಾಂತರದೊಂದಿಗೆ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತವೆ.
    /// ಪರಮಾಣುವಿನ ಎಲ್ಲಾ ಮಾರ್ಪಾಡುಗಳು ಹಂಚಿಕೆಯ ಉಲ್ಲೇಖದ ಮೂಲಕ ಮೌಲ್ಯವನ್ನು ಬದಲಾಯಿಸುತ್ತವೆ ಮತ್ತು ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬಳಸುವವರೆಗೂ ಅದನ್ನು ಸುರಕ್ಷಿತವಾಗಿ ಮಾಡಬಹುದು.
    /// ಹಿಂತಿರುಗಿದ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ನ ಯಾವುದೇ ಬಳಕೆಗೆ `unsafe` ಬ್ಲಾಕ್ ಅಗತ್ಯವಿರುತ್ತದೆ ಮತ್ತು ಇನ್ನೂ ಅದೇ ನಿರ್ಬಂಧವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕಾಗುತ್ತದೆ: ಅದರ ಮೇಲಿನ ಕಾರ್ಯಾಚರಣೆಗಳು ಪರಮಾಣು ಆಗಿರಬೇಕು.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// ಮೌಲ್ಯವನ್ನು ಪಡೆಯುತ್ತದೆ, ಮತ್ತು ಐಚ್ al ಿಕ ಹೊಸ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುವ ಕಾರ್ಯವನ್ನು ಅದಕ್ಕೆ ಅನ್ವಯಿಸುತ್ತದೆ.ಕಾರ್ಯವು `Some(_)` ಅನ್ನು ಹಿಂದಿರುಗಿಸಿದರೆ `Ok(previous_value)` ನ `Result` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ `Err(previous_value)`.
    ///
    /// Note: ಕಾರ್ಯವು `Some(_)` ಅನ್ನು ಹಿಂದಿರುಗಿಸುವವರೆಗೆ, ಈ ಮಧ್ಯೆ ಇತರ ಎಳೆಗಳಿಂದ ಮೌಲ್ಯವನ್ನು ಬದಲಾಯಿಸಿದ್ದರೆ ಇದು ಕಾರ್ಯವನ್ನು ಹಲವು ಬಾರಿ ಕರೆಯಬಹುದು, ಆದರೆ ಕಾರ್ಯವನ್ನು ಸಂಗ್ರಹಿಸಿದ ಮೌಲ್ಯಕ್ಕೆ ಒಮ್ಮೆ ಮಾತ್ರ ಅನ್ವಯಿಸಲಾಗುತ್ತದೆ.
    ///
    ///
    /// `fetch_update` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸಲು ಎರಡು [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್‌ಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    /// ಮೊದಲನೆಯದು ಕಾರ್ಯಾಚರಣೆಯು ಅಂತಿಮವಾಗಿ ಯಶಸ್ವಿಯಾದಾಗ ಅಗತ್ಯವಾದ ಆದೇಶವನ್ನು ವಿವರಿಸುತ್ತದೆ ಮತ್ತು ಎರಡನೆಯದು ಲೋಡ್‌ಗಳಿಗೆ ಅಗತ್ಯವಾದ ಆದೇಶವನ್ನು ವಿವರಿಸುತ್ತದೆ.
    /// ಇವು ಕ್ರಮವಾಗಿ [`AtomicBool::compare_exchange`] ನ ಯಶಸ್ಸು ಮತ್ತು ವೈಫಲ್ಯದ ಆದೇಶಗಳಿಗೆ ಅನುರೂಪವಾಗಿದೆ.
    ///
    /// [`Acquire`] ಅನ್ನು ಯಶಸ್ಸಿನ ಆದೇಶದಂತೆ ಬಳಸುವುದರಿಂದ ಅಂಗಡಿಯು [`Relaxed`] ನ ಅಂಗಡಿಯ ಭಾಗವಾಗಿಸುತ್ತದೆ, ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಅಂತಿಮ ಯಶಸ್ವಿ ಲೋಡ್ [`Relaxed`] ಆಗುತ್ತದೆ.
    /// (failed) ಲೋಡ್ ಆದೇಶವು [`SeqCst`], [`Acquire`] ಅಥವಾ [`Relaxed`] ಆಗಿರಬಹುದು ಮತ್ತು ಯಶಸ್ಸಿನ ಆದೇಶಕ್ಕಿಂತ ಸಮನಾಗಿರಬೇಕು ಅಥವಾ ದುರ್ಬಲವಾಗಿರಬೇಕು.
    ///
    /// **Note:** ಈ ವಿಧಾನವು `u8` ನಲ್ಲಿ ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಲಭ್ಯವಿದೆ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// ಹೊಸ `AtomicPtr` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// ಆಧಾರವಾಗಿರುವ ಪಾಯಿಂಟರ್‌ಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಇದು ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ಇತರ ಯಾವುದೇ ಎಳೆಗಳು ಏಕಕಾಲದಲ್ಲಿ ಪರಮಾಣು ಡೇಟಾವನ್ನು ಪ್ರವೇಶಿಸುವುದಿಲ್ಲ ಎಂದು ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// ಪಾಯಿಂಟರ್‌ಗೆ ಪರಮಾಣು ಪ್ರವೇಶವನ್ನು ಪಡೆಯಿರಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವು ಅನನ್ಯ ಮಾಲೀಕತ್ವವನ್ನು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
        //  - ಮೇಲೆ ಪರಿಶೀಲಿಸಿದಂತೆ, rust ನಿಂದ ಬೆಂಬಲಿತವಾದ ಎಲ್ಲಾ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ `*mut T` ಮತ್ತು `Self` ನ ಜೋಡಣೆ ಒಂದೇ ಆಗಿರುತ್ತದೆ.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// ಪರಮಾಣುವನ್ನು ಬಳಸುತ್ತದೆ ಮತ್ತು ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಇದು ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ `self` ಅನ್ನು ಮೌಲ್ಯದಿಂದ ಹಾದುಹೋಗುವುದರಿಂದ ಬೇರೆ ಯಾವುದೇ ಎಳೆಗಳು ಏಕಕಾಲದಲ್ಲಿ ಪರಮಾಣು ಡೇಟಾವನ್ನು ಪ್ರವೇಶಿಸುವುದಿಲ್ಲ ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// ಪಾಯಿಂಟರ್‌ನಿಂದ ಮೌಲ್ಯವನ್ನು ಲೋಡ್ ಮಾಡುತ್ತದೆ.
    ///
    /// `load` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸುವ [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    /// ಸಂಭಾವ್ಯ ಮೌಲ್ಯಗಳು [`SeqCst`], [`Acquire`] ಮತ್ತು [`Relaxed`].
    ///
    /// # Panics
    ///
    /// `order` [`Release`] ಅಥವಾ [`AcqRel`] ಆಗಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಆಂತರಿಕತೆಯಿಂದ ಡೇಟಾ ರೇಸ್‌ಗಳನ್ನು ತಡೆಯಲಾಗುತ್ತದೆ.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// ಪಾಯಿಂಟರ್‌ನಲ್ಲಿ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// `store` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸುವ [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    /// ಸಂಭಾವ್ಯ ಮೌಲ್ಯಗಳು [`SeqCst`], [`Release`] ಮತ್ತು [`Relaxed`].
    ///
    /// # Panics
    ///
    /// `order` [`Acquire`] ಅಥವಾ [`AcqRel`] ಆಗಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಆಂತರಿಕತೆಯಿಂದ ಡೇಟಾ ರೇಸ್‌ಗಳನ್ನು ತಡೆಯಲಾಗುತ್ತದೆ.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುವ ಮೂಲಕ ಪಾಯಿಂಟರ್‌ನಲ್ಲಿ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// `swap` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸುವ [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.ಎಲ್ಲಾ ಆದೇಶ ವಿಧಾನಗಳು ಸಾಧ್ಯ.
    /// [`Acquire`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಅಂಗಡಿಯು ಈ ಕಾರ್ಯಾಚರಣೆಯ [`Relaxed`] ನ ಭಾಗವಾಗಿಸುತ್ತದೆ ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಲೋಡ್ ಭಾಗ [`Relaxed`] ಆಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    ///
    /// **Note:** ಪಾಯಿಂಟರ್‌ಗಳಲ್ಲಿ ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಯನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಈ ವಿಧಾನ ಲಭ್ಯವಿದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಆಂತರಿಕತೆಯಿಂದ ಡೇಟಾ ರೇಸ್‌ಗಳನ್ನು ತಡೆಯಲಾಗುತ್ತದೆ.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `current` ಮೌಲ್ಯಕ್ಕೆ ಸಮನಾಗಿದ್ದರೆ ಮೌಲ್ಯವನ್ನು ಪಾಯಿಂಟರ್‌ನಲ್ಲಿ ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// ರಿಟರ್ನ್ ಮೌಲ್ಯವು ಯಾವಾಗಲೂ ಹಿಂದಿನ ಮೌಲ್ಯವಾಗಿರುತ್ತದೆ.ಇದು `current` ಗೆ ಸಮನಾಗಿದ್ದರೆ, ನಂತರ ಮೌಲ್ಯವನ್ನು ನವೀಕರಿಸಲಾಗಿದೆ.
    ///
    /// `compare_and_swap` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸುವ [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್ ಅನ್ನು ಸಹ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    /// [`AcqRel`] ಅನ್ನು ಬಳಸುವಾಗಲೂ ಸಹ, ಕಾರ್ಯಾಚರಣೆಯು ವಿಫಲವಾಗಬಹುದು ಮತ್ತು ಆದ್ದರಿಂದ ಕೇವಲ `Acquire` ಲೋಡ್ ಅನ್ನು ನಿರ್ವಹಿಸಬಹುದು, ಆದರೆ `Release` ಶಬ್ದಾರ್ಥವನ್ನು ಹೊಂದಿರುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    /// [`Acquire`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಅದು ಸಂಭವಿಸಿದಲ್ಲಿ [`Relaxed`] ಈ ಕಾರ್ಯಾಚರಣೆಯ ಅಂಗಡಿಯನ್ನು ಮಾಡುತ್ತದೆ, ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಲೋಡ್ ಭಾಗ [`Relaxed`] ಆಗುತ್ತದೆ.
    ///
    /// **Note:** ಪಾಯಿಂಟರ್‌ಗಳಲ್ಲಿ ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಯನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಈ ವಿಧಾನ ಲಭ್ಯವಿದೆ.
    ///
    /// # `compare_exchange` ಮತ್ತು `compare_exchange_weak` ಗೆ ವಲಸೆ ಹೋಗುತ್ತಿದೆ
    ///
    /// `compare_and_swap` ಮೆಮೊರಿ ಆದೇಶಗಳಿಗಾಗಿ ಈ ಕೆಳಗಿನ ಮ್ಯಾಪಿಂಗ್‌ನೊಂದಿಗೆ `compare_exchange` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ:
    ///
    /// ಮೂಲ |ಯಶಸ್ಸು |ವೈಫಲ್ಯ
    /// -------- | ------- | -------
    /// ವಿಶ್ರಾಂತಿ |ವಿಶ್ರಾಂತಿ |ವಿಶ್ರಾಂತಿ ಪಡೆದುಕೊಳ್ಳಿ |ಪಡೆದುಕೊಳ್ಳಿ |ಬಿಡುಗಡೆಯನ್ನು ಪಡೆದುಕೊಳ್ಳಿ |ಬಿಡುಗಡೆ |ವಿಶ್ರಾಂತಿ ಅಕ್ರೆಲ್ |ಅಕ್ರೆಲ್ |SeqCst ಅನ್ನು ಪಡೆದುಕೊಳ್ಳಿ |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` ಹೋಲಿಕೆ ಯಶಸ್ವಿಯಾದಾಗಲೂ ವಿಪರೀತವಾಗಿ ವಿಫಲಗೊಳ್ಳಲು ಅನುಮತಿಸಲಾಗಿದೆ, ಇದು ಹೋಲಿಕೆ ಮತ್ತು ಸ್ವಾಪ್ ಅನ್ನು ಲೂಪ್‌ನಲ್ಲಿ ಬಳಸಿದಾಗ ಕಂಪೈಲರ್ ಉತ್ತಮ ಜೋಡಣೆ ಕೋಡ್ ಅನ್ನು ರಚಿಸಲು ಅನುಮತಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `current` ಮೌಲ್ಯಕ್ಕೆ ಸಮನಾಗಿದ್ದರೆ ಮೌಲ್ಯವನ್ನು ಪಾಯಿಂಟರ್‌ನಲ್ಲಿ ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// ರಿಟರ್ನ್ ಮೌಲ್ಯವು ಹೊಸ ಮೌಲ್ಯವನ್ನು ಬರೆಯಲಾಗಿದೆಯೆ ಮತ್ತು ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿದೆಯೆ ಎಂದು ಸೂಚಿಸುವ ಫಲಿತಾಂಶವಾಗಿದೆ.
    /// ಯಶಸ್ಸಿನ ನಂತರ ಈ ಮೌಲ್ಯವು `current` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.
    ///
    /// `compare_exchange` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸಲು ಎರಡು [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್‌ಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    /// `success` `current` ನೊಂದಿಗೆ ಹೋಲಿಕೆ ಯಶಸ್ವಿಯಾದರೆ ನಡೆಯುವ ರೀಡ್-ಮಾರ್ಪಡಿಸಿ-ಬರೆಯುವ ಕಾರ್ಯಾಚರಣೆಗೆ ಅಗತ್ಯವಾದ ಆದೇಶವನ್ನು ವಿವರಿಸುತ್ತದೆ.
    /// `failure` ಹೋಲಿಕೆ ವಿಫಲವಾದಾಗ ನಡೆಯುವ ಲೋಡ್ ಕಾರ್ಯಾಚರಣೆಗೆ ಅಗತ್ಯವಾದ ಆದೇಶವನ್ನು ವಿವರಿಸುತ್ತದೆ.
    /// [`Acquire`] ಅನ್ನು ಯಶಸ್ಸಿನ ಆದೇಶದಂತೆ ಬಳಸುವುದರಿಂದ ಅಂಗಡಿಯು [`Relaxed`] ನ ಅಂಗಡಿಯ ಭಾಗವಾಗಿಸುತ್ತದೆ, ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಯಶಸ್ವಿ ಲೋಡ್ [`Relaxed`] ಆಗುತ್ತದೆ.
    ///
    /// ವೈಫಲ್ಯ ಆದೇಶವು [`SeqCst`], [`Acquire`] ಅಥವಾ [`Relaxed`] ಆಗಿರಬಹುದು ಮತ್ತು ಯಶಸ್ಸಿನ ಆದೇಶಕ್ಕಿಂತ ಸಮನಾಗಿರಬೇಕು ಅಥವಾ ದುರ್ಬಲವಾಗಿರಬೇಕು.
    ///
    /// **Note:** ಪಾಯಿಂಟರ್‌ಗಳಲ್ಲಿ ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಯನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಈ ವಿಧಾನ ಲಭ್ಯವಿದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಆಂತರಿಕತೆಯಿಂದ ಡೇಟಾ ರೇಸ್‌ಗಳನ್ನು ತಡೆಯಲಾಗುತ್ತದೆ.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `current` ಮೌಲ್ಯಕ್ಕೆ ಸಮನಾಗಿದ್ದರೆ ಮೌಲ್ಯವನ್ನು ಪಾಯಿಂಟರ್‌ನಲ್ಲಿ ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// [`AtomicPtr::compare_exchange`] ಗಿಂತ ಭಿನ್ನವಾಗಿ, ಹೋಲಿಕೆ ಯಶಸ್ವಿಯಾದಾಗಲೂ ಈ ಕಾರ್ಯವು ವಿಪರೀತವಾಗಿ ವಿಫಲಗೊಳ್ಳಲು ಅನುಮತಿಸಲಾಗಿದೆ, ಇದು ಕೆಲವು ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಹೆಚ್ಚು ಪರಿಣಾಮಕಾರಿಯಾದ ಕೋಡ್‌ಗೆ ಕಾರಣವಾಗಬಹುದು.
    ///
    /// ರಿಟರ್ನ್ ಮೌಲ್ಯವು ಹೊಸ ಮೌಲ್ಯವನ್ನು ಬರೆಯಲಾಗಿದೆಯೆ ಮತ್ತು ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿದೆಯೆ ಎಂದು ಸೂಚಿಸುವ ಫಲಿತಾಂಶವಾಗಿದೆ.
    ///
    /// `compare_exchange_weak` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸಲು ಎರಡು [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್‌ಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    /// `success` `current` ನೊಂದಿಗೆ ಹೋಲಿಕೆ ಯಶಸ್ವಿಯಾದರೆ ನಡೆಯುವ ರೀಡ್-ಮಾರ್ಪಡಿಸಿ-ಬರೆಯುವ ಕಾರ್ಯಾಚರಣೆಗೆ ಅಗತ್ಯವಾದ ಆದೇಶವನ್ನು ವಿವರಿಸುತ್ತದೆ.
    /// `failure` ಹೋಲಿಕೆ ವಿಫಲವಾದಾಗ ನಡೆಯುವ ಲೋಡ್ ಕಾರ್ಯಾಚರಣೆಗೆ ಅಗತ್ಯವಾದ ಆದೇಶವನ್ನು ವಿವರಿಸುತ್ತದೆ.
    /// [`Acquire`] ಅನ್ನು ಯಶಸ್ಸಿನ ಆದೇಶದಂತೆ ಬಳಸುವುದರಿಂದ ಅಂಗಡಿಯು [`Relaxed`] ನ ಅಂಗಡಿಯ ಭಾಗವಾಗಿಸುತ್ತದೆ, ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಯಶಸ್ವಿ ಲೋಡ್ [`Relaxed`] ಆಗುತ್ತದೆ.
    /// ವೈಫಲ್ಯ ಆದೇಶವು [`SeqCst`], [`Acquire`] ಅಥವಾ [`Relaxed`] ಆಗಿರಬಹುದು ಮತ್ತು ಯಶಸ್ಸಿನ ಆದೇಶಕ್ಕಿಂತ ಸಮನಾಗಿರಬೇಕು ಅಥವಾ ದುರ್ಬಲವಾಗಿರಬೇಕು.
    ///
    /// **Note:** ಪಾಯಿಂಟರ್‌ಗಳಲ್ಲಿ ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಯನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಈ ವಿಧಾನ ಲಭ್ಯವಿದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // ಸುರಕ್ಷತೆ: ಈ ಆಂತರಿಕವು ಅಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ಅದು ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ನಲ್ಲಿ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ
        // ಆದರೆ ಪಾಯಿಂಟರ್ ಮಾನ್ಯವಾಗಿದೆ ಎಂದು ನಮಗೆ ಖಚಿತವಾಗಿ ತಿಳಿದಿದೆ (ನಾವು ಅದನ್ನು ಉಲ್ಲೇಖದಿಂದ ಹೊಂದಿರುವ `UnsafeCell` ನಿಂದ ಪಡೆದುಕೊಂಡಿದ್ದೇವೆ) ಮತ್ತು ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಯು `UnsafeCell` ವಿಷಯಗಳನ್ನು ಸುರಕ್ಷಿತವಾಗಿ ಪರಿವರ್ತಿಸಲು ನಮಗೆ ಅನುಮತಿಸುತ್ತದೆ.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// ಮೌಲ್ಯವನ್ನು ಪಡೆಯುತ್ತದೆ, ಮತ್ತು ಐಚ್ al ಿಕ ಹೊಸ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುವ ಕಾರ್ಯವನ್ನು ಅದಕ್ಕೆ ಅನ್ವಯಿಸುತ್ತದೆ.ಕಾರ್ಯವು `Some(_)` ಅನ್ನು ಹಿಂದಿರುಗಿಸಿದರೆ `Ok(previous_value)` ನ `Result` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ `Err(previous_value)`.
    ///
    /// Note: ಕಾರ್ಯವು `Some(_)` ಅನ್ನು ಹಿಂದಿರುಗಿಸುವವರೆಗೆ, ಈ ಮಧ್ಯೆ ಇತರ ಎಳೆಗಳಿಂದ ಮೌಲ್ಯವನ್ನು ಬದಲಾಯಿಸಿದ್ದರೆ ಇದು ಕಾರ್ಯವನ್ನು ಹಲವು ಬಾರಿ ಕರೆಯಬಹುದು, ಆದರೆ ಕಾರ್ಯವನ್ನು ಸಂಗ್ರಹಿಸಿದ ಮೌಲ್ಯಕ್ಕೆ ಒಮ್ಮೆ ಮಾತ್ರ ಅನ್ವಯಿಸಲಾಗುತ್ತದೆ.
    ///
    ///
    /// `fetch_update` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸಲು ಎರಡು [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್‌ಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    /// ಮೊದಲನೆಯದು ಕಾರ್ಯಾಚರಣೆಯು ಅಂತಿಮವಾಗಿ ಯಶಸ್ವಿಯಾದಾಗ ಅಗತ್ಯವಾದ ಆದೇಶವನ್ನು ವಿವರಿಸುತ್ತದೆ ಮತ್ತು ಎರಡನೆಯದು ಲೋಡ್‌ಗಳಿಗೆ ಅಗತ್ಯವಾದ ಆದೇಶವನ್ನು ವಿವರಿಸುತ್ತದೆ.
    /// ಇವು ಕ್ರಮವಾಗಿ [`AtomicPtr::compare_exchange`] ನ ಯಶಸ್ಸು ಮತ್ತು ವೈಫಲ್ಯದ ಆದೇಶಗಳಿಗೆ ಅನುರೂಪವಾಗಿದೆ.
    ///
    /// [`Acquire`] ಅನ್ನು ಯಶಸ್ಸಿನ ಆದೇಶದಂತೆ ಬಳಸುವುದರಿಂದ ಅಂಗಡಿಯು [`Relaxed`] ನ ಅಂಗಡಿಯ ಭಾಗವಾಗಿಸುತ್ತದೆ, ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಅಂತಿಮ ಯಶಸ್ವಿ ಲೋಡ್ [`Relaxed`] ಆಗುತ್ತದೆ.
    /// (failed) ಲೋಡ್ ಆದೇಶವು [`SeqCst`], [`Acquire`] ಅಥವಾ [`Relaxed`] ಆಗಿರಬಹುದು ಮತ್ತು ಯಶಸ್ಸಿನ ಆದೇಶಕ್ಕಿಂತ ಸಮನಾಗಿರಬೇಕು ಅಥವಾ ದುರ್ಬಲವಾಗಿರಬೇಕು.
    ///
    /// **Note:** ಪಾಯಿಂಟರ್‌ಗಳಲ್ಲಿ ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಯನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಈ ವಿಧಾನ ಲಭ್ಯವಿದೆ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// `bool` ಅನ್ನು `AtomicBool` ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // ಈ ಮ್ಯಾಕ್ರೋ ಕೆಲವು ವಾಸ್ತುಶಿಲ್ಪಗಳಲ್ಲಿ ಬಳಕೆಯಾಗದಂತೆ ಕೊನೆಗೊಳ್ಳುತ್ತದೆ.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// ಎಳೆಗಳ ನಡುವೆ ಸುರಕ್ಷಿತವಾಗಿ ಹಂಚಿಕೊಳ್ಳಬಹುದಾದ ಒಂದು ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರ.
        ///
        /// ಈ ಪ್ರಕಾರವು ಆಧಾರವಾಗಿರುವ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರದಂತೆಯೇ ಸ್ಮರಣೆಯಲ್ಲಿನ ಪ್ರಾತಿನಿಧ್ಯವನ್ನು ಹೊಂದಿದೆ, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// ಪರಮಾಣು ಪ್ರಕಾರಗಳು ಮತ್ತು ಪರಮಾಣು ರಹಿತ ಪ್ರಕಾರಗಳ ನಡುವಿನ ವ್ಯತ್ಯಾಸಗಳು ಮತ್ತು ಈ ಪ್ರಕಾರದ ಒಯ್ಯಬಲ್ಲತೆಯ ಬಗ್ಗೆ ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ, ದಯವಿಟ್ಟು [module-level documentation] ನೋಡಿ.
        ///
        ///
        /// **Note:** ಈ ಪ್ರಕಾರವು ಪರಮಾಣು ಲೋಡ್‌ಗಳು ಮತ್ತು [`ನ ಮಳಿಗೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಲಭ್ಯವಿದೆ
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// ಪರಮಾಣು ಪೂರ್ಣಾಂಕವನ್ನು `0` ಗೆ ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // ಕಳುಹಿಸುವುದನ್ನು ಸೂಚ್ಯವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗಿದೆ.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// ಹೊಸ ಪರಮಾಣು ಪೂರ್ಣಾಂಕವನ್ನು ರಚಿಸುತ್ತದೆ.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// ಆಧಾರವಾಗಿರುವ ಪೂರ್ಣಾಂಕಕ್ಕೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
            ///
            /// ಇದು ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ಇತರ ಯಾವುದೇ ಎಳೆಗಳು ಏಕಕಾಲದಲ್ಲಿ ಪರಮಾಣು ಡೇಟಾವನ್ನು ಪ್ರವೇಶಿಸುವುದಿಲ್ಲ ಎಂದು ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// ಮ್ಯೂಟ್ some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವು ಅನನ್ಯ ಮಾಲೀಕತ್ವವನ್ನು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
                //  - `$int_type` ಮತ್ತು `Self` ನ ಜೋಡಣೆ ಒಂದೇ ಆಗಿರುತ್ತದೆ, $cfg_align ವಾಗ್ದಾನ ಮಾಡಿದಂತೆ ಮತ್ತು ಮೇಲೆ ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// ಪರಮಾಣುವನ್ನು ಬಳಸುತ್ತದೆ ಮತ್ತು ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
            ///
            /// ಇದು ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ `self` ಅನ್ನು ಮೌಲ್ಯದಿಂದ ಹಾದುಹೋಗುವುದರಿಂದ ಬೇರೆ ಯಾವುದೇ ಎಳೆಗಳು ಏಕಕಾಲದಲ್ಲಿ ಪರಮಾಣು ಡೇಟಾವನ್ನು ಪ್ರವೇಶಿಸುವುದಿಲ್ಲ ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// ಪರಮಾಣು ಪೂರ್ಣಾಂಕದಿಂದ ಮೌಲ್ಯವನ್ನು ಲೋಡ್ ಮಾಡುತ್ತದೆ.
            ///
            /// `load` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸುವ [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
            /// ಸಂಭಾವ್ಯ ಮೌಲ್ಯಗಳು [`SeqCst`], [`Acquire`] ಮತ್ತು [`Relaxed`].
            ///
            /// # Panics
            ///
            /// `order` [`Release`] ಅಥವಾ [`AcqRel`] ಆಗಿದ್ದರೆ Panics.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಆಂತರಿಕತೆಯಿಂದ ಡೇಟಾ ರೇಸ್‌ಗಳನ್ನು ತಡೆಯಲಾಗುತ್ತದೆ.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// ಮೌಲ್ಯವನ್ನು ಪರಮಾಣು ಪೂರ್ಣಾಂಕಕ್ಕೆ ಸಂಗ್ರಹಿಸುತ್ತದೆ.
            ///
            /// `store` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸುವ [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
            ///  ಸಂಭಾವ್ಯ ಮೌಲ್ಯಗಳು [`SeqCst`], [`Release`] ಮತ್ತು [`Relaxed`].
            ///
            /// # Panics
            ///
            /// `order` [`Acquire`] ಅಥವಾ [`AcqRel`] ಆಗಿದ್ದರೆ Panics.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಆಂತರಿಕತೆಯಿಂದ ಡೇಟಾ ರೇಸ್‌ಗಳನ್ನು ತಡೆಯಲಾಗುತ್ತದೆ.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// ಮೌಲ್ಯವನ್ನು ಪರಮಾಣು ಪೂರ್ಣಾಂಕದಲ್ಲಿ ಸಂಗ್ರಹಿಸುತ್ತದೆ, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
            ///
            /// `swap` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸುವ [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.ಎಲ್ಲಾ ಆದೇಶ ವಿಧಾನಗಳು ಸಾಧ್ಯ.
            /// [`Acquire`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಅಂಗಡಿಯು ಈ ಕಾರ್ಯಾಚರಣೆಯ [`Relaxed`] ನ ಭಾಗವಾಗಿಸುತ್ತದೆ ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಲೋಡ್ ಭಾಗ [`Relaxed`] ಆಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
            ///
            ///
            /// **ಗಮನಿಸಿ**: ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಈ ವಿಧಾನ ಲಭ್ಯವಿದೆ
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಆಂತರಿಕತೆಯಿಂದ ಡೇಟಾ ರೇಸ್‌ಗಳನ್ನು ತಡೆಯಲಾಗುತ್ತದೆ.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `current` ಮೌಲ್ಯಕ್ಕೆ ಸಮನಾಗಿದ್ದರೆ ಮೌಲ್ಯವನ್ನು ಪರಮಾಣು ಪೂರ್ಣಾಂಕಕ್ಕೆ ಸಂಗ್ರಹಿಸುತ್ತದೆ.
            ///
            /// ರಿಟರ್ನ್ ಮೌಲ್ಯವು ಯಾವಾಗಲೂ ಹಿಂದಿನ ಮೌಲ್ಯವಾಗಿರುತ್ತದೆ.ಇದು `current` ಗೆ ಸಮನಾಗಿದ್ದರೆ, ನಂತರ ಮೌಲ್ಯವನ್ನು ನವೀಕರಿಸಲಾಗಿದೆ.
            ///
            /// `compare_and_swap` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸುವ [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್ ಅನ್ನು ಸಹ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
            /// [`AcqRel`] ಅನ್ನು ಬಳಸುವಾಗಲೂ ಸಹ, ಕಾರ್ಯಾಚರಣೆಯು ವಿಫಲವಾಗಬಹುದು ಮತ್ತು ಆದ್ದರಿಂದ ಕೇವಲ `Acquire` ಲೋಡ್ ಅನ್ನು ನಿರ್ವಹಿಸಬಹುದು, ಆದರೆ `Release` ಶಬ್ದಾರ್ಥವನ್ನು ಹೊಂದಿರುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
            ///
            /// [`Acquire`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಅದು ಸಂಭವಿಸಿದಲ್ಲಿ [`Relaxed`] ಈ ಕಾರ್ಯಾಚರಣೆಯ ಅಂಗಡಿಯನ್ನು ಮಾಡುತ್ತದೆ, ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಲೋಡ್ ಭಾಗ [`Relaxed`] ಆಗುತ್ತದೆ.
            ///
            /// **ಗಮನಿಸಿ**: ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಈ ವಿಧಾನ ಲಭ್ಯವಿದೆ
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # `compare_exchange` ಮತ್ತು `compare_exchange_weak` ಗೆ ವಲಸೆ ಹೋಗುತ್ತಿದೆ
            ///
            /// `compare_and_swap` ಮೆಮೊರಿ ಆದೇಶಗಳಿಗಾಗಿ ಈ ಕೆಳಗಿನ ಮ್ಯಾಪಿಂಗ್‌ನೊಂದಿಗೆ `compare_exchange` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ:
            ///
            /// ಮೂಲ |ಯಶಸ್ಸು |ವೈಫಲ್ಯ
            /// -------- | ------- | -------
            /// ವಿಶ್ರಾಂತಿ |ವಿಶ್ರಾಂತಿ |ವಿಶ್ರಾಂತಿ ಪಡೆದುಕೊಳ್ಳಿ |ಪಡೆದುಕೊಳ್ಳಿ |ಬಿಡುಗಡೆಯನ್ನು ಪಡೆದುಕೊಳ್ಳಿ |ಬಿಡುಗಡೆ |ವಿಶ್ರಾಂತಿ ಅಕ್ರೆಲ್ |ಅಕ್ರೆಲ್ |SeqCst ಅನ್ನು ಪಡೆದುಕೊಳ್ಳಿ |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` ಹೋಲಿಕೆ ಯಶಸ್ವಿಯಾದಾಗಲೂ ವಿಪರೀತವಾಗಿ ವಿಫಲಗೊಳ್ಳಲು ಅನುಮತಿಸಲಾಗಿದೆ, ಇದು ಹೋಲಿಕೆ ಮತ್ತು ಸ್ವಾಪ್ ಅನ್ನು ಲೂಪ್‌ನಲ್ಲಿ ಬಳಸಿದಾಗ ಕಂಪೈಲರ್ ಉತ್ತಮ ಜೋಡಣೆ ಕೋಡ್ ಅನ್ನು ರಚಿಸಲು ಅನುಮತಿಸುತ್ತದೆ.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `current` ಮೌಲ್ಯಕ್ಕೆ ಸಮನಾಗಿದ್ದರೆ ಮೌಲ್ಯವನ್ನು ಪರಮಾಣು ಪೂರ್ಣಾಂಕಕ್ಕೆ ಸಂಗ್ರಹಿಸುತ್ತದೆ.
            ///
            /// ರಿಟರ್ನ್ ಮೌಲ್ಯವು ಹೊಸ ಮೌಲ್ಯವನ್ನು ಬರೆಯಲಾಗಿದೆಯೆ ಮತ್ತು ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿದೆಯೆ ಎಂದು ಸೂಚಿಸುವ ಫಲಿತಾಂಶವಾಗಿದೆ.
            /// ಯಶಸ್ಸಿನ ನಂತರ ಈ ಮೌಲ್ಯವು `current` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.
            ///
            /// `compare_exchange` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸಲು ಎರಡು [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್‌ಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
            /// `success` `current` ನೊಂದಿಗೆ ಹೋಲಿಕೆ ಯಶಸ್ವಿಯಾದರೆ ನಡೆಯುವ ರೀಡ್-ಮಾರ್ಪಡಿಸಿ-ಬರೆಯುವ ಕಾರ್ಯಾಚರಣೆಗೆ ಅಗತ್ಯವಾದ ಆದೇಶವನ್ನು ವಿವರಿಸುತ್ತದೆ.
            /// `failure` ಹೋಲಿಕೆ ವಿಫಲವಾದಾಗ ನಡೆಯುವ ಲೋಡ್ ಕಾರ್ಯಾಚರಣೆಗೆ ಅಗತ್ಯವಾದ ಆದೇಶವನ್ನು ವಿವರಿಸುತ್ತದೆ.
            /// [`Acquire`] ಅನ್ನು ಯಶಸ್ಸಿನ ಆದೇಶದಂತೆ ಬಳಸುವುದರಿಂದ ಅಂಗಡಿಯು [`Relaxed`] ನ ಅಂಗಡಿಯ ಭಾಗವಾಗಿಸುತ್ತದೆ, ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಯಶಸ್ವಿ ಲೋಡ್ [`Relaxed`] ಆಗುತ್ತದೆ.
            ///
            /// ವೈಫಲ್ಯ ಆದೇಶವು [`SeqCst`], [`Acquire`] ಅಥವಾ [`Relaxed`] ಆಗಿರಬಹುದು ಮತ್ತು ಯಶಸ್ಸಿನ ಆದೇಶಕ್ಕಿಂತ ಸಮನಾಗಿರಬೇಕು ಅಥವಾ ದುರ್ಬಲವಾಗಿರಬೇಕು.
            ///
            /// **ಗಮನಿಸಿ**: ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಈ ವಿಧಾನ ಲಭ್ಯವಿದೆ
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಆಂತರಿಕತೆಯಿಂದ ಡೇಟಾ ರೇಸ್‌ಗಳನ್ನು ತಡೆಯಲಾಗುತ್ತದೆ.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `current` ಮೌಲ್ಯಕ್ಕೆ ಸಮನಾಗಿದ್ದರೆ ಮೌಲ್ಯವನ್ನು ಪರಮಾಣು ಪೂರ್ಣಾಂಕಕ್ಕೆ ಸಂಗ್ರಹಿಸುತ್ತದೆ.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// ಹೋಲಿಕೆ ಯಶಸ್ವಿಯಾದಾಗಲೂ ಈ ಕಾರ್ಯವನ್ನು ವಿಪರೀತವಾಗಿ ವಿಫಲಗೊಳಿಸಲು ಅನುಮತಿಸಲಾಗಿದೆ, ಇದು ಕೆಲವು ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಹೆಚ್ಚು ಪರಿಣಾಮಕಾರಿಯಾದ ಕೋಡ್‌ಗೆ ಕಾರಣವಾಗಬಹುದು.
            /// ರಿಟರ್ನ್ ಮೌಲ್ಯವು ಹೊಸ ಮೌಲ್ಯವನ್ನು ಬರೆಯಲಾಗಿದೆಯೆ ಮತ್ತು ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿದೆಯೆ ಎಂದು ಸೂಚಿಸುವ ಫಲಿತಾಂಶವಾಗಿದೆ.
            ///
            /// `compare_exchange_weak` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸಲು ಎರಡು [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್‌ಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
            /// `success` `current` ನೊಂದಿಗೆ ಹೋಲಿಕೆ ಯಶಸ್ವಿಯಾದರೆ ನಡೆಯುವ ರೀಡ್-ಮಾರ್ಪಡಿಸಿ-ಬರೆಯುವ ಕಾರ್ಯಾಚರಣೆಗೆ ಅಗತ್ಯವಾದ ಆದೇಶವನ್ನು ವಿವರಿಸುತ್ತದೆ.
            /// `failure` ಹೋಲಿಕೆ ವಿಫಲವಾದಾಗ ನಡೆಯುವ ಲೋಡ್ ಕಾರ್ಯಾಚರಣೆಗೆ ಅಗತ್ಯವಾದ ಆದೇಶವನ್ನು ವಿವರಿಸುತ್ತದೆ.
            /// [`Acquire`] ಅನ್ನು ಯಶಸ್ಸಿನ ಆದೇಶದಂತೆ ಬಳಸುವುದರಿಂದ ಅಂಗಡಿಯು [`Relaxed`] ನ ಅಂಗಡಿಯ ಭಾಗವಾಗಿಸುತ್ತದೆ, ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಯಶಸ್ವಿ ಲೋಡ್ [`Relaxed`] ಆಗುತ್ತದೆ.
            ///
            /// ವೈಫಲ್ಯ ಆದೇಶವು [`SeqCst`], [`Acquire`] ಅಥವಾ [`Relaxed`] ಆಗಿರಬಹುದು ಮತ್ತು ಯಶಸ್ಸಿನ ಆದೇಶಕ್ಕಿಂತ ಸಮನಾಗಿರಬೇಕು ಅಥವಾ ದುರ್ಬಲವಾಗಿರಬೇಕು.
            ///
            /// **ಗಮನಿಸಿ**: ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಈ ವಿಧಾನ ಲಭ್ಯವಿದೆ
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// ಮಟ್ ಹಳೆಯ= val.load(Ordering::Relaxed) ಅನ್ನು ಬಿಡಿ;
            /// ಲೂಪ್ new ಹೊಸ=ಹಳೆಯ * 2 ಅನ್ನು ಬಿಡಿ;
            ///     ಹೊಂದಾಣಿಕೆ val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಆಂತರಿಕತೆಯಿಂದ ಡೇಟಾ ರೇಸ್‌ಗಳನ್ನು ತಡೆಯಲಾಗುತ್ತದೆ.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯಕ್ಕೆ ಸೇರಿಸುತ್ತದೆ, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
            ///
            /// ಈ ಕಾರ್ಯಾಚರಣೆಯು ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆ.
            ///
            /// `fetch_add` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸುವ [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.ಎಲ್ಲಾ ಆದೇಶ ವಿಧಾನಗಳು ಸಾಧ್ಯ.
            /// [`Acquire`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಅಂಗಡಿಯು ಈ ಕಾರ್ಯಾಚರಣೆಯ [`Relaxed`] ನ ಭಾಗವಾಗಿಸುತ್ತದೆ ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಲೋಡ್ ಭಾಗ [`Relaxed`] ಆಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
            ///
            ///
            /// **ಗಮನಿಸಿ**: ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಈ ವಿಧಾನ ಲಭ್ಯವಿದೆ
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಆಂತರಿಕತೆಯಿಂದ ಡೇಟಾ ರೇಸ್‌ಗಳನ್ನು ತಡೆಯಲಾಗುತ್ತದೆ.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದಿಂದ ಕಳೆಯುತ್ತದೆ, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
            ///
            /// ಈ ಕಾರ್ಯಾಚರಣೆಯು ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆ.
            ///
            /// `fetch_sub` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸುವ [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.ಎಲ್ಲಾ ಆದೇಶ ವಿಧಾನಗಳು ಸಾಧ್ಯ.
            /// [`Acquire`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಅಂಗಡಿಯು ಈ ಕಾರ್ಯಾಚರಣೆಯ [`Relaxed`] ನ ಭಾಗವಾಗಿಸುತ್ತದೆ ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಲೋಡ್ ಭಾಗ [`Relaxed`] ಆಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
            ///
            ///
            /// **ಗಮನಿಸಿ**: ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಈ ವಿಧಾನ ಲಭ್ಯವಿದೆ
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಆಂತರಿಕತೆಯಿಂದ ಡೇಟಾ ರೇಸ್‌ಗಳನ್ನು ತಡೆಯಲಾಗುತ್ತದೆ.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಬಿಟ್‌ವೈಸ್ "and".
            ///
            /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯ ಮತ್ತು ಆರ್ಗ್ಯುಮೆಂಟ್ `val` ನಲ್ಲಿ ಬಿಟ್‌ವೈಸ್ "and" ಕಾರ್ಯಾಚರಣೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ ಮತ್ತು ಫಲಿತಾಂಶಕ್ಕೆ ಹೊಸ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿಸುತ್ತದೆ.
            ///
            /// ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
            ///
            /// `fetch_and` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸುವ [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.ಎಲ್ಲಾ ಆದೇಶ ವಿಧಾನಗಳು ಸಾಧ್ಯ.
            /// [`Acquire`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಅಂಗಡಿಯು ಈ ಕಾರ್ಯಾಚರಣೆಯ [`Relaxed`] ನ ಭಾಗವಾಗಿಸುತ್ತದೆ ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಲೋಡ್ ಭಾಗ [`Relaxed`] ಆಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
            ///
            ///
            /// **ಗಮನಿಸಿ**: ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಈ ವಿಧಾನ ಲಭ್ಯವಿದೆ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಆಂತರಿಕತೆಯಿಂದ ಡೇಟಾ ರೇಸ್‌ಗಳನ್ನು ತಡೆಯಲಾಗುತ್ತದೆ.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಬಿಟ್‌ವೈಸ್ "nand".
            ///
            /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯ ಮತ್ತು ಆರ್ಗ್ಯುಮೆಂಟ್ `val` ನಲ್ಲಿ ಬಿಟ್‌ವೈಸ್ "nand" ಕಾರ್ಯಾಚರಣೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ ಮತ್ತು ಫಲಿತಾಂಶಕ್ಕೆ ಹೊಸ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿಸುತ್ತದೆ.
            ///
            /// ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
            ///
            /// `fetch_nand` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸುವ [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.ಎಲ್ಲಾ ಆದೇಶ ವಿಧಾನಗಳು ಸಾಧ್ಯ.
            /// [`Acquire`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಅಂಗಡಿಯು ಈ ಕಾರ್ಯಾಚರಣೆಯ [`Relaxed`] ನ ಭಾಗವಾಗಿಸುತ್ತದೆ ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಲೋಡ್ ಭಾಗ [`Relaxed`] ಆಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
            ///
            ///
            /// **ಗಮನಿಸಿ**: ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಈ ವಿಧಾನ ಲಭ್ಯವಿದೆ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಆಂತರಿಕತೆಯಿಂದ ಡೇಟಾ ರೇಸ್‌ಗಳನ್ನು ತಡೆಯಲಾಗುತ್ತದೆ.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಬಿಟ್‌ವೈಸ್ "or".
            ///
            /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯ ಮತ್ತು ಆರ್ಗ್ಯುಮೆಂಟ್ `val` ನಲ್ಲಿ ಬಿಟ್‌ವೈಸ್ "or" ಕಾರ್ಯಾಚರಣೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ ಮತ್ತು ಫಲಿತಾಂಶಕ್ಕೆ ಹೊಸ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿಸುತ್ತದೆ.
            ///
            /// ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
            ///
            /// `fetch_or` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸುವ [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.ಎಲ್ಲಾ ಆದೇಶ ವಿಧಾನಗಳು ಸಾಧ್ಯ.
            /// [`Acquire`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಅಂಗಡಿಯು ಈ ಕಾರ್ಯಾಚರಣೆಯ [`Relaxed`] ನ ಭಾಗವಾಗಿಸುತ್ತದೆ ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಲೋಡ್ ಭಾಗ [`Relaxed`] ಆಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
            ///
            ///
            /// **ಗಮನಿಸಿ**: ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಈ ವಿಧಾನ ಲಭ್ಯವಿದೆ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಆಂತರಿಕತೆಯಿಂದ ಡೇಟಾ ರೇಸ್‌ಗಳನ್ನು ತಡೆಯಲಾಗುತ್ತದೆ.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಬಿಟ್‌ವೈಸ್ "xor".
            ///
            /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯ ಮತ್ತು ಆರ್ಗ್ಯುಮೆಂಟ್ `val` ನಲ್ಲಿ ಬಿಟ್‌ವೈಸ್ "xor" ಕಾರ್ಯಾಚರಣೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ ಮತ್ತು ಫಲಿತಾಂಶಕ್ಕೆ ಹೊಸ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿಸುತ್ತದೆ.
            ///
            /// ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
            ///
            /// `fetch_xor` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸುವ [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.ಎಲ್ಲಾ ಆದೇಶ ವಿಧಾನಗಳು ಸಾಧ್ಯ.
            /// [`Acquire`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಅಂಗಡಿಯು ಈ ಕಾರ್ಯಾಚರಣೆಯ [`Relaxed`] ನ ಭಾಗವಾಗಿಸುತ್ತದೆ ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಲೋಡ್ ಭಾಗ [`Relaxed`] ಆಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
            ///
            ///
            /// **ಗಮನಿಸಿ**: ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಈ ವಿಧಾನ ಲಭ್ಯವಿದೆ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಆಂತರಿಕತೆಯಿಂದ ಡೇಟಾ ರೇಸ್‌ಗಳನ್ನು ತಡೆಯಲಾಗುತ್ತದೆ.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// ಮೌಲ್ಯವನ್ನು ಪಡೆಯುತ್ತದೆ, ಮತ್ತು ಐಚ್ al ಿಕ ಹೊಸ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುವ ಕಾರ್ಯವನ್ನು ಅದಕ್ಕೆ ಅನ್ವಯಿಸುತ್ತದೆ.ಕಾರ್ಯವು `Some(_)` ಅನ್ನು ಹಿಂದಿರುಗಿಸಿದರೆ `Ok(previous_value)` ನ `Result` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ `Err(previous_value)`.
            ///
            /// Note: ಕಾರ್ಯವು `Some(_)` ಅನ್ನು ಹಿಂದಿರುಗಿಸುವವರೆಗೆ, ಈ ಮಧ್ಯೆ ಇತರ ಎಳೆಗಳಿಂದ ಮೌಲ್ಯವನ್ನು ಬದಲಾಯಿಸಿದ್ದರೆ ಇದು ಕಾರ್ಯವನ್ನು ಹಲವು ಬಾರಿ ಕರೆಯಬಹುದು, ಆದರೆ ಕಾರ್ಯವನ್ನು ಸಂಗ್ರಹಿಸಿದ ಮೌಲ್ಯಕ್ಕೆ ಒಮ್ಮೆ ಮಾತ್ರ ಅನ್ವಯಿಸಲಾಗುತ್ತದೆ.
            ///
            ///
            /// `fetch_update` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸಲು ಎರಡು [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್‌ಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
            /// ಮೊದಲನೆಯದು ಕಾರ್ಯಾಚರಣೆಯು ಅಂತಿಮವಾಗಿ ಯಶಸ್ವಿಯಾದಾಗ ಅಗತ್ಯವಾದ ಆದೇಶವನ್ನು ವಿವರಿಸುತ್ತದೆ ಮತ್ತು ಎರಡನೆಯದು ಲೋಡ್‌ಗಳಿಗೆ ಅಗತ್ಯವಾದ ಆದೇಶವನ್ನು ವಿವರಿಸುತ್ತದೆ.ಇವುಗಳ ಯಶಸ್ಸು ಮತ್ತು ವೈಫಲ್ಯದ ಆದೇಶಗಳಿಗೆ ಅನುರೂಪವಾಗಿದೆ
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// [`Acquire`] ಅನ್ನು ಯಶಸ್ಸಿನ ಆದೇಶದಂತೆ ಬಳಸುವುದರಿಂದ ಅಂಗಡಿಯು [`Relaxed`] ನ ಅಂಗಡಿಯ ಭಾಗವಾಗಿಸುತ್ತದೆ, ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಅಂತಿಮ ಯಶಸ್ವಿ ಲೋಡ್ [`Relaxed`] ಆಗುತ್ತದೆ.
            /// (failed) ಲೋಡ್ ಆದೇಶವು [`SeqCst`], [`Acquire`] ಅಥವಾ [`Relaxed`] ಆಗಿರಬಹುದು ಮತ್ತು ಯಶಸ್ಸಿನ ಆದೇಶಕ್ಕಿಂತ ಸಮನಾಗಿರಬೇಕು ಅಥವಾ ದುರ್ಬಲವಾಗಿರಬೇಕು.
            ///
            /// **ಗಮನಿಸಿ**: ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಈ ವಿಧಾನ ಲಭ್ಯವಿದೆ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (ಆದೇಶ:::SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (ಆದೇಶ:::SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಗರಿಷ್ಠ.
            ///
            /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯ ಮತ್ತು ಆರ್ಗ್ಯುಮೆಂಟ್ `val` ನ ಗರಿಷ್ಠತೆಯನ್ನು ಕಂಡುಕೊಳ್ಳುತ್ತದೆ ಮತ್ತು ಫಲಿತಾಂಶಕ್ಕೆ ಹೊಸ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿಸುತ್ತದೆ.
            ///
            /// ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
            ///
            /// `fetch_max` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸುವ [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.ಎಲ್ಲಾ ಆದೇಶ ವಿಧಾನಗಳು ಸಾಧ್ಯ.
            /// [`Acquire`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಅಂಗಡಿಯು ಈ ಕಾರ್ಯಾಚರಣೆಯ [`Relaxed`] ನ ಭಾಗವಾಗಿಸುತ್ತದೆ ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಲೋಡ್ ಭಾಗ [`Relaxed`] ಆಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
            ///
            ///
            /// **ಗಮನಿಸಿ**: ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಈ ವಿಧಾನ ಲಭ್ಯವಿದೆ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// ಬಾರ್=42;
            /// max_foo=foo.fetch_max (ಬಾರ್, Ordering::SeqCst).max(bar);
            /// ಪ್ರತಿಪಾದಿಸು! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಆಂತರಿಕತೆಯಿಂದ ಡೇಟಾ ರೇಸ್‌ಗಳನ್ನು ತಡೆಯಲಾಗುತ್ತದೆ.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಕನಿಷ್ಠ.
            ///
            /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದ ಕನಿಷ್ಠ ಮತ್ತು `val` ಆರ್ಗ್ಯುಮೆಂಟ್ ಅನ್ನು ಕಂಡುಕೊಳ್ಳುತ್ತದೆ ಮತ್ತು ಫಲಿತಾಂಶಕ್ಕೆ ಹೊಸ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿಸುತ್ತದೆ.
            ///
            /// ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
            ///
            /// `fetch_min` ಈ ಕಾರ್ಯಾಚರಣೆಯ ಮೆಮೊರಿ ಆದೇಶವನ್ನು ವಿವರಿಸುವ [`Ordering`] ಆರ್ಗ್ಯುಮೆಂಟ್ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.ಎಲ್ಲಾ ಆದೇಶ ವಿಧಾನಗಳು ಸಾಧ್ಯ.
            /// [`Acquire`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಅಂಗಡಿಯು ಈ ಕಾರ್ಯಾಚರಣೆಯ [`Relaxed`] ನ ಭಾಗವಾಗಿಸುತ್ತದೆ ಮತ್ತು [`Release`] ಅನ್ನು ಬಳಸುವುದರಿಂದ ಲೋಡ್ ಭಾಗ [`Relaxed`] ಆಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
            ///
            ///
            /// **ಗಮನಿಸಿ**: ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಮಾತ್ರ ಈ ವಿಧಾನ ಲಭ್ಯವಿದೆ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// ಬಾರ್=12;
            /// min_foo=foo.fetch_min (ಬಾರ್, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಆಂತರಿಕತೆಯಿಂದ ಡೇಟಾ ರೇಸ್‌ಗಳನ್ನು ತಡೆಯಲಾಗುತ್ತದೆ.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// ರೂಪಾಂತರಿತ ಪಾಯಿಂಟರ್ ಅನ್ನು ಆಧಾರವಾಗಿರುವ ಪೂರ್ಣಾಂಕಕ್ಕೆ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
            ///
            /// ಪರಮಾಣು ರಹಿತ ಓದುವಿಕೆ ಮತ್ತು ಬರೆಯುವಿಕೆಯು ಪೂರ್ಣಾಂಕದಲ್ಲಿ ಡೇಟಾ ರೇಸ್ ಆಗಿರಬಹುದು.
            /// ಈ ವಿಧಾನವು ಎಫ್‌ಎಫ್‌ಐಗೆ ಹೆಚ್ಚಾಗಿ ಉಪಯುಕ್ತವಾಗಿದೆ, ಅಲ್ಲಿ ಫಂಕ್ಷನ್ ಸಿಗ್ನೇಚರ್ ಬಳಸಬಹುದು
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// ಈ ಪರಮಾಣುವಿನ ಹಂಚಿಕೆಯ ಉಲ್ಲೇಖದಿಂದ `*mut` ಪಾಯಿಂಟರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ಪರಮಾಣು ಪ್ರಕಾರಗಳು ಆಂತರಿಕ ರೂಪಾಂತರದೊಂದಿಗೆ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತವೆ.
            /// ಪರಮಾಣುವಿನ ಎಲ್ಲಾ ಮಾರ್ಪಾಡುಗಳು ಹಂಚಿಕೆಯ ಉಲ್ಲೇಖದ ಮೂಲಕ ಮೌಲ್ಯವನ್ನು ಬದಲಾಯಿಸುತ್ತವೆ ಮತ್ತು ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬಳಸುವವರೆಗೂ ಅದನ್ನು ಸುರಕ್ಷಿತವಾಗಿ ಮಾಡಬಹುದು.
            /// ಹಿಂತಿರುಗಿದ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ನ ಯಾವುದೇ ಬಳಕೆಗೆ `unsafe` ಬ್ಲಾಕ್ ಅಗತ್ಯವಿರುತ್ತದೆ ಮತ್ತು ಇನ್ನೂ ಅದೇ ನಿರ್ಬಂಧವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕಾಗುತ್ತದೆ: ಅದರ ಮೇಲಿನ ಕಾರ್ಯಾಚರಣೆಗಳು ಪರಮಾಣು ಆಗಿರಬೇಕು.
            ///
            ///
            /// # Examples
            ///
            /// `` (extern-declaration) ಅನ್ನು ನಿರ್ಲಕ್ಷಿಸಿ
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// ಬಾಹ್ಯ "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // ಸುರಕ್ಷತೆ: `my_atomic_op` ಪರಮಾಣು ಇರುವವರೆಗೆ ಸುರಕ್ಷಿತ.
            /// ಅಸುರಕ್ಷಿತ {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `atomic_store` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `atomic_load` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `atomic_swap` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ (__sync_fetch_and_add ನಂತಹ).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `atomic_add` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ (__sync_fetch_and_sub ನಂತಹ).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `atomic_sub` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `atomic_compare_exchange` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `atomic_compare_exchange_weak` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `atomic_and` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `atomic_nand` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `atomic_or` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `atomic_xor` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// ಗರಿಷ್ಠ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ (ಸಹಿ ಮಾಡಿದ ಹೋಲಿಕೆ)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `atomic_max` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// ಕನಿಷ್ಠ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ (ಸಹಿ ಮಾಡಿದ ಹೋಲಿಕೆ)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `atomic_min` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// ಗರಿಷ್ಠ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ (ಸಹಿ ಮಾಡದ ಹೋಲಿಕೆ)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `atomic_umax` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// ಕನಿಷ್ಠ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ (ಸಹಿ ಮಾಡದ ಹೋಲಿಕೆ)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `atomic_umin` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// ಪರಮಾಣು ಬೇಲಿ.
///
/// ನಿಗದಿತ ಕ್ರಮವನ್ನು ಅವಲಂಬಿಸಿ, ಕಂಪೈಲರ್ ಮತ್ತು ಸಿಪಿಯು ಅದರ ಸುತ್ತಲಿನ ಕೆಲವು ರೀತಿಯ ಮೆಮೊರಿ ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಮರುಕ್ರಮಗೊಳಿಸುವುದನ್ನು ಬೇಲಿ ತಡೆಯುತ್ತದೆ.
/// ಅದು ಸಿಂಕ್ರೊನೈಸ್-ಅದರ ನಡುವಿನ ಸಂಬಂಧಗಳು ಮತ್ತು ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳು ಅಥವಾ ಇತರ ಎಳೆಗಳಲ್ಲಿನ ಬೇಲಿಗಳನ್ನು ಸೃಷ್ಟಿಸುತ್ತದೆ.
///
/// (ಕನಿಷ್ಠ) [`Release`] ಆದೇಶ ಶಬ್ದಾರ್ಥಗಳನ್ನು ಹೊಂದಿರುವ ಬೇಲಿ 'A', ಬೇಲಿ 'B' ನೊಂದಿಗೆ (ಕನಿಷ್ಠ) [`Acquire`] ಶಬ್ದಾರ್ಥದೊಂದಿಗೆ ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡುತ್ತದೆ, X ಮತ್ತು Y ಕಾರ್ಯಾಚರಣೆಗಳು ಇದ್ದಲ್ಲಿ ಮತ್ತು ಕೆಲವು ಪರಮಾಣು ವಸ್ತುವಿನ 'M' ನಲ್ಲಿ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತಿದ್ದರೆ, ಎರಡೂ ಮೊದಲು ಅನುಕ್ರಮವಾಗಿರುತ್ತದೆ X ಮತ್ತು Y ಅನ್ನು B ಗೆ ಮೊದಲು ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡಲಾಗುತ್ತದೆ ಮತ್ತು Y ಗೆ ಬದಲಾವಣೆಯನ್ನು ಗಮನಿಸುತ್ತದೆ.
/// ಇದು ಎ ಮತ್ತು ಬಿ ನಡುವಿನ ಸಂಭವಿಸುವ ಮೊದಲು ಅವಲಂಬನೆಯನ್ನು ಒದಗಿಸುತ್ತದೆ.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// [`Release`] ಅಥವಾ [`Acquire`] ಶಬ್ದಾರ್ಥದೊಂದಿಗಿನ ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳು ಸಹ ಬೇಲಿಯೊಂದಿಗೆ ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡಬಹುದು.
///
/// [`SeqCst`] ಆದೇಶವನ್ನು ಹೊಂದಿರುವ ಬೇಲಿ, [`Acquire`] ಮತ್ತು [`Release`] ಶಬ್ದಾರ್ಥಗಳನ್ನು ಹೊಂದಿರುವುದರ ಜೊತೆಗೆ, ಇತರ [`SeqCst`] ಕಾರ್ಯಾಚರಣೆಗಳು ಮತ್ತು/ಅಥವಾ ಬೇಲಿಗಳ ಜಾಗತಿಕ ಪ್ರೋಗ್ರಾಂ ಕ್ರಮದಲ್ಲಿ ಭಾಗವಹಿಸುತ್ತದೆ.
///
/// [`Acquire`], [`Release`], [`AcqRel`] ಮತ್ತು [`SeqCst`] ಆದೇಶಗಳನ್ನು ಸ್ವೀಕರಿಸುತ್ತದೆ.
///
/// # Panics
///
/// `order` [`Relaxed`] ಆಗಿದ್ದರೆ Panics.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // ಸ್ಪಿನ್‌ಲಾಕ್ ಆಧಾರಿತ ಪರಸ್ಪರ ಹೊರಗಿಡುವ ಆದಿಮ.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // ಹಳೆಯ ಮೌಲ್ಯವು `false` ಆಗುವವರೆಗೆ ಕಾಯಿರಿ.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // ಈ ಬೇಲಿ `unlock` ನಲ್ಲಿ ಅಂಗಡಿಯೊಂದಿಗೆ ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡುತ್ತದೆ.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಬೇಲಿಯನ್ನು ಬಳಸುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// ಕಂಪೈಲರ್ ಮೆಮೊರಿ ಬೇಲಿ.
///
/// `compiler_fence` ಯಾವುದೇ ಯಂತ್ರ ಸಂಕೇತವನ್ನು ಹೊರಸೂಸುವುದಿಲ್ಲ, ಆದರೆ ಕಂಪೈಲರ್ ಮಾಡಲು ಮರು-ಆದೇಶಿಸುವ ರೀತಿಯ ಮೆಮೊರಿಯನ್ನು ನಿರ್ಬಂಧಿಸುತ್ತದೆ.ನಿರ್ದಿಷ್ಟವಾಗಿ, ಕೊಟ್ಟಿರುವ [`Ordering`] ಶಬ್ದಾರ್ಥವನ್ನು ಅವಲಂಬಿಸಿ, `compiler_fence` ಗೆ ಕರೆಯ ಇನ್ನೊಂದು ಬದಿಗೆ ಕರೆ ಮಾಡುವ ಮೊದಲು ಅಥವಾ ನಂತರ ಓದುವ ಅಥವಾ ಬರೆಯುವಿಕೆಯನ್ನು ಕಂಪೈಲರ್ ಅನುಮತಿಸಲಾಗುವುದಿಲ್ಲ.ಅಂತಹ ಮರು-ಆದೇಶವನ್ನು ಮಾಡುವುದರಿಂದ *ಹಾರ್ಡ್‌ವೇರ್* ಅನ್ನು ಇದು ** ತಡೆಯುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
///
/// ಏಕ-ಥ್ರೆಡ್, ಮರಣದಂಡನೆ ಸನ್ನಿವೇಶದಲ್ಲಿ ಇದು ಸಮಸ್ಯೆಯಲ್ಲ, ಆದರೆ ಇತರ ಎಳೆಗಳು ಒಂದೇ ಸಮಯದಲ್ಲಿ ಮೆಮೊರಿಯನ್ನು ಮಾರ್ಪಡಿಸಿದಾಗ, [`fence`] ನಂತಹ ಬಲವಾದ ಸಿಂಕ್ರೊನೈಸೇಶನ್ ಆದಿಮಾನಗಳು ಅಗತ್ಯವಿದೆ.
///
/// ವಿಭಿನ್ನ ಆದೇಶದ ಶಬ್ದಾರ್ಥಗಳಿಂದ ಮರು-ಆದೇಶವನ್ನು ತಡೆಯಲಾಗಿದೆ:
///
///  - [`SeqCst`] ನೊಂದಿಗೆ, ಈ ಹಂತದಲ್ಲಿ ಓದುವ ಮತ್ತು ಬರೆಯುವ ಯಾವುದೇ ಮರು-ಆದೇಶವನ್ನು ಅನುಮತಿಸಲಾಗುವುದಿಲ್ಲ.
///  - [`Release`] ನೊಂದಿಗೆ, ಹಿಂದಿನ ಓದುಗಳು ಮತ್ತು ಬರಹಗಳನ್ನು ಹಿಂದಿನ ನಂತರದ ಬರಹಗಳನ್ನು ಸರಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ.
///  - [`Acquire`] ನೊಂದಿಗೆ, ನಂತರದ ಓದು ಮತ್ತು ಬರಹಗಳನ್ನು ಹಿಂದಿನ ಓದುಗಳಿಗಿಂತ ಮುಂದಕ್ಕೆ ಸರಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ.
///  - [`AcqRel`] ನೊಂದಿಗೆ, ಮೇಲಿನ ಎರಡೂ ನಿಯಮಗಳನ್ನು ಜಾರಿಗೊಳಿಸಲಾಗುತ್ತದೆ.
///
/// `compiler_fence` ಥ್ರೆಡ್ ಅನ್ನು * ಸ್ವತಃ ಓಡಿಸುವುದನ್ನು ತಡೆಯಲು ಸಾಮಾನ್ಯವಾಗಿ ಉಪಯುಕ್ತವಾಗಿದೆ.ಅಂದರೆ, ಕೊಟ್ಟಿರುವ ಥ್ರೆಡ್ ಒಂದು ತುಂಡು ಕೋಡ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತಿದ್ದರೆ, ಮತ್ತು ನಂತರ ಅದನ್ನು ಅಡ್ಡಿಪಡಿಸಿದರೆ ಮತ್ತು ಕೋಡ್ ಅನ್ನು ಬೇರೆಡೆ ಕಾರ್ಯಗತಗೊಳಿಸಲು ಪ್ರಾರಂಭಿಸಿದರೆ (ಇನ್ನೂ ಅದೇ ಥ್ರೆಡ್‌ನಲ್ಲಿರುವಾಗ ಮತ್ತು ಪರಿಕಲ್ಪನಾತ್ಮಕವಾಗಿ ಇನ್ನೂ ಅದೇ ಕೋರ್‌ನಲ್ಲಿ).ಸಾಂಪ್ರದಾಯಿಕ ಕಾರ್ಯಕ್ರಮಗಳಲ್ಲಿ, ಸಿಗ್ನಲ್ ಹ್ಯಾಂಡ್ಲರ್ ನೋಂದಾಯಿಸಿದಾಗ ಮಾತ್ರ ಇದು ಸಂಭವಿಸುತ್ತದೆ.
/// ಹೆಚ್ಚು ಕೆಳಮಟ್ಟದ ಕೋಡ್‌ನಲ್ಲಿ, ಅಡೆತಡೆಗಳನ್ನು ನಿರ್ವಹಿಸುವಾಗ, ಪೂರ್ವ ಎಂಪೇಶನ್‌ನೊಂದಿಗೆ ಹಸಿರು ಎಳೆಗಳನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವಾಗ ಇಂತಹ ಸಂದರ್ಭಗಳು ಉದ್ಭವಿಸಬಹುದು.
/// ಕುತೂಹಲಕಾರಿ ಓದುಗರಿಗೆ [memory barriers] ನ Linux ಕರ್ನಲ್ ಚರ್ಚೆಯನ್ನು ಓದಲು ಪ್ರೋತ್ಸಾಹಿಸಲಾಗುತ್ತದೆ.
///
/// # Panics
///
/// `order` [`Relaxed`] ಆಗಿದ್ದರೆ Panics.
///
/// # Examples
///
/// `compiler_fence` ಇಲ್ಲದೆ, ಒಂದೇ ಥ್ರೆಡ್‌ನಲ್ಲಿ ಎಲ್ಲವೂ ನಡೆಯುತ್ತಿದ್ದರೂ, ಈ ಕೆಳಗಿನ ಕೋಡ್‌ನಲ್ಲಿನ `assert_eq!` ಯಶಸ್ವಿಯಾಗಲು * ಖಾತರಿಪಡಿಸುವುದಿಲ್ಲ.
/// ಏಕೆ ಎಂದು ನೋಡಲು, ಕಂಪೈಲರ್ `IMPORTANT_VARIABLE` ಮತ್ತು `IS_READ` ಗೆ ಮಳಿಗೆಗಳನ್ನು ಸ್ವ್ಯಾಪ್ ಮಾಡಲು ಉಚಿತವಾಗಿದೆ ಎಂಬುದನ್ನು ನೆನಪಿಡಿ ಏಕೆಂದರೆ ಅವುಗಳು ಎರಡೂ `Ordering::Relaxed` ಆಗಿರುತ್ತವೆ.ಅದು ಮಾಡಿದರೆ, ಮತ್ತು `IS_READY` ನವೀಕರಿಸಿದ ನಂತರ ಸಿಗ್ನಲ್ ಹ್ಯಾಂಡ್ಲರ್ ಅನ್ನು ಆಹ್ವಾನಿಸಿದರೆ, ಸಿಗ್ನಲ್ ಹ್ಯಾಂಡ್ಲರ್ `IS_READY=1` ಅನ್ನು ನೋಡುತ್ತದೆ, ಆದರೆ `IMPORTANT_VARIABLE=0`.
/// `compiler_fence` ಪರಿಹಾರಗಳನ್ನು ಬಳಸುವುದು ಈ ಪರಿಸ್ಥಿತಿಯನ್ನು ಪರಿಹರಿಸುತ್ತದೆ.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // ಹಿಂದಿನ ಬರಹಗಳನ್ನು ಈ ಹಂತವನ್ನು ಮೀರಿ ಚಲಿಸದಂತೆ ತಡೆಯಿರಿ
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // ಸುರಕ್ಷತೆ: ಪರಮಾಣು ಬೇಲಿಯನ್ನು ಬಳಸುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// ಪ್ರೊಸೆಸರ್ ಇದು ಕಾರ್ಯನಿರತ-ಕಾಯುವ ಸ್ಪಿನ್-ಲೂಪ್ ("ಸ್ಪಿನ್ ಲಾಕ್") ಒಳಗೆ ಇದೆ ಎಂದು ಸಂಕೇತಿಸುತ್ತದೆ.
///
/// ಈ ಕಾರ್ಯವನ್ನು [`hint::spin_loop`] ಪರವಾಗಿ ಅಸಮ್ಮತಿಸಲಾಗಿದೆ.
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}