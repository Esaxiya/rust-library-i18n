use crate::iter::FromIterator;

/// ಎಲ್ಲಾ ಘಟಕ ವಸ್ತುಗಳನ್ನು ಪುನರಾವರ್ತಕದಿಂದ ಒಂದರಂತೆ ಸಂಕುಚಿತಗೊಳಿಸುತ್ತದೆ.
///
/// `Result<(), E>` ಗೆ ಸಂಗ್ರಹಿಸುವಂತಹ ಉನ್ನತ-ಮಟ್ಟದ ಅಮೂರ್ತತೆಗಳೊಂದಿಗೆ ಸಂಯೋಜಿಸಿದಾಗ ಇದು ಹೆಚ್ಚು ಉಪಯುಕ್ತವಾಗಿದೆ, ಅಲ್ಲಿ ನೀವು ದೋಷಗಳ ಬಗ್ಗೆ ಮಾತ್ರ ಕಾಳಜಿ ವಹಿಸುತ್ತೀರಿ:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}