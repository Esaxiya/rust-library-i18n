#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` ಟಾಸ್ಕ್ ಎಕ್ಸಿಕ್ಯೂಟರ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವವರಿಗೆ [`Waker`] ಅನ್ನು ರಚಿಸಲು ಅನುಮತಿಸುತ್ತದೆ, ಇದು ಕಸ್ಟಮೈಸ್ ಮಾಡಿದ ಎಚ್ಚರಗೊಳ್ಳುವ ನಡವಳಿಕೆಯನ್ನು ಒದಗಿಸುತ್ತದೆ.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// ಇದು ಡೇಟಾ ಪಾಯಿಂಟರ್ ಮತ್ತು [virtual function pointer table (vtable)][vtable] ಅನ್ನು ಒಳಗೊಂಡಿರುತ್ತದೆ, ಅದು `RawWaker` ನ ವರ್ತನೆಯನ್ನು ಕಸ್ಟಮೈಸ್ ಮಾಡುತ್ತದೆ.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// ಡೇಟಾ ಪಾಯಿಂಟರ್, ಇದನ್ನು ಕಾರ್ಯನಿರ್ವಾಹಕರಿಂದ ಅಗತ್ಯವಿರುವಂತೆ ಅನಿಯಂತ್ರಿತ ಡೇಟಾವನ್ನು ಸಂಗ್ರಹಿಸಲು ಬಳಸಬಹುದು.
    /// ಇದು ಉದಾ
    /// ಕಾರ್ಯದೊಂದಿಗೆ ಸಂಯೋಜಿತವಾಗಿರುವ `Arc` ಗೆ ಟೈಪ್-ಅಳಿಸಿದ ಪಾಯಿಂಟರ್.
    /// ಈ ಕ್ಷೇತ್ರದ ಮೌಲ್ಯವು ಮೊದಲ ನಿಯತಾಂಕದಂತೆ vtable ನ ಭಾಗವಾಗಿರುವ ಎಲ್ಲಾ ಕಾರ್ಯಗಳಿಗೆ ರವಾನೆಯಾಗುತ್ತದೆ.
    ///
    data: *const (),
    /// ಈ ವೇಕರ್ ನಡವಳಿಕೆಯನ್ನು ಕಸ್ಟಮೈಸ್ ಮಾಡುವ ವರ್ಚುವಲ್ ಫಂಕ್ಷನ್ ಪಾಯಿಂಟರ್ ಟೇಬಲ್.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// ಒದಗಿಸಿದ `data` ಪಾಯಿಂಟರ್ ಮತ್ತು `vtable` ನಿಂದ ಹೊಸ `RawWaker` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// ಕಾರ್ಯನಿರ್ವಾಹಕರಿಂದ ಅಗತ್ಯವಿರುವಂತೆ ಅನಿಯಂತ್ರಿತ ಡೇಟಾವನ್ನು ಸಂಗ್ರಹಿಸಲು `data` ಪಾಯಿಂಟರ್ ಅನ್ನು ಬಳಸಬಹುದು.ಇದು ಉದಾ
    /// ಕಾರ್ಯದೊಂದಿಗೆ ಸಂಯೋಜಿತವಾಗಿರುವ `Arc` ಗೆ ಟೈಪ್-ಅಳಿಸಿದ ಪಾಯಿಂಟರ್.
    /// ಈ ಪಾಯಿಂಟರ್‌ನ ಮೌಲ್ಯವು ಮೊದಲ ಪ್ಯಾರಾಮೀಟರ್‌ನಂತೆ `vtable` ನ ಭಾಗವಾಗಿರುವ ಎಲ್ಲಾ ಕಾರ್ಯಗಳಿಗೆ ರವಾನೆಯಾಗುತ್ತದೆ.
    ///
    /// `vtable` `Waker` ನ ನಡವಳಿಕೆಯನ್ನು ಕಸ್ಟಮೈಸ್ ಮಾಡುತ್ತದೆ, ಅದು `RawWaker` ನಿಂದ ರಚಿಸಲ್ಪಡುತ್ತದೆ.
    /// `Waker` ನಲ್ಲಿನ ಪ್ರತಿ ಕಾರ್ಯಾಚರಣೆಗೆ, ಆಧಾರವಾಗಿರುವ `RawWaker` ನ `vtable` ನಲ್ಲಿನ ಸಂಬಂಧಿತ ಕಾರ್ಯವನ್ನು ಕರೆಯಲಾಗುತ್ತದೆ.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// [`RawWaker`] ನ ವರ್ತನೆಯನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸುವ ವರ್ಚುವಲ್ ಫಂಕ್ಷನ್ ಪಾಯಿಂಟರ್ ಟೇಬಲ್ (vtable).
///
/// Vtable ಒಳಗೆ ಎಲ್ಲಾ ಕಾರ್ಯಗಳಿಗೆ ರವಾನಿಸಲಾದ ಪಾಯಿಂಟರ್ ಸುತ್ತುವರಿದ [`RawWaker`] ವಸ್ತುವಿನಿಂದ `data` ಪಾಯಿಂಟರ್ ಆಗಿದೆ.
///
/// ಈ ರಚನೆಯೊಳಗಿನ ಕಾರ್ಯಗಳನ್ನು [`RawWaker`] ಅನುಷ್ಠಾನದ ಒಳಗಿನಿಂದ ಸರಿಯಾಗಿ ನಿರ್ಮಿಸಲಾದ [`RawWaker`] ವಸ್ತುವಿನ `data` ಪಾಯಿಂಟರ್‌ನಲ್ಲಿ ಕರೆಯಲು ಮಾತ್ರ ಉದ್ದೇಶಿಸಲಾಗಿದೆ.
/// ಬೇರೆ ಯಾವುದೇ `data` ಪಾಯಿಂಟರ್ ಬಳಸಿ ಒಳಗೊಂಡಿರುವ ಕಾರ್ಯಗಳಲ್ಲಿ ಒಂದನ್ನು ಕರೆಯುವುದು ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// [`RawWaker`] ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮಾಡಿದಾಗ ಈ ಕಾರ್ಯವನ್ನು ಕರೆಯಲಾಗುತ್ತದೆ, ಉದಾ. [`RawWaker`] ಅನ್ನು ಸಂಗ್ರಹಿಸಿರುವ [`Waker`] ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮಾಡಿದಾಗ.
    ///
    /// ಈ ಕಾರ್ಯದ ಅನುಷ್ಠಾನವು [`RawWaker`] ಮತ್ತು ಸಂಬಂಧಿತ ಕಾರ್ಯದ ಈ ಹೆಚ್ಚುವರಿ ನಿದರ್ಶನಕ್ಕೆ ಅಗತ್ಯವಿರುವ ಎಲ್ಲಾ ಸಂಪನ್ಮೂಲಗಳನ್ನು ಉಳಿಸಿಕೊಳ್ಳಬೇಕು.
    /// ಪರಿಣಾಮವಾಗಿ ಬರುವ [`RawWaker`] ನಲ್ಲಿ `wake` ಗೆ ಕರೆ ಮಾಡುವುದರಿಂದ ಅದೇ ಕಾರ್ಯವನ್ನು ಎಚ್ಚರಗೊಳಿಸಲು ಅದು ಮೂಲ [`RawWaker`] ನಿಂದ ಎಚ್ಚರಗೊಳ್ಳುತ್ತದೆ.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// [`Waker`] ನಲ್ಲಿ `wake` ಅನ್ನು ಕರೆದಾಗ ಈ ಕಾರ್ಯವನ್ನು ಕರೆಯಲಾಗುತ್ತದೆ.
    /// ಈ [`RawWaker`] ಗೆ ಸಂಬಂಧಿಸಿದ ಕಾರ್ಯವನ್ನು ಅದು ಎಚ್ಚರಗೊಳಿಸಬೇಕು.
    ///
    /// ಈ ಕಾರ್ಯದ ಅನುಷ್ಠಾನವು [`RawWaker`] ಮತ್ತು ಸಂಬಂಧಿತ ಕಾರ್ಯದ ಈ ನಿದರ್ಶನಕ್ಕೆ ಸಂಬಂಧಿಸಿದ ಯಾವುದೇ ಸಂಪನ್ಮೂಲಗಳನ್ನು ಬಿಡುಗಡೆ ಮಾಡುವುದನ್ನು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// [`Waker`] ನಲ್ಲಿ `wake_by_ref` ಅನ್ನು ಕರೆದಾಗ ಈ ಕಾರ್ಯವನ್ನು ಕರೆಯಲಾಗುತ್ತದೆ.
    /// ಈ [`RawWaker`] ಗೆ ಸಂಬಂಧಿಸಿದ ಕಾರ್ಯವನ್ನು ಅದು ಎಚ್ಚರಗೊಳಿಸಬೇಕು.
    ///
    /// ಈ ಕಾರ್ಯವು `wake` ಗೆ ಹೋಲುತ್ತದೆ, ಆದರೆ ಒದಗಿಸಿದ ಡೇಟಾ ಪಾಯಿಂಟರ್ ಅನ್ನು ಬಳಸಬಾರದು.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// [`RawWaker`] ಕೈಬಿಟ್ಟಾಗ ಈ ಕಾರ್ಯವನ್ನು ಕರೆಯಲಾಗುತ್ತದೆ.
    ///
    /// ಈ ಕಾರ್ಯದ ಅನುಷ್ಠಾನವು [`RawWaker`] ಮತ್ತು ಸಂಬಂಧಿತ ಕಾರ್ಯದ ಈ ನಿದರ್ಶನಕ್ಕೆ ಸಂಬಂಧಿಸಿದ ಯಾವುದೇ ಸಂಪನ್ಮೂಲಗಳನ್ನು ಬಿಡುಗಡೆ ಮಾಡುವುದನ್ನು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// ಒದಗಿಸಿದ `clone`, `wake`, `wake_by_ref`, ಮತ್ತು `drop` ಕಾರ್ಯಗಳಿಂದ ಹೊಸ `RawWakerVTable` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # `clone`
    ///
    /// [`RawWaker`] ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮಾಡಿದಾಗ ಈ ಕಾರ್ಯವನ್ನು ಕರೆಯಲಾಗುತ್ತದೆ, ಉದಾ. [`RawWaker`] ಅನ್ನು ಸಂಗ್ರಹಿಸಿರುವ [`Waker`] ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮಾಡಿದಾಗ.
    ///
    /// ಈ ಕಾರ್ಯದ ಅನುಷ್ಠಾನವು [`RawWaker`] ಮತ್ತು ಸಂಬಂಧಿತ ಕಾರ್ಯದ ಈ ಹೆಚ್ಚುವರಿ ನಿದರ್ಶನಕ್ಕೆ ಅಗತ್ಯವಿರುವ ಎಲ್ಲಾ ಸಂಪನ್ಮೂಲಗಳನ್ನು ಉಳಿಸಿಕೊಳ್ಳಬೇಕು.
    /// ಪರಿಣಾಮವಾಗಿ ಬರುವ [`RawWaker`] ನಲ್ಲಿ `wake` ಗೆ ಕರೆ ಮಾಡುವುದರಿಂದ ಅದೇ ಕಾರ್ಯವನ್ನು ಎಚ್ಚರಗೊಳಿಸಲು ಅದು ಮೂಲ [`RawWaker`] ನಿಂದ ಎಚ್ಚರಗೊಳ್ಳುತ್ತದೆ.
    ///
    /// # `wake`
    ///
    /// [`Waker`] ನಲ್ಲಿ `wake` ಅನ್ನು ಕರೆದಾಗ ಈ ಕಾರ್ಯವನ್ನು ಕರೆಯಲಾಗುತ್ತದೆ.
    /// ಈ [`RawWaker`] ಗೆ ಸಂಬಂಧಿಸಿದ ಕಾರ್ಯವನ್ನು ಅದು ಎಚ್ಚರಗೊಳಿಸಬೇಕು.
    ///
    /// ಈ ಕಾರ್ಯದ ಅನುಷ್ಠಾನವು [`RawWaker`] ಮತ್ತು ಸಂಬಂಧಿತ ಕಾರ್ಯದ ಈ ನಿದರ್ಶನಕ್ಕೆ ಸಂಬಂಧಿಸಿದ ಯಾವುದೇ ಸಂಪನ್ಮೂಲಗಳನ್ನು ಬಿಡುಗಡೆ ಮಾಡುವುದನ್ನು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// [`Waker`] ನಲ್ಲಿ `wake_by_ref` ಅನ್ನು ಕರೆದಾಗ ಈ ಕಾರ್ಯವನ್ನು ಕರೆಯಲಾಗುತ್ತದೆ.
    /// ಈ [`RawWaker`] ಗೆ ಸಂಬಂಧಿಸಿದ ಕಾರ್ಯವನ್ನು ಅದು ಎಚ್ಚರಗೊಳಿಸಬೇಕು.
    ///
    /// ಈ ಕಾರ್ಯವು `wake` ಗೆ ಹೋಲುತ್ತದೆ, ಆದರೆ ಒದಗಿಸಿದ ಡೇಟಾ ಪಾಯಿಂಟರ್ ಅನ್ನು ಬಳಸಬಾರದು.
    ///
    /// # `drop`
    ///
    /// [`RawWaker`] ಕೈಬಿಟ್ಟಾಗ ಈ ಕಾರ್ಯವನ್ನು ಕರೆಯಲಾಗುತ್ತದೆ.
    ///
    /// ಈ ಕಾರ್ಯದ ಅನುಷ್ಠಾನವು [`RawWaker`] ಮತ್ತು ಸಂಬಂಧಿತ ಕಾರ್ಯದ ಈ ನಿದರ್ಶನಕ್ಕೆ ಸಂಬಂಧಿಸಿದ ಯಾವುದೇ ಸಂಪನ್ಮೂಲಗಳನ್ನು ಬಿಡುಗಡೆ ಮಾಡುವುದನ್ನು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// ಅಸಮಕಾಲಿಕ ಕಾರ್ಯದ `Context`.
///
/// ಪ್ರಸ್ತುತ, `Context` `&Waker` ಗೆ ಪ್ರವೇಶವನ್ನು ಒದಗಿಸಲು ಮಾತ್ರ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ, ಇದನ್ನು ಪ್ರಸ್ತುತ ಕಾರ್ಯವನ್ನು ಎಚ್ಚರಗೊಳಿಸಲು ಬಳಸಬಹುದು.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // ಜೀವಿತಾವಧಿಯನ್ನು ಅಸ್ಥಿರವಾಗುವಂತೆ ಒತ್ತಾಯಿಸುವ ಮೂಲಕ ನಾವು ವ್ಯತ್ಯಾಸ ಬದಲಾವಣೆಗಳ ವಿರುದ್ಧ future-ಪ್ರೂಫ್ ಅನ್ನು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ (ಆರ್ಗ್ಯುಮೆಂಟ್-ಪೊಸಿಷನ್ ಜೀವಿತಾವಧಿಯು ವ್ಯತಿರಿಕ್ತವಾಗಿದೆ ಮತ್ತು ರಿಟರ್ನ್-ಪೊಸಿಷನ್ ಜೀವಿತಾವಧಿಯು ಕೋವಿಯಂಟ್ ಆಗಿರುತ್ತದೆ).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// `&Waker` ನಿಂದ ಹೊಸ `Context` ಅನ್ನು ರಚಿಸಿ.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// ಪ್ರಸ್ತುತ ಕಾರ್ಯಕ್ಕಾಗಿ `Waker` ಗೆ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` ಎನ್ನುವುದು ಕಾರ್ಯವನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ಸಿದ್ಧವಾಗಿದೆ ಎಂದು ಅದರ ಕಾರ್ಯನಿರ್ವಾಹಕರಿಗೆ ತಿಳಿಸುವ ಮೂಲಕ ಕಾರ್ಯವನ್ನು ಎಚ್ಚರಗೊಳಿಸುವ ಹ್ಯಾಂಡಲ್ ಆಗಿದೆ.
///
/// ಈ ಹ್ಯಾಂಡಲ್ [`RawWaker`] ನಿದರ್ಶನವನ್ನು ಒಳಗೊಳ್ಳುತ್ತದೆ, ಇದು ಕಾರ್ಯನಿರ್ವಾಹಕ-ನಿರ್ದಿಷ್ಟ ಎಚ್ಚರಗೊಳ್ಳುವ ನಡವಳಿಕೆಯನ್ನು ವ್ಯಾಖ್ಯಾನಿಸುತ್ತದೆ.
///
///
/// [`Clone`], [`Send`], ಮತ್ತು [`Sync`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// ಈ `Waker` ಗೆ ಸಂಬಂಧಿಸಿದ ಕಾರ್ಯವನ್ನು ಎಚ್ಚರಗೊಳಿಸಿ.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // ನಿಜವಾದ ಎಚ್ಚರಗೊಳ್ಳುವ ಕರೆಯನ್ನು ವರ್ಚುವಲ್ ಫಂಕ್ಷನ್ ಕರೆಯ ಮೂಲಕ ಅನುಷ್ಠಾನಕ್ಕೆ ನಿಯೋಜಿಸಲಾಗುತ್ತದೆ, ಇದನ್ನು ಕಾರ್ಯನಿರ್ವಾಹಕರಿಂದ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗುತ್ತದೆ.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // `drop` ಗೆ ಕರೆ ಮಾಡಬೇಡಿ-ವಾಕರ್ ಅನ್ನು `wake` ಸೇವಿಸುತ್ತದೆ.
        crate::mem::forget(self);

        // ಸುರಕ್ಷತೆ: ಇದು ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ `Waker::from_raw` ಏಕೈಕ ಮಾರ್ಗವಾಗಿದೆ
        // `wake` ಮತ್ತು `data` ಅನ್ನು ಪ್ರಾರಂಭಿಸಲು `RawWaker` ನ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಲಾಗಿದೆ ಎಂದು ಬಳಕೆದಾರರು ಒಪ್ಪಿಕೊಳ್ಳಬೇಕು.
        //
        unsafe { (wake)(data) };
    }

    /// `Waker` ಅನ್ನು ಸೇವಿಸದೆ ಈ `Waker` ಗೆ ಸಂಬಂಧಿಸಿದ ಕಾರ್ಯವನ್ನು ಎಚ್ಚರಗೊಳಿಸಿ.
    ///
    /// ಇದು `wake` ಗೆ ಹೋಲುತ್ತದೆ, ಆದರೆ ಒಡೆತನದ `Waker` ಲಭ್ಯವಿರುವ ಸಂದರ್ಭದಲ್ಲಿ ಸ್ವಲ್ಪ ಕಡಿಮೆ ದಕ್ಷತೆಯನ್ನು ಹೊಂದಿರಬಹುದು.
    /// `waker.clone().wake()` ಗೆ ಕರೆ ಮಾಡಲು ಈ ವಿಧಾನವನ್ನು ಆದ್ಯತೆ ನೀಡಬೇಕು.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // ನಿಜವಾದ ಎಚ್ಚರಗೊಳ್ಳುವ ಕರೆಯನ್ನು ವರ್ಚುವಲ್ ಫಂಕ್ಷನ್ ಕರೆಯ ಮೂಲಕ ಅನುಷ್ಠಾನಕ್ಕೆ ನಿಯೋಜಿಸಲಾಗುತ್ತದೆ, ಇದನ್ನು ಕಾರ್ಯನಿರ್ವಾಹಕರಿಂದ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗುತ್ತದೆ.
        //

        // ಸುರಕ್ಷತೆ: `wake` ನೋಡಿ
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// ಈ `Waker` ಮತ್ತು ಇನ್ನೊಂದು `Waker` ಒಂದೇ ಕಾರ್ಯವನ್ನು ಜಾಗೃತಗೊಳಿಸಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಕಾರ್ಯವು ಉತ್ತಮ ಪ್ರಯತ್ನದ ಆಧಾರದ ಮೇಲೆ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ, ಮತ್ತು `ವಾಕರ್'ಗಳು ಅದೇ ಕಾರ್ಯವನ್ನು ಜಾಗೃತಗೊಳಿಸಿದಾಗಲೂ ಸುಳ್ಳನ್ನು ಹಿಂತಿರುಗಿಸಬಹುದು.
    /// ಆದಾಗ್ಯೂ, ಈ ಕಾರ್ಯವು `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸಿದರೆ, `ವಾಕರ್'ಗಳು ಅದೇ ಕಾರ್ಯವನ್ನು ಜಾಗೃತಗೊಳಿಸುತ್ತಾರೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗುತ್ತದೆ.
    ///
    /// ಈ ಕಾರ್ಯವನ್ನು ಪ್ರಾಥಮಿಕವಾಗಿ ಆಪ್ಟಿಮೈಸೇಶನ್ ಉದ್ದೇಶಗಳಿಗಾಗಿ ಬಳಸಲಾಗುತ್ತದೆ.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// [`RawWaker`] ನಿಂದ ಹೊಸ `Waker` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// [`ರಾವಾಕರ್`] ಮತ್ತು [`ರಾವಾಕರ್ ವಿಟಬಲ್`] ದಸ್ತಾವೇಜಿನಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯದಿದ್ದರೆ ಹಿಂದಿರುಗಿದ `Waker` ನ ನಡವಳಿಕೆಯನ್ನು ವಿವರಿಸಲಾಗುವುದಿಲ್ಲ.
    ///
    /// ಆದ್ದರಿಂದ ಈ ವಿಧಾನವು ಅಸುರಕ್ಷಿತವಾಗಿದೆ.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // ಸುರಕ್ಷತೆ: ಇದು ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ `Waker::from_raw` ಏಕೈಕ ಮಾರ್ಗವಾಗಿದೆ
            // `clone` ಮತ್ತು `data` ಅನ್ನು ಪ್ರಾರಂಭಿಸಲು [`RawWaker`] ನ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಲಾಗಿದೆ ಎಂದು ಬಳಕೆದಾರರು ಒಪ್ಪಿಕೊಳ್ಳಬೇಕು.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // ಸುರಕ್ಷತೆ: ಇದು ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ `Waker::from_raw` ಏಕೈಕ ಮಾರ್ಗವಾಗಿದೆ
        // `drop` ಮತ್ತು `data` ಅನ್ನು ಪ್ರಾರಂಭಿಸಲು `RawWaker` ನ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಲಾಗಿದೆ ಎಂದು ಬಳಕೆದಾರರು ಒಪ್ಪಿಕೊಳ್ಳಬೇಕು.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}