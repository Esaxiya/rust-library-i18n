//! ASCII `[u8]` ನಲ್ಲಿ ಕಾರ್ಯಾಚರಣೆಗಳು.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// ಈ ಸ್ಲೈಸ್‌ನಲ್ಲಿರುವ ಎಲ್ಲಾ ಬೈಟ್‌ಗಳು ASCII ವ್ಯಾಪ್ತಿಯಲ್ಲಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// ಎರಡು ಚೂರುಗಳು ಎಎಸ್ಸಿಐಐ ಕೇಸ್-ಸೆನ್ಸಿಟಿವ್ ಮ್ಯಾಚ್ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` ನಂತೆಯೇ, ಆದರೆ ತಾತ್ಕಾಲಿಕಗಳನ್ನು ನಿಯೋಜಿಸದೆ ಮತ್ತು ನಕಲಿಸದೆ.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// ಈ ಸ್ಲೈಸ್ ಅನ್ನು ಅದರ ಎಎಸ್ಸಿಐಐ ಮೇಲಿನ ಪ್ರಕರಣಕ್ಕೆ ಸಮಾನವಾದ ಸ್ಥಳಕ್ಕೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ASCII ಅಕ್ಷರಗಳು 'a' ರಿಂದ 'z' ಅನ್ನು 'A' ನಿಂದ 'Z' ಗೆ ಮ್ಯಾಪ್ ಮಾಡಲಾಗಿದೆ, ಆದರೆ ASCII ಅಲ್ಲದ ಅಕ್ಷರಗಳು ಬದಲಾಗುವುದಿಲ್ಲ.
    ///
    /// ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ ಒಂದನ್ನು ಮಾರ್ಪಡಿಸದೆ ಹೊಸ ದೊಡ್ಡ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸಲು, [`to_ascii_uppercase`] ಬಳಸಿ.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// ಈ ಸ್ಲೈಸ್ ಅನ್ನು ಅದರ ಎಎಸ್ಸಿಐಐ ಲೋವರ್ ಕೇಸ್ ಸಮಾನ ಸ್ಥಳಕ್ಕೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ASCII ಅಕ್ಷರಗಳು 'A' ರಿಂದ 'Z' ಅನ್ನು 'a' ನಿಂದ 'z' ಗೆ ಮ್ಯಾಪ್ ಮಾಡಲಾಗಿದೆ, ಆದರೆ ASCII ಅಲ್ಲದ ಅಕ್ಷರಗಳು ಬದಲಾಗುವುದಿಲ್ಲ.
    ///
    /// ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ ಒಂದನ್ನು ಮಾರ್ಪಡಿಸದೆ ಹೊಸ ಕಡಿಮೆ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸಲು, [`to_ascii_lowercase`] ಬಳಸಿ.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// `v` ಪದದಲ್ಲಿನ ಯಾವುದೇ ಬೈಟ್ ನಾನಾಸ್ಕಿ (>=128) ಆಗಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
/// `../str/mod.rs` ನಿಂದ ಸ್ನಾರ್ಫೆಡ್, ಇದು utf8 ation ರ್ಜಿತಗೊಳಿಸುವಿಕೆಗೆ ಹೋಲುತ್ತದೆ.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// ಆಪ್ಟಿಮೈಸ್ಡ್ ಎಎಸ್ಸಿಐಐ ಪರೀಕ್ಷೆ, ಅದು ಬೈಟ್-ಅಟ್-ಎ-ಟೈಮ್ ಕಾರ್ಯಾಚರಣೆಗಳ ಬದಲಿಗೆ (ಸಾಧ್ಯವಾದಾಗ) ಬದಲಾಗಿ ಸಮಯ-ಸಮಯದ ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬಳಸುತ್ತದೆ.
///
/// ನಾವು ಇಲ್ಲಿ ಬಳಸುವ ಅಲ್ಗಾರಿದಮ್ ಬಹಳ ಸರಳವಾಗಿದೆ.`s` ತುಂಬಾ ಚಿಕ್ಕದಾಗಿದ್ದರೆ, ನಾವು ಪ್ರತಿ ಬೈಟ್ ಅನ್ನು ಪರಿಶೀಲಿಸುತ್ತೇವೆ ಮತ್ತು ಅದರೊಂದಿಗೆ ಮಾಡಲಾಗುತ್ತದೆ.ಇಲ್ಲದಿದ್ದರೆ:
///
/// - ಜೋಡಿಸದ ಲೋಡ್‌ನೊಂದಿಗೆ ಮೊದಲ ಪದವನ್ನು ಓದಿ.
/// - ಪಾಯಿಂಟರ್ ಅನ್ನು ಜೋಡಿಸಿ, ಜೋಡಿಸಲಾದ ಲೋಡ್‌ಗಳೊಂದಿಗೆ ಕೊನೆಯ ಪದಗಳನ್ನು ಕೊನೆಯವರೆಗೂ ಓದಿ.
/// - ಜೋಡಿಸದ ಲೋಡ್‌ನೊಂದಿಗೆ `s` ನಿಂದ ಕೊನೆಯ `usize` ಅನ್ನು ಓದಿ.
///
/// ಈ ಯಾವುದೇ ಲೋಡ್‌ಗಳು `contains_nonascii` (above) ನಿಜವಾಗಿದ್ದನ್ನು ಉತ್ಪಾದಿಸಿದರೆ, ಉತ್ತರವು ಸುಳ್ಳು ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // ಸಮಯದ ಅನುಷ್ಠಾನದಿಂದ ನಾವು ಏನನ್ನೂ ಗಳಿಸದಿದ್ದರೆ, ಸ್ಕೇಲಾರ್ ಲೂಪ್‌ಗೆ ಹಿಂತಿರುಗಿ.
    //
    // `usize` ಗೆ `size_of::<usize>()` ಸಾಕಷ್ಟು ಜೋಡಣೆ ಇಲ್ಲದಿರುವ ವಾಸ್ತುಶಿಲ್ಪಗಳಿಗಾಗಿ ನಾವು ಇದನ್ನು ಮಾಡುತ್ತೇವೆ, ಏಕೆಂದರೆ ಇದು ವಿಲಕ್ಷಣವಾದ edge ಪ್ರಕರಣವಾಗಿದೆ.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // ನಾವು ಯಾವಾಗಲೂ ಜೋಡಿಸದ ಮೊದಲ ಪದವನ್ನು ಓದುತ್ತೇವೆ, ಅಂದರೆ `align_offset`
    // 0, ಜೋಡಿಸಲಾದ ಓದುವಿಕೆಗಾಗಿ ನಾವು ಮತ್ತೆ ಅದೇ ಮೌಲ್ಯವನ್ನು ಓದುತ್ತೇವೆ.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // ಸುರಕ್ಷತೆ: ಮೇಲಿನ `len < USIZE_SIZE` ಅನ್ನು ನಾವು ಪರಿಶೀಲಿಸುತ್ತೇವೆ.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // ನಾವು ಇದನ್ನು ಸ್ವಲ್ಪಮಟ್ಟಿಗೆ ಸೂಚ್ಯವಾಗಿ ಪರಿಶೀಲಿಸಿದ್ದೇವೆ.
    // `offset_to_aligned` `align_offset` ಅಥವಾ `USIZE_SIZE` ಆಗಿರುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಎರಡೂ ಮೇಲೆ ಸ್ಪಷ್ಟವಾಗಿ ಪರಿಶೀಲಿಸಲಾಗುತ್ತದೆ.
    //
    debug_assert!(offset_to_aligned <= len);

    // ಸುರಕ್ಷತೆ: word_ptr ಎನ್ನುವುದು ನಾವು ಓದಲು ಬಳಸುವ (ಸರಿಯಾಗಿ ಜೋಡಿಸಲಾದ) ಬಳಕೆಯ ಪಿಟಿಆರ್ ಆಗಿದೆ
    // ಸ್ಲೈಸ್ನ ಮಧ್ಯದ ಭಾಗ.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` `word_ptr` ನ ಬೈಟ್ ಸೂಚ್ಯಂಕವಾಗಿದೆ, ಇದನ್ನು ಲೂಪ್ ಎಂಡ್ ಚೆಕ್‌ಗಳಿಗಾಗಿ ಬಳಸಲಾಗುತ್ತದೆ.
    let mut byte_pos = offset_to_aligned;

    // ವ್ಯಾಮೋಹವು ಜೋಡಣೆಯ ಬಗ್ಗೆ ಪರಿಶೀಲಿಸಿ, ಏಕೆಂದರೆ ನಾವು ಜೋಡಿಸದ ಲೋಡ್‌ಗಳ ಗುಂಪನ್ನು ಮಾಡಲಿದ್ದೇವೆ.
    // ಪ್ರಾಯೋಗಿಕವಾಗಿ ಇದು `align_offset` ನಲ್ಲಿನ ದೋಷವನ್ನು ಹೊರತುಪಡಿಸಿ ಅಸಾಧ್ಯ.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // ಕೊನೆಯ ಜೋಡಿಸಲಾದ ಪದದ ತನಕ ನಂತರದ ಪದಗಳನ್ನು ಓದಿ, ನಂತರ ಬಾಲ ಜೋಡಣೆಯಲ್ಲಿ ಮಾಡಬೇಕಾದ ಕೊನೆಯ ಜೋಡಿಸಲಾದ ಪದವನ್ನು ಹೊರತುಪಡಿಸಿ, ಬಾಲವು ಯಾವಾಗಲೂ ಒಂದು `usize` ಆಗಿರುತ್ತದೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ಹೆಚ್ಚುವರಿ branch `byte_pos == len` ಗೆ.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // ಓದುವಿಕೆ ಮಿತಿಯಲ್ಲಿದೆ ಎಂದು ವಿವೇಕದ ಪರಿಶೀಲನೆ
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // ಮತ್ತು `byte_pos` ಬಗ್ಗೆ ನಮ್ಮ ump ಹೆಗಳನ್ನು ಹಿಡಿದಿಟ್ಟುಕೊಳ್ಳುತ್ತದೆ.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // ಸುರಕ್ಷತೆ: `word_ptr` ಅನ್ನು ಸರಿಯಾಗಿ ಜೋಡಿಸಲಾಗಿದೆ ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ (ಏಕೆಂದರೆ
        // `align_offset`), ಮತ್ತು ನಮ್ಮಲ್ಲಿ `word_ptr` ಮತ್ತು ಅಂತ್ಯದ ನಡುವೆ ಸಾಕಷ್ಟು ಬೈಟ್‌ಗಳಿವೆ ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // ಸುರಕ್ಷತೆ: `byte_pos <= len - USIZE_SIZE` ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ, ಇದರರ್ಥ
        // ಈ `add` ನಂತರ, `word_ptr` ಒಂದು-ಕೊನೆಯ-ಅಂತ್ಯವಾಗಿರುತ್ತದೆ.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // ನಿಜವಾಗಿಯೂ ಕೇವಲ ಒಂದು `usize` ಮಾತ್ರ ಉಳಿದಿದೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ವಿವೇಕ ಪರಿಶೀಲನೆ.
    // ನಮ್ಮ ಲೂಪ್ ಸ್ಥಿತಿಯಿಂದ ಇದನ್ನು ಖಾತರಿಪಡಿಸಬೇಕು.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // ಸುರಕ್ಷತೆ: ಇದು `len >= USIZE_SIZE` ಅನ್ನು ಅವಲಂಬಿಸಿದೆ, ಅದನ್ನು ನಾವು ಪ್ರಾರಂಭದಲ್ಲಿ ಪರಿಶೀಲಿಸುತ್ತೇವೆ.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}