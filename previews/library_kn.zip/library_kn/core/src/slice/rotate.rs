// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// `[mid-left, mid+right)` ಶ್ರೇಣಿಯನ್ನು ತಿರುಗಿಸುತ್ತದೆ ಅಂದರೆ `mid` ನಲ್ಲಿರುವ ಅಂಶವು ಮೊದಲ ಅಂಶವಾಗುತ್ತದೆ.ಸಮಾನವಾಗಿ, ಶ್ರೇಣಿ `left` ಅಂಶಗಳನ್ನು ಎಡಕ್ಕೆ ಅಥವಾ `right` ಅಂಶಗಳನ್ನು ಬಲಕ್ಕೆ ತಿರುಗಿಸುತ್ತದೆ.
///
/// # Safety
///
/// ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಶ್ರೇಣಿ ಓದಲು ಮತ್ತು ಬರೆಯಲು ಮಾನ್ಯವಾಗಿರಬೇಕು.
///
/// # Algorithm
///
/// ಅಲ್ಗಾರಿದಮ್ 1 ಅನ್ನು `left + right` ನ ಸಣ್ಣ ಮೌಲ್ಯಗಳಿಗೆ ಅಥವಾ ದೊಡ್ಡ `T` ಗಾಗಿ ಬಳಸಲಾಗುತ್ತದೆ.
/// `mid - left` ನಿಂದ ಪ್ರಾರಂಭವಾಗುವ ಮತ್ತು `right` ಹಂತಗಳ ಮಾಡ್ಯುಲೋ `left + right` ನಿಂದ ಮುಂದುವರಿಯುವ ಅಂಶಗಳನ್ನು ಒಂದೊಂದಾಗಿ ಅವುಗಳ ಅಂತಿಮ ಸ್ಥಾನಗಳಿಗೆ ಸರಿಸಲಾಗುತ್ತದೆ, ಅಂದರೆ ಕೇವಲ ಒಂದು ತಾತ್ಕಾಲಿಕ ಅಗತ್ಯವಿರುತ್ತದೆ.
/// ಅಂತಿಮವಾಗಿ, ನಾವು `mid - left` ಗೆ ಹಿಂತಿರುಗುತ್ತೇವೆ.
/// ಆದಾಗ್ಯೂ, `gcd(left + right, right)` 1 ಅಲ್ಲದಿದ್ದರೆ, ಮೇಲಿನ ಹಂತಗಳು ಅಂಶಗಳ ಮೇಲೆ ಬಿಟ್ಟುಬಿಡುತ್ತವೆ.
/// ಉದಾಹರಣೆಗೆ:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// ಅದೃಷ್ಟವಶಾತ್, ಅಂತಿಮ ಅಂಶಗಳ ನಡುವೆ ಬಿಟ್ಟುಬಿಟ್ಟ ಅಂಶಗಳ ಸಂಖ್ಯೆ ಯಾವಾಗಲೂ ಸಮಾನವಾಗಿರುತ್ತದೆ, ಆದ್ದರಿಂದ ನಾವು ನಮ್ಮ ಆರಂಭಿಕ ಸ್ಥಾನವನ್ನು ಸರಿದೂಗಿಸಬಹುದು ಮತ್ತು ಹೆಚ್ಚಿನ ಸುತ್ತುಗಳನ್ನು ಮಾಡಬಹುದು (ಒಟ್ಟು ಸುತ್ತುಗಳ ಸಂಖ್ಯೆ `gcd(left + right, right)` value) ಆಗಿದೆ.
///
/// ಅಂತಿಮ ಫಲಿತಾಂಶವೆಂದರೆ ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ಒಮ್ಮೆ ಮತ್ತು ಒಮ್ಮೆ ಮಾತ್ರ ಅಂತಿಮಗೊಳಿಸಲಾಗುತ್ತದೆ.
///
/// `left + right` ದೊಡ್ಡದಾಗಿದ್ದರೆ ಅಲ್ಗಾರಿದಮ್ 2 ಅನ್ನು ಬಳಸಲಾಗುತ್ತದೆ ಆದರೆ `min(left, right)` ಸ್ಟಾಕ್ ಬಫರ್‌ಗೆ ಹೊಂದಿಕೊಳ್ಳಲು ಸಾಕಷ್ಟು ಚಿಕ್ಕದಾಗಿದೆ.
/// `min(left, right)` ಅಂಶಗಳನ್ನು ಬಫರ್‌ನಲ್ಲಿ ನಕಲಿಸಲಾಗುತ್ತದೆ, `memmove` ಅನ್ನು ಇತರರಿಗೆ ಅನ್ವಯಿಸಲಾಗುತ್ತದೆ, ಮತ್ತು ಬಫರ್‌ನಲ್ಲಿರುವವುಗಳನ್ನು ಅವು ಹುಟ್ಟಿದ ಸ್ಥಳದ ಎದುರು ಭಾಗದಲ್ಲಿರುವ ರಂಧ್ರಕ್ಕೆ ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
///
/// `left + right` ಸಾಕಷ್ಟು ದೊಡ್ಡದಾದ ನಂತರ ವೆಕ್ಟರೈಸ್ ಮಾಡಬಹುದಾದ ಕ್ರಮಾವಳಿಗಳು ಮೇಲಿನದನ್ನು ಮೀರಿಸುತ್ತದೆ.
/// ಏಕಕಾಲದಲ್ಲಿ ಅನೇಕ ಸುತ್ತುಗಳನ್ನು ಚಂಕ್ ಮಾಡುವ ಮೂಲಕ ಮತ್ತು ಪ್ರದರ್ಶಿಸುವ ಮೂಲಕ ಅಲ್ಗಾರಿದಮ್ 1 ಅನ್ನು ವೆಕ್ಟರೈಸ್ ಮಾಡಬಹುದು, ಆದರೆ `left + right` ಅಗಾಧವಾಗುವವರೆಗೆ ಸರಾಸರಿ ತುಂಬಾ ಕಡಿಮೆ ಸುತ್ತುಗಳಿವೆ, ಮತ್ತು ಒಂದೇ ಸುತ್ತಿನ ಕೆಟ್ಟ ಪ್ರಕರಣ ಯಾವಾಗಲೂ ಇರುತ್ತದೆ.
/// ಬದಲಾಗಿ, ಅಲ್ಗಾರಿದಮ್ 3 ಸಣ್ಣ ತಿರುಗುವ ಸಮಸ್ಯೆ ಉಳಿದಿರುವವರೆಗೆ `min(left, right)` ಅಂಶಗಳ ಪುನರಾವರ್ತಿತ ವಿನಿಮಯವನ್ನು ಬಳಸುತ್ತದೆ.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// `left < right` ವಿನಿಮಯವು ಎಡದಿಂದ ಬದಲಾಗಿ ಸಂಭವಿಸುತ್ತದೆ.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. ಈ ಪ್ರಕರಣಗಳನ್ನು ಪರಿಶೀಲಿಸದಿದ್ದರೆ ಕೆಳಗಿನ ಕ್ರಮಾವಳಿಗಳು ವಿಫಲಗೊಳ್ಳಬಹುದು
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // ಅಲ್ಗಾರಿದಮ್ 1 ಮೈಕ್ರೊಬೆಂಚ್‌ಮಾರ್ಕ್‌ಗಳು `left + right == 32` ರವರೆಗೆ ಯಾದೃಚ್ sh ಿಕ ವರ್ಗಾವಣೆಗಳ ಸರಾಸರಿ ಕಾರ್ಯಕ್ಷಮತೆ ಉತ್ತಮವಾಗಿದೆ ಎಂದು ಸೂಚಿಸುತ್ತದೆ, ಆದರೆ ಕೆಟ್ಟ ಕಾರ್ಯಕ್ಷಮತೆಯು 16 ರ ಆಸುಪಾಸಿನಲ್ಲಿ ಮುರಿಯುತ್ತದೆ.
            // 24 ಅನ್ನು ಮಧ್ಯಮ ಮೈದಾನವಾಗಿ ಆಯ್ಕೆ ಮಾಡಲಾಯಿತು.
            // `T` ನ ಗಾತ್ರವು 4 `usize` ಗಿಂತ ದೊಡ್ಡದಾಗಿದ್ದರೆ, ಈ ಅಲ್ಗಾರಿದಮ್ ಇತರ ಕ್ರಮಾವಳಿಗಳನ್ನು ಮೀರಿಸುತ್ತದೆ.
            //
            //
            let x = unsafe { mid.sub(left) };
            // ಮೊದಲ ಸುತ್ತಿನ ಆರಂಭ
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` `gcd(left + right, right)` ಅನ್ನು ಲೆಕ್ಕಹಾಕುವ ಮೂಲಕ ಕೈಗೆ ಮುಂಚಿತವಾಗಿ ಕಂಡುಹಿಡಿಯಬಹುದು, ಆದರೆ ಜಿಸಿಡಿಯನ್ನು ಅಡ್ಡಪರಿಣಾಮವಾಗಿ ಲೆಕ್ಕಹಾಕುವ ಒಂದು ಲೂಪ್ ಅನ್ನು ವೇಗವಾಗಿ ಮಾಡುವುದು, ನಂತರ ಉಳಿದ ಭಾಗವನ್ನು ಮಾಡುವುದು
            //
            //
            let mut gcd = right;
            // ಒಂದು ತಾತ್ಕಾಲಿಕತೆಯನ್ನು ಒಮ್ಮೆ ಓದುವ ಬದಲು, ಹಿಂದಕ್ಕೆ ನಕಲಿಸಿ, ತದನಂತರ ಆ ತಾತ್ಕಾಲಿಕವನ್ನು ಬಹಳ ಕೊನೆಯಲ್ಲಿ ಬರೆಯುವ ಬದಲು ತಾತ್ಕಾಲಿಕತೆಯನ್ನು ವಿನಿಮಯ ಮಾಡಿಕೊಳ್ಳುವುದು ವೇಗವಾಗಿದೆ ಎಂದು ಮಾನದಂಡಗಳು ಬಹಿರಂಗಪಡಿಸುತ್ತವೆ.
            // ತಾತ್ಕಾಲಿಕಗಳನ್ನು ವಿನಿಮಯ ಮಾಡಿಕೊಳ್ಳುವುದು ಅಥವಾ ಬದಲಾಯಿಸುವುದು ಎರಡನ್ನು ನಿರ್ವಹಿಸುವ ಬದಲು ಲೂಪ್‌ನಲ್ಲಿ ಕೇವಲ ಒಂದು ಮೆಮೊರಿ ವಿಳಾಸವನ್ನು ಬಳಸುತ್ತದೆ ಎಂಬುದು ಇದಕ್ಕೆ ಕಾರಣ.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // `i` ಅನ್ನು ಹೆಚ್ಚಿಸುವ ಬದಲು ಮತ್ತು ಅದು ಗಡಿರೇಖೆಯ ಹೊರಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುವ ಬದಲು, ಮುಂದಿನ ಏರಿಕೆಯಲ್ಲಿ `i` ಗಡಿಯ ಹೊರಗೆ ಹೋಗುತ್ತದೆಯೇ ಎಂದು ನಾವು ಪರಿಶೀಲಿಸುತ್ತೇವೆ.
                // ಇದು ಪಾಯಿಂಟರ್ಸ್ ಅಥವಾ ಎಕ್ಸ್ 00 ಎಕ್ಸ್ ಅನ್ನು ಸುತ್ತುವುದನ್ನು ತಡೆಯುತ್ತದೆ.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // ಮೊದಲ ಸುತ್ತಿನ ಅಂತ್ಯ
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // `left + right >= 15` ಇದ್ದರೆ ಈ ಷರತ್ತುಬದ್ಧವಾಗಿರಬೇಕು
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // ಹೆಚ್ಚಿನ ಸುತ್ತುಗಳೊಂದಿಗೆ ಚಂಕ್ ಅನ್ನು ಮುಗಿಸಿ
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` ಶೂನ್ಯ-ಗಾತ್ರದ ಪ್ರಕಾರವಲ್ಲ, ಆದ್ದರಿಂದ ಅದರ ಗಾತ್ರದಿಂದ ಭಾಗಿಸುವುದು ಸರಿಯಾಗಿದೆ.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // ಅಲ್ಗಾರಿದಮ್ 2 ಇಲ್ಲಿ `[T; 0]` ಇದು T ಗಾಗಿ ಸೂಕ್ತವಾಗಿ ಜೋಡಿಸಲ್ಪಟ್ಟಿದೆಯೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳುವುದು
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // ಅಲ್ಗಾರಿದಮ್ 3 ಈ ಅಲ್ಗಾರಿದಮ್ನ ಕೊನೆಯ ಸ್ವಾಪ್ ಎಲ್ಲಿದೆ ಎಂಬುದನ್ನು ಕಂಡುಹಿಡಿಯುವ ಪರ್ಯಾಯ ಮಾರ್ಗವಿದೆ, ಮತ್ತು ಈ ಅಲ್ಗಾರಿದಮ್ನಂತಹ ಪಕ್ಕದ ಭಾಗಗಳನ್ನು ವಿನಿಮಯ ಮಾಡಿಕೊಳ್ಳುವ ಬದಲು ಕೊನೆಯ ಭಾಗವನ್ನು ಬಳಸಿ ವಿನಿಮಯ ಮಾಡಿಕೊಳ್ಳುತ್ತಿದೆ, ಆದರೆ ಈ ಮಾರ್ಗವು ಇನ್ನೂ ವೇಗವಾಗಿದೆ.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // ಅಲ್ಗಾರಿದಮ್ 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}