// ಮೂಲ ಅನುಷ್ಠಾನವನ್ನು rust-memchr ನಿಂದ ತೆಗೆದುಕೊಳ್ಳಲಾಗಿದೆ.
// ಕೃತಿಸ್ವಾಮ್ಯ 2015 ಆಂಡ್ರ್ಯೂ ಗ್ಯಾಲೆಂಟ್, ಬ್ಲಸ್ ಮತ್ತು ನಿಕೋಲಸ್ ಕೋಚ್

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// ಮೊಟಕುಗೊಳಿಸುವಿಕೆಯನ್ನು ಬಳಸಿ.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// `x` ಯಾವುದೇ ಶೂನ್ಯ ಬೈಟ್ ಹೊಂದಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
///
/// *ಮ್ಯಾಟರ್ಸ್ ಕಂಪ್ಯೂಟೇಶನಲ್* ನಿಂದ, ಜೆ. ಅರ್ಂಡ್ಟ್:
///
/// "ಪ್ರತಿಯೊಂದು ಬೈಟ್‌ಗಳಿಂದ ಒಂದನ್ನು ಕಳೆಯುವುದು ಮತ್ತು ನಂತರ ಬೈಟ್‌ಗಳನ್ನು ಹುಡುಕುವುದು, ಅಲ್ಲಿ ಸಾಲವು ಎಲ್ಲಕ್ಕಿಂತ ಹೆಚ್ಚು ಪ್ರಾಮುಖ್ಯತೆಯನ್ನು ಪಡೆಯುತ್ತದೆ
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// `text` ನಲ್ಲಿ ಬೈಟ್ `x` ಗೆ ಹೊಂದಿಕೆಯಾಗುವ ಮೊದಲ ಸೂಚಿಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // ಸಣ್ಣ ಚೂರುಗಳಿಗೆ ವೇಗದ ಮಾರ್ಗ
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // ಒಂದು ಸಮಯದಲ್ಲಿ ಎರಡು `usize` ಪದಗಳನ್ನು ಓದುವ ಮೂಲಕ ಒಂದೇ ಬೈಟ್ ಮೌಲ್ಯಕ್ಕಾಗಿ ಸ್ಕ್ಯಾನ್ ಮಾಡಿ.
    //
    // `text` ಅನ್ನು ಮೂರು ಭಾಗಗಳಾಗಿ ವಿಭಜಿಸಿ
    // - ಜೋಡಿಸದ ಆರಂಭಿಕ ಭಾಗ, ಪಠ್ಯದಲ್ಲಿ ಮೊದಲ ಪದವನ್ನು ಜೋಡಿಸಿದ ವಿಳಾಸದ ಮೊದಲು
    // - ದೇಹ, ಒಂದು ಸಮಯದಲ್ಲಿ 2 ಪದಗಳಿಂದ ಸ್ಕ್ಯಾನ್ ಮಾಡಿ
    // - ಕೊನೆಯ ಉಳಿದ ಭಾಗ, <2 ಪದದ ಗಾತ್ರ

    // ಜೋಡಿಸಲಾದ ಗಡಿಯವರೆಗೆ ಹುಡುಕಿ
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // ಪಠ್ಯದ ದೇಹವನ್ನು ಹುಡುಕಿ
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // ಸುರಕ್ಷತೆ: ಸಮಯದ ಮುನ್ಸೂಚನೆಯು ಕನಿಷ್ಠ 2 * ಯುಸೈಜ್_ಬೈಟ್‌ಗಳ ಅಂತರವನ್ನು ಖಾತರಿಪಡಿಸುತ್ತದೆ
        // ಆಫ್‌ಸೆಟ್ ಮತ್ತು ಸ್ಲೈಸ್‌ನ ಅಂತ್ಯದ ನಡುವೆ.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // ಹೊಂದಾಣಿಕೆಯ ಬೈಟ್ ಇದ್ದರೆ ಮುರಿಯಿರಿ
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // ಬಾಡಿ ಲೂಪ್ ನಿಲ್ಲಿಸಿದ ನಂತರ ಬೈಟ್ ಅನ್ನು ಹುಡುಕಿ.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// `text` ನಲ್ಲಿ ಬೈಟ್ `x` ಗೆ ಹೊಂದಿಕೆಯಾಗುವ ಕೊನೆಯ ಸೂಚಿಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // ಒಂದು ಸಮಯದಲ್ಲಿ ಎರಡು `usize` ಪದಗಳನ್ನು ಓದುವ ಮೂಲಕ ಒಂದೇ ಬೈಟ್ ಮೌಲ್ಯಕ್ಕಾಗಿ ಸ್ಕ್ಯಾನ್ ಮಾಡಿ.
    //
    // `text` ಅನ್ನು ಮೂರು ಭಾಗಗಳಾಗಿ ವಿಭಜಿಸಿ:
    // - ಜೋಡಿಸದ ಬಾಲ, ಪಠ್ಯದಲ್ಲಿ ಕೊನೆಯ ಪದವನ್ನು ಜೋಡಿಸಿದ ವಿಳಾಸದ ನಂತರ,
    // - ದೇಹ, ಒಂದು ಸಮಯದಲ್ಲಿ 2 ಪದಗಳಿಂದ ಸ್ಕ್ಯಾನ್ ಮಾಡಲಾಗಿದೆ,
    // - ಉಳಿದಿರುವ ಮೊದಲ ಬೈಟ್‌ಗಳು, <2 ಪದದ ಗಾತ್ರ.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // ಪೂರ್ವಪ್ರತ್ಯಯ ಮತ್ತು ಪ್ರತ್ಯಯದ ಉದ್ದವನ್ನು ಪಡೆಯಲು ನಾವು ಇದನ್ನು ಕರೆಯುತ್ತೇವೆ.
        // ಮಧ್ಯದಲ್ಲಿ ನಾವು ಯಾವಾಗಲೂ ಎರಡು ಭಾಗಗಳನ್ನು ಒಂದೇ ಬಾರಿಗೆ ಪ್ರಕ್ರಿಯೆಗೊಳಿಸುತ್ತೇವೆ.
        // ಸುರಕ್ಷತೆ: `align_to` ನಿಂದ ನಿರ್ವಹಿಸಲ್ಪಡುವ ಗಾತ್ರದ ವ್ಯತ್ಯಾಸಗಳನ್ನು ಹೊರತುಪಡಿಸಿ `[u8]` ಅನ್ನು `[usize]` ಗೆ ಪರಿವರ್ತಿಸುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // ಪಠ್ಯದ ದೇಹವನ್ನು ಹುಡುಕಿ, ನಾವು min_aligned_offset ಅನ್ನು ದಾಟಿಲ್ಲ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ.
    // ಆಫ್‌ಸೆಟ್ ಅನ್ನು ಯಾವಾಗಲೂ ಜೋಡಿಸಲಾಗುತ್ತದೆ, ಆದ್ದರಿಂದ `>` ಅನ್ನು ಪರೀಕ್ಷಿಸುವುದು ಸಾಕು ಮತ್ತು ಸಂಭವನೀಯ ಉಕ್ಕಿ ಹರಿಯುವುದನ್ನು ತಪ್ಪಿಸುತ್ತದೆ.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // ಸುರಕ್ಷತೆ: ಆಫ್‌ಸೆಟ್ ಲೆನ್, ಎಕ್ಸ್‌00 ಎಕ್ಸ್‌ನಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ, ಅದು ದೊಡ್ಡದಾಗಿದೆ
        // min_aligned_offset (prefix.len()) ಉಳಿದ ಅಂತರವು ಕನಿಷ್ಠ 2 * ಚಂಕ್_ಬೈಟ್‌ಗಳು.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // ಹೊಂದಾಣಿಕೆಯ ಬೈಟ್ ಇದ್ದರೆ ಮುರಿಯಿರಿ.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // ಬಾಡಿ ಲೂಪ್ ನಿಲ್ಲಿಸುವ ಮೊದಲು ಬೈಟ್ ಅನ್ನು ಹುಡುಕಿ.
    text[..offset].iter().rposition(|elt| *elt == x)
}