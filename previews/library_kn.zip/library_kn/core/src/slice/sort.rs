//! ಸ್ಲೈಸ್ ವಿಂಗಡಣೆ
//!
//! ಈ ಮಾಡ್ಯೂಲ್ ಆರ್ಸನ್ ಪೀಟರ್ಸ್ ಮಾದರಿಯನ್ನು ಸೋಲಿಸುವ ಕ್ವಿಕ್‌ಸೋರ್ಟ್‌ನ ಆಧಾರದ ಮೇಲೆ ವಿಂಗಡಿಸುವ ಅಲ್ಗಾರಿದಮ್ ಅನ್ನು ಒಳಗೊಂಡಿದೆ, ಇದನ್ನು ಇಲ್ಲಿ ಪ್ರಕಟಿಸಲಾಗಿದೆ: <https://github.com/orlp/pdqsort>
//!
//!
//! ಅಸ್ಥಿರ ವಿಂಗಡಣೆಯು ಲಿಬ್‌ಕೋರ್‌ಗೆ ಹೊಂದಿಕೊಳ್ಳುತ್ತದೆ ಏಕೆಂದರೆ ಅದು ನಮ್ಮ ಸ್ಥಿರ ವಿಂಗಡಣೆಯ ಅನುಷ್ಠಾನಕ್ಕಿಂತ ಭಿನ್ನವಾಗಿ ಮೆಮೊರಿಯನ್ನು ನಿಯೋಜಿಸುವುದಿಲ್ಲ.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// ಕೈಬಿಟ್ಟಾಗ, `src` ನಿಂದ `dest` ಗೆ ಪ್ರತಿಗಳು.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // ಸುರಕ್ಷತೆ: ಇದು ಸಹಾಯಕ ವರ್ಗ.
        //          ಸರಿಯಾದತೆಗಾಗಿ ದಯವಿಟ್ಟು ಅದರ ಬಳಕೆಯನ್ನು ನೋಡಿ.
        //          ಅವುಗಳೆಂದರೆ, `ptr::copy_nonoverlapping` ಗೆ ಅಗತ್ಯವಿರುವಂತೆ `src` ಮತ್ತು `dst` ಅತಿಕ್ರಮಿಸುವುದಿಲ್ಲ ಎಂದು ಖಚಿತವಾಗಿರಬೇಕು.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// ಹೆಚ್ಚಿನ ಅಥವಾ ಸಮಾನ ಅಂಶವನ್ನು ಎದುರಿಸುವವರೆಗೆ ಮೊದಲ ಅಂಶವನ್ನು ಬಲಕ್ಕೆ ಬದಲಾಯಿಸುತ್ತದೆ.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // ಸುರಕ್ಷತೆ: ಕೆಳಗಿನ ಅಸುರಕ್ಷಿತ ಕಾರ್ಯಾಚರಣೆಗಳು ಬೌಂಡ್ ಚೆಕ್ ಇಲ್ಲದೆ ಸೂಚ್ಯಂಕವನ್ನು ಒಳಗೊಂಡಿರುತ್ತದೆ (`get_unchecked` ಮತ್ತು `get_unchecked_mut`)
    // ಮತ್ತು ಮೆಮೊರಿ (`ptr::copy_nonoverlapping`) ಅನ್ನು ನಕಲಿಸುವುದು.
    //
    // ಎ.ಸೂಚ್ಯಂಕ:
    //  1. ನಾವು ರಚನೆಯ ಗಾತ್ರವನ್ನು>=2 ಗೆ ಪರಿಶೀಲಿಸಿದ್ದೇವೆ.
    //  2. ನಾವು ಮಾಡುವ ಎಲ್ಲಾ ಸೂಚ್ಯಂಕವು ಯಾವಾಗಲೂ {0 <= index < len} ನಡುವೆ ಇರುತ್ತದೆ.
    //
    // ಬೌ.ಮೆಮೊರಿ ನಕಲು
    //  1. ನಾವು ಮಾನ್ಯ ಎಂದು ಖಾತರಿಪಡಿಸುವ ಉಲ್ಲೇಖಗಳಿಗೆ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಪಡೆಯುತ್ತಿದ್ದೇವೆ.
    //  2. ಅವುಗಳು ಅತಿಕ್ರಮಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ ಏಕೆಂದರೆ ನಾವು ಸ್ಲೈಸ್‌ನ ವ್ಯತ್ಯಾಸ ಸೂಚ್ಯಂಕಗಳಿಗೆ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಪಡೆಯುತ್ತೇವೆ.
    //     ಅವುಗಳೆಂದರೆ, `i` ಮತ್ತು `i-1`.
    //  3. ಸ್ಲೈಸ್ ಸರಿಯಾಗಿ ಜೋಡಿಸಿದ್ದರೆ, ಅಂಶಗಳನ್ನು ಸರಿಯಾಗಿ ಜೋಡಿಸಲಾಗುತ್ತದೆ.
    //     ಸ್ಲೈಸ್ ಸರಿಯಾಗಿ ಜೋಡಿಸಲ್ಪಟ್ಟಿದೆಯೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳುವುದು ಕರೆ ಮಾಡುವವರ ಜವಾಬ್ದಾರಿಯಾಗಿದೆ.
    //
    // ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ ಕೆಳಗಿನ ಕಾಮೆಂಟ್‌ಗಳನ್ನು ನೋಡಿ.
    unsafe {
        // ಮೊದಲ ಎರಡು ಅಂಶಗಳು ಕ್ರಮಬದ್ಧವಾಗಿಲ್ಲದಿದ್ದರೆ ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // ಮೊದಲ ಅಂಶವನ್ನು ಸ್ಟಾಕ್-ನಿಯೋಜಿತ ವೇರಿಯೇಬಲ್ ಆಗಿ ಓದಿ.
            // ಕೆಳಗಿನ ಹೋಲಿಕೆ ಕಾರ್ಯಾಚರಣೆ panics ಆಗಿದ್ದರೆ, `hole` ಕೈಬಿಡುತ್ತದೆ ಮತ್ತು ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಅಂಶವನ್ನು ಸ್ಲೈಸ್‌ಗೆ ಬರೆಯುತ್ತದೆ.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // `I`-th ಅಂಶವನ್ನು ಒಂದು ಸ್ಥಳಕ್ಕೆ ಎಡಕ್ಕೆ ಸರಿಸಿ, ಹೀಗೆ ರಂಧ್ರವನ್ನು ಬಲಕ್ಕೆ ವರ್ಗಾಯಿಸಿ.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` ಕೈಬಿಡಲಾಗುತ್ತದೆ ಮತ್ತು ಹೀಗಾಗಿ `tmp` ಅನ್ನು `v` ನಲ್ಲಿ ಉಳಿದ ರಂಧ್ರಕ್ಕೆ ನಕಲಿಸುತ್ತದೆ.
        }
    }
}

/// ಸಣ್ಣ ಅಥವಾ ಸಮಾನ ಅಂಶವನ್ನು ಎದುರಿಸುವವರೆಗೆ ಕೊನೆಯ ಅಂಶವನ್ನು ಎಡಕ್ಕೆ ಬದಲಾಯಿಸುತ್ತದೆ.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // ಸುರಕ್ಷತೆ: ಕೆಳಗಿನ ಅಸುರಕ್ಷಿತ ಕಾರ್ಯಾಚರಣೆಗಳು ಬೌಂಡ್ ಚೆಕ್ ಇಲ್ಲದೆ ಸೂಚ್ಯಂಕವನ್ನು ಒಳಗೊಂಡಿರುತ್ತದೆ (`get_unchecked` ಮತ್ತು `get_unchecked_mut`)
    // ಮತ್ತು ಮೆಮೊರಿ (`ptr::copy_nonoverlapping`) ಅನ್ನು ನಕಲಿಸುವುದು.
    //
    // ಎ.ಸೂಚ್ಯಂಕ:
    //  1. ನಾವು ರಚನೆಯ ಗಾತ್ರವನ್ನು>=2 ಗೆ ಪರಿಶೀಲಿಸಿದ್ದೇವೆ.
    //  2. ನಾವು ಮಾಡುವ ಎಲ್ಲಾ ಸೂಚ್ಯಂಕವು ಯಾವಾಗಲೂ `0 <= index < len-1` ನಡುವೆ ಇರುತ್ತದೆ.
    //
    // ಬೌ.ಮೆಮೊರಿ ನಕಲು
    //  1. ನಾವು ಮಾನ್ಯ ಎಂದು ಖಾತರಿಪಡಿಸುವ ಉಲ್ಲೇಖಗಳಿಗೆ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಪಡೆಯುತ್ತಿದ್ದೇವೆ.
    //  2. ಅವುಗಳು ಅತಿಕ್ರಮಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ ಏಕೆಂದರೆ ನಾವು ಸ್ಲೈಸ್‌ನ ವ್ಯತ್ಯಾಸ ಸೂಚ್ಯಂಕಗಳಿಗೆ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಪಡೆಯುತ್ತೇವೆ.
    //     ಅವುಗಳೆಂದರೆ, `i` ಮತ್ತು `i+1`.
    //  3. ಸ್ಲೈಸ್ ಸರಿಯಾಗಿ ಜೋಡಿಸಿದ್ದರೆ, ಅಂಶಗಳನ್ನು ಸರಿಯಾಗಿ ಜೋಡಿಸಲಾಗುತ್ತದೆ.
    //     ಸ್ಲೈಸ್ ಸರಿಯಾಗಿ ಜೋಡಿಸಲ್ಪಟ್ಟಿದೆಯೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳುವುದು ಕರೆ ಮಾಡುವವರ ಜವಾಬ್ದಾರಿಯಾಗಿದೆ.
    //
    // ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ ಕೆಳಗಿನ ಕಾಮೆಂಟ್‌ಗಳನ್ನು ನೋಡಿ.
    unsafe {
        // ಕೊನೆಯ ಎರಡು ಅಂಶಗಳು ಕ್ರಮಬದ್ಧವಾಗಿಲ್ಲದಿದ್ದರೆ ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // ಕೊನೆಯ ಅಂಶವನ್ನು ಸ್ಟಾಕ್-ನಿಯೋಜಿತ ವೇರಿಯೇಬಲ್ ಆಗಿ ಓದಿ.
            // ಕೆಳಗಿನ ಹೋಲಿಕೆ ಕಾರ್ಯಾಚರಣೆ panics ಆಗಿದ್ದರೆ, `hole` ಕೈಬಿಡುತ್ತದೆ ಮತ್ತು ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಅಂಶವನ್ನು ಸ್ಲೈಸ್‌ಗೆ ಬರೆಯುತ್ತದೆ.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // `I`-th ಅಂಶವನ್ನು ಒಂದು ಸ್ಥಳವನ್ನು ಬಲಕ್ಕೆ ಸರಿಸಿ, ಹೀಗೆ ರಂಧ್ರವನ್ನು ಎಡಕ್ಕೆ ವರ್ಗಾಯಿಸಿ.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` ಕೈಬಿಡಲಾಗುತ್ತದೆ ಮತ್ತು ಹೀಗಾಗಿ `tmp` ಅನ್ನು `v` ನಲ್ಲಿ ಉಳಿದ ರಂಧ್ರಕ್ಕೆ ನಕಲಿಸುತ್ತದೆ.
        }
    }
}

/// ಹಲವಾರು ಹೊರಗಿನ ಅಂಶಗಳನ್ನು ಬದಲಾಯಿಸುವ ಮೂಲಕ ಭಾಗಶಃ ಸ್ಲೈಸ್ ಅನ್ನು ವಿಂಗಡಿಸುತ್ತದೆ.
///
/// ಸ್ಲೈಸ್ ಕೊನೆಯಲ್ಲಿ ವಿಂಗಡಿಸಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.ಈ ಕಾರ್ಯವು *O*(*n*) ಕೆಟ್ಟ ಪ್ರಕರಣವಾಗಿದೆ.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // ಸ್ಥಳಾಂತರಗೊಳ್ಳುವ ಪಕ್ಕದ ಹೊರಗಿನ ಜೋಡಿಗಳ ಗರಿಷ್ಠ ಸಂಖ್ಯೆ.
    const MAX_STEPS: usize = 5;
    // ಸ್ಲೈಸ್ ಇದಕ್ಕಿಂತ ಚಿಕ್ಕದಾಗಿದ್ದರೆ, ಯಾವುದೇ ಅಂಶಗಳನ್ನು ಬದಲಾಯಿಸಬೇಡಿ.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // ಸುರಕ್ಷತೆ: ನಾವು ಈಗಾಗಲೇ `i < len` ನೊಂದಿಗೆ ಬೌಂಡ್ ಚೆಕಿಂಗ್ ಅನ್ನು ಸ್ಪಷ್ಟವಾಗಿ ಮಾಡಿದ್ದೇವೆ.
        // ನಮ್ಮ ಎಲ್ಲಾ ನಂತರದ ಸೂಚಿಕೆ `0 <= index < len` ವ್ಯಾಪ್ತಿಯಲ್ಲಿ ಮಾತ್ರ
        unsafe {
            // ಮುಂದಿನ ಜೋಡಿ ಪಕ್ಕದ ಆದೇಶದ ಅಂಶಗಳನ್ನು ಹುಡುಕಿ.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // ನಾವು ಮುಗಿಸಿದ್ದೇವೆಯೇ?
        if i == len {
            return true;
        }

        // ಕಾರ್ಯಕ್ಷಮತೆಯ ವೆಚ್ಚವನ್ನು ಹೊಂದಿರುವ ಅಂಶಗಳನ್ನು ಸಣ್ಣ ಸರಣಿಗಳಲ್ಲಿ ಬದಲಾಯಿಸಬೇಡಿ.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // ಕಂಡುಬರುವ ಜೋಡಿ ಅಂಶಗಳನ್ನು ವಿನಿಮಯ ಮಾಡಿಕೊಳ್ಳಿ.ಇದು ಅವುಗಳನ್ನು ಸರಿಯಾದ ಕ್ರಮದಲ್ಲಿರಿಸುತ್ತದೆ.
        v.swap(i - 1, i);

        // ಸಣ್ಣ ಅಂಶವನ್ನು ಎಡಕ್ಕೆ ಬದಲಾಯಿಸಿ.
        shift_tail(&mut v[..i], is_less);
        // ಹೆಚ್ಚಿನ ಅಂಶವನ್ನು ಬಲಕ್ಕೆ ಬದಲಾಯಿಸಿ.
        shift_head(&mut v[i..], is_less);
    }

    // ಸೀಮಿತ ಸಂಖ್ಯೆಯ ಹಂತಗಳಲ್ಲಿ ಸ್ಲೈಸ್ ಅನ್ನು ವಿಂಗಡಿಸಲು ನಿರ್ವಹಿಸಲಿಲ್ಲ.
    false
}

/// ಅಳವಡಿಕೆ ವಿಂಗಡಣೆಯನ್ನು ಬಳಸಿಕೊಂಡು ಸ್ಲೈಸ್ ಅನ್ನು ವಿಂಗಡಿಸುತ್ತದೆ, ಅದು *O*(*n*^ 2) ಕೆಟ್ಟ ಪ್ರಕರಣವಾಗಿದೆ.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// ಹೀಪ್ಸೋರ್ಟ್ ಬಳಸಿ `v` ಅನ್ನು ವಿಂಗಡಿಸುತ್ತದೆ, ಇದು *O*(*n*\*log(* n*)) ಕೆಟ್ಟ ಪ್ರಕರಣವನ್ನು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // ಈ ಬೈನರಿ ರಾಶಿ ಅಸ್ಥಿರ `parent >= child` ಅನ್ನು ಗೌರವಿಸುತ್ತದೆ.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node` ಮಕ್ಕಳು:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // ಹೆಚ್ಚಿನ ಮಗುವನ್ನು ಆರಿಸಿ.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // ಅಸ್ಥಿರತೆಯು `node` ನಲ್ಲಿ ಹಿಡಿದಿದ್ದರೆ ನಿಲ್ಲಿಸಿ.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // ಹೆಚ್ಚಿನ ಮಗುವಿನೊಂದಿಗೆ `node` ಅನ್ನು ಸ್ವ್ಯಾಪ್ ಮಾಡಿ, ಒಂದು ಹೆಜ್ಜೆ ಕೆಳಗೆ ಸರಿಸಿ, ಮತ್ತು ಜರಡಿ ಹಿಡಿಯುವುದನ್ನು ಮುಂದುವರಿಸಿ.
            v.swap(node, greater);
            node = greater;
        }
    };

    // ರೇಖೀಯ ಸಮಯದಲ್ಲಿ ರಾಶಿಯನ್ನು ನಿರ್ಮಿಸಿ.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // ರಾಶಿಯಿಂದ ಗರಿಷ್ಠ ಅಂಶಗಳನ್ನು ಪಾಪ್ ಮಾಡಿ.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// `v` ಅನ್ನು `pivot` ಗಿಂತ ಚಿಕ್ಕದಾದ ಅಂಶಗಳಾಗಿ ವಿಭಜಿಸುತ್ತದೆ, ನಂತರ `pivot` ಗಿಂತ ಹೆಚ್ಚಿನ ಅಥವಾ ಸಮನಾದ ಅಂಶಗಳು.
///
///
/// `pivot` ಗಿಂತ ಚಿಕ್ಕದಾದ ಅಂಶಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
///
/// ಕವಲೊಡೆಯುವ ಕಾರ್ಯಾಚರಣೆಯ ವೆಚ್ಚವನ್ನು ಕಡಿಮೆ ಮಾಡಲು ವಿಭಜನೆಯನ್ನು ಬ್ಲಾಕ್-ಬೈ-ಬ್ಲಾಕ್ ಮೂಲಕ ನಡೆಸಲಾಗುತ್ತದೆ.
/// ಈ ಕಲ್ಪನೆಯನ್ನು [BlockQuicksort][pdf] ಕಾಗದದಲ್ಲಿ ಪ್ರಸ್ತುತಪಡಿಸಲಾಗಿದೆ.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // ವಿಶಿಷ್ಟ ಬ್ಲಾಕ್ನಲ್ಲಿನ ಅಂಶಗಳ ಸಂಖ್ಯೆ.
    const BLOCK: usize = 128;

    // ವಿಭಜನಾ ಅಲ್ಗಾರಿದಮ್ ಪೂರ್ಣಗೊಳ್ಳುವವರೆಗೆ ಈ ಕೆಳಗಿನ ಹಂತಗಳನ್ನು ಪುನರಾವರ್ತಿಸುತ್ತದೆ:
    //
    // 1. ಪಿವೋಟ್‌ಗಿಂತ ದೊಡ್ಡದಾದ ಅಥವಾ ಸಮನಾದ ಅಂಶಗಳನ್ನು ಗುರುತಿಸಲು ಎಡಭಾಗದಿಂದ ಒಂದು ಬ್ಲಾಕ್ ಅನ್ನು ಪತ್ತೆಹಚ್ಚಿ.
    // 2. ಪಿವೋಟ್‌ಗಿಂತ ಚಿಕ್ಕದಾದ ಅಂಶಗಳನ್ನು ಗುರುತಿಸಲು ಬಲಭಾಗದಿಂದ ಒಂದು ಬ್ಲಾಕ್ ಅನ್ನು ಪತ್ತೆ ಮಾಡಿ.
    // 3. ಗುರುತಿಸಲಾದ ಅಂಶಗಳನ್ನು ಎಡ ಮತ್ತು ಬಲ ಭಾಗದ ನಡುವೆ ವಿನಿಮಯ ಮಾಡಿಕೊಳ್ಳಿ.
    //
    // ಅಂಶಗಳ ಬ್ಲಾಕ್ಗಾಗಿ ನಾವು ಈ ಕೆಳಗಿನ ಅಸ್ಥಿರಗಳನ್ನು ಇರಿಸುತ್ತೇವೆ:
    //
    // 1. `block` - ಬ್ಲಾಕ್ನಲ್ಲಿನ ಅಂಶಗಳ ಸಂಖ್ಯೆ.
    // 2. `start` - `offsets` ರಚನೆಗೆ ಪಾಯಿಂಟರ್ ಪ್ರಾರಂಭಿಸಿ.
    // 3. `end` - `offsets` ರಚನೆಗೆ ಪಾಯಿಂಟರ್ ಅನ್ನು ಕೊನೆಗೊಳಿಸಿ.
    // 4. `ಆಫ್‌ಸೆಟ್‌ಗಳು, ಬ್ಲಾಕ್‌ನೊಳಗಿನ ಆದೇಶದ ಅಂಶಗಳ ಸೂಚ್ಯಂಕಗಳು.

    // ಎಡಭಾಗದಲ್ಲಿರುವ ಪ್ರಸ್ತುತ ಬ್ಲಾಕ್ (`l` ನಿಂದ `l.add(block_l)`) ವರೆಗೆ.
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // ಬಲಭಾಗದಲ್ಲಿರುವ ಪ್ರಸ್ತುತ ಬ್ಲಾಕ್ (`r.sub(block_r)` to `r`) ನಿಂದ.
    // ಸುರಕ್ಷತೆ: .add() ಗಾಗಿ ದಸ್ತಾವೇಜನ್ನು ನಿರ್ದಿಷ್ಟವಾಗಿ `vec.as_ptr().add(vec.len())` ಯಾವಾಗಲೂ ಸುರಕ್ಷಿತವಾಗಿದೆ ಎಂದು ಉಲ್ಲೇಖಿಸುತ್ತದೆ`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: ನಾವು ವಿಎಲ್‌ಎಗಳನ್ನು ಪಡೆದಾಗ, `min(v.len(), 2 * BLOCK ಉದ್ದದ ಒಂದು ಶ್ರೇಣಿಯನ್ನು ರಚಿಸಲು ಪ್ರಯತ್ನಿಸಿ
    // `BLOCK` ಉದ್ದದ ಎರಡು ಸ್ಥಿರ-ಗಾತ್ರದ ಸರಣಿಗಳಿಗಿಂತ.ವಿಎಲ್‌ಎಗಳು ಹೆಚ್ಚು ಸಂಗ್ರಹ-ಸಮರ್ಥವಾಗಿರಬಹುದು.

    // ಪಾಯಿಂಟರ್ಸ್ `l` (inclusive) ಮತ್ತು `r` (exclusive) ನಡುವಿನ ಅಂಶಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // `l` ಮತ್ತು `r` ಬಹಳ ಹತ್ತಿರವಾದಾಗ ನಾವು ಬ್ಲಾಕ್-ಬೈ-ಬ್ಲಾಕ್ ಅನ್ನು ವಿಭಜಿಸುತ್ತೇವೆ.
        // ನಂತರ ಉಳಿದ ಅಂಶಗಳನ್ನು ವಿಭಜಿಸುವ ಸಲುವಾಗಿ ನಾವು ಕೆಲವು ಪ್ಯಾಚ್-ಅಪ್ ಕೆಲಸವನ್ನು ಮಾಡುತ್ತೇವೆ.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // ಉಳಿದ ಅಂಶಗಳ ಸಂಖ್ಯೆ (ಇನ್ನೂ ಪಿವೋಟ್‌ಗೆ ಹೋಲಿಸಲಾಗಿಲ್ಲ).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // ಬ್ಲಾಕ್ ಗಾತ್ರಗಳನ್ನು ಹೊಂದಿಸಿ ಇದರಿಂದ ಎಡ ಮತ್ತು ಬಲ ಬ್ಲಾಕ್ ಅತಿಕ್ರಮಿಸುವುದಿಲ್ಲ, ಆದರೆ ಉಳಿದಿರುವ ಅಂತರವನ್ನು ಸರಿದೂಗಿಸಲು ಸಂಪೂರ್ಣವಾಗಿ ಜೋಡಿಸಿ.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // ಎಡಭಾಗದಿಂದ `block_l` ಅಂಶಗಳನ್ನು ಪತ್ತೆಹಚ್ಚಿ.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // ಸುರಕ್ಷತೆ: ಕೆಳಗಿನ ಅಸುರಕ್ಷಿತ ಕಾರ್ಯಾಚರಣೆಗಳು `offset` ಬಳಕೆಯನ್ನು ಒಳಗೊಂಡಿರುತ್ತವೆ.
                //         ಕಾರ್ಯಕ್ಕೆ ಅಗತ್ಯವಾದ ಷರತ್ತುಗಳ ಪ್ರಕಾರ, ನಾವು ಅವುಗಳನ್ನು ಪೂರೈಸುತ್ತೇವೆ ಏಕೆಂದರೆ:
                //         1. `offsets_l` ಸ್ಟಾಕ್-ಹಂಚಿಕೆ, ಮತ್ತು ಆದ್ದರಿಂದ ಪ್ರತ್ಯೇಕ ಹಂಚಿಕೆಯ ವಸ್ತುವಾಗಿ ಪರಿಗಣಿಸಲಾಗುತ್ತದೆ.
                //         2. `is_less` ಕಾರ್ಯವು `bool` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
                //            `bool` ಅನ್ನು ಬಿತ್ತರಿಸುವುದರಿಂದ `isize` ಅನ್ನು ಎಂದಿಗೂ ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ.
                //         3. `block_l` `<= BLOCK` ಆಗಿರುತ್ತದೆ ಎಂದು ನಾವು ಖಾತರಿಪಡಿಸಿದ್ದೇವೆ.
                //            ಜೊತೆಗೆ, `end_l` ಅನ್ನು ಆರಂಭದಲ್ಲಿ `offsets_` ನ ಪ್ರಾರಂಭದ ಪಾಯಿಂಟರ್‌ಗೆ ಹೊಂದಿಸಲಾಗಿದೆ, ಅದನ್ನು ಸ್ಟಾಕ್‌ನಲ್ಲಿ ಘೋಷಿಸಲಾಯಿತು.
                //            ಹೀಗಾಗಿ, ಕೆಟ್ಟ ಪರಿಸ್ಥಿತಿಯಲ್ಲಿಯೂ ಸಹ (`is_less` ನ ಎಲ್ಲಾ ಆಹ್ವಾನಗಳು ಸುಳ್ಳನ್ನು ನೀಡುತ್ತವೆ) ನಾವು ಗರಿಷ್ಠ 1 ಬೈಟ್ ಮಾತ್ರ ಅಂತ್ಯವನ್ನು ಹಾದುಹೋಗುತ್ತೇವೆ ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ.
                //        ಇಲ್ಲಿ ಮತ್ತೊಂದು ಅಸುರಕ್ಷಿತ ಕಾರ್ಯಾಚರಣೆ `elem` ಅನ್ನು ಡಿಫರೆನ್ಸಿಂಗ್ ಮಾಡುವುದು.
                //        ಆದಾಗ್ಯೂ, `elem` ಆರಂಭದಲ್ಲಿ ಸ್ಲೈಸ್‌ಗೆ ಪ್ರಾರಂಭದ ಪಾಯಿಂಟರ್ ಆಗಿದ್ದು ಅದು ಯಾವಾಗಲೂ ಮಾನ್ಯವಾಗಿರುತ್ತದೆ.
                unsafe {
                    // ಶಾಖೆಯಿಲ್ಲದ ಹೋಲಿಕೆ.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // `block_r` ಅಂಶಗಳನ್ನು ಬಲಭಾಗದಿಂದ ಪತ್ತೆಹಚ್ಚಿ.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // ಸುರಕ್ಷತೆ: ಕೆಳಗಿನ ಅಸುರಕ್ಷಿತ ಕಾರ್ಯಾಚರಣೆಗಳು `offset` ಬಳಕೆಯನ್ನು ಒಳಗೊಂಡಿರುತ್ತವೆ.
                //         ಕಾರ್ಯಕ್ಕೆ ಅಗತ್ಯವಾದ ಷರತ್ತುಗಳ ಪ್ರಕಾರ, ನಾವು ಅವುಗಳನ್ನು ಪೂರೈಸುತ್ತೇವೆ ಏಕೆಂದರೆ:
                //         1. `offsets_r` ಸ್ಟಾಕ್-ಹಂಚಿಕೆ, ಮತ್ತು ಆದ್ದರಿಂದ ಪ್ರತ್ಯೇಕ ಹಂಚಿಕೆಯ ವಸ್ತುವಾಗಿ ಪರಿಗಣಿಸಲಾಗುತ್ತದೆ.
                //         2. `is_less` ಕಾರ್ಯವು `bool` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
                //            `bool` ಅನ್ನು ಬಿತ್ತರಿಸುವುದರಿಂದ `isize` ಅನ್ನು ಎಂದಿಗೂ ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ.
                //         3. `block_r` `<= BLOCK` ಆಗಿರುತ್ತದೆ ಎಂದು ನಾವು ಖಾತರಿಪಡಿಸಿದ್ದೇವೆ.
                //            ಜೊತೆಗೆ, `end_r` ಅನ್ನು ಆರಂಭದಲ್ಲಿ `offsets_` ನ ಪ್ರಾರಂಭದ ಪಾಯಿಂಟರ್‌ಗೆ ಹೊಂದಿಸಲಾಗಿದೆ, ಅದನ್ನು ಸ್ಟಾಕ್‌ನಲ್ಲಿ ಘೋಷಿಸಲಾಯಿತು.
                //            ಹೀಗಾಗಿ, ಕೆಟ್ಟ ಸಂದರ್ಭದಲ್ಲಿ (`is_less` ನ ಎಲ್ಲಾ ಆಹ್ವಾನಗಳು ನಿಜವಾಗುತ್ತವೆ) ನಮಗೆ ತಿಳಿದಿದೆ ನಾವು ಕೇವಲ 1 ಬೈಟ್ ಮಾತ್ರ ಅಂತ್ಯವನ್ನು ಹಾದುಹೋಗುತ್ತೇವೆ.
                //        ಇಲ್ಲಿ ಮತ್ತೊಂದು ಅಸುರಕ್ಷಿತ ಕಾರ್ಯಾಚರಣೆ `elem` ಅನ್ನು ಡಿಫರೆನ್ಸಿಂಗ್ ಮಾಡುವುದು.
                //        ಆದಾಗ್ಯೂ, `elem` ಆರಂಭದಲ್ಲಿ `1 *sizeof(T)` ಅಂತ್ಯದಲ್ಲಿತ್ತು ಮತ್ತು ಅದನ್ನು ಪ್ರವೇಶಿಸುವ ಮೊದಲು ನಾವು ಅದನ್ನು `1* sizeof(T)` ನಿಂದ ಕಡಿಮೆ ಮಾಡುತ್ತೇವೆ.
                //        ಜೊತೆಗೆ, `block_r` ಅನ್ನು `BLOCK` ಗಿಂತ ಕಡಿಮೆಯಿದೆ ಎಂದು ಪ್ರತಿಪಾದಿಸಲಾಯಿತು ಮತ್ತು `elem` ಆದ್ದರಿಂದ ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭವನ್ನು ಸೂಚಿಸುತ್ತದೆ.
                unsafe {
                    // ಶಾಖೆಯಿಲ್ಲದ ಹೋಲಿಕೆ.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // ಎಡ ಮತ್ತು ಬಲ ಭಾಗದ ನಡುವೆ ವಿನಿಮಯ ಮಾಡಿಕೊಳ್ಳಲು ಆದೇಶವಿಲ್ಲದ ಅಂಶಗಳ ಸಂಖ್ಯೆ.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // ಆ ಸಮಯದಲ್ಲಿ ಒಂದು ಜೋಡಿಯನ್ನು ವಿನಿಮಯ ಮಾಡಿಕೊಳ್ಳುವ ಬದಲು, ಆವರ್ತಕ ಕ್ರಮಪಲ್ಲಟನೆಯನ್ನು ಮಾಡುವುದು ಹೆಚ್ಚು ಪರಿಣಾಮಕಾರಿಯಾಗಿದೆ.
            // ಇದು ವಿನಿಮಯಕ್ಕೆ ಕಟ್ಟುನಿಟ್ಟಾಗಿ ಸಮನಾಗಿಲ್ಲ, ಆದರೆ ಕಡಿಮೆ ಮೆಮೊರಿ ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬಳಸಿಕೊಂಡು ಇದೇ ರೀತಿಯ ಫಲಿತಾಂಶವನ್ನು ನೀಡುತ್ತದೆ.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // ಎಡ ಬ್ಲಾಕ್ನಲ್ಲಿನ ಎಲ್ಲಾ-ಟ್-ಆಫ್-ಆರ್ಡರ್ ಅಂಶಗಳನ್ನು ಸರಿಸಲಾಗಿದೆ.ಮುಂದಿನ ಬ್ಲಾಕ್‌ಗೆ ಸರಿಸಿ.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // ಬಲ ಬ್ಲಾಕ್ನಲ್ಲಿನ ಎಲ್ಲಾ ಆದೇಶದ ಅಂಶಗಳನ್ನು ಸರಿಸಲಾಗಿದೆ.ಹಿಂದಿನ ಬ್ಲಾಕ್ಗೆ ಸರಿಸಿ.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // ಈಗ ಉಳಿದಿರುವುದು ಸುವ್ಯವಸ್ಥೆಯ ಹೊರಗಿನ ಅಂಶಗಳೊಂದಿಗೆ ಒಂದು ಬ್ಲಾಕ್‌ನಲ್ಲಿ (ಎಡ ಅಥವಾ ಬಲಕ್ಕೆ).
    // ಅಂತಹ ಉಳಿದ ಅಂಶಗಳನ್ನು ಅವುಗಳ ಬ್ಲಾಕ್‌ನೊಳಗೆ ಸರಳವಾಗಿ ಅಂತ್ಯಕ್ಕೆ ವರ್ಗಾಯಿಸಬಹುದು.
    //

    if start_l < end_l {
        // ಎಡ ಬ್ಲಾಕ್ ಉಳಿದಿದೆ.
        // ಅದರ ಉಳಿದ ಆದೇಶದ ಅಂಶಗಳನ್ನು ಬಲಗಡೆಗೆ ಸರಿಸಿ.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // ಸರಿಯಾದ ಬ್ಲಾಕ್ ಉಳಿದಿದೆ.
        // ಅದರ ಉಳಿದ ಆದೇಶದ ಅಂಶಗಳನ್ನು ದೂರದ ಎಡಕ್ಕೆ ಸರಿಸಿ.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // ಬೇರೆ ಏನೂ ಮಾಡಬೇಕಾಗಿಲ್ಲ, ನಾವು ಮುಗಿಸಿದ್ದೇವೆ.
        width(v.as_mut_ptr(), l)
    }
}

/// `v` ಅನ್ನು `v[pivot]` ಗಿಂತ ಚಿಕ್ಕದಾದ ಅಂಶಗಳಾಗಿ ವಿಭಜಿಸುತ್ತದೆ, ನಂತರ `v[pivot]` ಗಿಂತ ಹೆಚ್ಚಿನ ಅಥವಾ ಸಮನಾದ ಅಂಶಗಳು.
///
///
/// ಇದರ ಟ್ಯುಪಲ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ:
///
/// 1. `v[pivot]` ಗಿಂತ ಚಿಕ್ಕದಾದ ಅಂಶಗಳ ಸಂಖ್ಯೆ.
/// 2. `v` ಅನ್ನು ಈಗಾಗಲೇ ವಿಭಜಿಸಲಾಗಿದ್ದರೆ ನಿಜ.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // ಸ್ಲೈಸ್‌ನ ಆರಂಭದಲ್ಲಿ ಪಿವೋಟ್ ಇರಿಸಿ.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // ದಕ್ಷತೆಗಾಗಿ ಪಿವೋಟ್ ಅನ್ನು ಸ್ಟಾಕ್-ನಿಯೋಜಿತ ವೇರಿಯೇಬಲ್ ಆಗಿ ಓದಿ.
        // ಕೆಳಗಿನ ಹೋಲಿಕೆ ಕಾರ್ಯಾಚರಣೆ panics ಆಗಿದ್ದರೆ, ಪಿವೋಟ್ ಅನ್ನು ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಸ್ಲೈಸ್‌ಗೆ ಬರೆಯಲಾಗುತ್ತದೆ.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // ಮೊದಲ ಜೋಡಿ ಆದೇಶದ ಅಂಶಗಳನ್ನು ಹುಡುಕಿ.
        let mut l = 0;
        let mut r = v.len();

        // ಸುರಕ್ಷತೆ: ಕೆಳಗಿನ ಅಸುರಕ್ಷಿತತೆಯು ಶ್ರೇಣಿಯನ್ನು ಸೂಚಿಕೆ ಮಾಡುವುದನ್ನು ಒಳಗೊಂಡಿರುತ್ತದೆ.
        // ಮೊದಲನೆಯದಕ್ಕಾಗಿ: ನಾವು ಈಗಾಗಲೇ ಇಲ್ಲಿ `l < r` ನೊಂದಿಗೆ ಪರಿಶೀಲಿಸುವ ಪರಿಮಿತಿಯನ್ನು ಮಾಡುತ್ತೇವೆ.
        // ಎರಡನೆಯದಕ್ಕೆ: ನಾವು ಆರಂಭದಲ್ಲಿ `l == 0` ಮತ್ತು `r == v.len()` ಅನ್ನು ಹೊಂದಿದ್ದೇವೆ ಮತ್ತು ಪ್ರತಿ ಇಂಡೆಕ್ಸಿಂಗ್ ಕಾರ್ಯಾಚರಣೆಯಲ್ಲಿ ನಾವು `l < r` ಅನ್ನು ಪರಿಶೀಲಿಸಿದ್ದೇವೆ.
        //                     ಇಲ್ಲಿಂದ ನಮಗೆ ತಿಳಿದಿದೆ `r` ಕನಿಷ್ಠ `r == l` ಆಗಿರಬೇಕು ಅದು ಮೊದಲನೆಯದರಿಂದ ಮಾನ್ಯವಾಗಿದೆ ಎಂದು ತೋರಿಸಲಾಗಿದೆ.
        unsafe {
            // ಪಿವೋಟ್‌ಗಿಂತ ದೊಡ್ಡದಾದ ಅಥವಾ ಸಮನಾದ ಮೊದಲ ಅಂಶವನ್ನು ಹುಡುಕಿ.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // ಪಿವೋಟ್‌ನ ಚಿಕ್ಕದಾದ ಕೊನೆಯ ಅಂಶವನ್ನು ಹುಡುಕಿ.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` ವ್ಯಾಪ್ತಿಯಿಂದ ಹೊರಟು ಪಿವೋಟ್ (ಇದು ಸ್ಟಾಕ್-ನಿಯೋಜಿತ ವೇರಿಯೇಬಲ್) ಅನ್ನು ಮೂಲತಃ ಇದ್ದ ಸ್ಲೈಸ್‌ಗೆ ಬರೆಯುತ್ತದೆ.
        // ಸುರಕ್ಷತೆಯನ್ನು ಖಾತ್ರಿಪಡಿಸುವಲ್ಲಿ ಈ ಹಂತವು ನಿರ್ಣಾಯಕವಾಗಿದೆ!
        //
    };

    // ಎರಡು ವಿಭಾಗಗಳ ನಡುವೆ ಪಿವೋಟ್ ಇರಿಸಿ.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// `v` ಅನ್ನು `v[pivot]` ಗೆ ಸಮಾನವಾದ ಅಂಶಗಳಾಗಿ ವಿಭಜಿಸುತ್ತದೆ ಮತ್ತು ನಂತರ `v[pivot]` ಗಿಂತ ಹೆಚ್ಚಿನ ಅಂಶಗಳು.
///
/// ಪಿವೋಟ್‌ಗೆ ಸಮಾನವಾದ ಅಂಶಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
/// `v` ಪಿವೋಟ್‌ಗಿಂತ ಚಿಕ್ಕದಾದ ಅಂಶಗಳನ್ನು ಹೊಂದಿಲ್ಲ ಎಂದು is ಹಿಸಲಾಗಿದೆ.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // ಸ್ಲೈಸ್‌ನ ಆರಂಭದಲ್ಲಿ ಪಿವೋಟ್ ಇರಿಸಿ.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // ದಕ್ಷತೆಗಾಗಿ ಪಿವೋಟ್ ಅನ್ನು ಸ್ಟಾಕ್-ನಿಯೋಜಿತ ವೇರಿಯೇಬಲ್ ಆಗಿ ಓದಿ.
    // ಕೆಳಗಿನ ಹೋಲಿಕೆ ಕಾರ್ಯಾಚರಣೆ panics ಆಗಿದ್ದರೆ, ಪಿವೋಟ್ ಅನ್ನು ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಸ್ಲೈಸ್‌ಗೆ ಬರೆಯಲಾಗುತ್ತದೆ.
    // ಸುರಕ್ಷತೆ: ಇಲ್ಲಿ ಪಾಯಿಂಟರ್ ಮಾನ್ಯವಾಗಿದೆ ಏಕೆಂದರೆ ಅದನ್ನು ಸ್ಲೈಸ್‌ನ ಉಲ್ಲೇಖದಿಂದ ಪಡೆಯಲಾಗುತ್ತದೆ.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // ಈಗ ಸ್ಲೈಸ್ ಅನ್ನು ವಿಭಜಿಸಿ.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // ಸುರಕ್ಷತೆ: ಕೆಳಗಿನ ಅಸುರಕ್ಷಿತತೆಯು ಶ್ರೇಣಿಯನ್ನು ಸೂಚಿಕೆ ಮಾಡುವುದನ್ನು ಒಳಗೊಂಡಿರುತ್ತದೆ.
        // ಮೊದಲನೆಯದಕ್ಕಾಗಿ: ನಾವು ಈಗಾಗಲೇ ಇಲ್ಲಿ `l < r` ನೊಂದಿಗೆ ಪರಿಶೀಲಿಸುವ ಪರಿಮಿತಿಯನ್ನು ಮಾಡುತ್ತೇವೆ.
        // ಎರಡನೆಯದಕ್ಕೆ: ನಾವು ಆರಂಭದಲ್ಲಿ `l == 0` ಮತ್ತು `r == v.len()` ಅನ್ನು ಹೊಂದಿದ್ದೇವೆ ಮತ್ತು ಪ್ರತಿ ಇಂಡೆಕ್ಸಿಂಗ್ ಕಾರ್ಯಾಚರಣೆಯಲ್ಲಿ ನಾವು `l < r` ಅನ್ನು ಪರಿಶೀಲಿಸಿದ್ದೇವೆ.
        //                     ಇಲ್ಲಿಂದ ನಮಗೆ ತಿಳಿದಿದೆ `r` ಕನಿಷ್ಠ `r == l` ಆಗಿರಬೇಕು ಅದು ಮೊದಲನೆಯದರಿಂದ ಮಾನ್ಯವಾಗಿದೆ ಎಂದು ತೋರಿಸಲಾಗಿದೆ.
        unsafe {
            // ಪಿವೋಟ್‌ಗಿಂತ ದೊಡ್ಡದಾದ ಮೊದಲ ಅಂಶವನ್ನು ಹುಡುಕಿ.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // ಪಿವೋಟ್‌ಗೆ ಸಮಾನವಾದ ಕೊನೆಯ ಅಂಶವನ್ನು ಹುಡುಕಿ.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // ನಾವು ಮುಗಿಸಿದ್ದೇವೆಯೇ?
            if l >= r {
                break;
            }

            // ಕಂಡುಬರುವ ಜೋಡಿ ಹೊರಗಿನ ಆದೇಶದ ಅಂಶಗಳನ್ನು ವಿನಿಮಯ ಮಾಡಿಕೊಳ್ಳಿ.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // ಪಿವೋಟ್‌ಗೆ ಸಮಾನವಾದ `l` ಅಂಶಗಳನ್ನು ನಾವು ಕಂಡುಕೊಂಡಿದ್ದೇವೆ.ಪಿವೋಟ್‌ಗಾಗಿ ಖಾತೆಗೆ 1 ಸೇರಿಸಿ.
    l + 1

    // `_pivot_guard` ವ್ಯಾಪ್ತಿಯಿಂದ ಹೊರಟು ಪಿವೋಟ್ (ಇದು ಸ್ಟಾಕ್-ನಿಯೋಜಿತ ವೇರಿಯೇಬಲ್) ಅನ್ನು ಮೂಲತಃ ಇದ್ದ ಸ್ಲೈಸ್‌ಗೆ ಬರೆಯುತ್ತದೆ.
    // ಸುರಕ್ಷತೆಯನ್ನು ಖಾತ್ರಿಪಡಿಸುವಲ್ಲಿ ಈ ಹಂತವು ನಿರ್ಣಾಯಕವಾಗಿದೆ!
}

/// ಕ್ವಿಕ್‌ಸೋರ್ಟ್‌ನಲ್ಲಿ ಅಸಮತೋಲಿತ ವಿಭಾಗಗಳನ್ನು ಉಂಟುಮಾಡುವ ಮಾದರಿಗಳನ್ನು ಮುರಿಯುವ ಪ್ರಯತ್ನದಲ್ಲಿ ಕೆಲವು ಅಂಶಗಳನ್ನು ಸುತ್ತಲೂ ಹರಡುತ್ತದೆ.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // ಜಾರ್ಜ್ ಮಾರ್ಸಾಗ್ಲಿಯಾ ಬರೆದ "Xorshift RNGs" ಕಾಗದದಿಂದ ಸ್ಯೂಡೋರಾಂಡಮ್ ಸಂಖ್ಯೆ ಜನರೇಟರ್.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // ಈ ಸಂಖ್ಯೆಯನ್ನು ಯಾದೃಚ್ numbers ಿಕ ಸಂಖ್ಯೆಗಳ ಮಾಡ್ಯುಲೋ ತೆಗೆದುಕೊಳ್ಳಿ.
        // ಈ ಸಂಖ್ಯೆ `usize` ಗೆ ಹೊಂದಿಕೊಳ್ಳುತ್ತದೆ ಏಕೆಂದರೆ `len` `isize::MAX` ಗಿಂತ ಹೆಚ್ಚಿಲ್ಲ.
        let modulus = len.next_power_of_two();

        // ಕೆಲವು ಪಿವೋಟ್ ಅಭ್ಯರ್ಥಿಗಳು ಈ ಸೂಚ್ಯಂಕದ ಸಮೀಪದಲ್ಲಿರುತ್ತಾರೆ.ಅವುಗಳನ್ನು ಯಾದೃಚ್ ize ಿಕಗೊಳಿಸೋಣ.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // ಯಾದೃಚ್ number ಿಕ ಸಂಖ್ಯೆಯ ಮಾಡ್ಯುಲೋ `len` ಅನ್ನು ರಚಿಸಿ.
            // ಹೇಗಾದರೂ, ದುಬಾರಿ ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ತಪ್ಪಿಸುವ ಸಲುವಾಗಿ ನಾವು ಮೊದಲು ಅದನ್ನು ಎರಡು ಶಕ್ತಿಯನ್ನು ಮಾಡ್ಯುಲೋ ಆಗಿ ತೆಗೆದುಕೊಳ್ಳುತ್ತೇವೆ, ಮತ್ತು ನಂತರ ಅದು `[0, len - 1]` ವ್ಯಾಪ್ತಿಗೆ ಹೊಂದಿಕೊಳ್ಳುವವರೆಗೆ `len` ನಿಂದ ಕಡಿಮೆಯಾಗುತ್ತದೆ.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` `2 * len` ಗಿಂತ ಕಡಿಮೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// `v` ನಲ್ಲಿ ಪಿವೋಟ್ ಅನ್ನು ಆಯ್ಕೆ ಮಾಡುತ್ತದೆ ಮತ್ತು ಸ್ಲೈಸ್ ಅನ್ನು ಈಗಾಗಲೇ ವಿಂಗಡಿಸಿದ್ದರೆ ಸೂಚ್ಯಂಕ ಮತ್ತು `true` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
///
/// `v` ನಲ್ಲಿನ ಅಂಶಗಳನ್ನು ಪ್ರಕ್ರಿಯೆಯಲ್ಲಿ ಮರುಕ್ರಮಗೊಳಿಸಬಹುದು.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // ಮೀಡಿಯನ್-ಆಫ್-ಮೀಡಿಯನ್ಸ್ ವಿಧಾನವನ್ನು ಆಯ್ಕೆ ಮಾಡಲು ಕನಿಷ್ಠ ಉದ್ದ.
    // ಕಡಿಮೆ ಚೂರುಗಳು ಸರಳ ಮಧ್ಯಮ-ಮೂರು ವಿಧಾನವನ್ನು ಬಳಸುತ್ತವೆ.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // ಈ ಕಾರ್ಯದಲ್ಲಿ ನಿರ್ವಹಿಸಬಹುದಾದ ಗರಿಷ್ಠ ಸಂಖ್ಯೆಯ ಸ್ವಾಪ್‌ಗಳು.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // ಮೂರು ಸೂಚ್ಯಂಕಗಳು ನಾವು ಪಿವೋಟ್ ಅನ್ನು ಆಯ್ಕೆ ಮಾಡಲಿದ್ದೇವೆ.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // ಸೂಚ್ಯಂಕಗಳನ್ನು ವಿಂಗಡಿಸುವಾಗ ನಾವು ನಿರ್ವಹಿಸಲಿರುವ ಒಟ್ಟು ಸ್ವಾಪ್‌ಗಳ ಸಂಖ್ಯೆಯನ್ನು ಎಣಿಸುತ್ತದೆ.
    let mut swaps = 0;

    if len >= 8 {
        // ಸೂಚ್ಯಂಕಗಳನ್ನು ವಿನಿಮಯ ಮಾಡಿಕೊಳ್ಳುವುದರಿಂದ `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // ಸೂಚ್ಯಂಕಗಳನ್ನು ವಿನಿಮಯ ಮಾಡಿಕೊಳ್ಳುವುದರಿಂದ `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // `v[a - 1], v[a], v[a + 1]` ನ ಸರಾಸರಿ ಕಂಡುಕೊಳ್ಳುತ್ತದೆ ಮತ್ತು ಸೂಚ್ಯಂಕವನ್ನು `a` ಗೆ ಸಂಗ್ರಹಿಸುತ್ತದೆ.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // `a`, `b`, ಮತ್ತು `c` ನ ನೆರೆಹೊರೆಯಲ್ಲಿ ಮಧ್ಯವರ್ತಿಗಳನ್ನು ಹುಡುಕಿ.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // `a`, `b`, ಮತ್ತು `c` ನಡುವೆ ಸರಾಸರಿ ಹುಡುಕಿ.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // ಗರಿಷ್ಠ ಸಂಖ್ಯೆಯ ಸ್ವಾಪ್ಗಳನ್ನು ನಡೆಸಲಾಯಿತು.
        // ಸ್ಲೈಸ್ ಅವರೋಹಣ ಅಥವಾ ಹೆಚ್ಚಾಗಿ ಅವರೋಹಣಕ್ಕೆ ಅವಕಾಶಗಳಿವೆ, ಆದ್ದರಿಂದ ಹಿಮ್ಮುಖಗೊಳಿಸುವಿಕೆಯು ಅದನ್ನು ವೇಗವಾಗಿ ವಿಂಗಡಿಸಲು ಸಹಾಯ ಮಾಡುತ್ತದೆ.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v` ಅನ್ನು ಪುನರಾವರ್ತಿತವಾಗಿ ವಿಂಗಡಿಸುತ್ತದೆ.
///
/// ಸ್ಲೈಸ್ ಮೂಲ ಶ್ರೇಣಿಯಲ್ಲಿ ಪೂರ್ವವರ್ತಿಯನ್ನು ಹೊಂದಿದ್ದರೆ, ಅದನ್ನು `pred` ಎಂದು ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿದೆ.
///
/// `limit` `heapsort` ಗೆ ಬದಲಾಯಿಸುವ ಮೊದಲು ಅನುಮತಿಸಲಾದ ಅಸಮತೋಲಿತ ವಿಭಾಗಗಳ ಸಂಖ್ಯೆ.
/// ಶೂನ್ಯವಾಗಿದ್ದರೆ, ಈ ಕಾರ್ಯವು ತಕ್ಷಣವೇ ರಾಶಿ ರಾಶಿಗೆ ಬದಲಾಗುತ್ತದೆ.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // ಈ ಉದ್ದದ ಚೂರುಗಳನ್ನು ಅಳವಡಿಕೆ ವಿಂಗಡಣೆಯನ್ನು ಬಳಸಿಕೊಂಡು ವಿಂಗಡಿಸಲಾಗುತ್ತದೆ.
    const MAX_INSERTION: usize = 20;

    // ಕೊನೆಯ ವಿಭಜನೆಯು ಸಮಂಜಸವಾಗಿ ಸಮತೋಲನದಲ್ಲಿದ್ದರೆ ನಿಜ.
    let mut was_balanced = true;
    // ಕೊನೆಯ ವಿಭಜನೆಯು ಅಂಶಗಳನ್ನು ಬದಲಾಯಿಸದಿದ್ದರೆ ನಿಜ (ಸ್ಲೈಸ್ ಅನ್ನು ಈಗಾಗಲೇ ವಿಭಜಿಸಲಾಗಿದೆ).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // ಅಳವಡಿಕೆ ವಿಂಗಡಣೆಯನ್ನು ಬಳಸಿಕೊಂಡು ಬಹಳ ಸಣ್ಣ ಚೂರುಗಳನ್ನು ವಿಂಗಡಿಸಲಾಗುತ್ತದೆ.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // ಹಲವಾರು ಕೆಟ್ಟ ಪಿವೋಟ್ ಆಯ್ಕೆಗಳನ್ನು ಮಾಡಿದ್ದರೆ, `O(n * log(n))` ಕೆಟ್ಟ ಪ್ರಕರಣವನ್ನು ಖಾತರಿಪಡಿಸುವ ಸಲುವಾಗಿ ರಾಶಿ ರಾಶಿಗೆ ಹಿಂತಿರುಗಿ.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // ಕೊನೆಯ ವಿಭಜನೆಯು ಅಸಮತೋಲನದಲ್ಲಿದ್ದರೆ, ಸುತ್ತಲೂ ಕೆಲವು ಅಂಶಗಳನ್ನು ಬದಲಾಯಿಸುವ ಮೂಲಕ ಸ್ಲೈಸ್‌ನಲ್ಲಿ ಮಾದರಿಗಳನ್ನು ಮುರಿಯಲು ಪ್ರಯತ್ನಿಸಿ.
        // ಆಶಾದಾಯಕವಾಗಿ ನಾವು ಈ ಸಮಯದಲ್ಲಿ ಉತ್ತಮ ಪಿವೋಟ್ ಅನ್ನು ಆಯ್ಕೆ ಮಾಡುತ್ತೇವೆ.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // ಪಿವೋಟ್ ಅನ್ನು ಆರಿಸಿ ಮತ್ತು ಸ್ಲೈಸ್ ಅನ್ನು ಈಗಾಗಲೇ ವಿಂಗಡಿಸಲಾಗಿದೆಯೇ ಎಂದು try ಹಿಸಲು ಪ್ರಯತ್ನಿಸಿ.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // ಕೊನೆಯ ವಿಭಜನೆಯು ಯೋಗ್ಯವಾಗಿ ಸಮತೋಲಿತವಾಗಿದ್ದರೆ ಮತ್ತು ಅಂಶಗಳನ್ನು ಬದಲಾಯಿಸದಿದ್ದರೆ, ಮತ್ತು ಪಿವೋಟ್ ಆಯ್ಕೆಯು ic ಹಿಸಿದರೆ ಸ್ಲೈಸ್ ಅನ್ನು ಈಗಾಗಲೇ ವಿಂಗಡಿಸಬಹುದು ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // ಹಲವಾರು ಆದೇಶದ ಅಂಶಗಳನ್ನು ಗುರುತಿಸಲು ಪ್ರಯತ್ನಿಸಿ ಮತ್ತು ಅವುಗಳನ್ನು ಸರಿಯಾದ ಸ್ಥಾನಗಳಿಗೆ ವರ್ಗಾಯಿಸಿ.
            // ಸ್ಲೈಸ್ ಸಂಪೂರ್ಣವಾಗಿ ವಿಂಗಡಿಸಲ್ಪಟ್ಟರೆ, ನಾವು ಮುಗಿಸಿದ್ದೇವೆ.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // ಆಯ್ಕೆಮಾಡಿದ ಪಿವೋಟ್ ಹಿಂದಿನದಕ್ಕೆ ಸಮನಾಗಿದ್ದರೆ, ಅದು ಸ್ಲೈಸ್‌ನಲ್ಲಿರುವ ಚಿಕ್ಕ ಅಂಶವಾಗಿದೆ.
        // ಸ್ಲೈಸ್ ಅನ್ನು ಸಮಾನ ಅಂಶಗಳಾಗಿ ಮತ್ತು ಪಿವೋಟ್ಗಿಂತ ಹೆಚ್ಚಿನ ಅಂಶಗಳಾಗಿ ವಿಭಜಿಸಿ.
        // ಸ್ಲೈಸ್ ಅನೇಕ ನಕಲಿ ಅಂಶಗಳನ್ನು ಒಳಗೊಂಡಿರುವಾಗ ಈ ಪ್ರಕರಣವನ್ನು ಸಾಮಾನ್ಯವಾಗಿ ಹೊಡೆಯಲಾಗುತ್ತದೆ.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // ಪಿವೋಟ್‌ಗಿಂತ ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ವಿಂಗಡಿಸುವುದನ್ನು ಮುಂದುವರಿಸಿ.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // ಸ್ಲೈಸ್ ಅನ್ನು ವಿಭಜಿಸಿ.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // ಸ್ಲೈಸ್ ಅನ್ನು `left`, `pivot`, ಮತ್ತು `right` ಆಗಿ ವಿಭಜಿಸಿ.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // ಒಟ್ಟು ಪುನರಾವರ್ತಿತ ಕರೆಗಳ ಸಂಖ್ಯೆಯನ್ನು ಕಡಿಮೆ ಮಾಡಲು ಮತ್ತು ಕಡಿಮೆ ಸ್ಟಾಕ್ ಜಾಗವನ್ನು ಬಳಸುವುದಕ್ಕಾಗಿ ಮಾತ್ರ ಕಡಿಮೆ ಭಾಗಕ್ಕೆ ಹಿಂತಿರುಗಿ.
        // ನಂತರ ಕೇವಲ ಉದ್ದದ ಭಾಗದೊಂದಿಗೆ ಮುಂದುವರಿಯಿರಿ (ಇದು ಬಾಲ ಪುನರಾವರ್ತನೆಗೆ ಹೋಲುತ್ತದೆ).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// ಪ್ಯಾಟರ್ನ್-ಸೋಲಿಸುವ ಕ್ವಿಕ್‌ಸೋರ್ಟ್ ಅನ್ನು ಬಳಸಿಕೊಂಡು `v` ಅನ್ನು ವಿಂಗಡಿಸುತ್ತದೆ, ಅದು *O*(*n*\*log(* n*)) ಕೆಟ್ಟ ಪ್ರಕರಣವಾಗಿದೆ.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // ವಿಂಗಡಣೆಯು ಶೂನ್ಯ-ಗಾತ್ರದ ಪ್ರಕಾರಗಳಲ್ಲಿ ಯಾವುದೇ ಅರ್ಥಪೂರ್ಣ ನಡವಳಿಕೆಯನ್ನು ಹೊಂದಿಲ್ಲ.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // ಅಸಮತೋಲಿತ ವಿಭಾಗಗಳ ಸಂಖ್ಯೆಯನ್ನು `floor(log2(len)) + 1` ಗೆ ಮಿತಿಗೊಳಿಸಿ.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // ಈ ಉದ್ದದ ಚೂರುಗಳಿಗಾಗಿ ಅವುಗಳನ್ನು ಸರಳವಾಗಿ ವಿಂಗಡಿಸಲು ಬಹುಶಃ ವೇಗವಾಗಿರುತ್ತದೆ.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // ಪಿವೋಟ್ ಆಯ್ಕೆಮಾಡಿ
        let (pivot, _) = choose_pivot(v, is_less);

        // ಆಯ್ಕೆಮಾಡಿದ ಪಿವೋಟ್ ಹಿಂದಿನದಕ್ಕೆ ಸಮನಾಗಿದ್ದರೆ, ಅದು ಸ್ಲೈಸ್‌ನಲ್ಲಿರುವ ಚಿಕ್ಕ ಅಂಶವಾಗಿದೆ.
        // ಸ್ಲೈಸ್ ಅನ್ನು ಸಮಾನ ಅಂಶಗಳಾಗಿ ಮತ್ತು ಪಿವೋಟ್ಗಿಂತ ಹೆಚ್ಚಿನ ಅಂಶಗಳಾಗಿ ವಿಭಜಿಸಿ.
        // ಸ್ಲೈಸ್ ಅನೇಕ ನಕಲಿ ಅಂಶಗಳನ್ನು ಒಳಗೊಂಡಿರುವಾಗ ಈ ಪ್ರಕರಣವನ್ನು ಸಾಮಾನ್ಯವಾಗಿ ಹೊಡೆಯಲಾಗುತ್ತದೆ.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // ನಾವು ನಮ್ಮ ಸೂಚ್ಯಂಕವನ್ನು ಹಾದುಹೋಗಿದ್ದರೆ, ನಾವು ಒಳ್ಳೆಯವರು.
                if mid > index {
                    return;
                }

                // ಇಲ್ಲದಿದ್ದರೆ, ಪಿವೋಟ್‌ಗಿಂತ ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ವಿಂಗಡಿಸುವುದನ್ನು ಮುಂದುವರಿಸಿ.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // ಸ್ಲೈಸ್ ಅನ್ನು `left`, `pivot`, ಮತ್ತು `right` ಆಗಿ ವಿಭಜಿಸಿ.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // ಮಧ್ಯ==ಸೂಚ್ಯಂಕವಾಗಿದ್ದರೆ, ನಾವು ಮುಗಿಸಿದ್ದೇವೆ, ಏಕೆಂದರೆ ಮಧ್ಯದ ನಂತರದ ಎಲ್ಲಾ ಅಂಶಗಳು ಮಧ್ಯಕ್ಕಿಂತ ದೊಡ್ಡದಾಗಿದೆ ಅಥವಾ ಸಮಾನವಾಗಿರುತ್ತದೆ ಎಂದು partition() ಖಾತರಿಪಡಿಸುತ್ತದೆ.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // ವಿಂಗಡಣೆಯು ಶೂನ್ಯ-ಗಾತ್ರದ ಪ್ರಕಾರಗಳಲ್ಲಿ ಯಾವುದೇ ಅರ್ಥಪೂರ್ಣ ನಡವಳಿಕೆಯನ್ನು ಹೊಂದಿಲ್ಲ.ಏನನ್ನೂ ಮಾಡಬೇಡ.
    } else if index == v.len() - 1 {
        // ಗರಿಷ್ಠ ಅಂಶವನ್ನು ಹುಡುಕಿ ಮತ್ತು ಅದನ್ನು ರಚನೆಯ ಕೊನೆಯ ಸ್ಥಾನದಲ್ಲಿ ಇರಿಸಿ.
        // ನಾವು ಇಲ್ಲಿ `unwrap()` ಅನ್ನು ಬಳಸಲು ಮುಕ್ತರಾಗಿದ್ದೇವೆ ಏಕೆಂದರೆ v ಖಾಲಿಯಾಗಿರಬಾರದು ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // ನಿಮಿಷದ ಅಂಶವನ್ನು ಹುಡುಕಿ ಮತ್ತು ಅದನ್ನು ರಚನೆಯ ಮೊದಲ ಸ್ಥಾನದಲ್ಲಿ ಇರಿಸಿ.
        // ನಾವು ಇಲ್ಲಿ `unwrap()` ಅನ್ನು ಬಳಸಲು ಮುಕ್ತರಾಗಿದ್ದೇವೆ ಏಕೆಂದರೆ v ಖಾಲಿಯಾಗಿರಬಾರದು ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}