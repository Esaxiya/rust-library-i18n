//! ಸ್ಲೈಸ್‌ನ ಪುನರಾವರ್ತಕರು ಬಳಸುವ ಮ್ಯಾಕ್ರೋಗಳು.

// Is_empty ಮತ್ತು len ಅನ್ನು ಇನ್‌ಲೈನ್ ಮಾಡುವುದು ದೊಡ್ಡ ಕಾರ್ಯಕ್ಷಮತೆಯ ವ್ಯತ್ಯಾಸವನ್ನುಂಟು ಮಾಡುತ್ತದೆ
macro_rules! is_empty {
    // ನಾವು ZST ಪುನರಾವರ್ತನೆಯ ಉದ್ದವನ್ನು ಎನ್ಕೋಡ್ ಮಾಡುವ ವಿಧಾನ, ಇದು ZST ಮತ್ತು ZST ಅಲ್ಲದ ಎರಡಕ್ಕೂ ಕೆಲಸ ಮಾಡುತ್ತದೆ.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// ಕೆಲವು ಗಡಿ ತಪಾಸಣೆಗಳನ್ನು ತೊಡೆದುಹಾಕಲು (`position` ನೋಡಿ), ನಾವು ಉದ್ದವನ್ನು ಸ್ವಲ್ಪ ಅನಿರೀಕ್ಷಿತ ರೀತಿಯಲ್ಲಿ ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತೇವೆ.
// (`ಕೋಡೆಜೆನ್/ಸ್ಲೈಸ್-ಪೊಸಿಷನ್-ಬೌಂಡ್ಸ್-ಚೆಕ್` ನಿಂದ ಪರೀಕ್ಷಿಸಲಾಗಿದೆ.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // ನಾವು ಕೆಲವೊಮ್ಮೆ ಅಸುರಕ್ಷಿತ ಬ್ಲಾಕ್‌ನಲ್ಲಿ ಬಳಸುತ್ತೇವೆ

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // ಈ _cannot_ `unchecked_sub` ಅನ್ನು ಬಳಸುತ್ತದೆ ಏಕೆಂದರೆ ನಾವು ಉದ್ದವಾದ ZST ಸ್ಲೈಸ್ ಇಟರೇಟರ್‌ಗಳ ಉದ್ದವನ್ನು ಪ್ರತಿನಿಧಿಸಲು ಸುತ್ತುವುದನ್ನು ಅವಲಂಬಿಸಿದ್ದೇವೆ.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // `start <= end`, `offset_from` ಗಿಂತ ಉತ್ತಮವಾಗಿ ಮಾಡಬಹುದು ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ, ಇದು ಸಹಿ ಮಾಡಿದಲ್ಲಿ ವ್ಯವಹರಿಸಬೇಕಾಗಿದೆ.
            // ಸೂಕ್ತವಾದ ಧ್ವಜಗಳನ್ನು ಇಲ್ಲಿ ಹೊಂದಿಸುವ ಮೂಲಕ ನಾವು ಇದನ್ನು ಎಲ್ಎಲ್ವಿಎಂಗೆ ಹೇಳಬಹುದು, ಇದು ಗಡಿ ಪರಿಶೀಲನೆಗಳನ್ನು ತೆಗೆದುಹಾಕಲು ಸಹಾಯ ಮಾಡುತ್ತದೆ.
            // ಸುರಕ್ಷತೆ: ಅಸ್ಥಿರ ಪ್ರಕಾರದಿಂದ, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // ಪಾಯಿಂಟರ್‌ಗಳು ಟೈಪ್ ಗಾತ್ರದ ನಿಖರವಾದ ಗುಣಾಕಾರದಿಂದ ಪ್ರತ್ಯೇಕವಾಗಿವೆ ಎಂದು ಎಲ್‌ಎಲ್‌ವಿಎಂಗೆ ಹೇಳುವ ಮೂಲಕ, ಇದು ಎಕ್ಸ್‌00 ಎಕ್ಸ್‌ಗೆ ಬದಲಾಗಿ ಎಕ್ಸ್‌01 ಎಕ್ಸ್ ಅನ್ನು ಎಕ್ಸ್‌02 ಎಕ್ಸ್‌ಗೆ ಅತ್ಯುತ್ತಮವಾಗಿಸಬಹುದು.
            //
            // ಸುರಕ್ಷತೆ: ಅಸ್ಥಿರ ಪ್ರಕಾರದ ಪ್ರಕಾರ, ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಜೋಡಿಸಲಾಗಿದೆ ಆದ್ದರಿಂದ
            //         ಅವುಗಳ ನಡುವಿನ ಅಂತರವು ಪಾಯಿಂಟಿ ಗಾತ್ರದ ಬಹುಸಂಖ್ಯೆಯಾಗಿರಬೇಕು
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter` ಮತ್ತು `IterMut` ಪುನರಾವರ್ತಕರ ಹಂಚಿಕೆಯ ವ್ಯಾಖ್ಯಾನ
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // ಮೊದಲ ಅಂಶವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ ಮತ್ತು ಪುನರಾವರ್ತಕದ ಪ್ರಾರಂಭವನ್ನು 1 ರಿಂದ ಮುಂದಕ್ಕೆ ಚಲಿಸುತ್ತದೆ.
        // ಇನ್ಲೈನ್ ಮಾಡಿದ ಕಾರ್ಯಕ್ಕೆ ಹೋಲಿಸಿದರೆ ಕಾರ್ಯಕ್ಷಮತೆಯನ್ನು ಹೆಚ್ಚು ಸುಧಾರಿಸುತ್ತದೆ.
        // ಪುನರಾವರ್ತಕ ಖಾಲಿಯಾಗಿರಬಾರದು.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // ಕೊನೆಯ ಅಂಶವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ ಮತ್ತು ಪುನರಾವರ್ತಕದ ಅಂತ್ಯವನ್ನು 1 ರಿಂದ ಹಿಂದಕ್ಕೆ ಚಲಿಸುತ್ತದೆ.
        // ಇನ್ಲೈನ್ ಮಾಡಿದ ಕಾರ್ಯಕ್ಕೆ ಹೋಲಿಸಿದರೆ ಕಾರ್ಯಕ್ಷಮತೆಯನ್ನು ಹೆಚ್ಚು ಸುಧಾರಿಸುತ್ತದೆ.
        // ಪುನರಾವರ್ತಕ ಖಾಲಿಯಾಗಿರಬಾರದು.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // ಟಿ Z ಡ್‌ಎಸ್‌ಟಿ ಆಗಿರುವಾಗ, ಪುನರಾವರ್ತಕದ ಅಂತ್ಯವನ್ನು `n` ನಿಂದ ಹಿಂದಕ್ಕೆ ಚಲಿಸುವ ಮೂಲಕ ಪುನರಾವರ್ತಕವನ್ನು ಕುಗ್ಗಿಸುತ್ತದೆ.
        // `n` `self.len()` ಮೀರಬಾರದು.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // ಪುನರಾವರ್ತಕದಿಂದ ಸ್ಲೈಸ್ ರಚಿಸಲು ಸಹಾಯಕ ಕಾರ್ಯ.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // ಸುರಕ್ಷತೆ: ಪಾಯಿಂಟರ್‌ನೊಂದಿಗೆ ಸ್ಲೈಸ್‌ನಿಂದ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸಲಾಗಿದೆ
                // `self.ptr` ಮತ್ತು ಉದ್ದ `len!(self)`.
                // `from_raw_parts` ಗಾಗಿ ಎಲ್ಲಾ ಪೂರ್ವಾಪೇಕ್ಷಿತಗಳನ್ನು ಪೂರೈಸಲಾಗುತ್ತದೆ ಎಂದು ಇದು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // ಇಟರೇಟರ್ನ ಪ್ರಾರಂಭವನ್ನು `offset` ಅಂಶಗಳಿಂದ ಮುಂದಕ್ಕೆ ಸರಿಸಲು ಸಹಾಯಕ ಕಾರ್ಯ, ಹಳೆಯ ಪ್ರಾರಂಭವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
            //
            // ಅಸುರಕ್ಷಿತ ಏಕೆಂದರೆ ಆಫ್‌ಸೆಟ್ `self.len()` ಮೀರಬಾರದು.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `offset` `self.len()` ಅನ್ನು ಮೀರುವುದಿಲ್ಲ ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತದೆ,
                    // ಆದ್ದರಿಂದ ಈ ಹೊಸ ಪಾಯಿಂಟರ್ `self` ಒಳಗೆ ಇದೆ ಮತ್ತು ಆದ್ದರಿಂದ ಶೂನ್ಯವಲ್ಲ ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // ಪುನರಾವರ್ತಕದ ಅಂತ್ಯವನ್ನು `offset` ಅಂಶಗಳಿಂದ ಹಿಂದಕ್ಕೆ ಸರಿಸಲು, ಹೊಸ ತುದಿಯನ್ನು ಹಿಂದಿರುಗಿಸಲು ಸಹಾಯಕ ಕಾರ್ಯ.
            //
            // ಅಸುರಕ್ಷಿತ ಏಕೆಂದರೆ ಆಫ್‌ಸೆಟ್ `self.len()` ಮೀರಬಾರದು.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `offset` `self.len()` ಅನ್ನು ಮೀರುವುದಿಲ್ಲ ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತದೆ,
                    // ಇದು `isize` ಅನ್ನು ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.
                    // ಅಲ್ಲದೆ, ಪರಿಣಾಮವಾಗಿ ಸೂಚಕವು `slice` ನ ಪರಿಧಿಯಲ್ಲಿದೆ, ಇದು `offset` ಗಾಗಿ ಇತರ ಅವಶ್ಯಕತೆಗಳನ್ನು ಪೂರೈಸುತ್ತದೆ.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // ಚೂರುಗಳೊಂದಿಗೆ ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು, ಆದರೆ ಇದು ಗಡಿ ಪರಿಶೀಲನೆಯನ್ನು ತಪ್ಪಿಸುತ್ತದೆ

                // ಸುರಕ್ಷತೆ: ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದ ಪಾಯಿಂಟರ್‌ನಿಂದ `assume` ಕರೆಗಳು ಸುರಕ್ಷಿತವಾಗಿವೆ
                // ಶೂನ್ಯೇತರವಾಗಿರಬೇಕು ಮತ್ತು ZST ಅಲ್ಲದ ಮೇಲಿನ ಚೂರುಗಳು ಶೂನ್ಯವಲ್ಲದ ಎಂಡ್ ಪಾಯಿಂಟರ್ ಅನ್ನು ಸಹ ಹೊಂದಿರಬೇಕು.
                // ಇಟರೇಟರ್ ಮೊದಲು ಖಾಲಿಯಾಗಿದೆಯೇ ಎಂದು ನಾವು ಪರಿಶೀಲಿಸುವುದರಿಂದ `next_unchecked!` ಗೆ ಕರೆ ಸುರಕ್ಷಿತವಾಗಿದೆ.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // ಈ ಪುನರಾವರ್ತಕ ಈಗ ಖಾಲಿಯಾಗಿದೆ.
                    if mem::size_of::<T>() == 0 {
                        // `ptr` ಎಂದಿಗೂ 0 ಆಗಿರದ ಕಾರಣ ನಾವು ಇದನ್ನು ಈ ರೀತಿ ಮಾಡಬೇಕು, ಆದರೆ `end` ಆಗಿರಬಹುದು (ಸುತ್ತುವುದರಿಂದ).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // ಸುರಕ್ಷತೆ: ಟಿ Z ಡ್‌ಎಸ್‌ಟಿ ಅಲ್ಲದಿದ್ದರೆ ಅಂತ್ಯ 0 ಆಗಲು ಸಾಧ್ಯವಿಲ್ಲ ಏಕೆಂದರೆ ಪಿಟಿಆರ್ 0 ಅಲ್ಲ ಮತ್ತು ಅಂತ್ಯ>=ಪಿಟಿಆರ್
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // ಸುರಕ್ಷತೆ: ನಾವು ಮಿತಿಯಲ್ಲಿದ್ದೇವೆ.`post_inc_start` ZST ಗಳಿಗೆ ಸಹ ಸರಿಯಾದ ಕೆಲಸವನ್ನು ಮಾಡುತ್ತದೆ.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // `try_fold` ಅನ್ನು ಬಳಸುವ ಡೀಫಾಲ್ಟ್ ಅನುಷ್ಠಾನವನ್ನು ನಾವು ಅತಿಕ್ರಮಿಸುತ್ತೇವೆ, ಏಕೆಂದರೆ ಈ ಸರಳ ಅನುಷ್ಠಾನವು ಕಡಿಮೆ LLVM IR ಅನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ ಮತ್ತು ಕಂಪೈಲ್ ಮಾಡಲು ವೇಗವಾಗಿರುತ್ತದೆ.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // `try_fold` ಅನ್ನು ಬಳಸುವ ಡೀಫಾಲ್ಟ್ ಅನುಷ್ಠಾನವನ್ನು ನಾವು ಅತಿಕ್ರಮಿಸುತ್ತೇವೆ, ಏಕೆಂದರೆ ಈ ಸರಳ ಅನುಷ್ಠಾನವು ಕಡಿಮೆ LLVM IR ಅನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ ಮತ್ತು ಕಂಪೈಲ್ ಮಾಡಲು ವೇಗವಾಗಿರುತ್ತದೆ.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // `try_fold` ಅನ್ನು ಬಳಸುವ ಡೀಫಾಲ್ಟ್ ಅನುಷ್ಠಾನವನ್ನು ನಾವು ಅತಿಕ್ರಮಿಸುತ್ತೇವೆ, ಏಕೆಂದರೆ ಈ ಸರಳ ಅನುಷ್ಠಾನವು ಕಡಿಮೆ LLVM IR ಅನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ ಮತ್ತು ಕಂಪೈಲ್ ಮಾಡಲು ವೇಗವಾಗಿರುತ್ತದೆ.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // `try_fold` ಅನ್ನು ಬಳಸುವ ಡೀಫಾಲ್ಟ್ ಅನುಷ್ಠಾನವನ್ನು ನಾವು ಅತಿಕ್ರಮಿಸುತ್ತೇವೆ, ಏಕೆಂದರೆ ಈ ಸರಳ ಅನುಷ್ಠಾನವು ಕಡಿಮೆ LLVM IR ಅನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ ಮತ್ತು ಕಂಪೈಲ್ ಮಾಡಲು ವೇಗವಾಗಿರುತ್ತದೆ.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // `try_fold` ಅನ್ನು ಬಳಸುವ ಡೀಫಾಲ್ಟ್ ಅನುಷ್ಠಾನವನ್ನು ನಾವು ಅತಿಕ್ರಮಿಸುತ್ತೇವೆ, ಏಕೆಂದರೆ ಈ ಸರಳ ಅನುಷ್ಠಾನವು ಕಡಿಮೆ LLVM IR ಅನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ ಮತ್ತು ಕಂಪೈಲ್ ಮಾಡಲು ವೇಗವಾಗಿರುತ್ತದೆ.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // `try_fold` ಅನ್ನು ಬಳಸುವ ಡೀಫಾಲ್ಟ್ ಅನುಷ್ಠಾನವನ್ನು ನಾವು ಅತಿಕ್ರಮಿಸುತ್ತೇವೆ, ಏಕೆಂದರೆ ಈ ಸರಳ ಅನುಷ್ಠಾನವು ಕಡಿಮೆ LLVM IR ಅನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ ಮತ್ತು ಕಂಪೈಲ್ ಮಾಡಲು ವೇಗವಾಗಿರುತ್ತದೆ.
            // ಅಲ್ಲದೆ, `assume` ಬೌಂಡ್ಸ್ ಚೆಕ್ ಅನ್ನು ತಪ್ಪಿಸುತ್ತದೆ.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // ಸುರಕ್ಷತೆ: ಲೂಪ್ ಅಸ್ಥಿರತೆಯಿಂದ ನಾವು ಗಡಿರೇಖೆ ಹೊಂದಿದ್ದೇವೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ:
                        // `i >= n`, `self.next()` `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸಿದಾಗ ಮತ್ತು ಲೂಪ್ ಮುರಿಯುತ್ತದೆ.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // `try_fold` ಅನ್ನು ಬಳಸುವ ಡೀಫಾಲ್ಟ್ ಅನುಷ್ಠಾನವನ್ನು ನಾವು ಅತಿಕ್ರಮಿಸುತ್ತೇವೆ, ಏಕೆಂದರೆ ಈ ಸರಳ ಅನುಷ್ಠಾನವು ಕಡಿಮೆ LLVM IR ಅನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ ಮತ್ತು ಕಂಪೈಲ್ ಮಾಡಲು ವೇಗವಾಗಿರುತ್ತದೆ.
            // ಅಲ್ಲದೆ, `assume` ಬೌಂಡ್ಸ್ ಚೆಕ್ ಅನ್ನು ತಪ್ಪಿಸುತ್ತದೆ.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // ಸುರಕ್ಷತೆ: `i` `n` ನಿಂದ ಪ್ರಾರಂಭವಾಗುವುದರಿಂದ `n` ಗಿಂತ ಕಡಿಮೆಯಿರಬೇಕು
                        // ಮತ್ತು ಕಡಿಮೆಯಾಗುತ್ತಿದೆ.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `i` ಗಡಿಯಲ್ಲಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು
                // ಆಧಾರವಾಗಿರುವ ಸ್ಲೈಸ್, ಆದ್ದರಿಂದ `i` ಗೆ `isize` ಅನ್ನು ಉಕ್ಕಿ ಹರಿಯಲು ಸಾಧ್ಯವಿಲ್ಲ, ಮತ್ತು ಹಿಂದಿರುಗಿದ ಉಲ್ಲೇಖಗಳು ಸ್ಲೈಸ್‌ನ ಒಂದು ಅಂಶವನ್ನು ಉಲ್ಲೇಖಿಸಲು ಖಾತರಿಪಡಿಸುತ್ತದೆ ಮತ್ತು ಆದ್ದರಿಂದ ಮಾನ್ಯವಾಗಿರುತ್ತದೆ.
                //
                // ಅದೇ ಸೂಚ್ಯಂಕದೊಂದಿಗೆ ನಾವು ಎಂದಿಗೂ ಕರೆಯುವುದಿಲ್ಲ ಎಂದು ಕರೆ ಮಾಡುವವರು ಖಾತರಿಪಡಿಸುತ್ತಾರೆ ಮತ್ತು ಈ ಚಂದಾದಾರಿಕೆಯನ್ನು ಪ್ರವೇಶಿಸುವ ಬೇರೆ ಯಾವುದೇ ವಿಧಾನಗಳನ್ನು ಕರೆಯಲಾಗುವುದಿಲ್ಲ, ಆದ್ದರಿಂದ ಹಿಂದಿರುಗಿದ ಉಲ್ಲೇಖವು ರೂಪಾಂತರಗೊಳ್ಳಲು ಮಾನ್ಯವಾಗಿರುತ್ತದೆ
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // ಚೂರುಗಳೊಂದಿಗೆ ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು, ಆದರೆ ಇದು ಗಡಿ ಪರಿಶೀಲನೆಯನ್ನು ತಪ್ಪಿಸುತ್ತದೆ

                // ಸುರಕ್ಷತೆ: ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದ ಪಾಯಿಂಟರ್ ಶೂನ್ಯವಲ್ಲದ ಕಾರಣ `assume` ಕರೆಗಳು ಸುರಕ್ಷಿತವಾಗಿವೆ,
                // ಮತ್ತು ZST ಅಲ್ಲದ ಮೇಲಿನ ಚೂರುಗಳು ಶೂನ್ಯವಲ್ಲದ ಎಂಡ್ ಪಾಯಿಂಟರ್ ಅನ್ನು ಸಹ ಹೊಂದಿರಬೇಕು.
                // ಇಟರೇಟರ್ ಮೊದಲು ಖಾಲಿಯಾಗಿದೆಯೇ ಎಂದು ನಾವು ಪರಿಶೀಲಿಸುವುದರಿಂದ `next_back_unchecked!` ಗೆ ಕರೆ ಸುರಕ್ಷಿತವಾಗಿದೆ.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // ಈ ಪುನರಾವರ್ತಕ ಈಗ ಖಾಲಿಯಾಗಿದೆ.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // ಸುರಕ್ಷತೆ: ನಾವು ಮಿತಿಯಲ್ಲಿದ್ದೇವೆ.`pre_dec_end` ZST ಗಳಿಗೆ ಸಹ ಸರಿಯಾದ ಕೆಲಸವನ್ನು ಮಾಡುತ್ತದೆ.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}