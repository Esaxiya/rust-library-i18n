// ignore-tidy-filelength

//! ಸ್ಲೈಸ್ ನಿರ್ವಹಣೆ ಮತ್ತು ಕುಶಲತೆ.
//!
//! ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ [`std::slice`] ನೋಡಿ.
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// ಶುದ್ಧ rust memchr ಅನುಷ್ಠಾನ, rust-memchr ನಿಂದ ತೆಗೆದುಕೊಳ್ಳಲಾಗಿದೆ
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// ಯುನಿಟ್ ಟೆಸ್ಟ್ ಹೆಪ್ಸೋರ್ಟ್‌ಗೆ ಬೇರೆ ದಾರಿ ಇಲ್ಲದ ಕಾರಣ ಈ ಕಾರ್ಯವು ಸಾರ್ವಜನಿಕವಾಗಿದೆ.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// ಸ್ಲೈಸ್‌ನಲ್ಲಿರುವ ಅಂಶಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // ಸುರಕ್ಷತೆ: ಕಾನ್ಸ್ಟ್ ಸೌಂಡ್ ಏಕೆಂದರೆ ನಾವು ಉದ್ದದ ಕ್ಷೇತ್ರವನ್ನು ಯುಸೈಜ್ ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತೇವೆ (ಅದು ಇರಬೇಕು)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // ಸುರಕ್ಷತೆ: ಇದು ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ `&[T]` ಮತ್ತು `FatPtr<T>` ಒಂದೇ ವಿನ್ಯಾಸವನ್ನು ಹೊಂದಿವೆ.
            // `std` ಮಾತ್ರ ಈ ಖಾತರಿಯನ್ನು ನೀಡಬಲ್ಲದು.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: ಅದು ಸ್ಥಿರವಾಗಿರುವಾಗ `crate::ptr::metadata(self)` ನೊಂದಿಗೆ ಬದಲಾಯಿಸಿ.
            // ಈ ಬರವಣಿಗೆಯ ಪ್ರಕಾರ ಇದು "Const-stable functions can only call other const-stable functions" ದೋಷಕ್ಕೆ ಕಾರಣವಾಗುತ್ತದೆ.
            //

            // ಸುರಕ್ಷತೆ: * const T ರಿಂದ `PtrRepr` ಯೂನಿಯನ್‌ನಿಂದ ಮೌಲ್ಯವನ್ನು ಪ್ರವೇಶಿಸುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ
            // ಮತ್ತು PtrComponents<T>ಒಂದೇ ಮೆಮೊರಿ ವಿನ್ಯಾಸಗಳನ್ನು ಹೊಂದಿವೆ.
            // std ಮಾತ್ರ ಈ ಖಾತರಿಯನ್ನು ನೀಡುತ್ತದೆ.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// ಸ್ಲೈಸ್ 0 ಉದ್ದವನ್ನು ಹೊಂದಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ಸ್ಲೈಸ್‌ನ ಮೊದಲ ಅಂಶವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಥವಾ ಅದು ಖಾಲಿಯಾಗಿದ್ದರೆ `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// ರೂಪಾಂತರಗೊಳ್ಳುವ ಪಾಯಿಂಟರ್ ಅನ್ನು ಸ್ಲೈಸ್‌ನ ಮೊದಲ ಅಂಶಕ್ಕೆ ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಥವಾ ಅದು ಖಾಲಿಯಾಗಿದ್ದರೆ `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// ಸ್ಲೈಸ್‌ನ ಮೊದಲ ಮತ್ತು ಉಳಿದ ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಥವಾ ಅದು ಖಾಲಿಯಾಗಿದ್ದರೆ `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// ಸ್ಲೈಸ್‌ನ ಮೊದಲ ಮತ್ತು ಉಳಿದ ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಥವಾ ಅದು ಖಾಲಿಯಾಗಿದ್ದರೆ `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// ಸ್ಲೈಸ್‌ನ ಕೊನೆಯ ಮತ್ತು ಉಳಿದ ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಥವಾ ಅದು ಖಾಲಿಯಾಗಿದ್ದರೆ `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// ಸ್ಲೈಸ್‌ನ ಕೊನೆಯ ಮತ್ತು ಉಳಿದ ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಥವಾ ಅದು ಖಾಲಿಯಾಗಿದ್ದರೆ `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// ಸ್ಲೈಸ್‌ನ ಕೊನೆಯ ಅಂಶವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಥವಾ ಅದು ಖಾಲಿಯಾಗಿದ್ದರೆ `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// ಸ್ಲೈಸ್‌ನಲ್ಲಿನ ಕೊನೆಯ ಐಟಂಗೆ ರೂಪಾಂತರಿತ ಪಾಯಿಂಟರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// ಸೂಚ್ಯಂಕದ ಪ್ರಕಾರವನ್ನು ಅವಲಂಬಿಸಿ ಒಂದು ಅಂಶ ಅಥವಾ ಸಬ್‌ಲೈಸ್‌ಗೆ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// - ಸ್ಥಾನವನ್ನು ನೀಡಿದರೆ, ಆ ಸ್ಥಾನದಲ್ಲಿರುವ ಅಂಶಕ್ಕೆ ಉಲ್ಲೇಖವನ್ನು ಅಥವಾ ಮಿತಿ ಮೀರದಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// - ಒಂದು ಶ್ರೇಣಿಯನ್ನು ನೀಡಿದರೆ, ಆ ಶ್ರೇಣಿಗೆ ಅನುಗುಣವಾದ ಚಂದಾದಾರಿಕೆಯನ್ನು ಅಥವಾ ಮಿತಿ ಮೀರದಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// ಸೂಚ್ಯಂಕವು ಮಿತಿ ಮೀರಿದ್ದರೆ ಸೂಚ್ಯಂಕದ ಪ್ರಕಾರವನ್ನು ಅವಲಂಬಿಸಿ ([`get`] ನೋಡಿ) ಅಥವಾ `None` ಗೆ ಒಂದು ಅಂಶ ಅಥವಾ ಸಬ್‌ಲೈಸ್‌ಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// ಗಡಿ ಪರಿಶೀಲನೆ ಮಾಡದೆ, ಒಂದು ಅಂಶ ಅಥವಾ ಸಬ್‌ಲೈಸ್‌ಗೆ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಸುರಕ್ಷಿತ ಪರ್ಯಾಯಕ್ಕಾಗಿ [`get`] ನೋಡಿ.
    ///
    /// # Safety
    ///
    /// ಈ ವಿಧಾನವನ್ನು ಮಿತಿ ಮೀರದ ಸೂಚ್ಯಂಕದೊಂದಿಗೆ ಕರೆಯುವುದು *[ವಿವರಿಸಲಾಗದ ನಡವಳಿಕೆ]* ಫಲಿತಾಂಶದ ಉಲ್ಲೇಖವನ್ನು ಬಳಸದಿದ್ದರೂ ಸಹ.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `get_unchecked` ಗಾಗಿ ಹೆಚ್ಚಿನ ಸುರಕ್ಷತಾ ಅವಶ್ಯಕತೆಗಳನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು;
        // `self` ಸುರಕ್ಷಿತ ಉಲ್ಲೇಖವಾಗಿರುವುದರಿಂದ ಸ್ಲೈಸ್ ಡಿಫರೆನ್ಸೆಬಲ್ ಆಗಿದೆ.
        // ಹಿಂತಿರುಗಿದ ಪಾಯಿಂಟರ್ ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ `SliceIndex` ನ impls ಅದು ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು.
        unsafe { &*index.get_unchecked(self) }
    }

    /// ಗಡಿ ಪರಿಶೀಲನೆ ಮಾಡದೆ, ಒಂದು ಅಂಶ ಅಥವಾ ಸಬ್‌ಲೈಸ್‌ಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಸುರಕ್ಷಿತ ಪರ್ಯಾಯಕ್ಕಾಗಿ [`get_mut`] ನೋಡಿ.
    ///
    /// # Safety
    ///
    /// ಈ ವಿಧಾನವನ್ನು ಮಿತಿ ಮೀರದ ಸೂಚ್ಯಂಕದೊಂದಿಗೆ ಕರೆಯುವುದು *[ವಿವರಿಸಲಾಗದ ನಡವಳಿಕೆ]* ಫಲಿತಾಂಶದ ಉಲ್ಲೇಖವನ್ನು ಬಳಸದಿದ್ದರೂ ಸಹ.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `get_unchecked_mut` ಗಾಗಿ ಸುರಕ್ಷತಾ ಅವಶ್ಯಕತೆಗಳನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು;
        // `self` ಸುರಕ್ಷಿತ ಉಲ್ಲೇಖವಾಗಿರುವುದರಿಂದ ಸ್ಲೈಸ್ ಡಿಫರೆನ್ಸೆಬಲ್ ಆಗಿದೆ.
        // ಹಿಂತಿರುಗಿದ ಪಾಯಿಂಟರ್ ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ `SliceIndex` ನ impls ಅದು ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// ಸ್ಲೈಸ್‌ನ ಬಫರ್‌ಗೆ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಕಾರ್ಯವು ಹಿಂತಿರುಗಿಸುವ ಪಾಯಿಂಟರ್ ಅನ್ನು ಸ್ಲೈಸ್ ಮೀರಿಸುತ್ತದೆ ಎಂದು ಕರೆ ಮಾಡುವವರು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು, ಇಲ್ಲದಿದ್ದರೆ ಅದು ಕಸವನ್ನು ತೋರಿಸುತ್ತದೆ.
    ///
    /// ಈ ಪಾಯಿಂಟರ್ ಅಥವಾ ಅದರಿಂದ ಪಡೆದ ಯಾವುದೇ ಪಾಯಿಂಟರ್ ಅನ್ನು ಬಳಸಿಕೊಂಡು (non-transitively) ಪಾಯಿಂಟರ್ ಪಾಯಿಂಟರ್ ಮೆಮೊರಿಯನ್ನು ಎಂದಿಗೂ (`UnsafeCell` ಒಳಗೆ ಹೊರತುಪಡಿಸಿ) ಬರೆಯಲಾಗುವುದಿಲ್ಲ ಎಂದು ಕರೆ ಮಾಡುವವರು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು.
    /// ನೀವು ಸ್ಲೈಸ್‌ನ ವಿಷಯಗಳನ್ನು ರೂಪಾಂತರಿಸಬೇಕಾದರೆ, [`as_mut_ptr`] ಬಳಸಿ.
    ///
    /// ಈ ಸ್ಲೈಸ್‌ನಿಂದ ಉಲ್ಲೇಖಿಸಲಾದ ಕಂಟೇನರ್ ಅನ್ನು ಮಾರ್ಪಡಿಸುವುದರಿಂದ ಅದರ ಬಫರ್ ಅನ್ನು ಮರುಹಂಚಿಕೆ ಮಾಡಲು ಕಾರಣವಾಗಬಹುದು, ಅದು ಯಾವುದೇ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಅಮಾನ್ಯಗೊಳಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// ಸ್ಲೈಸ್‌ನ ಬಫರ್‌ಗೆ ಅಸುರಕ್ಷಿತ ರೂಪಾಂತರಿತ ಪಾಯಿಂಟರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಕಾರ್ಯವು ಹಿಂತಿರುಗಿಸುವ ಪಾಯಿಂಟರ್ ಅನ್ನು ಸ್ಲೈಸ್ ಮೀರಿಸುತ್ತದೆ ಎಂದು ಕರೆ ಮಾಡುವವರು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು, ಇಲ್ಲದಿದ್ದರೆ ಅದು ಕಸವನ್ನು ತೋರಿಸುತ್ತದೆ.
    ///
    /// ಈ ಸ್ಲೈಸ್‌ನಿಂದ ಉಲ್ಲೇಖಿಸಲಾದ ಕಂಟೇನರ್ ಅನ್ನು ಮಾರ್ಪಡಿಸುವುದರಿಂದ ಅದರ ಬಫರ್ ಅನ್ನು ಮರುಹಂಚಿಕೆ ಮಾಡಲು ಕಾರಣವಾಗಬಹುದು, ಅದು ಯಾವುದೇ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಅಮಾನ್ಯಗೊಳಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// ಸ್ಲೈಸ್ನಲ್ಲಿ ವ್ಯಾಪಿಸಿರುವ ಎರಡು ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಹಿಂತಿರುಗಿದ ಶ್ರೇಣಿ ಅರ್ಧ-ಮುಕ್ತವಾಗಿದೆ, ಇದರರ್ಥ ಎಂಡ್ ಪಾಯಿಂಟರ್ ಪಾಯಿಂಟ್‌ಗಳು *ಒಂದು ಹಿಂದಿನದು* ಸ್ಲೈಸ್‌ನ ಕೊನೆಯ ಅಂಶ.
    /// ಈ ರೀತಿಯಾಗಿ, ಖಾಲಿ ಸ್ಲೈಸ್ ಅನ್ನು ಎರಡು ಸಮಾನ ಪಾಯಿಂಟರ್‌ಗಳಿಂದ ಪ್ರತಿನಿಧಿಸಲಾಗುತ್ತದೆ, ಮತ್ತು ಎರಡು ಪಾಯಿಂಟರ್‌ಗಳ ನಡುವಿನ ವ್ಯತ್ಯಾಸವು ಸ್ಲೈಸ್‌ನ ಗಾತ್ರವನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
    ///
    /// ಈ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಬಳಸುವ ಎಚ್ಚರಿಕೆಗಳಿಗಾಗಿ [`as_ptr`] ನೋಡಿ.ಅಂತಿಮ ಪಾಯಿಂಟರ್‌ಗೆ ಹೆಚ್ಚುವರಿ ಎಚ್ಚರಿಕೆಯ ಅಗತ್ಯವಿರುತ್ತದೆ, ಏಕೆಂದರೆ ಅದು ಸ್ಲೈಸ್‌ನಲ್ಲಿ ಮಾನ್ಯ ಅಂಶವನ್ನು ಸೂಚಿಸುವುದಿಲ್ಲ.
    ///
    /// ಸಿ ++ ನಲ್ಲಿ ಸಾಮಾನ್ಯವಾಗಿರುವಂತೆ, ಮೆಮೊರಿಯಲ್ಲಿನ ಒಂದು ಶ್ರೇಣಿಯ ಅಂಶಗಳನ್ನು ಉಲ್ಲೇಖಿಸಲು ಎರಡು ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಬಳಸುವ ವಿದೇಶಿ ಇಂಟರ್ಫೇಸ್‌ಗಳೊಂದಿಗೆ ಸಂವಹನ ನಡೆಸಲು ಈ ಕಾರ್ಯವು ಉಪಯುಕ್ತವಾಗಿದೆ.
    ///
    ///
    /// ಒಂದು ಅಂಶಕ್ಕೆ ಪಾಯಿಂಟರ್ ಈ ಸ್ಲೈಸ್‌ನ ಒಂದು ಅಂಶವನ್ನು ಸೂಚಿಸುತ್ತದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸಲು ಸಹ ಇದು ಉಪಯುಕ್ತವಾಗಿದೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // ಸುರಕ್ಷತೆ: ಇಲ್ಲಿ `add` ಸುರಕ್ಷಿತವಾಗಿದೆ, ಏಕೆಂದರೆ:
        //
        //   - ಎರಡೂ ಪಾಯಿಂಟರ್‌ಗಳು ಒಂದೇ ವಸ್ತುವಿನ ಭಾಗವಾಗಿದೆ, ಏಕೆಂದರೆ ವಸ್ತುವನ್ನು ನೇರವಾಗಿ ಕಳೆದಂತೆ ಎಣಿಕೆ ಮಾಡುತ್ತದೆ.
        //
        //   - ಇಲ್ಲಿ ಗಮನಿಸಿದಂತೆ ಸ್ಲೈಸ್‌ನ ಗಾತ್ರವು ಎಂದಿಗೂ isize::MAX ಬೈಟ್‌ಗಳಿಗಿಂತ ದೊಡ್ಡದಲ್ಲ:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - ವಿಳಾಸದ ಸ್ಥಳದ ಕೊನೆಯಲ್ಲಿ ಚೂರುಗಳು ಸುತ್ತುವುದಿಲ್ಲವಾದ್ದರಿಂದ ಇದರಲ್ಲಿ ಯಾವುದೇ ಸುತ್ತುವರಿಯುವುದಿಲ್ಲ.
        //
        // pointer::add ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// ಸ್ಲೈಸ್‌ನಲ್ಲಿ ವ್ಯಾಪಿಸಿರುವ ಎರಡು ಅಸುರಕ್ಷಿತ ರೂಪಾಂತರಿತ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಹಿಂತಿರುಗಿದ ಶ್ರೇಣಿ ಅರ್ಧ-ಮುಕ್ತವಾಗಿದೆ, ಇದರರ್ಥ ಎಂಡ್ ಪಾಯಿಂಟರ್ ಪಾಯಿಂಟ್‌ಗಳು *ಒಂದು ಹಿಂದಿನದು* ಸ್ಲೈಸ್‌ನ ಕೊನೆಯ ಅಂಶ.
    /// ಈ ರೀತಿಯಾಗಿ, ಖಾಲಿ ಸ್ಲೈಸ್ ಅನ್ನು ಎರಡು ಸಮಾನ ಪಾಯಿಂಟರ್‌ಗಳಿಂದ ಪ್ರತಿನಿಧಿಸಲಾಗುತ್ತದೆ, ಮತ್ತು ಎರಡು ಪಾಯಿಂಟರ್‌ಗಳ ನಡುವಿನ ವ್ಯತ್ಯಾಸವು ಸ್ಲೈಸ್‌ನ ಗಾತ್ರವನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
    ///
    /// ಈ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಬಳಸುವ ಎಚ್ಚರಿಕೆಗಳಿಗಾಗಿ [`as_mut_ptr`] ನೋಡಿ.
    /// ಅಂತಿಮ ಪಾಯಿಂಟರ್‌ಗೆ ಹೆಚ್ಚುವರಿ ಎಚ್ಚರಿಕೆಯ ಅಗತ್ಯವಿರುತ್ತದೆ, ಏಕೆಂದರೆ ಅದು ಸ್ಲೈಸ್‌ನಲ್ಲಿ ಮಾನ್ಯ ಅಂಶವನ್ನು ಸೂಚಿಸುವುದಿಲ್ಲ.
    ///
    /// ಸಿ ++ ನಲ್ಲಿ ಸಾಮಾನ್ಯವಾಗಿರುವಂತೆ, ಮೆಮೊರಿಯಲ್ಲಿನ ಒಂದು ಶ್ರೇಣಿಯ ಅಂಶಗಳನ್ನು ಉಲ್ಲೇಖಿಸಲು ಎರಡು ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಬಳಸುವ ವಿದೇಶಿ ಇಂಟರ್ಫೇಸ್‌ಗಳೊಂದಿಗೆ ಸಂವಹನ ನಡೆಸಲು ಈ ಕಾರ್ಯವು ಉಪಯುಕ್ತವಾಗಿದೆ.
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // ಸುರಕ್ಷತೆ: ಇಲ್ಲಿ `add` ಏಕೆ ಸುರಕ್ಷಿತವಾಗಿದೆ ಎಂಬುದಕ್ಕೆ ಮೇಲಿನ as_ptr_range() ನೋಡಿ.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// ಸ್ಲೈಸ್‌ನಲ್ಲಿ ಎರಡು ಅಂಶಗಳನ್ನು ಬದಲಾಯಿಸುತ್ತದೆ.
    ///
    /// # Arguments
    ///
    /// * a, ಮೊದಲ ಅಂಶದ ಸೂಚ್ಯಂಕ
    /// * b, ಎರಡನೇ ಅಂಶದ ಸೂಚ್ಯಂಕ
    ///
    /// # Panics
    ///
    /// `a` ಅಥವಾ `b` ಮಿತಿ ಮೀರದಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // ಒಂದು vector ನಿಂದ ಎರಡು ರೂಪಾಂತರಿತ ಸಾಲಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳಲು ಸಾಧ್ಯವಿಲ್ಲ, ಆದ್ದರಿಂದ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಬಳಸಿ.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // ಸುರಕ್ಷತೆ: ಸುರಕ್ಷಿತ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳಿಂದ `pa` ಮತ್ತು `pb` ಅನ್ನು ರಚಿಸಲಾಗಿದೆ ಮತ್ತು ಉಲ್ಲೇಖಿಸಿ
        // ಸ್ಲೈಸ್‌ನಲ್ಲಿರುವ ಅಂಶಗಳಿಗೆ ಮತ್ತು ಆದ್ದರಿಂದ ಮಾನ್ಯ ಮತ್ತು ಜೋಡಣೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗುತ್ತದೆ.
        // `a` ಮತ್ತು `b` ನ ಹಿಂದಿನ ಅಂಶಗಳನ್ನು ಪ್ರವೇಶಿಸುವುದನ್ನು ಪರಿಶೀಲಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ಮಿತಿ ಮೀರಿದಾಗ panic ಆಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// ಸ್ಲೈಸ್‌ನಲ್ಲಿರುವ ಅಂಶಗಳ ಕ್ರಮವನ್ನು ಸ್ಥಳದಲ್ಲಿ ಹಿಮ್ಮುಖಗೊಳಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // ಬಹಳ ಸಣ್ಣ ಪ್ರಕಾರಗಳಿಗೆ, ಸಾಮಾನ್ಯ ಹಾದಿಯಲ್ಲಿರುವ ಎಲ್ಲಾ ವೈಯಕ್ತಿಕ ಓದುವಿಕೆಗಳು ಕಳಪೆಯಾಗಿ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತವೆ.
        // ದೊಡ್ಡದಾದ ಭಾಗವನ್ನು ಲೋಡ್ ಮಾಡುವ ಮೂಲಕ ಮತ್ತು ರಿಜಿಸ್ಟರ್ ಅನ್ನು ಹಿಮ್ಮುಖಗೊಳಿಸುವ ಮೂಲಕ ನಾವು ಸಮರ್ಥವಾಗಿ ಜೋಡಿಸದ load/store ಅನ್ನು ಉತ್ತಮವಾಗಿ ಮಾಡಬಹುದು.
        //

        // ತಾತ್ತ್ವಿಕವಾಗಿ ಎಲ್ಎಲ್ವಿಎಂ ನಮಗೆ ಇದನ್ನು ಮಾಡುತ್ತದೆ, ಏಕೆಂದರೆ ಜೋಡಿಸದ ವಾಚನಗೋಷ್ಠಿಗಳು ಪರಿಣಾಮಕಾರಿಯಾಗಿದೆಯೆ ಎಂದು ನಮಗೆ ತಿಳಿದಿರುವುದರಿಂದ (ವಿಭಿನ್ನ ಎಆರ್ಎಂ ಆವೃತ್ತಿಗಳ ನಡುವಿನ ಬದಲಾವಣೆಗಳಿಂದಾಗಿ, ಉದಾಹರಣೆಗೆ) ಮತ್ತು ಉತ್ತಮ ಚಂಕ್ ಗಾತ್ರ ಯಾವುದು.
        // ದುರದೃಷ್ಟವಶಾತ್, LLVM 4.0 (2017-05) ನಂತೆ ಇದು ಲೂಪ್ ಅನ್ನು ಮಾತ್ರ ಅನ್ರೋಲ್ ಮಾಡುತ್ತದೆ, ಆದ್ದರಿಂದ ನಾವು ಇದನ್ನು ನಾವೇ ಮಾಡಬೇಕಾಗಿದೆ.
        // (ಕಲ್ಪನೆ: ರಿವರ್ಸ್ ತೊಂದರೆಯಾಗಿದೆ ಏಕೆಂದರೆ ಬದಿಗಳನ್ನು ವಿಭಿನ್ನವಾಗಿ ಜೋಡಿಸಬಹುದು-ಉದ್ದವು ಬೆಸವಾಗಿದ್ದಾಗ ಇರುತ್ತದೆ-ಆದ್ದರಿಂದ ಮಧ್ಯದಲ್ಲಿ ಪೂರ್ಣವಾಗಿ ಜೋಡಿಸಲಾದ ಸಿಮ್‌ಡಿಯನ್ನು ಬಳಸಲು ಪೂರ್ವ ಮತ್ತು ಪೋಸ್ಟ್‌ಲುಡ್‌ಗಳನ್ನು ಹೊರಸೂಸುವ ಯಾವುದೇ ಮಾರ್ಗವಿಲ್ಲ.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // ಯುಸೈಜ್ನಲ್ಲಿ ಯು 8 ಗಳನ್ನು ರಿವರ್ಸ್ ಮಾಡಲು ಎಕ್ಸ್ 00 ಎಕ್ಸ್ ಆಂತರಿಕ ಬಳಸಿ
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // ಸುರಕ್ಷತೆ: ಇಲ್ಲಿ ಪರಿಶೀಲಿಸಲು ಹಲವಾರು ವಿಷಯಗಳಿವೆ:
                //
                // - ಮೇಲಿನ ಸಿಎಫ್‌ಜಿ ಪರಿಶೀಲನೆಯಿಂದಾಗಿ `chunk` 4 ಅಥವಾ 8 ಆಗಿರುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.ಆದ್ದರಿಂದ `chunk - 1` ಧನಾತ್ಮಕವಾಗಿರುತ್ತದೆ.
                // - ಲೂಪ್ ಚೆಕ್ ಖಾತರಿಪಡಿಸಿದಂತೆ ಸೂಚ್ಯಂಕ `i` ನೊಂದಿಗೆ ಸೂಚಿಕೆ ಉತ್ತಮವಾಗಿದೆ
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - ಸೂಚ್ಯಂಕ `ln - i - chunk = ln - (i + chunk)` ನೊಂದಿಗೆ ಸೂಚ್ಯಂಕವು ಉತ್ತಮವಾಗಿದೆ:
                //   - `i + chunk > 0` ಕ್ಷುಲ್ಲಕವಾಗಿ ನಿಜ.
                //   - ಲೂಪ್ ಚೆಕ್ ಗ್ಯಾರಂಟಿ:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, ಆದ್ದರಿಂದ ವ್ಯವಕಲನವು ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ.
                // - `read_unaligned` ಮತ್ತು `write_unaligned` ಕರೆಗಳು ಉತ್ತಮವಾಗಿವೆ:
                //   - `pa` ಸೂಚ್ಯಂಕ `i` ಗೆ ಸೂಚಿಸುತ್ತದೆ, ಅಲ್ಲಿ `i < ln / 2 - (chunk - 1)` (ಮೇಲೆ ನೋಡಿ) ಮತ್ತು `pb` ಸೂಚ್ಯಂಕ `ln - i - chunk` ಗೆ ಸೂಚಿಸುತ್ತದೆ, ಆದ್ದರಿಂದ ಎರಡೂ `self` ನ ಅಂತ್ಯದಿಂದ ಕನಿಷ್ಠ `chunk` ಅನೇಕ ಬೈಟ್‌ಗಳಷ್ಟು ದೂರದಲ್ಲಿರುತ್ತವೆ.
                //
                //   - ಯಾವುದೇ ಪ್ರಾರಂಭಿಕ ಮೆಮೊರಿ ಮಾನ್ಯ `usize` ಆಗಿದೆ.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // u32 ನಲ್ಲಿ u16 ಗಳನ್ನು ರಿವರ್ಸ್ ಮಾಡಲು ತಿರುಗಿಸು-16 ಬಳಸಿ
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // ಸುರಕ್ಷತೆ: ಜೋಡಿಸದ u32 ಅನ್ನು `i + 1 < ln` ಆಗಿದ್ದರೆ `i` ನಿಂದ ಓದಬಹುದು
                // (ಮತ್ತು ನಿಸ್ಸಂಶಯವಾಗಿ `i < ln`), ಏಕೆಂದರೆ ಪ್ರತಿಯೊಂದು ಅಂಶವು 2 ಬೈಟ್‌ಗಳು ಮತ್ತು ನಾವು 4 ಓದುತ್ತಿದ್ದೇವೆ.
                //
                // `i + chunk - 1 < ln / 2` # ಸ್ಥಿತಿಯಲ್ಲಿರುವಾಗ
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // ಇದು 2 ರಿಂದ ಭಾಗಿಸಲ್ಪಟ್ಟ ಉದ್ದಕ್ಕಿಂತ ಕಡಿಮೆ ಇರುವುದರಿಂದ, ಅದು ಮಿತಿಯಲ್ಲಿರಬೇಕು.
                //
                // ಇದರರ್ಥ `0 < i + chunk <= ln` ಸ್ಥಿತಿಯನ್ನು ಯಾವಾಗಲೂ ಗೌರವಿಸಲಾಗುತ್ತದೆ, `pb` ಪಾಯಿಂಟರ್ ಅನ್ನು ಸುರಕ್ಷಿತವಾಗಿ ಬಳಸಬಹುದೆಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // ಸುರಕ್ಷತೆ: `i` ಸ್ಲೈಸ್‌ನ ಅರ್ಧದಷ್ಟು ಉದ್ದಕ್ಕಿಂತ ಕೆಳಮಟ್ಟದ್ದಾಗಿದೆ
            // `i` ಮತ್ತು `ln - i - 1` ಅನ್ನು ಪ್ರವೇಶಿಸುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ (`i` 0 ರಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ ಮತ್ತು `ln / 2 - 1` ಗಿಂತ ಹೆಚ್ಚು ಹೋಗುವುದಿಲ್ಲ).
            // ಪರಿಣಾಮವಾಗಿ ಸೂಚಕಗಳು `pa` ಮತ್ತು `pb` ಆದ್ದರಿಂದ ಮಾನ್ಯ ಮತ್ತು ಜೋಡಿಸಲ್ಪಟ್ಟಿವೆ, ಮತ್ತು ಅದನ್ನು ಓದಬಹುದು ಮತ್ತು ಬರೆಯಬಹುದು.
            //
            //
            unsafe {
                // ಸುರಕ್ಷಿತ ಸ್ವಾಪ್ನಲ್ಲಿ ಗಡಿ ಪರಿಶೀಲನೆಯನ್ನು ತಪ್ಪಿಸಲು ಅಸುರಕ್ಷಿತ ಸ್ವಾಪ್.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// ಸ್ಲೈಸ್‌ನ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// ಪ್ರತಿ ಮೌಲ್ಯವನ್ನು ಮಾರ್ಪಡಿಸಲು ಅನುಮತಿಸುವ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// `size` ಉದ್ದದ ಎಲ್ಲಾ windows ಉದ್ದದ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// windows ಅತಿಕ್ರಮಿಸುತ್ತದೆ.
    /// ಸ್ಲೈಸ್ `size` ಗಿಂತ ಚಿಕ್ಕದಾಗಿದ್ದರೆ, ಪುನರಾವರ್ತಕ ಯಾವುದೇ ಮೌಲ್ಯಗಳನ್ನು ನೀಡುವುದಿಲ್ಲ.
    ///
    /// # Panics
    ///
    /// `size` 0 ಆಗಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// ಸ್ಲೈಸ್ `size` ಗಿಂತ ಚಿಕ್ಕದಾಗಿದ್ದರೆ:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದಿಂದ ಪ್ರಾರಂಭವಾಗುವ ಒಂದು ಸಮಯದಲ್ಲಿ ಸ್ಲೈಸ್‌ನ `chunk_size` ಅಂಶಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಭಾಗಗಳು ಚೂರುಗಳಾಗಿವೆ ಮತ್ತು ಅತಿಕ್ರಮಿಸುವುದಿಲ್ಲ.`chunk_size` ಸ್ಲೈಸ್‌ನ ಉದ್ದವನ್ನು ಭಾಗಿಸದಿದ್ದರೆ, ಕೊನೆಯ ಚಂಕ್ ಉದ್ದ `chunk_size` ಅನ್ನು ಹೊಂದಿರುವುದಿಲ್ಲ.
    ///
    /// ಈ ಪುನರಾವರ್ತಕದ ರೂಪಾಂತರಕ್ಕಾಗಿ [`chunks_exact`] ಅನ್ನು ನೋಡಿ, ಅದು ಯಾವಾಗಲೂ ನಿಖರವಾಗಿ `chunk_size` ಅಂಶಗಳ ಭಾಗಗಳನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಮತ್ತು ಅದೇ ಪುನರಾವರ್ತಕಕ್ಕಾಗಿ [`rchunks`] ಆದರೆ ಸ್ಲೈಸ್‌ನ ಕೊನೆಯಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 ಆಗಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದಿಂದ ಪ್ರಾರಂಭವಾಗುವ ಒಂದು ಸಮಯದಲ್ಲಿ ಸ್ಲೈಸ್‌ನ `chunk_size` ಅಂಶಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಭಾಗಗಳು ರೂಪಾಂತರಗೊಳ್ಳುವ ಚೂರುಗಳಾಗಿವೆ, ಮತ್ತು ಅತಿಕ್ರಮಿಸುವುದಿಲ್ಲ.`chunk_size` ಸ್ಲೈಸ್‌ನ ಉದ್ದವನ್ನು ಭಾಗಿಸದಿದ್ದರೆ, ಕೊನೆಯ ಚಂಕ್ ಉದ್ದ `chunk_size` ಅನ್ನು ಹೊಂದಿರುವುದಿಲ್ಲ.
    ///
    /// ಈ ಪುನರಾವರ್ತಕದ ರೂಪಾಂತರಕ್ಕಾಗಿ [`chunks_exact_mut`] ಅನ್ನು ನೋಡಿ, ಅದು ಯಾವಾಗಲೂ ನಿಖರವಾಗಿ `chunk_size` ಅಂಶಗಳ ಭಾಗಗಳನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಮತ್ತು ಅದೇ ಪುನರಾವರ್ತಕಕ್ಕಾಗಿ [`rchunks_mut`] ಆದರೆ ಸ್ಲೈಸ್‌ನ ಕೊನೆಯಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 ಆಗಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದಿಂದ ಪ್ರಾರಂಭವಾಗುವ ಒಂದು ಸಮಯದಲ್ಲಿ ಸ್ಲೈಸ್‌ನ `chunk_size` ಅಂಶಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಭಾಗಗಳು ಚೂರುಗಳಾಗಿವೆ ಮತ್ತು ಅತಿಕ್ರಮಿಸುವುದಿಲ್ಲ.
    /// `chunk_size` ಸ್ಲೈಸ್‌ನ ಉದ್ದವನ್ನು ಭಾಗಿಸದಿದ್ದರೆ, ನಂತರ `chunk_size-1` ವರೆಗಿನ ಕೊನೆಯ ಅಂಶಗಳನ್ನು ಬಿಟ್ಟುಬಿಡಲಾಗುತ್ತದೆ ಮತ್ತು ಪುನರಾವರ್ತಕದ `remainder` ಕಾರ್ಯದಿಂದ ಹಿಂಪಡೆಯಬಹುದು.
    ///
    ///
    /// ಪ್ರತಿ ಚಂಕ್ ನಿಖರವಾಗಿ `chunk_size` ಅಂಶಗಳನ್ನು ಹೊಂದಿರುವುದರಿಂದ, ಕಂಪೈಲರ್ ಆಗಾಗ್ಗೆ ಫಲಿತಾಂಶದ ಕೋಡ್ ಅನ್ನು [`chunks`] ಗಿಂತ ಉತ್ತಮವಾಗಿ ಉತ್ತಮಗೊಳಿಸಬಹುದು.
    ///
    /// ಈ ಪುನರಾವರ್ತಕದ ರೂಪಾಂತರಕ್ಕಾಗಿ [`chunks`] ಅನ್ನು ನೋಡಿ, ಅದು ಉಳಿದ ಭಾಗವನ್ನು ಸಣ್ಣ ಭಾಗವಾಗಿ ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಮತ್ತು ಅದೇ ಪುನರಾವರ್ತಕಕ್ಕಾಗಿ [`rchunks_exact`] ಆದರೆ ಸ್ಲೈಸ್‌ನ ಕೊನೆಯಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 ಆಗಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದಿಂದ ಪ್ರಾರಂಭವಾಗುವ ಒಂದು ಸಮಯದಲ್ಲಿ ಸ್ಲೈಸ್‌ನ `chunk_size` ಅಂಶಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಭಾಗಗಳು ರೂಪಾಂತರಗೊಳ್ಳುವ ಚೂರುಗಳಾಗಿವೆ, ಮತ್ತು ಅತಿಕ್ರಮಿಸುವುದಿಲ್ಲ.
    /// `chunk_size` ಸ್ಲೈಸ್‌ನ ಉದ್ದವನ್ನು ಭಾಗಿಸದಿದ್ದರೆ, ನಂತರ `chunk_size-1` ವರೆಗಿನ ಕೊನೆಯ ಅಂಶಗಳನ್ನು ಬಿಟ್ಟುಬಿಡಲಾಗುತ್ತದೆ ಮತ್ತು ಪುನರಾವರ್ತಕದ `into_remainder` ಕಾರ್ಯದಿಂದ ಹಿಂಪಡೆಯಬಹುದು.
    ///
    ///
    /// ಪ್ರತಿ ಚಂಕ್ ನಿಖರವಾಗಿ `chunk_size` ಅಂಶಗಳನ್ನು ಹೊಂದಿರುವುದರಿಂದ, ಕಂಪೈಲರ್ ಆಗಾಗ್ಗೆ ಫಲಿತಾಂಶದ ಕೋಡ್ ಅನ್ನು [`chunks_mut`] ಗಿಂತ ಉತ್ತಮವಾಗಿ ಉತ್ತಮಗೊಳಿಸಬಹುದು.
    ///
    /// ಈ ಪುನರಾವರ್ತಕದ ರೂಪಾಂತರಕ್ಕಾಗಿ [`chunks_mut`] ಅನ್ನು ನೋಡಿ, ಅದು ಉಳಿದ ಭಾಗವನ್ನು ಸಣ್ಣ ಭಾಗವಾಗಿ ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಮತ್ತು ಅದೇ ಪುನರಾವರ್ತಕಕ್ಕಾಗಿ [`rchunks_exact_mut`] ಆದರೆ ಸ್ಲೈಸ್‌ನ ಕೊನೆಯಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 ಆಗಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// ಸ್ಲೈಸ್ ಅನ್ನು `ಎನ್`-ಎಲಿಮೆಂಟ್ ಅರೇಗಳ ಸ್ಲೈಸ್‌ಗೆ ವಿಭಜಿಸುತ್ತದೆ, ಉಳಿದಿಲ್ಲ ಎಂದು uming ಹಿಸಿ.
    ///
    ///
    /// # Safety
    ///
    /// ಇದನ್ನು ಯಾವಾಗ ಎಂದು ಕರೆಯಬಹುದು
    /// - ಸ್ಲೈಸ್ ನಿಖರವಾಗಿ `N`-ಅಂಶ ಭಾಗಗಳಾಗಿ (ಅಕಾ `self.len() % N == 0`)) ವಿಭಜಿಸುತ್ತದೆ.
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // ಸುರಕ್ಷತೆ: 1-ಅಂಶದ ಭಾಗಗಳಲ್ಲಿ ಎಂದಿಗೂ ಉಳಿದಿಲ್ಲ
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // ಸುರಕ್ಷತೆ: ಸ್ಲೈಸ್ ಉದ್ದ (6) 3 ರ ಗುಣಾಕಾರವಾಗಿದೆ
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // ಇವುಗಳು ಅಸ್ಪಷ್ಟವಾಗಿರುತ್ತವೆ:
    /// // ಭಾಗಗಳನ್ನು ಬಿಡಿ: &[[_;5]]= slice.as_chunks_unchecked()//ಸ್ಲೈಸ್ ಉದ್ದವು 5 ಲೆಟ್ ಭಾಗಗಳ ಗುಣಾಕಾರವಲ್ಲ:&[[_;0]]= slice.as_chunks_unchecked()//ಶೂನ್ಯ-ಉದ್ದದ ಭಾಗಗಳನ್ನು ಎಂದಿಗೂ ಅನುಮತಿಸಲಾಗುವುದಿಲ್ಲ
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // ಸುರಕ್ಷತೆ: ಇದನ್ನು ಕರೆಯಲು ನಮ್ಮ ಪೂರ್ವಭಾವಿ ಷರತ್ತು ನಿಖರವಾಗಿ ಬೇಕಾಗುತ್ತದೆ
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // ಸುರಕ್ಷತೆ: ನಾವು `new_len * N` ಅಂಶಗಳ ಸ್ಲೈಸ್ ಅನ್ನು ಹಾಕುತ್ತೇವೆ
        // `new_len` ನ ಒಂದು ಸ್ಲೈಸ್ ಅನೇಕ `N` ಅಂಶಗಳ ಭಾಗಗಳು.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// ಸ್ಲೈಸ್ ಅನ್ನು `N`-ಎಲಿಮೆಂಟ್ ಅರೇಗಳ ಸ್ಲೈಸ್‌ಗೆ ವಿಭಜಿಸುತ್ತದೆ, ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ ಮತ್ತು ಉಳಿದ ಸ್ಲೈಸ್ `N` ಗಿಂತ ಕಡಿಮೆ ಉದ್ದವನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    ///
    ///
    /// # Panics
    ///
    /// `N` 0 ಆಗಿದ್ದರೆ Panics. ಈ ವಿಧಾನವು ಸ್ಥಿರಗೊಳ್ಳುವ ಮೊದಲು ಈ ಪರಿಶೀಲನೆಯು ಕಂಪೈಲ್ ಸಮಯದ ದೋಷಕ್ಕೆ ಬದಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // ಸುರಕ್ಷತೆ: ನಾವು ಈಗಾಗಲೇ ಶೂನ್ಯಕ್ಕಾಗಿ ಭಯಭೀತರಾಗಿದ್ದೇವೆ ಮತ್ತು ನಿರ್ಮಾಣದಿಂದ ಖಾತ್ರಿಪಡಿಸಿಕೊಂಡಿದ್ದೇವೆ
        // ಚಂದಾದಾರಿಕೆಯ ಉದ್ದವು N ನ ಬಹುಸಂಖ್ಯೆಯಾಗಿದೆ.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// ಸ್ಲೈಸ್ ಅನ್ನು `N`-ಎಲಿಮೆಂಟ್ ಅರೇಗಳ ಸ್ಲೈಸ್‌ಗೆ ವಿಭಜಿಸುತ್ತದೆ, ಸ್ಲೈಸ್‌ನ ಕೊನೆಯಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ ಮತ್ತು ಉಳಿದ ಸ್ಲೈಸ್ `N` ಗಿಂತ ಕಡಿಮೆ ಉದ್ದವನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    ///
    ///
    /// # Panics
    ///
    /// `N` 0 ಆಗಿದ್ದರೆ Panics. ಈ ವಿಧಾನವು ಸ್ಥಿರಗೊಳ್ಳುವ ಮೊದಲು ಈ ಪರಿಶೀಲನೆಯು ಕಂಪೈಲ್ ಸಮಯದ ದೋಷಕ್ಕೆ ಬದಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // ಸುರಕ್ಷತೆ: ನಾವು ಈಗಾಗಲೇ ಶೂನ್ಯಕ್ಕಾಗಿ ಭಯಭೀತರಾಗಿದ್ದೇವೆ ಮತ್ತು ನಿರ್ಮಾಣದಿಂದ ಖಾತ್ರಿಪಡಿಸಿಕೊಂಡಿದ್ದೇವೆ
        // ಚಂದಾದಾರಿಕೆಯ ಉದ್ದವು N ನ ಬಹುಸಂಖ್ಯೆಯಾಗಿದೆ.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದಿಂದ ಪ್ರಾರಂಭವಾಗುವ ಒಂದು ಸಮಯದಲ್ಲಿ ಸ್ಲೈಸ್‌ನ `N` ಅಂಶಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಭಾಗಗಳು ರಚನೆಯ ಉಲ್ಲೇಖಗಳಾಗಿವೆ ಮತ್ತು ಅತಿಕ್ರಮಿಸುವುದಿಲ್ಲ.
    /// `N` ಸ್ಲೈಸ್‌ನ ಉದ್ದವನ್ನು ಭಾಗಿಸದಿದ್ದರೆ, ನಂತರ `N-1` ವರೆಗಿನ ಕೊನೆಯ ಅಂಶಗಳನ್ನು ಬಿಟ್ಟುಬಿಡಲಾಗುತ್ತದೆ ಮತ್ತು ಪುನರಾವರ್ತಕದ `remainder` ಕಾರ್ಯದಿಂದ ಹಿಂಪಡೆಯಬಹುದು.
    ///
    ///
    /// ಈ ವಿಧಾನವು [`chunks_exact`] ಗೆ ಸಮಾನವಾದ ಸಾಮಾನ್ಯವಾಗಿದೆ.
    ///
    /// # Panics
    ///
    /// `N` 0 ಆಗಿದ್ದರೆ Panics. ಈ ವಿಧಾನವು ಸ್ಥಿರಗೊಳ್ಳುವ ಮೊದಲು ಈ ಪರಿಶೀಲನೆಯು ಕಂಪೈಲ್ ಸಮಯದ ದೋಷಕ್ಕೆ ಬದಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// ಸ್ಲೈಸ್ ಅನ್ನು `ಎನ್`-ಎಲಿಮೆಂಟ್ ಅರೇಗಳ ಸ್ಲೈಸ್‌ಗೆ ವಿಭಜಿಸುತ್ತದೆ, ಉಳಿದಿಲ್ಲ ಎಂದು uming ಹಿಸಿ.
    ///
    ///
    /// # Safety
    ///
    /// ಇದನ್ನು ಯಾವಾಗ ಎಂದು ಕರೆಯಬಹುದು
    /// - ಸ್ಲೈಸ್ ನಿಖರವಾಗಿ `N`-ಅಂಶ ಭಾಗಗಳಾಗಿ (ಅಕಾ `self.len() % N == 0`)) ವಿಭಜಿಸುತ್ತದೆ.
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // ಸುರಕ್ಷತೆ: 1-ಅಂಶದ ಭಾಗಗಳಲ್ಲಿ ಎಂದಿಗೂ ಉಳಿದಿಲ್ಲ
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // ಸುರಕ್ಷತೆ: ಸ್ಲೈಸ್ ಉದ್ದ (6) 3 ರ ಗುಣಾಕಾರವಾಗಿದೆ
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // ಇವುಗಳು ಅಸ್ಪಷ್ಟವಾಗಿರುತ್ತವೆ:
    /// // ಭಾಗಗಳನ್ನು ಬಿಡಿ: &[[_;5]]= slice.as_chunks_unchecked_mut()//ಸ್ಲೈಸ್ ಉದ್ದವು 5 ಲೆಟ್ ಭಾಗಗಳ ಗುಣಾಕಾರವಲ್ಲ:&[[_ _;0]]= slice.as_chunks_unchecked_mut()//ಶೂನ್ಯ-ಉದ್ದದ ಭಾಗಗಳನ್ನು ಎಂದಿಗೂ ಅನುಮತಿಸಲಾಗುವುದಿಲ್ಲ
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // ಸುರಕ್ಷತೆ: ಇದನ್ನು ಕರೆಯಲು ನಮ್ಮ ಪೂರ್ವಭಾವಿ ಷರತ್ತು ನಿಖರವಾಗಿ ಬೇಕಾಗುತ್ತದೆ
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // ಸುರಕ್ಷತೆ: ನಾವು `new_len * N` ಅಂಶಗಳ ಸ್ಲೈಸ್ ಅನ್ನು ಹಾಕುತ್ತೇವೆ
        // `new_len` ನ ಒಂದು ಸ್ಲೈಸ್ ಅನೇಕ `N` ಅಂಶಗಳ ಭಾಗಗಳು.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// ಸ್ಲೈಸ್ ಅನ್ನು `N`-ಎಲಿಮೆಂಟ್ ಅರೇಗಳ ಸ್ಲೈಸ್‌ಗೆ ವಿಭಜಿಸುತ್ತದೆ, ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ ಮತ್ತು ಉಳಿದ ಸ್ಲೈಸ್ `N` ಗಿಂತ ಕಡಿಮೆ ಉದ್ದವನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    ///
    ///
    /// # Panics
    ///
    /// `N` 0 ಆಗಿದ್ದರೆ Panics. ಈ ವಿಧಾನವು ಸ್ಥಿರಗೊಳ್ಳುವ ಮೊದಲು ಈ ಪರಿಶೀಲನೆಯು ಕಂಪೈಲ್ ಸಮಯದ ದೋಷಕ್ಕೆ ಬದಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // ಸುರಕ್ಷತೆ: ನಾವು ಈಗಾಗಲೇ ಶೂನ್ಯಕ್ಕಾಗಿ ಭಯಭೀತರಾಗಿದ್ದೇವೆ ಮತ್ತು ನಿರ್ಮಾಣದಿಂದ ಖಾತ್ರಿಪಡಿಸಿಕೊಂಡಿದ್ದೇವೆ
        // ಚಂದಾದಾರಿಕೆಯ ಉದ್ದವು N ನ ಬಹುಸಂಖ್ಯೆಯಾಗಿದೆ.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// ಸ್ಲೈಸ್ ಅನ್ನು `N`-ಎಲಿಮೆಂಟ್ ಅರೇಗಳ ಸ್ಲೈಸ್‌ಗೆ ವಿಭಜಿಸುತ್ತದೆ, ಸ್ಲೈಸ್‌ನ ಕೊನೆಯಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ ಮತ್ತು ಉಳಿದ ಸ್ಲೈಸ್ `N` ಗಿಂತ ಕಡಿಮೆ ಉದ್ದವನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    ///
    ///
    /// # Panics
    ///
    /// `N` 0 ಆಗಿದ್ದರೆ Panics. ಈ ವಿಧಾನವು ಸ್ಥಿರಗೊಳ್ಳುವ ಮೊದಲು ಈ ಪರಿಶೀಲನೆಯು ಕಂಪೈಲ್ ಸಮಯದ ದೋಷಕ್ಕೆ ಬದಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // ಸುರಕ್ಷತೆ: ನಾವು ಈಗಾಗಲೇ ಶೂನ್ಯಕ್ಕಾಗಿ ಭಯಭೀತರಾಗಿದ್ದೇವೆ ಮತ್ತು ನಿರ್ಮಾಣದಿಂದ ಖಾತ್ರಿಪಡಿಸಿಕೊಂಡಿದ್ದೇವೆ
        // ಚಂದಾದಾರಿಕೆಯ ಉದ್ದವು N ನ ಬಹುಸಂಖ್ಯೆಯಾಗಿದೆ.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದಿಂದ ಪ್ರಾರಂಭವಾಗುವ ಒಂದು ಸಮಯದಲ್ಲಿ ಸ್ಲೈಸ್‌ನ `N` ಅಂಶಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಭಾಗಗಳು ರೂಪಾಂತರಗೊಳ್ಳುವ ರಚನೆಯ ಉಲ್ಲೇಖಗಳಾಗಿವೆ ಮತ್ತು ಅತಿಕ್ರಮಿಸುವುದಿಲ್ಲ.
    /// `N` ಸ್ಲೈಸ್‌ನ ಉದ್ದವನ್ನು ಭಾಗಿಸದಿದ್ದರೆ, ನಂತರ `N-1` ವರೆಗಿನ ಕೊನೆಯ ಅಂಶಗಳನ್ನು ಬಿಟ್ಟುಬಿಡಲಾಗುತ್ತದೆ ಮತ್ತು ಪುನರಾವರ್ತಕದ `into_remainder` ಕಾರ್ಯದಿಂದ ಹಿಂಪಡೆಯಬಹುದು.
    ///
    ///
    /// ಈ ವಿಧಾನವು [`chunks_exact_mut`] ಗೆ ಸಮಾನವಾದ ಸಾಮಾನ್ಯವಾಗಿದೆ.
    ///
    /// # Panics
    ///
    /// `N` 0 ಆಗಿದ್ದರೆ Panics. ಈ ವಿಧಾನವು ಸ್ಥಿರಗೊಳ್ಳುವ ಮೊದಲು ಈ ಪರಿಶೀಲನೆಯು ಕಂಪೈಲ್ ಸಮಯದ ದೋಷಕ್ಕೆ ಬದಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// ಸ್ಲೈಸ್‌ನ `N` ಅಂಶಗಳ windows ಅನ್ನು ಅತಿಕ್ರಮಿಸುವ ಮೂಲಕ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ.
    ///
    ///
    /// ಇದು [`windows`] ಗೆ ಸಮಾನವಾದ ಸಾಮಾನ್ಯವಾಗಿದೆ.
    ///
    /// `N` ಸ್ಲೈಸ್‌ನ ಗಾತ್ರಕ್ಕಿಂತ ಹೆಚ್ಚಿದ್ದರೆ, ಅದು ಯಾವುದೇ windows ಅನ್ನು ಹಿಂತಿರುಗಿಸುವುದಿಲ್ಲ.
    ///
    /// # Panics
    ///
    /// `N` 0 ಆಗಿದ್ದರೆ Panics.
    /// ಈ ವಿಧಾನವು ಸ್ಥಿರಗೊಳ್ಳುವ ಮೊದಲು ಈ ಪರಿಶೀಲನೆಯು ಕಂಪೈಲ್ ಸಮಯದ ದೋಷಕ್ಕೆ ಬದಲಾಗಬಹುದು.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// ಸ್ಲೈಸ್‌ನ ಕೊನೆಯಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುವ ಒಂದು ಸಮಯದಲ್ಲಿ ಸ್ಲೈಸ್‌ನ `chunk_size` ಅಂಶಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಭಾಗಗಳು ಚೂರುಗಳಾಗಿವೆ ಮತ್ತು ಅತಿಕ್ರಮಿಸುವುದಿಲ್ಲ.`chunk_size` ಸ್ಲೈಸ್‌ನ ಉದ್ದವನ್ನು ಭಾಗಿಸದಿದ್ದರೆ, ಕೊನೆಯ ಚಂಕ್ ಉದ್ದ `chunk_size` ಅನ್ನು ಹೊಂದಿರುವುದಿಲ್ಲ.
    ///
    /// ಈ ಪುನರಾವರ್ತಕದ ರೂಪಾಂತರಕ್ಕಾಗಿ [`rchunks_exact`] ನೋಡಿ ಅದು ಯಾವಾಗಲೂ ನಿಖರವಾಗಿ `chunk_size` ಅಂಶಗಳ ಭಾಗಗಳನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಮತ್ತು ಅದೇ ಪುನರಾವರ್ತಕಕ್ಕಾಗಿ [`chunks`] ಆದರೆ ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 ಆಗಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// ಸ್ಲೈಸ್‌ನ ಕೊನೆಯಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುವ ಒಂದು ಸಮಯದಲ್ಲಿ ಸ್ಲೈಸ್‌ನ `chunk_size` ಅಂಶಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಭಾಗಗಳು ರೂಪಾಂತರಗೊಳ್ಳುವ ಚೂರುಗಳಾಗಿವೆ, ಮತ್ತು ಅತಿಕ್ರಮಿಸುವುದಿಲ್ಲ.`chunk_size` ಸ್ಲೈಸ್‌ನ ಉದ್ದವನ್ನು ಭಾಗಿಸದಿದ್ದರೆ, ಕೊನೆಯ ಚಂಕ್ ಉದ್ದ `chunk_size` ಅನ್ನು ಹೊಂದಿರುವುದಿಲ್ಲ.
    ///
    /// ಈ ಪುನರಾವರ್ತಕದ ರೂಪಾಂತರಕ್ಕಾಗಿ [`rchunks_exact_mut`] ನೋಡಿ ಅದು ಯಾವಾಗಲೂ ನಿಖರವಾಗಿ `chunk_size` ಅಂಶಗಳ ಭಾಗಗಳನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಮತ್ತು ಅದೇ ಪುನರಾವರ್ತಕಕ್ಕಾಗಿ [`chunks_mut`] ಆದರೆ ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 ಆಗಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// ಸ್ಲೈಸ್‌ನ ಕೊನೆಯಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುವ ಒಂದು ಸಮಯದಲ್ಲಿ ಸ್ಲೈಸ್‌ನ `chunk_size` ಅಂಶಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಭಾಗಗಳು ಚೂರುಗಳಾಗಿವೆ ಮತ್ತು ಅತಿಕ್ರಮಿಸುವುದಿಲ್ಲ.
    /// `chunk_size` ಸ್ಲೈಸ್‌ನ ಉದ್ದವನ್ನು ಭಾಗಿಸದಿದ್ದರೆ, ನಂತರ `chunk_size-1` ವರೆಗಿನ ಕೊನೆಯ ಅಂಶಗಳನ್ನು ಬಿಟ್ಟುಬಿಡಲಾಗುತ್ತದೆ ಮತ್ತು ಪುನರಾವರ್ತಕದ `remainder` ಕಾರ್ಯದಿಂದ ಹಿಂಪಡೆಯಬಹುದು.
    ///
    /// ಪ್ರತಿ ಚಂಕ್ ನಿಖರವಾಗಿ `chunk_size` ಅಂಶಗಳನ್ನು ಹೊಂದಿರುವುದರಿಂದ, ಕಂಪೈಲರ್ ಆಗಾಗ್ಗೆ ಫಲಿತಾಂಶದ ಕೋಡ್ ಅನ್ನು [`chunks`] ಗಿಂತ ಉತ್ತಮವಾಗಿ ಉತ್ತಮಗೊಳಿಸಬಹುದು.
    ///
    /// ಈ ಪುನರಾವರ್ತಕದ ರೂಪಾಂತರಕ್ಕಾಗಿ [`rchunks`] ಅನ್ನು ನೋಡಿ, ಅದು ಉಳಿದ ಭಾಗವನ್ನು ಸಣ್ಣ ಭಾಗವಾಗಿ ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಮತ್ತು ಅದೇ ಪುನರಾವರ್ತಕಕ್ಕಾಗಿ [`chunks_exact`] ಆದರೆ ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 ಆಗಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// ಸ್ಲೈಸ್‌ನ ಕೊನೆಯಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುವ ಒಂದು ಸಮಯದಲ್ಲಿ ಸ್ಲೈಸ್‌ನ `chunk_size` ಅಂಶಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಭಾಗಗಳು ರೂಪಾಂತರಗೊಳ್ಳುವ ಚೂರುಗಳಾಗಿವೆ, ಮತ್ತು ಅತಿಕ್ರಮಿಸುವುದಿಲ್ಲ.
    /// `chunk_size` ಸ್ಲೈಸ್‌ನ ಉದ್ದವನ್ನು ಭಾಗಿಸದಿದ್ದರೆ, ನಂತರ `chunk_size-1` ವರೆಗಿನ ಕೊನೆಯ ಅಂಶಗಳನ್ನು ಬಿಟ್ಟುಬಿಡಲಾಗುತ್ತದೆ ಮತ್ತು ಪುನರಾವರ್ತಕದ `into_remainder` ಕಾರ್ಯದಿಂದ ಹಿಂಪಡೆಯಬಹುದು.
    ///
    /// ಪ್ರತಿ ಚಂಕ್ ನಿಖರವಾಗಿ `chunk_size` ಅಂಶಗಳನ್ನು ಹೊಂದಿರುವುದರಿಂದ, ಕಂಪೈಲರ್ ಆಗಾಗ್ಗೆ ಫಲಿತಾಂಶದ ಕೋಡ್ ಅನ್ನು [`chunks_mut`] ಗಿಂತ ಉತ್ತಮವಾಗಿ ಉತ್ತಮಗೊಳಿಸಬಹುದು.
    ///
    /// ಈ ಪುನರಾವರ್ತಕದ ರೂಪಾಂತರಕ್ಕಾಗಿ [`rchunks_mut`] ಅನ್ನು ನೋಡಿ, ಅದು ಉಳಿದ ಭಾಗವನ್ನು ಸಣ್ಣ ಭಾಗವಾಗಿ ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಮತ್ತು ಅದೇ ಪುನರಾವರ್ತಕಕ್ಕಾಗಿ [`chunks_exact_mut`] ಆದರೆ ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 ಆಗಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// ಅಂಶಗಳನ್ನು ಬೇರ್ಪಡಿಸಲು ಮುನ್ಸೂಚನೆಯನ್ನು ಬಳಸಿಕೊಂಡು ಅಂಶಗಳ ಅತಿಕ್ರಮಿಸದ ರನ್‌ಗಳನ್ನು ಉತ್ಪಾದಿಸುವ ಸ್ಲೈಸ್‌ನ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಮುನ್ಸೂಚನೆಯನ್ನು ತಮ್ಮನ್ನು ಅನುಸರಿಸುವ ಎರಡು ಅಂಶಗಳ ಮೇಲೆ ಕರೆಯಲಾಗುತ್ತದೆ, ಇದರರ್ಥ ಪ್ರೆಡಿಕೇಟ್ ಅನ್ನು `slice[0]` ಮತ್ತು `slice[1]` ನಲ್ಲಿ ಕರೆಯಲಾಗುತ್ತದೆ ಮತ್ತು ನಂತರ `slice[1]` ಮತ್ತು `slice[2]` ನಲ್ಲಿ ಕರೆಯಲಾಗುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ವಿಂಗಡಿಸಲಾದ ಚಂದಾದಾರಿಕೆಗಳನ್ನು ಹೊರತೆಗೆಯಲು ಈ ವಿಧಾನವನ್ನು ಬಳಸಬಹುದು:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// ಸ್ಲೈಸ್‌ನ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅವುಗಳನ್ನು ಬೇರ್ಪಡಿಸಲು ಮುನ್ಸೂಚನೆಯನ್ನು ಬಳಸಿಕೊಂಡು ಅಂಶಗಳ ಅತಿಕ್ರಮಿಸದ ರೂಪಾಂತರಿತ ರನ್ಗಳನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ.
    ///
    /// ಮುನ್ಸೂಚನೆಯನ್ನು ತಮ್ಮನ್ನು ಅನುಸರಿಸುವ ಎರಡು ಅಂಶಗಳ ಮೇಲೆ ಕರೆಯಲಾಗುತ್ತದೆ, ಇದರರ್ಥ ಪ್ರೆಡಿಕೇಟ್ ಅನ್ನು `slice[0]` ಮತ್ತು `slice[1]` ನಲ್ಲಿ ಕರೆಯಲಾಗುತ್ತದೆ ಮತ್ತು ನಂತರ `slice[1]` ಮತ್ತು `slice[2]` ನಲ್ಲಿ ಕರೆಯಲಾಗುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ವಿಂಗಡಿಸಲಾದ ಚಂದಾದಾರಿಕೆಗಳನ್ನು ಹೊರತೆಗೆಯಲು ಈ ವಿಧಾನವನ್ನು ಬಳಸಬಹುದು:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// ಸೂಚ್ಯಂಕದಲ್ಲಿ ಒಂದು ಸ್ಲೈಸ್ ಅನ್ನು ಎರಡು ಭಾಗಿಸುತ್ತದೆ.
    ///
    /// ಮೊದಲನೆಯದು `[0, mid)` ನಿಂದ ಎಲ್ಲಾ ಸೂಚ್ಯಂಕಗಳನ್ನು ಹೊಂದಿರುತ್ತದೆ (ಸೂಚ್ಯಂಕ `mid` ಅನ್ನು ಹೊರತುಪಡಿಸಿ) ಮತ್ತು ಎರಡನೆಯದು `[mid, len)` ನಿಂದ ಎಲ್ಲಾ ಸೂಚ್ಯಂಕಗಳನ್ನು ಹೊಂದಿರುತ್ತದೆ (ಸೂಚ್ಯಂಕ `len` ಅನ್ನು ಹೊರತುಪಡಿಸಿ).
    ///
    ///
    /// # Panics
    ///
    /// `mid > len` ವೇಳೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // ಸುರಕ್ಷತೆ: `[ptr; mid]` ಮತ್ತು `[mid; len]` `self` ಒಳಗೆ ಇವೆ, ಅದು
        // `from_raw_parts_mut` ನ ಅವಶ್ಯಕತೆಗಳನ್ನು ಪೂರೈಸುತ್ತದೆ.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// ಸೂಚ್ಯಂಕದಲ್ಲಿ ಒಂದು ರೂಪಾಂತರಿತ ಸ್ಲೈಸ್ ಅನ್ನು ಎರಡು ಭಾಗಿಸುತ್ತದೆ.
    ///
    /// ಮೊದಲನೆಯದು `[0, mid)` ನಿಂದ ಎಲ್ಲಾ ಸೂಚ್ಯಂಕಗಳನ್ನು ಹೊಂದಿರುತ್ತದೆ (ಸೂಚ್ಯಂಕ `mid` ಅನ್ನು ಹೊರತುಪಡಿಸಿ) ಮತ್ತು ಎರಡನೆಯದು `[mid, len)` ನಿಂದ ಎಲ್ಲಾ ಸೂಚ್ಯಂಕಗಳನ್ನು ಹೊಂದಿರುತ್ತದೆ (ಸೂಚ್ಯಂಕ `len` ಅನ್ನು ಹೊರತುಪಡಿಸಿ).
    ///
    ///
    /// # Panics
    ///
    /// `mid > len` ವೇಳೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // ಸುರಕ್ಷತೆ: `[ptr; mid]` ಮತ್ತು `[mid; len]` `self` ಒಳಗೆ ಇವೆ, ಅದು
        // `from_raw_parts_mut` ನ ಅವಶ್ಯಕತೆಗಳನ್ನು ಪೂರೈಸುತ್ತದೆ.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// ಬೌಂಡ್ಸ್ ಚೆಕಿಂಗ್ ಮಾಡದೆ, ಒಂದು ಸ್ಲೈಸ್ ಅನ್ನು ಸೂಚ್ಯಂಕದಲ್ಲಿ ಎರಡು ಭಾಗಿಸುತ್ತದೆ.
    ///
    /// ಮೊದಲನೆಯದು `[0, mid)` ನಿಂದ ಎಲ್ಲಾ ಸೂಚ್ಯಂಕಗಳನ್ನು ಹೊಂದಿರುತ್ತದೆ (ಸೂಚ್ಯಂಕ `mid` ಅನ್ನು ಹೊರತುಪಡಿಸಿ) ಮತ್ತು ಎರಡನೆಯದು `[mid, len)` ನಿಂದ ಎಲ್ಲಾ ಸೂಚ್ಯಂಕಗಳನ್ನು ಹೊಂದಿರುತ್ತದೆ (ಸೂಚ್ಯಂಕ `len` ಅನ್ನು ಹೊರತುಪಡಿಸಿ).
    ///
    ///
    /// ಸುರಕ್ಷಿತ ಪರ್ಯಾಯಕ್ಕಾಗಿ [`split_at`] ನೋಡಿ.
    ///
    /// # Safety
    ///
    /// ಈ ವಿಧಾನವನ್ನು ಮಿತಿ ಮೀರದ ಸೂಚ್ಯಂಕದೊಂದಿಗೆ ಕರೆಯುವುದು *[ವಿವರಿಸಲಾಗದ ನಡವಳಿಕೆ]* ಫಲಿತಾಂಶದ ಉಲ್ಲೇಖವನ್ನು ಬಳಸದಿದ್ದರೂ ಸಹ.ಕರೆ ಮಾಡುವವರು `0 <= mid <= self.len()` ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು ಆ `0 <= mid <= self.len()` ಅನ್ನು ಪರಿಶೀಲಿಸಬೇಕು
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// ಬೌಂಡ್ಸ್ ಚೆಕಿಂಗ್ ಮಾಡದೆ, ಒಂದು ರೂಪಾಂತರಿತ ಸ್ಲೈಸ್ ಅನ್ನು ಸೂಚ್ಯಂಕದಲ್ಲಿ ಎರಡು ಭಾಗಿಸುತ್ತದೆ.
    ///
    /// ಮೊದಲನೆಯದು `[0, mid)` ನಿಂದ ಎಲ್ಲಾ ಸೂಚ್ಯಂಕಗಳನ್ನು ಹೊಂದಿರುತ್ತದೆ (ಸೂಚ್ಯಂಕ `mid` ಅನ್ನು ಹೊರತುಪಡಿಸಿ) ಮತ್ತು ಎರಡನೆಯದು `[mid, len)` ನಿಂದ ಎಲ್ಲಾ ಸೂಚ್ಯಂಕಗಳನ್ನು ಹೊಂದಿರುತ್ತದೆ (ಸೂಚ್ಯಂಕ `len` ಅನ್ನು ಹೊರತುಪಡಿಸಿ).
    ///
    ///
    /// ಸುರಕ್ಷಿತ ಪರ್ಯಾಯಕ್ಕಾಗಿ [`split_at_mut`] ನೋಡಿ.
    ///
    /// # Safety
    ///
    /// ಈ ವಿಧಾನವನ್ನು ಮಿತಿ ಮೀರದ ಸೂಚ್ಯಂಕದೊಂದಿಗೆ ಕರೆಯುವುದು *[ವಿವರಿಸಲಾಗದ ನಡವಳಿಕೆ]* ಫಲಿತಾಂಶದ ಉಲ್ಲೇಖವನ್ನು ಬಳಸದಿದ್ದರೂ ಸಹ.ಕರೆ ಮಾಡುವವರು `0 <= mid <= self.len()` ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು ಆ `0 <= mid <= self.len()` ಅನ್ನು ಪರಿಶೀಲಿಸಬೇಕು.
        //
        // `[ptr; mid]` ಮತ್ತು `[mid; len]` ಅತಿಕ್ರಮಿಸುವುದಿಲ್ಲ, ಆದ್ದರಿಂದ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುವುದು ಉತ್ತಮವಾಗಿದೆ.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// `pred` ಗೆ ಹೊಂದಿಕೆಯಾಗುವ ಅಂಶಗಳಿಂದ ಬೇರ್ಪಡಿಸಲಾದ ಚಂದಾದಾರಿಕೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಹೊಂದಿಕೆಯಾದ ಅಂಶವು ಚಂದಾದಾರಿಕೆಗಳಲ್ಲಿ ಇಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// ಮೊದಲ ಅಂಶವು ಹೊಂದಿಕೆಯಾದರೆ, ಖಾಲಿ ಸ್ಲೈಸ್ ಪುನರಾವರ್ತಕರಿಂದ ಹಿಂದಿರುಗಿದ ಮೊದಲ ಐಟಂ ಆಗಿರುತ್ತದೆ.
    /// ಅಂತೆಯೇ, ಸ್ಲೈಸ್‌ನಲ್ಲಿನ ಕೊನೆಯ ಅಂಶವು ಹೊಂದಿಕೆಯಾದರೆ, ಖಾಲಿ ಸ್ಲೈಸ್ ಪುನರಾವರ್ತಕರಿಂದ ಹಿಂತಿರುಗಿಸಲಾದ ಕೊನೆಯ ಐಟಂ ಆಗಿರುತ್ತದೆ:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// ಹೊಂದಿಕೆಯಾದ ಎರಡು ಅಂಶಗಳು ನೇರವಾಗಿ ಪಕ್ಕದಲ್ಲಿದ್ದರೆ, ಅವುಗಳ ನಡುವೆ ಖಾಲಿ ಸ್ಲೈಸ್ ಇರುತ್ತದೆ:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// `pred` ಗೆ ಹೊಂದಿಕೆಯಾಗುವ ಅಂಶಗಳಿಂದ ಬೇರ್ಪಡಿಸಬಹುದಾದ ರೂಪಾಂತರಿತ ಚಂದಾದಾರಿಕೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಹೊಂದಿಕೆಯಾದ ಅಂಶವು ಚಂದಾದಾರಿಕೆಗಳಲ್ಲಿ ಇಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// `pred` ಗೆ ಹೊಂದಿಕೆಯಾಗುವ ಅಂಶಗಳಿಂದ ಬೇರ್ಪಡಿಸಲಾದ ಚಂದಾದಾರಿಕೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಹೊಂದಿಕೆಯಾದ ಅಂಶವು ಹಿಂದಿನ ಸಬ್‌ಲೈಸ್‌ನ ಕೊನೆಯಲ್ಲಿ ಟರ್ಮಿನೇಟರ್‌ನಂತೆ ಇರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// ಸ್ಲೈಸ್‌ನ ಕೊನೆಯ ಅಂಶವು ಹೊಂದಿಕೆಯಾದರೆ, ಆ ಅಂಶವನ್ನು ಹಿಂದಿನ ಸ್ಲೈಸ್‌ನ ಟರ್ಮಿನೇಟರ್ ಎಂದು ಪರಿಗಣಿಸಲಾಗುತ್ತದೆ.
    ///
    /// ಆ ಸ್ಲೈಸ್ ಪುನರಾವರ್ತಕ ಹಿಂದಿರುಗಿಸಿದ ಕೊನೆಯ ಐಟಂ ಆಗಿರುತ್ತದೆ.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// `pred` ಗೆ ಹೊಂದಿಕೆಯಾಗುವ ಅಂಶಗಳಿಂದ ಬೇರ್ಪಡಿಸಬಹುದಾದ ರೂಪಾಂತರಿತ ಚಂದಾದಾರಿಕೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಹೊಂದಿಕೆಯಾದ ಅಂಶವು ಹಿಂದಿನ ಸಬ್‌ಲೈಸ್‌ನಲ್ಲಿ ಟರ್ಮಿನೇಟರ್‌ನಂತೆ ಇರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// `pred` ಗೆ ಹೊಂದಿಕೆಯಾಗುವ ಅಂಶಗಳಿಂದ ಬೇರ್ಪಟ್ಟ ಚಂದಾದಾರಿಕೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಸ್ಲೈಸ್‌ನ ಕೊನೆಯಲ್ಲಿ ಪ್ರಾರಂಭಿಸಿ ಹಿಂದಕ್ಕೆ ಕೆಲಸ ಮಾಡುತ್ತದೆ.
    /// ಹೊಂದಿಕೆಯಾದ ಅಂಶವು ಚಂದಾದಾರಿಕೆಗಳಲ್ಲಿ ಇಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `split()` ನಂತೆ, ಮೊದಲ ಅಥವಾ ಕೊನೆಯ ಅಂಶವು ಹೊಂದಿಕೆಯಾದರೆ, ಖಾಲಿ ಸ್ಲೈಸ್ ಪುನರಾವರ್ತಕರಿಂದ ಹಿಂದಿರುಗಿದ ಮೊದಲ (ಅಥವಾ ಕೊನೆಯ) ಐಟಂ ಆಗಿರುತ್ತದೆ.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// `pred` ಗೆ ಹೊಂದಿಕೆಯಾಗುವ ಅಂಶಗಳಿಂದ ಬೇರ್ಪಡಿಸಲಾದ ರೂಪಾಂತರಿತ ಚಂದಾದಾರಿಕೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಸ್ಲೈಸ್‌ನ ಕೊನೆಯಲ್ಲಿ ಪ್ರಾರಂಭಿಸಿ ಹಿಂದಕ್ಕೆ ಕೆಲಸ ಮಾಡುತ್ತದೆ.
    /// ಹೊಂದಿಕೆಯಾದ ಅಂಶವು ಚಂದಾದಾರಿಕೆಗಳಲ್ಲಿ ಇಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// `pred` ಗೆ ಹೊಂದಿಕೆಯಾಗುವ ಅಂಶಗಳಿಂದ ಬೇರ್ಪಡಿಸಲಾಗಿರುವ ಚಂದಾದಾರಿಕೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಇದು ಹೆಚ್ಚಿನ `n` ವಸ್ತುಗಳನ್ನು ಹಿಂತಿರುಗಿಸಲು ಸೀಮಿತವಾಗಿದೆ.
    /// ಹೊಂದಿಕೆಯಾದ ಅಂಶವು ಚಂದಾದಾರಿಕೆಗಳಲ್ಲಿ ಇಲ್ಲ.
    ///
    /// ಹಿಂದಿರುಗಿದ ಕೊನೆಯ ಅಂಶ, ಯಾವುದಾದರೂ ಇದ್ದರೆ, ಸ್ಲೈಸ್‌ನ ಉಳಿದ ಭಾಗವನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಸ್ಲೈಸ್ ಸ್ಪ್ಲಿಟ್ ಅನ್ನು 3 ರಿಂದ ಭಾಗಿಸಬಹುದಾದ ಸಂಖ್ಯೆಗಳಿಂದ ಒಮ್ಮೆ ಮುದ್ರಿಸಿ (ಅಂದರೆ, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// `pred` ಗೆ ಹೊಂದಿಕೆಯಾಗುವ ಅಂಶಗಳಿಂದ ಬೇರ್ಪಡಿಸಲಾಗಿರುವ ಚಂದಾದಾರಿಕೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಇದು ಹೆಚ್ಚಿನ `n` ವಸ್ತುಗಳನ್ನು ಹಿಂತಿರುಗಿಸಲು ಸೀಮಿತವಾಗಿದೆ.
    /// ಹೊಂದಿಕೆಯಾದ ಅಂಶವು ಚಂದಾದಾರಿಕೆಗಳಲ್ಲಿ ಇಲ್ಲ.
    ///
    /// ಹಿಂದಿರುಗಿದ ಕೊನೆಯ ಅಂಶ, ಯಾವುದಾದರೂ ಇದ್ದರೆ, ಸ್ಲೈಸ್‌ನ ಉಳಿದ ಭಾಗವನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// ಹೆಚ್ಚಿನ `n` ವಸ್ತುಗಳನ್ನು ಹಿಂತಿರುಗಿಸಲು ಸೀಮಿತವಾದ `pred` ಗೆ ಹೊಂದಿಕೆಯಾಗುವ ಅಂಶಗಳಿಂದ ಬೇರ್ಪಟ್ಟ ಚಂದಾದಾರಿಕೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಇದು ಸ್ಲೈಸ್‌ನ ಕೊನೆಯಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ ಮತ್ತು ಹಿಂದಕ್ಕೆ ಕೆಲಸ ಮಾಡುತ್ತದೆ.
    /// ಹೊಂದಿಕೆಯಾದ ಅಂಶವು ಚಂದಾದಾರಿಕೆಗಳಲ್ಲಿ ಇಲ್ಲ.
    ///
    /// ಹಿಂದಿರುಗಿದ ಕೊನೆಯ ಅಂಶ, ಯಾವುದಾದರೂ ಇದ್ದರೆ, ಸ್ಲೈಸ್‌ನ ಉಳಿದ ಭಾಗವನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಸ್ಲೈಸ್ ಸ್ಪ್ಲಿಟ್ ಅನ್ನು ಒಮ್ಮೆ ಮುದ್ರಿಸಿ, ಕೊನೆಯಿಂದ ಪ್ರಾರಂಭಿಸಿ, 3 ರಿಂದ ಭಾಗಿಸಬಹುದಾದ ಸಂಖ್ಯೆಗಳಿಂದ (ಅಂದರೆ, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// ಹೆಚ್ಚಿನ `n` ವಸ್ತುಗಳನ್ನು ಹಿಂತಿರುಗಿಸಲು ಸೀಮಿತವಾದ `pred` ಗೆ ಹೊಂದಿಕೆಯಾಗುವ ಅಂಶಗಳಿಂದ ಬೇರ್ಪಟ್ಟ ಚಂದಾದಾರಿಕೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಇದು ಸ್ಲೈಸ್‌ನ ಕೊನೆಯಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ ಮತ್ತು ಹಿಂದಕ್ಕೆ ಕೆಲಸ ಮಾಡುತ್ತದೆ.
    /// ಹೊಂದಿಕೆಯಾದ ಅಂಶವು ಚಂದಾದಾರಿಕೆಗಳಲ್ಲಿ ಇಲ್ಲ.
    ///
    /// ಹಿಂದಿರುಗಿದ ಕೊನೆಯ ಅಂಶ, ಯಾವುದಾದರೂ ಇದ್ದರೆ, ಸ್ಲೈಸ್‌ನ ಉಳಿದ ಭಾಗವನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// ನಿರ್ದಿಷ್ಟ ಮೌಲ್ಯದೊಂದಿಗೆ ಸ್ಲೈಸ್ ಒಂದು ಅಂಶವನ್ನು ಹೊಂದಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// ನೀವು `&T` ಹೊಂದಿಲ್ಲದಿದ್ದರೆ, ಆದರೆ `T: Borrow<U>` ನಂತಹ `&U` (ಉದಾ
    /// `ದಾರ: ಸಾಲ<str>`), ನೀವು `iter().any` ಅನ್ನು ಬಳಸಬಹುದು:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // `String` ನ ಸ್ಲೈಸ್
    /// assert!(v.iter().any(|e| e == "hello")); // `&str` ನೊಂದಿಗೆ ಹುಡುಕಿ
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// `needle` ಸ್ಲೈಸ್‌ನ ಪೂರ್ವಪ್ರತ್ಯಯವಾಗಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// `needle` ಖಾಲಿ ಸ್ಲೈಸ್ ಆಗಿದ್ದರೆ ಯಾವಾಗಲೂ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// `needle` ಸ್ಲೈಸ್‌ನ ಪ್ರತ್ಯಯವಾಗಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// `needle` ಖಾಲಿ ಸ್ಲೈಸ್ ಆಗಿದ್ದರೆ ಯಾವಾಗಲೂ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// ತೆಗೆದುಹಾಕಲಾದ ಪೂರ್ವಪ್ರತ್ಯಯದೊಂದಿಗೆ ಚಂದಾದಾರಿಕೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಸ್ಲೈಸ್ `prefix` ನೊಂದಿಗೆ ಪ್ರಾರಂಭವಾದರೆ, `Some` ನಲ್ಲಿ ಸುತ್ತಿ, ಪೂರ್ವಪ್ರತ್ಯಯದ ನಂತರ ಚಂದಾದಾರಿಕೆಯನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    /// `prefix` ಖಾಲಿಯಾಗಿದ್ದರೆ, ಮೂಲ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಸ್ಲೈಸ್ `prefix` ನೊಂದಿಗೆ ಪ್ರಾರಂಭವಾಗದಿದ್ದರೆ, `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // ಸ್ಲೈಸ್‌ಪ್ಯಾಟರ್ನ್ ಹೆಚ್ಚು ಅತ್ಯಾಧುನಿಕವಾದಾಗ ಮತ್ತು ಯಾವಾಗ ಈ ಕಾರ್ಯಕ್ಕೆ ಪುನಃ ಬರೆಯುವ ಅಗತ್ಯವಿದೆ.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// ತೆಗೆದುಹಾಕಲಾದ ಪ್ರತ್ಯಯದೊಂದಿಗೆ ಚಂದಾದಾರಿಕೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಸ್ಲೈಸ್ `suffix` ನೊಂದಿಗೆ ಕೊನೆಗೊಂಡರೆ, `Some` ನಲ್ಲಿ ಸುತ್ತಿ ಪ್ರತ್ಯಯಕ್ಕೆ ಮೊದಲು ಚಂದಾದಾರಿಕೆಯನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    /// `suffix` ಖಾಲಿಯಾಗಿದ್ದರೆ, ಮೂಲ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಸ್ಲೈಸ್ `suffix` ನೊಂದಿಗೆ ಕೊನೆಗೊಳ್ಳದಿದ್ದರೆ, `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // ಸ್ಲೈಸ್‌ಪ್ಯಾಟರ್ನ್ ಹೆಚ್ಚು ಅತ್ಯಾಧುನಿಕವಾದಾಗ ಮತ್ತು ಯಾವಾಗ ಈ ಕಾರ್ಯಕ್ಕೆ ಪುನಃ ಬರೆಯುವ ಅಗತ್ಯವಿದೆ.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// ನಿರ್ದಿಷ್ಟ ಅಂಶಕ್ಕಾಗಿ ಬೈನರಿ ಈ ವಿಂಗಡಿಸಲಾದ ಸ್ಲೈಸ್ ಅನ್ನು ಹುಡುಕುತ್ತದೆ.
    ///
    /// ಮೌಲ್ಯವು ಕಂಡುಬಂದಲ್ಲಿ [`Result::Ok`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ, ಇದು ಹೊಂದಾಣಿಕೆಯ ಅಂಶದ ಸೂಚಿಯನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    /// ಬಹು ಪಂದ್ಯಗಳಿದ್ದರೆ, ಯಾವುದೇ ಒಂದು ಪಂದ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸಬಹುದು.
    /// ಮೌಲ್ಯವು ಕಂಡುಬಂದಿಲ್ಲವಾದರೆ, [`Result::Err`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ, ವಿಂಗಡಿಸಲಾದ ಕ್ರಮವನ್ನು ನಿರ್ವಹಿಸುವಾಗ ಹೊಂದಾಣಿಕೆಯ ಅಂಶವನ್ನು ಸೇರಿಸಬಹುದಾದ ಸೂಚಿಯನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    ///
    ///
    /// [`binary_search_by`], [`binary_search_by_key`], ಮತ್ತು [`partition_point`] ಸಹ ನೋಡಿ.
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// ನಾಲ್ಕು ಅಂಶಗಳ ಸರಣಿಯನ್ನು ಹುಡುಕುತ್ತದೆ.
    /// ಮೊದಲನೆಯದು ಅನನ್ಯವಾಗಿ ನಿರ್ಧರಿಸಲ್ಪಟ್ಟ ಸ್ಥಾನದೊಂದಿಗೆ ಕಂಡುಬರುತ್ತದೆ;ಎರಡನೆಯ ಮತ್ತು ಮೂರನೆಯದು ಕಂಡುಬರುವುದಿಲ್ಲ;ನಾಲ್ಕನೆಯದು `[1, 4]` ನಲ್ಲಿ ಯಾವುದೇ ಸ್ಥಾನಕ್ಕೆ ಹೊಂದಿಕೆಯಾಗಬಹುದು.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// ವಿಂಗಡಿಸಲಾದ ಕ್ರಮವನ್ನು ನಿರ್ವಹಿಸುವಾಗ ನೀವು ವಿಂಗಡಿಸಲಾದ vector ಗೆ ಐಟಂ ಅನ್ನು ಸೇರಿಸಲು ಬಯಸಿದರೆ:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// ಬೈನರಿ ಈ ವಿಂಗಡಿಸಲಾದ ಸ್ಲೈಸ್ ಅನ್ನು ಹೋಲಿಕೆದಾರರ ಕ್ರಿಯೆಯೊಂದಿಗೆ ಹುಡುಕುತ್ತದೆ.
    ///
    /// ತುಲನಾತ್ಮಕ ಕಾರ್ಯವು ಆಧಾರವಾಗಿರುವ ಸ್ಲೈಸ್‌ನ ವಿಂಗಡಣೆಯ ಕ್ರಮಕ್ಕೆ ಅನುಗುಣವಾದ ಆದೇಶವನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಬೇಕು, ಅದರ ಆರ್ಗ್ಯುಮೆಂಟ್ `Less`, `Equal` ಅಥವಾ `Greater` ಬಯಸಿದ ಗುರಿಯೇ ಎಂದು ಸೂಚಿಸುವ ಆದೇಶ ಕೋಡ್ ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// ಮೌಲ್ಯವು ಕಂಡುಬಂದಲ್ಲಿ [`Result::Ok`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ, ಇದು ಹೊಂದಾಣಿಕೆಯ ಅಂಶದ ಸೂಚಿಯನ್ನು ಹೊಂದಿರುತ್ತದೆ.ಬಹು ಪಂದ್ಯಗಳಿದ್ದರೆ, ಯಾವುದೇ ಒಂದು ಪಂದ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸಬಹುದು.
    /// ಮೌಲ್ಯವು ಕಂಡುಬಂದಿಲ್ಲವಾದರೆ, [`Result::Err`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ, ವಿಂಗಡಿಸಲಾದ ಕ್ರಮವನ್ನು ನಿರ್ವಹಿಸುವಾಗ ಹೊಂದಾಣಿಕೆಯ ಅಂಶವನ್ನು ಸೇರಿಸಬಹುದಾದ ಸೂಚಿಯನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    ///
    /// [`binary_search`], [`binary_search_by_key`], ಮತ್ತು [`partition_point`] ಸಹ ನೋಡಿ.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// ನಾಲ್ಕು ಅಂಶಗಳ ಸರಣಿಯನ್ನು ಹುಡುಕುತ್ತದೆ.ಮೊದಲನೆಯದು ಅನನ್ಯವಾಗಿ ನಿರ್ಧರಿಸಲ್ಪಟ್ಟ ಸ್ಥಾನದೊಂದಿಗೆ ಕಂಡುಬರುತ್ತದೆ;ಎರಡನೆಯ ಮತ್ತು ಮೂರನೆಯದು ಕಂಡುಬರುವುದಿಲ್ಲ;ನಾಲ್ಕನೆಯದು `[1, 4]` ನಲ್ಲಿ ಯಾವುದೇ ಸ್ಥಾನಕ್ಕೆ ಹೊಂದಿಕೆಯಾಗಬಹುದು.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // ಸುರಕ್ಷತೆ: ಈ ಕೆಳಗಿನ ಅಸ್ಥಿರಗಳಿಂದ ಕರೆ ಸುರಕ್ಷಿತವಾಗಿದೆ:
            // - `mid >= 0`
            // - `mid < size`: `mid` ಅನ್ನು `[left; right)` ಬೌಂಡ್‌ನಿಂದ ಸೀಮಿತಗೊಳಿಸಲಾಗಿದೆ.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // ಹೊಂದಾಣಿಕೆಗಿಂತ ನಾವು if/else ನಿಯಂತ್ರಣ ಹರಿವನ್ನು ಬಳಸುವುದಕ್ಕೆ ಕಾರಣವೆಂದರೆ ಹೊಂದಾಣಿಕೆ ಹೋಲಿಕೆ ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಮರುಕ್ರಮಗೊಳಿಸುತ್ತದೆ, ಇದು ಪರಿಪೂರ್ಣ ಸೂಕ್ಷ್ಮವಾಗಿರುತ್ತದೆ.
            //
            // ಇದು u8 ಗಾಗಿ x86 asm ಆಗಿದೆ: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// ಕೀಲಿ ಹೊರತೆಗೆಯುವ ಕಾರ್ಯದೊಂದಿಗೆ ಬೈನರಿ ಈ ವಿಂಗಡಿಸಲಾದ ಸ್ಲೈಸ್ ಅನ್ನು ಹುಡುಕುತ್ತದೆ.
    ///
    /// ಸ್ಲೈಸ್ ಅನ್ನು ಕೀಲಿಯಿಂದ ವಿಂಗಡಿಸಲಾಗಿದೆ ಎಂದು umes ಹಿಸುತ್ತದೆ, ಉದಾಹರಣೆಗೆ [`sort_by_key`] ನೊಂದಿಗೆ ಅದೇ ಕೀ ಹೊರತೆಗೆಯುವ ಕಾರ್ಯವನ್ನು ಬಳಸಿ.
    ///
    /// ಮೌಲ್ಯವು ಕಂಡುಬಂದಲ್ಲಿ [`Result::Ok`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ, ಇದು ಹೊಂದಾಣಿಕೆಯ ಅಂಶದ ಸೂಚಿಯನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    /// ಬಹು ಪಂದ್ಯಗಳಿದ್ದರೆ, ಯಾವುದೇ ಒಂದು ಪಂದ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸಬಹುದು.
    /// ಮೌಲ್ಯವು ಕಂಡುಬಂದಿಲ್ಲವಾದರೆ, [`Result::Err`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ, ವಿಂಗಡಿಸಲಾದ ಕ್ರಮವನ್ನು ನಿರ್ವಹಿಸುವಾಗ ಹೊಂದಾಣಿಕೆಯ ಅಂಶವನ್ನು ಸೇರಿಸಬಹುದಾದ ಸೂಚಿಯನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    ///
    ///
    /// [`binary_search`], [`binary_search_by`], ಮತ್ತು [`partition_point`] ಸಹ ನೋಡಿ.
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// ಜೋಡಿಗಳ ಸ್ಲೈಸ್‌ನಲ್ಲಿ ನಾಲ್ಕು ಅಂಶಗಳ ಸರಣಿಯನ್ನು ಅವುಗಳ ಎರಡನೆಯ ಅಂಶಗಳಿಂದ ವಿಂಗಡಿಸಲಾಗಿದೆ.
    /// ಮೊದಲನೆಯದು ಅನನ್ಯವಾಗಿ ನಿರ್ಧರಿಸಲ್ಪಟ್ಟ ಸ್ಥಾನದೊಂದಿಗೆ ಕಂಡುಬರುತ್ತದೆ;ಎರಡನೆಯ ಮತ್ತು ಮೂರನೆಯದು ಕಂಡುಬರುವುದಿಲ್ಲ;ನಾಲ್ಕನೆಯದು `[1, 4]` ನಲ್ಲಿ ಯಾವುದೇ ಸ್ಥಾನಕ್ಕೆ ಹೊಂದಿಕೆಯಾಗಬಹುದು.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // `slice::sort_by_key` crate `alloc` ನಲ್ಲಿರುವುದರಿಂದ Lint rustdoc::broken_intra_doc_links ಅನ್ನು ಅನುಮತಿಸಲಾಗಿದೆ, ಮತ್ತು `core` ಅನ್ನು ನಿರ್ಮಿಸುವಾಗ ಇನ್ನೂ ಅಸ್ತಿತ್ವದಲ್ಲಿಲ್ಲ.
    //
    // ಡೌನ್‌ಸ್ಟ್ರೀಮ್ crate ಗೆ ಲಿಂಕ್‌ಗಳು: #74481.ಆದಿಮಾನಗಳನ್ನು libstd (#73423) ನಲ್ಲಿ ಮಾತ್ರ ದಾಖಲಿಸಲಾಗಿರುವುದರಿಂದ, ಇದು ಎಂದಿಗೂ ಆಚರಣೆಯಲ್ಲಿ ಮುರಿದ ಲಿಂಕ್‌ಗಳಿಗೆ ಕಾರಣವಾಗುವುದಿಲ್ಲ.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// ಸ್ಲೈಸ್ ಅನ್ನು ವಿಂಗಡಿಸುತ್ತದೆ, ಆದರೆ ಸಮಾನ ಅಂಶಗಳ ಕ್ರಮವನ್ನು ಕಾಪಾಡದಿರಬಹುದು.
    ///
    /// ಈ ರೀತಿಯು ಅಸ್ಥಿರವಾಗಿದೆ (ಅಂದರೆ, ಸಮಾನ ಅಂಶಗಳನ್ನು ಮರುಕ್ರಮಗೊಳಿಸಬಹುದು), ಸ್ಥಳದಲ್ಲಿ (ಅಂದರೆ, ಹಂಚುವುದಿಲ್ಲ), ಮತ್ತು *O*(*n*\*log(* n*)) ಕೆಟ್ಟ-ಪ್ರಕರಣ.
    ///
    /// # ಪ್ರಸ್ತುತ ಅನುಷ್ಠಾನ
    ///
    /// ಪ್ರಸ್ತುತ ಅಲ್ಗಾರಿದಮ್ ಆರ್ಸನ್ ಪೀಟರ್ಸ್ ಅವರಿಂದ [pattern-defeating quicksort][pdqsort] ಅನ್ನು ಆಧರಿಸಿದೆ, ಇದು ಯಾದೃಚ್ ized ಿಕ ಕ್ವಿಕ್ಸೋರ್ಟ್‌ನ ವೇಗದ ಸರಾಸರಿ ಪ್ರಕರಣವನ್ನು ಹೆಪ್ಸೋರ್ಟ್‌ನ ವೇಗದ ಕೆಟ್ಟ ಪ್ರಕರಣದೊಂದಿಗೆ ಸಂಯೋಜಿಸುತ್ತದೆ, ಆದರೆ ಕೆಲವು ಮಾದರಿಗಳೊಂದಿಗೆ ಚೂರುಗಳ ಮೇಲೆ ರೇಖೀಯ ಸಮಯವನ್ನು ಸಾಧಿಸುತ್ತದೆ.
    /// ಕ್ಷೀಣಗೊಳ್ಳುವ ಪ್ರಕರಣಗಳನ್ನು ತಪ್ಪಿಸಲು ಇದು ಕೆಲವು ಯಾದೃಚ್ ization ಿಕೀಕರಣವನ್ನು ಬಳಸುತ್ತದೆ, ಆದರೆ ಯಾವಾಗಲೂ ನಿರ್ಣಾಯಕ ನಡವಳಿಕೆಯನ್ನು ಒದಗಿಸಲು ಸ್ಥಿರವಾದ seed ನೊಂದಿಗೆ.
    ///
    /// ಕೆಲವು ವಿಶೇಷ ಸಂದರ್ಭಗಳಲ್ಲಿ ಹೊರತುಪಡಿಸಿ, ಸ್ಥಿರವಾದ ವಿಂಗಡಣೆಗಿಂತ ಇದು ಸಾಮಾನ್ಯವಾಗಿ ವೇಗವಾಗಿರುತ್ತದೆ, ಉದಾ., ಸ್ಲೈಸ್ ಹಲವಾರು ಒಗ್ಗೂಡಿಸಿದ ವಿಂಗಡಿಸಲಾದ ಅನುಕ್ರಮಗಳನ್ನು ಒಳಗೊಂಡಿರುವಾಗ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// ತುಂಡನ್ನು ತುಲನಾತ್ಮಕ ಕ್ರಿಯೆಯೊಂದಿಗೆ ವಿಂಗಡಿಸುತ್ತದೆ, ಆದರೆ ಸಮಾನ ಅಂಶಗಳ ಕ್ರಮವನ್ನು ಕಾಪಾಡದಿರಬಹುದು.
    ///
    /// ಈ ರೀತಿಯು ಅಸ್ಥಿರವಾಗಿದೆ (ಅಂದರೆ, ಸಮಾನ ಅಂಶಗಳನ್ನು ಮರುಕ್ರಮಗೊಳಿಸಬಹುದು), ಸ್ಥಳದಲ್ಲಿ (ಅಂದರೆ, ಹಂಚುವುದಿಲ್ಲ), ಮತ್ತು *O*(*n*\*log(* n*)) ಕೆಟ್ಟ-ಪ್ರಕರಣ.
    ///
    /// ತುಲನಾತ್ಮಕ ಕಾರ್ಯವು ಸ್ಲೈಸ್‌ನಲ್ಲಿರುವ ಅಂಶಗಳಿಗೆ ಒಟ್ಟು ಆದೇಶವನ್ನು ವ್ಯಾಖ್ಯಾನಿಸಬೇಕು.ಆದೇಶವು ಒಟ್ಟು ಇಲ್ಲದಿದ್ದರೆ, ಅಂಶಗಳ ಕ್ರಮವನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿಲ್ಲ.ಆದೇಶವು ಒಟ್ಟು ಆದೇಶವಾಗಿದ್ದರೆ (ಎಲ್ಲಾ `a`, `b` ಮತ್ತು `c` ಗೆ):
    ///
    /// * ಒಟ್ಟು ಮತ್ತು ಆಂಟಿಸ್ಮಿಮೆಟ್ರಿಕ್: ನಿಖರವಾಗಿ `a < b`, `a == b` ಅಥವಾ `a > b` ನಲ್ಲಿ ಒಂದು ನಿಜ, ಮತ್ತು
    /// * ಅಸ್ಥಿರ, `a < b` ಮತ್ತು `b < c` `a < c` ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ.`==` ಮತ್ತು `>` ಎರಡಕ್ಕೂ ಅದೇ ಹಿಡಿದಿರಬೇಕು.
    ///
    /// ಉದಾಹರಣೆಗೆ, [`f64`] [`Ord`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸದ ಕಾರಣ `NaN != NaN`, ಸ್ಲೈಸ್ `NaN` ಅನ್ನು ಹೊಂದಿಲ್ಲ ಎಂದು ನಮಗೆ ತಿಳಿದಾಗ ನಾವು `partial_cmp` ಅನ್ನು ನಮ್ಮ ರೀತಿಯ ಕಾರ್ಯವಾಗಿ ಬಳಸಬಹುದು.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # ಪ್ರಸ್ತುತ ಅನುಷ್ಠಾನ
    ///
    /// ಪ್ರಸ್ತುತ ಅಲ್ಗಾರಿದಮ್ ಆರ್ಸನ್ ಪೀಟರ್ಸ್ ಅವರಿಂದ [pattern-defeating quicksort][pdqsort] ಅನ್ನು ಆಧರಿಸಿದೆ, ಇದು ಯಾದೃಚ್ ized ಿಕ ಕ್ವಿಕ್ಸೋರ್ಟ್‌ನ ವೇಗದ ಸರಾಸರಿ ಪ್ರಕರಣವನ್ನು ಹೆಪ್ಸೋರ್ಟ್‌ನ ವೇಗದ ಕೆಟ್ಟ ಪ್ರಕರಣದೊಂದಿಗೆ ಸಂಯೋಜಿಸುತ್ತದೆ, ಆದರೆ ಕೆಲವು ಮಾದರಿಗಳೊಂದಿಗೆ ಚೂರುಗಳ ಮೇಲೆ ರೇಖೀಯ ಸಮಯವನ್ನು ಸಾಧಿಸುತ್ತದೆ.
    /// ಕ್ಷೀಣಗೊಳ್ಳುವ ಪ್ರಕರಣಗಳನ್ನು ತಪ್ಪಿಸಲು ಇದು ಕೆಲವು ಯಾದೃಚ್ ization ಿಕೀಕರಣವನ್ನು ಬಳಸುತ್ತದೆ, ಆದರೆ ಯಾವಾಗಲೂ ನಿರ್ಣಾಯಕ ನಡವಳಿಕೆಯನ್ನು ಒದಗಿಸಲು ಸ್ಥಿರವಾದ seed ನೊಂದಿಗೆ.
    ///
    /// ಕೆಲವು ವಿಶೇಷ ಸಂದರ್ಭಗಳಲ್ಲಿ ಹೊರತುಪಡಿಸಿ, ಸ್ಥಿರವಾದ ವಿಂಗಡಣೆಗಿಂತ ಇದು ಸಾಮಾನ್ಯವಾಗಿ ವೇಗವಾಗಿರುತ್ತದೆ, ಉದಾ., ಸ್ಲೈಸ್ ಹಲವಾರು ಒಗ್ಗೂಡಿಸಿದ ವಿಂಗಡಿಸಲಾದ ಅನುಕ್ರಮಗಳನ್ನು ಒಳಗೊಂಡಿರುವಾಗ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // ರಿವರ್ಸ್ ವಿಂಗಡಣೆ
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// ಕೀಲಿ ಹೊರತೆಗೆಯುವ ಕಾರ್ಯದೊಂದಿಗೆ ಸ್ಲೈಸ್ ಅನ್ನು ವಿಂಗಡಿಸುತ್ತದೆ, ಆದರೆ ಸಮಾನ ಅಂಶಗಳ ಕ್ರಮವನ್ನು ಕಾಪಾಡದಿರಬಹುದು.
    ///
    /// ಈ ರೀತಿಯು ಅಸ್ಥಿರವಾಗಿದೆ (ಅಂದರೆ, ಸಮಾನ ಅಂಶಗಳನ್ನು ಮರುಕ್ರಮಗೊಳಿಸಬಹುದು), ಸ್ಥಳದಲ್ಲಿ (ಅಂದರೆ, ಹಂಚುವುದಿಲ್ಲ), ಮತ್ತು *O*(m\* * n *\* log(*n*)) ಕೆಟ್ಟ ಪ್ರಕರಣ, ಅಲ್ಲಿ ಪ್ರಮುಖ ಕಾರ್ಯ *O*(*ಮೀ*).
    ///
    /// # ಪ್ರಸ್ತುತ ಅನುಷ್ಠಾನ
    ///
    /// ಪ್ರಸ್ತುತ ಅಲ್ಗಾರಿದಮ್ ಆರ್ಸನ್ ಪೀಟರ್ಸ್ ಅವರಿಂದ [pattern-defeating quicksort][pdqsort] ಅನ್ನು ಆಧರಿಸಿದೆ, ಇದು ಯಾದೃಚ್ ized ಿಕ ಕ್ವಿಕ್ಸೋರ್ಟ್‌ನ ವೇಗದ ಸರಾಸರಿ ಪ್ರಕರಣವನ್ನು ಹೆಪ್ಸೋರ್ಟ್‌ನ ವೇಗದ ಕೆಟ್ಟ ಪ್ರಕರಣದೊಂದಿಗೆ ಸಂಯೋಜಿಸುತ್ತದೆ, ಆದರೆ ಕೆಲವು ಮಾದರಿಗಳೊಂದಿಗೆ ಚೂರುಗಳ ಮೇಲೆ ರೇಖೀಯ ಸಮಯವನ್ನು ಸಾಧಿಸುತ್ತದೆ.
    /// ಕ್ಷೀಣಗೊಳ್ಳುವ ಪ್ರಕರಣಗಳನ್ನು ತಪ್ಪಿಸಲು ಇದು ಕೆಲವು ಯಾದೃಚ್ ization ಿಕೀಕರಣವನ್ನು ಬಳಸುತ್ತದೆ, ಆದರೆ ಯಾವಾಗಲೂ ನಿರ್ಣಾಯಕ ನಡವಳಿಕೆಯನ್ನು ಒದಗಿಸಲು ಸ್ಥಿರವಾದ seed ನೊಂದಿಗೆ.
    ///
    /// ಕೀ ಕರೆ ಮಾಡುವ ತಂತ್ರದಿಂದಾಗಿ, ಪ್ರಮುಖ ಕಾರ್ಯವು ದುಬಾರಿಯಾದ ಸಂದರ್ಭಗಳಲ್ಲಿ [`sort_unstable_by_key`](#method.sort_unstable_by_key) [`sort_by_cached_key`](#method.sort_by_cached_key) ಗಿಂತ ನಿಧಾನವಾಗಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// `index` ನಲ್ಲಿನ ಅಂಶವು ಅದರ ಅಂತಿಮ ವಿಂಗಡಿಸಲಾದ ಸ್ಥಾನದಲ್ಲಿರುವಂತೆ ಸ್ಲೈಸ್ ಅನ್ನು ಮರುಕ್ರಮಗೊಳಿಸಿ.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// `index` ನಲ್ಲಿನ ಅಂಶವು ಅದರ ಅಂತಿಮ ವಿಂಗಡಿಸಲಾದ ಸ್ಥಾನದಲ್ಲಿರುವಂತಹ ತುಲನಾತ್ಮಕ ಕ್ರಿಯೆಯೊಂದಿಗೆ ಸ್ಲೈಸ್ ಅನ್ನು ಮರುಕ್ರಮಗೊಳಿಸಿ.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// ಕೀಲಿ ಹೊರತೆಗೆಯುವ ಕಾರ್ಯದೊಂದಿಗೆ ಸ್ಲೈಸ್ ಅನ್ನು ಮರುಕ್ರಮಗೊಳಿಸಿ, ಅಂದರೆ `index` ನಲ್ಲಿನ ಅಂಶವು ಅದರ ಅಂತಿಮ ವಿಂಗಡಿಸಲಾದ ಸ್ಥಾನದಲ್ಲಿದೆ.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// `index` ನಲ್ಲಿನ ಅಂಶವು ಅದರ ಅಂತಿಮ ವಿಂಗಡಿಸಲಾದ ಸ್ಥಾನದಲ್ಲಿರುವಂತೆ ಸ್ಲೈಸ್ ಅನ್ನು ಮರುಕ್ರಮಗೊಳಿಸಿ.
    ///
    /// ಈ ಮರುಕ್ರಮಗೊಳಿಸುವಿಕೆಯು ಹೆಚ್ಚುವರಿ ಆಸ್ತಿಯನ್ನು ಹೊಂದಿದ್ದು, `i < index` ಸ್ಥಾನದಲ್ಲಿರುವ ಯಾವುದೇ ಮೌಲ್ಯವು `j > index` ಸ್ಥಾನದಲ್ಲಿರುವ ಯಾವುದೇ ಮೌಲ್ಯಕ್ಕಿಂತ ಕಡಿಮೆ ಅಥವಾ ಸಮನಾಗಿರುತ್ತದೆ.
    /// ಹೆಚ್ಚುವರಿಯಾಗಿ, ಈ ಮರುಕ್ರಮಗೊಳಿಸುವಿಕೆಯು ಅಸ್ಥಿರವಾಗಿದೆ (ಅಂದರೆ
    /// ಯಾವುದೇ ಸಮಾನ ಅಂಶಗಳು `index` ಸ್ಥಾನದಲ್ಲಿ ಕೊನೆಗೊಳ್ಳಬಹುದು), ಸ್ಥಳದಲ್ಲಿ (ಅಂದರೆ
    /// ಹಂಚುವುದಿಲ್ಲ), ಮತ್ತು *O*(*n*) ಕೆಟ್ಟ ಪ್ರಕರಣ.
    /// ಈ ಕಾರ್ಯವನ್ನು ಇತರ ಗ್ರಂಥಾಲಯಗಳಲ್ಲಿ "kth element" ಎಂದೂ ಕರೆಯಲಾಗುತ್ತದೆ.
    /// ಇದು ಈ ಕೆಳಗಿನ ಮೌಲ್ಯಗಳ ಮೂರು ಪಟ್ಟು ಹಿಂತಿರುಗಿಸುತ್ತದೆ: ಕೊಟ್ಟಿರುವ ಸೂಚ್ಯಂಕದಲ್ಲಿ ಒಂದಕ್ಕಿಂತ ಕಡಿಮೆ ಇರುವ ಎಲ್ಲಾ ಅಂಶಗಳು, ಕೊಟ್ಟಿರುವ ಸೂಚ್ಯಂಕದಲ್ಲಿನ ಮೌಲ್ಯ ಮತ್ತು ಕೊಟ್ಟಿರುವ ಸೂಚ್ಯಂಕದಲ್ಲಿ ಒಂದಕ್ಕಿಂತ ಹೆಚ್ಚಿನ ಎಲ್ಲಾ ಅಂಶಗಳು.
    ///
    ///
    /// # ಪ್ರಸ್ತುತ ಅನುಷ್ಠಾನ
    ///
    /// ಪ್ರಸ್ತುತ ಅಲ್ಗಾರಿದಮ್ [`sort_unstable`] ಗಾಗಿ ಬಳಸುವ ಅದೇ ಕ್ವಿಕ್ಸೋರ್ಟ್ ಅಲ್ಗಾರಿದಮ್ನ ಕ್ವಿಕ್ಸೆಲೆಕ್ಟ್ ಭಾಗವನ್ನು ಆಧರಿಸಿದೆ.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` ಇದ್ದಾಗ Panics, ಅಂದರೆ ಖಾಲಿ ಚೂರುಗಳಲ್ಲಿ ಯಾವಾಗಲೂ panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // ಸರಾಸರಿ ಹುಡುಕಿ
    /// v.select_nth_unstable(2);
    ///
    /// // ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಸೂಚ್ಯಂಕದ ಬಗ್ಗೆ ನಾವು ವಿಂಗಡಿಸುವ ವಿಧಾನದ ಆಧಾರದ ಮೇಲೆ ಸ್ಲೈಸ್ ಈ ಕೆಳಗಿನವುಗಳಲ್ಲಿ ಒಂದಾಗಿದೆ ಎಂದು ನಮಗೆ ಖಾತ್ರಿಯಿದೆ.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// `index` ನಲ್ಲಿನ ಅಂಶವು ಅದರ ಅಂತಿಮ ವಿಂಗಡಿಸಲಾದ ಸ್ಥಾನದಲ್ಲಿರುವಂತಹ ತುಲನಾತ್ಮಕ ಕ್ರಿಯೆಯೊಂದಿಗೆ ಸ್ಲೈಸ್ ಅನ್ನು ಮರುಕ್ರಮಗೊಳಿಸಿ.
    ///
    /// ಈ ಮರುಕ್ರಮಗೊಳಿಸುವಿಕೆಯು ಹೆಚ್ಚುವರಿ ಆಸ್ತಿಯನ್ನು ಹೊಂದಿದ್ದು, `i < index` ಸ್ಥಾನದಲ್ಲಿರುವ ಯಾವುದೇ ಮೌಲ್ಯವು ತುಲನಾತ್ಮಕ ಕಾರ್ಯವನ್ನು ಬಳಸಿಕೊಂಡು `j > index` ಸ್ಥಾನದಲ್ಲಿರುವ ಯಾವುದೇ ಮೌಲ್ಯಕ್ಕಿಂತ ಕಡಿಮೆ ಅಥವಾ ಸಮನಾಗಿರುತ್ತದೆ.
    /// ಹೆಚ್ಚುವರಿಯಾಗಿ, ಈ ಮರುಕ್ರಮಗೊಳಿಸುವಿಕೆಯು ಅಸ್ಥಿರವಾಗಿದೆ (ಅಂದರೆ ಯಾವುದೇ ಸಮಾನ ಅಂಶಗಳು `index` ಸ್ಥಾನದಲ್ಲಿ ಕೊನೆಗೊಳ್ಳಬಹುದು), ಸ್ಥಳದಲ್ಲಿ (ಅಂದರೆ ಹಂಚುವುದಿಲ್ಲ), ಮತ್ತು *O*(*n*) ಕೆಟ್ಟ ಪ್ರಕರಣ.
    /// ಈ ಕಾರ್ಯವನ್ನು ಇತರ ಗ್ರಂಥಾಲಯಗಳಲ್ಲಿ "kth element" ಎಂದೂ ಕರೆಯಲಾಗುತ್ತದೆ.
    /// ಇದು ಈ ಕೆಳಗಿನ ಮೌಲ್ಯಗಳ ಮೂರು ಪಟ್ಟು ನೀಡುತ್ತದೆ: ಕೊಟ್ಟಿರುವ ಸೂಚ್ಯಂಕದಲ್ಲಿ ಒಂದಕ್ಕಿಂತ ಕಡಿಮೆ ಇರುವ ಎಲ್ಲಾ ಅಂಶಗಳು, ಕೊಟ್ಟಿರುವ ಸೂಚ್ಯಂಕದಲ್ಲಿನ ಮೌಲ್ಯ, ಮತ್ತು ಕೊಟ್ಟಿರುವ ಸೂಚ್ಯಂಕದಲ್ಲಿ ಒಂದಕ್ಕಿಂತ ದೊಡ್ಡದಾದ ಎಲ್ಲಾ ಅಂಶಗಳು, ಒದಗಿಸಿದ ತುಲನಾತ್ಮಕ ಕಾರ್ಯವನ್ನು ಬಳಸಿ.
    ///
    ///
    /// # ಪ್ರಸ್ತುತ ಅನುಷ್ಠಾನ
    ///
    /// ಪ್ರಸ್ತುತ ಅಲ್ಗಾರಿದಮ್ [`sort_unstable`] ಗಾಗಿ ಬಳಸುವ ಅದೇ ಕ್ವಿಕ್ಸೋರ್ಟ್ ಅಲ್ಗಾರಿದಮ್ನ ಕ್ವಿಕ್ಸೆಲೆಕ್ಟ್ ಭಾಗವನ್ನು ಆಧರಿಸಿದೆ.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` ಇದ್ದಾಗ Panics, ಅಂದರೆ ಖಾಲಿ ಚೂರುಗಳಲ್ಲಿ ಯಾವಾಗಲೂ panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // ಸ್ಲೈಸ್ ಅವರೋಹಣ ಕ್ರಮದಲ್ಲಿ ವಿಂಗಡಿಸಲಾದಂತೆ ಮಧ್ಯಮವನ್ನು ಹುಡುಕಿ.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಸೂಚ್ಯಂಕದ ಬಗ್ಗೆ ನಾವು ವಿಂಗಡಿಸುವ ವಿಧಾನದ ಆಧಾರದ ಮೇಲೆ ಸ್ಲೈಸ್ ಈ ಕೆಳಗಿನವುಗಳಲ್ಲಿ ಒಂದಾಗಿದೆ ಎಂದು ನಮಗೆ ಖಾತ್ರಿಯಿದೆ.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// ಕೀಲಿ ಹೊರತೆಗೆಯುವ ಕಾರ್ಯದೊಂದಿಗೆ ಸ್ಲೈಸ್ ಅನ್ನು ಮರುಕ್ರಮಗೊಳಿಸಿ, ಅಂದರೆ `index` ನಲ್ಲಿನ ಅಂಶವು ಅದರ ಅಂತಿಮ ವಿಂಗಡಿಸಲಾದ ಸ್ಥಾನದಲ್ಲಿದೆ.
    ///
    /// ಈ ಮರುಕ್ರಮಗೊಳಿಸುವಿಕೆಯು ಹೆಚ್ಚುವರಿ ಆಸ್ತಿಯನ್ನು ಹೊಂದಿದ್ದು, `i < index` ಸ್ಥಾನದಲ್ಲಿರುವ ಯಾವುದೇ ಮೌಲ್ಯವು ಕೀ ಹೊರತೆಗೆಯುವ ಕಾರ್ಯವನ್ನು ಬಳಸಿಕೊಂಡು `j > index` ಸ್ಥಾನದಲ್ಲಿರುವ ಯಾವುದೇ ಮೌಲ್ಯಕ್ಕಿಂತ ಕಡಿಮೆ ಅಥವಾ ಸಮನಾಗಿರುತ್ತದೆ.
    /// ಹೆಚ್ಚುವರಿಯಾಗಿ, ಈ ಮರುಕ್ರಮಗೊಳಿಸುವಿಕೆಯು ಅಸ್ಥಿರವಾಗಿದೆ (ಅಂದರೆ ಯಾವುದೇ ಸಮಾನ ಅಂಶಗಳು `index` ಸ್ಥಾನದಲ್ಲಿ ಕೊನೆಗೊಳ್ಳಬಹುದು), ಸ್ಥಳದಲ್ಲಿ (ಅಂದರೆ ಹಂಚುವುದಿಲ್ಲ), ಮತ್ತು *O*(*n*) ಕೆಟ್ಟ ಪ್ರಕರಣ.
    /// ಈ ಕಾರ್ಯವನ್ನು ಇತರ ಗ್ರಂಥಾಲಯಗಳಲ್ಲಿ "kth element" ಎಂದೂ ಕರೆಯಲಾಗುತ್ತದೆ.
    /// ಇದು ಈ ಕೆಳಗಿನ ಮೌಲ್ಯಗಳ ಮೂರು ಪಟ್ಟು ಹಿಂತಿರುಗಿಸುತ್ತದೆ: ಕೊಟ್ಟಿರುವ ಸೂಚ್ಯಂಕದಲ್ಲಿ ಒಂದಕ್ಕಿಂತ ಕಡಿಮೆ ಇರುವ ಎಲ್ಲಾ ಅಂಶಗಳು, ಕೊಟ್ಟಿರುವ ಸೂಚ್ಯಂಕದಲ್ಲಿನ ಮೌಲ್ಯ ಮತ್ತು ಕೊಟ್ಟಿರುವ ಸೂಚ್ಯಂಕದಲ್ಲಿ ಒಂದಕ್ಕಿಂತ ದೊಡ್ಡದಾದ ಎಲ್ಲಾ ಅಂಶಗಳು, ಒದಗಿಸಿದ ಕೀ ಹೊರತೆಗೆಯುವ ಕಾರ್ಯವನ್ನು ಬಳಸಿ.
    ///
    ///
    /// # ಪ್ರಸ್ತುತ ಅನುಷ್ಠಾನ
    ///
    /// ಪ್ರಸ್ತುತ ಅಲ್ಗಾರಿದಮ್ [`sort_unstable`] ಗಾಗಿ ಬಳಸುವ ಅದೇ ಕ್ವಿಕ್ಸೋರ್ಟ್ ಅಲ್ಗಾರಿದಮ್ನ ಕ್ವಿಕ್ಸೆಲೆಕ್ಟ್ ಭಾಗವನ್ನು ಆಧರಿಸಿದೆ.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` ಇದ್ದಾಗ Panics, ಅಂದರೆ ಖಾಲಿ ಚೂರುಗಳಲ್ಲಿ ಯಾವಾಗಲೂ panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // ಶ್ರೇಣಿಯನ್ನು ಸಂಪೂರ್ಣ ಮೌಲ್ಯಕ್ಕೆ ಅನುಗುಣವಾಗಿ ವಿಂಗಡಿಸಿದಂತೆ ಸರಾಸರಿ ಹಿಂತಿರುಗಿ.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಸೂಚ್ಯಂಕದ ಬಗ್ಗೆ ನಾವು ವಿಂಗಡಿಸುವ ವಿಧಾನದ ಆಧಾರದ ಮೇಲೆ ಸ್ಲೈಸ್ ಈ ಕೆಳಗಿನವುಗಳಲ್ಲಿ ಒಂದಾಗಿದೆ ಎಂದು ನಮಗೆ ಖಾತ್ರಿಯಿದೆ.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// [`PartialEq`] trait ಅನುಷ್ಠಾನದ ಪ್ರಕಾರ ಎಲ್ಲಾ ಸತತ ಪುನರಾವರ್ತಿತ ಅಂಶಗಳನ್ನು ಸ್ಲೈಸ್‌ನ ಕೊನೆಯಲ್ಲಿ ಸರಿಸುತ್ತದೆ.
    ///
    ///
    /// ಎರಡು ಹೋಳುಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.ಮೊದಲನೆಯದು ಸತತ ಪುನರಾವರ್ತಿತ ಅಂಶಗಳನ್ನು ಒಳಗೊಂಡಿಲ್ಲ.
    /// ಎರಡನೆಯದು ಎಲ್ಲಾ ನಕಲುಗಳನ್ನು ಯಾವುದೇ ನಿರ್ದಿಷ್ಟ ಕ್ರಮದಲ್ಲಿ ಹೊಂದಿಲ್ಲ.
    ///
    /// ಸ್ಲೈಸ್ ಅನ್ನು ವಿಂಗಡಿಸಿದರೆ, ಮೊದಲು ಹಿಂದಿರುಗಿದ ಸ್ಲೈಸ್‌ನಲ್ಲಿ ಯಾವುದೇ ನಕಲುಗಳಿಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// ನಿರ್ದಿಷ್ಟ ಸಮಾನತೆಯ ಸಂಬಂಧವನ್ನು ತೃಪ್ತಿಪಡಿಸುವ ಸ್ಲೈಸ್‌ನ ಅಂತ್ಯಕ್ಕೆ ಸತತ ಅಂಶಗಳಲ್ಲಿ ಮೊದಲನೆಯದನ್ನು ಹೊರತುಪಡಿಸಿ ಎಲ್ಲವನ್ನೂ ಚಲಿಸುತ್ತದೆ.
    ///
    /// ಎರಡು ಹೋಳುಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.ಮೊದಲನೆಯದು ಸತತ ಪುನರಾವರ್ತಿತ ಅಂಶಗಳನ್ನು ಒಳಗೊಂಡಿಲ್ಲ.
    /// ಎರಡನೆಯದು ಎಲ್ಲಾ ನಕಲುಗಳನ್ನು ಯಾವುದೇ ನಿರ್ದಿಷ್ಟ ಕ್ರಮದಲ್ಲಿ ಹೊಂದಿಲ್ಲ.
    ///
    /// `same_bucket` ಕಾರ್ಯವು ಸ್ಲೈಸ್‌ನಿಂದ ಎರಡು ಅಂಶಗಳಿಗೆ ಉಲ್ಲೇಖಗಳನ್ನು ರವಾನಿಸಲಾಗಿದೆ ಮತ್ತು ಅಂಶಗಳು ಸಮಾನವಾಗಿ ಹೋಲಿಸುತ್ತದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸಬೇಕು.
    /// ಸ್ಲೈಸ್‌ನಲ್ಲಿನ ಅವುಗಳ ಕ್ರಮದಿಂದ ಅಂಶಗಳನ್ನು ವಿರುದ್ಧ ಕ್ರಮದಲ್ಲಿ ರವಾನಿಸಲಾಗುತ್ತದೆ, ಆದ್ದರಿಂದ `same_bucket(a, b)` `true` ಅನ್ನು ಹಿಂದಿರುಗಿಸಿದರೆ, `a` ಅನ್ನು ಸ್ಲೈಸ್‌ನ ಕೊನೆಯಲ್ಲಿ ಸರಿಸಲಾಗುತ್ತದೆ.
    ///
    ///
    /// ಸ್ಲೈಸ್ ಅನ್ನು ವಿಂಗಡಿಸಿದರೆ, ಮೊದಲು ಹಿಂದಿರುಗಿದ ಸ್ಲೈಸ್‌ನಲ್ಲಿ ಯಾವುದೇ ನಕಲುಗಳಿಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // ನಾವು `self` ಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಹೊಂದಿದ್ದರೂ, ನಾವು *ಅನಿಯಂತ್ರಿತ* ಬದಲಾವಣೆಗಳನ್ನು ಮಾಡಲು ಸಾಧ್ಯವಿಲ್ಲ.`same_bucket` ಕರೆಗಳು panic ಆಗಿರಬಹುದು, ಆದ್ದರಿಂದ ಸ್ಲೈಸ್ ಎಲ್ಲಾ ಸಮಯದಲ್ಲೂ ಮಾನ್ಯ ಸ್ಥಿತಿಯಲ್ಲಿದೆ ಎಂದು ನಾವು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು.
        //
        // ಸ್ವಾಪ್‌ಗಳನ್ನು ಬಳಸುವುದರ ಮೂಲಕ ನಾವು ಇದನ್ನು ನಿರ್ವಹಿಸುವ ವಿಧಾನ;ನಾವು ಎಲ್ಲಾ ಅಂಶಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಿಸುತ್ತೇವೆ, ನಾವು ಹೋಗುವಾಗ ವಿನಿಮಯ ಮಾಡಿಕೊಳ್ಳುತ್ತೇವೆ ಆದ್ದರಿಂದ ಕೊನೆಯಲ್ಲಿ ನಾವು ಇರಿಸಿಕೊಳ್ಳಲು ಬಯಸುವ ಅಂಶಗಳು ಮುಂಭಾಗದಲ್ಲಿರುತ್ತವೆ ಮತ್ತು ನಾವು ತಿರಸ್ಕರಿಸಲು ಬಯಸುವವರು ಹಿಂಭಾಗದಲ್ಲಿರುತ್ತಾರೆ.
        // ನಾವು ನಂತರ ಸ್ಲೈಸ್ ಅನ್ನು ವಿಭಜಿಸಬಹುದು.
        // ಈ ಕಾರ್ಯಾಚರಣೆ ಇನ್ನೂ `O(n)` ಆಗಿದೆ.
        //
        // ಉದಾಹರಣೆ: ನಾವು ಈ ಸ್ಥಿತಿಯಲ್ಲಿ ಪ್ರಾರಂಭಿಸುತ್ತೇವೆ, ಅಲ್ಲಿ `r` "ಮುಂದಿನದನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ
        // ಓದಿ "ಮತ್ತು `w` ಮುಂದಿನ_ರೈಟ್` ಅನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // self[r] ಅನ್ನು ಸ್ವಯಂ [w-1] ಗೆ ಹೋಲಿಸಿದರೆ, ಇದು ನಕಲು ಅಲ್ಲ, ಆದ್ದರಿಂದ ನಾವು self[r] ಮತ್ತು self[w] ಅನ್ನು ವಿನಿಮಯ ಮಾಡಿಕೊಳ್ಳುತ್ತೇವೆ (r==w ನಂತೆ ಯಾವುದೇ ಪರಿಣಾಮವಿಲ್ಲ) ಮತ್ತು ನಂತರ r ಮತ್ತು w ಎರಡನ್ನೂ ಹೆಚ್ಚಿಸಿ, ನಮ್ಮನ್ನು ಬಿಟ್ಟುಬಿಡುತ್ತೇವೆ:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // self[r] ಅನ್ನು ಸ್ವಯಂ [w-1] ಗೆ ಹೋಲಿಸಿದರೆ, ಈ ಮೌಲ್ಯವು ನಕಲು, ಆದ್ದರಿಂದ ನಾವು `r` ಅನ್ನು ಹೆಚ್ಚಿಸುತ್ತೇವೆ ಆದರೆ ಉಳಿದಂತೆ ಬದಲಾಗದೆ ಬಿಡುತ್ತೇವೆ:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // self[r] ಅನ್ನು ಸ್ವಯಂ [w-1] ಗೆ ಹೋಲಿಸಿದರೆ, ಇದು ನಕಲು ಅಲ್ಲ, ಆದ್ದರಿಂದ self[r] ಮತ್ತು self[w] ಅನ್ನು ವಿನಿಮಯ ಮಾಡಿಕೊಳ್ಳಿ ಮತ್ತು ಮುಂಗಡ r ಮತ್ತು w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // ನಕಲು ಅಲ್ಲ, ಪುನರಾವರ್ತಿಸಿ:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // ನಕಲಿ, ಸ್ಲೈಸ್‌ನ advance r. End.W ನಲ್ಲಿ ವಿಭಜಿಸಿ.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // ಸುರಕ್ಷತೆ: `while` ಸ್ಥಿತಿಯು `next_read` ಮತ್ತು `next_write` ಅನ್ನು ಖಾತರಿಪಡಿಸುತ್ತದೆ
        // `len` ಗಿಂತ ಕಡಿಮೆ, ಆದ್ದರಿಂದ `self` ಒಳಗೆ ಇರುತ್ತವೆ.
        // `prev_ptr_write` `ptr_write` ಗೆ ಮೊದಲು ಒಂದು ಅಂಶವನ್ನು ಸೂಚಿಸುತ್ತದೆ, ಆದರೆ `next_write` 1 ರಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ, ಆದ್ದರಿಂದ `prev_ptr_write` ಎಂದಿಗೂ 0 ಕ್ಕಿಂತ ಕಡಿಮೆಯಿಲ್ಲ ಮತ್ತು ಸ್ಲೈಸ್‌ನ ಒಳಗೆ ಇರುತ್ತದೆ.
        // ಇದು `ptr_read`, `prev_ptr_write` ಮತ್ತು `ptr_write` ಅನ್ನು ಡಿಫರೆನ್ಸಿಂಗ್ ಮಾಡುವ ಅವಶ್ಯಕತೆಗಳನ್ನು ಮತ್ತು `ptr.add(next_read)`, `ptr.add(next_write - 1)` ಮತ್ತು `prev_ptr_write.offset(1)` ಅನ್ನು ಬಳಸುವ ಅವಶ್ಯಕತೆಗಳನ್ನು ಪೂರೈಸುತ್ತದೆ.
        //
        //
        // `next_write` ಪ್ರತಿ ಲೂಪ್‌ಗೆ ಒಮ್ಮೆಯಾದರೂ ಹೆಚ್ಚಿಸಲಾಗುತ್ತದೆ ಅಂದರೆ ಯಾವುದೇ ಅಂಶವನ್ನು ಬದಲಾಯಿಸಬೇಕಾದಾಗ ಅದನ್ನು ಬಿಟ್ಟುಬಿಡುವುದಿಲ್ಲ.
        //
        // `ptr_read` ಮತ್ತು `prev_ptr_write` ಎಂದಿಗೂ ಒಂದೇ ಅಂಶವನ್ನು ಸೂಚಿಸುವುದಿಲ್ಲ.`&mut *ptr_read`, `&mut* prev_ptr_write` ಸುರಕ್ಷಿತವಾಗಿರಲು ಇದು ಅಗತ್ಯವಿದೆ.
        // ವಿವರಣೆಯು ಸರಳವಾಗಿ `next_read >= next_write` ಯಾವಾಗಲೂ ನಿಜ, ಆದ್ದರಿಂದ `next_read > next_write - 1` ತುಂಬಾ ಆಗಿದೆ.
        //
        //
        //
        //
        //
        unsafe {
            // ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಬಳಸುವ ಮೂಲಕ ಗಡಿ ಪರಿಶೀಲನೆಯನ್ನು ತಪ್ಪಿಸಿ.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// ಒಂದೇ ಕೀಲಿಯನ್ನು ಪರಿಹರಿಸುವ ಸ್ಲೈಸ್‌ನ ಅಂತ್ಯಕ್ಕೆ ಸತತ ಅಂಶಗಳಲ್ಲಿ ಮೊದಲನೆಯದನ್ನು ಹೊರತುಪಡಿಸಿ ಎಲ್ಲವನ್ನೂ ಚಲಿಸುತ್ತದೆ.
    ///
    ///
    /// ಎರಡು ಹೋಳುಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.ಮೊದಲನೆಯದು ಸತತ ಪುನರಾವರ್ತಿತ ಅಂಶಗಳನ್ನು ಒಳಗೊಂಡಿಲ್ಲ.
    /// ಎರಡನೆಯದು ಎಲ್ಲಾ ನಕಲುಗಳನ್ನು ಯಾವುದೇ ನಿರ್ದಿಷ್ಟ ಕ್ರಮದಲ್ಲಿ ಹೊಂದಿಲ್ಲ.
    ///
    /// ಸ್ಲೈಸ್ ಅನ್ನು ವಿಂಗಡಿಸಿದರೆ, ಮೊದಲು ಹಿಂದಿರುಗಿದ ಸ್ಲೈಸ್‌ನಲ್ಲಿ ಯಾವುದೇ ನಕಲುಗಳಿಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// ಸ್ಲೈಸ್ ಅನ್ನು ಸ್ಥಳದಲ್ಲಿ ತಿರುಗಿಸುತ್ತದೆ, ಅಂದರೆ ಸ್ಲೈಸ್‌ನ ಮೊದಲ `mid` ಅಂಶಗಳು ಅಂತ್ಯಕ್ಕೆ ಚಲಿಸುತ್ತವೆ ಮತ್ತು ಕೊನೆಯ `self.len() - mid` ಅಂಶಗಳು ಮುಂಭಾಗಕ್ಕೆ ಚಲಿಸುತ್ತವೆ.
    /// `rotate_left` ಗೆ ಕರೆ ಮಾಡಿದ ನಂತರ, ಈ ಹಿಂದೆ ಸೂಚ್ಯಂಕ `mid` ನಲ್ಲಿರುವ ಅಂಶವು ಸ್ಲೈಸ್‌ನ ಮೊದಲ ಅಂಶವಾಗಿ ಪರಿಣಮಿಸುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// `mid` ಸ್ಲೈಸ್‌ನ ಉದ್ದಕ್ಕಿಂತ ಹೆಚ್ಚಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.`mid == self.len()` _not_ panic ಅನ್ನು ಮಾಡುತ್ತದೆ ಮತ್ತು ಇದು ಯಾವುದೇ ಆಪ್ ತಿರುಗುವಿಕೆಯಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    /// # Complexity
    ///
    /// ರೇಖೀಯ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ (`self.len()`) ಸಮಯದಲ್ಲಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// ಚಂದಾದಾರಿಕೆಯನ್ನು ತಿರುಗಿಸುವುದು:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // ಸುರಕ್ಷತೆ: `[p.add(mid) - mid, p.add(mid) + k)` ಶ್ರೇಣಿ ಕ್ಷುಲ್ಲಕವಾಗಿದೆ
        // `ptr_rotate` ಗೆ ಅಗತ್ಯವಿರುವಂತೆ ಓದಲು ಮತ್ತು ಬರೆಯಲು ಮಾನ್ಯವಾಗಿದೆ.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// ಸ್ಲೈಸ್ ಅನ್ನು ಸ್ಥಳದಲ್ಲಿ ತಿರುಗಿಸುತ್ತದೆ, ಅಂದರೆ ಸ್ಲೈಸ್‌ನ ಮೊದಲ `self.len() - k` ಅಂಶಗಳು ಅಂತ್ಯಕ್ಕೆ ಚಲಿಸುತ್ತವೆ ಮತ್ತು ಕೊನೆಯ `k` ಅಂಶಗಳು ಮುಂಭಾಗಕ್ಕೆ ಚಲಿಸುತ್ತವೆ.
    /// `rotate_right` ಗೆ ಕರೆ ಮಾಡಿದ ನಂತರ, ಈ ಹಿಂದೆ ಸೂಚ್ಯಂಕ `self.len() - k` ನಲ್ಲಿರುವ ಅಂಶವು ಸ್ಲೈಸ್‌ನ ಮೊದಲ ಅಂಶವಾಗಿ ಪರಿಣಮಿಸುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// `k` ಸ್ಲೈಸ್‌ನ ಉದ್ದಕ್ಕಿಂತ ಹೆಚ್ಚಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.`k == self.len()` _not_ panic ಅನ್ನು ಮಾಡುತ್ತದೆ ಮತ್ತು ಇದು ಯಾವುದೇ ಆಪ್ ತಿರುಗುವಿಕೆಯಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    /// # Complexity
    ///
    /// ರೇಖೀಯ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ (`self.len()`) ಸಮಯದಲ್ಲಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// ಚಂದಾದಾರಿಕೆಯನ್ನು ತಿರುಗಿಸಿ:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // ಸುರಕ್ಷತೆ: `[p.add(mid) - mid, p.add(mid) + k)` ಶ್ರೇಣಿ ಕ್ಷುಲ್ಲಕವಾಗಿದೆ
        // `ptr_rotate` ಗೆ ಅಗತ್ಯವಿರುವಂತೆ ಓದಲು ಮತ್ತು ಬರೆಯಲು ಮಾನ್ಯವಾಗಿದೆ.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// `value` ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮೂಲಕ ಅಂಶಗಳೊಂದಿಗೆ `self` ಅನ್ನು ತುಂಬುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// ಮುಚ್ಚುವಿಕೆಯನ್ನು ಪದೇ ಪದೇ ಕರೆಯುವ ಮೂಲಕ ಹಿಂತಿರುಗಿದ ಅಂಶಗಳೊಂದಿಗೆ `self` ಅನ್ನು ತುಂಬುತ್ತದೆ.
    ///
    /// ಹೊಸ ಮೌಲ್ಯಗಳನ್ನು ರಚಿಸಲು ಈ ವಿಧಾನವು ಮುಚ್ಚುವಿಕೆಯನ್ನು ಬಳಸುತ್ತದೆ.ನಿರ್ದಿಷ್ಟ ಮೌಲ್ಯವನ್ನು ನೀವು [`Clone`] ಬದಲಿಸಲು ಬಯಸಿದರೆ, [`fill`] ಬಳಸಿ.
    /// ಮೌಲ್ಯಗಳನ್ನು ರಚಿಸಲು ನೀವು [`Default`] trait ಅನ್ನು ಬಳಸಲು ಬಯಸಿದರೆ, ನೀವು [`Default::default`] ಅನ್ನು ಆರ್ಗ್ಯುಮೆಂಟ್ ಆಗಿ ರವಾನಿಸಬಹುದು.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// `src` ನಿಂದ `self` ಗೆ ಅಂಶಗಳನ್ನು ನಕಲಿಸುತ್ತದೆ.
    ///
    /// `src` ನ ಉದ್ದವು `self` ನಂತೆಯೇ ಇರಬೇಕು.
    ///
    /// `T` `Copy` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದರೆ, [`copy_from_slice`] ಅನ್ನು ಬಳಸಲು ಇದು ಹೆಚ್ಚು ಕಾರ್ಯಕ್ಷಮತೆಯನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// ಎರಡು ಚೂರುಗಳು ವಿಭಿನ್ನ ಉದ್ದಗಳನ್ನು ಹೊಂದಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಸ್ಲೈಸ್‌ನಿಂದ ಇನ್ನೊಂದಕ್ಕೆ ಎರಡು ಅಂಶಗಳನ್ನು ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // ಚೂರುಗಳು ಒಂದೇ ಉದ್ದವಾಗಿರಬೇಕು, ನಾವು ಮೂಲ ಸ್ಲೈಸ್ ಅನ್ನು ನಾಲ್ಕು ಅಂಶಗಳಿಂದ ಎರಡಕ್ಕೆ ಕತ್ತರಿಸುತ್ತೇವೆ.
    /// // ನಾವು ಇದನ್ನು ಮಾಡದಿದ್ದರೆ ಅದು panic ಆಗುತ್ತದೆ.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust ಒಂದು ನಿರ್ದಿಷ್ಟ ವ್ಯಾಪ್ತಿಯ ದತ್ತಾಂಶದ ನಿರ್ದಿಷ್ಟ ಬದಲಾವಣೆಯ ಯಾವುದೇ ಉಲ್ಲೇಖವಿಲ್ಲದ ಒಂದು ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖ ಮಾತ್ರ ಇರಬಹುದೆಂದು ಜಾರಿಗೊಳಿಸುತ್ತದೆ.
    /// ಈ ಕಾರಣದಿಂದಾಗಿ, ಒಂದೇ ಸ್ಲೈಸ್‌ನಲ್ಲಿ `clone_from_slice` ಅನ್ನು ಬಳಸಲು ಪ್ರಯತ್ನಿಸುವುದರಿಂದ ಕಂಪೈಲ್ ವಿಫಲಗೊಳ್ಳುತ್ತದೆ:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// ಇದರೊಂದಿಗೆ ಕೆಲಸ ಮಾಡಲು, ಸ್ಲೈಸ್‌ನಿಂದ ಎರಡು ವಿಭಿನ್ನ ಉಪ-ಚೂರುಗಳನ್ನು ರಚಿಸಲು ನಾವು [`split_at_mut`] ಅನ್ನು ಬಳಸಬಹುದು:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು `src` ನಿಂದ `self` ಗೆ ನಕಲಿಸುತ್ತದೆ, ಒಂದು memcpy ಬಳಸಿ.
    ///
    /// `src` ನ ಉದ್ದವು `self` ನಂತೆಯೇ ಇರಬೇಕು.
    ///
    /// `T` `Copy` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸದಿದ್ದರೆ, [`clone_from_slice`] ಬಳಸಿ.
    ///
    /// # Panics
    ///
    /// ಎರಡು ಚೂರುಗಳು ವಿಭಿನ್ನ ಉದ್ದಗಳನ್ನು ಹೊಂದಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಸ್ಲೈಸ್‌ನಿಂದ ಇನ್ನೊಂದಕ್ಕೆ ಎರಡು ಅಂಶಗಳನ್ನು ನಕಲಿಸಲಾಗುತ್ತಿದೆ:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // ಚೂರುಗಳು ಒಂದೇ ಉದ್ದವಾಗಿರಬೇಕು, ನಾವು ಮೂಲ ಸ್ಲೈಸ್ ಅನ್ನು ನಾಲ್ಕು ಅಂಶಗಳಿಂದ ಎರಡಕ್ಕೆ ಕತ್ತರಿಸುತ್ತೇವೆ.
    /// // ನಾವು ಇದನ್ನು ಮಾಡದಿದ್ದರೆ ಅದು panic ಆಗುತ್ತದೆ.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust ಒಂದು ನಿರ್ದಿಷ್ಟ ವ್ಯಾಪ್ತಿಯ ದತ್ತಾಂಶದ ನಿರ್ದಿಷ್ಟ ಬದಲಾವಣೆಯ ಯಾವುದೇ ಉಲ್ಲೇಖವಿಲ್ಲದ ಒಂದು ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖ ಮಾತ್ರ ಇರಬಹುದೆಂದು ಜಾರಿಗೊಳಿಸುತ್ತದೆ.
    /// ಈ ಕಾರಣದಿಂದಾಗಿ, ಒಂದೇ ಸ್ಲೈಸ್‌ನಲ್ಲಿ `copy_from_slice` ಅನ್ನು ಬಳಸಲು ಪ್ರಯತ್ನಿಸುವುದರಿಂದ ಕಂಪೈಲ್ ವಿಫಲಗೊಳ್ಳುತ್ತದೆ:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// ಇದರೊಂದಿಗೆ ಕೆಲಸ ಮಾಡಲು, ಸ್ಲೈಸ್‌ನಿಂದ ಎರಡು ವಿಭಿನ್ನ ಉಪ-ಚೂರುಗಳನ್ನು ರಚಿಸಲು ನಾವು [`split_at_mut`] ಅನ್ನು ಬಳಸಬಹುದು:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // ಕಾಲ್ ಸೈಟ್ ಅನ್ನು ಉಬ್ಬಿಕೊಳ್ಳದಂತೆ panic ಕೋಡ್ ಮಾರ್ಗವನ್ನು ಶೀತಲ ಕಾರ್ಯಕ್ಕೆ ಇಡಲಾಗಿದೆ.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // ಸುರಕ್ಷತೆ: `self` ವ್ಯಾಖ್ಯಾನದಿಂದ `self.len()` ಅಂಶಗಳಿಗೆ ಮಾನ್ಯವಾಗಿದೆ, ಮತ್ತು `src` ಆಗಿತ್ತು
        // ಒಂದೇ ಉದ್ದವನ್ನು ಹೊಂದಲು ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
        // ಚೂರುಗಳು ಅತಿಕ್ರಮಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ ಏಕೆಂದರೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳು ಪ್ರತ್ಯೇಕವಾಗಿವೆ.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// ಸ್ಲೈಸ್‌ನ ಒಂದು ಭಾಗದಿಂದ ಮತ್ತೊಂದು ಭಾಗಕ್ಕೆ ಅಂಶಗಳನ್ನು ಒಂದು ಮೆಮೋವ್ ಬಳಸಿ ನಕಲಿಸುತ್ತದೆ.
    ///
    /// `src` ನಿಂದ ನಕಲಿಸಲು `self` ವ್ಯಾಪ್ತಿಯಲ್ಲಿದೆ.
    /// `dest` ಇದು ನಕಲಿಸಲು `self` ವ್ಯಾಪ್ತಿಯ ಆರಂಭಿಕ ಸೂಚ್ಯಂಕವಾಗಿದೆ, ಇದು `src` ನಂತೆಯೇ ಉದ್ದವನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    /// ಎರಡು ಶ್ರೇಣಿಗಳು ಅತಿಕ್ರಮಿಸಬಹುದು.
    /// ಎರಡು ಶ್ರೇಣಿಗಳ ತುದಿಗಳು `self.len()` ಗಿಂತ ಕಡಿಮೆ ಅಥವಾ ಸಮನಾಗಿರಬೇಕು.
    ///
    /// # Panics
    ///
    /// ಎರಡೂ ಶ್ರೇಣಿಯು ಸ್ಲೈಸ್‌ನ ಅಂತ್ಯವನ್ನು ಮೀರಿದರೆ ಅಥವಾ `src` ನ ಅಂತ್ಯವು ಪ್ರಾರಂಭದ ಮೊದಲು ಇದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಸ್ಲೈಸ್‌ನೊಳಗೆ ನಾಲ್ಕು ಬೈಟ್‌ಗಳನ್ನು ನಕಲಿಸಲಾಗುತ್ತಿದೆ:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // ಸುರಕ್ಷತೆ: `ptr::copy` ಗಾಗಿನ ಷರತ್ತುಗಳನ್ನು ಮೇಲೆ ಪರಿಶೀಲಿಸಲಾಗಿದೆ,
        // `ptr::add` ಗಾಗಿರುವಂತೆ.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// `other` ನಲ್ಲಿರುವ ಎಲ್ಲ ಅಂಶಗಳನ್ನು `self` ನಲ್ಲಿ ಬದಲಾಯಿಸುತ್ತದೆ.
    ///
    /// `other` ನ ಉದ್ದವು `self` ನಂತೆಯೇ ಇರಬೇಕು.
    ///
    /// # Panics
    ///
    /// ಎರಡು ಚೂರುಗಳು ವಿಭಿನ್ನ ಉದ್ದಗಳನ್ನು ಹೊಂದಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರುತ್ತದೆ.
    ///
    /// # Example
    ///
    /// ಚೂರುಗಳಲ್ಲಿ ಎರಡು ಅಂಶಗಳನ್ನು ವಿನಿಮಯ ಮಾಡಿಕೊಳ್ಳುವುದು:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust ಒಂದು ನಿರ್ದಿಷ್ಟ ವ್ಯಾಪ್ತಿಯಲ್ಲಿ ಒಂದು ನಿರ್ದಿಷ್ಟ ದತ್ತಾಂಶಕ್ಕೆ ಕೇವಲ ಒಂದು ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವಿರಬಹುದು ಎಂದು ಜಾರಿಗೊಳಿಸುತ್ತದೆ.
    ///
    /// ಈ ಕಾರಣದಿಂದಾಗಿ, ಒಂದೇ ಸ್ಲೈಸ್‌ನಲ್ಲಿ `swap_with_slice` ಅನ್ನು ಬಳಸಲು ಪ್ರಯತ್ನಿಸುವುದರಿಂದ ಕಂಪೈಲ್ ವಿಫಲಗೊಳ್ಳುತ್ತದೆ:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// ಇದರೊಂದಿಗೆ ಕೆಲಸ ಮಾಡಲು, ಸ್ಲೈಸ್‌ನಿಂದ ಎರಡು ವಿಭಿನ್ನ ರೂಪಾಂತರಿತ ಉಪ-ಚೂರುಗಳನ್ನು ರಚಿಸಲು ನಾವು [`split_at_mut`] ಅನ್ನು ಬಳಸಬಹುದು:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // ಸುರಕ್ಷತೆ: `self` ವ್ಯಾಖ್ಯಾನದಿಂದ `self.len()` ಅಂಶಗಳಿಗೆ ಮಾನ್ಯವಾಗಿದೆ, ಮತ್ತು `src` ಆಗಿತ್ತು
        // ಒಂದೇ ಉದ್ದವನ್ನು ಹೊಂದಲು ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
        // ಚೂರುಗಳು ಅತಿಕ್ರಮಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ ಏಕೆಂದರೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳು ಪ್ರತ್ಯೇಕವಾಗಿವೆ.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// `align_to{,_mut}` ಗಾಗಿ ಮಧ್ಯ ಮತ್ತು ಹಿಂದುಳಿದ ಸ್ಲೈಸ್‌ನ ಉದ್ದವನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುವ ಕಾರ್ಯ.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // `rest` ಬಗ್ಗೆ ನಾವು ಏನು ಮಾಡಲಿದ್ದೇವೆಂದರೆ, ನಾವು ಕಡಿಮೆ ಸಂಖ್ಯೆಯ `T` ಗಳನ್ನು ಹಾಕಬಹುದು.
        //
        // ಮತ್ತು ಅಂತಹ ಪ್ರತಿಯೊಂದು "multiple" ಗೆ ನಮಗೆ ಎಷ್ಟು `ಟಿ`ಗಳು ಬೇಕು.
        //
        // ಉದಾಹರಣೆಗೆ T=u8 U=u16 ಅನ್ನು ಪರಿಗಣಿಸಿ.ನಂತರ ನಾವು 1 T ಅನ್ನು 2 Ts ನಲ್ಲಿ ಹಾಕಬಹುದು.ಸರಳ.
        // ಈಗ, ಉದಾಹರಣೆಗೆ size_of: : ಅನ್ನು ಪರಿಗಣಿಸಿ<T>=16, size_of::<U>=24.</u>
        // ನಾವು `rest` ಸ್ಲೈಸ್‌ನಲ್ಲಿ ಪ್ರತಿ 3 Ts ಬದಲಿಗೆ 2 Us ಗಳನ್ನು ಹಾಕಬಹುದು.
        // ಸ್ವಲ್ಪ ಹೆಚ್ಚು ಸಂಕೀರ್ಣವಾಗಿದೆ.
        //
        // ಇದನ್ನು ಲೆಕ್ಕಹಾಕಲು ಸೂತ್ರ:
        //
        // ನಮ್ಮ= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // ವಿಸ್ತರಿಸಲಾಗಿದೆ ಮತ್ತು ಸರಳೀಕರಿಸಲಾಗಿದೆ:
        //
        // ನಮ್ಮ=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // ಅದೃಷ್ಟವಶಾತ್ ಇವೆಲ್ಲವೂ ಸ್ಥಿರ-ಮೌಲ್ಯಮಾಪನವಾಗಿರುವುದರಿಂದ ... ಇಲ್ಲಿ ಕಾರ್ಯಕ್ಷಮತೆ ಮುಖ್ಯವಲ್ಲ!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // ಪುನರಾವರ್ತಿತ ಸ್ಟೈನ್‌ನ ಅಲ್ಗಾರಿದಮ್ ನಾವು ಇನ್ನೂ ಈ `const fn` ಅನ್ನು ಮಾಡಬೇಕು (ಮತ್ತು ನಾವು ಮಾಡಿದರೆ ಪುನರಾವರ್ತಿತ ಅಲ್ಗಾರಿದಮ್‌ಗೆ ಹಿಂತಿರುಗಬೇಕು) ಏಕೆಂದರೆ llvm ಅನ್ನು ಅವಲಂಬಿಸಲು ಇವೆಲ್ಲವನ್ನೂ ಸಹಕರಿಸುವುದು…ಜೊತೆಗೆ, ಇದು ನನಗೆ ಅನಾನುಕೂಲವನ್ನುಂಟು ಮಾಡುತ್ತದೆ.
            //
            //

            // ಸುರಕ್ಷತೆ: `a` ಮತ್ತು `b` ಅನ್ನು ಶೂನ್ಯೇತರ ಮೌಲ್ಯಗಳೆಂದು ಪರಿಶೀಲಿಸಲಾಗುತ್ತದೆ.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // b ಯಿಂದ 2 ರ ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ತೆಗೆದುಹಾಕಿ
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // ಸುರಕ್ಷತೆ: `b` ಅನ್ನು ಶೂನ್ಯೇತರ ಎಂದು ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // ಈ ಜ್ಞಾನದಿಂದ ಶಸ್ತ್ರಸಜ್ಜಿತವಾದ ನಾವು ಎಷ್ಟು `ಯು'ಗಳನ್ನು ಹೊಂದಿಕೊಳ್ಳಬಹುದು ಎಂಬುದನ್ನು ನಾವು ಕಂಡುಕೊಳ್ಳಬಹುದು!
        let us_len = self.len() / ts * us;
        // ಮತ್ತು ಹಿಂದುಳಿದ ಸ್ಲೈಸ್‌ನಲ್ಲಿ ಎಷ್ಟು `ಟಿ`ಗಳು ಇರುತ್ತವೆ!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// ಸ್ಲೈಸ್ ಅನ್ನು ಮತ್ತೊಂದು ಪ್ರಕಾರದ ಸ್ಲೈಸ್‌ಗೆ ಪರಿವರ್ತಿಸಿ, ಪ್ರಕಾರಗಳ ಜೋಡಣೆಯನ್ನು ಕಾಪಾಡಿಕೊಳ್ಳುವುದನ್ನು ಖಾತ್ರಿಪಡಿಸುತ್ತದೆ.
    ///
    /// ಈ ವಿಧಾನವು ಸ್ಲೈಸ್ ಅನ್ನು ಮೂರು ವಿಭಿನ್ನ ಹೋಳುಗಳಾಗಿ ವಿಭಜಿಸುತ್ತದೆ: ಪೂರ್ವಪ್ರತ್ಯಯ, ಹೊಸ ಪ್ರಕಾರದ ಮಧ್ಯದ ಸ್ಲೈಸ್ ಅನ್ನು ಸರಿಯಾಗಿ ಜೋಡಿಸಲಾಗಿದೆ ಮತ್ತು ಪ್ರತ್ಯಯ ಸ್ಲೈಸ್.
    /// ಈ ವಿಧಾನವು ಮಧ್ಯದ ಸ್ಲೈಸ್ ಅನ್ನು ನಿರ್ದಿಷ್ಟ ಪ್ರಕಾರ ಮತ್ತು ಇನ್ಪುಟ್ ಸ್ಲೈಸ್ಗೆ ಸಾಧ್ಯವಾದಷ್ಟು ದೊಡ್ಡ ಉದ್ದವಾಗಿಸಬಹುದು, ಆದರೆ ನಿಮ್ಮ ಅಲ್ಗಾರಿದಮ್ನ ಕಾರ್ಯಕ್ಷಮತೆ ಮಾತ್ರ ಅದರ ಮೇಲೆ ಅವಲಂಬಿತವಾಗಿರುತ್ತದೆ, ಅದರ ಸರಿಯಾದತೆಯಲ್ಲ.
    ///
    /// ಎಲ್ಲಾ ಇನ್ಪುಟ್ ಡೇಟಾವನ್ನು ಪೂರ್ವಪ್ರತ್ಯಯ ಅಥವಾ ಪ್ರತ್ಯಯ ಸ್ಲೈಸ್ ಆಗಿ ಹಿಂತಿರುಗಿಸಲು ಅನುಮತಿಸಲಾಗಿದೆ.
    ///
    /// ಇನ್ಪುಟ್ ಎಲಿಮೆಂಟ್ `T` ಅಥವಾ output ಟ್ಪುಟ್ ಎಲಿಮೆಂಟ್ `U` ಶೂನ್ಯ-ಗಾತ್ರದಾಗ ಈ ವಿಧಾನಕ್ಕೆ ಯಾವುದೇ ಉದ್ದೇಶವಿಲ್ಲ ಮತ್ತು ಯಾವುದನ್ನೂ ವಿಭಜಿಸದೆ ಮೂಲ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// ಈ ವಿಧಾನವು ಮೂಲಭೂತವಾಗಿ ಹಿಂತಿರುಗಿದ ಮಧ್ಯದ ಸ್ಲೈಸ್‌ನಲ್ಲಿನ ಅಂಶಗಳಿಗೆ ಸಂಬಂಧಿಸಿದಂತೆ `transmute` ಆಗಿದೆ, ಆದ್ದರಿಂದ `transmute::<T, U>` ಗೆ ಸಂಬಂಧಿಸಿದ ಎಲ್ಲಾ ಸಾಮಾನ್ಯ ಕೇವಿಯಟ್‌ಗಳು ಸಹ ಇಲ್ಲಿ ಅನ್ವಯಿಸುತ್ತವೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // ಈ ಕಾರ್ಯದ ಬಹುಪಾಲು ಸ್ಥಿರ-ಮೌಲ್ಯಮಾಪನವಾಗಲಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // ZST ಗಳನ್ನು ವಿಶೇಷವಾಗಿ ನಿರ್ವಹಿಸಿ, ಅಂದರೆ-ಅವುಗಳನ್ನು ನಿಭಾಯಿಸಬೇಡಿ.
            return (self, &[], &[]);
        }

        // ಮೊದಲಿಗೆ, ಮೊದಲ ಮತ್ತು 2 ನೇ ಸ್ಲೈಸ್‌ಗಳ ನಡುವೆ ನಾವು ಯಾವ ಹಂತದಲ್ಲಿ ವಿಭಜಿಸುತ್ತೇವೆ ಎಂಬುದನ್ನು ಕಂಡುಕೊಳ್ಳಿ.
        // ptr.align_offset ನೊಂದಿಗೆ ಸುಲಭ.
        let ptr = self.as_ptr();
        // ಸುರಕ್ಷತೆ: ವಿವರವಾದ ಸುರಕ್ಷತಾ ಕಾಮೆಂಟ್‌ಗಾಗಿ `align_to_mut` ವಿಧಾನವನ್ನು ನೋಡಿ.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // ಸುರಕ್ಷತೆ: ಈಗ `rest` ಖಂಡಿತವಾಗಿಯೂ ಜೋಡಿಸಲ್ಪಟ್ಟಿದೆ, ಆದ್ದರಿಂದ ಕೆಳಗಿನ `from_raw_parts` ಸರಿ,
            // ನಾವು `T` ಅನ್ನು `U` ಗೆ ಸುರಕ್ಷಿತವಾಗಿ ಪರಿವರ್ತಿಸಬಹುದು ಎಂದು ಕರೆ ಮಾಡುವವರು ಖಾತರಿಪಡಿಸುತ್ತಾರೆ.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// ಸ್ಲೈಸ್ ಅನ್ನು ಮತ್ತೊಂದು ಪ್ರಕಾರದ ಸ್ಲೈಸ್‌ಗೆ ಪರಿವರ್ತಿಸಿ, ಪ್ರಕಾರಗಳ ಜೋಡಣೆಯನ್ನು ಕಾಪಾಡಿಕೊಳ್ಳುವುದನ್ನು ಖಾತ್ರಿಪಡಿಸುತ್ತದೆ.
    ///
    /// ಈ ವಿಧಾನವು ಸ್ಲೈಸ್ ಅನ್ನು ಮೂರು ವಿಭಿನ್ನ ಹೋಳುಗಳಾಗಿ ವಿಭಜಿಸುತ್ತದೆ: ಪೂರ್ವಪ್ರತ್ಯಯ, ಹೊಸ ಪ್ರಕಾರದ ಮಧ್ಯದ ಸ್ಲೈಸ್ ಅನ್ನು ಸರಿಯಾಗಿ ಜೋಡಿಸಲಾಗಿದೆ ಮತ್ತು ಪ್ರತ್ಯಯ ಸ್ಲೈಸ್.
    /// ಈ ವಿಧಾನವು ಮಧ್ಯದ ಸ್ಲೈಸ್ ಅನ್ನು ನಿರ್ದಿಷ್ಟ ಪ್ರಕಾರ ಮತ್ತು ಇನ್ಪುಟ್ ಸ್ಲೈಸ್ಗೆ ಸಾಧ್ಯವಾದಷ್ಟು ದೊಡ್ಡ ಉದ್ದವಾಗಿಸಬಹುದು, ಆದರೆ ನಿಮ್ಮ ಅಲ್ಗಾರಿದಮ್ನ ಕಾರ್ಯಕ್ಷಮತೆ ಮಾತ್ರ ಅದರ ಮೇಲೆ ಅವಲಂಬಿತವಾಗಿರುತ್ತದೆ, ಅದರ ಸರಿಯಾದತೆಯಲ್ಲ.
    ///
    /// ಎಲ್ಲಾ ಇನ್ಪುಟ್ ಡೇಟಾವನ್ನು ಪೂರ್ವಪ್ರತ್ಯಯ ಅಥವಾ ಪ್ರತ್ಯಯ ಸ್ಲೈಸ್ ಆಗಿ ಹಿಂತಿರುಗಿಸಲು ಅನುಮತಿಸಲಾಗಿದೆ.
    ///
    /// ಇನ್ಪುಟ್ ಎಲಿಮೆಂಟ್ `T` ಅಥವಾ output ಟ್ಪುಟ್ ಎಲಿಮೆಂಟ್ `U` ಶೂನ್ಯ-ಗಾತ್ರದಾಗ ಈ ವಿಧಾನಕ್ಕೆ ಯಾವುದೇ ಉದ್ದೇಶವಿಲ್ಲ ಮತ್ತು ಯಾವುದನ್ನೂ ವಿಭಜಿಸದೆ ಮೂಲ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// ಈ ವಿಧಾನವು ಮೂಲಭೂತವಾಗಿ ಹಿಂತಿರುಗಿದ ಮಧ್ಯದ ಸ್ಲೈಸ್‌ನಲ್ಲಿನ ಅಂಶಗಳಿಗೆ ಸಂಬಂಧಿಸಿದಂತೆ `transmute` ಆಗಿದೆ, ಆದ್ದರಿಂದ `transmute::<T, U>` ಗೆ ಸಂಬಂಧಿಸಿದ ಎಲ್ಲಾ ಸಾಮಾನ್ಯ ಕೇವಿಯಟ್‌ಗಳು ಸಹ ಇಲ್ಲಿ ಅನ್ವಯಿಸುತ್ತವೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // ಈ ಕಾರ್ಯದ ಬಹುಪಾಲು ಸ್ಥಿರ-ಮೌಲ್ಯಮಾಪನವಾಗಲಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // ZST ಗಳನ್ನು ವಿಶೇಷವಾಗಿ ನಿರ್ವಹಿಸಿ, ಅಂದರೆ-ಅವುಗಳನ್ನು ನಿಭಾಯಿಸಬೇಡಿ.
            return (self, &mut [], &mut []);
        }

        // ಮೊದಲಿಗೆ, ಮೊದಲ ಮತ್ತು 2 ನೇ ಸ್ಲೈಸ್‌ಗಳ ನಡುವೆ ನಾವು ಯಾವ ಹಂತದಲ್ಲಿ ವಿಭಜಿಸುತ್ತೇವೆ ಎಂಬುದನ್ನು ಕಂಡುಕೊಳ್ಳಿ.
        // ptr.align_offset ನೊಂದಿಗೆ ಸುಲಭ.
        let ptr = self.as_ptr();
        // ಸುರಕ್ಷತೆ: ಇಲ್ಲಿ ನಾವು U ಗಾಗಿ ಜೋಡಿಸಲಾದ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಬಳಸುತ್ತೇವೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳುತ್ತಿದ್ದೇವೆ
        // ಉಳಿದ ವಿಧಾನ.ಯು ಅನ್ನು ಗುರಿಯಾಗಿರಿಸಿಕೊಂಡು ಜೋಡಣೆಯೊಂದಿಗೆ&[ಟಿ] ಗೆ ಪಾಯಿಂಟರ್ ಅನ್ನು ಹಾದುಹೋಗುವ ಮೂಲಕ ಇದನ್ನು ಮಾಡಲಾಗುತ್ತದೆ.
        // `crate::ptr::align_offset` ಸರಿಯಾಗಿ ಜೋಡಿಸಲಾದ ಮತ್ತು ಮಾನ್ಯ ಪಾಯಿಂಟರ್ `ptr` (ಇದನ್ನು `self` ಗೆ ಉಲ್ಲೇಖದಿಂದ ಬಂದಿದೆ) ಮತ್ತು ಎರಡು ಶಕ್ತಿಯ ಶಕ್ತಿಯೊಂದಿಗೆ ಕರೆಯಲಾಗುತ್ತದೆ (ಇದು U ಗಾಗಿ ಜೋಡಣೆಯಿಂದ ಬಂದಿರುವುದರಿಂದ), ಅದರ ಸುರಕ್ಷತಾ ನಿರ್ಬಂಧಗಳನ್ನು ಪೂರೈಸುತ್ತದೆ.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // ಇದರ ನಂತರ ನಾವು ಮತ್ತೆ `rest` ಅನ್ನು ಬಳಸಲಾಗುವುದಿಲ್ಲ, ಅದು ಅದರ ಅಲಿಯಾಸ್ `mut_ptr` ಅನ್ನು ಅಮಾನ್ಯಗೊಳಿಸುತ್ತದೆ!ಸುರಕ್ಷತೆ: `align_to` ಗಾಗಿ ಕಾಮೆಂಟ್‌ಗಳನ್ನು ನೋಡಿ.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// ಈ ಸ್ಲೈಸ್‌ನ ಅಂಶಗಳನ್ನು ವಿಂಗಡಿಸಲಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ.
    ///
    /// ಅಂದರೆ, ಪ್ರತಿ ಅಂಶ `a` ಮತ್ತು ಅದರ ಕೆಳಗಿನ ಅಂಶ `b` ಗೆ, `a <= b` ಹಿಡಿದಿರಬೇಕು.ಸ್ಲೈಸ್ ನಿಖರವಾಗಿ ಶೂನ್ಯ ಅಥವಾ ಒಂದು ಅಂಶವನ್ನು ನೀಡಿದರೆ, `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// `Self::Item` ಕೇವಲ `PartialOrd` ಆಗಿದ್ದರೆ, ಆದರೆ `Ord` ಅಲ್ಲದಿದ್ದರೆ, ಮೇಲಿನ ಎರಡು ವ್ಯಾಖ್ಯಾನವು ಯಾವುದೇ ಎರಡು ಸತತ ವಸ್ತುಗಳನ್ನು ಹೋಲಿಸಲಾಗದಿದ್ದರೆ ಈ ಕಾರ್ಯವು `false` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ ಎಂದು ಸೂಚಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// ಕೊಟ್ಟಿರುವ ತುಲನಾತ್ಮಕ ಕಾರ್ಯವನ್ನು ಬಳಸಿಕೊಂಡು ಈ ಸ್ಲೈಸ್‌ನ ಅಂಶಗಳನ್ನು ವಿಂಗಡಿಸಲಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ.
    ///
    /// `PartialOrd::partial_cmp` ಅನ್ನು ಬಳಸುವ ಬದಲು, ಈ ಕಾರ್ಯವು ಎರಡು ಅಂಶಗಳ ಕ್ರಮವನ್ನು ನಿರ್ಧರಿಸಲು ಕೊಟ್ಟಿರುವ `compare` ಕಾರ್ಯವನ್ನು ಬಳಸುತ್ತದೆ.
    /// ಅದನ್ನು ಹೊರತುಪಡಿಸಿ, ಇದು [`is_sorted`] ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ;ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// ಕೊಟ್ಟಿರುವ ಕೀ ಹೊರತೆಗೆಯುವ ಕಾರ್ಯವನ್ನು ಬಳಸಿಕೊಂಡು ಈ ಸ್ಲೈಸ್‌ನ ಅಂಶಗಳನ್ನು ವಿಂಗಡಿಸಲಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ.
    ///
    /// ಸ್ಲೈಸ್‌ನ ಅಂಶಗಳನ್ನು ನೇರವಾಗಿ ಹೋಲಿಸುವ ಬದಲು, ಈ ಕಾರ್ಯವು `f` ನಿಂದ ನಿರ್ಧರಿಸಲ್ಪಟ್ಟ ಅಂಶಗಳ ಕೀಲಿಗಳನ್ನು ಹೋಲಿಸುತ್ತದೆ.
    /// ಅದನ್ನು ಹೊರತುಪಡಿಸಿ, ಇದು [`is_sorted`] ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ;ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// ಕೊಟ್ಟಿರುವ ಮುನ್ಸೂಚನೆಯ ಪ್ರಕಾರ ವಿಭಜನಾ ಬಿಂದುವಿನ ಸೂಚಿಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ (ಎರಡನೇ ವಿಭಾಗದ ಮೊದಲ ಅಂಶದ ಸೂಚ್ಯಂಕ).
    ///
    /// ಕೊಟ್ಟಿರುವ ಮುನ್ಸೂಚನೆಯ ಪ್ರಕಾರ ಸ್ಲೈಸ್ ಅನ್ನು ವಿಭಜಿಸಲಾಗಿದೆ ಎಂದು is ಹಿಸಲಾಗಿದೆ.
    /// ಇದರರ್ಥ, icate ಹಿಸುವ ಆದಾಯವು ನಿಜವಾಗಿದ್ದ ಎಲ್ಲಾ ಅಂಶಗಳು ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದಲ್ಲಿರುತ್ತವೆ ಮತ್ತು pred ಹಿಸುವ ಸುಳ್ಳನ್ನು ಹಿಂದಿರುಗಿಸುವ ಎಲ್ಲಾ ಅಂಶಗಳು ಕೊನೆಯಲ್ಲಿರುತ್ತವೆ.
    ///
    /// ಉದಾಹರಣೆಗೆ, [7, 15, 3, 5, 4, 12, 6] ಎನ್ನುವುದು x% 2!=0 ಎಂಬ ಮುನ್ಸೂಚನೆಯ ಅಡಿಯಲ್ಲಿ ಒಂದು ವಿಭಜನೆಯಾಗಿದೆ (ಎಲ್ಲಾ ಬೆಸ ಸಂಖ್ಯೆಗಳು ಪ್ರಾರಂಭದಲ್ಲಿವೆ, ಎಲ್ಲವೂ ಕೊನೆಯಲ್ಲಿ ಸಹ).
    ///
    /// ಈ ಸ್ಲೈಸ್ ಅನ್ನು ವಿಭಜಿಸದಿದ್ದರೆ, ಹಿಂದಿರುಗಿದ ಫಲಿತಾಂಶವು ಅನಿರ್ದಿಷ್ಟ ಮತ್ತು ಅರ್ಥಹೀನವಾಗಿರುತ್ತದೆ, ಏಕೆಂದರೆ ಈ ವಿಧಾನವು ಒಂದು ರೀತಿಯ ಬೈನರಿ ಹುಡುಕಾಟವನ್ನು ಮಾಡುತ್ತದೆ.
    ///
    /// [`binary_search`], [`binary_search_by`], ಮತ್ತು [`binary_search_by_key`] ಸಹ ನೋಡಿ.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // ಸುರಕ್ಷತೆ: ಯಾವಾಗ `left < right`, `left <= mid < right`.
            // ಆದ್ದರಿಂದ `left` ಯಾವಾಗಲೂ ಹೆಚ್ಚಾಗುತ್ತದೆ ಮತ್ತು `right` ಯಾವಾಗಲೂ ಕಡಿಮೆಯಾಗುತ್ತದೆ, ಮತ್ತು ಅವುಗಳಲ್ಲಿ ಯಾವುದನ್ನಾದರೂ ಆಯ್ಕೆ ಮಾಡಲಾಗುತ್ತದೆ.ಎರಡೂ ಸಂದರ್ಭಗಳಲ್ಲಿ `left <= right` ತೃಪ್ತಿಗೊಂಡಿದೆ.ಆದ್ದರಿಂದ ಒಂದು ಹಂತದಲ್ಲಿ `left < right` ಇದ್ದರೆ, ಮುಂದಿನ ಹಂತದಲ್ಲಿ `left <= right` ತೃಪ್ತಿಪಡಿಸುತ್ತದೆ.
            //
            // ಆದ್ದರಿಂದ `left != right` ಇರುವವರೆಗೆ, `0 <= left < right <= len` ತೃಪ್ತಿಗೊಳ್ಳುತ್ತದೆ ಮತ್ತು ಈ ಸಂದರ್ಭದಲ್ಲಿ `0 <= mid < len` ಸಹ ತೃಪ್ತಿಗೊಳ್ಳುತ್ತದೆ.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: ನಾವು ಅವುಗಳನ್ನು ಒಂದೇ ಉದ್ದಕ್ಕೆ ಸ್ಪಷ್ಟವಾಗಿ ಕತ್ತರಿಸಬೇಕಾಗಿದೆ
        // ಗಡಿ ಪರಿಶೀಲನೆಯನ್ನು ಆಪ್ಟಿಮೈಜರ್‌ಗೆ ಸುಲಭಗೊಳಿಸಲು.
        // ಆದರೆ ಇದನ್ನು ಅವಲಂಬಿಸಲಾಗದ ಕಾರಣ ನಾವು ಟಿ: ಕಾಪಿಗಾಗಿ ಸ್ಪಷ್ಟ ವಿಶೇಷತೆಯನ್ನು ಹೊಂದಿದ್ದೇವೆ.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// ಖಾಲಿ ಸ್ಲೈಸ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// ರೂಪಾಂತರಿತ ಖಾಲಿ ಸ್ಲೈಸ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// ಚೂರುಗಳಲ್ಲಿನ ಮಾದರಿಗಳು, ಪ್ರಸ್ತುತ, `strip_prefix` ಮತ್ತು `strip_suffix` ನಿಂದ ಮಾತ್ರ ಬಳಸಲ್ಪಡುತ್ತವೆ.
/// future ಹಂತದಲ್ಲಿ, `core::str::Pattern` ಅನ್ನು (ಬರವಣಿಗೆಯ ಸಮಯದಲ್ಲಿ `str` ಗೆ ಸೀಮಿತವಾಗಿದೆ) ಚೂರುಗಳಿಗೆ ಸಾಮಾನ್ಯೀಕರಿಸಲು ನಾವು ಆಶಿಸುತ್ತೇವೆ, ಮತ್ತು ನಂತರ ಈ trait ಅನ್ನು ಬದಲಾಯಿಸಲಾಗುತ್ತದೆ ಅಥವಾ ರದ್ದುಗೊಳಿಸಲಾಗುತ್ತದೆ.
///
pub trait SlicePattern {
    /// ಸ್ಲೈಸ್‌ನ ಅಂಶ ಪ್ರಕಾರವನ್ನು ಹೊಂದಿಸಲಾಗಿದೆ.
    type Item;

    /// ಪ್ರಸ್ತುತ, `SlicePattern` ನ ಗ್ರಾಹಕರಿಗೆ ಸ್ಲೈಸ್ ಅಗತ್ಯವಿದೆ.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}