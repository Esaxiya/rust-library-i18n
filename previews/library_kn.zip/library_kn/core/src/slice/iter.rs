// ignore-tidy-filelength
//! `[T]` ಗಾಗಿ ಪುನರಾವರ್ತಕರ ಗುಂಪಿನ ವ್ಯಾಖ್ಯಾನಗಳು.

#[macro_use] // ಆಮದು ಪುನರಾವರ್ತಕ!ಮತ್ತು ಫಾರ್ವರ್ಡ್_ಇಟರೇಟರ್!
mod macros;

use crate::cmp;
use crate::cmp::Ordering;
use crate::fmt;
use crate::intrinsics::{assume, exact_div, unchecked_sub};
use crate::iter::{FusedIterator, TrustedLen, TrustedRandomAccess};
use crate::marker::{PhantomData, Send, Sized, Sync};
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

use super::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a [T] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut [T] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

// ಮ್ಯಾಕ್ರೋ ಸಹಾಯಕ ಕಾರ್ಯಗಳು
#[inline(always)]
fn size_from_ptr<T>(_: *const T) -> usize {
    mem::size_of::<T>()
}

/// ಬದಲಾಯಿಸಲಾಗದ ಸ್ಲೈಸ್ ಪುನರಾವರ್ತಕ
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`iter`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Examples
///
/// ಮೂಲ ಬಳಕೆ:
///
/// ```
/// // ಮೊದಲಿಗೆ, `Iter` struct (ಇಲ್ಲಿ `&[usize]`) ಪಡೆಯಲು `iter` ವಿಧಾನವನ್ನು ಹೊಂದಿರುವ ಪ್ರಕಾರವನ್ನು ನಾವು ಘೋಷಿಸುತ್ತೇವೆ:
/// let slice = &[1, 2, 3];
///
/// // ನಂತರ, ನಾವು ಅದರ ಮೇಲೆ ಪುನರಾವರ್ತಿಸುತ್ತೇವೆ:
/// for element in slice.iter() {
///     println!("{}", element);
/// }
/// ```
///
/// [`iter`]: slice::iter
/// [slices]: slice
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    ptr: NonNull<T>,
    end: *const T, // ಟಿ Z ಡ್‌ಎಸ್‌ಟಿ ಆಗಿದ್ದರೆ, ಇದು ವಾಸ್ತವವಾಗಿ ಪಿಟಿಆರ್ + ಲೆನ್ ಆಗಿದೆ.ಈ ಎನ್ಕೋಡಿಂಗ್ ಅನ್ನು ಆಯ್ಕೆ ಮಾಡಲಾಗಿದೆ
    // ptr==ಅಂತ್ಯವು ಇಟರೇಟರ್ ಖಾಲಿಯಾಗಿರುವುದಕ್ಕೆ ತ್ವರಿತ ಪರೀಕ್ಷೆಯಾಗಿದೆ, ಇದು ZST ಮತ್ತು ZST ಅಲ್ಲದ ಎರಡಕ್ಕೂ ಕೆಲಸ ಮಾಡುತ್ತದೆ.
    //
    _marker: PhantomData<&'a T>,
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

impl<'a, T> Iter<'a, T> {
    #[inline]
    pub(super) fn new(slice: &'a [T]) -> Self {
        let ptr = slice.as_ptr();
        // ಸುರಕ್ಷತೆ: `IterMut::new` ಗೆ ಹೋಲುತ್ತದೆ.
        unsafe {
            assume(!ptr.is_null());

            let end = if mem::size_of::<T>() == 0 {
                (ptr as *const u8).wrapping_add(slice.len()) as *const T
            } else {
                ptr.add(slice.len())
            };

            Self { ptr: NonNull::new_unchecked(ptr as *mut T), end, _marker: PhantomData }
        }
    }

    /// ಆಧಾರವಾಗಿರುವ ಡೇಟಾವನ್ನು ಮೂಲ ಡೇಟಾದ ಉಪವಿಭಾಗವಾಗಿ ವೀಕ್ಷಿಸುತ್ತದೆ.
    ///
    /// ಇದು ಮೂಲ ಸ್ಲೈಸ್‌ನಂತೆಯೇ ಜೀವಿತಾವಧಿಯನ್ನು ಹೊಂದಿದೆ, ಮತ್ತು ಇದು ಅಸ್ತಿತ್ವದಲ್ಲಿರುವಾಗ ಪುನರಾವರ್ತಕವನ್ನು ಬಳಸುವುದನ್ನು ಮುಂದುವರಿಸಬಹುದು.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// // ಮೊದಲಿಗೆ, `Iter` struct (ಇಲ್ಲಿ `&[usize]`) ಪಡೆಯಲು `iter` ವಿಧಾನವನ್ನು ಹೊಂದಿರುವ ಪ್ರಕಾರವನ್ನು ನಾವು ಘೋಷಿಸುತ್ತೇವೆ:
    /////
    /// let slice = &[1, 2, 3];
    ///
    /// // ನಂತರ, ನಾವು ಪುನರಾವರ್ತಕವನ್ನು ಪಡೆಯುತ್ತೇವೆ:
    /// let mut iter = slice.iter();
    /// // ಹಾಗಾಗಿ `as_slice` ವಿಧಾನವು ಇಲ್ಲಿಗೆ ಹಿಂದಿರುಗುವದನ್ನು ನಾವು ಮುದ್ರಿಸಿದರೆ, ನಮ್ಮಲ್ಲಿ "[1, 2, 3]" ಇದೆ:
    /// println!("{:?}", iter.as_slice());
    ///
    /// // ಮುಂದೆ, ನಾವು ಸ್ಲೈಸ್‌ನ ಎರಡನೇ ಅಂಶಕ್ಕೆ ಹೋಗುತ್ತೇವೆ:
    /// iter.next();
    /// // ಈಗ `as_slice` "[2, 3]" ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ:
    /// println!("{:?}", iter.as_slice());
    /// ```
    #[stable(feature = "iter_to_slice", since = "1.4.0")]
    pub fn as_slice(&self) -> &'a [T] {
        self.make_slice()
    }
}

iterator! {struct Iter -> *const T, &'a T, const, {/* no mut */}, {
    fn is_sorted_by<F>(self, mut compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        self.as_slice().windows(2).all(|w| {
            compare(&&w[0], &&w[1]).map(|o| o != Ordering::Greater).unwrap_or(false)
        })
    }
}}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ptr: self.ptr, end: self.end, _marker: self._marker }
    }
}

#[stable(feature = "slice_iter_as_ref", since = "1.13.0")]
impl<T> AsRef<[T]> for Iter<'_, T> {
    fn as_ref(&self) -> &[T] {
        self.as_slice()
    }
}

/// ರೂಪಾಂತರಿತ ಸ್ಲೈಸ್ ಪುನರಾವರ್ತಕ.
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`iter_mut`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Examples
///
/// ಮೂಲ ಬಳಕೆ:
///
/// ```
/// // ಮೊದಲಿಗೆ, `IterMut` struct (ಇಲ್ಲಿ `&[usize]`) ಪಡೆಯಲು `iter_mut` ವಿಧಾನವನ್ನು ಹೊಂದಿರುವ ಪ್ರಕಾರವನ್ನು ನಾವು ಘೋಷಿಸುತ್ತೇವೆ:
/////
/// let mut slice = &mut [1, 2, 3];
///
/// // ನಂತರ, ನಾವು ಅದರ ಮೇಲೆ ಪುನರಾವರ್ತಿಸುತ್ತೇವೆ ಮತ್ತು ಪ್ರತಿ ಅಂಶ ಮೌಲ್ಯವನ್ನು ಹೆಚ್ಚಿಸುತ್ತೇವೆ:
/// for element in slice.iter_mut() {
///     *element += 1;
/// }
///
/// // ನಾವು ಈಗ "[2, 3, 4]" ಅನ್ನು ಹೊಂದಿದ್ದೇವೆ:
/// println!("{:?}", slice);
/// ```
///
/// [`iter_mut`]: slice::iter_mut
/// [slices]: slice
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    ptr: NonNull<T>,
    end: *mut T, // ಟಿ Z ಡ್‌ಎಸ್‌ಟಿ ಆಗಿದ್ದರೆ, ಇದು ವಾಸ್ತವವಾಗಿ ಪಿಟಿಆರ್ + ಲೆನ್ ಆಗಿದೆ.ಈ ಎನ್ಕೋಡಿಂಗ್ ಅನ್ನು ಆಯ್ಕೆ ಮಾಡಲಾಗಿದೆ
    // ptr==ಅಂತ್ಯವು ಇಟರೇಟರ್ ಖಾಲಿಯಾಗಿರುವುದಕ್ಕೆ ತ್ವರಿತ ಪರೀಕ್ಷೆಯಾಗಿದೆ, ಇದು ZST ಮತ್ತು ZST ಅಲ್ಲದ ಎರಡಕ್ಕೂ ಕೆಲಸ ಮಾಡುತ್ತದೆ.
    //
    _marker: PhantomData<&'a mut T>,
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.make_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

impl<'a, T> IterMut<'a, T> {
    #[inline]
    pub(super) fn new(slice: &'a mut [T]) -> Self {
        let ptr = slice.as_mut_ptr();
        // ಸುರಕ್ಷತೆ: ಇಲ್ಲಿ ಹಲವಾರು ವಿಷಯಗಳಿವೆ:
        //
        // `ptr` `slice.as_ptr()` ನಿಂದ ಪಡೆಯಲಾಗಿದೆ, ಅಲ್ಲಿ `slice` ಮಾನ್ಯ ಉಲ್ಲೇಖವಾಗಿದೆ ಆದ್ದರಿಂದ ಇದು NUL ಅಲ್ಲದ ಮತ್ತು `NonNull::new_unchecked` ಗೆ ಬಳಸಲು ಸುರಕ್ಷಿತವಾಗಿದೆ.
        //
        //
        // ಆರಂಭಿಕ ಪಾಯಿಂಟರ್‌ಗೆ `slice.len()` ಅನ್ನು ಸೇರಿಸುವುದರಿಂದ `slice` ನ ಕೊನೆಯಲ್ಲಿ ಪಾಯಿಂಟರ್ ನೀಡುತ್ತದೆ.
        // `end` ಎಂದಿಗೂ ಡಿಫರೆನ್ಸ್ ಮಾಡಲಾಗುವುದಿಲ್ಲ, ಇಟರೇಟರ್ ಮಾಡಲಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸಲು `ptr` ನೊಂದಿಗೆ ನೇರ ಪಾಯಿಂಟರ್ ಸಮಾನತೆಗಾಗಿ ಮಾತ್ರ ಪರಿಶೀಲಿಸಲಾಗುತ್ತದೆ.
        //
        // ZST ಯ ಸಂದರ್ಭದಲ್ಲಿ, ಎಂಡ್ ಪಾಯಿಂಟರ್ ಕೇವಲ ಸ್ಟಾರ್ಟ್ ಪಾಯಿಂಟರ್ ಮತ್ತು ಉದ್ದವಾಗಿದೆ, ಇದು ವೇಗದ `ptr == end` ಚೆಕ್ ಅನ್ನು ಸಹ ಅನುಮತಿಸುತ್ತದೆ.
        //
        // ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ `next_unchecked!` ಮತ್ತು `is_empty!` ಮ್ಯಾಕ್ರೋಗಳು ಮತ್ತು `post_inc_start` ವಿಧಾನವನ್ನು ನೋಡಿ.
        //
        //
        //
        //
        //
        unsafe {
            assume(!ptr.is_null());

            let end = if mem::size_of::<T>() == 0 {
                (ptr as *mut u8).wrapping_add(slice.len()) as *mut T
            } else {
                ptr.add(slice.len())
            };

            Self { ptr: NonNull::new_unchecked(ptr), end, _marker: PhantomData }
        }
    }

    /// ಆಧಾರವಾಗಿರುವ ಡೇಟಾವನ್ನು ಮೂಲ ಡೇಟಾದ ಉಪವಿಭಾಗವಾಗಿ ವೀಕ್ಷಿಸುತ್ತದೆ.
    ///
    /// ಅಲಿಯಾಸ್ ಎಂದು `&mut` ಉಲ್ಲೇಖಗಳನ್ನು ರಚಿಸುವುದನ್ನು ತಪ್ಪಿಸಲು, ಇದು ಪುನರಾವರ್ತಕವನ್ನು ಸೇವಿಸಲು ಒತ್ತಾಯಿಸಲಾಗುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// // ಮೊದಲಿಗೆ, `IterMut` struct (ಇಲ್ಲಿ `&[usize]`) ಪಡೆಯಲು `iter_mut` ವಿಧಾನವನ್ನು ಹೊಂದಿರುವ ಪ್ರಕಾರವನ್ನು ನಾವು ಘೋಷಿಸುತ್ತೇವೆ:
    /////
    /// let mut slice = &mut [1, 2, 3];
    ///
    /// {
    ///     // ನಂತರ, ನಾವು ಪುನರಾವರ್ತಕವನ್ನು ಪಡೆಯುತ್ತೇವೆ:
    ///     let mut iter = slice.iter_mut();
    ///     // ನಾವು ಮುಂದಿನ ಅಂಶಕ್ಕೆ ಹೋಗುತ್ತೇವೆ:
    ///     iter.next();
    ///     // ಹಾಗಾಗಿ `into_slice` ವಿಧಾನವು ಇಲ್ಲಿಗೆ ಹಿಂದಿರುಗುವದನ್ನು ನಾವು ಮುದ್ರಿಸಿದರೆ, ನಮ್ಮಲ್ಲಿ "[2, 3]" ಇದೆ:
    ///     println!("{:?}", iter.into_slice());
    /// }
    ///
    /// // ಈಗ ಸ್ಲೈಸ್‌ನ ಮೌಲ್ಯವನ್ನು ಮಾರ್ಪಡಿಸೋಣ:
    /// {
    ///     // ಮೊದಲು ನಾವು ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತೇವೆ:
    ///     let mut iter = slice.iter_mut();
    ///     // `next` ವಿಧಾನದಿಂದ ಹಿಂತಿರುಗಿಸಲಾದ ಸ್ಲೈಸ್‌ನ ಮೊದಲ ಅಂಶದ ಮೌಲ್ಯವನ್ನು ನಾವು ಬದಲಾಯಿಸುತ್ತೇವೆ:
    ///     *iter.next().unwrap() += 1;
    /// }
    /// // ಈಗ ಸ್ಲೈಸ್ "[2, 2, 3]" ಆಗಿದೆ:
    /// println!("{:?}", slice);
    /// ```
    #[stable(feature = "iter_to_slice", since = "1.4.0")]
    pub fn into_slice(self) -> &'a mut [T] {
        // ಸುರಕ್ಷತೆ: ಪಾಯಿಂಟರ್‌ನೊಂದಿಗೆ ರೂಪಾಂತರಿತ ಸ್ಲೈಸ್‌ನಿಂದ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸಲಾಗಿದೆ
        // `self.ptr` ಮತ್ತು ಉದ್ದ `len!(self)`.
        // `from_raw_parts_mut` ಗಾಗಿ ಎಲ್ಲಾ ಪೂರ್ವಾಪೇಕ್ಷಿತಗಳನ್ನು ಪೂರೈಸಲಾಗುತ್ತದೆ ಎಂದು ಇದು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
        unsafe { from_raw_parts_mut(self.ptr.as_ptr(), len!(self)) }
    }

    /// ಆಧಾರವಾಗಿರುವ ಡೇಟಾವನ್ನು ಮೂಲ ಡೇಟಾದ ಉಪವಿಭಾಗವಾಗಿ ವೀಕ್ಷಿಸುತ್ತದೆ.
    ///
    /// ಅಲಿಯಾಸ್ ಎಂದು `&mut [T]` ಉಲ್ಲೇಖಗಳನ್ನು ರಚಿಸುವುದನ್ನು ತಪ್ಪಿಸಲು, ಹಿಂದಿರುಗಿದ ಸ್ಲೈಸ್ ತನ್ನ ಜೀವಿತಾವಧಿಯನ್ನು ಪುನರಾವರ್ತಕದಿಂದ ಎರವಲು ಪಡೆಯುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// # #![feature(slice_iter_mut_as_slice)]
    /// let mut slice: &mut [usize] = &mut [1, 2, 3];
    ///
    /// // ಮೊದಲಿಗೆ, ನಾವು ಪುನರಾವರ್ತಕವನ್ನು ಪಡೆಯುತ್ತೇವೆ:
    /// let mut iter = slice.iter_mut();
    /// // ಆದ್ದರಿಂದ `as_slice` ವಿಧಾನವು ಇಲ್ಲಿಗೆ ಏನು ಮರಳುತ್ತದೆ ಎಂಬುದನ್ನು ನಾವು ಪರಿಶೀಲಿಸಿದರೆ, ನಮ್ಮಲ್ಲಿ "[1, 2, 3]" ಇದೆ:
    /// assert_eq!(iter.as_slice(), &[1, 2, 3]);
    ///
    /// // ಮುಂದೆ, ನಾವು ಸ್ಲೈಸ್‌ನ ಎರಡನೇ ಅಂಶಕ್ಕೆ ಹೋಗುತ್ತೇವೆ:
    /// iter.next();
    /// // ಈಗ `as_slice` "[2, 3]" ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ:
    /// assert_eq!(iter.as_slice(), &[2, 3]);
    /// ```
    #[unstable(feature = "slice_iter_mut_as_slice", reason = "recently added", issue = "58957")]
    pub fn as_slice(&self) -> &[T] {
        self.make_slice()
    }
}

iterator! {struct IterMut -> *mut T, &'a mut T, mut, {mut}, {}}

/// ವಿಭಜಿಸುವ ಪುನರಾವರ್ತಕರ ಮೇಲೆ ಆಂತರಿಕ ಅಮೂರ್ತತೆ, ಇದರಿಂದಾಗಿ ಸ್ಪ್ಲಿಟ್ನ್, ಸ್ಪ್ಲಿಟ್ನ್_ಮಟ್ ಇತ್ಯಾದಿಗಳನ್ನು ಒಮ್ಮೆ ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು.
///
#[doc(hidden)]
pub(super) trait SplitIter: DoubleEndedIterator {
    /// ಸ್ಲೈಸ್‌ನ ಉಳಿದ ಭಾಗವನ್ನು ಹೊರತೆಗೆಯುವ ಮೂಲಕ ಆಧಾರವಾಗಿರುವ ಪುನರಾವರ್ತಕವನ್ನು ಪೂರ್ಣವೆಂದು ಗುರುತಿಸುತ್ತದೆ.
    ///
    fn finish(&mut self) -> Option<Self::Item>;
}

/// Icate ಹಿಸುವ ಕಾರ್ಯಕ್ಕೆ ಹೊಂದಿಕೆಯಾಗುವ ಅಂಶಗಳಿಂದ ಬೇರ್ಪಟ್ಟ ಚಂದಾದಾರಿಕೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ.
///
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`split`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Example
///
/// ```
/// let slice = [10, 40, 33, 20];
/// let mut iter = slice.split(|num| num % 3 == 0);
/// ```
///
/// [`split`]: slice::split
/// [slices]: slice
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Split<'a, T: 'a, P>
where
    P: FnMut(&T) -> bool,
{
    // `SplitWhitespace` ಮತ್ತು `SplitAsciiWhitespace` `as_str` ವಿಧಾನಗಳಿಗೆ ಬಳಸಲಾಗುತ್ತದೆ
    pub(crate) v: &'a [T],
    pred: P,
    // `SplitAsciiWhitespace` `as_str` ವಿಧಾನಕ್ಕಾಗಿ ಬಳಸಲಾಗುತ್ತದೆ
    pub(crate) finished: bool,
}

impl<'a, T: 'a, P: FnMut(&T) -> bool> Split<'a, T, P> {
    #[inline]
    pub(super) fn new(slice: &'a [T], pred: P) -> Self {
        Self { v: slice, pred, finished: false }
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: fmt::Debug, P> fmt::Debug for Split<'_, T, P>
where
    P: FnMut(&T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Split").field("v", &self.v).field("finished", &self.finished).finish()
    }
}

// FIXME(#26925) `#[derive(Clone)]` ಪರವಾಗಿ ತೆಗೆದುಹಾಕಿ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, P> Clone for Split<'_, T, P>
where
    P: Clone + FnMut(&T) -> bool,
{
    fn clone(&self) -> Self {
        Split { v: self.v, pred: self.pred.clone(), finished: self.finished }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, P> Iterator for Split<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    type Item = &'a [T];

    #[inline]
    fn next(&mut self) -> Option<&'a [T]> {
        if self.finished {
            return None;
        }

        match self.v.iter().position(|x| (self.pred)(x)) {
            None => self.finish(),
            Some(idx) => {
                let ret = Some(&self.v[..idx]);
                self.v = &self.v[idx + 1..];
                ret
            }
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.finished { (0, Some(0)) } else { (1, Some(self.v.len() + 1)) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, P> DoubleEndedIterator for Split<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    #[inline]
    fn next_back(&mut self) -> Option<&'a [T]> {
        if self.finished {
            return None;
        }

        match self.v.iter().rposition(|x| (self.pred)(x)) {
            None => self.finish(),
            Some(idx) => {
                let ret = Some(&self.v[idx + 1..]);
                self.v = &self.v[..idx];
                ret
            }
        }
    }
}

impl<'a, T, P> SplitIter for Split<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    #[inline]
    fn finish(&mut self) -> Option<&'a [T]> {
        if self.finished {
            None
        } else {
            self.finished = true;
            Some(self.v)
        }
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T, P> FusedIterator for Split<'_, T, P> where P: FnMut(&T) -> bool {}

/// Icate ಹಿಸುವ ಕಾರ್ಯಕ್ಕೆ ಹೊಂದಿಕೆಯಾಗುವ ಅಂಶಗಳಿಂದ ಬೇರ್ಪಟ್ಟ ಚಂದಾದಾರಿಕೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ.
/// `Split` ಗಿಂತ ಭಿನ್ನವಾಗಿ, ಇದು ಸಬ್‌ಲೈಸ್‌ನ ಟರ್ಮಿನೇಟರ್ ಆಗಿ ಹೊಂದಿಕೆಯಾದ ಭಾಗವನ್ನು ಒಳಗೊಂಡಿದೆ.
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`split_inclusive`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Example
///
/// ```
/// let slice = [10, 40, 33, 20];
/// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
/// ```
///
/// [`split_inclusive`]: slice::split_inclusive
/// [slices]: slice
///
#[stable(feature = "split_inclusive", since = "1.51.0")]
pub struct SplitInclusive<'a, T: 'a, P>
where
    P: FnMut(&T) -> bool,
{
    v: &'a [T],
    pred: P,
    finished: bool,
}

impl<'a, T: 'a, P: FnMut(&T) -> bool> SplitInclusive<'a, T, P> {
    #[inline]
    pub(super) fn new(slice: &'a [T], pred: P) -> Self {
        Self { v: slice, pred, finished: false }
    }
}

#[stable(feature = "split_inclusive", since = "1.51.0")]
impl<T: fmt::Debug, P> fmt::Debug for SplitInclusive<'_, T, P>
where
    P: FnMut(&T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SplitInclusive")
            .field("v", &self.v)
            .field("finished", &self.finished)
            .finish()
    }
}

// FIXME(#26925) `#[derive(Clone)]` ಪರವಾಗಿ ತೆಗೆದುಹಾಕಿ
#[stable(feature = "split_inclusive", since = "1.51.0")]
impl<T, P> Clone for SplitInclusive<'_, T, P>
where
    P: Clone + FnMut(&T) -> bool,
{
    fn clone(&self) -> Self {
        SplitInclusive { v: self.v, pred: self.pred.clone(), finished: self.finished }
    }
}

#[stable(feature = "split_inclusive", since = "1.51.0")]
impl<'a, T, P> Iterator for SplitInclusive<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    type Item = &'a [T];

    #[inline]
    fn next(&mut self) -> Option<&'a [T]> {
        if self.finished {
            return None;
        }

        let idx =
            self.v.iter().position(|x| (self.pred)(x)).map(|idx| idx + 1).unwrap_or(self.v.len());
        if idx == self.v.len() {
            self.finished = true;
        }
        let ret = Some(&self.v[..idx]);
        self.v = &self.v[idx..];
        ret
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.finished { (0, Some(0)) } else { (1, Some(self.v.len() + 1)) }
    }
}

#[stable(feature = "split_inclusive", since = "1.51.0")]
impl<'a, T, P> DoubleEndedIterator for SplitInclusive<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    #[inline]
    fn next_back(&mut self) -> Option<&'a [T]> {
        if self.finished {
            return None;
        }

        // self.v ನ ಕೊನೆಯ ಸೂಚ್ಯಂಕವನ್ನು ಈಗಾಗಲೇ ಪರಿಶೀಲಿಸಲಾಗಿದೆ ಮತ್ತು ಕೊನೆಯ ಪುನರಾವರ್ತನೆಯೊಂದಿಗೆ ಹೊಂದಿಕೆಯಾಗುತ್ತದೆ ಎಂದು ನಾವು ಕಂಡುಕೊಂಡಿದ್ದೇವೆ, ಆದ್ದರಿಂದ ನಾವು ಎಡಕ್ಕೆ ಹೊಸ ಹೊಂದಾಣಿಕೆಯ ಒಂದು ಸೂಚಿಯನ್ನು ಹುಡುಕಲು ಪ್ರಾರಂಭಿಸುತ್ತೇವೆ.
        //
        //
        let remainder = if self.v.is_empty() { &[] } else { &self.v[..(self.v.len() - 1)] };
        let idx = remainder.iter().rposition(|x| (self.pred)(x)).map(|idx| idx + 1).unwrap_or(0);
        if idx == 0 {
            self.finished = true;
        }
        let ret = Some(&self.v[idx..]);
        self.v = &self.v[..idx];
        ret
    }
}

#[stable(feature = "split_inclusive", since = "1.51.0")]
impl<T, P> FusedIterator for SplitInclusive<'_, T, P> where P: FnMut(&T) -> bool {}

/// vector ನ ರೂಪಾಂತರಿತ ಚಂದಾದಾರಿಕೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ, ಇವುಗಳನ್ನು `pred` ಗೆ ಹೊಂದಿಕೆಯಾಗುವ ಅಂಶಗಳಿಂದ ಬೇರ್ಪಡಿಸಲಾಗುತ್ತದೆ.
///
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`split_mut`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Example
///
/// ```
/// let mut v = [10, 40, 30, 20, 60, 50];
/// let iter = v.split_mut(|num| *num % 3 == 0);
/// ```
///
/// [`split_mut`]: slice::split_mut
/// [slices]: slice
#[stable(feature = "rust1", since = "1.0.0")]
pub struct SplitMut<'a, T: 'a, P>
where
    P: FnMut(&T) -> bool,
{
    v: &'a mut [T],
    pred: P,
    finished: bool,
}

impl<'a, T: 'a, P: FnMut(&T) -> bool> SplitMut<'a, T, P> {
    #[inline]
    pub(super) fn new(slice: &'a mut [T], pred: P) -> Self {
        Self { v: slice, pred, finished: false }
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: fmt::Debug, P> fmt::Debug for SplitMut<'_, T, P>
where
    P: FnMut(&T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SplitMut").field("v", &self.v).field("finished", &self.finished).finish()
    }
}

impl<'a, T, P> SplitIter for SplitMut<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    #[inline]
    fn finish(&mut self) -> Option<&'a mut [T]> {
        if self.finished {
            None
        } else {
            self.finished = true;
            Some(mem::replace(&mut self.v, &mut []))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, P> Iterator for SplitMut<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    type Item = &'a mut [T];

    #[inline]
    fn next(&mut self) -> Option<&'a mut [T]> {
        if self.finished {
            return None;
        }

        let idx_opt = {
            // ಎರವಲು ಮಿತಿಗಳ ಸುತ್ತ ಕೆಲಸ
            let pred = &mut self.pred;
            self.v.iter().position(|x| (*pred)(x))
        };
        match idx_opt {
            None => self.finish(),
            Some(idx) => {
                let tmp = mem::replace(&mut self.v, &mut []);
                let (head, tail) = tmp.split_at_mut(idx);
                self.v = &mut tail[1..];
                Some(head)
            }
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.finished {
            (0, Some(0))
        } else {
            // ಮುನ್ಸೂಚನೆಯು ಯಾವುದಕ್ಕೂ ಹೊಂದಿಕೆಯಾಗದಿದ್ದರೆ, ಅದು ಪ್ರತಿಯೊಂದು ಅಂಶಕ್ಕೂ ಹೊಂದಿಕೆಯಾದರೆ ನಾವು ಒಂದು ಸ್ಲೈಸ್ ನೀಡುತ್ತೇವೆ, ನಾವು ಲೆನ್ + 1 ಖಾಲಿ ಚೂರುಗಳನ್ನು ನೀಡುತ್ತೇವೆ.
            //
            (1, Some(self.v.len() + 1))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, P> DoubleEndedIterator for SplitMut<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut [T]> {
        if self.finished {
            return None;
        }

        let idx_opt = {
            // ಎರವಲು ಮಿತಿಗಳ ಸುತ್ತ ಕೆಲಸ
            let pred = &mut self.pred;
            self.v.iter().rposition(|x| (*pred)(x))
        };
        match idx_opt {
            None => self.finish(),
            Some(idx) => {
                let tmp = mem::replace(&mut self.v, &mut []);
                let (head, tail) = tmp.split_at_mut(idx);
                self.v = head;
                Some(&mut tail[1..])
            }
        }
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T, P> FusedIterator for SplitMut<'_, T, P> where P: FnMut(&T) -> bool {}

/// vector ನ ರೂಪಾಂತರಿತ ಚಂದಾದಾರಿಕೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ, ಇವುಗಳನ್ನು `pred` ಗೆ ಹೊಂದಿಕೆಯಾಗುವ ಅಂಶಗಳಿಂದ ಬೇರ್ಪಡಿಸಲಾಗುತ್ತದೆ.
/// `SplitMut` ಗಿಂತ ಭಿನ್ನವಾಗಿ, ಇದು ಚಂದಾದಾರಿಕೆಗಳ ತುದಿಗಳಲ್ಲಿ ಹೊಂದಿಕೆಯಾದ ಭಾಗಗಳನ್ನು ಹೊಂದಿರುತ್ತದೆ.
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`split_inclusive_mut`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Example
///
/// ```
/// let mut v = [10, 40, 30, 20, 60, 50];
/// let iter = v.split_inclusive_mut(|num| *num % 3 == 0);
/// ```
///
/// [`split_inclusive_mut`]: slice::split_inclusive_mut
/// [slices]: slice
///
#[stable(feature = "split_inclusive", since = "1.51.0")]
pub struct SplitInclusiveMut<'a, T: 'a, P>
where
    P: FnMut(&T) -> bool,
{
    v: &'a mut [T],
    pred: P,
    finished: bool,
}

impl<'a, T: 'a, P: FnMut(&T) -> bool> SplitInclusiveMut<'a, T, P> {
    #[inline]
    pub(super) fn new(slice: &'a mut [T], pred: P) -> Self {
        Self { v: slice, pred, finished: false }
    }
}

#[stable(feature = "split_inclusive", since = "1.51.0")]
impl<T: fmt::Debug, P> fmt::Debug for SplitInclusiveMut<'_, T, P>
where
    P: FnMut(&T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SplitInclusiveMut")
            .field("v", &self.v)
            .field("finished", &self.finished)
            .finish()
    }
}

#[stable(feature = "split_inclusive", since = "1.51.0")]
impl<'a, T, P> Iterator for SplitInclusiveMut<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    type Item = &'a mut [T];

    #[inline]
    fn next(&mut self) -> Option<&'a mut [T]> {
        if self.finished {
            return None;
        }

        let idx_opt = {
            // ಎರವಲು ಮಿತಿಗಳ ಸುತ್ತ ಕೆಲಸ
            let pred = &mut self.pred;
            self.v.iter().position(|x| (*pred)(x))
        };
        let idx = idx_opt.map(|idx| idx + 1).unwrap_or(self.v.len());
        if idx == self.v.len() {
            self.finished = true;
        }
        let tmp = mem::replace(&mut self.v, &mut []);
        let (head, tail) = tmp.split_at_mut(idx);
        self.v = tail;
        Some(head)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.finished {
            (0, Some(0))
        } else {
            // ಮುನ್ಸೂಚನೆಯು ಯಾವುದಕ್ಕೂ ಹೊಂದಿಕೆಯಾಗದಿದ್ದರೆ, ಅದು ಪ್ರತಿಯೊಂದು ಅಂಶಕ್ಕೂ ಹೊಂದಿಕೆಯಾದರೆ ನಾವು ಒಂದು ಸ್ಲೈಸ್ ನೀಡುತ್ತೇವೆ, ನಾವು ಲೆನ್ + 1 ಖಾಲಿ ಚೂರುಗಳನ್ನು ನೀಡುತ್ತೇವೆ.
            //
            (1, Some(self.v.len() + 1))
        }
    }
}

#[stable(feature = "split_inclusive", since = "1.51.0")]
impl<'a, T, P> DoubleEndedIterator for SplitInclusiveMut<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut [T]> {
        if self.finished {
            return None;
        }

        let idx_opt = if self.v.is_empty() {
            None
        } else {
            // ಎರವಲು ಮಿತಿಗಳ ಸುತ್ತ ಕೆಲಸ
            let pred = &mut self.pred;

            // self.v ನ ಕೊನೆಯ ಸೂಚ್ಯಂಕವನ್ನು ಈಗಾಗಲೇ ಪರಿಶೀಲಿಸಲಾಗಿದೆ ಮತ್ತು ಕೊನೆಯ ಪುನರಾವರ್ತನೆಯೊಂದಿಗೆ ಹೊಂದಿಕೆಯಾಗುತ್ತದೆ ಎಂದು ನಾವು ಕಂಡುಕೊಂಡಿದ್ದೇವೆ, ಆದ್ದರಿಂದ ನಾವು ಎಡಕ್ಕೆ ಹೊಸ ಹೊಂದಾಣಿಕೆಯ ಒಂದು ಸೂಚಿಯನ್ನು ಹುಡುಕಲು ಪ್ರಾರಂಭಿಸುತ್ತೇವೆ.
            //
            //
            let remainder = &self.v[..(self.v.len() - 1)];
            remainder.iter().rposition(|x| (*pred)(x))
        };
        let idx = idx_opt.map(|idx| idx + 1).unwrap_or(0);
        if idx == 0 {
            self.finished = true;
        }
        let tmp = mem::replace(&mut self.v, &mut []);
        let (head, tail) = tmp.split_at_mut(idx);
        self.v = head;
        Some(tail)
    }
}

#[stable(feature = "split_inclusive", since = "1.51.0")]
impl<T, P> FusedIterator for SplitInclusiveMut<'_, T, P> where P: FnMut(&T) -> bool {}

/// ಸ್ಲೈಸ್‌ನ ತುದಿಯಿಂದ ಪ್ರಾರಂಭವಾಗುವ, icate ಹಿಸುವ ಕಾರ್ಯಕ್ಕೆ ಹೊಂದಿಕೆಯಾಗುವ ಅಂಶಗಳಿಂದ ಬೇರ್ಪಟ್ಟ ಚಂದಾದಾರಿಕೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ.
///
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`rsplit`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Example
///
/// ```
/// let slice = [11, 22, 33, 0, 44, 55];
/// let iter = slice.rsplit(|num| *num == 0);
/// ```
///
/// [`rsplit`]: slice::rsplit
/// [slices]: slice
#[stable(feature = "slice_rsplit", since = "1.27.0")]
#[derive(Clone)] // ಇದು ಸರಿಯೇ, ಅಥವಾ ಇದಕ್ಕೆ `T: Clone` ತಪ್ಪಾಗಿ ಅಗತ್ಯವಿದೆಯೇ?
pub struct RSplit<'a, T: 'a, P>
where
    P: FnMut(&T) -> bool,
{
    inner: Split<'a, T, P>,
}

impl<'a, T: 'a, P: FnMut(&T) -> bool> RSplit<'a, T, P> {
    #[inline]
    pub(super) fn new(slice: &'a [T], pred: P) -> Self {
        Self { inner: Split::new(slice, pred) }
    }
}

#[stable(feature = "slice_rsplit", since = "1.27.0")]
impl<T: fmt::Debug, P> fmt::Debug for RSplit<'_, T, P>
where
    P: FnMut(&T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("RSplit")
            .field("v", &self.inner.v)
            .field("finished", &self.inner.finished)
            .finish()
    }
}

#[stable(feature = "slice_rsplit", since = "1.27.0")]
impl<'a, T, P> Iterator for RSplit<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    type Item = &'a [T];

    #[inline]
    fn next(&mut self) -> Option<&'a [T]> {
        self.inner.next_back()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "slice_rsplit", since = "1.27.0")]
impl<'a, T, P> DoubleEndedIterator for RSplit<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    #[inline]
    fn next_back(&mut self) -> Option<&'a [T]> {
        self.inner.next()
    }
}

#[stable(feature = "slice_rsplit", since = "1.27.0")]
impl<'a, T, P> SplitIter for RSplit<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    #[inline]
    fn finish(&mut self) -> Option<&'a [T]> {
        self.inner.finish()
    }
}

#[stable(feature = "slice_rsplit", since = "1.27.0")]
impl<T, P> FusedIterator for RSplit<'_, T, P> where P: FnMut(&T) -> bool {}

/// vector ನ ಚಂದಾದಾರಿಕೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ, ಇದು `pred` ಗೆ ಹೊಂದಿಕೆಯಾಗುವ ಅಂಶಗಳಿಂದ ಬೇರ್ಪಟ್ಟಿದೆ, ಇದು ಸ್ಲೈಸ್‌ನ ತುದಿಯಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ.
///
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`rsplit_mut`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Example
///
/// ```
/// let mut slice = [11, 22, 33, 0, 44, 55];
/// let iter = slice.rsplit_mut(|num| *num == 0);
/// ```
///
/// [`rsplit_mut`]: slice::rsplit_mut
/// [slices]: slice
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub struct RSplitMut<'a, T: 'a, P>
where
    P: FnMut(&T) -> bool,
{
    inner: SplitMut<'a, T, P>,
}

impl<'a, T: 'a, P: FnMut(&T) -> bool> RSplitMut<'a, T, P> {
    #[inline]
    pub(super) fn new(slice: &'a mut [T], pred: P) -> Self {
        Self { inner: SplitMut::new(slice, pred) }
    }
}

#[stable(feature = "slice_rsplit", since = "1.27.0")]
impl<T: fmt::Debug, P> fmt::Debug for RSplitMut<'_, T, P>
where
    P: FnMut(&T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("RSplitMut")
            .field("v", &self.inner.v)
            .field("finished", &self.inner.finished)
            .finish()
    }
}

#[stable(feature = "slice_rsplit", since = "1.27.0")]
impl<'a, T, P> SplitIter for RSplitMut<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    #[inline]
    fn finish(&mut self) -> Option<&'a mut [T]> {
        self.inner.finish()
    }
}

#[stable(feature = "slice_rsplit", since = "1.27.0")]
impl<'a, T, P> Iterator for RSplitMut<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    type Item = &'a mut [T];

    #[inline]
    fn next(&mut self) -> Option<&'a mut [T]> {
        self.inner.next_back()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "slice_rsplit", since = "1.27.0")]
impl<'a, T, P> DoubleEndedIterator for RSplitMut<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut [T]> {
        self.inner.next()
    }
}

#[stable(feature = "slice_rsplit", since = "1.27.0")]
impl<T, P> FusedIterator for RSplitMut<'_, T, P> where P: FnMut(&T) -> bool {}

/// ಮುನ್ಸೂಚನೆಯ ಕಾರ್ಯಕ್ಕೆ ಹೊಂದಿಕೆಯಾಗುವ ಅಂಶಗಳಿಂದ ಬೇರ್ಪಡಿಸಲಾಗಿರುವ ಚಂದಾದಾರಿಕೆಗಳ ಮೇಲೆ ಖಾಸಗಿ ಪುನರಾವರ್ತಕ, ನಿಗದಿತ ಸಂಖ್ಯೆಯ ಬಾರಿ ವಿಭಜಿಸುತ್ತದೆ.
///
///
#[derive(Debug)]
struct GenericSplitN<I> {
    iter: I,
    count: usize,
}

impl<T, I: SplitIter<Item = T>> Iterator for GenericSplitN<I> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        match self.count {
            0 => None,
            1 => {
                self.count -= 1;
                self.iter.finish()
            }
            _ => {
                self.count -= 1;
                self.iter.next()
            }
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let (lower, upper_opt) = self.iter.size_hint();
        (lower, upper_opt.map(|upper| cmp::min(self.count, upper)))
    }
}

/// ನಿರ್ದಿಷ್ಟ ಕಾರ್ಯಕ್ಕೆ ಹೊಂದಿಕೆಯಾಗುವ ಅಂಶಗಳಿಂದ ಬೇರ್ಪಡಿಸಲಾಗಿರುವ ಚಂದಾದಾರಿಕೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ, ನಿರ್ದಿಷ್ಟ ಸಂಖ್ಯೆಯ ವಿಭಜನೆಗಳಿಗೆ ಸೀಮಿತವಾಗಿದೆ.
///
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`splitn`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Example
///
/// ```
/// let slice = [10, 40, 30, 20, 60, 50];
/// let iter = slice.splitn(2, |num| *num % 3 == 0);
/// ```
///
/// [`splitn`]: slice::splitn
/// [slices]: slice
#[stable(feature = "rust1", since = "1.0.0")]
pub struct SplitN<'a, T: 'a, P>
where
    P: FnMut(&T) -> bool,
{
    inner: GenericSplitN<Split<'a, T, P>>,
}

impl<'a, T: 'a, P: FnMut(&T) -> bool> SplitN<'a, T, P> {
    #[inline]
    pub(super) fn new(s: Split<'a, T, P>, n: usize) -> Self {
        Self { inner: GenericSplitN { iter: s, count: n } }
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: fmt::Debug, P> fmt::Debug for SplitN<'_, T, P>
where
    P: FnMut(&T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SplitN").field("inner", &self.inner).finish()
    }
}

/// ಒಂದು ನಿರ್ದಿಷ್ಟ ಕಾರ್ಯಕ್ಕೆ ಹೊಂದಿಕೆಯಾಗುವ ಅಂಶಗಳಿಂದ ಬೇರ್ಪಟ್ಟ ಚಂದಾದಾರಿಕೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ, ನಿರ್ದಿಷ್ಟ ಸಂಖ್ಯೆಯ ವಿಭಜನೆಗಳಿಗೆ ಸೀಮಿತವಾಗಿರುತ್ತದೆ, ಇದು ಸ್ಲೈಸ್‌ನ ಅಂತ್ಯದಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ.
///
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`rsplitn`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Example
///
/// ```
/// let slice = [10, 40, 30, 20, 60, 50];
/// let iter = slice.rsplitn(2, |num| *num % 3 == 0);
/// ```
///
/// [`rsplitn`]: slice::rsplitn
/// [slices]: slice
///
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RSplitN<'a, T: 'a, P>
where
    P: FnMut(&T) -> bool,
{
    inner: GenericSplitN<RSplit<'a, T, P>>,
}

impl<'a, T: 'a, P: FnMut(&T) -> bool> RSplitN<'a, T, P> {
    #[inline]
    pub(super) fn new(s: RSplit<'a, T, P>, n: usize) -> Self {
        Self { inner: GenericSplitN { iter: s, count: n } }
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: fmt::Debug, P> fmt::Debug for RSplitN<'_, T, P>
where
    P: FnMut(&T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("RSplitN").field("inner", &self.inner).finish()
    }
}

/// ನಿರ್ದಿಷ್ಟ ಕಾರ್ಯಕ್ಕೆ ಹೊಂದಿಕೆಯಾಗುವ ಅಂಶಗಳಿಂದ ಬೇರ್ಪಡಿಸಲಾಗಿರುವ ಚಂದಾದಾರಿಕೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ, ನಿರ್ದಿಷ್ಟ ಸಂಖ್ಯೆಯ ವಿಭಜನೆಗಳಿಗೆ ಸೀಮಿತವಾಗಿದೆ.
///
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`splitn_mut`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Example
///
/// ```
/// let mut slice = [10, 40, 30, 20, 60, 50];
/// let iter = slice.splitn_mut(2, |num| *num % 3 == 0);
/// ```
///
/// [`splitn_mut`]: slice::splitn_mut
/// [slices]: slice
#[stable(feature = "rust1", since = "1.0.0")]
pub struct SplitNMut<'a, T: 'a, P>
where
    P: FnMut(&T) -> bool,
{
    inner: GenericSplitN<SplitMut<'a, T, P>>,
}

impl<'a, T: 'a, P: FnMut(&T) -> bool> SplitNMut<'a, T, P> {
    #[inline]
    pub(super) fn new(s: SplitMut<'a, T, P>, n: usize) -> Self {
        Self { inner: GenericSplitN { iter: s, count: n } }
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: fmt::Debug, P> fmt::Debug for SplitNMut<'_, T, P>
where
    P: FnMut(&T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SplitNMut").field("inner", &self.inner).finish()
    }
}

/// ಒಂದು ನಿರ್ದಿಷ್ಟ ಕಾರ್ಯಕ್ಕೆ ಹೊಂದಿಕೆಯಾಗುವ ಅಂಶಗಳಿಂದ ಬೇರ್ಪಟ್ಟ ಚಂದಾದಾರಿಕೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ, ನಿರ್ದಿಷ್ಟ ಸಂಖ್ಯೆಯ ವಿಭಜನೆಗಳಿಗೆ ಸೀಮಿತವಾಗಿರುತ್ತದೆ, ಇದು ಸ್ಲೈಸ್‌ನ ಅಂತ್ಯದಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ.
///
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`rsplitn_mut`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Example
///
/// ```
/// let mut slice = [10, 40, 30, 20, 60, 50];
/// let iter = slice.rsplitn_mut(2, |num| *num % 3 == 0);
/// ```
///
/// [`rsplitn_mut`]: slice::rsplitn_mut
/// [slices]: slice
///
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RSplitNMut<'a, T: 'a, P>
where
    P: FnMut(&T) -> bool,
{
    inner: GenericSplitN<RSplitMut<'a, T, P>>,
}

impl<'a, T: 'a, P: FnMut(&T) -> bool> RSplitNMut<'a, T, P> {
    #[inline]
    pub(super) fn new(s: RSplitMut<'a, T, P>, n: usize) -> Self {
        Self { inner: GenericSplitN { iter: s, count: n } }
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: fmt::Debug, P> fmt::Debug for RSplitNMut<'_, T, P>
where
    P: FnMut(&T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("RSplitNMut").field("inner", &self.inner).finish()
    }
}

forward_iterator! { SplitN: T, &'a [T] }
forward_iterator! { RSplitN: T, &'a [T] }
forward_iterator! { SplitNMut: T, &'a mut [T] }
forward_iterator! { RSplitNMut: T, &'a mut [T] }

/// `size` ಉದ್ದದ ಅತಿಕ್ರಮಿಸುವ ಚಂದಾದಾರಿಕೆಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ.
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`windows`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Example
///
/// ```
/// let slice = ['r', 'u', 's', 't'];
/// let iter = slice.windows(2);
/// ```
///
/// [`windows`]: slice::windows
/// [slices]: slice
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Windows<'a, T: 'a> {
    v: &'a [T],
    size: NonZeroUsize,
}

impl<'a, T: 'a> Windows<'a, T> {
    #[inline]
    pub(super) fn new(slice: &'a [T], size: NonZeroUsize) -> Self {
        Self { v: slice, size }
    }
}

// FIXME(#26925) `#[derive(Clone)]` ಪರವಾಗಿ ತೆಗೆದುಹಾಕಿ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Windows<'_, T> {
    fn clone(&self) -> Self {
        Windows { v: self.v, size: self.size }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Windows<'a, T> {
    type Item = &'a [T];

    #[inline]
    fn next(&mut self) -> Option<&'a [T]> {
        if self.size.get() > self.v.len() {
            None
        } else {
            let ret = Some(&self.v[..self.size.get()]);
            self.v = &self.v[1..];
            ret
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.size.get() > self.v.len() {
            (0, Some(0))
        } else {
            let size = self.v.len() - self.size.get() + 1;
            (size, Some(size))
        }
    }

    #[inline]
    fn count(self) -> usize {
        self.len()
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let (end, overflow) = self.size.get().overflowing_add(n);
        if end > self.v.len() || overflow {
            self.v = &[];
            None
        } else {
            let nth = &self.v[n..end];
            self.v = &self.v[n + 1..];
            Some(nth)
        }
    }

    #[inline]
    fn last(self) -> Option<Self::Item> {
        if self.size.get() > self.v.len() {
            None
        } else {
            let start = self.v.len() - self.size.get();
            Some(&self.v[start..])
        }
    }

    #[doc(hidden)]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `i` ಗಡಿಯಲ್ಲಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸುವುದರಿಂದ,
        // ಇದರರ್ಥ `i` ಗೆ `isize` ಅನ್ನು ಉಕ್ಕಿ ಹರಿಯಲು ಸಾಧ್ಯವಿಲ್ಲ, ಮತ್ತು `from_raw_parts` ರಚಿಸಿದ ಸ್ಲೈಸ್ `self.v` ನ ಸಬ್‌ಲೈಸ್ ಆಗಿದ್ದು, ಆದ್ದರಿಂದ `self.v` ನ `'a` ಜೀವಿತಾವಧಿಗೆ ಮಾನ್ಯವಾಗಿರುತ್ತದೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.
        //
        //
        unsafe { from_raw_parts(self.v.as_ptr().add(idx), self.size.get()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Windows<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a [T]> {
        if self.size.get() > self.v.len() {
            None
        } else {
            let ret = Some(&self.v[self.v.len() - self.size.get()..]);
            self.v = &self.v[..self.v.len() - 1];
            ret
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        let (end, overflow) = self.v.len().overflowing_sub(n);
        if end < self.size.get() || overflow {
            self.v = &[];
            None
        } else {
            let ret = &self.v[end - self.size.get()..end];
            self.v = &self.v[..end - 1];
            Some(ret)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Windows<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Windows<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Windows<'_, T> {}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<'a, T> TrustedRandomAccess for Windows<'a, T> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

/// ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದಿಂದ ಪ್ರಾರಂಭವಾಗುವ (non-overlapping) ಭಾಗಗಳಲ್ಲಿ (ಒಂದು ಸಮಯದಲ್ಲಿ `chunk_size` ಅಂಶಗಳು) ಸ್ಲೈಸ್‌ನ ಮೇಲೆ ಪುನರಾವರ್ತಕ.
///
///
/// ಸ್ಲೈಸ್ ಲೆನ್ ಅನ್ನು ಚಂಕ್ ಗಾತ್ರದಿಂದ ಸಮನಾಗಿ ವಿಂಗಡಿಸದಿದ್ದಾಗ, ಪುನರಾವರ್ತನೆಯ ಕೊನೆಯ ಸ್ಲೈಸ್ ಉಳಿದದ್ದಾಗಿರುತ್ತದೆ.
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`chunks`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Example
///
/// ```
/// let slice = ['l', 'o', 'r', 'e', 'm'];
/// let iter = slice.chunks(2);
/// ```
///
/// [`chunks`]: slice::chunks
/// [slices]: slice
///
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Chunks<'a, T: 'a> {
    v: &'a [T],
    chunk_size: usize,
}

impl<'a, T: 'a> Chunks<'a, T> {
    #[inline]
    pub(super) fn new(slice: &'a [T], size: usize) -> Self {
        Self { v: slice, chunk_size: size }
    }
}

// FIXME(#26925) `#[derive(Clone)]` ಪರವಾಗಿ ತೆಗೆದುಹಾಕಿ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Chunks<'_, T> {
    fn clone(&self) -> Self {
        Chunks { v: self.v, chunk_size: self.chunk_size }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Chunks<'a, T> {
    type Item = &'a [T];

    #[inline]
    fn next(&mut self) -> Option<&'a [T]> {
        if self.v.is_empty() {
            None
        } else {
            let chunksz = cmp::min(self.v.len(), self.chunk_size);
            let (fst, snd) = self.v.split_at(chunksz);
            self.v = snd;
            Some(fst)
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.v.is_empty() {
            (0, Some(0))
        } else {
            let n = self.v.len() / self.chunk_size;
            let rem = self.v.len() % self.chunk_size;
            let n = if rem > 0 { n + 1 } else { n };
            (n, Some(n))
        }
    }

    #[inline]
    fn count(self) -> usize {
        self.len()
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let (start, overflow) = n.overflowing_mul(self.chunk_size);
        if start >= self.v.len() || overflow {
            self.v = &[];
            None
        } else {
            let end = match start.checked_add(self.chunk_size) {
                Some(sum) => cmp::min(self.v.len(), sum),
                None => self.v.len(),
            };
            let nth = &self.v[start..end];
            self.v = &self.v[end..];
            Some(nth)
        }
    }

    #[inline]
    fn last(self) -> Option<Self::Item> {
        if self.v.is_empty() {
            None
        } else {
            let start = (self.v.len() - 1) / self.chunk_size * self.chunk_size;
            Some(&self.v[start..])
        }
    }

    #[doc(hidden)]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
        let start = idx * self.chunk_size;
        let end = match start.checked_add(self.chunk_size) {
            None => self.v.len(),
            Some(end) => cmp::min(end, self.v.len()),
        };
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `i` ಗಡಿಯಲ್ಲಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತದೆ,
        // ಇದರರ್ಥ `start` ಆಧಾರವಾಗಿರುವ `self.v` ಸ್ಲೈಸ್‌ನ ಪರಿಮಿತಿಯಲ್ಲಿರಬೇಕು ಮತ್ತು `end` ಸಹ `self.v` ನ ಪರಿಧಿಯಲ್ಲಿದೆ ಎಂದು ನಾವು ಖಚಿತಪಡಿಸಿದ್ದೇವೆ.
        // ಹೀಗಾಗಿ, `start` ಗೆ `isize` ಅನ್ನು ಉಕ್ಕಿ ಹರಿಯಲು ಸಾಧ್ಯವಿಲ್ಲ, ಮತ್ತು `from_raw_parts` ನಿರ್ಮಿಸಿದ ಸ್ಲೈಸ್ `self.v` ನ ಉಪವರ್ಗವಾಗಿದ್ದು, ಇದು `self.v` ನ ಜೀವಿತಾವಧಿಯ `'a` ಗೆ ಮಾನ್ಯವಾಗಿರುತ್ತದೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.
        //
        //
        //
        //
        unsafe { from_raw_parts(self.v.as_ptr().add(start), end - start) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Chunks<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a [T]> {
        if self.v.is_empty() {
            None
        } else {
            let remainder = self.v.len() % self.chunk_size;
            let chunksz = if remainder != 0 { remainder } else { self.chunk_size };
            let (fst, snd) = self.v.split_at(self.v.len() - chunksz);
            self.v = fst;
            Some(snd)
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        let len = self.len();
        if n >= len {
            self.v = &[];
            None
        } else {
            let start = (len - 1 - n) * self.chunk_size;
            let end = match start.checked_add(self.chunk_size) {
                Some(res) => cmp::min(res, self.v.len()),
                None => self.v.len(),
            };
            let nth_back = &self.v[start..end];
            self.v = &self.v[..start];
            Some(nth_back)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Chunks<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Chunks<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Chunks<'_, T> {}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<'a, T> TrustedRandomAccess for Chunks<'a, T> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

/// (non-overlapping) ರೂಪಾಂತರಿತ ಭಾಗಗಳಲ್ಲಿ (ಒಂದು ಸಮಯದಲ್ಲಿ `chunk_size` ಅಂಶಗಳು) ಸ್ಲೈಸ್‌ನ ಮೇಲೆ ಪುನರಾವರ್ತಕ, ಇದು ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ.
///
///
/// ಸ್ಲೈಸ್ ಲೆನ್ ಅನ್ನು ಚಂಕ್ ಗಾತ್ರದಿಂದ ಸಮನಾಗಿ ವಿಂಗಡಿಸದಿದ್ದಾಗ, ಪುನರಾವರ್ತನೆಯ ಕೊನೆಯ ಸ್ಲೈಸ್ ಉಳಿದದ್ದಾಗಿರುತ್ತದೆ.
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`chunks_mut`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Example
///
/// ```
/// let mut slice = ['l', 'o', 'r', 'e', 'm'];
/// let iter = slice.chunks_mut(2);
/// ```
///
/// [`chunks_mut`]: slice::chunks_mut
/// [slices]: slice
///
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ChunksMut<'a, T: 'a> {
    v: &'a mut [T],
    chunk_size: usize,
}

impl<'a, T: 'a> ChunksMut<'a, T> {
    #[inline]
    pub(super) fn new(slice: &'a mut [T], size: usize) -> Self {
        Self { v: slice, chunk_size: size }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for ChunksMut<'a, T> {
    type Item = &'a mut [T];

    #[inline]
    fn next(&mut self) -> Option<&'a mut [T]> {
        if self.v.is_empty() {
            None
        } else {
            let sz = cmp::min(self.v.len(), self.chunk_size);
            let tmp = mem::replace(&mut self.v, &mut []);
            let (head, tail) = tmp.split_at_mut(sz);
            self.v = tail;
            Some(head)
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.v.is_empty() {
            (0, Some(0))
        } else {
            let n = self.v.len() / self.chunk_size;
            let rem = self.v.len() % self.chunk_size;
            let n = if rem > 0 { n + 1 } else { n };
            (n, Some(n))
        }
    }

    #[inline]
    fn count(self) -> usize {
        self.len()
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<&'a mut [T]> {
        let (start, overflow) = n.overflowing_mul(self.chunk_size);
        if start >= self.v.len() || overflow {
            self.v = &mut [];
            None
        } else {
            let end = match start.checked_add(self.chunk_size) {
                Some(sum) => cmp::min(self.v.len(), sum),
                None => self.v.len(),
            };
            let tmp = mem::replace(&mut self.v, &mut []);
            let (head, tail) = tmp.split_at_mut(end);
            let (_, nth) = head.split_at_mut(start);
            self.v = tail;
            Some(nth)
        }
    }

    #[inline]
    fn last(self) -> Option<Self::Item> {
        if self.v.is_empty() {
            None
        } else {
            let start = (self.v.len() - 1) / self.chunk_size * self.chunk_size;
            Some(&mut self.v[start..])
        }
    }

    #[doc(hidden)]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
        let start = idx * self.chunk_size;
        let end = match start.checked_add(self.chunk_size) {
            None => self.v.len(),
            Some(end) => cmp::min(end, self.v.len()),
        };
        // ಸುರಕ್ಷತೆ: `Chunks::__iterator_get_unchecked` ಗಾಗಿ ಕಾಮೆಂಟ್‌ಗಳನ್ನು ನೋಡಿ.
        //
        // ಅದೇ ಸೂಚ್ಯಂಕದೊಂದಿಗೆ ನಾವು ಮತ್ತೆ ಕರೆ ಮಾಡಿಲ್ಲ ಎಂದು ಕರೆ ಮಾಡುವವರು ಖಾತರಿಪಡಿಸುತ್ತಾರೆ ಮತ್ತು ಈ ಚಂದಾದಾರಿಕೆಯನ್ನು ಪ್ರವೇಶಿಸುವ ಬೇರೆ ಯಾವುದೇ ವಿಧಾನಗಳನ್ನು ಕರೆಯಲಾಗುವುದಿಲ್ಲ, ಆದ್ದರಿಂದ ಹಿಂದಿರುಗಿದ ಸ್ಲೈಸ್ ರೂಪಾಂತರಗೊಳ್ಳಲು ಇದು ಮಾನ್ಯವಾಗಿರುತ್ತದೆ.
        //
        //
        //
        unsafe { from_raw_parts_mut(self.v.as_mut_ptr().add(start), end - start) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for ChunksMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut [T]> {
        if self.v.is_empty() {
            None
        } else {
            let remainder = self.v.len() % self.chunk_size;
            let sz = if remainder != 0 { remainder } else { self.chunk_size };
            let tmp = mem::replace(&mut self.v, &mut []);
            let tmp_len = tmp.len();
            let (head, tail) = tmp.split_at_mut(tmp_len - sz);
            self.v = head;
            Some(tail)
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        let len = self.len();
        if n >= len {
            self.v = &mut [];
            None
        } else {
            let start = (len - 1 - n) * self.chunk_size;
            let end = match start.checked_add(self.chunk_size) {
                Some(res) => cmp::min(res, self.v.len()),
                None => self.v.len(),
            };
            let (temp, _tail) = mem::replace(&mut self.v, &mut []).split_at_mut(end);
            let (head, nth_back) = temp.split_at_mut(start);
            self.v = head;
            Some(nth_back)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for ChunksMut<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for ChunksMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for ChunksMut<'_, T> {}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<'a, T> TrustedRandomAccess for ChunksMut<'a, T> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

/// ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದಿಂದ ಪ್ರಾರಂಭವಾಗುವ (non-overlapping) ಭಾಗಗಳಲ್ಲಿ (ಒಂದು ಸಮಯದಲ್ಲಿ `chunk_size` ಅಂಶಗಳು) ಸ್ಲೈಸ್‌ನ ಮೇಲೆ ಪುನರಾವರ್ತಕ.
///
/// ಸ್ಲೈಸ್ ಲೆನ್ ಅನ್ನು ಚಂಕ್ ಗಾತ್ರದಿಂದ ಸಮನಾಗಿ ವಿಂಗಡಿಸದಿದ್ದಾಗ, `chunk_size-1` ವರೆಗಿನ ಕೊನೆಯ ಅಂಶಗಳನ್ನು ಬಿಟ್ಟುಬಿಡಲಾಗುತ್ತದೆ ಆದರೆ ಪುನರಾವರ್ತಕದಿಂದ [`remainder`] ಕಾರ್ಯದಿಂದ ಹಿಂಪಡೆಯಬಹುದು.
///
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`chunks_exact`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Example
///
/// ```
/// let slice = ['l', 'o', 'r', 'e', 'm'];
/// let iter = slice.chunks_exact(2);
/// ```
///
/// [`chunks_exact`]: slice::chunks_exact
/// [`remainder`]: ChunksExact::remainder
/// [slices]: slice
///
///
#[derive(Debug)]
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub struct ChunksExact<'a, T: 'a> {
    v: &'a [T],
    rem: &'a [T],
    chunk_size: usize,
}

impl<'a, T> ChunksExact<'a, T> {
    #[inline]
    pub(super) fn new(slice: &'a [T], chunk_size: usize) -> Self {
        let rem = slice.len() % chunk_size;
        let fst_len = slice.len() - rem;
        // ಸುರಕ್ಷತೆ: ಮೇಲಿನ ನಿರ್ಮಾಣದಿಂದ 0 <=fst_len <= slice.len()
        let (fst, snd) = unsafe { slice.split_at_unchecked(fst_len) };
        Self { v: fst, rem: snd, chunk_size }
    }

    /// ಪುನರಾವರ್ತಕರಿಂದ ಹಿಂತಿರುಗಿಸಲಾಗದ ಮೂಲ ಸ್ಲೈಸ್‌ನ ಉಳಿದ ಭಾಗವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಹಿಂತಿರುಗಿದ ಸ್ಲೈಸ್ ಹೆಚ್ಚಿನ `chunk_size-1` ಅಂಶಗಳನ್ನು ಹೊಂದಿದೆ.
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    pub fn remainder(&self) -> &'a [T] {
        self.rem
    }
}

// FIXME(#26925) `#[derive(Clone)]` ಪರವಾಗಿ ತೆಗೆದುಹಾಕಿ
#[stable(feature = "chunks_exact", since = "1.31.0")]
impl<T> Clone for ChunksExact<'_, T> {
    fn clone(&self) -> Self {
        ChunksExact { v: self.v, rem: self.rem, chunk_size: self.chunk_size }
    }
}

#[stable(feature = "chunks_exact", since = "1.31.0")]
impl<'a, T> Iterator for ChunksExact<'a, T> {
    type Item = &'a [T];

    #[inline]
    fn next(&mut self) -> Option<&'a [T]> {
        if self.v.len() < self.chunk_size {
            None
        } else {
            let (fst, snd) = self.v.split_at(self.chunk_size);
            self.v = snd;
            Some(fst)
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = self.v.len() / self.chunk_size;
        (n, Some(n))
    }

    #[inline]
    fn count(self) -> usize {
        self.len()
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let (start, overflow) = n.overflowing_mul(self.chunk_size);
        if start >= self.v.len() || overflow {
            self.v = &[];
            None
        } else {
            let (_, snd) = self.v.split_at(start);
            self.v = snd;
            self.next()
        }
    }

    #[inline]
    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }

    #[doc(hidden)]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
        let start = idx * self.chunk_size;
        // ಸುರಕ್ಷತೆ: ಹೆಚ್ಚಾಗಿ `Chunks::__iterator_get_unchecked` ಗೆ ಹೋಲುತ್ತದೆ.
        unsafe { from_raw_parts(self.v.as_ptr().add(start), self.chunk_size) }
    }
}

#[stable(feature = "chunks_exact", since = "1.31.0")]
impl<'a, T> DoubleEndedIterator for ChunksExact<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a [T]> {
        if self.v.len() < self.chunk_size {
            None
        } else {
            let (fst, snd) = self.v.split_at(self.v.len() - self.chunk_size);
            self.v = fst;
            Some(snd)
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        let len = self.len();
        if n >= len {
            self.v = &[];
            None
        } else {
            let start = (len - 1 - n) * self.chunk_size;
            let end = start + self.chunk_size;
            let nth_back = &self.v[start..end];
            self.v = &self.v[..start];
            Some(nth_back)
        }
    }
}

#[stable(feature = "chunks_exact", since = "1.31.0")]
impl<T> ExactSizeIterator for ChunksExact<'_, T> {
    fn is_empty(&self) -> bool {
        self.v.is_empty()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for ChunksExact<'_, T> {}

#[stable(feature = "chunks_exact", since = "1.31.0")]
impl<T> FusedIterator for ChunksExact<'_, T> {}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<'a, T> TrustedRandomAccess for ChunksExact<'a, T> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

/// (non-overlapping) ರೂಪಾಂತರಿತ ಭಾಗಗಳಲ್ಲಿ (ಒಂದು ಸಮಯದಲ್ಲಿ `chunk_size` ಅಂಶಗಳು) ಸ್ಲೈಸ್‌ನ ಮೇಲೆ ಪುನರಾವರ್ತಕ, ಇದು ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ.
///
/// ಸ್ಲೈಸ್ ಲೆನ್ ಅನ್ನು ಚಂಕ್ ಗಾತ್ರದಿಂದ ಸಮನಾಗಿ ವಿಂಗಡಿಸದಿದ್ದಾಗ, `chunk_size-1` ವರೆಗಿನ ಕೊನೆಯ ಅಂಶಗಳನ್ನು ಬಿಟ್ಟುಬಿಡಲಾಗುತ್ತದೆ ಆದರೆ ಪುನರಾವರ್ತಕದಿಂದ [`into_remainder`] ಕಾರ್ಯದಿಂದ ಹಿಂಪಡೆಯಬಹುದು.
///
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`chunks_exact_mut`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Example
///
/// ```
/// let mut slice = ['l', 'o', 'r', 'e', 'm'];
/// let iter = slice.chunks_exact_mut(2);
/// ```
///
/// [`chunks_exact_mut`]: slice::chunks_exact_mut
/// [`into_remainder`]: ChunksExactMut::into_remainder
/// [slices]: slice
///
///
#[derive(Debug)]
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub struct ChunksExactMut<'a, T: 'a> {
    v: &'a mut [T],
    rem: &'a mut [T],
    chunk_size: usize,
}

impl<'a, T> ChunksExactMut<'a, T> {
    #[inline]
    pub(super) fn new(slice: &'a mut [T], chunk_size: usize) -> Self {
        let rem = slice.len() % chunk_size;
        let fst_len = slice.len() - rem;
        // ಸುರಕ್ಷತೆ: ಮೇಲಿನ ನಿರ್ಮಾಣದಿಂದ 0 <=fst_len <= slice.len()
        let (fst, snd) = unsafe { slice.split_at_mut_unchecked(fst_len) };
        Self { v: fst, rem: snd, chunk_size }
    }

    /// ಪುನರಾವರ್ತಕರಿಂದ ಹಿಂತಿರುಗಿಸಲಾಗದ ಮೂಲ ಸ್ಲೈಸ್‌ನ ಉಳಿದ ಭಾಗವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಹಿಂತಿರುಗಿದ ಸ್ಲೈಸ್ ಹೆಚ್ಚಿನ `chunk_size-1` ಅಂಶಗಳನ್ನು ಹೊಂದಿದೆ.
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    pub fn into_remainder(self) -> &'a mut [T] {
        self.rem
    }
}

#[stable(feature = "chunks_exact", since = "1.31.0")]
impl<'a, T> Iterator for ChunksExactMut<'a, T> {
    type Item = &'a mut [T];

    #[inline]
    fn next(&mut self) -> Option<&'a mut [T]> {
        if self.v.len() < self.chunk_size {
            None
        } else {
            let tmp = mem::replace(&mut self.v, &mut []);
            let (head, tail) = tmp.split_at_mut(self.chunk_size);
            self.v = tail;
            Some(head)
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = self.v.len() / self.chunk_size;
        (n, Some(n))
    }

    #[inline]
    fn count(self) -> usize {
        self.len()
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<&'a mut [T]> {
        let (start, overflow) = n.overflowing_mul(self.chunk_size);
        if start >= self.v.len() || overflow {
            self.v = &mut [];
            None
        } else {
            let tmp = mem::replace(&mut self.v, &mut []);
            let (_, snd) = tmp.split_at_mut(start);
            self.v = snd;
            self.next()
        }
    }

    #[inline]
    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }

    #[doc(hidden)]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
        let start = idx * self.chunk_size;
        // ಸುರಕ್ಷತೆ: `ChunksMut::__iterator_get_unchecked` ಗಾಗಿ ಕಾಮೆಂಟ್‌ಗಳನ್ನು ನೋಡಿ.
        unsafe { from_raw_parts_mut(self.v.as_mut_ptr().add(start), self.chunk_size) }
    }
}

#[stable(feature = "chunks_exact", since = "1.31.0")]
impl<'a, T> DoubleEndedIterator for ChunksExactMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut [T]> {
        if self.v.len() < self.chunk_size {
            None
        } else {
            let tmp = mem::replace(&mut self.v, &mut []);
            let tmp_len = tmp.len();
            let (head, tail) = tmp.split_at_mut(tmp_len - self.chunk_size);
            self.v = head;
            Some(tail)
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        let len = self.len();
        if n >= len {
            self.v = &mut [];
            None
        } else {
            let start = (len - 1 - n) * self.chunk_size;
            let end = start + self.chunk_size;
            let (temp, _tail) = mem::replace(&mut self.v, &mut []).split_at_mut(end);
            let (head, nth_back) = temp.split_at_mut(start);
            self.v = head;
            Some(nth_back)
        }
    }
}

#[stable(feature = "chunks_exact", since = "1.31.0")]
impl<T> ExactSizeIterator for ChunksExactMut<'_, T> {
    fn is_empty(&self) -> bool {
        self.v.is_empty()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for ChunksExactMut<'_, T> {}

#[stable(feature = "chunks_exact", since = "1.31.0")]
impl<T> FusedIterator for ChunksExactMut<'_, T> {}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<'a, T> TrustedRandomAccess for ChunksExactMut<'a, T> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

/// ಅತಿಕ್ರಮಿಸುವ ಭಾಗಗಳಲ್ಲಿ (ಒಂದು ಸಮಯದಲ್ಲಿ `N` ಅಂಶಗಳು) ಸ್ಲೈಸ್‌ನ ಆರಂಭದಲ್ಲಿ ಕಿಟಕಿಯ ಪುನರಾವರ್ತಕ, ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ
///
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`array_windows`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Example
///
/// ```
/// #![feature(array_windows)]
///
/// let slice = [0, 1, 2, 3];
/// let iter = slice.array_windows::<2>();
/// ```
///
/// [`array_windows`]: slice::array_windows
/// [slices]: slice
#[derive(Debug, Clone, Copy)]
#[unstable(feature = "array_windows", issue = "75027")]
pub struct ArrayWindows<'a, T: 'a, const N: usize> {
    slice_head: *const T,
    num: usize,
    marker: PhantomData<&'a [T; N]>,
}

impl<'a, T: 'a, const N: usize> ArrayWindows<'a, T, N> {
    #[inline]
    pub(super) fn new(slice: &'a [T]) -> Self {
        let num_windows = slice.len().saturating_sub(N - 1);
        Self { slice_head: slice.as_ptr(), num: num_windows, marker: PhantomData }
    }
}

#[unstable(feature = "array_windows", issue = "75027")]
impl<'a, T, const N: usize> Iterator for ArrayWindows<'a, T, N> {
    type Item = &'a [T; N];

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        if self.num == 0 {
            return None;
        }
        // SAFETY:
        // ಇದು ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ಇದು ಉದ್ದ> ಎನ್ ಎಂದು ಖಾತರಿಪಡಿಸುವ ಸ್ಲೈಸ್‌ಗೆ ಸೂಚಿಕೆ ಮಾಡುತ್ತದೆ.
        let ret = unsafe { &*self.slice_head.cast::<[T; N]>() };
        // ಸುರಕ್ಷತೆ: ಇಲ್ಲದಿದ್ದರೆ ಕನಿಷ್ಠ 1 ಐಟಂ ಉಳಿದಿದೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ
        // ಹಿಂದಿನ branch ಅನ್ನು ಹೊಡೆಯಲಾಗುತ್ತಿತ್ತು
        self.slice_head = unsafe { self.slice_head.add(1) };

        self.num -= 1;
        Some(ret)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.num, Some(self.num))
    }

    #[inline]
    fn count(self) -> usize {
        self.num
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        if self.num <= n {
            self.num = 0;
            return None;
        }
        // SAFETY:
        // ಇದು ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ಇದು ಉದ್ದ> ಎನ್ ಎಂದು ಖಾತರಿಪಡಿಸುವ ಸ್ಲೈಸ್‌ಗೆ ಸೂಚಿಕೆ ಮಾಡುತ್ತದೆ.
        let ret = unsafe { &*self.slice_head.add(n).cast::<[T; N]>() };
        // ಸುರಕ್ಷತೆ: ಕನಿಷ್ಠ n ವಸ್ತುಗಳು ಉಳಿದಿವೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ
        self.slice_head = unsafe { self.slice_head.add(n + 1) };

        self.num -= n + 1;
        Some(ret)
    }

    #[inline]
    fn last(mut self) -> Option<Self::Item> {
        self.nth(self.num.checked_sub(1)?)
    }
}

#[unstable(feature = "array_windows", issue = "75027")]
impl<'a, T, const N: usize> DoubleEndedIterator for ArrayWindows<'a, T, N> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a [T; N]> {
        if self.num == 0 {
            return None;
        }
        // ಸುರಕ್ಷತೆ: n ವಸ್ತುಗಳು ಉಳಿದಿವೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ, 0-ಸೂಚಿಕೆಗಾಗಿ n-1.
        let ret = unsafe { &*self.slice_head.add(self.num - 1).cast::<[T; N]>() };
        self.num -= 1;
        Some(ret)
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<&'a [T; N]> {
        if self.num <= n {
            self.num = 0;
            return None;
        }
        // ಸುರಕ್ಷತೆ: n ವಸ್ತುಗಳು ಉಳಿದಿವೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ, 0-ಸೂಚಿಕೆಗಾಗಿ n-1.
        let ret = unsafe { &*self.slice_head.add(self.num - (n + 1)).cast::<[T; N]>() };
        self.num -= n + 1;
        Some(ret)
    }
}

#[unstable(feature = "array_windows", issue = "75027")]
impl<T, const N: usize> ExactSizeIterator for ArrayWindows<'_, T, N> {
    fn is_empty(&self) -> bool {
        self.num == 0
    }
}

/// ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದಿಂದ ಪ್ರಾರಂಭವಾಗುವ (non-overlapping) ಭಾಗಗಳಲ್ಲಿ (ಒಂದು ಸಮಯದಲ್ಲಿ `N` ಅಂಶಗಳು) ಸ್ಲೈಸ್‌ನ ಮೇಲೆ ಪುನರಾವರ್ತಕ.
///
/// ಸ್ಲೈಸ್ ಲೆನ್ ಅನ್ನು ಚಂಕ್ ಗಾತ್ರದಿಂದ ಸಮನಾಗಿ ವಿಂಗಡಿಸದಿದ್ದಾಗ, `N-1` ವರೆಗಿನ ಕೊನೆಯ ಅಂಶಗಳನ್ನು ಬಿಟ್ಟುಬಿಡಲಾಗುತ್ತದೆ ಆದರೆ ಪುನರಾವರ್ತಕದಿಂದ [`remainder`] ಕಾರ್ಯದಿಂದ ಹಿಂಪಡೆಯಬಹುದು.
///
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`array_chunks`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Example
///
/// ```
/// #![feature(array_chunks)]
///
/// let slice = ['l', 'o', 'r', 'e', 'm'];
/// let iter = slice.array_chunks::<2>();
/// ```
///
/// [`array_chunks`]: slice::array_chunks
/// [`remainder`]: ArrayChunks::remainder
/// [slices]: slice
///
///
#[derive(Debug)]
#[unstable(feature = "array_chunks", issue = "74985")]
pub struct ArrayChunks<'a, T: 'a, const N: usize> {
    iter: Iter<'a, [T; N]>,
    rem: &'a [T],
}

impl<'a, T, const N: usize> ArrayChunks<'a, T, N> {
    #[inline]
    pub(super) fn new(slice: &'a [T]) -> Self {
        let (array_slice, rem) = slice.as_chunks();
        Self { iter: array_slice.iter(), rem }
    }

    /// ಪುನರಾವರ್ತಕರಿಂದ ಹಿಂತಿರುಗಿಸಲಾಗದ ಮೂಲ ಸ್ಲೈಸ್‌ನ ಉಳಿದ ಭಾಗವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಹಿಂತಿರುಗಿದ ಸ್ಲೈಸ್ ಹೆಚ್ಚಿನ `N-1` ಅಂಶಗಳನ್ನು ಹೊಂದಿದೆ.
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    pub fn remainder(&self) -> &'a [T] {
        self.rem
    }
}

// FIXME(#26925) `#[derive(Clone)]` ಪರವಾಗಿ ತೆಗೆದುಹಾಕಿ
#[unstable(feature = "array_chunks", issue = "74985")]
impl<T, const N: usize> Clone for ArrayChunks<'_, T, N> {
    fn clone(&self) -> Self {
        ArrayChunks { iter: self.iter.clone(), rem: self.rem }
    }
}

#[unstable(feature = "array_chunks", issue = "74985")]
impl<'a, T, const N: usize> Iterator for ArrayChunks<'a, T, N> {
    type Item = &'a [T; N];

    #[inline]
    fn next(&mut self) -> Option<&'a [T; N]> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn count(self) -> usize {
        self.iter.count()
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.iter.nth(n)
    }

    #[inline]
    fn last(self) -> Option<Self::Item> {
        self.iter.last()
    }

    unsafe fn __iterator_get_unchecked(&mut self, i: usize) -> &'a [T; N] {
        // ಸುರಕ್ಷತೆ: `__iterator_get_unchecked` ನ ಸುರಕ್ಷತಾ ಖಾತರಿಗಳು
        // ಕರೆ ಮಾಡಿದವರಿಗೆ ವರ್ಗಾಯಿಸಲಾಗಿದೆ.
        unsafe { self.iter.__iterator_get_unchecked(i) }
    }
}

#[unstable(feature = "array_chunks", issue = "74985")]
impl<'a, T, const N: usize> DoubleEndedIterator for ArrayChunks<'a, T, N> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a [T; N]> {
        self.iter.next_back()
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.iter.nth_back(n)
    }
}

#[unstable(feature = "array_chunks", issue = "74985")]
impl<T, const N: usize> ExactSizeIterator for ArrayChunks<'_, T, N> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T, const N: usize> TrustedLen for ArrayChunks<'_, T, N> {}

#[unstable(feature = "array_chunks", issue = "74985")]
impl<T, const N: usize> FusedIterator for ArrayChunks<'_, T, N> {}

#[doc(hidden)]
#[unstable(feature = "array_chunks", issue = "74985")]
unsafe impl<'a, T, const N: usize> TrustedRandomAccess for ArrayChunks<'a, T, N> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

/// (non-overlapping) ರೂಪಾಂತರಿತ ಭಾಗಗಳಲ್ಲಿ (ಒಂದು ಸಮಯದಲ್ಲಿ `N` ಅಂಶಗಳು) ಸ್ಲೈಸ್‌ನ ಮೇಲೆ ಪುನರಾವರ್ತಕ, ಇದು ಸ್ಲೈಸ್‌ನ ಪ್ರಾರಂಭದಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ.
///
/// ಸ್ಲೈಸ್ ಲೆನ್ ಅನ್ನು ಚಂಕ್ ಗಾತ್ರದಿಂದ ಸಮನಾಗಿ ವಿಂಗಡಿಸದಿದ್ದಾಗ, `N-1` ವರೆಗಿನ ಕೊನೆಯ ಅಂಶಗಳನ್ನು ಬಿಟ್ಟುಬಿಡಲಾಗುತ್ತದೆ ಆದರೆ ಪುನರಾವರ್ತಕದಿಂದ [`into_remainder`] ಕಾರ್ಯದಿಂದ ಹಿಂಪಡೆಯಬಹುದು.
///
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`array_chunks_mut`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Example
///
/// ```
/// #![feature(array_chunks)]
///
/// let mut slice = ['l', 'o', 'r', 'e', 'm'];
/// let iter = slice.array_chunks_mut::<2>();
/// ```
///
/// [`array_chunks_mut`]: slice::array_chunks_mut
/// [`into_remainder`]: ../../std/slice/struct.ArrayChunksMut.html#method.into_remainder
/// [slices]: slice
///
///
#[derive(Debug)]
#[unstable(feature = "array_chunks", issue = "74985")]
pub struct ArrayChunksMut<'a, T: 'a, const N: usize> {
    iter: IterMut<'a, [T; N]>,
    rem: &'a mut [T],
}

impl<'a, T, const N: usize> ArrayChunksMut<'a, T, N> {
    #[inline]
    pub(super) fn new(slice: &'a mut [T]) -> Self {
        let (array_slice, rem) = slice.as_chunks_mut();
        Self { iter: array_slice.iter_mut(), rem }
    }

    /// ಪುನರಾವರ್ತಕರಿಂದ ಹಿಂತಿರುಗಿಸಲಾಗದ ಮೂಲ ಸ್ಲೈಸ್‌ನ ಉಳಿದ ಭಾಗವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಹಿಂತಿರುಗಿದ ಸ್ಲೈಸ್ ಹೆಚ್ಚಿನ `N-1` ಅಂಶಗಳನ್ನು ಹೊಂದಿದೆ.
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    pub fn into_remainder(self) -> &'a mut [T] {
        self.rem
    }
}

#[unstable(feature = "array_chunks", issue = "74985")]
impl<'a, T, const N: usize> Iterator for ArrayChunksMut<'a, T, N> {
    type Item = &'a mut [T; N];

    #[inline]
    fn next(&mut self) -> Option<&'a mut [T; N]> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn count(self) -> usize {
        self.iter.count()
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.iter.nth(n)
    }

    #[inline]
    fn last(self) -> Option<Self::Item> {
        self.iter.last()
    }

    unsafe fn __iterator_get_unchecked(&mut self, i: usize) -> &'a mut [T; N] {
        // ಸುರಕ್ಷತೆ: `__iterator_get_unchecked` ನ ಸುರಕ್ಷತಾ ಖಾತರಿಗಳನ್ನು ವರ್ಗಾಯಿಸಲಾಗುತ್ತದೆ
        // ಕರೆ ಮಾಡುವವರು.
        unsafe { self.iter.__iterator_get_unchecked(i) }
    }
}

#[unstable(feature = "array_chunks", issue = "74985")]
impl<'a, T, const N: usize> DoubleEndedIterator for ArrayChunksMut<'a, T, N> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut [T; N]> {
        self.iter.next_back()
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.iter.nth_back(n)
    }
}

#[unstable(feature = "array_chunks", issue = "74985")]
impl<T, const N: usize> ExactSizeIterator for ArrayChunksMut<'_, T, N> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T, const N: usize> TrustedLen for ArrayChunksMut<'_, T, N> {}

#[unstable(feature = "array_chunks", issue = "74985")]
impl<T, const N: usize> FusedIterator for ArrayChunksMut<'_, T, N> {}

#[doc(hidden)]
#[unstable(feature = "array_chunks", issue = "74985")]
unsafe impl<'a, T, const N: usize> TrustedRandomAccess for ArrayChunksMut<'a, T, N> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

/// (non-overlapping) ಭಾಗಗಳಲ್ಲಿ (ಒಂದು ಸಮಯದಲ್ಲಿ `chunk_size` ಅಂಶಗಳು) ಸ್ಲೈಸ್‌ನ ಮೇಲೆ ಪುನರಾವರ್ತಕ, ಸ್ಲೈಸ್‌ನ ಕೊನೆಯಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ.
///
///
/// ಸ್ಲೈಸ್ ಲೆನ್ ಅನ್ನು ಚಂಕ್ ಗಾತ್ರದಿಂದ ಸಮನಾಗಿ ವಿಂಗಡಿಸದಿದ್ದಾಗ, ಪುನರಾವರ್ತನೆಯ ಕೊನೆಯ ಸ್ಲೈಸ್ ಉಳಿದದ್ದಾಗಿರುತ್ತದೆ.
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`rchunks`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Example
///
/// ```
/// let slice = ['l', 'o', 'r', 'e', 'm'];
/// let iter = slice.rchunks(2);
/// ```
///
/// [`rchunks`]: slice::rchunks
/// [slices]: slice
///
#[derive(Debug)]
#[stable(feature = "rchunks", since = "1.31.0")]
pub struct RChunks<'a, T: 'a> {
    v: &'a [T],
    chunk_size: usize,
}

impl<'a, T: 'a> RChunks<'a, T> {
    #[inline]
    pub(super) fn new(slice: &'a [T], size: usize) -> Self {
        Self { v: slice, chunk_size: size }
    }
}

// FIXME(#26925) `#[derive(Clone)]` ಪರವಾಗಿ ತೆಗೆದುಹಾಕಿ
#[stable(feature = "rchunks", since = "1.31.0")]
impl<T> Clone for RChunks<'_, T> {
    fn clone(&self) -> Self {
        RChunks { v: self.v, chunk_size: self.chunk_size }
    }
}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<'a, T> Iterator for RChunks<'a, T> {
    type Item = &'a [T];

    #[inline]
    fn next(&mut self) -> Option<&'a [T]> {
        if self.v.is_empty() {
            None
        } else {
            let chunksz = cmp::min(self.v.len(), self.chunk_size);
            let (fst, snd) = self.v.split_at(self.v.len() - chunksz);
            self.v = fst;
            Some(snd)
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.v.is_empty() {
            (0, Some(0))
        } else {
            let n = self.v.len() / self.chunk_size;
            let rem = self.v.len() % self.chunk_size;
            let n = if rem > 0 { n + 1 } else { n };
            (n, Some(n))
        }
    }

    #[inline]
    fn count(self) -> usize {
        self.len()
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let (end, overflow) = n.overflowing_mul(self.chunk_size);
        if end >= self.v.len() || overflow {
            self.v = &[];
            None
        } else {
            // ಮೇಲಿನ ಚೆಕ್‌ನಿಂದಾಗಿ ಉಕ್ಕಿ ಹರಿಯಲು ಸಾಧ್ಯವಿಲ್ಲ
            let end = self.v.len() - end;
            let start = match end.checked_sub(self.chunk_size) {
                Some(sum) => sum,
                None => 0,
            };
            let nth = &self.v[start..end];
            self.v = &self.v[0..start];
            Some(nth)
        }
    }

    #[inline]
    fn last(self) -> Option<Self::Item> {
        if self.v.is_empty() {
            None
        } else {
            let rem = self.v.len() % self.chunk_size;
            let end = if rem == 0 { self.chunk_size } else { rem };
            Some(&self.v[0..end])
        }
    }

    #[doc(hidden)]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
        let end = self.v.len() - idx * self.chunk_size;
        let start = match end.checked_sub(self.chunk_size) {
            None => 0,
            Some(start) => start,
        };
        // ಸುರಕ್ಷತೆ: ಹೆಚ್ಚಾಗಿ `Chunks::__iterator_get_unchecked` ಗೆ ಹೋಲುತ್ತದೆ.
        unsafe { from_raw_parts(self.v.as_ptr().add(start), end - start) }
    }
}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<'a, T> DoubleEndedIterator for RChunks<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a [T]> {
        if self.v.is_empty() {
            None
        } else {
            let remainder = self.v.len() % self.chunk_size;
            let chunksz = if remainder != 0 { remainder } else { self.chunk_size };
            let (fst, snd) = self.v.split_at(chunksz);
            self.v = snd;
            Some(fst)
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        let len = self.len();
        if n >= len {
            self.v = &[];
            None
        } else {
            // `n < len` ಏಕೆಂದರೆ ಉಕ್ಕಿ ಹರಿಯಲು ಸಾಧ್ಯವಿಲ್ಲ
            let offset_from_end = (len - 1 - n) * self.chunk_size;
            let end = self.v.len() - offset_from_end;
            let start = end.saturating_sub(self.chunk_size);
            let nth_back = &self.v[start..end];
            self.v = &self.v[end..];
            Some(nth_back)
        }
    }
}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<T> ExactSizeIterator for RChunks<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for RChunks<'_, T> {}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<T> FusedIterator for RChunks<'_, T> {}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<'a, T> TrustedRandomAccess for RChunks<'a, T> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

/// (non-overlapping) ರೂಪಾಂತರಿತ ಭಾಗಗಳಲ್ಲಿ (ಒಂದು ಸಮಯದಲ್ಲಿ `chunk_size` ಅಂಶಗಳು) ಒಂದು ಸ್ಲೈಸ್‌ನ ಮೇಲೆ ಪುನರಾವರ್ತಕ, ಇದು ಸ್ಲೈಸ್‌ನ ಕೊನೆಯಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ.
///
///
/// ಸ್ಲೈಸ್ ಲೆನ್ ಅನ್ನು ಚಂಕ್ ಗಾತ್ರದಿಂದ ಸಮನಾಗಿ ವಿಂಗಡಿಸದಿದ್ದಾಗ, ಪುನರಾವರ್ತನೆಯ ಕೊನೆಯ ಸ್ಲೈಸ್ ಉಳಿದದ್ದಾಗಿರುತ್ತದೆ.
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`rchunks_mut`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Example
///
/// ```
/// let mut slice = ['l', 'o', 'r', 'e', 'm'];
/// let iter = slice.rchunks_mut(2);
/// ```
///
/// [`rchunks_mut`]: slice::rchunks_mut
/// [slices]: slice
///
#[derive(Debug)]
#[stable(feature = "rchunks", since = "1.31.0")]
pub struct RChunksMut<'a, T: 'a> {
    v: &'a mut [T],
    chunk_size: usize,
}

impl<'a, T: 'a> RChunksMut<'a, T> {
    #[inline]
    pub(super) fn new(slice: &'a mut [T], size: usize) -> Self {
        Self { v: slice, chunk_size: size }
    }
}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<'a, T> Iterator for RChunksMut<'a, T> {
    type Item = &'a mut [T];

    #[inline]
    fn next(&mut self) -> Option<&'a mut [T]> {
        if self.v.is_empty() {
            None
        } else {
            let sz = cmp::min(self.v.len(), self.chunk_size);
            let tmp = mem::replace(&mut self.v, &mut []);
            let tmp_len = tmp.len();
            let (head, tail) = tmp.split_at_mut(tmp_len - sz);
            self.v = head;
            Some(tail)
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.v.is_empty() {
            (0, Some(0))
        } else {
            let n = self.v.len() / self.chunk_size;
            let rem = self.v.len() % self.chunk_size;
            let n = if rem > 0 { n + 1 } else { n };
            (n, Some(n))
        }
    }

    #[inline]
    fn count(self) -> usize {
        self.len()
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<&'a mut [T]> {
        let (end, overflow) = n.overflowing_mul(self.chunk_size);
        if end >= self.v.len() || overflow {
            self.v = &mut [];
            None
        } else {
            // ಮೇಲಿನ ಚೆಕ್‌ನಿಂದಾಗಿ ಉಕ್ಕಿ ಹರಿಯಲು ಸಾಧ್ಯವಿಲ್ಲ
            let end = self.v.len() - end;
            let start = match end.checked_sub(self.chunk_size) {
                Some(sum) => sum,
                None => 0,
            };
            let tmp = mem::replace(&mut self.v, &mut []);
            let (head, tail) = tmp.split_at_mut(start);
            let (nth, _) = tail.split_at_mut(end - start);
            self.v = head;
            Some(nth)
        }
    }

    #[inline]
    fn last(self) -> Option<Self::Item> {
        if self.v.is_empty() {
            None
        } else {
            let rem = self.v.len() % self.chunk_size;
            let end = if rem == 0 { self.chunk_size } else { rem };
            Some(&mut self.v[0..end])
        }
    }

    #[doc(hidden)]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
        let end = self.v.len() - idx * self.chunk_size;
        let start = match end.checked_sub(self.chunk_size) {
            None => 0,
            Some(start) => start,
        };
        // ಸುರಕ್ಷತೆ: `RChunks::__iterator_get_unchecked` ಗಾಗಿ ಕಾಮೆಂಟ್‌ಗಳನ್ನು ನೋಡಿ ಮತ್ತು
        // `ChunksMut::__iterator_get_unchecked`
        unsafe { from_raw_parts_mut(self.v.as_mut_ptr().add(start), end - start) }
    }
}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<'a, T> DoubleEndedIterator for RChunksMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut [T]> {
        if self.v.is_empty() {
            None
        } else {
            let remainder = self.v.len() % self.chunk_size;
            let sz = if remainder != 0 { remainder } else { self.chunk_size };
            let tmp = mem::replace(&mut self.v, &mut []);
            let (head, tail) = tmp.split_at_mut(sz);
            self.v = tail;
            Some(head)
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        let len = self.len();
        if n >= len {
            self.v = &mut [];
            None
        } else {
            // `n < len` ಏಕೆಂದರೆ ಉಕ್ಕಿ ಹರಿಯಲು ಸಾಧ್ಯವಿಲ್ಲ
            let offset_from_end = (len - 1 - n) * self.chunk_size;
            let end = self.v.len() - offset_from_end;
            let start = end.saturating_sub(self.chunk_size);
            let (tmp, tail) = mem::replace(&mut self.v, &mut []).split_at_mut(end);
            let (_, nth_back) = tmp.split_at_mut(start);
            self.v = tail;
            Some(nth_back)
        }
    }
}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<T> ExactSizeIterator for RChunksMut<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for RChunksMut<'_, T> {}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<T> FusedIterator for RChunksMut<'_, T> {}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<'a, T> TrustedRandomAccess for RChunksMut<'a, T> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

/// (non-overlapping) ಭಾಗಗಳಲ್ಲಿ (ಒಂದು ಸಮಯದಲ್ಲಿ `chunk_size` ಅಂಶಗಳು) ಸ್ಲೈಸ್‌ನ ಮೇಲೆ ಪುನರಾವರ್ತಕ, ಸ್ಲೈಸ್‌ನ ಕೊನೆಯಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ.
///
/// ಸ್ಲೈಸ್ ಲೆನ್ ಅನ್ನು ಚಂಕ್ ಗಾತ್ರದಿಂದ ಸಮನಾಗಿ ವಿಂಗಡಿಸದಿದ್ದಾಗ, `chunk_size-1` ವರೆಗಿನ ಕೊನೆಯ ಅಂಶಗಳನ್ನು ಬಿಟ್ಟುಬಿಡಲಾಗುತ್ತದೆ ಆದರೆ ಪುನರಾವರ್ತಕದಿಂದ [`remainder`] ಕಾರ್ಯದಿಂದ ಹಿಂಪಡೆಯಬಹುದು.
///
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`rchunks_exact`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Example
///
/// ```
/// let slice = ['l', 'o', 'r', 'e', 'm'];
/// let iter = slice.rchunks_exact(2);
/// ```
///
/// [`rchunks_exact`]: slice::rchunks_exact
/// [`remainder`]: ChunksExact::remainder
/// [slices]: slice
///
///
#[derive(Debug)]
#[stable(feature = "rchunks", since = "1.31.0")]
pub struct RChunksExact<'a, T: 'a> {
    v: &'a [T],
    rem: &'a [T],
    chunk_size: usize,
}

impl<'a, T> RChunksExact<'a, T> {
    #[inline]
    pub(super) fn new(slice: &'a [T], chunk_size: usize) -> Self {
        let rem = slice.len() % chunk_size;
        // ಸುರಕ್ಷತೆ: ಮೇಲಿನ ನಿರ್ಮಾಣದಿಂದ 0 <=rem <= slice.len()
        let (fst, snd) = unsafe { slice.split_at_unchecked(rem) };
        Self { v: snd, rem: fst, chunk_size }
    }

    /// ಪುನರಾವರ್ತಕರಿಂದ ಹಿಂತಿರುಗಿಸಲಾಗದ ಮೂಲ ಸ್ಲೈಸ್‌ನ ಉಳಿದ ಭಾಗವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಹಿಂತಿರುಗಿದ ಸ್ಲೈಸ್ ಹೆಚ್ಚಿನ `chunk_size-1` ಅಂಶಗಳನ್ನು ಹೊಂದಿದೆ.
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    pub fn remainder(&self) -> &'a [T] {
        self.rem
    }
}

// FIXME(#26925) `#[derive(Clone)]` ಪರವಾಗಿ ತೆಗೆದುಹಾಕಿ
#[stable(feature = "rchunks", since = "1.31.0")]
impl<'a, T> Clone for RChunksExact<'a, T> {
    fn clone(&self) -> RChunksExact<'a, T> {
        RChunksExact { v: self.v, rem: self.rem, chunk_size: self.chunk_size }
    }
}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<'a, T> Iterator for RChunksExact<'a, T> {
    type Item = &'a [T];

    #[inline]
    fn next(&mut self) -> Option<&'a [T]> {
        if self.v.len() < self.chunk_size {
            None
        } else {
            let (fst, snd) = self.v.split_at(self.v.len() - self.chunk_size);
            self.v = fst;
            Some(snd)
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = self.v.len() / self.chunk_size;
        (n, Some(n))
    }

    #[inline]
    fn count(self) -> usize {
        self.len()
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let (end, overflow) = n.overflowing_mul(self.chunk_size);
        if end >= self.v.len() || overflow {
            self.v = &[];
            None
        } else {
            let (fst, _) = self.v.split_at(self.v.len() - end);
            self.v = fst;
            self.next()
        }
    }

    #[inline]
    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }

    #[doc(hidden)]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
        let end = self.v.len() - idx * self.chunk_size;
        let start = end - self.chunk_size;
        // ಸುರಕ್ಷತೆ: ಸುರಕ್ಷತೆ: ಹೆಚ್ಚಿನವು `Chunks::__iterator_get_unchecked` ಗೆ ಹೋಲುತ್ತದೆ.
        //
        unsafe { from_raw_parts(self.v.as_ptr().add(start), self.chunk_size) }
    }
}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<'a, T> DoubleEndedIterator for RChunksExact<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a [T]> {
        if self.v.len() < self.chunk_size {
            None
        } else {
            let (fst, snd) = self.v.split_at(self.chunk_size);
            self.v = snd;
            Some(fst)
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        let len = self.len();
        if n >= len {
            self.v = &[];
            None
        } else {
            // `n` ಒಂದು ಭಾಗಕ್ಕೆ ಅನುರೂಪವಾಗಿದೆ ಎಂದು ಈಗ ನಮಗೆ ತಿಳಿದಿದೆ, ಈ ಯಾವುದೇ ಕಾರ್ಯಾಚರಣೆಗಳು underflow/overflow ಗೆ ಸಾಧ್ಯವಿಲ್ಲ
            //
            let offset = (len - n) * self.chunk_size;
            let start = self.v.len() - offset;
            let end = start + self.chunk_size;
            let nth_back = &self.v[start..end];
            self.v = &self.v[end..];
            Some(nth_back)
        }
    }
}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<'a, T> ExactSizeIterator for RChunksExact<'a, T> {
    fn is_empty(&self) -> bool {
        self.v.is_empty()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for RChunksExact<'_, T> {}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<T> FusedIterator for RChunksExact<'_, T> {}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<'a, T> TrustedRandomAccess for RChunksExact<'a, T> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

/// (non-overlapping) ರೂಪಾಂತರಿತ ಭಾಗಗಳಲ್ಲಿ (ಒಂದು ಸಮಯದಲ್ಲಿ `chunk_size` ಅಂಶಗಳು) ಒಂದು ಸ್ಲೈಸ್‌ನ ಮೇಲೆ ಪುನರಾವರ್ತಕ, ಇದು ಸ್ಲೈಸ್‌ನ ಕೊನೆಯಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ.
///
/// ಸ್ಲೈಸ್ ಲೆನ್ ಅನ್ನು ಚಂಕ್ ಗಾತ್ರದಿಂದ ಸಮನಾಗಿ ವಿಂಗಡಿಸದಿದ್ದಾಗ, `chunk_size-1` ವರೆಗಿನ ಕೊನೆಯ ಅಂಶಗಳನ್ನು ಬಿಟ್ಟುಬಿಡಲಾಗುತ್ತದೆ ಆದರೆ ಪುನರಾವರ್ತಕದಿಂದ [`into_remainder`] ಕಾರ್ಯದಿಂದ ಹಿಂಪಡೆಯಬಹುದು.
///
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`rchunks_exact_mut`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// # Example
///
/// ```
/// let mut slice = ['l', 'o', 'r', 'e', 'm'];
/// let iter = slice.rchunks_exact_mut(2);
/// ```
///
/// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
/// [`into_remainder`]: ChunksExactMut::into_remainder
/// [slices]: slice
///
///
#[derive(Debug)]
#[stable(feature = "rchunks", since = "1.31.0")]
pub struct RChunksExactMut<'a, T: 'a> {
    v: &'a mut [T],
    rem: &'a mut [T],
    chunk_size: usize,
}

impl<'a, T> RChunksExactMut<'a, T> {
    #[inline]
    pub(super) fn new(slice: &'a mut [T], chunk_size: usize) -> Self {
        let rem = slice.len() % chunk_size;
        // ಸುರಕ್ಷತೆ: ಮೇಲಿನ ನಿರ್ಮಾಣದಿಂದ 0 <=rem <= slice.len()
        let (fst, snd) = unsafe { slice.split_at_mut_unchecked(rem) };
        Self { v: snd, rem: fst, chunk_size }
    }

    /// ಪುನರಾವರ್ತಕರಿಂದ ಹಿಂತಿರುಗಿಸಲಾಗದ ಮೂಲ ಸ್ಲೈಸ್‌ನ ಉಳಿದ ಭಾಗವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಹಿಂತಿರುಗಿದ ಸ್ಲೈಸ್ ಹೆಚ್ಚಿನ `chunk_size-1` ಅಂಶಗಳನ್ನು ಹೊಂದಿದೆ.
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    pub fn into_remainder(self) -> &'a mut [T] {
        self.rem
    }
}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<'a, T> Iterator for RChunksExactMut<'a, T> {
    type Item = &'a mut [T];

    #[inline]
    fn next(&mut self) -> Option<&'a mut [T]> {
        if self.v.len() < self.chunk_size {
            None
        } else {
            let tmp = mem::replace(&mut self.v, &mut []);
            let tmp_len = tmp.len();
            let (head, tail) = tmp.split_at_mut(tmp_len - self.chunk_size);
            self.v = head;
            Some(tail)
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = self.v.len() / self.chunk_size;
        (n, Some(n))
    }

    #[inline]
    fn count(self) -> usize {
        self.len()
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<&'a mut [T]> {
        let (end, overflow) = n.overflowing_mul(self.chunk_size);
        if end >= self.v.len() || overflow {
            self.v = &mut [];
            None
        } else {
            let tmp = mem::replace(&mut self.v, &mut []);
            let tmp_len = tmp.len();
            let (fst, _) = tmp.split_at_mut(tmp_len - end);
            self.v = fst;
            self.next()
        }
    }

    #[inline]
    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }

    #[doc(hidden)]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
        let end = self.v.len() - idx * self.chunk_size;
        let start = end - self.chunk_size;
        // ಸುರಕ್ಷತೆ: `RChunksMut::__iterator_get_unchecked` ಗಾಗಿ ಕಾಮೆಂಟ್‌ಗಳನ್ನು ನೋಡಿ.
        unsafe { from_raw_parts_mut(self.v.as_mut_ptr().add(start), self.chunk_size) }
    }
}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<'a, T> DoubleEndedIterator for RChunksExactMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut [T]> {
        if self.v.len() < self.chunk_size {
            None
        } else {
            let tmp = mem::replace(&mut self.v, &mut []);
            let (head, tail) = tmp.split_at_mut(self.chunk_size);
            self.v = tail;
            Some(head)
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        let len = self.len();
        if n >= len {
            self.v = &mut [];
            None
        } else {
            // `n` ಒಂದು ಭಾಗಕ್ಕೆ ಅನುರೂಪವಾಗಿದೆ ಎಂದು ಈಗ ನಮಗೆ ತಿಳಿದಿದೆ, ಈ ಯಾವುದೇ ಕಾರ್ಯಾಚರಣೆಗಳು underflow/overflow ಗೆ ಸಾಧ್ಯವಿಲ್ಲ
            //
            let offset = (len - n) * self.chunk_size;
            let start = self.v.len() - offset;
            let end = start + self.chunk_size;
            let (tmp, tail) = mem::replace(&mut self.v, &mut []).split_at_mut(end);
            let (_, nth_back) = tmp.split_at_mut(start);
            self.v = tail;
            Some(nth_back)
        }
    }
}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<T> ExactSizeIterator for RChunksExactMut<'_, T> {
    fn is_empty(&self) -> bool {
        self.v.is_empty()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for RChunksExactMut<'_, T> {}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<T> FusedIterator for RChunksExactMut<'_, T> {}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<'a, T> TrustedRandomAccess for RChunksExactMut<'a, T> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<'a, T> TrustedRandomAccess for Iter<'a, T> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<'a, T> TrustedRandomAccess for IterMut<'a, T> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

/// (non-overlapping) ಭಾಗಗಳಲ್ಲಿ ಸ್ಲೈಸ್ ಓವರ್ ಇರೇಟರ್ ಅನ್ನು icate ಹಿಸಿ ಬೇರ್ಪಡಿಸಲಾಗಿದೆ.
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`group_by`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// [`group_by`]: slice::group_by
/// [slices]: slice
#[unstable(feature = "slice_group_by", issue = "80552")]
pub struct GroupBy<'a, T: 'a, P> {
    slice: &'a [T],
    predicate: P,
}

#[unstable(feature = "slice_group_by", issue = "80552")]
impl<'a, T: 'a, P> GroupBy<'a, T, P> {
    pub(super) fn new(slice: &'a [T], predicate: P) -> Self {
        GroupBy { slice, predicate }
    }
}

#[unstable(feature = "slice_group_by", issue = "80552")]
impl<'a, T: 'a, P> Iterator for GroupBy<'a, T, P>
where
    P: FnMut(&T, &T) -> bool,
{
    type Item = &'a [T];

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        if self.slice.is_empty() {
            None
        } else {
            let mut len = 1;
            let mut iter = self.slice.windows(2);
            while let Some([l, r]) = iter.next() {
                if (self.predicate)(l, r) { len += 1 } else { break }
            }
            let (head, tail) = self.slice.split_at(len);
            self.slice = tail;
            Some(head)
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.slice.is_empty() { (0, Some(0)) } else { (1, Some(self.slice.len())) }
    }

    #[inline]
    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[unstable(feature = "slice_group_by", issue = "80552")]
impl<'a, T: 'a, P> DoubleEndedIterator for GroupBy<'a, T, P>
where
    P: FnMut(&T, &T) -> bool,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        if self.slice.is_empty() {
            None
        } else {
            let mut len = 1;
            let mut iter = self.slice.windows(2);
            while let Some([l, r]) = iter.next_back() {
                if (self.predicate)(l, r) { len += 1 } else { break }
            }
            let (head, tail) = self.slice.split_at(self.slice.len() - len);
            self.slice = head;
            Some(tail)
        }
    }
}

#[unstable(feature = "slice_group_by", issue = "80552")]
impl<'a, T: 'a, P> FusedIterator for GroupBy<'a, T, P> where P: FnMut(&T, &T) -> bool {}

#[unstable(feature = "slice_group_by", issue = "80552")]
impl<'a, T: 'a + fmt::Debug, P> fmt::Debug for GroupBy<'a, T, P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("GroupBy").field("slice", &self.slice).finish()
    }
}

/// (non-overlapping) ರೂಪಾಂತರಿತ ಭಾಗಗಳಲ್ಲಿ ಸ್ಲೈಸ್‌ನ ಮೇಲೆ ಪುನರಾವರ್ತಕವು ಒಂದು ಮುನ್ಸೂಚನೆಯಿಂದ ಬೇರ್ಪಡಿಸಲಾಗಿದೆ.
///
///
/// ಈ ರಚನೆಯನ್ನು [slices] ನಲ್ಲಿ [`group_by_mut`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
///
/// [`group_by_mut`]: slice::group_by_mut
/// [slices]: slice
#[unstable(feature = "slice_group_by", issue = "80552")]
pub struct GroupByMut<'a, T: 'a, P> {
    slice: &'a mut [T],
    predicate: P,
}

#[unstable(feature = "slice_group_by", issue = "80552")]
impl<'a, T: 'a, P> GroupByMut<'a, T, P> {
    pub(super) fn new(slice: &'a mut [T], predicate: P) -> Self {
        GroupByMut { slice, predicate }
    }
}

#[unstable(feature = "slice_group_by", issue = "80552")]
impl<'a, T: 'a, P> Iterator for GroupByMut<'a, T, P>
where
    P: FnMut(&T, &T) -> bool,
{
    type Item = &'a mut [T];

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        if self.slice.is_empty() {
            None
        } else {
            let mut len = 1;
            let mut iter = self.slice.windows(2);
            while let Some([l, r]) = iter.next() {
                if (self.predicate)(l, r) { len += 1 } else { break }
            }
            let slice = mem::take(&mut self.slice);
            let (head, tail) = slice.split_at_mut(len);
            self.slice = tail;
            Some(head)
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.slice.is_empty() { (0, Some(0)) } else { (1, Some(self.slice.len())) }
    }

    #[inline]
    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[unstable(feature = "slice_group_by", issue = "80552")]
impl<'a, T: 'a, P> DoubleEndedIterator for GroupByMut<'a, T, P>
where
    P: FnMut(&T, &T) -> bool,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        if self.slice.is_empty() {
            None
        } else {
            let mut len = 1;
            let mut iter = self.slice.windows(2);
            while let Some([l, r]) = iter.next_back() {
                if (self.predicate)(l, r) { len += 1 } else { break }
            }
            let slice = mem::take(&mut self.slice);
            let (head, tail) = slice.split_at_mut(slice.len() - len);
            self.slice = head;
            Some(tail)
        }
    }
}

#[unstable(feature = "slice_group_by", issue = "80552")]
impl<'a, T: 'a, P> FusedIterator for GroupByMut<'a, T, P> where P: FnMut(&T, &T) -> bool {}

#[unstable(feature = "slice_group_by", issue = "80552")]
impl<'a, T: 'a + fmt::Debug, P> fmt::Debug for GroupByMut<'a, T, P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("GroupByMut").field("slice", &self.slice).finish()
    }
}