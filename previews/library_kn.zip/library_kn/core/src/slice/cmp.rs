//! `[T]` ಗಾಗಿ traits ಅನ್ನು ಹೋಲಿಕೆ ಮಾಡಿ.

use crate::cmp;
use crate::cmp::Ordering::{self, Greater, Less};
use crate::mem;

use super::from_raw_parts;
use super::memchr;

extern "C" {
    /// ಕರೆಗಳ ಅನುಷ್ಠಾನವು memcmp ಅನ್ನು ಒದಗಿಸಿದೆ.
    ///
    /// ಡೇಟಾವನ್ನು u8 ಎಂದು ವ್ಯಾಖ್ಯಾನಿಸುತ್ತದೆ.
    ///
    /// ಸಮಾನಕ್ಕೆ 0, <0 ಕ್ಕಿಂತ ಕಡಿಮೆ ಮತ್ತು> 0 ಗಿಂತ ಹೆಚ್ಚಿನದನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    // FIXME(#32610): ರಿಟರ್ನ್ ಪ್ರಕಾರವು c_int ಆಗಿರಬೇಕು
    fn memcmp(s1: *const u8, s2: *const u8, n: usize) -> i32;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> PartialEq<[B]> for [A]
where
    A: PartialEq<B>,
{
    fn eq(&self, other: &[B]) -> bool {
        SlicePartialEq::equal(self, other)
    }

    fn ne(&self, other: &[B]) -> bool {
        SlicePartialEq::not_equal(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for [T] {}

/// vectors [lexicographically](Ord#lexicographical-comparison) ನ ಹೋಲಿಕೆಯನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for [T] {
    fn cmp(&self, other: &[T]) -> Ordering {
        SliceOrd::compare(self, other)
    }
}

/// vectors [lexicographically](Ord#lexicographical-comparison) ನ ಹೋಲಿಕೆಯನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for [T] {
    fn partial_cmp(&self, other: &[T]) -> Option<Ordering> {
        SlicePartialOrd::partial_compare(self, other)
    }
}

#[doc(hidden)]
// ಸ್ಲೈಸ್‌ನ ಭಾಗಶಃ ಎಕ್‌ನ ವಿಶೇಷತೆಗಾಗಿ ಮಧ್ಯಂತರ trait
trait SlicePartialEq<B> {
    fn equal(&self, other: &[B]) -> bool;

    fn not_equal(&self, other: &[B]) -> bool {
        !self.equal(other)
    }
}

// ಜೆನೆರಿಕ್ ಸ್ಲೈಸ್ ಸಮಾನತೆ
impl<A, B> SlicePartialEq<B> for [A]
where
    A: PartialEq<B>,
{
    default fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        self.iter().zip(other.iter()).all(|(x, y)| x == y)
    }
}

// ಪ್ರಕಾರಗಳು ಅನುಮತಿಸಿದಾಗ ಬೈಟ್‌ವೈಸ್ ಸಮಾನತೆಗಾಗಿ memcmp ಬಳಸಿ
impl<A, B> SlicePartialEq<B> for [A]
where
    A: BytewiseEquality<B>,
{
    fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        // ಸುರಕ್ಷತೆ: `self` ಮತ್ತು `other` ಉಲ್ಲೇಖಗಳು ಮತ್ತು ಆದ್ದರಿಂದ ಮಾನ್ಯ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.
        // ಎರಡು ಚೂರುಗಳು ಒಂದೇ ಗಾತ್ರವನ್ನು ಹೊಂದಿದೆಯೆ ಎಂದು ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
        unsafe {
            let size = mem::size_of_val(self);
            memcmp(self.as_ptr() as *const u8, other.as_ptr() as *const u8, size) == 0
        }
    }
}

#[doc(hidden)]
// ಸ್ಲೈಸ್‌ನ ಭಾಗಶಃ ಆದೇಶದ ವಿಶೇಷತೆಗಾಗಿ ಮಧ್ಯಂತರ trait
trait SlicePartialOrd: Sized {
    fn partial_compare(left: &[Self], right: &[Self]) -> Option<Ordering>;
}

impl<A: PartialOrd> SlicePartialOrd for A {
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        let l = cmp::min(left.len(), right.len());

        // ಕಂಪೈಲರ್ನಲ್ಲಿ ಬೌಂಡ್ ಚೆಕ್ ಎಲಿಮಿನೇಷನ್ ಅನ್ನು ಸಕ್ರಿಯಗೊಳಿಸಲು ಲೂಪ್ ಪುನರಾವರ್ತನೆ ಶ್ರೇಣಿಗೆ ಸ್ಲೈಸ್ ಮಾಡಿ
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].partial_cmp(&rhs[i]) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }

        left.len().partial_cmp(&right.len())
    }
}

// ಇದು ನಾವು ಹೊಂದಲು ಬಯಸುವ ಇಂಪ್ಲ್ ಆಗಿದೆ.ದುರದೃಷ್ಟವಶಾತ್ ಇದು ಶಬ್ದವಲ್ಲ.
// `partial_ord_slice.rs` ನೋಡಿ.
/*
impl<A> SlicePartialOrd for A
where
    A: Ord,
{
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}
*/

impl<A: AlwaysApplicableOrd> SlicePartialOrd for A {
    fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}

#[rustc_specialization_trait]
trait AlwaysApplicableOrd: SliceOrd + Ord {}

macro_rules! always_applicable_ord {
    ($([$($p:tt)*] $t:ty,)*) => {
        $(impl<$($p)*> AlwaysApplicableOrd for $t {})*
    }
}

always_applicable_ord! {
    [] u8, [] u16, [] u32, [] u64, [] u128, [] usize,
    [] i8, [] i16, [] i32, [] i64, [] i128, [] isize,
    [] bool, [] char,
    [T: ?Sized] *const T, [T: ?Sized] *mut T,
    [T: AlwaysApplicableOrd] &T,
    [T: AlwaysApplicableOrd] &mut T,
    [T: AlwaysApplicableOrd] Option<T>,
}

#[doc(hidden)]
// ಸ್ಲೈಸ್‌ನ ಆರ್ಡ್‌ನ ವಿಶೇಷತೆಗಾಗಿ ಮಧ್ಯಂತರ trait
trait SliceOrd: Sized {
    fn compare(left: &[Self], right: &[Self]) -> Ordering;
}

impl<A: Ord> SliceOrd for A {
    default fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let l = cmp::min(left.len(), right.len());

        // ಕಂಪೈಲರ್ನಲ್ಲಿ ಬೌಂಡ್ ಚೆಕ್ ಎಲಿಮಿನೇಷನ್ ಅನ್ನು ಸಕ್ರಿಯಗೊಳಿಸಲು ಲೂಪ್ ಪುನರಾವರ್ತನೆ ಶ್ರೇಣಿಗೆ ಸ್ಲೈಸ್ ಮಾಡಿ
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].cmp(&rhs[i]) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }

        left.len().cmp(&right.len())
    }
}

// memcmp ಶಬ್ದರಹಿತವಾಗಿ ಸಹಿ ಮಾಡದ ಬೈಟ್‌ಗಳ ಅನುಕ್ರಮವನ್ನು ಹೋಲಿಸುತ್ತದೆ.
// ಇದು [u8] ಗಾಗಿ ನಾವು ಬಯಸುವ ಕ್ರಮಕ್ಕೆ ಹೊಂದಿಕೆಯಾಗುತ್ತದೆ, ಆದರೆ ಇತರರು ಇಲ್ಲ ([i8] ಸಹ ಅಲ್ಲ).
impl SliceOrd for u8 {
    #[inline]
    fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let order =
            // ಸುರಕ್ಷತೆ: `left` ಮತ್ತು `right` ಉಲ್ಲೇಖಗಳು ಮತ್ತು ಆದ್ದರಿಂದ ಮಾನ್ಯ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.
            // ಆ ಮಧ್ಯಂತರದಲ್ಲಿ ಓದಲು ಎರಡೂ ಪ್ರದೇಶಗಳು ಮಾನ್ಯವಾಗಿರುತ್ತವೆ ಎಂದು ಖಾತರಿಪಡಿಸುವ ಕನಿಷ್ಠ ಎರಡೂ ಉದ್ದಗಳನ್ನು ನಾವು ಬಳಸುತ್ತೇವೆ.
            //
            unsafe { memcmp(left.as_ptr(), right.as_ptr(), cmp::min(left.len(), right.len())) };
        if order == 0 {
            left.len().cmp(&right.len())
        } else if order < 0 {
            Less
        } else {
            Greater
        }
    }
}

// `Eq` ಒಂದು ವಿಧಾನವನ್ನು ಹೊಂದಿದ್ದರೂ ಸಹ `Eq` ನಲ್ಲಿ ವಿಶೇಷತೆಯನ್ನು ಅನುಮತಿಸಲು ಹ್ಯಾಕ್ ಮಾಡಿ.
#[rustc_unsafe_specialization_marker]
trait MarkerEq<T>: PartialEq<T> {}

impl<T: Eq> MarkerEq<T> for T {}

#[doc(hidden)]
/// Trait ಅನ್ನು ಅವುಗಳ ಬೈಟ್‌ವೈಸ್ ಪ್ರಾತಿನಿಧ್ಯವನ್ನು ಬಳಸಿಕೊಂಡು ಸಮಾನತೆಗಾಗಿ ಹೋಲಿಸಬಹುದಾದ ಪ್ರಕಾರಗಳಿಗಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗಿದೆ
///
#[rustc_specialization_trait]
trait BytewiseEquality<T>: MarkerEq<T> + Copy {}

macro_rules! impl_marker_for {
    ($traitname:ident, $($ty:ty)*) => {
        $(
            impl $traitname<$ty> for $ty { }
        )*
    }
}

impl_marker_for!(BytewiseEquality,
                 u8 i8 u16 i16 u32 i32 u64 i64 u128 i128 usize isize char bool);

pub(super) trait SliceContains: Sized {
    fn slice_contains(&self, x: &[Self]) -> bool;
}

impl<T> SliceContains for T
where
    T: PartialEq,
{
    default fn slice_contains(&self, x: &[Self]) -> bool {
        x.iter().any(|y| *y == *self)
    }
}

impl SliceContains for u8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        memchr::memchr(*self, x).is_some()
    }
}

impl SliceContains for i8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        let byte = *self as u8;
        // ಸುರಕ್ಷತೆ: `i8` ಮತ್ತು `u8` ಒಂದೇ ಮೆಮೊರಿ ವಿನ್ಯಾಸವನ್ನು ಹೊಂದಿವೆ, ಹೀಗಾಗಿ `x.as_ptr()` ಅನ್ನು ಬಿತ್ತರಿಸಲಾಗುತ್ತದೆ
        // `*const u8` ಸುರಕ್ಷಿತವಾಗಿದೆ.
        // `x.as_ptr()` ಒಂದು ಉಲ್ಲೇಖದಿಂದ ಬಂದಿದೆ ಮತ್ತು ಆದ್ದರಿಂದ `x.len()` ಸ್ಲೈಸ್‌ನ ಉದ್ದದ ಓದುವಿಕೆಗಳಿಗೆ ಮಾನ್ಯವಾಗಿರುತ್ತದೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ, ಅದು `isize::MAX` ಗಿಂತ ದೊಡ್ಡದಾಗಿರಬಾರದು.
        // ಹಿಂತಿರುಗಿದ ಸ್ಲೈಸ್ ಎಂದಿಗೂ ರೂಪಾಂತರಗೊಳ್ಳುವುದಿಲ್ಲ.
        let bytes: &[u8] = unsafe { from_raw_parts(x.as_ptr() as *const u8, x.len()) };
        memchr::memchr(byte, bytes).is_some()
    }
}