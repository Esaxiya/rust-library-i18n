//! `Result` ಪ್ರಕಾರದೊಂದಿಗೆ ನಿರ್ವಹಿಸುವಲ್ಲಿ ದೋಷ.
//!
//! [`Result<T, E>`][`Result`] ದೋಷಗಳನ್ನು ಹಿಂತಿರುಗಿಸಲು ಮತ್ತು ಪ್ರಚಾರ ಮಾಡಲು ಬಳಸುವ ಪ್ರಕಾರ.
//! ಇದು [`Ok(T)`] ಎಂಬ ರೂಪಾಂತರಗಳೊಂದಿಗೆ ಎನಮ್ ಆಗಿದೆ, ಇದು ಯಶಸ್ಸನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ ಮತ್ತು ಮೌಲ್ಯವನ್ನು ಹೊಂದಿರುತ್ತದೆ, ಮತ್ತು [`Err(E)`], ದೋಷವನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ ಮತ್ತು ದೋಷ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿರುತ್ತದೆ.
//!
//! ```
//! # #[allow(dead_code)]
//! enum Result<T, E> {
//!    Ok(T),
//!    Err(E),
//! }
//! ```
//!
//! ದೋಷಗಳು ನಿರೀಕ್ಷಿಸಿದಾಗ ಮತ್ತು ಮರುಪಡೆಯಬಹುದಾದಾಗ ಕಾರ್ಯಗಳು [`Result`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತವೆ.`std` crate ನಲ್ಲಿ, [`Result`] ಅನ್ನು [I/O](../../std/io/index.html) ಗಾಗಿ ಹೆಚ್ಚು ಪ್ರಮುಖವಾಗಿ ಬಳಸಲಾಗುತ್ತದೆ.
//!
//! [`Result`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುವ ಸರಳ ಕಾರ್ಯವನ್ನು ವ್ಯಾಖ್ಯಾನಿಸಬಹುದು ಮತ್ತು ಹಾಗೆ ಬಳಸಬಹುದು:
//!
//! ```
//! #[derive(Debug)]
//! enum Version { Version1, Version2 }
//!
//! fn parse_version(header: &[u8]) -> Result<Version, &'static str> {
//!     match header.get(0) {
//!         None => Err("invalid header length"),
//!         Some(&1) => Ok(Version::Version1),
//!         Some(&2) => Ok(Version::Version2),
//!         Some(_) => Err("invalid version"),
//!     }
//! }
//!
//! let version = parse_version(&[1, 2, 3, 4]);
//! match version {
//!     Ok(v) => println!("working with version: {:?}", v),
//!     Err(e) => println!("error parsing header: {:?}", e),
//! }
//! ```
//!
//! [`ಫಲಿತಾಂಶ`] ಗಳಲ್ಲಿನ ಪ್ಯಾಟರ್ನ್ ಹೊಂದಾಣಿಕೆ ಸರಳ ಮತ್ತು ಸರಳವಾದ ಪ್ರಕರಣಗಳಿಗೆ ಸ್ಪಷ್ಟವಾಗಿದೆ, ಆದರೆ [`Result`] ಕೆಲವು ಅನುಕೂಲಕರ ವಿಧಾನಗಳೊಂದಿಗೆ ಬರುತ್ತದೆ ಮತ್ತು ಅದು ಅದರೊಂದಿಗೆ ಕೆಲಸ ಮಾಡುವುದನ್ನು ಹೆಚ್ಚು ಸಂಕ್ಷಿಪ್ತಗೊಳಿಸುತ್ತದೆ.
//!
//! ```
//! let good_result: Result<i32, i32> = Ok(10);
//! let bad_result: Result<i32, i32> = Err(10);
//!
//! // `is_ok` ಮತ್ತು `is_err` ವಿಧಾನಗಳು ಅವರು ಹೇಳಿದಂತೆ ಮಾಡುತ್ತವೆ.
//! assert!(good_result.is_ok() && !good_result.is_err());
//! assert!(bad_result.is_err() && !bad_result.is_ok());
//!
//! // `map` `Result` ಅನ್ನು ಬಳಸುತ್ತದೆ ಮತ್ತು ಇನ್ನೊಂದನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ.
//! let good_result: Result<i32, i32> = good_result.map(|i| i + 1);
//! let bad_result: Result<i32, i32> = bad_result.map(|i| i - 1);
//!
//! // ಗಣನೆಯನ್ನು ಮುಂದುವರಿಸಲು `and_then` ಬಳಸಿ.
//! let good_result: Result<bool, i32> = good_result.and_then(|i| Ok(i == 11));
//!
//! // ದೋಷವನ್ನು ನಿರ್ವಹಿಸಲು `or_else` ಬಳಸಿ.
//! let bad_result: Result<i32, i32> = bad_result.or_else(|i| Ok(i + 20));
//!
//! // ಫಲಿತಾಂಶವನ್ನು ಸೇವಿಸಿ ಮತ್ತು `unwrap` ನೊಂದಿಗೆ ವಿಷಯಗಳನ್ನು ಹಿಂತಿರುಗಿಸಿ.
//! let final_awesome_result = good_result.unwrap();
//! ```
//!
//! # ಫಲಿತಾಂಶಗಳನ್ನು ಬಳಸಬೇಕು
//!
//! ದೋಷಗಳನ್ನು ಸೂಚಿಸಲು ರಿಟರ್ನ್ ಮೌಲ್ಯಗಳನ್ನು ಬಳಸುವ ಸಾಮಾನ್ಯ ಸಮಸ್ಯೆ ಎಂದರೆ ರಿಟರ್ನ್ ಮೌಲ್ಯವನ್ನು ನಿರ್ಲಕ್ಷಿಸುವುದು ಸುಲಭ, ಆದ್ದರಿಂದ ದೋಷವನ್ನು ನಿಭಾಯಿಸಲು ವಿಫಲವಾಗಿದೆ.
//! [`Result`] `#[must_use]` ಗುಣಲಕ್ಷಣದೊಂದಿಗೆ ಟಿಪ್ಪಣಿ ಮಾಡಲಾಗಿದೆ, ಇದು ಫಲಿತಾಂಶದ ಮೌಲ್ಯವನ್ನು ನಿರ್ಲಕ್ಷಿಸಿದಾಗ ಕಂಪೈಲರ್ ಎಚ್ಚರಿಕೆ ನೀಡಲು ಕಾರಣವಾಗುತ್ತದೆ.
//! ದೋಷಗಳನ್ನು ಎದುರಿಸಬಹುದಾದ ಆದರೆ ಉಪಯುಕ್ತ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸದಂತಹ ಕಾರ್ಯಗಳೊಂದಿಗೆ ಇದು [`Result`] ಅನ್ನು ವಿಶೇಷವಾಗಿ ಉಪಯುಕ್ತವಾಗಿಸುತ್ತದೆ.
//!
//! [`Write`] trait ನಿಂದ I/O ಪ್ರಕಾರಗಳಿಗಾಗಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ [`write_all`] ವಿಧಾನವನ್ನು ಪರಿಗಣಿಸಿ:
//!
//! ```
//! use std::io;
//!
//! trait Write {
//!     fn write_all(&mut self, bytes: &[u8]) -> Result<(), io::Error>;
//! }
//! ```
//!
//! *Note: [`Write`] ನ ನಿಜವಾದ ವ್ಯಾಖ್ಯಾನವು [`io::Result`] ಅನ್ನು ಬಳಸುತ್ತದೆ, ಇದು ಕೇವಲ [`ಫಲಿತಾಂಶ`]`ಗೆ ಸಮಾನಾರ್ಥಕವಾಗಿದೆ<T,`[`io: :Error`]`>`.*
//!
//! ಈ ವಿಧಾನವು ಮೌಲ್ಯವನ್ನು ಉತ್ಪಾದಿಸುವುದಿಲ್ಲ, ಆದರೆ ಬರಹವು ವಿಫಲವಾಗಬಹುದು.ದೋಷ ಪ್ರಕರಣವನ್ನು ನಿಭಾಯಿಸುವುದು ನಿರ್ಣಾಯಕ, ಮತ್ತು * ಈ ರೀತಿಯದನ್ನು ಬರೆಯಬಾರದು:
//!
//! ```no_run
//! # #![allow(unused_must_use)] // \o/
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! // `write_all` ದೋಷಗಳಿದ್ದರೆ, ನಮಗೆ ಎಂದಿಗೂ ತಿಳಿದಿರುವುದಿಲ್ಲ, ಏಕೆಂದರೆ ರಿಟರ್ನ್ ಮೌಲ್ಯವನ್ನು ನಿರ್ಲಕ್ಷಿಸಲಾಗುತ್ತದೆ.
//! //
//! file.write_all(b"important message");
//! ```
//!
//! Rust ನಲ್ಲಿ ನೀವು ಅದನ್ನು * ಮಾಡಿದರೆ, ಕಂಪೈಲರ್ ನಿಮಗೆ ಎಚ್ಚರಿಕೆ ನೀಡುತ್ತದೆ (ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ, `unused_must_use` lint ನಿಂದ ನಿಯಂತ್ರಿಸಲ್ಪಡುತ್ತದೆ).
//!
//! ನೀವು ದೋಷವನ್ನು ನಿಭಾಯಿಸಲು ಬಯಸದಿದ್ದರೆ, [`expect`] ನೊಂದಿಗೆ ಯಶಸ್ಸನ್ನು ಪ್ರತಿಪಾದಿಸಬಹುದು.
//! ಬರಹ ವಿಫಲವಾದರೆ ಇದು panic ಆಗುತ್ತದೆ, ಏಕೆ ಎಂದು ಸೂಚಿಸುವ ಅಲ್ಪ ಉಪಯುಕ್ತ ಸಂದೇಶವನ್ನು ನೀಡುತ್ತದೆ:
//!
//! ```no_run
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! file.write_all(b"important message").expect("failed to write message");
//! ```
//!
//! ನೀವು ಯಶಸ್ಸನ್ನು ಸರಳವಾಗಿ ಪ್ರತಿಪಾದಿಸಬಹುದು:
//!
//! ```no_run
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # let mut file = File::create("valuable_data.txt").unwrap();
//! assert!(file.write_all(b"important message").is_ok());
//! ```
//!
//! ಅಥವಾ [`?`] ನೊಂದಿಗೆ ಕರೆ ಸ್ಟ್ಯಾಕ್‌ನಲ್ಲಿ ದೋಷವನ್ನು ಪ್ರಚಾರ ಮಾಡಿ:
//!
//! ```
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # use std::io;
//! # #[allow(dead_code)]
//! fn write_message() -> io::Result<()> {
//!     let mut file = File::create("valuable_data.txt")?;
//!     file.write_all(b"important message")?;
//!     Ok(())
//! }
//! ```
//!
//! # ಪ್ರಶ್ನೆ ಗುರುತು ಆಪರೇಟರ್, `?`
//!
//! [`Result`] ಪ್ರಕಾರವನ್ನು ಹಿಂದಿರುಗಿಸುವ ಅನೇಕ ಕಾರ್ಯಗಳನ್ನು ಕರೆಯುವ ಕೋಡ್ ಬರೆಯುವಾಗ, ದೋಷ ನಿರ್ವಹಣೆ ಬೇಸರದ ಸಂಗತಿಯಾಗಿದೆ.
//! ಪ್ರಶ್ನೆ ಗುರುತು ಆಪರೇಟರ್, [`?`], ಕರೆ ಸ್ಟ್ಯಾಕ್‌ನಲ್ಲಿ ದೋಷಗಳನ್ನು ಪ್ರಚಾರ ಮಾಡುವ ಕೆಲವು ಬಾಯ್ಲರ್ ಅನ್ನು ಮರೆಮಾಡುತ್ತದೆ.
//!
//! ಇದು ಇದನ್ನು ಬದಲಾಯಿಸುತ್ತದೆ:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     // ದೋಷದ ಆರಂಭಿಕ ಲಾಭ
//!     let mut file = match File::create("my_best_friends.txt") {
//!            Err(e) => return Err(e),
//!            Ok(f) => f,
//!     };
//!     if let Err(e) = file.write_all(format!("name: {}\n", info.name).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("age: {}\n", info.age).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("rating: {}\n", info.rating).as_bytes()) {
//!         return Err(e)
//!     }
//!     Ok(())
//! }
//! ```
//!
//! ಇದರೊಂದಿಗೆ:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     let mut file = File::create("my_best_friends.txt")?;
//!     // ದೋಷದ ಆರಂಭಿಕ ಲಾಭ
//!     file.write_all(format!("name: {}\n", info.name).as_bytes())?;
//!     file.write_all(format!("age: {}\n", info.age).as_bytes())?;
//!     file.write_all(format!("rating: {}\n", info.rating).as_bytes())?;
//!     Ok(())
//! }
//! ```
//!
//! *ಇದು ತುಂಬಾ ಒಳ್ಳೆಯದು!*
//!
//! [`?`] ನೊಂದಿಗೆ ಅಭಿವ್ಯಕ್ತಿಯನ್ನು ಕೊನೆಗೊಳಿಸುವುದರಿಂದ ಫಲಿತಾಂಶವು [`Err`] ಆಗದ ಹೊರತು, ಅನ್ರ್ಯಾಪ್ ಮಾಡದ ಯಶಸ್ಸಿನ ([`Ok`]) ಮೌಲ್ಯಕ್ಕೆ ಕಾರಣವಾಗುತ್ತದೆ, ಈ ಸಂದರ್ಭದಲ್ಲಿ [`Err`] ಅನ್ನು ಸುತ್ತುವರಿದ ಕಾರ್ಯದಿಂದ ಮೊದಲೇ ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
//!
//!
//! [`?`] [`Result`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುವ ಕಾರ್ಯಗಳಲ್ಲಿ ಮಾತ್ರ ಇದನ್ನು ಬಳಸಬಹುದು ಏಕೆಂದರೆ ಅದು ಒದಗಿಸುವ [`Err`] ನ ಆರಂಭಿಕ ಆದಾಯ.
//!
//! [`expect`]: Result::expect
//! [`Write`]: ../../std/io/trait.Write.html
//! [`write_all`]: ../../std/io/trait.Write.html#method.write_all
//! [`io::Result`]: ../../std/io/type.Result.html
//! [`?`]: crate::ops::Try
//! [`Ok(T)`]: Ok
//! [`Err(E)`]: Err
//! [`io::Error`]: ../../std/io/struct.Error.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{self, FromIterator, FusedIterator, TrustedLen};
use crate::ops::{self, Deref, DerefMut};
use crate::{convert, fmt, hint};

/// `Result` ಇದು ಯಶಸ್ಸಿನ ([`Ok`]) ಅಥವಾ ವೈಫಲ್ಯ ([`Err`]) ಅನ್ನು ಪ್ರತಿನಿಧಿಸುವ ಒಂದು ವಿಧವಾಗಿದೆ.
///
/// ವಿವರಗಳಿಗಾಗಿ [module documentation](self) ನೋಡಿ.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[must_use = "this `Result` may be an `Err` variant, which should be handled"]
#[rustc_diagnostic_item = "result_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Result<T, E> {
    /// ಯಶಸ್ಸಿನ ಮೌಲ್ಯವನ್ನು ಒಳಗೊಂಡಿದೆ
    #[lang = "Ok"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Ok(#[stable(feature = "rust1", since = "1.0.0")] T),

    /// ದೋಷ ಮೌಲ್ಯವನ್ನು ಒಳಗೊಂಡಿದೆ
    #[lang = "Err"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Err(#[stable(feature = "rust1", since = "1.0.0")] E),
}

/////////////////////////////////////////////////////////////////////////////
// ಟೈಪ್ ಅನುಷ್ಠಾನ
/////////////////////////////////////////////////////////////////////////////

impl<T, E> Result<T, E> {
    /////////////////////////////////////////////////////////////////////////
    // ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯಗಳನ್ನು ಪ್ರಶ್ನಿಸುವುದು
    /////////////////////////////////////////////////////////////////////////

    /// ಫಲಿತಾಂಶವು [`Ok`] ಆಗಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_ok(), true);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_ok(), false);
    /// ```
    #[must_use = "if you intended to assert that this is ok, consider `.unwrap()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_ok(&self) -> bool {
        matches!(*self, Ok(_))
    }

    /// ಫಲಿತಾಂಶವು [`Err`] ಆಗಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_err(), false);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_err(), true);
    /// ```
    #[must_use = "if you intended to assert that this is err, consider `.unwrap_err()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_err(&self) -> bool {
        !self.is_ok()
    }

    /// ಫಲಿತಾಂಶವು ನಿರ್ದಿಷ್ಟ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿರುವ [`Ok`] ಮೌಲ್ಯವಾಗಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Result<u32, &str> = Ok(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Ok(y) => x == y,
            Err(_) => false,
        }
    }

    /// ಫಲಿತಾಂಶವು ನಿರ್ದಿಷ್ಟ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿರುವ [`Err`] ಮೌಲ್ಯವಾಗಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_contains_err)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains_err(&"Some error message"), true);
    ///
    /// let x: Result<u32, &str> = Err("Some other error message");
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "result_contains_err", issue = "62358")]
    pub fn contains_err<F>(&self, f: &F) -> bool
    where
        F: PartialEq<E>,
    {
        match self {
            Ok(_) => false,
            Err(e) => f == e,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ಪ್ರತಿ ರೂಪಾಂತರಕ್ಕೆ ಅಡಾಪ್ಟರ್
    /////////////////////////////////////////////////////////////////////////

    /// `Result<T, E>` ನಿಂದ [`Option<T>`] ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// `self` ಅನ್ನು [`Option<T>`] ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ, `self` ಅನ್ನು ಸೇವಿಸುತ್ತದೆ ಮತ್ತು ಯಾವುದಾದರೂ ಇದ್ದರೆ ದೋಷವನ್ನು ತ್ಯಜಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.ok(), Some(2));
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.ok(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok(self) -> Option<T> {
        match self {
            Ok(x) => Some(x),
            Err(_) => None,
        }
    }

    /// `Result<T, E>` ನಿಂದ [`Option<E>`] ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// `self` ಅನ್ನು [`Option<E>`] ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ, `self` ಅನ್ನು ಸೇವಿಸುತ್ತದೆ ಮತ್ತು ಯಶಸ್ಸಿನ ಮೌಲ್ಯವನ್ನು ಯಾವುದಾದರೂ ಇದ್ದರೆ ತ್ಯಜಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.err(), None);
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.err(), Some("Nothing here"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn err(self) -> Option<E> {
        match self {
            Ok(_) => None,
            Err(x) => Some(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ಉಲ್ಲೇಖಗಳೊಂದಿಗೆ ಕೆಲಸ ಮಾಡಲು ಅಡಾಪ್ಟರ್
    /////////////////////////////////////////////////////////////////////////

    /// `&Result<T, E>` ನಿಂದ `Result<&T, &E>` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ಹೊಸ `Result` ಅನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ, ಮೂಲದ ಬಗ್ಗೆ ಉಲ್ಲೇಖವನ್ನು ಒಳಗೊಂಡಿರುತ್ತದೆ, ಮೂಲವನ್ನು ಸ್ಥಳದಲ್ಲಿ ಇಡುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.as_ref(), Ok(&2));
    ///
    /// let x: Result<u32, &str> = Err("Error");
    /// assert_eq!(x.as_ref(), Err(&"Error"));
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Result<&T, &E> {
        match *self {
            Ok(ref x) => Ok(x),
            Err(ref x) => Err(x),
        }
    }

    /// `&mut Result<T, E>` ನಿಂದ `Result<&mut T, &mut E>` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// fn mutate(r: &mut Result<i32, i32>) {
    ///     match r.as_mut() {
    ///         Ok(v) => *v = 42,
    ///         Err(e) => *e = 0,
    ///     }
    /// }
    ///
    /// let mut x: Result<i32, i32> = Ok(2);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap(), 42);
    ///
    /// let mut x: Result<i32, i32> = Err(13);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap_err(), 0);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Result<&mut T, &mut E> {
        match *self {
            Ok(ref mut x) => Ok(x),
            Err(ref mut x) => Err(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯಗಳನ್ನು ಪರಿವರ್ತಿಸುವುದು
    /////////////////////////////////////////////////////////////////////////

    /// ಒಳಗೊಂಡಿರುವ [`Ok`] ಮೌಲ್ಯಕ್ಕೆ ಕಾರ್ಯವನ್ನು ಅನ್ವಯಿಸುವ ಮೂಲಕ `Result<T, E>` ನಿಂದ `Result<U, E>` ಗೆ ನಕ್ಷೆ ಮಾಡುತ್ತದೆ, ಮತ್ತು [`Err`] ಮೌಲ್ಯವನ್ನು ಅಸ್ಪೃಶ್ಯವಾಗಿ ಬಿಡುತ್ತದೆ.
    ///
    ///
    /// ಎರಡು ಕಾರ್ಯಗಳ ಫಲಿತಾಂಶಗಳನ್ನು ಸಂಯೋಜಿಸಲು ಈ ಕಾರ್ಯವನ್ನು ಬಳಸಬಹುದು.
    ///
    /// # Examples
    ///
    /// ಎರಡು ಗುಣಿಸಿದಾಗ ಸ್ಟ್ರಿಂಗ್‌ನ ಪ್ರತಿಯೊಂದು ಸಾಲಿನ ಸಂಖ್ಯೆಗಳನ್ನು ಮುದ್ರಿಸಿ.
    ///
    /// ```
    /// let line = "1\n2\n3\n4\n";
    ///
    /// for num in line.lines() {
    ///     match num.parse::<i32>().map(|i| i * 2) {
    ///         Ok(n) => println!("{}", n),
    ///         Err(..) => {}
    ///     }
    /// }
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => Ok(op(t)),
            Err(e) => Err(e),
        }
    }

    /// ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯಕ್ಕೆ ([`Ok`] ಆಗಿದ್ದರೆ) ಒಂದು ಕಾರ್ಯವನ್ನು ಅನ್ವಯಿಸುತ್ತದೆ, ಅಥವಾ ಒದಗಿಸಿದ ಡೀಫಾಲ್ಟ್ ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ ([`Err`] ಆಗಿದ್ದರೆ).
    ///
    /// `map_or` ಗೆ ರವಾನಿಸಲಾದ ವಾದಗಳನ್ನು ಕುತೂಹಲದಿಂದ ಮೌಲ್ಯಮಾಪನ ಮಾಡಲಾಗುತ್ತದೆ;ನೀವು ಕಾರ್ಯ ಕರೆಯ ಫಲಿತಾಂಶವನ್ನು ರವಾನಿಸುತ್ತಿದ್ದರೆ, [`map_or_else`] ಅನ್ನು ಬಳಸಲು ಶಿಫಾರಸು ಮಾಡಲಾಗಿದೆ, ಇದನ್ನು ಸೋಮಾರಿಯಾಗಿ ಮೌಲ್ಯಮಾಪನ ಮಾಡಲಾಗುತ್ತದೆ.
    ///
    ///
    /// [`map_or_else`]: Result::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or", since = "1.41.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(_) => default,
        }
    }

    /// ಒಳಗೊಂಡಿರುವ [`Ok`] ಮೌಲ್ಯಕ್ಕೆ ಒಂದು ಕಾರ್ಯವನ್ನು ಅನ್ವಯಿಸುವ ಮೂಲಕ `Result<T, E>` ನಿಂದ `U` ಗೆ ನಕ್ಷೆ ಮಾಡುತ್ತದೆ ಅಥವಾ ಒಳಗೊಂಡಿರುವ [`Err`] ಮೌಲ್ಯಕ್ಕೆ ಫಾಲ್‌ಬ್ಯಾಕ್ ಕಾರ್ಯವನ್ನು ಮಾಡುತ್ತದೆ.
    ///
    ///
    /// ದೋಷವನ್ನು ನಿರ್ವಹಿಸುವಾಗ ಯಶಸ್ವಿ ಫಲಿತಾಂಶವನ್ನು ಅನ್ಪ್ಯಾಕ್ ಮಾಡಲು ಈ ಕಾರ್ಯವನ್ನು ಬಳಸಬಹುದು.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x : Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 3);
    ///
    /// let x : Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 42);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or_else", since = "1.41.0")]
    pub fn map_or_else<U, D: FnOnce(E) -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(e) => default(e),
        }
    }

    /// ಒಳಗೊಂಡಿರುವ [`Err`] ಮೌಲ್ಯಕ್ಕೆ ಕಾರ್ಯವನ್ನು ಅನ್ವಯಿಸುವ ಮೂಲಕ `Result<T, E>` ನಿಂದ `Result<T, F>` ಗೆ ನಕ್ಷೆ ಮಾಡುತ್ತದೆ, ಮತ್ತು [`Ok`] ಮೌಲ್ಯವನ್ನು ಅಸ್ಪೃಶ್ಯವಾಗಿ ಬಿಡುತ್ತದೆ.
    ///
    ///
    /// ದೋಷವನ್ನು ನಿರ್ವಹಿಸುವಾಗ ಯಶಸ್ವಿ ಫಲಿತಾಂಶವನ್ನು ಹಾದುಹೋಗಲು ಈ ಕಾರ್ಯವನ್ನು ಬಳಸಬಹುದು.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// fn stringify(x: u32) -> String { format!("error code: {}", x) }
    ///
    /// let x: Result<u32, u32> = Ok(2);
    /// assert_eq!(x.map_err(stringify), Ok(2));
    ///
    /// let x: Result<u32, u32> = Err(13);
    /// assert_eq!(x.map_err(stringify), Err("error code: 13".to_string()));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_err<F, O: FnOnce(E) -> F>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => Err(op(e)),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ಇಟರೇಟರ್ ಕನ್‌ಸ್ಟ್ರಕ್ಟರ್‌ಗಳು
    /////////////////////////////////////////////////////////////////////////

    /// ಬಹುಶಃ ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯದ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಫಲಿತಾಂಶವು [`Result::Ok`] ಆಗಿದ್ದರೆ ಪುನರಾವರ್ತಕವು ಒಂದು ಮೌಲ್ಯವನ್ನು ನೀಡುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ ಯಾವುದೂ ಇಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(7);
    /// assert_eq!(x.iter().next(), Some(&7));
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { inner: self.as_ref().ok() }
    }

    /// ಬಹುಶಃ ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯದ ಮೇಲೆ ರೂಪಾಂತರಿತ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಫಲಿತಾಂಶವು [`Result::Ok`] ಆಗಿದ್ದರೆ ಪುನರಾವರ್ತಕವು ಒಂದು ಮೌಲ್ಯವನ್ನು ನೀಡುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ ಯಾವುದೂ ಇಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let mut x: Result<u32, &str> = Ok(7);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 40,
    ///     None => {},
    /// }
    /// assert_eq!(x, Ok(40));
    ///
    /// let mut x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: self.as_mut().ok() }
    }

    ////////////////////////////////////////////////////////////////////////
    // ಮೌಲ್ಯಗಳ ಮೇಲೆ ಬೂಲಿಯನ್ ಕಾರ್ಯಾಚರಣೆಗಳು, ಉತ್ಸಾಹ ಮತ್ತು ಸೋಮಾರಿಯಾದ
    /////////////////////////////////////////////////////////////////////////

    /// ಫಲಿತಾಂಶವು [`Ok`] ಆಗಿದ್ದರೆ `res` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ `self` ನ [`Err`] ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<&str, &str> = Ok("foo");
    /// assert_eq!(x.and(y), Err("early error"));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("not a 2"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Ok("different result type");
    /// assert_eq!(x.and(y), Ok("different result type"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, res: Result<U, E>) -> Result<U, E> {
        match self {
            Ok(_) => res,
            Err(e) => Err(e),
        }
    }

    /// ಫಲಿತಾಂಶವು [`Ok`] ಆಗಿದ್ದರೆ `op` ಅನ್ನು ಕರೆ ಮಾಡುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ `self` ನ [`Err`] ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// ಈ ಕಾರ್ಯವನ್ನು `Result` ಮೌಲ್ಯಗಳ ಆಧಾರದ ಮೇಲೆ ನಿಯಂತ್ರಣ ಹರಿವುಗಾಗಿ ಬಳಸಬಹುದು.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).and_then(sq).and_then(sq), Ok(16));
    /// assert_eq!(Ok(2).and_then(sq).and_then(err), Err(4));
    /// assert_eq!(Ok(2).and_then(err).and_then(sq), Err(2));
    /// assert_eq!(Err(3).and_then(sq).and_then(sq), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Result<U, E>>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => op(t),
            Err(e) => Err(e),
        }
    }

    /// ಫಲಿತಾಂಶವು [`Err`] ಆಗಿದ್ದರೆ `res` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ `self` ನ [`Ok`] ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `or` ಗೆ ರವಾನಿಸಲಾದ ವಾದಗಳನ್ನು ಕುತೂಹಲದಿಂದ ಮೌಲ್ಯಮಾಪನ ಮಾಡಲಾಗುತ್ತದೆ;ನೀವು ಕಾರ್ಯ ಕರೆಯ ಫಲಿತಾಂಶವನ್ನು ರವಾನಿಸುತ್ತಿದ್ದರೆ, [`or_else`] ಅನ್ನು ಬಳಸಲು ಶಿಫಾರಸು ಮಾಡಲಾಗಿದೆ, ಇದನ್ನು ಸೋಮಾರಿಯಾಗಿ ಮೌಲ್ಯಮಾಪನ ಮಾಡಲಾಗುತ್ತದೆ.
    ///
    ///
    /// [`or_else`]: Result::or_else
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Ok(100);
    /// assert_eq!(x.or(y), Ok(2));
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or<F>(self, res: Result<T, F>) -> Result<T, F> {
        match self {
            Ok(v) => Ok(v),
            Err(_) => res,
        }
    }

    /// ಫಲಿತಾಂಶವು [`Err`] ಆಗಿದ್ದರೆ `op` ಅನ್ನು ಕರೆ ಮಾಡುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ `self` ನ [`Ok`] ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// ಫಲಿತಾಂಶದ ಮೌಲ್ಯಗಳ ಆಧಾರದ ಮೇಲೆ ನಿಯಂತ್ರಣ ಹರಿವಿಗೆ ಈ ಕಾರ್ಯವನ್ನು ಬಳಸಬಹುದು.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).or_else(sq).or_else(sq), Ok(2));
    /// assert_eq!(Ok(2).or_else(err).or_else(sq), Ok(2));
    /// assert_eq!(Err(3).or_else(sq).or_else(err), Ok(9));
    /// assert_eq!(Err(3).or_else(err).or_else(err), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F, O: FnOnce(E) -> Result<T, F>>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => op(e),
        }
    }

    /// ಒಳಗೊಂಡಿರುವ [`Ok`] ಮೌಲ್ಯ ಅಥವಾ ಒದಗಿಸಿದ ಡೀಫಾಲ್ಟ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `unwrap_or` ಗೆ ರವಾನಿಸಲಾದ ವಾದಗಳನ್ನು ಕುತೂಹಲದಿಂದ ಮೌಲ್ಯಮಾಪನ ಮಾಡಲಾಗುತ್ತದೆ;ನೀವು ಕಾರ್ಯ ಕರೆಯ ಫಲಿತಾಂಶವನ್ನು ರವಾನಿಸುತ್ತಿದ್ದರೆ, [`unwrap_or_else`] ಅನ್ನು ಬಳಸಲು ಶಿಫಾರಸು ಮಾಡಲಾಗಿದೆ, ಇದನ್ನು ಸೋಮಾರಿಯಾಗಿ ಮೌಲ್ಯಮಾಪನ ಮಾಡಲಾಗುತ್ತದೆ.
    ///
    ///
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let default = 2;
    /// let x: Result<u32, &str> = Ok(9);
    /// assert_eq!(x.unwrap_or(default), 9);
    ///
    /// let x: Result<u32, &str> = Err("error");
    /// assert_eq!(x.unwrap_or(default), default);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Ok(t) => t,
            Err(_) => default,
        }
    }

    /// ಒಳಗೊಂಡಿರುವ [`Ok`] ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ ಅಥವಾ ಮುಚ್ಚುವಿಕೆಯಿಂದ ಅದನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// fn count(x: &str) -> usize { x.len() }
    ///
    /// assert_eq!(Ok(2).unwrap_or_else(count), 2);
    /// assert_eq!(Err("foo").unwrap_or_else(count), 3);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce(E) -> T>(self, op: F) -> T {
        match self {
            Ok(t) => t,
            Err(e) => op(e),
        }
    }

    /// ಮೌಲ್ಯವು [`Err`] ಅಲ್ಲ ಎಂದು ಪರಿಶೀಲಿಸದೆ, `self` ಮೌಲ್ಯವನ್ನು ಸೇವಿಸುವ, ಒಳಗೊಂಡಿರುವ [`Ok`] ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Safety
    ///
    /// ಈ ವಿಧಾನವನ್ನು [`Err`] ನಲ್ಲಿ ಕರೆಯುವುದು *[ವಿವರಿಸಲಾಗದ ನಡವಳಿಕೆ]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, 2);
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// unsafe { x.unwrap_unchecked(); } // ವಿವರಿಸಲಾಗದ ನಡವಳಿಕೆ!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_ok());
        match self {
            Ok(t) => t,
            // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರಿಂದ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
            Err(_) => unsafe { hint::unreachable_unchecked() },
        }
    }

    /// ಮೌಲ್ಯವು [`Ok`] ಅಲ್ಲ ಎಂದು ಪರಿಶೀಲಿಸದೆ, `self` ಮೌಲ್ಯವನ್ನು ಸೇವಿಸುವ, ಒಳಗೊಂಡಿರುವ [`Err`] ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Safety
    ///
    /// ಈ ವಿಧಾನವನ್ನು [`Ok`] ನಲ್ಲಿ ಕರೆಯುವುದು *[ವಿವರಿಸಲಾಗದ ನಡವಳಿಕೆ]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// unsafe { x.unwrap_err_unchecked() }; // ವಿವರಿಸಲಾಗದ ನಡವಳಿಕೆ!
    /// ```
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(unsafe { x.unwrap_err_unchecked() }, "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_err_unchecked(self) -> E {
        debug_assert!(self.is_err());
        match self {
            // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರಿಂದ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
            Ok(_) => unsafe { hint::unreachable_unchecked() },
            Err(e) => e,
        }
    }
}

impl<T: Copy, E> Result<&T, E> {
    /// `Ok` ಭಾಗದ ವಿಷಯಗಳನ್ನು ನಕಲಿಸುವ ಮೂಲಕ `Result<&T, E>` ಅನ್ನು `Result<T, E>` ಗೆ ನಕ್ಷೆ ಮಾಡುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&t| t)
    }
}

impl<T: Copy, E> Result<&mut T, E> {
    /// `Ok` ಭಾಗದ ವಿಷಯಗಳನ್ನು ನಕಲಿಸುವ ಮೂಲಕ `Result<&mut T, E>` ಅನ್ನು `Result<T, E>` ಗೆ ನಕ್ಷೆ ಮಾಡುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone, E> Result<&T, E> {
    /// `Ok` ಭಾಗದ ವಿಷಯಗಳನ್ನು ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮಾಡುವ ಮೂಲಕ `Result<&T, E>` ಅನ್ನು `Result<T, E>` ಗೆ ನಕ್ಷೆ ಮಾಡುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone, E> Result<&mut T, E> {
    /// `Ok` ಭಾಗದ ವಿಷಯಗಳನ್ನು ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮಾಡುವ ಮೂಲಕ `Result<&mut T, E>` ಅನ್ನು `Result<T, E>` ಗೆ ನಕ್ಷೆ ಮಾಡುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T, E: fmt::Debug> Result<T, E> {
    /// ಒಳಗೊಂಡಿರುವ [`Ok`] ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, `self` ಮೌಲ್ಯವನ್ನು ಬಳಸುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// Panics ಮೌಲ್ಯವು [`Err`] ಆಗಿದ್ದರೆ, ರವಾನಿಸಿದ ಸಂದೇಶವನ್ನು ಒಳಗೊಂಡಂತೆ panic ಸಂದೇಶ ಮತ್ತು [`Err`] ನ ವಿಷಯವನ್ನು ಒಳಗೊಂಡಿರುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.expect("Testing expect"); // panics with `Testing expect: emergency failure`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect", since = "1.4.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed(msg, &e),
        }
    }

    /// ಒಳಗೊಂಡಿರುವ [`Ok`] ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, `self` ಮೌಲ್ಯವನ್ನು ಬಳಸುತ್ತದೆ.
    ///
    /// ಈ ಕಾರ್ಯವು panic ಆಗಿರಬಹುದು, ಇದರ ಬಳಕೆಯನ್ನು ಸಾಮಾನ್ಯವಾಗಿ ನಿರುತ್ಸಾಹಗೊಳಿಸಲಾಗುತ್ತದೆ.
    /// ಬದಲಾಗಿ, ಪ್ಯಾಟರ್ನ್ ಹೊಂದಾಣಿಕೆಯನ್ನು ಬಳಸಲು ಆದ್ಯತೆ ನೀಡಿ ಮತ್ತು [`Err`] ಕೇಸ್ ಅನ್ನು ಸ್ಪಷ್ಟವಾಗಿ ನಿರ್ವಹಿಸಲು ಅಥವಾ [`unwrap_or`], [`unwrap_or_else`], ಅಥವಾ [`unwrap_or_default`] ಗೆ ಕರೆ ಮಾಡಿ.
    ///
    ///
    /// [`unwrap_or`]: Result::unwrap_or
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    /// [`unwrap_or_default`]: Result::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics ಮೌಲ್ಯವು [`Err`] ಆಗಿದ್ದರೆ, [`Err`] ನ ಮೌಲ್ಯದಿಂದ ಒದಗಿಸಲಾದ panic ಸಂದೇಶದೊಂದಿಗೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.unwrap(), 2);
    /// ```
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.unwrap(); // panics with `emergency failure`
    /// ```
    ///
    ///
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap(self) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed("called `Result::unwrap()` on an `Err` value", &e),
        }
    }
}

impl<T: fmt::Debug, E> Result<T, E> {
    /// ಒಳಗೊಂಡಿರುವ [`Err`] ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, `self` ಮೌಲ್ಯವನ್ನು ಬಳಸುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// Panics ಮೌಲ್ಯವು [`Ok`] ಆಗಿದ್ದರೆ, ರವಾನಿಸಿದ ಸಂದೇಶವನ್ನು ಒಳಗೊಂಡಂತೆ panic ಸಂದೇಶ ಮತ್ತು [`Ok`] ನ ವಿಷಯವನ್ನು ಒಳಗೊಂಡಿರುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(10);
    /// x.expect_err("Testing expect_err"); // panics with `Testing expect_err: 10`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect_err", since = "1.17.0")]
    pub fn expect_err(self, msg: &str) -> E {
        match self {
            Ok(t) => unwrap_failed(msg, &t),
            Err(e) => e,
        }
    }

    /// ಒಳಗೊಂಡಿರುವ [`Err`] ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, `self` ಮೌಲ್ಯವನ್ನು ಬಳಸುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// Panics ಮೌಲ್ಯವು [`Ok`] ಆಗಿದ್ದರೆ, ಕಸ್ಟಮ್ panic ಸಂದೇಶದೊಂದಿಗೆ [`ಸರಿ`] ಮೌಲ್ಯದಿಂದ ಒದಗಿಸಲಾಗುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(2);
    /// x.unwrap_err(); // panics with `2`
    /// ```
    ///
    /// ```
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(x.unwrap_err(), "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_err(self) -> E {
        match self {
            Ok(t) => unwrap_failed("called `Result::unwrap_err()` on an `Ok` value", &t),
            Err(e) => e,
        }
    }
}

impl<T: Default, E> Result<T, E> {
    /// ಒಳಗೊಂಡಿರುವ [`Ok`] ಮೌಲ್ಯ ಅಥವಾ ಡೀಫಾಲ್ಟ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ
    ///
    /// `self` ಆರ್ಗ್ಯುಮೆಂಟ್ ಅನ್ನು ಬಳಸುತ್ತದೆ, [`Ok`] ಇದ್ದರೆ, ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ [`Err`] ಆಗಿದ್ದರೆ, ಆ ಪ್ರಕಾರದ ಡೀಫಾಲ್ಟ್ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಪೂರ್ಣಾಂಕಕ್ಕೆ ಪರಿವರ್ತಿಸುತ್ತದೆ, ಕಳಪೆಯಾಗಿ ರೂಪುಗೊಂಡ ತಂತಿಗಳನ್ನು 0 ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ (ಪೂರ್ಣಾಂಕಗಳಿಗೆ ಪೂರ್ವನಿಯೋಜಿತ ಮೌಲ್ಯ).
    /// [`parse`] [`FromStr`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಯಾವುದೇ ಪ್ರಕಾರಕ್ಕೆ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಪರಿವರ್ತಿಸುತ್ತದೆ, [`Err`] ಅನ್ನು ದೋಷದಿಂದ ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_unwrap_or_default", since = "1.16.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Ok(x) => x,
            Err(_) => Default::default(),
        }
    }
}

#[unstable(feature = "unwrap_infallible", reason = "newly added", issue = "61695")]
impl<T, E: Into<!>> Result<T, E> {
    /// ಒಳಗೊಂಡಿರುವ [`Ok`] ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಆದರೆ ಎಂದಿಗೂ panics.
    ///
    /// [`unwrap`] ಗಿಂತ ಭಿನ್ನವಾಗಿ, ಈ ವಿಧಾನವು ಅದನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದ ಫಲಿತಾಂಶ ಪ್ರಕಾರಗಳಲ್ಲಿ ಎಂದಿಗೂ panic ಎಂದು ತಿಳಿದಿಲ್ಲ.
    /// ಆದ್ದರಿಂದ, ಇದನ್ನು `unwrap` ಬದಲಿಗೆ ನಿರ್ವಹಣೆಯ ಸುರಕ್ಷತೆಯಾಗಿ ಬಳಸಬಹುದು, ಅದು `Result` ನ ದೋಷ ಪ್ರಕಾರವನ್ನು ನಂತರ ನಿಜವಾಗಿ ಸಂಭವಿಸಬಹುದಾದ ದೋಷಕ್ಕೆ ಬದಲಾಯಿಸಿದರೆ ಕಂಪೈಲ್ ಮಾಡಲು ವಿಫಲವಾಗುತ್ತದೆ.
    ///
    ///
    /// [`unwrap`]: Result::unwrap
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// # #![feature(never_type)]
    /// # #![feature(unwrap_infallible)]
    ///
    /// fn only_good_news() -> Result<String, !> {
    ///     Ok("this is fine".into())
    /// }
    ///
    /// let s: String = only_good_news().into_ok();
    /// println!("{}", s);
    /// ```
    ///
    ///
    #[inline]
    pub fn into_ok(self) -> T {
        match self {
            Ok(x) => x,
            Err(e) => e.into(),
        }
    }
}

impl<T: Deref, E> Result<T, E> {
    /// `Result<T, E>` (ಅಥವಾ `&Result<T, E>`) ನಿಂದ `Result<&<T as Deref>::Target, &E>` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// [`Deref`](crate::ops::Deref) ಮೂಲಕ ಮೂಲ [`Result`] ನ [`Ok`] ರೂಪಾಂತರವನ್ನು ಒತ್ತಾಯಿಸುತ್ತದೆ ಮತ್ತು ಹೊಸ [`Result`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&str, &u32> = Ok("hello");
    /// assert_eq!(x.as_deref(), y);
    ///
    /// let x: Result<String, u32> = Err(42);
    /// let y: Result<&str, &u32> = Err(&42);
    /// assert_eq!(x.as_deref(), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref(&self) -> Result<&T::Target, &E> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut, E> Result<T, E> {
    /// `Result<T, E>` (ಅಥವಾ `&mut Result<T, E>`) ನಿಂದ `Result<&mut <T as DerefMut>::Target, &mut E>` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// [`DerefMut`](crate::ops::DerefMut) ಮೂಲಕ ಮೂಲ [`Result`] ನ [`Ok`] ರೂಪಾಂತರವನ್ನು ಒತ್ತಾಯಿಸುತ್ತದೆ ಮತ್ತು ಹೊಸ [`Result`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = "HELLO".to_string();
    /// let mut x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&mut str, &mut u32> = Ok(&mut s);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    ///
    /// let mut i = 42;
    /// let mut x: Result<String, u32> = Err(42);
    /// let y: Result<&mut str, &mut u32> = Err(&mut i);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref_mut(&mut self) -> Result<&mut T::Target, &mut E> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Result<Option<T>, E> {
    /// `Option` ನ `Result` ಅನ್ನು `Result` ನ `Option` ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// `Ok(None)` `None` ಗೆ ಮ್ಯಾಪ್ ಮಾಡಲಾಗುತ್ತದೆ.
    /// `Ok(Some(_))` ಮತ್ತು `Err(_)` ಅನ್ನು `Some(Ok(_))` ಮತ್ತು `Some(Err(_))` ಗೆ ಮ್ಯಾಪ್ ಮಾಡಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x.transpose(), y);
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_result", issue = "82814")]
    pub const fn transpose(self) -> Option<Result<T, E>> {
        match self {
            Ok(Some(x)) => Some(Ok(x)),
            Ok(None) => None,
            Err(e) => Some(Err(e)),
        }
    }
}

impl<T, E> Result<Result<T, E>, E> {
    /// `Result<Result<T, E>, E>` ನಿಂದ `Result<T, E>` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Ok("hello"));
    /// assert_eq!(Ok("hello"), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Err(6));
    /// assert_eq!(Err(6), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Err(6);
    /// assert_eq!(Err(6), x.flatten());
    /// ```
    ///
    /// ಚಪ್ಪಟೆಯಾಗುವುದು ಒಂದು ಸಮಯದಲ್ಲಿ ಒಂದು ಹಂತದ ಗೂಡುಕಟ್ಟುವಿಕೆಯನ್ನು ಮಾತ್ರ ತೆಗೆದುಹಾಕುತ್ತದೆ:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<Result<&'static str, u32>, u32>, u32> = Ok(Ok(Ok("hello")));
    /// assert_eq!(Ok(Ok("hello")), x.flatten());
    /// assert_eq!(Ok("hello"), x.flatten().flatten());
    /// ```
    #[inline]
    #[unstable(feature = "result_flattening", issue = "70142")]
    pub fn flatten(self) -> Result<T, E> {
        self.and_then(convert::identity)
    }
}

impl<T> Result<T, T> {
    /// `self` `Ok` ಆಗಿದ್ದರೆ [`Ok`] ಮೌಲ್ಯವನ್ನು ಮತ್ತು `self` `Err` ಆಗಿದ್ದರೆ [`Err`] ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, ಈ ಕಾರ್ಯವು `Ok` ಅಥವಾ `Err` ಆಗಿರಲಿ ಅಥವಾ ಇಲ್ಲದಿರಲಿ, `Result<T, T>` ನ ಮೌಲ್ಯವನ್ನು (`T`) ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಇದು [`Atomic*::compare_exchange`], ಅಥವಾ [`slice::binary_search`] ನಂತಹ API ಗಳ ಜೊತೆಯಲ್ಲಿ ಉಪಯುಕ್ತವಾಗಬಹುದು, ಆದರೆ ಫಲಿತಾಂಶವು `Ok` ಆಗಿದೆಯೆ ಅಥವಾ ಇಲ್ಲವೇ ಎಂಬುದನ್ನು ನೀವು ಹೆದರುವುದಿಲ್ಲ.
    ///
    ///
    /// [`Atomic*::compare_exchange`]: crate::sync::atomic::AtomicBool::compare_exchange
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_into_ok_or_err)]
    /// let ok: Result<u32, u32> = Ok(3);
    /// let err: Result<u32, u32> = Err(4);
    ///
    /// assert_eq!(ok.into_ok_or_err(), 3);
    /// assert_eq!(err.into_ok_or_err(), 4);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "result_into_ok_or_err", reason = "newly added", issue = "82223")]
    pub const fn into_ok_or_err(self) -> T {
        match self {
            Ok(v) => v,
            Err(v) => v,
        }
    }
}

// ವಿಧಾನಗಳ ಕೋಡ್ ಗಾತ್ರವನ್ನು ಕಡಿಮೆ ಮಾಡಲು ಇದು ಪ್ರತ್ಯೇಕ ಕಾರ್ಯವಾಗಿದೆ
#[inline(never)]
#[cold]
#[track_caller]
fn unwrap_failed(msg: &str, error: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, error)
}

/////////////////////////////////////////////////////////////////////////////
// Trait ಅನುಷ್ಠಾನಗಳು
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, E: Clone> Clone for Result<T, E> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Ok(x) => Ok(x.clone()),
            Err(x) => Err(x.clone()),
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Ok(to), Ok(from)) => to.clone_from(from),
            (Err(to), Err(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, E> IntoIterator for Result<T, E> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// ಬಹುಶಃ ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯದ ಮೇಲೆ ಸೇವಿಸುವ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಫಲಿತಾಂಶವು [`Result::Ok`] ಆಗಿದ್ದರೆ ಪುನರಾವರ್ತಕವು ಒಂದು ಮೌಲ್ಯವನ್ನು ನೀಡುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ ಯಾವುದೂ ಇಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(5);
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, [5]);
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, []);
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self.ok() }
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a Result<T, E> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a mut Result<T, E> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// ಫಲಿತಾಂಶ ಪುನರಾವರ್ತಕರು
/////////////////////////////////////////////////////////////////////////////

/// [`Result`] ನ [`Ok`] ರೂಪಾಂತರದ ಉಲ್ಲೇಖದ ಮೇಲೆ ಪುನರಾವರ್ತಕ.
///
/// ಫಲಿತಾಂಶವು [`Ok`] ಆಗಿದ್ದರೆ ಪುನರಾವರ್ತಕವು ಒಂದು ಮೌಲ್ಯವನ್ನು ನೀಡುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ ಯಾವುದೂ ಇಲ್ಲ.
///
/// [`Result::iter`] ನಿಂದ ರಚಿಸಲಾಗಿದೆ.
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    inner: Option<&'a T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner }
    }
}

/// [`Result`] ನ [`Ok`] ರೂಪಾಂತರಕ್ಕೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖದ ಮೇಲೆ ಪುನರಾವರ್ತಕ.
///
/// [`Result::iter_mut`] ನಿಂದ ರಚಿಸಲಾಗಿದೆ.
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    inner: Option<&'a mut T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// [`Result`] ನ [`Ok`] ರೂಪಾಂತರದಲ್ಲಿನ ಮೌಲ್ಯದ ಮೇಲೆ ಪುನರಾವರ್ತಕ.
///
/// ಫಲಿತಾಂಶವು [`Ok`] ಆಗಿದ್ದರೆ ಪುನರಾವರ್ತಕವು ಒಂದು ಮೌಲ್ಯವನ್ನು ನೀಡುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ ಯಾವುದೂ ಇಲ್ಲ.
///
/// ಈ ರಚನೆಯನ್ನು [`Result`] ನಲ್ಲಿ [`into_iter`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ ([`IntoIterator`] trait ನಿಂದ ಒದಗಿಸಲಾಗಿದೆ).
///
///
/// [`into_iter`]: IntoIterator::into_iter
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    inner: Option<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, E, V: FromIterator<A>> FromIterator<Result<A, E>> for Result<V, E> {
    /// `Iterator` ನಲ್ಲಿನ ಪ್ರತಿಯೊಂದು ಅಂಶವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ: ಇದು `Err` ಆಗಿದ್ದರೆ, ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳಲಾಗುವುದಿಲ್ಲ, ಮತ್ತು `Err` ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    /// ಯಾವುದೇ `Err` ಸಂಭವಿಸದಿದ್ದರೆ, ಪ್ರತಿ `Result` ನ ಮೌಲ್ಯಗಳನ್ನು ಹೊಂದಿರುವ ಧಾರಕವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// vector ನಲ್ಲಿನ ಪ್ರತಿ ಪೂರ್ಣಾಂಕವನ್ನು ಹೆಚ್ಚಿಸುವ ಉದಾಹರಣೆ ಇಲ್ಲಿದೆ, ಉಕ್ಕಿ ಹರಿಯುವುದನ್ನು ಪರಿಶೀಲಿಸುತ್ತದೆ:
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_add(1).ok_or("Overflow!")
    /// ).collect();
    /// assert_eq!(res, Ok(vec![2, 3]));
    /// ```
    ///
    /// ಪೂರ್ಣಾಂಕಗಳ ಮತ್ತೊಂದು ಪಟ್ಟಿಯಿಂದ ಒಂದನ್ನು ಕಳೆಯಲು ಪ್ರಯತ್ನಿಸುವ ಮತ್ತೊಂದು ಉದಾಹರಣೆ ಇಲ್ಲಿದೆ, ಈ ಸಮಯದಲ್ಲಿ ಒಳಹರಿವು ಪರಿಶೀಲಿಸಲಾಗುತ್ತಿದೆ:
    ///
    /// ```
    /// let v = vec![1, 2, 0];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_sub(1).ok_or("Underflow!")
    /// ).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// ```
    ///
    /// ಹಿಂದಿನ ಉದಾಹರಣೆಯ ಮೇಲಿನ ವ್ಯತ್ಯಾಸ ಇಲ್ಲಿದೆ, ಮೊದಲ `Err` ನಂತರ `iter` ನಿಂದ ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳಲಾಗುವುದಿಲ್ಲ ಎಂದು ತೋರಿಸುತ್ತದೆ.
    ///
    /// ```
    /// let v = vec![3, 2, 1, 10];
    /// let mut shared = 0;
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32| {
    ///     shared += x;
    ///     x.checked_sub(2).ok_or("Underflow!")
    /// }).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// ಮೂರನೆಯ ಅಂಶವು ಒಳಹರಿವು ಉಂಟುಮಾಡಿದ ಕಾರಣ, ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳಲಾಗಿಲ್ಲ, ಆದ್ದರಿಂದ `shared` ನ ಅಂತಿಮ ಮೌಲ್ಯವು 6 (= `3 + 2 + 1`), 16 ಅಲ್ಲ.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Result<A, E>>>(iter: I) -> Result<V, E> {
        // FIXME(#11084): ಈ ಕಾರ್ಯಕ್ಷಮತೆಯ ದೋಷವನ್ನು ಮುಚ್ಚಿದಾಗ ಇದನ್ನು Iterator::scan ನೊಂದಿಗೆ ಬದಲಾಯಿಸಬಹುದು.
        //

        iter::process_results(iter.into_iter(), |i| i.collect())
    }
}

#[unstable(feature = "try_trait", issue = "42327")]
impl<T, E> ops::Try for Result<T, E> {
    type Ok = T;
    type Error = E;

    #[inline]
    fn into_result(self) -> Self {
        self
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Ok(v)
    }

    #[inline]
    fn from_error(v: E) -> Self {
        Err(v)
    }
}