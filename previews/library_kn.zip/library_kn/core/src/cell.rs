//! ಹಂಚಿಕೊಳ್ಳಬಹುದಾದ ರೂಪಾಂತರಿತ ಪಾತ್ರೆಗಳು.
//!
//! Rust ಮೆಮೊರಿ ಸುರಕ್ಷತೆಯು ಈ ನಿಯಮವನ್ನು ಆಧರಿಸಿದೆ: `T` ಆಬ್ಜೆಕ್ಟ್ ಅನ್ನು ನೀಡಿದರೆ, ಈ ಕೆಳಗಿನವುಗಳಲ್ಲಿ ಒಂದನ್ನು ಹೊಂದಲು ಮಾತ್ರ ಸಾಧ್ಯ:
//!
//! - ವಸ್ತುವಿಗೆ ಹಲವಾರು ಬದಲಾಗದ ಉಲ್ಲೇಖಗಳು (`&T`) (ಇದನ್ನು **ಅಲಿಯಾಸಿಂಗ್** ಎಂದೂ ಕರೆಯುತ್ತಾರೆ).
//! - ವಸ್ತುವಿಗೆ ಒಂದು ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು (`&ಮಟ್ ಟಿ`) ಹೊಂದಿರುವುದು (ಇದನ್ನು **ಮ್ಯುಟಬಿಲಿಟಿ** ಎಂದೂ ಕರೆಯುತ್ತಾರೆ).
//!
//! ಇದನ್ನು Rust ಕಂಪೈಲರ್ ಜಾರಿಗೊಳಿಸಿದೆ.ಆದಾಗ್ಯೂ, ಈ ನಿಯಮವು ಸಾಕಷ್ಟು ಹೊಂದಿಕೊಳ್ಳದ ಸಂದರ್ಭಗಳಿವೆ.ಕೆಲವೊಮ್ಮೆ ವಸ್ತುವಿಗೆ ಅನೇಕ ಉಲ್ಲೇಖಗಳನ್ನು ಹೊಂದಲು ಮತ್ತು ಅದನ್ನು ರೂಪಾಂತರಿಸಲು ಇದು ಅಗತ್ಯವಾಗಿರುತ್ತದೆ.
//!
//! ಅಲಿಯಾಸಿಂಗ್ ಉಪಸ್ಥಿತಿಯಲ್ಲಿ ಸಹ, ನಿಯಂತ್ರಿತ ರೀತಿಯಲ್ಲಿ ರೂಪಾಂತರವನ್ನು ಅನುಮತಿಸಲು ಹಂಚಿಕೊಳ್ಳಬಹುದಾದ ರೂಪಾಂತರಿತ ಪಾತ್ರೆಗಳು ಅಸ್ತಿತ್ವದಲ್ಲಿವೆ.[`Cell<T>`] ಮತ್ತು [`RefCell<T>`] ಎರಡೂ ಇದನ್ನು ಒಂದೇ-ಥ್ರೆಡ್ ರೀತಿಯಲ್ಲಿ ಮಾಡಲು ಅನುಮತಿಸುತ್ತದೆ.
//! ಆದಾಗ್ಯೂ, `Cell<T>` ಅಥವಾ `RefCell<T>` ಎರಡೂ ಥ್ರೆಡ್ ಸುರಕ್ಷಿತವಲ್ಲ (ಅವು [`Sync`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದಿಲ್ಲ).
//! ನೀವು ಅನೇಕ ಎಳೆಗಳ ನಡುವೆ ಅಲಿಯಾಸಿಂಗ್ ಮತ್ತು ರೂಪಾಂತರವನ್ನು ಮಾಡಬೇಕಾದರೆ [`Mutex<T>`], [`RwLock<T>`] ಅಥವಾ [`atomic`] ಪ್ರಕಾರಗಳನ್ನು ಬಳಸಲು ಸಾಧ್ಯವಿದೆ.
//!
//! `Cell<T>` ಮತ್ತು `RefCell<T>` ಪ್ರಕಾರಗಳ ಮೌಲ್ಯಗಳನ್ನು ಹಂಚಿದ ಉಲ್ಲೇಖಗಳ ಮೂಲಕ ಪರಿವರ್ತಿಸಬಹುದು (ಅಂದರೆ
//! ಸಾಮಾನ್ಯ `&T` ಪ್ರಕಾರ), ಆದರೆ ಹೆಚ್ಚಿನ Rust ಪ್ರಕಾರಗಳನ್ನು ಅನನ್ಯ (`&ಮಟ್ ಟಿ`) ಉಲ್ಲೇಖಗಳ ಮೂಲಕ ಮಾತ್ರ ಪರಿವರ್ತಿಸಬಹುದು.
//! 'ಆನುವಂಶಿಕ ರೂಪಾಂತರವನ್ನು' ಪ್ರದರ್ಶಿಸುವ ವಿಶಿಷ್ಟವಾದ Rust ಪ್ರಕಾರಗಳಿಗೆ ವ್ಯತಿರಿಕ್ತವಾಗಿ, `Cell<T>` ಮತ್ತು `RefCell<T>` 'ಆಂತರಿಕ ರೂಪಾಂತರ'ವನ್ನು ಒದಗಿಸುತ್ತದೆ ಎಂದು ನಾವು ಹೇಳುತ್ತೇವೆ.
//!
//! ಸೆಲ್ ಪ್ರಕಾರಗಳು ಎರಡು ರುಚಿಗಳಲ್ಲಿ ಬರುತ್ತವೆ: `Cell<T>` ಮತ್ತು `RefCell<T>`.`Cell<T>` `Cell<T>` ಒಳಗೆ ಮತ್ತು ಹೊರಗೆ ಮೌಲ್ಯಗಳನ್ನು ಚಲಿಸುವ ಮೂಲಕ ಆಂತರಿಕ ರೂಪಾಂತರವನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
//! ಮೌಲ್ಯಗಳಿಗೆ ಬದಲಾಗಿ ಉಲ್ಲೇಖಗಳನ್ನು ಬಳಸಲು, ಒಬ್ಬರು `RefCell<T>` ಪ್ರಕಾರವನ್ನು ಬಳಸಬೇಕು, ರೂಪಾಂತರಗೊಳ್ಳುವ ಮೊದಲು ರೈಟ್ ಲಾಕ್ ಅನ್ನು ಪಡೆದುಕೊಳ್ಳಬೇಕು.ಪ್ರಸ್ತುತ ಆಂತರಿಕ ಮೌಲ್ಯವನ್ನು ಹಿಂಪಡೆಯಲು ಮತ್ತು ಬದಲಾಯಿಸಲು `Cell<T>` ವಿಧಾನಗಳನ್ನು ಒದಗಿಸುತ್ತದೆ:
//!
//!  - [`Copy`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಪ್ರಕಾರಗಳಿಗಾಗಿ, [`get`](Cell::get) ವಿಧಾನವು ಪ್ರಸ್ತುತ ಆಂತರಿಕ ಮೌಲ್ಯವನ್ನು ಹಿಂಪಡೆಯುತ್ತದೆ.
//!  - [`Default`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಪ್ರಕಾರಗಳಿಗಾಗಿ, [`take`](Cell::take) ವಿಧಾನವು ಪ್ರಸ್ತುತ ಆಂತರಿಕ ಮೌಲ್ಯವನ್ನು [`Default::default()`] ನೊಂದಿಗೆ ಬದಲಾಯಿಸುತ್ತದೆ ಮತ್ತು ಬದಲಾದ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
//!  - ಎಲ್ಲಾ ಪ್ರಕಾರಗಳಿಗೆ, [`replace`](Cell::replace) ವಿಧಾನವು ಪ್ರಸ್ತುತ ಆಂತರಿಕ ಮೌಲ್ಯವನ್ನು ಬದಲಾಯಿಸುತ್ತದೆ ಮತ್ತು ಬದಲಾದ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ ಮತ್ತು [`into_inner`](Cell::into_inner) ವಿಧಾನವು `Cell<T>` ಅನ್ನು ಬಳಸುತ್ತದೆ ಮತ್ತು ಆಂತರಿಕ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
//!  ಹೆಚ್ಚುವರಿಯಾಗಿ, [`set`](Cell::set) ವಿಧಾನವು ಆಂತರಿಕ ಮೌಲ್ಯವನ್ನು ಬದಲಾಯಿಸುತ್ತದೆ, ಬದಲಾದ ಮೌಲ್ಯವನ್ನು ಬಿಡುತ್ತದೆ.
//!
//! `RefCell<T>` 'ಡೈನಾಮಿಕ್ ಎರವಲು' ಕಾರ್ಯಗತಗೊಳಿಸಲು Rust ನ ಜೀವಿತಾವಧಿಯನ್ನು ಬಳಸುತ್ತದೆ, ಈ ಪ್ರಕ್ರಿಯೆಯು ಆಂತರಿಕ ಮೌಲ್ಯಕ್ಕೆ ತಾತ್ಕಾಲಿಕ, ವಿಶೇಷ, ರೂಪಾಂತರಿತ ಪ್ರವೇಶವನ್ನು ಪಡೆಯಬಹುದು.
//! `ರೆಫ್‌ಸೆಲ್‌ಗಾಗಿ ಸಾಲಗಳು<T>Rust ನ ಸ್ಥಳೀಯ ಉಲ್ಲೇಖ ಪ್ರಕಾರಗಳಿಗಿಂತ ಭಿನ್ನವಾಗಿ, ರನ್‌ಟೈಮ್‌ನಲ್ಲಿ`s ಅನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಲಾಗುತ್ತದೆ, ಇವುಗಳನ್ನು ಕಂಪೈಲ್ ಸಮಯದಲ್ಲಿ ಸಂಪೂರ್ಣವಾಗಿ ಸ್ಥಿರವಾಗಿ ಟ್ರ್ಯಾಕ್ ಮಾಡಲಾಗುತ್ತದೆ.
//! `RefCell<T>` ಸಾಲಗಳು ಕ್ರಿಯಾತ್ಮಕವಾಗಿರುವುದರಿಂದ ಈಗಾಗಲೇ ಪರಸ್ಪರ ಸಾಲ ಪಡೆದ ಮೌಲ್ಯವನ್ನು ಎರವಲು ಪಡೆಯಲು ಪ್ರಯತ್ನಿಸಬಹುದು;ಇದು ಸಂಭವಿಸಿದಾಗ ಅದು ಥ್ರೆಡ್ panic ಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
//!
//! # ಆಂತರಿಕ ರೂಪಾಂತರವನ್ನು ಯಾವಾಗ ಆರಿಸಬೇಕು
//!
//! ಮೌಲ್ಯವನ್ನು ಪರಿವರ್ತಿಸಲು ಅನನ್ಯ ಪ್ರವೇಶವನ್ನು ಹೊಂದಿರಬೇಕಾದ ಹೆಚ್ಚು ಸಾಮಾನ್ಯವಾದ ಆನುವಂಶಿಕ ರೂಪಾಂತರವು ಪಾಯಿಂಟರ್ ಅಲಿಯಾಸಿಂಗ್ ಬಗ್ಗೆ ಬಲವಾಗಿ ವಿವರಿಸಲು Rust ಅನ್ನು ಶಕ್ತಗೊಳಿಸುವ ಪ್ರಮುಖ ಭಾಷಾ ಅಂಶಗಳಲ್ಲಿ ಒಂದಾಗಿದೆ, ಸ್ಥಿರವಾಗಿ ಕ್ರ್ಯಾಶ್ ದೋಷಗಳನ್ನು ತಡೆಯುತ್ತದೆ.
//! ಆ ಕಾರಣದಿಂದಾಗಿ, ಆನುವಂಶಿಕವಾಗಿ ರೂಪಾಂತರವನ್ನು ಆದ್ಯತೆ ನೀಡಲಾಗುತ್ತದೆ, ಮತ್ತು ಆಂತರಿಕ ರೂಪಾಂತರವು ಕೊನೆಯ ಉಪಾಯವಾಗಿದೆ.
//! ಕೋಶ ಪ್ರಕಾರಗಳು ರೂಪಾಂತರವನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುವುದರಿಂದ ಅದನ್ನು ಅನುಮತಿಸಲಾಗುವುದಿಲ್ಲ, ಆಂತರಿಕ ರೂಪಾಂತರವು ಸೂಕ್ತವಾಗಬಹುದು, ಅಥವಾ *ಸಹ* ಬಳಸಬೇಕು, ಉದಾ.
//!
//! * ಬದಲಾಗದ ಯಾವುದನ್ನಾದರೂ ರೂಪಾಂತರಿತ 'inside' ಪರಿಚಯಿಸುತ್ತಿದೆ
//! * ತಾರ್ಕಿಕವಾಗಿ-ಬದಲಾಯಿಸಲಾಗದ ವಿಧಾನಗಳ ಅನುಷ್ಠಾನದ ವಿವರಗಳು.
//! * [`Clone`] ನ ರೂಪಾಂತರ ಅನುಷ್ಠಾನಗಳು.
//!
//! ## ಬದಲಾಗದ ಯಾವುದನ್ನಾದರೂ ರೂಪಾಂತರಿತ 'inside' ಪರಿಚಯಿಸುತ್ತಿದೆ
//!
//! [`Rc<T>`] ಮತ್ತು [`Arc<T>`] ಸೇರಿದಂತೆ ಅನೇಕ ಹಂಚಿಕೆಯ ಸ್ಮಾರ್ಟ್ ಪಾಯಿಂಟರ್ ಪ್ರಕಾರಗಳು, ಅನೇಕ ಪಕ್ಷಗಳ ನಡುವೆ ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮತ್ತು ಹಂಚಿಕೊಳ್ಳಬಹುದಾದ ಪಾತ್ರೆಗಳನ್ನು ಒದಗಿಸುತ್ತವೆ.
//! ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯಗಳು ಗುಣಾಕಾರ-ಅಲಿಯಾಸ್ ಆಗಿರಬಹುದು, ಅವುಗಳನ್ನು `&` ನೊಂದಿಗೆ ಮಾತ್ರ ಎರವಲು ಪಡೆಯಬಹುದು, ಆದರೆ `&mut` ಅಲ್ಲ.
//! ಕೋಶಗಳಿಲ್ಲದೆ ಈ ಸ್ಮಾರ್ಟ್ ಪಾಯಿಂಟರ್‌ಗಳ ಒಳಗೆ ಡೇಟಾವನ್ನು ರೂಪಾಂತರಿಸುವುದು ಅಸಾಧ್ಯ.
//!
//! ರೂಪಾಂತರವನ್ನು ಪುನಃ ಪರಿಚಯಿಸಲು ಹಂಚಿದ ಪಾಯಿಂಟರ್ ಪ್ರಕಾರಗಳಲ್ಲಿ `RefCell<T>` ಅನ್ನು ಹಾಕುವುದು ತುಂಬಾ ಸಾಮಾನ್ಯವಾಗಿದೆ:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // ಕ್ರಿಯಾತ್ಮಕ ಸಾಲದ ವ್ಯಾಪ್ತಿಯನ್ನು ಮಿತಿಗೊಳಿಸಲು ಹೊಸ ಬ್ಲಾಕ್ ಅನ್ನು ರಚಿಸಿ
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // ಸಂಗ್ರಹದ ಹಿಂದಿನ ಸಾಲವನ್ನು ನಾವು ವ್ಯಾಪ್ತಿಯಿಂದ ಹೊರಹಾಕಲು ಬಿಡದಿದ್ದರೆ, ನಂತರದ ಸಾಲವು ಡೈನಾಮಿಕ್ ಥ್ರೆಡ್ panic ಗೆ ಕಾರಣವಾಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
//!     //
//!     // ಇದು `RefCell` ಬಳಸುವ ಪ್ರಮುಖ ಅಪಾಯವಾಗಿದೆ.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! ಈ ಉದಾಹರಣೆಯು `Rc<T>` ಅನ್ನು ಬಳಸುತ್ತದೆ ಮತ್ತು `Arc<T>` ಅಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.`ರೆಫ್ಸೆಲ್<T>`ಗಳು ಏಕ-ಥ್ರೆಡ್ ಸನ್ನಿವೇಶಗಳಿಗಾಗಿ.ಬಹು-ಥ್ರೆಡ್ ಪರಿಸ್ಥಿತಿಯಲ್ಲಿ ನಿಮಗೆ ಹಂಚಿಕೆಯ ರೂಪಾಂತರದ ಅಗತ್ಯವಿದ್ದರೆ [`RwLock<T>`] ಅಥವಾ [`Mutex<T>`] ಅನ್ನು ಪರಿಗಣಿಸಿ.
//!
//! ## ತಾರ್ಕಿಕವಾಗಿ-ಬದಲಾಗದ ವಿಧಾನಗಳ ಅನುಷ್ಠಾನದ ವಿವರಗಳು
//!
//! ಸಾಂದರ್ಭಿಕವಾಗಿ "under the hood" ನಲ್ಲಿ ರೂಪಾಂತರ ಸಂಭವಿಸುತ್ತಿದೆ ಎಂದು API ಯಲ್ಲಿ ಬಹಿರಂಗಪಡಿಸದಿರುವುದು ಅಪೇಕ್ಷಣೀಯವಾಗಿದೆ.
//! ತಾರ್ಕಿಕವಾಗಿ ಕಾರ್ಯಾಚರಣೆಯು ಬದಲಾಗದ ಕಾರಣ ಇದು ಇರಬಹುದು, ಆದರೆ ಉದಾ., ಹಿಡಿದಿಟ್ಟುಕೊಳ್ಳುವಿಕೆಯು ರೂಪಾಂತರವನ್ನು ನಿರ್ವಹಿಸಲು ಅನುಷ್ಠಾನವನ್ನು ಒತ್ತಾಯಿಸುತ್ತದೆ;ಅಥವಾ `&self` ತೆಗೆದುಕೊಳ್ಳಲು ಮೂಲತಃ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ trait ವಿಧಾನವನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ನೀವು ರೂಪಾಂತರವನ್ನು ಬಳಸಿಕೊಳ್ಳಬೇಕು.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // ದುಬಾರಿ ಗಣನೆ ಇಲ್ಲಿಗೆ ಹೋಗುತ್ತದೆ
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## `Clone` ನ ರೂಪಾಂತರ ಅನುಷ್ಠಾನಗಳು
//!
//! ಇದು ಹಿಂದಿನ ಒಂದು ವಿಶೇಷವಾದ, ಆದರೆ ಸಾಮಾನ್ಯವಾದ ಪ್ರಕರಣವಾಗಿದೆ: ಬದಲಾಗದಂತೆ ಕಂಡುಬರುವ ಕಾರ್ಯಾಚರಣೆಗಳಿಗೆ ರೂಪಾಂತರವನ್ನು ಮರೆಮಾಡುವುದು.
//! [`clone`](Clone::clone) ವಿಧಾನವು ಮೂಲ ಮೌಲ್ಯವನ್ನು ಬದಲಾಯಿಸುವುದಿಲ್ಲ ಎಂದು ನಿರೀಕ್ಷಿಸಲಾಗಿದೆ, ಮತ್ತು `&mut self` ಅಲ್ಲ, `&self` ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ ಎಂದು ಘೋಷಿಸಲಾಗಿದೆ.
//! ಆದ್ದರಿಂದ, `clone` ವಿಧಾನದಲ್ಲಿ ಸಂಭವಿಸುವ ಯಾವುದೇ ರೂಪಾಂತರವು ಕೋಶ ಪ್ರಕಾರಗಳನ್ನು ಬಳಸಬೇಕು.
//! ಉದಾಹರಣೆಗೆ, [`Rc<T>`] ತನ್ನ ಉಲ್ಲೇಖ ಎಣಿಕೆಗಳನ್ನು `Cell<T>` ಒಳಗೆ ನಿರ್ವಹಿಸುತ್ತದೆ.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// ರೂಪಾಂತರಿತ ಮೆಮೊರಿ ಸ್ಥಳ.
///
/// # Examples
///
/// ಈ ಉದಾಹರಣೆಯಲ್ಲಿ, `Cell<T>` ಬದಲಾಗದ ರಚನೆಯೊಳಗೆ ರೂಪಾಂತರವನ್ನು ಶಕ್ತಗೊಳಿಸುತ್ತದೆ ಎಂದು ನೀವು ನೋಡಬಹುದು.
/// ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, ಇದು "interior mutability" ಅನ್ನು ಶಕ್ತಗೊಳಿಸುತ್ತದೆ.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ದೋಷ: `my_struct` ಬದಲಾಗದು
/// // my_struct.regular_field =ಹೊಸ_ಮೌಲ್ಯ;
///
/// // ಕೆಲಸಗಳು: `my_struct` ಬದಲಾಗದಿದ್ದರೂ, `special_field` ಒಂದು `Cell`,
/// // ಇದನ್ನು ಯಾವಾಗಲೂ ರೂಪಾಂತರಿಸಬಹುದು
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ [module-level documentation](self) ನೋಡಿ.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// T ಗಾಗಿ `Default` ಮೌಲ್ಯದೊಂದಿಗೆ `Cell<T>` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// ಕೊಟ್ಟಿರುವ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿರುವ ಹೊಸ `Cell` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// ಎರಡು ಕೋಶಗಳ ಮೌಲ್ಯಗಳನ್ನು ಬದಲಾಯಿಸುತ್ತದೆ.
    /// `std::mem::swap` ನೊಂದಿಗಿನ ವ್ಯತ್ಯಾಸವೆಂದರೆ ಈ ಕಾರ್ಯಕ್ಕೆ `&mut` ಉಲ್ಲೇಖ ಅಗತ್ಯವಿಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // ಸುರಕ್ಷತೆ: ಪ್ರತ್ಯೇಕ ಎಳೆಗಳಿಂದ ಕರೆದರೆ ಇದು ಅಪಾಯಕಾರಿ, ಆದರೆ `Cell`
        // `!Sync` ಆದ್ದರಿಂದ ಇದು ಸಂಭವಿಸುವುದಿಲ್ಲ.
        // ಇದು ಯಾವುದೇ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಅಮಾನ್ಯಗೊಳಿಸುವುದಿಲ್ಲ ಏಕೆಂದರೆ `Cell` ಈ `ಸೆಲ್‌'ಗಳಲ್ಲಿ ಯಾವುದಕ್ಕೂ ಸೂಚಿಸುವುದಿಲ್ಲ ಎಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯವನ್ನು `val` ನೊಂದಿಗೆ ಬದಲಾಯಿಸುತ್ತದೆ ಮತ್ತು ಹಳೆಯ ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // ಸುರಕ್ಷತೆ: ಪ್ರತ್ಯೇಕ ಥ್ರೆಡ್‌ನಿಂದ ಕರೆ ಮಾಡಿದರೆ ಇದು ಡೇಟಾ ರೇಸ್‌ಗಳಿಗೆ ಕಾರಣವಾಗಬಹುದು,
        // ಆದರೆ `Cell` `!Sync` ಆದ್ದರಿಂದ ಇದು ಸಂಭವಿಸುವುದಿಲ್ಲ.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// ಮೌಲ್ಯವನ್ನು ಬಿಚ್ಚಿಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯದ ನಕಲನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // ಸುರಕ್ಷತೆ: ಪ್ರತ್ಯೇಕ ಥ್ರೆಡ್‌ನಿಂದ ಕರೆ ಮಾಡಿದರೆ ಇದು ಡೇಟಾ ರೇಸ್‌ಗಳಿಗೆ ಕಾರಣವಾಗಬಹುದು,
        // ಆದರೆ `Cell` `!Sync` ಆದ್ದರಿಂದ ಇದು ಸಂಭವಿಸುವುದಿಲ್ಲ.
        unsafe { *self.value.get() }
    }

    /// ಕಾರ್ಯವನ್ನು ಬಳಸಿಕೊಂಡು ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯವನ್ನು ನವೀಕರಿಸುತ್ತದೆ ಮತ್ತು ಹೊಸ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// ಈ ಕೋಶದಲ್ಲಿನ ಆಧಾರವಾಗಿರುವ ಡೇಟಾಗೆ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// ಆಧಾರವಾಗಿರುವ ಡೇಟಾಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಕರೆ `Cell` ಅನ್ನು ಪರಸ್ಪರ ಎರವಲು ಪಡೆಯುತ್ತದೆ (ಕಂಪೈಲ್ ಸಮಯದಲ್ಲಿ) ಇದು ನಾವು ಒಂದೇ ಉಲ್ಲೇಖವನ್ನು ಹೊಂದಿದ್ದೇವೆ ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `&mut T` ನಿಂದ `&Cell<T>` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // ಸುರಕ್ಷತೆ: `&mut` ಅನನ್ಯ ಪ್ರವೇಶವನ್ನು ಖಾತ್ರಿಗೊಳಿಸುತ್ತದೆ.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// ಕೋಶದ ಮೌಲ್ಯವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ, `Default::default()` ಅನ್ನು ಅದರ ಸ್ಥಳದಲ್ಲಿ ಬಿಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// `&Cell<[T]>` ನಿಂದ `&[Cell<T>]` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // ಸುರಕ್ಷತೆ: `Cell<T>` `T` ನಂತೆಯೇ ಮೆಮೊರಿ ವಿನ್ಯಾಸವನ್ನು ಹೊಂದಿದೆ.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// ಕ್ರಿಯಾತ್ಮಕವಾಗಿ ಪರಿಶೀಲಿಸಿದ ಸಾಲ ನಿಯಮಗಳೊಂದಿಗೆ ರೂಪಾಂತರಿತ ಮೆಮೊರಿ ಸ್ಥಳ
///
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ [module-level documentation](self) ನೋಡಿ.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`] ನಿಂದ ಹಿಂತಿರುಗಿದ ದೋಷ.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`] ನಿಂದ ಹಿಂತಿರುಗಿದ ದೋಷ.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// ಸಕಾರಾತ್ಮಕ ಮೌಲ್ಯಗಳು `Ref` ಸಕ್ರಿಯ ಸಂಖ್ಯೆಯನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತವೆ.Values ಣಾತ್ಮಕ ಮೌಲ್ಯಗಳು `RefMut` ಸಕ್ರಿಯ ಸಂಖ್ಯೆಯನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತವೆ.
// `RefCell` (ಉದಾ., ಸ್ಲೈಸ್‌ನ ವಿಭಿನ್ನ ಶ್ರೇಣಿಗಳು) ನ ವಿಭಿನ್ನ, ನಾನ್‌ಓವರ್‌ಲ್ಯಾಪಿಂಗ್ ಘಟಕಗಳನ್ನು ಉಲ್ಲೇಖಿಸಿದರೆ ಮಾತ್ರ ಅನೇಕ `ರೆಫ್‌ಮಟ್'ಗಳು ಒಂದು ಸಮಯದಲ್ಲಿ ಸಕ್ರಿಯವಾಗಿರುತ್ತವೆ.
//
// `Ref` ಮತ್ತು `RefMut` ಎರಡೂ ಗಾತ್ರದಲ್ಲಿ ಎರಡು ಪದಗಳಾಗಿವೆ, ಆದ್ದರಿಂದ `usize` ಶ್ರೇಣಿಯ ಅರ್ಧದಷ್ಟು ಉಕ್ಕಿ ಹರಿಯಲು ಸಾಕಷ್ಟು `Ref` ಗಳು ಅಥವಾ`RefMut` ಗಳು ಅಸ್ತಿತ್ವದಲ್ಲಿಲ್ಲ.
// ಹೀಗಾಗಿ, `BorrowFlag` ಬಹುಶಃ ಎಂದಿಗೂ ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ ಅಥವಾ ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ.
// ಆದಾಗ್ಯೂ, ಇದು ಖಾತರಿಯಲ್ಲ, ಏಕೆಂದರೆ ರೋಗಶಾಸ್ತ್ರೀಯ ಪ್ರೋಗ್ರಾಂ ಪದೇ ಪದೇ ರಚಿಸಬಹುದು ಮತ್ತು ನಂತರ mem::forget `Ref`s ಅಥವಾ`RefMut`s.
// ಆದ್ದರಿಂದ, ಎಲ್ಲಾ ಕೋಡ್ ಅಸುರಕ್ಷಿತತೆಯನ್ನು ತಪ್ಪಿಸಲು ಓವರ್‌ಫ್ಲೋ ಮತ್ತು ಒಳಹರಿವುಗಾಗಿ ಸ್ಪಷ್ಟವಾಗಿ ಪರಿಶೀಲಿಸಬೇಕು, ಅಥವಾ ಉಕ್ಕಿ ಹರಿಯುವ ಅಥವಾ ಒಳಹರಿವು ಸಂಭವಿಸಿದಲ್ಲಿ ಕನಿಷ್ಠ ಸರಿಯಾಗಿ ವರ್ತಿಸಬೇಕು (ಉದಾ., BorrowRef::new ನೋಡಿ).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// `value` ಹೊಂದಿರುವ ಹೊಸ `RefCell` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// `RefCell` ಅನ್ನು ಬಳಸುತ್ತದೆ, ಸುತ್ತಿದ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // ಈ ಕಾರ್ಯವು `self` (`RefCell`) ಅನ್ನು ಮೌಲ್ಯದಿಂದ ತೆಗೆದುಕೊಳ್ಳುವುದರಿಂದ, ಕಂಪೈಲರ್ ಅದನ್ನು ಪ್ರಸ್ತುತ ಎರವಲು ಪಡೆದಿಲ್ಲ ಎಂದು ಸ್ಥಿರವಾಗಿ ಪರಿಶೀಲಿಸುತ್ತದೆ.
        //
        self.value.into_inner()
    }

    /// ಸುತ್ತಿದ ಮೌಲ್ಯವನ್ನು ಹೊಸದರೊಂದಿಗೆ ಬದಲಾಯಿಸುತ್ತದೆ, ಹಳೆಯ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// ಈ ಕಾರ್ಯವು [`std::mem::replace`](../mem/fn.replace.html) ಗೆ ಅನುರೂಪವಾಗಿದೆ.
    ///
    /// # Panics
    ///
    /// ಮೌಲ್ಯವನ್ನು ಪ್ರಸ್ತುತ ಎರವಲು ಪಡೆದಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// ಸುತ್ತಿದ ಮೌಲ್ಯವನ್ನು `f` ನಿಂದ ಲೆಕ್ಕಹಾಕಿದ ಹೊಸದರೊಂದಿಗೆ ಬದಲಾಯಿಸುತ್ತದೆ, ಹಳೆಯ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Panics
    ///
    /// ಮೌಲ್ಯವನ್ನು ಪ್ರಸ್ತುತ ಎರವಲು ಪಡೆದಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// `self` ನ ಸುತ್ತಿದ ಮೌಲ್ಯವನ್ನು `other` ನ ಸುತ್ತಿದ ಮೌಲ್ಯದೊಂದಿಗೆ ವಿನಿಮಯ ಮಾಡಿಕೊಳ್ಳಿ.
    ///
    ///
    /// ಈ ಕಾರ್ಯವು [`std::mem::swap`](../mem/fn.swap.html) ಗೆ ಅನುರೂಪವಾಗಿದೆ.
    ///
    /// # Panics
    ///
    /// `RefCell` ನಲ್ಲಿನ ಮೌಲ್ಯವನ್ನು ಪ್ರಸ್ತುತ ಎರವಲು ಪಡೆದಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// ಸುತ್ತಿದ ಮೌಲ್ಯವನ್ನು ಅಸ್ಥಿರವಾಗಿ ಎರವಲು ಪಡೆಯುತ್ತದೆ.
    ///
    /// ಹಿಂದಿರುಗಿದ `Ref` ವ್ಯಾಪ್ತಿಯಿಂದ ನಿರ್ಗಮಿಸುವವರೆಗೆ ಸಾಲವು ಇರುತ್ತದೆ.
    /// ಅನೇಕ ಬದಲಾಗದ ಸಾಲಗಳನ್ನು ಒಂದೇ ಸಮಯದಲ್ಲಿ ತೆಗೆದುಕೊಳ್ಳಬಹುದು.
    ///
    /// # Panics
    ///
    /// ಮೌಲ್ಯವನ್ನು ಪ್ರಸ್ತುತ ರೂಪಾಂತರಿತವಾಗಿ ಎರವಲು ಪಡೆದಿದ್ದರೆ Panics.
    /// ಭಯಪಡದ ರೂಪಾಂತರಕ್ಕಾಗಿ, [`try_borrow`](#method.try_borrow) ಬಳಸಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// panic ನ ಉದಾಹರಣೆ:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// ಸುತ್ತಿದ ಮೌಲ್ಯವನ್ನು ಅಸ್ಥಿರವಾಗಿ ಎರವಲು ಪಡೆಯುತ್ತದೆ, ಪ್ರಸ್ತುತ ಮೌಲ್ಯವನ್ನು ಪರಸ್ಪರ ಸಾಲವಾಗಿ ಪಡೆದರೆ ದೋಷವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// ಹಿಂದಿರುಗಿದ `Ref` ವ್ಯಾಪ್ತಿಯಿಂದ ನಿರ್ಗಮಿಸುವವರೆಗೆ ಸಾಲವು ಇರುತ್ತದೆ.
    /// ಅನೇಕ ಬದಲಾಗದ ಸಾಲಗಳನ್ನು ಒಂದೇ ಸಮಯದಲ್ಲಿ ತೆಗೆದುಕೊಳ್ಳಬಹುದು.
    ///
    /// ಇದು [`borrow`](#method.borrow) ನ ಪ್ಯಾನಿಕ್-ಅಲ್ಲದ ರೂಪಾಂತರವಾಗಿದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // ಸುರಕ್ಷತೆ: ಕೇವಲ ಬದಲಾಯಿಸಲಾಗದ ಪ್ರವೇಶವಿದೆ ಎಂದು `BorrowRef` ಖಾತ್ರಿಗೊಳಿಸುತ್ತದೆ
            // ಎರವಲು ಪಡೆದಾಗ ಮೌಲ್ಯಕ್ಕೆ.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// ಸುತ್ತಿದ ಮೌಲ್ಯವನ್ನು ಪರಸ್ಪರ ಎರವಲು ಪಡೆಯುತ್ತದೆ.
    ///
    /// ಹಿಂತಿರುಗಿದ `RefMut` ಅಥವಾ ಅದರಿಂದ ಪಡೆದ ಎಲ್ಲಾ `RefMut` ಗಳು ನಿರ್ಗಮನ ವ್ಯಾಪ್ತಿಯವರೆಗೆ ಸಾಲವು ಇರುತ್ತದೆ.
    ///
    /// ಈ ಸಾಲವು ಸಕ್ರಿಯವಾಗಿದ್ದಾಗ ಮೌಲ್ಯವನ್ನು ಎರವಲು ಪಡೆಯಲಾಗುವುದಿಲ್ಲ.
    ///
    /// # Panics
    ///
    /// ಮೌಲ್ಯವನ್ನು ಪ್ರಸ್ತುತ ಎರವಲು ಪಡೆದಿದ್ದರೆ Panics.
    /// ಭಯಪಡದ ರೂಪಾಂತರಕ್ಕಾಗಿ, [`try_borrow_mut`](#method.try_borrow_mut) ಬಳಸಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// panic ನ ಉದಾಹರಣೆ:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// ಸುತ್ತಿದ ಮೌಲ್ಯವನ್ನು ಪರಸ್ಪರ ಎರವಲು ಪಡೆಯುತ್ತದೆ, ಪ್ರಸ್ತುತ ಮೌಲ್ಯವನ್ನು ಎರವಲು ಪಡೆದಿದ್ದರೆ ದೋಷವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// ಹಿಂತಿರುಗಿದ `RefMut` ಅಥವಾ ಅದರಿಂದ ಪಡೆದ ಎಲ್ಲಾ `RefMut` ಗಳು ನಿರ್ಗಮನ ವ್ಯಾಪ್ತಿಯವರೆಗೆ ಸಾಲವು ಇರುತ್ತದೆ.
    /// ಈ ಸಾಲವು ಸಕ್ರಿಯವಾಗಿದ್ದಾಗ ಮೌಲ್ಯವನ್ನು ಎರವಲು ಪಡೆಯಲಾಗುವುದಿಲ್ಲ.
    ///
    /// ಇದು [`borrow_mut`](#method.borrow_mut) ನ ಪ್ಯಾನಿಕ್-ಅಲ್ಲದ ರೂಪಾಂತರವಾಗಿದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // ಸುರಕ್ಷತೆ: `BorrowRef` ಅನನ್ಯ ಪ್ರವೇಶವನ್ನು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// ಈ ಕೋಶದಲ್ಲಿನ ಆಧಾರವಾಗಿರುವ ಡೇಟಾಗೆ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// ಆಧಾರವಾಗಿರುವ ಡೇಟಾಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಕರೆ `RefCell` ಅನ್ನು ಪರಸ್ಪರ ಎರವಲು ಪಡೆಯುತ್ತದೆ (ಕಂಪೈಲ್ ಸಮಯದಲ್ಲಿ) ಆದ್ದರಿಂದ ಕ್ರಿಯಾತ್ಮಕ ತಪಾಸಣೆ ಅಗತ್ಯವಿಲ್ಲ.
    ///
    /// ಆದಾಗ್ಯೂ ಜಾಗರೂಕರಾಗಿರಿ: ಈ ವಿಧಾನವು `self` ಅನ್ನು ರೂಪಾಂತರಿಸಬಹುದೆಂದು ನಿರೀಕ್ಷಿಸುತ್ತದೆ, ಇದು ಸಾಮಾನ್ಯವಾಗಿ `RefCell` ಅನ್ನು ಬಳಸುವಾಗ ಆಗುವುದಿಲ್ಲ.
    ///
    /// `self` ರೂಪಾಂತರಗೊಳ್ಳದಿದ್ದರೆ [`borrow_mut`] ವಿಧಾನವನ್ನು ನೋಡೋಣ.
    ///
    /// ಅಲ್ಲದೆ, ಈ ವಿಧಾನವು ವಿಶೇಷ ಸಂದರ್ಭಗಳಿಗೆ ಮಾತ್ರ ಮತ್ತು ಸಾಮಾನ್ಯವಾಗಿ ನಿಮಗೆ ಬೇಕಾದುದಲ್ಲ ಎಂಬುದನ್ನು ದಯವಿಟ್ಟು ತಿಳಿದುಕೊಳ್ಳಿ.
    /// ಸಂದೇಹವಿದ್ದಲ್ಲಿ, ಬದಲಿಗೆ [`borrow_mut`] ಬಳಸಿ.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `RefCell` ನ ಎರವಲು ಸ್ಥಿತಿಯ ಮೇಲೆ ಸೋರಿಕೆಯಾದ ಕಾವಲುಗಾರರ ಪರಿಣಾಮವನ್ನು ರದ್ದುಗೊಳಿಸಿ.
    ///
    /// ಈ ಕರೆ [`get_mut`] ಗೆ ಹೋಲುತ್ತದೆ ಆದರೆ ಹೆಚ್ಚು ವಿಶೇಷವಾಗಿದೆ.
    /// ಯಾವುದೇ ಸಾಲಗಳು ಅಸ್ತಿತ್ವದಲ್ಲಿಲ್ಲ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ಇದು `RefCell` ಅನ್ನು ಪರಸ್ಪರ ಎರವಲು ಪಡೆಯುತ್ತದೆ ಮತ್ತು ನಂತರ ರಾಜ್ಯ ಟ್ರ್ಯಾಕಿಂಗ್ ಹಂಚಿಕೆಯ ಸಾಲಗಳನ್ನು ಮರುಹೊಂದಿಸುತ್ತದೆ.
    /// ಕೆಲವು `Ref` ಅಥವಾ `RefMut` ಸಾಲಗಳು ಸೋರಿಕೆಯಾಗಿದ್ದರೆ ಇದು ಪ್ರಸ್ತುತವಾಗಿರುತ್ತದೆ.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// ಸುತ್ತಿದ ಮೌಲ್ಯವನ್ನು ಅಸ್ಥಿರವಾಗಿ ಎರವಲು ಪಡೆಯುತ್ತದೆ, ಪ್ರಸ್ತುತ ಮೌಲ್ಯವನ್ನು ಪರಸ್ಪರ ಸಾಲವಾಗಿ ಪಡೆದರೆ ದೋಷವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// `RefCell::borrow` ಗಿಂತ ಭಿನ್ನವಾಗಿ, ಈ ವಿಧಾನವು ಅಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ಅದು `Ref` ಅನ್ನು ಹಿಂತಿರುಗಿಸುವುದಿಲ್ಲ, ಇದರಿಂದಾಗಿ ಸಾಲ ಧ್ವಜವನ್ನು ಮುಟ್ಟಲಾಗುವುದಿಲ್ಲ.
    /// ಈ ವಿಧಾನದಿಂದ ಹಿಂತಿರುಗಿದ ಉಲ್ಲೇಖವು ಜೀವಂತವಾಗಿರುವಾಗ `RefCell` ಅನ್ನು ಎರವಲು ಪಡೆಯುವುದು ವಿವರಿಸಲಾಗದ ವರ್ತನೆಯಾಗಿದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // ಸುರಕ್ಷತೆ: ಯಾರೂ ಈಗ ಸಕ್ರಿಯವಾಗಿ ಬರೆಯುತ್ತಿಲ್ಲ ಎಂದು ನಾವು ಪರಿಶೀಲಿಸುತ್ತೇವೆ, ಆದರೆ ಅದು
            // ಹಿಂದಿರುಗಿದ ಉಲ್ಲೇಖವು ಬಳಕೆಯಲ್ಲಿಲ್ಲದ ತನಕ ಯಾರೂ ಬರೆಯುವುದಿಲ್ಲ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳುವವರ ಜವಾಬ್ದಾರಿ.
            // ಅಲ್ಲದೆ, `self.value.get()` ಎಂಬುದು `self` ಒಡೆತನದ ಮೌಲ್ಯವನ್ನು ಸೂಚಿಸುತ್ತದೆ ಮತ್ತು ಆದ್ದರಿಂದ `self` ನ ಜೀವಿತಾವಧಿಗೆ ಮಾನ್ಯವಾಗಿರುತ್ತದೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// ಸುತ್ತಿದ ಮೌಲ್ಯವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ, `Default::default()` ಅನ್ನು ಅದರ ಸ್ಥಾನದಲ್ಲಿ ಬಿಡುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// ಮೌಲ್ಯವನ್ನು ಪ್ರಸ್ತುತ ಎರವಲು ಪಡೆದಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// ಮೌಲ್ಯವನ್ನು ಪ್ರಸ್ತುತ ರೂಪಾಂತರಿತವಾಗಿ ಎರವಲು ಪಡೆದಿದ್ದರೆ Panics.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// T ಗಾಗಿ `Default` ಮೌಲ್ಯದೊಂದಿಗೆ `RefCell<T>` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// `RefCell` ನಲ್ಲಿನ ಮೌಲ್ಯವನ್ನು ಪ್ರಸ್ತುತ ಎರವಲು ಪಡೆದಿದ್ದರೆ Panics.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// `RefCell` ನಲ್ಲಿನ ಮೌಲ್ಯವನ್ನು ಪ್ರಸ್ತುತ ಎರವಲು ಪಡೆದಿದ್ದರೆ Panics.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// `RefCell` ನಲ್ಲಿನ ಮೌಲ್ಯವನ್ನು ಪ್ರಸ್ತುತ ಎರವಲು ಪಡೆದಿದ್ದರೆ Panics.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// `RefCell` ನಲ್ಲಿನ ಮೌಲ್ಯವನ್ನು ಪ್ರಸ್ತುತ ಎರವಲು ಪಡೆದಿದ್ದರೆ Panics.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// `RefCell` ನಲ್ಲಿನ ಮೌಲ್ಯವನ್ನು ಪ್ರಸ್ತುತ ಎರವಲು ಪಡೆದಿದ್ದರೆ Panics.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// `RefCell` ನಲ್ಲಿನ ಮೌಲ್ಯವನ್ನು ಪ್ರಸ್ತುತ ಎರವಲು ಪಡೆದಿದ್ದರೆ Panics.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// `RefCell` ನಲ್ಲಿನ ಮೌಲ್ಯವನ್ನು ಪ್ರಸ್ತುತ ಎರವಲು ಪಡೆದಿದ್ದರೆ Panics.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // ಸಾಲವನ್ನು ಹೆಚ್ಚಿಸುವುದರಿಂದ ಈ ಸಂದರ್ಭಗಳಲ್ಲಿ ಓದದಿರುವ ಮೌಲ್ಯಕ್ಕೆ (<=0) ಕಾರಣವಾಗಬಹುದು:
            // 1. ಇದು <0, ಅಂದರೆ ಬರೆಯುವ ಸಾಲಗಳಿವೆ, ಆದ್ದರಿಂದ Rust ನ ಉಲ್ಲೇಖ ಅಲಿಯಾಸಿಂಗ್ ನಿಯಮಗಳಿಂದಾಗಿ ನಾವು ಓದುವ ಸಾಲವನ್ನು ಅನುಮತಿಸಲಾಗುವುದಿಲ್ಲ.
            // 2.
            // ಇದು isize::MAX (ಓದುವ ಸಾಲಗಳ ಗರಿಷ್ಠ ಮೊತ್ತ) ಮತ್ತು ಅದು isize::MIN (ಉಕ್ಕಿನ ಬರವಣಿಗೆಯ ಗರಿಷ್ಠ ಮೊತ್ತ) ಗೆ ಉಕ್ಕಿ ಹರಿಯಿತು, ಆದ್ದರಿಂದ ನಾವು ಹೆಚ್ಚುವರಿ ಓದುವ ಸಾಲವನ್ನು ಅನುಮತಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ ಏಕೆಂದರೆ ಐಸೈಜ್ ಅನೇಕ ಓದಿದ ಸಾಲಗಳನ್ನು ಪ್ರತಿನಿಧಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ (ಇದು ಸಂಭವಿಸಿದಲ್ಲಿ ಮಾತ್ರ ನೀವು ಒಂದು ಸಣ್ಣ ಸ್ಥಿರವಾದ `ರೆಫ್'ಗಳಿಗಿಂತ mem::forget ಹೆಚ್ಚು, ಅದು ಉತ್ತಮ ಅಭ್ಯಾಸವಲ್ಲ)
            //
            //
            //
            //
            None
        } else {
            // ಸಾಲವನ್ನು ಹೆಚ್ಚಿಸುವುದರಿಂದ ಈ ಸಂದರ್ಭಗಳಲ್ಲಿ ಓದುವ ಮೌಲ್ಯಕ್ಕೆ (> 0) ಕಾರಣವಾಗಬಹುದು:
            // 1. ಅದು=0 ಆಗಿತ್ತು, ಅಂದರೆ ಅದನ್ನು ಎರವಲು ಪಡೆಯಲಾಗಿಲ್ಲ, ಮತ್ತು ನಾವು ಮೊದಲ ಓದಿದ ಸಾಲವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತಿದ್ದೇವೆ
            // 2. ಅದು> 0 ಮತ್ತು <isize::MAX, ಅಂದರೆ
            // ಓದಿದ ಸಾಲಗಳು ಇದ್ದವು, ಮತ್ತು ಐಸೈಜ್ ಇನ್ನೂ ಒಂದು ದೊಡ್ಡ ಸಾಲವನ್ನು ಹೊಂದಿರುವುದನ್ನು ಪ್ರತಿನಿಧಿಸುವಷ್ಟು ದೊಡ್ಡದಾಗಿದೆ
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // ಈ ರೆಫ್ ಅಸ್ತಿತ್ವದಲ್ಲಿರುವುದರಿಂದ, ಸಾಲ ಧ್ವಜವು ಓದುವ ಸಾಲ ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // ಬರವಣಿಗೆಯ ಸಾಲಕ್ಕೆ ಉಕ್ಕಿ ಹರಿಯದಂತೆ ಸಾಲ ಕೌಂಟರ್ ಅನ್ನು ತಡೆಯಿರಿ.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// ಎರವಲು ಪಡೆದ ಉಲ್ಲೇಖವನ್ನು `RefCell` ಪೆಟ್ಟಿಗೆಯಲ್ಲಿನ ಮೌಲ್ಯಕ್ಕೆ ಸುತ್ತಿಕೊಳ್ಳುತ್ತದೆ.
/// `RefCell<T>` ನಿಂದ ಎರವಲು ಪಡೆಯದ ಮೌಲ್ಯಕ್ಕಾಗಿ ಒಂದು ಹೊದಿಕೆ ಪ್ರಕಾರ.
///
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ [module-level documentation](self) ನೋಡಿ.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// `Ref` ಅನ್ನು ನಕಲಿಸುತ್ತದೆ.
    ///
    /// `RefCell` ಈಗಾಗಲೇ ಬದಲಾಗದೆ ಎರವಲು ಪಡೆದಿದೆ, ಆದ್ದರಿಂದ ಇದು ವಿಫಲಗೊಳ್ಳಲು ಸಾಧ್ಯವಿಲ್ಲ.
    ///
    /// ಇದು `Ref::clone(...)` ಆಗಿ ಬಳಸಬೇಕಾದ ಸಂಯೋಜಿತ ಕಾರ್ಯವಾಗಿದೆ.
    /// `Clone` ಅನುಷ್ಠಾನ ಅಥವಾ ಒಂದು ವಿಧಾನವು `RefCell` ನ ವಿಷಯಗಳನ್ನು ಕ್ಲೋನ್ ಮಾಡಲು `r.borrow().clone()` ನ ವ್ಯಾಪಕ ಬಳಕೆಗೆ ಅಡ್ಡಿಯಾಗುತ್ತದೆ.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// ಎರವಲು ಪಡೆದ ಡೇಟಾದ ಒಂದು ಘಟಕಕ್ಕಾಗಿ ಹೊಸ `Ref` ಅನ್ನು ಮಾಡುತ್ತದೆ.
    ///
    /// `RefCell` ಈಗಾಗಲೇ ಬದಲಾಗದೆ ಎರವಲು ಪಡೆದಿದೆ, ಆದ್ದರಿಂದ ಇದು ವಿಫಲಗೊಳ್ಳಲು ಸಾಧ್ಯವಿಲ್ಲ.
    ///
    /// ಇದು `Ref::map(...)` ಆಗಿ ಬಳಸಬೇಕಾದ ಸಂಯೋಜಿತ ಕಾರ್ಯವಾಗಿದೆ.
    /// ಒಂದು ವಿಧಾನವು `Deref` ಮೂಲಕ ಬಳಸುವ `RefCell` ನ ವಿಷಯಗಳ ಮೇಲೆ ಅದೇ ಹೆಸರಿನ ವಿಧಾನಗಳಿಗೆ ಅಡ್ಡಿಪಡಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// ಎರವಲು ಪಡೆದ ಡೇಟಾದ ಐಚ್ al ಿಕ ಘಟಕಕ್ಕಾಗಿ ಹೊಸ `Ref` ಅನ್ನು ಮಾಡುತ್ತದೆ.
    /// ಮುಚ್ಚುವಿಕೆಯು `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸಿದರೆ ಮೂಲ ಸಿಬ್ಬಂದಿಯನ್ನು `Err(..)` ಆಗಿ ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// `RefCell` ಈಗಾಗಲೇ ಬದಲಾಗದೆ ಎರವಲು ಪಡೆದಿದೆ, ಆದ್ದರಿಂದ ಇದು ವಿಫಲಗೊಳ್ಳಲು ಸಾಧ್ಯವಿಲ್ಲ.
    ///
    /// ಇದು `Ref::filter_map(...)` ಆಗಿ ಬಳಸಬೇಕಾದ ಸಂಯೋಜಿತ ಕಾರ್ಯವಾಗಿದೆ.
    /// ಒಂದು ವಿಧಾನವು `Deref` ಮೂಲಕ ಬಳಸುವ `RefCell` ನ ವಿಷಯಗಳ ಮೇಲೆ ಅದೇ ಹೆಸರಿನ ವಿಧಾನಗಳಿಗೆ ಅಡ್ಡಿಪಡಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// ಎರವಲು ಪಡೆದ ಡೇಟಾದ ವಿಭಿನ್ನ ಘಟಕಗಳಿಗಾಗಿ `Ref` ಅನ್ನು ಬಹು `ರೆಫ್'ಗಳಾಗಿ ವಿಭಜಿಸುತ್ತದೆ.
    ///
    /// `RefCell` ಈಗಾಗಲೇ ಬದಲಾಗದೆ ಎರವಲು ಪಡೆದಿದೆ, ಆದ್ದರಿಂದ ಇದು ವಿಫಲಗೊಳ್ಳಲು ಸಾಧ್ಯವಿಲ್ಲ.
    ///
    /// ಇದು `Ref::map_split(...)` ಆಗಿ ಬಳಸಬೇಕಾದ ಸಂಯೋಜಿತ ಕಾರ್ಯವಾಗಿದೆ.
    /// ಒಂದು ವಿಧಾನವು `Deref` ಮೂಲಕ ಬಳಸುವ `RefCell` ನ ವಿಷಯಗಳ ಮೇಲೆ ಅದೇ ಹೆಸರಿನ ವಿಧಾನಗಳಿಗೆ ಅಡ್ಡಿಪಡಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// ಆಧಾರವಾಗಿರುವ ಡೇಟಾಗೆ ಉಲ್ಲೇಖವಾಗಿ ಪರಿವರ್ತಿಸಿ.
    ///
    /// ಆಧಾರವಾಗಿರುವ `RefCell` ಅನ್ನು ಎಂದಿಗೂ ಮತ್ತೆ ಎರವಲು ಪಡೆಯಲಾಗುವುದಿಲ್ಲ ಮತ್ತು ಯಾವಾಗಲೂ ಬದಲಾಗದೆ ಎರವಲು ಪಡೆದಂತೆ ಕಾಣಿಸುತ್ತದೆ.
    ///
    /// ಸ್ಥಿರ ಸಂಖ್ಯೆಯ ಉಲ್ಲೇಖಗಳಿಗಿಂತ ಹೆಚ್ಚಿನದನ್ನು ಸೋರಿಕೆ ಮಾಡುವುದು ಒಳ್ಳೆಯದಲ್ಲ.
    /// ಒಟ್ಟು ಕಡಿಮೆ ಸಂಖ್ಯೆಯ ಸೋರಿಕೆಗಳು ಸಂಭವಿಸಿದಲ್ಲಿ `RefCell` ಅನ್ನು ಮತ್ತೆ ಬದಲಾಯಿಸಲಾಗುವುದಿಲ್ಲ.
    ///
    /// ಇದು `Ref::leak(...)` ಆಗಿ ಬಳಸಬೇಕಾದ ಸಂಯೋಜಿತ ಕಾರ್ಯವಾಗಿದೆ.
    /// ಒಂದು ವಿಧಾನವು `Deref` ಮೂಲಕ ಬಳಸುವ `RefCell` ನ ವಿಷಯಗಳ ಮೇಲೆ ಅದೇ ಹೆಸರಿನ ವಿಧಾನಗಳಿಗೆ ಅಡ್ಡಿಪಡಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // ಈ ರೆಫ್ ಅನ್ನು ಮರೆತುಬಿಡುವ ಮೂಲಕ, ರೆಫ್‌ಸೆಲ್‌ನಲ್ಲಿನ ಸಾಲ ಕೌಂಟರ್ ಜೀವಿತಾವಧಿಯ `'b` ಒಳಗೆ ಬಳಕೆಯಾಗದಂತೆ ಹಿಂತಿರುಗಲು ಸಾಧ್ಯವಿಲ್ಲ ಎಂದು ನಾವು ಖಚಿತಪಡಿಸುತ್ತೇವೆ.
        // ಉಲ್ಲೇಖ ಟ್ರ್ಯಾಕಿಂಗ್ ಸ್ಥಿತಿಯನ್ನು ಮರುಹೊಂದಿಸಲು ಎರವಲು ಪಡೆದ ರೆಫ್‌ಸೆಲ್‌ಗೆ ವಿಶಿಷ್ಟ ಉಲ್ಲೇಖದ ಅಗತ್ಯವಿದೆ.
        // ಮೂಲ ಕೋಶದಿಂದ ಯಾವುದೇ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳನ್ನು ರಚಿಸಲಾಗುವುದಿಲ್ಲ.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// ಎರವಲು ಪಡೆದ ಡೇಟಾದ ಒಂದು ಘಟಕಕ್ಕಾಗಿ ಹೊಸ `RefMut` ಅನ್ನು ಮಾಡುತ್ತದೆ, ಉದಾ, ಎನಮ್ ರೂಪಾಂತರ.
    ///
    /// `RefCell` ಈಗಾಗಲೇ ರೂಪಾಂತರಗೊಂಡಿದೆ, ಆದ್ದರಿಂದ ಇದು ವಿಫಲಗೊಳ್ಳುವುದಿಲ್ಲ.
    ///
    /// ಇದು `RefMut::map(...)` ಆಗಿ ಬಳಸಬೇಕಾದ ಸಂಯೋಜಿತ ಕಾರ್ಯವಾಗಿದೆ.
    /// ಒಂದು ವಿಧಾನವು `Deref` ಮೂಲಕ ಬಳಸುವ `RefCell` ನ ವಿಷಯಗಳ ಮೇಲೆ ಅದೇ ಹೆಸರಿನ ವಿಧಾನಗಳಿಗೆ ಅಡ್ಡಿಪಡಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): ಸಾಲ-ಚೆಕ್ ಅನ್ನು ಸರಿಪಡಿಸಿ
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// ಎರವಲು ಪಡೆದ ಡೇಟಾದ ಐಚ್ al ಿಕ ಘಟಕಕ್ಕಾಗಿ ಹೊಸ `RefMut` ಅನ್ನು ಮಾಡುತ್ತದೆ.
    /// ಮುಚ್ಚುವಿಕೆಯು `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸಿದರೆ ಮೂಲ ಸಿಬ್ಬಂದಿಯನ್ನು `Err(..)` ಆಗಿ ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// `RefCell` ಈಗಾಗಲೇ ರೂಪಾಂತರಗೊಂಡಿದೆ, ಆದ್ದರಿಂದ ಇದು ವಿಫಲಗೊಳ್ಳುವುದಿಲ್ಲ.
    ///
    /// ಇದು `RefMut::filter_map(...)` ಆಗಿ ಬಳಸಬೇಕಾದ ಸಂಯೋಜಿತ ಕಾರ್ಯವಾಗಿದೆ.
    /// ಒಂದು ವಿಧಾನವು `Deref` ಮೂಲಕ ಬಳಸುವ `RefCell` ನ ವಿಷಯಗಳ ಮೇಲೆ ಅದೇ ಹೆಸರಿನ ವಿಧಾನಗಳಿಗೆ ಅಡ್ಡಿಪಡಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): ಸಾಲ-ಚೆಕ್ ಅನ್ನು ಸರಿಪಡಿಸಿ
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // ಸುರಕ್ಷತೆ: ಕಾರ್ಯವು ಅವಧಿಗೆ ವಿಶೇಷ ಉಲ್ಲೇಖವನ್ನು ಹೊಂದಿರುತ್ತದೆ
        // `orig` ಮೂಲಕ ಅದರ ಕರೆಯ, ಮತ್ತು ಪಾಯಿಂಟರ್ ಅನ್ನು ಫಂಕ್ಷನ್ ಕರೆಯ ಒಳಗೆ ಮಾತ್ರ ಡಿ-ಉಲ್ಲೇಖಿಸಲಾಗುತ್ತದೆ, ವಿಶೇಷ ಉಲ್ಲೇಖವನ್ನು ತಪ್ಪಿಸಿಕೊಳ್ಳಲು ಎಂದಿಗೂ ಅನುಮತಿಸುವುದಿಲ್ಲ.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // ಸುರಕ್ಷತೆ: ಮೇಲಿನಂತೆಯೇ.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// ಎರವಲು ಪಡೆದ ಡೇಟಾದ ವಿಭಿನ್ನ ಘಟಕಗಳಿಗಾಗಿ `RefMut` ಅನ್ನು ಬಹು `ರೆಫ್‌ಮಟ್‌'ಗಳಾಗಿ ವಿಭಜಿಸುತ್ತದೆ.
    ///
    /// ಹಿಂದಿರುಗಿದ ಎರಡೂ `ರೆಫ್‌ಮಟ್'ಗಳು ವ್ಯಾಪ್ತಿಯಿಂದ ಹೊರಹೋಗುವವರೆಗೆ ಆಧಾರವಾಗಿರುವ `RefCell` ಪರಸ್ಪರ ಸಾಲವಾಗಿ ಉಳಿಯುತ್ತದೆ.
    ///
    /// `RefCell` ಈಗಾಗಲೇ ರೂಪಾಂತರಗೊಂಡಿದೆ, ಆದ್ದರಿಂದ ಇದು ವಿಫಲಗೊಳ್ಳುವುದಿಲ್ಲ.
    ///
    /// ಇದು `RefMut::map_split(...)` ಆಗಿ ಬಳಸಬೇಕಾದ ಸಂಯೋಜಿತ ಕಾರ್ಯವಾಗಿದೆ.
    /// ಒಂದು ವಿಧಾನವು `Deref` ಮೂಲಕ ಬಳಸುವ `RefCell` ನ ವಿಷಯಗಳ ಮೇಲೆ ಅದೇ ಹೆಸರಿನ ವಿಧಾನಗಳಿಗೆ ಅಡ್ಡಿಪಡಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// ಆಧಾರವಾಗಿರುವ ಡೇಟಾಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವಾಗಿ ಪರಿವರ್ತಿಸಿ.
    ///
    /// ಆಧಾರವಾಗಿರುವ `RefCell` ಅನ್ನು ಮತ್ತೆ ಎರವಲು ಪಡೆಯಲಾಗುವುದಿಲ್ಲ ಮತ್ತು ಯಾವಾಗಲೂ ಈಗಾಗಲೇ ಪರಸ್ಪರ ಎರವಲು ಪಡೆದಂತೆ ಕಾಣಿಸುತ್ತದೆ, ಹಿಂದಿರುಗಿದ ಉಲ್ಲೇಖವನ್ನು ಒಳಾಂಗಣಕ್ಕೆ ಮಾತ್ರ ಮಾಡುತ್ತದೆ.
    ///
    ///
    /// ಇದು `RefMut::leak(...)` ಆಗಿ ಬಳಸಬೇಕಾದ ಸಂಯೋಜಿತ ಕಾರ್ಯವಾಗಿದೆ.
    /// ಒಂದು ವಿಧಾನವು `Deref` ಮೂಲಕ ಬಳಸುವ `RefCell` ನ ವಿಷಯಗಳ ಮೇಲೆ ಅದೇ ಹೆಸರಿನ ವಿಧಾನಗಳಿಗೆ ಅಡ್ಡಿಪಡಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // ಈ BorrowRefMut ಅನ್ನು ಮರೆತುಬಿಡುವುದರ ಮೂಲಕ, RefCell ನಲ್ಲಿನ ಸಾಲ ಕೌಂಟರ್ ಜೀವಿತಾವಧಿಯ `'b` ಒಳಗೆ UNUSED ಗೆ ಹಿಂತಿರುಗಲು ಸಾಧ್ಯವಿಲ್ಲ ಎಂದು ನಾವು ಖಚಿತಪಡಿಸುತ್ತೇವೆ.
        // ಉಲ್ಲೇಖ ಟ್ರ್ಯಾಕಿಂಗ್ ಸ್ಥಿತಿಯನ್ನು ಮರುಹೊಂದಿಸಲು ಎರವಲು ಪಡೆದ ರೆಫ್‌ಸೆಲ್‌ಗೆ ವಿಶಿಷ್ಟ ಉಲ್ಲೇಖದ ಅಗತ್ಯವಿದೆ.
        // ಆ ಜೀವಿತಾವಧಿಯಲ್ಲಿ ಮೂಲ ಕೋಶದಿಂದ ಹೆಚ್ಚಿನ ಉಲ್ಲೇಖಗಳನ್ನು ರಚಿಸಲಾಗುವುದಿಲ್ಲ, ಉಳಿದ ಜೀವಿತಾವಧಿಯಲ್ಲಿ ಪ್ರಸ್ತುತ ಸಾಲವನ್ನು ಮಾತ್ರ ಉಲ್ಲೇಖಿಸುತ್ತದೆ.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: BorrowRefMut::clone ಗಿಂತ ಭಿನ್ನವಾಗಿ, ಹೊಸದನ್ನು ಆರಂಭಿಕವನ್ನು ರಚಿಸಲು ಕರೆಯಲಾಗುತ್ತದೆ
        // ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖ, ಮತ್ತು ಪ್ರಸ್ತುತ ಯಾವುದೇ ಉಲ್ಲೇಖಗಳು ಇರಬಾರದು.
        // ಹೀಗಾಗಿ, ಕ್ಲೋನ್ ರೂಪಾಂತರಿತ ಮರುಪಾವತಿಯನ್ನು ಹೆಚ್ಚಿಸುವಾಗ, ಇಲ್ಲಿ ನಾವು ಸ್ಪಷ್ಟವಾಗಿ UNUSED ನಿಂದ UNUSED, 1 ಗೆ ಹೋಗಲು ಮಾತ್ರ ಅನುಮತಿಸುತ್ತೇವೆ.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // `BorrowRefMut` ಅನ್ನು ಕ್ಲೋನ್ ಮಾಡುತ್ತದೆ.
    //
    // ಪ್ರತಿ `BorrowRefMut` ಅನ್ನು ಮೂಲ ವಸ್ತುವಿನ ವಿಶಿಷ್ಟವಾದ, ನಾನ್‌ಓವರ್‌ಲ್ಯಾಪಿಂಗ್ ಶ್ರೇಣಿಗೆ ಪರಿವರ್ತಿಸಬಹುದಾದ ಉಲ್ಲೇಖವನ್ನು ಪತ್ತೆಹಚ್ಚಲು ಬಳಸಿದರೆ ಮಾತ್ರ ಇದು ಮಾನ್ಯವಾಗಿರುತ್ತದೆ.
    //
    // ಇದು ಕ್ಲೋನ್ ಇಂಪ್ಲ್‌ನಲ್ಲಿಲ್ಲ ಆದ್ದರಿಂದ ಕೋಡ್ ಇದನ್ನು ಸೂಚ್ಯವಾಗಿ ಕರೆಯುವುದಿಲ್ಲ.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // ಸಾಲದ ಕೌಂಟರ್ ಅನ್ನು ಒಳಹರಿವಿನಿಂದ ತಡೆಯಿರಿ.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// `RefCell<T>` ನಿಂದ ರೂಪಾಂತರಿತ ಎರವಲು ಪಡೆದ ಮೌಲ್ಯಕ್ಕಾಗಿ ಹೊದಿಕೆ ಪ್ರಕಾರ.
///
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ [module-level documentation](self) ನೋಡಿ.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Rust ನಲ್ಲಿ ಆಂತರಿಕ ರೂಪಾಂತರದ ಪ್ರಮುಖ ಪ್ರಾಚೀನ.
///
/// ನೀವು `&T` ಉಲ್ಲೇಖವನ್ನು ಹೊಂದಿದ್ದರೆ, ಸಾಮಾನ್ಯವಾಗಿ Rust ನಲ್ಲಿ ಕಂಪೈಲರ್ `&T` ಬದಲಾಗದ ಡೇಟಾಗೆ ಸೂಚಿಸುವ ಜ್ಞಾನದ ಆಧಾರದ ಮೇಲೆ ಆಪ್ಟಿಮೈಸೇಶನ್ ಮಾಡುತ್ತದೆ.ಆ ಡೇಟಾವನ್ನು ರೂಪಾಂತರಿಸುವುದು, ಉದಾಹರಣೆಗೆ ಅಲಿಯಾಸ್ ಮೂಲಕ ಅಥವಾ `&T` ಅನ್ನು `&mut T` ಗೆ ಪರಿವರ್ತಿಸುವ ಮೂಲಕ, ವಿವರಿಸಲಾಗದ ನಡವಳಿಕೆ ಎಂದು ಪರಿಗಣಿಸಲಾಗುತ್ತದೆ.
/// `UnsafeCell<T>` `&T` ಗಾಗಿ ಬದಲಾಗದ ಖಾತರಿಯಿಂದ ಹೊರಗುಳಿಯುತ್ತದೆ: ಹಂಚಿದ ಉಲ್ಲೇಖ `&UnsafeCell<T>` ರೂಪಾಂತರಗೊಳ್ಳುತ್ತಿರುವ ಡೇಟಾವನ್ನು ಸೂಚಿಸುತ್ತದೆ.ಇದನ್ನು "interior mutability" ಎಂದು ಕರೆಯಲಾಗುತ್ತದೆ.
///
/// `Cell<T>` ಮತ್ತು `RefCell<T>` ನಂತಹ ಆಂತರಿಕ ರೂಪಾಂತರವನ್ನು ಅನುಮತಿಸುವ ಎಲ್ಲಾ ಇತರ ಪ್ರಕಾರಗಳು ಆಂತರಿಕವಾಗಿ ತಮ್ಮ ಡೇಟಾವನ್ನು ಕಟ್ಟಲು `UnsafeCell` ಅನ್ನು ಬಳಸುತ್ತವೆ.
///
/// ಹಂಚಿದ ಉಲ್ಲೇಖಗಳಿಗೆ ಬದಲಾಯಿಸಲಾಗದ ಖಾತರಿ ಮಾತ್ರ `UnsafeCell` ನಿಂದ ಪ್ರಭಾವಿತವಾಗಿರುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳಿಗೆ ಅನನ್ಯತೆಯ ಖಾತರಿ ಪರಿಣಾಮ ಬೀರುವುದಿಲ್ಲ.ಅಲಿಯಾಸಿಂಗ್ `&mut` ಅನ್ನು ಪಡೆಯಲು *ಯಾವುದೇ* ಕಾನೂನು ಮಾರ್ಗವಿಲ್ಲ, `UnsafeCell<T>` ನೊಂದಿಗೆ ಸಹ ಇಲ್ಲ.
///
/// `UnsafeCell` API ಸ್ವತಃ ತಾಂತ್ರಿಕವಾಗಿ ತುಂಬಾ ಸರಳವಾಗಿದೆ: [`.get()`] ನಿಮಗೆ ಅದರ ವಿಷಯಗಳಿಗೆ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ `*mut T` ನೀಡುತ್ತದೆ.ಆ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಅನ್ನು ಸರಿಯಾಗಿ ಬಳಸುವುದು ಅಮೂರ್ತ ವಿನ್ಯಾಸಕನಾಗಿ _you_ ವರೆಗೆ.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// ನಿಖರವಾದ Rust ಅಲಿಯಾಸಿಂಗ್ ನಿಯಮಗಳು ಸ್ವಲ್ಪಮಟ್ಟಿಗೆ ಫ್ಲಕ್ಸ್‌ನಲ್ಲಿವೆ, ಆದರೆ ಮುಖ್ಯ ಅಂಶಗಳು ವಿವಾದಾಸ್ಪದವಾಗಿಲ್ಲ:
///
/// - ಸುರಕ್ಷಿತ ಕೋಡ್‌ನಿಂದ ಪ್ರವೇಶಿಸಬಹುದಾದ (ಉದಾಹರಣೆಗೆ, ನೀವು ಅದನ್ನು ಹಿಂದಿರುಗಿಸಿದ್ದರಿಂದ) ಜೀವಮಾನದ `'a` (`&T` ಅಥವಾ `&mut T` ಉಲ್ಲೇಖ) ದೊಂದಿಗೆ ನೀವು ಸುರಕ್ಷಿತ ಉಲ್ಲೇಖವನ್ನು ರಚಿಸಿದರೆ, ಉಳಿದ ಡೇಟಾವನ್ನು ಉಲ್ಲೇಖಿಸುವ ಯಾವುದೇ ರೀತಿಯಲ್ಲಿ ನೀವು ಡೇಟಾವನ್ನು ಪ್ರವೇಶಿಸಬಾರದು `'a` ನ.
/// ಉದಾಹರಣೆಗೆ, ಇದರರ್ಥ ನೀವು `UnsafeCell<T>` ನಿಂದ `*mut T` ಅನ್ನು ತೆಗೆದುಕೊಂಡು ಅದನ್ನು `&T` ಗೆ ಬಿತ್ತರಿಸಿದರೆ, ಆ ಉಲ್ಲೇಖದ ಜೀವಿತಾವಧಿಯು ಮುಕ್ತಾಯಗೊಳ್ಳುವವರೆಗೆ `T` ನಲ್ಲಿನ ಡೇಟಾವು ಬದಲಾಗದೆ ಉಳಿಯಬೇಕು (`T` ನಲ್ಲಿ ಕಂಡುಬರುವ ಯಾವುದೇ `UnsafeCell` ಡೇಟಾವನ್ನು ಮಾಡ್ಯುಲೋ ಮಾಡಿ).
/// ಅಂತೆಯೇ, ನೀವು ಸುರಕ್ಷಿತ ಕೋಡ್‌ಗೆ ಬಿಡುಗಡೆಯಾದ `&mut T` ಉಲ್ಲೇಖವನ್ನು ರಚಿಸಿದರೆ, ಆ ಉಲ್ಲೇಖವು ಮುಕ್ತಾಯಗೊಳ್ಳುವವರೆಗೆ ನೀವು `UnsafeCell` ಒಳಗೆ ಡೇಟಾವನ್ನು ಪ್ರವೇಶಿಸಬಾರದು.
///
/// - ಎಲ್ಲಾ ಸಮಯದಲ್ಲೂ, ನೀವು ಡೇಟಾ ರೇಸ್ ಗಳನ್ನು ತಪ್ಪಿಸಬೇಕು.ಅನೇಕ ಎಳೆಗಳು ಒಂದೇ `UnsafeCell` ಗೆ ಪ್ರವೇಶವನ್ನು ಹೊಂದಿದ್ದರೆ, ನಂತರ ಯಾವುದೇ ಬರಹಗಳು ಸರಿಯಾದ ಎಲ್ಲಾ ಘಟನೆಗಳನ್ನು ಹೊಂದಿರಬೇಕು-ಇತರ ಎಲ್ಲ ಪ್ರವೇಶಗಳಿಗೆ ಸಂಬಂಧಿಸಿರಬೇಕು (ಅಥವಾ ಪರಮಾಣುಗಳನ್ನು ಬಳಸಿ).
///
/// ಸರಿಯಾದ ವಿನ್ಯಾಸಕ್ಕೆ ಸಹಾಯ ಮಾಡಲು, ಈ ಕೆಳಗಿನ ಸನ್ನಿವೇಶಗಳನ್ನು ಏಕ-ಥ್ರೆಡ್ ಕೋಡ್‌ಗೆ ಕಾನೂನುಬದ್ಧವಾಗಿ ಸ್ಪಷ್ಟವಾಗಿ ಘೋಷಿಸಲಾಗಿದೆ:
///
/// 1. `&T` ಉಲ್ಲೇಖವನ್ನು ಸುರಕ್ಷಿತ ಕೋಡ್‌ಗೆ ಬಿಡುಗಡೆ ಮಾಡಬಹುದು ಮತ್ತು ಅಲ್ಲಿ ಅದು ಇತರ `&T` ಉಲ್ಲೇಖಗಳೊಂದಿಗೆ ಸಹಬಾಳ್ವೆ ಮಾಡಬಹುದು, ಆದರೆ `&mut T` ನೊಂದಿಗೆ ಅಲ್ಲ
///
/// 2. `&mut T` ಉಲ್ಲೇಖವನ್ನು ಸುರಕ್ಷಿತ ಕೋಡ್‌ಗೆ ಬಿಡುಗಡೆ ಮಾಡಬಹುದು, ಅದು ಇತರ `&mut T` ಅಥವಾ `&T` ನೊಂದಿಗೆ ಸಹ-ಅಸ್ತಿತ್ವದಲ್ಲಿಲ್ಲ.`&mut T` ಯಾವಾಗಲೂ ಅನನ್ಯವಾಗಿರಬೇಕು.
///
/// `&UnsafeCell<T>` ನ ವಿಷಯಗಳನ್ನು ರೂಪಾಂತರಿಸುವಾಗ (ಇತರ `&UnsafeCell<T>` ಉಲ್ಲೇಖಗಳು ಅಲಿಯಾಸ್ ಸೆಲ್ ಆಗಿದ್ದರೂ ಸಹ) ಸರಿಯಾಗಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ (ಮೇಲಿನ ಅಸ್ಥಿರತೆಗಳನ್ನು ನೀವು ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಜಾರಿಗೊಳಿಸಿದರೆ), ಅನೇಕ `&mut UnsafeCell<T>` ಅಲಿಯಾಸ್‌ಗಳನ್ನು ಹೊಂದಲು ಇದು ಇನ್ನೂ ವಿವರಿಸಲಾಗದ ನಡವಳಿಕೆಯಾಗಿದೆ.
/// ಅಂದರೆ, `UnsafeCell` ಎಂಬುದು _shared_ accesses (_i.e._ ನೊಂದಿಗೆ ವಿಶೇಷ ಸಂವಾದವನ್ನು ಹೊಂದಲು ವಿನ್ಯಾಸಗೊಳಿಸಲಾದ ಹೊದಿಕೆ, `&UnsafeCell<_>` ಉಲ್ಲೇಖದ ಮೂಲಕ);_exclusive_ accesses (_e.g._ ನೊಂದಿಗೆ, `&mut UnsafeCell<_>` ಮೂಲಕ ವ್ಯವಹರಿಸುವಾಗ ಯಾವುದೇ ಮ್ಯಾಜಿಕ್ ಇಲ್ಲ): ಆ `&mut` ಸಾಲದ ಅವಧಿಗೆ ಕೋಶ ಅಥವಾ ಸುತ್ತಿದ ಮೌಲ್ಯವನ್ನು ಅಲಿಯಾಸ್ ಮಾಡಲಾಗುವುದಿಲ್ಲ.
///
/// ಇದನ್ನು [`.get_mut()`] ಆಕ್ಸೆಸರ್ ಪ್ರದರ್ಶಿಸುತ್ತದೆ, ಇದು _safe_ getter ಆಗಿದೆ, ಅದು `&mut T` ಅನ್ನು ನೀಡುತ್ತದೆ.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// ಕೋಶವನ್ನು ಅಲಿಯಾಸ್ ಮಾಡುವ ಅನೇಕ ಉಲ್ಲೇಖಗಳು ಇದ್ದರೂ `UnsafeCell<_>` ನ ವಿಷಯಗಳನ್ನು ಹೇಗೆ ಉತ್ತಮವಾಗಿ ಪರಿವರ್ತಿಸಬಹುದು ಎಂಬುದನ್ನು ತೋರಿಸುವ ಉದಾಹರಣೆ ಇಲ್ಲಿದೆ:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // ಒಂದೇ `x` ಗೆ ಬಹು/ಏಕಕಾಲೀನ/ಹಂಚಿದ ಉಲ್ಲೇಖಗಳನ್ನು ಪಡೆಯಿರಿ.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // ಸುರಕ್ಷತೆ: ಈ ವ್ಯಾಪ್ತಿಯಲ್ಲಿ `x` ನ ವಿಷಯಗಳಿಗೆ ಬೇರೆ ಉಲ್ಲೇಖಗಳಿಲ್ಲ,
///     // ಆದ್ದರಿಂದ ನಮ್ಮದು ಪರಿಣಾಮಕಾರಿಯಾಗಿ ವಿಶಿಷ್ಟವಾಗಿದೆ.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- ಎರವಲು-+
///     *p1_exclusive += 27; // |
/// } // <---------- ಈ ಹಂತವನ್ನು ಮೀರಿ ಹೋಗಲು ಸಾಧ್ಯವಿಲ್ಲ -------------------+
///
/// unsafe {
///     // ಸುರಕ್ಷತೆ: ಈ ವ್ಯಾಪ್ತಿಯಲ್ಲಿ `x` ನ ವಿಷಯಗಳಿಗೆ ಪ್ರತ್ಯೇಕ ಪ್ರವೇಶವನ್ನು ಯಾರೂ ನಿರೀಕ್ಷಿಸುವುದಿಲ್ಲ,
///     // ಆದ್ದರಿಂದ ನಾವು ಏಕಕಾಲದಲ್ಲಿ ಅನೇಕ ಹಂಚಿದ ಪ್ರವೇಶಗಳನ್ನು ಹೊಂದಬಹುದು.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// ಈ ಕೆಳಗಿನ ಉದಾಹರಣೆಯು `UnsafeCell<T>` ಗೆ ವಿಶೇಷ ಪ್ರವೇಶವು ಅದರ `T` ಗೆ ವಿಶೇಷ ಪ್ರವೇಶವನ್ನು ಸೂಚಿಸುತ್ತದೆ ಎಂಬ ಅಂಶವನ್ನು ತೋರಿಸುತ್ತದೆ:
///
/// ```rust
/// #![forbid(unsafe_code)] // ವಿಶೇಷ ಪ್ರವೇಶಗಳೊಂದಿಗೆ,
///                         // `UnsafeCell` ಇದು ಪಾರದರ್ಶಕ ನೋ-ಆಪ್ ಹೊದಿಕೆಯಾಗಿದೆ, ಆದ್ದರಿಂದ ಇಲ್ಲಿ `unsafe` ಅಗತ್ಯವಿಲ್ಲ.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // `x` ಗೆ ಕಂಪೈಲ್-ಸಮಯ-ಪರಿಶೀಲಿಸಿದ ಅನನ್ಯ ಉಲ್ಲೇಖವನ್ನು ಪಡೆಯಿರಿ.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // ವಿಶೇಷ ಉಲ್ಲೇಖದೊಂದಿಗೆ, ನಾವು ವಿಷಯಗಳನ್ನು ಉಚಿತವಾಗಿ ಪರಿವರ್ತಿಸಬಹುದು.
/// *p_unique.get_mut() = 0;
/// // ಅಥವಾ, ಸಮಾನವಾಗಿ:
/// x = UnsafeCell::new(0);
///
/// // ನಾವು ಮೌಲ್ಯವನ್ನು ಹೊಂದಿರುವಾಗ, ನಾವು ವಿಷಯಗಳನ್ನು ಉಚಿತವಾಗಿ ಹೊರತೆಗೆಯಬಹುದು.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// `UnsafeCell` ನ ಹೊಸ ಉದಾಹರಣೆಯನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ ಅದು ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಮೌಲ್ಯವನ್ನು ಸುತ್ತುತ್ತದೆ.
    ///
    ///
    /// ವಿಧಾನಗಳ ಮೂಲಕ ಆಂತರಿಕ ಮೌಲ್ಯಕ್ಕೆ ಎಲ್ಲಾ ಪ್ರವೇಶವು `unsafe` ಆಗಿದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// ಮೌಲ್ಯವನ್ನು ಬಿಚ್ಚಿಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// ಸುತ್ತಿದ ಮೌಲ್ಯಕ್ಕೆ ರೂಪಾಂತರಿತ ಪಾಯಿಂಟರ್ ಅನ್ನು ಪಡೆಯುತ್ತದೆ.
    ///
    /// ಇದನ್ನು ಯಾವುದೇ ರೀತಿಯ ಪಾಯಿಂಟರ್‌ಗೆ ಬಿತ್ತರಿಸಬಹುದು.
    /// `&mut T` ಗೆ ಬಿತ್ತರಿಸುವಾಗ ಪ್ರವೇಶವು ಅನನ್ಯವಾಗಿದೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ (ಸಕ್ರಿಯ ಉಲ್ಲೇಖಗಳಿಲ್ಲ, ರೂಪಾಂತರ ಅಥವಾ ಇಲ್ಲ), ಮತ್ತು `&T` ಗೆ ಬಿತ್ತರಿಸುವಾಗ ಯಾವುದೇ ರೂಪಾಂತರಗಳು ಅಥವಾ ರೂಪಾಂತರಿತ ಅಲಿಯಾಸ್‌ಗಳು ನಡೆಯುತ್ತಿಲ್ಲ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // #[repr(transparent)] ಕಾರಣದಿಂದಾಗಿ ನಾವು ಪಾಯಿಂಟರ್ ಅನ್ನು `UnsafeCell<T>` ನಿಂದ `T` ಗೆ ಬಿತ್ತರಿಸಬಹುದು.
        // ಇದು libstd ನ ವಿಶೇಷ ಸ್ಥಿತಿಯನ್ನು ಬಳಸಿಕೊಳ್ಳುತ್ತದೆ, ಇದು ಕಂಪೈಲರ್‌ನ future ಆವೃತ್ತಿಗಳಲ್ಲಿ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ ಎಂಬ ಬಳಕೆದಾರ ಕೋಡ್‌ಗೆ ಯಾವುದೇ ಗ್ಯಾರಂಟಿ ಇಲ್ಲ!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// ಆಧಾರವಾಗಿರುವ ಡೇಟಾಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಕರೆ `UnsafeCell` ಅನ್ನು ಪರಸ್ಪರ ಎರವಲು ಪಡೆಯುತ್ತದೆ (ಕಂಪೈಲ್ ಸಮಯದಲ್ಲಿ) ಇದು ನಾವು ಒಂದೇ ಉಲ್ಲೇಖವನ್ನು ಹೊಂದಿದ್ದೇವೆ ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// ಸುತ್ತಿದ ಮೌಲ್ಯಕ್ಕೆ ರೂಪಾಂತರಿತ ಪಾಯಿಂಟರ್ ಅನ್ನು ಪಡೆಯುತ್ತದೆ.
    /// [`get`] ಗೆ ವ್ಯತ್ಯಾಸವೆಂದರೆ ಈ ಕಾರ್ಯವು ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಅನ್ನು ಸ್ವೀಕರಿಸುತ್ತದೆ, ಇದು ತಾತ್ಕಾಲಿಕ ಉಲ್ಲೇಖಗಳ ರಚನೆಯನ್ನು ತಪ್ಪಿಸಲು ಉಪಯುಕ್ತವಾಗಿದೆ.
    ///
    /// ಫಲಿತಾಂಶವನ್ನು ಯಾವುದೇ ರೀತಿಯ ಪಾಯಿಂಟರ್‌ಗೆ ಬಿತ್ತರಿಸಬಹುದು.
    /// `&mut T` ಗೆ ಬಿತ್ತರಿಸುವಾಗ ಪ್ರವೇಶವು ಅನನ್ಯವಾಗಿದೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ (ಯಾವುದೇ ಸಕ್ರಿಯ ಉಲ್ಲೇಖಗಳು, ರೂಪಾಂತರ ಅಥವಾ ಇಲ್ಲ), ಮತ್ತು `&T` ಗೆ ಬಿತ್ತರಿಸುವಾಗ ಯಾವುದೇ ರೂಪಾಂತರಗಳು ಅಥವಾ ರೂಪಾಂತರಿತ ಅಲಿಯಾಸ್‌ಗಳು ನಡೆಯುತ್ತಿಲ್ಲ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// `UnsafeCell` ನ ಕ್ರಮೇಣ ಪ್ರಾರಂಭಕ್ಕೆ `raw_get` ಅಗತ್ಯವಿದೆ, ಏಕೆಂದರೆ `get` ಗೆ ಕರೆ ಮಾಡುವುದರಿಂದ ಪ್ರಾರಂಭಿಸದ ಡೇಟಾಗೆ ಉಲ್ಲೇಖವನ್ನು ರಚಿಸುವ ಅಗತ್ಯವಿರುತ್ತದೆ:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // #[repr(transparent)] ಕಾರಣದಿಂದಾಗಿ ನಾವು ಪಾಯಿಂಟರ್ ಅನ್ನು `UnsafeCell<T>` ನಿಂದ `T` ಗೆ ಬಿತ್ತರಿಸಬಹುದು.
        // ಇದು libstd ನ ವಿಶೇಷ ಸ್ಥಿತಿಯನ್ನು ಬಳಸಿಕೊಳ್ಳುತ್ತದೆ, ಇದು ಕಂಪೈಲರ್‌ನ future ಆವೃತ್ತಿಗಳಲ್ಲಿ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ ಎಂಬ ಬಳಕೆದಾರ ಕೋಡ್‌ಗೆ ಯಾವುದೇ ಗ್ಯಾರಂಟಿ ಇಲ್ಲ!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// T ಗಾಗಿ `Default` ಮೌಲ್ಯದೊಂದಿಗೆ `UnsafeCell` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}