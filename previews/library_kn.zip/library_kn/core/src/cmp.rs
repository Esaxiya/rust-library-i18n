//! ಆದೇಶ ಮತ್ತು ಹೋಲಿಕೆಗಾಗಿ ಕ್ರಿಯಾತ್ಮಕತೆ.
//!
//! ಈ ಮಾಡ್ಯೂಲ್ ಮೌಲ್ಯಗಳನ್ನು ಆದೇಶಿಸಲು ಮತ್ತು ಹೋಲಿಸಲು ವಿವಿಧ ಸಾಧನಗಳನ್ನು ಒಳಗೊಂಡಿದೆ.ಸಾರಾಂಶದಲ್ಲಿ:
//!
//! * [`Eq`] ಮತ್ತು [`PartialEq`] ಗಳು traits ಆಗಿದ್ದು ಅದು ಕ್ರಮವಾಗಿ ಮೌಲ್ಯಗಳ ನಡುವೆ ಒಟ್ಟು ಮತ್ತು ಭಾಗಶಃ ಸಮಾನತೆಯನ್ನು ವ್ಯಾಖ್ಯಾನಿಸಲು ಅನುವು ಮಾಡಿಕೊಡುತ್ತದೆ.
//! ಅವುಗಳನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದರಿಂದ `==` ಮತ್ತು `!=` ಆಪರೇಟರ್‌ಗಳನ್ನು ಓವರ್‌ಲೋಡ್ ಮಾಡುತ್ತದೆ.
//! * [`Ord`] ಮತ್ತು [`PartialOrd`] ಗಳು traits ಆಗಿದ್ದು, ಅವು ಕ್ರಮವಾಗಿ ಮೌಲ್ಯಗಳ ನಡುವೆ ಒಟ್ಟು ಮತ್ತು ಭಾಗಶಃ ಕ್ರಮಗಳನ್ನು ವ್ಯಾಖ್ಯಾನಿಸಲು ಅನುವು ಮಾಡಿಕೊಡುತ್ತದೆ.
//!
//! ಅವುಗಳನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದರಿಂದ `<`, `<=`, `>`, ಮತ್ತು `>=` ಆಪರೇಟರ್‌ಗಳನ್ನು ಓವರ್‌ಲೋಡ್ ಮಾಡುತ್ತದೆ.
//! * [`Ordering`] ಇದು [`Ord`] ಮತ್ತು [`PartialOrd`] ನ ಮುಖ್ಯ ಕಾರ್ಯಗಳಿಂದ ಹಿಂದಿರುಗಿದ ಎನಮ್ ಆಗಿದೆ, ಮತ್ತು ಆದೇಶವನ್ನು ವಿವರಿಸುತ್ತದೆ.
//! * [`Reverse`] ಆದೇಶವನ್ನು ಸುಲಭವಾಗಿ ಹಿಮ್ಮುಖಗೊಳಿಸಲು ನಿಮಗೆ ಅನುಮತಿಸುವ ಒಂದು ರಚನೆಯಾಗಿದೆ.
//! * [`max`] ಮತ್ತು [`min`] ಎಂಬುದು [`Ord`] ನಿಂದ ಹೊರಹೊಮ್ಮುವ ಕಾರ್ಯಗಳು ಮತ್ತು ಗರಿಷ್ಠ ಅಥವಾ ಕನಿಷ್ಠ ಎರಡು ಮೌಲ್ಯಗಳನ್ನು ಕಂಡುಹಿಡಿಯಲು ನಿಮಗೆ ಅನುವು ಮಾಡಿಕೊಡುತ್ತದೆ.
//!
//! ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ, ಪಟ್ಟಿಯಲ್ಲಿರುವ ಪ್ರತಿಯೊಂದು ಐಟಂನ ಆಯಾ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) ಆಗಿರುವ ಸಮಾನತೆಯ ಹೋಲಿಕೆಗಳಿಗಾಗಿ Trait.
///
/// ಈ trait ಭಾಗಶಃ ಸಮಾನತೆಯನ್ನು ಅನುಮತಿಸುತ್ತದೆ, ಪೂರ್ಣ ಸಮಾನ ಸಂಬಂಧವನ್ನು ಹೊಂದಿರದ ಪ್ರಕಾರಗಳಿಗೆ.
/// ಉದಾಹರಣೆಗೆ, ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಸಂಖ್ಯೆಗಳಲ್ಲಿ `NaN != NaN`, ಆದ್ದರಿಂದ ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಪ್ರಕಾರಗಳು `PartialEq` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತವೆ ಆದರೆ [`trait@Eq`] ಅಲ್ಲ.
///
/// Ly ಪಚಾರಿಕವಾಗಿ, ಸಮಾನತೆಯು ಇರಬೇಕು (ಎಲ್ಲಾ `a`, `b`, `A` ಪ್ರಕಾರದ `A`, `B`, `C`):
///
/// - **ಸಮ್ಮಿತೀಯ**: `A: PartialEq<B>` ಮತ್ತು `B: PartialEq<A>` ಆಗಿದ್ದರೆ,**`a==b` ಎಂದರೆ`b==a`**;ಮತ್ತು
///
/// - **ಪರಿವರ್ತಕ**: `A: PartialEq<B>` ಮತ್ತು `B: PartialEq<C>` ಮತ್ತು `A:
///   ಭಾಗಶಃ ಎಕ್<C>`, ನಂತರ **` a==b`ಮತ್ತು `b == c` a==c`** ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ.
///
/// `B: PartialEq<A>` (symmetric) ಮತ್ತು `A: PartialEq<C>` (transitive) impls ಅಸ್ತಿತ್ವದಲ್ಲಿರಲು ಒತ್ತಾಯಿಸುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಆದರೆ ಈ ಅವಶ್ಯಕತೆಗಳು ಅಸ್ತಿತ್ವದಲ್ಲಿದ್ದಾಗಲೆಲ್ಲಾ ಅವು ಅನ್ವಯಿಸುತ್ತವೆ.
///
/// ## Derivable
///
/// ಈ trait ಅನ್ನು `#[derive]` ನೊಂದಿಗೆ ಬಳಸಬಹುದು.ಸ್ಟ್ರಕ್ಟ್‌ಗಳಲ್ಲಿ `ವ್ಯುತ್ಪನ್ನಗೊಳಿಸಿದಾಗ, ಎಲ್ಲಾ ಕ್ಷೇತ್ರಗಳು ಸಮಾನವಾಗಿದ್ದರೆ ಎರಡು ನಿದರ್ಶನಗಳು ಸಮಾನವಾಗಿರುತ್ತದೆ ಮತ್ತು ಯಾವುದೇ ಕ್ಷೇತ್ರಗಳು ಸಮಾನವಾಗಿಲ್ಲದಿದ್ದರೆ ಸಮಾನವಾಗಿರುವುದಿಲ್ಲ.ಎನುಮ್‌ಗಳಲ್ಲಿ`ವ್ಯುತ್ಪನ್ನಗೊಳಿಸಿದಾಗ, ಪ್ರತಿಯೊಂದು ರೂಪಾಂತರವು ತನಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ ಮತ್ತು ಇತರ ರೂಪಾಂತರಗಳಿಗೆ ಸಮನಾಗಿರುವುದಿಲ್ಲ.
///
/// ## `PartialEq` ಅನ್ನು ನಾನು ಹೇಗೆ ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು?
///
/// `PartialEq` [`eq`] ವಿಧಾನವನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ಮಾತ್ರ ಅಗತ್ಯವಿದೆ;[`ne`] ಅನ್ನು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ ಅದರ ಪರಿಭಾಷೆಯಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿದೆ.[`ne`] * ನ ಯಾವುದೇ ಹಸ್ತಚಾಲಿತ ಅನುಷ್ಠಾನವು [`eq`] ಎಂಬುದು [`ne`] ನ ಕಟ್ಟುನಿಟ್ಟಾದ ವಿಲೋಮ ಎಂಬ ನಿಯಮವನ್ನು ಗೌರವಿಸಬೇಕು;ಅಂದರೆ, `!(a == b)` ವೇಳೆ ಮತ್ತು `a != b` ಆಗಿದ್ದರೆ ಮಾತ್ರ.
///
/// `PartialEq`, [`PartialOrd`], ಮತ್ತು [`Ord`]*ನ ಅನುಷ್ಠಾನಗಳು* ಪರಸ್ಪರ ಒಪ್ಪಿಕೊಳ್ಳಬೇಕು.ಕೆಲವು traits ಅನ್ನು ಪಡೆದುಕೊಳ್ಳುವ ಮೂಲಕ ಮತ್ತು ಇತರರನ್ನು ಹಸ್ತಚಾಲಿತವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸುವ ಮೂಲಕ ಆಕಸ್ಮಿಕವಾಗಿ ಅವರನ್ನು ಒಪ್ಪುವುದಿಲ್ಲ.
///
/// ಡೊಮೇನ್‌ಗಾಗಿ ಉದಾಹರಣೆ ಅನುಷ್ಠಾನ, ಇದರಲ್ಲಿ ಎರಡು ಪುಸ್ತಕಗಳು ಅವುಗಳ ಐಎಸ್‌ಬಿಎನ್ ಹೊಂದಿಕೆಯಾದರೆ ಒಂದೇ ಸ್ವರೂಪವೆಂದು ಪರಿಗಣಿಸಲಾಗುತ್ತದೆ, ಸ್ವರೂಪಗಳು ಭಿನ್ನವಾಗಿದ್ದರೂ ಸಹ:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## ಎರಡು ವಿಭಿನ್ನ ಪ್ರಕಾರಗಳನ್ನು ನಾನು ಹೇಗೆ ಹೋಲಿಸಬಹುದು?
///
/// ನೀವು ಹೋಲಿಸಬಹುದಾದ ಪ್ರಕಾರವನ್ನು `ಭಾಗಶಃ ಎಕ್` ಪ್ರಕಾರದ ನಿಯತಾಂಕದಿಂದ ನಿಯಂತ್ರಿಸಲಾಗುತ್ತದೆ.
/// ಉದಾಹರಣೆಗೆ, ನಮ್ಮ ಹಿಂದಿನ ಕೋಡ್ ಅನ್ನು ಸ್ವಲ್ಪ ತಿರುಚೋಣ:
///
/// ```
/// // ವ್ಯುತ್ಪನ್ನ ಸಾಧನಗಳು<BookFormat>==<BookFormat>ಹೋಲಿಕೆಗಳು
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // ಕಾರ್ಯಗತಗೊಳಿಸಿ<Book>==<BookFormat>ಹೋಲಿಕೆಗಳು
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // ಕಾರ್ಯಗತಗೊಳಿಸಿ<BookFormat>==<Book>ಹೋಲಿಕೆಗಳು
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// `impl PartialEq for Book` ಅನ್ನು `impl PartialEq<BookFormat> for Book` ಗೆ ಬದಲಾಯಿಸುವ ಮೂಲಕ, `ಬುಕ್‌ಫಾರ್ಮ್ಯಾಟ್‌ಗಳನ್ನು` ಪುಸ್ತಕಗಳೊಂದಿಗೆ ಹೋಲಿಸಲು ನಾವು ಅನುಮತಿಸುತ್ತೇವೆ.
///
/// ಸ್ಟ್ರಕ್ಟ್‌ನ ಕೆಲವು ಕ್ಷೇತ್ರಗಳನ್ನು ನಿರ್ಲಕ್ಷಿಸುವ ಮೇಲಿನ ಹೋಲಿಕೆ ಅಪಾಯಕಾರಿ.ಭಾಗಶಃ ಸಮಾನ ಸಂಬಂಧದ ಅವಶ್ಯಕತೆಗಳ ಅನಪೇಕ್ಷಿತ ಉಲ್ಲಂಘನೆಗೆ ಇದು ಸುಲಭವಾಗಿ ಕಾರಣವಾಗಬಹುದು.
/// ಉದಾಹರಣೆಗೆ, ನಾವು `PartialEq<Book>` ನ ಮೇಲಿನ ಅನುಷ್ಠಾನವನ್ನು `BookFormat` ಗಾಗಿ ಇಟ್ಟುಕೊಂಡಿದ್ದರೆ ಮತ್ತು `Book` ಗಾಗಿ `PartialEq<Book>` ನ ಅನುಷ್ಠಾನವನ್ನು ಸೇರಿಸಿದರೆ (`#[derive]` ಮೂಲಕ ಅಥವಾ ಮೊದಲ ಉದಾಹರಣೆಯಿಂದ ಹಸ್ತಚಾಲಿತ ಅನುಷ್ಠಾನದ ಮೂಲಕ) ಆಗ ಫಲಿತಾಂಶವು ಸಂವಹನವನ್ನು ಉಲ್ಲಂಘಿಸುತ್ತದೆ:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// ಈ ವಿಧಾನವು `self` ಮತ್ತು `other` ಮೌಲ್ಯಗಳನ್ನು ಸಮನಾಗಿರಬೇಕೆಂದು ಪರೀಕ್ಷಿಸುತ್ತದೆ, ಮತ್ತು ಇದನ್ನು `==` ಬಳಸುತ್ತದೆ.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// ಈ ವಿಧಾನವು `!=` ಗಾಗಿ ಪರೀಕ್ಷಿಸುತ್ತದೆ.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// trait `PartialEq` ನ ಇಂಪಲ್ ಅನ್ನು ಉತ್ಪಾದಿಸುವ ಮ್ಯಾಕ್ರೋ ಅನ್ನು ಪಡೆಯಿರಿ.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) ಆಗಿರುವ ಸಮಾನತೆಯ ಹೋಲಿಕೆಗಳಿಗಾಗಿ Trait.
///
/// ಇದರರ್ಥ, `a == b` ಮತ್ತು `a != b` ಕಟ್ಟುನಿಟ್ಟಾದ ವಿಲೋಮಗಳ ಜೊತೆಗೆ, ಸಮಾನತೆಯು ಇರಬೇಕು (ಎಲ್ಲಾ `a`, `b` ಮತ್ತು `c` ಗೆ):
///
/// - reflexive: `a == a`;
/// - ಸಮ್ಮಿತೀಯ: `a == b` `b == a` ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ;ಮತ್ತು
/// - ಅಸ್ಥಿರ: `a == b` ಮತ್ತು `b == c` `a == c` ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ.
///
/// ಈ ಆಸ್ತಿಯನ್ನು ಕಂಪೈಲರ್ ಪರಿಶೀಲಿಸಲಾಗುವುದಿಲ್ಲ, ಮತ್ತು ಆದ್ದರಿಂದ `Eq` [`PartialEq`] ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ ಮತ್ತು ಯಾವುದೇ ಹೆಚ್ಚುವರಿ ವಿಧಾನಗಳನ್ನು ಹೊಂದಿಲ್ಲ.
///
/// ## Derivable
///
/// ಈ trait ಅನ್ನು `#[derive]` ನೊಂದಿಗೆ ಬಳಸಬಹುದು.
/// `ವ್ಯುತ್ಪನ್ನಗೊಳಿಸಿದಾಗ, `Eq` ಗೆ ಯಾವುದೇ ಹೆಚ್ಚುವರಿ ವಿಧಾನಗಳಿಲ್ಲದ ಕಾರಣ, ಇದು ಭಾಗಶಃ ಸಮಾನ ಸಂಬಂಧಕ್ಕಿಂತ ಹೆಚ್ಚಾಗಿ ಇದು ಸಮಾನ ಸಂಬಂಧ ಎಂದು ಕಂಪೈಲರ್‌ಗೆ ತಿಳಿಸುತ್ತಿದೆ.
///
/// `derive` ಕಾರ್ಯತಂತ್ರಕ್ಕೆ ಎಲ್ಲಾ ಕ್ಷೇತ್ರಗಳು `Eq` ಆಗಿರಬೇಕು ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಅದು ಯಾವಾಗಲೂ ಅಪೇಕ್ಷಿಸುವುದಿಲ್ಲ.
///
/// ## `Eq` ಅನ್ನು ನಾನು ಹೇಗೆ ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು?
///
/// ನಿಮಗೆ `derive` ತಂತ್ರವನ್ನು ಬಳಸಲು ಸಾಧ್ಯವಾಗದಿದ್ದರೆ, ನಿಮ್ಮ ಪ್ರಕಾರವು `Eq` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ ಎಂದು ಸೂಚಿಸಿ, ಅದು ಯಾವುದೇ ವಿಧಾನಗಳನ್ನು ಹೊಂದಿಲ್ಲ:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // ಈ ವಿಧಾನವನ್ನು ಕೇವಲ#[ವ್ಯುತ್ಪನ್ನ] ಮೂಲಕ ಬಳಸಲಾಗುತ್ತದೆ, ಒಂದು ಪ್ರಕಾರದ ಪ್ರತಿಯೊಂದು ಘಟಕವು ಸ್ವತಃ [[ಪಡೆಯುವುದು], ಪ್ರಸ್ತುತ ಪಡೆಯುವ ಮೂಲಸೌಕರ್ಯ ಎಂದರೆ ಈ trait ನಲ್ಲಿ ಒಂದು ವಿಧಾನವನ್ನು ಬಳಸದೆ ಈ ಪ್ರತಿಪಾದನೆಯನ್ನು ಮಾಡುವುದು ಅಸಾಧ್ಯ.
    //
    //
    // ಇದನ್ನು ಎಂದಿಗೂ ಕೈಯಿಂದ ಕಾರ್ಯಗತಗೊಳಿಸಬಾರದು.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// trait `Eq` ನ ಇಂಪಲ್ ಅನ್ನು ಉತ್ಪಾದಿಸುವ ಮ್ಯಾಕ್ರೋ ಅನ್ನು ಪಡೆಯಿರಿ.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: ಈ ರಚನೆಯನ್ನು ಕೇವಲ#[ವ್ಯುತ್ಪನ್ನ] ಗೆ ಬಳಸಲಾಗುತ್ತದೆ
// ಒಂದು ಪ್ರಕಾರದ ಪ್ರತಿಯೊಂದು ಘಟಕವು ಇಕ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ ಎಂದು ಪ್ರತಿಪಾದಿಸಿ.
//
// ಈ ರಚನೆಯು ಬಳಕೆದಾರ ಕೋಡ್‌ನಲ್ಲಿ ಎಂದಿಗೂ ಕಾಣಿಸಿಕೊಳ್ಳಬಾರದು.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Ordering` ಎಂಬುದು ಎರಡು ಮೌಲ್ಯಗಳ ನಡುವಿನ ಹೋಲಿಕೆಯ ಫಲಿತಾಂಶವಾಗಿದೆ.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// ಹೋಲಿಸಿದ ಮೌಲ್ಯವು ಇನ್ನೊಂದಕ್ಕಿಂತ ಕಡಿಮೆ ಇರುವ ಆದೇಶ.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// ಹೋಲಿಸಿದ ಮೌಲ್ಯವು ಇನ್ನೊಂದಕ್ಕೆ ಸಮನಾಗಿರುವ ಆದೇಶ.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// ಹೋಲಿಸಿದ ಮೌಲ್ಯವು ಇನ್ನೊಂದಕ್ಕಿಂತ ಹೆಚ್ಚಿರುವ ಆದೇಶ.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// ಆದೇಶವು `Equal` ರೂಪಾಂತರವಾಗಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// ಆದೇಶವು `Equal` ರೂಪಾಂತರವಲ್ಲದಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// ಆದೇಶವು `Less` ರೂಪಾಂತರವಾಗಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// ಆದೇಶವು `Greater` ರೂಪಾಂತರವಾಗಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// ಆದೇಶವು `Less` ಅಥವಾ `Equal` ರೂಪಾಂತರವಾಗಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// ಆದೇಶವು `Greater` ಅಥವಾ `Equal` ರೂಪಾಂತರವಾಗಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// `Ordering` ಅನ್ನು ಹಿಮ್ಮುಖಗೊಳಿಸುತ್ತದೆ.
    ///
    /// * `Less` `Greater` ಆಗುತ್ತದೆ.
    /// * `Greater` `Less` ಆಗುತ್ತದೆ.
    /// * `Equal` `Equal` ಆಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ನಡವಳಿಕೆ:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// ಹೋಲಿಕೆಯನ್ನು ಹಿಮ್ಮುಖಗೊಳಿಸಲು ಈ ವಿಧಾನವನ್ನು ಬಳಸಬಹುದು:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // ಶ್ರೇಣಿಯನ್ನು ದೊಡ್ಡದರಿಂದ ಚಿಕ್ಕದಕ್ಕೆ ವಿಂಗಡಿಸಿ.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// ಸರಪಳಿಗಳು ಎರಡು ಆದೇಶಗಳು.
    ///
    /// `Equal` ಅಲ್ಲದಿದ್ದಾಗ `self` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.ಇಲ್ಲದಿದ್ದರೆ `other` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// ಕೊಟ್ಟಿರುವ ಕಾರ್ಯದೊಂದಿಗೆ ಆದೇಶವನ್ನು ಸರಪಳಿ ಮಾಡುತ್ತದೆ.
    ///
    /// `Equal` ಇಲ್ಲದಿದ್ದಾಗ `self` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಇಲ್ಲದಿದ್ದರೆ `f` ಗೆ ಕರೆ ಮಾಡಿ ಫಲಿತಾಂಶವನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// ರಿವರ್ಸ್ ಆದೇಶಕ್ಕಾಗಿ ಸಹಾಯಕ ರಚನೆ.
///
/// ಈ ರಚನೆಯು [`Vec::sort_by_key`] ನಂತಹ ಕಾರ್ಯಗಳೊಂದಿಗೆ ಬಳಸಲು ಸಹಾಯಕವಾಗಿದೆ ಮತ್ತು ಕೀಲಿಯ ಒಂದು ಭಾಗವನ್ನು ರಿವರ್ಸ್ ಆರ್ಡರ್ ಮಾಡಲು ಬಳಸಬಹುದು.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// [total order](https://en.wikipedia.org/wiki/Total_order) ಅನ್ನು ರೂಪಿಸುವ ಪ್ರಕಾರಗಳಿಗಾಗಿ Trait.
///
/// ಆದೇಶವು ಒಟ್ಟು ಆದೇಶವಾಗಿದ್ದರೆ (ಎಲ್ಲಾ `a`, `b` ಮತ್ತು `c` ಗೆ):
///
/// - ಒಟ್ಟು ಮತ್ತು ಅಸಮ್ಮಿತ: ನಿಖರವಾಗಿ `a < b`, `a == b` ಅಥವಾ `a > b` ನಲ್ಲಿ ಒಂದು ನಿಜ;ಮತ್ತು
/// - ಅಸ್ಥಿರ, `a < b` ಮತ್ತು `b < c` `a < c` ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ.`==` ಮತ್ತು `>` ಎರಡಕ್ಕೂ ಅದೇ ಹಿಡಿದಿರಬೇಕು.
///
/// ## Derivable
///
/// ಈ trait ಅನ್ನು `#[derive]` ನೊಂದಿಗೆ ಬಳಸಬಹುದು.
/// ಸ್ಟ್ರಕ್ಟ್‌ಗಳಲ್ಲಿ `ಡಿರೈವ್` ಮಾಡಿದಾಗ, ಇದು ಸ್ಟ್ರಕ್ಟ್‌ನ ಸದಸ್ಯರ ಮೇಲಿನಿಂದ ಕೆಳಕ್ಕೆ ಘೋಷಣೆಯ ಆದೇಶದ ಆಧಾರದ ಮೇಲೆ [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) ಆದೇಶವನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ.
///
/// ಎನಮ್‌ಗಳಲ್ಲಿ `ವ್ಯುತ್ಪನ್ನಗೊಳಿಸಿದಾಗ, ರೂಪಾಂತರಗಳನ್ನು ಅವುಗಳ ಮೇಲಿನಿಂದ ಕೆಳಕ್ಕೆ ತಾರತಮ್ಯದ ಆದೇಶದಿಂದ ಆದೇಶಿಸಲಾಗುತ್ತದೆ.
///
/// ## ಲೆಕ್ಸಿಕೋಗ್ರಾಫಿಕಲ್ ಹೋಲಿಕೆ
///
/// ಲೆಕ್ಸಿಕೋಗ್ರಾಫಿಕಲ್ ಹೋಲಿಕೆ ಈ ಕೆಳಗಿನ ಗುಣಲಕ್ಷಣಗಳೊಂದಿಗೆ ಒಂದು ಕಾರ್ಯಾಚರಣೆಯಾಗಿದೆ:
///  - ಎರಡು ಅನುಕ್ರಮಗಳನ್ನು ಅಂಶದಿಂದ ಅಂಶಕ್ಕೆ ಹೋಲಿಸಲಾಗುತ್ತದೆ.
///  - ಮೊದಲ ಹೊಂದಿಕೆಯಾಗದ ಅಂಶವು ಯಾವ ಅನುಕ್ರಮವು ಇತರಕ್ಕಿಂತ ಕಡಿಮೆ ಅಥವಾ ಹೆಚ್ಚಿನದಾಗಿದೆ ಎಂಬುದನ್ನು ವ್ಯಾಖ್ಯಾನಿಸುತ್ತದೆ.
///  - ಒಂದು ಅನುಕ್ರಮವು ಇನ್ನೊಂದರ ಪೂರ್ವಪ್ರತ್ಯಯವಾಗಿದ್ದರೆ, ಕಡಿಮೆ ಅನುಕ್ರಮವು ಇನ್ನೊಂದಕ್ಕಿಂತ ಶಬ್ದಕೋಶಶಾಸ್ತ್ರೀಯವಾಗಿ ಕಡಿಮೆ ಇರುತ್ತದೆ.
///  - ಎರಡು ಅನುಕ್ರಮಗಳು ಸಮಾನ ಅಂಶಗಳನ್ನು ಹೊಂದಿದ್ದರೆ ಮತ್ತು ಒಂದೇ ಉದ್ದವನ್ನು ಹೊಂದಿದ್ದರೆ, ನಂತರ ಅನುಕ್ರಮಗಳು ನಿಘಂಟುಶಾಸ್ತ್ರೀಯವಾಗಿ ಸಮಾನವಾಗಿರುತ್ತದೆ.
///  - ಖಾಲಿ ಅನುಕ್ರಮವು ಯಾವುದೇ ಖಾಲಿ ಅಲ್ಲದ ಅನುಕ್ರಮಕ್ಕಿಂತ ನಿಘಂಟುಶಾಸ್ತ್ರೀಯವಾಗಿ ಕಡಿಮೆ.
///  - ಎರಡು ಖಾಲಿ ಅನುಕ್ರಮಗಳು ನಿಘಂಟುಶಾಸ್ತ್ರೀಯವಾಗಿ ಸಮಾನವಾಗಿವೆ.
///
/// ## `Ord` ಅನ್ನು ನಾನು ಹೇಗೆ ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು?
///
/// `Ord` ಪ್ರಕಾರವು [`PartialOrd`] ಮತ್ತು [`Eq`] ಆಗಿರಬೇಕು (ಇದಕ್ಕೆ [`PartialEq`] ಅಗತ್ಯವಿದೆ).
///
/// ನಂತರ ನೀವು [`cmp`] ಗಾಗಿ ಅನುಷ್ಠಾನವನ್ನು ವ್ಯಾಖ್ಯಾನಿಸಬೇಕು.ನಿಮ್ಮ ಪ್ರಕಾರದ ಕ್ಷೇತ್ರಗಳಲ್ಲಿ [`cmp`] ಅನ್ನು ಬಳಸುವುದು ನಿಮಗೆ ಉಪಯುಕ್ತವಾಗಿದೆ.
///
/// [`PartialEq`], [`PartialOrd`], ಮತ್ತು `Ord`*ನ ಅನುಷ್ಠಾನಗಳು* ಪರಸ್ಪರ ಒಪ್ಪಿಕೊಳ್ಳಬೇಕು.
/// ಅಂದರೆ, ಎಲ್ಲಾ `a` ಮತ್ತು `b` ಗಾಗಿ `a == b` ಮತ್ತು `Some(a.cmp(b)) == a.partial_cmp(b)` ಇದ್ದರೆ ಮಾತ್ರ.
/// ಕೆಲವು traits ಅನ್ನು ಪಡೆದುಕೊಳ್ಳುವ ಮೂಲಕ ಮತ್ತು ಇತರರನ್ನು ಹಸ್ತಚಾಲಿತವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸುವ ಮೂಲಕ ಆಕಸ್ಮಿಕವಾಗಿ ಅವರನ್ನು ಒಪ್ಪುವುದಿಲ್ಲ.
///
/// `id` ಮತ್ತು `name` ಅನ್ನು ಕಡೆಗಣಿಸಿ ಜನರನ್ನು ಎತ್ತರದಿಂದ ಮಾತ್ರ ವಿಂಗಡಿಸಲು ನೀವು ಬಯಸುವ ಉದಾಹರಣೆ ಇಲ್ಲಿದೆ:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// ಈ ವಿಧಾನವು `self` ಮತ್ತು `other` ನಡುವೆ [`Ordering`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಸಮಾವೇಶದ ಪ್ರಕಾರ, `self.cmp(&other)` ನಿಜವಾಗಿದ್ದರೆ `self <operator> other` ಅಭಿವ್ಯಕ್ತಿಗೆ ಹೊಂದಿಕೆಯಾಗುವ ಆದೇಶವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// ಗರಿಷ್ಠ ಎರಡು ಮೌಲ್ಯಗಳನ್ನು ಹೋಲಿಸುತ್ತದೆ ಮತ್ತು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಹೋಲಿಕೆ ಅವುಗಳನ್ನು ಸಮಾನವೆಂದು ನಿರ್ಧರಿಸಿದರೆ ಎರಡನೇ ವಾದವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// ಕನಿಷ್ಠ ಎರಡು ಮೌಲ್ಯಗಳನ್ನು ಹೋಲಿಸುತ್ತದೆ ಮತ್ತು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಹೋಲಿಕೆ ಅವುಗಳನ್ನು ಸಮಾನವೆಂದು ನಿರ್ಧರಿಸಿದರೆ ಮೊದಲ ವಾದವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// ಮೌಲ್ಯವನ್ನು ನಿರ್ದಿಷ್ಟ ಮಧ್ಯಂತರಕ್ಕೆ ನಿರ್ಬಂಧಿಸಿ.
    ///
    /// `self` `max` ಗಿಂತ ಹೆಚ್ಚಿದ್ದರೆ `max` ಮತ್ತು `self` `min` ಗಿಂತ ಕಡಿಮೆಯಿದ್ದರೆ `min` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಇಲ್ಲದಿದ್ದರೆ ಇದು `self` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// `min > max` ವೇಳೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// trait `Ord` ನ ಇಂಪಲ್ ಅನ್ನು ಉತ್ಪಾದಿಸುವ ಮ್ಯಾಕ್ರೋ ಅನ್ನು ಪಡೆಯಿರಿ.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// ವಿಂಗಡಣೆ-ಆದೇಶಕ್ಕಾಗಿ ಹೋಲಿಸಬಹುದಾದ ಮೌಲ್ಯಗಳಿಗಾಗಿ Trait.
///
/// ಎಲ್ಲಾ `a`, `b` ಮತ್ತು `c` ಗೆ ಹೋಲಿಕೆ ಪೂರೈಸಬೇಕು:
///
/// - ಅಸಿಮ್ಮೆಟ್ರಿ: `a < b` ಆಗಿದ್ದರೆ `!(a > b)`, ಹಾಗೆಯೇ `!(a < b)` `!(a < b)` ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ;ಮತ್ತು
/// - ಸಂವಹನ: `a < b` ಮತ್ತು `b < c` `a < c` ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ.`==` ಮತ್ತು `>` ಎರಡಕ್ಕೂ ಅದೇ ಹಿಡಿದಿರಬೇಕು.
///
/// ಈ ಅವಶ್ಯಕತೆಗಳು trait ಅನ್ನು ಸಮ್ಮಿತೀಯವಾಗಿ ಮತ್ತು ಪರಿವರ್ತಕವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸಬೇಕು ಎಂದು ಗಮನಿಸಿ: `T: PartialOrd<U>` ಮತ್ತು `U: PartialOrd<V>` ಆಗಿದ್ದರೆ `U: PartialOrd<T>` ಮತ್ತು `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// ಈ trait ಅನ್ನು `#[derive]` ನೊಂದಿಗೆ ಬಳಸಬಹುದು.ರಚನೆಗಳ ಮೇಲೆ `ಪಡೆದಾಗ, ಅದು ರಚನೆಯ ಸದಸ್ಯರ ಮೇಲಿನಿಂದ ಕೆಳಕ್ಕೆ ಘೋಷಣೆಯ ಆದೇಶದ ಆಧಾರದ ಮೇಲೆ ಒಂದು ನಿಘಂಟು ಆದೇಶವನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ.
/// ಎನಮ್‌ಗಳಲ್ಲಿ `ವ್ಯುತ್ಪನ್ನಗೊಳಿಸಿದಾಗ, ರೂಪಾಂತರಗಳನ್ನು ಅವುಗಳ ಮೇಲಿನಿಂದ ಕೆಳಕ್ಕೆ ತಾರತಮ್ಯದ ಆದೇಶದಿಂದ ಆದೇಶಿಸಲಾಗುತ್ತದೆ.
///
/// ## `PartialOrd` ಅನ್ನು ನಾನು ಹೇಗೆ ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು?
///
/// `PartialOrd` [`partial_cmp`] ವಿಧಾನದ ಅನುಷ್ಠಾನಕ್ಕೆ ಮಾತ್ರ ಅಗತ್ಯವಿರುತ್ತದೆ, ಇತರವು ಡೀಫಾಲ್ಟ್ ಅನುಷ್ಠಾನಗಳಿಂದ ಉತ್ಪತ್ತಿಯಾಗುತ್ತದೆ.
///
/// ಆದಾಗ್ಯೂ ಒಟ್ಟು ಕ್ರಮವನ್ನು ಹೊಂದಿರದ ಪ್ರಕಾರಗಳಿಗಾಗಿ ಇತರರನ್ನು ಪ್ರತ್ಯೇಕವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸಲು ಸಾಧ್ಯವಿದೆ.
/// ಉದಾಹರಣೆಗೆ, ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಸಂಖ್ಯೆಗಳಿಗೆ, `NaN < 0 == false` ಮತ್ತು `NaN >= 0 == false` (cf.
/// ಐಇಇಇ 754-2008 ವಿಭಾಗ 5.11).
///
/// `PartialOrd` ನಿಮ್ಮ ಪ್ರಕಾರವು [`PartialEq`] ಆಗಿರಬೇಕು.
///
/// [`PartialEq`], `PartialOrd`, ಮತ್ತು [`Ord`]*ನ ಅನುಷ್ಠಾನಗಳು* ಪರಸ್ಪರ ಒಪ್ಪಿಕೊಳ್ಳಬೇಕು.
/// ಕೆಲವು traits ಅನ್ನು ಪಡೆದುಕೊಳ್ಳುವ ಮೂಲಕ ಮತ್ತು ಇತರರನ್ನು ಹಸ್ತಚಾಲಿತವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸುವ ಮೂಲಕ ಆಕಸ್ಮಿಕವಾಗಿ ಅವರನ್ನು ಒಪ್ಪುವುದಿಲ್ಲ.
///
/// ನಿಮ್ಮ ಪ್ರಕಾರವು [`Ord`] ಆಗಿದ್ದರೆ, ನೀವು [`cmp`] ಅನ್ನು ಬಳಸಿಕೊಂಡು [`partial_cmp`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// ನಿಮ್ಮ ಪ್ರಕಾರದ ಕ್ಷೇತ್ರಗಳಲ್ಲಿ [`partial_cmp`] ಅನ್ನು ಬಳಸುವುದು ಸಹ ನಿಮಗೆ ಉಪಯುಕ್ತವಾಗಿದೆ.
/// ಫ್ಲೋಟಿಂಗ್-ಪಾಯಿಂಟ್ `height` ಕ್ಷೇತ್ರವನ್ನು ಹೊಂದಿರುವ `Person` ಪ್ರಕಾರಗಳ ಉದಾಹರಣೆ ಇಲ್ಲಿದೆ, ಅದು ವಿಂಗಡಿಸಲು ಬಳಸಬೇಕಾದ ಏಕೈಕ ಕ್ಷೇತ್ರವಾಗಿದೆ:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// ಈ ವಿಧಾನವು ಅಸ್ತಿತ್ವದಲ್ಲಿದ್ದರೆ `self` ಮತ್ತು `other` ಮೌಲ್ಯಗಳ ನಡುವೆ ಆದೇಶವನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// ಹೋಲಿಕೆ ಅಸಾಧ್ಯವಾದಾಗ:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// ಈ ವಿಧಾನವು (`self` ಮತ್ತು `other` ಗಾಗಿ) ಕಡಿಮೆ ಪರೀಕ್ಷಿಸುತ್ತದೆ ಮತ್ತು ಇದನ್ನು `<` ಆಪರೇಟರ್ ಬಳಸುತ್ತಾರೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// ಈ ವಿಧಾನವು (`self` ಮತ್ತು `other` ಗಾಗಿ) ಕಡಿಮೆ ಅಥವಾ ಸಮನಾಗಿರುತ್ತದೆ ಮತ್ತು ಇದನ್ನು `<=` ಆಪರೇಟರ್ ಬಳಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// ಈ ವಿಧಾನವು (`self` ಮತ್ತು `other` ಗಾಗಿ) ಗಿಂತ ಹೆಚ್ಚಿನದನ್ನು ಪರೀಕ್ಷಿಸುತ್ತದೆ ಮತ್ತು ಇದನ್ನು `>` ಆಪರೇಟರ್ ಬಳಸುತ್ತಾರೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// ಈ ವಿಧಾನವು (`self` ಮತ್ತು `other` ಗಾಗಿ) ಹೆಚ್ಚು ಅಥವಾ ಸಮನಾಗಿರುತ್ತದೆ ಮತ್ತು ಇದನ್ನು `>=` ಆಪರೇಟರ್ ಬಳಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// trait `PartialOrd` ನ ಇಂಪಲ್ ಅನ್ನು ಉತ್ಪಾದಿಸುವ ಮ್ಯಾಕ್ರೋ ಅನ್ನು ಪಡೆಯಿರಿ.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// ಕನಿಷ್ಠ ಎರಡು ಮೌಲ್ಯಗಳನ್ನು ಹೋಲಿಸುತ್ತದೆ ಮತ್ತು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
///
/// ಹೋಲಿಕೆ ಅವುಗಳನ್ನು ಸಮಾನವೆಂದು ನಿರ್ಧರಿಸಿದರೆ ಮೊದಲ ವಾದವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
///
/// ಆಂತರಿಕವಾಗಿ [`Ord::min`] ಗೆ ಅಲಿಯಾಸ್ ಅನ್ನು ಬಳಸುತ್ತದೆ.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಹೋಲಿಕೆ ಕಾರ್ಯಕ್ಕೆ ಸಂಬಂಧಿಸಿದಂತೆ ಕನಿಷ್ಠ ಎರಡು ಮೌಲ್ಯಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
///
/// ಹೋಲಿಕೆ ಅವುಗಳನ್ನು ಸಮಾನವೆಂದು ನಿರ್ಧರಿಸಿದರೆ ಮೊದಲ ವಾದವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಕಾರ್ಯದಿಂದ ಕನಿಷ್ಠ ಮೌಲ್ಯವನ್ನು ನೀಡುವ ಅಂಶವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
///
/// ಹೋಲಿಕೆ ಅವುಗಳನ್ನು ಸಮಾನವೆಂದು ನಿರ್ಧರಿಸಿದರೆ ಮೊದಲ ವಾದವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// ಗರಿಷ್ಠ ಎರಡು ಮೌಲ್ಯಗಳನ್ನು ಹೋಲಿಸುತ್ತದೆ ಮತ್ತು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
///
/// ಹೋಲಿಕೆ ಅವುಗಳನ್ನು ಸಮಾನವೆಂದು ನಿರ್ಧರಿಸಿದರೆ ಎರಡನೇ ವಾದವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
///
/// ಆಂತರಿಕವಾಗಿ [`Ord::max`] ಗೆ ಅಲಿಯಾಸ್ ಅನ್ನು ಬಳಸುತ್ತದೆ.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಹೋಲಿಕೆ ಕಾರ್ಯಕ್ಕೆ ಸಂಬಂಧಿಸಿದಂತೆ ಗರಿಷ್ಠ ಎರಡು ಮೌಲ್ಯಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
///
/// ಹೋಲಿಕೆ ಅವುಗಳನ್ನು ಸಮಾನವೆಂದು ನಿರ್ಧರಿಸಿದರೆ ಎರಡನೇ ವಾದವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಕಾರ್ಯದಿಂದ ಗರಿಷ್ಠ ಮೌಲ್ಯವನ್ನು ನೀಡುವ ಅಂಶವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
///
/// ಹೋಲಿಕೆ ಅವುಗಳನ್ನು ಸಮಾನವೆಂದು ನಿರ್ಧರಿಸಿದರೆ ಎರಡನೇ ವಾದವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// ಪ್ರಾಚೀನ ಪ್ರಕಾರಗಳಿಗೆ ಭಾಗಶಃ ಎಕ್, ಇಕ್, ಭಾಗಶಃ ಆರ್ಡ್ ಮತ್ತು ಆರ್ಡ್ ಅನುಷ್ಠಾನ
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // ಹೆಚ್ಚು ಸೂಕ್ತವಾದ ಜೋಡಣೆಯನ್ನು ಉತ್ಪಾದಿಸಲು ಇಲ್ಲಿ ಆದೇಶವು ಮುಖ್ಯವಾಗಿದೆ.
                    // ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ <https://github.com/rust-lang/rust/issues/63758> ನೋಡಿ.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // ಐ 8 ಗೆ ಬಿತ್ತರಿಸುವುದು ಮತ್ತು ವ್ಯತ್ಯಾಸವನ್ನು ಆರ್ಡರ್ ಮಾಡುವಂತೆ ಪರಿವರ್ತಿಸುವುದು ಹೆಚ್ಚು ಸೂಕ್ತವಾದ ಜೋಡಣೆಯನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ.
            //
            // ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ <https://github.com/rust-lang/rust/issues/66780> ನೋಡಿ.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // ಸುರಕ್ಷತೆ: i8 ನಂತೆ bool 0 ಅಥವಾ 1 ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಆದ್ದರಿಂದ ವ್ಯತ್ಯಾಸವು ಬೇರೆ ಯಾವುದೂ ಆಗಿರಬಾರದು
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &ಪಾಯಿಂಟರ್ಸ್

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}