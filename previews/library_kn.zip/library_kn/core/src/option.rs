//! ಐಚ್ al ಿಕ ಮೌಲ್ಯಗಳು.
//!
//! ಟೈಪ್ [`Option`] ಐಚ್ al ಿಕ ಮೌಲ್ಯವನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ: ಪ್ರತಿ [`Option`] [`Some`] ಆಗಿರುತ್ತದೆ ಮತ್ತು ಮೌಲ್ಯವನ್ನು ಅಥವಾ [`None`] ಅನ್ನು ಹೊಂದಿರುತ್ತದೆ ಮತ್ತು ಅದು ಮಾಡುವುದಿಲ್ಲ.
//! [`Option`] Rust ಕೋಡ್‌ನಲ್ಲಿ ಪ್ರಕಾರಗಳು ಬಹಳ ಸಾಮಾನ್ಯವಾಗಿದೆ, ಏಕೆಂದರೆ ಅವುಗಳು ಹಲವಾರು ಉಪಯೋಗಗಳನ್ನು ಹೊಂದಿವೆ:
//!
//! * ಆರಂಭಿಕ ಮೌಲ್ಯಗಳು
//! * ಅವುಗಳ ಸಂಪೂರ್ಣ ಇನ್ಪುಟ್ ವ್ಯಾಪ್ತಿಯಲ್ಲಿ (ಭಾಗಶಃ ಕಾರ್ಯಗಳು) ವ್ಯಾಖ್ಯಾನಿಸದ ಕಾರ್ಯಗಳಿಗಾಗಿ ರಿಟರ್ನ್ ಮೌಲ್ಯಗಳು
//! * ಸರಳ ದೋಷಗಳನ್ನು ವರದಿ ಮಾಡಲು ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸಿ, ಅಲ್ಲಿ [`None`] ಅನ್ನು ದೋಷದಿಂದ ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ
//! * ಐಚ್ al ಿಕ ರಚನೆ ಕ್ಷೇತ್ರಗಳು
//! * ಸಾಲ ಅಥವಾ "taken" ಮಾಡಬಹುದಾದ ಕ್ಷೇತ್ರಗಳನ್ನು ರಚಿಸಿ
//! * ಐಚ್ al ಿಕ ಕಾರ್ಯ ವಾದಗಳು
//! * ಶೂನ್ಯ ಸೂಚಕಗಳು
//! * ಕಷ್ಟಕರ ಸಂದರ್ಭಗಳಿಂದ ವಿಷಯಗಳನ್ನು ವಿನಿಮಯ ಮಾಡಿಕೊಳ್ಳುವುದು
//!
//! [`ಆಯ್ಕೆ`] ಗಳನ್ನು ಸಾಮಾನ್ಯವಾಗಿ ಮೌಲ್ಯದ ಉಪಸ್ಥಿತಿಯನ್ನು ಪ್ರಶ್ನಿಸಲು ಮತ್ತು ಕ್ರಮ ತೆಗೆದುಕೊಳ್ಳಲು ಮಾದರಿಯ ಹೊಂದಾಣಿಕೆಯೊಂದಿಗೆ ಜೋಡಿಸಲಾಗುತ್ತದೆ, ಯಾವಾಗಲೂ [`None`] ಪ್ರಕರಣಕ್ಕೆ ಕಾರಣವಾಗುತ್ತದೆ.
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // ಕಾರ್ಯದ ರಿಟರ್ನ್ ಮೌಲ್ಯವು ಒಂದು ಆಯ್ಕೆಯಾಗಿದೆ
//! let result = divide(2.0, 3.0);
//!
//! // ಮೌಲ್ಯವನ್ನು ಹಿಂಪಡೆಯಲು ಪ್ಯಾಟರ್ನ್ ಹೊಂದಾಣಿಕೆ
//! match result {
//!     // ವಿಭಾಗವು ಮಾನ್ಯವಾಗಿತ್ತು
//!     Some(x) => println!("Result: {}", x),
//!     // ವಿಭಾಗವು ಅಮಾನ್ಯವಾಗಿದೆ
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: `Option` ಅನ್ನು ಸಾಕಷ್ಟು ವಿಧಾನಗಳೊಂದಿಗೆ ಆಚರಣೆಯಲ್ಲಿ ಹೇಗೆ ಬಳಸಲಾಗುತ್ತದೆ ಎಂಬುದನ್ನು ತೋರಿಸಿ
//
//! # ಆಯ್ಕೆಗಳು ಮತ್ತು ಪಾಯಿಂಟರ್‌ಗಳು ("nullable" ಪಾಯಿಂಟರ್‌ಗಳು)
//!
//! Rust ನ ಪಾಯಿಂಟರ್ ಪ್ರಕಾರಗಳು ಯಾವಾಗಲೂ ಮಾನ್ಯವಾದ ಸ್ಥಳಕ್ಕೆ ಸೂಚಿಸಬೇಕು;ಯಾವುದೇ "null" ಉಲ್ಲೇಖಗಳಿಲ್ಲ.ಬದಲಾಗಿ, Rust ಐಚ್ al ಿಕ ಸ್ವಾಮ್ಯದ ಪೆಟ್ಟಿಗೆಯಂತೆ *ಐಚ್ al ಿಕ* ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಹೊಂದಿದೆ, [`ಆಯ್ಕೆ`]`<`[`ಬಾಕ್ಸ್<T>`]`>`.
//!
//! ಕೆಳಗಿನ ಉದಾಹರಣೆಯು [`i32`] ನ ಐಚ್ al ಿಕ ಪೆಟ್ಟಿಗೆಯನ್ನು ರಚಿಸಲು [`Option`] ಅನ್ನು ಬಳಸುತ್ತದೆ.
//! ಆಂತರಿಕ [`i32`] ಮೌಲ್ಯವನ್ನು ಮೊದಲು ಬಳಸಲು, `check_optional` ಕಾರ್ಯವು ಪೆಟ್ಟಿಗೆಗೆ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿದೆಯೆ ಎಂದು ನಿರ್ಧರಿಸಲು ಪ್ಯಾಟರ್ನ್ ಮ್ಯಾಚಿಂಗ್ ಅನ್ನು ಬಳಸಬೇಕಾಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ (ಅಂದರೆ, ಇದು [`Some(...)`][`Some`]) ಅಥವಾ ([`None`]) ಅಲ್ಲ.
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! Rust ಈ ಕೆಳಗಿನ ಪ್ರಕಾರಗಳನ್ನು `T` ಅನ್ನು ಅತ್ಯುತ್ತಮವಾಗಿಸಲು ಖಾತರಿಪಡಿಸುತ್ತದೆ, ಅಂದರೆ [`Option<T>`] `T` ನಂತೆಯೇ ಗಾತ್ರವನ್ನು ಹೊಂದಿರುತ್ತದೆ:
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` ಈ ಪಟ್ಟಿಯಲ್ಲಿರುವ ಪ್ರಕಾರಗಳಲ್ಲಿ ಒಂದನ್ನು ರಚಿಸಿ.
//!
//! ಮೇಲಿನ ಪ್ರಕರಣಗಳಿಗೆ ಸಂಬಂಧಿಸಿದಂತೆ, `T` ನ ಎಲ್ಲಾ ಮಾನ್ಯ ಮೌಲ್ಯಗಳಿಂದ [`mem::transmute`] ಮತ್ತು `Some::<T>(_)` ನಿಂದ `T` ಗೆ [`mem::transmute`] ಮಾಡಬಹುದು (ಆದರೆ `None::<T>` ನಿಂದ `T` ಗೆ ಪರಿವರ್ತಿಸುವುದು ಸ್ಪಷ್ಟೀಕರಿಸದ ನಡವಳಿಕೆ).
//!
//! # Examples
//!
//! [`Option`] ನಲ್ಲಿ ಮೂಲ ಮಾದರಿ ಹೊಂದಾಣಿಕೆ:
//!
//! ```
//! let msg = Some("howdy");
//!
//! // ಒಳಗೊಂಡಿರುವ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಉಲ್ಲೇಖಿಸಿ
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // ಒಳಗೊಂಡಿರುವ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ತೆಗೆದುಹಾಕಿ, ಆಯ್ಕೆಯನ್ನು ನಾಶಪಡಿಸುತ್ತದೆ
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! ಲೂಪ್ ಮೊದಲು [`None`] ಗೆ ಫಲಿತಾಂಶವನ್ನು ಪ್ರಾರಂಭಿಸಿ:
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // ಹುಡುಕಲು ಡೇಟಾದ ಪಟ್ಟಿ.
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // ನಾವು ಅತಿದೊಡ್ಡ ಪ್ರಾಣಿಗಳ ಹೆಸರನ್ನು ಹುಡುಕಲಿದ್ದೇವೆ, ಆದರೆ ಪ್ರಾರಂಭಿಸಲು ನಾವು ಇದೀಗ `None` ಅನ್ನು ಪಡೆದುಕೊಂಡಿದ್ದೇವೆ.
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // ಈಗ ನಾವು ಕೆಲವು ದೊಡ್ಡ ಪ್ರಾಣಿಗಳ ಹೆಸರನ್ನು ಕಂಡುಕೊಂಡಿದ್ದೇವೆ
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// `Option` ಪ್ರಕಾರ.ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ [the module level documentation](self) ನೋಡಿ.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// ಮೌಲ್ಯವಿಲ್ಲ
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// ಕೆಲವು ಮೌಲ್ಯ `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// ಟೈಪ್ ಅನುಷ್ಠಾನ
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯಗಳನ್ನು ಪ್ರಶ್ನಿಸುವುದು
    /////////////////////////////////////////////////////////////////////////

    /// ಆಯ್ಕೆಯು [`Some`] ಮೌಲ್ಯವಾಗಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// ಆಯ್ಕೆಯು [`None`] ಮೌಲ್ಯವಾಗಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// ಆಯ್ಕೆಯು ನಿರ್ದಿಷ್ಟ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿರುವ [`Some`] ಮೌಲ್ಯವಾಗಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ಉಲ್ಲೇಖಗಳೊಂದಿಗೆ ಕೆಲಸ ಮಾಡಲು ಅಡಾಪ್ಟರ್
    /////////////////////////////////////////////////////////////////////////

    /// `&Option<T>` ನಿಂದ `Option<&T>` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// `ಆಯ್ಕೆಯನ್ನು <` [`ಸ್ಟ್ರಿಂಗ್`]`>`ಅನ್ನು`ಆಯ್ಕೆಯಾಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ <`[`ಬಳಕೆ`] `>`, ಮೂಲವನ್ನು ಸಂರಕ್ಷಿಸುತ್ತದೆ.
    /// [`map`] ವಿಧಾನವು `self` ಆರ್ಗ್ಯುಮೆಂಟ್ ಅನ್ನು ಮೌಲ್ಯದಿಂದ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ, ಮೂಲವನ್ನು ಬಳಸುತ್ತದೆ, ಆದ್ದರಿಂದ ಈ ತಂತ್ರವು `as_ref` ಅನ್ನು ಮೊದಲು `Option` ಅನ್ನು ಮೂಲದೊಳಗಿನ ಮೌಲ್ಯದ ಉಲ್ಲೇಖಕ್ಕೆ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // ಮೊದಲಿಗೆ, `as_ref` ನೊಂದಿಗೆ `Option<String>` ಗೆ `Option<&String>` ಗೆ ಬಿತ್ತರಿಸಿ, ನಂತರ `map` ನೊಂದಿಗೆ *that* ಅನ್ನು ಸೇವಿಸಿ, `text` ಅನ್ನು ಸ್ಟಾಕ್‌ನಲ್ಲಿ ಬಿಡಿ.
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// `&mut Option<T>` ನಿಂದ `Option<&mut T>` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// [`ಪಿನ್`]`<&ಆಯ್ಕೆಯಿಂದ ಪರಿವರ್ತಿಸುತ್ತದೆ<T>>`ಗೆ`ಆಯ್ಕೆ <`[`ಪಿನ್`] `<&ಟಿ>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // ಸುರಕ್ಷತೆ: `x` ಅನ್ನು ಪಿನ್ ಮಾಡುವ ಭರವಸೆ ಇದೆ ಏಕೆಂದರೆ ಅದು `self` ನಿಂದ ಬರುತ್ತದೆ
        // ಅದನ್ನು ಪಿನ್ ಮಾಡಲಾಗಿದೆ.
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// [`ಪಿನ್`]`<&ಮಟ್ ಆಯ್ಕೆಯಿಂದ ಪರಿವರ್ತಿಸುತ್ತದೆ<T>>`ಗೆ`ಆಯ್ಕೆ <`[`ಪಿನ್`] `<&ಮಟ್ ಟಿ>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // ಸುರಕ್ಷತೆ: `self` ಒಳಗೆ `Option` ಅನ್ನು ಸರಿಸಲು `get_unchecked_mut` ಅನ್ನು ಎಂದಿಗೂ ಬಳಸಲಾಗುವುದಿಲ್ಲ.
        // `x` ಪಿನ್ ಮಾಡಲಾಗುವುದು ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ ಏಕೆಂದರೆ ಅದು ಪಿನ್ ಮಾಡಲಾದ `self` ನಿಂದ ಬರುತ್ತದೆ.
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯಗಳಿಗೆ ಹೋಗುವುದು
    /////////////////////////////////////////////////////////////////////////

    /// ಒಳಗೊಂಡಿರುವ [`Some`] ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, `self` ಮೌಲ್ಯವನ್ನು ಬಳಸುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// `msg` ಒದಗಿಸಿದ ಕಸ್ಟಮ್ panic ಸಂದೇಶದೊಂದಿಗೆ ಮೌಲ್ಯವು [`None`] ಆಗಿದ್ದರೆ Panics.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// ಒಳಗೊಂಡಿರುವ [`Some`] ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, `self` ಮೌಲ್ಯವನ್ನು ಬಳಸುತ್ತದೆ.
    ///
    /// ಈ ಕಾರ್ಯವು panic ಆಗಿರಬಹುದು, ಇದರ ಬಳಕೆಯನ್ನು ಸಾಮಾನ್ಯವಾಗಿ ನಿರುತ್ಸಾಹಗೊಳಿಸಲಾಗುತ್ತದೆ.
    /// ಬದಲಾಗಿ, ಪ್ಯಾಟರ್ನ್ ಹೊಂದಾಣಿಕೆಯನ್ನು ಬಳಸಲು ಆದ್ಯತೆ ನೀಡಿ ಮತ್ತು [`None`] ಕೇಸ್ ಅನ್ನು ಸ್ಪಷ್ಟವಾಗಿ ನಿರ್ವಹಿಸಲು ಅಥವಾ [`unwrap_or`], [`unwrap_or_else`], ಅಥವಾ [`unwrap_or_default`] ಗೆ ಕರೆ ಮಾಡಿ.
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// ಸ್ವಯಂ ಮೌಲ್ಯವು [`None`] ಗೆ ಸಮನಾಗಿದ್ದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// ಒಳಗೊಂಡಿರುವ [`Some`] ಮೌಲ್ಯ ಅಥವಾ ಒದಗಿಸಿದ ಡೀಫಾಲ್ಟ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `unwrap_or` ಗೆ ರವಾನಿಸಲಾದ ವಾದಗಳನ್ನು ಕುತೂಹಲದಿಂದ ಮೌಲ್ಯಮಾಪನ ಮಾಡಲಾಗುತ್ತದೆ;ನೀವು ಕಾರ್ಯ ಕರೆಯ ಫಲಿತಾಂಶವನ್ನು ರವಾನಿಸುತ್ತಿದ್ದರೆ, [`unwrap_or_else`] ಅನ್ನು ಬಳಸಲು ಶಿಫಾರಸು ಮಾಡಲಾಗಿದೆ, ಇದನ್ನು ಸೋಮಾರಿಯಾಗಿ ಮೌಲ್ಯಮಾಪನ ಮಾಡಲಾಗುತ್ತದೆ.
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// ಒಳಗೊಂಡಿರುವ [`Some`] ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ ಅಥವಾ ಮುಚ್ಚುವಿಕೆಯಿಂದ ಅದನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// ಮೌಲ್ಯವು [`None`] ಅಲ್ಲ ಎಂದು ಪರಿಶೀಲಿಸದೆ, `self` ಮೌಲ್ಯವನ್ನು ಸೇವಿಸುವ, ಒಳಗೊಂಡಿರುವ [`Some`] ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Safety
    ///
    /// [`None`] ನಲ್ಲಿ ಈ ವಿಧಾನವನ್ನು ಕರೆಯುವುದು *[ವಿವರಿಸಲಾಗದ ನಡವಳಿಕೆ]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // ವಿವರಿಸಲಾಗದ ನಡವಳಿಕೆ!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರಿಂದ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯಗಳನ್ನು ಪರಿವರ್ತಿಸುವುದು
    /////////////////////////////////////////////////////////////////////////

    /// ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯಕ್ಕೆ ಕಾರ್ಯವನ್ನು ಅನ್ವಯಿಸುವ ಮೂಲಕ `Option<T>` ನಿಂದ `Option<U>` ಗೆ ನಕ್ಷೆ ಮಾಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// `ಆಯ್ಕೆಯನ್ನು <` [`ಸ್ಟ್ರಿಂಗ್`]`>`ಅನ್ನು`ಆಯ್ಕೆಯಾಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ <`[`ಬಳಕೆ`] `>`, ಮೂಲವನ್ನು ಸೇವಿಸುತ್ತದೆ:
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` `maybe_some_string` ಅನ್ನು ಸೇವಿಸುವ ಮೌಲ್ಯದಿಂದ ಸ್ವಯಂ * ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯಕ್ಕೆ (ಯಾವುದಾದರೂ ಇದ್ದರೆ) ಕಾರ್ಯವನ್ನು ಅನ್ವಯಿಸುತ್ತದೆ, ಅಥವಾ ಒದಗಿಸಿದ ಡೀಫಾಲ್ಟ್ ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ (ಇಲ್ಲದಿದ್ದರೆ).
    ///
    /// `map_or` ಗೆ ರವಾನಿಸಲಾದ ವಾದಗಳನ್ನು ಕುತೂಹಲದಿಂದ ಮೌಲ್ಯಮಾಪನ ಮಾಡಲಾಗುತ್ತದೆ;ನೀವು ಕಾರ್ಯ ಕರೆಯ ಫಲಿತಾಂಶವನ್ನು ರವಾನಿಸುತ್ತಿದ್ದರೆ, [`map_or_else`] ಅನ್ನು ಬಳಸಲು ಶಿಫಾರಸು ಮಾಡಲಾಗಿದೆ, ಇದನ್ನು ಸೋಮಾರಿಯಾಗಿ ಮೌಲ್ಯಮಾಪನ ಮಾಡಲಾಗುತ್ತದೆ.
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯಕ್ಕೆ (ಯಾವುದಾದರೂ ಇದ್ದರೆ) ಒಂದು ಕಾರ್ಯವನ್ನು ಅನ್ವಯಿಸುತ್ತದೆ, ಅಥವಾ ಡೀಫಾಲ್ಟ್ ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ (ಇಲ್ಲದಿದ್ದರೆ).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// `Option<T>` ಅನ್ನು [`Result<T, E>`] ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ, [`Some(v)`] ಅನ್ನು [`Ok(v)`] ಗೆ ಮತ್ತು [`None`] ಅನ್ನು [`Err(err)`] ಗೆ ಮ್ಯಾಪಿಂಗ್ ಮಾಡುತ್ತದೆ.
    ///
    /// `ok_or` ಗೆ ರವಾನಿಸಲಾದ ವಾದಗಳನ್ನು ಕುತೂಹಲದಿಂದ ಮೌಲ್ಯಮಾಪನ ಮಾಡಲಾಗುತ್ತದೆ;ನೀವು ಕಾರ್ಯ ಕರೆಯ ಫಲಿತಾಂಶವನ್ನು ರವಾನಿಸುತ್ತಿದ್ದರೆ, [`ok_or_else`] ಅನ್ನು ಬಳಸಲು ಶಿಫಾರಸು ಮಾಡಲಾಗಿದೆ, ಇದನ್ನು ಸೋಮಾರಿಯಾಗಿ ಮೌಲ್ಯಮಾಪನ ಮಾಡಲಾಗುತ್ತದೆ.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// `Option<T>` ಅನ್ನು [`Result<T, E>`] ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ, [`Some(v)`] ಅನ್ನು [`Ok(v)`] ಗೆ ಮತ್ತು [`None`] ಅನ್ನು [`Err(err())`] ಗೆ ಮ್ಯಾಪಿಂಗ್ ಮಾಡುತ್ತದೆ.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// `value` ಆಯ್ಕೆಯನ್ನು ಸೇರಿಸಿದ ನಂತರ ಅದಕ್ಕೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// ಆಯ್ಕೆಯು ಈಗಾಗಲೇ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿದ್ದರೆ, ಹಳೆಯ ಮೌಲ್ಯವನ್ನು ಕೈಬಿಡಲಾಗುತ್ತದೆ.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // ಸುರಕ್ಷತೆ: ಮೇಲಿನ ಕೋಡ್ ಆಯ್ಕೆಯನ್ನು ಭರ್ತಿ ಮಾಡಿದೆ
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ಇಟರೇಟರ್ ಕನ್‌ಸ್ಟ್ರಕ್ಟರ್‌ಗಳು
    /////////////////////////////////////////////////////////////////////////

    /// ಬಹುಶಃ ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯದ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// ಬಹುಶಃ ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯದ ಮೇಲೆ ರೂಪಾಂತರಿತ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // ಮೌಲ್ಯಗಳ ಮೇಲೆ ಬೂಲಿಯನ್ ಕಾರ್ಯಾಚರಣೆಗಳು, ಉತ್ಸಾಹ ಮತ್ತು ಸೋಮಾರಿಯಾದ
    /////////////////////////////////////////////////////////////////////////

    /// ಆಯ್ಕೆಯು [`None`] ಆಗಿದ್ದರೆ [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ `optb` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// ಆಯ್ಕೆಯು [`None`] ಆಗಿದ್ದರೆ [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ ಸುತ್ತಿದ ಮೌಲ್ಯದೊಂದಿಗೆ `f` ಗೆ ಕರೆ ಮಾಡಿ ಫಲಿತಾಂಶವನ್ನು ನೀಡುತ್ತದೆ.
    ///
    ///
    /// ಕೆಲವು ಭಾಷೆಗಳು ಈ ಕಾರ್ಯಾಚರಣೆಯನ್ನು ಫ್ಲಾಟ್‌ಮ್ಯಾಪ್ ಎಂದು ಕರೆಯುತ್ತವೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// ಆಯ್ಕೆಯು [`None`] ಆಗಿದ್ದರೆ [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ ಸುತ್ತಿದ ಮೌಲ್ಯದೊಂದಿಗೆ `predicate` ಗೆ ಕರೆ ಮಾಡಿ ಮತ್ತು ಹಿಂತಿರುಗಿಸುತ್ತದೆ:
    ///
    ///
    /// - [`Some(t)`] `predicate` `true` ಅನ್ನು ಹಿಂದಿರುಗಿಸಿದರೆ (ಅಲ್ಲಿ `t` ಸುತ್ತಿದ ಮೌಲ್ಯವಾಗಿದೆ), ಮತ್ತು
    /// - [`None`] `predicate` `false` ಅನ್ನು ಹಿಂದಿರುಗಿಸಿದರೆ.
    ///
    /// ಈ ಕಾರ್ಯವು [`Iterator::filter()`] ಗೆ ಹೋಲುತ್ತದೆ.
    /// `Option<T>` ಒಂದು ಅಥವಾ ಶೂನ್ಯ ಅಂಶಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕ ಎಂದು ನೀವು can ಹಿಸಬಹುದು.
    /// `filter()` ಯಾವ ಅಂಶಗಳನ್ನು ಇರಿಸಿಕೊಳ್ಳಬೇಕೆಂದು ನಿರ್ಧರಿಸಲು ನಿಮಗೆ ಅನುಮತಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// ಇದು ಮೌಲ್ಯವನ್ನು ಹೊಂದಿದ್ದರೆ ಆಯ್ಕೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ `optb` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `or` ಗೆ ರವಾನಿಸಲಾದ ವಾದಗಳನ್ನು ಕುತೂಹಲದಿಂದ ಮೌಲ್ಯಮಾಪನ ಮಾಡಲಾಗುತ್ತದೆ;ನೀವು ಕಾರ್ಯ ಕರೆಯ ಫಲಿತಾಂಶವನ್ನು ರವಾನಿಸುತ್ತಿದ್ದರೆ, [`or_else`] ಅನ್ನು ಬಳಸಲು ಶಿಫಾರಸು ಮಾಡಲಾಗಿದೆ, ಇದನ್ನು ಸೋಮಾರಿಯಾಗಿ ಮೌಲ್ಯಮಾಪನ ಮಾಡಲಾಗುತ್ತದೆ.
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// ಅದು ಮೌಲ್ಯವನ್ನು ಹೊಂದಿದ್ದರೆ ಆಯ್ಕೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ `f` ಗೆ ಕರೆ ಮಾಡಿ ಫಲಿತಾಂಶವನ್ನು ನೀಡುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// `self`, `optb` [`Some`] ಆಗಿದ್ದರೆ [`Some`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ಯಾವುದೂ ಇಲ್ಲದಿದ್ದರೆ ಸೇರಿಸಲು ಮತ್ತು ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸಲು ಪ್ರವೇಶದಂತಹ ಕಾರ್ಯಾಚರಣೆಗಳು
    /////////////////////////////////////////////////////////////////////////

    /// [`None`] ಆಗಿದ್ದರೆ `value` ಆಯ್ಕೆಗೆ ಸೇರಿಸುತ್ತದೆ, ನಂತರ ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯಕ್ಕೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ನೀಡುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// [`None`] ಆಗಿದ್ದರೆ ಡೀಫಾಲ್ಟ್ ಮೌಲ್ಯವನ್ನು ಆಯ್ಕೆಯಲ್ಲಿ ಸೇರಿಸುತ್ತದೆ, ನಂತರ ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯಕ್ಕೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ನೀಡುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// `f` ನಿಂದ ಲೆಕ್ಕಹಾಕಲಾದ ಮೌಲ್ಯವನ್ನು ಅದು [`None`] ಆಗಿದ್ದರೆ ಆಯ್ಕೆಗೆ ಸೇರಿಸುತ್ತದೆ, ನಂತರ ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯಕ್ಕೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ನೀಡುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // ಸುರಕ್ಷತೆ: `self` ಗಾಗಿ `None` ರೂಪಾಂತರವನ್ನು `Some` ನಿಂದ ಬದಲಾಯಿಸಬಹುದಿತ್ತು
            // ಮೇಲಿನ ಕೋಡ್‌ನಲ್ಲಿನ ರೂಪಾಂತರ.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// ಆಯ್ಕೆಯಿಂದ ಮೌಲ್ಯವನ್ನು ಹೊರತೆಗೆಯುತ್ತದೆ, ಅದರ ಸ್ಥಳದಲ್ಲಿ [`None`] ಅನ್ನು ಬಿಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// ಆಯ್ಕೆಯಲ್ಲಿನ ನೈಜ ಮೌಲ್ಯವನ್ನು ಪ್ಯಾರಾಮೀಟರ್‌ನಲ್ಲಿ ನೀಡಲಾದ ಮೌಲ್ಯದಿಂದ ಬದಲಾಯಿಸುತ್ತದೆ, ಹಳೆಯ ಮೌಲ್ಯವನ್ನು ಇದ್ದರೆ ಹಿಂದಿರುಗಿಸುತ್ತದೆ, [`Some`] ಅನ್ನು ಅದರ ಸ್ಥಳದಲ್ಲಿ ಡಿಇನಿಟೈಲೈಸ್ ಮಾಡದೆಯೇ ಬಿಟ್ಟುಬಿಡುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// ಮತ್ತೊಂದು `Option` ನೊಂದಿಗೆ ಜಿಪ್ಸ್ `self`.
    ///
    /// `self` `Some(s)` ಮತ್ತು `other` `Some(o)` ಆಗಿದ್ದರೆ, ಈ ವಿಧಾನವು `Some((s, o))` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    /// ಇಲ್ಲದಿದ್ದರೆ, `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// ಜಿಪ್ಸ್ `self` ಮತ್ತು `f` ಕಾರ್ಯದೊಂದಿಗೆ ಮತ್ತೊಂದು `Option`.
    ///
    /// `self` `Some(s)` ಮತ್ತು `other` `Some(o)` ಆಗಿದ್ದರೆ, ಈ ವಿಧಾನವು `Some(f(s, o))` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    /// ಇಲ್ಲದಿದ್ದರೆ, `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// ಆಯ್ಕೆಯ ವಿಷಯಗಳನ್ನು ನಕಲಿಸುವ ಮೂಲಕ `Option<&T>` ಅನ್ನು `Option<T>` ಗೆ ನಕ್ಷೆ ಮಾಡುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// ಆಯ್ಕೆಯ ವಿಷಯಗಳನ್ನು ನಕಲಿಸುವ ಮೂಲಕ `Option<&mut T>` ಅನ್ನು `Option<T>` ಗೆ ನಕ್ಷೆ ಮಾಡುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// ಆಯ್ಕೆಯ ವಿಷಯಗಳನ್ನು ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮಾಡುವ ಮೂಲಕ `Option<&T>` ಅನ್ನು `Option<T>` ಗೆ ನಕ್ಷೆ ಮಾಡುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// ಆಯ್ಕೆಯ ವಿಷಯಗಳನ್ನು ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮಾಡುವ ಮೂಲಕ `Option<&mut T>` ಅನ್ನು `Option<T>` ಗೆ ನಕ್ಷೆ ಮಾಡುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// [`None`] ಅನ್ನು ನಿರೀಕ್ಷಿಸುವಾಗ ಮತ್ತು ಏನನ್ನೂ ಹಿಂದಿರುಗಿಸದೆ `self` ಅನ್ನು ಬಳಸುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// Panics ಮೌಲ್ಯವು [`Some`] ಆಗಿದ್ದರೆ, ರವಾನಿಸಿದ ಸಂದೇಶವನ್ನು ಒಳಗೊಂಡಂತೆ panic ಸಂದೇಶ ಮತ್ತು [`Some`] ನ ವಿಷಯವನ್ನು ಒಳಗೊಂಡಿರುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // ಎಲ್ಲಾ ಕೀಗಳು ಅನನ್ಯವಾಗಿರುವ ಕಾರಣ ಇದು panic ಆಗುವುದಿಲ್ಲ.
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// [`None`] ಅನ್ನು ನಿರೀಕ್ಷಿಸುವಾಗ ಮತ್ತು ಏನನ್ನೂ ಹಿಂದಿರುಗಿಸದೆ `self` ಅನ್ನು ಬಳಸುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// Panics ಮೌಲ್ಯವು [`Some`] ಆಗಿದ್ದರೆ, ಕಸ್ಟಮ್ panic ಸಂದೇಶದೊಂದಿಗೆ [`ಕೆಲವು`] ಮೌಲ್ಯದಿಂದ ಒದಗಿಸಲಾಗುತ್ತದೆ.
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // ಎಲ್ಲಾ ಕೀಗಳು ಅನನ್ಯವಾಗಿರುವ ಕಾರಣ ಇದು panic ಆಗುವುದಿಲ್ಲ.
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// ಒಳಗೊಂಡಿರುವ [`Some`] ಮೌಲ್ಯ ಅಥವಾ ಡೀಫಾಲ್ಟ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ
    ///
    /// `self` ಆರ್ಗ್ಯುಮೆಂಟ್ ಅನ್ನು ಬಳಸುತ್ತದೆ, [`Some`] ಇದ್ದರೆ, ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ [`None`] ಆಗಿದ್ದರೆ, ಆ ಪ್ರಕಾರಕ್ಕೆ [default value] ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಪೂರ್ಣಾಂಕಕ್ಕೆ ಪರಿವರ್ತಿಸುತ್ತದೆ, ಕಳಪೆಯಾಗಿ ರೂಪುಗೊಂಡ ತಂತಿಗಳನ್ನು 0 ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ (ಪೂರ್ಣಾಂಕಗಳಿಗೆ ಪೂರ್ವನಿಯೋಜಿತ ಮೌಲ್ಯ).
    /// [`parse`] [`FromStr`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಯಾವುದೇ ಪ್ರಕಾರಕ್ಕೆ ಪರಿವರ್ತಿಸುತ್ತದೆ, [`None`] ಅನ್ನು ದೋಷದಿಂದ ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// `Option<T>` (ಅಥವಾ `&Option<T>`) ನಿಂದ `Option<&T::Target>` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ಮೂಲ ಆಯ್ಕೆಯನ್ನು ಸ್ಥಳದಲ್ಲಿಯೇ ಬಿಟ್ಟು, ಮೂಲವನ್ನು ಉಲ್ಲೇಖಿಸಿ ಹೊಸದನ್ನು ರಚಿಸುತ್ತದೆ, ಹೆಚ್ಚುವರಿಯಾಗಿ [`Deref`] ಮೂಲಕ ವಿಷಯಗಳನ್ನು ಒತ್ತಾಯಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// `Option<T>` (ಅಥವಾ `&mut Option<T>`) ನಿಂದ `Option<&mut T::Target>` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ಮೂಲ `Option` ಅನ್ನು ಸ್ಥಳದಲ್ಲಿಯೇ ಬಿಟ್ಟು, ಆಂತರಿಕ ಪ್ರಕಾರದ `Deref::Target` ಪ್ರಕಾರಕ್ಕೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಹೊಂದಿರುವ ಹೊಸದನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// [`Result`] ನ `Option` ಅನ್ನು `Option` ನ [`Result`] ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// [`None`] [`ಸರಿ`]`(`[`ಯಾವುದೂ ಇಲ್ಲ]]`)` ಗೆ ಮ್ಯಾಪ್ ಮಾಡಲಾಗುತ್ತದೆ.
    /// [`ಕೆಲವು`]`(`[`ಸರಿ`] `(_))` ಮತ್ತು [`ಕೆಲವು`]`(`[`ದೋಷ`] `(_))` ಅನ್ನು [`ಸರಿ`]`(`[`ಕೆಲವು`] `(_))` ಮತ್ತು [`ದೋಷ`]`(_)`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// .expect() ನ ಕೋಡ್ ಗಾತ್ರವನ್ನು ಕಡಿಮೆ ಮಾಡಲು ಇದು ಪ್ರತ್ಯೇಕ ಕಾರ್ಯವಾಗಿದೆ.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// .expect_none() ನ ಕೋಡ್ ಗಾತ್ರವನ್ನು ಕಡಿಮೆ ಮಾಡಲು ಇದು ಪ್ರತ್ಯೇಕ ಕಾರ್ಯವಾಗಿದೆ.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// Trait ಅನುಷ್ಠಾನಗಳು
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// [`None`][Option::None] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// ಬಹುಶಃ ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯದ ಮೇಲೆ ಸೇವಿಸುವ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// `val` ಅನ್ನು ಹೊಸ `Some` ಗೆ ನಕಲಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// `&Option<T>` ನಿಂದ `Option<&T>` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// `ಆಯ್ಕೆಯನ್ನು <` [`ಸ್ಟ್ರಿಂಗ್`]`>`ಅನ್ನು`ಆಯ್ಕೆಯಾಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ <`[`ಬಳಕೆ`] `>`, ಮೂಲವನ್ನು ಸಂರಕ್ಷಿಸುತ್ತದೆ.
    /// [`map`] ವಿಧಾನವು `self` ಆರ್ಗ್ಯುಮೆಂಟ್ ಅನ್ನು ಮೌಲ್ಯದಿಂದ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ, ಮೂಲವನ್ನು ಬಳಸುತ್ತದೆ, ಆದ್ದರಿಂದ ಈ ತಂತ್ರವು `as_ref` ಅನ್ನು ಮೊದಲು `Option` ಅನ್ನು ಮೂಲದೊಳಗಿನ ಮೌಲ್ಯದ ಉಲ್ಲೇಖಕ್ಕೆ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// `&mut Option<T>` ನಿಂದ `Option<&mut T>` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// ಆಯ್ಕೆ ಪುನರಾವರ್ತಕರು
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// [`Option`] ನ [`Some`] ರೂಪಾಂತರದ ಉಲ್ಲೇಖದ ಮೇಲೆ ಪುನರಾವರ್ತಕ.
///
/// [`Option`] [`Some`] ಆಗಿದ್ದರೆ ಪುನರಾವರ್ತಕವು ಒಂದು ಮೌಲ್ಯವನ್ನು ನೀಡುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ ಯಾವುದೂ ಇಲ್ಲ.
///
/// ಈ `struct` ಅನ್ನು [`Option::iter`] ಕಾರ್ಯದಿಂದ ರಚಿಸಲಾಗಿದೆ.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// [`Option`] ನ [`Some`] ರೂಪಾಂತರಕ್ಕೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖದ ಮೇಲೆ ಪುನರಾವರ್ತಕ.
///
/// [`Option`] [`Some`] ಆಗಿದ್ದರೆ ಪುನರಾವರ್ತಕವು ಒಂದು ಮೌಲ್ಯವನ್ನು ನೀಡುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ ಯಾವುದೂ ಇಲ್ಲ.
///
/// ಈ `struct` ಅನ್ನು [`Option::iter_mut`] ಕಾರ್ಯದಿಂದ ರಚಿಸಲಾಗಿದೆ.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// [`Option`] ನ [`Some`] ರೂಪಾಂತರದಲ್ಲಿನ ಮೌಲ್ಯದ ಮೇಲೆ ಪುನರಾವರ್ತಕ.
///
/// [`Option`] [`Some`] ಆಗಿದ್ದರೆ ಪುನರಾವರ್ತಕವು ಒಂದು ಮೌಲ್ಯವನ್ನು ನೀಡುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ ಯಾವುದೂ ಇಲ್ಲ.
///
/// ಈ `struct` ಅನ್ನು [`Option::into_iter`] ಕಾರ್ಯದಿಂದ ರಚಿಸಲಾಗಿದೆ.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// [`Iterator`] ನಲ್ಲಿನ ಪ್ರತಿಯೊಂದು ಅಂಶವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ: ಅದು [`None`][Option::None] ಆಗಿದ್ದರೆ, ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳಲಾಗುವುದಿಲ್ಲ, ಮತ್ತು [`None`][Option::None] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    /// ಯಾವುದೇ [`None`][Option::None] ಸಂಭವಿಸದಿದ್ದರೆ, ಪ್ರತಿ [`Option`] ನ ಮೌಲ್ಯಗಳನ್ನು ಹೊಂದಿರುವ ಧಾರಕವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// vector ನಲ್ಲಿನ ಪ್ರತಿ ಪೂರ್ಣಾಂಕವನ್ನು ಹೆಚ್ಚಿಸುವ ಉದಾಹರಣೆ ಇಲ್ಲಿದೆ.
    /// `add` ನ ಪರಿಶೀಲಿಸಿದ ರೂಪಾಂತರವನ್ನು ನಾವು ಬಳಸುತ್ತೇವೆ, ಅದು ಲೆಕ್ಕಾಚಾರವು ಉಕ್ಕಿ ಹರಿಯುವಾಗ `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// ನೀವು ನೋಡುವಂತೆ, ಇದು ನಿರೀಕ್ಷಿತ, ಮಾನ್ಯ ವಸ್ತುಗಳನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಪೂರ್ಣಾಂಕಗಳ ಮತ್ತೊಂದು ಪಟ್ಟಿಯಿಂದ ಒಂದನ್ನು ಕಳೆಯಲು ಪ್ರಯತ್ನಿಸುವ ಮತ್ತೊಂದು ಉದಾಹರಣೆ ಇಲ್ಲಿದೆ, ಈ ಸಮಯದಲ್ಲಿ ಒಳಹರಿವು ಪರಿಶೀಲಿಸಲಾಗುತ್ತಿದೆ:
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// ಕೊನೆಯ ಅಂಶ ಶೂನ್ಯವಾಗಿರುವುದರಿಂದ, ಅದು ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆ.ಹೀಗಾಗಿ, ಪರಿಣಾಮವಾಗಿ ಬರುವ ಮೌಲ್ಯವು `None` ಆಗಿದೆ.
    ///
    /// ಹಿಂದಿನ ಉದಾಹರಣೆಯ ಮೇಲಿನ ವ್ಯತ್ಯಾಸ ಇಲ್ಲಿದೆ, ಮೊದಲ `None` ನಂತರ `iter` ನಿಂದ ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳಲಾಗುವುದಿಲ್ಲ ಎಂದು ತೋರಿಸುತ್ತದೆ.
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// ಮೂರನೆಯ ಅಂಶವು ಒಳಹರಿವು ಉಂಟುಮಾಡಿದ ಕಾರಣ, ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳಲಾಗಿಲ್ಲ, ಆದ್ದರಿಂದ `shared` ನ ಅಂತಿಮ ಮೌಲ್ಯವು 6 (= `3 + 2 + 1`), 16 ಅಲ್ಲ.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): ಈ ಕಾರ್ಯಕ್ಷಮತೆಯ ದೋಷವನ್ನು ಮುಚ್ಚಿದಾಗ ಇದನ್ನು Iterator::scan ನೊಂದಿಗೆ ಬದಲಾಯಿಸಬಹುದು.
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// ಟ್ರೈ ಆಪರೇಟರ್ (`?`) ಅನ್ನು `None` ಮೌಲ್ಯಕ್ಕೆ ಅನ್ವಯಿಸುವುದರಿಂದ ಉಂಟಾಗುವ ದೋಷ ಪ್ರಕಾರ.
/// ನಿಮ್ಮ ದೋಷ ಪ್ರಕಾರಕ್ಕೆ ಪರಿವರ್ತಿಸಲು ನೀವು `x?` (ಅಲ್ಲಿ `x` ಒಂದು `Option<T>` ಆಗಿದೆ) ಅನ್ನು ಅನುಮತಿಸಲು ಬಯಸಿದರೆ, ನೀವು `YourErrorType` ಗಾಗಿ `impl From<NoneError>` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು.
///
/// ಅಂತಹ ಸಂದರ್ಭದಲ್ಲಿ, `Result<_, YourErrorType>` ಅನ್ನು ಹಿಂದಿರುಗಿಸುವ ಕ್ರಿಯೆಯೊಳಗಿನ `x?` `None` ಮೌಲ್ಯವನ್ನು `Err` ಫಲಿತಾಂಶಕ್ಕೆ ಅನುವಾದಿಸುತ್ತದೆ.
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// `Option<Option<T>>` ನಿಂದ `Option<T>` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// ಚಪ್ಪಟೆಯಾಗುವುದು ಒಂದು ಸಮಯದಲ್ಲಿ ಒಂದು ಹಂತದ ಗೂಡುಕಟ್ಟುವಿಕೆಯನ್ನು ಮಾತ್ರ ತೆಗೆದುಹಾಕುತ್ತದೆ:
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}