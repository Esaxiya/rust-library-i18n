use crate::{fmt, iter::FusedIterator};

/// ಹೊಸ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ, ಅಲ್ಲಿ ಪ್ರತಿ ಸತತ ಐಟಂ ಅನ್ನು ಹಿಂದಿನದನ್ನು ಆಧರಿಸಿ ಲೆಕ್ಕಹಾಕಲಾಗುತ್ತದೆ.
///
/// ಪುನರಾವರ್ತಕವು ಕೊಟ್ಟಿರುವ ಮೊದಲ ಐಟಂನೊಂದಿಗೆ (ಯಾವುದಾದರೂ ಇದ್ದರೆ) ಪ್ರಾರಂಭವಾಗುತ್ತದೆ ಮತ್ತು ಪ್ರತಿ ಐಟಂನ ಉತ್ತರಾಧಿಕಾರಿಯನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡಲು ಕೊಟ್ಟಿರುವ `FnMut(&T) -> Option<T>` ಮುಚ್ಚುವಿಕೆಯನ್ನು ಕರೆಯುತ್ತದೆ.
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // ಈ ಕಾರ್ಯವು `impl Iterator<Item=T>` ಅನ್ನು ಹಿಂತಿರುಗಿಸಿದರೆ ಅದು `unfold` ಅನ್ನು ಆಧರಿಸಿರಬಹುದು ಮತ್ತು ಮೀಸಲಾದ ಪ್ರಕಾರದ ಅಗತ್ಯವಿಲ್ಲ.
    //
    // ಆದಾಗ್ಯೂ ಹೆಸರಿಸಲಾದ `Successors<T, F>` ಪ್ರಕಾರವನ್ನು ಹೊಂದಿರುವುದು `T` ಮತ್ತು `F` ಆಗಿದ್ದಾಗ ಅದು `Clone` ಆಗಲು ಅನುಮತಿಸುತ್ತದೆ.
    Successors { next: first, succ }
}

/// ಹೊಸ ಪುನರಾವರ್ತಕ, ಅಲ್ಲಿ ಪ್ರತಿ ಸತತ ಐಟಂ ಅನ್ನು ಹಿಂದಿನದನ್ನು ಆಧರಿಸಿ ಲೆಕ್ಕಹಾಕಲಾಗುತ್ತದೆ.
///
/// ಈ `struct` ಅನ್ನು [`iter::successors()`] ಕಾರ್ಯದಿಂದ ರಚಿಸಲಾಗಿದೆ.
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}