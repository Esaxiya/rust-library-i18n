use crate::iter::{FusedIterator, TrustedLen};

/// ಒದಗಿಸಿದ ಮುಚ್ಚುವಿಕೆಯನ್ನು ಆಹ್ವಾನಿಸುವ ಮೂಲಕ ಆಲಸ್ಯವು ನಿಖರವಾಗಿ ಒಮ್ಮೆ ಮೌಲ್ಯವನ್ನು ಉತ್ಪಾದಿಸುವ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ.
///
/// ಒಂದೇ ಮೌಲ್ಯದ ಜನರೇಟರ್ ಅನ್ನು ಇತರ ರೀತಿಯ ಪುನರಾವರ್ತನೆಯ [`chain()`] ಗೆ ಹೊಂದಿಸಲು ಇದನ್ನು ಸಾಮಾನ್ಯವಾಗಿ ಬಳಸಲಾಗುತ್ತದೆ.
/// ಬಹುಶಃ ನೀವು ಪುನರಾವರ್ತಕವನ್ನು ಹೊಂದಿದ್ದೀರಿ ಅದು ಬಹುತೇಕ ಎಲ್ಲವನ್ನೂ ಒಳಗೊಳ್ಳುತ್ತದೆ, ಆದರೆ ನಿಮಗೆ ಹೆಚ್ಚುವರಿ ವಿಶೇಷ ಪ್ರಕರಣದ ಅಗತ್ಯವಿದೆ.
/// ಬಹುಶಃ ನೀವು ಪುನರಾವರ್ತಕರಲ್ಲಿ ಕಾರ್ಯನಿರ್ವಹಿಸುವ ಕಾರ್ಯವನ್ನು ಹೊಂದಿರಬಹುದು, ಆದರೆ ನೀವು ಕೇವಲ ಒಂದು ಮೌಲ್ಯವನ್ನು ಪ್ರಕ್ರಿಯೆಗೊಳಿಸಬೇಕಾಗುತ್ತದೆ.
///
/// [`once()`] ಗಿಂತ ಭಿನ್ನವಾಗಿ, ಈ ಕಾರ್ಯವು ವಿನಂತಿಯ ಮೇರೆಗೆ ಸೋಮಾರಿಯಾಗಿ ಮೌಲ್ಯವನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// ಮೂಲ ಬಳಕೆ:
///
/// ```
/// use std::iter;
///
/// // ಒಂದು ಏಕಾಂಗಿ ಸಂಖ್ಯೆ
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // ಕೇವಲ ಒಂದು, ನಮಗೆ ಸಿಗುವುದು ಅಷ್ಟೆ
/// assert_eq!(None, one.next());
/// ```
///
/// ಮತ್ತೊಂದು ಪುನರಾವರ್ತಕನೊಂದಿಗೆ ಚೈನ್ ಮಾಡುವುದು.
/// ನಾವು `.foo` ಡೈರೆಕ್ಟರಿಯ ಪ್ರತಿಯೊಂದು ಫೈಲ್‌ನ ಮೇಲೆ ಪುನರಾವರ್ತಿಸಲು ಬಯಸುತ್ತೇವೆ ಎಂದು ಹೇಳೋಣ, ಆದರೆ ಕಾನ್ಫಿಗರೇಶನ್ ಫೈಲ್,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // ನಾವು ಡಿರ್ ಎಂಟ್ರಿ-ಎಸ್‌ನ ಪುನರಾವರ್ತಕದಿಂದ ಪಾತ್‌ಬಫ್ಸ್‌ನ ಪುನರಾವರ್ತಕಕ್ಕೆ ಪರಿವರ್ತಿಸಬೇಕಾಗಿದೆ, ಆದ್ದರಿಂದ ನಾವು ನಕ್ಷೆಯನ್ನು ಬಳಸುತ್ತೇವೆ
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ಈಗ, ನಮ್ಮ ಸಂರಚನಾ ಕಡತಕ್ಕಾಗಿ ನಮ್ಮ ಪುನರಾವರ್ತಕ
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // ಎರಡು ಪುನರಾವರ್ತಕಗಳನ್ನು ಒಟ್ಟಿಗೆ ಒಂದು ದೊಡ್ಡ ಪುನರಾವರ್ತಕಕ್ಕೆ ಜೋಡಿಸಿ
/// let files = dirs.chain(config);
///
/// // ಇದು ನಮಗೆ .foo ಮತ್ತು .foorc ನಲ್ಲಿನ ಎಲ್ಲಾ ಫೈಲ್‌ಗಳನ್ನು ನೀಡುತ್ತದೆ
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// ಒದಗಿಸಿದ ಮುಚ್ಚುವಿಕೆ `F: FnOnce() -> A` ಅನ್ನು ಅನ್ವಯಿಸುವ ಮೂಲಕ `A` ಪ್ರಕಾರದ ಒಂದೇ ಅಂಶವನ್ನು ನೀಡುವ ಪುನರಾವರ್ತಕ.
///
///
/// ಈ `struct` ಅನ್ನು [`once_with()`] ಕಾರ್ಯದಿಂದ ರಚಿಸಲಾಗಿದೆ.
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}