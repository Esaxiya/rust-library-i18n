use crate::fmt;

/// ಹೊಸ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ, ಅಲ್ಲಿ ಪ್ರತಿ ಪುನರಾವರ್ತನೆಯು ಒದಗಿಸಿದ ಮುಚ್ಚುವಿಕೆಯನ್ನು `F: FnMut() -> Option<T>` ಎಂದು ಕರೆಯುತ್ತದೆ.
///
/// ಮೀಸಲಾದ ಪ್ರಕಾರವನ್ನು ರಚಿಸುವ ಮತ್ತು ಅದಕ್ಕಾಗಿ [`Iterator`] trait ಅನ್ನು ಹೆಚ್ಚು ವರ್ಬೊಸ್ ಸಿಂಟ್ಯಾಕ್ಸ್ ಬಳಸದೆ ಯಾವುದೇ ನಡವಳಿಕೆಯೊಂದಿಗೆ ಕಸ್ಟಮ್ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸಲು ಇದು ಅನುಮತಿಸುತ್ತದೆ.
///
/// `FromFn` ಪುನರಾವರ್ತಕವು ಮುಚ್ಚುವಿಕೆಯ ನಡವಳಿಕೆಯ ಬಗ್ಗೆ tions ಹೆಗಳನ್ನು ಮಾಡುವುದಿಲ್ಲ ಮತ್ತು ಆದ್ದರಿಂದ ಸಂಪ್ರದಾಯಬದ್ಧವಾಗಿ [`FusedIterator`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದಿಲ್ಲ, ಅಥವಾ [`Iterator::size_hint()`] ಅನ್ನು ಅದರ ಡೀಫಾಲ್ಟ್ `(0, None)` ನಿಂದ ಅತಿಕ್ರಮಿಸುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
///
///
/// ಮುಚ್ಚುವಿಕೆಯು ಪುನರಾವರ್ತನೆಗಳಾದ್ಯಂತ ಸ್ಥಿತಿಯನ್ನು ಪತ್ತೆಹಚ್ಚಲು ಕ್ಯಾಪ್ಚರ್‌ಗಳು ಮತ್ತು ಅದರ ಪರಿಸರವನ್ನು ಬಳಸಬಹುದು.ಪುನರಾವರ್ತಕವನ್ನು ಹೇಗೆ ಬಳಸಲಾಗುತ್ತದೆ ಎಂಬುದರ ಆಧಾರದ ಮೇಲೆ, ಇದಕ್ಕೆ ಮುಚ್ಚುವಿಕೆಯ ಮೇಲೆ [`move`] ಕೀವರ್ಡ್ ಅನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸುವ ಅಗತ್ಯವಿರುತ್ತದೆ.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// [module-level documentation] ನಿಂದ ಕೌಂಟರ್ ಇಟರೇಟರ್ ಅನ್ನು ಮರು-ಕಾರ್ಯಗತಗೊಳಿಸೋಣ:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // ನಮ್ಮ ಸಂಖ್ಯೆಯನ್ನು ಹೆಚ್ಚಿಸಿ.ಇದಕ್ಕಾಗಿಯೇ ನಾವು ಶೂನ್ಯದಿಂದ ಪ್ರಾರಂಭಿಸಿದ್ದೇವೆ.
///     count += 1;
///
///     // ನಾವು ಎಣಿಕೆಯನ್ನು ಪೂರ್ಣಗೊಳಿಸಿದ್ದೇವೆಯೇ ಅಥವಾ ಇಲ್ಲವೇ ಎಂದು ಪರಿಶೀಲಿಸಿ.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// ಪ್ರತಿ ಪುನರಾವರ್ತನೆಯು ಒದಗಿಸಿದ ಮುಚ್ಚುವಿಕೆಯನ್ನು `F: FnMut() -> Option<T>` ಎಂದು ಕರೆಯುವ ಪುನರಾವರ್ತಕ.
///
/// ಈ `struct` ಅನ್ನು [`iter::from_fn()`] ಕಾರ್ಯದಿಂದ ರಚಿಸಲಾಗಿದೆ.
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}