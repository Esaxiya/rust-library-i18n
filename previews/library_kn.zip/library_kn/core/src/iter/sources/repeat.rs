use crate::iter::{FusedIterator, TrustedLen};

/// ಒಂದೇ ಅಂಶವನ್ನು ಅನಂತವಾಗಿ ಪುನರಾವರ್ತಿಸುವ ಹೊಸ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ.
///
/// `repeat()` ಕಾರ್ಯವು ಒಂದೇ ಮೌಲ್ಯವನ್ನು ಮತ್ತೆ ಮತ್ತೆ ಪುನರಾವರ್ತಿಸುತ್ತದೆ.
///
/// `repeat()` ನಂತಹ ಅನಂತ ಪುನರಾವರ್ತಕಗಳನ್ನು ಸಾಮಾನ್ಯವಾಗಿ [`Iterator::take()`] ನಂತಹ ಅಡಾಪ್ಟರುಗಳೊಂದಿಗೆ ಬಳಸಲಾಗುತ್ತದೆ, ಅವುಗಳನ್ನು ಸೀಮಿತವಾಗಿಸುತ್ತದೆ.
///
/// ನಿಮಗೆ ಅಗತ್ಯವಿರುವ ಪುನರಾವರ್ತಕದ ಅಂಶ ಪ್ರಕಾರವು `Clone` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸದಿದ್ದರೆ, ಅಥವಾ ಪುನರಾವರ್ತಿತ ಅಂಶವನ್ನು ಮೆಮೊರಿಯಲ್ಲಿ ಇಡಲು ನೀವು ಬಯಸದಿದ್ದರೆ, ನೀವು ಬದಲಿಗೆ [`repeat_with()`] ಕಾರ್ಯವನ್ನು ಬಳಸಬಹುದು.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// ಮೂಲ ಬಳಕೆ:
///
/// ```
/// use std::iter;
///
/// // ಸಂಖ್ಯೆ 4 ಎವರ್:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // ಹೌದು, ಇನ್ನೂ ನಾಲ್ಕು
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// [`Iterator::take()`] ನೊಂದಿಗೆ ಸೀಮಿತವಾಗುತ್ತಿದೆ:
///
/// ```
/// use std::iter;
///
/// // ಆ ಕೊನೆಯ ಉದಾಹರಣೆ ಹಲವಾರು ಬೌಂಡರಿಗಳು.ನಾಲ್ಕು ಬೌಂಡರಿಗಳನ್ನು ಮಾತ್ರ ಹೊಂದೋಣ.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... ಮತ್ತು ಈಗ ನಾವು ಮುಗಿಸಿದ್ದೇವೆ
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// ಒಂದು ಅಂಶವನ್ನು ಅನಂತವಾಗಿ ಪುನರಾವರ್ತಿಸುವ ಪುನರಾವರ್ತಕ.
///
/// ಈ `struct` ಅನ್ನು [`repeat()`] ಕಾರ್ಯದಿಂದ ರಚಿಸಲಾಗಿದೆ.ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}