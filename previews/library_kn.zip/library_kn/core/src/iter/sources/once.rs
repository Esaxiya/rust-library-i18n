use crate::iter::{FusedIterator, TrustedLen};

/// ಒಂದು ಅಂಶವನ್ನು ನಿಖರವಾಗಿ ಒಮ್ಮೆ ನೀಡುವ ಇಟರೇಟರ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ.
///
/// ಒಂದೇ ಮೌಲ್ಯವನ್ನು [`chain()`] ಗೆ ಇತರ ರೀತಿಯ ಪುನರಾವರ್ತನೆಗೆ ಹೊಂದಿಸಲು ಇದನ್ನು ಸಾಮಾನ್ಯವಾಗಿ ಬಳಸಲಾಗುತ್ತದೆ.
/// ಬಹುಶಃ ನೀವು ಪುನರಾವರ್ತಕವನ್ನು ಹೊಂದಿದ್ದೀರಿ ಅದು ಬಹುತೇಕ ಎಲ್ಲವನ್ನೂ ಒಳಗೊಳ್ಳುತ್ತದೆ, ಆದರೆ ನಿಮಗೆ ಹೆಚ್ಚುವರಿ ವಿಶೇಷ ಪ್ರಕರಣದ ಅಗತ್ಯವಿದೆ.
/// ಬಹುಶಃ ನೀವು ಪುನರಾವರ್ತಕರಲ್ಲಿ ಕಾರ್ಯನಿರ್ವಹಿಸುವ ಕಾರ್ಯವನ್ನು ಹೊಂದಿರಬಹುದು, ಆದರೆ ನೀವು ಕೇವಲ ಒಂದು ಮೌಲ್ಯವನ್ನು ಪ್ರಕ್ರಿಯೆಗೊಳಿಸಬೇಕಾಗುತ್ತದೆ.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// ಮೂಲ ಬಳಕೆ:
///
/// ```
/// use std::iter;
///
/// // ಒಂದು ಏಕಾಂಗಿ ಸಂಖ್ಯೆ
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // ಕೇವಲ ಒಂದು, ನಮಗೆ ಸಿಗುವುದು ಅಷ್ಟೆ
/// assert_eq!(None, one.next());
/// ```
///
/// ಮತ್ತೊಂದು ಪುನರಾವರ್ತಕನೊಂದಿಗೆ ಚೈನ್ ಮಾಡುವುದು.
/// ನಾವು `.foo` ಡೈರೆಕ್ಟರಿಯ ಪ್ರತಿಯೊಂದು ಫೈಲ್‌ನ ಮೇಲೆ ಪುನರಾವರ್ತಿಸಲು ಬಯಸುತ್ತೇವೆ ಎಂದು ಹೇಳೋಣ, ಆದರೆ ಕಾನ್ಫಿಗರೇಶನ್ ಫೈಲ್,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // ನಾವು ಡಿರ್ ಎಂಟ್ರಿ-ಎಸ್‌ನ ಪುನರಾವರ್ತಕದಿಂದ ಪಾತ್‌ಬಫ್ಸ್‌ನ ಪುನರಾವರ್ತಕಕ್ಕೆ ಪರಿವರ್ತಿಸಬೇಕಾಗಿದೆ, ಆದ್ದರಿಂದ ನಾವು ನಕ್ಷೆಯನ್ನು ಬಳಸುತ್ತೇವೆ
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ಈಗ, ನಮ್ಮ ಸಂರಚನಾ ಕಡತಕ್ಕಾಗಿ ನಮ್ಮ ಪುನರಾವರ್ತಕ
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // ಎರಡು ಪುನರಾವರ್ತಕಗಳನ್ನು ಒಟ್ಟಿಗೆ ಒಂದು ದೊಡ್ಡ ಪುನರಾವರ್ತಕಕ್ಕೆ ಜೋಡಿಸಿ
/// let files = dirs.chain(config);
///
/// // ಇದು ನಮಗೆ .foo ಮತ್ತು .foorc ನಲ್ಲಿನ ಎಲ್ಲಾ ಫೈಲ್‌ಗಳನ್ನು ನೀಡುತ್ತದೆ
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// ಒಂದು ಅಂಶವನ್ನು ನಿಖರವಾಗಿ ಒಮ್ಮೆ ನೀಡುವ ಇಟರೇಟರ್.
///
/// ಈ `struct` ಅನ್ನು [`once()`] ಕಾರ್ಯದಿಂದ ರಚಿಸಲಾಗಿದೆ.ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}