use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// *ಉತ್ತರಾಧಿಕಾರಿ* ಮತ್ತು *ಹಿಂದಿನ* ಕಾರ್ಯಾಚರಣೆಗಳ ಕಲ್ಪನೆಯನ್ನು ಹೊಂದಿರುವ ವಸ್ತುಗಳು.
///
/// *ಉತ್ತರಾಧಿಕಾರಿ* ಕಾರ್ಯಾಚರಣೆಯು ಹೆಚ್ಚಿನದನ್ನು ಹೋಲಿಸುವ ಮೌಲ್ಯಗಳ ಕಡೆಗೆ ಚಲಿಸುತ್ತದೆ.
/// *ಹಿಂದಿನ* ಕಾರ್ಯಾಚರಣೆಯು ಕಡಿಮೆ ಹೋಲಿಸುವ ಮೌಲ್ಯಗಳ ಕಡೆಗೆ ಚಲಿಸುತ್ತದೆ.
///
/// # Safety
///
/// ಈ trait `unsafe` ಆಗಿದೆ ಏಕೆಂದರೆ `unsafe trait TrustedLen` ಅನುಷ್ಠಾನಗಳ ಸುರಕ್ಷತೆಗಾಗಿ ಅದರ ಅನುಷ್ಠಾನವು ಸರಿಯಾಗಿರಬೇಕು, ಮತ್ತು ಈ trait ಅನ್ನು ಬಳಸುವ ಫಲಿತಾಂಶಗಳನ್ನು `unsafe` ಕೋಡ್‌ನಿಂದ ನಂಬಬಹುದು ಮತ್ತು ಸರಿಯಾಗಿದೆ ಮತ್ತು ಪಟ್ಟಿಮಾಡಿದ ಕಟ್ಟುಪಾಡುಗಳನ್ನು ಪೂರೈಸುತ್ತದೆ.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// `start` ನಿಂದ `end` ಗೆ ಪಡೆಯಲು ಅಗತ್ಯವಿರುವ *ಉತ್ತರಾಧಿಕಾರಿ* ಹಂತಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಹಂತಗಳ ಸಂಖ್ಯೆಯು `usize` ಅನ್ನು ಉಕ್ಕಿ ಹರಿಯುತ್ತಿದ್ದರೆ (ಅಥವಾ ಅನಂತ, ಅಥವಾ `end` ಅನ್ನು ಎಂದಿಗೂ ತಲುಪದಿದ್ದರೆ) `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Invariants
    ///
    /// ಯಾವುದೇ `a`, `b`, ಮತ್ತು `n` ಗಾಗಿ:
    ///
    /// * `steps_between(&a, &b) == Some(n)` ವೇಳೆ ಮತ್ತು `Step::forward_checked(&a, n) == Some(b)` ಆಗಿದ್ದರೆ ಮಾತ್ರ
    /// * `steps_between(&a, &b) == Some(n)` ವೇಳೆ ಮತ್ತು `Step::backward_checked(&a, n) == Some(a)` ಆಗಿದ್ದರೆ ಮಾತ್ರ
    /// * `steps_between(&a, &b) == Some(n)` `a <= b` ಆಗಿದ್ದರೆ ಮಾತ್ರ
    ///   * ಕೊರೊಲರಿ: `steps_between(&a, &b) == Some(0)` ವೇಳೆ ಮತ್ತು `a == b` ಆಗಿದ್ದರೆ ಮಾತ್ರ
    ///   * `a <= b` _not_ `steps_between(&a, &b) != None` ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ;
    ///     `b` ಗೆ ಹೋಗಲು `usize::MAX` ಗಿಂತ ಹೆಚ್ಚಿನ ಹಂತಗಳು ಬೇಕಾದಾಗ ಇದು ಸಂಭವಿಸುತ್ತದೆ
    /// * `steps_between(&a, &b) == None` `a > b` ವೇಳೆ
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// `self` `count` ಬಾರಿ *ಉತ್ತರಾಧಿಕಾರಿ* ತೆಗೆದುಕೊಳ್ಳುವ ಮೂಲಕ ಪಡೆಯಬಹುದಾದ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಇದು `Self` ನಿಂದ ಬೆಂಬಲಿತವಾದ ಮೌಲ್ಯಗಳ ಶ್ರೇಣಿಯನ್ನು ಉಕ್ಕಿ ಹರಿಯುತ್ತಿದ್ದರೆ, `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Invariants
    ///
    /// ಯಾವುದೇ `a`, `n`, ಮತ್ತು `m` ಗಾಗಿ:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// `n + m` ಉಕ್ಕಿ ಹರಿಯದ ಯಾವುದೇ `a`, `n`, ಮತ್ತು `m` ಗೆ:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// ಯಾವುದೇ `a` ಮತ್ತು `n` ಗಾಗಿ:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// `self` `count` ಬಾರಿ *ಉತ್ತರಾಧಿಕಾರಿ* ತೆಗೆದುಕೊಳ್ಳುವ ಮೂಲಕ ಪಡೆಯಬಹುದಾದ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಇದು `Self` ನಿಂದ ಬೆಂಬಲಿತವಾದ ಮೌಲ್ಯಗಳ ಶ್ರೇಣಿಯನ್ನು ಉಕ್ಕಿ ಹರಿಯುತ್ತಿದ್ದರೆ, ಈ ಕಾರ್ಯವನ್ನು panic, ಸುತ್ತು ಅಥವಾ ಸ್ಯಾಚುರೇಟ್ ಮಾಡಲು ಅನುಮತಿಸಲಾಗಿದೆ.
    ///
    /// ಡೀಬಗ್ ಪ್ರತಿಪಾದನೆಗಳನ್ನು ಸಕ್ರಿಯಗೊಳಿಸಿದಾಗ ಸೂಚಿಸಲಾದ ನಡವಳಿಕೆಯು panic ಗೆ, ಮತ್ತು ಇಲ್ಲದಿದ್ದರೆ ಕಟ್ಟಲು ಅಥವಾ ಸ್ಯಾಚುರೇಟ್ ಮಾಡುವುದು.
    ///
    /// ಅಸುರಕ್ಷಿತ ಕೋಡ್ ಉಕ್ಕಿ ಹರಿಯುವ ನಂತರ ವರ್ತನೆಯ ಸರಿಯಾದತೆಯನ್ನು ಅವಲಂಬಿಸಬಾರದು.
    ///
    /// # Invariants
    ///
    /// ಯಾವುದೇ `a`, `n`, ಮತ್ತು `m` ಗೆ, ಅಲ್ಲಿ ಯಾವುದೇ ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// ಯಾವುದೇ `a` ಮತ್ತು `n` ಗಾಗಿ, ಯಾವುದೇ ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// `self` `count` ಬಾರಿ *ಉತ್ತರಾಧಿಕಾರಿ* ತೆಗೆದುಕೊಳ್ಳುವ ಮೂಲಕ ಪಡೆಯಬಹುದಾದ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// ಈ ಕಾರ್ಯಾಚರಣೆಯು `Self` ನಿಂದ ಬೆಂಬಲಿತವಾದ ಮೌಲ್ಯಗಳ ಶ್ರೇಣಿಯನ್ನು ಉಕ್ಕಿ ಹರಿಯುವುದು ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಯಾಗಿದೆ.
    /// ಇದು ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ ಎಂದು ನಿಮಗೆ ಖಾತರಿ ನೀಡಲಾಗದಿದ್ದರೆ, ಬದಲಿಗೆ `forward` ಅಥವಾ `forward_checked` ಬಳಸಿ.
    ///
    /// # Invariants
    ///
    /// ಯಾವುದೇ `a` ಗಾಗಿ:
    ///
    /// * `b > a` ನಂತಹ `b` ಇದ್ದರೆ, `Step::forward_unchecked(a, 1)` ಗೆ ಕರೆ ಮಾಡುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ
    /// * `steps_between(&a, &b) == Some(n)` ನಂತಹ `b`, `n` ಇದ್ದರೆ, ಯಾವುದೇ `m <= n` ಗಾಗಿ `Step::forward_unchecked(a, m)` ಗೆ ಕರೆ ಮಾಡುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ.
    ///
    ///
    /// ಯಾವುದೇ `a` ಮತ್ತು `n` ಗಾಗಿ, ಯಾವುದೇ ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ:
    ///
    /// * `Step::forward_unchecked(a, n)` ಇದು `Step::forward(a, n)` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// `self` `count` ಬಾರಿ *ಪೂರ್ವವರ್ತಿ* ತೆಗೆದುಕೊಳ್ಳುವ ಮೂಲಕ ಪಡೆಯಬಹುದಾದ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಇದು `Self` ನಿಂದ ಬೆಂಬಲಿತವಾದ ಮೌಲ್ಯಗಳ ಶ್ರೇಣಿಯನ್ನು ಉಕ್ಕಿ ಹರಿಯುತ್ತಿದ್ದರೆ, `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Invariants
    ///
    /// ಯಾವುದೇ `a`, `n`, ಮತ್ತು `m` ಗಾಗಿ:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// ಯಾವುದೇ `a` ಮತ್ತು `n` ಗಾಗಿ:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// `self` `count` ಬಾರಿ *ಪೂರ್ವವರ್ತಿ* ತೆಗೆದುಕೊಳ್ಳುವ ಮೂಲಕ ಪಡೆಯಬಹುದಾದ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಇದು `Self` ನಿಂದ ಬೆಂಬಲಿತವಾದ ಮೌಲ್ಯಗಳ ಶ್ರೇಣಿಯನ್ನು ಉಕ್ಕಿ ಹರಿಯುತ್ತಿದ್ದರೆ, ಈ ಕಾರ್ಯವನ್ನು panic, ಸುತ್ತು ಅಥವಾ ಸ್ಯಾಚುರೇಟ್ ಮಾಡಲು ಅನುಮತಿಸಲಾಗಿದೆ.
    ///
    /// ಡೀಬಗ್ ಪ್ರತಿಪಾದನೆಗಳನ್ನು ಸಕ್ರಿಯಗೊಳಿಸಿದಾಗ ಸೂಚಿಸಲಾದ ನಡವಳಿಕೆಯು panic ಗೆ, ಮತ್ತು ಇಲ್ಲದಿದ್ದರೆ ಕಟ್ಟಲು ಅಥವಾ ಸ್ಯಾಚುರೇಟ್ ಮಾಡುವುದು.
    ///
    /// ಅಸುರಕ್ಷಿತ ಕೋಡ್ ಉಕ್ಕಿ ಹರಿಯುವ ನಂತರ ವರ್ತನೆಯ ಸರಿಯಾದತೆಯನ್ನು ಅವಲಂಬಿಸಬಾರದು.
    ///
    /// # Invariants
    ///
    /// ಯಾವುದೇ `a`, `n`, ಮತ್ತು `m` ಗೆ, ಅಲ್ಲಿ ಯಾವುದೇ ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// ಯಾವುದೇ `a` ಮತ್ತು `n` ಗಾಗಿ, ಯಾವುದೇ ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// `self` `count` ಬಾರಿ *ಪೂರ್ವವರ್ತಿ* ತೆಗೆದುಕೊಳ್ಳುವ ಮೂಲಕ ಪಡೆಯಬಹುದಾದ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// ಈ ಕಾರ್ಯಾಚರಣೆಯು `Self` ನಿಂದ ಬೆಂಬಲಿತವಾದ ಮೌಲ್ಯಗಳ ಶ್ರೇಣಿಯನ್ನು ಉಕ್ಕಿ ಹರಿಯುವುದು ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಯಾಗಿದೆ.
    /// ಇದು ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ ಎಂದು ನಿಮಗೆ ಖಾತರಿ ನೀಡಲಾಗದಿದ್ದರೆ, ಬದಲಿಗೆ `backward` ಅಥವಾ `backward_checked` ಬಳಸಿ.
    ///
    /// # Invariants
    ///
    /// ಯಾವುದೇ `a` ಗಾಗಿ:
    ///
    /// * `b < a` ನಂತಹ `b` ಇದ್ದರೆ, `Step::backward_unchecked(a, 1)` ಗೆ ಕರೆ ಮಾಡುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ
    /// * `steps_between(&b, &a) == Some(n)` ನಂತಹ `b`, `n` ಇದ್ದರೆ, ಯಾವುದೇ `m <= n` ಗಾಗಿ `Step::backward_unchecked(a, m)` ಗೆ ಕರೆ ಮಾಡುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ.
    ///
    ///
    /// ಯಾವುದೇ `a` ಮತ್ತು `n` ಗಾಗಿ, ಯಾವುದೇ ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ:
    ///
    /// * `Step::backward_unchecked(a, n)` ಇದು `Step::backward(a, n)` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// ಇವುಗಳು ಇನ್ನೂ ಸ್ಥೂಲ-ರಚಿತವಾಗಿವೆ ಏಕೆಂದರೆ ಪೂರ್ಣಾಂಕ ಅಕ್ಷರಗಳು ವಿಭಿನ್ನ ಪ್ರಕಾರಗಳಿಗೆ ಪರಿಹರಿಸುತ್ತವೆ.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `start + n` ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `start - n` ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // ಡೀಬಗ್ ನಿರ್ಮಾಣಗಳಲ್ಲಿ, ಓವರ್‌ಫ್ಲೋನಲ್ಲಿ panic ಅನ್ನು ಪ್ರಚೋದಿಸಿ.
            // ಬಿಡುಗಡೆಯ ನಿರ್ಮಾಣಗಳಲ್ಲಿ ಇದು ಸಂಪೂರ್ಣವಾಗಿ ಉತ್ತಮಗೊಳ್ಳುತ್ತದೆ.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // ಉದಾ. ಅನುಮತಿಸಲು ಗಣಿತವನ್ನು ಸುತ್ತುವಂತೆ ಮಾಡಿ `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // ಡೀಬಗ್ ನಿರ್ಮಾಣಗಳಲ್ಲಿ, ಓವರ್‌ಫ್ಲೋನಲ್ಲಿ panic ಅನ್ನು ಪ್ರಚೋದಿಸಿ.
            // ಬಿಡುಗಡೆಯ ನಿರ್ಮಾಣಗಳಲ್ಲಿ ಇದು ಸಂಪೂರ್ಣವಾಗಿ ಉತ್ತಮಗೊಳ್ಳುತ್ತದೆ.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // ಉದಾ. ಅನುಮತಿಸಲು ಗಣಿತವನ್ನು ಸುತ್ತುವಂತೆ ಮಾಡಿ `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // ಇದು $u_narrower <=usize ಅನ್ನು ಅವಲಂಬಿಸಿದೆ
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // n ವ್ಯಾಪ್ತಿಯಿಂದ ಹೊರಗಿದ್ದರೆ, `unsigned_start + n` ತುಂಬಾ
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // n ವ್ಯಾಪ್ತಿಯಿಂದ ಹೊರಗಿದ್ದರೆ, `unsigned_start - n` ತುಂಬಾ
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // ಇದು $i_narrower <=usize ಅನ್ನು ಅವಲಂಬಿಸಿದೆ
                        //
                        // ಐಸೈಜ್ ಮಾಡಲು ಬಿತ್ತರಿಸುವಿಕೆಯು ಅಗಲವನ್ನು ವಿಸ್ತರಿಸುತ್ತದೆ ಆದರೆ ಚಿಹ್ನೆಯನ್ನು ಸಂರಕ್ಷಿಸುತ್ತದೆ.
                        // ಐಸೈಜ್ ಜಾಗದಲ್ಲಿ ಸುತ್ತುವ_ಸಬ್ ಬಳಸಿ ಮತ್ತು ಐಸೈಜ್ ವ್ಯಾಪ್ತಿಯಲ್ಲಿ ಹೊಂದಿಕೆಯಾಗದ ವ್ಯತ್ಯಾಸವನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡಲು ಬಳಸಿಕೊಳ್ಳಲು ಬಿತ್ತರಿಸಿ.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // i8 ಗೆ 200 ವ್ಯಾಪ್ತಿಯಿಲ್ಲದಿದ್ದರೂ, `Step::forward(-120_i8, 200) == Some(80_i8)` ನಂತಹ ಪ್ರಕರಣಗಳನ್ನು ಸುತ್ತುವುದು ನಿರ್ವಹಿಸುತ್ತದೆ.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // ಸೇರ್ಪಡೆ ಉಕ್ಕಿ ಹರಿಯಿತು
                            }
                        }
                        // N ಉದಾ ವ್ಯಾಪ್ತಿಯಿಂದ ಹೊರಗಿದ್ದರೆ
                        // u8, ನಂತರ ಅದು i8 ಗಾಗಿ ಸಂಪೂರ್ಣ ಶ್ರೇಣಿಗಿಂತ ದೊಡ್ಡದಾಗಿದೆ ಆದ್ದರಿಂದ `any_i8 + n` ಅಗತ್ಯವಾಗಿ i8 ಅನ್ನು ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆ.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // i8 ಗೆ 200 ವ್ಯಾಪ್ತಿಯಿಲ್ಲದಿದ್ದರೂ, `Step::forward(-120_i8, 200) == Some(80_i8)` ನಂತಹ ಪ್ರಕರಣಗಳನ್ನು ಸುತ್ತುವುದು ನಿರ್ವಹಿಸುತ್ತದೆ.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // ವ್ಯವಕಲನ ಉಕ್ಕಿ ಹರಿಯಿತು
                            }
                        }
                        // N ಉದಾ ವ್ಯಾಪ್ತಿಯಿಂದ ಹೊರಗಿದ್ದರೆ
                        // u8, ನಂತರ ಅದು i8 ಗಾಗಿ ಸಂಪೂರ್ಣ ಶ್ರೇಣಿಗಿಂತ ದೊಡ್ಡದಾಗಿದೆ ಆದ್ದರಿಂದ `any_i8 - n` ಅಗತ್ಯವಾಗಿ i8 ಅನ್ನು ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆ.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // ವ್ಯತ್ಯಾಸವು ಉದಾ
                            // i128, ಕಡಿಮೆ ಬಿಟ್‌ಗಳೊಂದಿಗೆ ಬಳಸುವುದಕ್ಕೂ ಇದು ತುಂಬಾ ದೊಡ್ಡದಾಗಿದೆ.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // ಸುರಕ್ಷತೆ: ರೆಸ್ ಮಾನ್ಯ ಯುನಿಕೋಡ್ ಸ್ಕೇಲಾರ್ ಆಗಿದೆ
            // (0x110000 ಗಿಂತ ಕಡಿಮೆ ಮತ್ತು 0xD800..0xE000 ನಲ್ಲಿ ಅಲ್ಲ)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // ಸುರಕ್ಷತೆ: ರೆಸ್ ಮಾನ್ಯ ಯುನಿಕೋಡ್ ಸ್ಕೇಲಾರ್ ಆಗಿದೆ
        // (0x110000 ಗಿಂತ ಕಡಿಮೆ ಮತ್ತು 0xD800..0xE000 ನಲ್ಲಿ ಅಲ್ಲ)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು ಇದು ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು
        // ಚಾರ್ಗಾಗಿ ಮೌಲ್ಯಗಳ ಶ್ರೇಣಿ.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು ಇದು ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು
            // ಚಾರ್ಗಾಗಿ ಮೌಲ್ಯಗಳ ಶ್ರೇಣಿ.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // ಸುರಕ್ಷತೆ: ಹಿಂದಿನ ಒಪ್ಪಂದದ ಕಾರಣ, ಇದು ಖಾತರಿಪಡಿಸುತ್ತದೆ
        // ಕರೆ ಮಾಡುವವರಿಂದ ಮಾನ್ಯ ಚಾರ್ ಆಗಿರುತ್ತದೆ.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು ಇದು ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು
        // ಚಾರ್ಗಾಗಿ ಮೌಲ್ಯಗಳ ಶ್ರೇಣಿ.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು ಇದು ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು
            // ಚಾರ್ಗಾಗಿ ಮೌಲ್ಯಗಳ ಶ್ರೇಣಿ.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // ಸುರಕ್ಷತೆ: ಹಿಂದಿನ ಒಪ್ಪಂದದ ಕಾರಣ, ಇದು ಖಾತರಿಪಡಿಸುತ್ತದೆ
        // ಕರೆ ಮಾಡುವವರಿಂದ ಮಾನ್ಯ ಚಾರ್ ಆಗಿರುತ್ತದೆ.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // ಸುರಕ್ಷತೆ: ಪೂರ್ವಭಾವಿ ಸ್ಥಿತಿಯನ್ನು ಪರಿಶೀಲಿಸಲಾಗಿದೆ
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // ಸುರಕ್ಷತೆ: ಪೂರ್ವಭಾವಿ ಸ್ಥಿತಿಯನ್ನು ಪರಿಶೀಲಿಸಲಾಗಿದೆ
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// ಈ ಮ್ಯಾಕ್ರೋಗಳು ವಿವಿಧ ಶ್ರೇಣಿಯ ಪ್ರಕಾರಗಳಿಗೆ `ExactSizeIterator` ಇಂಪ್ಲ್‌ಗಳನ್ನು ಉತ್ಪಾದಿಸುತ್ತವೆ.
//
// * `ExactSizeIterator::len` ಯಾವಾಗಲೂ ನಿಖರವಾದ `usize` ಅನ್ನು ಹಿಂತಿರುಗಿಸಲು ಅಗತ್ಯವಿದೆ, ಆದ್ದರಿಂದ ಯಾವುದೇ ಶ್ರೇಣಿ `usize::MAX` ಗಿಂತ ಉದ್ದವಾಗಿರಬಾರದು.
//
// * `Range<_>` ನಲ್ಲಿನ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳಿಗೆ `usize` ಗಿಂತ ಕಿರಿದಾದ ಅಥವಾ ಅಗಲವಾದ ಪ್ರಕಾರಗಳಿಗೆ ಇದು ಅನ್ವಯಿಸುತ್ತದೆ.
//   `RangeInclusive<_>` ನಲ್ಲಿನ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳಿಗೆ ಉದಾ. ರಿಂದ `usize` ಗಿಂತ *ಕಟ್ಟುನಿಟ್ಟಾಗಿ ಕಿರಿದಾದ* ಪ್ರಕಾರಗಳಿಗೆ ಇದು ಅನ್ವಯಿಸುತ್ತದೆ
//   `(0..=u64::MAX).len()` `u64::MAX + 1` ಆಗಿರುತ್ತದೆ.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // ಮೇಲಿನ ತಾರ್ಕಿಕತೆಗೆ ಅನುಗುಣವಾಗಿ ಇವು ಅಸಮಂಜಸವಾಗಿವೆ, ಆದರೆ ಅವುಗಳನ್ನು ತೆಗೆದುಹಾಕುವುದು ಬ್ರೇಕಿಂಗ್ ಬದಲಾವಣೆಯಾಗಿದೆ ಏಕೆಂದರೆ ಅವುಗಳು Rust 1.0.0 ನಲ್ಲಿ ಸ್ಥಿರಗೊಂಡಿವೆ.
    // ಆದ್ದರಿಂದ ಉದಾ
    // `(0..66_000_u32).len()` ಉದಾಹರಣೆಗೆ 16-ಬಿಟ್ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ದೋಷ ಅಥವಾ ಎಚ್ಚರಿಕೆಗಳಿಲ್ಲದೆ ಕಂಪೈಲ್ ಮಾಡುತ್ತದೆ, ಆದರೆ ತಪ್ಪಾದ ಫಲಿತಾಂಶವನ್ನು ನೀಡುವುದನ್ನು ಮುಂದುವರಿಸುತ್ತದೆ.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // ಮೇಲಿನ ತಾರ್ಕಿಕತೆಗೆ ಅನುಗುಣವಾಗಿ ಇವು ಅಸಮಂಜಸವಾಗಿವೆ, ಆದರೆ ಅವುಗಳನ್ನು ತೆಗೆದುಹಾಕುವುದು ಬ್ರೇಕಿಂಗ್ ಬದಲಾವಣೆಯಾಗಿದೆ ಏಕೆಂದರೆ ಅವುಗಳು Rust 1.26.0 ನಲ್ಲಿ ಸ್ಥಿರಗೊಂಡಿವೆ.
    // ಆದ್ದರಿಂದ ಉದಾ
    // `(0..=u16::MAX).len()` ಉದಾಹರಣೆಗೆ 16-ಬಿಟ್ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ದೋಷ ಅಥವಾ ಎಚ್ಚರಿಕೆಗಳಿಲ್ಲದೆ ಕಂಪೈಲ್ ಮಾಡುತ್ತದೆ, ಆದರೆ ತಪ್ಪಾದ ಫಲಿತಾಂಶವನ್ನು ನೀಡುವುದನ್ನು ಮುಂದುವರಿಸುತ್ತದೆ.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // ಸುರಕ್ಷತೆ: ಪೂರ್ವಭಾವಿ ಸ್ಥಿತಿಯನ್ನು ಪರಿಶೀಲಿಸಲಾಗಿದೆ
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // ಸುರಕ್ಷತೆ: ಪೂರ್ವಭಾವಿ ಸ್ಥಿತಿಯನ್ನು ಪರಿಶೀಲಿಸಲಾಗಿದೆ
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // ಸುರಕ್ಷತೆ: ಪೂರ್ವಭಾವಿ ಸ್ಥಿತಿಯನ್ನು ಪರಿಶೀಲಿಸಲಾಗಿದೆ
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // ಸುರಕ್ಷತೆ: ಪೂರ್ವಭಾವಿ ಸ್ಥಿತಿಯನ್ನು ಪರಿಶೀಲಿಸಲಾಗಿದೆ
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // ಸುರಕ್ಷತೆ: ಪೂರ್ವಭಾವಿ ಸ್ಥಿತಿಯನ್ನು ಪರಿಶೀಲಿಸಲಾಗಿದೆ
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // ಸುರಕ್ಷತೆ: ಪೂರ್ವಭಾವಿ ಸ್ಥಿತಿಯನ್ನು ಪರಿಶೀಲಿಸಲಾಗಿದೆ
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}