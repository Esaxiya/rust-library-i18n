use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// `peek()` ನೊಂದಿಗೆ ಪುನರಾವರ್ತಕವು ಮುಂದಿನ ಅಂಶಕ್ಕೆ ಐಚ್ al ಿಕ ಉಲ್ಲೇಖವನ್ನು ನೀಡುತ್ತದೆ.
///
///
/// ಈ `struct` ಅನ್ನು [`Iterator`] ನಲ್ಲಿ [`peekable`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// ಯಾವುದೂ ಇಲ್ಲದಿದ್ದರೂ ಸಹ, ಇಣುಕಿದ ಮೌಲ್ಯವನ್ನು ನೆನಪಿಡಿ.
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// `.peek()` ವಿಧಾನದಲ್ಲಿ ಯಾವುದೂ ಕಾಣಿಸದಿದ್ದರೆ ಪೀಕಬಲ್ ನೆನಪಿಟ್ಟುಕೊಳ್ಳಬೇಕು.
// ಇದು `.peek() ಎಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ;.peek();` ಅಥವಾ `.peek();.next();` ಆಧಾರವಾಗಿರುವ ಪುನರಾವರ್ತಕವನ್ನು ಏಕಕಾಲದಲ್ಲಿ ಮಾತ್ರ ಮುನ್ನಡೆಸುತ್ತದೆ.
// ಇದು ಸ್ವತಃ ಪುನರಾವರ್ತಕವನ್ನು ಬೆಸೆಯುವಂತೆ ಮಾಡುವುದಿಲ್ಲ.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// ಪುನರಾವರ್ತಕವನ್ನು ಮುಂದುವರಿಸದೆ next() ಮೌಲ್ಯಕ್ಕೆ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [`next`] ನಂತೆ, ಒಂದು ಮೌಲ್ಯವಿದ್ದರೆ, ಅದನ್ನು `Some(T)` ನಲ್ಲಿ ಸುತ್ತಿಡಲಾಗುತ್ತದೆ.
    /// ಆದರೆ ಪುನರಾವರ್ತನೆ ಮುಗಿದಿದ್ದರೆ, `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// [`next`]: Iterator::next
    ///
    /// ಏಕೆಂದರೆ `peek()` ಒಂದು ಉಲ್ಲೇಖವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಮತ್ತು ಅನೇಕ ಪುನರಾವರ್ತಕರು ಉಲ್ಲೇಖಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಿಸುತ್ತಾರೆ, ರಿಟರ್ನ್ ಮೌಲ್ಯವು ಎರಡು ಉಲ್ಲೇಖವಾಗಿರುವ ಗೊಂದಲಮಯ ಪರಿಸ್ಥಿತಿ ಇರಬಹುದು.
    /// ಕೆಳಗಿನ ಉದಾಹರಣೆಗಳಲ್ಲಿ ನೀವು ಈ ಪರಿಣಾಮವನ್ನು ನೋಡಬಹುದು.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() future ಗೆ ನೋಡಲು ನಮಗೆ ಅನುಮತಿಸುತ್ತದೆ
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // ನಾವು ಅನೇಕ ಬಾರಿ `peek` ಮಾಡಿದರೂ ಪುನರಾವರ್ತಕ ಮುನ್ನಡೆಯುವುದಿಲ್ಲ
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // ಪುನರಾವರ್ತಕ ಮುಗಿದ ನಂತರ, `peek()` ಕೂಡ ಆಗಿದೆ
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// ಪುನರಾವರ್ತಕವನ್ನು ಮುಂದುವರಿಸದೆ next() ಮೌಲ್ಯಕ್ಕೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [`next`] ನಂತೆ, ಒಂದು ಮೌಲ್ಯವಿದ್ದರೆ, ಅದನ್ನು `Some(T)` ನಲ್ಲಿ ಸುತ್ತಿಡಲಾಗುತ್ತದೆ.
    /// ಆದರೆ ಪುನರಾವರ್ತನೆ ಮುಗಿದಿದ್ದರೆ, `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// ಏಕೆಂದರೆ `peek_mut()` ಒಂದು ಉಲ್ಲೇಖವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಮತ್ತು ಅನೇಕ ಪುನರಾವರ್ತಕರು ಉಲ್ಲೇಖಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಿಸುತ್ತಾರೆ, ರಿಟರ್ನ್ ಮೌಲ್ಯವು ಎರಡು ಉಲ್ಲೇಖವಾಗಿರುವ ಗೊಂದಲಮಯ ಪರಿಸ್ಥಿತಿ ಇರಬಹುದು.
    /// ಕೆಳಗಿನ ಉದಾಹರಣೆಗಳಲ್ಲಿ ನೀವು ಈ ಪರಿಣಾಮವನ್ನು ನೋಡಬಹುದು.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // `peek()` ನಂತೆ, ಪುನರಾವರ್ತಕವನ್ನು ಮುಂದುವರಿಸದೆ ನಾವು future ಗೆ ನೋಡಬಹುದು.
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // ಪುನರಾವರ್ತಕಕ್ಕೆ ಇಣುಕಿ ನೋಡಿ ಮತ್ತು ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖದ ಹಿಂದೆ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿಸಿ.
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // ಪುನರಾವರ್ತಕ ಮುಂದುವರಿದಂತೆ ನಾವು ಹಾಕಿದ ಮೌಲ್ಯವು ಮತ್ತೆ ಕಾಣಿಸಿಕೊಳ್ಳುತ್ತದೆ.
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// ಷರತ್ತು ನಿಜವಾಗಿದ್ದರೆ ಈ ಪುನರಾವರ್ತಕದ ಮುಂದಿನ ಮೌಲ್ಯವನ್ನು ಸೇವಿಸಿ ಮತ್ತು ಹಿಂತಿರುಗಿಸಿ.
    /// ಈ ಪುನರಾವರ್ತಕದ ಮುಂದಿನ ಮೌಲ್ಯಕ್ಕಾಗಿ `func` `true` ಅನ್ನು ಹಿಂದಿರುಗಿಸಿದರೆ, ಅದನ್ನು ಸೇವಿಸಿ ಮತ್ತು ಹಿಂತಿರುಗಿಸಿ.
    /// ಇಲ್ಲದಿದ್ದರೆ, `None` ಅನ್ನು ಹಿಂತಿರುಗಿ.
    /// # Examples
    /// 0 ಗೆ ಸಮನಾಗಿದ್ದರೆ ಸಂಖ್ಯೆಯನ್ನು ಸೇವಿಸಿ.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // ಪುನರಾವರ್ತಕದ ಮೊದಲ ಐಟಂ 0;ಅದನ್ನು ಸೇವಿಸಿ.
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // ಹಿಂತಿರುಗಿದ ಮುಂದಿನ ಐಟಂ ಈಗ 1 ಆಗಿದೆ, ಆದ್ದರಿಂದ `consume` `false` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` `expected` ಗೆ ಸಮನಾಗಿರದಿದ್ದರೆ ಮುಂದಿನ ಐಟಂನ ಮೌಲ್ಯವನ್ನು ಉಳಿಸುತ್ತದೆ.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// 10 ಕ್ಕಿಂತ ಕಡಿಮೆ ಇರುವ ಯಾವುದೇ ಸಂಖ್ಯೆಯನ್ನು ಸೇವಿಸಿ.
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // ಎಲ್ಲಾ ಸಂಖ್ಯೆಗಳನ್ನು 10 ಕ್ಕಿಂತ ಕಡಿಮೆ ಸೇವಿಸಿ
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // ಹಿಂದಿರುಗಿದ ಮುಂದಿನ ಮೌಲ್ಯ 10 ಆಗಿರುತ್ತದೆ
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // ನಾವು `self.next()` ಎಂದು ಕರೆಯುವುದರಿಂದ, ನಾವು `self.peeked` ಅನ್ನು ಸೇವಿಸಿದ್ದೇವೆ.
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// ಮುಂದಿನ ಐಟಂ `expected` ಗೆ ಸಮನಾಗಿದ್ದರೆ ಅದನ್ನು ಸೇವಿಸಿ ಮತ್ತು ಹಿಂತಿರುಗಿಸಿ.
    /// # Example
    /// 0 ಗೆ ಸಮನಾಗಿದ್ದರೆ ಸಂಖ್ಯೆಯನ್ನು ಸೇವಿಸಿ.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // ಪುನರಾವರ್ತಕದ ಮೊದಲ ಐಟಂ 0;ಅದನ್ನು ಸೇವಿಸಿ.
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // ಹಿಂತಿರುಗಿದ ಮುಂದಿನ ಐಟಂ ಈಗ 1 ಆಗಿದೆ, ಆದ್ದರಿಂದ `consume` `false` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` `expected` ಗೆ ಸಮನಾಗಿರದಿದ್ದರೆ ಮುಂದಿನ ಐಟಂನ ಮೌಲ್ಯವನ್ನು ಉಳಿಸುತ್ತದೆ.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // ಸುರಕ್ಷತೆ: ಅಸುರಕ್ಷಿತ ಕಾರ್ಯವು ಅದೇ ಅವಶ್ಯಕತೆಗಳೊಂದಿಗೆ ಅಸುರಕ್ಷಿತ ಕಾರ್ಯಕ್ಕೆ ರವಾನಿಸುತ್ತದೆ
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}