use crate::{iter::FusedIterator, ops::Try};

/// ಅನಂತವಾಗಿ ಪುನರಾವರ್ತಿಸುವ ಪುನರಾವರ್ತಕ.
///
/// ಈ `struct` ಅನ್ನು [`Iterator`] ನಲ್ಲಿ [`cycle`] ವಿಧಾನದಿಂದ ರಚಿಸಲಾಗಿದೆ.
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // ಸೈಕಲ್ ಪುನರಾವರ್ತಕ ಖಾಲಿ ಅಥವಾ ಅನಂತವಾಗಿರುತ್ತದೆ
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // ಪ್ರಸ್ತುತ ಪುನರಾವರ್ತಕವನ್ನು ಸಂಪೂರ್ಣವಾಗಿ ಪುನರಾವರ್ತಿಸಿ.
        // ಇದು ಅವಶ್ಯಕವಾಗಿದೆ ಏಕೆಂದರೆ `self.orig` ಇಲ್ಲದಿದ್ದರೂ ಸಹ `self.iter` ಖಾಲಿಯಾಗಿರಬಹುದು
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // ಪೂರ್ಣ ಚಕ್ರವನ್ನು ಪೂರ್ಣಗೊಳಿಸಿ, ಸೈಕ್ಲಿಂಗ್ ಇಟರೇಟರ್ ಖಾಲಿಯಾಗಿದೆಯೆ ಅಥವಾ ಇಲ್ಲವೇ ಎಂಬುದನ್ನು ಗಮನದಲ್ಲಿರಿಸಿಕೊಳ್ಳಿ.
        // ಅನಂತ ಲೂಪ್ ಅನ್ನು ತಡೆಗಟ್ಟಲು ಖಾಲಿ ಪುನರಾವರ್ತಕದ ಸಂದರ್ಭದಲ್ಲಿ ನಾವು ಬೇಗನೆ ಹಿಂತಿರುಗಬೇಕಾಗಿದೆ
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // ಯಾವುದೇ `fold` ಅತಿಕ್ರಮಣವಿಲ್ಲ, ಏಕೆಂದರೆ `fold` ಗೆ `Cycle` ಗೆ ಹೆಚ್ಚು ಅರ್ಥವಿಲ್ಲ, ಮತ್ತು ಡೀಫಾಲ್ಟ್ ಗಿಂತ ಉತ್ತಮವಾಗಿ ನಾವು ಏನನ್ನೂ ಮಾಡಲು ಸಾಧ್ಯವಿಲ್ಲ.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}