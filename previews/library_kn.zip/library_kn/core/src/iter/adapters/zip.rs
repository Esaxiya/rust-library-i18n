use crate::cmp;
use crate::fmt::{self, Debug};
use crate::iter::{DoubleEndedIterator, ExactSizeIterator, FusedIterator, Iterator};
use crate::iter::{InPlaceIterable, SourceIter, TrustedLen};

/// ಏಕಕಾಲದಲ್ಲಿ ಇತರ ಎರಡು ಪುನರಾವರ್ತಕಗಳನ್ನು ಪುನರಾವರ್ತಿಸುವ ಪುನರಾವರ್ತಕ.
///
/// ಈ `struct` ಅನ್ನು [`Iterator::zip`] ನಿಂದ ರಚಿಸಲಾಗಿದೆ.
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
#[derive(Clone)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Zip<A, B> {
    a: A,
    b: B,
    // ಸೂಚ್ಯಂಕ, ಲೆನ್ ಮತ್ತು ಎ_ಲೆನ್ ಅನ್ನು ಜಿಪ್‌ನ ವಿಶೇಷ ಆವೃತ್ತಿಯಿಂದ ಮಾತ್ರ ಬಳಸಲಾಗುತ್ತದೆ
    index: usize,
    len: usize,
    a_len: usize,
}
impl<A: Iterator, B: Iterator> Zip<A, B> {
    pub(in crate::iter) fn new(a: A, b: B) -> Zip<A, B> {
        ZipImpl::new(a, b)
    }
    fn super_nth(&mut self, mut n: usize) -> Option<(A::Item, B::Item)> {
        while let Some(x) = Iterator::next(self) {
            if n == 0 {
                return Some(x);
            }
            n -= 1;
        }
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> Iterator for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        ZipImpl::next(self)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        ZipImpl::size_hint(self)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        ZipImpl::nth(self, n)
    }

    #[inline]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        // ಸುರಕ್ಷತೆ: `ZipImpl::__iterator_get_unchecked` ಒಂದೇ ಸುರಕ್ಷತೆಯನ್ನು ಹೊಂದಿದೆ
        // `Iterator::__iterator_get_unchecked` ನಂತೆ ಅವಶ್ಯಕತೆಗಳು.
        unsafe { ZipImpl::get_unchecked(self, idx) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> DoubleEndedIterator for Zip<A, B>
where
    A: DoubleEndedIterator + ExactSizeIterator,
    B: DoubleEndedIterator + ExactSizeIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)> {
        ZipImpl::next_back(self)
    }
}

// ಜಿಪ್ ವಿಶೇಷತೆ trait
#[doc(hidden)]
trait ZipImpl<A, B> {
    type Item;
    fn new(a: A, b: B) -> Self;
    fn next(&mut self) -> Option<Self::Item>;
    fn size_hint(&self) -> (usize, Option<usize>);
    fn nth(&mut self, n: usize) -> Option<Self::Item>;
    fn next_back(&mut self) -> Option<Self::Item>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator;
    // ಇದು `Iterator::__iterator_get_unchecked` ನಂತೆಯೇ ಸುರಕ್ಷತಾ ಅವಶ್ಯಕತೆಗಳನ್ನು ಹೊಂದಿದೆ
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item
    where
        Self: Iterator + TrustedRandomAccess;
}

// ಜನರಲ್ ಜಿಪ್ impl
#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);
    default fn new(a: A, b: B) -> Self {
        Zip {
            a,
            b,
            index: 0, // unused
            len: 0,   // unused
            a_len: 0, // unused
        }
    }

    #[inline]
    default fn next(&mut self) -> Option<(A::Item, B::Item)> {
        let x = self.a.next()?;
        let y = self.b.next()?;
        Some((x, y))
    }

    #[inline]
    default fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.super_nth(n)
    }

    #[inline]
    default fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        let a_sz = self.a.len();
        let b_sz = self.b.len();
        if a_sz != b_sz {
            // ಎ, ಬಿ ಅನ್ನು ಸಮಾನ ಉದ್ದಕ್ಕೆ ಹೊಂದಿಸಿ
            if a_sz > b_sz {
                for _ in 0..a_sz - b_sz {
                    self.a.next_back();
                }
            } else {
                for _ in 0..b_sz - a_sz {
                    self.b.next_back();
                }
            }
        }
        match (self.a.next_back(), self.b.next_back()) {
            (Some(x), Some(y)) => Some((x, y)),
            (None, None) => None,
            _ => unreachable!(),
        }
    }

    #[inline]
    default fn size_hint(&self) -> (usize, Option<usize>) {
        let (a_lower, a_upper) = self.a.size_hint();
        let (b_lower, b_upper) = self.b.size_hint();

        let lower = cmp::min(a_lower, b_lower);

        let upper = match (a_upper, b_upper) {
            (Some(x), Some(y)) => Some(cmp::min(x, y)),
            (Some(x), None) => Some(x),
            (None, Some(y)) => Some(y),
            (None, None) => None,
        };

        (lower, upper)
    }

    default unsafe fn get_unchecked(&mut self, _idx: usize) -> <Self as Iterator>::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: TrustedRandomAccess + Iterator,
    B: TrustedRandomAccess + Iterator,
{
    fn new(a: A, b: B) -> Self {
        let a_len = a.size();
        let len = cmp::min(a_len, b.size());
        Zip { a, b, index: 0, len, a_len }
    }

    #[inline]
    fn next(&mut self) -> Option<(A::Item, B::Item)> {
        if self.index < self.len {
            let i = self.index;
            self.index += 1;
            // ಸುರಕ್ಷತೆ: `i` `self.len` ಗಿಂತ ಚಿಕ್ಕದಾಗಿದೆ, ಆದ್ದರಿಂದ `self.a.len()` ಮತ್ತು `self.b.len()` ಗಿಂತ ಚಿಕ್ಕದಾಗಿದೆ
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else if A::MAY_HAVE_SIDE_EFFECT && self.index < self.a_len {
            let i = self.index;
            self.index += 1;
            self.len += 1;
            // ಮೂಲ ಅನುಷ್ಠಾನದ ಸಂಭಾವ್ಯ ಅಡ್ಡಪರಿಣಾಮಗಳನ್ನು ಹೊಂದಿಸಿ ಸುರಕ್ಷತೆ: ನಾವು ಅದನ್ನು `i` <`self.a.len()` ಎಂದು ಪರಿಶೀಲಿಸಿದ್ದೇವೆ
            //
            unsafe {
                self.a.__iterator_get_unchecked(i);
            }
            None
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len - self.index;
        (len, Some(len))
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let delta = cmp::min(n, self.len - self.index);
        let end = self.index + delta;
        while self.index < end {
            let i = self.index;
            self.index += 1;
            if A::MAY_HAVE_SIDE_EFFECT {
                // ಸುರಕ್ಷತೆ: `delta` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡಲು `cmp::min` ಬಳಕೆ
                // `end` `self.len` ಗಿಂತ ಚಿಕ್ಕದಾಗಿದೆ ಅಥವಾ ಸಮನಾಗಿರುತ್ತದೆ ಎಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ, ಆದ್ದರಿಂದ `i` ಸಹ `self.len` ಗಿಂತ ಚಿಕ್ಕದಾಗಿದೆ.
                //
                unsafe {
                    self.a.__iterator_get_unchecked(i);
                }
            }
            if B::MAY_HAVE_SIDE_EFFECT {
                // ಸುರಕ್ಷತೆ: ಮೇಲಿನಂತೆಯೇ.
                unsafe {
                    self.b.__iterator_get_unchecked(i);
                }
            }
        }

        self.super_nth(n - delta)
    }

    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        if A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT {
            let sz_a = self.a.size();
            let sz_b = self.b.size();
            // A, b ಅನ್ನು ಸಮಾನ ಉದ್ದಕ್ಕೆ ಹೊಂದಿಸಿ, `next_back` ನ ಮೊದಲ ಕರೆ ಮಾತ್ರ ಇದನ್ನು ಮಾಡುತ್ತದೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ, ಇಲ್ಲದಿದ್ದರೆ ನಾವು `get_unchecked()` ಗೆ ಕರೆ ಮಾಡಿದ ನಂತರ `self.next_back()` ಗೆ ಕರೆಗಳ ಮೇಲಿನ ನಿರ್ಬಂಧವನ್ನು ಮುರಿಯುತ್ತೇವೆ.
            //
            //
            if sz_a != sz_b {
                let sz_a = self.a.size();
                if A::MAY_HAVE_SIDE_EFFECT && sz_a > self.len {
                    for _ in 0..sz_a - self.len {
                        self.a.next_back();
                    }
                    self.a_len = self.len;
                }
                let sz_b = self.b.size();
                if B::MAY_HAVE_SIDE_EFFECT && sz_b > self.len {
                    for _ in 0..sz_b - self.len {
                        self.b.next_back();
                    }
                }
            }
        }
        if self.index < self.len {
            self.len -= 1;
            self.a_len -= 1;
            let i = self.len;
            // ಸುರಕ್ಷತೆ: `i` ಹಿಂದಿನ `self.len` ಮೌಲ್ಯಕ್ಕಿಂತ ಚಿಕ್ಕದಾಗಿದೆ,
            // ಇದು `self.a.len()` ಮತ್ತು `self.b.len()` ಗಿಂತ ಚಿಕ್ಕದಾಗಿದೆ ಅಥವಾ ಸಮಾನವಾಗಿರುತ್ತದೆ
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else {
            None
        }
    }

    #[inline]
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item {
        let idx = self.index + idx;
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `Iterator::__iterator_get_unchecked` ಗಾಗಿ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
        //
        unsafe { (self.a.__iterator_get_unchecked(idx), self.b.__iterator_get_unchecked(idx)) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> ExactSizeIterator for Zip<A, B>
where
    A: ExactSizeIterator,
    B: ExactSizeIterator,
{
}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<A, B> TrustedRandomAccess for Zip<A, B>
where
    A: TrustedRandomAccess,
    B: TrustedRandomAccess,
{
    const MAY_HAVE_SIDE_EFFECT: bool = A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT;
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A, B> FusedIterator for Zip<A, B>
where
    A: FusedIterator,
    B: FusedIterator,
{
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, B> TrustedLen for Zip<A, B>
where
    A: TrustedLen,
    B: TrustedLen,
{
}

// ಹೊರತೆಗೆಯಬಹುದಾದ "source" ಎಂದು ಜಿಪ್ ಪುನರಾವರ್ತನೆಯ ಎಡಭಾಗವನ್ನು ಅನಿಯಂತ್ರಿತವಾಗಿ ಆಯ್ಕೆ ಮಾಡುತ್ತದೆ, ಎರಡನ್ನೂ ಪ್ರಯತ್ನಿಸಲು negative ಣಾತ್ಮಕ trait bounds ಅಗತ್ಯವಿರುತ್ತದೆ
//
#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S, A, B> SourceIter for Zip<A, B>
where
    A: SourceIter<Source = S>,
    B: Iterator,
    S: Iterator,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // ಸುರಕ್ಷತೆ: ಅಸುರಕ್ಷಿತ ಕಾರ್ಯವು ಅದೇ ಅವಶ್ಯಕತೆಗಳೊಂದಿಗೆ ಅಸುರಕ್ಷಿತ ಕಾರ್ಯಕ್ಕೆ ರವಾನಿಸುತ್ತದೆ
        unsafe { SourceIter::as_inner(&mut self.a) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
// ಐಟಂಗೆ ಸೀಮಿತವಾಗಿದೆ: ಜಿಪ್‌ನ ಟ್ರಸ್ಟೆಡ್ ರಾಂಡಮ್ ಆಕ್ಸೆಸ್ ಬಳಕೆ ಮತ್ತು ಮೂಲದ ಡ್ರಾಪ್ ಅನುಷ್ಠಾನದ ನಡುವಿನ ಸಂವಹನವು ಸ್ಪಷ್ಟವಾಗಿಲ್ಲವಾದ್ದರಿಂದ ನಕಲಿಸಿ.
//
// ಮೂಲವನ್ನು ಎಷ್ಟು ಬಾರಿ ತಾರ್ಕಿಕವಾಗಿ ಮುಂದುವರೆಸಲಾಗಿದೆ ಎಂಬುದನ್ನು ಹಿಂದಿರುಗಿಸುವ ಹೆಚ್ಚುವರಿ ವಿಧಾನ (next()) ಗೆ ಕರೆ ಮಾಡದೆ ಮೂಲದ ಉಳಿದ ಭಾಗವನ್ನು ಸರಿಯಾಗಿ ಬಿಡಲು ಅಗತ್ಯವಾಗಿರುತ್ತದೆ.
//
//
unsafe impl<A: InPlaceIterable, B: Iterator> InPlaceIterable for Zip<A, B> where A::Item: Copy {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Debug, B: Debug> Debug for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        ZipFmt::fmt(self, f)
    }
}

trait ZipFmt<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result;
}

impl<A: Debug, B: Debug> ZipFmt<A, B> for Zip<A, B> {
    default fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Zip").field("a", &self.a).field("b", &self.b).finish()
    }
}

impl<A: Debug + TrustedRandomAccess, B: Debug + TrustedRandomAccess> ZipFmt<A, B> for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // ಒಳಗೊಂಡಿರುವ ಪುನರಾವರ್ತಕರ ಮೇಲೆ ಎಫ್‌ಎಮ್‌ಟಿಯನ್ನು ಕರೆಯುವುದು *ಸುರಕ್ಷಿತವಲ್ಲ*, ಏಕೆಂದರೆ ನಾವು ಪುನರಾವರ್ತಿಸಲು ಪ್ರಾರಂಭಿಸಿದ ನಂತರ ಅವು ವಿಚಿತ್ರವಾದ, ಅಸುರಕ್ಷಿತ, ರಾಜ್ಯಗಳಲ್ಲಿವೆ.
        //
        f.debug_struct("Zip").finish()
    }
}

/// ಯಾದೃಚ್-ಿಕವಾಗಿ ಪ್ರವೇಶಿಸಬಹುದಾದ ವಸ್ತುಗಳನ್ನು ಪರಿಣಾಮಕಾರಿಯಾಗಿ ಪುನರಾವರ್ತಿಸುವವ
///
/// # Safety
///
/// ಪುನರಾವರ್ತಕನ `size_hint` ಕರೆ ಮಾಡಲು ನಿಖರ ಮತ್ತು ಅಗ್ಗವಾಗಿರಬೇಕು.
///
/// `size` ಅತಿಕ್ರಮಿಸದಿರಬಹುದು.
///
/// `<Self as Iterator>::__iterator_get_unchecked` ಈ ಕೆಳಗಿನ ಷರತ್ತುಗಳನ್ನು ಪೂರೈಸಿದಲ್ಲಿ ಕರೆ ಮಾಡಲು ಸುರಕ್ಷಿತವಾಗಿರಬೇಕು.
///
/// 1. `0 <= idx` ಮತ್ತು `idx < self.size()`.
/// 2. `self: !Clone` ಆಗಿದ್ದರೆ, `get_unchecked` ಅನ್ನು ಒಂದೇ ಸೂಚ್ಯಂಕದೊಂದಿಗೆ `self` ನಲ್ಲಿ ಒಂದಕ್ಕಿಂತ ಹೆಚ್ಚು ಬಾರಿ ಕರೆಯಲಾಗುವುದಿಲ್ಲ.
/// 3. `self.get_unchecked(idx)` ಅನ್ನು ಕರೆದ ನಂತರ `next_back` ಅನ್ನು ಹೆಚ್ಚಿನ `self.size() - idx - 1` ಸಮಯಗಳಲ್ಲಿ ಮಾತ್ರ ಕರೆಯಲಾಗುತ್ತದೆ.
/// 4. `get_unchecked` ಅನ್ನು ಕರೆದ ನಂತರ, ಈ ಕೆಳಗಿನ ವಿಧಾನಗಳನ್ನು ಮಾತ್ರ `self` ನಲ್ಲಿ ಕರೆಯಲಾಗುತ್ತದೆ:
///     * `std::clone::Clone::clone()`
///     * `std::iter::Iterator::size_hint()`
///     * `std::iter::Iterator::next_back()`
///     * `std::iter::Iterator::__iterator_get_unchecked()`
///     * `std::iter::TrustedRandomAccess::size()`
///
/// ಇದಲ್ಲದೆ, ಈ ಷರತ್ತುಗಳನ್ನು ಪೂರೈಸಿದರೆ, ಅದು ಇದನ್ನು ಖಾತರಿಪಡಿಸಬೇಕು:
///
/// * ಇದು `size_hint` ನಿಂದ ಹಿಂತಿರುಗಿದ ಮೌಲ್ಯವನ್ನು ಬದಲಾಯಿಸುವುದಿಲ್ಲ
/// * `get_unchecked` ಗೆ ಕರೆ ಮಾಡಿದ ನಂತರ `self` ನಲ್ಲಿ ಮೇಲೆ ಪಟ್ಟಿ ಮಾಡಲಾದ ವಿಧಾನಗಳನ್ನು ಕರೆಯುವುದು ಸುರಕ್ಷಿತವಾಗಿರಬೇಕು, ಅಗತ್ಯವಿರುವ traits ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗಿದೆ ಎಂದು uming ಹಿಸಿ.
///
/// * `get_unchecked` ಗೆ ಕರೆ ಮಾಡಿದ ನಂತರ `self` ಅನ್ನು ಬಿಡಲು ಸಹ ಸುರಕ್ಷಿತವಾಗಿರಬೇಕು.
///
///
///
///
#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
#[rustc_specialization_trait]
pub unsafe trait TrustedRandomAccess: Sized {
    // ಅನುಕೂಲಕರ ವಿಧಾನ.
    fn size(&self) -> usize
    where
        Self: Iterator,
    {
        self.size_hint().0
    }
    /// `true` ಪುನರಾವರ್ತಕ ಅಂಶವನ್ನು ಪಡೆದರೆ ಅಡ್ಡಪರಿಣಾಮಗಳು ಉಂಟಾಗಬಹುದು.
    /// ಆಂತರಿಕ ಪುನರಾವರ್ತಕಗಳನ್ನು ಗಣನೆಗೆ ತೆಗೆದುಕೊಳ್ಳಲು ಮರೆಯದಿರಿ.
    const MAY_HAVE_SIDE_EFFECT: bool;
}

/// `Iterator::__iterator_get_unchecked` ನಂತೆ, ಆದರೆ ಕಂಪೈಲರ್ `U: TrustedRandomAccess` ಎಂದು ತಿಳಿಯಲು ಅಗತ್ಯವಿಲ್ಲ.
///
///
/// ## Safety
///
/// `get_unchecked` ಅನ್ನು ನೇರವಾಗಿ ಕರೆಯುವ ಅದೇ ಅವಶ್ಯಕತೆಗಳು.
#[doc(hidden)]
pub(in crate::iter::adapters) unsafe fn try_get_unchecked<I>(it: &mut I, idx: usize) -> I::Item
where
    I: Iterator,
{
    // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `Iterator::__iterator_get_unchecked` ಗಾಗಿ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
    //
    unsafe { it.try_get_unchecked(idx) }
}

unsafe trait SpecTrustedRandomAccess: Iterator {
    /// `Self: TrustedRandomAccess` ಆಗಿದ್ದರೆ, `Iterator::__iterator_get_unchecked(self, index)` ಗೆ ಕರೆ ಮಾಡುವುದು ಸುರಕ್ಷಿತವಾಗಿರಬೇಕು.
    ///
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item;
}

unsafe impl<I: Iterator> SpecTrustedRandomAccess for I {
    default unsafe fn try_get_unchecked(&mut self, _: usize) -> Self::Item {
        panic!("Should only be called on TrustedRandomAccess iterators");
    }
}

unsafe impl<I: Iterator + TrustedRandomAccess> SpecTrustedRandomAccess for I {
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `Iterator::__iterator_get_unchecked` ಗಾಗಿ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
        //
        unsafe { self.__iterator_get_unchecked(index) }
    }
}