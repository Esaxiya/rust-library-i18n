/// ಅದರ ನಿಖರವಾದ ಉದ್ದವನ್ನು ತಿಳಿದಿರುವ ಪುನರಾವರ್ತಕ.
///
/// ಅನೇಕ [`ಇಟರೇಟರ್] ಗಳು ಅವರು ಎಷ್ಟು ಬಾರಿ ಪುನರಾವರ್ತಿಸುತ್ತಾರೆಂದು ತಿಳಿದಿಲ್ಲ, ಆದರೆ ಕೆಲವರು ಹಾಗೆ ಮಾಡುತ್ತಾರೆ.
/// ಪುನರಾವರ್ತಕನಿಗೆ ಅದು ಎಷ್ಟು ಬಾರಿ ಪುನರಾವರ್ತಿಸಬಹುದು ಎಂದು ತಿಳಿದಿದ್ದರೆ, ಆ ಮಾಹಿತಿಗೆ ಪ್ರವೇಶವನ್ನು ಒದಗಿಸುವುದು ಉಪಯುಕ್ತವಾಗಿರುತ್ತದೆ.
/// ಉದಾಹರಣೆಗೆ, ನೀವು ಹಿಂದಕ್ಕೆ ಪುನರಾವರ್ತಿಸಲು ಬಯಸಿದರೆ, ಅಂತ್ಯ ಎಲ್ಲಿದೆ ಎಂದು ತಿಳಿಯುವುದು ಉತ್ತಮ ಆರಂಭ.
///
/// `ExactSizeIterator` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವಾಗ, ನೀವು [`Iterator`] ಅನ್ನು ಸಹ ಕಾರ್ಯಗತಗೊಳಿಸಬೇಕು.
/// ಹಾಗೆ ಮಾಡುವಾಗ, [`Iterator::size_hint`] * ನ ಅನುಷ್ಠಾನವು ಪುನರಾವರ್ತಕದ ನಿಖರವಾದ ಗಾತ್ರವನ್ನು ಹಿಂದಿರುಗಿಸಬೇಕು.
///
/// [`len`] ವಿಧಾನವು ಡೀಫಾಲ್ಟ್ ಅನುಷ್ಠಾನವನ್ನು ಹೊಂದಿದೆ, ಆದ್ದರಿಂದ ನೀವು ಸಾಮಾನ್ಯವಾಗಿ ಅದನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಬಾರದು.
/// ಆದಾಗ್ಯೂ, ಡೀಫಾಲ್ಟ್ ಗಿಂತ ಹೆಚ್ಚು ಕಾರ್ಯಕ್ಷಮತೆಯ ಅನುಷ್ಠಾನವನ್ನು ಒದಗಿಸಲು ನಿಮಗೆ ಸಾಧ್ಯವಾಗಬಹುದು, ಆದ್ದರಿಂದ ಈ ಸಂದರ್ಭದಲ್ಲಿ ಅದನ್ನು ಅತಿಕ್ರಮಿಸುವುದು ಅರ್ಥಪೂರ್ಣವಾಗಿದೆ.
///
///
/// ಈ trait ಸುರಕ್ಷಿತ trait ಎಂಬುದನ್ನು ಗಮನಿಸಿ ಮತ್ತು ಹಿಂದಿರುಗಿದ ಉದ್ದ ಸರಿಯಾಗಿದೆ ಎಂದು *ಅಲ್ಲ* ಮತ್ತು * ಖಾತರಿಪಡಿಸುವುದಿಲ್ಲ.
/// ಇದರರ್ಥ `unsafe` ಕೋಡ್ ** [`Iterator::size_hint`] ನ ಸರಿಯಾದತೆಯನ್ನು ಅವಲಂಬಿಸಬಾರದು.
/// ಅಸ್ಥಿರ ಮತ್ತು ಅಸುರಕ್ಷಿತ [`TrustedLen`](super::marker::TrustedLen) trait ಈ ಹೆಚ್ಚುವರಿ ಖಾತರಿಯನ್ನು ನೀಡುತ್ತದೆ.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// ಮೂಲ ಬಳಕೆ:
///
/// ```
/// // ಒಂದು ಸೀಮಿತ ಶ್ರೇಣಿಯು ಎಷ್ಟು ಬಾರಿ ಪುನರಾವರ್ತಿಸುತ್ತದೆ ಎಂದು ತಿಳಿದಿದೆ
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs] ನಲ್ಲಿ, ನಾವು [`Iterator`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದ್ದೇವೆ, `Counter`.
/// ಇದಕ್ಕಾಗಿ `ExactSizeIterator` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸೋಣ:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // ಉಳಿದ ಸಂಖ್ಯೆಯ ಪುನರಾವರ್ತನೆಗಳನ್ನು ನಾವು ಸುಲಭವಾಗಿ ಲೆಕ್ಕ ಹಾಕಬಹುದು.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // ಮತ್ತು ಈಗ ನಾವು ಅದನ್ನು ಬಳಸಬಹುದು!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// ಪುನರಾವರ್ತಕದ ನಿಖರವಾದ ಉದ್ದವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [`None`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುವ ಮೊದಲು, ಪುನರಾವರ್ತಕವು [`Some(T)`] ಮೌಲ್ಯಕ್ಕಿಂತ ನಿಖರವಾಗಿ `len()` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ ಎಂದು ಅನುಷ್ಠಾನವು ಖಚಿತಪಡಿಸುತ್ತದೆ.
    ///
    /// ಈ ವಿಧಾನವು ಡೀಫಾಲ್ಟ್ ಅನುಷ್ಠಾನವನ್ನು ಹೊಂದಿದೆ, ಆದ್ದರಿಂದ ನೀವು ಸಾಮಾನ್ಯವಾಗಿ ಅದನ್ನು ನೇರವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸಬಾರದು.
    /// ಆದಾಗ್ಯೂ, ನೀವು ಹೆಚ್ಚು ಪರಿಣಾಮಕಾರಿ ಅನುಷ್ಠಾನವನ್ನು ಒದಗಿಸಬಹುದಾದರೆ, ನೀವು ಹಾಗೆ ಮಾಡಬಹುದು.
    /// ಉದಾಹರಣೆಗಾಗಿ [trait-level] ಡಾಕ್ಸ್ ನೋಡಿ.
    ///
    /// ಈ ಕಾರ್ಯವು [`Iterator::size_hint`] ಕಾರ್ಯದಂತೆಯೇ ಸುರಕ್ಷತಾ ಖಾತರಿಗಳನ್ನು ಹೊಂದಿದೆ.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// // ಒಂದು ಸೀಮಿತ ಶ್ರೇಣಿಯು ಎಷ್ಟು ಬಾರಿ ಪುನರಾವರ್ತಿಸುತ್ತದೆ ಎಂದು ತಿಳಿದಿದೆ
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: ಈ ಪ್ರತಿಪಾದನೆಯು ವಿಪರೀತ ರಕ್ಷಣಾತ್ಮಕವಾಗಿದೆ, ಆದರೆ ಇದು ಅಸ್ಥಿರತೆಯನ್ನು ಪರಿಶೀಲಿಸುತ್ತದೆ
        // trait ನಿಂದ ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.
        // ಈ trait rust-ಆಂತರಿಕವಾಗಿದ್ದರೆ, ನಾವು debug_assert ಅನ್ನು ಬಳಸಬಹುದು;assert_eq!ಎಲ್ಲಾ Rust ಬಳಕೆದಾರ ಅನುಷ್ಠಾನಗಳನ್ನು ಸಹ ಪರಿಶೀಲಿಸುತ್ತದೆ.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// ಪುನರಾವರ್ತಕ ಖಾಲಿಯಾಗಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ವಿಧಾನವು [`ExactSizeIterator::len()`] ಅನ್ನು ಬಳಸಿಕೊಂಡು ಡೀಫಾಲ್ಟ್ ಅನುಷ್ಠಾನವನ್ನು ಹೊಂದಿದೆ, ಆದ್ದರಿಂದ ನೀವು ಅದನ್ನು ನೀವೇ ಕಾರ್ಯಗತಗೊಳಿಸುವ ಅಗತ್ಯವಿಲ್ಲ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}