// ನಿರ್ಲಕ್ಷಿಸು-ಅಚ್ಚುಕಟ್ಟಾದ-ಕಡತ-ಉದ್ದ ಈ ಫೈಲ್ ಬಹುತೇಕ ಪ್ರತ್ಯೇಕವಾಗಿ `Iterator` ನ ವ್ಯಾಖ್ಯಾನವನ್ನು ಒಳಗೊಂಡಿದೆ.
// ನಾವು ಅದನ್ನು ಬಹು ಫೈಲ್‌ಗಳಾಗಿ ವಿಭಜಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// ಪುನರಾವರ್ತಕರೊಂದಿಗೆ ವ್ಯವಹರಿಸಲು ಒಂದು ಇಂಟರ್ಫೇಸ್.
///
/// ಇದು ಮುಖ್ಯ ಪುನರಾವರ್ತಕ trait ಆಗಿದೆ.
/// ಸಾಮಾನ್ಯವಾಗಿ ಪುನರಾವರ್ತಕರ ಪರಿಕಲ್ಪನೆಯ ಬಗ್ಗೆ ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ, ದಯವಿಟ್ಟು [module-level documentation] ನೋಡಿ.
/// ನಿರ್ದಿಷ್ಟವಾಗಿ, ನೀವು [implement `Iterator`][impl] ಹೇಗೆ ಎಂದು ತಿಳಿಯಲು ಬಯಸಬಹುದು.
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// ಅಂಶಗಳ ಪ್ರಕಾರವನ್ನು ಪುನರಾವರ್ತಿಸಲಾಗುತ್ತದೆ.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// ಪುನರಾವರ್ತಕವನ್ನು ಮುನ್ನಡೆಸುತ್ತದೆ ಮತ್ತು ಮುಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಪುನರಾವರ್ತನೆ ಮುಗಿದ ನಂತರ [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ವೈಯಕ್ತಿಕ ಪುನರಾವರ್ತಕ ಅನುಷ್ಠಾನಗಳು ಪುನರಾವರ್ತನೆಯನ್ನು ಪುನರಾರಂಭಿಸಲು ಆಯ್ಕೆಮಾಡಬಹುದು, ಮತ್ತು ಆದ್ದರಿಂದ `next()` ಅನ್ನು ಮತ್ತೆ ಕರೆಯುವುದರಿಂದ ಕೆಲವು ಹಂತದಲ್ಲಿ ಮತ್ತೆ [`Some(Item)`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲು ಪ್ರಾರಂಭಿಸಬಹುದು ಅಥವಾ ಇರಬಹುದು.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // next() ಗೆ ಕರೆ ಮುಂದಿನ ಮೌಲ್ಯವನ್ನು ನೀಡುತ್ತದೆ ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... ತದನಂತರ ಅದು ಮುಗಿದ ನಂತರ ಯಾವುದೂ ಇಲ್ಲ.
    /// assert_eq!(None, iter.next());
    ///
    /// // ಹೆಚ್ಚಿನ ಕರೆಗಳು `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸಬಹುದು ಅಥವಾ ಹಿಂತಿರುಗಿಸಬಾರದು.ಇಲ್ಲಿ, ಅವರು ಯಾವಾಗಲೂ ತಿನ್ನುವೆ.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// ಪುನರಾವರ್ತಕದ ಉಳಿದ ಉದ್ದದ ಗಡಿಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ನಿರ್ದಿಷ್ಟವಾಗಿ ಹೇಳುವುದಾದರೆ, `size_hint()` ಒಂದು ಟಪಲ್ ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಅಲ್ಲಿ ಮೊದಲ ಅಂಶವು ಕಡಿಮೆ ಬೌಂಡ್ ಆಗಿರುತ್ತದೆ ಮತ್ತು ಎರಡನೆಯ ಅಂಶವು ಮೇಲಿನ ಬೌಂಡ್ ಆಗಿದೆ.
    ///
    /// ಹಿಂತಿರುಗಿದ ಟಪಲ್‌ನ ದ್ವಿತೀಯಾರ್ಧವು [`ಆಯ್ಕೆ`]`<`[`ಬಳಕೆ`] `>` ಆಗಿದೆ.
    /// ಇಲ್ಲಿ [`None`] ಎಂದರೆ ಯಾವುದೇ ಮೇಲ್ಭಾಗದ ಬೌಂಡ್ ಇಲ್ಲ, ಅಥವಾ ಮೇಲಿನ ಬೌಂಡ್ [`usize`] ಗಿಂತ ದೊಡ್ಡದಾಗಿದೆ.
    ///
    /// # ಅನುಷ್ಠಾನ ಟಿಪ್ಪಣಿಗಳು
    ///
    /// ಪುನರಾವರ್ತಕ ಅನುಷ್ಠಾನವು ಘೋಷಿತ ಸಂಖ್ಯೆಯ ಅಂಶಗಳನ್ನು ನೀಡುತ್ತದೆ ಎಂದು ಜಾರಿಗೊಳಿಸಲಾಗಿಲ್ಲ.ದೋಷಯುಕ್ತ ಪುನರಾವರ್ತಕವು ಕಡಿಮೆ ಬೌಂಡ್‌ಗಿಂತ ಕಡಿಮೆ ಅಥವಾ ಅಂಶಗಳ ಮೇಲಿನ ಬೌಂಡ್‌ಗಿಂತ ಹೆಚ್ಚಿನದನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// `size_hint()` ಇಟರೇಟರ್‌ನ ಅಂಶಗಳಿಗೆ ಜಾಗವನ್ನು ಕಾಯ್ದಿರಿಸುವಂತಹ ಆಪ್ಟಿಮೈಸೇಷನ್‌ಗಳಿಗಾಗಿ ಇದನ್ನು ಪ್ರಾಥಮಿಕವಾಗಿ ಬಳಸಲು ಉದ್ದೇಶಿಸಲಾಗಿದೆ, ಆದರೆ ಉದಾ., ವಿಶ್ವಾಸಾರ್ಹವಲ್ಲ, ಅಸುರಕ್ಷಿತ ಕೋಡ್‌ನಲ್ಲಿ ಬೌಂಡ್ ಚೆಕ್‌ಗಳನ್ನು ಬಿಟ್ಟುಬಿಡಿ.
    /// `size_hint()` ನ ತಪ್ಪಾದ ಅನುಷ್ಠಾನವು ಮೆಮೊರಿ ಸುರಕ್ಷತೆಯ ಉಲ್ಲಂಘನೆಗೆ ಕಾರಣವಾಗಬಾರದು.
    ///
    /// ಅದು ಅನುಷ್ಠಾನವು ಸರಿಯಾದ ಅಂದಾಜು ನೀಡಬೇಕು, ಇಲ್ಲದಿದ್ದರೆ ಅದು trait ನ ಪ್ರೋಟೋಕಾಲ್‌ನ ಉಲ್ಲಂಘನೆಯಾಗುತ್ತದೆ.
    ///
    /// ಡೀಫಾಲ್ಟ್ ಅನುಷ್ಠಾನವು `(0,` [`ಯಾವುದೂ ಇಲ್ಲ]]`) `ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಅದು ಯಾವುದೇ ಪುನರಾವರ್ತಕರಿಗೆ ಸರಿಯಾಗಿರುತ್ತದೆ.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// ಹೆಚ್ಚು ಸಂಕೀರ್ಣ ಉದಾಹರಣೆ:
    ///
    /// ```
    /// // ಶೂನ್ಯದಿಂದ ಹತ್ತರವರೆಗಿನ ಸಮ ಸಂಖ್ಯೆಗಳು.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // ನಾವು ಶೂನ್ಯದಿಂದ ಹತ್ತು ಬಾರಿ ಪುನರಾವರ್ತಿಸಬಹುದು.
    /// // filter() ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸದೆ ಅದು ಐದು ಎಂದು ತಿಳಿಯುವುದು ನಿಖರವಾಗಿ ಸಾಧ್ಯವಿಲ್ಲ.
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // chain() ನೊಂದಿಗೆ ಇನ್ನೂ ಐದು ಸಂಖ್ಯೆಗಳನ್ನು ಸೇರಿಸೋಣ
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // ಈಗ ಎರಡೂ ಗಡಿಗಳನ್ನು ಐದು ಹೆಚ್ಚಿಸಲಾಗಿದೆ
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// ಮೇಲಿನ ಬೌಂಡ್‌ಗಾಗಿ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತಿದೆ:
    ///
    /// ```
    /// // ಅನಂತ ಪುನರಾವರ್ತಕವು ಮೇಲಿನ ಬೌಂಡ್ ಅನ್ನು ಹೊಂದಿಲ್ಲ ಮತ್ತು ಗರಿಷ್ಠ ಕಡಿಮೆ ಬೌಂಡ್ ಅನ್ನು ಹೊಂದಿರುತ್ತದೆ
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// ಪುನರಾವರ್ತಕವನ್ನು ಬಳಸುತ್ತದೆ, ಪುನರಾವರ್ತನೆಗಳ ಸಂಖ್ಯೆಯನ್ನು ಎಣಿಸಿ ಅದನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ವಿಧಾನವು [`None`] ಅನ್ನು ಎದುರಿಸುವವರೆಗೆ [`next`] ಅನ್ನು ಪದೇ ಪದೇ ಕರೆಯುತ್ತದೆ, ಇದು [`Some`] ಅನ್ನು ಎಷ್ಟು ಬಾರಿ ನೋಡಿದೆ ಎಂಬುದನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    /// ಪುನರಾವರ್ತಕವು ಯಾವುದೇ ಅಂಶಗಳನ್ನು ಹೊಂದಿಲ್ಲದಿದ್ದರೂ ಸಹ [`next`] ಅನ್ನು ಒಮ್ಮೆಯಾದರೂ ಕರೆಯಬೇಕಾಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # ಉಕ್ಕಿ ಹರಿಯುವ ವರ್ತನೆ
    ///
    /// ಈ ವಿಧಾನವು ಓವರ್‌ಫ್ಲೋಗಳ ವಿರುದ್ಧ ಯಾವುದೇ ಕಾವಲು ಮಾಡುವುದಿಲ್ಲ, ಆದ್ದರಿಂದ [`usize::MAX`] ಗಿಂತ ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ಹೊಂದಿರುವ ಇಟರೇಟರ್‌ನ ಅಂಶಗಳನ್ನು ಎಣಿಸುವುದರಿಂದ ತಪ್ಪಾದ ಫಲಿತಾಂಶ ಅಥವಾ panics ಅನ್ನು ಉತ್ಪಾದಿಸಲಾಗುತ್ತದೆ.
    ///
    /// ಡೀಬಗ್ ಪ್ರತಿಪಾದನೆಗಳನ್ನು ಸಕ್ರಿಯಗೊಳಿಸಿದರೆ, panic ಅನ್ನು ಖಾತರಿಪಡಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// ಪುನರಾವರ್ತಕವು [`usize::MAX`] ಗಿಂತ ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ಹೊಂದಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರಬಹುದು.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// ಪುನರಾವರ್ತಕವನ್ನು ಬಳಸುತ್ತದೆ, ಕೊನೆಯ ಅಂಶವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ವಿಧಾನವು [`None`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುವವರೆಗೆ ಪುನರಾವರ್ತಕವನ್ನು ಮೌಲ್ಯಮಾಪನ ಮಾಡುತ್ತದೆ.
    /// ಹಾಗೆ ಮಾಡುವಾಗ, ಇದು ಪ್ರಸ್ತುತ ಅಂಶವನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡುತ್ತದೆ.
    /// [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಿದ ನಂತರ, `last()` ಅದು ನೋಡಿದ ಕೊನೆಯ ಅಂಶವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// `n` ಅಂಶಗಳಿಂದ ಪುನರಾವರ್ತಕವನ್ನು ಮುನ್ನಡೆಸುತ್ತದೆ.
    ///
    /// ಈ ವಿಧಾನವು [`None`] ಎದುರಾಗುವವರೆಗೆ [`next`] ಅನ್ನು `n` ಬಾರಿ ಕರೆ ಮಾಡುವ ಮೂಲಕ `n` ಅಂಶಗಳನ್ನು ಕುತೂಹಲದಿಂದ ಬಿಟ್ಟುಬಿಡುತ್ತದೆ.
    ///
    /// `advance_by(n)` ಪುನರಾವರ್ತಕವು `n` ಅಂಶಗಳಿಂದ ಯಶಸ್ವಿಯಾಗಿ ಮುಂದುವರಿದರೆ [`Ok(())`][Ok] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಥವಾ [`None`] ಎದುರಾದರೆ [`Err(k)`][Err], ಇಲ್ಲಿ `k` ಎನ್ನುವುದು ಅಂಶಗಳಿಂದ ಹೊರಗುಳಿಯುವ ಮೊದಲು ಪುನರಾವರ್ತಕವು ಮುಂದುವರೆದ ಅಂಶಗಳ ಸಂಖ್ಯೆ (ಅಂದರೆ
    /// ಪುನರಾವರ್ತಕದ ಉದ್ದ).
    /// `k` ಯಾವಾಗಲೂ `n` ಗಿಂತ ಕಡಿಮೆಯಿರುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    /// `advance_by(0)` ಗೆ ಕರೆ ಮಾಡುವುದರಿಂದ ಯಾವುದೇ ಅಂಶಗಳನ್ನು ಸೇವಿಸುವುದಿಲ್ಲ ಮತ್ತು ಯಾವಾಗಲೂ [`Ok(())`][Ok] ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // `&4` ಅನ್ನು ಮಾತ್ರ ಬಿಡಲಾಗಿದೆ
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// ಪುನರಾವರ್ತಕದ `n` ನೇ ಅಂಶವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಹೆಚ್ಚಿನ ಇಂಡೆಕ್ಸಿಂಗ್ ಕಾರ್ಯಾಚರಣೆಗಳಂತೆ, ಎಣಿಕೆ ಶೂನ್ಯದಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ, ಆದ್ದರಿಂದ `nth(0)` ಮೊದಲ ಮೌಲ್ಯವನ್ನು, `nth(1)` ಎರಡನೆಯದನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಹಿಂದಿನ ಎಲ್ಲಾ ಅಂಶಗಳು, ಹಾಗೆಯೇ ಹಿಂದಿರುಗಿದ ಅಂಶವನ್ನು ಪುನರಾವರ್ತಕದಿಂದ ಸೇವಿಸಲಾಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    /// ಇದರರ್ಥ ಹಿಂದಿನ ಅಂಶಗಳನ್ನು ತಿರಸ್ಕರಿಸಲಾಗುವುದು, ಮತ್ತು ಒಂದೇ ಪುನರಾವರ್ತಕದಲ್ಲಿ `nth(0)` ಅನ್ನು ಅನೇಕ ಬಾರಿ ಕರೆಯುವುದರಿಂದ ವಿಭಿನ್ನ ಅಂಶಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// `nth()` `n` ಪುನರಾವರ್ತಕದ ಉದ್ದಕ್ಕಿಂತ ದೊಡ್ಡದಾಗಿದ್ದರೆ ಅಥವಾ ಸಮನಾಗಿದ್ದರೆ [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// `nth()` ಅನ್ನು ಅನೇಕ ಬಾರಿ ಕರೆ ಮಾಡುವುದರಿಂದ ಪುನರಾವರ್ತಕವನ್ನು ರಿವೈಂಡ್ ಮಾಡುವುದಿಲ್ಲ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// `n + 1` ಗಿಂತ ಕಡಿಮೆ ಅಂಶಗಳಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// ಒಂದೇ ಹಂತದಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುವ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ, ಆದರೆ ಪ್ರತಿ ಪುನರಾವರ್ತನೆಯ ಸಮಯದಲ್ಲಿ ನಿರ್ದಿಷ್ಟ ಮೊತ್ತದಿಂದ ಹೆಜ್ಜೆ ಹಾಕುತ್ತದೆ.
    ///
    /// ಗಮನಿಸಿ 1: ಕೊಟ್ಟಿರುವ ಹಂತವನ್ನು ಲೆಕ್ಕಿಸದೆ, ಪುನರಾವರ್ತಕದ ಮೊದಲ ಅಂಶವನ್ನು ಯಾವಾಗಲೂ ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// ಸೂಚನೆ 2: ನಿರ್ಲಕ್ಷಿಸಲಾದ ಅಂಶಗಳನ್ನು ಎಳೆಯುವ ಸಮಯವನ್ನು ನಿಗದಿಪಡಿಸಲಾಗಿಲ್ಲ.
    /// `StepBy` `next(), nth(step-1), nth(step-1),…` ಅನುಕ್ರಮದಂತೆ ವರ್ತಿಸುತ್ತದೆ, ಆದರೆ ಅನುಕ್ರಮದಂತೆ ವರ್ತಿಸಲು ಸಹ ಉಚಿತವಾಗಿದೆ
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// ಕಾರ್ಯಕ್ಷಮತೆಯ ಕಾರಣಗಳಿಗಾಗಿ ಕೆಲವು ಪುನರಾವರ್ತಕರಿಗೆ ಯಾವ ಮಾರ್ಗವನ್ನು ಬಳಸಲಾಗುತ್ತದೆ.
    /// ಎರಡನೆಯ ಮಾರ್ಗವು ಪುನರಾವರ್ತಕವನ್ನು ಮೊದಲೇ ಮುನ್ನಡೆಸುತ್ತದೆ ಮತ್ತು ಹೆಚ್ಚಿನ ವಸ್ತುಗಳನ್ನು ಸೇವಿಸಬಹುದು.
    ///
    /// `advance_n_and_return_first` ಇದಕ್ಕೆ ಸಮನಾಗಿರುತ್ತದೆ:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// ಕೊಟ್ಟಿರುವ ಹಂತವು `0` ಆಗಿದ್ದರೆ ವಿಧಾನವು panic ಆಗಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// ಎರಡು ಪುನರಾವರ್ತಕಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ ಮತ್ತು ಅನುಕ್ರಮದಲ್ಲಿ ಎರಡರ ಮೇಲೆ ಹೊಸ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// `chain()` ಹೊಸ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಅದು ಮೊದಲು ಮೊದಲ ಪುನರಾವರ್ತಕದಿಂದ ಮೌಲ್ಯಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಿಸುತ್ತದೆ ಮತ್ತು ನಂತರ ಎರಡನೇ ಪುನರಾವರ್ತಕದಿಂದ ಮೌಲ್ಯಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, ಇದು ಸರಪಳಿಯಲ್ಲಿ ಎರಡು ಪುನರಾವರ್ತಕಗಳನ್ನು ಒಟ್ಟಿಗೆ ಜೋಡಿಸುತ್ತದೆ.🔗
    ///
    /// [`once`] ಒಂದೇ ಮೌಲ್ಯವನ್ನು ಇತರ ರೀತಿಯ ಪುನರಾವರ್ತನೆಯ ಸರಪಳಿಯಾಗಿ ಹೊಂದಿಸಲು ಸಾಮಾನ್ಯವಾಗಿ ಬಳಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `chain()` ಗೆ ಆರ್ಗ್ಯುಮೆಂಟ್ [`IntoIterator`] ಅನ್ನು ಬಳಸುವುದರಿಂದ, ನಾವು [`Iterator`] ಅನ್ನು ಮಾತ್ರವಲ್ಲದೆ [`Iterator`] ಆಗಿ ಪರಿವರ್ತಿಸಬಹುದಾದ ಯಾವುದನ್ನಾದರೂ ರವಾನಿಸಬಹುದು.
    /// ಉದಾಹರಣೆಗೆ, (`&[T]`) ಚೂರುಗಳು [`IntoIterator`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತವೆ, ಮತ್ತು ಆದ್ದರಿಂದ ಇದನ್ನು ನೇರವಾಗಿ `chain()` ಗೆ ರವಾನಿಸಬಹುದು:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ನೀವು Windows API ನೊಂದಿಗೆ ಕೆಲಸ ಮಾಡುತ್ತಿದ್ದರೆ, ನೀವು [`OsStr`] ಅನ್ನು `Vec<u16>` ಗೆ ಪರಿವರ್ತಿಸಲು ಬಯಸಬಹುದು:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// ಜೋಡಿಗಳ ಒಂದೇ ಪುನರಾವರ್ತಕಕ್ಕೆ ಎರಡು ಪುನರಾವರ್ತಕಗಳನ್ನು 'ಜಿಪ್ಸ್ ಅಪ್' ಮಾಡಿ.
    ///
    /// `zip()` ಹೊಸ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಅದು ಇತರ ಎರಡು ಪುನರಾವರ್ತಕಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಿಸುತ್ತದೆ, ಮೊದಲ ಅಂಶವು ಮೊದಲ ಪುನರಾವರ್ತಕದಿಂದ ಬರುತ್ತದೆ ಮತ್ತು ಎರಡನೆಯ ಅಂಶವು ಎರಡನೇ ಪುನರಾವರ್ತಕದಿಂದ ಬರುತ್ತದೆ.
    ///
    ///
    /// ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, ಇದು ಎರಡು ಪುನರಾವರ್ತಕಗಳನ್ನು ಒಟ್ಟಿಗೆ ಜಿಪ್ ಮಾಡುತ್ತದೆ.
    ///
    /// ಎರಡೂ ಪುನರಾವರ್ತಕವು [`None`] ಅನ್ನು ಹಿಂದಿರುಗಿಸಿದರೆ, ಜಿಪ್ ಮಾಡಿದ ಪುನರಾವರ್ತಕದಿಂದ [`next`] [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಮೊದಲ ಪುನರಾವರ್ತಕವು [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಿದರೆ, `zip` ಶಾರ್ಟ್-ಸರ್ಕ್ಯೂಟ್ ಆಗುತ್ತದೆ ಮತ್ತು ಎರಡನೇ ಪುನರಾವರ್ತಕದಲ್ಲಿ `next` ಅನ್ನು ಕರೆಯಲಾಗುವುದಿಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` ಗೆ ಆರ್ಗ್ಯುಮೆಂಟ್ [`IntoIterator`] ಅನ್ನು ಬಳಸುವುದರಿಂದ, ನಾವು [`Iterator`] ಅನ್ನು ಮಾತ್ರವಲ್ಲದೆ [`Iterator`] ಆಗಿ ಪರಿವರ್ತಿಸಬಹುದಾದ ಯಾವುದನ್ನಾದರೂ ರವಾನಿಸಬಹುದು.
    /// ಉದಾಹರಣೆಗೆ, (`&[T]`) ಚೂರುಗಳು [`IntoIterator`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತವೆ, ಮತ್ತು ಆದ್ದರಿಂದ ಇದನ್ನು ನೇರವಾಗಿ `zip()` ಗೆ ರವಾನಿಸಬಹುದು:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` ಅನಂತ ಪುನರಾವರ್ತಕವನ್ನು ಸೀಮಿತ ಒಂದಕ್ಕೆ ಜಿಪ್ ಮಾಡಲು ಹೆಚ್ಚಾಗಿ ಬಳಸಲಾಗುತ್ತದೆ.
    /// ಇದು ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ ಏಕೆಂದರೆ ಸೀಮಿತ ಪುನರಾವರ್ತಕವು ಅಂತಿಮವಾಗಿ [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ipp ಿಪ್ಪರ್ ಅನ್ನು ಕೊನೆಗೊಳಿಸುತ್ತದೆ.`(0..)` ನೊಂದಿಗೆ ಜಿಪ್ ಮಾಡುವುದರಿಂದ [`enumerate`] ನಂತೆ ಕಾಣಿಸಬಹುದು:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// ಹೊಸ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ, ಅದು ಮೂಲ ಪುನರಾವರ್ತಕದ ಪಕ್ಕದ ಐಟಂಗಳ ನಡುವೆ `separator` ನ ನಕಲನ್ನು ಇರಿಸುತ್ತದೆ.
    ///
    /// ಒಂದು ವೇಳೆ `separator` [`Clone`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸದಿದ್ದರೆ ಅಥವಾ ಪ್ರತಿ ಬಾರಿಯೂ ಲೆಕ್ಕಾಚಾರ ಮಾಡಬೇಕಾದರೆ, [`intersperse_with`] ಬಳಸಿ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // `a` ನಿಂದ ಮೊದಲ ಅಂಶ.
    /// assert_eq!(a.next(), Some(&100)); // ವಿಭಜಕ.
    /// assert_eq!(a.next(), Some(&1));   // `a` ನಿಂದ ಮುಂದಿನ ಅಂಶ.
    /// assert_eq!(a.next(), Some(&100)); // ವಿಭಜಕ.
    /// assert_eq!(a.next(), Some(&2));   // `a` ನಿಂದ ಕೊನೆಯ ಅಂಶ.
    /// assert_eq!(a.next(), None);       // ಪುನರಾವರ್ತಕ ಮುಗಿದಿದೆ.
    /// ```
    ///
    /// `intersperse` ಸಾಮಾನ್ಯ ಅಂಶವನ್ನು ಬಳಸಿಕೊಂಡು ಪುನರಾವರ್ತಕನ ವಸ್ತುಗಳನ್ನು ಸೇರಲು ಇದು ತುಂಬಾ ಉಪಯುಕ್ತವಾಗಿದೆ:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// ಹೊಸ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ, ಅದು `separator` ನಿಂದ ಉತ್ಪತ್ತಿಯಾದ ಐಟಂ ಅನ್ನು ಮೂಲ ಪುನರಾವರ್ತಕದ ಪಕ್ಕದ ಐಟಂಗಳ ನಡುವೆ ಇರಿಸುತ್ತದೆ.
    ///
    /// ಆಧಾರವಾಗಿರುವ ಪುನರಾವರ್ತಕದಿಂದ ಎರಡು ಪಕ್ಕದ ವಸ್ತುಗಳ ನಡುವೆ ಪ್ರತಿ ಬಾರಿ ವಸ್ತುವನ್ನು ಇರಿಸಿದಾಗ ಮುಚ್ಚುವಿಕೆಯನ್ನು ನಿಖರವಾಗಿ ಕರೆಯಲಾಗುತ್ತದೆ;
    /// ನಿರ್ದಿಷ್ಟವಾಗಿ ಹೇಳುವುದಾದರೆ, ಆಧಾರವಾಗಿರುವ ಪುನರಾವರ್ತಕವು ಎರಡು ವಸ್ತುಗಳಿಗಿಂತ ಕಡಿಮೆ ಇಳುವರಿ ನೀಡಿದರೆ ಮತ್ತು ಕೊನೆಯ ಐಟಂ ಅನ್ನು ನೀಡಿದ ನಂತರ ಮುಚ್ಚುವಿಕೆಯನ್ನು ಕರೆಯಲಾಗುವುದಿಲ್ಲ.
    ///
    ///
    /// ಪುನರಾವರ್ತಕನ ಐಟಂ [`Clone`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದರೆ, [`intersperse`] ಅನ್ನು ಬಳಸುವುದು ಸುಲಭವಾಗಬಹುದು.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // `v` ನಿಂದ ಮೊದಲ ಅಂಶ.
    /// assert_eq!(it.next(), Some(NotClone(99))); // ವಿಭಜಕ.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // `v` ನಿಂದ ಮುಂದಿನ ಅಂಶ.
    /// assert_eq!(it.next(), Some(NotClone(99))); // ವಿಭಜಕ.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // `v` ನಿಂದ ಕೊನೆಯ ಅಂಶ.
    /// assert_eq!(it.next(), None);               // ಪುನರಾವರ್ತಕ ಮುಗಿದಿದೆ.
    /// ```
    ///
    /// `intersperse_with` ವಿಭಜಕವನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡಬೇಕಾದ ಸಂದರ್ಭಗಳಲ್ಲಿ ಇದನ್ನು ಬಳಸಬಹುದು:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // ಮುಚ್ಚುವಿಕೆಯು ವಸ್ತುವನ್ನು ಉತ್ಪಾದಿಸಲು ಅದರ ಸಂದರ್ಭವನ್ನು ಎರವಲು ಪಡೆಯುತ್ತದೆ.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// ಮುಚ್ಚುವಿಕೆಯನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ ಮತ್ತು ಪ್ರತಿ ಅಂಶದ ಮೇಲೆ ಆ ಮುಚ್ಚುವಿಕೆಯನ್ನು ಕರೆಯುವ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// `map()` ಅದರ ವಾದದ ಮೂಲಕ ಒಂದು ಪುನರಾವರ್ತಕವನ್ನು ಇನ್ನೊಂದಕ್ಕೆ ಪರಿವರ್ತಿಸುತ್ತದೆ:
    /// [`FnMut`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವಂತಹದ್ದು.ಇದು ಹೊಸ ಪುನರಾವರ್ತಕವನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ, ಅದು ಮೂಲ ಪುನರಾವರ್ತಕದ ಪ್ರತಿಯೊಂದು ಅಂಶಗಳ ಮೇಲೆ ಈ ಮುಚ್ಚುವಿಕೆಯನ್ನು ಕರೆಯುತ್ತದೆ.
    ///
    /// ನೀವು ಪ್ರಕಾರಗಳಲ್ಲಿ ಯೋಚಿಸುವುದರಲ್ಲಿ ಉತ್ತಮವಾಗಿದ್ದರೆ, ನೀವು ಈ ರೀತಿಯ `map()` ಬಗ್ಗೆ ಯೋಚಿಸಬಹುದು:
    /// ನೀವು ಕೆಲವು ರೀತಿಯ `A` ನ ಅಂಶಗಳನ್ನು ನೀಡುವ ಪುನರಾವರ್ತಕವನ್ನು ಹೊಂದಿದ್ದರೆ, ಮತ್ತು ನೀವು ಬೇರೆ ರೀತಿಯ `B` ನ ಪುನರಾವರ್ತಕವನ್ನು ಬಯಸಿದರೆ, ನೀವು `map()` ಅನ್ನು ಬಳಸಬಹುದು, ಒಂದು ಮುಚ್ಚುವಿಕೆಯನ್ನು ಹಾದುಹೋಗುವ ಮೂಲಕ `A` ತೆಗೆದುಕೊಂಡು `B` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// `map()` ಪರಿಕಲ್ಪನಾತ್ಮಕವಾಗಿ [`for`] ಲೂಪ್‌ಗೆ ಹೋಲುತ್ತದೆ.ಆದಾಗ್ಯೂ, `map()` ಸೋಮಾರಿಯಾಗಿರುವುದರಿಂದ, ನೀವು ಈಗಾಗಲೇ ಇತರ ಪುನರಾವರ್ತಕರೊಂದಿಗೆ ಕೆಲಸ ಮಾಡುತ್ತಿರುವಾಗ ಇದನ್ನು ಉತ್ತಮವಾಗಿ ಬಳಸಲಾಗುತ್ತದೆ.
    /// ಅಡ್ಡಪರಿಣಾಮಕ್ಕಾಗಿ ನೀವು ಕೆಲವು ರೀತಿಯ ಲೂಪಿಂಗ್ ಮಾಡುತ್ತಿದ್ದರೆ, `map()` ಗಿಂತ [`for`] ಅನ್ನು ಬಳಸುವುದನ್ನು ಹೆಚ್ಚು ಭಾಷಾವೈಶಿಷ್ಟ್ಯವೆಂದು ಪರಿಗಣಿಸಲಾಗುತ್ತದೆ.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ನೀವು ಕೆಲವು ರೀತಿಯ ಅಡ್ಡಪರಿಣಾಮಗಳನ್ನು ಮಾಡುತ್ತಿದ್ದರೆ,`map()` ಗೆ `map()` ಗೆ ಆದ್ಯತೆ ನೀಡಿ:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // ಇದನ್ನು ಮಾಡಬೇಡಿ:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // ಅದು ಸೋಮಾರಿಯಾದ ಕಾರಣ ಅದು ಕಾರ್ಯಗತಗೊಳಿಸುವುದಿಲ್ಲ.Rust ಈ ಬಗ್ಗೆ ನಿಮಗೆ ಎಚ್ಚರಿಕೆ ನೀಡುತ್ತದೆ.
    ///
    /// // ಬದಲಾಗಿ, ಇದಕ್ಕಾಗಿ ಬಳಸಿ:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// ಪುನರಾವರ್ತಕದ ಪ್ರತಿಯೊಂದು ಅಂಶದ ಮೇಲೆ ಮುಚ್ಚುವಿಕೆಯನ್ನು ಕರೆಯುತ್ತದೆ.
    ///
    /// ಇದು ಪುನರಾವರ್ತಕದಲ್ಲಿ [`for`] ಲೂಪ್ ಅನ್ನು ಬಳಸುವುದಕ್ಕೆ ಸಮನಾಗಿರುತ್ತದೆ, ಆದರೂ `break` ಮತ್ತು `continue` ಮುಚ್ಚುವಿಕೆಯಿಂದ ಸಾಧ್ಯವಿಲ್ಲ.
    /// `for` ಲೂಪ್ ಅನ್ನು ಬಳಸುವುದು ಸಾಮಾನ್ಯವಾಗಿ ಹೆಚ್ಚು ಭಾಷಾಶಾಸ್ತ್ರೀಯವಾಗಿದೆ, ಆದರೆ ದೀರ್ಘ ಪುನರಾವರ್ತಕ ಸರಪಳಿಗಳ ಕೊನೆಯಲ್ಲಿ ವಸ್ತುಗಳನ್ನು ಸಂಸ್ಕರಿಸುವಾಗ `for_each` ಹೆಚ್ಚು ಸ್ಪಷ್ಟವಾಗಿರುತ್ತದೆ.
    ///
    /// ಕೆಲವು ಸಂದರ್ಭಗಳಲ್ಲಿ `for_each` ಲೂಪ್‌ಗಿಂತಲೂ ವೇಗವಾಗಿರಬಹುದು, ಏಕೆಂದರೆ ಇದು `Chain` ನಂತಹ ಅಡಾಪ್ಟರುಗಳಲ್ಲಿ ಆಂತರಿಕ ಪುನರಾವರ್ತನೆಯನ್ನು ಬಳಸುತ್ತದೆ.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// ಅಂತಹ ಒಂದು ಸಣ್ಣ ಉದಾಹರಣೆಗಾಗಿ, `for` ಲೂಪ್ ಸ್ವಚ್ er ವಾಗಿರಬಹುದು, ಆದರೆ ಕ್ರಿಯಾತ್ಮಕ ಶೈಲಿಯನ್ನು ದೀರ್ಘ ಪುನರಾವರ್ತಕಗಳೊಂದಿಗೆ ಇರಿಸಿಕೊಳ್ಳಲು `for_each` ಯೋಗ್ಯವಾಗಿರುತ್ತದೆ:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// ಒಂದು ಅಂಶವನ್ನು ನೀಡಬೇಕೆ ಎಂದು ನಿರ್ಧರಿಸಲು ಮುಚ್ಚುವಿಕೆಯನ್ನು ಬಳಸುವ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// ಒಂದು ಅಂಶವನ್ನು ನೀಡಿದರೆ ಮುಚ್ಚುವಿಕೆಯು `true` ಅಥವಾ `false` ಅನ್ನು ಹಿಂತಿರುಗಿಸಬೇಕು.ಹಿಂತಿರುಗಿದ ಪುನರಾವರ್ತಕವು ಮುಚ್ಚುವಿಕೆಯು ನಿಜವಾಗುವ ಅಂಶಗಳನ್ನು ಮಾತ್ರ ನೀಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `filter()` ಗೆ ರವಾನಿಸಲಾದ ಮುಚ್ಚುವಿಕೆಯು ಒಂದು ಉಲ್ಲೇಖವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ, ಮತ್ತು ಅನೇಕ ಪುನರಾವರ್ತಕರು ಉಲ್ಲೇಖಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಿಸುತ್ತಾರೆ, ಇದು ಬಹುಶಃ ಗೊಂದಲಮಯ ಪರಿಸ್ಥಿತಿಗೆ ಕಾರಣವಾಗುತ್ತದೆ, ಅಲ್ಲಿ ಮುಚ್ಚುವಿಕೆಯ ಪ್ರಕಾರವು ಎರಡು ಉಲ್ಲೇಖವಾಗಿದೆ:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // ಎರಡು * ರು ಬೇಕು!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ಒಂದನ್ನು ತೆಗೆದುಹಾಕಲು ವಾದದ ಮೇಲೆ ವಿನಾಶವನ್ನು ಬಳಸುವುದು ಸಾಮಾನ್ಯವಾಗಿದೆ:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // ಎರಡೂ ಮತ್ತು *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ಅಥವಾ ಎರಡೂ:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // ಎರಡು &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ಈ ಪದರಗಳಲ್ಲಿ.
    ///
    /// `iter.filter(f).next()` `iter.find(f)` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// ಫಿಲ್ಟರ್‌ಗಳು ಮತ್ತು ನಕ್ಷೆಗಳು ಎರಡೂ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// ಹಿಂತಿರುಗಿದ ಪುನರಾವರ್ತಕವು `ಮೌಲ್ಯ'ಗಳನ್ನು ಮಾತ್ರ ನೀಡುತ್ತದೆ, ಇದಕ್ಕಾಗಿ ಸರಬರಾಜು ಮುಚ್ಚುವಿಕೆಯು `Some(value)` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `filter_map` [`filter`] ಮತ್ತು [`map`] ಸರಪಳಿಗಳನ್ನು ಹೆಚ್ಚು ಸಂಕ್ಷಿಪ್ತಗೊಳಿಸಲು ಬಳಸಬಹುದು.
    /// ಕೆಳಗಿನ ಉದಾಹರಣೆಯು `map().filter().map()` ಅನ್ನು `filter_map` ಗೆ ಒಂದೇ ಕರೆಗೆ ಹೇಗೆ ಸಂಕ್ಷಿಪ್ತಗೊಳಿಸಬಹುದು ಎಂಬುದನ್ನು ತೋರಿಸುತ್ತದೆ.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ಅದೇ ಉದಾಹರಣೆ ಇಲ್ಲಿದೆ, ಆದರೆ [`filter`] ಮತ್ತು [`map`] ನೊಂದಿಗೆ:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ ಅದು ಪ್ರಸ್ತುತ ಪುನರಾವರ್ತನೆಯ ಎಣಿಕೆ ಮತ್ತು ಮುಂದಿನ ಮೌಲ್ಯವನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// ಪುನರಾವರ್ತಕವು ಇಳುವರಿ ಜೋಡಿಗಳು `(i, val)` ಅನ್ನು ನೀಡುತ್ತದೆ, ಇಲ್ಲಿ `i` ಪ್ರಸ್ತುತ ಪುನರಾವರ್ತನೆಯ ಸೂಚ್ಯಂಕವಾಗಿದೆ ಮತ್ತು `val` ಎಂಬುದು ಪುನರಾವರ್ತಕ ಹಿಂದಿರುಗಿಸಿದ ಮೌಲ್ಯವಾಗಿದೆ.
    ///
    ///
    /// `enumerate()` ಅದರ ಎಣಿಕೆಯನ್ನು [`usize`] ಆಗಿ ಇಡುತ್ತದೆ.
    /// ನೀವು ಬೇರೆ ಗಾತ್ರದ ಪೂರ್ಣಾಂಕದಿಂದ ಎಣಿಸಲು ಬಯಸಿದರೆ, [`zip`] ಕಾರ್ಯವು ಇದೇ ರೀತಿಯ ಕಾರ್ಯವನ್ನು ಒದಗಿಸುತ್ತದೆ.
    ///
    /// # ಉಕ್ಕಿ ಹರಿಯುವ ವರ್ತನೆ
    ///
    /// ಈ ವಿಧಾನವು ಓವರ್‌ಫ್ಲೋಗಳ ವಿರುದ್ಧ ಯಾವುದೇ ಕಾವಲು ಮಾಡುವುದಿಲ್ಲ, ಆದ್ದರಿಂದ [`usize::MAX`] ಗಿಂತ ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ಎಣಿಸುವುದರಿಂದ ತಪ್ಪಾದ ಫಲಿತಾಂಶ ಅಥವಾ panics ಉತ್ಪತ್ತಿಯಾಗುತ್ತದೆ.
    /// ಡೀಬಗ್ ಪ್ರತಿಪಾದನೆಗಳನ್ನು ಸಕ್ರಿಯಗೊಳಿಸಿದರೆ, panic ಅನ್ನು ಖಾತರಿಪಡಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// ಹಿಂತಿರುಗಿಸಬೇಕಾದ ಸೂಚ್ಯಂಕವು [`usize`] ಅನ್ನು ಉಕ್ಕಿ ಹರಿಯುವುದಾದರೆ ಹಿಂದಿರುಗಿದ ಪುನರಾವರ್ತಕವು panic ಆಗಿರಬಹುದು.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ, ಅದು ಪುನರಾವರ್ತನೆಯ ಮುಂದಿನ ಅಂಶವನ್ನು ಸೇವಿಸದೆ ನೋಡಲು [`peek`] ಅನ್ನು ಬಳಸಬಹುದು.
    ///
    /// ಪುನರಾವರ್ತಕಕ್ಕೆ [`peek`] ವಿಧಾನವನ್ನು ಸೇರಿಸುತ್ತದೆ.ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
    ///
    /// [`peek`] ಅನ್ನು ಮೊದಲ ಬಾರಿಗೆ ಕರೆದಾಗ ಆಧಾರವಾಗಿರುವ ಪುನರಾವರ್ತಕವು ಇನ್ನೂ ಮುಂದುವರೆದಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ: ಮುಂದಿನ ಅಂಶವನ್ನು ಹಿಂಪಡೆಯಲು, [`next`] ಅನ್ನು ಆಧಾರವಾಗಿರುವ ಪುನರಾವರ್ತಕದಲ್ಲಿ ಕರೆಯಲಾಗುತ್ತದೆ, ಆದ್ದರಿಂದ ಯಾವುದೇ ಅಡ್ಡಪರಿಣಾಮಗಳು (ಅಂದರೆ
    ///
    /// [`next`] ವಿಧಾನದ ಮುಂದಿನ ಮೌಲ್ಯವನ್ನು ಪಡೆಯುವುದನ್ನು ಬಿಟ್ಟು ಬೇರೆ ಯಾವುದಾದರೂ ಸಂಭವಿಸುತ್ತದೆ.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() future ಗೆ ನೋಡಲು ನಮಗೆ ಅನುಮತಿಸುತ್ತದೆ
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // ನಾವು ಅನೇಕ ಬಾರಿ peek() ಮಾಡಬಹುದು, ಪುನರಾವರ್ತಕ ಮುನ್ನಡೆಯುವುದಿಲ್ಲ
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // ಪುನರಾವರ್ತಕ ಮುಗಿದ ನಂತರ, peek() ಕೂಡ ಆಗಿದೆ
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// [`ಸ್ಕಿಪ್`] ಅಂಶಗಳು icate ಹೆಯ ಆಧಾರದ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` ಮುಚ್ಚುವಿಕೆಯನ್ನು ವಾದವಾಗಿ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.ಇದು ಪುನರಾವರ್ತಕದ ಪ್ರತಿಯೊಂದು ಅಂಶದಲ್ಲೂ ಈ ಮುಚ್ಚುವಿಕೆಯನ್ನು ಕರೆಯುತ್ತದೆ ಮತ್ತು ಅದು `false` ಅನ್ನು ಹಿಂದಿರುಗಿಸುವವರೆಗೆ ಅಂಶಗಳನ್ನು ನಿರ್ಲಕ್ಷಿಸುತ್ತದೆ.
    ///
    /// `false` ಹಿಂತಿರುಗಿದ ನಂತರ, `skip_while()`'s ಕೆಲಸ ಮುಗಿದಿದೆ, ಮತ್ತು ಉಳಿದ ಅಂಶಗಳು ಫಲ ನೀಡುತ್ತವೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `skip_while()` ಗೆ ರವಾನಿಸಲಾದ ಮುಚ್ಚುವಿಕೆಯು ಒಂದು ಉಲ್ಲೇಖವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ, ಮತ್ತು ಅನೇಕ ಪುನರಾವರ್ತಕರು ಉಲ್ಲೇಖಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಿಸುತ್ತಾರೆ, ಇದು ಬಹುಶಃ ಗೊಂದಲಮಯ ಪರಿಸ್ಥಿತಿಗೆ ಕಾರಣವಾಗುತ್ತದೆ, ಅಲ್ಲಿ ಮುಚ್ಚುವಿಕೆಯ ವಾದದ ಪ್ರಕಾರವು ಎರಡು ಉಲ್ಲೇಖವಾಗಿದೆ:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // ಎರಡು * ರು ಬೇಕು!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ಆರಂಭಿಕ `false` ನಂತರ ನಿಲ್ಲಿಸಲಾಗುತ್ತಿದೆ:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // ಇದು ಸುಳ್ಳಾಗಿರಬಹುದು, ಏಕೆಂದರೆ ನಾವು ಈಗಾಗಲೇ ಸುಳ್ಳನ್ನು ಪಡೆದುಕೊಂಡಿದ್ದೇವೆ, skip_while() ಅನ್ನು ಇನ್ನು ಮುಂದೆ ಬಳಸಲಾಗುವುದಿಲ್ಲ
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Ic ಹೆಯ ಆಧಾರದ ಮೇಲೆ ಅಂಶಗಳನ್ನು ನೀಡುವ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// `take_while()` ಮುಚ್ಚುವಿಕೆಯನ್ನು ವಾದವಾಗಿ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.ಇದು ಪುನರಾವರ್ತಕದ ಪ್ರತಿಯೊಂದು ಅಂಶಗಳ ಮೇಲೆ ಈ ಮುಚ್ಚುವಿಕೆಯನ್ನು ಕರೆಯುತ್ತದೆ, ಮತ್ತು ಅದು `true` ಅನ್ನು ಹಿಂದಿರುಗಿಸುವಾಗ ಅಂಶಗಳನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// `false` ಹಿಂತಿರುಗಿದ ನಂತರ, `take_while()`'s ಕೆಲಸ ಮುಗಿದಿದೆ, ಮತ್ತು ಉಳಿದ ಅಂಶಗಳನ್ನು ನಿರ್ಲಕ್ಷಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take_while()` ಗೆ ರವಾನಿಸಲಾದ ಮುಚ್ಚುವಿಕೆಯು ಒಂದು ಉಲ್ಲೇಖವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ, ಮತ್ತು ಅನೇಕ ಪುನರಾವರ್ತಕರು ಉಲ್ಲೇಖಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಿಸುತ್ತಾರೆ, ಇದು ಬಹುಶಃ ಗೊಂದಲಮಯ ಪರಿಸ್ಥಿತಿಗೆ ಕಾರಣವಾಗುತ್ತದೆ, ಅಲ್ಲಿ ಮುಚ್ಚುವಿಕೆಯ ಪ್ರಕಾರವು ಎರಡು ಉಲ್ಲೇಖವಾಗಿದೆ:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // ಎರಡು * ರು ಬೇಕು!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ಆರಂಭಿಕ `false` ನಂತರ ನಿಲ್ಲಿಸಲಾಗುತ್ತಿದೆ:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // ನಮ್ಮಲ್ಲಿ ಶೂನ್ಯಕ್ಕಿಂತ ಕಡಿಮೆ ಇರುವ ಹೆಚ್ಚಿನ ಅಂಶಗಳಿವೆ, ಆದರೆ ನಾವು ಈಗಾಗಲೇ ಸುಳ್ಳನ್ನು ಪಡೆದಿರುವುದರಿಂದ, take_while() ಅನ್ನು ಇನ್ನು ಮುಂದೆ ಬಳಸಲಾಗುವುದಿಲ್ಲ
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take_while()` ಮೌಲ್ಯವನ್ನು ಸೇರಿಸಬೇಕೆ ಅಥವಾ ಬೇಡವೇ ಎಂದು ನೋಡಲು ಮೌಲ್ಯವನ್ನು ನೋಡಬೇಕಾದ ಕಾರಣ, ಸೇವಿಸುವ ಪುನರಾವರ್ತಕರು ಅದನ್ನು ತೆಗೆದುಹಾಕಲಾಗಿದೆ ಎಂದು ನೋಡುತ್ತಾರೆ:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` ಇನ್ನು ಮುಂದೆ ಇಲ್ಲ, ಏಕೆಂದರೆ ಪುನರಾವರ್ತನೆಯು ನಿಲ್ಲಬೇಕೆ ಎಂದು ನೋಡಲು ಅದನ್ನು ಸೇವಿಸಲಾಗಿದೆ, ಆದರೆ ಅದನ್ನು ಪುನರಾವರ್ತಕಕ್ಕೆ ಇಡಲಾಗಿಲ್ಲ.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// ಮುನ್ಸೂಚನೆ ಮತ್ತು ನಕ್ಷೆಗಳ ಆಧಾರದ ಮೇಲೆ ಎರಡೂ ಅಂಶಗಳನ್ನು ಇಳುವರಿ ನೀಡುವ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// `map_while()` ಮುಚ್ಚುವಿಕೆಯನ್ನು ವಾದವಾಗಿ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    /// ಇದು ಪುನರಾವರ್ತಕದ ಪ್ರತಿಯೊಂದು ಅಂಶಗಳ ಮೇಲೆ ಈ ಮುಚ್ಚುವಿಕೆಯನ್ನು ಕರೆಯುತ್ತದೆ, ಮತ್ತು ಅದು [`Some(_)`][`Some`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುವಾಗ ಅಂಶಗಳನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ಅದೇ ಉದಾಹರಣೆ ಇಲ್ಲಿದೆ, ಆದರೆ [`take_while`] ಮತ್ತು [`map`] ನೊಂದಿಗೆ:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ಆರಂಭಿಕ [`None`] ನಂತರ ನಿಲ್ಲಿಸಲಾಗುತ್ತಿದೆ:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // ನಾವು u32 (4, 5) ಗೆ ಹೊಂದಿಕೆಯಾಗುವ ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ಹೊಂದಿದ್ದೇವೆ, ಆದರೆ `map_while` `-3` ಗಾಗಿ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸಿದೆ (`predicate` `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸಿದಂತೆ) ಮತ್ತು `collect` ಮೊದಲ `None` ಎದುರಾದಾಗ ನಿಲ್ಲುತ್ತದೆ.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// `map_while()` ಮೌಲ್ಯವನ್ನು ಸೇರಿಸಬೇಕೆ ಅಥವಾ ಬೇಡವೇ ಎಂದು ನೋಡಲು ಮೌಲ್ಯವನ್ನು ನೋಡಬೇಕಾದ ಕಾರಣ, ಸೇವಿಸುವ ಪುನರಾವರ್ತಕರು ಅದನ್ನು ತೆಗೆದುಹಾಕಲಾಗಿದೆ ಎಂದು ನೋಡುತ್ತಾರೆ:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` ಇನ್ನು ಮುಂದೆ ಇಲ್ಲ, ಏಕೆಂದರೆ ಪುನರಾವರ್ತನೆಯು ನಿಲ್ಲಬೇಕೆ ಎಂದು ನೋಡಲು ಅದನ್ನು ಸೇವಿಸಲಾಗಿದೆ, ಆದರೆ ಅದನ್ನು ಪುನರಾವರ್ತಕಕ್ಕೆ ಇಡಲಾಗಿಲ್ಲ.
    ///
    /// [`take_while`] ಗಿಂತ ಭಿನ್ನವಾಗಿ ಈ ಪುನರಾವರ್ತಕವು ** ಬೆಸುಗೆ ಹಾಕಿಲ್ಲ.
    /// ಮೊದಲ [`None`] ಹಿಂತಿರುಗಿದ ನಂತರ ಈ ಪುನರಾವರ್ತಕ ಏನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ ಎಂಬುದನ್ನು ಸಹ ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿಲ್ಲ.
    /// ನಿಮಗೆ ಬೆಸುಗೆ ಹಾಕಿದ ಪುನರಾವರ್ತಕ ಅಗತ್ಯವಿದ್ದರೆ, [`fuse`] ಬಳಸಿ.
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// ಮೊದಲ `n` ಅಂಶಗಳನ್ನು ಬಿಟ್ಟುಬಿಡುವ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// ಅವುಗಳನ್ನು ಸೇವಿಸಿದ ನಂತರ, ಉಳಿದ ಅಂಶಗಳು ಫಲ ನೀಡುತ್ತವೆ.
    /// ಈ ವಿಧಾನವನ್ನು ನೇರವಾಗಿ ಅತಿಕ್ರಮಿಸುವ ಬದಲು, ಬದಲಿಗೆ `nth` ವಿಧಾನವನ್ನು ಅತಿಕ್ರಮಿಸಿ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// ಅದರ ಮೊದಲ `n` ಅಂಶಗಳನ್ನು ನೀಡುವ ಇಟರೇಟರ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` ಇದನ್ನು ಸೀಮಿತಗೊಳಿಸಲು ಅನಂತ ಪುನರಾವರ್ತಕದೊಂದಿಗೆ ಹೆಚ್ಚಾಗಿ ಬಳಸಲಾಗುತ್ತದೆ:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `n` ಗಿಂತ ಕಡಿಮೆ ಅಂಶಗಳು ಲಭ್ಯವಿದ್ದರೆ, `take` ತನ್ನನ್ನು ಆಧಾರವಾಗಿರುವ ಪುನರಾವರ್ತಕದ ಗಾತ್ರಕ್ಕೆ ಸೀಮಿತಗೊಳಿಸುತ್ತದೆ:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// [`fold`] ಗೆ ಹೋಲುವ ಪುನರಾವರ್ತಕ ಅಡಾಪ್ಟರ್ ಅದು ಆಂತರಿಕ ಸ್ಥಿತಿಯನ್ನು ಹೊಂದಿದೆ ಮತ್ತು ಹೊಸ ಪುನರಾವರ್ತಕವನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` ಎರಡು ವಾದಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ: ಆಂತರಿಕ ಸ್ಥಿತಿಯನ್ನು ಬೀಜಿಸುವ ಆರಂಭಿಕ ಮೌಲ್ಯ, ಮತ್ತು ಎರಡು ವಾದಗಳೊಂದಿಗೆ ಮುಚ್ಚುವಿಕೆ, ಮೊದಲನೆಯದು ಆಂತರಿಕ ಸ್ಥಿತಿಗೆ ರೂಪಾಂತರಗೊಳ್ಳುವ ಉಲ್ಲೇಖ ಮತ್ತು ಎರಡನೆಯದು ಪುನರಾವರ್ತಕ ಅಂಶ.
    ///
    /// ಪುನರಾವರ್ತನೆಗಳ ನಡುವೆ ಸ್ಥಿತಿಯನ್ನು ಹಂಚಿಕೊಳ್ಳಲು ಮುಚ್ಚುವಿಕೆಯು ಆಂತರಿಕ ಸ್ಥಿತಿಗೆ ನಿಯೋಜಿಸಬಹುದು.
    ///
    /// ಪುನರಾವರ್ತನೆಯ ಮೇಲೆ, ಮುಚ್ಚುವಿಕೆಯನ್ನು ಪುನರಾವರ್ತಕದ ಪ್ರತಿಯೊಂದು ಅಂಶಕ್ಕೂ ಅನ್ವಯಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ಮುಚ್ಚುವಿಕೆಯಿಂದ ಹಿಂತಿರುಗುವ ಮೌಲ್ಯ, [`Option`], ಪುನರಾವರ್ತಕದಿಂದ ನೀಡಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // ಪ್ರತಿ ಪುನರಾವರ್ತನೆ, ನಾವು ರಾಜ್ಯದಿಂದ ಅಂಶದಿಂದ ಗುಣಿಸುತ್ತೇವೆ
    ///     *state = *state * x;
    ///
    ///     // ನಂತರ, ನಾವು ರಾಜ್ಯದ ನಿರಾಕರಣೆಯನ್ನು ನೀಡುತ್ತೇವೆ
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// ನಕ್ಷೆಯಂತೆ ಕಾರ್ಯನಿರ್ವಹಿಸುವ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ, ಆದರೆ ನೆಸ್ಟೆಡ್ ರಚನೆಯನ್ನು ಚಪ್ಪಟೆಗೊಳಿಸುತ್ತದೆ.
    ///
    /// [`map`] ಅಡಾಪ್ಟರ್ ತುಂಬಾ ಉಪಯುಕ್ತವಾಗಿದೆ, ಆದರೆ ಮುಚ್ಚುವಿಕೆಯ ವಾದವು ಮೌಲ್ಯಗಳನ್ನು ಉತ್ಪಾದಿಸಿದಾಗ ಮಾತ್ರ.
    /// ಅದು ಪುನರಾವರ್ತಕವನ್ನು ಉತ್ಪಾದಿಸಿದರೆ, ಇಂಡೈರೆಕ್ಷನ್‌ನ ಹೆಚ್ಚುವರಿ ಪದರವಿದೆ.
    /// `flat_map()` ಈ ಹೆಚ್ಚುವರಿ ಪದರವನ್ನು ತನ್ನದೇ ಆದ ಮೇಲೆ ತೆಗೆದುಹಾಕುತ್ತದೆ.
    ///
    /// ನೀವು `flat_map(f)` ಅನ್ನು [`ನಕ್ಷೆ`] ಪಿಂಗ್‌ಗೆ ಶಬ್ದಾರ್ಥದ ಸಮಾನವೆಂದು ಭಾವಿಸಬಹುದು, ತದನಂತರ `map(f).flatten()` ನಂತೆ [`ಚಪ್ಪಟೆಗೊಳಿಸಿ`].
    ///
    /// `flat_map()` ಬಗ್ಗೆ ಯೋಚಿಸುವ ಇನ್ನೊಂದು ವಿಧಾನ: [`ನಕ್ಷೆ`] ಮುಚ್ಚುವಿಕೆಯು ಪ್ರತಿ ಅಂಶಕ್ಕೆ ಒಂದು ಐಟಂ ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಮತ್ತು `flat_map()`'s ಮುಚ್ಚುವಿಕೆಯು ಪ್ರತಿ ಅಂಶಕ್ಕೂ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// ನೆಸ್ಟೆಡ್ ರಚನೆಯನ್ನು ಚಪ್ಪಟೆಗೊಳಿಸುವ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// ನೀವು ಪುನರಾವರ್ತಕರ ಪುನರಾವರ್ತಕ ಅಥವಾ ಪುನರಾವರ್ತಕಗಳಾಗಿ ಪರಿವರ್ತಿಸಬಹುದಾದ ವಸ್ತುಗಳ ಪುನರಾವರ್ತಕವನ್ನು ಹೊಂದಿರುವಾಗ ಇದು ಉಪಯುಕ್ತವಾಗಿರುತ್ತದೆ ಮತ್ತು ನೀವು ಒಂದು ಹಂತದ ಅಪ್ರಸ್ತುತತೆಯನ್ನು ತೆಗೆದುಹಾಕಲು ಬಯಸುತ್ತೀರಿ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// ಮ್ಯಾಪಿಂಗ್ ಮತ್ತು ನಂತರ ಚಪ್ಪಟೆ:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// ನೀವು ಇದನ್ನು [`flat_map()`] ನ ಪರಿಭಾಷೆಯಲ್ಲಿ ಸಹ ಪುನಃ ಬರೆಯಬಹುದು, ಇದು ಉದ್ದೇಶವನ್ನು ಹೆಚ್ಚು ಸ್ಪಷ್ಟವಾಗಿ ತಿಳಿಸುವುದರಿಂದ ಈ ಸಂದರ್ಭದಲ್ಲಿ ಇದು ಯೋಗ್ಯವಾಗಿರುತ್ತದೆ:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// ಚಪ್ಪಟೆಯಾಗುವುದು ಒಂದು ಸಮಯದಲ್ಲಿ ಒಂದು ಹಂತದ ಗೂಡುಕಟ್ಟುವಿಕೆಯನ್ನು ಮಾತ್ರ ತೆಗೆದುಹಾಕುತ್ತದೆ:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// `flatten()` "deep" ಚಪ್ಪಟೆಯನ್ನು ನಿರ್ವಹಿಸುವುದಿಲ್ಲ ಎಂದು ಇಲ್ಲಿ ನಾವು ನೋಡುತ್ತೇವೆ.
    /// ಬದಲಾಗಿ, ಒಂದು ಹಂತದ ಗೂಡುಕಟ್ಟುವಿಕೆಯನ್ನು ಮಾತ್ರ ತೆಗೆದುಹಾಕಲಾಗುತ್ತದೆ.ಅಂದರೆ, ನೀವು ಮೂರು ಆಯಾಮದ ರಚನೆಯನ್ನು `flatten()` ಮಾಡಿದರೆ, ಫಲಿತಾಂಶವು ಎರಡು ಆಯಾಮದ ಮತ್ತು ಒಂದು ಆಯಾಮದದ್ದಾಗಿರುತ್ತದೆ.
    /// ಒಂದು ಆಯಾಮದ ರಚನೆಯನ್ನು ಪಡೆಯಲು, ನೀವು ಮತ್ತೆ `flatten()` ಮಾಡಬೇಕು.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// ಮೊದಲ [`None`] ನಂತರ ಕೊನೆಗೊಳ್ಳುವ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// ಪುನರಾವರ್ತಕ [`None`] ಅನ್ನು ಹಿಂದಿರುಗಿಸಿದ ನಂತರ, future ಕರೆಗಳು [`Some(T)`] ಅನ್ನು ಮತ್ತೆ ನೀಡಬಹುದು ಅಥವಾ ನೀಡದಿರಬಹುದು.
    /// `fuse()` ಪುನರಾವರ್ತಕವನ್ನು ಹೊಂದಿಸುತ್ತದೆ, [`None`] ನೀಡಿದ ನಂತರ, ಅದು ಯಾವಾಗಲೂ [`None`] ಅನ್ನು ಶಾಶ್ವತವಾಗಿ ಹಿಂದಿರುಗಿಸುತ್ತದೆ ಎಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// // ಕೆಲವು ಮತ್ತು ಯಾವುದರ ನಡುವೆ ಪರ್ಯಾಯವಾಗಿರುವ ಪುನರಾವರ್ತಕ
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // ಅದು ಸಮವಾಗಿದ್ದರೆ, Some(i32), ಇಲ್ಲದಿದ್ದರೆ ಯಾವುದೂ ಇಲ್ಲ
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // ನಮ್ಮ ಪುನರಾವರ್ತಕ ಹಿಂದಕ್ಕೆ ಮತ್ತು ಮುಂದಕ್ಕೆ ಹೋಗುವುದನ್ನು ನಾವು ನೋಡಬಹುದು
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // ಆದಾಗ್ಯೂ, ಒಮ್ಮೆ ನಾವು ಅದನ್ನು ಬೆಸೆಯುತ್ತೇವೆ ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // ಇದು ಯಾವಾಗಲೂ ಮೊದಲ ಬಾರಿಗೆ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// ಪುನರಾವರ್ತಕನ ಪ್ರತಿಯೊಂದು ಅಂಶದೊಂದಿಗೆ ಏನನ್ನಾದರೂ ಮಾಡುತ್ತದೆ, ಮೌಲ್ಯವನ್ನು ಹಾದುಹೋಗುತ್ತದೆ.
    ///
    /// ಪುನರಾವರ್ತಕಗಳನ್ನು ಬಳಸುವಾಗ, ನೀವು ಆಗಾಗ್ಗೆ ಅವುಗಳಲ್ಲಿ ಹಲವಾರು ಸರಪಳಿಗಳನ್ನು ಜೋಡಿಸುತ್ತೀರಿ.
    /// ಅಂತಹ ಕೋಡ್‌ನಲ್ಲಿ ಕೆಲಸ ಮಾಡುವಾಗ, ಪೈಪ್‌ಲೈನ್‌ನಲ್ಲಿ ವಿವಿಧ ಭಾಗಗಳಲ್ಲಿ ಏನಾಗುತ್ತಿದೆ ಎಂಬುದನ್ನು ನೀವು ಪರಿಶೀಲಿಸಲು ಬಯಸಬಹುದು.ಅದನ್ನು ಮಾಡಲು, `inspect()` ಗೆ ಕರೆ ಸೇರಿಸಿ.
    ///
    /// ನಿಮ್ಮ ಅಂತಿಮ ಕೋಡ್‌ನಲ್ಲಿ ಅಸ್ತಿತ್ವದಲ್ಲಿರುವುದಕ್ಕಿಂತ `inspect()` ಅನ್ನು ಡೀಬಗ್ ಮಾಡುವ ಸಾಧನವಾಗಿ ಬಳಸುವುದು ಹೆಚ್ಚು ಸಾಮಾನ್ಯವಾಗಿದೆ, ಆದರೆ ದೋಷಗಳನ್ನು ತ್ಯಜಿಸುವ ಮೊದಲು ಲಾಗ್ ಇನ್ ಆಗಬೇಕಾದಾಗ ಕೆಲವು ಸಂದರ್ಭಗಳಲ್ಲಿ ಅಪ್ಲಿಕೇಶನ್‌ಗಳು ಇದು ಉಪಯುಕ್ತವಾಗಬಹುದು.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // ಈ ಪುನರಾವರ್ತಕ ಅನುಕ್ರಮವು ಸಂಕೀರ್ಣವಾಗಿದೆ.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // ಏನಾಗುತ್ತಿದೆ ಎಂದು ತನಿಖೆ ಮಾಡಲು ಕೆಲವು inspect() ಕರೆಗಳನ್ನು ಸೇರಿಸೋಣ
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// ಇದು ಮುದ್ರಿಸುತ್ತದೆ:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// ದೋಷಗಳನ್ನು ತ್ಯಜಿಸುವ ಮೊದಲು ಅವುಗಳನ್ನು ಲಾಗ್ ಮಾಡುವುದು:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// ಇದು ಮುದ್ರಿಸುತ್ತದೆ:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// ಅದನ್ನು ಸೇವಿಸುವ ಬದಲು ಪುನರಾವರ್ತಕವನ್ನು ಎರವಲು ಪಡೆಯುತ್ತದೆ.
    ///
    /// ಮೂಲ ಪುನರಾವರ್ತಕದ ಮಾಲೀಕತ್ವವನ್ನು ಉಳಿಸಿಕೊಂಡು ಪುನರಾವರ್ತಕ ಅಡಾಪ್ಟರುಗಳನ್ನು ಅನ್ವಯಿಸಲು ಇದು ಅನುಮತಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // ನಾವು ಅದನ್ನು ಮತ್ತೆ ಬಳಸಲು ಪ್ರಯತ್ನಿಸಿದರೆ, ಅದು ಕಾರ್ಯನಿರ್ವಹಿಸುವುದಿಲ್ಲ.
    /// // ಕೆಳಗಿನ ಸಾಲು "ದೋಷ: ಸರಿಸಿದ ಮೌಲ್ಯದ ಬಳಕೆ: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // ಅದನ್ನು ಮತ್ತೆ ಪ್ರಯತ್ನಿಸೋಣ
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // ಬದಲಾಗಿ, ನಾವು .by_ref() ನಲ್ಲಿ ಸೇರಿಸುತ್ತೇವೆ
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // ಈಗ ಇದು ಉತ್ತಮವಾಗಿದೆ:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// ಪುನರಾವರ್ತಕವನ್ನು ಸಂಗ್ರಹವಾಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// `collect()` ಪುನರಾವರ್ತಿಸಬಹುದಾದ ಯಾವುದನ್ನಾದರೂ ತೆಗೆದುಕೊಳ್ಳಬಹುದು ಮತ್ತು ಅದನ್ನು ಸಂಬಂಧಿತ ಸಂಗ್ರಹವಾಗಿ ಪರಿವರ್ತಿಸಬಹುದು.
    /// ಸ್ಟ್ಯಾಂಡರ್ಡ್ ಲೈಬ್ರರಿಯಲ್ಲಿ ಇದು ಹೆಚ್ಚು ಶಕ್ತಿಶಾಲಿ ವಿಧಾನಗಳಲ್ಲಿ ಒಂದಾಗಿದೆ, ಇದನ್ನು ವಿವಿಧ ಸಂದರ್ಭಗಳಲ್ಲಿ ಬಳಸಲಾಗುತ್ತದೆ.
    ///
    /// `collect()` ಅನ್ನು ಬಳಸುವ ಅತ್ಯಂತ ಮೂಲ ಮಾದರಿಯೆಂದರೆ ಒಂದು ಸಂಗ್ರಹವನ್ನು ಇನ್ನೊಂದಕ್ಕೆ ಪರಿವರ್ತಿಸುವುದು.
    /// ನೀವು ಸಂಗ್ರಹವನ್ನು ತೆಗೆದುಕೊಳ್ಳಿ, ಅದರ ಮೇಲೆ [`iter`] ಗೆ ಕರೆ ಮಾಡಿ, ರೂಪಾಂತರಗಳ ಗುಂಪನ್ನು ಮಾಡಿ, ತದನಂತರ `collect()` ಕೊನೆಯಲ್ಲಿ.
    ///
    /// `collect()` ವಿಶಿಷ್ಟ ಸಂಗ್ರಹಗಳಲ್ಲದ ಪ್ರಕಾರಗಳ ನಿದರ್ಶನಗಳನ್ನು ಸಹ ರಚಿಸಬಹುದು.
    /// ಉದಾಹರಣೆಗೆ, [`ಚಾರ್`] ಗಳಿಂದ [`String`] ಅನ್ನು ನಿರ್ಮಿಸಬಹುದು, ಮತ್ತು [`Result<T, E>`][`Result`] ಐಟಂಗಳ ಪುನರಾವರ್ತಕವನ್ನು `Result<Collection<T>, E>` ಗೆ ಸಂಗ್ರಹಿಸಬಹುದು.
    ///
    /// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ ಕೆಳಗಿನ ಉದಾಹರಣೆಗಳನ್ನು ನೋಡಿ.
    ///
    /// `collect()` ತುಂಬಾ ಸಾಮಾನ್ಯವಾದ ಕಾರಣ, ಇದು ಪ್ರಕಾರದ ಅನುಮಾನದೊಂದಿಗೆ ಸಮಸ್ಯೆಗಳನ್ನು ಉಂಟುಮಾಡಬಹುದು.
    /// ಅಂತೆಯೇ, 'turbofish' ಎಂದು ನೀವು ಪ್ರೀತಿಯಿಂದ ಕರೆಯಲ್ಪಡುವ ಸಿಂಟ್ಯಾಕ್ಸ್ ಅನ್ನು ನೀವು ನೋಡುವ ಕೆಲವೇ ಸಮಯಗಳಲ್ಲಿ `collect()` ಒಂದಾಗಿದೆ: `::<>`.
    /// ನೀವು ಯಾವ ಸಂಗ್ರಹಕ್ಕೆ ಸಂಗ್ರಹಿಸಲು ಪ್ರಯತ್ನಿಸುತ್ತಿದ್ದೀರಿ ಎಂಬುದನ್ನು ನಿರ್ದಿಷ್ಟವಾಗಿ ಅರ್ಥಮಾಡಿಕೊಳ್ಳಲು ಇದು ಅನುಮಾನದ ಅಲ್ಗಾರಿದಮ್‌ಗೆ ಸಹಾಯ ಮಾಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// ನಮಗೆ ಎಡಗೈಯಲ್ಲಿ `: Vec<i32>` ಅಗತ್ಯವಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.ಇದಕ್ಕೆ ಕಾರಣ ನಾವು ಉದಾಹರಣೆಗೆ [`VecDeque<T>`] ಅನ್ನು ಸಂಗ್ರಹಿಸಬಹುದು:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// `doubled` ಅನ್ನು ಟಿಪ್ಪಣಿ ಮಾಡುವ ಬದಲು 'turbofish' ಅನ್ನು ಬಳಸುವುದು:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// `collect()` ನೀವು ಏನನ್ನು ಸಂಗ್ರಹಿಸುತ್ತಿದ್ದೀರಿ ಎಂಬುದರ ಬಗ್ಗೆ ಮಾತ್ರ ಕಾಳಜಿ ವಹಿಸುತ್ತಿರುವುದರಿಂದ, ನೀವು ಇನ್ನೂ ಟರ್ಬೊಫಿಶ್‌ನೊಂದಿಗೆ ಭಾಗಶಃ ಪ್ರಕಾರದ ಸುಳಿವು `_` ಅನ್ನು ಬಳಸಬಹುದು:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// [`String`] ಮಾಡಲು `collect()` ಅನ್ನು ಬಳಸುವುದು:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// ನೀವು [`ಫಲಿತಾಂಶದ ಪಟ್ಟಿಯನ್ನು ಹೊಂದಿದ್ದರೆ<T, E>`][`ಫಲಿತಾಂಶ`] ಗಳು, ಅವುಗಳಲ್ಲಿ ಯಾವುದಾದರೂ ವಿಫಲವಾಗಿದೆಯೇ ಎಂದು ನೋಡಲು ನೀವು `collect()` ಅನ್ನು ಬಳಸಬಹುದು:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ನಮಗೆ ಮೊದಲ ದೋಷವನ್ನು ನೀಡುತ್ತದೆ
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ನಮಗೆ ಉತ್ತರಗಳ ಪಟ್ಟಿಯನ್ನು ನೀಡುತ್ತದೆ
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// ಪುನರಾವರ್ತಕವನ್ನು ಬಳಸುತ್ತದೆ, ಅದರಿಂದ ಎರಡು ಸಂಗ್ರಹಗಳನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// `partition()` ಗೆ ರವಾನಿಸಲಾದ ಮುನ್ಸೂಚನೆಯು `true`, ಅಥವಾ `false` ಅನ್ನು ಹಿಂತಿರುಗಿಸಬಹುದು.
    /// `partition()` ಒಂದು ಜೋಡಿಯನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಅದು `true` ಅನ್ನು ಹಿಂದಿರುಗಿಸಿದ ಎಲ್ಲಾ ಅಂಶಗಳು ಮತ್ತು ಅದು `false` ಅನ್ನು ಹಿಂದಿರುಗಿಸಿದ ಎಲ್ಲಾ ಅಂಶಗಳು.
    ///
    ///
    /// [`is_partitioned()`] ಮತ್ತು [`partition_in_place()`] ಸಹ ನೋಡಿ.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// ಕೊಟ್ಟಿರುವ ಮುನ್ಸೂಚನೆಯ ಪ್ರಕಾರ ಈ ಪುನರಾವರ್ತಕದ ಅಂಶಗಳನ್ನು *ಸ್ಥಳದಲ್ಲಿ* ಮರುಕ್ರಮಗೊಳಿಸುತ್ತದೆ, ಅಂದರೆ `true` ಅನ್ನು ಹಿಂದಿರುಗಿಸುವವರೆಲ್ಲರೂ `false` ಅನ್ನು ಹಿಂದಿರುಗಿಸುವ ಎಲ್ಲಕ್ಕಿಂತ ಮುಂಚಿತವಾಗಿರುತ್ತಾರೆ.
    ///
    /// ಕಂಡುಬರುವ `true` ಅಂಶಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ವಿಭಜಿತ ವಸ್ತುಗಳ ಸಾಪೇಕ್ಷ ಕ್ರಮವನ್ನು ನಿರ್ವಹಿಸಲಾಗುವುದಿಲ್ಲ.
    ///
    /// [`is_partitioned()`] ಮತ್ತು [`partition()`] ಸಹ ನೋಡಿ.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // ಸಂಜೆ ಮತ್ತು ಆಡ್ಸ್ ನಡುವೆ ವಿಭಜನೆ
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: ಎಣಿಕೆ ತುಂಬಿ ಹರಿಯುವ ಬಗ್ಗೆ ನಾವು ಚಿಂತಿಸಬೇಕೇ?ಗಿಂತ ಹೆಚ್ಚಿನದನ್ನು ಹೊಂದಲು ಏಕೈಕ ಮಾರ್ಗವಾಗಿದೆ
        // `usize::MAX` ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳು ZST ಗಳೊಂದಿಗೆ ಇವೆ, ಅದು ವಿಭಜನೆಗೆ ಉಪಯುಕ್ತವಲ್ಲ ...

        // `Self` ನಲ್ಲಿ ಸಾರ್ವತ್ರಿಕತೆಯನ್ನು ತಪ್ಪಿಸಲು ಈ ಮುಚ್ಚುವಿಕೆ "factory" ಕಾರ್ಯಗಳು ಅಸ್ತಿತ್ವದಲ್ಲಿವೆ.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // ಮೊದಲ `false` ಅನ್ನು ಪದೇ ಪದೇ ಹುಡುಕಿ ಮತ್ತು ಅದನ್ನು ಕೊನೆಯ `true` ನೊಂದಿಗೆ ವಿನಿಮಯ ಮಾಡಿಕೊಳ್ಳಿ.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// ಈ ಪುನರಾವರ್ತಕದ ಅಂಶಗಳನ್ನು ನಿರ್ದಿಷ್ಟ ಮುನ್ಸೂಚನೆಯ ಪ್ರಕಾರ ವಿಭಜಿಸಲಾಗಿದೆಯೆ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ, ಅಂದರೆ `true` ಅನ್ನು ಹಿಂದಿರುಗಿಸುವವರೆಲ್ಲರೂ `false` ಅನ್ನು ಹಿಂದಿರುಗಿಸುವ ಎಲ್ಲಕ್ಕಿಂತ ಮುಂಚಿತವಾಗಿರುತ್ತಾರೆ.
    ///
    ///
    /// [`partition()`] ಮತ್ತು [`partition_in_place()`] ಸಹ ನೋಡಿ.
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // ಎಲ್ಲಾ ಐಟಂಗಳು `true` ಅನ್ನು ಪರೀಕ್ಷಿಸುತ್ತವೆ, ಅಥವಾ ಮೊದಲ ಷರತ್ತು `false` ನಲ್ಲಿ ನಿಲ್ಲುತ್ತದೆ ಮತ್ತು ಅದರ ನಂತರ ಯಾವುದೇ `true` ಐಟಂಗಳಿಲ್ಲ ಎಂದು ನಾವು ಪರಿಶೀಲಿಸುತ್ತೇವೆ.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// ಒಂದು ಪುನರಾವರ್ತಿತ ವಿಧಾನವು ಒಂದು ಕಾರ್ಯವನ್ನು ಯಶಸ್ವಿಯಾಗಿ ಹಿಂದಿರುಗಿಸುವವರೆಗೆ ಅನ್ವಯಿಸುತ್ತದೆ, ಇದು ಒಂದೇ, ಅಂತಿಮ ಮೌಲ್ಯವನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ.
    ///
    /// `try_fold()` ಎರಡು ವಾದಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ: ಆರಂಭಿಕ ಮೌಲ್ಯ, ಮತ್ತು ಎರಡು ವಾದಗಳೊಂದಿಗೆ ಮುಚ್ಚುವಿಕೆ: 'accumulator', ಮತ್ತು ಒಂದು ಅಂಶ.
    /// ಮುಚ್ಚುವಿಕೆಯು ಯಶಸ್ವಿಯಾಗಿ ಹಿಂತಿರುಗುತ್ತದೆ, ಮುಂದಿನ ಪುನರಾವರ್ತನೆಗಾಗಿ ಸಂಚಯಕವು ಹೊಂದಿರಬೇಕಾದ ಮೌಲ್ಯದೊಂದಿಗೆ, ಅಥವಾ ಅದು ವೈಫಲ್ಯವನ್ನು ನೀಡುತ್ತದೆ, ದೋಷ ಮೌಲ್ಯದೊಂದಿಗೆ ತಕ್ಷಣವೇ ಕರೆ ಮಾಡುವವರಿಗೆ (short-circuiting) ಗೆ ಪ್ರಸಾರವಾಗುತ್ತದೆ.
    ///
    ///
    /// ಆರಂಭಿಕ ಮೌಲ್ಯವು ಸಂಚಯಕವು ಮೊದಲ ಕರೆಯಲ್ಲಿ ಹೊಂದಿರುವ ಮೌಲ್ಯವಾಗಿದೆ.ಮುಚ್ಚುವಿಕೆಯನ್ನು ಅನ್ವಯಿಸುವಿಕೆಯು ಪುನರಾವರ್ತಕದ ಪ್ರತಿಯೊಂದು ಅಂಶಗಳ ವಿರುದ್ಧ ಯಶಸ್ವಿಯಾದರೆ, `try_fold()` ಅಂತಿಮ ಸಂಚಯಕವನ್ನು ಯಶಸ್ಸಿನಂತೆ ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ನೀವು ಏನಾದರೂ ಸಂಗ್ರಹವನ್ನು ಹೊಂದಿರುವಾಗ ಮಡಿಸುವಿಕೆಯು ಉಪಯುಕ್ತವಾಗಿದೆ ಮತ್ತು ಅದರಿಂದ ಒಂದೇ ಮೌಲ್ಯವನ್ನು ಉತ್ಪಾದಿಸಲು ಬಯಸುತ್ತದೆ.
    ///
    /// # ಅನುಷ್ಠಾನಕಾರರಿಗೆ ಟಿಪ್ಪಣಿ
    ///
    /// ಹಲವಾರು ಇತರ (forward) ವಿಧಾನಗಳು ಈ ವಿಷಯದಲ್ಲಿ ಡೀಫಾಲ್ಟ್ ಅನುಷ್ಠಾನಗಳನ್ನು ಹೊಂದಿವೆ, ಆದ್ದರಿಂದ ಡೀಫಾಲ್ಟ್ `for` ಲೂಪ್ ಅನುಷ್ಠಾನಕ್ಕಿಂತ ಉತ್ತಮವಾದದ್ದನ್ನು ಮಾಡಲು ಸಾಧ್ಯವಾದರೆ ಇದನ್ನು ಸ್ಪಷ್ಟವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸಲು ಪ್ರಯತ್ನಿಸಿ.
    ///
    /// ನಿರ್ದಿಷ್ಟವಾಗಿ, ಈ ಪುನರಾವರ್ತಕ ಸಂಯೋಜನೆಗೊಂಡ ಆಂತರಿಕ ಭಾಗಗಳಲ್ಲಿ ಈ ಕರೆ `try_fold()` ಅನ್ನು ಹೊಂದಲು ಪ್ರಯತ್ನಿಸಿ.
    /// ಬಹು ಕರೆಗಳು ಅಗತ್ಯವಿದ್ದರೆ, ಸಂಚಯಕ ಮೌಲ್ಯವನ್ನು ಸರಪಳಿ ಮಾಡಲು `?` ಆಪರೇಟರ್ ಅನುಕೂಲಕರವಾಗಿರಬಹುದು, ಆದರೆ ಆ ಆರಂಭಿಕ ಆದಾಯದ ಮೊದಲು ಎತ್ತಿಹಿಡಿಯಬೇಕಾದ ಯಾವುದೇ ಅಸ್ಥಿರತೆಗಳನ್ನು ಹುಷಾರಾಗಿರು.
    /// ಇದು `&mut self` ವಿಧಾನವಾಗಿದೆ, ಆದ್ದರಿಂದ ಇಲ್ಲಿ ದೋಷವನ್ನು ಹೊಡೆದ ನಂತರ ಪುನರಾವರ್ತನೆ ಪುನರಾರಂಭಿಸಬೇಕಾಗಿದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ರಚನೆಯ ಎಲ್ಲಾ ಅಂಶಗಳ ಪರಿಶೀಲಿಸಿದ ಮೊತ್ತ
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // 100 ಅಂಶವನ್ನು ಸೇರಿಸುವಾಗ ಈ ಮೊತ್ತವು ಉಕ್ಕಿ ಹರಿಯುತ್ತದೆ
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // ಇದು ಶಾರ್ಟ್-ಸರ್ಕ್ಯೂಟ್ ಆಗಿರುವುದರಿಂದ, ಉಳಿದ ಅಂಶಗಳು ಇಟರೇಟರ್ ಮೂಲಕ ಇನ್ನೂ ಲಭ್ಯವಿವೆ.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// ಪುನರಾವರ್ತಕ ವಿಧಾನವು ಪುನರಾವರ್ತಕದಲ್ಲಿನ ಪ್ರತಿಯೊಂದು ಐಟಂಗೆ ತಪ್ಪಾದ ಕಾರ್ಯವನ್ನು ಅನ್ವಯಿಸುತ್ತದೆ, ಮೊದಲ ದೋಷವನ್ನು ನಿಲ್ಲಿಸುತ್ತದೆ ಮತ್ತು ಆ ದೋಷವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// ಇದನ್ನು [`for_each()`] ನ ದೋಷಪೂರಿತ ರೂಪ ಅಥವಾ [`try_fold()`] ನ ಸ್ಥಿತಿಯಿಲ್ಲದ ಆವೃತ್ತಿಯೆಂದು ಸಹ ಭಾವಿಸಬಹುದು.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // ಇದು ಶಾರ್ಟ್-ಸರ್ಕ್ಯೂಟ್ ಆಗಿದೆ, ಆದ್ದರಿಂದ ಉಳಿದ ವಸ್ತುಗಳು ಇನ್ನೂ ಪುನರಾವರ್ತಕದಲ್ಲಿವೆ:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// ಕಾರ್ಯಾಚರಣೆಯನ್ನು ಅನ್ವಯಿಸುವ ಮೂಲಕ ಪ್ರತಿ ಅಂಶವನ್ನು ಸಂಚಯಕಕ್ಕೆ ಮಡಚಿ, ಅಂತಿಮ ಫಲಿತಾಂಶವನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// `fold()` ಎರಡು ವಾದಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ: ಆರಂಭಿಕ ಮೌಲ್ಯ, ಮತ್ತು ಎರಡು ವಾದಗಳೊಂದಿಗೆ ಮುಚ್ಚುವಿಕೆ: 'accumulator', ಮತ್ತು ಒಂದು ಅಂಶ.
    /// ಮುಚ್ಚುವಿಕೆಯು ಮುಂದಿನ ಪುನರಾವರ್ತನೆಗಾಗಿ ಸಂಚಯಕವು ಹೊಂದಿರಬೇಕಾದ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಆರಂಭಿಕ ಮೌಲ್ಯವು ಸಂಚಯಕವು ಮೊದಲ ಕರೆಯಲ್ಲಿ ಹೊಂದಿರುವ ಮೌಲ್ಯವಾಗಿದೆ.
    ///
    /// ಪುನರಾವರ್ತಕದ ಪ್ರತಿಯೊಂದು ಅಂಶಕ್ಕೂ ಈ ಮುಚ್ಚುವಿಕೆಯನ್ನು ಅನ್ವಯಿಸಿದ ನಂತರ, `fold()` ಸಂಚಯಕವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಕಾರ್ಯಾಚರಣೆಯನ್ನು ಕೆಲವೊಮ್ಮೆ 'reduce' ಅಥವಾ 'inject' ಎಂದು ಕರೆಯಲಾಗುತ್ತದೆ.
    ///
    /// ನೀವು ಏನಾದರೂ ಸಂಗ್ರಹವನ್ನು ಹೊಂದಿರುವಾಗ ಮಡಿಸುವಿಕೆಯು ಉಪಯುಕ್ತವಾಗಿದೆ ಮತ್ತು ಅದರಿಂದ ಒಂದೇ ಮೌಲ್ಯವನ್ನು ಉತ್ಪಾದಿಸಲು ಬಯಸುತ್ತದೆ.
    ///
    /// Note: `fold()`, ಮತ್ತು ಇಡೀ ಪುನರಾವರ್ತಕವನ್ನು ಹಾದುಹೋಗುವ ಅಂತಹುದೇ ವಿಧಾನಗಳು, ಅನಂತ ಪುನರಾವರ್ತಕರಿಗೆ, traits ನಲ್ಲಿಯೂ ಸಹ ಕೊನೆಗೊಳ್ಳುವುದಿಲ್ಲ, ಇದಕ್ಕಾಗಿ ಫಲಿತಾಂಶವು ಸೀಮಿತ ಸಮಯದಲ್ಲಿ ನಿರ್ಧರಿಸಲ್ಪಡುತ್ತದೆ.
    ///
    /// Note: ಸಂಚಯಕ ಪ್ರಕಾರ ಮತ್ತು ಐಟಂ ಪ್ರಕಾರ ಒಂದೇ ಆಗಿದ್ದರೆ, ಮೊದಲ ಅಂಶವನ್ನು ಆರಂಭಿಕ ಮೌಲ್ಯವಾಗಿ ಬಳಸಲು [`reduce()`] ಅನ್ನು ಬಳಸಬಹುದು.
    ///
    /// # ಅನುಷ್ಠಾನಕಾರರಿಗೆ ಟಿಪ್ಪಣಿ
    ///
    /// ಹಲವಾರು ಇತರ (forward) ವಿಧಾನಗಳು ಈ ವಿಷಯದಲ್ಲಿ ಡೀಫಾಲ್ಟ್ ಅನುಷ್ಠಾನಗಳನ್ನು ಹೊಂದಿವೆ, ಆದ್ದರಿಂದ ಡೀಫಾಲ್ಟ್ `for` ಲೂಪ್ ಅನುಷ್ಠಾನಕ್ಕಿಂತ ಉತ್ತಮವಾದದ್ದನ್ನು ಮಾಡಲು ಸಾಧ್ಯವಾದರೆ ಇದನ್ನು ಸ್ಪಷ್ಟವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸಲು ಪ್ರಯತ್ನಿಸಿ.
    ///
    ///
    /// ನಿರ್ದಿಷ್ಟವಾಗಿ, ಈ ಪುನರಾವರ್ತಕ ಸಂಯೋಜನೆಗೊಂಡ ಆಂತರಿಕ ಭಾಗಗಳಲ್ಲಿ ಈ ಕರೆ `fold()` ಅನ್ನು ಹೊಂದಲು ಪ್ರಯತ್ನಿಸಿ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ರಚನೆಯ ಎಲ್ಲಾ ಅಂಶಗಳ ಮೊತ್ತ
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// ಪುನರಾವರ್ತನೆಯ ಪ್ರತಿಯೊಂದು ಹಂತದಲ್ಲೂ ಇಲ್ಲಿ ನಡೆಯೋಣ:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// ಆದ್ದರಿಂದ, ನಮ್ಮ ಅಂತಿಮ ಫಲಿತಾಂಶ, `6`.
    ///
    /// ಪುನರಾವರ್ತಕಗಳನ್ನು ಹೆಚ್ಚು ಬಳಸದ ಜನರು ಫಲಿತಾಂಶವನ್ನು ನಿರ್ಮಿಸಲು ವಸ್ತುಗಳ ಪಟ್ಟಿಯೊಂದಿಗೆ `for` ಲೂಪ್ ಅನ್ನು ಬಳಸುವುದು ಸಾಮಾನ್ಯವಾಗಿದೆ.ಅವುಗಳನ್ನು `fold()`s ಆಗಿ ಪರಿವರ್ತಿಸಬಹುದು:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // ಲೂಪ್‌ಗಾಗಿ:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // ಅವರು ಒಂದೇ
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// ಕಡಿಮೆಗೊಳಿಸುವ ಕಾರ್ಯಾಚರಣೆಯನ್ನು ಪದೇ ಪದೇ ಅನ್ವಯಿಸುವ ಮೂಲಕ ಅಂಶಗಳನ್ನು ಒಂದೇ ಒಂದಕ್ಕೆ ಕಡಿಮೆ ಮಾಡುತ್ತದೆ.
    ///
    /// ಪುನರಾವರ್ತಕ ಖಾಲಿಯಾಗಿದ್ದರೆ, [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ;ಇಲ್ಲದಿದ್ದರೆ, ಕಡಿತದ ಫಲಿತಾಂಶವನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// ಕನಿಷ್ಠ ಒಂದು ಅಂಶವನ್ನು ಹೊಂದಿರುವ ಪುನರಾವರ್ತಕರಿಗೆ, ಇದು ಆರಂಭಿಕ ಮೌಲ್ಯದ ಪುನರಾವರ್ತನೆಯ ಮೊದಲ ಅಂಶದೊಂದಿಗೆ [`fold()`] ಗೆ ಸಮನಾಗಿರುತ್ತದೆ, ನಂತರದ ಪ್ರತಿಯೊಂದು ಅಂಶವನ್ನು ಅದರೊಳಗೆ ಮಡಚಿಕೊಳ್ಳುತ್ತದೆ.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// ಗರಿಷ್ಠ ಮೌಲ್ಯವನ್ನು ಹುಡುಕಿ:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// ಪುನರಾವರ್ತಕದ ಪ್ರತಿಯೊಂದು ಅಂಶವು ಮುನ್ಸೂಚನೆಗೆ ಹೊಂದಿಕೆಯಾದರೆ ಪರೀಕ್ಷೆಗಳು.
    ///
    /// `all()` `true` ಅಥವಾ `false` ಅನ್ನು ಹಿಂದಿರುಗಿಸುವ ಮುಚ್ಚುವಿಕೆಯನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.ಇದು ಪುನರಾವರ್ತಕದ ಪ್ರತಿಯೊಂದು ಅಂಶಕ್ಕೂ ಈ ಮುಚ್ಚುವಿಕೆಯನ್ನು ಅನ್ವಯಿಸುತ್ತದೆ, ಮತ್ತು ಅವರೆಲ್ಲರೂ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸಿದರೆ, `all()` ಕೂಡ ಹಾಗೆ ಮಾಡುತ್ತದೆ.
    /// ಅವುಗಳಲ್ಲಿ ಯಾವುದಾದರೂ `false` ಅನ್ನು ಹಿಂತಿರುಗಿಸಿದರೆ, ಅದು `false` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `all()` ಶಾರ್ಟ್ ಸರ್ಕ್ಯೂಟಿಂಗ್ ಆಗಿದೆ;ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, ಇದು `false` ಅನ್ನು ಕಂಡುಕೊಂಡ ತಕ್ಷಣ ಅದು ಪ್ರಕ್ರಿಯೆಯನ್ನು ನಿಲ್ಲಿಸುತ್ತದೆ, ಬೇರೆ ಏನಾಗುತ್ತದೆಯೋ, ಫಲಿತಾಂಶವು `false` ಆಗಿರುತ್ತದೆ.
    ///
    ///
    /// ಖಾಲಿ ಪುನರಾವರ್ತಕವು `true` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// ಮೊದಲ `false` ನಲ್ಲಿ ನಿಲ್ಲಿಸಲಾಗುತ್ತಿದೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // ಹೆಚ್ಚಿನ ಅಂಶಗಳು ಇರುವುದರಿಂದ ನಾವು ಇನ್ನೂ `iter` ಅನ್ನು ಬಳಸಬಹುದು.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// ಪುನರಾವರ್ತಕದ ಯಾವುದೇ ಅಂಶವು icate ಹೆಯೊಂದಿಗೆ ಹೊಂದಿಕೆಯಾದರೆ ಪರೀಕ್ಷೆಗಳು.
    ///
    /// `any()` `true` ಅಥವಾ `false` ಅನ್ನು ಹಿಂದಿರುಗಿಸುವ ಮುಚ್ಚುವಿಕೆಯನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.ಇದು ಪುನರಾವರ್ತಕದ ಪ್ರತಿಯೊಂದು ಅಂಶಕ್ಕೂ ಈ ಮುಚ್ಚುವಿಕೆಯನ್ನು ಅನ್ವಯಿಸುತ್ತದೆ, ಮತ್ತು ಅವುಗಳಲ್ಲಿ ಯಾವುದಾದರೂ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸಿದರೆ, `any()` ಸಹ ಮಾಡುತ್ತದೆ.
    /// ಅವರೆಲ್ಲರೂ `false` ಅನ್ನು ಹಿಂತಿರುಗಿಸಿದರೆ, ಅದು `false` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `any()` ಶಾರ್ಟ್ ಸರ್ಕ್ಯೂಟಿಂಗ್ ಆಗಿದೆ;ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, ಇದು `true` ಅನ್ನು ಕಂಡುಕೊಂಡ ತಕ್ಷಣ ಅದು ಪ್ರಕ್ರಿಯೆಯನ್ನು ನಿಲ್ಲಿಸುತ್ತದೆ, ಬೇರೆ ಏನಾಗುತ್ತದೆಯೋ, ಫಲಿತಾಂಶವು `true` ಆಗಿರುತ್ತದೆ.
    ///
    ///
    /// ಖಾಲಿ ಪುನರಾವರ್ತಕವು `false` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// ಮೊದಲ `true` ನಲ್ಲಿ ನಿಲ್ಲಿಸಲಾಗುತ್ತಿದೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // ಹೆಚ್ಚಿನ ಅಂಶಗಳು ಇರುವುದರಿಂದ ನಾವು ಇನ್ನೂ `iter` ಅನ್ನು ಬಳಸಬಹುದು.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// ಮುನ್ಸೂಚನೆಯನ್ನು ತೃಪ್ತಿಪಡಿಸುವ ಪುನರಾವರ್ತಕನ ಅಂಶಕ್ಕಾಗಿ ಹುಡುಕುತ್ತದೆ.
    ///
    /// `find()` `true` ಅಥವಾ `false` ಅನ್ನು ಹಿಂದಿರುಗಿಸುವ ಮುಚ್ಚುವಿಕೆಯನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    /// ಇದು ಪುನರಾವರ್ತಕದ ಪ್ರತಿಯೊಂದು ಅಂಶಕ್ಕೂ ಈ ಮುಚ್ಚುವಿಕೆಯನ್ನು ಅನ್ವಯಿಸುತ್ತದೆ, ಮತ್ತು ಅವುಗಳಲ್ಲಿ ಯಾವುದಾದರೂ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸಿದರೆ, `find()` [`Some(element)`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    /// ಅವರೆಲ್ಲರೂ `false` ಅನ್ನು ಹಿಂತಿರುಗಿಸಿದರೆ, ಅದು [`None`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `find()` ಶಾರ್ಟ್ ಸರ್ಕ್ಯೂಟಿಂಗ್ ಆಗಿದೆ;ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, ಮುಚ್ಚುವಿಕೆಯು `true` ಅನ್ನು ಹಿಂದಿರುಗಿಸಿದ ತಕ್ಷಣ ಅದು ಪ್ರಕ್ರಿಯೆಯನ್ನು ನಿಲ್ಲಿಸುತ್ತದೆ.
    ///
    /// ಏಕೆಂದರೆ `find()` ಒಂದು ಉಲ್ಲೇಖವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ, ಮತ್ತು ಅನೇಕ ಪುನರಾವರ್ತಕರು ಉಲ್ಲೇಖಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಿಸುತ್ತಾರೆ, ಇದು ಬಹುಶಃ ಗೊಂದಲಮಯ ಪರಿಸ್ಥಿತಿಗೆ ಕಾರಣವಾಗುತ್ತದೆ, ಅಲ್ಲಿ ವಾದವು ಎರಡು ಉಲ್ಲೇಖವಾಗಿರುತ್ತದೆ.
    ///
    /// `&&x` ನೊಂದಿಗೆ ಕೆಳಗಿನ ಉದಾಹರಣೆಗಳಲ್ಲಿ ನೀವು ಈ ಪರಿಣಾಮವನ್ನು ನೋಡಬಹುದು.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// ಮೊದಲ `true` ನಲ್ಲಿ ನಿಲ್ಲಿಸಲಾಗುತ್ತಿದೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // ಹೆಚ್ಚಿನ ಅಂಶಗಳು ಇರುವುದರಿಂದ ನಾವು ಇನ್ನೂ `iter` ಅನ್ನು ಬಳಸಬಹುದು.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// `iter.find(f)` `iter.filter(f).next()` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// ಪುನರಾವರ್ತಕದ ಅಂಶಗಳಿಗೆ ಕಾರ್ಯವನ್ನು ಅನ್ವಯಿಸುತ್ತದೆ ಮತ್ತು ಯಾವುದೂ ಅಲ್ಲದ ಮೊದಲ ಫಲಿತಾಂಶವನ್ನು ನೀಡುತ್ತದೆ.
    ///
    ///
    /// `iter.find_map(f)` ಇದು `iter.filter_map(f).next()` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// ಪುನರಾವರ್ತಕದ ಅಂಶಗಳಿಗೆ ಕಾರ್ಯವನ್ನು ಅನ್ವಯಿಸುತ್ತದೆ ಮತ್ತು ಮೊದಲ ನಿಜವಾದ ಫಲಿತಾಂಶ ಅಥವಾ ಮೊದಲ ದೋಷವನ್ನು ನೀಡುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// ಪುನರಾವರ್ತಕದಲ್ಲಿನ ಒಂದು ಅಂಶಕ್ಕಾಗಿ ಹುಡುಕುತ್ತದೆ, ಅದರ ಸೂಚಿಯನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `position()` `true` ಅಥವಾ `false` ಅನ್ನು ಹಿಂದಿರುಗಿಸುವ ಮುಚ್ಚುವಿಕೆಯನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    /// ಇದು ಪುನರಾವರ್ತಕದ ಪ್ರತಿಯೊಂದು ಅಂಶಕ್ಕೂ ಈ ಮುಚ್ಚುವಿಕೆಯನ್ನು ಅನ್ವಯಿಸುತ್ತದೆ, ಮತ್ತು ಅವುಗಳಲ್ಲಿ ಒಂದು `true` ಅನ್ನು ಹಿಂದಿರುಗಿಸಿದರೆ, `position()` [`Some(index)`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    /// ಅವರೆಲ್ಲರೂ `false` ಅನ್ನು ಹಿಂತಿರುಗಿಸಿದರೆ, ಅದು [`None`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `position()` ಶಾರ್ಟ್ ಸರ್ಕ್ಯೂಟಿಂಗ್ ಆಗಿದೆ;ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, ಇದು `true` ಅನ್ನು ಕಂಡುಕೊಂಡ ತಕ್ಷಣ ಅದು ಪ್ರಕ್ರಿಯೆಯನ್ನು ನಿಲ್ಲಿಸುತ್ತದೆ.
    ///
    /// # ಉಕ್ಕಿ ಹರಿಯುವ ವರ್ತನೆ
    ///
    /// ಈ ವಿಧಾನವು ಓವರ್‌ಫ್ಲೋಗಳ ವಿರುದ್ಧ ಯಾವುದೇ ಕಾವಲು ಕಾಯುವುದಿಲ್ಲ, ಆದ್ದರಿಂದ [`usize::MAX`] ಗಿಂತ ಹೆಚ್ಚು ಹೊಂದಿಕೆಯಾಗದ ಅಂಶಗಳು ಇದ್ದರೆ, ಅದು ತಪ್ಪು ಫಲಿತಾಂಶವನ್ನು ನೀಡುತ್ತದೆ ಅಥವಾ panics ಅನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// ಡೀಬಗ್ ಪ್ರತಿಪಾದನೆಗಳನ್ನು ಸಕ್ರಿಯಗೊಳಿಸಿದರೆ, panic ಅನ್ನು ಖಾತರಿಪಡಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// ಪುನರಾವರ್ತಕವು `usize::MAX` ಗಿಂತ ಹೆಚ್ಚು ಹೊಂದಿಕೆಯಾಗದ ಅಂಶಗಳನ್ನು ಹೊಂದಿದ್ದರೆ ಈ ಕಾರ್ಯವು panic ಆಗಿರಬಹುದು.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// ಮೊದಲ `true` ನಲ್ಲಿ ನಿಲ್ಲಿಸಲಾಗುತ್ತಿದೆ:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // ಹೆಚ್ಚಿನ ಅಂಶಗಳು ಇರುವುದರಿಂದ ನಾವು ಇನ್ನೂ `iter` ಅನ್ನು ಬಳಸಬಹುದು.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // ಹಿಂತಿರುಗಿದ ಸೂಚ್ಯಂಕವು ಪುನರಾವರ್ತಕ ಸ್ಥಿತಿಯನ್ನು ಅವಲಂಬಿಸಿರುತ್ತದೆ
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// ಬಲದಿಂದ ಪುನರಾವರ್ತಕದಲ್ಲಿನ ಒಂದು ಅಂಶಕ್ಕಾಗಿ ಹುಡುಕುತ್ತದೆ, ಅದರ ಸೂಚಿಯನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `rposition()` `true` ಅಥವಾ `false` ಅನ್ನು ಹಿಂದಿರುಗಿಸುವ ಮುಚ್ಚುವಿಕೆಯನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    /// ಇದು ಕೊನೆಯಿಂದ ಪ್ರಾರಂಭವಾಗುವ ಪುನರಾವರ್ತಕದ ಪ್ರತಿಯೊಂದು ಅಂಶಕ್ಕೂ ಈ ಮುಚ್ಚುವಿಕೆಯನ್ನು ಅನ್ವಯಿಸುತ್ತದೆ, ಮತ್ತು ಅವುಗಳಲ್ಲಿ ಒಂದು `true` ಅನ್ನು ಹಿಂದಿರುಗಿಸಿದರೆ, `rposition()` [`Some(index)`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಅವರೆಲ್ಲರೂ `false` ಅನ್ನು ಹಿಂತಿರುಗಿಸಿದರೆ, ಅದು [`None`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `rposition()` ಶಾರ್ಟ್ ಸರ್ಕ್ಯೂಟಿಂಗ್ ಆಗಿದೆ;ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, ಇದು `true` ಅನ್ನು ಕಂಡುಕೊಂಡ ತಕ್ಷಣ ಅದು ಪ್ರಕ್ರಿಯೆಯನ್ನು ನಿಲ್ಲಿಸುತ್ತದೆ.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// ಮೊದಲ `true` ನಲ್ಲಿ ನಿಲ್ಲಿಸಲಾಗುತ್ತಿದೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // ಹೆಚ್ಚಿನ ಅಂಶಗಳು ಇರುವುದರಿಂದ ನಾವು ಇನ್ನೂ `iter` ಅನ್ನು ಬಳಸಬಹುದು.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // ಇಲ್ಲಿ ಓವರ್‌ಫ್ಲೋ ಪರಿಶೀಲನೆಯ ಅಗತ್ಯವಿಲ್ಲ, ಏಕೆಂದರೆ ಅಂಶಗಳ ಸಂಖ್ಯೆ `usize` ಗೆ ಹೊಂದಿಕೊಳ್ಳುತ್ತದೆ ಎಂದು `ExactSizeIterator` ಸೂಚಿಸುತ್ತದೆ.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// ಪುನರಾವರ್ತಕದ ಗರಿಷ್ಠ ಅಂಶವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಹಲವಾರು ಅಂಶಗಳು ಸಮಾನವಾಗಿ ಗರಿಷ್ಠವಾಗಿದ್ದರೆ, ಕೊನೆಯ ಅಂಶವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    /// ಪುನರಾವರ್ತಕ ಖಾಲಿಯಾಗಿದ್ದರೆ, [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// ಪುನರಾವರ್ತಕದ ಕನಿಷ್ಠ ಅಂಶವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಹಲವಾರು ಅಂಶಗಳು ಸಮಾನವಾಗಿ ಕನಿಷ್ಠವಾಗಿದ್ದರೆ, ಮೊದಲ ಅಂಶವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    /// ಪುನರಾವರ್ತಕ ಖಾಲಿಯಾಗಿದ್ದರೆ, [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಕಾರ್ಯದಿಂದ ಗರಿಷ್ಠ ಮೌಲ್ಯವನ್ನು ನೀಡುವ ಅಂಶವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// ಹಲವಾರು ಅಂಶಗಳು ಸಮಾನವಾಗಿ ಗರಿಷ್ಠವಾಗಿದ್ದರೆ, ಕೊನೆಯ ಅಂಶವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    /// ಪುನರಾವರ್ತಕ ಖಾಲಿಯಾಗಿದ್ದರೆ, [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಹೋಲಿಕೆ ಕಾರ್ಯಕ್ಕೆ ಸಂಬಂಧಿಸಿದಂತೆ ಗರಿಷ್ಠ ಮೌಲ್ಯವನ್ನು ನೀಡುವ ಅಂಶವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// ಹಲವಾರು ಅಂಶಗಳು ಸಮಾನವಾಗಿ ಗರಿಷ್ಠವಾಗಿದ್ದರೆ, ಕೊನೆಯ ಅಂಶವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    /// ಪುನರಾವರ್ತಕ ಖಾಲಿಯಾಗಿದ್ದರೆ, [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಕಾರ್ಯದಿಂದ ಕನಿಷ್ಠ ಮೌಲ್ಯವನ್ನು ನೀಡುವ ಅಂಶವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// ಹಲವಾರು ಅಂಶಗಳು ಸಮಾನವಾಗಿ ಕನಿಷ್ಠವಾಗಿದ್ದರೆ, ಮೊದಲ ಅಂಶವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    /// ಪುನರಾವರ್ತಕ ಖಾಲಿಯಾಗಿದ್ದರೆ, [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಹೋಲಿಕೆ ಕಾರ್ಯಕ್ಕೆ ಸಂಬಂಧಿಸಿದಂತೆ ಕನಿಷ್ಠ ಮೌಲ್ಯವನ್ನು ನೀಡುವ ಅಂಶವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// ಹಲವಾರು ಅಂಶಗಳು ಸಮಾನವಾಗಿ ಕನಿಷ್ಠವಾಗಿದ್ದರೆ, ಮೊದಲ ಅಂಶವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    /// ಪುನರಾವರ್ತಕ ಖಾಲಿಯಾಗಿದ್ದರೆ, [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// ಪುನರಾವರ್ತಕನ ನಿರ್ದೇಶನವನ್ನು ಹಿಮ್ಮುಖಗೊಳಿಸುತ್ತದೆ.
    ///
    /// ಸಾಮಾನ್ಯವಾಗಿ, ಪುನರಾವರ್ತಕರು ಎಡದಿಂದ ಬಲಕ್ಕೆ ಪುನರಾವರ್ತಿಸುತ್ತಾರೆ.
    /// `rev()` ಅನ್ನು ಬಳಸಿದ ನಂತರ, ಪುನರಾವರ್ತಕವು ಬಲದಿಂದ ಎಡಕ್ಕೆ ಪುನರಾವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ಪುನರಾವರ್ತಕವು ಅಂತ್ಯವನ್ನು ಹೊಂದಿದ್ದರೆ ಮಾತ್ರ ಇದು ಸಾಧ್ಯ, ಆದ್ದರಿಂದ `rev()` [`DoubleEndedIterator`] ಗಳಲ್ಲಿ ಮಾತ್ರ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// ಜೋಡಿಗಳ ಪುನರಾವರ್ತಕವನ್ನು ಜೋಡಿ ಪಾತ್ರೆಗಳಾಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// `unzip()` ಜೋಡಿಗಳ ಸಂಪೂರ್ಣ ಪುನರಾವರ್ತಕವನ್ನು ಬಳಸುತ್ತದೆ, ಎರಡು ಸಂಗ್ರಹಗಳನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ: ಒಂದು ಜೋಡಿಗಳ ಎಡ ಅಂಶಗಳಿಂದ ಮತ್ತು ಒಂದು ಬಲ ಅಂಶಗಳಿಂದ.
    ///
    ///
    /// ಈ ಕಾರ್ಯವು ಕೆಲವು ಅರ್ಥದಲ್ಲಿ, [`zip`] ಗೆ ವಿರುದ್ಧವಾಗಿರುತ್ತದೆ.
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// ಅದರ ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ನಕಲಿಸುವ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// ನೀವು `&T` ಗಿಂತ ಪುನರಾವರ್ತಕವನ್ನು ಹೊಂದಿರುವಾಗ ಇದು ಉಪಯುಕ್ತವಾಗಿದೆ, ಆದರೆ ನಿಮಗೆ `T` ಗಿಂತ ಪುನರಾವರ್ತಕ ಅಗತ್ಯವಿದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // ನಕಲಿಸಲಾಗಿದೆ .map(|&x| x) ನಂತೆಯೇ ಇರುತ್ತದೆ
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// [`ಕ್ಲೋನ್`] ಅದರ ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ಹೊಂದಿರುವ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// ನೀವು `&T` ಗಿಂತ ಪುನರಾವರ್ತಕವನ್ನು ಹೊಂದಿರುವಾಗ ಇದು ಉಪಯುಕ್ತವಾಗಿದೆ, ಆದರೆ ನಿಮಗೆ `T` ಗಿಂತ ಪುನರಾವರ್ತಕ ಅಗತ್ಯವಿದೆ.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿಗಾಗಿ .map(|&x| x) ನಂತೆಯೇ ಇರುತ್ತದೆ
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// ಪುನರಾವರ್ತಕವನ್ನು ಅನಂತವಾಗಿ ಪುನರಾವರ್ತಿಸುತ್ತದೆ.
    ///
    /// [`None`] ನಲ್ಲಿ ನಿಲ್ಲಿಸುವ ಬದಲು, ಪುನರಾವರ್ತಕವು ಮೊದಲಿನಿಂದಲೂ ಮತ್ತೆ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ.ಮತ್ತೆ ಪುನರಾವರ್ತಿಸಿದ ನಂತರ, ಅದು ಮತ್ತೆ ಪ್ರಾರಂಭದಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ.ಮತ್ತು ಮತ್ತೆ.
    /// ಮತ್ತು ಮತ್ತೆ.
    /// Forever.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// ಪುನರಾವರ್ತಕದ ಅಂಶಗಳನ್ನು ಒಟ್ಟುಗೂಡಿಸುತ್ತದೆ.
    ///
    /// ಪ್ರತಿ ಅಂಶವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ, ಅವುಗಳನ್ನು ಒಟ್ಟಿಗೆ ಸೇರಿಸುತ್ತದೆ ಮತ್ತು ಫಲಿತಾಂಶವನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// ಖಾಲಿ ಪುನರಾವರ್ತಕವು ಪ್ರಕಾರದ ಶೂನ್ಯ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// `sum()` ಗೆ ಕರೆ ಮಾಡುವಾಗ ಮತ್ತು ಪ್ರಾಚೀನ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತಿರುವಾಗ, ಗಣನೆಯು ಉಕ್ಕಿ ಹರಿಯುವುದು ಮತ್ತು ಡೀಬಗ್ ಪ್ರತಿಪಾದನೆಗಳನ್ನು ಸಕ್ರಿಯಗೊಳಿಸಿದರೆ ಈ ವಿಧಾನವು panic ಆಗಿರುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// ಸಂಪೂರ್ಣ ಪುನರಾವರ್ತಕದ ಮೇಲೆ ಪುನರಾವರ್ತಿಸುತ್ತದೆ, ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ಗುಣಿಸುತ್ತದೆ
    ///
    /// ಖಾಲಿ ಪುನರಾವರ್ತಕವು ಪ್ರಕಾರದ ಒಂದು ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// `product()` ಗೆ ಕರೆ ಮಾಡುವಾಗ ಮತ್ತು ಪ್ರಾಚೀನ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತಿರುವಾಗ, ಗಣನೆಯು ಉಕ್ಕಿ ಹರಿಯುವುದು ಮತ್ತು ಡೀಬಗ್ ಪ್ರತಿಪಾದನೆಗಳನ್ನು ಸಕ್ರಿಯಗೊಳಿಸಿದರೆ ವಿಧಾನವು panic ಆಗಿರುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ಈ [`Iterator`] ನ ಅಂಶಗಳನ್ನು ಇನ್ನೊಂದರೊಂದಿಗೆ ಹೋಲಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ನಿಗದಿತ ಹೋಲಿಕೆ ಕಾರ್ಯಕ್ಕೆ ಸಂಬಂಧಿಸಿದಂತೆ ಈ [`Iterator`] ನ ಅಂಶಗಳನ್ನು ಇನ್ನೊಂದರೊಂದಿಗೆ ಹೋಲಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ಈ [`Iterator`] ನ ಅಂಶಗಳನ್ನು ಇನ್ನೊಂದರೊಂದಿಗೆ ಹೋಲಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ನಿಗದಿತ ಹೋಲಿಕೆ ಕಾರ್ಯಕ್ಕೆ ಸಂಬಂಧಿಸಿದಂತೆ ಈ [`Iterator`] ನ ಅಂಶಗಳನ್ನು ಇನ್ನೊಂದರೊಂದಿಗೆ ಹೋಲಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// ಈ [`Iterator`] ನ ಅಂಶಗಳು ಇನ್ನೊಂದಕ್ಕೆ ಸಮನಾಗಿವೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಸಮಾನತೆಯ ಕಾರ್ಯಕ್ಕೆ ಸಂಬಂಧಿಸಿದಂತೆ ಈ [`Iterator`] ನ ಅಂಶಗಳು ಇನ್ನೊಂದಕ್ಕೆ ಸಮನಾಗಿವೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// ಈ [`Iterator`] ನ ಅಂಶಗಳು ಇನ್ನೊಂದಕ್ಕೆ ಅಸಮಾನವಾಗಿದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// ಈ [`Iterator`] ನ ಅಂಶಗಳು ಇನ್ನೊಂದಕ್ಕಿಂತ [lexicographically](Ord#lexicographical-comparison) ಕಡಿಮೆ ಇದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// ಈ [`Iterator`] ನ ಅಂಶಗಳು [lexicographically](Ord#lexicographical-comparison) ಕಡಿಮೆ ಅಥವಾ ಇನ್ನೊಂದಕ್ಕೆ ಸಮನಾಗಿವೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// ಈ [`Iterator`] ನ ಅಂಶಗಳು ಇನ್ನೊಂದಕ್ಕಿಂತ [lexicographically](Ord#lexicographical-comparison) ಹೆಚ್ಚಿದೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// ಈ [`Iterator`] ನ ಅಂಶಗಳು [lexicographically](Ord#lexicographical-comparison) ಇನ್ನೊಂದಕ್ಕಿಂತ ದೊಡ್ಡದಾಗಿದೆ ಅಥವಾ ಸಮನಾಗಿವೆಯೇ ಎಂದು ನಿರ್ಧರಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// ಈ ಪುನರಾವರ್ತಕದ ಅಂಶಗಳನ್ನು ವಿಂಗಡಿಸಲಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ.
    ///
    /// ಅಂದರೆ, ಪ್ರತಿ ಅಂಶ `a` ಮತ್ತು ಅದರ ಕೆಳಗಿನ ಅಂಶ `b` ಗೆ, `a <= b` ಹಿಡಿದಿರಬೇಕು.ಪುನರಾವರ್ತಕ ನಿಖರವಾಗಿ ಶೂನ್ಯ ಅಥವಾ ಒಂದು ಅಂಶವನ್ನು ನೀಡಿದರೆ, `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// `Self::Item` ಕೇವಲ `PartialOrd` ಆಗಿದ್ದರೆ, ಆದರೆ `Ord` ಅಲ್ಲದಿದ್ದರೆ, ಮೇಲಿನ ಎರಡು ವ್ಯಾಖ್ಯಾನವು ಯಾವುದೇ ಎರಡು ಸತತ ವಸ್ತುಗಳನ್ನು ಹೋಲಿಸಲಾಗದಿದ್ದರೆ ಈ ಕಾರ್ಯವು `false` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ ಎಂದು ಸೂಚಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// ಕೊಟ್ಟಿರುವ ಹೋಲಿಕೆದಾರ ಕಾರ್ಯವನ್ನು ಬಳಸಿಕೊಂಡು ಈ ಪುನರಾವರ್ತಕದ ಅಂಶಗಳನ್ನು ವಿಂಗಡಿಸಲಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ.
    ///
    /// `PartialOrd::partial_cmp` ಅನ್ನು ಬಳಸುವ ಬದಲು, ಈ ಕಾರ್ಯವು ಎರಡು ಅಂಶಗಳ ಕ್ರಮವನ್ನು ನಿರ್ಧರಿಸಲು ಕೊಟ್ಟಿರುವ `compare` ಕಾರ್ಯವನ್ನು ಬಳಸುತ್ತದೆ.
    /// ಅದನ್ನು ಹೊರತುಪಡಿಸಿ, ಇದು [`is_sorted`] ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ;ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// ಕೊಟ್ಟಿರುವ ಕೀ ಹೊರತೆಗೆಯುವ ಕಾರ್ಯವನ್ನು ಬಳಸಿಕೊಂಡು ಈ ಪುನರಾವರ್ತಕದ ಅಂಶಗಳನ್ನು ವಿಂಗಡಿಸಲಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ.
    ///
    /// ಪುನರಾವರ್ತಕನ ಅಂಶಗಳನ್ನು ನೇರವಾಗಿ ಹೋಲಿಸುವ ಬದಲು, ಈ ಕಾರ್ಯವು `f` ನಿಂದ ನಿರ್ಧರಿಸಲ್ಪಟ್ಟ ಅಂಶಗಳ ಕೀಲಿಗಳನ್ನು ಹೋಲಿಸುತ್ತದೆ.
    /// ಅದನ್ನು ಹೊರತುಪಡಿಸಿ, ಇದು [`is_sorted`] ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ;ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// [TrustedRandomAccess] ನೋಡಿ
    // ವಿಧಾನ ರೆಸಲ್ಯೂಶನ್‌ನಲ್ಲಿ ಹೆಸರು ಘರ್ಷಣೆಯನ್ನು ತಪ್ಪಿಸುವುದು ಅಸಾಮಾನ್ಯ ಹೆಸರು #76479 ನೋಡಿ.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}