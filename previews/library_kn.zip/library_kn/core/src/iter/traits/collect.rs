/// [`Iterator`] ನಿಂದ ಪರಿವರ್ತನೆ.
///
/// ಒಂದು ಪ್ರಕಾರಕ್ಕಾಗಿ `FromIterator` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಮೂಲಕ, ಪುನರಾವರ್ತಕದಿಂದ ಅದನ್ನು ಹೇಗೆ ರಚಿಸಲಾಗುತ್ತದೆ ಎಂಬುದನ್ನು ನೀವು ವ್ಯಾಖ್ಯಾನಿಸುತ್ತೀರಿ.
/// ಕೆಲವು ರೀತಿಯ ಸಂಗ್ರಹವನ್ನು ವಿವರಿಸುವ ಪ್ರಕಾರಗಳಿಗೆ ಇದು ಸಾಮಾನ್ಯವಾಗಿದೆ.
///
/// [`FromIterator::from_iter()`] ಇದನ್ನು ವಿರಳವಾಗಿ ಸ್ಪಷ್ಟವಾಗಿ ಕರೆಯಲಾಗುತ್ತದೆ, ಮತ್ತು ಇದನ್ನು [`Iterator::collect()`] ವಿಧಾನದ ಮೂಲಕ ಬಳಸಲಾಗುತ್ತದೆ.
///
/// ಹೆಚ್ಚಿನ ಉದಾಹರಣೆಗಳಿಗಾಗಿ [`Iterator::collect()`]'s ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
///
/// ಸಹ ನೋಡಿ: [`IntoIterator`].
///
/// # Examples
///
/// ಮೂಲ ಬಳಕೆ:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// `FromIterator` ಅನ್ನು ಸೂಚ್ಯವಾಗಿ ಬಳಸಲು [`Iterator::collect()`] ಅನ್ನು ಬಳಸುವುದು:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// ನಿಮ್ಮ ಪ್ರಕಾರಕ್ಕಾಗಿ `FromIterator` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದು:
///
/// ```
/// use std::iter::FromIterator;
///
/// // ಮಾದರಿ ಸಂಗ್ರಹ, ಅದು ವೆಕ್ ಮೇಲೆ ಕೇವಲ ಹೊದಿಕೆ<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // ಅದಕ್ಕೆ ಕೆಲವು ವಿಧಾನಗಳನ್ನು ನೀಡೋಣ ಆದ್ದರಿಂದ ನಾವು ಒಂದನ್ನು ರಚಿಸಬಹುದು ಮತ್ತು ಅದಕ್ಕೆ ವಿಷಯಗಳನ್ನು ಸೇರಿಸಬಹುದು.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ಮತ್ತು ನಾವು ಫ್ರಂಇಟರೇಟರ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತೇವೆ
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // ಈಗ ನಾವು ಹೊಸ ಪುನರಾವರ್ತಕವನ್ನು ಮಾಡಬಹುದು ...
/// let iter = (0..5).into_iter();
///
/// // ... ಮತ್ತು ಅದರಿಂದ ಮೈ ಕಲೆಕ್ಷನ್ ಮಾಡಿ
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // ಸಂಗ್ರಹಗಳನ್ನು ಸಹ ಸಂಗ್ರಹಿಸಿ!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// ಪುನರಾವರ್ತಕದಿಂದ ಮೌಲ್ಯವನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ [module-level documentation] ನೋಡಿ.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// [`Iterator`] ಆಗಿ ಪರಿವರ್ತನೆ.
///
/// ಒಂದು ಪ್ರಕಾರಕ್ಕಾಗಿ `IntoIterator` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಮೂಲಕ, ಅದನ್ನು ಪುನರಾವರ್ತಕಕ್ಕೆ ಹೇಗೆ ಪರಿವರ್ತಿಸಲಾಗುತ್ತದೆ ಎಂಬುದನ್ನು ನೀವು ವ್ಯಾಖ್ಯಾನಿಸುತ್ತೀರಿ.
/// ಕೆಲವು ರೀತಿಯ ಸಂಗ್ರಹವನ್ನು ವಿವರಿಸುವ ಪ್ರಕಾರಗಳಿಗೆ ಇದು ಸಾಮಾನ್ಯವಾಗಿದೆ.
///
/// `IntoIterator` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಒಂದು ಪ್ರಯೋಜನವೆಂದರೆ ನಿಮ್ಮ ಪ್ರಕಾರವು [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) ಆಗಿರುತ್ತದೆ.
///
///
/// ಸಹ ನೋಡಿ: [`FromIterator`].
///
/// # Examples
///
/// ಮೂಲ ಬಳಕೆ:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// ನಿಮ್ಮ ಪ್ರಕಾರಕ್ಕಾಗಿ `IntoIterator` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದು:
///
/// ```
/// // ಮಾದರಿ ಸಂಗ್ರಹ, ಅದು ವೆಕ್ ಮೇಲೆ ಕೇವಲ ಹೊದಿಕೆ<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // ಅದಕ್ಕೆ ಕೆಲವು ವಿಧಾನಗಳನ್ನು ನೀಡೋಣ ಆದ್ದರಿಂದ ನಾವು ಒಂದನ್ನು ರಚಿಸಬಹುದು ಮತ್ತು ಅದಕ್ಕೆ ವಿಷಯಗಳನ್ನು ಸೇರಿಸಬಹುದು.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ಮತ್ತು ನಾವು IntoIterator ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತೇವೆ
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // ಈಗ ನಾವು ಹೊಸ ಸಂಗ್ರಹವನ್ನು ಮಾಡಬಹುದು ...
/// let mut c = MyCollection::new();
///
/// // ... ಅದಕ್ಕೆ ಕೆಲವು ಸಂಗತಿಗಳನ್ನು ಸೇರಿಸಿ ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... ತದನಂತರ ಅದನ್ನು ಇಟರೇಟರ್ ಆಗಿ ಪರಿವರ್ತಿಸಿ:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// `IntoIterator` ಅನ್ನು trait bound ಆಗಿ ಬಳಸುವುದು ಸಾಮಾನ್ಯವಾಗಿದೆ.ಇನ್ಪುಟ್ ಸಂಗ್ರಹ ಪ್ರಕಾರವನ್ನು ಬದಲಾಯಿಸಲು ಇದು ಅನುಮತಿಸುತ್ತದೆ, ಅದು ಇನ್ನೂ ಪುನರಾವರ್ತಕವಾಗಿದೆ.
/// ನಿರ್ಬಂಧಿಸುವ ಮೂಲಕ ಹೆಚ್ಚುವರಿ ಮಿತಿಗಳನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಬಹುದು
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// ಅಂಶಗಳ ಪ್ರಕಾರವನ್ನು ಪುನರಾವರ್ತಿಸಲಾಗುತ್ತದೆ.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// ನಾವು ಇದನ್ನು ಯಾವ ರೀತಿಯ ಪುನರಾವರ್ತಕರಾಗಿ ಪರಿವರ್ತಿಸುತ್ತಿದ್ದೇವೆ?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// ಮೌಲ್ಯದಿಂದ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ [module-level documentation] ನೋಡಿ.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// ಪುನರಾವರ್ತಕನ ವಿಷಯಗಳೊಂದಿಗೆ ಸಂಗ್ರಹವನ್ನು ವಿಸ್ತರಿಸಿ.
///
/// ಪುನರಾವರ್ತಕರು ಮೌಲ್ಯಗಳ ಸರಣಿಯನ್ನು ಉತ್ಪಾದಿಸುತ್ತಾರೆ, ಮತ್ತು ಸಂಗ್ರಹಣೆಯನ್ನು ಮೌಲ್ಯಗಳ ಸರಣಿಯೆಂದು ಸಹ ಭಾವಿಸಬಹುದು.
/// `Extend` trait ಈ ಅಂತರವನ್ನು ನಿವಾರಿಸುತ್ತದೆ, ಆ ಪುನರಾವರ್ತಕದ ವಿಷಯಗಳನ್ನು ಸೇರಿಸುವ ಮೂಲಕ ಸಂಗ್ರಹವನ್ನು ವಿಸ್ತರಿಸಲು ನಿಮಗೆ ಅನುವು ಮಾಡಿಕೊಡುತ್ತದೆ.
/// ಈಗಾಗಲೇ ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ ಕೀಲಿಯೊಂದಿಗೆ ಸಂಗ್ರಹವನ್ನು ವಿಸ್ತರಿಸುವಾಗ, ಆ ನಮೂದನ್ನು ನವೀಕರಿಸಲಾಗುತ್ತದೆ ಅಥವಾ ಸಮಾನ ಕೀಲಿಗಳನ್ನು ಹೊಂದಿರುವ ಅನೇಕ ನಮೂದುಗಳನ್ನು ಅನುಮತಿಸುವ ಸಂಗ್ರಹಗಳ ಸಂದರ್ಭದಲ್ಲಿ, ಆ ನಮೂದನ್ನು ಸೇರಿಸಲಾಗುತ್ತದೆ.
///
///
/// # Examples
///
/// ಮೂಲ ಬಳಕೆ:
///
/// ```
/// // ನೀವು ಕೆಲವು ಅಕ್ಷರಗಳೊಂದಿಗೆ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ವಿಸ್ತರಿಸಬಹುದು:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗುತ್ತಿದೆ:
///
/// ```
/// // ಮಾದರಿ ಸಂಗ್ರಹ, ಅದು ವೆಕ್ ಮೇಲೆ ಕೇವಲ ಹೊದಿಕೆ<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // ಅದಕ್ಕೆ ಕೆಲವು ವಿಧಾನಗಳನ್ನು ನೀಡೋಣ ಆದ್ದರಿಂದ ನಾವು ಒಂದನ್ನು ರಚಿಸಬಹುದು ಮತ್ತು ಅದಕ್ಕೆ ವಿಷಯಗಳನ್ನು ಸೇರಿಸಬಹುದು.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // MyCollection i32 ಗಳ ಪಟ್ಟಿಯನ್ನು ಹೊಂದಿರುವುದರಿಂದ, ನಾವು i32 ಗಾಗಿ ವಿಸ್ತರಣೆ ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತೇವೆ
/// impl Extend<i32> for MyCollection {
///
///     // ಕಾಂಕ್ರೀಟ್ ಪ್ರಕಾರದ ಸಹಿಯೊಂದಿಗೆ ಇದು ಸ್ವಲ್ಪ ಸರಳವಾಗಿದೆ: ಇಟೆರೇಟರ್ ಆಗಿ ಪರಿವರ್ತಿಸಬಹುದಾದ ಯಾವುದನ್ನಾದರೂ ವಿಸ್ತರಿಸಲು ನಾವು ಕರೆಯಬಹುದು, ಅದು ನಮಗೆ i32 ಗಳನ್ನು ನೀಡುತ್ತದೆ.
///     // ಏಕೆಂದರೆ ಮೈ ಕಲೆಕ್ಷನ್‌ಗೆ ಹಾಕಲು ನಮಗೆ ಐ 32 ಗಳು ಬೇಕಾಗುತ್ತವೆ.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // ಅನುಷ್ಠಾನವು ತುಂಬಾ ಸರಳವಾಗಿದೆ: ಪುನರಾವರ್ತಕದ ಮೂಲಕ ಲೂಪ್, ಮತ್ತು add() ಪ್ರತಿಯೊಂದು ಅಂಶವೂ ನಮಗೆ.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // ನಮ್ಮ ಸಂಗ್ರಹಣೆಯನ್ನು ಇನ್ನೂ ಮೂರು ಸಂಖ್ಯೆಗಳೊಂದಿಗೆ ವಿಸ್ತರಿಸೋಣ
/// c.extend(vec![1, 2, 3]);
///
/// // ನಾವು ಈ ಅಂಶಗಳನ್ನು ಕೊನೆಯಲ್ಲಿ ಸೇರಿಸಿದ್ದೇವೆ
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// ಪುನರಾವರ್ತಕನ ವಿಷಯಗಳೊಂದಿಗೆ ಸಂಗ್ರಹವನ್ನು ವಿಸ್ತರಿಸುತ್ತದೆ.
    ///
    /// ಈ trait ಗೆ ಅಗತ್ಯವಿರುವ ಏಕೈಕ ವಿಧಾನ ಇದಾಗಿರುವುದರಿಂದ, [trait-level] ಡಾಕ್ಸ್ ಹೆಚ್ಚಿನ ವಿವರಗಳನ್ನು ಒಳಗೊಂಡಿದೆ.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// // ನೀವು ಕೆಲವು ಅಕ್ಷರಗಳೊಂದಿಗೆ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ವಿಸ್ತರಿಸಬಹುದು:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// ನಿಖರವಾಗಿ ಒಂದು ಅಂಶದೊಂದಿಗೆ ಸಂಗ್ರಹವನ್ನು ವಿಸ್ತರಿಸುತ್ತದೆ.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// ನಿರ್ದಿಷ್ಟ ಸಂಖ್ಯೆಯ ಹೆಚ್ಚುವರಿ ಅಂಶಗಳಿಗಾಗಿ ಸಂಗ್ರಹದಲ್ಲಿ ಸಾಮರ್ಥ್ಯವನ್ನು ಕಾಯ್ದಿರಿಸಲಾಗಿದೆ.
    ///
    /// ಡೀಫಾಲ್ಟ್ ಅನುಷ್ಠಾನವು ಏನನ್ನೂ ಮಾಡುವುದಿಲ್ಲ.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}