use crate::ops::{ControlFlow, Try};

/// ಎರಡೂ ತುದಿಗಳಿಂದ ಅಂಶಗಳನ್ನು ನೀಡುವ ಇಟರೇಟರ್.
///
/// `DoubleEndedIterator` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಯಾವುದಾದರೂ ಒಂದು [`Iterator`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಯಾವುದಕ್ಕಿಂತ ಒಂದು ಹೆಚ್ಚುವರಿ ಸಾಮರ್ಥ್ಯವನ್ನು ಹೊಂದಿದೆ: `ಐಟಂ'ಗಳನ್ನು ಹಿಂಭಾಗದಿಂದ ಮತ್ತು ಮುಂಭಾಗದಿಂದ ತೆಗೆದುಕೊಳ್ಳುವ ಸಾಮರ್ಥ್ಯ.
///
///
/// ಹಿಂದಕ್ಕೆ ಮತ್ತು ಮುಂದಕ್ಕೆ ಒಂದೇ ವ್ಯಾಪ್ತಿಯಲ್ಲಿ ಕೆಲಸ ಮಾಡುತ್ತದೆ ಮತ್ತು ದಾಟಬೇಡಿ ಎಂಬುದನ್ನು ಗಮನಿಸುವುದು ಮುಖ್ಯ: ಅವರು ಮಧ್ಯದಲ್ಲಿ ಭೇಟಿಯಾದಾಗ ಪುನರಾವರ್ತನೆ ಮುಗಿದಿದೆ.
///
/// [`Iterator`] ಪ್ರೋಟೋಕಾಲ್‌ಗೆ ಹೋಲುವ ರೀತಿಯಲ್ಲಿ, ಒಮ್ಮೆ `DoubleEndedIterator` [`next_back()`] ನಿಂದ [`None`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಅದನ್ನು ಮತ್ತೆ ಕರೆಯುವುದರಿಂದ [`Some`] ಅನ್ನು ಮತ್ತೆ ಹಿಂತಿರುಗಿಸದೇ ಇರಬಹುದು.
/// [`next()`] ಮತ್ತು [`next_back()`] ಈ ಉದ್ದೇಶಕ್ಕಾಗಿ ಪರಸ್ಪರ ಬದಲಾಯಿಸಲ್ಪಡುತ್ತವೆ.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// ಮೂಲ ಬಳಕೆ:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// ಪುನರಾವರ್ತಕದ ತುದಿಯಿಂದ ಒಂದು ಅಂಶವನ್ನು ತೆಗೆದುಹಾಕುತ್ತದೆ ಮತ್ತು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಹೆಚ್ಚಿನ ಅಂಶಗಳಿಲ್ಲದಿದ್ದಾಗ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [trait-level] ಡಾಕ್ಸ್ ಹೆಚ್ಚಿನ ವಿವರಗಳನ್ನು ಒಳಗೊಂಡಿದೆ.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// `ಡಬಲ್ಎಂಡೆಡ್ಇಟೆರೇಟರ್'ನ ವಿಧಾನಗಳಿಂದ ಉತ್ಪತ್ತಿಯಾಗುವ ಅಂಶಗಳು [` ಇಟರೇಟರ್`] ನ ವಿಧಾನಗಳಿಂದ ಭಿನ್ನವಾಗಿರುತ್ತವೆ:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// `n` ಅಂಶಗಳಿಂದ ಹಿಂದಿನಿಂದ ಪುನರಾವರ್ತಕವನ್ನು ಮುನ್ನಡೆಸುತ್ತದೆ.
    ///
    /// `advance_back_by` ಇದು [`advance_by`] ನ ರಿವರ್ಸ್ ಆವೃತ್ತಿಯಾಗಿದೆ.ಈ ವಿಧಾನವು ಹಿಂದಿನಿಂದ ಪ್ರಾರಂಭವಾಗುವ `n` ಅಂಶಗಳನ್ನು [`next_back`] ಗೆ ಕರೆ ಮಾಡುವ ಮೂಲಕ [`next_back`] ಅನ್ನು `n` ಬಾರಿ [`None`] ಗೆ ಕರೆ ಮಾಡುವ ಮೂಲಕ ಕುತೂಹಲದಿಂದ ಬಿಡುತ್ತದೆ.
    ///
    /// `advance_back_by(n)` ಪುನರಾವರ್ತಕವು `n` ಅಂಶಗಳಿಂದ ಯಶಸ್ವಿಯಾಗಿ ಮುಂದುವರಿದರೆ [`Ok(())`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಥವಾ [`None`] ಎದುರಾದರೆ [`Err(k)`], ಇಲ್ಲಿ `k` ಎನ್ನುವುದು ಅಂಶಗಳಿಂದ ಹೊರಗುಳಿಯುವ ಮೊದಲು ಪುನರಾವರ್ತಕವು ಮುಂದುವರೆದ ಅಂಶಗಳ ಸಂಖ್ಯೆ (ಅಂದರೆ
    /// ಪುನರಾವರ್ತಕದ ಉದ್ದ).
    /// `k` ಯಾವಾಗಲೂ `n` ಗಿಂತ ಕಡಿಮೆಯಿರುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    /// `advance_back_by(0)` ಗೆ ಕರೆ ಮಾಡುವುದರಿಂದ ಯಾವುದೇ ಅಂಶಗಳನ್ನು ಸೇವಿಸುವುದಿಲ್ಲ ಮತ್ತು ಯಾವಾಗಲೂ [`Ok(())`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // `&3` ಅನ್ನು ಮಾತ್ರ ಬಿಡಲಾಗಿದೆ
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// ಇಟರೇಟರ್ನ ಅಂತ್ಯದಿಂದ `n` ನೇ ಅಂಶವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಇದು ಮೂಲಭೂತವಾಗಿ [`Iterator::nth()`] ನ ವ್ಯತಿರಿಕ್ತ ಆವೃತ್ತಿಯಾಗಿದೆ.
    /// ಹೆಚ್ಚಿನ ಇಂಡೆಕ್ಸಿಂಗ್ ಕಾರ್ಯಾಚರಣೆಗಳಂತೆ, ಎಣಿಕೆ ಶೂನ್ಯದಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ, ಆದ್ದರಿಂದ `nth_back(0)` ಮೊದಲ ಮೌಲ್ಯವನ್ನು ಕೊನೆಯಿಂದ ಹಿಂದಿರುಗಿಸುತ್ತದೆ, `nth_back(1)` ಎರಡನೆಯದು, ಮತ್ತು ಹೀಗೆ.
    ///
    ///
    /// ಹಿಂತಿರುಗಿದ ಅಂಶವನ್ನು ಒಳಗೊಂಡಂತೆ ಅಂತ್ಯ ಮತ್ತು ಹಿಂತಿರುಗಿದ ಅಂಶದ ನಡುವಿನ ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ಸೇವಿಸಲಾಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    /// ಒಂದೇ ಪುನರಾವರ್ತಕದಲ್ಲಿ `nth_back(0)` ಅನ್ನು ಅನೇಕ ಬಾರಿ ಕರೆ ಮಾಡುವುದರಿಂದ ವಿಭಿನ್ನ ಅಂಶಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ ಎಂದರ್ಥ.
    ///
    /// `nth_back()` `n` ಪುನರಾವರ್ತಕದ ಉದ್ದಕ್ಕಿಂತ ದೊಡ್ಡದಾಗಿದ್ದರೆ ಅಥವಾ ಸಮನಾಗಿದ್ದರೆ [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// `nth_back()` ಅನ್ನು ಅನೇಕ ಬಾರಿ ಕರೆ ಮಾಡುವುದರಿಂದ ಪುನರಾವರ್ತಕವನ್ನು ರಿವೈಂಡ್ ಮಾಡುವುದಿಲ್ಲ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// `n + 1` ಗಿಂತ ಕಡಿಮೆ ಅಂಶಗಳಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// ಇದು [`Iterator::try_fold()`] ನ ರಿವರ್ಸ್ ಆವೃತ್ತಿಯಾಗಿದೆ: ಇದು ಪುನರಾವರ್ತಕದ ಹಿಂಭಾಗದಿಂದ ಪ್ರಾರಂಭವಾಗುವ ಅಂಶಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // ಇದು ಶಾರ್ಟ್-ಸರ್ಕ್ಯೂಟ್ ಆಗಿರುವುದರಿಂದ, ಉಳಿದ ಅಂಶಗಳು ಇಟರೇಟರ್ ಮೂಲಕ ಇನ್ನೂ ಲಭ್ಯವಿವೆ.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// ಪುನರಾವರ್ತಕ ವಿಧಾನವು ಪುನರಾವರ್ತಕ ಅಂಶಗಳನ್ನು ಹಿಂದಿನಿಂದ ಪ್ರಾರಂಭಿಸಿ ಒಂದೇ, ಅಂತಿಮ ಮೌಲ್ಯಕ್ಕೆ ತಗ್ಗಿಸುತ್ತದೆ.
    ///
    /// ಇದು [`Iterator::fold()`] ನ ರಿವರ್ಸ್ ಆವೃತ್ತಿಯಾಗಿದೆ: ಇದು ಪುನರಾವರ್ತಕದ ಹಿಂಭಾಗದಿಂದ ಪ್ರಾರಂಭವಾಗುವ ಅಂಶಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    ///
    /// `rfold()` ಎರಡು ವಾದಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ: ಆರಂಭಿಕ ಮೌಲ್ಯ, ಮತ್ತು ಎರಡು ವಾದಗಳೊಂದಿಗೆ ಮುಚ್ಚುವಿಕೆ: 'accumulator', ಮತ್ತು ಒಂದು ಅಂಶ.
    /// ಮುಚ್ಚುವಿಕೆಯು ಮುಂದಿನ ಪುನರಾವರ್ತನೆಗಾಗಿ ಸಂಚಯಕವು ಹೊಂದಿರಬೇಕಾದ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಆರಂಭಿಕ ಮೌಲ್ಯವು ಸಂಚಯಕವು ಮೊದಲ ಕರೆಯಲ್ಲಿ ಹೊಂದಿರುವ ಮೌಲ್ಯವಾಗಿದೆ.
    ///
    /// ಪುನರಾವರ್ತಕದ ಪ್ರತಿಯೊಂದು ಅಂಶಕ್ಕೂ ಈ ಮುಚ್ಚುವಿಕೆಯನ್ನು ಅನ್ವಯಿಸಿದ ನಂತರ, `rfold()` ಸಂಚಯಕವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಕಾರ್ಯಾಚರಣೆಯನ್ನು ಕೆಲವೊಮ್ಮೆ 'reduce' ಅಥವಾ 'inject' ಎಂದು ಕರೆಯಲಾಗುತ್ತದೆ.
    ///
    /// ನೀವು ಏನಾದರೂ ಸಂಗ್ರಹವನ್ನು ಹೊಂದಿರುವಾಗ ಮಡಿಸುವಿಕೆಯು ಉಪಯುಕ್ತವಾಗಿದೆ ಮತ್ತು ಅದರಿಂದ ಒಂದೇ ಮೌಲ್ಯವನ್ನು ಉತ್ಪಾದಿಸಲು ಬಯಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // a ನ ಎಲ್ಲಾ ಅಂಶಗಳ ಮೊತ್ತ
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// ಈ ಉದಾಹರಣೆಯು ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ, ಇದು ಆರಂಭಿಕ ಮೌಲ್ಯದಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ ಮತ್ತು ಹಿಂಭಾಗದಿಂದ ಮುಂಭಾಗಕ್ಕೆ ಪ್ರತಿಯೊಂದು ಅಂಶದೊಂದಿಗೆ ಮುಂದುವರಿಯುತ್ತದೆ:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// ಹಿಂದಿನದನ್ನು ಪುನರಾವರ್ತಿಸುವ ಒಂದು ಅಂಶಕ್ಕಾಗಿ ಹುಡುಕಾಟಗಳು.
    ///
    /// `rfind()` `true` ಅಥವಾ `false` ಅನ್ನು ಹಿಂದಿರುಗಿಸುವ ಮುಚ್ಚುವಿಕೆಯನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    /// ಇದು ಪುನರಾವರ್ತನೆಯ ಪ್ರತಿಯೊಂದು ಅಂಶಕ್ಕೂ ಈ ಮುಚ್ಚುವಿಕೆಯನ್ನು ಅನ್ವಯಿಸುತ್ತದೆ, ಕೊನೆಯಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ, ಮತ್ತು ಅವುಗಳಲ್ಲಿ ಯಾವುದಾದರೂ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸಿದರೆ, `rfind()` [`Some(element)`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    /// ಅವರೆಲ್ಲರೂ `false` ಅನ್ನು ಹಿಂತಿರುಗಿಸಿದರೆ, ಅದು [`None`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `rfind()` ಶಾರ್ಟ್ ಸರ್ಕ್ಯೂಟಿಂಗ್ ಆಗಿದೆ;ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, ಮುಚ್ಚುವಿಕೆಯು `true` ಅನ್ನು ಹಿಂದಿರುಗಿಸಿದ ತಕ್ಷಣ ಅದು ಪ್ರಕ್ರಿಯೆಯನ್ನು ನಿಲ್ಲಿಸುತ್ತದೆ.
    ///
    /// ಏಕೆಂದರೆ `rfind()` ಒಂದು ಉಲ್ಲೇಖವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ, ಮತ್ತು ಅನೇಕ ಪುನರಾವರ್ತಕರು ಉಲ್ಲೇಖಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಿಸುತ್ತಾರೆ, ಇದು ಬಹುಶಃ ಗೊಂದಲಮಯ ಪರಿಸ್ಥಿತಿಗೆ ಕಾರಣವಾಗುತ್ತದೆ, ಅಲ್ಲಿ ವಾದವು ಎರಡು ಉಲ್ಲೇಖವಾಗಿರುತ್ತದೆ.
    ///
    /// `&&x` ನೊಂದಿಗೆ ಕೆಳಗಿನ ಉದಾಹರಣೆಗಳಲ್ಲಿ ನೀವು ಈ ಪರಿಣಾಮವನ್ನು ನೋಡಬಹುದು.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// ಮೊದಲ `true` ನಲ್ಲಿ ನಿಲ್ಲಿಸಲಾಗುತ್ತಿದೆ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // ಹೆಚ್ಚಿನ ಅಂಶಗಳು ಇರುವುದರಿಂದ ನಾವು ಇನ್ನೂ `iter` ಅನ್ನು ಬಳಸಬಹುದು.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}