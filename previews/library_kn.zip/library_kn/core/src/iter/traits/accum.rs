use crate::iter;
use crate::num::Wrapping;

/// ಪುನರಾವರ್ತಕವನ್ನು ಒಟ್ಟುಗೂಡಿಸುವ ಮೂಲಕ ರಚಿಸಬಹುದಾದ ಪ್ರಕಾರಗಳನ್ನು ಪ್ರತಿನಿಧಿಸಲು Trait.
///
/// ಈ trait ಅನ್ನು ಇಟರೇಟರ್‌ಗಳಲ್ಲಿ [`sum()`] ವಿಧಾನವನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ಬಳಸಲಾಗುತ್ತದೆ.
/// trait ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಪ್ರಕಾರಗಳನ್ನು [`sum()`] ವಿಧಾನದಿಂದ ಉತ್ಪಾದಿಸಬಹುದು.
/// [`FromIterator`] ನಂತೆ ಈ trait ಅನ್ನು ವಿರಳವಾಗಿ ನೇರವಾಗಿ ಕರೆಯಬೇಕು ಮತ್ತು ಬದಲಿಗೆ [`Iterator::sum()`] ಮೂಲಕ ಸಂವಹನ ನಡೆಸಬೇಕು.
///
///
/// [`sum()`]: Sum::sum
/// [`FromIterator`]: iter::FromIterator
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Sum<A = Self>: Sized {
    /// ಪುನರಾವರ್ತಕವನ್ನು ತೆಗೆದುಕೊಳ್ಳುವ ಮತ್ತು "summing up" ಅಂಶಗಳಿಂದ `Self` ಅನ್ನು ಅಂಶಗಳಿಂದ ಉತ್ಪಾದಿಸುವ ವಿಧಾನ.
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn sum<I: Iterator<Item = A>>(iter: I) -> Self;
}

/// ಪುನರಾವರ್ತಕದ ಅಂಶಗಳನ್ನು ಗುಣಿಸುವ ಮೂಲಕ ರಚಿಸಬಹುದಾದ ಪ್ರಕಾರಗಳನ್ನು ಪ್ರತಿನಿಧಿಸಲು Trait.
///
/// ಈ trait ಅನ್ನು ಇಟರೇಟರ್‌ಗಳಲ್ಲಿ [`product()`] ವಿಧಾನವನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ಬಳಸಲಾಗುತ್ತದೆ.
/// trait ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಪ್ರಕಾರಗಳನ್ನು [`product()`] ವಿಧಾನದಿಂದ ಉತ್ಪಾದಿಸಬಹುದು.
/// [`FromIterator`] ನಂತೆ ಈ trait ಅನ್ನು ವಿರಳವಾಗಿ ನೇರವಾಗಿ ಕರೆಯಬೇಕು ಮತ್ತು ಬದಲಿಗೆ [`Iterator::product()`] ಮೂಲಕ ಸಂವಹನ ನಡೆಸಬೇಕು.
///
///
/// [`product()`]: Product::product
/// [`FromIterator`]: iter::FromIterator
///
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Product<A = Self>: Sized {
    /// ಪುನರಾವರ್ತಕವನ್ನು ತೆಗೆದುಕೊಳ್ಳುವ ಮತ್ತು ವಸ್ತುಗಳನ್ನು ಗುಣಿಸುವ ಮೂಲಕ ಅಂಶಗಳಿಂದ `Self` ಅನ್ನು ಉತ್ಪಾದಿಸುವ ವಿಧಾನ.
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn product<I: Iterator<Item = A>>(iter: I) -> Self;
}

macro_rules! integer_sum_product {
    (@impls $zero:expr, $one:expr, #[$attr:meta], $($a:ty)*) => ($(
        #[$attr]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[$attr]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*);
    ($($a:ty)*) => (
        integer_sum_product!(@impls 0, 1,
                #[stable(feature = "iter_arith_traits", since = "1.12.0")],
                $($a)*);
        integer_sum_product!(@impls Wrapping(0), Wrapping(1),
                #[stable(feature = "wrapping_iter_arith", since = "1.14.0")],
                $(Wrapping<$a>)*);
    );
}

macro_rules! float_sum_product {
    ($($a:ident)*) => ($(
        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*)
}

integer_sum_product! { i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize }
float_sum_product! { f32 f64 }

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Sum<Result<U, E>> for Result<T, E>
where
    T: Sum<U>,
{
    /// [`Iterator`] ನಲ್ಲಿನ ಪ್ರತಿಯೊಂದು ಅಂಶವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ: ಇದು [`Err`] ಆಗಿದ್ದರೆ, ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳಲಾಗುವುದಿಲ್ಲ, ಮತ್ತು [`Err`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    /// ಯಾವುದೇ [`Err`] ಸಂಭವಿಸದಿದ್ದರೆ, ಎಲ್ಲಾ ಅಂಶಗಳ ಮೊತ್ತವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಇದು vector ನಲ್ಲಿನ ಪ್ರತಿ ಪೂರ್ಣಾಂಕವನ್ನು ಒಟ್ಟುಗೂಡಿಸುತ್ತದೆ, negative ಣಾತ್ಮಕ ಅಂಶ ಎದುರಾದರೆ ಮೊತ್ತವನ್ನು ತಿರಸ್ಕರಿಸುತ್ತದೆ:
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<i32, &'static str> = v.iter().map(|&x: &i32|
    ///     if x < 0 { Err("Negative element found") }
    ///     else { Ok(x) }
    /// ).sum();
    /// assert_eq!(res, Ok(3));
    /// ```
    ///
    ///
    fn sum<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.sum())
    }
}

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Product<Result<U, E>> for Result<T, E>
where
    T: Product<U>,
{
    /// [`Iterator`] ನಲ್ಲಿನ ಪ್ರತಿಯೊಂದು ಅಂಶವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ: ಇದು [`Err`] ಆಗಿದ್ದರೆ, ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳಲಾಗುವುದಿಲ್ಲ, ಮತ್ತು [`Err`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    /// ಯಾವುದೇ [`Err`] ಸಂಭವಿಸದಿದ್ದರೆ, ಎಲ್ಲಾ ಅಂಶಗಳ ಉತ್ಪನ್ನವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    fn product<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.product())
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Sum<Option<U>> for Option<T>
where
    T: Sum<U>,
{
    /// [`Iterator`] ನಲ್ಲಿನ ಪ್ರತಿಯೊಂದು ಅಂಶವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ: ಇದು [`None`] ಆಗಿದ್ದರೆ, ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳಲಾಗುವುದಿಲ್ಲ, ಮತ್ತು [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    /// ಯಾವುದೇ [`None`] ಸಂಭವಿಸದಿದ್ದರೆ, ಎಲ್ಲಾ ಅಂಶಗಳ ಮೊತ್ತವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಇದು vector ತಂತಿಗಳಲ್ಲಿ 'a' ಅಕ್ಷರದ ಸ್ಥಾನವನ್ನು ಒಟ್ಟುಗೂಡಿಸುತ್ತದೆ, ಒಂದು ಪದವು 'a' ಅಕ್ಷರವನ್ನು ಹೊಂದಿಲ್ಲದಿದ್ದರೆ ಕಾರ್ಯಾಚರಣೆಯು `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ:
    ///
    ///
    /// ```
    /// let words = vec!["have", "a", "great", "day"];
    /// let total: Option<usize> = words.iter().map(|w| w.find('a')).sum();
    /// assert_eq!(total, Some(5));
    /// ```
    ///
    fn sum<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).sum::<Result<_, _>>().ok()
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Product<Option<U>> for Option<T>
where
    T: Product<U>,
{
    /// [`Iterator`] ನಲ್ಲಿನ ಪ್ರತಿಯೊಂದು ಅಂಶವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ: ಇದು [`None`] ಆಗಿದ್ದರೆ, ಹೆಚ್ಚಿನ ಅಂಶಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳಲಾಗುವುದಿಲ್ಲ, ಮತ್ತು [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    /// ಯಾವುದೇ [`None`] ಸಂಭವಿಸದಿದ್ದರೆ, ಎಲ್ಲಾ ಅಂಶಗಳ ಉತ್ಪನ್ನವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    fn product<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).product::<Result<_, _>>().ok()
    }
}