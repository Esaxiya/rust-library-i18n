//! ಸೋಮಾರಿಯಾದ ಮೌಲ್ಯಗಳು ಮತ್ತು ಸ್ಥಿರ ಡೇಟಾದ ಒಂದು-ಬಾರಿ ಪ್ರಾರಂಭ.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// ಒಂದು ಕೋಶವನ್ನು ಒಮ್ಮೆ ಮಾತ್ರ ಬರೆಯಬಹುದು.
///
/// `RefCell` ಗಿಂತ ಭಿನ್ನವಾಗಿ, `OnceCell` ಅದರ ಮೌಲ್ಯಕ್ಕೆ ಹಂಚಿದ `&T` ಉಲ್ಲೇಖಗಳನ್ನು ಮಾತ್ರ ಒದಗಿಸುತ್ತದೆ.
/// `Cell` ಗಿಂತ ಭಿನ್ನವಾಗಿ, `OnceCell` ಗೆ ಅದನ್ನು ಪ್ರವೇಶಿಸಲು ಮೌಲ್ಯವನ್ನು ನಕಲಿಸುವ ಅಥವಾ ಬದಲಿಸುವ ಅಗತ್ಯವಿಲ್ಲ.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // ಅಸ್ಥಿರ: ಒಮ್ಮೆಗೆ ಬರೆಯಲಾಗಿದೆ.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// ಹೊಸ ಖಾಲಿ ಕೋಶವನ್ನು ರಚಿಸುತ್ತದೆ.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// ಆಧಾರವಾಗಿರುವ ಮೌಲ್ಯಕ್ಕೆ ಉಲ್ಲೇಖವನ್ನು ಪಡೆಯುತ್ತದೆ.
    ///
    /// ಸೆಲ್ ಖಾಲಿಯಾಗಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // ಸುರಕ್ಷತೆ: `ಆಂತರಿಕ` ಬದಲಾವಣೆಯಿಂದಾಗಿ ಸುರಕ್ಷಿತ
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// ಆಧಾರವಾಗಿರುವ ಮೌಲ್ಯಕ್ಕೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಪಡೆಯುತ್ತದೆ.
    ///
    /// ಸೆಲ್ ಖಾಲಿಯಾಗಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // ಸುರಕ್ಷತೆ: ಸುರಕ್ಷಿತ ಏಕೆಂದರೆ ನಮಗೆ ಅನನ್ಯ ಪ್ರವೇಶವಿದೆ
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// ಕೋಶದ ವಿಷಯಗಳನ್ನು `value` ಗೆ ಹೊಂದಿಸುತ್ತದೆ.
    ///
    /// # Errors
    ///
    /// ಕೋಶ ಖಾಲಿಯಾಗಿದ್ದರೆ ಈ ವಿಧಾನವು `Ok(())` ಮತ್ತು ಅದು ತುಂಬಿದ್ದರೆ `Err(value)` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // ಸುರಕ್ಷತೆ: ಸುರಕ್ಷಿತ ಏಕೆಂದರೆ ನಾವು ಅತಿಕ್ರಮಿಸುವ ರೂಪಾಂತರಿತ ಸಾಲಗಳನ್ನು ಹೊಂದಲು ಸಾಧ್ಯವಿಲ್ಲ
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // ಸುರಕ್ಷತೆ: ನಾವು ಸ್ಲಾಟ್ ಅನ್ನು ಹೊಂದಿಸಿದ ಏಕೈಕ ಸ್ಥಳ ಇದು, ಯಾವುದೇ ಜನಾಂಗಗಳಿಲ್ಲ
        // reentrancy/concurrency ಕಾರಣದಿಂದಾಗಿ ಸಾಧ್ಯವಿದೆ, ಮತ್ತು ಸ್ಲಾಟ್ ಪ್ರಸ್ತುತ `None` ಎಂದು ನಾವು ಪರಿಶೀಲಿಸಿದ್ದೇವೆ, ಆದ್ದರಿಂದ ಈ ಬರಹವು `ಆಂತರಿಕ` ಅಸ್ಥಿರತೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// ಕೋಶದ ವಿಷಯಗಳನ್ನು ಪಡೆಯುತ್ತದೆ, ಕೋಶವು ಖಾಲಿಯಾಗಿದ್ದರೆ ಅದನ್ನು `f` ನೊಂದಿಗೆ ಪ್ರಾರಂಭಿಸುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// `f` panics ಆಗಿದ್ದರೆ, panic ಅನ್ನು ಕರೆ ಮಾಡುವವರಿಗೆ ಪ್ರಸಾರ ಮಾಡಲಾಗುತ್ತದೆ, ಮತ್ತು ಕೋಶವು ಪ್ರಾರಂಭವಾಗದೆ ಉಳಿಯುತ್ತದೆ.
    ///
    ///
    /// `f` ನಿಂದ ಕೋಶವನ್ನು ಪುನಃ ಪ್ರಾರಂಭಿಸುವುದು ದೋಷ.ಹಾಗೆ ಮಾಡುವುದರಿಂದ panic ಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// ಕೋಶದ ವಿಷಯಗಳನ್ನು ಪಡೆಯುತ್ತದೆ, ಕೋಶವು ಖಾಲಿಯಾಗಿದ್ದರೆ ಅದನ್ನು `f` ನೊಂದಿಗೆ ಪ್ರಾರಂಭಿಸುತ್ತದೆ.
    /// ಸೆಲ್ ಖಾಲಿಯಾಗಿದ್ದರೆ ಮತ್ತು `f` ವಿಫಲವಾದರೆ, ದೋಷವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// `f` panics ಆಗಿದ್ದರೆ, panic ಅನ್ನು ಕರೆ ಮಾಡುವವರಿಗೆ ಪ್ರಸಾರ ಮಾಡಲಾಗುತ್ತದೆ, ಮತ್ತು ಕೋಶವು ಪ್ರಾರಂಭವಾಗದೆ ಉಳಿಯುತ್ತದೆ.
    ///
    ///
    /// `f` ನಿಂದ ಕೋಶವನ್ನು ಪುನಃ ಪ್ರಾರಂಭಿಸುವುದು ದೋಷ.ಹಾಗೆ ಮಾಡುವುದರಿಂದ panic ಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // *ಕೆಲವು* ಪುನರಾವರ್ತಿತ ಪ್ರಾರಂಭವು ಯುಬಿಗೆ ಕಾರಣವಾಗಬಹುದು ಎಂಬುದನ್ನು ಗಮನಿಸಿ (`reentrant_init` ಪರೀಕ್ಷೆ ನೋಡಿ).
        // `set/get` ಅನ್ನು ಉಳಿಸಿಕೊಳ್ಳುವಾಗ ಈ `assert` ಅನ್ನು ತೆಗೆದುಹಾಕುವುದು ಉತ್ತಮ ಎಂದು ನಾನು ನಂಬುತ್ತೇನೆ, ಆದರೆ ಹಳೆಯ ಮೌಲ್ಯವನ್ನು ಮೌನವಾಗಿ ಬಳಸುವುದಕ್ಕಿಂತ ಹೆಚ್ಚಾಗಿ panic ಗೆ ಇದು ಉತ್ತಮವಾಗಿದೆ.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// ಸುತ್ತಿದ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುವ ಮೂಲಕ ಕೋಶವನ್ನು ಬಳಸುತ್ತದೆ.
    ///
    /// ಸೆಲ್ ಖಾಲಿಯಾಗಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // `into_inner` `self` ಅನ್ನು ಮೌಲ್ಯದಿಂದ ತೆಗೆದುಕೊಳ್ಳುವುದರಿಂದ, ಕಂಪೈಲರ್ ಅದನ್ನು ಪ್ರಸ್ತುತ ಎರವಲು ಪಡೆದಿಲ್ಲ ಎಂದು ಸ್ಥಿರವಾಗಿ ಪರಿಶೀಲಿಸುತ್ತದೆ.
        // ಆದ್ದರಿಂದ `Option<T>` ಅನ್ನು ಹೊರಹಾಕುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ.
        self.inner.into_inner()
    }

    /// ಈ `OnceCell` ನಿಂದ ಮೌಲ್ಯವನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ, ಅದನ್ನು ಪ್ರಾರಂಭಿಸದ ಸ್ಥಿತಿಗೆ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಯಾವುದೇ ಪರಿಣಾಮ ಬೀರುವುದಿಲ್ಲ ಮತ್ತು `OnceCell` ಅನ್ನು ಪ್ರಾರಂಭಿಸದಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖದ ಅಗತ್ಯವಿರುವ ಮೂಲಕ ಸುರಕ್ಷತೆಯನ್ನು ಖಾತರಿಪಡಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// ಮೊದಲ ಪ್ರವೇಶದಲ್ಲಿ ಪ್ರಾರಂಭಿಸಲಾದ ಮೌಲ್ಯ.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   ಪ್ರಾರಂಭಿಸಲು ಸಿದ್ಧವಾಗಿದೆ
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// ಕೊಟ್ಟಿರುವ ಪ್ರಾರಂಭಿಕ ಕ್ರಿಯೆಯೊಂದಿಗೆ ಹೊಸ ಸೋಮಾರಿಯಾದ ಮೌಲ್ಯವನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// ಈ ಸೋಮಾರಿಯಾದ ಮೌಲ್ಯದ ಮೌಲ್ಯಮಾಪನವನ್ನು ಒತ್ತಾಯಿಸುತ್ತದೆ ಮತ್ತು ಫಲಿತಾಂಶಕ್ಕೆ ಉಲ್ಲೇಖವನ್ನು ನೀಡುತ್ತದೆ.
    ///
    ///
    /// ಇದು `Deref` impl ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ, ಆದರೆ ಇದು ಸ್ಪಷ್ಟವಾಗಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// ಪ್ರಾರಂಭಿಸುವ ಕಾರ್ಯವಾಗಿ `Default` ಬಳಸಿ ಹೊಸ ಸೋಮಾರಿಯಾದ ಮೌಲ್ಯವನ್ನು ರಚಿಸುತ್ತದೆ.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}