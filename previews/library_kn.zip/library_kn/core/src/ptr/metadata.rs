#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// ಯಾವುದೇ ಪಾಯಿಂಟ್-ಟು ಪ್ರಕಾರದ ಪಾಯಿಂಟರ್ ಮೆಟಾಡೇಟಾ ಪ್ರಕಾರವನ್ನು ಒದಗಿಸುತ್ತದೆ.
///
/// # ಪಾಯಿಂಟರ್ ಮೆಟಾಡೇಟಾ
///
/// Rust ನಲ್ಲಿ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಪ್ರಕಾರಗಳು ಮತ್ತು ಉಲ್ಲೇಖ ಪ್ರಕಾರಗಳನ್ನು ಎರಡು ಭಾಗಗಳಿಂದ ಮಾಡಲಾಗಿದೆಯೆಂದು ಭಾವಿಸಬಹುದು:
/// ಮೌಲ್ಯದ ಮೆಮೊರಿ ವಿಳಾಸ ಮತ್ತು ಕೆಲವು ಮೆಟಾಡೇಟಾವನ್ನು ಒಳಗೊಂಡಿರುವ ಡೇಟಾ ಪಾಯಿಂಟರ್.
///
/// ಸ್ಥಾಯೀ-ಗಾತ್ರದ ಪ್ರಕಾರಗಳಿಗೆ (ಅದು `Sized` traits ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ) ಮತ್ತು `extern` ಪ್ರಕಾರಗಳಿಗೆ, ಪಾಯಿಂಟರ್‌ಗಳನ್ನು `ತೆಳುವಾದ` ಎಂದು ಹೇಳಲಾಗುತ್ತದೆ: ಮೆಟಾಡೇಟಾ ಶೂನ್ಯ-ಗಾತ್ರ ಮತ್ತು ಅದರ ಪ್ರಕಾರವು `()` ಆಗಿದೆ.
///
///
/// [dynamically-sized types][dst] ಗೆ ಪಾಯಿಂಟರ್‌ಗಳು `ಅಗಲ` ಅಥವಾ `ಕೊಬ್ಬು` ಎಂದು ಹೇಳಲಾಗುತ್ತದೆ, ಅವು ಶೂನ್ಯ-ಗಾತ್ರದ ಮೆಟಾಡೇಟಾವನ್ನು ಹೊಂದಿವೆ:
///
/// * ಕೊನೆಯ ಕ್ಷೇತ್ರವು ಡಿಎಸ್ಟಿ ಆಗಿರುವ ಸ್ಟ್ರಕ್ಟ್‌ಗಳಿಗೆ, ಮೆಟಾಡೇಟಾ ಕೊನೆಯ ಕ್ಷೇತ್ರಕ್ಕೆ ಮೆಟಾಡೇಟಾ ಆಗಿದೆ
/// * `str` ಪ್ರಕಾರಕ್ಕಾಗಿ, ಮೆಟಾಡೇಟಾವು ಬೈಟ್‌ಗಳಲ್ಲಿ `usize` ನ ಉದ್ದವಾಗಿದೆ
/// * `[T]` ನಂತಹ ಸ್ಲೈಸ್ ಪ್ರಕಾರಗಳಿಗೆ, ಮೆಟಾಡೇಟಾ ಎಂಬುದು `usize` ನಂತಹ ಐಟಂಗಳ ಉದ್ದವಾಗಿದೆ
/// * `dyn SomeTrait` ನಂತಹ trait ವಸ್ತುಗಳಿಗೆ, ಮೆಟಾಡೇಟಾ [`DynMetadata<Self>`][DynMetadata] (ಉದಾ. `DynMetadata<dyn SomeTrait>`)
///
/// future ನಲ್ಲಿ, Rust ಭಾಷೆ ವಿಭಿನ್ನ ರೀತಿಯ ಪಾಯಿಂಟರ್ ಮೆಟಾಡೇಟಾವನ್ನು ಹೊಂದಿರುವ ಹೊಸ ಪ್ರಕಾರಗಳನ್ನು ಪಡೆಯಬಹುದು.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// ಈ trait ನ ಬಿಂದುವು ಅದರ `Metadata` ಸಂಬಂಧಿತ ಪ್ರಕಾರವಾಗಿದೆ, ಇದು ಮೇಲೆ ವಿವರಿಸಿದಂತೆ `()` ಅಥವಾ `usize` ಅಥವಾ `DynMetadata<_>` ಆಗಿದೆ.
/// ಇದು ಪ್ರತಿಯೊಂದು ಪ್ರಕಾರಕ್ಕೂ ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಕಾರ್ಯಗತಗೊಳ್ಳುತ್ತದೆ.
/// ಅನುಗುಣವಾದ ಪರಿಮಿತಿಯಿಲ್ಲದಿದ್ದರೂ ಸಹ, ಇದನ್ನು ಸಾಮಾನ್ಯ ಸನ್ನಿವೇಶದಲ್ಲಿ ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು ಎಂದು can ಹಿಸಬಹುದು.
///
/// # Usage
///
/// ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಅವುಗಳ [`to_raw_parts`] ವಿಧಾನದೊಂದಿಗೆ ಡೇಟಾ ವಿಳಾಸ ಮತ್ತು ಮೆಟಾಡೇಟಾ ಘಟಕಗಳಾಗಿ ವಿಭಜಿಸಬಹುದು.
///
/// ಪರ್ಯಾಯವಾಗಿ, ಮೆಟಾಡೇಟಾವನ್ನು ಮಾತ್ರ [`metadata`] ಕ್ರಿಯೆಯೊಂದಿಗೆ ಹೊರತೆಗೆಯಬಹುದು.
/// ಉಲ್ಲೇಖವನ್ನು [`metadata`] ಗೆ ರವಾನಿಸಬಹುದು ಮತ್ತು ಸೂಚ್ಯವಾಗಿ ಒತ್ತಾಯಿಸಬಹುದು.
///
/// (possibly-wide) ಪಾಯಿಂಟರ್ ಅನ್ನು ಅದರ ವಿಳಾಸ ಮತ್ತು ಮೆಟಾಡೇಟಾದಿಂದ [`from_raw_parts`] ಅಥವಾ [`from_raw_parts_mut`] ನೊಂದಿಗೆ ಮತ್ತೆ ಸೇರಿಸಬಹುದು.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// ಪಾಯಿಂಟರ್‌ಗಳಲ್ಲಿನ ಮೆಟಾಡೇಟಾ ಮತ್ತು `Self` ಗೆ ಉಲ್ಲೇಖಗಳು.
    #[lang = "metadata_type"]
    // NOTE: `static_assert_expected_bounds_for_metadata` ನಲ್ಲಿ trait bounds ಅನ್ನು ಇರಿಸಿ
    //
    // `library/core/src/ptr/metadata.rs` ನಲ್ಲಿ ಇಲ್ಲಿರುವವರೊಂದಿಗೆ ಸಿಂಕ್ ಮಾಡಲಾಗಿದೆ:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// ಈ trait ಅಲಿಯಾಸ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಪ್ರಕಾರಗಳ ಪಾಯಿಂಟರ್‌ಗಳು `ತೆಳುವಾದವು`.
///
/// ಇದು ಸ್ಥಾಯೀ-`ಗಾತ್ರದ` ಪ್ರಕಾರಗಳು ಮತ್ತು `extern` ಪ್ರಕಾರಗಳನ್ನು ಒಳಗೊಂಡಿದೆ.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: trait ಅಲಿಯಾಸ್‌ಗಳು ಭಾಷೆಯಲ್ಲಿ ಸ್ಥಿರವಾಗುವ ಮೊದಲು ಇದನ್ನು ಸ್ಥಿರಗೊಳಿಸಬೇಡಿ?
pub trait Thin = Pointee<Metadata = ()>;

/// ಪಾಯಿಂಟರ್‌ನ ಮೆಟಾಡೇಟಾ ಘಟಕವನ್ನು ಹೊರತೆಗೆಯಿರಿ.
///
/// `*mut T`, `&T`, ಅಥವಾ `&mut T` ಪ್ರಕಾರದ ಮೌಲ್ಯಗಳನ್ನು ಈ ಕಾರ್ಯಕ್ಕೆ ನೇರವಾಗಿ ರವಾನಿಸಬಹುದು ಏಕೆಂದರೆ ಅವುಗಳು `* const T` ಗೆ ಸೂಚ್ಯವಾಗಿ ಒತ್ತಾಯಿಸುತ್ತವೆ.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // ಸುರಕ್ಷತೆ: * const T ರಿಂದ `PtrRepr` ಯೂನಿಯನ್‌ನಿಂದ ಮೌಲ್ಯವನ್ನು ಪ್ರವೇಶಿಸುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ
    // ಮತ್ತು PtrComponents<T>ಒಂದೇ ಮೆಮೊರಿ ವಿನ್ಯಾಸಗಳನ್ನು ಹೊಂದಿವೆ.
    // std ಮಾತ್ರ ಈ ಖಾತರಿಯನ್ನು ನೀಡುತ್ತದೆ.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// ಡೇಟಾ ವಿಳಾಸ ಮತ್ತು ಮೆಟಾಡೇಟಾದಿಂದ (possibly-wide) ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಅನ್ನು ರೂಪಿಸುತ್ತದೆ.
///
/// ಈ ಕಾರ್ಯವು ಸುರಕ್ಷಿತವಾಗಿದೆ ಆದರೆ ಹಿಂತಿರುಗಿದ ಪಾಯಿಂಟರ್ ಅಪನಗದೀಕರಣಕ್ಕೆ ಸುರಕ್ಷಿತವಾಗಿರುವುದಿಲ್ಲ.
/// ಚೂರುಗಳಿಗಾಗಿ, ಸುರಕ್ಷತಾ ಅವಶ್ಯಕತೆಗಳಿಗಾಗಿ [`slice::from_raw_parts`] ನ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
/// trait ಆಬ್ಜೆಕ್ಟ್‌ಗಳಿಗಾಗಿ, ಮೆಟಾಡೇಟಾ ಪಾಯಿಂಟರ್‌ನಿಂದ ಅದೇ ಆಧಾರವಾಗಿರುವ ereased ಪ್ರಕಾರಕ್ಕೆ ಬರಬೇಕು.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // ಸುರಕ್ಷತೆ: * const T ರಿಂದ `PtrRepr` ಯೂನಿಯನ್‌ನಿಂದ ಮೌಲ್ಯವನ್ನು ಪ್ರವೇಶಿಸುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ
    // ಮತ್ತು PtrComponents<T>ಒಂದೇ ಮೆಮೊರಿ ವಿನ್ಯಾಸಗಳನ್ನು ಹೊಂದಿವೆ.
    // std ಮಾತ್ರ ಈ ಖಾತರಿಯನ್ನು ನೀಡುತ್ತದೆ.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// ಕಚ್ಚಾ `*const` ಪಾಯಿಂಟರ್‌ಗೆ ವಿರುದ್ಧವಾಗಿ ಕಚ್ಚಾ `* mut` ಪಾಯಿಂಟರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುವುದನ್ನು ಹೊರತುಪಡಿಸಿ, [`from_raw_parts`] ನಂತೆಯೇ ಅದೇ ಕಾರ್ಯವನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
///
///
/// ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ [`from_raw_parts`] ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // ಸುರಕ್ಷತೆ: * const T ರಿಂದ `PtrRepr` ಯೂನಿಯನ್‌ನಿಂದ ಮೌಲ್ಯವನ್ನು ಪ್ರವೇಶಿಸುವುದು ಸುರಕ್ಷಿತವಾಗಿದೆ
    // ಮತ್ತು PtrComponents<T>ಒಂದೇ ಮೆಮೊರಿ ವಿನ್ಯಾಸಗಳನ್ನು ಹೊಂದಿವೆ.
    // std ಮಾತ್ರ ಈ ಖಾತರಿಯನ್ನು ನೀಡುತ್ತದೆ.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// `T: Copy` ಬೌಂಡ್ ಅನ್ನು ತಪ್ಪಿಸಲು ಮ್ಯಾನುಯಲ್ ಇಂಪ್ಲ್ ಅಗತ್ಯವಿದೆ.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// `T: Clone` ಬೌಂಡ್ ಅನ್ನು ತಪ್ಪಿಸಲು ಮ್ಯಾನುಯಲ್ ಇಂಪ್ಲ್ ಅಗತ್ಯವಿದೆ.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait ಆಬ್ಜೆಕ್ಟ್ ಪ್ರಕಾರದ ಮೆಟಾಡೇಟಾ.
///
/// ಇದು Vtable (ವರ್ಚುವಲ್ ಕಾಲ್ ಟೇಬಲ್) ಗೆ ಪಾಯಿಂಟರ್ ಆಗಿದ್ದು ಅದು trait ವಸ್ತುವಿನೊಳಗೆ ಸಂಗ್ರಹವಾಗಿರುವ ಕಾಂಕ್ರೀಟ್ ಪ್ರಕಾರವನ್ನು ಕುಶಲತೆಯಿಂದ ನಿರ್ವಹಿಸಲು ಅಗತ್ಯವಿರುವ ಎಲ್ಲಾ ಮಾಹಿತಿಯನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
/// Vtable ಗಮನಾರ್ಹವಾಗಿ ಇದನ್ನು ಒಳಗೊಂಡಿದೆ:
///
/// * ಗಾತ್ರವನ್ನು ಟೈಪ್ ಮಾಡಿ
/// * ಟೈಪ್ ಜೋಡಣೆ
/// * ಪ್ರಕಾರದ `drop_in_place` impl ಗೆ ಪಾಯಿಂಟರ್ (ಸರಳ-ಹಳೆಯ-ಡೇಟಾಗೆ ಯಾವುದೇ ಆಯ್ಕೆ ಇಲ್ಲದಿರಬಹುದು)
/// * trait ಪ್ರಕಾರದ ಅನುಷ್ಠಾನಕ್ಕೆ ಎಲ್ಲಾ ವಿಧಾನಗಳಿಗೆ ಪಾಯಿಂಟರ್‌ಗಳು
///
/// ಯಾವುದೇ trait ಆಬ್ಜೆಕ್ಟ್ ಅನ್ನು ನಿಯೋಜಿಸಲು, ಬಿಡಲು ಮತ್ತು ಡಿಲೊಕೊಲೇಟ್ ಮಾಡಲು ಅಗತ್ಯವಿರುವ ಕಾರಣ ಮೊದಲ ಮೂರು ವಿಶೇಷವಾಗಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
///
/// ಈ ರಚನೆಯನ್ನು `dyn` trait ಆಬ್ಜೆಕ್ಟ್ ಅಲ್ಲದ (ಉದಾಹರಣೆಗೆ `DynMetadata<u64>`) ಒಂದು ರೀತಿಯ ನಿಯತಾಂಕದೊಂದಿಗೆ ಹೆಸರಿಸಲು ಸಾಧ್ಯವಿದೆ ಆದರೆ ಆ ರಚನೆಯ ಅರ್ಥಪೂರ್ಣ ಮೌಲ್ಯವನ್ನು ಪಡೆಯುವುದಿಲ್ಲ.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// ಎಲ್ಲಾ vtables ನ ಸಾಮಾನ್ಯ ಪೂರ್ವಪ್ರತ್ಯಯ.ಇದನ್ನು trait ವಿಧಾನಗಳಿಗಾಗಿ ಫಂಕ್ಷನ್ ಪಾಯಿಂಟರ್‌ಗಳು ಅನುಸರಿಸುತ್ತವೆ.
///
/// `DynMetadata::size_of` ಇತ್ಯಾದಿಗಳ ಖಾಸಗಿ ಅನುಷ್ಠಾನ ವಿವರ.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// ಈ vtable ಗೆ ಸಂಬಂಧಿಸಿದ ಪ್ರಕಾರದ ಗಾತ್ರವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// ಈ vtable ಗೆ ಸಂಬಂಧಿಸಿದ ಪ್ರಕಾರದ ಜೋಡಣೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// ಗಾತ್ರ ಮತ್ತು ಜೋಡಣೆಯನ್ನು ಒಟ್ಟಿಗೆ `Layout` ಆಗಿ ಹಿಂತಿರುಗಿಸುತ್ತದೆ
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // ಸುರಕ್ಷತೆ: ಕಾಂಕ್ರೀಟ್ Rust ಪ್ರಕಾರಕ್ಕಾಗಿ ಕಂಪೈಲರ್ ಈ vtable ಅನ್ನು ಹೊರಸೂಸುತ್ತದೆ
        // ಮಾನ್ಯ ವಿನ್ಯಾಸವನ್ನು ಹೊಂದಿದೆ ಎಂದು ತಿಳಿದುಬಂದಿದೆ.`Layout::for_value` ನಂತೆಯೇ ಅದೇ ತಾರ್ಕಿಕತೆ.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// `Dyn: $Trait` ಗಡಿಗಳನ್ನು ತಪ್ಪಿಸಲು ಹಸ್ತಚಾಲಿತ ಇಂಪ್ಲ್ಸ್ ಅಗತ್ಯವಿದೆ.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}