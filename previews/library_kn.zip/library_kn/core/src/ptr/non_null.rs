use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` ಆದರೆ ಶೂನ್ಯೇತರ ಮತ್ತು ಕೋವಿಯಂಟ್.
///
/// ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಬಳಸಿಕೊಂಡು ಡೇಟಾ ರಚನೆಗಳನ್ನು ನಿರ್ಮಿಸುವಾಗ ಇದು ಸಾಮಾನ್ಯವಾಗಿ ಬಳಸಬೇಕಾದ ಸರಿಯಾದ ವಿಷಯವಾಗಿದೆ, ಆದರೆ ಅಂತಿಮವಾಗಿ ಅದರ ಹೆಚ್ಚುವರಿ ಗುಣಲಕ್ಷಣಗಳಿಂದಾಗಿ ಬಳಸಲು ಹೆಚ್ಚು ಅಪಾಯಕಾರಿ.ನೀವು `NonNull<T>` ಅನ್ನು ಬಳಸಬೇಕೆ ಎಂದು ನಿಮಗೆ ಖಚಿತವಿಲ್ಲದಿದ್ದರೆ, `*mut T` ಅನ್ನು ಬಳಸಿ!
///
/// `*mut T` ಗಿಂತ ಭಿನ್ನವಾಗಿ, ಪಾಯಿಂಟರ್ ಎಂದಿಗೂ ಡಿಫರೆನ್ಸ್ ಮಾಡದಿದ್ದರೂ ಸಹ, ಪಾಯಿಂಟರ್ ಯಾವಾಗಲೂ ಶೂನ್ಯವಾಗಿರಬಾರದು.ಎನ್ಯುಮ್ಗಳು ಈ ನಿಷೇಧಿತ ಮೌಲ್ಯವನ್ನು ತಾರತಮ್ಯವಾಗಿ ಬಳಸಬಹುದು-`Option<NonNull<T>>` `* mut T` ನಂತೆಯೇ ಗಾತ್ರವನ್ನು ಹೊಂದಿರುತ್ತದೆ.
/// ಆದಾಗ್ಯೂ, ಪಾಯಿಂಟರ್ ಡಿಫರೆನ್ಸ್ ಮಾಡದಿದ್ದರೆ ಇನ್ನೂ ತೂಗಾಡಬಹುದು.
///
/// `*mut T` ಗಿಂತ ಭಿನ್ನವಾಗಿ, `NonNull<T>` ಅನ್ನು `T` ಗಿಂತ ಸಹವರ್ತಿ ಎಂದು ಆಯ್ಕೆ ಮಾಡಲಾಗಿದೆ.ಕೋವಿಯಂಟ್ ಪ್ರಕಾರಗಳನ್ನು ನಿರ್ಮಿಸುವಾಗ ಇದು `NonNull<T>` ಅನ್ನು ಬಳಸಲು ಸಾಧ್ಯವಾಗಿಸುತ್ತದೆ, ಆದರೆ ಒಂದು ಪ್ರಕಾರದಲ್ಲಿ ಬಳಸಿದರೆ ಅಸ್ಪಷ್ಟತೆಯ ಅಪಾಯವನ್ನು ಪರಿಚಯಿಸುತ್ತದೆ.
/// (ಅಸುರಕ್ಷಿತ ಕಾರ್ಯಗಳನ್ನು ಕರೆಯುವುದರಿಂದ ಮಾತ್ರ ತಾಂತ್ರಿಕವಾಗಿ ಅಸ್ಪಷ್ಟತೆ ಉಂಟಾಗಬಹುದಾದರೂ `*mut T` ಗೆ ವಿರುದ್ಧವಾದ ಆಯ್ಕೆಯನ್ನು ಮಾಡಲಾಗಿದೆ.)
///
/// `Box`, `Rc`, `Arc`, `Vec`, ಮತ್ತು `LinkedList` ನಂತಹ ಹೆಚ್ಚಿನ ಸುರಕ್ಷಿತ ಅಮೂರ್ತತೆಗಳಿಗೆ ಕೋವಿಯೇರಿಯನ್ಸ್ ಸರಿಯಾಗಿದೆ.Rust ನ ಸಾಮಾನ್ಯ ಹಂಚಿಕೆಯ XOR ರೂಪಾಂತರಿತ ನಿಯಮಗಳನ್ನು ಅನುಸರಿಸುವ ಸಾರ್ವಜನಿಕ API ಅನ್ನು ಅವರು ಒದಗಿಸುತ್ತಾರೆ.
///
/// ನಿಮ್ಮ ಪ್ರಕಾರವು ಸುರಕ್ಷಿತವಾಗಿ ಕೋವಿಯೇರಿಯಂಟ್ ಆಗಲು ಸಾಧ್ಯವಾಗದಿದ್ದರೆ, ಅಸ್ಥಿರತೆಯನ್ನು ಒದಗಿಸಲು ಇದು ಕೆಲವು ಹೆಚ್ಚುವರಿ ಕ್ಷೇತ್ರವನ್ನು ಹೊಂದಿದೆ ಎಂದು ನೀವು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು.ಸಾಮಾನ್ಯವಾಗಿ ಈ ಕ್ಷೇತ್ರವು `PhantomData<Cell<T>>` ಅಥವಾ `PhantomData<&'a mut T>` ನಂತಹ [`PhantomData`] ಪ್ರಕಾರವಾಗಿರುತ್ತದೆ.
///
/// X002 ಗಾಗಿ `NonNull<T>` ಗೆ `From` ನಿದರ್ಶನವಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.ಆದಾಗ್ಯೂ, [`UnsafeCell<T>`] ಒಳಗೆ ರೂಪಾಂತರವು ಸಂಭವಿಸದ ಹೊರತು (a ನಿಂದ ಪಡೆದ ಪಾಯಿಂಟರ್) ಹಂಚಿಕೆಯ ಉಲ್ಲೇಖದ ಮೂಲಕ ರೂಪಾಂತರಗೊಳ್ಳುವುದು ವಿವರಿಸಲಾಗದ ನಡವಳಿಕೆಯಾಗಿದೆ ಎಂಬ ಅಂಶವನ್ನು ಇದು ಬದಲಾಯಿಸುವುದಿಲ್ಲ.ಹಂಚಿದ ಉಲ್ಲೇಖದಿಂದ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ರಚಿಸಲು ಅದೇ ಹೋಗುತ್ತದೆ.
///
/// `UnsafeCell<T>` ಇಲ್ಲದೆ ಈ `From` ನಿದರ್ಶನವನ್ನು ಬಳಸುವಾಗ, `as_mut` ಅನ್ನು ಎಂದಿಗೂ ಕರೆಯಲಾಗುವುದಿಲ್ಲ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳುವುದು ನಿಮ್ಮ ಜವಾಬ್ದಾರಿಯಾಗಿದೆ, ಮತ್ತು `as_ptr` ಅನ್ನು ರೂಪಾಂತರಕ್ಕಾಗಿ ಎಂದಿಗೂ ಬಳಸಲಾಗುವುದಿಲ್ಲ.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` ಪಾಯಿಂಟರ್‌ಗಳು `Send` ಅಲ್ಲ ಏಕೆಂದರೆ ಅವು ಉಲ್ಲೇಖಿಸುವ ಡೇಟಾವನ್ನು ಅಲಿಯಾಸ್ ಮಾಡಬಹುದು.
// NB, ಈ impl ಅನಗತ್ಯ, ಆದರೆ ಉತ್ತಮ ದೋಷ ಸಂದೇಶಗಳನ್ನು ಒದಗಿಸಬೇಕು.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` ಪಾಯಿಂಟರ್‌ಗಳು `Sync` ಅಲ್ಲ ಏಕೆಂದರೆ ಅವು ಉಲ್ಲೇಖಿಸುವ ಡೇಟಾವನ್ನು ಅಲಿಯಾಸ್ ಮಾಡಬಹುದು.
// NB, ಈ impl ಅನಗತ್ಯ, ಆದರೆ ಉತ್ತಮ ದೋಷ ಸಂದೇಶಗಳನ್ನು ಒದಗಿಸಬೇಕು.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// ಹೊಸ `NonNull` ಅನ್ನು ರಚಿಸುತ್ತದೆ ಅದು ತೂಗಾಡುತ್ತಿರುವ, ಆದರೆ ಉತ್ತಮವಾಗಿ ಹೊಂದಿಕೊಳ್ಳುತ್ತದೆ.
    ///
    /// `Vec::new` ನಂತೆ ಸೋಮಾರಿಯಾಗಿ ಹಂಚುವ ಪ್ರಕಾರಗಳನ್ನು ಪ್ರಾರಂಭಿಸಲು ಇದು ಉಪಯುಕ್ತವಾಗಿದೆ.
    ///
    /// ಪಾಯಿಂಟರ್ ಮೌಲ್ಯವು `T` ಗೆ ಮಾನ್ಯ ಪಾಯಿಂಟರ್ ಅನ್ನು ಸಂಭಾವ್ಯವಾಗಿ ಪ್ರತಿನಿಧಿಸಬಹುದು ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಇದರರ್ಥ ಇದನ್ನು "not yet initialized" ಸೆಂಟಿನೆಲ್ ಮೌಲ್ಯವಾಗಿ ಬಳಸಬಾರದು.
    /// ಸೋಮಾರಿಯಾಗಿ ಹಂಚುವ ಪ್ರಕಾರಗಳು ಇತರ ವಿಧಾನಗಳಿಂದ ಪ್ರಾರಂಭವನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಬೇಕು.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // ಸುರಕ್ಷತೆ: mem::align_of() ಶೂನ್ಯೇತರ ಬಳಕೆಯನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ನಂತರ ಅದನ್ನು ಬಿತ್ತರಿಸಲಾಗುತ್ತದೆ
        // ಗೆ * ಮಟ್ ಟಿ.
        // ಆದ್ದರಿಂದ, `ptr` ಶೂನ್ಯವಾಗಿಲ್ಲ ಮತ್ತು new_unchecked() ಗೆ ಕರೆ ಮಾಡುವ ಷರತ್ತುಗಳನ್ನು ಗೌರವಿಸಲಾಗುತ್ತದೆ.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// ಮೌಲ್ಯಕ್ಕೆ ಹಂಚಿದ ಉಲ್ಲೇಖಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.[`as_ref`] ಗೆ ವ್ಯತಿರಿಕ್ತವಾಗಿ, ಮೌಲ್ಯವನ್ನು ಪ್ರಾರಂಭಿಸಬೇಕಾಗಿಲ್ಲ.
    ///
    /// ರೂಪಾಂತರಿತ ಪ್ರತಿರೂಪಕ್ಕಾಗಿ [`as_uninit_mut`] ನೋಡಿ.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// ಈ ವಿಧಾನವನ್ನು ಕರೆಯುವಾಗ, ಈ ಕೆಳಗಿನವುಗಳೆಲ್ಲವೂ ನಿಜವೆಂದು ನೀವು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು:
    ///
    /// * ಪಾಯಿಂಟರ್ ಅನ್ನು ಸರಿಯಾಗಿ ಜೋಡಿಸಬೇಕು.
    ///
    /// * ಇದು [the module documentation] ನಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ಅರ್ಥದಲ್ಲಿ "dereferencable" ಆಗಿರಬೇಕು.
    ///
    /// * ನೀವು Rust ನ ಅಲಿಯಾಸಿಂಗ್ ನಿಯಮಗಳನ್ನು ಜಾರಿಗೊಳಿಸಬೇಕು, ಏಕೆಂದರೆ ಹಿಂದಿರುಗಿದ ಜೀವಿತಾವಧಿಯ `'a` ಅನ್ನು ಅನಿಯಂತ್ರಿತವಾಗಿ ಆಯ್ಕೆಮಾಡಲಾಗುತ್ತದೆ ಮತ್ತು ಇದು ಡೇಟಾದ ನಿಜವಾದ ಜೀವಿತಾವಧಿಯನ್ನು ಪ್ರತಿಬಿಂಬಿಸುವುದಿಲ್ಲ.
    ///
    ///   ನಿರ್ದಿಷ್ಟವಾಗಿ ಹೇಳುವುದಾದರೆ, ಈ ಜೀವಿತಾವಧಿಯ ಅವಧಿಗೆ, ಪಾಯಿಂಟರ್ ಸೂಚಿಸುವ ಮೆಮೊರಿ ರೂಪಾಂತರಗೊಳ್ಳಬಾರದು (`UnsafeCell` ಒಳಗೆ ಹೊರತುಪಡಿಸಿ).
    ///
    /// ಈ ವಿಧಾನದ ಫಲಿತಾಂಶವು ಬಳಕೆಯಾಗದಿದ್ದರೂ ಸಹ ಇದು ಅನ್ವಯಿಸುತ್ತದೆ!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `self` ಎಲ್ಲವನ್ನು ಪೂರೈಸುತ್ತಾರೆ ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು
        // ಉಲ್ಲೇಖದ ಅವಶ್ಯಕತೆಗಳು.
        unsafe { &*self.cast().as_ptr() }
    }

    /// ಮೌಲ್ಯಕ್ಕೆ ಅನನ್ಯ ಉಲ್ಲೇಖಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.[`as_mut`] ಗೆ ವ್ಯತಿರಿಕ್ತವಾಗಿ, ಮೌಲ್ಯವನ್ನು ಪ್ರಾರಂಭಿಸಬೇಕಾಗಿಲ್ಲ.
    ///
    /// ಹಂಚಿದ ಪ್ರತಿರೂಪಕ್ಕಾಗಿ [`as_uninit_ref`] ನೋಡಿ.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// ಈ ವಿಧಾನವನ್ನು ಕರೆಯುವಾಗ, ಈ ಕೆಳಗಿನವುಗಳೆಲ್ಲವೂ ನಿಜವೆಂದು ನೀವು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು:
    ///
    /// * ಪಾಯಿಂಟರ್ ಅನ್ನು ಸರಿಯಾಗಿ ಜೋಡಿಸಬೇಕು.
    ///
    /// * ಇದು [the module documentation] ನಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ಅರ್ಥದಲ್ಲಿ "dereferencable" ಆಗಿರಬೇಕು.
    ///
    /// * ನೀವು Rust ನ ಅಲಿಯಾಸಿಂಗ್ ನಿಯಮಗಳನ್ನು ಜಾರಿಗೊಳಿಸಬೇಕು, ಏಕೆಂದರೆ ಹಿಂದಿರುಗಿದ ಜೀವಿತಾವಧಿಯ `'a` ಅನ್ನು ಅನಿಯಂತ್ರಿತವಾಗಿ ಆಯ್ಕೆಮಾಡಲಾಗುತ್ತದೆ ಮತ್ತು ಇದು ಡೇಟಾದ ನಿಜವಾದ ಜೀವಿತಾವಧಿಯನ್ನು ಪ್ರತಿಬಿಂಬಿಸುವುದಿಲ್ಲ.
    ///
    ///   ನಿರ್ದಿಷ್ಟವಾಗಿ ಹೇಳುವುದಾದರೆ, ಈ ಜೀವಿತಾವಧಿಯ ಅವಧಿಗೆ, ಪಾಯಿಂಟರ್ ಸೂಚಿಸುವ ಮೆಮೊರಿ ಬೇರೆ ಯಾವುದೇ ಪಾಯಿಂಟರ್ ಮೂಲಕ ಪ್ರವೇಶಿಸಬಾರದು (ಓದಲು ಅಥವಾ ಬರೆಯಲು).
    ///
    /// ಈ ವಿಧಾನದ ಫಲಿತಾಂಶವು ಬಳಕೆಯಾಗದಿದ್ದರೂ ಸಹ ಇದು ಅನ್ವಯಿಸುತ್ತದೆ!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `self` ಎಲ್ಲವನ್ನು ಪೂರೈಸುತ್ತಾರೆ ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು
        // ಉಲ್ಲೇಖದ ಅವಶ್ಯಕತೆಗಳು.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// ಹೊಸ `NonNull` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// `ptr` ಶೂನ್ಯೇತರವಾಗಿರಬೇಕು.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `ptr` ಶೂನ್ಯವಲ್ಲ ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// `ptr` ಶೂನ್ಯವಲ್ಲದಿದ್ದರೆ ಹೊಸ `NonNull` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // ಸುರಕ್ಷತೆ: ಪಾಯಿಂಟರ್ ಅನ್ನು ಈಗಾಗಲೇ ಪರಿಶೀಲಿಸಲಾಗಿದೆ ಮತ್ತು ಶೂನ್ಯವಾಗಿಲ್ಲ
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// ಕಚ್ಚಾ `*const` ಪಾಯಿಂಟರ್‌ಗೆ ವಿರುದ್ಧವಾಗಿ, `NonNull` ಪಾಯಿಂಟರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುವುದನ್ನು ಹೊರತುಪಡಿಸಿ, [`std::ptr::from_raw_parts`] ನಂತೆಯೇ ಅದೇ ಕಾರ್ಯವನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
    ///
    ///
    /// ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ [`std::ptr::from_raw_parts`] ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // ಸುರಕ್ಷತೆ: `ptr::from::raw_parts_mut` ನ ಫಲಿತಾಂಶವು ಶೂನ್ಯವಲ್ಲ ಏಕೆಂದರೆ `data_address` ಆಗಿದೆ.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// ವಿಳಾಸ ಮತ್ತು ಮೆಟಾಡೇಟಾ ಘಟಕಗಳಾಗಿ (ಬಹುಶಃ ಅಗಲವಾದ) ಪಾಯಿಂಟರ್ ಅನ್ನು ವಿಭಜಿಸಿ.
    ///
    /// ಪಾಯಿಂಟರ್ ಅನ್ನು ನಂತರ [`NonNull::from_raw_parts`] ನೊಂದಿಗೆ ಪುನರ್ನಿರ್ಮಿಸಬಹುದು.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// ಆಧಾರವಾಗಿರುವ `*mut` ಪಾಯಿಂಟರ್ ಅನ್ನು ಪಡೆದುಕೊಳ್ಳುತ್ತದೆ.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// ಮೌಲ್ಯಕ್ಕೆ ಹಂಚಿದ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.ಮೌಲ್ಯವನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗದಿದ್ದರೆ, ಬದಲಿಗೆ [`as_uninit_ref`] ಅನ್ನು ಬಳಸಬೇಕು.
    ///
    /// ರೂಪಾಂತರಿತ ಪ್ರತಿರೂಪಕ್ಕಾಗಿ [`as_mut`] ನೋಡಿ.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// ಈ ವಿಧಾನವನ್ನು ಕರೆಯುವಾಗ, ಈ ಕೆಳಗಿನವುಗಳೆಲ್ಲವೂ ನಿಜವೆಂದು ನೀವು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು:
    ///
    /// * ಪಾಯಿಂಟರ್ ಅನ್ನು ಸರಿಯಾಗಿ ಜೋಡಿಸಬೇಕು.
    ///
    /// * ಇದು [the module documentation] ನಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ಅರ್ಥದಲ್ಲಿ "dereferencable" ಆಗಿರಬೇಕು.
    ///
    /// * ಪಾಯಿಂಟರ್ `T` ನ ಪ್ರಾರಂಭಿಕ ನಿದರ್ಶನಕ್ಕೆ ಸೂಚಿಸಬೇಕು.
    ///
    /// * ನೀವು Rust ನ ಅಲಿಯಾಸಿಂಗ್ ನಿಯಮಗಳನ್ನು ಜಾರಿಗೊಳಿಸಬೇಕು, ಏಕೆಂದರೆ ಹಿಂದಿರುಗಿದ ಜೀವಿತಾವಧಿಯ `'a` ಅನ್ನು ಅನಿಯಂತ್ರಿತವಾಗಿ ಆಯ್ಕೆಮಾಡಲಾಗುತ್ತದೆ ಮತ್ತು ಇದು ಡೇಟಾದ ನಿಜವಾದ ಜೀವಿತಾವಧಿಯನ್ನು ಪ್ರತಿಬಿಂಬಿಸುವುದಿಲ್ಲ.
    ///
    ///   ನಿರ್ದಿಷ್ಟವಾಗಿ ಹೇಳುವುದಾದರೆ, ಈ ಜೀವಿತಾವಧಿಯ ಅವಧಿಗೆ, ಪಾಯಿಂಟರ್ ಸೂಚಿಸುವ ಮೆಮೊರಿ ರೂಪಾಂತರಗೊಳ್ಳಬಾರದು (`UnsafeCell` ಒಳಗೆ ಹೊರತುಪಡಿಸಿ).
    ///
    /// ಈ ವಿಧಾನದ ಫಲಿತಾಂಶವು ಬಳಕೆಯಾಗದಿದ್ದರೂ ಸಹ ಇದು ಅನ್ವಯಿಸುತ್ತದೆ!
    /// (ಪ್ರಾರಂಭಿಸುವ ಬಗ್ಗೆ ಭಾಗವನ್ನು ಇನ್ನೂ ಸಂಪೂರ್ಣವಾಗಿ ನಿರ್ಧರಿಸಲಾಗಿಲ್ಲ, ಆದರೆ ಅದು ಆಗುವವರೆಗೂ, ಅವುಗಳನ್ನು ನಿಜವಾಗಿಯೂ ಪ್ರಾರಂಭಿಸಲಾಗಿದೆಯೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳುವುದು ಮಾತ್ರ ಸುರಕ್ಷಿತ ವಿಧಾನವಾಗಿದೆ.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `self` ಎಲ್ಲವನ್ನು ಪೂರೈಸುತ್ತಾರೆ ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು
        // ಉಲ್ಲೇಖದ ಅವಶ್ಯಕತೆಗಳು.
        unsafe { &*self.as_ptr() }
    }

    /// ಮೌಲ್ಯಕ್ಕೆ ಅನನ್ಯ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.ಮೌಲ್ಯವನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗದಿದ್ದರೆ, ಬದಲಿಗೆ [`as_uninit_mut`] ಅನ್ನು ಬಳಸಬೇಕು.
    ///
    /// ಹಂಚಿದ ಪ್ರತಿರೂಪಕ್ಕಾಗಿ [`as_ref`] ನೋಡಿ.
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// ಈ ವಿಧಾನವನ್ನು ಕರೆಯುವಾಗ, ಈ ಕೆಳಗಿನವುಗಳೆಲ್ಲವೂ ನಿಜವೆಂದು ನೀವು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು:
    ///
    /// * ಪಾಯಿಂಟರ್ ಅನ್ನು ಸರಿಯಾಗಿ ಜೋಡಿಸಬೇಕು.
    ///
    /// * ಇದು [the module documentation] ನಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ಅರ್ಥದಲ್ಲಿ "dereferencable" ಆಗಿರಬೇಕು.
    ///
    /// * ಪಾಯಿಂಟರ್ `T` ನ ಪ್ರಾರಂಭಿಕ ನಿದರ್ಶನಕ್ಕೆ ಸೂಚಿಸಬೇಕು.
    ///
    /// * ನೀವು Rust ನ ಅಲಿಯಾಸಿಂಗ್ ನಿಯಮಗಳನ್ನು ಜಾರಿಗೊಳಿಸಬೇಕು, ಏಕೆಂದರೆ ಹಿಂದಿರುಗಿದ ಜೀವಿತಾವಧಿಯ `'a` ಅನ್ನು ಅನಿಯಂತ್ರಿತವಾಗಿ ಆಯ್ಕೆಮಾಡಲಾಗುತ್ತದೆ ಮತ್ತು ಇದು ಡೇಟಾದ ನಿಜವಾದ ಜೀವಿತಾವಧಿಯನ್ನು ಪ್ರತಿಬಿಂಬಿಸುವುದಿಲ್ಲ.
    ///
    ///   ನಿರ್ದಿಷ್ಟವಾಗಿ ಹೇಳುವುದಾದರೆ, ಈ ಜೀವಿತಾವಧಿಯ ಅವಧಿಗೆ, ಪಾಯಿಂಟರ್ ಸೂಚಿಸುವ ಮೆಮೊರಿ ಬೇರೆ ಯಾವುದೇ ಪಾಯಿಂಟರ್ ಮೂಲಕ ಪ್ರವೇಶಿಸಬಾರದು (ಓದಲು ಅಥವಾ ಬರೆಯಲು).
    ///
    /// ಈ ವಿಧಾನದ ಫಲಿತಾಂಶವು ಬಳಕೆಯಾಗದಿದ್ದರೂ ಸಹ ಇದು ಅನ್ವಯಿಸುತ್ತದೆ!
    /// (ಪ್ರಾರಂಭಿಸುವ ಬಗ್ಗೆ ಭಾಗವನ್ನು ಇನ್ನೂ ಸಂಪೂರ್ಣವಾಗಿ ನಿರ್ಧರಿಸಲಾಗಿಲ್ಲ, ಆದರೆ ಅದು ಆಗುವವರೆಗೂ, ಅವುಗಳನ್ನು ನಿಜವಾಗಿಯೂ ಪ್ರಾರಂಭಿಸಲಾಗಿದೆಯೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳುವುದು ಮಾತ್ರ ಸುರಕ್ಷಿತ ವಿಧಾನವಾಗಿದೆ.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `self` ಎಲ್ಲವನ್ನು ಪೂರೈಸುತ್ತಾರೆ ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು
        // ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖದ ಅವಶ್ಯಕತೆಗಳು.
        unsafe { &mut *self.as_ptr() }
    }

    /// ಮತ್ತೊಂದು ಪ್ರಕಾರದ ಪಾಯಿಂಟರ್‌ಗೆ ಬಿತ್ತರಿಸುತ್ತದೆ.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // ಸುರಕ್ಷತೆ: `self` ಎಂಬುದು `NonNull` ಪಾಯಿಂಟರ್ ಆಗಿದ್ದು ಅದು ಶೂನ್ಯವಲ್ಲ
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// ತೆಳುವಾದ ಪಾಯಿಂಟರ್ ಮತ್ತು ಉದ್ದದಿಂದ ಶೂನ್ಯವಲ್ಲದ ಕಚ್ಚಾ ಸ್ಲೈಸ್ ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// `len` ಆರ್ಗ್ಯುಮೆಂಟ್ **ಅಂಶಗಳ ಸಂಖ್ಯೆ**, ಆದರೆ ಬೈಟ್‌ಗಳ ಸಂಖ್ಯೆ ಅಲ್ಲ.
    ///
    /// ಈ ಕಾರ್ಯವು ಸುರಕ್ಷಿತವಾಗಿದೆ, ಆದರೆ ರಿಟರ್ನ್ ಮೌಲ್ಯವನ್ನು ಡಿಫರೆನ್ಸಿಂಗ್ ಮಾಡುವುದು ಅಸುರಕ್ಷಿತವಾಗಿದೆ.
    /// ಸ್ಲೈಸ್ ಸುರಕ್ಷತಾ ಅವಶ್ಯಕತೆಗಳಿಗಾಗಿ [`slice::from_raw_parts`] ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // ಮೊದಲ ಅಂಶಕ್ಕೆ ಪಾಯಿಂಟರ್‌ನೊಂದಿಗೆ ಪ್ರಾರಂಭಿಸುವಾಗ ಸ್ಲೈಸ್ ಪಾಯಿಂಟರ್ ರಚಿಸಿ
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (ಈ ಉದಾಹರಣೆಯು ಈ ವಿಧಾನದ ಬಳಕೆಯನ್ನು ಕೃತಕವಾಗಿ ತೋರಿಸುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಆದರೆ `ಸ್ಲೈಸ್= NonNull::from(&x[..]);` would be a better way to write code like this.) ಅನ್ನು ಬಿಡಿ
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // ಸುರಕ್ಷತೆ: `data` ಎಂಬುದು `NonNull` ಪಾಯಿಂಟರ್ ಆಗಿದ್ದು ಅದು ಶೂನ್ಯವಲ್ಲ
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// ಶೂನ್ಯವಲ್ಲದ ಕಚ್ಚಾ ಸ್ಲೈಸ್‌ನ ಉದ್ದವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಹಿಂತಿರುಗಿದ ಮೌಲ್ಯವು **ಅಂಶಗಳ ಸಂಖ್ಯೆ**, ಆದರೆ ಬೈಟ್‌ಗಳ ಸಂಖ್ಯೆ ಅಲ್ಲ.
    ///
    /// ಶೂನ್ಯವಲ್ಲದ ಕಚ್ಚಾ ಸ್ಲೈಸ್ ಅನ್ನು ಸ್ಲೈಸ್‌ಗೆ ಡಿಫರೆನ್ಸ್ ಮಾಡಲಾಗದಿದ್ದರೂ ಸಹ, ಈ ಕಾರ್ಯವು ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ ಪಾಯಿಂಟರ್‌ಗೆ ಮಾನ್ಯ ವಿಳಾಸವಿಲ್ಲ.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// ಸ್ಲೈಸ್‌ನ ಬಫರ್‌ಗೆ ಶೂನ್ಯವಲ್ಲದ ಪಾಯಿಂಟರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // ಸುರಕ್ಷತೆ: `self` ಶೂನ್ಯವಲ್ಲ ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// ಸ್ಲೈಸ್‌ನ ಬಫರ್‌ಗೆ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// ಪ್ರಾರಂಭಿಸದ ಮೌಲ್ಯಗಳ ಸ್ಲೈಸ್‌ಗೆ ಹಂಚಿದ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.[`as_ref`] ಗೆ ವ್ಯತಿರಿಕ್ತವಾಗಿ, ಮೌಲ್ಯವನ್ನು ಪ್ರಾರಂಭಿಸಬೇಕಾಗಿಲ್ಲ.
    ///
    /// ರೂಪಾಂತರಿತ ಪ್ರತಿರೂಪಕ್ಕಾಗಿ [`as_uninit_slice_mut`] ನೋಡಿ.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// ಈ ವಿಧಾನವನ್ನು ಕರೆಯುವಾಗ, ಈ ಕೆಳಗಿನವುಗಳೆಲ್ಲವೂ ನಿಜವೆಂದು ನೀವು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು:
    ///
    /// * `ptr.len() * mem::size_of::<T>()` ಅನೇಕ ಬೈಟ್‌ಗಳ ಓದುವಿಕೆಗಾಗಿ ಪಾಯಿಂಟರ್ [valid] ಆಗಿರಬೇಕು ಮತ್ತು ಅದನ್ನು ಸರಿಯಾಗಿ ಜೋಡಿಸಬೇಕು.ಇದರರ್ಥ ನಿರ್ದಿಷ್ಟವಾಗಿ:
    ///
    ///     * ಈ ಸ್ಲೈಸ್‌ನ ಸಂಪೂರ್ಣ ಮೆಮೊರಿ ವ್ಯಾಪ್ತಿಯು ಒಂದೇ ನಿಯೋಜಿತ ವಸ್ತುವಿನೊಳಗೆ ಇರಬೇಕು!
    ///       ಹಂಚಿದ ಬಹು ವಸ್ತುಗಳಾದ್ಯಂತ ಚೂರುಗಳು ಎಂದಿಗೂ ವ್ಯಾಪಿಸುವುದಿಲ್ಲ.
    ///
    ///     * ಪಾಯಿಂಟರ್ ಅನ್ನು ಶೂನ್ಯ-ಉದ್ದದ ಚೂರುಗಳಿಗೆ ಸಹ ಜೋಡಿಸಬೇಕು.
    ///     ಇದಕ್ಕೆ ಒಂದು ಕಾರಣವೆಂದರೆ, ಎನಮ್ ಲೇ layout ಟ್ ಆಪ್ಟಿಮೈಸೇಶನ್‌ಗಳು ಇತರ ಡೇಟಾದಿಂದ ಪ್ರತ್ಯೇಕಿಸಲು ಉಲ್ಲೇಖಗಳನ್ನು (ಯಾವುದೇ ಉದ್ದದ ಚೂರುಗಳನ್ನು ಒಳಗೊಂಡಂತೆ) ಜೋಡಿಸಿ ಮತ್ತು ಶೂನ್ಯವಲ್ಲದ ಮೇಲೆ ಅವಲಂಬಿತವಾಗಿರುತ್ತದೆ.
    ///
    ///     [`NonNull::dangling()`] ಬಳಸಿ ಶೂನ್ಯ-ಉದ್ದದ ಚೂರುಗಳಿಗಾಗಿ `data` ಆಗಿ ಬಳಸಬಹುದಾದ ಪಾಯಿಂಟರ್ ಅನ್ನು ನೀವು ಪಡೆಯಬಹುದು.
    ///
    /// * ಸ್ಲೈಸ್‌ನ ಒಟ್ಟು ಗಾತ್ರ `ptr.len() * mem::size_of::<T>()` `isize::MAX` ಗಿಂತ ದೊಡ್ಡದಾಗಿರಬಾರದು.
    ///   [`pointer::offset`] ನ ಸುರಕ್ಷತಾ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
    ///
    /// * ನೀವು Rust ನ ಅಲಿಯಾಸಿಂಗ್ ನಿಯಮಗಳನ್ನು ಜಾರಿಗೊಳಿಸಬೇಕು, ಏಕೆಂದರೆ ಹಿಂದಿರುಗಿದ ಜೀವಿತಾವಧಿಯ `'a` ಅನ್ನು ಅನಿಯಂತ್ರಿತವಾಗಿ ಆಯ್ಕೆಮಾಡಲಾಗುತ್ತದೆ ಮತ್ತು ಇದು ಡೇಟಾದ ನಿಜವಾದ ಜೀವಿತಾವಧಿಯನ್ನು ಪ್ರತಿಬಿಂಬಿಸುವುದಿಲ್ಲ.
    ///   ನಿರ್ದಿಷ್ಟವಾಗಿ ಹೇಳುವುದಾದರೆ, ಈ ಜೀವಿತಾವಧಿಯ ಅವಧಿಗೆ, ಪಾಯಿಂಟರ್ ಸೂಚಿಸುವ ಮೆಮೊರಿ ರೂಪಾಂತರಗೊಳ್ಳಬಾರದು (`UnsafeCell` ಒಳಗೆ ಹೊರತುಪಡಿಸಿ).
    ///
    /// ಈ ವಿಧಾನದ ಫಲಿತಾಂಶವು ಬಳಕೆಯಾಗದಿದ್ದರೂ ಸಹ ಇದು ಅನ್ವಯಿಸುತ್ತದೆ!
    ///
    /// [`slice::from_raw_parts`] ಸಹ ನೋಡಿ.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `as_uninit_slice` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// ಪ್ರಾರಂಭಿಸದ ಮೌಲ್ಯಗಳ ಸ್ಲೈಸ್‌ಗೆ ಅನನ್ಯ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.[`as_mut`] ಗೆ ವ್ಯತಿರಿಕ್ತವಾಗಿ, ಮೌಲ್ಯವನ್ನು ಪ್ರಾರಂಭಿಸಬೇಕಾಗಿಲ್ಲ.
    ///
    /// ಹಂಚಿದ ಪ್ರತಿರೂಪಕ್ಕಾಗಿ [`as_uninit_slice`] ನೋಡಿ.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// ಈ ವಿಧಾನವನ್ನು ಕರೆಯುವಾಗ, ಈ ಕೆಳಗಿನವುಗಳೆಲ್ಲವೂ ನಿಜವೆಂದು ನೀವು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು:
    ///
    /// * `ptr.len() * mem::size_of::<T>()` ಅನೇಕ ಬೈಟ್‌ಗಳಿಗಾಗಿ ಓದಲು ಮತ್ತು ಬರೆಯಲು ಪಾಯಿಂಟರ್ [valid] ಆಗಿರಬೇಕು ಮತ್ತು ಅದನ್ನು ಸರಿಯಾಗಿ ಜೋಡಿಸಬೇಕು.ಇದರರ್ಥ ನಿರ್ದಿಷ್ಟವಾಗಿ:
    ///
    ///     * ಈ ಸ್ಲೈಸ್‌ನ ಸಂಪೂರ್ಣ ಮೆಮೊರಿ ವ್ಯಾಪ್ತಿಯು ಒಂದೇ ನಿಯೋಜಿತ ವಸ್ತುವಿನೊಳಗೆ ಇರಬೇಕು!
    ///       ಹಂಚಿದ ಬಹು ವಸ್ತುಗಳಾದ್ಯಂತ ಚೂರುಗಳು ಎಂದಿಗೂ ವ್ಯಾಪಿಸುವುದಿಲ್ಲ.
    ///
    ///     * ಪಾಯಿಂಟರ್ ಅನ್ನು ಶೂನ್ಯ-ಉದ್ದದ ಚೂರುಗಳಿಗೆ ಸಹ ಜೋಡಿಸಬೇಕು.
    ///     ಇದಕ್ಕೆ ಒಂದು ಕಾರಣವೆಂದರೆ, ಎನಮ್ ಲೇ layout ಟ್ ಆಪ್ಟಿಮೈಸೇಶನ್‌ಗಳು ಇತರ ಡೇಟಾದಿಂದ ಪ್ರತ್ಯೇಕಿಸಲು ಉಲ್ಲೇಖಗಳನ್ನು (ಯಾವುದೇ ಉದ್ದದ ಚೂರುಗಳನ್ನು ಒಳಗೊಂಡಂತೆ) ಜೋಡಿಸಿ ಮತ್ತು ಶೂನ್ಯವಲ್ಲದ ಮೇಲೆ ಅವಲಂಬಿತವಾಗಿರುತ್ತದೆ.
    ///
    ///     [`NonNull::dangling()`] ಬಳಸಿ ಶೂನ್ಯ-ಉದ್ದದ ಚೂರುಗಳಿಗಾಗಿ `data` ಆಗಿ ಬಳಸಬಹುದಾದ ಪಾಯಿಂಟರ್ ಅನ್ನು ನೀವು ಪಡೆಯಬಹುದು.
    ///
    /// * ಸ್ಲೈಸ್‌ನ ಒಟ್ಟು ಗಾತ್ರ `ptr.len() * mem::size_of::<T>()` `isize::MAX` ಗಿಂತ ದೊಡ್ಡದಾಗಿರಬಾರದು.
    ///   [`pointer::offset`] ನ ಸುರಕ್ಷತಾ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
    ///
    /// * ನೀವು Rust ನ ಅಲಿಯಾಸಿಂಗ್ ನಿಯಮಗಳನ್ನು ಜಾರಿಗೊಳಿಸಬೇಕು, ಏಕೆಂದರೆ ಹಿಂದಿರುಗಿದ ಜೀವಿತಾವಧಿಯ `'a` ಅನ್ನು ಅನಿಯಂತ್ರಿತವಾಗಿ ಆಯ್ಕೆಮಾಡಲಾಗುತ್ತದೆ ಮತ್ತು ಇದು ಡೇಟಾದ ನಿಜವಾದ ಜೀವಿತಾವಧಿಯನ್ನು ಪ್ರತಿಬಿಂಬಿಸುವುದಿಲ್ಲ.
    ///   ನಿರ್ದಿಷ್ಟವಾಗಿ ಹೇಳುವುದಾದರೆ, ಈ ಜೀವಿತಾವಧಿಯ ಅವಧಿಗೆ, ಪಾಯಿಂಟರ್ ಸೂಚಿಸುವ ಮೆಮೊರಿ ಬೇರೆ ಯಾವುದೇ ಪಾಯಿಂಟರ್ ಮೂಲಕ ಪ್ರವೇಶಿಸಬಾರದು (ಓದಲು ಅಥವಾ ಬರೆಯಲು).
    ///
    /// ಈ ವಿಧಾನದ ಫಲಿತಾಂಶವು ಬಳಕೆಯಾಗದಿದ್ದರೂ ಸಹ ಇದು ಅನ್ವಯಿಸುತ್ತದೆ!
    ///
    /// [`slice::from_raw_parts_mut`] ಸಹ ನೋಡಿ.
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // `memory` ಅನೇಕ ಬೈಟ್‌ಗಳಿಗೆ ಓದಲು ಮತ್ತು ಬರೆಯಲು ಮಾನ್ಯವಾಗಿರುವುದರಿಂದ ಇದು ಸುರಕ್ಷಿತವಾಗಿದೆ.
    /// // ವಿಷಯವನ್ನು ಪ್ರಾರಂಭಿಸದ ಕಾರಣ `memory.as_mut()` ಗೆ ಕರೆ ಮಾಡಲು ಇಲ್ಲಿ ಅನುಮತಿಸಲಾಗುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `as_uninit_slice_mut` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// ಗಡಿ ಪರಿಶೀಲನೆ ಮಾಡದೆಯೇ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಅನ್ನು ಒಂದು ಅಂಶ ಅಥವಾ ಸಬ್‌ಲೈಸ್‌ಗೆ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ವಿಧಾನವನ್ನು ಮಿತಿಯಿಲ್ಲದ ಸೂಚ್ಯಂಕದೊಂದಿಗೆ ಕರೆಯುವುದು ಅಥವಾ `self` ಅನ್ನು ಡಿಫರೆನ್ಫರೆಬಲ್ ಆಗದಿದ್ದಾಗ *[ಸ್ಪಷ್ಟೀಕರಿಸದ ನಡವಳಿಕೆ]* ಫಲಿತಾಂಶದ ಪಾಯಿಂಟರ್ ಅನ್ನು ಬಳಸದಿದ್ದರೂ ಸಹ.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `self` ಅನ್ನು ಡಿಫರೆನ್ಸೆನ್ಬಲ್ ಮತ್ತು `index` ಇನ್-ಬೌಂಡ್ ಎಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ.
        // ಇದರ ಪರಿಣಾಮವಾಗಿ, ಪರಿಣಾಮವಾಗಿ ಪಾಯಿಂಟರ್ NULL ಆಗಿರಬಾರದು.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // ಸುರಕ್ಷತೆ: ವಿಶಿಷ್ಟ ಪಾಯಿಂಟರ್ ಶೂನ್ಯವಾಗಿರಲು ಸಾಧ್ಯವಿಲ್ಲ, ಆದ್ದರಿಂದ ಪರಿಸ್ಥಿತಿಗಳು
        // new_unchecked() ಗೌರವಿಸಲಾಗುತ್ತದೆ.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // ಸುರಕ್ಷತೆ: ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖ ಶೂನ್ಯವಾಗಿರಬಾರದು.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // ಸುರಕ್ಷತೆ: ಉಲ್ಲೇಖವು ಶೂನ್ಯವಾಗಿರಲು ಸಾಧ್ಯವಿಲ್ಲ, ಆದ್ದರಿಂದ ಪರಿಸ್ಥಿತಿಗಳು
        // new_unchecked() ಗೌರವಿಸಲಾಗುತ್ತದೆ.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}