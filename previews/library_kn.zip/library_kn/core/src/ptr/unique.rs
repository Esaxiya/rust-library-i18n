use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// ಕಚ್ಚಾ ಶೂನ್ಯವಲ್ಲದ `*mut T` ಸುತ್ತಲೂ ಒಂದು ಹೊದಿಕೆ ಈ ಹೊದಿಕೆಯನ್ನು ಹೊಂದಿರುವವರು ಉಲ್ಲೇಖವನ್ನು ಹೊಂದಿದ್ದಾರೆಂದು ಸೂಚಿಸುತ್ತದೆ.
/// `Box<T>`, `Vec<T>`, `String`, ಮತ್ತು `HashMap<K, V>` ನಂತಹ ಅಮೂರ್ತತೆಗಳನ್ನು ನಿರ್ಮಿಸಲು ಉಪಯುಕ್ತವಾಗಿದೆ.
///
/// `*mut T` ಗಿಂತ ಭಿನ್ನವಾಗಿ, `Unique<T>` "as if" ನಂತೆ ವರ್ತಿಸುತ್ತದೆ ಇದು `T` ನ ಉದಾಹರಣೆಯಾಗಿದೆ.
/// `T` `Send`/`Sync` ಆಗಿದ್ದರೆ ಅದು `Send`/`Sync` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
/// ಇದು `T` ನ ಉದಾಹರಣೆಯನ್ನು ನಿರೀಕ್ಷಿಸಬಹುದಾದಂತಹ ಬಲವಾದ ಅಲಿಯಾಸಿಂಗ್ ಖಾತರಿಗಳನ್ನು ಸಹ ಸೂಚಿಸುತ್ತದೆ:
/// ಪಾಯಿಂಟರ್‌ನ ಉಲ್ಲೇಖವನ್ನು ತನ್ನದೇ ಆದ ವಿಶಿಷ್ಟತೆಗೆ ಅನನ್ಯ ಮಾರ್ಗವಿಲ್ಲದೆ ಮಾರ್ಪಡಿಸಬಾರದು.
///
/// ನಿಮ್ಮ ಉದ್ದೇಶಗಳಿಗಾಗಿ `Unique` ಅನ್ನು ಬಳಸುವುದು ಸರಿಯೇ ಎಂದು ನಿಮಗೆ ಖಚಿತವಿಲ್ಲದಿದ್ದರೆ, `NonNull` ಅನ್ನು ಪರಿಗಣಿಸಿ, ಅದು ದುರ್ಬಲ ಶಬ್ದಾರ್ಥವನ್ನು ಹೊಂದಿದೆ.
///
///
/// `*mut T` ಗಿಂತ ಭಿನ್ನವಾಗಿ, ಪಾಯಿಂಟರ್ ಎಂದಿಗೂ ಡಿಫರೆನ್ಸ್ ಮಾಡದಿದ್ದರೂ ಸಹ, ಪಾಯಿಂಟರ್ ಯಾವಾಗಲೂ ಶೂನ್ಯವಾಗಿರಬಾರದು.
/// ಎನ್ಯುಮ್ಗಳು ಈ ನಿಷೇಧಿತ ಮೌಲ್ಯವನ್ನು ತಾರತಮ್ಯವಾಗಿ ಬಳಸಬಹುದು-`Option<Unique<T>>` `Unique<T>` ನಂತೆಯೇ ಗಾತ್ರವನ್ನು ಹೊಂದಿರುತ್ತದೆ.
/// ಆದಾಗ್ಯೂ, ಪಾಯಿಂಟರ್ ಡಿಫರೆನ್ಸ್ ಮಾಡದಿದ್ದರೆ ಇನ್ನೂ ತೂಗಾಡಬಹುದು.
///
/// `*mut T` ಗಿಂತ ಭಿನ್ನವಾಗಿ, `Unique<T>` `T` ಗಿಂತಲೂ ಸಹವರ್ತಿಯಾಗಿದೆ.
/// ವಿಶಿಷ್ಟವಾದ ಅಲಿಯಾಸಿಂಗ್ ಅವಶ್ಯಕತೆಗಳನ್ನು ಎತ್ತಿಹಿಡಿಯುವ ಯಾವುದೇ ಪ್ರಕಾರಕ್ಕೆ ಇದು ಯಾವಾಗಲೂ ಸರಿಯಾಗಿರಬೇಕು.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: ಈ ಮಾರ್ಕರ್ ವ್ಯತ್ಯಾಸಕ್ಕೆ ಯಾವುದೇ ಪರಿಣಾಮಗಳನ್ನು ಹೊಂದಿಲ್ಲ, ಆದರೆ ಇದು ಅವಶ್ಯಕವಾಗಿದೆ
    // ಡ್ರಾಪ್ಕ್ ನಾವು ತಾರ್ಕಿಕವಾಗಿ `T` ಅನ್ನು ಹೊಂದಿದ್ದೇವೆ ಎಂದು ಅರ್ಥಮಾಡಿಕೊಳ್ಳಲು.
    //
    // ವಿವರಗಳಿಗಾಗಿ, ನೋಡಿ:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` `T` `Send` ಆಗಿದ್ದರೆ ಪಾಯಿಂಟರ್‌ಗಳು `Send` ಆಗಿರುತ್ತವೆ ಏಕೆಂದರೆ ಅವು ಉಲ್ಲೇಖಿಸುವ ಡೇಟಾ ಅನಿಯಂತ್ರಿತವಾಗಿರುತ್ತದೆ.
/// ಈ ಅಲಿಯಾಸಿಂಗ್ ಅಸ್ಥಿರತೆಯು ಟೈಪ್ ಸಿಸ್ಟಮ್‌ನಿಂದ ಬಲಪಡಿಸುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ;`Unique` ಅನ್ನು ಬಳಸುವ ಅಮೂರ್ತತೆಯು ಅದನ್ನು ಜಾರಿಗೊಳಿಸಬೇಕು.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` `T` `Sync` ಆಗಿದ್ದರೆ ಪಾಯಿಂಟರ್‌ಗಳು `Sync` ಆಗಿರುತ್ತವೆ ಏಕೆಂದರೆ ಅವು ಉಲ್ಲೇಖಿಸುವ ಡೇಟಾ ಅನಿಯಂತ್ರಿತವಾಗಿರುತ್ತದೆ.
/// ಈ ಅಲಿಯಾಸಿಂಗ್ ಅಸ್ಥಿರತೆಯು ಟೈಪ್ ಸಿಸ್ಟಮ್‌ನಿಂದ ಬಲಪಡಿಸುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ;`Unique` ಅನ್ನು ಬಳಸುವ ಅಮೂರ್ತತೆಯು ಅದನ್ನು ಜಾರಿಗೊಳಿಸಬೇಕು.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// ಹೊಸ `Unique` ಅನ್ನು ರಚಿಸುತ್ತದೆ ಅದು ತೂಗಾಡುತ್ತಿರುವ, ಆದರೆ ಉತ್ತಮವಾಗಿ ಹೊಂದಿಕೊಳ್ಳುತ್ತದೆ.
    ///
    /// `Vec::new` ನಂತೆ ಸೋಮಾರಿಯಾಗಿ ಹಂಚುವ ಪ್ರಕಾರಗಳನ್ನು ಪ್ರಾರಂಭಿಸಲು ಇದು ಉಪಯುಕ್ತವಾಗಿದೆ.
    ///
    /// ಪಾಯಿಂಟರ್ ಮೌಲ್ಯವು `T` ಗೆ ಮಾನ್ಯ ಪಾಯಿಂಟರ್ ಅನ್ನು ಸಂಭಾವ್ಯವಾಗಿ ಪ್ರತಿನಿಧಿಸಬಹುದು ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಇದರರ್ಥ ಇದನ್ನು "not yet initialized" ಸೆಂಟಿನೆಲ್ ಮೌಲ್ಯವಾಗಿ ಬಳಸಬಾರದು.
    /// ಸೋಮಾರಿಯಾಗಿ ಹಂಚುವ ಪ್ರಕಾರಗಳು ಇತರ ವಿಧಾನಗಳಿಂದ ಪ್ರಾರಂಭವನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಬೇಕು.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // ಸುರಕ್ಷತೆ: mem::align_of() ಮಾನ್ಯ, ಶೂನ್ಯವಲ್ಲದ ಪಾಯಿಂಟರ್ ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.ದಿ
        // new_unchecked() ಗೆ ಕರೆ ಮಾಡುವ ಷರತ್ತುಗಳನ್ನು ಹೀಗೆ ಗೌರವಿಸಲಾಗುತ್ತದೆ.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// ಹೊಸ `Unique` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// `ptr` ಶೂನ್ಯೇತರವಾಗಿರಬೇಕು.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `ptr` ಶೂನ್ಯವಲ್ಲ ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// `ptr` ಶೂನ್ಯವಲ್ಲದಿದ್ದರೆ ಹೊಸ `Unique` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // ಸುರಕ್ಷತೆ: ಪಾಯಿಂಟರ್ ಅನ್ನು ಈಗಾಗಲೇ ಪರಿಶೀಲಿಸಲಾಗಿದೆ ಮತ್ತು ಶೂನ್ಯವಾಗಿಲ್ಲ.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// ಆಧಾರವಾಗಿರುವ `*mut` ಪಾಯಿಂಟರ್ ಅನ್ನು ಪಡೆದುಕೊಳ್ಳುತ್ತದೆ.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// ವಿಷಯವನ್ನು ಡಿಫರೆನ್ಸ್ ಮಾಡುತ್ತದೆ.
    ///
    /// ಪರಿಣಾಮವಾಗಿ ಜೀವಿತಾವಧಿಯು ಸ್ವಯಂಗೆ ಬಂಧಿತವಾಗಿರುತ್ತದೆ, ಆದ್ದರಿಂದ ಇದು "as if" ನಂತೆ ವರ್ತಿಸುತ್ತದೆ, ಇದು ವಾಸ್ತವವಾಗಿ T ಯ ಒಂದು ಉದಾಹರಣೆಯಾಗಿದೆ, ಅದು ಎರವಲು ಪಡೆಯುತ್ತಿದೆ.
    /// ಮುಂದೆ (unbound) ಜೀವಿತಾವಧಿ ಅಗತ್ಯವಿದ್ದರೆ, `&*my_ptr.as_ptr()` ಬಳಸಿ.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `self` ಎಲ್ಲವನ್ನು ಪೂರೈಸುತ್ತಾರೆ ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು
        // ಉಲ್ಲೇಖದ ಅವಶ್ಯಕತೆಗಳು.
        unsafe { &*self.as_ptr() }
    }

    /// ವಿಷಯವನ್ನು ಪರಸ್ಪರ ವಿರೂಪಗೊಳಿಸುತ್ತದೆ.
    ///
    /// ಪರಿಣಾಮವಾಗಿ ಜೀವಿತಾವಧಿಯು ಸ್ವಯಂಗೆ ಬಂಧಿತವಾಗಿರುತ್ತದೆ, ಆದ್ದರಿಂದ ಇದು "as if" ನಂತೆ ವರ್ತಿಸುತ್ತದೆ, ಇದು ವಾಸ್ತವವಾಗಿ T ಯ ಒಂದು ಉದಾಹರಣೆಯಾಗಿದೆ, ಅದು ಎರವಲು ಪಡೆಯುತ್ತಿದೆ.
    /// ಮುಂದೆ (unbound) ಜೀವಿತಾವಧಿ ಅಗತ್ಯವಿದ್ದರೆ, `&mut *my_ptr.as_ptr()` ಬಳಸಿ.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `self` ಎಲ್ಲವನ್ನು ಪೂರೈಸುತ್ತಾರೆ ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು
        // ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖದ ಅವಶ್ಯಕತೆಗಳು.
        unsafe { &mut *self.as_ptr() }
    }

    /// ಮತ್ತೊಂದು ಪ್ರಕಾರದ ಪಾಯಿಂಟರ್‌ಗೆ ಬಿತ್ತರಿಸುತ್ತದೆ.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // ಸುರಕ್ಷತೆ: Unique::new_unchecked() ಹೊಸ ಅನನ್ಯ ಮತ್ತು ಅಗತ್ಯಗಳನ್ನು ಸೃಷ್ಟಿಸುತ್ತದೆ
        // ಕೊಟ್ಟಿರುವ ಪಾಯಿಂಟರ್ ಶೂನ್ಯವಾಗಿರಬಾರದು.
        // ನಾವು ಸ್ವಯಂ ಪಾಯಿಂಟರ್ ಆಗಿ ಹಾದುಹೋಗುತ್ತಿರುವುದರಿಂದ, ಅದು ಶೂನ್ಯವಾಗಿರಲು ಸಾಧ್ಯವಿಲ್ಲ.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // ಸುರಕ್ಷತೆ: ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖ ಶೂನ್ಯವಾಗಿರಬಾರದು
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}