//! ASCII ತಂತಿಗಳು ಮತ್ತು ಅಕ್ಷರಗಳ ಮೇಲಿನ ಕಾರ್ಯಾಚರಣೆಗಳು.
//!
//! Rust ನಲ್ಲಿನ ಹೆಚ್ಚಿನ ಸ್ಟ್ರಿಂಗ್ ಕಾರ್ಯಾಚರಣೆಗಳು UTF-8 ತಂತಿಗಳಲ್ಲಿ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತವೆ.
//! ಆದಾಗ್ಯೂ, ಕೆಲವೊಮ್ಮೆ ನಿರ್ದಿಷ್ಟ ಕಾರ್ಯಾಚರಣೆಗಾಗಿ ಎಎಸ್ಸಿಐಐ ಅಕ್ಷರವನ್ನು ಮಾತ್ರ ಪರಿಗಣಿಸುವುದು ಹೆಚ್ಚು ಅರ್ಥಪೂರ್ಣವಾಗಿದೆ.
//!
//! [`escape_default`] ಕಾರ್ಯವು ಕೊಟ್ಟಿರುವ ಪಾತ್ರದ ತಪ್ಪಿಸಿಕೊಂಡ ಆವೃತ್ತಿಯ ಬೈಟ್‌ಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ಒದಗಿಸುತ್ತದೆ.
//!
//!

#![stable(feature = "core_ascii", since = "1.26.0")]

use crate::fmt;
use crate::iter::FusedIterator;
use crate::ops::Range;
use crate::str::from_utf8_unchecked;

/// ಬೈಟ್‌ನ ತಪ್ಪಿಸಿಕೊಂಡ ಆವೃತ್ತಿಯ ಮೇಲೆ ಪುನರಾವರ್ತಕ.
///
/// ಈ `struct` ಅನ್ನು [`escape_default`] ಕಾರ್ಯದಿಂದ ರಚಿಸಲಾಗಿದೆ.
/// ಹೆಚ್ಚಿನದಕ್ಕಾಗಿ ಅದರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct EscapeDefault {
    range: Range<usize>,
    data: [u8; 4],
}

/// `u8` ನ ತಪ್ಪಿಸಿಕೊಂಡ ಆವೃತ್ತಿಯನ್ನು ಉತ್ಪಾದಿಸುವ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
///
/// C ++ 11 ಮತ್ತು ಅಂತಹುದೇ ಸಿ-ಫ್ಯಾಮಿಲಿ ಭಾಷೆಗಳು ಸೇರಿದಂತೆ ವಿವಿಧ ಭಾಷೆಗಳಲ್ಲಿ ಕಾನೂನುಬದ್ಧವಾಗಿರುವ ಅಕ್ಷರಗಳನ್ನು ಉತ್ಪಾದಿಸುವ ಪಕ್ಷಪಾತದೊಂದಿಗೆ ಪೂರ್ವನಿಯೋಜಿತತೆಯನ್ನು ಆಯ್ಕೆ ಮಾಡಲಾಗಿದೆ.
/// ನಿಖರವಾದ ನಿಯಮಗಳು ಹೀಗಿವೆ:
///
/// * ಟ್ಯಾಬ್ ಅನ್ನು `\t` ಎಂದು ತಪ್ಪಿಸಲಾಗಿದೆ.
/// * ಕ್ಯಾರೇಜ್ ರಿಟರ್ನ್ ಅನ್ನು `\r` ಎಂದು ತಪ್ಪಿಸಲಾಗಿದೆ.
/// * ಲೈನ್ ಫೀಡ್ ಅನ್ನು `\n` ಎಂದು ತಪ್ಪಿಸಲಾಗಿದೆ.
/// * ಏಕ ಉಲ್ಲೇಖವನ್ನು `\'` ಎಂದು ತಪ್ಪಿಸಲಾಗಿದೆ.
/// * `\"` ಎಂದು ಡಬಲ್ ಉಲ್ಲೇಖ ತಪ್ಪಿಸಲಾಗಿದೆ.
/// * ಬ್ಯಾಕ್ಸ್‌ಲ್ಯಾಶ್ ಅನ್ನು `\\` ಎಂದು ತಪ್ಪಿಸಲಾಗಿದೆ.
/// * 'ಮುದ್ರಿಸಬಹುದಾದ ASCII' ಶ್ರೇಣಿಯ `0x20` .. `0x7e` ಒಳಗೊಂಡ ಯಾವುದೇ ಅಕ್ಷರ ತಪ್ಪಿಸಿಕೊಂಡಿಲ್ಲ.
/// * ಯಾವುದೇ ಇತರ ಅಕ್ಷರಗಳಿಗೆ '\xNN' ರೂಪದ ಹೆಕ್ಸ್ ಪಾರುಗಳನ್ನು ನೀಡಲಾಗುತ್ತದೆ.
/// * ಈ ಕಾರ್ಯದಿಂದ ಯೂನಿಕೋಡ್ ಪಾರುಗಳು ಎಂದಿಗೂ ಉತ್ಪತ್ತಿಯಾಗುವುದಿಲ್ಲ.
///
/// # Examples
///
/// ```
/// use std::ascii;
///
/// let escaped = ascii::escape_default(b'0').next().unwrap();
/// assert_eq!(b'0', escaped);
///
/// let mut escaped = ascii::escape_default(b'\t');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b't', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\r');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'r', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\n');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'n', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\'');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'\'', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'"');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'"', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\\');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'\\', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\x9d');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'x', escaped.next().unwrap());
/// assert_eq!(b'9', escaped.next().unwrap());
/// assert_eq!(b'd', escaped.next().unwrap());
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn escape_default(c: u8) -> EscapeDefault {
    let (data, len) = match c {
        b'\t' => ([b'\\', b't', 0, 0], 2),
        b'\r' => ([b'\\', b'r', 0, 0], 2),
        b'\n' => ([b'\\', b'n', 0, 0], 2),
        b'\\' => ([b'\\', b'\\', 0, 0], 2),
        b'\'' => ([b'\\', b'\'', 0, 0], 2),
        b'"' => ([b'\\', b'"', 0, 0], 2),
        b'\x20'..=b'\x7e' => ([c, 0, 0, 0], 1),
        _ => ([b'\\', b'x', hexify(c >> 4), hexify(c & 0xf)], 4),
    };

    return EscapeDefault { range: 0..len, data };

    fn hexify(b: u8) -> u8 {
        match b {
            0..=9 => b'0' + b,
            _ => b'a' + b - 10,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Iterator for EscapeDefault {
    type Item = u8;
    fn next(&mut self) -> Option<u8> {
        self.range.next().map(|i| self.data[i])
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.range.size_hint()
    }
    fn last(mut self) -> Option<u8> {
        self.next_back()
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl DoubleEndedIterator for EscapeDefault {
    fn next_back(&mut self) -> Option<u8> {
        self.range.next_back().map(|i| self.data[i])
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ExactSizeIterator for EscapeDefault {}
#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for EscapeDefault {}

#[stable(feature = "ascii_escape_display", since = "1.39.0")]
impl fmt::Display for EscapeDefault {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // ಸುರಕ್ಷತೆ: ಸರಿ ಏಕೆಂದರೆ `escape_default` ಮಾನ್ಯ utf-8 ಡೇಟಾವನ್ನು ಮಾತ್ರ ರಚಿಸಿದೆ
        f.write_str(unsafe { from_utf8_unchecked(&self.data[self.range.clone()]) })
    }
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for EscapeDefault {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("EscapeDefault { .. }")
    }
}