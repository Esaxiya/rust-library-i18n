use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// ಈ ಕಾರ್ಯವನ್ನು ಒಂದೇ ಸ್ಥಳದಲ್ಲಿ ಬಳಸಲಾಗುತ್ತದೆಯಾದರೂ ಮತ್ತು ಅದರ ಅನುಷ್ಠಾನವನ್ನು ಇನ್‌ಲೈನ್ ಮಾಡಬಹುದಾದರೂ, ಹಿಂದಿನ ಪ್ರಯತ್ನಗಳು rustc ಅನ್ನು ನಿಧಾನಗೊಳಿಸಿದವು:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// ಮೆಮೊರಿಯ ಬ್ಲಾಕ್ನ ವಿನ್ಯಾಸ.
///
/// `Layout` ನ ಒಂದು ಉದಾಹರಣೆಯು ಮೆಮೊರಿಯ ನಿರ್ದಿಷ್ಟ ವಿನ್ಯಾಸವನ್ನು ವಿವರಿಸುತ್ತದೆ.
/// ಹಂಚಿಕೆದಾರರಿಗೆ ನೀಡಲು ನೀವು `Layout` ಅನ್ನು ಇನ್ಪುಟ್ ಆಗಿ ನಿರ್ಮಿಸುತ್ತೀರಿ.
///
/// ಎಲ್ಲಾ ವಿನ್ಯಾಸಗಳು ಸಂಬಂಧಿತ ಗಾತ್ರ ಮತ್ತು ಪವರ್-ಆಫ್-ಎರಡು ಜೋಡಣೆಯನ್ನು ಹೊಂದಿವೆ.
///
/// (ಎಲ್ಲಾ ಮೆಮೊರಿ ವಿನಂತಿಗಳು ಶೂನ್ಯವಲ್ಲದ ಗಾತ್ರದಲ್ಲಿರಬೇಕು ಎಂದು `GlobalAlloc` ಗೆ ಅಗತ್ಯವಿದ್ದರೂ ಸಹ, ವಿನ್ಯಾಸಗಳು ಶೂನ್ಯೇತರ ಗಾತ್ರವನ್ನು ಹೊಂದಲು *ಅಗತ್ಯವಿಲ್ಲ* ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
/// ಕರೆ ಮಾಡುವವರು ಈ ರೀತಿಯ ಷರತ್ತುಗಳನ್ನು ಪೂರೈಸುತ್ತಾರೆಯೇ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು, ನಿರ್ದಿಷ್ಟ ಹಂಚಿಕೆಗಳನ್ನು ಸಡಿಲ ಅವಶ್ಯಕತೆಗಳೊಂದಿಗೆ ಬಳಸಬೇಕು ಅಥವಾ ಹೆಚ್ಚು ಮೃದುವಾದ `Allocator` ಇಂಟರ್ಫೇಸ್ ಅನ್ನು ಬಳಸಬೇಕು.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // ಬೈಟ್‌ಗಳಲ್ಲಿ ಅಳೆಯುವ ಮೆಮೊರಿಯ ವಿನಂತಿಸಿದ ಬ್ಲಾಕ್‌ನ ಗಾತ್ರ.
    size_: usize,

    // ಬೈಟ್‌ಗಳಲ್ಲಿ ಅಳೆಯುವ ಮೆಮೊರಿಯ ವಿನಂತಿಸಿದ ಬ್ಲಾಕ್‌ನ ಜೋಡಣೆ.
    // ಇದು ಯಾವಾಗಲೂ ಎರಡು-ಶಕ್ತಿಯಾಗಿದೆ ಎಂದು ನಾವು ಖಚಿತಪಡಿಸುತ್ತೇವೆ, ಏಕೆಂದರೆ API ಗೆ `posix_memalign` ನಂತಹ ಅಗತ್ಯವಿರುತ್ತದೆ ಮತ್ತು ಲೇ Layout ಟ್ ಕನ್‌ಸ್ಟ್ರಕ್ಟರ್‌ಗಳ ಮೇಲೆ ಹೇರಲು ಇದು ಸಮಂಜಸವಾದ ನಿರ್ಬಂಧವಾಗಿದೆ.
    //
    //
    // (ಆದಾಗ್ಯೂ, ನಮಗೆ ಸಾದೃಶ್ಯವಾಗಿ `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.) ಅಗತ್ಯವಿಲ್ಲ
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// ಕೊಟ್ಟಿರುವ `size` ಮತ್ತು `align` ನಿಂದ `Layout` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ, ಅಥವಾ ಈ ಕೆಳಗಿನ ಯಾವುದೇ ಷರತ್ತುಗಳನ್ನು ಪೂರೈಸದಿದ್ದರೆ `LayoutError` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ:
    ///
    /// * `align` ಶೂನ್ಯವಾಗಿರಬಾರದು,
    ///
    /// * `align` ಎರಡು ಶಕ್ತಿಯಾಗಿರಬೇಕು,
    ///
    /// * `size`, `align` ನ ಹತ್ತಿರದ ಬಹುಸಂಖ್ಯೆಯವರೆಗೆ ದುಂಡಾದಾಗ, ಉಕ್ಕಿ ಹರಿಯಬಾರದು (ಅಂದರೆ, ದುಂಡಾದ ಮೌಲ್ಯವು `usize::MAX` ಗಿಂತ ಕಡಿಮೆ ಅಥವಾ ಸಮನಾಗಿರಬೇಕು).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (ಪವರ್-ಆಫ್-ಎರಡು ಒಗ್ಗೂಡಿಸುವಿಕೆಯನ್ನು ಸೂಚಿಸುತ್ತದೆ!=0.)

        // ದುಂಡಾದ ಗಾತ್ರ:
        //   size_rounded_up=(ಗಾತ್ರ + ಒಗ್ಗೂಡಿಸಿ, 1)&! (ಒಗ್ಗೂಡಿಸಿ, 1);
        //
        // ಆ ಜೋಡಣೆ ಮೇಲಿನಿಂದ ನಮಗೆ ತಿಳಿದಿದೆ!=0.
        // ಸೇರಿಸಿದರೆ (ಜೋಡಿಸಿ, 1) ಉಕ್ಕಿ ಹರಿಯದಿದ್ದರೆ, ನಂತರ ಪೂರ್ಣಗೊಳಿಸುವುದು ಉತ್ತಮವಾಗಿರುತ್ತದೆ.
        //
        // ಇದಕ್ಕೆ ವ್ಯತಿರಿಕ್ತವಾಗಿ,&-ಮಾಸ್ಕಿಂಗ್! (ಜೋಡಿಸಿ, 1) ಕಡಿಮೆ-ಆದೇಶ-ಬಿಟ್‌ಗಳನ್ನು ಮಾತ್ರ ಕಳೆಯುತ್ತದೆ.
        // ಆದ್ದರಿಂದ ಮೊತ್ತದೊಂದಿಗೆ ಓವರ್‌ಫ್ಲೋ ಸಂಭವಿಸಿದಲ್ಲಿ, ಆ ಉಕ್ಕಿ ಹರಿಯಲು&-ಮಾಸ್ಕ್ ಸಾಕಷ್ಟು ಕಳೆಯಲು ಸಾಧ್ಯವಿಲ್ಲ.
        //
        //
        // ಮೇಲಿನ ಸಂಕಲನ ಉಕ್ಕಿ ಹರಿಯುವಿಕೆಯನ್ನು ಪರಿಶೀಲಿಸುವುದು ಅಗತ್ಯ ಮತ್ತು ಸಾಕಷ್ಟು ಎಂದು ಸೂಚಿಸುತ್ತದೆ.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // ಸುರಕ್ಷತೆ: `from_size_align_unchecked` ಗಾಗಿ ಪರಿಸ್ಥಿತಿಗಳು
        // ಮೇಲೆ ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// ಎಲ್ಲಾ ಚೆಕ್‌ಗಳನ್ನು ಬೈಪಾಸ್ ಮಾಡುವ ಮೂಲಕ ವಿನ್ಯಾಸವನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// [`Layout::from_size_align`] ನಿಂದ ಪೂರ್ವಭಾವಿಗಳನ್ನು ಪರಿಶೀಲಿಸದ ಕಾರಣ ಈ ಕಾರ್ಯವು ಅಸುರಕ್ಷಿತವಾಗಿದೆ.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `align` ಶೂನ್ಯಕ್ಕಿಂತ ದೊಡ್ಡದಾಗಿದೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// ಈ ವಿನ್ಯಾಸದ ಮೆಮೊರಿ ಬ್ಲಾಕ್‌ಗಾಗಿ ಬೈಟ್‌ಗಳಲ್ಲಿ ಕನಿಷ್ಠ ಗಾತ್ರ.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// ಈ ವಿನ್ಯಾಸದ ಮೆಮೊರಿ ಬ್ಲಾಕ್‌ಗಾಗಿ ಕನಿಷ್ಠ ಬೈಟ್ ಜೋಡಣೆ.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// `T` ಪ್ರಕಾರದ ಮೌಲ್ಯವನ್ನು ಹಿಡಿದಿಡಲು ಸೂಕ್ತವಾದ `Layout` ಅನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // ಸುರಕ್ಷತೆ: ಜೋಡಣೆಯನ್ನು Rust ನಿಂದ ಎರಡು ಮತ್ತು ಒಂದು ಶಕ್ತಿಯಾಗಿ ಖಾತರಿಪಡಿಸಲಾಗುತ್ತದೆ
        // ಗಾತ್ರ + ಅಲೈನ್ ಕಾಂಬೊ ನಮ್ಮ ವಿಳಾಸ ಜಾಗದಲ್ಲಿ ಹೊಂದಿಕೊಳ್ಳುತ್ತದೆ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.
        // ಇದರ ಪರಿಣಾಮವಾಗಿ panics ಅನ್ನು ಸಾಕಷ್ಟು ಹೊಂದುವಂತೆ ಮಾಡದಿದ್ದರೆ ಕೋಡ್ ಸೇರಿಸುವುದನ್ನು ತಪ್ಪಿಸಲು ಇಲ್ಲಿ ಪರಿಶೀಲಿಸದ ಕನ್‌ಸ್ಟ್ರಕ್ಟರ್ ಅನ್ನು ಬಳಸಿ.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` ಗಾಗಿ ಹಿಮ್ಮೇಳ ರಚನೆಯನ್ನು ನಿಯೋಜಿಸಲು ಬಳಸಬಹುದಾದ ದಾಖಲೆಯನ್ನು ವಿವರಿಸುವ ವಿನ್ಯಾಸವನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ (ಇದು trait ಅಥವಾ ಸ್ಲೈಸ್‌ನಂತಹ ಇತರ ಗಾತ್ರದ ಪ್ರಕಾರವಾಗಿರಬಹುದು).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // ಸುರಕ್ಷತೆ: ಇದು ಏಕೆ ಅಸುರಕ್ಷಿತ ರೂಪಾಂತರವನ್ನು ಬಳಸುತ್ತಿದೆ ಎಂಬುದಕ್ಕೆ `new` ನಲ್ಲಿ ತಾರ್ಕಿಕತೆಯನ್ನು ನೋಡಿ
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` ಗಾಗಿ ಹಿಮ್ಮೇಳ ರಚನೆಯನ್ನು ನಿಯೋಜಿಸಲು ಬಳಸಬಹುದಾದ ದಾಖಲೆಯನ್ನು ವಿವರಿಸುವ ವಿನ್ಯಾಸವನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ (ಇದು trait ಅಥವಾ ಸ್ಲೈಸ್‌ನಂತಹ ಇತರ ಗಾತ್ರದ ಪ್ರಕಾರವಾಗಿರಬಹುದು).
    ///
    /// # Safety
    ///
    /// ಈ ಕಾರ್ಯವು ಈ ಕೆಳಗಿನ ಷರತ್ತುಗಳನ್ನು ಹೊಂದಿದ್ದರೆ ಮಾತ್ರ ಕರೆ ಮಾಡಲು ಸುರಕ್ಷಿತವಾಗಿದೆ:
    ///
    /// - `T` `Sized` ಆಗಿದ್ದರೆ, ಈ ಕಾರ್ಯವು ಯಾವಾಗಲೂ ಕರೆ ಮಾಡಲು ಸುರಕ್ಷಿತವಾಗಿದೆ.
    /// - `T` ನ ಗಾತ್ರವಿಲ್ಲದ ಬಾಲ ಹೀಗಿದ್ದರೆ:
    ///     - [slice], ನಂತರ ಸ್ಲೈಸ್ ಬಾಲದ ಉದ್ದವು ಒಂದು ಪೂರ್ಣಾಂಕ ಪೂರ್ಣಾಂಕವಾಗಿರಬೇಕು ಮತ್ತು * ಸಂಪೂರ್ಣ ಮೌಲ್ಯದ ಗಾತ್ರ (ಡೈನಾಮಿಕ್ ಬಾಲ ಉದ್ದ + ಸ್ಥಾಯೀ ಗಾತ್ರದ ಪೂರ್ವಪ್ರತ್ಯಯ) `isize` ನಲ್ಲಿ ಹೊಂದಿಕೊಳ್ಳಬೇಕು.
    ///     - [trait object], ನಂತರ ಪಾಯಿಂಟರ್‌ನ vtable ಭಾಗವು ಗಾತ್ರೀಕರಿಸದ ಒಗ್ಗೂಡಿಸುವಿಕೆಯಿಂದ ಸ್ವಾಧೀನಪಡಿಸಿಕೊಂಡ `T` ಪ್ರಕಾರಕ್ಕೆ ಮಾನ್ಯ vtable ಗೆ ಸೂಚಿಸಬೇಕು ಮತ್ತು * ಸಂಪೂರ್ಣ ಮೌಲ್ಯದ ಗಾತ್ರ (ಡೈನಾಮಿಕ್ ಬಾಲ ಉದ್ದ + ಸ್ಥಾಯೀ ಗಾತ್ರದ ಪೂರ್ವಪ್ರತ್ಯಯ) `isize` ಗೆ ಹೊಂದಿಕೆಯಾಗಬೇಕು.
    ///
    ///     - (unstable) [extern type], ನಂತರ ಈ ಕಾರ್ಯವು ಯಾವಾಗಲೂ ಕರೆ ಮಾಡಲು ಸುರಕ್ಷಿತವಾಗಿದೆ, ಆದರೆ ಬಾಹ್ಯ ಪ್ರಕಾರದ ವಿನ್ಯಾಸವು ತಿಳಿದಿಲ್ಲದ ಕಾರಣ panic ಅಥವಾ ತಪ್ಪಾದ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸಬಹುದು.
    ///     ಬಾಹ್ಯ ಪ್ರಕಾರದ ಬಾಲವನ್ನು ಉಲ್ಲೇಖಿಸಿ ಇದು [`Layout::for_value`] ನಂತೆಯೇ ವರ್ತಿಸುತ್ತದೆ.
    ///     - ಇಲ್ಲದಿದ್ದರೆ, ಈ ಕಾರ್ಯವನ್ನು ಕರೆಯಲು ಸಂಪ್ರದಾಯಬದ್ಧವಾಗಿ ಅನುಮತಿಸಲಾಗುವುದಿಲ್ಲ.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // ಸುರಕ್ಷತೆ: ಈ ಕಾರ್ಯಗಳ ಪೂರ್ವಾಪೇಕ್ಷಿತಗಳನ್ನು ನಾವು ಕರೆ ಮಾಡುವವರಿಗೆ ತಲುಪಿಸುತ್ತೇವೆ
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // ಸುರಕ್ಷತೆ: ಇದು ಏಕೆ ಅಸುರಕ್ಷಿತ ರೂಪಾಂತರವನ್ನು ಬಳಸುತ್ತಿದೆ ಎಂಬುದಕ್ಕೆ `new` ನಲ್ಲಿ ತಾರ್ಕಿಕತೆಯನ್ನು ನೋಡಿ
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `NonNull` ಅನ್ನು ರಚಿಸುತ್ತದೆ ಅದು ತೂಗಾಡುತ್ತಿದೆ, ಆದರೆ ಈ ವಿನ್ಯಾಸಕ್ಕೆ ಉತ್ತಮವಾಗಿ ಹೊಂದಿಕೊಳ್ಳುತ್ತದೆ.
    ///
    /// ಪಾಯಿಂಟರ್ ಮೌಲ್ಯವು ಮಾನ್ಯವಾದ ಪಾಯಿಂಟರ್ ಅನ್ನು ಪ್ರತಿನಿಧಿಸಬಹುದು ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಇದರರ್ಥ ಇದನ್ನು "not yet initialized" ಸೆಂಟಿನೆಲ್ ಮೌಲ್ಯವಾಗಿ ಬಳಸಬಾರದು.
    /// ಸೋಮಾರಿಯಾಗಿ ಹಂಚುವ ಪ್ರಕಾರಗಳು ಇತರ ವಿಧಾನಗಳಿಂದ ಪ್ರಾರಂಭವನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಬೇಕು.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // ಸುರಕ್ಷತೆ: ಜೋಡಣೆ ಶೂನ್ಯವಲ್ಲ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// `self` ನಂತೆಯೇ ಅದೇ ವಿನ್ಯಾಸದ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿರುವ ದಾಖಲೆಯನ್ನು ವಿವರಿಸುವ ವಿನ್ಯಾಸವನ್ನು ರಚಿಸುತ್ತದೆ, ಆದರೆ ಇದು `align` (ಬೈಟ್‌ಗಳಲ್ಲಿ ಅಳೆಯಲಾಗುತ್ತದೆ) ಜೋಡಣೆಗೆ ಜೋಡಿಸಲ್ಪಟ್ಟಿದೆ.
    ///
    ///
    /// `self` ಈಗಾಗಲೇ ನಿಗದಿತ ಜೋಡಣೆಯನ್ನು ಪೂರೈಸಿದರೆ, ನಂತರ `self` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಹಿಂದಿರುಗಿದ ವಿನ್ಯಾಸವು ವಿಭಿನ್ನ ಜೋಡಣೆಯನ್ನು ಹೊಂದಿದೆಯೆ ಎಂದು ಪರಿಗಣಿಸದೆ, ಈ ವಿಧಾನವು ಒಟ್ಟಾರೆ ಗಾತ್ರಕ್ಕೆ ಯಾವುದೇ ಪ್ಯಾಡಿಂಗ್ ಅನ್ನು ಸೇರಿಸುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    /// ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, `K` ಗಾತ್ರ 16 ಹೊಂದಿದ್ದರೆ, `K.align_to(32)`*ಇನ್ನೂ* ಗಾತ್ರ 16 ಅನ್ನು ಹೊಂದಿರುತ್ತದೆ.
    ///
    /// `self.size()` ಮತ್ತು ಕೊಟ್ಟಿರುವ `align` ನ ಸಂಯೋಜನೆಯು [`Layout::from_size_align`] ನಲ್ಲಿ ಪಟ್ಟಿ ಮಾಡಲಾದ ಷರತ್ತುಗಳನ್ನು ಉಲ್ಲಂಘಿಸಿದರೆ ದೋಷವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// ಕೆಳಗಿನ ವಿಳಾಸವು `align` ಅನ್ನು ಪೂರೈಸುತ್ತದೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ನಾವು `self` ನಂತರ ಸೇರಿಸಬೇಕಾದ ಪ್ಯಾಡಿಂಗ್ ಪ್ರಮಾಣವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ (ಬೈಟ್‌ಗಳಲ್ಲಿ ಅಳೆಯಲಾಗುತ್ತದೆ).
    ///
    /// ಉದಾ., `self.size()` 9 ಆಗಿದ್ದರೆ, `self.padding_needed_for(4)` 3 ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಏಕೆಂದರೆ ಅದು 4-ಜೋಡಿಸಿದ ವಿಳಾಸವನ್ನು ಪಡೆಯಲು ಅಗತ್ಯವಿರುವ ಕನಿಷ್ಠ ಸಂಖ್ಯೆಯ ಪ್ಯಾಡಿಂಗ್ ಪ್ಯಾಡಿಂಗ್ ಆಗಿದೆ (ಅನುಗುಣವಾದ ಮೆಮೊರಿ ಬ್ಲಾಕ್ 4-ಜೋಡಿಸಿದ ವಿಳಾಸದಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ ಎಂದು uming ಹಿಸಿ).
    ///
    ///
    /// `align` ಪವರ್-ಆಫ್-ಎರಡು ಆಗಿಲ್ಲದಿದ್ದರೆ ಈ ಕಾರ್ಯದ ರಿಟರ್ನ್ ಮೌಲ್ಯಕ್ಕೆ ಯಾವುದೇ ಅರ್ಥವಿಲ್ಲ.
    ///
    /// ಹಿಂತಿರುಗಿದ ಮೌಲ್ಯದ ಉಪಯುಕ್ತತೆಗೆ `align` ಸಂಪೂರ್ಣ ಹಂಚಿಕೆಯ ಮೆಮೊರಿಯ ಬ್ಲಾಕ್‌ಗಾಗಿ ಆರಂಭಿಕ ವಿಳಾಸದ ಜೋಡಣೆಗೆ ಕಡಿಮೆ ಅಥವಾ ಸಮನಾಗಿರಬೇಕು ಎಂಬುದನ್ನು ಗಮನಿಸಿ.ಈ ನಿರ್ಬಂಧವನ್ನು ಪೂರೈಸುವ ಒಂದು ಮಾರ್ಗವೆಂದರೆ `align <= self.align()` ಅನ್ನು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳುವುದು.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // ದುಂಡಾದ ಮೌಲ್ಯ:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // ತದನಂತರ ನಾವು ಪ್ಯಾಡಿಂಗ್ ವ್ಯತ್ಯಾಸವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತೇವೆ: `len_rounded_up - len`.
        //
        // ನಾವು ಉದ್ದಕ್ಕೂ ಮಾಡ್ಯುಲರ್ ಅಂಕಗಣಿತವನ್ನು ಬಳಸುತ್ತೇವೆ:
        //
        // 1. align ಅನ್ನು 0 ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ, ಆದ್ದರಿಂದ ಜೋಡಿಸಿ, 1 ಯಾವಾಗಲೂ ಮಾನ್ಯವಾಗಿರುತ್ತದೆ.
        //
        // 2.
        // `len + align - 1` ಹೆಚ್ಚಿನ `align - 1` ನಿಂದ ಉಕ್ಕಿ ಹರಿಯಬಹುದು, ಆದ್ದರಿಂದ `!(align - 1)` ನೊಂದಿಗೆ&-ಮಾಸ್ಕ್ ಓವರ್‌ಫ್ಲೋ ಸಂದರ್ಭದಲ್ಲಿ, `len_rounded_up` ಸ್ವತಃ 0 ಆಗಿರುತ್ತದೆ ಎಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ.
        //
        //    ಹೀಗೆ ಹಿಂತಿರುಗಿದ ಪ್ಯಾಡಿಂಗ್, `len` ಗೆ ಸೇರಿಸಿದಾಗ, 0 ಅನ್ನು ನೀಡುತ್ತದೆ, ಇದು `align` ಜೋಡಣೆಯನ್ನು ಕ್ಷುಲ್ಲಕವಾಗಿ ಪೂರೈಸುತ್ತದೆ.
        //
        // (ಸಹಜವಾಗಿ, ಮೇಲಿನ ರೀತಿಯಲ್ಲಿ ಗಾತ್ರ ಮತ್ತು ಪ್ಯಾಡಿಂಗ್ ಉಕ್ಕಿ ಹರಿಯುವ ಮೆಮೊರಿಯ ಬ್ಲಾಕ್ಗಳನ್ನು ನಿಯೋಜಿಸುವ ಪ್ರಯತ್ನಗಳು ಹಂಚಿಕೆದಾರನು ಹೇಗಾದರೂ ದೋಷವನ್ನು ಉಂಟುಮಾಡಬಹುದು.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// ಈ ವಿನ್ಯಾಸದ ಗಾತ್ರವನ್ನು ಲೇ layout ಟ್‌ನ ಜೋಡಣೆಯ ಬಹುಭಾಗದವರೆಗೆ ಪೂರ್ಣಗೊಳಿಸುವ ಮೂಲಕ ವಿನ್ಯಾಸವನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    ///
    /// ಇದು `padding_needed_for` ನ ಫಲಿತಾಂಶವನ್ನು ಲೇ layout ಟ್‌ನ ಪ್ರಸ್ತುತ ಗಾತ್ರಕ್ಕೆ ಸೇರಿಸಲು ಸಮಾನವಾಗಿರುತ್ತದೆ.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // ಇದು ಉಕ್ಕಿ ಹರಿಯಲು ಸಾಧ್ಯವಿಲ್ಲ.ವಿನ್ಯಾಸದ ಅಸ್ಥಿರತೆಯಿಂದ ಉಲ್ಲೇಖಿಸುವುದು:
        // > `size`, `align` ನ ಹತ್ತಿರದ ಬಹುಸಂಖ್ಯೆಯವರೆಗೆ ದುಂಡಾದಾಗ,
        // > ಉಕ್ಕಿ ಹರಿಯಬಾರದು (ಅಂದರೆ, ದುಂಡಾದ ಮೌಲ್ಯವು ಕಡಿಮೆ ಇರಬೇಕು
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// `self` ನ `n` ನಿದರ್ಶನಗಳ ದಾಖಲೆಯನ್ನು ವಿವರಿಸುವ ವಿನ್ಯಾಸವನ್ನು ರಚಿಸುತ್ತದೆ, ಪ್ರತಿಯೊಂದು ನಿದರ್ಶನಕ್ಕೂ ಅದರ ವಿನಂತಿಸಿದ ಗಾತ್ರ ಮತ್ತು ಜೋಡಣೆಯನ್ನು ನೀಡಲಾಗಿದೆಯೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ಪ್ರತಿಯೊಂದರ ನಡುವೆ ಸೂಕ್ತವಾದ ಪ್ಯಾಡಿಂಗ್ ಇರುತ್ತದೆ.
    /// ಯಶಸ್ಸಿನ ಮೇಲೆ, `(k, offs)` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಅಲ್ಲಿ `k` ರಚನೆಯ ವಿನ್ಯಾಸ ಮತ್ತು `offs` ಎಂಬುದು ರಚನೆಯ ಪ್ರತಿಯೊಂದು ಅಂಶದ ಪ್ರಾರಂಭದ ನಡುವಿನ ಅಂತರವಾಗಿದೆ.
    ///
    /// ಅಂಕಗಣಿತದ ಉಕ್ಕಿ ಹರಿಯುವಾಗ, `LayoutError` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // ಇದು ಉಕ್ಕಿ ಹರಿಯಲು ಸಾಧ್ಯವಿಲ್ಲ.ವಿನ್ಯಾಸದ ಅಸ್ಥಿರತೆಯಿಂದ ಉಲ್ಲೇಖಿಸುವುದು:
        // > `size`, `align` ನ ಹತ್ತಿರದ ಬಹುಸಂಖ್ಯೆಯವರೆಗೆ ದುಂಡಾದಾಗ,
        // > ಉಕ್ಕಿ ಹರಿಯಬಾರದು (ಅಂದರೆ, ದುಂಡಾದ ಮೌಲ್ಯವು ಕಡಿಮೆ ಇರಬೇಕು
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // ಸುರಕ್ಷತೆ: self.align ಈಗಾಗಲೇ ಮಾನ್ಯವಾಗಿದೆ ಎಂದು ತಿಳಿದುಬಂದಿದೆ ಮತ್ತು ಹಂಚಿಕೆ_ ಗಾತ್ರವಾಗಿದೆ
        // ಈಗಾಗಲೇ ಪ್ಯಾಡ್ ಮಾಡಲಾಗಿದೆ.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// `self` ನ ದಾಖಲೆಯನ್ನು ವಿವರಿಸುವ ವಿನ್ಯಾಸವನ್ನು ರಚಿಸುತ್ತದೆ, ನಂತರ `next`, `next` ಅನ್ನು ಸರಿಯಾಗಿ ಜೋಡಿಸಲಾಗಿದೆಯೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ಅಗತ್ಯವಿರುವ ಯಾವುದೇ ಪ್ಯಾಡಿಂಗ್ ಸೇರಿದಂತೆ, ಆದರೆ *ಹಿಂದುಳಿದ ಪ್ಯಾಡಿಂಗ್ ಇಲ್ಲ*.
    ///
    /// ಸಿ ಪ್ರಾತಿನಿಧ್ಯ ವಿನ್ಯಾಸ `repr(C)` ಅನ್ನು ಹೊಂದಿಸಲು, ಎಲ್ಲಾ ಕ್ಷೇತ್ರಗಳೊಂದಿಗೆ ವಿನ್ಯಾಸವನ್ನು ವಿಸ್ತರಿಸಿದ ನಂತರ ನೀವು `pad_to_align` ಗೆ ಕರೆ ಮಾಡಬೇಕು.
    /// (ಡೀಫಾಲ್ಟ್ Rust ಪ್ರಾತಿನಿಧ್ಯ ವಿನ್ಯಾಸ `repr(Rust)`, as it is unspecified.) ಅನ್ನು ಹೊಂದಿಸಲು ಯಾವುದೇ ಮಾರ್ಗವಿಲ್ಲ
    ///
    /// ಎರಡೂ ಭಾಗಗಳ ಜೋಡಣೆಯನ್ನು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ಫಲಿತಾಂಶದ ವಿನ್ಯಾಸದ ಜೋಡಣೆ `self` ಮತ್ತು `next` ಗಳ ಗರಿಷ್ಠವಾಗಿರುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
    ///
    /// `Ok((k, offset))` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಅಲ್ಲಿ `k` ಎಂಬುದು ಕಾನ್ಕಟನೇಟೆಡ್ ರೆಕಾರ್ಡ್‌ನ ವಿನ್ಯಾಸವಾಗಿದೆ ಮತ್ತು `offset` ಎಂಬುದು ಬೈಟ್‌ಗಳಲ್ಲಿ, `next` ನ ಪ್ರಾರಂಭದ ಸಂಯೋಜಿತ ದಾಖಲೆಯೊಳಗೆ ಹುದುಗಿದೆ (ರೆಕಾರ್ಡ್ ಆಫ್‌ಸೆಟ್ 0 ರಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ ಎಂದು uming ಹಿಸಿ).
    ///
    ///
    /// ಅಂಕಗಣಿತದ ಉಕ್ಕಿ ಹರಿಯುವಾಗ, `LayoutError` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// `#[repr(C)]` ರಚನೆಯ ವಿನ್ಯಾಸ ಮತ್ತು ಅದರ ಕ್ಷೇತ್ರಗಳ ವಿನ್ಯಾಸಗಳಿಂದ ಕ್ಷೇತ್ರಗಳ ಆಫ್‌ಸೆಟ್‌ಗಳನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡಲು:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // `pad_to_align` ನೊಂದಿಗೆ ಅಂತಿಮಗೊಳಿಸಲು ಮರೆಯದಿರಿ!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // ಅದು ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ ಎಂದು ಪರೀಕ್ಷಿಸಿ
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// `self` ನ `n` ನಿದರ್ಶನಗಳ ದಾಖಲೆಯನ್ನು ವಿವರಿಸುವ ವಿನ್ಯಾಸವನ್ನು ರಚಿಸುತ್ತದೆ, ಪ್ರತಿಯೊಂದು ನಿದರ್ಶನಗಳ ನಡುವೆ ಯಾವುದೇ ಪ್ಯಾಡಿಂಗ್ ಇಲ್ಲ.
    ///
    /// ಗಮನಿಸಿ, `repeat` ಗಿಂತ ಭಿನ್ನವಾಗಿ, `self` ನ ಪುನರಾವರ್ತಿತ ನಿದರ್ಶನಗಳು ಸರಿಯಾಗಿ ಜೋಡಿಸಲ್ಪಟ್ಟಿದ್ದರೂ ಸಹ, `self` ನ ಪುನರಾವರ್ತಿತ ನಿದರ್ಶನಗಳು ಸರಿಯಾಗಿ ಜೋಡಿಸಲ್ಪಡುತ್ತವೆ ಎಂದು ಖಾತರಿಪಡಿಸುವುದಿಲ್ಲ.
    /// ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, `repeat_packed` ನಿಂದ ಹಿಂತಿರುಗಿಸಲಾದ ವಿನ್ಯಾಸವನ್ನು ಒಂದು ಶ್ರೇಣಿಯನ್ನು ನಿಯೋಜಿಸಲು ಬಳಸಿದರೆ, ರಚನೆಯ ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ಸರಿಯಾಗಿ ಜೋಡಿಸಲಾಗುತ್ತದೆ ಎಂದು ಖಾತರಿಪಡಿಸುವುದಿಲ್ಲ.
    ///
    /// ಅಂಕಗಣಿತದ ಉಕ್ಕಿ ಹರಿಯುವಾಗ, `LayoutError` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// `self` ಗಾಗಿ ದಾಖಲೆಯನ್ನು ವಿವರಿಸುವ ವಿನ್ಯಾಸವನ್ನು ರಚಿಸುತ್ತದೆ ಮತ್ತು ನಂತರ `next` ಎರಡರ ನಡುವೆ ಹೆಚ್ಚುವರಿ ಪ್ಯಾಡಿಂಗ್ ಇಲ್ಲ.
    /// ಯಾವುದೇ ಪ್ಯಾಡಿಂಗ್ ಅನ್ನು ಸೇರಿಸದ ಕಾರಣ, `next` ನ ಜೋಡಣೆ ಅಪ್ರಸ್ತುತವಾಗಿದೆ ಮತ್ತು ಫಲಿತಾಂಶದ ವಿನ್ಯಾಸಕ್ಕೆ *ಎಲ್ಲವನ್ನು* ಸಂಯೋಜಿಸಲಾಗಿಲ್ಲ.
    ///
    ///
    /// ಅಂಕಗಣಿತದ ಉಕ್ಕಿ ಹರಿಯುವಾಗ, `LayoutError` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// `[T; n]` ಗಾಗಿ ದಾಖಲೆಯನ್ನು ವಿವರಿಸುವ ವಿನ್ಯಾಸವನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// ಅಂಕಗಣಿತದ ಉಕ್ಕಿ ಹರಿಯುವಾಗ, `LayoutError` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align` ಅಥವಾ ಇತರ `Layout` ಕನ್‌ಸ್ಟ್ರಕ್ಟರ್‌ಗೆ ನೀಡಲಾದ ನಿಯತಾಂಕಗಳು ಅದರ ದಾಖಲಿತ ನಿರ್ಬಂಧಗಳನ್ನು ಪೂರೈಸುವುದಿಲ್ಲ.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (trait ದೋಷದ ಡೌನ್‌ಸ್ಟ್ರೀಮ್ impl ಗಾಗಿ ನಮಗೆ ಇದು ಅಗತ್ಯವಿದೆ)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}