//! impl ಚಾರ್ {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// `char` ಹೊಂದಬಹುದಾದ ಅತ್ಯಧಿಕ ಮಾನ್ಯ ಕೋಡ್ ಪಾಯಿಂಟ್.
    ///
    /// `char` ಎಂಬುದು [Unicode Scalar Value] ಆಗಿದೆ, ಇದರರ್ಥ ಅದು [Code Point], ಆದರೆ ಒಂದು ನಿರ್ದಿಷ್ಟ ವ್ಯಾಪ್ತಿಯಲ್ಲಿ ಮಾತ್ರ.
    /// `MAX` ಇದು ಮಾನ್ಯ [Unicode Scalar Value] ನ ಅತ್ಯಧಿಕ ಮಾನ್ಯ ಕೋಡ್ ಪಾಯಿಂಟ್ ಆಗಿದೆ.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` ಡಿಕೋಡಿಂಗ್ ದೋಷವನ್ನು ಪ್ರತಿನಿಧಿಸಲು ಯೂನಿಕೋಡ್‌ನಲ್ಲಿ () ಅನ್ನು ಬಳಸಲಾಗುತ್ತದೆ.
    ///
    /// ಉದಾಹರಣೆಗೆ, [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) ಗೆ ಕೆಟ್ಟದಾಗಿ ರೂಪುಗೊಂಡ UTF-8 ಬೈಟ್‌ಗಳನ್ನು ನೀಡುವಾಗ ಅದು ಸಂಭವಿಸಬಹುದು.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// `char` ಮತ್ತು `str` ವಿಧಾನಗಳ ಯುನಿಕೋಡ್ ಭಾಗಗಳನ್ನು ಆಧರಿಸಿದ [Unicode](http://www.unicode.org/) ನ ಆವೃತ್ತಿ.
    ///
    /// ಯೂನಿಕೋಡ್‌ನ ಹೊಸ ಆವೃತ್ತಿಗಳನ್ನು ನಿಯಮಿತವಾಗಿ ಬಿಡುಗಡೆ ಮಾಡಲಾಗುತ್ತದೆ ಮತ್ತು ತರುವಾಯ ಯುನಿಕೋಡ್‌ಗೆ ಅನುಗುಣವಾಗಿ ಪ್ರಮಾಣಿತ ಗ್ರಂಥಾಲಯದಲ್ಲಿನ ಎಲ್ಲಾ ವಿಧಾನಗಳನ್ನು ನವೀಕರಿಸಲಾಗುತ್ತದೆ.
    /// ಆದ್ದರಿಂದ ಕೆಲವು `char` ಮತ್ತು `str` ವಿಧಾನಗಳ ವರ್ತನೆ ಮತ್ತು ಕಾಲಾನಂತರದಲ್ಲಿ ಈ ಸ್ಥಿರ ಬದಲಾವಣೆಗಳ ಮೌಲ್ಯ.
    /// ಇದನ್ನು * ಬ್ರೇಕಿಂಗ್ ಬದಲಾವಣೆ ಎಂದು ಪರಿಗಣಿಸಲಾಗುವುದಿಲ್ಲ.
    ///
    /// ಆವೃತ್ತಿ ಸಂಖ್ಯೆಯ ಯೋಜನೆಯನ್ನು [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) ನಲ್ಲಿ ವಿವರಿಸಲಾಗಿದೆ.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// `iter` ನಲ್ಲಿ UTF-16 ಎನ್ಕೋಡ್ ಮಾಡಲಾದ ಕೋಡ್ ಪಾಯಿಂಟ್‌ಗಳ ಮೇಲೆ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ, ಜೋಡಿಯಾಗದ ಬಾಡಿಗೆದಾರರನ್ನು `Err`s ಎಂದು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// `Err` ಫಲಿತಾಂಶಗಳನ್ನು ಬದಲಿ ಅಕ್ಷರದಿಂದ ಬದಲಾಯಿಸುವ ಮೂಲಕ ನಷ್ಟದ ಡಿಕೋಡರ್ ಪಡೆಯಬಹುದು:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32` ಅನ್ನು `char` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ಎಲ್ಲಾ `ಚಾರ್`ಗಳು ಮಾನ್ಯ [`u32`] ಗಳು ಎಂದು ಗಮನಿಸಿ, ಮತ್ತು ಇವುಗಳನ್ನು ಒಂದಕ್ಕೆ ಬಿತ್ತರಿಸಬಹುದು
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// ಆದಾಗ್ಯೂ, ರಿವರ್ಸ್ ನಿಜವಲ್ಲ: ಎಲ್ಲಾ ಮಾನ್ಯ [`u32`] ಗಳು ಮಾನ್ಯ`ಚಾರ್` ಗಳು ಅಲ್ಲ.
    /// `from_u32()` `char` ಗೆ ಇನ್ಪುಟ್ ಮಾನ್ಯ ಮೌಲ್ಯವಲ್ಲದಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಪರಿಶೀಲನೆಗಳನ್ನು ನಿರ್ಲಕ್ಷಿಸುವ ಈ ಕಾರ್ಯದ ಅಸುರಕ್ಷಿತ ಆವೃತ್ತಿಗೆ, [`from_u32_unchecked`] ನೋಡಿ.
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// ಇನ್ಪುಟ್ ಮಾನ್ಯ `char` ಆಗದಿದ್ದಾಗ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// ಸಿಂಧುತ್ವವನ್ನು ನಿರ್ಲಕ್ಷಿಸಿ, `u32` ಅನ್ನು `char` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ಎಲ್ಲಾ `ಚಾರ್`ಗಳು ಮಾನ್ಯ [`u32`] ಗಳು ಎಂದು ಗಮನಿಸಿ, ಮತ್ತು ಇವುಗಳನ್ನು ಒಂದಕ್ಕೆ ಬಿತ್ತರಿಸಬಹುದು
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// ಆದಾಗ್ಯೂ, ರಿವರ್ಸ್ ನಿಜವಲ್ಲ: ಎಲ್ಲಾ ಮಾನ್ಯ [`u32`] ಗಳು ಮಾನ್ಯ`ಚಾರ್` ಗಳು ಅಲ್ಲ.
    /// `from_u32_unchecked()` ಇದನ್ನು ನಿರ್ಲಕ್ಷಿಸುತ್ತದೆ ಮತ್ತು `char` ಗೆ ಕುರುಡಾಗಿ ಬಿತ್ತರಿಸುತ್ತದೆ, ಬಹುಶಃ ಅಮಾನ್ಯವಾದುದನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    ///
    /// # Safety
    ///
    /// ಈ ಕಾರ್ಯವು ಅಸುರಕ್ಷಿತವಾಗಿದೆ, ಏಕೆಂದರೆ ಇದು ಅಮಾನ್ಯ `char` ಮೌಲ್ಯಗಳನ್ನು ರಚಿಸಬಹುದು.
    ///
    /// ಈ ಕಾರ್ಯದ ಸುರಕ್ಷಿತ ಆವೃತ್ತಿಗಾಗಿ, [`from_u32`] ಕಾರ್ಯವನ್ನು ನೋಡಿ.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರಿಂದ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// ಕೊಟ್ಟಿರುವ ರಾಡಿಕ್ಸ್‌ನಲ್ಲಿರುವ ಅಂಕಿಯನ್ನು `char` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ಇಲ್ಲಿ 'radix' ಅನ್ನು ಕೆಲವೊಮ್ಮೆ 'base' ಎಂದೂ ಕರೆಯಲಾಗುತ್ತದೆ.
    /// ಎರಡರ ರಾಡಿಕ್ಸ್ ಕೆಲವು ಸಾಮಾನ್ಯ ಮೌಲ್ಯಗಳನ್ನು ನೀಡಲು ಬೈನರಿ ಸಂಖ್ಯೆ, ಹತ್ತು, ದಶಮಾಂಶ ಮತ್ತು ಹದಿನಾರು, ಹೆಕ್ಸಾಡೆಸಿಮಲ್ನ ರಾಡಿಕ್ಸ್ ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ.
    ///
    /// ಅನಿಯಂತ್ರಿತ ರೇಡಿಸ್‌ಗಳನ್ನು ಬೆಂಬಲಿಸಲಾಗುತ್ತದೆ.
    ///
    /// `from_digit()` ಕೊಟ್ಟಿರುವ ರಾಡಿಕ್ಸ್‌ನಲ್ಲಿ ಇನ್‌ಪುಟ್ ಅಂಕೆ ಇಲ್ಲದಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// 36 ಕ್ಕಿಂತ ದೊಡ್ಡದಾದ ರಾಡಿಕ್ಸ್ ನೀಡಿದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // ದಶಮಾಂಶ 11 ಬೇಸ್ 16 ರಲ್ಲಿ ಒಂದೇ ಅಂಕೆ
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// ಇನ್ಪುಟ್ ಅಂಕಿಯಲ್ಲದಿದ್ದಾಗ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// ದೊಡ್ಡ ರಾಡಿಕ್ಸ್ ಅನ್ನು ಹಾದುಹೋಗುತ್ತದೆ, ಇದು panic ಗೆ ಕಾರಣವಾಗುತ್ತದೆ:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// ಕೊಟ್ಟಿರುವ ರಾಡಿಕ್ಸ್‌ನಲ್ಲಿ `char` ಒಂದು ಅಂಕಿಯಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ.
    ///
    /// ಇಲ್ಲಿ 'radix' ಅನ್ನು ಕೆಲವೊಮ್ಮೆ 'base' ಎಂದೂ ಕರೆಯಲಾಗುತ್ತದೆ.
    /// ಎರಡರ ರಾಡಿಕ್ಸ್ ಕೆಲವು ಸಾಮಾನ್ಯ ಮೌಲ್ಯಗಳನ್ನು ನೀಡಲು ಬೈನರಿ ಸಂಖ್ಯೆ, ಹತ್ತು, ದಶಮಾಂಶ ಮತ್ತು ಹದಿನಾರು, ಹೆಕ್ಸಾಡೆಸಿಮಲ್ನ ರಾಡಿಕ್ಸ್ ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ.
    ///
    /// ಅನಿಯಂತ್ರಿತ ರೇಡಿಸ್‌ಗಳನ್ನು ಬೆಂಬಲಿಸಲಾಗುತ್ತದೆ.
    ///
    /// [`is_numeric()`] ಗೆ ಹೋಲಿಸಿದರೆ, ಈ ಕಾರ್ಯವು `0-9`, `a-z` ಮತ್ತು `A-Z` ಅಕ್ಷರಗಳನ್ನು ಮಾತ್ರ ಗುರುತಿಸುತ್ತದೆ.
    ///
    /// 'Digit' ಈ ಕೆಳಗಿನ ಅಕ್ಷರಗಳು ಮಾತ್ರ ಎಂದು ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿದೆ:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit' ನ ಹೆಚ್ಚು ಸಮಗ್ರ ತಿಳುವಳಿಕೆಗಾಗಿ, [`is_numeric()`] ನೋಡಿ.
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// 36 ಕ್ಕಿಂತ ದೊಡ್ಡದಾದ ರಾಡಿಕ್ಸ್ ನೀಡಿದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// ದೊಡ್ಡ ರಾಡಿಕ್ಸ್ ಅನ್ನು ಹಾದುಹೋಗುತ್ತದೆ, ಇದು panic ಗೆ ಕಾರಣವಾಗುತ್ತದೆ:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// ಕೊಟ್ಟಿರುವ ರಾಡಿಕ್ಸ್‌ನಲ್ಲಿ `char` ಅನ್ನು ಅಂಕೆಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ಇಲ್ಲಿ 'radix' ಅನ್ನು ಕೆಲವೊಮ್ಮೆ 'base' ಎಂದೂ ಕರೆಯಲಾಗುತ್ತದೆ.
    /// ಎರಡರ ರಾಡಿಕ್ಸ್ ಕೆಲವು ಸಾಮಾನ್ಯ ಮೌಲ್ಯಗಳನ್ನು ನೀಡಲು ಬೈನರಿ ಸಂಖ್ಯೆ, ಹತ್ತು, ದಶಮಾಂಶ ಮತ್ತು ಹದಿನಾರು, ಹೆಕ್ಸಾಡೆಸಿಮಲ್ನ ರಾಡಿಕ್ಸ್ ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ.
    ///
    /// ಅನಿಯಂತ್ರಿತ ರೇಡಿಸ್‌ಗಳನ್ನು ಬೆಂಬಲಿಸಲಾಗುತ್ತದೆ.
    ///
    /// 'Digit' ಈ ಕೆಳಗಿನ ಅಕ್ಷರಗಳು ಮಾತ್ರ ಎಂದು ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿದೆ:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// ಕೊಟ್ಟಿರುವ ರಾಡಿಕ್ಸ್‌ನಲ್ಲಿ `char` ಒಂದು ಅಂಕಿಯನ್ನು ಉಲ್ಲೇಖಿಸದಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Panics
    ///
    /// 36 ಕ್ಕಿಂತ ದೊಡ್ಡದಾದ ರಾಡಿಕ್ಸ್ ನೀಡಿದರೆ Panics.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// ಅಂಕಿಯಲ್ಲದ ಫಲಿತಾಂಶವನ್ನು ಹಾದುಹೋಗುವುದು ವಿಫಲಗೊಳ್ಳುತ್ತದೆ:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// ದೊಡ್ಡ ರಾಡಿಕ್ಸ್ ಅನ್ನು ಹಾದುಹೋಗುತ್ತದೆ, ಇದು panic ಗೆ ಕಾರಣವಾಗುತ್ತದೆ:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // `radix` ಸ್ಥಿರ ಮತ್ತು 10 ಅಥವಾ ಚಿಕ್ಕದಾದ ಸಂದರ್ಭಗಳಲ್ಲಿ ಮರಣದಂಡನೆ ವೇಗವನ್ನು ಸುಧಾರಿಸಲು ಕೋಡ್ ಅನ್ನು ಇಲ್ಲಿ ವಿಭಜಿಸಲಾಗಿದೆ
        //
        let val = if likely(radix <= 10) {
            // ಅಂಕಿಯಲ್ಲದಿದ್ದರೆ, ರಾಡಿಕ್ಸ್‌ಗಿಂತ ಹೆಚ್ಚಿನ ಸಂಖ್ಯೆಯನ್ನು ರಚಿಸಲಾಗುತ್ತದೆ.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// ಒಂದು ಪಾತ್ರದ ಹೆಕ್ಸಾಡೆಸಿಮಲ್ ಯೂನಿಕೋಡ್ ತಪ್ಪಿಸಿಕೊಳ್ಳುವಿಕೆಯನ್ನು `ಚಾರ್` ಎಂದು ನೀಡುವ ಇಟರೇಟರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಇದು `\u{NNNNNN}` ರೂಪದ Rust ಸಿಂಟ್ಯಾಕ್ಸ್‌ನೊಂದಿಗೆ ಅಕ್ಷರಗಳನ್ನು ತಪ್ಪಿಸುತ್ತದೆ, ಅಲ್ಲಿ `NNNNNN` ಒಂದು ಹೆಕ್ಸಾಡೆಸಿಮಲ್ ಪ್ರಾತಿನಿಧ್ಯವಾಗಿದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಪುನರಾವರ್ತಕರಾಗಿ:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ಅನ್ನು ನೇರವಾಗಿ ಬಳಸುವುದು:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// ಎರಡೂ ಇದಕ್ಕೆ ಸಮಾನವಾಗಿವೆ:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` ಬಳಸುವುದು:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // ಅಥವಾ-ಇಂಗ್ 1 ಸಿ==0 ಗಾಗಿ ಒಂದು ಅಂಕಿಯನ್ನು ಮುದ್ರಿಸಬೇಕು ಎಂದು ಕೋಡ್ ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ ಮತ್ತು (ಅದು ಒಂದೇ)(31, 32) ಒಳಹರಿವನ್ನು ತಪ್ಪಿಸುತ್ತದೆ
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // ಅತ್ಯಂತ ಗಮನಾರ್ಹವಾದ ಹೆಕ್ಸ್ ಅಂಕಿಯ ಸೂಚ್ಯಂಕ
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// ವಿಸ್ತೃತ ಗ್ರ್ಯಾಫೀಮ್ ಕೋಡ್‌ಪಾಯಿಂಟ್‌ಗಳನ್ನು ತಪ್ಪಿಸಿಕೊಳ್ಳಲು ಐಚ್ ally ಿಕವಾಗಿ ಅನುಮತಿಸುವ `escape_debug` ನ ವಿಸ್ತೃತ ಆವೃತ್ತಿ.
    /// ಸ್ಟ್ರಿಂಗ್‌ನ ಪ್ರಾರಂಭದಲ್ಲಿರುವಾಗ ಗುರುತು ಹಾಕದಂತಹ ಅಕ್ಷರಗಳನ್ನು ಉತ್ತಮವಾಗಿ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಲು ಇದು ನಮಗೆ ಅನುಮತಿಸುತ್ತದೆ.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// ಪಾತ್ರದ ಅಕ್ಷರಶಃ ಎಸ್ಕೇಪ್ ಕೋಡ್ ಅನ್ನು `ಚಾರ್` ಎಂದು ನೀಡುವ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಇದು `str` ಅಥವಾ `char` ನ `Debug` ಅನುಷ್ಠಾನಗಳಿಗೆ ಹೋಲುವ ಅಕ್ಷರಗಳಿಂದ ತಪ್ಪಿಸಿಕೊಳ್ಳುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ಪುನರಾವರ್ತಕರಾಗಿ:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ಅನ್ನು ನೇರವಾಗಿ ಬಳಸುವುದು:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// ಎರಡೂ ಇದಕ್ಕೆ ಸಮಾನವಾಗಿವೆ:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` ಬಳಸುವುದು:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// ಪಾತ್ರದ ಅಕ್ಷರಶಃ ಎಸ್ಕೇಪ್ ಕೋಡ್ ಅನ್ನು `ಚಾರ್` ಎಂದು ನೀಡುವ ಪುನರಾವರ್ತಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// C ++ 11 ಮತ್ತು ಅಂತಹುದೇ ಸಿ-ಫ್ಯಾಮಿಲಿ ಭಾಷೆಗಳು ಸೇರಿದಂತೆ ವಿವಿಧ ಭಾಷೆಗಳಲ್ಲಿ ಕಾನೂನುಬದ್ಧವಾಗಿರುವ ಅಕ್ಷರಗಳನ್ನು ಉತ್ಪಾದಿಸುವ ಪಕ್ಷಪಾತದೊಂದಿಗೆ ಪೂರ್ವನಿಯೋಜಿತತೆಯನ್ನು ಆಯ್ಕೆ ಮಾಡಲಾಗಿದೆ.
    /// ನಿಖರವಾದ ನಿಯಮಗಳು ಹೀಗಿವೆ:
    ///
    /// * ಟ್ಯಾಬ್ ಅನ್ನು `\t` ಎಂದು ತಪ್ಪಿಸಲಾಗಿದೆ.
    /// * ಕ್ಯಾರೇಜ್ ರಿಟರ್ನ್ ಅನ್ನು `\r` ಎಂದು ತಪ್ಪಿಸಲಾಗಿದೆ.
    /// * ಲೈನ್ ಫೀಡ್ ಅನ್ನು `\n` ಎಂದು ತಪ್ಪಿಸಲಾಗಿದೆ.
    /// * ಏಕ ಉಲ್ಲೇಖವನ್ನು `\'` ಎಂದು ತಪ್ಪಿಸಲಾಗಿದೆ.
    /// * `\"` ಎಂದು ಡಬಲ್ ಉಲ್ಲೇಖ ತಪ್ಪಿಸಲಾಗಿದೆ.
    /// * ಬ್ಯಾಕ್ಸ್‌ಲ್ಯಾಶ್ ಅನ್ನು `\\` ಎಂದು ತಪ್ಪಿಸಲಾಗಿದೆ.
    /// * 'ಮುದ್ರಿಸಬಹುದಾದ ASCII' ಶ್ರೇಣಿಯ `0x20` .. `0x7e` ಒಳಗೊಂಡ ಯಾವುದೇ ಅಕ್ಷರ ತಪ್ಪಿಸಿಕೊಂಡಿಲ್ಲ.
    /// * ಎಲ್ಲಾ ಇತರ ಪಾತ್ರಗಳಿಗೆ ಹೆಕ್ಸಾಡೆಸಿಮಲ್ ಯೂನಿಕೋಡ್ ತಪ್ಪಿಸಿಕೊಳ್ಳುತ್ತದೆ;[`escape_unicode`] ನೋಡಿ.
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// ಪುನರಾವರ್ತಕರಾಗಿ:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ಅನ್ನು ನೇರವಾಗಿ ಬಳಸುವುದು:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// ಎರಡೂ ಇದಕ್ಕೆ ಸಮಾನವಾಗಿವೆ:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` ಬಳಸುವುದು:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// UTF-8 ನಲ್ಲಿ ಎನ್ಕೋಡ್ ಮಾಡಿದ್ದರೆ ಈ `char` ಗೆ ಅಗತ್ಯವಿರುವ ಬೈಟ್‌ಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಆ ಸಂಖ್ಯೆಯ ಬೈಟ್‌ಗಳು ಯಾವಾಗಲೂ 1 ಮತ್ತು 4 ರ ನಡುವೆ ಇರುತ್ತವೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` ಪ್ರಕಾರವು ಅದರ ವಿಷಯಗಳು UTF-8 ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತದೆ, ಆದ್ದರಿಂದ ಪ್ರತಿ ಕೋಡ್ ಪಾಯಿಂಟ್ ಅನ್ನು `&str` ನಲ್ಲಿಯೇ `char` Vs ಎಂದು ಪ್ರತಿನಿಧಿಸಿದರೆ ಅದು ತೆಗೆದುಕೊಳ್ಳುವ ಉದ್ದವನ್ನು ನಾವು ಹೋಲಿಸಬಹುದು:
    ///
    ///
    /// ```
    /// // ಅಕ್ಷರಗಳಾಗಿ
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // ಎರಡನ್ನೂ ಮೂರು ಬೈಟ್‌ಗಳಾಗಿ ನಿರೂಪಿಸಬಹುದು
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // &str ಆಗಿ, ಈ ಎರಡನ್ನು UTF-8 ನಲ್ಲಿ ಎನ್ಕೋಡ್ ಮಾಡಲಾಗಿದೆ
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // ಅವರು ಒಟ್ಟು ಆರು ಬೈಟ್‌ಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತಾರೆ ಎಂದು ನಾವು ನೋಡಬಹುದು ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... &str ನಂತೆಯೇ
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// UTF-16 ನಲ್ಲಿ ಎನ್ಕೋಡ್ ಮಾಡಿದ್ದರೆ ಈ `char` ಗೆ ಅಗತ್ಯವಿರುವ 16-ಬಿಟ್ ಕೋಡ್ ಘಟಕಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// ಈ ಪರಿಕಲ್ಪನೆಯ ಹೆಚ್ಚಿನ ವಿವರಣೆಗಾಗಿ [`len_utf8()`] ಗಾಗಿ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
    /// ಈ ಕಾರ್ಯವು ಕನ್ನಡಿಯಾಗಿದೆ, ಆದರೆ UTF-8 ಬದಲಿಗೆ UTF-16 ಗೆ.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// ಒದಗಿಸಿದ ಬೈಟ್ ಬಫರ್‌ಗೆ ಈ ಅಕ್ಷರವನ್ನು UTF-8 ಎಂದು ಎನ್‌ಕೋಡ್ ಮಾಡುತ್ತದೆ, ತದನಂತರ ಎನ್‌ಕೋಡ್ ಮಾಡಲಾದ ಅಕ್ಷರವನ್ನು ಹೊಂದಿರುವ ಬಫರ್‌ನ ಚಂದಾದಾರಿಕೆಯನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Panics
    ///
    /// ಬಫರ್ ಸಾಕಷ್ಟು ದೊಡ್ಡದಾಗದಿದ್ದರೆ Panics.
    /// ಯಾವುದೇ `char` ಅನ್ನು ಎನ್ಕೋಡ್ ಮಾಡಲು ಸಾಕಷ್ಟು ಉದ್ದದ ಬಫರ್ ದೊಡ್ಡದಾಗಿದೆ.
    ///
    /// # Examples
    ///
    /// ಈ ಎರಡೂ ಉದಾಹರಣೆಗಳಲ್ಲಿ, 'ß' ಎನ್ಕೋಡ್ ಮಾಡಲು ಎರಡು ಬೈಟ್‌ಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// ತುಂಬಾ ಚಿಕ್ಕದಾದ ಬಫರ್:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // ಸುರಕ್ಷತೆ: `char` ಬಾಡಿಗೆ ಅಲ್ಲ, ಆದ್ದರಿಂದ ಇದು ಮಾನ್ಯ UTF-8 ಆಗಿದೆ.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// ಒದಗಿಸಿದ `u16` ಬಫರ್‌ಗೆ ಈ ಅಕ್ಷರವನ್ನು UTF-16 ಎಂದು ಎನ್‌ಕೋಡ್ ಮಾಡುತ್ತದೆ, ತದನಂತರ ಎನ್‌ಕೋಡ್ ಮಾಡಲಾದ ಅಕ್ಷರವನ್ನು ಹೊಂದಿರುವ ಬಫರ್‌ನ ಚಂದಾದಾರಿಕೆಯನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Panics
    ///
    /// ಬಫರ್ ಸಾಕಷ್ಟು ದೊಡ್ಡದಾಗದಿದ್ದರೆ Panics.
    /// ಯಾವುದೇ `char` ಅನ್ನು ಎನ್ಕೋಡ್ ಮಾಡಲು ಉದ್ದ 2 ರ ಬಫರ್ ದೊಡ್ಡದಾಗಿದೆ.
    ///
    /// # Examples
    ///
    /// ಈ ಎರಡೂ ಉದಾಹರಣೆಗಳಲ್ಲಿ, '𝕊' ಎನ್ಕೋಡ್ ಮಾಡಲು ಎರಡು `u16` ಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// ತುಂಬಾ ಚಿಕ್ಕದಾದ ಬಫರ್:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// ಈ `char` ಗೆ `Alphabetic` ಆಸ್ತಿ ಇದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `Alphabetic` ಇದನ್ನು [Unicode Standard] ನ ಅಧ್ಯಾಯ 4 (ಅಕ್ಷರ ಗುಣಲಕ್ಷಣಗಳು) ನಲ್ಲಿ ವಿವರಿಸಲಾಗಿದೆ ಮತ್ತು [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] ನಲ್ಲಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿದೆ.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // ಪ್ರೀತಿ ಅನೇಕ ವಿಷಯಗಳು, ಆದರೆ ಅದು ವರ್ಣಮಾಲೆಯಲ್ಲ
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// ಈ `char` ಗೆ `Lowercase` ಆಸ್ತಿ ಇದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `Lowercase` ಇದನ್ನು [Unicode Standard] ನ ಅಧ್ಯಾಯ 4 (ಅಕ್ಷರ ಗುಣಲಕ್ಷಣಗಳು) ನಲ್ಲಿ ವಿವರಿಸಲಾಗಿದೆ ಮತ್ತು [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] ನಲ್ಲಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿದೆ.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // ವಿವಿಧ ಚೀನೀ ಲಿಪಿಗಳು ಮತ್ತು ವಿರಾಮಚಿಹ್ನೆಗಳು ಪ್ರಕರಣವನ್ನು ಹೊಂದಿಲ್ಲ, ಮತ್ತು ಹೀಗೆ:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// ಈ `char` ಗೆ `Uppercase` ಆಸ್ತಿ ಇದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `Uppercase` ಇದನ್ನು [Unicode Standard] ನ ಅಧ್ಯಾಯ 4 (ಅಕ್ಷರ ಗುಣಲಕ್ಷಣಗಳು) ನಲ್ಲಿ ವಿವರಿಸಲಾಗಿದೆ ಮತ್ತು [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] ನಲ್ಲಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿದೆ.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // ವಿವಿಧ ಚೀನೀ ಲಿಪಿಗಳು ಮತ್ತು ವಿರಾಮಚಿಹ್ನೆಗಳು ಪ್ರಕರಣವನ್ನು ಹೊಂದಿಲ್ಲ, ಮತ್ತು ಹೀಗೆ:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// ಈ `char` ಗೆ `White_Space` ಆಸ್ತಿ ಇದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `White_Space` [Unicode Character Database][ucd] [`PropList.txt`] ನಲ್ಲಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿದೆ.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // ಮುರಿಯದ ಸ್ಥಳ
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// ಈ `char` [`is_alphabetic()`] ಅಥವಾ [`is_numeric()`] ಅನ್ನು ತೃಪ್ತಿಪಡಿಸಿದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// ನಿಯಂತ್ರಣ ಸಂಕೇತಗಳಿಗಾಗಿ ಈ `char` ಸಾಮಾನ್ಯ ವರ್ಗವನ್ನು ಹೊಂದಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ನಿಯಂತ್ರಣ ಸಂಕೇತಗಳನ್ನು (`Cc` ನ ಸಾಮಾನ್ಯ ವರ್ಗದೊಂದಿಗೆ ಕೋಡ್ ಪಾಯಿಂಟ್‌ಗಳು) [Unicode Standard] ನ ಅಧ್ಯಾಯ 4 (ಅಕ್ಷರ ಗುಣಲಕ್ಷಣಗಳು) ನಲ್ಲಿ ವಿವರಿಸಲಾಗಿದೆ ಮತ್ತು [Unicode Character Database][ucd] [`UnicodeData.txt`] ನಲ್ಲಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿದೆ.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// // ಯು + 009 ಸಿ, STRING ಟರ್ಮಿನೇಟರ್
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// ಈ `char` ಗೆ `Grapheme_Extend` ಆಸ್ತಿ ಇದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `Grapheme_Extend` ಇದನ್ನು [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] ನಲ್ಲಿ ವಿವರಿಸಲಾಗಿದೆ ಮತ್ತು [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] ನಲ್ಲಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿದೆ.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// ಈ `char` ಸಂಖ್ಯೆಗಳಿಗೆ ಸಾಮಾನ್ಯ ವರ್ಗಗಳಲ್ಲಿ ಒಂದನ್ನು ಹೊಂದಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಸಂಖ್ಯೆಗಳಿಗೆ ಸಾಮಾನ್ಯ ವರ್ಗಗಳು (ದಶಮಾಂಶ ಅಂಕೆಗಳಿಗೆ `Nd`, ಅಕ್ಷರದಂತಹ ಸಂಖ್ಯಾ ಅಕ್ಷರಗಳಿಗೆ `Nl`, ಮತ್ತು ಇತರ ಸಂಖ್ಯಾ ಅಕ್ಷರಗಳಿಗೆ `No`) ಅನ್ನು [Unicode Character Database][ucd] [`UnicodeData.txt`] ನಲ್ಲಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿದೆ.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// ಈ `char` ನ ಸಣ್ಣಕ್ಷರ ಮ್ಯಾಪಿಂಗ್ ಅನ್ನು ಒಂದು ಅಥವಾ ಹೆಚ್ಚಿನದಾಗಿ ನೀಡುವ ಇಟರೇಟರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ
    /// `char`s.
    ///
    /// ಈ `char` ಲೋವರ್ಕೇಸ್ ಮ್ಯಾಪಿಂಗ್ ಹೊಂದಿಲ್ಲದಿದ್ದರೆ, ಪುನರಾವರ್ತಕವು ಅದೇ `char` ಅನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// ಈ `char` [Unicode Character Database][ucd] [`UnicodeData.txt`] ನೀಡಿದ ಒನ್-ಟು-ಒನ್ ಲೋವರ್ಕೇಸ್ ಮ್ಯಾಪಿಂಗ್ ಹೊಂದಿದ್ದರೆ, ಪುನರಾವರ್ತಕವು `char` ಅನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// ಈ `char` ಗೆ ವಿಶೇಷ ಪರಿಗಣನೆಗಳು ಅಗತ್ಯವಿದ್ದರೆ (ಉದಾ. ಬಹು `ಚಾರ್`ಗಳು) ಪುನರಾವರ್ತಕವು [`SpecialCasing.txt`] ನೀಡಿದ`ಚಾರ್` (ಗಳನ್ನು) ನೀಡುತ್ತದೆ.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// ಈ ಕಾರ್ಯಾಚರಣೆಯು ಟೈಲರಿಂಗ್ ಇಲ್ಲದೆ ಬೇಷರತ್ತಾದ ಮ್ಯಾಪಿಂಗ್ ಅನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.ಅಂದರೆ, ಪರಿವರ್ತನೆ ಸಂದರ್ಭ ಮತ್ತು ಭಾಷೆಯಿಂದ ಸ್ವತಂತ್ರವಾಗಿದೆ.
    ///
    /// [Unicode Standard] ನಲ್ಲಿ, ಅಧ್ಯಾಯ 4 (ಅಕ್ಷರ ಗುಣಲಕ್ಷಣಗಳು) ಸಾಮಾನ್ಯವಾಗಿ ಕೇಸ್ ಮ್ಯಾಪಿಂಗ್ ಅನ್ನು ಚರ್ಚಿಸುತ್ತದೆ ಮತ್ತು ಅಧ್ಯಾಯ 3 (Conformance) ಕೇಸ್ ಪರಿವರ್ತನೆಗಾಗಿ ಡೀಫಾಲ್ಟ್ ಅಲ್ಗಾರಿದಮ್ ಅನ್ನು ಚರ್ಚಿಸುತ್ತದೆ.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// ಪುನರಾವರ್ತಕರಾಗಿ:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ಅನ್ನು ನೇರವಾಗಿ ಬಳಸುವುದು:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// ಎರಡೂ ಇದಕ್ಕೆ ಸಮಾನವಾಗಿವೆ:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` ಬಳಸುವುದು:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // ಕೆಲವೊಮ್ಮೆ ಫಲಿತಾಂಶವು ಒಂದಕ್ಕಿಂತ ಹೆಚ್ಚು ಅಕ್ಷರಗಳನ್ನು ಹೊಂದಿರುತ್ತದೆ:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // ದೊಡ್ಡಕ್ಷರ ಮತ್ತು ಸಣ್ಣ ಅಕ್ಷರಗಳೆರಡನ್ನೂ ಹೊಂದಿರದ ಅಕ್ಷರಗಳು ತಮ್ಮನ್ನು ತಾವು ಪರಿವರ್ತಿಸಿಕೊಳ್ಳುತ್ತವೆ.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// ಈ `char` ನ ದೊಡ್ಡಕ್ಷರ ಮ್ಯಾಪಿಂಗ್ ಅನ್ನು ಒಂದು ಅಥವಾ ಹೆಚ್ಚಿನದಾಗಿ ನೀಡುವ ಇಟರೇಟರ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ
    /// `char`s.
    ///
    /// ಈ `char` ದೊಡ್ಡಕ್ಷರ ಮ್ಯಾಪಿಂಗ್ ಹೊಂದಿಲ್ಲದಿದ್ದರೆ, ಪುನರಾವರ್ತಕವು ಅದೇ `char` ಅನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// ಈ `char` ಗೆ [Unicode Character Database][ucd] [`UnicodeData.txt`] ನೀಡಿದ ಒನ್ ಟು ಒನ್ ದೊಡ್ಡಕ್ಷರ ಮ್ಯಾಪಿಂಗ್ ಇದ್ದರೆ, ಪುನರಾವರ್ತಕವು `char` ಅನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// ಈ `char` ಗೆ ವಿಶೇಷ ಪರಿಗಣನೆಗಳು ಅಗತ್ಯವಿದ್ದರೆ (ಉದಾ. ಬಹು `ಚಾರ್`ಗಳು) ಪುನರಾವರ್ತಕವು [`SpecialCasing.txt`] ನೀಡಿದ`ಚಾರ್` (ಗಳನ್ನು) ನೀಡುತ್ತದೆ.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// ಈ ಕಾರ್ಯಾಚರಣೆಯು ಟೈಲರಿಂಗ್ ಇಲ್ಲದೆ ಬೇಷರತ್ತಾದ ಮ್ಯಾಪಿಂಗ್ ಅನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.ಅಂದರೆ, ಪರಿವರ್ತನೆ ಸಂದರ್ಭ ಮತ್ತು ಭಾಷೆಯಿಂದ ಸ್ವತಂತ್ರವಾಗಿದೆ.
    ///
    /// [Unicode Standard] ನಲ್ಲಿ, ಅಧ್ಯಾಯ 4 (ಅಕ್ಷರ ಗುಣಲಕ್ಷಣಗಳು) ಸಾಮಾನ್ಯವಾಗಿ ಕೇಸ್ ಮ್ಯಾಪಿಂಗ್ ಅನ್ನು ಚರ್ಚಿಸುತ್ತದೆ ಮತ್ತು ಅಧ್ಯಾಯ 3 (Conformance) ಕೇಸ್ ಪರಿವರ್ತನೆಗಾಗಿ ಡೀಫಾಲ್ಟ್ ಅಲ್ಗಾರಿದಮ್ ಅನ್ನು ಚರ್ಚಿಸುತ್ತದೆ.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// ಪುನರಾವರ್ತಕರಾಗಿ:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` ಅನ್ನು ನೇರವಾಗಿ ಬಳಸುವುದು:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// ಎರಡೂ ಇದಕ್ಕೆ ಸಮಾನವಾಗಿವೆ:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` ಬಳಸುವುದು:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // ಕೆಲವೊಮ್ಮೆ ಫಲಿತಾಂಶವು ಒಂದಕ್ಕಿಂತ ಹೆಚ್ಚು ಅಕ್ಷರಗಳನ್ನು ಹೊಂದಿರುತ್ತದೆ:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // ದೊಡ್ಡಕ್ಷರ ಮತ್ತು ಸಣ್ಣ ಅಕ್ಷರಗಳೆರಡನ್ನೂ ಹೊಂದಿರದ ಅಕ್ಷರಗಳು ತಮ್ಮನ್ನು ತಾವು ಪರಿವರ್ತಿಸಿಕೊಳ್ಳುತ್ತವೆ.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # ಲೊಕೇಲ್ನಲ್ಲಿ ಗಮನಿಸಿ
    ///
    /// ಟರ್ಕಿಯಲ್ಲಿ, ಲ್ಯಾಟಿನ್ ಭಾಷೆಯಲ್ಲಿ 'i' ಗೆ ಸಮಾನವಾದವು ಎರಡು ಬದಲಿಗೆ ಐದು ರೂಪಗಳನ್ನು ಹೊಂದಿದೆ:
    ///
    /// * 'Dotless': I/ı, ಕೆಲವೊಮ್ಮೆ ಬರೆಯಲಾಗಿದೆ
    /// * 'Dotted': İ/i
    ///
    /// ಲೋವರ್ಕೇಸ್ ಚುಕ್ಕೆಗಳಿರುವ 'i' ಲ್ಯಾಟಿನ್‌ನಂತೆಯೇ ಇರುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.ಆದ್ದರಿಂದ:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// ಇಲ್ಲಿ `upper_i` ನ ಮೌಲ್ಯವು ಪಠ್ಯದ ಭಾಷೆಯನ್ನು ಅವಲಂಬಿಸಿದೆ: ನಾವು `en-US` ನಲ್ಲಿದ್ದರೆ, ಅದು `"I"` ಆಗಿರಬೇಕು, ಆದರೆ ನಾವು `tr_TR` ನಲ್ಲಿದ್ದರೆ, ಅದು `"İ"` ಆಗಿರಬೇಕು.
    /// `to_uppercase()` ಇದನ್ನು ಗಣನೆಗೆ ತೆಗೆದುಕೊಳ್ಳುವುದಿಲ್ಲ, ಮತ್ತು ಹೀಗೆ:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// ಭಾಷೆಗಳಾದ್ಯಂತ ಹೊಂದಿದೆ.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// ಮೌಲ್ಯವು ಎಎಸ್ಸಿಐಐ ವ್ಯಾಪ್ತಿಯಲ್ಲಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// ಅದರ ಎಎಸ್ಸಿಐಐ ಮೇಲಿನ ಪ್ರಕರಣದಲ್ಲಿ ಮೌಲ್ಯದ ನಕಲನ್ನು ಸಮಾನವಾಗಿಸುತ್ತದೆ.
    ///
    /// ASCII ಅಕ್ಷರಗಳು 'a' ರಿಂದ 'z' ಅನ್ನು 'A' ನಿಂದ 'Z' ಗೆ ಮ್ಯಾಪ್ ಮಾಡಲಾಗಿದೆ, ಆದರೆ ASCII ಅಲ್ಲದ ಅಕ್ಷರಗಳು ಬದಲಾಗುವುದಿಲ್ಲ.
    ///
    /// ಸ್ಥಳದಲ್ಲಿ ಮೌಲ್ಯವನ್ನು ದೊಡ್ಡದಾಗಿಸಲು, [`make_ascii_uppercase()`] ಬಳಸಿ.
    ///
    /// ASCII ಅಲ್ಲದ ಅಕ್ಷರಗಳ ಜೊತೆಗೆ ASCII ಅಕ್ಷರಗಳನ್ನು ದೊಡ್ಡದಾಗಿಸಲು, [`to_uppercase()`] ಬಳಸಿ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// ಅದರ ಎಎಸ್ಸಿಐಐ ಲೋವರ್ ಕೇಸ್ ಮೌಲ್ಯದ ನಕಲನ್ನು ಸಮಾನವಾಗಿಸುತ್ತದೆ.
    ///
    /// ASCII ಅಕ್ಷರಗಳು 'A' ರಿಂದ 'Z' ಅನ್ನು 'a' ನಿಂದ 'z' ಗೆ ಮ್ಯಾಪ್ ಮಾಡಲಾಗಿದೆ, ಆದರೆ ASCII ಅಲ್ಲದ ಅಕ್ಷರಗಳು ಬದಲಾಗುವುದಿಲ್ಲ.
    ///
    /// ಸ್ಥಳದಲ್ಲಿ ಮೌಲ್ಯವನ್ನು ಕಡಿಮೆ ಮಾಡಲು, [`make_ascii_lowercase()`] ಬಳಸಿ.
    ///
    /// ASCII ಅಲ್ಲದ ಅಕ್ಷರಗಳ ಜೊತೆಗೆ ASCII ಅಕ್ಷರಗಳನ್ನು ಕಡಿಮೆ ಮಾಡಲು, [`to_lowercase()`] ಬಳಸಿ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// ಎರಡು ಮೌಲ್ಯಗಳು ಎಎಸ್ಸಿಐಐ ಕೇಸ್-ಸೆನ್ಸಿಟಿವ್ ಮ್ಯಾಚ್ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` ಗೆ ಸಮಾನ.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// ಈ ಪ್ರಕಾರವನ್ನು ಅದರ ಎಎಸ್ಸಿಐಐ ಮೇಲಿನ ಪ್ರಕರಣಕ್ಕೆ ಸಮಾನವಾದ ಸ್ಥಳಕ್ಕೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ASCII ಅಕ್ಷರಗಳು 'a' ರಿಂದ 'z' ಅನ್ನು 'A' ನಿಂದ 'Z' ಗೆ ಮ್ಯಾಪ್ ಮಾಡಲಾಗಿದೆ, ಆದರೆ ASCII ಅಲ್ಲದ ಅಕ್ಷರಗಳು ಬದಲಾಗುವುದಿಲ್ಲ.
    ///
    /// ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ ಒಂದನ್ನು ಮಾರ್ಪಡಿಸದೆ ಹೊಸ ದೊಡ್ಡ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸಲು, [`to_ascii_uppercase()`] ಬಳಸಿ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// ಈ ಪ್ರಕಾರವನ್ನು ಅದರ ಎಎಸ್ಸಿಐಐ ಲೋವರ್ ಕೇಸ್ ಸಮಾನ ಸ್ಥಳಕ್ಕೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// ASCII ಅಕ್ಷರಗಳು 'A' ರಿಂದ 'Z' ಅನ್ನು 'a' ನಿಂದ 'z' ಗೆ ಮ್ಯಾಪ್ ಮಾಡಲಾಗಿದೆ, ಆದರೆ ASCII ಅಲ್ಲದ ಅಕ್ಷರಗಳು ಬದಲಾಗುವುದಿಲ್ಲ.
    ///
    /// ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ ಒಂದನ್ನು ಮಾರ್ಪಡಿಸದೆ ಹೊಸ ಕಡಿಮೆ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸಲು, [`to_ascii_lowercase()`] ಬಳಸಿ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// ಮೌಲ್ಯವು ಎಎಸ್ಸಿಐಐ ವರ್ಣಮಾಲೆಯ ಅಕ್ಷರವಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', ಅಥವಾ
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// ಮೌಲ್ಯವು ಎಎಸ್ಸಿಐಐ ದೊಡ್ಡಕ್ಷರವಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// ಮೌಲ್ಯವು ಎಎಸ್ಸಿಐಐ ಸಣ್ಣ ಅಕ್ಷರವಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// ಮೌಲ್ಯವು ಎಎಸ್ಸಿಐಐ ಆಲ್ಫಾನ್ಯೂಮರಿಕ್ ಅಕ್ಷರವಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', ಅಥವಾ
    /// - U + 0061 'a' ..=U + 007A 'z', ಅಥವಾ
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// ಮೌಲ್ಯವು ಎಎಸ್ಸಿಐಐ ದಶಮಾಂಶ ಅಂಕಿಯಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// ಮೌಲ್ಯವು ಎಎಸ್ಸಿಐಐ ಹೆಕ್ಸಾಡೆಸಿಮಲ್ ಅಂಕಿಯಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', ಅಥವಾ
    /// - U + 0041 'A' ..=U + 0046 'F', ಅಥವಾ
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// ಮೌಲ್ಯವು ಎಎಸ್ಸಿಐಐ ವಿರಾಮಚಿಹ್ನೆಯ ಅಕ್ಷರವಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, ಅಥವಾ
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, ಅಥವಾ
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, ಅಥವಾ
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// ಮೌಲ್ಯವು ಎಎಸ್ಸಿಐಐ ಗ್ರಾಫಿಕ್ ಅಕ್ಷರವಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// ಮೌಲ್ಯವು ಎಎಸ್ಸಿಐಐ ವೈಟ್‌ಸ್ಪೇಸ್ ಅಕ್ಷರವಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ:
    /// ಯು + 0020 ಸ್ಪೇಸ್, ಯು + 0009 ಹಾರಿಜಂಟಲ್ ಟ್ಯಾಬ್, ಯು + 000 ಎ ಲೈನ್ ಫೀಡ್, ಯು + 000 ಸಿ ಫಾರ್ಮ್ ಫೀಡ್, ಅಥವಾ ಯು + 000 ಡಿ ಕ್ಯಾರೇಜ್ ರಿಟರ್ನ್.
    ///
    /// Rust WhatWG ಇನ್ಫ್ರಾ ಸ್ಟ್ಯಾಂಡರ್ಡ್‌ನ [definition of ASCII whitespace][infra-aw] ಅನ್ನು ಬಳಸುತ್ತದೆ.ವ್ಯಾಪಕ ಬಳಕೆಯಲ್ಲಿ ಇನ್ನೂ ಹಲವಾರು ವ್ಯಾಖ್ಯಾನಗಳಿವೆ.
    /// ಉದಾಹರಣೆಗೆ, [the POSIX locale][pct] ಯು + 000 ಬಿ ವರ್ಟಿಕಲ್ ಟ್ಯಾಬ್ ಮತ್ತು ಮೇಲಿನ ಎಲ್ಲಾ ಅಕ್ಷರಗಳನ್ನು ಒಳಗೊಂಡಿದೆ, ಆದರೆ-ಅದೇ ವಿವರಣೆಯಿಂದ-[ಬೌರ್ನ್ shell ನಲ್ಲಿ "field splitting" ಗಾಗಿ ಡೀಫಾಲ್ಟ್ ನಿಯಮ][bfs]*ಮಾತ್ರ* SPACE, HORIZONTAL TAB, ಮತ್ತು ವೈಟ್‌ಸ್ಪೇಸ್‌ನಂತೆ LINE ಫೀಡ್.
    ///
    ///
    /// ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ ಫೈಲ್ ಫಾರ್ಮ್ಯಾಟ್ ಅನ್ನು ಪ್ರಕ್ರಿಯೆಗೊಳಿಸುವಂತಹ ಪ್ರೋಗ್ರಾಂ ಅನ್ನು ನೀವು ಬರೆಯುತ್ತಿದ್ದರೆ, ಈ ಕಾರ್ಯವನ್ನು ಬಳಸುವ ಮೊದಲು ಆ ಸ್ವರೂಪದ ವೈಟ್‌ಸ್ಪೇಸ್‌ನ ವ್ಯಾಖ್ಯಾನ ಏನು ಎಂದು ಪರಿಶೀಲಿಸಿ.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// ಮೌಲ್ಯವು ಎಎಸ್ಸಿಐಐ ನಿಯಂತ್ರಣ ಅಕ್ಷರವಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR, ಅಥವಾ U + 007F DELETE.
    /// ಹೆಚ್ಚಿನ ASCII ವೈಟ್‌ಸ್ಪೇಸ್ ಅಕ್ಷರಗಳು ನಿಯಂತ್ರಣ ಅಕ್ಷರಗಳಾಗಿವೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಆದರೆ SPACE ಅಲ್ಲ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// ಕಚ್ಚಾ u32 ಮೌಲ್ಯವನ್ನು UTF-8 ನಂತೆ ಒದಗಿಸಿದ ಬೈಟ್ ಬಫರ್‌ಗೆ ಎನ್‌ಕೋಡ್ ಮಾಡುತ್ತದೆ, ತದನಂತರ ಎನ್‌ಕೋಡ್ ಮಾಡಲಾದ ಅಕ್ಷರವನ್ನು ಹೊಂದಿರುವ ಬಫರ್‌ನ ಚಂದಾದಾರಿಕೆಯನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
///
///
/// `char::encode_utf8` ಗಿಂತ ಭಿನ್ನವಾಗಿ, ಈ ವಿಧಾನವು ಬಾಡಿಗೆ ವ್ಯಾಪ್ತಿಯಲ್ಲಿ ಕೋಡ್‌ಪಾಯಿಂಟ್‌ಗಳನ್ನು ಸಹ ನಿರ್ವಹಿಸುತ್ತದೆ.
/// (ಬಾಡಿಗೆ ವ್ಯಾಪ್ತಿಯಲ್ಲಿ `char` ಅನ್ನು ರಚಿಸುವುದು UB ಆಗಿದೆ.) ಫಲಿತಾಂಶವು ಮಾನ್ಯ [generalized UTF-8] ಆದರೆ ಮಾನ್ಯ UTF-8 ಅಲ್ಲ.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// ಬಫರ್ ಸಾಕಷ್ಟು ದೊಡ್ಡದಾಗದಿದ್ದರೆ Panics.
/// ಯಾವುದೇ `char` ಅನ್ನು ಎನ್ಕೋಡ್ ಮಾಡಲು ಸಾಕಷ್ಟು ಉದ್ದದ ಬಫರ್ ದೊಡ್ಡದಾಗಿದೆ.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// ಕಚ್ಚಾ u32 ಮೌಲ್ಯವನ್ನು UTF-16 ನಂತೆ ಒದಗಿಸಿದ `u16` ಬಫರ್‌ಗೆ ಎನ್‌ಕೋಡ್ ಮಾಡುತ್ತದೆ, ತದನಂತರ ಎನ್‌ಕೋಡ್ ಮಾಡಲಾದ ಅಕ್ಷರವನ್ನು ಹೊಂದಿರುವ ಬಫರ್‌ನ ಚಂದಾದಾರಿಕೆಯನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
///
///
/// `char::encode_utf16` ಗಿಂತ ಭಿನ್ನವಾಗಿ, ಈ ವಿಧಾನವು ಬಾಡಿಗೆ ವ್ಯಾಪ್ತಿಯಲ್ಲಿ ಕೋಡ್‌ಪಾಯಿಂಟ್‌ಗಳನ್ನು ಸಹ ನಿರ್ವಹಿಸುತ್ತದೆ.
/// (ಬಾಡಿಗೆ ವ್ಯಾಪ್ತಿಯಲ್ಲಿ `char` ಅನ್ನು ರಚಿಸುವುದು ಯುಬಿ ಆಗಿದೆ.)
///
/// # Panics
///
/// ಬಫರ್ ಸಾಕಷ್ಟು ದೊಡ್ಡದಾಗದಿದ್ದರೆ Panics.
/// ಯಾವುದೇ `char` ಅನ್ನು ಎನ್ಕೋಡ್ ಮಾಡಲು ಉದ್ದ 2 ರ ಬಫರ್ ದೊಡ್ಡದಾಗಿದೆ.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // ಸುರಕ್ಷತೆ: ಬರೆಯಲು ಸಾಕಷ್ಟು ಬಿಟ್‌ಗಳಿವೆಯೇ ಎಂದು ಪ್ರತಿ ತೋಳು ಪರಿಶೀಲಿಸುತ್ತದೆ
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP ಮೂಲಕ ಬರುತ್ತದೆ
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // ಪೂರಕ ವಿಮಾನಗಳು ಬಾಡಿಗೆಗೆ ಒಡೆಯುತ್ತವೆ.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}