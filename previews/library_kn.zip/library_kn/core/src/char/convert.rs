//! ಅಕ್ಷರ ಪರಿವರ್ತನೆಗಳು.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// `u32` ಅನ್ನು `char` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
///
/// ಎಲ್ಲಾ [`ಚಾರ್`] ಗಳು ಮಾನ್ಯ [`u32`] ಗಳು ಎಂದು ಗಮನಿಸಿ, ಮತ್ತು ಇವುಗಳನ್ನು ಒಂದಕ್ಕೆ ಬಿತ್ತರಿಸಬಹುದು
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// ಆದಾಗ್ಯೂ, ರಿವರ್ಸ್ ನಿಜವಲ್ಲ: ಎಲ್ಲಾ ಮಾನ್ಯ [`u32`] ಗಳು ಮಾನ್ಯವಾಗಿಲ್ಲ [`ಚಾರ್`] ಗಳು.
/// `from_u32()` [`char`] ಗೆ ಇನ್ಪುಟ್ ಮಾನ್ಯ ಮೌಲ್ಯವಲ್ಲದಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
///
/// ಈ ಪರಿಶೀಲನೆಗಳನ್ನು ನಿರ್ಲಕ್ಷಿಸುವ ಈ ಕಾರ್ಯದ ಅಸುರಕ್ಷಿತ ಆವೃತ್ತಿಗೆ, [`from_u32_unchecked`] ನೋಡಿ.
///
///
/// # Examples
///
/// ಮೂಲ ಬಳಕೆ:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// ಇನ್ಪುಟ್ ಮಾನ್ಯ [`char`] ಆಗದಿದ್ದಾಗ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// ಸಿಂಧುತ್ವವನ್ನು ನಿರ್ಲಕ್ಷಿಸಿ, `u32` ಅನ್ನು `char` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
///
/// ಎಲ್ಲಾ [`ಚಾರ್`] ಗಳು ಮಾನ್ಯ [`u32`] ಗಳು ಎಂದು ಗಮನಿಸಿ, ಮತ್ತು ಇವುಗಳನ್ನು ಒಂದಕ್ಕೆ ಬಿತ್ತರಿಸಬಹುದು
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// ಆದಾಗ್ಯೂ, ರಿವರ್ಸ್ ನಿಜವಲ್ಲ: ಎಲ್ಲಾ ಮಾನ್ಯ [`u32`] ಗಳು ಮಾನ್ಯವಾಗಿಲ್ಲ [`ಚಾರ್`] ಗಳು.
/// `from_u32_unchecked()` ಇದನ್ನು ನಿರ್ಲಕ್ಷಿಸುತ್ತದೆ ಮತ್ತು [`char`] ಗೆ ಕುರುಡಾಗಿ ಬಿತ್ತರಿಸುತ್ತದೆ, ಬಹುಶಃ ಅಮಾನ್ಯವಾದುದನ್ನು ರಚಿಸುತ್ತದೆ.
///
///
/// # Safety
///
/// ಈ ಕಾರ್ಯವು ಅಸುರಕ್ಷಿತವಾಗಿದೆ, ಏಕೆಂದರೆ ಇದು ಅಮಾನ್ಯ `char` ಮೌಲ್ಯಗಳನ್ನು ರಚಿಸಬಹುದು.
///
/// ಈ ಕಾರ್ಯದ ಸುರಕ್ಷಿತ ಆವೃತ್ತಿಗಾಗಿ, [`from_u32`] ಕಾರ್ಯವನ್ನು ನೋಡಿ.
///
/// # Examples
///
/// ಮೂಲ ಬಳಕೆ:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `i` ಮಾನ್ಯ ಚಾರ್ ಮೌಲ್ಯ ಎಂದು ಖಾತರಿಪಡಿಸಬೇಕು.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// [`char`] ಅನ್ನು [`u32`] ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`] ಅನ್ನು [`u64`] ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // ಚಾರ್ ಅನ್ನು ಕೋಡ್ ಪಾಯಿಂಟ್‌ನ ಮೌಲ್ಯಕ್ಕೆ ಬಿತ್ತರಿಸಲಾಗುತ್ತದೆ, ನಂತರ ಶೂನ್ಯವನ್ನು 64 ಬಿಟ್‌ಗೆ ವಿಸ್ತರಿಸಲಾಗುತ್ತದೆ.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] ನೋಡಿ
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// [`char`] ಅನ್ನು [`u128`] ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // ಚಾರ್ ಅನ್ನು ಕೋಡ್ ಪಾಯಿಂಟ್‌ನ ಮೌಲ್ಯಕ್ಕೆ ಬಿತ್ತರಿಸಲಾಗುತ್ತದೆ, ನಂತರ ಅದನ್ನು 128 ಬಿಟ್‌ಗೆ ಶೂನ್ಯ-ವಿಸ್ತರಿಸಲಾಗುತ್ತದೆ.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] ನೋಡಿ
        c as u128
    }
}

/// 0 +00 ರಲ್ಲಿ ಬೈಟ್ ಅನ್ನು ನಕ್ಷೆ ಮಾಡುತ್ತದೆ ..=0xFF ಅನ್ನು `char` ಗೆ ಕೋಡ್ ಪಾಯಿಂಟ್ ಒಂದೇ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿರುತ್ತದೆ, U + 0000 ನಲ್ಲಿ ..=U + 00FF.
///
/// ಯುನಿಕೋಡ್ ಅನ್ನು ವಿನ್ಯಾಸಗೊಳಿಸಲಾಗಿದೆ, ಇದು ಐಎಎನ್ಎ ಐಎಸ್ಒ-8859-1 ಎಂದು ಕರೆಯುವ ಅಕ್ಷರ ಎನ್‌ಕೋಡಿಂಗ್‌ನೊಂದಿಗೆ ಬೈಟ್‌ಗಳನ್ನು ಪರಿಣಾಮಕಾರಿಯಾಗಿ ಡಿಕೋಡ್ ಮಾಡುತ್ತದೆ.
/// ಈ ಎನ್‌ಕೋಡಿಂಗ್ ಎಎಸ್‌ಸಿಐಐಗೆ ಹೊಂದಿಕೊಳ್ಳುತ್ತದೆ.
///
/// ಇದು ISO/IEC 8859-1 ಅಕಾಕ್ಕಿಂತ ಭಿನ್ನವಾಗಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ
/// ಐಎಸ್ಒ 8859-1 (ಒಂದು ಕಡಿಮೆ ಹೈಫನ್‌ನೊಂದಿಗೆ), ಇದು ಕೆಲವು ಎಕ್ಸ್‌00 ಎಕ್ಸ್, ಬೈಟ್ ಮೌಲ್ಯಗಳನ್ನು ಯಾವುದೇ ಅಕ್ಷರಕ್ಕೆ ನಿಗದಿಪಡಿಸುವುದಿಲ್ಲ.
/// ISO-8859-1 (IANA ಒಂದು) ಅವುಗಳನ್ನು C0 ಮತ್ತು C1 ನಿಯಂತ್ರಣ ಸಂಕೇತಗಳಿಗೆ ನಿಯೋಜಿಸುತ್ತದೆ.
///
/// ಇದು ವಿಂಡೋಸ್-1252 ಅಕಾಕ್ಕಿಂತ *ಸಹ* ಭಿನ್ನವಾಗಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ
/// ಕೋಡ್ ಪುಟ 1252, ಇದು ಸೂಪರ್‌ಸೆಟ್ ISO/IEC 8859-1, ಇದು ವಿರಾಮಚಿಹ್ನೆ ಮತ್ತು ವಿವಿಧ ಲ್ಯಾಟಿನ್ ಅಕ್ಷರಗಳಿಗೆ ಕೆಲವು (ಎಲ್ಲವಲ್ಲ!) ಖಾಲಿ ಜಾಗಗಳನ್ನು ನಿಯೋಜಿಸುತ್ತದೆ.
///
/// ವಿಷಯಗಳನ್ನು ಮತ್ತಷ್ಟು ಗೊಂದಲಕ್ಕೀಡುಮಾಡಲು, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1`, ಮತ್ತು `windows-1252` ಎಲ್ಲವೂ ವಿಂಡೋಸ್-1252 ರ ಸೂಪರ್‌ಸೆಟ್‌ಗಾಗಿ ಅಲಿಯಾಸ್‌ಗಳಾಗಿವೆ, ಅದು ಉಳಿದ ಖಾಲಿ ಜಾಗಗಳನ್ನು ಅನುಗುಣವಾದ C0 ಮತ್ತು C1 ನಿಯಂತ್ರಣ ಸಂಕೇತಗಳೊಂದಿಗೆ ತುಂಬುತ್ತದೆ.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// [`u8`] ಅನ್ನು [`char`] ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// ಚಾರ್ ಅನ್ನು ಪಾರ್ಸ್ ಮಾಡುವಾಗ ಹಿಂತಿರುಗಿಸಬಹುದಾದ ದೋಷ.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // ಸುರಕ್ಷತೆ: ಇದು ಕಾನೂನುಬದ್ಧ ಯುನಿಕೋಡ್ ಮೌಲ್ಯ ಎಂದು ಪರಿಶೀಲಿಸಲಾಗಿದೆ
            Ok(unsafe { transmute(i) })
        }
    }
}

/// u32 ನಿಂದ ಚಾರ್‌ಗೆ ಪರಿವರ್ತನೆ ವಿಫಲವಾದಾಗ ದೋಷ ಪ್ರಕಾರ ಮರಳಿದೆ.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// ಕೊಟ್ಟಿರುವ ರಾಡಿಕ್ಸ್‌ನಲ್ಲಿರುವ ಅಂಕಿಯನ್ನು `char` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
///
/// ಇಲ್ಲಿ 'radix' ಅನ್ನು ಕೆಲವೊಮ್ಮೆ 'base' ಎಂದೂ ಕರೆಯಲಾಗುತ್ತದೆ.
/// ಎರಡರ ರಾಡಿಕ್ಸ್ ಕೆಲವು ಸಾಮಾನ್ಯ ಮೌಲ್ಯಗಳನ್ನು ನೀಡಲು ಬೈನರಿ ಸಂಖ್ಯೆ, ಹತ್ತು, ದಶಮಾಂಶ ಮತ್ತು ಹದಿನಾರು, ಹೆಕ್ಸಾಡೆಸಿಮಲ್ನ ರಾಡಿಕ್ಸ್ ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ.
///
/// ಅನಿಯಂತ್ರಿತ ರೇಡಿಸ್‌ಗಳನ್ನು ಬೆಂಬಲಿಸಲಾಗುತ್ತದೆ.
///
/// `from_digit()` ಕೊಟ್ಟಿರುವ ರಾಡಿಕ್ಸ್‌ನಲ್ಲಿ ಇನ್‌ಪುಟ್ ಅಂಕೆ ಇಲ್ಲದಿದ್ದರೆ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
///
/// # Panics
///
/// 36 ಕ್ಕಿಂತ ದೊಡ್ಡದಾದ ರಾಡಿಕ್ಸ್ ನೀಡಿದರೆ Panics.
///
/// # Examples
///
/// ಮೂಲ ಬಳಕೆ:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // ದಶಮಾಂಶ 11 ಬೇಸ್ 16 ರಲ್ಲಿ ಒಂದೇ ಅಂಕೆ
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// ಇನ್ಪುಟ್ ಅಂಕಿಯಲ್ಲದಿದ್ದಾಗ `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// ದೊಡ್ಡ ರಾಡಿಕ್ಸ್ ಅನ್ನು ಹಾದುಹೋಗುತ್ತದೆ, ಇದು panic ಗೆ ಕಾರಣವಾಗುತ್ತದೆ:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}