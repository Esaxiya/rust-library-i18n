//! ನಿಗದಿತ-ಉದ್ದದ ಸರಣಿಗಳಿಗೆ `Eq` ನಂತಹ ವಸ್ತುಗಳ ಅನುಷ್ಠಾನಗಳು ಒಂದು ನಿರ್ದಿಷ್ಟ ಉದ್ದದವರೆಗೆ.
//! ಅಂತಿಮವಾಗಿ, ನಾವು ಎಲ್ಲಾ ಉದ್ದಗಳಿಗೆ ಸಾಮಾನ್ಯೀಕರಿಸಲು ಸಾಧ್ಯವಾಗುತ್ತದೆ.
//!
//! *[See also the array primitive type](array).*
//!

#![stable(feature = "core_array", since = "1.36.0")]

use crate::borrow::{Borrow, BorrowMut};
use crate::cmp::Ordering;
use crate::convert::{Infallible, TryFrom};
use crate::fmt;
use crate::hash::{self, Hash};
use crate::iter::TrustedLen;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{Index, IndexMut};
use crate::slice::{Iter, IterMut};

mod iter;

#[stable(feature = "array_value_iter", since = "1.51.0")]
pub use iter::IntoIter;

/// `T` ಗೆ ಉಲ್ಲೇಖವನ್ನು ಉದ್ದ 1 ರ ಶ್ರೇಣಿಗೆ ಉಲ್ಲೇಖವಾಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ (ನಕಲಿಸದೆ).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_ref<T>(s: &T) -> &[T; 1] {
    // ಸುರಕ್ಷತೆ: `&T` ಅನ್ನು `&[T; 1]` ಗೆ ಪರಿವರ್ತಿಸುವುದು ಧ್ವನಿ.
    unsafe { &*(s as *const T).cast::<[T; 1]>() }
}

/// `T` ಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಉದ್ದ 1 ರ ಶ್ರೇಣಿಗೆ (ನಕಲಿಸದೆ) ಪರಿವರ್ತಿಸಬಹುದಾದ ಉಲ್ಲೇಖವಾಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_mut<T>(s: &mut T) -> &mut [T; 1] {
    // ಸುರಕ್ಷತೆ: `&mut T` ಅನ್ನು `&mut [T; 1]` ಗೆ ಪರಿವರ್ತಿಸುವುದು ಧ್ವನಿ.
    unsafe { &mut *(s as *mut T).cast::<[T; 1]>() }
}

/// ಯುಟಿಲಿಟಿ trait ಅನ್ನು ಸ್ಥಿರ ಗಾತ್ರದ ಸರಣಿಗಳಲ್ಲಿ ಮಾತ್ರ ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗಿದೆ
///
/// ಈ trait ಅನ್ನು ಹೆಚ್ಚು ಮೆಟಾಡೇಟಾ ಉಬ್ಬುವಿಕೆಗೆ ಕಾರಣವಾಗದೆ ಸ್ಥಿರ ಗಾತ್ರದ ಅರೇಗಳಲ್ಲಿ ಇತರ traits ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ಬಳಸಬಹುದು.
///
/// ಕಾರ್ಯಗತಗೊಳಿಸುವವರನ್ನು ಸ್ಥಿರ-ಗಾತ್ರದ ಸರಣಿಗಳಿಗೆ ನಿರ್ಬಂಧಿಸುವ ಸಲುವಾಗಿ trait ಅನ್ನು ಅಸುರಕ್ಷಿತ ಎಂದು ಗುರುತಿಸಲಾಗಿದೆ.
/// ಈ trait ನ ಬಳಕೆದಾರರು ನಿಗದಿತ ಗಾತ್ರದ ರಚನೆಯ ಸ್ಮರಣೆಯಲ್ಲಿ ಅನುಷ್ಠಾನಕಾರರು ನಿಖರವಾದ ವಿನ್ಯಾಸವನ್ನು ಹೊಂದಿದ್ದಾರೆಂದು can ಹಿಸಬಹುದು (ಉದಾಹರಣೆಗೆ, ಅಸುರಕ್ಷಿತ ಪ್ರಾರಂಭಕ್ಕಾಗಿ).
///
///
/// traits [`AsRef`] ಮತ್ತು [`AsMut`] ಸ್ಥಿರ ಗಾತ್ರದ ಸರಣಿಗಳಲ್ಲದ ಪ್ರಕಾರಗಳಿಗೆ ಒಂದೇ ರೀತಿಯ ವಿಧಾನಗಳನ್ನು ಒದಗಿಸುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
/// ಅನುಷ್ಠಾನಕಾರರು ಆ traits ಗೆ ಆದ್ಯತೆ ನೀಡಬೇಕು.
///
///
///
#[unstable(feature = "fixed_size_array", issue = "27778")]
pub unsafe trait FixedSizeArray<T> {
    /// ರಚನೆಯನ್ನು ಬದಲಾಯಿಸಲಾಗದ ಸ್ಲೈಸ್‌ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_slice(&self) -> &[T];
    /// ರಚನೆಯನ್ನು ರೂಪಾಂತರಿತ ಸ್ಲೈಸ್‌ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_mut_slice(&mut self) -> &mut [T];
}

#[unstable(feature = "fixed_size_array", issue = "27778")]
unsafe impl<T, A: Unsize<[T]>> FixedSizeArray<T> for A {
    #[inline]
    fn as_slice(&self) -> &[T] {
        self
    }
    #[inline]
    fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }
}

/// ಸ್ಲೈಸ್‌ನಿಂದ ಅರೇಗೆ ಪರಿವರ್ತನೆ ವಿಫಲವಾದಾಗ ದೋಷ ಪ್ರಕಾರ ಮರಳಿದೆ.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone)]
pub struct TryFromSliceError(());

#[stable(feature = "core_array", since = "1.36.0")]
impl fmt::Display for TryFromSliceError {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self.__description(), f)
    }
}

impl TryFromSliceError {
    #[unstable(
        feature = "array_error_internals",
        reason = "available through Error trait and this method should not \
                     be exposed publicly",
        issue = "none"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "could not convert slice to array"
    }
}

#[stable(feature = "try_from_slice_error", since = "1.36.0")]
impl From<Infallible> for TryFromSliceError {
    fn from(x: Infallible) -> TryFromSliceError {
        match x {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsRef<[T]> for [T; N] {
    #[inline]
    fn as_ref(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsMut<[T]> for [T; N] {
    #[inline]
    fn as_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> Borrow<[T]> for [T; N] {
    fn borrow(&self) -> &[T] {
        self
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> BorrowMut<[T]> for [T; N] {
    fn borrow_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<T, const N: usize> TryFrom<&[T]> for [T; N]
where
    T: Copy,
{
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<[T; N], TryFromSliceError> {
        <&Self>::try_from(slice).map(|r| *r)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a [T]> for &'a [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<&[T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_ptr() as *const [T; N];
            // ಸುರಕ್ಷತೆ: ಸರಿ ಏಕೆಂದರೆ ಉದ್ದವು ಹೊಂದಿಕೊಳ್ಳುತ್ತದೆ ಎಂದು ನಾವು ಪರಿಶೀಲಿಸಿದ್ದೇವೆ
            unsafe { Ok(&*ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a mut [T]> for &'a mut [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &mut [T]) -> Result<&mut [T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_mut_ptr() as *mut [T; N];
            // ಸುರಕ್ಷತೆ: ಸರಿ ಏಕೆಂದರೆ ಉದ್ದವು ಹೊಂದಿಕೊಳ್ಳುತ್ತದೆ ಎಂದು ನಾವು ಪರಿಶೀಲಿಸಿದ್ದೇವೆ
            unsafe { Ok(&mut *ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, const N: usize> Hash for [T; N] {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        Hash::hash(&self[..], state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for [T; N] {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&&self[..], f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a [T; N] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a mut [T; N] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> Index<I> for [T; N]
where
    [T]: Index<I>,
{
    type Output = <[T] as Index<I>>::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(self as &[T], index)
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> IndexMut<I> for [T; N]
where
    [T]: IndexMut<I>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(self as &mut [T], index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B; N]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &[B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&mut [B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&mut [B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&mut [B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &mut [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

// NOTE: ಕೋಡ್ ಉಬ್ಬರವನ್ನು ಕಡಿಮೆ ಮಾಡಲು ಕೆಲವು ಕಡಿಮೆ ಪ್ರಾಮುಖ್ಯತೆಯನ್ನು ಬಿಟ್ಟುಬಿಡಲಾಗಿದೆ
// __impl_slice_eq2!{ [A; $N], &'b [B; $N] } __impl_slice_eq2! { [A; $N], &'b mut [B; $N] }
//

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, const N: usize> Eq for [T; N] {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, const N: usize> PartialOrd for [T; N] {
    #[inline]
    fn partial_cmp(&self, other: &[T; N]) -> Option<Ordering> {
        PartialOrd::partial_cmp(&&self[..], &&other[..])
    }
    #[inline]
    fn lt(&self, other: &[T; N]) -> bool {
        PartialOrd::lt(&&self[..], &&other[..])
    }
    #[inline]
    fn le(&self, other: &[T; N]) -> bool {
        PartialOrd::le(&&self[..], &&other[..])
    }
    #[inline]
    fn ge(&self, other: &[T; N]) -> bool {
        PartialOrd::ge(&&self[..], &&other[..])
    }
    #[inline]
    fn gt(&self, other: &[T; N]) -> bool {
        PartialOrd::gt(&&self[..], &&other[..])
    }
}

/// [lexicographically](Ord#lexicographical-comparison) ಸರಣಿಗಳ ಹೋಲಿಕೆಯನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, const N: usize> Ord for [T; N] {
    #[inline]
    fn cmp(&self, other: &[T; N]) -> Ordering {
        Ord::cmp(&&self[..], &&other[..])
    }
}

// ಡೀಫಾಲ್ಟ್ ಇಂಪಲ್ಸ್ ಅನ್ನು ಕಾನ್ಸ್ ಜೆನೆರಿಕ್ಸ್‌ನೊಂದಿಗೆ ಮಾಡಲಾಗುವುದಿಲ್ಲ ಏಕೆಂದರೆ ಎಕ್ಸ್‌00ಎಕ್ಸ್‌ಗೆ ಡೀಫಾಲ್ಟ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಅಗತ್ಯವಿಲ್ಲ, ಮತ್ತು ವಿಭಿನ್ನ ಸಂಖ್ಯೆಗಳಿಗೆ ವಿಭಿನ್ನ ಇಂಪ್ಲ್ ಬ್ಲಾಕ್‌ಗಳನ್ನು ಹೊಂದಿರುವುದು ಇನ್ನೂ ಬೆಂಬಲಿಸುವುದಿಲ್ಲ.
//
//

macro_rules! array_impl_default {
    {$n:expr, $t:ident $($ts:ident)*} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] where T: Default {
            fn default() -> [T; $n] {
                [$t::default(), $($ts::default()),*]
            }
        }
        array_impl_default!{($n - 1), $($ts)*}
    };
    {$n:expr,} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] {
            fn default() -> [T; $n] { [] }
        }
    };
}

array_impl_default! {32, T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T}

#[lang = "array"]
impl<T, const N: usize> [T; N] {
    /// `self` ನಂತೆಯೇ ಒಂದೇ ಗಾತ್ರದ ಒಂದು ಶ್ರೇಣಿಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, `f` ಕಾರ್ಯವನ್ನು ಪ್ರತಿ ಅಂಶಕ್ಕೂ ಕ್ರಮವಾಗಿ ಅನ್ವಯಿಸಲಾಗುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_map)]
    /// let x = [1, 2, 3];
    /// let y = x.map(|v| v + 1);
    /// assert_eq!(y, [2, 3, 4]);
    ///
    /// let x = [1, 2, 3];
    /// let mut temp = 0;
    /// let y = x.map(|v| { temp += 1; v * temp });
    /// assert_eq!(y, [1, 4, 9]);
    ///
    /// let x = ["Ferris", "Bueller's", "Day", "Off"];
    /// let y = x.map(|v| v.len());
    /// assert_eq!(y, [6, 9, 3, 3]);
    /// ```
    #[unstable(feature = "array_map", issue = "75243")]
    pub fn map<F, U>(self, f: F) -> [U; N]
    where
        F: FnMut(T) -> U,
    {
        // ಸುರಕ್ಷತೆ: ಈ ಪುನರಾವರ್ತಕ ನಿಖರವಾಗಿ `N` ಅನ್ನು ನೀಡುತ್ತದೆ ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ
        // items.
        unsafe { collect_into_array_unchecked(&mut IntoIter::new(self).map(f)) }
    }

    /// ಜೋಡಿಗಳ ಒಂದೇ ಶ್ರೇಣಿಯಲ್ಲಿ ಎರಡು ಸರಣಿಗಳನ್ನು 'ಜಿಪ್ಸ್ ಅಪ್' ಮಾಡಿ.
    ///
    /// `zip()` ಹೊಸ ಅಂಶವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಅಲ್ಲಿ ಪ್ರತಿಯೊಂದು ಅಂಶವು ಟಪಲ್ ಆಗಿದ್ದು, ಅಲ್ಲಿ ಮೊದಲ ಅಂಶವು ಮೊದಲ ಶ್ರೇಣಿಯಿಂದ ಬರುತ್ತದೆ, ಮತ್ತು ಎರಡನೇ ಅಂಶವು ಎರಡನೇ ರಚನೆಯಿಂದ ಬರುತ್ತದೆ.
    ///
    /// ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, ಇದು ಎರಡು ಸರಣಿಗಳನ್ನು ಒಟ್ಟಿಗೆ, ಒಂದೇ ಒಂದಕ್ಕೆ ಜಿಪ್ ಮಾಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_zip)]
    /// let x = [1, 2, 3];
    /// let y = [4, 5, 6];
    /// let z = x.zip(y);
    /// assert_eq!(z, [(1, 4), (2, 5), (3, 6)]);
    /// ```
    ///
    #[unstable(feature = "array_zip", issue = "80094")]
    pub fn zip<U>(self, rhs: [U; N]) -> [(T, U); N] {
        let mut iter = IntoIter::new(self).zip(IntoIter::new(rhs));

        // ಸುರಕ್ಷತೆ: ಈ ಪುನರಾವರ್ತಕ ನಿಖರವಾಗಿ `N` ಅನ್ನು ನೀಡುತ್ತದೆ ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ
        // items.
        unsafe { collect_into_array_unchecked(&mut iter) }
    }

    /// ಸಂಪೂರ್ಣ ಶ್ರೇಣಿಯನ್ನು ಹೊಂದಿರುವ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.`&s[..]` ಗೆ ಸಮಾನ.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// ಸಂಪೂರ್ಣ ಶ್ರೇಣಿಯನ್ನು ಹೊಂದಿರುವ ರೂಪಾಂತರಿತ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// `&mut s[..]` ಗೆ ಸಮಾನ.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// ಪ್ರತಿ ಅಂಶವನ್ನು ಎರವಲು ಪಡೆಯುತ್ತದೆ ಮತ್ತು `self` ನ ಒಂದೇ ಗಾತ್ರದೊಂದಿಗೆ ಉಲ್ಲೇಖಗಳ ಒಂದು ಶ್ರೇಣಿಯನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&f64; 3] = floats.each_ref();
    /// assert_eq!(float_refs, [&3.1, &2.7, &-1.0]);
    /// ```
    ///
    /// [`map`](#method.map) ನಂತಹ ಇತರ ವಿಧಾನಗಳೊಂದಿಗೆ ಸಂಯೋಜಿಸಿದರೆ ಈ ವಿಧಾನವು ವಿಶೇಷವಾಗಿ ಉಪಯುಕ್ತವಾಗಿದೆ.
    /// ಈ ರೀತಿಯಾಗಿ, ಮೂಲ ರಚನೆಯ ಅಂಶಗಳು `Copy` ಅಲ್ಲದಿದ್ದರೆ ನೀವು ಅದನ್ನು ಚಲಿಸುವುದನ್ನು ತಪ್ಪಿಸಬಹುದು.
    ///
    /// ```
    /// #![feature(array_methods, array_map)]
    ///
    /// let strings = ["Ferris".to_string(), "♥".to_string(), "Rust".to_string()];
    /// let is_ascii = strings.each_ref().map(|s| s.is_ascii());
    /// assert_eq!(is_ascii, [true, false, true]);
    ///
    /// // ನಾವು ಇನ್ನೂ ಮೂಲ ಶ್ರೇಣಿಯನ್ನು ಪ್ರವೇಶಿಸಬಹುದು: ಅದನ್ನು ಸರಿಸಲಾಗಿಲ್ಲ.
    /// assert_eq!(strings.len(), 3);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_ref(&self) -> [&T; N] {
        // ಸುರಕ್ಷತೆ: ಈ ಪುನರಾವರ್ತಕ ನಿಖರವಾಗಿ `N` ಅನ್ನು ನೀಡುತ್ತದೆ ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter()) }
    }

    /// ಪ್ರತಿ ಅಂಶವನ್ನು ಪರಸ್ಪರ ಎರವಲು ಪಡೆಯುತ್ತದೆ ಮತ್ತು `self` ನ ಒಂದೇ ಗಾತ್ರದೊಂದಿಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳ ಒಂದು ಶ್ರೇಣಿಯನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let mut floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&mut f64; 3] = floats.each_mut();
    /// *float_refs[0] = 0.0;
    /// assert_eq!(float_refs, [&mut 0.0, &mut 2.7, &mut -1.0]);
    /// assert_eq!(floats, [0.0, 2.7, -1.0]);
    /// ```
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_mut(&mut self) -> [&mut T; N] {
        // ಸುರಕ್ಷತೆ: ಈ ಪುನರಾವರ್ತಕ ನಿಖರವಾಗಿ `N` ಅನ್ನು ನೀಡುತ್ತದೆ ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter_mut()) }
    }
}

/// `iter` ನಿಂದ `N` ವಸ್ತುಗಳನ್ನು ಎಳೆಯುತ್ತದೆ ಮತ್ತು ಅವುಗಳನ್ನು ರಚನೆಯಾಗಿ ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
/// ಪುನರಾವರ್ತಕವು `N` ಗಿಂತ ಕಡಿಮೆ ಇಳುವರಿಯನ್ನು ನೀಡಿದರೆ, ಈ ಕಾರ್ಯವು ವಿವರಿಸಲಾಗದ ನಡವಳಿಕೆಯನ್ನು ಪ್ರದರ್ಶಿಸುತ್ತದೆ.
///
///
/// ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ [`collect_into_array`] ನೋಡಿ.
///
/// # Safety
///
/// `iter` ಕನಿಷ್ಠ `N` ವಸ್ತುಗಳನ್ನು ನೀಡುತ್ತದೆ ಎಂದು ಖಾತರಿಪಡಿಸುವುದು ಕರೆ ಮಾಡುವವರಿಗೆ ಬಿಟ್ಟದ್ದು.
/// ಈ ಸ್ಥಿತಿಯನ್ನು ಉಲ್ಲಂಘಿಸುವುದು ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
unsafe fn collect_into_array_unchecked<I, const N: usize>(iter: &mut I) -> [I::Item; N]
where
    // Note: ಇಲ್ಲಿ `TrustedLen` ಸ್ವಲ್ಪ ಮಟ್ಟಿಗೆ ಒಂದು ಪ್ರಯೋಗವಾಗಿದೆ.ಇದು ಕೇವಲ ಒಂದು
    // ಆಂತರಿಕ ಕಾರ್ಯ, ಆದ್ದರಿಂದ ಈ ಬೌಂಡ್ ಕೆಟ್ಟ ಆಲೋಚನೆಯಾಗಿದ್ದರೆ ತೆಗೆದುಹಾಕಲು ಹಿಂಜರಿಯಬೇಡಿ.
    // ಅಂತಹ ಸಂದರ್ಭದಲ್ಲಿ, ಕೆಳಗಿನ ಬೌಂಡ್ `debug_assert!` ಅನ್ನು ಸಹ ತೆಗೆದುಹಾಕಲು ಮರೆಯದಿರಿ!
    //
    I: Iterator + TrustedLen,
{
    debug_assert!(N <= iter.size_hint().1.unwrap_or(usize::MAX));
    debug_assert!(N <= iter.size_hint().0);

    match collect_into_array(iter) {
        Some(array) => array,
        // ಸುರಕ್ಷತೆ: ಕಾರ್ಯ ಒಪ್ಪಂದದಿಂದ ಒಳಗೊಂಡಿದೆ.
        None => unsafe { crate::hint::unreachable_unchecked() },
    }
}

/// `iter` ನಿಂದ `N` ವಸ್ತುಗಳನ್ನು ಎಳೆಯುತ್ತದೆ ಮತ್ತು ಅವುಗಳನ್ನು ರಚನೆಯಾಗಿ ಹಿಂದಿರುಗಿಸುತ್ತದೆ.ಪುನರಾವರ್ತಕವು `N` ಗಿಂತ ಕಡಿಮೆ ಇಳುವರಿಯನ್ನು ನೀಡಿದರೆ, `None` ಅನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ಈಗಾಗಲೇ ಇಳುವರಿ ಪಡೆದ ಎಲ್ಲಾ ವಸ್ತುಗಳನ್ನು ಕೈಬಿಡಲಾಗುತ್ತದೆ.
///
/// ಪುನರಾವರ್ತಕವನ್ನು ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವಾಗಿ ರವಾನಿಸಲಾಗಿರುವುದರಿಂದ ಮತ್ತು ಈ ಕಾರ್ಯವು ಹೆಚ್ಚಿನ `N` ಸಮಯಗಳಲ್ಲಿ `next` ಅನ್ನು ಕರೆಯುವುದರಿಂದ, ಉಳಿದ ವಸ್ತುಗಳನ್ನು ಹಿಂಪಡೆಯಲು ಪುನರಾವರ್ತಕವನ್ನು ಇನ್ನೂ ಬಳಸಬಹುದು.
///
///
/// `iter.next()` ಪ್ಯಾನಿಕ್ ಆಗಿದ್ದರೆ, ಪುನರಾವರ್ತಕದಿಂದ ಈಗಾಗಲೇ ನೀಡಲಾದ ಎಲ್ಲಾ ವಸ್ತುಗಳನ್ನು ಕೈಬಿಡಲಾಗುತ್ತದೆ.
///
///
///
///
fn collect_into_array<I, const N: usize>(iter: &mut I) -> Option<[I::Item; N]>
where
    I: Iterator,
{
    if N == 0 {
        // ಸುರಕ್ಷತೆ: ಖಾಲಿ ರಚನೆಯು ಯಾವಾಗಲೂ ವಾಸಿಸುತ್ತದೆ ಮತ್ತು ಯಾವುದೇ ಮಾನ್ಯತೆಯ ಅಸ್ಥಿರತೆಯನ್ನು ಹೊಂದಿರುವುದಿಲ್ಲ.
        return unsafe { Some(mem::zeroed()) };
    }

    struct Guard<T, const N: usize> {
        ptr: *mut T,
        initialized: usize,
    }

    impl<T, const N: usize> Drop for Guard<T, N> {
        fn drop(&mut self) {
            debug_assert!(self.initialized <= N);

            let initialized_part = crate::ptr::slice_from_raw_parts_mut(self.ptr, self.initialized);

            // ಸುರಕ್ಷತೆ: ಈ ಕಚ್ಚಾ ಸ್ಲೈಸ್ ಪ್ರಾರಂಭಿಕ ವಸ್ತುಗಳನ್ನು ಮಾತ್ರ ಹೊಂದಿರುತ್ತದೆ.
            unsafe {
                crate::ptr::drop_in_place(initialized_part);
            }
        }
    }

    let mut array = MaybeUninit::uninit_array::<N>();
    let mut guard: Guard<_, N> =
        Guard { ptr: MaybeUninit::slice_as_mut_ptr(&mut array), initialized: 0 };

    while let Some(item) = iter.next() {
        // ಸುರಕ್ಷತೆ: `guard.initialized` 0 ರಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ, ಇದನ್ನು ಒಂದರಿಂದ ಹೆಚ್ಚಿಸಲಾಗುತ್ತದೆ
        // ಲೂಪ್ ಮತ್ತು ಲೂಪ್ N ಅನ್ನು ತಲುಪಿದ ನಂತರ ಅದನ್ನು ಸ್ಥಗಿತಗೊಳಿಸಲಾಗುತ್ತದೆ (ಇದು `array.len()`) ಆಗಿದೆ.
        //
        unsafe {
            array.get_unchecked_mut(guard.initialized).write(item);
        }
        guard.initialized += 1;

        // ಇಡೀ ಶ್ರೇಣಿಯನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸಿ.
        if guard.initialized == N {
            mem::forget(guard);

            // ಸುರಕ್ಷತೆ: ಮೇಲಿನ ಸ್ಥಿತಿಯು ಎಲ್ಲಾ ಅಂಶಗಳು ಎಂದು ಪ್ರತಿಪಾದಿಸುತ್ತದೆ
            // initialized.
            let out = unsafe { MaybeUninit::array_assume_init(array) };
            return Some(out);
        }
    }

    // `guard.initialized` `N` ತಲುಪುವ ಮೊದಲು ಪುನರಾವರ್ತಕವು ಖಾಲಿಯಾದರೆ ಮಾತ್ರ ಇದನ್ನು ತಲುಪಲಾಗುತ್ತದೆ.
    //
    // `guard` ಅನ್ನು ಇಲ್ಲಿ ಕೈಬಿಡಲಾಗಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಈಗಾಗಲೇ ಪ್ರಾರಂಭಿಸಲಾದ ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ಬಿಡಿ.
    None
}