//! ಸರಣಿಗಳಿಗಾಗಿ `IntoIter` ಒಡೆತನದ ಪುನರಾವರ್ತಕವನ್ನು ವ್ಯಾಖ್ಯಾನಿಸುತ್ತದೆ.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// ಉಪ-ಮೌಲ್ಯದ [array] ಪುನರಾವರ್ತಕ.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// ಇದು ನಾವು ಪುನರಾವರ್ತಿಸುತ್ತಿರುವ ರಚನೆಯಾಗಿದೆ.
    ///
    /// ಸೂಚ್ಯಂಕ `i` ಯೊಂದಿಗಿನ ಅಂಶಗಳು, ಅಲ್ಲಿ `alive.start <= i < alive.end` ಅನ್ನು ಇನ್ನೂ ನೀಡಲಾಗಿಲ್ಲ ಮತ್ತು ಮಾನ್ಯ ಅರೇ ನಮೂದುಗಳಾಗಿವೆ.
    /// `i < alive.start` ಅಥವಾ `i >= alive.end` ಸೂಚ್ಯಂಕಗಳನ್ನು ಹೊಂದಿರುವ ಅಂಶಗಳನ್ನು ಈಗಾಗಲೇ ನೀಡಲಾಗಿದೆ ಮತ್ತು ಇನ್ನು ಮುಂದೆ ಪ್ರವೇಶಿಸಬಾರದು!ಆ ಸತ್ತ ಅಂಶಗಳು ಸಂಪೂರ್ಣವಾಗಿ ಪ್ರಾರಂಭಿಸದ ಸ್ಥಿತಿಯಲ್ಲಿರಬಹುದು!
    ///
    ///
    /// ಆದ್ದರಿಂದ ಅಸ್ಥಿರತೆಗಳು ಹೀಗಿವೆ:
    /// - `data[alive]` ಜೀವಂತವಾಗಿದೆ (ಅಂದರೆ ಮಾನ್ಯ ಅಂಶಗಳನ್ನು ಒಳಗೊಂಡಿದೆ)
    /// - `data[..alive.start]` ಮತ್ತು `data[alive.end..]` ಸತ್ತಿದೆ (ಅಂದರೆ ಅಂಶಗಳನ್ನು ಈಗಾಗಲೇ ಓದಲಾಗಿದೆ ಮತ್ತು ಇನ್ನು ಮುಂದೆ ಮುಟ್ಟಬಾರದು!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data` ನಲ್ಲಿನ ಅಂಶಗಳು ಇನ್ನೂ ಇಳುವರಿ ನೀಡಿಲ್ಲ.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// ಕೊಟ್ಟಿರುವ `array` ಗಿಂತ ಹೊಸ ಪುನರಾವರ್ತಕವನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// *ಗಮನಿಸಿ*: ಈ ವಿಧಾನವನ್ನು [`IntoIterator` is implemented for arrays][array-into-iter] ನಂತರ future ನಲ್ಲಿ ಅಸಮ್ಮತಿಸಬಹುದು.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `&i32` ಬದಲಿಗೆ `value` ಪ್ರಕಾರವು ಇಲ್ಲಿ `i32` ಆಗಿದೆ
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // ಸುರಕ್ಷತೆ: ಇಲ್ಲಿ ಪರಿವರ್ತನೆ ವಾಸ್ತವವಾಗಿ ಸುರಕ್ಷಿತವಾಗಿದೆ.`MaybeUninit` ನ ಡಾಕ್ಸ್
        // promise:
        //
        // > `MaybeUninit<T>` ಒಂದೇ ಗಾತ್ರ ಮತ್ತು ಜೋಡಣೆಯನ್ನು ಹೊಂದಲು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ
        // > `T` ಆಗಿ.
        //
        // ಡಾಕ್ಸ್ `MaybeUninit<T>` ನ ಶ್ರೇಣಿಯಿಂದ `T` ನ ಶ್ರೇಣಿಗೆ ಪರಿವರ್ತನೆಯನ್ನು ಸಹ ತೋರಿಸುತ್ತದೆ.
        //
        //
        // ಇದರೊಂದಿಗೆ, ಈ ಪ್ರಾರಂಭವು ಅಸ್ಥಿರತೆಯನ್ನು ತೃಪ್ತಿಪಡಿಸುತ್ತದೆ.

        // FIXME(LukasKalbertodt): ವಾಸ್ತವವಾಗಿ ಇಲ್ಲಿ `mem::transmute` ಅನ್ನು ಬಳಸಿ, ಅದು ಕಾನ್ಸ್ಟ್ ಜೆನೆರಿಕ್ಸ್‌ನೊಂದಿಗೆ ಕೆಲಸ ಮಾಡಿದ ನಂತರ:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // ಅಲ್ಲಿಯವರೆಗೆ, ನಾವು ಬಿಟ್‌ವೈಸ್ ನಕಲನ್ನು ಬೇರೆ ಪ್ರಕಾರವಾಗಿ ರಚಿಸಲು `mem::transmute_copy` ಅನ್ನು ಬಳಸಬಹುದು, ನಂತರ `array` ಅನ್ನು ಮರೆತುಬಿಡಿ ಆದ್ದರಿಂದ ಅದನ್ನು ಕೈಬಿಡಲಾಗುವುದಿಲ್ಲ.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// ಇನ್ನೂ ಇಳುವರಿ ನೀಡದ ಎಲ್ಲಾ ಅಂಶಗಳ ಬದಲಾಗದ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // ಸುರಕ್ಷತೆ: `alive` ಯೊಳಗಿನ ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ಸರಿಯಾಗಿ ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// ಇನ್ನೂ ಇಳುವರಿ ನೀಡದ ಎಲ್ಲಾ ಅಂಶಗಳ ರೂಪಾಂತರಿತ ಸ್ಲೈಸ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // ಸುರಕ್ಷತೆ: `alive` ಯೊಳಗಿನ ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು ಸರಿಯಾಗಿ ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ ಎಂದು ನಮಗೆ ತಿಳಿದಿದೆ.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // ಮುಂದಿನ ಸೂಚ್ಯಂಕವನ್ನು ಮುಂಭಾಗದಿಂದ ಪಡೆಯಿರಿ.
        //
        // `alive.start` ಅನ್ನು 1 ರಿಂದ ಹೆಚ್ಚಿಸುವುದರಿಂದ `alive` ಗೆ ಸಂಬಂಧಿಸಿದಂತೆ ಅಸ್ಥಿರತೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
        // ಆದಾಗ್ಯೂ, ಈ ಬದಲಾವಣೆಯಿಂದಾಗಿ, ಅಲ್ಪಾವಧಿಗೆ, ಜೀವಂತ ವಲಯವು ಇನ್ನು ಮುಂದೆ `data[alive]` ಅಲ್ಲ, ಆದರೆ `data[idx..alive.end]` ಆಗಿದೆ.
        //
        self.alive.next().map(|idx| {
            // ರಚನೆಯ ಅಂಶವನ್ನು ಓದಿ.
            // ಸುರಕ್ಷತೆ: `idx` ಎಂಬುದು ಹಿಂದಿನ "alive" ಪ್ರದೇಶದ ಸೂಚ್ಯಂಕವಾಗಿದೆ
            // ರಚನೆ.ಈ ಅಂಶವನ್ನು ಓದುವುದರಿಂದ `data[idx]` ಅನ್ನು ಈಗ ಸತ್ತಂತೆ ಪರಿಗಣಿಸಲಾಗುತ್ತದೆ (ಅಂದರೆ ಮುಟ್ಟಬೇಡಿ).
            // `idx` ಜೀವಂತ-ವಲಯದ ಪ್ರಾರಂಭವಾಗಿದ್ದರಿಂದ, ಜೀವಂತ ವಲಯವು ಈಗ ಮತ್ತೆ `data[alive]` ಆಗಿದೆ, ಎಲ್ಲಾ ಅಸ್ಥಿರಗಳನ್ನು ಮರುಸ್ಥಾಪಿಸುತ್ತದೆ.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // ಮುಂದಿನ ಸೂಚ್ಯಂಕವನ್ನು ಹಿಂದಿನಿಂದ ಪಡೆಯಿರಿ.
        //
        // `alive.end` ಅನ್ನು 1 ರಿಂದ ಕಡಿಮೆ ಮಾಡುವುದರಿಂದ `alive` ಗೆ ಸಂಬಂಧಿಸಿದಂತೆ ಅಸ್ಥಿರತೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
        // ಆದಾಗ್ಯೂ, ಈ ಬದಲಾವಣೆಯಿಂದಾಗಿ, ಅಲ್ಪಾವಧಿಗೆ, ಜೀವಂತ ವಲಯವು ಇನ್ನು ಮುಂದೆ `data[alive]` ಅಲ್ಲ, ಆದರೆ `data[alive.start..=idx]` ಆಗಿದೆ.
        //
        self.alive.next_back().map(|idx| {
            // ರಚನೆಯ ಅಂಶವನ್ನು ಓದಿ.
            // ಸುರಕ್ಷತೆ: `idx` ಎಂಬುದು ಹಿಂದಿನ "alive" ಪ್ರದೇಶದ ಸೂಚ್ಯಂಕವಾಗಿದೆ
            // ರಚನೆ.ಈ ಅಂಶವನ್ನು ಓದುವುದರಿಂದ `data[idx]` ಅನ್ನು ಈಗ ಸತ್ತಂತೆ ಪರಿಗಣಿಸಲಾಗುತ್ತದೆ (ಅಂದರೆ ಮುಟ್ಟಬೇಡಿ).
            // `idx` ಜೀವಂತ-ವಲಯದ ಅಂತ್ಯವಾಗಿದ್ದರಿಂದ, ಜೀವಂತ ವಲಯವು ಈಗ ಮತ್ತೆ `data[alive]` ಆಗಿದ್ದು, ಎಲ್ಲಾ ಅಸ್ಥಿರಗಳನ್ನು ಮರುಸ್ಥಾಪಿಸುತ್ತದೆ.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // ಸುರಕ್ಷತೆ: ಇದು ಸುರಕ್ಷಿತವಾಗಿದೆ: `as_mut_slice` ನಿಖರವಾಗಿ ಉಪ-ಸ್ಲೈಸ್ ಅನ್ನು ನೀಡುತ್ತದೆ
        // ಇನ್ನೂ ಹೊರಹಾಕದ ಮತ್ತು ಕೈಬಿಡಬೇಕಾದ ಅಂಶಗಳ.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // ಅಸ್ಥಿರವಾದ 'ಜೀವಂತ.ಸ್ಟಾರ್ಟ್ <=ಕಾರಣದಿಂದಾಗಿ ಎಂದಿಗೂ ಉಕ್ಕಿ ಹರಿಯುವುದಿಲ್ಲ
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// ಪುನರಾವರ್ತಕವು ಸರಿಯಾದ ಉದ್ದವನ್ನು ವರದಿ ಮಾಡುತ್ತದೆ.
// "alive" ಅಂಶಗಳ ಸಂಖ್ಯೆ (ಅದು ಇನ್ನೂ ಫಲ ನೀಡಲಾಗುವುದು) `alive` ಶ್ರೇಣಿಯ ಉದ್ದವಾಗಿದೆ.
// ಈ ಶ್ರೇಣಿಯನ್ನು `next` ಅಥವಾ `next_back` ನಲ್ಲಿ ಉದ್ದದಲ್ಲಿ ಕಡಿಮೆ ಮಾಡಲಾಗಿದೆ.
// ಆ ವಿಧಾನಗಳಲ್ಲಿ ಇದನ್ನು ಯಾವಾಗಲೂ 1 ರಷ್ಟು ಕಡಿಮೆಗೊಳಿಸಲಾಗುತ್ತದೆ, ಆದರೆ `Some(_)` ಅನ್ನು ಹಿಂತಿರುಗಿಸಿದರೆ ಮಾತ್ರ.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // ಗಮನಿಸಿ, ನಾವು ನಿಖರವಾಗಿ ಅದೇ ಜೀವಂತ ಶ್ರೇಣಿಯನ್ನು ಹೊಂದಿಸುವ ಅಗತ್ಯವಿಲ್ಲ, ಆದ್ದರಿಂದ ನಾವು `self` ಎಲ್ಲಿದ್ದರೂ ಲೆಕ್ಕಿಸದೆ ಆಫ್‌ಸೆಟ್ 0 ಗೆ ಕ್ಲೋನ್ ಮಾಡಬಹುದು.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // ಎಲ್ಲಾ ಜೀವಂತ ಅಂಶಗಳನ್ನು ಕ್ಲೋನ್ ಮಾಡಿ.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // ಹೊಸ ಶ್ರೇಣಿಗೆ ತದ್ರೂಪಿ ಬರೆಯಿರಿ, ನಂತರ ಅದರ ಜೀವಂತ ಶ್ರೇಣಿಯನ್ನು ನವೀಕರಿಸಿ.
            // panics ಅನ್ನು ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮಾಡಿದರೆ, ನಾವು ಹಿಂದಿನ ವಸ್ತುಗಳನ್ನು ಸರಿಯಾಗಿ ಬಿಡುತ್ತೇವೆ.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // ಇನ್ನೂ ಇಳುವರಿ ನೀಡದ ಅಂಶಗಳನ್ನು ಮಾತ್ರ ಮುದ್ರಿಸಿ: ಇಳುವರಿ ನೀಡಿದ ಅಂಶಗಳನ್ನು ನಾವು ಇನ್ನು ಮುಂದೆ ಪ್ರವೇಶಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}