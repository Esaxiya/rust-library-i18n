//! 'ಸೂಚ್ಯವಾಗಿ ನಕಲಿಸಲಾಗದ' ಪ್ರಕಾರಗಳಿಗಾಗಿ `Clone` trait.
//!
//! Rust ನಲ್ಲಿ, ಕೆಲವು ಸರಳ ಪ್ರಕಾರಗಳು "implicitly copyable" ಮತ್ತು ನೀವು ಅವುಗಳನ್ನು ನಿಯೋಜಿಸಿದಾಗ ಅಥವಾ ಅವುಗಳನ್ನು ಆರ್ಗ್ಯುಮೆಂಟ್‌ಗಳಾಗಿ ರವಾನಿಸಿದಾಗ, ರಿಸೀವರ್ ನಕಲನ್ನು ಪಡೆಯುತ್ತದೆ, ಮೂಲ ಮೌಲ್ಯವನ್ನು ಸ್ಥಳದಲ್ಲಿ ಇಡುತ್ತದೆ.
//! ಈ ಪ್ರಕಾರಗಳಿಗೆ ನಕಲಿಸಲು ಹಂಚಿಕೆ ಅಗತ್ಯವಿಲ್ಲ ಮತ್ತು ಫೈನಲೈಜರ್‌ಗಳನ್ನು ಹೊಂದಿಲ್ಲ (ಅಂದರೆ, ಅವು ಒಡೆತನದ ಪೆಟ್ಟಿಗೆಗಳನ್ನು ಹೊಂದಿರುವುದಿಲ್ಲ ಅಥವಾ [`Drop`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತವೆ), ಆದ್ದರಿಂದ ಕಂಪೈಲರ್ ಅವುಗಳನ್ನು ಅಗ್ಗದ ಮತ್ತು ನಕಲಿಸಲು ಸುರಕ್ಷಿತವೆಂದು ಪರಿಗಣಿಸುತ್ತದೆ.
//!
//! [`Clone`] trait ಅನ್ನು ಜಾರಿಗೆ ತರುವ ಮೂಲಕ ಮತ್ತು [`clone`] ವಿಧಾನವನ್ನು ಕರೆಯುವ ಮೂಲಕ ಇತರ ಪ್ರಕಾರಗಳಿಗೆ ಪ್ರತಿಗಳನ್ನು ಸ್ಪಷ್ಟವಾಗಿ ಮಾಡಬೇಕು.
//!
//! [`clone`]: Clone::clone
//!
//! ಮೂಲ ಬಳಕೆಯ ಉದಾಹರಣೆ:
//!
//! ```
//! let s = String::new(); // ಸ್ಟ್ರಿಂಗ್ ಪ್ರಕಾರ ಕ್ಲೋನ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ
//! let copy = s.clone(); // ಆದ್ದರಿಂದ ನಾವು ಅದನ್ನು ಕ್ಲೋನ್ ಮಾಡಬಹುದು
//! ```
//!
//! ಕ್ಲೋನ್ trait ಅನ್ನು ಸುಲಭವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸಲು, ನೀವು `#[derive(Clone)]` ಅನ್ನು ಸಹ ಬಳಸಬಹುದು.ಉದಾಹರಣೆ:
//!
//! ```
//! #[derive(Clone)] // ನಾವು ಮಾರ್ಫಿಯಸ್ ಸ್ಟ್ರಕ್ಟ್‌ಗೆ trait ಕ್ಲೋನ್ ಅನ್ನು ಸೇರಿಸುತ್ತೇವೆ
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // ಮತ್ತು ಈಗ ನಾವು ಅದನ್ನು ಕ್ಲೋನ್ ಮಾಡಬಹುದು!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// ವಸ್ತುವನ್ನು ಸ್ಪಷ್ಟವಾಗಿ ನಕಲು ಮಾಡುವ ಸಾಮರ್ಥ್ಯಕ್ಕಾಗಿ ಸಾಮಾನ್ಯ trait.
///
/// ಆ [`Copy`] ನಲ್ಲಿ [`Copy`] ನಿಂದ ಭಿನ್ನವಾಗಿದೆ ಸೂಚ್ಯ ಮತ್ತು ಅತ್ಯಂತ ಅಗ್ಗವಾಗಿದೆ, ಆದರೆ `Clone` ಯಾವಾಗಲೂ ಸ್ಪಷ್ಟವಾಗಿರುತ್ತದೆ ಮತ್ತು ದುಬಾರಿಯಾಗಬಹುದು ಅಥವಾ ಇರಬಹುದು.
/// ಈ ಗುಣಲಕ್ಷಣಗಳನ್ನು ಜಾರಿಗೊಳಿಸಲು, [`Copy`] ಅನ್ನು ಮರುಹೊಂದಿಸಲು Rust ನಿಮಗೆ ಅನುಮತಿಸುವುದಿಲ್ಲ, ಆದರೆ ನೀವು `Clone` ಅನ್ನು ಮರುಹೊಂದಿಸಬಹುದು ಮತ್ತು ಅನಿಯಂತ್ರಿತ ಕೋಡ್ ಅನ್ನು ಚಲಾಯಿಸಬಹುದು.
///
/// [`Copy`] ಗಿಂತ `Clone` ಹೆಚ್ಚು ಸಾಮಾನ್ಯವಾದ ಕಾರಣ, ನೀವು ಸ್ವಯಂಚಾಲಿತವಾಗಿ [`Copy`] ಅನ್ನು `Clone` ಆಗಿ ಮಾಡಬಹುದು.
///
/// ## Derivable
///
/// ಎಲ್ಲಾ ಕ್ಷೇತ್ರಗಳು `Clone` ಆಗಿದ್ದರೆ ಈ trait ಅನ್ನು `#[derive]` ನೊಂದಿಗೆ ಬಳಸಬಹುದು.[`Clone`] ನ `ವ್ಯುತ್ಪನ್ನ` ಅನುಷ್ಠಾನವು ಪ್ರತಿ ಕ್ಷೇತ್ರದಲ್ಲಿ [`clone`] ಅನ್ನು ಕರೆಯುತ್ತದೆ.
///
/// [`clone`]: Clone::clone
///
/// ಜೆನೆರಿಕ್ ಸ್ಟ್ರಕ್ಟ್‌ಗಾಗಿ, ಜೆನೆರಿಕ್ ನಿಯತಾಂಕಗಳಲ್ಲಿ ಬೌಂಡ್ `Clone` ಅನ್ನು ಸೇರಿಸುವ ಮೂಲಕ `#[derive]` `Clone` ಅನ್ನು ಷರತ್ತುಬದ್ಧವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
///
/// ```
/// // `derive` ಓದುವಿಕೆಗಾಗಿ ಕ್ಲೋನ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ<T>ಟಿ ಕ್ಲೋನ್ ಆಗಿದ್ದಾಗ.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## `Clone` ಅನ್ನು ನಾನು ಹೇಗೆ ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು?
///
/// [`Copy`] ಆಗಿರುವ ಪ್ರಕಾರಗಳು `Clone` ನ ಕ್ಷುಲ್ಲಕ ಅನುಷ್ಠಾನವನ್ನು ಹೊಂದಿರಬೇಕು.ಹೆಚ್ಚು ly ಪಚಾರಿಕವಾಗಿ:
/// `T: Copy`, `x: T`, ಮತ್ತು `y: &T` ಆಗಿದ್ದರೆ, `let x = y.clone();` `let x = *y;` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ.
/// ಹಸ್ತಚಾಲಿತ ಅನುಷ್ಠಾನಗಳು ಈ ಅಸ್ಥಿರತೆಯನ್ನು ಎತ್ತಿಹಿಡಿಯಲು ಜಾಗರೂಕರಾಗಿರಬೇಕು;ಆದಾಗ್ಯೂ, ಮೆಮೊರಿ ಸುರಕ್ಷತೆಯನ್ನು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ಅಸುರಕ್ಷಿತ ಕೋಡ್ ಅದನ್ನು ಅವಲಂಬಿಸಬಾರದು.
///
/// ಫಂಕ್ಷನ್ ಪಾಯಿಂಟರ್ ಅನ್ನು ಹೊಂದಿರುವ ಜೆನೆರಿಕ್ ಸ್ಟ್ರಕ್ಟ್ ಒಂದು ಉದಾಹರಣೆಯಾಗಿದೆ.ಈ ಸಂದರ್ಭದಲ್ಲಿ, `Clone` ನ ಅನುಷ್ಠಾನವು `ವ್ಯುತ್ಪನ್ನ` ಆಗಲು ಸಾಧ್ಯವಿಲ್ಲ, ಆದರೆ ಇದನ್ನು ಹೀಗೆ ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## ಹೆಚ್ಚುವರಿ ಅನುಷ್ಠಾನಕಾರರು
///
/// [implementors listed below][impls] ಜೊತೆಗೆ, ಈ ಕೆಳಗಿನ ಪ್ರಕಾರಗಳು `Clone` ಅನ್ನು ಸಹ ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತವೆ:
///
/// * ಕಾರ್ಯ ಐಟಂ ಪ್ರಕಾರಗಳು (ಅಂದರೆ, ಪ್ರತಿ ಕಾರ್ಯಕ್ಕೂ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ವಿಭಿನ್ನ ಪ್ರಕಾರಗಳು)
/// * ಕಾರ್ಯ ಪಾಯಿಂಟರ್ ಪ್ರಕಾರಗಳು (ಉದಾ., `fn() -> i32`)
/// * ಐಟಂ ಪ್ರಕಾರವು `Clone` (ಉದಾ., `[i32; 123456]`) ಅನ್ನು ಸಹ ಕಾರ್ಯಗತಗೊಳಿಸಿದರೆ, ಎಲ್ಲಾ ಗಾತ್ರಗಳಿಗೆ ಅರೇ ಪ್ರಕಾರಗಳು
/// * ಟ್ಯುಪಲ್ ಪ್ರಕಾರಗಳು, ಪ್ರತಿಯೊಂದು ಘಟಕವು `Clone` ಅನ್ನು ಸಹ ಕಾರ್ಯಗತಗೊಳಿಸಿದರೆ (ಉದಾ., `()`, `(i32, bool)`)
/// * ಮುಚ್ಚುವ ಪ್ರಕಾರಗಳು, ಅವು ಪರಿಸರದಿಂದ ಯಾವುದೇ ಮೌಲ್ಯವನ್ನು ಸೆರೆಹಿಡಿಯದಿದ್ದರೆ ಅಥವಾ ಅಂತಹ ಎಲ್ಲಾ ಸೆರೆಹಿಡಿದ ಮೌಲ್ಯಗಳು `Clone` ಅನ್ನು ಸ್ವತಃ ಕಾರ್ಯಗತಗೊಳಿಸಿದರೆ.
///   ಹಂಚಿದ ಉಲ್ಲೇಖದಿಂದ ಸೆರೆಹಿಡಿಯಲಾದ ಅಸ್ಥಿರಗಳು ಯಾವಾಗಲೂ `Clone` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತವೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ (ಉಲ್ಲೇಖಿಸದಿದ್ದರೂ ಸಹ), ಆದರೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖದಿಂದ ಸೆರೆಹಿಡಿಯಲಾದ ಅಸ್ಥಿರಗಳು ಎಂದಿಗೂ `Clone` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದಿಲ್ಲ.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// ಮೌಲ್ಯದ ನಕಲನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str ಕ್ಲೋನ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// `source` ನಿಂದ ನಕಲು-ನಿಯೋಜನೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
    ///
    /// `a.clone_from(&b)` ಕ್ರಿಯಾತ್ಮಕತೆಯಲ್ಲಿ `a = b.clone()` ಗೆ ಸಮನಾಗಿರುತ್ತದೆ, ಆದರೆ ಅನಗತ್ಯ ಹಂಚಿಕೆಗಳನ್ನು ತಪ್ಪಿಸಲು `a` ನ ಸಂಪನ್ಮೂಲಗಳನ್ನು ಮರುಬಳಕೆ ಮಾಡಲು ಅತಿಕ್ರಮಿಸಬಹುದು.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// trait `Clone` ನ ಇಂಪಲ್ ಅನ್ನು ಉತ್ಪಾದಿಸುವ ಮ್ಯಾಕ್ರೋ ಅನ್ನು ಪಡೆಯಿರಿ.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): ಒಂದು ರೀತಿಯ ಪ್ರತಿಯೊಂದು ಘಟಕವು ಕ್ಲೋನ್ ಅಥವಾ ನಕಲನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ ಎಂದು ಪ್ರತಿಪಾದಿಸಲು ಈ ರಚನೆಗಳನ್ನು ಕೇವಲ#[ವ್ಯುತ್ಪನ್ನ] ಮೂಲಕ ಬಳಸಲಾಗುತ್ತದೆ.
//
//
// ಈ ರಚನೆಗಳು ಎಂದಿಗೂ ಬಳಕೆದಾರ ಕೋಡ್‌ನಲ್ಲಿ ಗೋಚರಿಸಬಾರದು.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// ಪ್ರಾಚೀನ ಪ್ರಕಾರಗಳಿಗೆ `Clone` ನ ಅನುಷ್ಠಾನಗಳು.
///
/// Rust ನಲ್ಲಿ ವಿವರಿಸಲಾಗದ ಅನುಷ್ಠಾನಗಳನ್ನು `rustc_trait_selection` ನಲ್ಲಿ `traits::SelectionContext::copy_clone_conditions()` ನಲ್ಲಿ ಅಳವಡಿಸಲಾಗಿದೆ.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// ಹಂಚಿದ ಉಲ್ಲೇಖಗಳನ್ನು ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮಾಡಬಹುದು, ಆದರೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳು *ಸಾಧ್ಯವಿಲ್ಲ*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// ಹಂಚಿದ ಉಲ್ಲೇಖಗಳನ್ನು ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮಾಡಬಹುದು, ಆದರೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳು *ಸಾಧ್ಯವಿಲ್ಲ*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}