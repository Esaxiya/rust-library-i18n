//! ಈ ಮಾಡ್ಯೂಲ್ ಇತರ ಘೋಷಿತ ಪ್ರಕಾರಗಳಿಂದ ನೆರಳು ಪಡೆಯದ ಬಳಕೆಯನ್ನು ಅನುಮತಿಸಲು ಪ್ರಾಚೀನ ಪ್ರಕಾರಗಳನ್ನು ಮರುಪರಿಶೀಲಿಸುತ್ತದೆ.
//!
//! ಇದು ಸಾಮಾನ್ಯವಾಗಿ ಮ್ಯಾಕ್ರೋ ರಚಿತ ಕೋಡ್‌ನಲ್ಲಿ ಮಾತ್ರ ಉಪಯುಕ್ತವಾಗಿದೆ.
//!
//! ಹೊಸ ರಚನೆ ಮತ್ತು ಅದಕ್ಕಾಗಿ ಒಂದು ಪ್ರಚೋದನೆಯನ್ನು ರಚಿಸುವಾಗ ಇದಕ್ಕೆ ಉದಾಹರಣೆಯಾಗಿದೆ:
//!
//! ```rust,compile_fail
//! pub struct bool;
//!
//! impl QueryId for bool {
//!     const SOME_PROPERTY: bool = true;
//! }
//!
//! # trait QueryId { const SOME_PROPERTY: core::primitive::bool; }
//! ```
//!
//! `SOME_PROPERTY` ಸಂಬಂಧಿತ ಸ್ಥಿರಾಂಕವು ಕಂಪೈಲ್ ಮಾಡುವುದಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಏಕೆಂದರೆ ಅದರ ಪ್ರಕಾರ `bool` ಪ್ರಾಚೀನ bool ಪ್ರಕಾರಕ್ಕಿಂತ ಹೆಚ್ಚಾಗಿ struct ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ.
//!
//!
//! ಸರಿಯಾದ ಅನುಷ್ಠಾನವು ಹೀಗಿರಬಹುದು:
//!
//! ```rust
//! # #[allow(non_camel_case_types)]
//! pub struct bool;
//!
//! impl QueryId for bool {
//!     const SOME_PROPERTY: core::primitive::bool = true;
//! }
//!
//! # trait QueryId { const SOME_PROPERTY: core::primitive::bool; }
//! ```
//!

#[stable(feature = "core_primitive", since = "1.43.0")]
pub use bool;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use char;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use f32;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use f64;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i128;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i16;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i32;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i64;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i8;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use isize;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use str;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u128;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u16;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u32;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u64;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u8;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use usize;