//! ಈ ಮಾಡ್ಯೂಲ್ `Any` trait ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ, ಇದು ರನ್ಟೈಮ್ ಪ್ರತಿಫಲನದ ಮೂಲಕ ಯಾವುದೇ `'static` ಪ್ರಕಾರದ ಡೈನಾಮಿಕ್ ಟೈಪಿಂಗ್ ಅನ್ನು ಶಕ್ತಗೊಳಿಸುತ್ತದೆ.
//!
//! `Any` `TypeId` ಪಡೆಯಲು ಸ್ವತಃ ಬಳಸಬಹುದು, ಮತ್ತು trait ವಸ್ತುವಾಗಿ ಬಳಸಿದಾಗ ಹೆಚ್ಚಿನ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಹೊಂದಿದೆ.
//! `&dyn Any` (ಎರವಲು ಪಡೆದ trait ಆಬ್ಜೆಕ್ಟ್) ನಂತೆ, ಇದು `is` ಮತ್ತು `downcast_ref` ವಿಧಾನಗಳನ್ನು ಹೊಂದಿದೆ, ಒಳಗೊಂಡಿರುವ ಮೌಲ್ಯವು ನಿರ್ದಿಷ್ಟ ಪ್ರಕಾರದಲ್ಲಿದೆಯೇ ಎಂದು ಪರೀಕ್ಷಿಸಲು ಮತ್ತು ಆಂತರಿಕ ಮೌಲ್ಯಕ್ಕೆ ಒಂದು ಪ್ರಕಾರವಾಗಿ ಉಲ್ಲೇಖವನ್ನು ಪಡೆಯಲು.
//! ಆಂತರಿಕ ಮೌಲ್ಯಕ್ಕೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಪಡೆಯಲು `&mut dyn Any` ನಂತೆ, `downcast_mut` ವಿಧಾನವೂ ಇದೆ.
//! `Box<dyn Any>` `downcast` ವಿಧಾನವನ್ನು ಸೇರಿಸುತ್ತದೆ, ಇದು `Box<T>` ಗೆ ಪರಿವರ್ತಿಸಲು ಪ್ರಯತ್ನಿಸುತ್ತದೆ.
//! ಪೂರ್ಣ ವಿವರಗಳಿಗಾಗಿ [`Box`] ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
//!
//! ಮೌಲ್ಯವು ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಕಾಂಕ್ರೀಟ್ ಪ್ರಕಾರವೇ ಎಂದು ಪರೀಕ್ಷಿಸಲು `&dyn Any` ಸೀಮಿತವಾಗಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಮತ್ತು ಒಂದು ಪ್ರಕಾರವು trait ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆಯೇ ಎಂದು ಪರೀಕ್ಷಿಸಲು ಬಳಸಲಾಗುವುದಿಲ್ಲ.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # ಸ್ಮಾರ್ಟ್ ಪಾಯಿಂಟರ್ಸ್ ಮತ್ತು ಎಕ್ಸ್ 00 ಎಕ್ಸ್
//!
//! `Any` ಅನ್ನು trait ವಸ್ತುವಾಗಿ ಬಳಸುವಾಗ, ವಿಶೇಷವಾಗಿ `Box<dyn Any>` ಅಥವಾ `Arc<dyn Any>` ನಂತಹ ಪ್ರಕಾರಗಳೊಂದಿಗೆ ನೆನಪಿನಲ್ಲಿಟ್ಟುಕೊಳ್ಳಬೇಕಾದ ಒಂದು ನಡವಳಿಕೆಯೆಂದರೆ, ಮೌಲ್ಯದ ಮೇಲೆ `.type_id()` ಅನ್ನು ಕರೆಯುವುದರಿಂದ *ಕಂಟೇನರ್* ನ `TypeId` ಅನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ, ಆದರೆ ಆಧಾರವಾಗಿರುವ trait ವಸ್ತುವಲ್ಲ.
//!
//! ಬದಲಿಗೆ ಸ್ಮಾರ್ಟ್ ಪಾಯಿಂಟರ್ ಅನ್ನು `&dyn Any` ಆಗಿ ಪರಿವರ್ತಿಸುವ ಮೂಲಕ ಇದನ್ನು ತಪ್ಪಿಸಬಹುದು, ಅದು ವಸ್ತುವಿನ `TypeId` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
//! ಉದಾಹರಣೆಗೆ:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // ನೀವು ಇದನ್ನು ಬಯಸುವ ಸಾಧ್ಯತೆ ಹೆಚ್ಚು:
//! let actual_id = (&*boxed).type_id();
//! // ... ಇದಕ್ಕಿಂತ:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! ಒಂದು ಕಾರ್ಯಕ್ಕೆ ರವಾನಿಸಲಾದ ಮೌಲ್ಯವನ್ನು ನಾವು ಲಾಗ್ to ಟ್ ಮಾಡಲು ಬಯಸುವ ಪರಿಸ್ಥಿತಿಯನ್ನು ಪರಿಗಣಿಸಿ.
//! ಡೀಬಗ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವಲ್ಲಿ ನಾವು ಕೆಲಸ ಮಾಡುತ್ತಿರುವ ಮೌಲ್ಯ ನಮಗೆ ತಿಳಿದಿದೆ, ಆದರೆ ಅದರ ಕಾಂಕ್ರೀಟ್ ಪ್ರಕಾರ ನಮಗೆ ತಿಳಿದಿಲ್ಲ.ನಾವು ಕೆಲವು ಪ್ರಕಾರಗಳಿಗೆ ವಿಶೇಷ ಚಿಕಿತ್ಸೆಯನ್ನು ನೀಡಲು ಬಯಸುತ್ತೇವೆ: ಈ ಸಂದರ್ಭದಲ್ಲಿ ಸ್ಟ್ರಿಂಗ್ ಮೌಲ್ಯಗಳ ಉದ್ದವನ್ನು ಅವುಗಳ ಮೌಲ್ಯಕ್ಕಿಂತ ಮೊದಲು ಮುದ್ರಿಸುತ್ತದೆ.
//! ಕಂಪೈಲ್ ಸಮಯದಲ್ಲಿ ನಮ್ಮ ಮೌಲ್ಯದ ಕಾಂಕ್ರೀಟ್ ಪ್ರಕಾರ ನಮಗೆ ತಿಳಿದಿಲ್ಲ, ಆದ್ದರಿಂದ ನಾವು ರನ್ಟೈಮ್ ಪ್ರತಿಫಲನವನ್ನು ಬಳಸಬೇಕಾಗಿದೆ.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // ಡೀಬಗ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಯಾವುದೇ ಪ್ರಕಾರದ ಲಾಗರ್ ಕಾರ್ಯ.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // ನಮ್ಮ ಮೌಲ್ಯವನ್ನು `String` ಗೆ ಪರಿವರ್ತಿಸಲು ಪ್ರಯತ್ನಿಸಿ.
//!     // ಯಶಸ್ವಿಯಾದರೆ, ನಾವು ಸ್ಟ್ರಿಂಗ್‌ನ ಉದ್ದ ಮತ್ತು ಅದರ ಮೌಲ್ಯವನ್ನು output ಟ್‌ಪುಟ್ ಮಾಡಲು ಬಯಸುತ್ತೇವೆ.
//!     // ಇಲ್ಲದಿದ್ದರೆ, ಇದು ಬೇರೆ ಪ್ರಕಾರವಾಗಿದೆ: ಅದನ್ನು ಅಲಂಕರಿಸದೆ ಮುದ್ರಿಸಿ.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // ಈ ಕಾರ್ಯವು ಅದರ ನಿಯತಾಂಕವನ್ನು ಅದರೊಂದಿಗೆ ಕೆಲಸ ಮಾಡುವ ಮೊದಲು ಲಾಗ್ out ಟ್ ಮಾಡಲು ಬಯಸುತ್ತದೆ.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... ಬೇರೆ ಯಾವುದಾದರೂ ಕೆಲಸ ಮಾಡಿ
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// ಯಾವುದೇ trait
///////////////////////////////////////////////////////////////////////////////

/// ಡೈನಾಮಿಕ್ ಟೈಪಿಂಗ್ ಅನ್ನು ಅನುಕರಿಸಲು trait.
///
/// ಹೆಚ್ಚಿನ ಪ್ರಕಾರಗಳು `Any` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತವೆ.ಆದಾಗ್ಯೂ, `ಸ್ಟ್ಯಾಟಿಕ್ ಅಲ್ಲದ` ಉಲ್ಲೇಖವನ್ನು ಹೊಂದಿರುವ ಯಾವುದೇ ಪ್ರಕಾರವು ಮಾಡುವುದಿಲ್ಲ.
/// ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ [module-level documentation][mod] ನೋಡಿ.
///
/// [mod]: crate::any
// ಈ trait ಅಸುರಕ್ಷಿತವಲ್ಲ, ಆದರೂ ನಾವು ಅಸುರಕ್ಷಿತ ಕೋಡ್‌ನಲ್ಲಿ (ಉದಾ., `downcast`) ಅದರ ಏಕೈಕ impl ನ `type_id` ಕಾರ್ಯದ ನಿಶ್ಚಿತಗಳನ್ನು ಅವಲಂಬಿಸಿದ್ದೇವೆ.ಸಾಮಾನ್ಯವಾಗಿ, ಅದು ಸಮಸ್ಯೆಯಾಗಿರುತ್ತದೆ, ಆದರೆ `Any` ನ ಏಕೈಕ ಪ್ರಚೋದನೆಯು ಕಂಬಳಿ ಅನುಷ್ಠಾನವಾಗಿರುವುದರಿಂದ, ಬೇರೆ ಯಾವುದೇ ಕೋಡ್ `Any` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದಿಲ್ಲ.
//
// ನಾವು ಈ trait ಅನ್ನು ಅಸುರಕ್ಷಿತವಾಗಿಸಬಹುದು-ಇದು ಎಲ್ಲಾ ಅನುಷ್ಠಾನಗಳನ್ನು ನಾವು ನಿಯಂತ್ರಿಸುವುದರಿಂದ ಅದು ಒಡೆಯಲು ಕಾರಣವಾಗುವುದಿಲ್ಲ-ಆದರೆ ಅದು ನಿಜವಾಗಿಯೂ ಅಗತ್ಯವಿಲ್ಲ ಎಂದು ನಾವು ಆರಿಸಿಕೊಳ್ಳುತ್ತೇವೆ ಮತ್ತು ಅಸುರಕ್ಷಿತ traits ಮತ್ತು ಅಸುರಕ್ಷಿತ ವಿಧಾನಗಳ ವ್ಯತ್ಯಾಸದ ಬಗ್ಗೆ ಬಳಕೆದಾರರನ್ನು ಗೊಂದಲಗೊಳಿಸಬಹುದು (ಅಂದರೆ, `type_id` ಕರೆ ಮಾಡಲು ಇನ್ನೂ ಸುರಕ್ಷಿತವಾಗಿರುತ್ತದೆ, ಆದರೆ ದಸ್ತಾವೇಜಿನಲ್ಲಿ ನಾವು ಸೂಚಿಸಲು ಬಯಸುತ್ತೇವೆ).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// `self` ನ `TypeId` ಅನ್ನು ಪಡೆಯುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// ಯಾವುದೇ trait ಆಬ್ಜೆಕ್ಟ್‌ಗಳಿಗೆ ವಿಸ್ತರಣೆ ವಿಧಾನಗಳು.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// ಉದಾ, ಥ್ರೆಡ್‌ಗೆ ಸೇರ್ಪಡೆಗೊಳ್ಳುವ ಫಲಿತಾಂಶವನ್ನು ಮುದ್ರಿಸಬಹುದೆಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ ಮತ್ತು ಆದ್ದರಿಂದ `unwrap` ನೊಂದಿಗೆ ಬಳಸಲಾಗುತ್ತದೆ.
// ರವಾನೆ ಅಪ್‌ಕಾಸ್ಟಿಂಗ್‌ನೊಂದಿಗೆ ಕೆಲಸ ಮಾಡಿದರೆ ಅಂತಿಮವಾಗಿ ಇನ್ನು ಮುಂದೆ ಅಗತ್ಯವಿಲ್ಲ.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// ಪೆಟ್ಟಿಗೆಯ ಪ್ರಕಾರವು `T` ನಂತೆಯೇ ಇದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // ಈ ಕಾರ್ಯವನ್ನು ತ್ವರಿತಗೊಳಿಸಿದ `TypeId` ಪ್ರಕಾರವನ್ನು ಪಡೆಯಿರಿ.
        let t = TypeId::of::<T>();

        // trait ಆಬ್ಜೆಕ್ಟ್ (`self`) ನಲ್ಲಿ ಪ್ರಕಾರದ `TypeId` ಪಡೆಯಿರಿ.
        let concrete = self.type_id();

        // ಸಮಾನತೆಯ ಮೇಲೆ `ಟೈಪ್‌ಐಡ್` ಎರಡನ್ನೂ ಹೋಲಿಕೆ ಮಾಡಿ.
        t == concrete
    }

    /// ಪೆಟ್ಟಿಗೆಯ ಮೌಲ್ಯವು `T` ಪ್ರಕಾರದಲ್ಲಿದ್ದರೆ ಅಥವಾ ಅದು ಇಲ್ಲದಿದ್ದರೆ `None` ಗೆ ಕೆಲವು ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // ಸುರಕ್ಷತೆ: ನಾವು ಸರಿಯಾದ ಪ್ರಕಾರವನ್ನು ತೋರಿಸುತ್ತೇವೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸಿದ್ದೇವೆ ಮತ್ತು ನಾವು ಅವಲಂಬಿಸಬಹುದು
            // ಮೆಮೊರಿ ಸುರಕ್ಷತೆಗಾಗಿ ಅದು ಪರಿಶೀಲಿಸುತ್ತದೆ ಏಕೆಂದರೆ ನಾವು ಎಲ್ಲ ಪ್ರಕಾರಗಳಿಗೆ ಯಾವುದನ್ನಾದರೂ ಜಾರಿಗೆ ತಂದಿದ್ದೇವೆ;ನಮ್ಮ ಇಂಪಲ್‌ನೊಂದಿಗೆ ಸಂಘರ್ಷಗೊಳ್ಳುವುದರಿಂದ ಬೇರೆ ಯಾವುದೇ ಇಂಪ್ಲ್‌ಗಳು ಅಸ್ತಿತ್ವದಲ್ಲಿಲ್ಲ.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// ಪೆಟ್ಟಿಗೆಯ ಮೌಲ್ಯವು `T` ಪ್ರಕಾರದಲ್ಲಿದ್ದರೆ ಅಥವಾ `None` ಇಲ್ಲದಿದ್ದರೆ ಕೆಲವು ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // ಸುರಕ್ಷತೆ: ನಾವು ಸರಿಯಾದ ಪ್ರಕಾರವನ್ನು ತೋರಿಸುತ್ತೇವೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸಿದ್ದೇವೆ ಮತ್ತು ನಾವು ಅವಲಂಬಿಸಬಹುದು
            // ಮೆಮೊರಿ ಸುರಕ್ಷತೆಗಾಗಿ ಅದು ಪರಿಶೀಲಿಸುತ್ತದೆ ಏಕೆಂದರೆ ನಾವು ಎಲ್ಲ ಪ್ರಕಾರಗಳಿಗೆ ಯಾವುದನ್ನಾದರೂ ಜಾರಿಗೆ ತಂದಿದ್ದೇವೆ;ನಮ್ಮ ಇಂಪಲ್‌ನೊಂದಿಗೆ ಸಂಘರ್ಷಗೊಳ್ಳುವುದರಿಂದ ಬೇರೆ ಯಾವುದೇ ಇಂಪ್ಲ್‌ಗಳು ಅಸ್ತಿತ್ವದಲ್ಲಿಲ್ಲ.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// `Any` ಪ್ರಕಾರದಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ವಿಧಾನಕ್ಕೆ ಫಾರ್ವರ್ಡ್ ಮಾಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` ಪ್ರಕಾರದಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ವಿಧಾನಕ್ಕೆ ಫಾರ್ವರ್ಡ್ ಮಾಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` ಪ್ರಕಾರದಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ವಿಧಾನಕ್ಕೆ ಫಾರ್ವರ್ಡ್ ಮಾಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// `Any` ಪ್ರಕಾರದಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ವಿಧಾನಕ್ಕೆ ಫಾರ್ವರ್ಡ್ ಮಾಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` ಪ್ರಕಾರದಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ವಿಧಾನಕ್ಕೆ ಫಾರ್ವರ್ಡ್ ಮಾಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` ಪ್ರಕಾರದಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ವಿಧಾನಕ್ಕೆ ಫಾರ್ವರ್ಡ್ ಮಾಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// ಟೈಪ್ಐಡಿ ಮತ್ತು ಅದರ ವಿಧಾನಗಳು
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` ಒಂದು ಪ್ರಕಾರಕ್ಕಾಗಿ ಜಾಗತಿಕವಾಗಿ ವಿಶಿಷ್ಟವಾದ ಗುರುತಿಸುವಿಕೆಯನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
///
/// ಪ್ರತಿಯೊಂದು `TypeId` ಅಪಾರದರ್ಶಕ ವಸ್ತುವಾಗಿದ್ದು ಅದು ಒಳಗಿನದನ್ನು ಪರೀಕ್ಷಿಸಲು ಅನುಮತಿಸುವುದಿಲ್ಲ ಆದರೆ ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ, ಹೋಲಿಕೆ, ಮುದ್ರಣ ಮತ್ತು ಪ್ರದರ್ಶನದಂತಹ ಮೂಲ ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಅನುಮತಿಸುತ್ತದೆ.
///
///
/// `'static` ಗೆ ಸೂಚಿಸುವ ಪ್ರಕಾರಗಳಿಗೆ ಮಾತ್ರ `TypeId` ಪ್ರಸ್ತುತ ಲಭ್ಯವಿದೆ, ಆದರೆ ಈ ಮಿತಿಯನ್ನು future ನಲ್ಲಿ ತೆಗೆದುಹಾಕಬಹುದು.
///
/// `TypeId` `Hash`, `PartialOrd`, ಮತ್ತು `Ord` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದರೆ, ಹ್ಯಾಶ್‌ಗಳು ಮತ್ತು ಆದೇಶವು Rust ಬಿಡುಗಡೆಗಳ ನಡುವೆ ಬದಲಾಗುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಬೇಕಾದ ಸಂಗತಿ.
/// ನಿಮ್ಮ ಕೋಡ್‌ನ ಒಳಗೆ ಅವುಗಳನ್ನು ಅವಲಂಬಿಸುವುದರ ಬಗ್ಗೆ ಎಚ್ಚರವಹಿಸಿ!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// ಈ ಜೆನೆರಿಕ್ ಕಾರ್ಯವನ್ನು ತ್ವರಿತಗೊಳಿಸಿದ ಪ್ರಕಾರದ `TypeId` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// ಒಂದು ಪ್ರಕಾರದ ಹೆಸರನ್ನು ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಆಗಿ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
///
/// # Note
///
/// ರೋಗನಿರ್ಣಯದ ಬಳಕೆಗಾಗಿ ಇದನ್ನು ಉದ್ದೇಶಿಸಲಾಗಿದೆ.
/// ಹಿಂತಿರುಗಿದ ಸ್ಟ್ರಿಂಗ್‌ನ ನಿಖರವಾದ ವಿಷಯಗಳು ಮತ್ತು ಸ್ವರೂಪವನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿಲ್ಲ, ಪ್ರಕಾರದ ಉತ್ತಮ ಪ್ರಯತ್ನದ ವಿವರಣೆಯನ್ನು ಹೊರತುಪಡಿಸಿ.
/// ಉದಾಹರಣೆಗೆ, `type_name::<Option<String>>()` ಹಿಂತಿರುಗಿಸಬಹುದಾದ ತಂತಿಗಳ ನಡುವೆ `"Option<String>"` ಮತ್ತು `"std::option::Option<std::string::String>"` ಇವೆ.
///
///
/// ಹಿಂದಿರುಗಿದ ಸ್ಟ್ರಿಂಗ್ ಅನ್ನು ಒಂದು ಪ್ರಕಾರದ ಅನನ್ಯ ಗುರುತಿಸುವಿಕೆ ಎಂದು ಪರಿಗಣಿಸಬಾರದು ಏಕೆಂದರೆ ಅನೇಕ ಪ್ರಕಾರಗಳು ಒಂದೇ ಪ್ರಕಾರದ ಹೆಸರಿಗೆ ನಕ್ಷೆ ಮಾಡಬಹುದು.
/// ಅಂತೆಯೇ, ಹಿಂತಿರುಗಿದ ಸ್ಟ್ರಿಂಗ್‌ನಲ್ಲಿ ಒಂದು ಪ್ರಕಾರದ ಎಲ್ಲಾ ಭಾಗಗಳು ಗೋಚರಿಸುತ್ತವೆ ಎಂಬುದಕ್ಕೆ ಯಾವುದೇ ಗ್ಯಾರಂಟಿ ಇಲ್ಲ: ಉದಾಹರಣೆಗೆ, ಜೀವಮಾನದ ನಿರ್ದಿಷ್ಟತೆಗಳನ್ನು ಪ್ರಸ್ತುತ ಸೇರಿಸಲಾಗಿಲ್ಲ.
/// ಹೆಚ್ಚುವರಿಯಾಗಿ, ಕಂಪೈಲರ್ ಆವೃತ್ತಿಗಳ ನಡುವೆ output ಟ್‌ಪುಟ್ ಬದಲಾಗಬಹುದು.
///
/// ಪ್ರಸ್ತುತ ಅನುಷ್ಠಾನವು ಕಂಪೈಲರ್ ಡಯಾಗ್ನೋಸ್ಟಿಕ್ಸ್ ಮತ್ತು ಡೀಬಗಿನ್‌ಫೊಗಳಂತೆಯೇ ಮೂಲಸೌಕರ್ಯವನ್ನು ಬಳಸುತ್ತದೆ, ಆದರೆ ಇದು ಖಾತರಿಯಿಲ್ಲ.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// ಪಾಯಿಂಟ್-ಟು ಮೌಲ್ಯದ ಪ್ರಕಾರದ ಹೆಸರನ್ನು ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್‌ನಂತೆ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
/// ಇದು `type_name::<T>()` ನಂತೆಯೇ ಇರುತ್ತದೆ, ಆದರೆ ವೇರಿಯೇಬಲ್ ಪ್ರಕಾರವು ಸುಲಭವಾಗಿ ಲಭ್ಯವಿಲ್ಲದಿದ್ದಲ್ಲಿ ಇದನ್ನು ಬಳಸಬಹುದು.
///
/// # Note
///
/// ರೋಗನಿರ್ಣಯದ ಬಳಕೆಗಾಗಿ ಇದನ್ನು ಉದ್ದೇಶಿಸಲಾಗಿದೆ.ಪ್ರಕಾರದ ಉತ್ತಮ ಪ್ರಯತ್ನದ ವಿವರಣೆಯ ಹೊರತಾಗಿ ಸ್ಟ್ರಿಂಗ್‌ನ ನಿಖರವಾದ ವಿಷಯಗಳು ಮತ್ತು ಸ್ವರೂಪವನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿಲ್ಲ.
/// ಉದಾಹರಣೆಗೆ, `type_name_of_val::<Option<String>>(None)` `"Option<String>"` ಅಥವಾ `"std::option::Option<std::string::String>"` ಅನ್ನು ಹಿಂತಿರುಗಿಸಬಹುದು, ಆದರೆ `"foobar"` ಅಲ್ಲ.
///
/// ಹೆಚ್ಚುವರಿಯಾಗಿ, ಕಂಪೈಲರ್ ಆವೃತ್ತಿಗಳ ನಡುವೆ output ಟ್‌ಪುಟ್ ಬದಲಾಗಬಹುದು.
///
/// ಈ ಕಾರ್ಯವು trait ಆಬ್ಜೆಕ್ಟ್‌ಗಳನ್ನು ಪರಿಹರಿಸುವುದಿಲ್ಲ, ಅಂದರೆ `type_name_of_val(&7u32 as &dyn Debug)` `"dyn Debug"` ಅನ್ನು ಹಿಂತಿರುಗಿಸಬಹುದು, ಆದರೆ `"u32"` ಅಲ್ಲ.
///
/// ಪ್ರಕಾರದ ಹೆಸರನ್ನು ಒಂದು ಪ್ರಕಾರದ ವಿಶಿಷ್ಟ ಗುರುತಿಸುವಿಕೆ ಎಂದು ಪರಿಗಣಿಸಬಾರದು;
/// ಅನೇಕ ಪ್ರಕಾರಗಳು ಒಂದೇ ರೀತಿಯ ಹೆಸರನ್ನು ಹಂಚಿಕೊಳ್ಳಬಹುದು.
///
/// ಪ್ರಸ್ತುತ ಅನುಷ್ಠಾನವು ಕಂಪೈಲರ್ ಡಯಾಗ್ನೋಸ್ಟಿಕ್ಸ್ ಮತ್ತು ಡೀಬಗಿನ್‌ಫೊಗಳಂತೆಯೇ ಮೂಲಸೌಕರ್ಯವನ್ನು ಬಳಸುತ್ತದೆ, ಆದರೆ ಇದು ಖಾತರಿಯಿಲ್ಲ.
///
/// # Examples
///
/// ಡೀಫಾಲ್ಟ್ ಪೂರ್ಣಾಂಕ ಮತ್ತು ಫ್ಲೋಟ್ ಪ್ರಕಾರಗಳನ್ನು ಮುದ್ರಿಸುತ್ತದೆ.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}