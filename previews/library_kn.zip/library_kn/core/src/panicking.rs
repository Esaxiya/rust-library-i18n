//! ಲಿಬ್‌ಕೋರ್‌ಗಾಗಿ Panic ಬೆಂಬಲ
//!
//! ಕೋರ್ ಲೈಬ್ರರಿಯು ಪ್ಯಾನಿಕ್ ಮಾಡುವುದನ್ನು ವ್ಯಾಖ್ಯಾನಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ, ಆದರೆ ಅದು ಪ್ಯಾನಿಕ್ ಮಾಡುವುದನ್ನು * ಘೋಷಿಸುತ್ತದೆ.
//! ಇದರರ್ಥ ಲಿಬ್‌ಕೋರ್‌ನೊಳಗಿನ ಕಾರ್ಯಗಳನ್ನು panic ಗೆ ಅನುಮತಿಸಲಾಗಿದೆ, ಆದರೆ ಉಪಯುಕ್ತವಾಗಲು ಅಪ್‌ಸ್ಟ್ರೀಮ್ crate ಲಿಬ್‌ಕೋರ್ ಬಳಸಲು ಭಯವನ್ನು ವ್ಯಾಖ್ಯಾನಿಸಬೇಕು.
//! ಪ್ಯಾನಿಕ್ ಮಾಡಲು ಪ್ರಸ್ತುತ ಇಂಟರ್ಫೇಸ್ ಹೀಗಿದೆ:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! ಈ ವ್ಯಾಖ್ಯಾನವು ಯಾವುದೇ ಸಾಮಾನ್ಯ ಸಂದೇಶದೊಂದಿಗೆ ಭಯಭೀತರಾಗಲು ಅನುಮತಿಸುತ್ತದೆ, ಆದರೆ ಇದು `Box<Any>` ಮೌಲ್ಯದೊಂದಿಗೆ ವಿಫಲಗೊಳ್ಳಲು ಅನುಮತಿಸುವುದಿಲ್ಲ.
//! (`PanicInfo` ಕೇವಲ `&(dyn Any + Send)` ಅನ್ನು ಹೊಂದಿದೆ, ಇದಕ್ಕಾಗಿ ನಾವು `PanicInfo: : internal_constructor` ನಲ್ಲಿ ನಕಲಿ ಮೌಲ್ಯವನ್ನು ತುಂಬುತ್ತೇವೆ.) ಇದಕ್ಕೆ ಕಾರಣವೆಂದರೆ ಲಿಬ್‌ಕೋರ್ ಅನ್ನು ನಿಯೋಜಿಸಲು ಅನುಮತಿಸಲಾಗುವುದಿಲ್ಲ.
//!
//!
//! ಈ ಮಾಡ್ಯೂಲ್ ಕೆಲವು ಇತರ ಭೀತಿಗೊಳಿಸುವ ಕಾರ್ಯಗಳನ್ನು ಒಳಗೊಂಡಿದೆ, ಆದರೆ ಇವು ಕಂಪೈಲರ್‌ಗೆ ಅಗತ್ಯವಾದ ಲ್ಯಾಂಗ್ ವಸ್ತುಗಳು.ಎಲ್ಲಾ panics ಅನ್ನು ಈ ಒಂದು ಕಾರ್ಯದ ಮೂಲಕ ಜೋಡಿಸಲಾಗುತ್ತದೆ.
//! ನಿಜವಾದ ಚಿಹ್ನೆಯನ್ನು `#[panic_handler]` ಗುಣಲಕ್ಷಣದ ಮೂಲಕ ಘೋಷಿಸಲಾಗುತ್ತದೆ.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// ಯಾವುದೇ ಫಾರ್ಮ್ಯಾಟಿಂಗ್ ಬಳಸದಿದ್ದಾಗ ಲಿಬ್‌ಕೋರ್‌ನ `panic!` ಮ್ಯಾಕ್ರೊದ ಆಧಾರವಾಗಿರುವ ಅನುಷ್ಠಾನ.
#[cold]
// ಕಾಲ್ ಸೈಟ್‌ಗಳಲ್ಲಿ ಸಾಧ್ಯವಾದಷ್ಟು ಕೋಡ್ ಉಬ್ಬುವುದನ್ನು ತಪ್ಪಿಸಲು ಪ್ಯಾನಿಕ್_ಇಮ್ಮಿಡಿಯೇಟ್_ಅಬೋರ್ಟ್ ಹೊರತು ಎಂದಿಗೂ ಇನ್ಲೈನ್ ಮಾಡಬೇಡಿ
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // ಓವರ್‌ಫ್ಲೋ ಮತ್ತು ಇತರ `Assert` MIR ಟರ್ಮಿನೇಟರ್‌ಗಳಲ್ಲಿ panic ಗಾಗಿ ಕೋಡ್‌ಜೆನ್ ಅಗತ್ಯವಿದೆ
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // ಗಾತ್ರ ಓವರ್ಹೆಡ್ ಅನ್ನು ಕಡಿಮೆ ಮಾಡಲು ಫಾರ್ಮ್ಯಾಟ್_ಆರ್ಗ್ಸ್! ("{}", ಎಕ್ಸ್‌ಪ್ರೆಸ್) ಬದಲಿಗೆ Arguments::new_v1 ಬಳಸಿ.
    // ಫಾರ್ಮ್ಯಾಟ್_ಆರ್ಗ್ಸ್!ಎಕ್ಸ್‌ಪ್ರೆಸ್ ಬರೆಯಲು ಮ್ಯಾಕ್ರೊ ಸ್ಟ್ರಸ್‌ನ ಡಿಸ್ಪ್ಲೇ trait ಅನ್ನು ಬಳಸುತ್ತದೆ, ಇದನ್ನು Formatter::pad ಎಂದು ಕರೆಯುತ್ತದೆ, ಇದು ಸ್ಟ್ರಿಂಗ್ ಮೊಟಕುಗೊಳಿಸುವಿಕೆ ಮತ್ತು ಪ್ಯಾಡಿಂಗ್ ಅನ್ನು ಹೊಂದಿರಬೇಕು (ಇಲ್ಲಿ ಯಾವುದನ್ನೂ ಬಳಸದಿದ್ದರೂ ಸಹ).
    //
    // Arguments::new_v1 ಅನ್ನು ಬಳಸುವುದರಿಂದ ಕಂಪೈಲರ್ X ಟ್ಪುಟ್ ಬೈನರಿ ಯಿಂದ Formatter::pad ಅನ್ನು ಬಿಟ್ಟುಬಿಡಲು ಅನುಮತಿಸಬಹುದು, ಕೆಲವು ಕಿಲೋಬೈಟ್‌ಗಳವರೆಗೆ ಉಳಿಸುತ್ತದೆ.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // ಕಾನ್ಸ್-ಮೌಲ್ಯಮಾಪನ ಮಾಡಿದ panics ಗೆ ಅಗತ್ಯವಿದೆ
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // OOB array/slice ಪ್ರವೇಶದಲ್ಲಿ panic ಗಾಗಿ ಕೋಡ್‌ಜೆನ್ ಅಗತ್ಯವಿದೆ
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// ಫಾರ್ಮ್ಯಾಟಿಂಗ್ ಬಳಸುವಾಗ ಲಿಬ್‌ಕೋರ್‌ನ `panic!` ಮ್ಯಾಕ್ರೊದ ಆಧಾರವಾಗಿರುವ ಅನುಷ್ಠಾನ.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // ಸೂಚನೆ ಈ ಕಾರ್ಯವು ಎಂದಿಗೂ ಎಫ್‌ಎಫ್‌ಐ ಗಡಿಯನ್ನು ದಾಟುವುದಿಲ್ಲ;ಇದು Rust-to-Rust ಕರೆ, ಅದು `#[panic_handler]` ಕಾರ್ಯಕ್ಕೆ ಪರಿಹರಿಸಲ್ಪಡುತ್ತದೆ.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // ಸುರಕ್ಷತೆ: `panic_impl` ಅನ್ನು ಸುರಕ್ಷಿತ Rust ಕೋಡ್‌ನಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿದೆ ಮತ್ತು ಆದ್ದರಿಂದ ಕರೆ ಮಾಡಲು ಸುರಕ್ಷಿತವಾಗಿದೆ.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// `assert_eq!` ಮತ್ತು `assert_ne!` ಮ್ಯಾಕ್ರೋಗಳಿಗಾಗಿ ಆಂತರಿಕ ಕಾರ್ಯ
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}