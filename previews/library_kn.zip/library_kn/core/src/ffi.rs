#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! ವಿದೇಶಿ ಕಾರ್ಯ ಇಂಟರ್ಫೇಸ್ (FFI) ಬೈಂಡಿಂಗ್ಗೆ ಸಂಬಂಧಿಸಿದ ಉಪಯುಕ್ತತೆಗಳು.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// [pointer] ಆಗಿ ಬಳಸಿದಾಗ C ನ `void` ಪ್ರಕಾರಕ್ಕೆ ಸಮ.
///
/// ಮೂಲಭೂತವಾಗಿ, `*const c_void` C ನ `const void*` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ ಮತ್ತು `*mut c_void` C ನ `void*` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ.
/// ಅದು ಸಿ ಯ `void` ರಿಟರ್ನ್ ಪ್ರಕಾರಕ್ಕೆ ಸಮನಾಗಿಲ್ಲ, ಅದು Rust ನ `()` ಪ್ರಕಾರವಾಗಿದೆ.
///
/// ಎಫ್‌ಎಫ್‌ಐನಲ್ಲಿ ಅಪಾರದರ್ಶಕ ಪ್ರಕಾರಗಳಿಗೆ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ರೂಪಿಸಲು, ಎಕ್ಸ್‌00 ಎಕ್ಸ್ ಸ್ಥಿರಗೊಳ್ಳುವವರೆಗೆ, ಖಾಲಿ ಬೈಟ್ ರಚನೆಯ ಸುತ್ತಲೂ ನ್ಯೂಟೈಪ್ ಹೊದಿಕೆಯನ್ನು ಬಳಸಲು ಸೂಚಿಸಲಾಗುತ್ತದೆ.
///
/// ವಿವರಗಳಿಗಾಗಿ [Nomicon] ನೋಡಿ.
///
/// ಹಳೆಯ Rust ಕಂಪೈಲರ್ ಅನ್ನು 1.1.0 ಗೆ ಬೆಂಬಲಿಸಲು ಅವರು ಬಯಸಿದರೆ `std::os::raw::c_void` ಅನ್ನು ಬಳಸಬಹುದು.
/// Rust 1.30.0 ನಂತರ, ಈ ವ್ಯಾಖ್ಯಾನದಿಂದ ಅದನ್ನು ಮರು-ರಫ್ತು ಮಾಡಲಾಗಿದೆ.
/// ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ, ದಯವಿಟ್ಟು [RFC 2521] ಓದಿ.
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, ಅನೂರ್ಜಿತ ಪಾಯಿಂಟರ್ ಪ್ರಕಾರವನ್ನು ಗುರುತಿಸಲು LLVM ಗಾಗಿ ಮತ್ತು malloc() ನಂತಹ ವಿಸ್ತರಣಾ ಕಾರ್ಯಗಳಿಂದ, ನಾವು ಅದನ್ನು LLVM ಬಿಟ್‌ಕೋಡ್‌ನಲ್ಲಿ i8 * ಎಂದು ಪ್ರತಿನಿಧಿಸಬೇಕಾಗಿದೆ.
// ಇಲ್ಲಿ ಬಳಸುವ ಎನಮ್ ಇದನ್ನು ಖಚಿತಪಡಿಸುತ್ತದೆ ಮತ್ತು ಖಾಸಗಿ ರೂಪಾಂತರಗಳನ್ನು ಮಾತ್ರ ಹೊಂದುವ ಮೂಲಕ "raw" ಪ್ರಕಾರದ ದುರುಪಯೋಗವನ್ನು ತಡೆಯುತ್ತದೆ.
// ನಮಗೆ ಎರಡು ರೂಪಾಂತರಗಳು ಬೇಕಾಗುತ್ತವೆ, ಏಕೆಂದರೆ ಕಂಪೈಲರ್ repr ಗುಣಲಕ್ಷಣದ ಬಗ್ಗೆ ದೂರು ನೀಡುತ್ತಾರೆ ಮತ್ತು ನಮಗೆ ಕನಿಷ್ಠ ಒಂದು ರೂಪಾಂತರದ ಅಗತ್ಯವಿರುತ್ತದೆ, ಇಲ್ಲದಿದ್ದರೆ ಎನಮ್ ಜನವಸತಿ ಇರುವುದಿಲ್ಲ ಮತ್ತು ಕನಿಷ್ಠ ಅಂತಹ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಡಿಫರೆನ್ಸಿಂಗ್ ಮಾಡುವುದು ಯುಬಿ ಆಗಿರುತ್ತದೆ.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// `va_list` ನ ಮೂಲ ಅನುಷ್ಠಾನ.
// ಹೆಸರು WIP, ಇದೀಗ `VaListImpl` ಅನ್ನು ಬಳಸುತ್ತಿದೆ.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // `'f` ಗಿಂತ ಅಸ್ಥಿರವಾಗಿದೆ, ಆದ್ದರಿಂದ ಪ್ರತಿ `VaListImpl<'f>` ಆಬ್ಜೆಕ್ಟ್ ಅದನ್ನು ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ಕಾರ್ಯದ ಪ್ರದೇಶದೊಂದಿಗೆ ಕಟ್ಟಲಾಗುತ್ತದೆ
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 `va_list` ನ ಎಬಿಐ ಅನುಷ್ಠಾನ.
/// ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ [AArch64 Procedure Call Standard] ನೋಡಿ.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC `va_list` ನ ಎಬಿಐ ಅನುಷ್ಠಾನ.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 `va_list` ನ ಎಬಿಐ ಅನುಷ್ಠಾನ.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// `va_list` ಗಾಗಿ ಹೊದಿಕೆ
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// `VaListImpl` ಅನ್ನು `VaList` ಆಗಿ ಪರಿವರ್ತಿಸಿ ಅದು C ನ `va_list` ನೊಂದಿಗೆ ಬೈನರಿ-ಹೊಂದಿಕೊಳ್ಳುತ್ತದೆ.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// `VaListImpl` ಅನ್ನು `VaList` ಆಗಿ ಪರಿವರ್ತಿಸಿ ಅದು C ನ `va_list` ನೊಂದಿಗೆ ಬೈನರಿ-ಹೊಂದಿಕೊಳ್ಳುತ್ತದೆ.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait ಅನ್ನು ಸಾರ್ವಜನಿಕ ಸಂಪರ್ಕಸಾಧನಗಳಲ್ಲಿ ಬಳಸಬೇಕಾಗಿದೆ, ಆದಾಗ್ಯೂ, trait ಅನ್ನು ಈ ಮಾಡ್ಯೂಲ್‌ನ ಹೊರಗೆ ಬಳಸಲು ಅನುಮತಿಸಬಾರದು.
// ಹೊಸ ಪ್ರಕಾರಕ್ಕಾಗಿ trait ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ಬಳಕೆದಾರರಿಗೆ ಅವಕಾಶ ಮಾಡಿಕೊಡುವುದು (ಆ ಮೂಲಕ va_arg ಅನ್ನು ಹೊಸ ಪ್ರಕಾರದಲ್ಲಿ ಬಳಸಲು ಅನುಮತಿಸುತ್ತದೆ) ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗಬಹುದು.
//
// FIXME(dlrobertson): ಸಾರ್ವಜನಿಕ ಇಂಟರ್ಫೇಸ್‌ನಲ್ಲಿ VaArgSafe trait ಅನ್ನು ಬಳಸಲು ಆದರೆ ಅದನ್ನು ಬೇರೆಡೆ ಬಳಸಲಾಗುವುದಿಲ್ಲ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು, trait ಖಾಸಗಿ ಮಾಡ್ಯೂಲ್‌ನಲ್ಲಿ ಸಾರ್ವಜನಿಕವಾಗಿರಬೇಕು.
// ಆರ್‌ಎಫ್‌ಸಿ 2145 ಅನ್ನು ಜಾರಿಗೆ ತಂದ ನಂತರ ಇದನ್ನು ಸುಧಾರಿಸಲು ನೋಡಿ.
//
//
//
//
mod sealed_trait {
    /// Trait ಇದು [super::VaListImpl::arg] ನೊಂದಿಗೆ ಅನುಮತಿಸಲಾದ ಪ್ರಕಾರಗಳನ್ನು ಬಳಸಲು ಅನುಮತಿಸುತ್ತದೆ.
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// ಮುಂದಿನ ಆರ್ಗ್‌ಗೆ ಮುನ್ನಡೆಯಿರಿ.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `va_arg` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
        unsafe { va_arg(self) }
    }

    /// ಪ್ರಸ್ತುತ ಸ್ಥಳದಲ್ಲಿ `va_list` ಅನ್ನು ನಕಲಿಸುತ್ತದೆ.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // ಸುರಕ್ಷತೆ: ಕರೆ ಮಾಡುವವರು `va_end` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // ಸುರಕ್ಷತೆ: ನಾವು `MaybeUninit` ಗೆ ಬರೆಯುತ್ತೇವೆ, ಆದ್ದರಿಂದ ಇದನ್ನು ಪ್ರಾರಂಭಿಸಲಾಗುತ್ತದೆ ಮತ್ತು `assume_init` ಕಾನೂನುಬದ್ಧವಾಗಿರುತ್ತದೆ
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: ಇದು `va_end` ಎಂದು ಕರೆಯಬೇಕು, ಆದರೆ ಇದಕ್ಕೆ ಯಾವುದೇ ಸ್ವಚ್ way ವಾದ ಮಾರ್ಗವಿಲ್ಲ
        // `drop` ಯಾವಾಗಲೂ ಅದರ ಕಾಲರ್‌ಗೆ ಇನ್‌ಲೈನ್ ಆಗುತ್ತದೆ ಎಂದು ಖಾತರಿಪಡಿಸುತ್ತದೆ, ಆದ್ದರಿಂದ `va_end` ಅನ್ನು ಅನುಗುಣವಾದ `va_copy` ನಂತೆಯೇ ಅದೇ ಕಾರ್ಯದಿಂದ ನೇರವಾಗಿ ಕರೆಯಲಾಗುತ್ತದೆ.
        // `man va_end` C ಗೆ ಇದು ಅಗತ್ಯವೆಂದು ಹೇಳುತ್ತದೆ, ಮತ್ತು LLVM ಮೂಲತಃ C ಶಬ್ದಾರ್ಥವನ್ನು ಅನುಸರಿಸುತ್ತದೆ, ಆದ್ದರಿಂದ `va_end` ಅನ್ನು ಯಾವಾಗಲೂ `va_copy` ನಂತೆಯೇ ಅದೇ ಕಾರ್ಯದಿಂದ ಕರೆಯಲಾಗುತ್ತದೆ ಎಂದು ನಾವು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು.
        //
        // ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // ಇದು ಈಗಿನವರೆಗೆ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ, ಏಕೆಂದರೆ `va_end` ಎಲ್ಲಾ ಪ್ರಸ್ತುತ LLVM ಗುರಿಗಳಲ್ಲಿ ಯಾವುದೇ ಆಯ್ಕೆಯಾಗಿಲ್ಲ.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// `va_start` ಅಥವಾ `va_copy` ನೊಂದಿಗೆ ಪ್ರಾರಂಭಿಸಿದ ನಂತರ ಆರ್ಗ್ಲಿಸ್ಟ್ `ap` ಅನ್ನು ನಾಶಮಾಡಿ.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// ಆರ್ಗ್ಲಿಸ್ಟ್ `src` ನ ಪ್ರಸ್ತುತ ಸ್ಥಳವನ್ನು ಆರ್ಗ್ಲಿಸ್ಟ್ `dst` ಗೆ ನಕಲಿಸುತ್ತದೆ.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// `va_list` `ap` ನಿಂದ `T` ಪ್ರಕಾರದ ಆರ್ಗ್ಯುಮೆಂಟ್ ಅನ್ನು ಲೋಡ್ ಮಾಡುತ್ತದೆ ಮತ್ತು `ap` ಪಾಯಿಂಟ್‌ಗಳನ್ನು ಆರ್ಗ್ಯುಮೆಂಟ್ ಅನ್ನು ಹೆಚ್ಚಿಸಿ.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}