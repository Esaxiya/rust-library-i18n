use crate::marker::Unsize;

/// Trait ಇದು ಪಾಯಿಂಟರ್ ಅಥವಾ ಒಂದಕ್ಕೆ ಹೊದಿಕೆ ಎಂದು ಸೂಚಿಸುತ್ತದೆ, ಅಲ್ಲಿ ಪಾಯಿಂಟಿಯಲ್ಲಿ ಗಾತ್ರವನ್ನು ಮಾಡಬಹುದು.
///
/// ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ [DST coercion RFC][dst-coerce] ಮತ್ತು [the nomicon entry on coercion][nomicon-coerce] ನೋಡಿ.
///
/// ಅಂತರ್ನಿರ್ಮಿತ ಪಾಯಿಂಟರ್ ಪ್ರಕಾರಗಳಿಗಾಗಿ, ತೆಳುವಾದ ಪಾಯಿಂಟರ್‌ನಿಂದ ಕೊಬ್ಬಿನ ಪಾಯಿಂಟರ್‌ಗೆ ಪರಿವರ್ತಿಸುವ ಮೂಲಕ `T: Unsize<U>` ಆಗಿದ್ದರೆ `T` ಗೆ ಪಾಯಿಂಟರ್‌ಗಳು `U` ಗೆ ಪಾಯಿಂಟರ್‌ಗಳಿಗೆ ಒತ್ತಾಯಿಸುತ್ತದೆ.
///
/// ಕಸ್ಟಮ್ ಪ್ರಕಾರಗಳಿಗಾಗಿ, ಇಲ್ಲಿ ಬಲಾತ್ಕಾರವು `Foo<T>` ಅನ್ನು `Foo<U>` ಗೆ ಒತ್ತಾಯಿಸುವ ಮೂಲಕ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ.
/// `Foo<T>` ನಲ್ಲಿ `T` ಒಳಗೊಂಡ ಒಂದೇ ಫ್ಯಾಂಟಮ್‌ಡೇಟಾ ಕ್ಷೇತ್ರವಿಲ್ಲದಿದ್ದರೆ ಮಾತ್ರ ಅಂತಹ ಇಂಪ್ಲ್ ಅನ್ನು ಬರೆಯಬಹುದು.
/// ಆ ಕ್ಷೇತ್ರದ ಪ್ರಕಾರವು `Bar<T>` ಆಗಿದ್ದರೆ, `CoerceUnsized<Bar<U>> for Bar<T>` ನ ಅನುಷ್ಠಾನ ಅಸ್ತಿತ್ವದಲ್ಲಿರಬೇಕು.
/// `Bar<T>` ಕ್ಷೇತ್ರವನ್ನು `Bar<U>` ಗೆ ಒತ್ತಾಯಿಸುವ ಮೂಲಕ ಮತ್ತು `Foo<U>` ಅನ್ನು ರಚಿಸಲು `Foo<T>` ನಿಂದ ಉಳಿದ ಕ್ಷೇತ್ರಗಳನ್ನು ಭರ್ತಿ ಮಾಡುವ ಮೂಲಕ ಬಲವಂತವು ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ.
/// ಇದು ಪರಿಣಾಮಕಾರಿಯಾಗಿ ಪಾಯಿಂಟರ್ ಕ್ಷೇತ್ರಕ್ಕೆ ಕೊರೆಯುತ್ತದೆ ಮತ್ತು ಅದನ್ನು ಒತ್ತಾಯಿಸುತ್ತದೆ.
///
/// ಸಾಮಾನ್ಯವಾಗಿ, ಸ್ಮಾರ್ಟ್ ಪಾಯಿಂಟರ್‌ಗಳಿಗಾಗಿ ನೀವು `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತೀರಿ, ಐಚ್ al ಿಕ `?Sized` ಅನ್ನು `T` ನಲ್ಲಿಯೇ ಬಂಧಿಸಲಾಗುತ್ತದೆ.
/// `Cell<T>` ಮತ್ತು `RefCell<T>` ನಂತಹ `T` ಅನ್ನು ನೇರವಾಗಿ ಎಂಬೆಡ್ ಮಾಡುವ ಹೊದಿಕೆ ಪ್ರಕಾರಗಳಿಗಾಗಿ, ನೀವು ನೇರವಾಗಿ `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು.
///
/// ಇದು `Cell<Box<T>>` ನಂತಹ ವಿಧಗಳ ಬಲಾತ್ಕಾರಗಳನ್ನು ಕೆಲಸ ಮಾಡಲು ಅನುಮತಿಸುತ್ತದೆ.
///
/// [`Unsize`][unsize] ಪಾಯಿಂಟರ್‌ಗಳ ಹಿಂದೆ ಇದ್ದರೆ ಡಿಎಸ್‌ಟಿಗಳಿಗೆ ಒತ್ತಾಯಿಸಬಹುದಾದ ಪ್ರಕಾರಗಳನ್ನು ಗುರುತಿಸಲು ಬಳಸಲಾಗುತ್ತದೆ.ಇದನ್ನು ಕಂಪೈಲರ್ ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut ಟಿ-> ಎಕ್ಸ್ 00 ಎಕ್ಸ್ ಯು
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut ಟಿ-> ಎಕ್ಸ್ 00 ಎಕ್ಸ್
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut ಟಿ-> * ಮಟ್ ಯು
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut ಟಿ-> * const ಯು
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *ಮ್ಯೂಟ್ ಟಿ->* ಮಟ್ ಯು
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *ಮ್ಯೂಟ್ ಟಿ->* ಕಾನ್ಸ್ ಯು
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// ಒಂದು ವಿಧಾನದ ರಿಸೀವರ್ ಪ್ರಕಾರವನ್ನು ರವಾನಿಸಬಹುದೇ ಎಂದು ಪರಿಶೀಲಿಸಲು ಇದನ್ನು ಆಬ್ಜೆಕ್ಟ್ ಸುರಕ್ಷತೆಗಾಗಿ ಬಳಸಲಾಗುತ್ತದೆ.
///
/// trait ನ ಉದಾಹರಣೆ ಅನುಷ್ಠಾನ:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut ಟಿ-> ಎಕ್ಸ್ 00 ಎಕ್ಸ್ ಯು
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U.
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *ಮ್ಯೂಟ್ ಟಿ->* ಮಟ್ ಯು
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}