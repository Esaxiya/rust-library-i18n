use crate::fmt;
use crate::hash::Hash;

/// ಮಿತಿಯಿಲ್ಲದ ಶ್ರೇಣಿ (`..`).
///
/// `RangeFull` ಇದನ್ನು ಪ್ರಾಥಮಿಕವಾಗಿ [slicing index] ಆಗಿ ಬಳಸಲಾಗುತ್ತದೆ, ಇದರ ಸಂಕ್ಷಿಪ್ತ ರೂಪ `..` ಆಗಿದೆ.
/// ಇದು [`Iterator`] ಆಗಿ ಕಾರ್ಯನಿರ್ವಹಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ ಏಕೆಂದರೆ ಅದು ಪ್ರಾರಂಭದ ಹಂತವನ್ನು ಹೊಂದಿಲ್ಲ.
///
/// # Examples
///
/// `..` ಸಿಂಟ್ಯಾಕ್ಸ್ `RangeFull` ಆಗಿದೆ:
///
/// ```
/// assert_eq!((..), std::ops::RangeFull);
/// ```
///
/// ಇದು [`IntoIterator`] ಅನುಷ್ಠಾನವನ್ನು ಹೊಂದಿಲ್ಲ, ಆದ್ದರಿಂದ ನೀವು ಅದನ್ನು ನೇರವಾಗಿ `for` ಲೂಪ್‌ನಲ್ಲಿ ಬಳಸಲಾಗುವುದಿಲ್ಲ.
/// ಇದು ಕಂಪೈಲ್ ಮಾಡುವುದಿಲ್ಲ:
///
/// ```compile_fail,E0277
/// for i in .. {
///     // ...
/// }
/// ```
///
/// [slicing index] ಆಗಿ ಬಳಸಲಾಗುತ್ತದೆ, `RangeFull` ಪೂರ್ಣ ಶ್ರೇಣಿಯನ್ನು ಸ್ಲೈಸ್‌ನಂತೆ ಉತ್ಪಾದಿಸುತ್ತದೆ.
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]); // ಇದು `RangeFull` ಆಗಿದೆ
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeFull"]
#[doc(alias = "..")]
#[derive(Copy, Clone, Default, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFull;

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for RangeFull {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")
    }
}

/// (half-open) ಶ್ರೇಣಿಯು ಎಲ್ಲರನ್ನೂ ಒಳಗೊಂಡಂತೆ ಮತ್ತು ಪ್ರತ್ಯೇಕವಾಗಿ (`start..end`) ಗಿಂತ ಮೇಲಿರುತ್ತದೆ.
///
///
/// `start..end` ಶ್ರೇಣಿ `start <= x < end` ನೊಂದಿಗೆ ಎಲ್ಲಾ ಮೌಲ್ಯಗಳನ್ನು ಒಳಗೊಂಡಿದೆ.
/// `start >= end` ಇದ್ದರೆ ಅದು ಖಾಲಿಯಾಗಿದೆ.
///
/// # Examples
///
/// `start..end` ಸಿಂಟ್ಯಾಕ್ಸ್ `Range` ಆಗಿದೆ:
///
/// ```
/// assert_eq!((3..5), std::ops::Range { start: 3, end: 5 });
/// assert_eq!(3 + 4 + 5, (3..6).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]); // ಇದು `Range` ಆಗಿದೆ
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
#[lang = "Range"]
#[doc(alias = "..")]
#[derive(Clone, Default, PartialEq, Eq, Hash)] // ನಕಲಿಸಲಾಗಿಲ್ಲ-#27186 ನೋಡಿ
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Range<Idx> {
    /// (inclusive) ಶ್ರೇಣಿಯ ಕೆಳಗಿನ ಬೌಂಡ್.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
    /// (exclusive) ಶ್ರೇಣಿಯ ಮೇಲಿನ ಬೌಂಡ್.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for Range<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> Range<Idx> {
    /// `item` ವ್ಯಾಪ್ತಿಯಲ್ಲಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).contains(&2));
    /// assert!( (3..5).contains(&3));
    /// assert!( (3..5).contains(&4));
    /// assert!(!(3..5).contains(&5));
    ///
    /// assert!(!(3..3).contains(&3));
    /// assert!(!(3..2).contains(&3));
    ///
    /// assert!( (0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// ಶ್ರೇಣಿಯು ಯಾವುದೇ ವಸ್ತುಗಳನ್ನು ಹೊಂದಿಲ್ಲದಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).is_empty());
    /// assert!( (3..3).is_empty());
    /// assert!( (3..2).is_empty());
    /// ```
    ///
    /// ಎರಡೂ ಬದಿ ಹೋಲಿಸಲಾಗದಿದ್ದಲ್ಲಿ ಶ್ರೇಣಿ ಖಾಲಿಯಾಗಿದೆ:
    ///
    /// ```
    /// assert!(!(3.0..5.0).is_empty());
    /// assert!( (3.0..f32::NAN).is_empty());
    /// assert!( (f32::NAN..5.0).is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    pub fn is_empty(&self) -> bool {
        !(self.start < self.end)
    }
}

/// ಒಂದು ಶ್ರೇಣಿಯು ಕೇವಲ (`start..`) ಗಿಂತ ಕೆಳಗಿರುತ್ತದೆ.
///
/// `RangeFrom` `start..` `x >= start` ನೊಂದಿಗೆ ಎಲ್ಲಾ ಮೌಲ್ಯಗಳನ್ನು ಒಳಗೊಂಡಿದೆ.
///
/// *ಗಮನಿಸಿ*: [`Iterator`] ಅನುಷ್ಠಾನದಲ್ಲಿ ಉಕ್ಕಿ ಹರಿಯುವುದು (ಒಳಗೊಂಡಿರುವ ಡೇಟಾ ಪ್ರಕಾರವು ಅದರ ಸಂಖ್ಯಾತ್ಮಕ ಮಿತಿಯನ್ನು ತಲುಪಿದಾಗ) panic, ಸುತ್ತು ಅಥವಾ ಸ್ಯಾಚುರೇಟ್‌ಗೆ ಅನುಮತಿಸಲಾಗಿದೆ.
/// ಈ ನಡವಳಿಕೆಯನ್ನು [`Step`] trait ಅನುಷ್ಠಾನದಿಂದ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿದೆ.
/// ಪ್ರಾಚೀನ ಪೂರ್ಣಾಂಕಗಳಿಗಾಗಿ, ಇದು ಸಾಮಾನ್ಯ ನಿಯಮಗಳನ್ನು ಅನುಸರಿಸುತ್ತದೆ ಮತ್ತು ಓವರ್‌ಫ್ಲೋ ಚೆಕ್ ಪ್ರೊಫೈಲ್ ಅನ್ನು ಗೌರವಿಸುತ್ತದೆ (ಡೀಬಗ್‌ನಲ್ಲಿ panic, ಬಿಡುಗಡೆಯಲ್ಲಿ ಸುತ್ತು).
/// ಓವರ್‌ಫ್ಲೋ ನೀವು might ಹಿಸುವುದಕ್ಕಿಂತ ಮುಂಚೆಯೇ ಸಂಭವಿಸುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ: ಗರಿಷ್ಠ ಮೌಲ್ಯವನ್ನು ನೀಡುವ `next` ಗೆ ಕರೆಯಲ್ಲಿ ಓವರ್‌ಫ್ಲೋ ಸಂಭವಿಸುತ್ತದೆ, ಏಕೆಂದರೆ ಮುಂದಿನ ಮೌಲ್ಯವನ್ನು ನೀಡಲು ಶ್ರೇಣಿಯನ್ನು ಸ್ಥಿತಿಗೆ ಹೊಂದಿಸಬೇಕು.
///
///
/// [`Step`]: crate::iter::Step
///
/// # Examples
///
/// `start..` ಸಿಂಟ್ಯಾಕ್ಸ್ `RangeFrom` ಆಗಿದೆ:
///
/// ```
/// assert_eq!((2..), std::ops::RangeFrom { start: 2 });
/// assert_eq!(2 + 3 + 4, (2..).take(3).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]); // ಇದು `RangeFrom` ಆಗಿದೆ
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
///
///
#[lang = "RangeFrom"]
#[doc(alias = "..")]
#[derive(Clone, PartialEq, Eq, Hash)] // ನಕಲಿಸಲಾಗಿಲ್ಲ-#27186 ನೋಡಿ
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFrom<Idx> {
    /// (inclusive) ಶ್ರೇಣಿಯ ಕೆಳಗಿನ ಬೌಂಡ್.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeFrom<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeFrom<Idx> {
    /// `item` ವ್ಯಾಪ್ತಿಯಲ್ಲಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..).contains(&2));
    /// assert!( (3..).contains(&3));
    /// assert!( (3..).contains(&1_000_000_000));
    ///
    /// assert!( (0.0..).contains(&0.5));
    /// assert!(!(0.0..).contains(&f32::NAN));
    /// assert!(!(f32::NAN..).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// ಒಂದು ಶ್ರೇಣಿ ಕೇವಲ (`..end`) ಗಿಂತ ಮಾತ್ರ ಸೀಮಿತವಾಗಿದೆ.
///
/// `RangeTo` `..end` `x < end` ನೊಂದಿಗೆ ಎಲ್ಲಾ ಮೌಲ್ಯಗಳನ್ನು ಒಳಗೊಂಡಿದೆ.
/// ಇದು [`Iterator`] ಆಗಿ ಕಾರ್ಯನಿರ್ವಹಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ ಏಕೆಂದರೆ ಅದು ಪ್ರಾರಂಭದ ಹಂತವನ್ನು ಹೊಂದಿಲ್ಲ.
///
/// # Examples
///
/// `..end` ಸಿಂಟ್ಯಾಕ್ಸ್ `RangeTo` ಆಗಿದೆ:
///
/// ```
/// assert_eq!((..5), std::ops::RangeTo { end: 5 });
/// ```
///
/// ಇದು [`IntoIterator`] ಅನುಷ್ಠಾನವನ್ನು ಹೊಂದಿಲ್ಲ, ಆದ್ದರಿಂದ ನೀವು ಅದನ್ನು ನೇರವಾಗಿ `for` ಲೂಪ್‌ನಲ್ಲಿ ಬಳಸಲಾಗುವುದಿಲ್ಲ.
/// ಇದು ಕಂಪೈಲ್ ಮಾಡುವುದಿಲ್ಲ:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeTo<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..5 {
///     // ...
/// }
/// ```
///
/// [slicing index] ಆಗಿ ಬಳಸಿದಾಗ, `end` ಸೂಚಿಸಿದ ಸೂಚ್ಯಂಕದ ಮೊದಲು `RangeTo` ಎಲ್ಲಾ ರಚನೆಯ ಅಂಶಗಳ ಸ್ಲೈಸ್ ಅನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ.
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]); // ಇದು `RangeTo` ಆಗಿದೆ
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeTo"]
#[doc(alias = "..")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeTo<Idx> {
    /// (exclusive) ಶ್ರೇಣಿಯ ಮೇಲಿನ ಬೌಂಡ್.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeTo<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeTo<Idx> {
    /// `item` ವ್ಯಾಪ್ತಿಯಲ್ಲಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..5).contains(&-1_000_000_000));
    /// assert!( (..5).contains(&4));
    /// assert!(!(..5).contains(&5));
    ///
    /// assert!( (..1.0).contains(&0.5));
    /// assert!(!(..1.0).contains(&f32::NAN));
    /// assert!(!(..f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// (`start..=end`) ಗಿಂತ ಕೆಳಗಿನ ಮತ್ತು ಮೇಲಿರುವ ಒಂದು ಶ್ರೇಣಿ.
///
/// `RangeInclusive` `start..=end` ಎಲ್ಲಾ ಮೌಲ್ಯಗಳನ್ನು `x >= start` ಮತ್ತು `x <= end` ನೊಂದಿಗೆ ಒಳಗೊಂಡಿದೆ.`start <= end` ಹೊರತು ಅದು ಖಾಲಿಯಾಗಿದೆ.
///
/// ಈ ಪುನರಾವರ್ತಕವು [fused] ಆಗಿದೆ, ಆದರೆ ಪುನರಾವರ್ತನೆ ಮುಗಿದ ನಂತರ `start` ಮತ್ತು `end` ನ ನಿರ್ದಿಷ್ಟ ಮೌಲ್ಯಗಳು **ಅನಿರ್ದಿಷ್ಟ** ಹೊರತುಪಡಿಸಿ [`.is_empty()`] ಹೊರತುಪಡಿಸಿ [`.is_empty()`] `true` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
///
///
/// [fused]: crate::iter::FusedIterator
/// [`.is_empty()`]: RangeInclusive::is_empty
///
/// # Examples
///
/// `start..=end` ಸಿಂಟ್ಯಾಕ್ಸ್ `RangeInclusive` ಆಗಿದೆ:
///
/// ```
/// assert_eq!((3..=5), std::ops::RangeInclusive::new(3, 5));
/// assert_eq!(3 + 4 + 5, (3..=5).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]); // ಇದು `RangeInclusive` ಆಗಿದೆ
/// ```
///
///
#[lang = "RangeInclusive"]
#[doc(alias = "..=")]
#[derive(Clone, PartialEq, Eq, Hash)] // ನಕಲಿಸಲಾಗಿಲ್ಲ-#27186 ನೋಡಿ
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeInclusive<Idx> {
    // future ನಲ್ಲಿ ಪ್ರಾತಿನಿಧ್ಯವನ್ನು ಬದಲಾಯಿಸಲು ಇಲ್ಲಿ ಕ್ಷೇತ್ರಗಳು ಸಾರ್ವಜನಿಕವಾಗಿಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ;ನಿರ್ದಿಷ್ಟವಾಗಿ ಹೇಳುವುದಾದರೆ, ನಾವು start/end ಅನ್ನು ಸ್ಪಷ್ಟವಾಗಿ ಬಹಿರಂಗಪಡಿಸುವಾಗ, (future/current) ಖಾಸಗಿ ಕ್ಷೇತ್ರಗಳನ್ನು ಬದಲಾಯಿಸದೆ ಅವುಗಳನ್ನು ಮಾರ್ಪಡಿಸುವುದು ತಪ್ಪಾದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗಬಹುದು, ಆದ್ದರಿಂದ ನಾವು ಆ ಮೋಡ್ ಅನ್ನು ಬೆಂಬಲಿಸಲು ಬಯಸುವುದಿಲ್ಲ.
    //
    //
    //
    //
    pub(crate) start: Idx,
    pub(crate) end: Idx,

    // ಈ ಕ್ಷೇತ್ರ ಹೀಗಿದೆ:
    //  - `false` ನಿರ್ಮಾಣದ ಮೇಲೆ
    //  - `false` ಪುನರಾವರ್ತನೆಯು ಒಂದು ಅಂಶವನ್ನು ನೀಡಿದಾಗ ಮತ್ತು ಪುನರಾವರ್ತಕವು ಖಾಲಿಯಾಗುವುದಿಲ್ಲ
    //  - `true` ಪುನರಾವರ್ತಕವನ್ನು ನಿಷ್ಕಾಸಗೊಳಿಸಲು ಪುನರಾವರ್ತನೆಯನ್ನು ಬಳಸಿದಾಗ
    //
    // ಭಾಗಶಃ ಆದೇಶ ಅಥವಾ ವಿಶೇಷತೆ ಇಲ್ಲದೆ ಭಾಗಶಃ ಎಕ್ ಮತ್ತು ಹ್ಯಾಶ್ ಅನ್ನು ಬೆಂಬಲಿಸಲು ಇದು ಅಗತ್ಯವಿದೆ.
    pub(crate) exhausted: bool,
}

impl<Idx> RangeInclusive<Idx> {
    /// ಹೊಸ ಅಂತರ್ಗತ ಶ್ರೇಣಿಯನ್ನು ರಚಿಸುತ್ತದೆ.`start..=end` ಬರೆಯಲು ಸಮಾನ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ops::RangeInclusive;
    ///
    /// assert_eq!(3..=5, RangeInclusive::new(3, 5));
    /// ```
    #[lang = "range_inclusive_new"]
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    #[rustc_promotable]
    #[rustc_const_stable(feature = "const_range_new", since = "1.32.0")]
    pub const fn new(start: Idx, end: Idx) -> Self {
        Self { start, end, exhausted: false }
    }

    /// (inclusive) ಶ್ರೇಣಿಯ ಕೆಳಗಿನ ಬೌಂಡ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಪುನರಾವರ್ತನೆಗಾಗಿ ಅಂತರ್ಗತ ಶ್ರೇಣಿಯನ್ನು ಬಳಸುವಾಗ, ಪುನರಾವರ್ತನೆ ಮುಗಿದ ನಂತರ `start()` ಮತ್ತು [`end()`] ನ ಮೌಲ್ಯಗಳನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗುವುದಿಲ್ಲ.
    /// ಅಂತರ್ಗತ ಶ್ರೇಣಿ ಖಾಲಿಯಾಗಿದೆಯೆ ಎಂದು ನಿರ್ಧರಿಸಲು, `start() > end()` ಅನ್ನು ಹೋಲಿಸುವ ಬದಲು [`is_empty()`] ವಿಧಾನವನ್ನು ಬಳಸಿ.
    ///
    /// Note: ಶ್ರೇಣಿಯನ್ನು ಬಳಲಿಕೆಗೆ ಪುನರಾವರ್ತಿಸಿದ ನಂತರ ಈ ವಿಧಾನದಿಂದ ಹಿಂತಿರುಗಿಸಲಾದ ಮೌಲ್ಯವನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿಲ್ಲ.
    ///
    /// [`end()`]: RangeInclusive::end
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).start(), &3);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn start(&self) -> &Idx {
        &self.start
    }

    /// (inclusive) ಶ್ರೇಣಿಯ ಮೇಲಿನ ಬೌಂಡ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಪುನರಾವರ್ತನೆಗಾಗಿ ಅಂತರ್ಗತ ಶ್ರೇಣಿಯನ್ನು ಬಳಸುವಾಗ, ಪುನರಾವರ್ತನೆ ಮುಗಿದ ನಂತರ [`start()`] ಮತ್ತು `end()` ನ ಮೌಲ್ಯಗಳನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗುವುದಿಲ್ಲ.
    /// ಅಂತರ್ಗತ ಶ್ರೇಣಿ ಖಾಲಿಯಾಗಿದೆಯೆ ಎಂದು ನಿರ್ಧರಿಸಲು, `start() > end()` ಅನ್ನು ಹೋಲಿಸುವ ಬದಲು [`is_empty()`] ವಿಧಾನವನ್ನು ಬಳಸಿ.
    ///
    /// Note: ಶ್ರೇಣಿಯನ್ನು ಬಳಲಿಕೆಗೆ ಪುನರಾವರ್ತಿಸಿದ ನಂತರ ಈ ವಿಧಾನದಿಂದ ಹಿಂತಿರುಗಿಸಲಾದ ಮೌಲ್ಯವನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿಲ್ಲ.
    ///
    /// [`start()`]: RangeInclusive::start
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).end(), &5);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn end(&self) -> &Idx {
        &self.end
    }

    /// `RangeInclusive` ಅನ್ನು ನಾಶಪಡಿಸುತ್ತದೆ (ಕಡಿಮೆ ಬೌಂಡ್, ಮೇಲಿನ (inclusive) ಬೌಂಡ್).
    ///
    /// Note: ಶ್ರೇಣಿಯನ್ನು ಬಳಲಿಕೆಗೆ ಪುನರಾವರ್ತಿಸಿದ ನಂತರ ಈ ವಿಧಾನದಿಂದ ಹಿಂತಿರುಗಿಸಲಾದ ಮೌಲ್ಯವನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿಲ್ಲ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).into_inner(), (3, 5));
    /// ```
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    pub fn into_inner(self) -> (Idx, Idx) {
        (self.start, self.end)
    }
}

impl RangeInclusive<usize> {
    /// `SliceIndex` ಅನುಷ್ಠಾನಗಳಿಗಾಗಿ ವಿಶೇಷ `Range` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    /// `end == usize::MAX` ನೊಂದಿಗೆ ವ್ಯವಹರಿಸಲು ಕರೆ ಮಾಡುವವರು ಜವಾಬ್ದಾರರಾಗಿರುತ್ತಾರೆ.
    #[inline]
    pub(crate) fn into_slice_range(self) -> Range<usize> {
        // ನಾವು ದಣಿದಿಲ್ಲದಿದ್ದರೆ, ನಾವು `start..end + 1` ಅನ್ನು ತುಂಡು ಮಾಡಲು ಬಯಸುತ್ತೇವೆ.
        // ನಾವು ದಣಿದಿದ್ದರೆ, `end + 1..end + 1` ನೊಂದಿಗೆ ಸ್ಲೈಸಿಂಗ್ ನಮಗೆ ಖಾಲಿ ಶ್ರೇಣಿಯನ್ನು ನೀಡುತ್ತದೆ, ಅದು ಆ ಅಂತಿಮ ಬಿಂದುವಿನ ಗಡಿ-ಪರಿಶೀಲನೆಗಳಿಗೆ ಒಳಪಟ್ಟಿರುತ್ತದೆ.
        //
        let exclusive_end = self.end + 1;
        let start = if self.exhausted { exclusive_end } else { self.start };
        start..exclusive_end
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        if self.exhausted {
            write!(fmt, " (exhausted)")?;
        }
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeInclusive<Idx> {
    /// `item` ವ್ಯಾಪ್ತಿಯಲ್ಲಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).contains(&2));
    /// assert!( (3..=5).contains(&3));
    /// assert!( (3..=5).contains(&4));
    /// assert!( (3..=5).contains(&5));
    /// assert!(!(3..=5).contains(&6));
    ///
    /// assert!( (3..=3).contains(&3));
    /// assert!(!(3..=2).contains(&3));
    ///
    /// assert!( (0.0..=1.0).contains(&1.0));
    /// assert!(!(0.0..=1.0).contains(&f32::NAN));
    /// assert!(!(0.0..=f32::NAN).contains(&0.0));
    /// assert!(!(f32::NAN..=1.0).contains(&1.0));
    /// ```
    ///
    /// ಪುನರಾವರ್ತನೆ ಮುಗಿದ ನಂತರ ಈ ವಿಧಾನವು ಯಾವಾಗಲೂ `false` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ:
    ///
    /// ```
    /// let mut r = 3..=5;
    /// assert!(r.contains(&3) && r.contains(&5));
    /// for _ in r.by_ref() {}
    /// // ನಿಖರವಾದ ಕ್ಷೇತ್ರ ಮೌಲ್ಯಗಳನ್ನು ಇಲ್ಲಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿಲ್ಲ
    /// assert!(!r.contains(&3) && !r.contains(&5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// ಶ್ರೇಣಿಯು ಯಾವುದೇ ವಸ್ತುಗಳನ್ನು ಹೊಂದಿಲ್ಲದಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).is_empty());
    /// assert!(!(3..=3).is_empty());
    /// assert!( (3..=2).is_empty());
    /// ```
    ///
    /// ಎರಡೂ ಬದಿ ಹೋಲಿಸಲಾಗದಿದ್ದಲ್ಲಿ ಶ್ರೇಣಿ ಖಾಲಿಯಾಗಿದೆ:
    ///
    /// ```
    /// assert!(!(3.0..=5.0).is_empty());
    /// assert!( (3.0..=f32::NAN).is_empty());
    /// assert!( (f32::NAN..=5.0).is_empty());
    /// ```
    ///
    /// ಪುನರಾವರ್ತನೆ ಮುಗಿದ ನಂತರ ಈ ವಿಧಾನವು `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ:
    ///
    /// ```
    /// let mut r = 3..=5;
    /// for _ in r.by_ref() {}
    /// // ನಿಖರವಾದ ಕ್ಷೇತ್ರ ಮೌಲ್ಯಗಳನ್ನು ಇಲ್ಲಿ ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿಲ್ಲ
    /// assert!(r.is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.exhausted || !(self.start <= self.end)
    }
}

/// ಒಂದು ಶ್ರೇಣಿಯು (`..=end`) ಗಿಂತ ಮಾತ್ರ ಒಳಗೊಳ್ಳುತ್ತದೆ.
///
/// `RangeToInclusive` `..=end` `x <= end` ನೊಂದಿಗೆ ಎಲ್ಲಾ ಮೌಲ್ಯಗಳನ್ನು ಒಳಗೊಂಡಿದೆ.
/// ಇದು [`Iterator`] ಆಗಿ ಕಾರ್ಯನಿರ್ವಹಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ ಏಕೆಂದರೆ ಅದು ಪ್ರಾರಂಭದ ಹಂತವನ್ನು ಹೊಂದಿಲ್ಲ.
///
/// # Examples
///
/// `..=end` ಸಿಂಟ್ಯಾಕ್ಸ್ `RangeToInclusive` ಆಗಿದೆ:
///
/// ```
/// assert_eq!((..=5), std::ops::RangeToInclusive{ end: 5 });
/// ```
///
/// ಇದು [`IntoIterator`] ಅನುಷ್ಠಾನವನ್ನು ಹೊಂದಿಲ್ಲ, ಆದ್ದರಿಂದ ನೀವು ಅದನ್ನು ನೇರವಾಗಿ `for` ಲೂಪ್‌ನಲ್ಲಿ ಬಳಸಲಾಗುವುದಿಲ್ಲ.ಇದು ಕಂಪೈಲ್ ಮಾಡುವುದಿಲ್ಲ:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeToInclusive<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..=5 {
///     // ...
/// }
/// ```
///
/// [slicing index] ಆಗಿ ಬಳಸಿದಾಗ, `RangeToInclusive` ಎಲ್ಲಾ ಅರೇ ಅಂಶಗಳ ಸ್ಲೈಸ್ ಅನ್ನು `end` ಸೂಚಿಸಿದ ಸೂಚ್ಯಂಕವನ್ನು ಒಳಗೊಂಡಂತೆ ಉತ್ಪಾದಿಸುತ್ತದೆ.
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]); // ಇದು `RangeToInclusive` ಆಗಿದೆ
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
///
#[lang = "RangeToInclusive"]
#[doc(alias = "..=")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeToInclusive<Idx> {
    /// (inclusive) ಶ್ರೇಣಿಯ ಮೇಲಿನ ಬೌಂಡ್
    #[stable(feature = "inclusive_range", since = "1.26.0")]
    pub end: Idx,
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeToInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeToInclusive<Idx> {
    /// `item` ವ್ಯಾಪ್ತಿಯಲ್ಲಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..=5).contains(&-1_000_000_000));
    /// assert!( (..=5).contains(&5));
    /// assert!(!(..=5).contains(&6));
    ///
    /// assert!( (..=1.0).contains(&1.0));
    /// assert!(!(..=1.0).contains(&f32::NAN));
    /// assert!(!(..=f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

// ರೇಂಜ್ ಟೊಇನ್ಕ್ಲೂಸಿವ್<Idx>ನಿಂದ ಸೂಚಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ <RangeTo<Idx>> ಏಕೆಂದರೆ (..0).into() ನೊಂದಿಗೆ ಒಳಹರಿವು ಸಾಧ್ಯ
//

/// ಕೀಗಳ ಶ್ರೇಣಿಯ ಅಂತಿಮ ಬಿಂದು.
///
/// # Examples
///
/// `ಬೌಂಡ್`ಗಳು ಶ್ರೇಣಿಯ ಅಂತಿಮ ಬಿಂದುಗಳಾಗಿವೆ:
///
/// ```
/// use std::ops::Bound::*;
/// use std::ops::RangeBounds;
///
/// assert_eq!((..100).start_bound(), Unbounded);
/// assert_eq!((1..12).start_bound(), Included(&1));
/// assert_eq!((1..12).end_bound(), Excluded(&12));
/// ```
///
/// [`BTreeMap::range`] ಗೆ ವಾದವಾಗಿ `ಬೌಂಡ್`ಗಳ ಟಪಲ್ ಅನ್ನು ಬಳಸುವುದು.
/// ಹೆಚ್ಚಿನ ಸಂದರ್ಭಗಳಲ್ಲಿ, ಬದಲಿಗೆ ಶ್ರೇಣಿ ಸಿಂಟ್ಯಾಕ್ಸ್ (`1..5`) ಅನ್ನು ಬಳಸುವುದು ಉತ್ತಮ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
///
/// ```
/// use std::collections::BTreeMap;
/// use std::ops::Bound::{Excluded, Included, Unbounded};
///
/// let mut map = BTreeMap::new();
/// map.insert(3, "a");
/// map.insert(5, "b");
/// map.insert(8, "c");
///
/// for (key, value) in map.range((Excluded(3), Included(8))) {
///     println!("{}: {}", key, value);
/// }
///
/// assert_eq!(Some((&3, &"a")), map.range((Unbounded, Included(5))).next());
/// ```
///
/// [`BTreeMap::range`]: ../../std/collections/btree_map/struct.BTreeMap.html#method.range
#[stable(feature = "collections_bound", since = "1.17.0")]
#[derive(Clone, Copy, Debug, Hash, PartialEq, Eq)]
pub enum Bound<T> {
    /// ಅಂತರ್ಗತ ಬೌಂಡ್.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Included(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// ವಿಶೇಷ ಬೌಂಡ್.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Excluded(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// ಅನಂತ ಎಂಡ್ ಪಾಯಿಂಟ್.ಈ ದಿಕ್ಕಿನಲ್ಲಿ ಯಾವುದೇ ಮಿತಿಯಿಲ್ಲ ಎಂದು ಸೂಚಿಸುತ್ತದೆ.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Unbounded,
}

#[unstable(feature = "bound_as_ref", issue = "80996")]
impl<T> Bound<T> {
    /// `&Bound<T>` ನಿಂದ `Bound<&T>` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    #[inline]
    pub fn as_ref(&self) -> Bound<&T> {
        match *self {
            Included(ref x) => Included(x),
            Excluded(ref x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }

    /// `&mut Bound<T>` ನಿಂದ `Bound<&T>` ಗೆ ಪರಿವರ್ತಿಸುತ್ತದೆ.
    #[inline]
    pub fn as_mut(&mut self) -> Bound<&mut T> {
        match *self {
            Included(ref mut x) => Included(x),
            Excluded(ref mut x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }
}

impl<T: Clone> Bound<&T> {
    /// ಬೌಂಡ್‌ನ ವಿಷಯಗಳನ್ನು ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಮಾಡುವ ಮೂಲಕ `Bound<&T>` ಅನ್ನು `Bound<T>` ಗೆ ನಕ್ಷೆ ಮಾಡಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(bound_cloned)]
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((1..12).start_bound(), Included(&1));
    /// assert_eq!((1..12).start_bound().cloned(), Included(1));
    /// ```
    #[unstable(feature = "bound_cloned", issue = "61356")]
    pub fn cloned(self) -> Bound<T> {
        match self {
            Bound::Unbounded => Bound::Unbounded,
            Bound::Included(x) => Bound::Included(x.clone()),
            Bound::Excluded(x) => Bound::Excluded(x.clone()),
        }
    }
}

/// `RangeBounds` `..`, `a..`, `..b`, `..=c`, `d..e`, ಅಥವಾ `f..=g` ನಂತಹ ಶ್ರೇಣಿಯ ಸಿಂಟ್ಯಾಕ್ಸ್‌ನಿಂದ ಉತ್ಪತ್ತಿಯಾಗುವ Rust ನ ಅಂತರ್ನಿರ್ಮಿತ ಶ್ರೇಣಿ ಪ್ರಕಾರಗಳಿಂದ ಇದನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗುತ್ತದೆ.
///
#[stable(feature = "collections_range", since = "1.28.0")]
pub trait RangeBounds<T: ?Sized> {
    /// ಸೂಚ್ಯಂಕವನ್ನು ಪ್ರಾರಂಭಿಸಿ.
    ///
    /// ಪ್ರಾರಂಭದ ಮೌಲ್ಯವನ್ನು `Bound` ಆಗಿ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((..10).start_bound(), Unbounded);
    /// assert_eq!((3..10).start_bound(), Included(&3));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn start_bound(&self) -> Bound<&T>;

    /// ಅಂತಿಮ ಸೂಚ್ಯಂಕ ಬೌಂಡ್.
    ///
    /// ಅಂತಿಮ ಮೌಲ್ಯವನ್ನು `Bound` ಆಗಿ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((3..).end_bound(), Unbounded);
    /// assert_eq!((3..10).end_bound(), Excluded(&10));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn end_bound(&self) -> Bound<&T>;

    /// `item` ವ್ಯಾಪ್ತಿಯಲ್ಲಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// ((3..5).contains(&4));
    /// assert!(!(3..5).contains(&2));
    ///
    /// ((0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    #[stable(feature = "range_contains", since = "1.35.0")]
    fn contains<U>(&self, item: &U) -> bool
    where
        T: PartialOrd<U>,
        U: ?Sized + PartialOrd<T>,
    {
        (match self.start_bound() {
            Included(ref start) => *start <= item,
            Excluded(ref start) => *start < item,
            Unbounded => true,
        }) && (match self.end_bound() {
            Included(ref end) => item <= *end,
            Excluded(ref end) => item < *end,
            Unbounded => true,
        })
    }
}

use self::Bound::{Excluded, Included, Unbounded};

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T: ?Sized> RangeBounds<T> for RangeFull {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        if self.exhausted {
            // ಪುನರಾವರ್ತಕವು ಖಾಲಿಯಾದಾಗ, ನಾವು ಸಾಮಾನ್ಯವಾಗಿ ಪ್ರಾರಂಭ==ಅಂತ್ಯವನ್ನು ಹೊಂದಿದ್ದೇವೆ, ಆದರೆ ಶ್ರೇಣಿಯು ಖಾಲಿಯಾಗಿ ಕಾಣಿಸಿಕೊಳ್ಳಲು ನಾವು ಬಯಸುತ್ತೇವೆ, ಅದರಲ್ಲಿ ಏನೂ ಇಲ್ಲ.
            //
            Excluded(&self.end)
        } else {
            Included(&self.end)
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for (Bound<T>, Bound<T>) {
    fn start_bound(&self) -> Bound<&T> {
        match *self {
            (Included(ref start), _) => Included(start),
            (Excluded(ref start), _) => Excluded(start),
            (Unbounded, _) => Unbounded,
        }
    }

    fn end_bound(&self) -> Bound<&T> {
        match *self {
            (_, Included(ref end)) => Included(end),
            (_, Excluded(ref end)) => Excluded(end),
            (_, Unbounded) => Unbounded,
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<'a, T: ?Sized + 'a> RangeBounds<T> for (Bound<&'a T>, Bound<&'a T>) {
    fn start_bound(&self) -> Bound<&T> {
        self.0
    }

    fn end_bound(&self) -> Bound<&T> {
        self.1
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}