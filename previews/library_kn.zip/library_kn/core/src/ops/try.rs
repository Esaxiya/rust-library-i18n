/// `?` ಆಪರೇಟರ್ನ ನಡವಳಿಕೆಯನ್ನು ಕಸ್ಟಮೈಸ್ ಮಾಡಲು trait.
///
/// `Try` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಒಂದು ಪ್ರಕಾರವೆಂದರೆ ಅದನ್ನು success/failure ದ್ವಂದ್ವಶಾಸ್ತ್ರದ ದೃಷ್ಟಿಯಿಂದ ವೀಕ್ಷಿಸಲು ಅಂಗೀಕೃತ ಮಾರ್ಗವನ್ನು ಹೊಂದಿದೆ.
/// ಈ trait ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ ಉದಾಹರಣೆಯಿಂದ ಆ ಯಶಸ್ಸು ಅಥವಾ ವೈಫಲ್ಯ ಮೌಲ್ಯಗಳನ್ನು ಹೊರತೆಗೆಯಲು ಮತ್ತು ಯಶಸ್ಸು ಅಥವಾ ವೈಫಲ್ಯ ಮೌಲ್ಯದಿಂದ ಹೊಸ ನಿದರ್ಶನವನ್ನು ರಚಿಸಲು ಅನುಮತಿಸುತ್ತದೆ.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// ಯಶಸ್ವಿಯಾದಾಗ ಈ ಮೌಲ್ಯದ ಪ್ರಕಾರ.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// ವಿಫಲವಾದಂತೆ ನೋಡಿದಾಗ ಈ ಮೌಲ್ಯದ ಪ್ರಕಾರ.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// "?" ಆಪರೇಟರ್ ಅನ್ನು ಅನ್ವಯಿಸುತ್ತದೆ.`Ok(t)` ನ ಹಿಂತಿರುಗುವಿಕೆ ಎಂದರೆ ಮರಣದಂಡನೆ ಸಾಮಾನ್ಯವಾಗಿ ಮುಂದುವರಿಯಬೇಕು, ಮತ್ತು `?` ನ ಫಲಿತಾಂಶವು `t` ಮೌಲ್ಯವಾಗಿರುತ್ತದೆ.
    /// `Err(e)` ನ ರಿಟರ್ನ್ ಎಂದರೆ ಮರಣದಂಡನೆಯು branch ಅನ್ನು ಒಳಗಿನ `catch` ಗೆ ಸುತ್ತುವರಿಯಬೇಕು ಅಥವಾ ಕಾರ್ಯದಿಂದ ಹಿಂತಿರುಗಬೇಕು.
    ///
    /// `Err(e)` ಫಲಿತಾಂಶವನ್ನು ಹಿಂತಿರುಗಿಸಿದರೆ, ಸುತ್ತುವರಿದ ವ್ಯಾಪ್ತಿಯ ರಿಟರ್ನ್ ಪ್ರಕಾರದಲ್ಲಿ `e` ಮೌಲ್ಯವು "wrapped" ಆಗಿರುತ್ತದೆ (ಅದು ಸ್ವತಃ `Try` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಬೇಕು).
    ///
    /// ನಿರ್ದಿಷ್ಟವಾಗಿ, `X::from_error(From::from(e))` ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ, ಇಲ್ಲಿ `X` ಎಂಬುದು ಸುತ್ತುವರಿದ ಕಾರ್ಯದ ರಿಟರ್ನ್ ಪ್ರಕಾರವಾಗಿದೆ.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// ಸಂಯೋಜಿತ ಫಲಿತಾಂಶವನ್ನು ನಿರ್ಮಿಸಲು ದೋಷ ಮೌಲ್ಯವನ್ನು ಕಟ್ಟಿಕೊಳ್ಳಿ.
    /// ಉದಾಹರಣೆಗೆ, `Result::Err(x)` ಮತ್ತು `Result::from_error(x)` ಸಮಾನವಾಗಿರುತ್ತದೆ.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// ಸಂಯೋಜಿತ ಫಲಿತಾಂಶವನ್ನು ನಿರ್ಮಿಸಲು ಸರಿ ಮೌಲ್ಯವನ್ನು ಕಟ್ಟಿಕೊಳ್ಳಿ.
    /// ಉದಾಹರಣೆಗೆ, `Result::Ok(x)` ಮತ್ತು `Result::from_ok(x)` ಸಮಾನವಾಗಿರುತ್ತದೆ.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}