//! ಓವರ್‌ಲೋಡ್ ಮಾಡಬಹುದಾದ ಆಪರೇಟರ್‌ಗಳು.
//!
//! ಈ traits ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದರಿಂದ ಕೆಲವು ಆಪರೇಟರ್‌ಗಳನ್ನು ಓವರ್‌ಲೋಡ್ ಮಾಡಲು ನಿಮಗೆ ಅನುಮತಿಸುತ್ತದೆ.
//!
//! ಈ ಕೆಲವು traits ಅನ್ನು prelude ನಿಂದ ಆಮದು ಮಾಡಿಕೊಳ್ಳಲಾಗುತ್ತದೆ, ಆದ್ದರಿಂದ ಅವು ಪ್ರತಿ Rust ಪ್ರೋಗ್ರಾಂನಲ್ಲಿ ಲಭ್ಯವಿದೆ.traits ನಿಂದ ಬೆಂಬಲಿತ ಆಪರೇಟರ್‌ಗಳನ್ನು ಮಾತ್ರ ಓವರ್‌ಲೋಡ್ ಮಾಡಬಹುದು.
//! ಉದಾಹರಣೆಗೆ, ಸೇರ್ಪಡೆ ಆಪರೇಟರ್ (`+`) ಅನ್ನು [`Add`] trait ಮೂಲಕ ಓವರ್‌ಲೋಡ್ ಮಾಡಬಹುದು, ಆದರೆ ನಿಯೋಜನೆ ಆಪರೇಟರ್ (`=`) ಗೆ ಯಾವುದೇ ಬೆಂಬಲ trait ಇಲ್ಲದಿರುವುದರಿಂದ, ಅದರ ಶಬ್ದಾರ್ಥವನ್ನು ಓವರ್‌ಲೋಡ್ ಮಾಡುವ ವಿಧಾನವಿಲ್ಲ.
//! ಹೆಚ್ಚುವರಿಯಾಗಿ, ಈ ಮಾಡ್ಯೂಲ್ ಹೊಸ ಆಪರೇಟರ್‌ಗಳನ್ನು ರಚಿಸಲು ಯಾವುದೇ ಕಾರ್ಯವಿಧಾನವನ್ನು ಒದಗಿಸುವುದಿಲ್ಲ.
//! ಗುಣಲಕ್ಷಣವಿಲ್ಲದ ಓವರ್‌ಲೋಡ್ ಅಥವಾ ಕಸ್ಟಮ್ ಆಪರೇಟರ್‌ಗಳು ಅಗತ್ಯವಿದ್ದರೆ, Rust ನ ಸಿಂಟ್ಯಾಕ್ಸ್ ಅನ್ನು ವಿಸ್ತರಿಸಲು ನೀವು ಮ್ಯಾಕ್ರೋಗಳು ಅಥವಾ ಕಂಪೈಲರ್ ಪ್ಲಗ್‌ಇನ್‌ಗಳತ್ತ ನೋಡಬೇಕು.
//!
//! ಆಪರೇಟರ್ traits ನ ಅನುಷ್ಠಾನಗಳು ಆಯಾ ಸನ್ನಿವೇಶಗಳಲ್ಲಿ ಆಶ್ಚರ್ಯಕರವಾಗಿರಬೇಕು, ಅವುಗಳ ಸಾಮಾನ್ಯ ಅರ್ಥಗಳನ್ನು ಮತ್ತು [operator precedence] ಅನ್ನು ಗಮನದಲ್ಲಿರಿಸಿಕೊಳ್ಳಬೇಕು.
//! ಉದಾಹರಣೆಗೆ, [`Mul`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವಾಗ, ಕಾರ್ಯಾಚರಣೆಯು ಗುಣಾಕಾರಕ್ಕೆ ಕೆಲವು ಹೋಲಿಕೆಯನ್ನು ಹೊಂದಿರಬೇಕು (ಮತ್ತು ಸಹಭಾಗಿತ್ವದಂತಹ ನಿರೀಕ್ಷಿತ ಗುಣಲಕ್ಷಣಗಳನ್ನು ಹಂಚಿಕೊಳ್ಳಿ).
//!
//! `&&` ಮತ್ತು `||` ಆಪರೇಟರ್‌ಗಳು ಶಾರ್ಟ್-ಸರ್ಕ್ಯೂಟ್ ಅನ್ನು ಗಮನಿಸಿ, ಅಂದರೆ, ಫಲಿತಾಂಶಕ್ಕೆ ಕೊಡುಗೆ ನೀಡಿದರೆ ಮಾತ್ರ ಅವರು ತಮ್ಮ ಎರಡನೆಯ ಕಾರ್ಯಾಚರಣೆಯನ್ನು ಮೌಲ್ಯಮಾಪನ ಮಾಡುತ್ತಾರೆ.ಈ ನಡವಳಿಕೆಯನ್ನು traits ನಿಂದ ಜಾರಿಗೊಳಿಸಲಾಗದ ಕಾರಣ, `&&` ಮತ್ತು `||` ಅನ್ನು ಓವರ್‌ಲೋಡ್ ಮಾಡಬಹುದಾದ ಆಪರೇಟರ್‌ಗಳಾಗಿ ಬೆಂಬಲಿಸುವುದಿಲ್ಲ.
//!
//! ಅನೇಕ ನಿರ್ವಾಹಕರು ತಮ್ಮ ಕಾರ್ಯಚಟುವಟಿಕೆಗಳನ್ನು ಮೌಲ್ಯದಿಂದ ತೆಗೆದುಕೊಳ್ಳುತ್ತಾರೆ.ಅಂತರ್ನಿರ್ಮಿತ ಪ್ರಕಾರಗಳನ್ನು ಒಳಗೊಂಡ ಸಾಮಾನ್ಯವಲ್ಲದ ಸಂದರ್ಭಗಳಲ್ಲಿ, ಇದು ಸಾಮಾನ್ಯವಾಗಿ ಸಮಸ್ಯೆಯಲ್ಲ.
//! ಆದಾಗ್ಯೂ, ಈ ಆಪರೇಟರ್‌ಗಳನ್ನು ಜೆನೆರಿಕ್ ಕೋಡ್‌ನಲ್ಲಿ ಬಳಸುವುದರಿಂದ, ಆಪರೇಟರ್‌ಗಳು ಅವುಗಳನ್ನು ಸೇವಿಸಲು ಅವಕಾಶ ನೀಡುವುದರ ವಿರುದ್ಧವಾಗಿ ಮೌಲ್ಯಗಳನ್ನು ಮರುಬಳಕೆ ಮಾಡಬೇಕಾದರೆ ಸ್ವಲ್ಪ ಗಮನ ಹರಿಸಬೇಕು.ಸಾಂದರ್ಭಿಕವಾಗಿ [`clone`] ಅನ್ನು ಬಳಸುವುದು ಒಂದು ಆಯ್ಕೆಯಾಗಿದೆ.
//! ಉಲ್ಲೇಖಗಳಿಗಾಗಿ ಹೆಚ್ಚುವರಿ ಆಪರೇಟರ್ ಅನುಷ್ಠಾನಗಳನ್ನು ಒದಗಿಸುವ ಪ್ರಕಾರಗಳನ್ನು ಅವಲಂಬಿಸುವುದು ಮತ್ತೊಂದು ಆಯ್ಕೆಯಾಗಿದೆ.
//! ಉದಾಹರಣೆಗೆ, ಸೇರ್ಪಡೆಗಳನ್ನು ಬೆಂಬಲಿಸುವ ಬಳಕೆದಾರ-ವ್ಯಾಖ್ಯಾನಿತ ಪ್ರಕಾರದ `T` ಗೆ, `T` ಮತ್ತು `&T` ಎರಡೂ traits [`Add<T>`][`Add`] ಮತ್ತು [`Add<&T>`][`Add`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದು ಒಳ್ಳೆಯದು ಆದ್ದರಿಂದ ಅನಗತ್ಯ ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಇಲ್ಲದೆ ಜೆನೆರಿಕ್ ಕೋಡ್ ಅನ್ನು ಬರೆಯಬಹುದು.
//!
//!
//! # Examples
//!
//! ಈ ಉದಾಹರಣೆಯು [`Add`] ಮತ್ತು [`Sub`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ `Point` ರಚನೆಯನ್ನು ರಚಿಸುತ್ತದೆ, ತದನಂತರ ಎರಡು `ಪಾಯಿಂಟ್'ಗಳನ್ನು ಸೇರಿಸುವ ಮತ್ತು ಕಳೆಯುವುದನ್ನು ತೋರಿಸುತ್ತದೆ.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! ಉದಾಹರಣೆ ಅನುಷ್ಠಾನಕ್ಕಾಗಿ ಪ್ರತಿ trait ಗಾಗಿ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
//!
//! [`Fn`], [`FnMut`], ಮತ್ತು [`FnOnce`] traits ಅನ್ನು ಕಾರ್ಯಗಳಂತೆ ಆಹ್ವಾನಿಸಬಹುದಾದ ಪ್ರಕಾರಗಳಿಂದ ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗುತ್ತದೆ.[`Fn`] `&self` ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ, [`FnMut`] `&mut self` ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ ಮತ್ತು [`FnOnce`] `self` ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
//! ಇವುಗಳು ಉದಾಹರಣೆಯಲ್ಲಿ ಆಹ್ವಾನಿಸಬಹುದಾದ ಮೂರು ಬಗೆಯ ವಿಧಾನಗಳಿಗೆ ಸಂಬಂಧಿಸಿವೆ: ಕರೆ-ಮೂಲಕ-ಉಲ್ಲೇಖ, ಕರೆ-ಮೂಲಕ-ರೂಪಾಂತರ-ಉಲ್ಲೇಖ, ಮತ್ತು ಕರೆ-ಮೂಲಕ-ಮೌಲ್ಯ.
//! ಈ traits ನ ಸಾಮಾನ್ಯ ಬಳಕೆಯೆಂದರೆ ಕಾರ್ಯಗಳು ಅಥವಾ ಮುಚ್ಚುವಿಕೆಗಳನ್ನು ವಾದಗಳಾಗಿ ತೆಗೆದುಕೊಳ್ಳುವ ಉನ್ನತ-ಮಟ್ಟದ ಕಾರ್ಯಗಳಿಗೆ ಮಿತಿಯಾಗಿ ಕಾರ್ಯನಿರ್ವಹಿಸುವುದು.
//!
//! [`Fn`] ಅನ್ನು ನಿಯತಾಂಕವಾಗಿ ತೆಗೆದುಕೊಳ್ಳುವುದು:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! [`FnMut`] ಅನ್ನು ನಿಯತಾಂಕವಾಗಿ ತೆಗೆದುಕೊಳ್ಳುವುದು:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! [`FnOnce`] ಅನ್ನು ನಿಯತಾಂಕವಾಗಿ ತೆಗೆದುಕೊಳ್ಳುವುದು:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` ಅದರ ಸೆರೆಹಿಡಿದ ಅಸ್ಥಿರಗಳನ್ನು ಬಳಸುತ್ತದೆ, ಆದ್ದರಿಂದ ಇದನ್ನು ಒಂದಕ್ಕಿಂತ ಹೆಚ್ಚು ಬಾರಿ ಚಲಾಯಿಸಲಾಗುವುದಿಲ್ಲ
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // `func()` ಅನ್ನು ಮತ್ತೆ ಆಹ್ವಾನಿಸಲು ಪ್ರಯತ್ನಿಸುವುದರಿಂದ `func` ಗಾಗಿ `use of moved value` ದೋಷವನ್ನು ಎಸೆಯಲಾಗುತ್ತದೆ
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` ಈ ಹಂತದಲ್ಲಿ ಇನ್ನು ಮುಂದೆ ಆಹ್ವಾನಿಸಲಾಗುವುದಿಲ್ಲ
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;