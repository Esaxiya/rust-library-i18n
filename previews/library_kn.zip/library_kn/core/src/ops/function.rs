/// ಬದಲಾಗದ ರಿಸೀವರ್ ತೆಗೆದುಕೊಳ್ಳುವ ಕರೆ ಆಪರೇಟರ್‌ನ ಆವೃತ್ತಿ.
///
/// `Fn` ನ ನಿದರ್ಶನಗಳನ್ನು ರೂಪಾಂತರಗೊಳ್ಳದೆ ಪದೇ ಪದೇ ಕರೆಯಬಹುದು.
///
/// *ಈ trait (`Fn`) ಅನ್ನು [function pointers] (`fn`) ನೊಂದಿಗೆ ಗೊಂದಲಗೊಳಿಸಬಾರದು.*
///
/// `Fn` ಸೆರೆಹಿಡಿಯಲಾದ ಅಸ್ಥಿರಗಳಿಗೆ ಮಾತ್ರ ಬದಲಾಯಿಸಲಾಗದ ಉಲ್ಲೇಖಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುವ ಅಥವಾ ಯಾವುದನ್ನೂ ಸೆರೆಹಿಡಿಯದಿರುವ ಮುಚ್ಚುವಿಕೆಗಳಿಂದ ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಕಾರ್ಯಗತಗೊಳ್ಳುತ್ತದೆ, ಹಾಗೆಯೇ (safe) [function pointers] (ಕೆಲವು ಎಚ್ಚರಿಕೆಗಳೊಂದಿಗೆ, ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ ಅವರ ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ).
///
/// ಹೆಚ್ಚುವರಿಯಾಗಿ, `Fn` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಯಾವುದೇ ಪ್ರಕಾರದ `F` ಗೆ, `&F` `Fn` ಅನ್ನು ಸಹ ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
///
/// [`FnMut`] ಮತ್ತು [`FnOnce`] ಎರಡೂ `Fn` ನ ಸೂಪರ್‌ಟ್ರೇಟ್‌ಗಳಾಗಿರುವುದರಿಂದ, `Fn` ನ ಯಾವುದೇ ಉದಾಹರಣೆಯನ್ನು [`FnMut`] ಅಥವಾ [`FnOnce`] ನಿರೀಕ್ಷಿಸುವ ನಿಯತಾಂಕವಾಗಿ ಬಳಸಬಹುದು.
///
/// ನೀವು ಕಾರ್ಯ-ರೀತಿಯ ಪ್ರಕಾರದ ನಿಯತಾಂಕವನ್ನು ಸ್ವೀಕರಿಸಲು ಬಯಸಿದಾಗ `Fn` ಅನ್ನು ಬೌಂಡ್ ಆಗಿ ಬಳಸಿ ಮತ್ತು ಅದನ್ನು ಪದೇ ಪದೇ ಮತ್ತು ಪರಿವರ್ತನೆಯ ಸ್ಥಿತಿಯಿಲ್ಲದೆ ಕರೆಯುವ ಅಗತ್ಯವಿರುತ್ತದೆ (ಉದಾ. ಇದನ್ನು ಏಕಕಾಲದಲ್ಲಿ ಕರೆಯುವಾಗ).
/// ನಿಮಗೆ ಅಂತಹ ಕಟ್ಟುನಿಟ್ಟಾದ ಅವಶ್ಯಕತೆಗಳು ಅಗತ್ಯವಿಲ್ಲದಿದ್ದರೆ, [`FnMut`] ಅಥವಾ [`FnOnce`] ಅನ್ನು ಗಡಿಯಾಗಿ ಬಳಸಿ.
///
/// ಈ ವಿಷಯದ ಕುರಿತು ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ [chapter on closures in *The Rust Programming Language*][book] ನೋಡಿ.
///
/// `Fn` traits (ಉದಾ.) ಗಾಗಿ ವಿಶೇಷ ಸಿಂಟ್ಯಾಕ್ಸ್ ಸಹ ಗಮನಿಸಬೇಕಾದ ಅಂಶವಾಗಿದೆ
/// `Fn(usize, bool) -> usize`).ಇದರ ತಾಂತ್ರಿಕ ವಿವರಗಳಲ್ಲಿ ಆಸಕ್ತಿ ಇರುವವರು [the relevant section in the *Rustonomicon*][nomicon] ಅನ್ನು ಉಲ್ಲೇಖಿಸಬಹುದು.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## ಮುಚ್ಚುವಿಕೆಯನ್ನು ಕರೆಯಲಾಗುತ್ತಿದೆ
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## `Fn` ನಿಯತಾಂಕವನ್ನು ಬಳಸುವುದು
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ಆದ್ದರಿಂದ regex ಆ `&str: !FnMut` ಅನ್ನು ಅವಲಂಬಿಸಬಹುದು
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// ಕರೆ ಕಾರ್ಯಾಚರಣೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// ರೂಪಾಂತರಿತ ರಿಸೀವರ್ ತೆಗೆದುಕೊಳ್ಳುವ ಕರೆ ಆಪರೇಟರ್‌ನ ಆವೃತ್ತಿ.
///
/// `FnMut` ನ ನಿದರ್ಶನಗಳನ್ನು ಪದೇ ಪದೇ ಕರೆಯಬಹುದು ಮತ್ತು ಸ್ಥಿತಿಯನ್ನು ಪರಿವರ್ತಿಸಬಹುದು.
///
/// `FnMut` ಸೆರೆಹಿಡಿಯಲಾದ ಅಸ್ಥಿರಗಳಿಗೆ ರೂಪಾಂತರಗೊಳ್ಳುವ ಉಲ್ಲೇಖಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುವ ಮುಚ್ಚುವಿಕೆಗಳಿಂದ ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಕಾರ್ಯಗತಗೊಳ್ಳುತ್ತದೆ, ಜೊತೆಗೆ [`Fn`], ಉದಾ, (safe) [function pointers] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಎಲ್ಲಾ ಪ್ರಕಾರಗಳು (`FnMut` [`Fn`] ನ ಸೂಪರ್‌ಟ್ರೇಟ್ ಆಗಿರುವುದರಿಂದ).
/// ಹೆಚ್ಚುವರಿಯಾಗಿ, `FnMut` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಯಾವುದೇ ಪ್ರಕಾರದ `F` ಗೆ, `&mut F` `FnMut` ಅನ್ನು ಸಹ ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
///
/// [`FnOnce`] `FnMut` ನ ಸೂಪರ್‌ಟ್ರೇಟ್ ಆಗಿರುವುದರಿಂದ, [`FnOnce`] ಅನ್ನು ನಿರೀಕ್ಷಿಸಿದಲ್ಲಿ `FnMut` ನ ಯಾವುದೇ ಉದಾಹರಣೆಯನ್ನು ಬಳಸಬಹುದು, ಮತ್ತು [`Fn`] `FnMut` ನ ಸಬ್‌ಟ್ರೇಟ್ ಆಗಿರುವುದರಿಂದ, `FnMut` ಅನ್ನು ನಿರೀಕ್ಷಿಸಿದಲ್ಲಿ [`Fn`] ನ ಯಾವುದೇ ಉದಾಹರಣೆಯನ್ನು ಬಳಸಬಹುದು.
///
/// ನೀವು ಕಾರ್ಯ-ರೀತಿಯ ಪ್ರಕಾರದ ನಿಯತಾಂಕವನ್ನು ಸ್ವೀಕರಿಸಲು ಬಯಸಿದಾಗ `FnMut` ಅನ್ನು ಬೌಂಡ್ ಆಗಿ ಬಳಸಿ ಮತ್ತು ಅದನ್ನು ಪದೇ ಪದೇ ಕರೆಯುವ ಅಗತ್ಯವಿರುತ್ತದೆ, ಆದರೆ ಅದನ್ನು ಸ್ಥಿತಿಯನ್ನು ಪರಿವರ್ತಿಸಲು ಅನುಮತಿಸುತ್ತದೆ.
/// ಪ್ಯಾರಾಮೀಟರ್ ಸ್ಥಿತಿಯನ್ನು ಪರಿವರ್ತಿಸಲು ನೀವು ಬಯಸದಿದ್ದರೆ, [`Fn`] ಅನ್ನು ಬೌಂಡ್ ಆಗಿ ಬಳಸಿ;ನೀವು ಅದನ್ನು ಪದೇ ಪದೇ ಕರೆಯುವ ಅಗತ್ಯವಿಲ್ಲದಿದ್ದರೆ, [`FnOnce`] ಬಳಸಿ.
///
/// ಈ ವಿಷಯದ ಕುರಿತು ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ [chapter on closures in *The Rust Programming Language*][book] ನೋಡಿ.
///
/// `Fn` traits (ಉದಾ.) ಗಾಗಿ ವಿಶೇಷ ಸಿಂಟ್ಯಾಕ್ಸ್ ಸಹ ಗಮನಿಸಬೇಕಾದ ಅಂಶವಾಗಿದೆ
/// `Fn(usize, bool) -> usize`).ಇದರ ತಾಂತ್ರಿಕ ವಿವರಗಳಲ್ಲಿ ಆಸಕ್ತಿ ಇರುವವರು [the relevant section in the *Rustonomicon*][nomicon] ಅನ್ನು ಉಲ್ಲೇಖಿಸಬಹುದು.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## ಪರಸ್ಪರ ಸೆರೆಹಿಡಿಯುವ ಮುಚ್ಚುವಿಕೆ ಎಂದು ಕರೆಯಲಾಗುತ್ತಿದೆ
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## `FnMut` ನಿಯತಾಂಕವನ್ನು ಬಳಸುವುದು
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ಆದ್ದರಿಂದ regex ಆ `&str: !FnMut` ಅನ್ನು ಅವಲಂಬಿಸಬಹುದು
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// ಕರೆ ಕಾರ್ಯಾಚರಣೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// ಬೈ-ವ್ಯಾಲ್ಯೂ ರಿಸೀವರ್ ತೆಗೆದುಕೊಳ್ಳುವ ಕರೆ ಆಪರೇಟರ್‌ನ ಆವೃತ್ತಿ.
///
/// `FnOnce` ನ ನಿದರ್ಶನಗಳನ್ನು ಕರೆಯಬಹುದು, ಆದರೆ ಅನೇಕ ಬಾರಿ ಕರೆಯಲಾಗುವುದಿಲ್ಲ.ಈ ಕಾರಣದಿಂದಾಗಿ, ಒಂದು ಪ್ರಕಾರದ ಬಗ್ಗೆ ತಿಳಿದಿರುವ ಏಕೈಕ ವಿಷಯವೆಂದರೆ ಅದು `FnOnce` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ, ಅದನ್ನು ಒಮ್ಮೆ ಮಾತ್ರ ಕರೆಯಬಹುದು.
///
/// `FnOnce` ಸೆರೆಹಿಡಿಯಲಾದ ಅಸ್ಥಿರಗಳನ್ನು ಸೇವಿಸುವಂತಹ ಮುಚ್ಚುವಿಕೆಯಿಂದ ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಕಾರ್ಯಗತಗೊಳ್ಳುತ್ತದೆ, ಜೊತೆಗೆ [`FnMut`], ಉದಾ., (safe) [function pointers] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಎಲ್ಲಾ ಪ್ರಕಾರಗಳು (`FnOnce` [`FnMut`] ನ ಸೂಪರ್‌ಟ್ರೇಟ್ ಆಗಿರುವುದರಿಂದ).
///
///
/// [`Fn`] ಮತ್ತು [`FnMut`] ಎರಡೂ `FnOnce` ನ ಸಬ್‌ಟ್ರೇಟ್‌ಗಳಾಗಿರುವುದರಿಂದ, [`Fn`] ಅಥವಾ [`FnMut`] ನ ಯಾವುದೇ ಉದಾಹರಣೆಯನ್ನು `FnOnce` ನಿರೀಕ್ಷಿಸಿದ ಸ್ಥಳದಲ್ಲಿ ಬಳಸಬಹುದು.
///
/// ನೀವು ಕಾರ್ಯ-ರೀತಿಯ ಪ್ರಕಾರದ ನಿಯತಾಂಕವನ್ನು ಸ್ವೀಕರಿಸಲು ಬಯಸಿದಾಗ `FnOnce` ಅನ್ನು ಬೌಂಡ್ ಆಗಿ ಬಳಸಿ ಮತ್ತು ಅದನ್ನು ಒಮ್ಮೆ ಮಾತ್ರ ಕರೆಯಬೇಕಾಗುತ್ತದೆ.
/// ನೀವು ನಿಯತಾಂಕವನ್ನು ಪದೇ ಪದೇ ಕರೆಯಬೇಕಾದರೆ, [`FnMut`] ಅನ್ನು ಬೌಂಡ್ ಆಗಿ ಬಳಸಿ;ಸ್ಥಿತಿಯನ್ನು ಪರಿವರ್ತಿಸದಿರಲು ನಿಮಗೆ ಅಗತ್ಯವಿದ್ದರೆ, [`Fn`] ಬಳಸಿ.
///
/// ಈ ವಿಷಯದ ಕುರಿತು ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ [chapter on closures in *The Rust Programming Language*][book] ನೋಡಿ.
///
/// `Fn` traits (ಉದಾ.) ಗಾಗಿ ವಿಶೇಷ ಸಿಂಟ್ಯಾಕ್ಸ್ ಸಹ ಗಮನಿಸಬೇಕಾದ ಅಂಶವಾಗಿದೆ
/// `Fn(usize, bool) -> usize`).ಇದರ ತಾಂತ್ರಿಕ ವಿವರಗಳಲ್ಲಿ ಆಸಕ್ತಿ ಇರುವವರು [the relevant section in the *Rustonomicon*][nomicon] ಅನ್ನು ಉಲ್ಲೇಖಿಸಬಹುದು.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## `FnOnce` ನಿಯತಾಂಕವನ್ನು ಬಳಸುವುದು
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` ಅದರ ಸೆರೆಹಿಡಿದ ಅಸ್ಥಿರಗಳನ್ನು ಬಳಸುತ್ತದೆ, ಆದ್ದರಿಂದ ಇದನ್ನು ಒಂದಕ್ಕಿಂತ ಹೆಚ್ಚು ಬಾರಿ ಚಲಾಯಿಸಲಾಗುವುದಿಲ್ಲ.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // `func()` ಅನ್ನು ಮತ್ತೆ ಆಹ್ವಾನಿಸಲು ಪ್ರಯತ್ನಿಸುವುದರಿಂದ `func` ಗಾಗಿ `use of moved value` ದೋಷವನ್ನು ಎಸೆಯಲಾಗುತ್ತದೆ.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` ಈ ಹಂತದಲ್ಲಿ ಇನ್ನು ಮುಂದೆ ಆಹ್ವಾನಿಸಲಾಗುವುದಿಲ್ಲ
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ಆದ್ದರಿಂದ regex ಆ `&str: !FnMut` ಅನ್ನು ಅವಲಂಬಿಸಬಹುದು
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// ಕರೆ ಆಪರೇಟರ್ ಬಳಸಿದ ನಂತರ ಹಿಂತಿರುಗಿದ ಪ್ರಕಾರ.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// ಕರೆ ಕಾರ್ಯಾಚರಣೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}