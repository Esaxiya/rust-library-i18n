/// `*v` ನಂತಹ ಬದಲಾಗದ ಡಿಫರೆನ್ಸಿಂಗ್ ಕಾರ್ಯಾಚರಣೆಗಳಿಗೆ ಬಳಸಲಾಗುತ್ತದೆ.
///
/// ಬದಲಾಗದ ಸಂದರ್ಭಗಳಲ್ಲಿ (unary) `*` ಆಪರೇಟರ್‌ನೊಂದಿಗೆ ಸ್ಪಷ್ಟವಾದ ಡಿಫರೆನ್ಸಿಂಗ್ ಕಾರ್ಯಾಚರಣೆಗಳಿಗೆ ಬಳಸುವುದರ ಜೊತೆಗೆ, `Deref` ಅನ್ನು ಕಂಪೈಲರ್ ಅನೇಕ ಸಂದರ್ಭಗಳಲ್ಲಿ ಸೂಚ್ಯವಾಗಿ ಬಳಸುತ್ತಾರೆ.
/// ಈ ಕಾರ್ಯವಿಧಾನವನ್ನು ['`Deref` coercion'][more] ಎಂದು ಕರೆಯಲಾಗುತ್ತದೆ.
/// ರೂಪಾಂತರಿತ ಸಂದರ್ಭಗಳಲ್ಲಿ, [`DerefMut`] ಅನ್ನು ಬಳಸಲಾಗುತ್ತದೆ.
///
/// ಸ್ಮಾರ್ಟ್ ಪಾಯಿಂಟರ್‌ಗಳಿಗಾಗಿ `Deref` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದರಿಂದ ಅವುಗಳ ಹಿಂದಿನ ಡೇಟಾವನ್ನು ಪ್ರವೇಶಿಸಲು ಅನುಕೂಲಕರವಾಗಿಸುತ್ತದೆ, ಅದಕ್ಕಾಗಿಯೇ ಅವರು `Deref` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತಾರೆ.
/// ಮತ್ತೊಂದೆಡೆ, ಸ್ಮಾರ್ಟ್ ಪಾಯಿಂಟರ್‌ಗಳಿಗೆ ಅನುಗುಣವಾಗಿ `Deref` ಮತ್ತು [`DerefMut`] ಗೆ ಸಂಬಂಧಿಸಿದ ನಿಯಮಗಳನ್ನು ವಿಶೇಷವಾಗಿ ವಿನ್ಯಾಸಗೊಳಿಸಲಾಗಿದೆ.
/// ಈ ಕಾರಣದಿಂದಾಗಿ, ಗೊಂದಲವನ್ನು ತಪ್ಪಿಸಲು ** `ಡೆರೆಫ್` ಅನ್ನು ಸ್ಮಾರ್ಟ್ ಪಾಯಿಂಟರ್‌ಗಳಿಗೆ ಮಾತ್ರ ಕಾರ್ಯಗತಗೊಳಿಸಬೇಕು.
///
/// ಇದೇ ಕಾರಣಗಳಿಗಾಗಿ,**ಈ trait ಎಂದಿಗೂ ವಿಫಲವಾಗಬಾರದು**.`Deref` ಅನ್ನು ಸೂಚ್ಯವಾಗಿ ಆಹ್ವಾನಿಸಿದಾಗ ಡಿಫರೆನ್ಸಿಂಗ್ ಸಮಯದಲ್ಲಿನ ವೈಫಲ್ಯವು ಅತ್ಯಂತ ಗೊಂದಲಕ್ಕೊಳಗಾಗುತ್ತದೆ.
///
/// # `Deref` ದಬ್ಬಾಳಿಕೆಯ ಕುರಿತು ಇನ್ನಷ್ಟು
///
/// `T` `Deref<Target = U>` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದರೆ, ಮತ್ತು `x` `T` ಪ್ರಕಾರದ ಮೌಲ್ಯವಾಗಿದ್ದರೆ, ನಂತರ:
///
/// * ಬದಲಾಗದ ಸಂದರ್ಭಗಳಲ್ಲಿ, `*x` (ಅಲ್ಲಿ `T` ಒಂದು ಉಲ್ಲೇಖ ಅಥವಾ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಅಲ್ಲ) `* Deref::deref(&x)` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ.
/// * `&T` ಪ್ರಕಾರದ ಮೌಲ್ಯಗಳನ್ನು `&U` ಪ್ರಕಾರದ ಮೌಲ್ಯಗಳಿಗೆ ಒತ್ತಾಯಿಸಲಾಗುತ್ತದೆ
/// * `T` `U` ಪ್ರಕಾರದ ಎಲ್ಲಾ (immutable) ವಿಧಾನಗಳನ್ನು ಸೂಚ್ಯವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
///
/// ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ, [the chapter in *The Rust Programming Language*][book] ಮತ್ತು [the dereference operator][ref-deref-op], [method resolution] ಮತ್ತು [type coercions] ನಲ್ಲಿನ ಉಲ್ಲೇಖ ವಿಭಾಗಗಳಿಗೆ ಭೇಟಿ ನೀಡಿ.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// ಒಂದೇ ಕ್ಷೇತ್ರವನ್ನು ಹೊಂದಿರುವ ರಚನೆಯು ರಚನೆಯನ್ನು ಡಿಫರೆನ್ ಮಾಡುವ ಮೂಲಕ ಪ್ರವೇಶಿಸಬಹುದು.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// ಡಿಫರೆನ್ಸಿಂಗ್ ನಂತರ ಫಲಿತಾಂಶದ ಪ್ರಕಾರ.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// ಮೌಲ್ಯವನ್ನು ಕಡಿಮೆ ಮಾಡುತ್ತದೆ.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// `*v = 1;` ನಂತೆ ರೂಪಾಂತರಿತ ಡಿಫರೆನ್ಸಿಂಗ್ ಕಾರ್ಯಾಚರಣೆಗಳಿಗೆ ಬಳಸಲಾಗುತ್ತದೆ.
///
/// ರೂಪಾಂತರಿತ ಸಂದರ್ಭಗಳಲ್ಲಿ (unary) `*` ಆಪರೇಟರ್‌ನೊಂದಿಗೆ ಸ್ಪಷ್ಟವಾದ ಡಿಫರೆನ್ಸಿಂಗ್ ಕಾರ್ಯಾಚರಣೆಗಳಿಗೆ ಬಳಸುವುದರ ಜೊತೆಗೆ, `DerefMut` ಅನ್ನು ಕಂಪೈಲರ್ ಅನೇಕ ಸಂದರ್ಭಗಳಲ್ಲಿ ಸೂಚ್ಯವಾಗಿ ಬಳಸುತ್ತಾರೆ.
/// ಈ ಕಾರ್ಯವಿಧಾನವನ್ನು ['`Deref` coercion'][more] ಎಂದು ಕರೆಯಲಾಗುತ್ತದೆ.
/// ಬದಲಾಗದ ಸಂದರ್ಭಗಳಲ್ಲಿ, [`Deref`] ಅನ್ನು ಬಳಸಲಾಗುತ್ತದೆ.
///
/// ಸ್ಮಾರ್ಟ್ ಪಾಯಿಂಟರ್‌ಗಳಿಗಾಗಿ `DerefMut` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದರಿಂದ ಅವುಗಳ ಹಿಂದಿನ ಡೇಟಾವನ್ನು ಪರಿವರ್ತಿಸಲು ಅನುಕೂಲಕರವಾಗಿಸುತ್ತದೆ, ಅದಕ್ಕಾಗಿಯೇ ಅವರು `DerefMut` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತಾರೆ.
/// ಮತ್ತೊಂದೆಡೆ, ಸ್ಮಾರ್ಟ್ ಪಾಯಿಂಟರ್‌ಗಳಿಗೆ ಅನುಗುಣವಾಗಿ [`Deref`] ಮತ್ತು `DerefMut` ಗೆ ಸಂಬಂಧಿಸಿದ ನಿಯಮಗಳನ್ನು ವಿಶೇಷವಾಗಿ ವಿನ್ಯಾಸಗೊಳಿಸಲಾಗಿದೆ.
/// ಈ ಕಾರಣದಿಂದಾಗಿ, ಗೊಂದಲವನ್ನು ತಪ್ಪಿಸಲು ** `ಡೆರೆಫ್‌ಮಟ್` ಅನ್ನು ಸ್ಮಾರ್ಟ್ ಪಾಯಿಂಟರ್‌ಗಳಿಗೆ ಮಾತ್ರ ಕಾರ್ಯಗತಗೊಳಿಸಬೇಕು.
///
/// ಇದೇ ಕಾರಣಗಳಿಗಾಗಿ,**ಈ trait ಎಂದಿಗೂ ವಿಫಲವಾಗಬಾರದು**.`DerefMut` ಅನ್ನು ಸೂಚ್ಯವಾಗಿ ಆಹ್ವಾನಿಸಿದಾಗ ಡಿಫರೆನ್ಸಿಂಗ್ ಸಮಯದಲ್ಲಿನ ವೈಫಲ್ಯವು ಅತ್ಯಂತ ಗೊಂದಲಕ್ಕೊಳಗಾಗುತ್ತದೆ.
///
/// # `Deref` ದಬ್ಬಾಳಿಕೆಯ ಕುರಿತು ಇನ್ನಷ್ಟು
///
/// `T` `DerefMut<Target = U>` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದರೆ, ಮತ್ತು `x` `T` ಪ್ರಕಾರದ ಮೌಲ್ಯವಾಗಿದ್ದರೆ, ನಂತರ:
///
/// * ರೂಪಾಂತರಗೊಳ್ಳುವ ಸಂದರ್ಭಗಳಲ್ಲಿ, `*x` (ಅಲ್ಲಿ `T` ಒಂದು ಉಲ್ಲೇಖ ಅಥವಾ ಕಚ್ಚಾ ಪಾಯಿಂಟರ್ ಅಲ್ಲ) `* DerefMut::deref_mut(&mut x)` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ.
/// * `&mut T` ಪ್ರಕಾರದ ಮೌಲ್ಯಗಳನ್ನು `&mut U` ಪ್ರಕಾರದ ಮೌಲ್ಯಗಳಿಗೆ ಒತ್ತಾಯಿಸಲಾಗುತ್ತದೆ
/// * `T` `U` ಪ್ರಕಾರದ ಎಲ್ಲಾ (mutable) ವಿಧಾನಗಳನ್ನು ಸೂಚ್ಯವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
///
/// ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ, [the chapter in *The Rust Programming Language*][book] ಮತ್ತು [the dereference operator][ref-deref-op], [method resolution] ಮತ್ತು [type coercions] ನಲ್ಲಿನ ಉಲ್ಲೇಖ ವಿಭಾಗಗಳಿಗೆ ಭೇಟಿ ನೀಡಿ.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// ಒಂದೇ ಕ್ಷೇತ್ರವನ್ನು ಹೊಂದಿರುವ ರಚನೆಯು ರಚನೆಯನ್ನು ಡಿಫರೆನ್ಸ್ ಮಾಡುವ ಮೂಲಕ ಮಾರ್ಪಡಿಸಬಹುದು.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// ಮೌಲ್ಯವನ್ನು ಮೌಲ್ಯವನ್ನು ಅಪನಗದಗೊಳಿಸುತ್ತದೆ.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// `arbitrary_self_types` ವೈಶಿಷ್ಟ್ಯವಿಲ್ಲದೆ, ಒಂದು struct ಅನ್ನು ವಿಧಾನ ರಿಸೀವರ್ ಆಗಿ ಬಳಸಬಹುದು ಎಂದು ಸೂಚಿಸುತ್ತದೆ.
///
/// ಇದನ್ನು ಸ್ಟಡ್ಲಿಬ್ ಪಾಯಿಂಟರ್ ಪ್ರಕಾರಗಳಾದ `Box<T>`, `Rc<T>`, `&T`, ಮತ್ತು `Pin<P>` ನಿಂದ ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗುತ್ತದೆ.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}