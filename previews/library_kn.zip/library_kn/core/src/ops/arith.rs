/// ಸೇರ್ಪಡೆ ಆಪರೇಟರ್ `+`.
///
/// `Rhs` ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ `Self` ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಆದರೆ ಇದು ಕಡ್ಡಾಯವಲ್ಲ.
/// ಉದಾಹರಣೆಗೆ, [`std::time::SystemTime`] `Add<Duration>` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ, ಇದು `SystemTime = SystemTime + Duration` ರೂಪದ ಕಾರ್ಯಾಚರಣೆಯನ್ನು ಅನುಮತಿಸುತ್ತದೆ.
///
///
/// [`std::time::SystemTime`]: ../../std/time/struct.SystemTime.html
///
/// # Examples
///
/// ## `ಸೇರಿಸಬಹುದಾದ` ಅಂಕಗಳನ್ನು ಸೇರಿಸಿ
///
/// ```
/// use std::ops::Add;
///
/// #[derive(Debug, Copy, Clone, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl Add for Point {
///     type Output = Self;
///
///     fn add(self, other: Self) -> Self {
///         Self {
///             x: self.x + other.x,
///             y: self.y + other.y,
///         }
///     }
/// }
///
/// assert_eq!(Point { x: 1, y: 0 } + Point { x: 2, y: 3 },
///            Point { x: 3, y: 3 });
/// ```
///
/// ## ಜೆನೆರಿಕ್ಸ್‌ನೊಂದಿಗೆ `Add` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗುತ್ತಿದೆ
///
/// ಜೆನೆರಿಕ್ಸ್ ಬಳಸಿ `Add` trait ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಅದೇ `Point` ರಚನೆಯ ಉದಾಹರಣೆ ಇಲ್ಲಿದೆ.
///
/// ```
/// use std::ops::Add;
///
/// #[derive(Debug, Copy, Clone, PartialEq)]
/// struct Point<T> {
///     x: T,
///     y: T,
/// }
///
/// // ಅನುಷ್ಠಾನವು ಸಂಬಂಧಿತ ಪ್ರಕಾರದ `Output` ಅನ್ನು ಬಳಸುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
/// impl<T: Add<Output = T>> Add for Point<T> {
///     type Output = Self;
///
///     fn add(self, other: Self) -> Self::Output {
///         Self {
///             x: self.x + other.x,
///             y: self.y + other.y,
///         }
///     }
/// }
///
/// assert_eq!(Point { x: 1, y: 0 } + Point { x: 2, y: 3 },
///            Point { x: 3, y: 3 });
/// ```
///
#[lang = "add"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(all(_Self = "{integer}", Rhs = "{float}"), message = "cannot add a float to an integer",),
    on(all(_Self = "{float}", Rhs = "{integer}"), message = "cannot add an integer to a float",),
    message = "cannot add `{Rhs}` to `{Self}`",
    label = "no implementation for `{Self} + {Rhs}`"
)]
#[doc(alias = "+")]
pub trait Add<Rhs = Self> {
    /// `+` ಆಪರೇಟರ್ ಅನ್ನು ಅನ್ವಯಿಸಿದ ನಂತರ ಫಲಿತಾಂಶದ ಪ್ರಕಾರ.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output;

    /// `+` ಕಾರ್ಯಾಚರಣೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
    ///
    /// # Example
    ///
    /// ```
    /// assert_eq!(12 + 1, 13);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn add(self, rhs: Rhs) -> Self::Output;
}

macro_rules! add_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Add for $t {
            type Output = $t;

            #[inline]
            #[rustc_inherit_overflow_checks]
            fn add(self, other: $t) -> $t { self + other }
        }

        forward_ref_binop! { impl Add, add for $t, $t }
    )*)
}

add_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// ವ್ಯವಕಲನ ಆಪರೇಟರ್ `-`.
///
/// `Rhs` ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ `Self` ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಆದರೆ ಇದು ಕಡ್ಡಾಯವಲ್ಲ.
/// ಉದಾಹರಣೆಗೆ, [`std::time::SystemTime`] `Sub<Duration>` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ, ಇದು `SystemTime = SystemTime - Duration` ರೂಪದ ಕಾರ್ಯಾಚರಣೆಯನ್ನು ಅನುಮತಿಸುತ್ತದೆ.
///
///
/// [`std::time::SystemTime`]: ../../std/time/struct.SystemTime.html
///
/// # Examples
///
/// ## `ಉಪ` ಟ್ರ್ಯಾಕ್ಟಬಲ್ ಪಾಯಿಂಟ್‌ಗಳು
///
/// ```
/// use std::ops::Sub;
///
/// #[derive(Debug, Copy, Clone, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl Sub for Point {
///     type Output = Self;
///
///     fn sub(self, other: Self) -> Self::Output {
///         Self {
///             x: self.x - other.x,
///             y: self.y - other.y,
///         }
///     }
/// }
///
/// assert_eq!(Point { x: 3, y: 3 } - Point { x: 2, y: 3 },
///            Point { x: 1, y: 0 });
/// ```
///
/// ## ಜೆನೆರಿಕ್ಸ್‌ನೊಂದಿಗೆ `Sub` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗುತ್ತಿದೆ
///
/// ಜೆನೆರಿಕ್ಸ್ ಬಳಸಿ `Sub` trait ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಅದೇ `Point` ರಚನೆಯ ಉದಾಹರಣೆ ಇಲ್ಲಿದೆ.
///
/// ```
/// use std::ops::Sub;
///
/// #[derive(Debug, PartialEq)]
/// struct Point<T> {
///     x: T,
///     y: T,
/// }
///
/// // ಅನುಷ್ಠಾನವು ಸಂಬಂಧಿತ ಪ್ರಕಾರದ `Output` ಅನ್ನು ಬಳಸುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
/// impl<T: Sub<Output = T>> Sub for Point<T> {
///     type Output = Self;
///
///     fn sub(self, other: Self) -> Self::Output {
///         Point {
///             x: self.x - other.x,
///             y: self.y - other.y,
///         }
///     }
/// }
///
/// assert_eq!(Point { x: 2, y: 3 } - Point { x: 1, y: 0 },
///            Point { x: 1, y: 3 });
/// ```
///
#[lang = "sub"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "cannot subtract `{Rhs}` from `{Self}`",
    label = "no implementation for `{Self} - {Rhs}`"
)]
#[doc(alias = "-")]
pub trait Sub<Rhs = Self> {
    /// `-` ಆಪರೇಟರ್ ಅನ್ನು ಅನ್ವಯಿಸಿದ ನಂತರ ಫಲಿತಾಂಶದ ಪ್ರಕಾರ.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output;

    /// `-` ಕಾರ್ಯಾಚರಣೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
    ///
    /// # Example
    ///
    /// ```
    /// assert_eq!(12 - 1, 11);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn sub(self, rhs: Rhs) -> Self::Output;
}

macro_rules! sub_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Sub for $t {
            type Output = $t;

            #[inline]
            #[rustc_inherit_overflow_checks]
            fn sub(self, other: $t) -> $t { self - other }
        }

        forward_ref_binop! { impl Sub, sub for $t, $t }
    )*)
}

sub_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// ಗುಣಾಕಾರ ಆಪರೇಟರ್ `*`.
///
/// `Rhs` ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ `Self` ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಆದರೆ ಇದು ಕಡ್ಡಾಯವಲ್ಲ.
///
/// # Examples
///
/// ## `ಮುಲ್` ಸೂಚಿಸಬಹುದಾದ ಭಾಗಲಬ್ಧ ಸಂಖ್ಯೆಗಳು
///
/// ```
/// use std::ops::Mul;
///
/// // ಅಂಕಗಣಿತದ ಮೂಲಭೂತ ಪ್ರಮೇಯದಿಂದ, ಕಡಿಮೆ ಪದಗಳಲ್ಲಿ ಭಾಗಲಬ್ಧ ಸಂಖ್ಯೆಗಳು ವಿಶಿಷ್ಟವಾಗಿವೆ.
/// // ಆದ್ದರಿಂದ, `ತರ್ಕಬದ್ಧತೆಯನ್ನು ಕಡಿಮೆ ರೂಪದಲ್ಲಿ ಇರಿಸುವ ಮೂಲಕ, ನಾವು `Eq` ಮತ್ತು `PartialEq` ಅನ್ನು ಪಡೆಯಬಹುದು.
/////
/// #[derive(Debug, Eq, PartialEq)]
/// struct Rational {
///     numerator: usize,
///     denominator: usize,
/// }
///
/// impl Rational {
///     fn new(numerator: usize, denominator: usize) -> Self {
///         if denominator == 0 {
///             panic!("Zero is an invalid denominator!");
///         }
///
///         // ಶ್ರೇಷ್ಠ ಸಾಮಾನ್ಯ ವಿಭಾಜಕದಿಂದ ಭಾಗಿಸುವ ಮೂಲಕ ಕಡಿಮೆ ಪದಗಳಿಗೆ ಇಳಿಸಿ.
/////
///         let gcd = gcd(numerator, denominator);
///         Self {
///             numerator: numerator / gcd,
///             denominator: denominator / gcd,
///         }
///     }
/// }
///
/// impl Mul for Rational {
///     // ಭಾಗಲಬ್ಧ ಸಂಖ್ಯೆಗಳ ಗುಣಾಕಾರವು ಮುಚ್ಚಿದ ಕಾರ್ಯಾಚರಣೆಯಾಗಿದೆ.
///     type Output = Self;
///
///     fn mul(self, rhs: Self) -> Self {
///         let numerator = self.numerator * rhs.numerator;
///         let denominator = self.denominator * rhs.denominator;
///         Self::new(numerator, denominator)
///     }
/// }
///
/// // ಶ್ರೇಷ್ಠ ಸಾಮಾನ್ಯ ವಿಭಾಜಕವನ್ನು ಕಂಡುಹಿಡಿಯಲು ಯೂಕ್ಲಿಡ್‌ನ ಎರಡು ಸಾವಿರ ವರ್ಷಗಳ ಹಳೆಯ ಅಲ್ಗಾರಿದಮ್.
/////
/// fn gcd(x: usize, y: usize) -> usize {
///     let mut x = x;
///     let mut y = y;
///     while y != 0 {
///         let t = y;
///         y = x % y;
///         x = t;
///     }
///     x
/// }
///
/// assert_eq!(Rational::new(1, 2), Rational::new(2, 4));
/// assert_eq!(Rational::new(2, 3) * Rational::new(3, 4),
///            Rational::new(1, 2));
/// ```
///
/// ## ರೇಖೀಯ ಬೀಜಗಣಿತದಂತೆ ಸ್ಕೇಲರ್‌ಗಳಿಂದ vectors ಅನ್ನು ಗುಣಿಸುವುದು
///
/// ```
/// use std::ops::Mul;
///
/// struct Scalar { value: usize }
///
/// #[derive(Debug, PartialEq)]
/// struct Vector { value: Vec<usize> }
///
/// impl Mul<Scalar> for Vector {
///     type Output = Self;
///
///     fn mul(self, rhs: Scalar) -> Self::Output {
///         Self { value: self.value.iter().map(|v| v * rhs.value).collect() }
///     }
/// }
///
/// let vector = Vector { value: vec![2, 4, 6] };
/// let scalar = Scalar { value: 3 };
/// assert_eq!(vector * scalar, Vector { value: vec![6, 12, 18] });
/// ```
#[lang = "mul"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "cannot multiply `{Self}` by `{Rhs}`",
    label = "no implementation for `{Self} * {Rhs}`"
)]
#[doc(alias = "*")]
pub trait Mul<Rhs = Self> {
    /// `*` ಆಪರೇಟರ್ ಅನ್ನು ಅನ್ವಯಿಸಿದ ನಂತರ ಫಲಿತಾಂಶದ ಪ್ರಕಾರ.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output;

    /// `*` ಕಾರ್ಯಾಚರಣೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
    ///
    /// # Example
    ///
    /// ```
    /// assert_eq!(12 * 2, 24);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn mul(self, rhs: Rhs) -> Self::Output;
}

macro_rules! mul_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Mul for $t {
            type Output = $t;

            #[inline]
            #[rustc_inherit_overflow_checks]
            fn mul(self, other: $t) -> $t { self * other }
        }

        forward_ref_binop! { impl Mul, mul for $t, $t }
    )*)
}

mul_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// ವಿಭಾಗ ಆಪರೇಟರ್ `/`.
///
/// `Rhs` ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ `Self` ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಆದರೆ ಇದು ಕಡ್ಡಾಯವಲ್ಲ.
///
/// # Examples
///
/// ## `ಡಿವ್` ಮಾಡಬಹುದಾದ ಭಾಗಲಬ್ಧ ಸಂಖ್ಯೆಗಳು
///
/// ```
/// use std::ops::Div;
///
/// // ಅಂಕಗಣಿತದ ಮೂಲಭೂತ ಪ್ರಮೇಯದಿಂದ, ಕಡಿಮೆ ಪದಗಳಲ್ಲಿ ಭಾಗಲಬ್ಧ ಸಂಖ್ಯೆಗಳು ವಿಶಿಷ್ಟವಾಗಿವೆ.
/// // ಆದ್ದರಿಂದ, `ತರ್ಕಬದ್ಧತೆಯನ್ನು ಕಡಿಮೆ ರೂಪದಲ್ಲಿ ಇರಿಸುವ ಮೂಲಕ, ನಾವು `Eq` ಮತ್ತು `PartialEq` ಅನ್ನು ಪಡೆಯಬಹುದು.
/////
/// #[derive(Debug, Eq, PartialEq)]
/// struct Rational {
///     numerator: usize,
///     denominator: usize,
/// }
///
/// impl Rational {
///     fn new(numerator: usize, denominator: usize) -> Self {
///         if denominator == 0 {
///             panic!("Zero is an invalid denominator!");
///         }
///
///         // ಶ್ರೇಷ್ಠ ಸಾಮಾನ್ಯ ವಿಭಾಜಕದಿಂದ ಭಾಗಿಸುವ ಮೂಲಕ ಕಡಿಮೆ ಪದಗಳಿಗೆ ಇಳಿಸಿ.
/////
///         let gcd = gcd(numerator, denominator);
///         Self {
///             numerator: numerator / gcd,
///             denominator: denominator / gcd,
///         }
///     }
/// }
///
/// impl Div for Rational {
///     // ಭಾಗಲಬ್ಧ ಸಂಖ್ಯೆಗಳ ವಿಭಜನೆಯು ಒಂದು ಮುಚ್ಚಿದ ಕಾರ್ಯಾಚರಣೆಯಾಗಿದೆ.
///     type Output = Self;
///
///     fn div(self, rhs: Self) -> Self::Output {
///         if rhs.numerator == 0 {
///             panic!("Cannot divide by zero-valued `Rational`!");
///         }
///
///         let numerator = self.numerator * rhs.denominator;
///         let denominator = self.denominator * rhs.numerator;
///         Self::new(numerator, denominator)
///     }
/// }
///
/// // ಶ್ರೇಷ್ಠ ಸಾಮಾನ್ಯ ವಿಭಾಜಕವನ್ನು ಕಂಡುಹಿಡಿಯಲು ಯೂಕ್ಲಿಡ್‌ನ ಎರಡು ಸಾವಿರ ವರ್ಷಗಳ ಹಳೆಯ ಅಲ್ಗಾರಿದಮ್.
/////
/// fn gcd(x: usize, y: usize) -> usize {
///     let mut x = x;
///     let mut y = y;
///     while y != 0 {
///         let t = y;
///         y = x % y;
///         x = t;
///     }
///     x
/// }
///
/// assert_eq!(Rational::new(1, 2), Rational::new(2, 4));
/// assert_eq!(Rational::new(1, 2) / Rational::new(3, 4),
///            Rational::new(2, 3));
/// ```
///
/// ## ರೇಖೀಯ ಬೀಜಗಣಿತದಂತೆ ಸ್ಕೇಲರ್‌ಗಳಿಂದ vectors ಅನ್ನು ಭಾಗಿಸುವುದು
///
/// ```
/// use std::ops::Div;
///
/// struct Scalar { value: f32 }
///
/// #[derive(Debug, PartialEq)]
/// struct Vector { value: Vec<f32> }
///
/// impl Div<Scalar> for Vector {
///     type Output = Self;
///
///     fn div(self, rhs: Scalar) -> Self::Output {
///         Self { value: self.value.iter().map(|v| v / rhs.value).collect() }
///     }
/// }
///
/// let scalar = Scalar { value: 2f32 };
/// let vector = Vector { value: vec![2f32, 4f32, 6f32] };
/// assert_eq!(vector / scalar, Vector { value: vec![1f32, 2f32, 3f32] });
/// ```
#[lang = "div"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "cannot divide `{Self}` by `{Rhs}`",
    label = "no implementation for `{Self} / {Rhs}`"
)]
#[doc(alias = "/")]
pub trait Div<Rhs = Self> {
    /// `/` ಆಪರೇಟರ್ ಅನ್ನು ಅನ್ವಯಿಸಿದ ನಂತರ ಫಲಿತಾಂಶದ ಪ್ರಕಾರ.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output;

    /// `/` ಕಾರ್ಯಾಚರಣೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
    ///
    /// # Example
    ///
    /// ```
    /// assert_eq!(12 / 2, 6);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn div(self, rhs: Rhs) -> Self::Output;
}

macro_rules! div_impl_integer {
    ($($t:ty)*) => ($(
        /// ಈ ಕಾರ್ಯಾಚರಣೆಯು ಶೂನ್ಯದ ಕಡೆಗೆ ಸುತ್ತುತ್ತದೆ, ನಿಖರ ಫಲಿತಾಂಶದ ಯಾವುದೇ ಭಾಗ ಭಾಗವನ್ನು ಮೊಟಕುಗೊಳಿಸುತ್ತದೆ.
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Div for $t {
            type Output = $t;

            #[inline]
            fn div(self, other: $t) -> $t { self / other }
        }

        forward_ref_binop! { impl Div, div for $t, $t }
    )*)
}

div_impl_integer! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

macro_rules! div_impl_float {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Div for $t {
            type Output = $t;

            #[inline]
            fn div(self, other: $t) -> $t { self / other }
        }

        forward_ref_binop! { impl Div, div for $t, $t }
    )*)
}

div_impl_float! { f32 f64 }

/// ಉಳಿದ ಆಪರೇಟರ್ `%`.
///
/// `Rhs` ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ `Self` ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಆದರೆ ಇದು ಕಡ್ಡಾಯವಲ್ಲ.
///
/// # Examples
///
/// ಈ ಉದಾಹರಣೆಯು `SplitSlice` ವಸ್ತುವಿನ ಮೇಲೆ `Rem` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
/// `Rem` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದ ನಂತರ, ಒಂದು ನಿರ್ದಿಷ್ಟ ಉದ್ದದ ಸಮಾನ ಹೋಳುಗಳಾಗಿ ವಿಭಜಿಸಿದ ನಂತರ ಸ್ಲೈಸ್‌ನ ಉಳಿದ ಅಂಶಗಳು ಏನೆಂದು ಕಂಡುಹಿಡಿಯಲು `%` ಆಪರೇಟರ್ ಅನ್ನು ಬಳಸಬಹುದು.
///
///
/// ```
/// use std::ops::Rem;
///
/// #[derive(PartialEq, Debug)]
/// struct SplitSlice<'a, T: 'a> {
///     slice: &'a [T],
/// }
///
/// impl<'a, T> Rem<usize> for SplitSlice<'a, T> {
///     type Output = Self;
///
///     fn rem(self, modulus: usize) -> Self::Output {
///         let len = self.slice.len();
///         let rem = len % modulus;
///         let start = len - rem;
///         Self {slice: &self.slice[start..]}
///     }
/// }
///
/// // ನಾವು&[0, 1, 2, 3, 4, 5, 6, 7] ಅನ್ನು 3 ಗಾತ್ರದ ಚೂರುಗಳಾಗಿ ವಿಂಗಡಿಸಿದರೆ, ಉಳಿದವು&[6, 7] ಆಗಿರುತ್ತದೆ.
/////
/// assert_eq!(SplitSlice { slice: &[0, 1, 2, 3, 4, 5, 6, 7] } % 3,
///            SplitSlice { slice: &[6, 7] });
/// ```
///
#[lang = "rem"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "cannot mod `{Self}` by `{Rhs}`",
    label = "no implementation for `{Self} % {Rhs}`"
)]
#[doc(alias = "%")]
pub trait Rem<Rhs = Self> {
    /// `%` ಆಪರೇಟರ್ ಅನ್ನು ಅನ್ವಯಿಸಿದ ನಂತರ ಫಲಿತಾಂಶದ ಪ್ರಕಾರ.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output;

    /// `%` ಕಾರ್ಯಾಚರಣೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
    ///
    /// # Example
    ///
    /// ```
    /// assert_eq!(12 % 10, 2);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rem(self, rhs: Rhs) -> Self::Output;
}

macro_rules! rem_impl_integer {
    ($($t:ty)*) => ($(
        /// ಈ ಕಾರ್ಯಾಚರಣೆಯು `n % d == n - (n / d) * d` ಅನ್ನು ತೃಪ್ತಿಪಡಿಸುತ್ತದೆ.
        /// ಫಲಿತಾಂಶವು ಎಡ ಕಾರ್ಯಾಚರಣೆಯಂತೆಯೇ ಒಂದೇ ಚಿಹ್ನೆಯನ್ನು ಹೊಂದಿದೆ.
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Rem for $t {
            type Output = $t;

            #[inline]
            fn rem(self, other: $t) -> $t { self % other }
        }

        forward_ref_binop! { impl Rem, rem for $t, $t }
    )*)
}

rem_impl_integer! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

macro_rules! rem_impl_float {
    ($($t:ty)*) => ($(

        /// ಎರಡು ಫ್ಲೋಟ್‌ಗಳ ವಿಭಾಗದಿಂದ ಉಳಿದವು.
        ///
        /// ಉಳಿದವು ಲಾಭಾಂಶದಂತೆಯೇ ಒಂದೇ ಚಿಹ್ನೆಯನ್ನು ಹೊಂದಿದೆ ಮತ್ತು ಇದನ್ನು ಹೀಗೆ ಲೆಕ್ಕಹಾಕಲಾಗುತ್ತದೆ: `x - (x / y).trunc() * y`.
        ///
        /// # Examples
        ///
        /// ```
        /// let x: f32 = 50.50;
        /// let y: f32 = 8.125;
        /// let remainder = x - (x / y).trunc() * y;
        ///
        /// // ಎರಡೂ ಕಾರ್ಯಾಚರಣೆಗಳಿಗೆ ಉತ್ತರ 1.75 ಆಗಿದೆ
        /// assert_eq!(x % y, remainder);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Rem for $t {
            type Output = $t;

            #[inline]
            fn rem(self, other: $t) -> $t { self % other }
        }

        forward_ref_binop! { impl Rem, rem for $t, $t }
    )*)
}

rem_impl_float! { f32 f64 }

/// ಅನಾರಿ ನಿರಾಕರಣೆ ಆಪರೇಟರ್ `-`.
///
/// # Examples
///
/// `Sign` ಗಾಗಿ `Neg` ನ ಅನುಷ್ಠಾನ, ಇದು `-` ಬಳಕೆಯನ್ನು ಅದರ ಮೌಲ್ಯವನ್ನು ನಿರಾಕರಿಸಲು ಅನುವು ಮಾಡಿಕೊಡುತ್ತದೆ.
///
///
/// ```
/// use std::ops::Neg;
///
/// #[derive(Debug, PartialEq)]
/// enum Sign {
///     Negative,
///     Zero,
///     Positive,
/// }
///
/// impl Neg for Sign {
///     type Output = Self;
///
///     fn neg(self) -> Self::Output {
///         match self {
///             Sign::Negative => Sign::Positive,
///             Sign::Zero => Sign::Zero,
///             Sign::Positive => Sign::Negative,
///         }
///     }
/// }
///
/// // Positive ಣಾತ್ಮಕ ಧನಾತ್ಮಕ a ಣಾತ್ಮಕ.
/// assert_eq!(-Sign::Positive, Sign::Negative);
/// // ಡಬಲ್ ನೆಗೆಟಿವ್ ಧನಾತ್ಮಕವಾಗಿರುತ್ತದೆ.
/// assert_eq!(-Sign::Negative, Sign::Positive);
/// // ಶೂನ್ಯವು ತನ್ನದೇ ಆದ ನಿರಾಕರಣೆಯಾಗಿದೆ.
/// assert_eq!(-Sign::Zero, Sign::Zero);
/// ```
#[lang = "neg"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "-")]
pub trait Neg {
    /// `-` ಆಪರೇಟರ್ ಅನ್ನು ಅನ್ವಯಿಸಿದ ನಂತರ ಫಲಿತಾಂಶದ ಪ್ರಕಾರ.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output;

    /// ಏಕರೂಪದ `-` ಕಾರ್ಯಾಚರಣೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
    ///
    /// # Example
    ///
    /// ```
    /// let x: i32 = 12;
    /// assert_eq!(-x, -12);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn neg(self) -> Self::Output;
}

macro_rules! neg_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Neg for $t {
            type Output = $t;

            #[inline]
            #[rustc_inherit_overflow_checks]
            fn neg(self) -> $t { -self }
        }

        forward_ref_unop! { impl Neg, neg for $t }
    )*)
}

neg_impl! { isize i8 i16 i32 i64 i128 f32 f64 }

/// ಸೇರ್ಪಡೆ ನಿಯೋಜನೆ ಆಪರೇಟರ್ `+=`.
///
/// # Examples
///
/// ಈ ಉದಾಹರಣೆಯು `Point` struct ಅನ್ನು ರಚಿಸುತ್ತದೆ ಅದು `AddAssign` trait ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ, ತದನಂತರ ರೂಪಾಂತರಿತ `Point` ಗೆ ಆಡ್-ಅಸೈನಿಂಗ್ ಅನ್ನು ತೋರಿಸುತ್ತದೆ.
///
///
/// ```
/// use std::ops::AddAssign;
///
/// #[derive(Debug, Copy, Clone, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl AddAssign for Point {
///     fn add_assign(&mut self, other: Self) {
///         *self = Self {
///             x: self.x + other.x,
///             y: self.y + other.y,
///         };
///     }
/// }
///
/// let mut point = Point { x: 1, y: 0 };
/// point += Point { x: 2, y: 3 };
/// assert_eq!(point, Point { x: 3, y: 3 });
/// ```
#[lang = "add_assign"]
#[stable(feature = "op_assign_traits", since = "1.8.0")]
#[rustc_on_unimplemented(
    message = "cannot add-assign `{Rhs}` to `{Self}`",
    label = "no implementation for `{Self} += {Rhs}`"
)]
#[doc(alias = "+")]
#[doc(alias = "+=")]
pub trait AddAssign<Rhs = Self> {
    /// `+=` ಕಾರ್ಯಾಚರಣೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
    ///
    /// # Example
    ///
    /// ```
    /// let mut x: u32 = 12;
    /// x += 1;
    /// assert_eq!(x, 13);
    /// ```
    #[stable(feature = "op_assign_traits", since = "1.8.0")]
    fn add_assign(&mut self, rhs: Rhs);
}

macro_rules! add_assign_impl {
    ($($t:ty)+) => ($(
        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl AddAssign for $t {
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn add_assign(&mut self, other: $t) { *self += other }
        }

        forward_ref_op_assign! { impl AddAssign, add_assign for $t, $t }
    )+)
}

add_assign_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// ವ್ಯವಕಲನ ನಿಯೋಜನೆ ಆಪರೇಟರ್ `-=`.
///
/// # Examples
///
/// ಈ ಉದಾಹರಣೆಯು `Point` struct ಅನ್ನು ರಚಿಸುತ್ತದೆ ಅದು `SubAssign` trait ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ, ತದನಂತರ ರೂಪಾಂತರಿತ `Point` ಗೆ ಉಪ-ನಿಯೋಜನೆಯನ್ನು ತೋರಿಸುತ್ತದೆ.
///
///
/// ```
/// use std::ops::SubAssign;
///
/// #[derive(Debug, Copy, Clone, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl SubAssign for Point {
///     fn sub_assign(&mut self, other: Self) {
///         *self = Self {
///             x: self.x - other.x,
///             y: self.y - other.y,
///         };
///     }
/// }
///
/// let mut point = Point { x: 3, y: 3 };
/// point -= Point { x: 2, y: 3 };
/// assert_eq!(point, Point {x: 1, y: 0});
/// ```
#[lang = "sub_assign"]
#[stable(feature = "op_assign_traits", since = "1.8.0")]
#[rustc_on_unimplemented(
    message = "cannot subtract-assign `{Rhs}` from `{Self}`",
    label = "no implementation for `{Self} -= {Rhs}`"
)]
#[doc(alias = "-")]
#[doc(alias = "-=")]
pub trait SubAssign<Rhs = Self> {
    /// `-=` ಕಾರ್ಯಾಚರಣೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
    ///
    /// # Example
    ///
    /// ```
    /// let mut x: u32 = 12;
    /// x -= 1;
    /// assert_eq!(x, 11);
    /// ```
    #[stable(feature = "op_assign_traits", since = "1.8.0")]
    fn sub_assign(&mut self, rhs: Rhs);
}

macro_rules! sub_assign_impl {
    ($($t:ty)+) => ($(
        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl SubAssign for $t {
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn sub_assign(&mut self, other: $t) { *self -= other }
        }

        forward_ref_op_assign! { impl SubAssign, sub_assign for $t, $t }
    )+)
}

sub_assign_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// ಗುಣಾಕಾರ ನಿಯೋಜನೆ ಆಪರೇಟರ್ `*=`.
///
/// # Examples
///
/// ```
/// use std::ops::MulAssign;
///
/// #[derive(Debug, PartialEq)]
/// struct Frequency { hertz: f64 }
///
/// impl MulAssign<f64> for Frequency {
///     fn mul_assign(&mut self, rhs: f64) {
///         self.hertz *= rhs;
///     }
/// }
///
/// let mut frequency = Frequency { hertz: 50.0 };
/// frequency *= 4.0;
/// assert_eq!(Frequency { hertz: 200.0 }, frequency);
/// ```
#[lang = "mul_assign"]
#[stable(feature = "op_assign_traits", since = "1.8.0")]
#[rustc_on_unimplemented(
    message = "cannot multiply-assign `{Self}` by `{Rhs}`",
    label = "no implementation for `{Self} *= {Rhs}`"
)]
#[doc(alias = "*")]
#[doc(alias = "*=")]
pub trait MulAssign<Rhs = Self> {
    /// `*=` ಕಾರ್ಯಾಚರಣೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
    ///
    /// # Example
    ///
    /// ```
    /// let mut x: u32 = 12;
    /// x *= 2;
    /// assert_eq!(x, 24);
    /// ```
    #[stable(feature = "op_assign_traits", since = "1.8.0")]
    fn mul_assign(&mut self, rhs: Rhs);
}

macro_rules! mul_assign_impl {
    ($($t:ty)+) => ($(
        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl MulAssign for $t {
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn mul_assign(&mut self, other: $t) { *self *= other }
        }

        forward_ref_op_assign! { impl MulAssign, mul_assign for $t, $t }
    )+)
}

mul_assign_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// ವಿಭಾಗ ನಿಯೋಜನೆ ಆಪರೇಟರ್ `/=`.
///
/// # Examples
///
/// ```
/// use std::ops::DivAssign;
///
/// #[derive(Debug, PartialEq)]
/// struct Frequency { hertz: f64 }
///
/// impl DivAssign<f64> for Frequency {
///     fn div_assign(&mut self, rhs: f64) {
///         self.hertz /= rhs;
///     }
/// }
///
/// let mut frequency = Frequency { hertz: 200.0 };
/// frequency /= 4.0;
/// assert_eq!(Frequency { hertz: 50.0 }, frequency);
/// ```
#[lang = "div_assign"]
#[stable(feature = "op_assign_traits", since = "1.8.0")]
#[rustc_on_unimplemented(
    message = "cannot divide-assign `{Self}` by `{Rhs}`",
    label = "no implementation for `{Self} /= {Rhs}`"
)]
#[doc(alias = "/")]
#[doc(alias = "/=")]
pub trait DivAssign<Rhs = Self> {
    /// `/=` ಕಾರ್ಯಾಚರಣೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
    ///
    /// # Example
    ///
    /// ```
    /// let mut x: u32 = 12;
    /// x /= 2;
    /// assert_eq!(x, 6);
    /// ```
    #[stable(feature = "op_assign_traits", since = "1.8.0")]
    fn div_assign(&mut self, rhs: Rhs);
}

macro_rules! div_assign_impl {
    ($($t:ty)+) => ($(
        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl DivAssign for $t {
            #[inline]
            fn div_assign(&mut self, other: $t) { *self /= other }
        }

        forward_ref_op_assign! { impl DivAssign, div_assign for $t, $t }
    )+)
}

div_assign_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// ಉಳಿದ ನಿಯೋಜನೆ ಆಪರೇಟರ್ `%=`.
///
/// # Examples
///
/// ```
/// use std::ops::RemAssign;
///
/// struct CookieJar { cookies: u32 }
///
/// impl RemAssign<u32> for CookieJar {
///     fn rem_assign(&mut self, piles: u32) {
///         self.cookies %= piles;
///     }
/// }
///
/// let mut jar = CookieJar { cookies: 31 };
/// let piles = 4;
///
/// println!("Splitting up {} cookies into {} even piles!", jar.cookies, piles);
///
/// jar %= piles;
///
/// println!("{} cookies remain in the cookie jar!", jar.cookies);
/// ```
#[lang = "rem_assign"]
#[stable(feature = "op_assign_traits", since = "1.8.0")]
#[rustc_on_unimplemented(
    message = "cannot mod-assign `{Self}` by `{Rhs}``",
    label = "no implementation for `{Self} %= {Rhs}`"
)]
#[doc(alias = "%")]
#[doc(alias = "%=")]
pub trait RemAssign<Rhs = Self> {
    /// `%=` ಕಾರ್ಯಾಚರಣೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
    ///
    /// # Example
    ///
    /// ```
    /// let mut x: u32 = 12;
    /// x %= 10;
    /// assert_eq!(x, 2);
    /// ```
    #[stable(feature = "op_assign_traits", since = "1.8.0")]
    fn rem_assign(&mut self, rhs: Rhs);
}

macro_rules! rem_assign_impl {
    ($($t:ty)+) => ($(
        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl RemAssign for $t {
            #[inline]
            fn rem_assign(&mut self, other: $t) { *self %= other }
        }

        forward_ref_op_assign! { impl RemAssign, rem_assign for $t, $t }
    )+)
}

rem_assign_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }