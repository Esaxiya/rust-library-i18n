use crate::ops::Try;

/// ಕಾರ್ಯಾಚರಣೆಯು ಬೇಗನೆ ನಿರ್ಗಮಿಸಬೇಕೇ ಅಥವಾ ಎಂದಿನಂತೆ ಮುಂದುವರಿಯಬೇಕೆ ಎಂದು ಹೇಳಲು ಬಳಸಲಾಗುತ್ತದೆ.
///
/// ವಿಷಯಗಳನ್ನು ನಿರ್ಗಮಿಸುವಾಗ ಇದನ್ನು ಬಳಸಲಾಗುತ್ತದೆ (ಗ್ರಾಫ್ ಟ್ರಾವೆರ್ಸಲ್‌ಗಳು ಅಥವಾ ಸಂದರ್ಶಕರಂತೆ) ಅಲ್ಲಿ ಬಳಕೆದಾರರು ಬೇಗನೆ ನಿರ್ಗಮಿಸಬೇಕೆ ಎಂದು ಆಯ್ಕೆ ಮಾಡಿಕೊಳ್ಳಲು ನೀವು ಬಯಸುತ್ತೀರಿ.
/// ಎನಮ್ ಅನ್ನು ಹೊಂದಿರುವುದು ಅದನ್ನು ಸ್ಪಷ್ಟಪಡಿಸುತ್ತದೆ-ಹೆಚ್ಚು ಆಶ್ಚರ್ಯಪಡುವ "wait, what did `false` mean again?" ಇಲ್ಲ-ಮತ್ತು ಮೌಲ್ಯವನ್ನು ಒಳಗೊಂಡಂತೆ ಅನುಮತಿಸುತ್ತದೆ.
///
/// # Examples
///
/// [`Iterator::try_for_each`] ನಿಂದ ಆರಂಭಿಕ ನಿರ್ಗಮನ:
///
/// ```
/// #![feature(control_flow_enum)]
/// use std::ops::ControlFlow;
///
/// let r = (2..100).try_for_each(|x| {
///     if 403 % x == 0 {
///         return ControlFlow::Break(x)
///     }
///
///     ControlFlow::Continue(())
/// });
/// assert_eq!(r, ControlFlow::Break(13));
/// ```
///
/// ಒಂದು ಮೂಲ ಮರದ ಅಡ್ಡಹಾಯುವಿಕೆ:
///
/// ```no_run
/// #![feature(control_flow_enum)]
/// use std::ops::ControlFlow;
///
/// pub struct TreeNode<T> {
///     value: T,
///     left: Option<Box<TreeNode<T>>>,
///     right: Option<Box<TreeNode<T>>>,
/// }
///
/// impl<T> TreeNode<T> {
///     pub fn traverse_inorder<B>(&self, mut f: impl FnMut(&T) -> ControlFlow<B>) -> ControlFlow<B> {
///         if let Some(left) = &self.left {
///             left.traverse_inorder(&mut f)?;
///         }
///         f(&self.value)?;
///         if let Some(right) = &self.right {
///             right.traverse_inorder(&mut f)?;
///         }
///         ControlFlow::Continue(())
///     }
/// }
/// ```
#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum ControlFlow<B, C = ()> {
    /// ಕಾರ್ಯಾಚರಣೆಯ ಮುಂದಿನ ಹಂತಕ್ಕೆ ಸಾಮಾನ್ಯದಂತೆ ಸರಿಸಿ.
    Continue(C),
    /// ನಂತರದ ಹಂತಗಳನ್ನು ಚಲಾಯಿಸದೆ ಕಾರ್ಯಾಚರಣೆಯಿಂದ ನಿರ್ಗಮಿಸಿ.
    Break(B),
    // ಹೌದು, ರೂಪಾಂತರಗಳ ಕ್ರಮವು ಪ್ರಕಾರದ ನಿಯತಾಂಕಗಳಿಗೆ ಹೊಂದಿಕೆಯಾಗುವುದಿಲ್ಲ.
    // ಅವರು ಈ ಕ್ರಮದಲ್ಲಿದ್ದಾರೆ ಆದ್ದರಿಂದ `ControlFlow<A, B>` <-> `Result<B, A>` ಎಂಬುದು `Try` ಅನುಷ್ಠಾನದಲ್ಲಿ ಯಾವುದೇ ಆಪ್ ಪರಿವರ್ತನೆಯಾಗಿಲ್ಲ.
    //
}

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
impl<B, C> Try for ControlFlow<B, C> {
    type Ok = C;
    type Error = B;
    #[inline]
    fn into_result(self) -> Result<Self::Ok, Self::Error> {
        match self {
            ControlFlow::Continue(y) => Ok(y),
            ControlFlow::Break(x) => Err(x),
        }
    }
    #[inline]
    fn from_error(v: Self::Error) -> Self {
        ControlFlow::Break(v)
    }
    #[inline]
    fn from_ok(v: Self::Ok) -> Self {
        ControlFlow::Continue(v)
    }
}

impl<B, C> ControlFlow<B, C> {
    /// ಇದು `Break` ರೂಪಾಂತರವಾಗಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// assert!(ControlFlow::<i32, String>::Break(3).is_break());
    /// assert!(!ControlFlow::<String, i32>::Continue(3).is_break());
    /// ```
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn is_break(&self) -> bool {
        matches!(*self, ControlFlow::Break(_))
    }

    /// ಇದು `Continue` ರೂಪಾಂತರವಾಗಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// assert!(!ControlFlow::<i32, String>::Break(3).is_continue());
    /// assert!(ControlFlow::<String, i32>::Continue(3).is_continue());
    /// ```
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn is_continue(&self) -> bool {
        matches!(*self, ControlFlow::Continue(_))
    }

    /// `ControlFlow` ಅನ್ನು `Option` ಆಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ, ಅದು `ControlFlow` `Break` ಆಗಿದ್ದರೆ ಮತ್ತು `None` ಇಲ್ಲದಿದ್ದರೆ `Some` ಆಗಿದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// assert_eq!(ControlFlow::<i32, String>::Break(3).break_value(), Some(3));
    /// assert_eq!(ControlFlow::<String, i32>::Continue(3).break_value(), None);
    /// ```
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn break_value(self) -> Option<B> {
        match self {
            ControlFlow::Continue(..) => None,
            ControlFlow::Break(x) => Some(x),
        }
    }

    /// ಒಂದು ಕಾರ್ಯ ಅಸ್ತಿತ್ವದಲ್ಲಿದ್ದರೆ ಅದನ್ನು ಬ್ರೇಕ್ ಮೌಲ್ಯಕ್ಕೆ ಅನ್ವಯಿಸುವ ಮೂಲಕ `ControlFlow<B, C>` ರಿಂದ `ControlFlow<T, C>` ಗೆ ನಕ್ಷೆಗಳು.
    ///
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn map_break<T, F>(self, f: F) -> ControlFlow<T, C>
    where
        F: FnOnce(B) -> T,
    {
        match self {
            ControlFlow::Continue(x) => ControlFlow::Continue(x),
            ControlFlow::Break(x) => ControlFlow::Break(f(x)),
        }
    }
}

impl<R: Try> ControlFlow<R, R::Ok> {
    /// `Try` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಯಾವುದೇ ಪ್ರಕಾರದಿಂದ `ControlFlow` ಅನ್ನು ರಚಿಸಿ.
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    #[inline]
    pub fn from_try(r: R) -> Self {
        match Try::into_result(r) {
            Ok(v) => ControlFlow::Continue(v),
            Err(v) => ControlFlow::Break(Try::from_error(v)),
        }
    }

    /// `Try` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಯಾವುದೇ ಪ್ರಕಾರಕ್ಕೆ `ControlFlow` ಅನ್ನು ಪರಿವರ್ತಿಸಿ;
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    #[inline]
    pub fn into_try(self) -> R {
        match self {
            ControlFlow::Continue(v) => Try::from_ok(v),
            ControlFlow::Break(v) => v,
        }
    }
}

impl<B> ControlFlow<B, ()> {
    /// `Continue` ನೊಂದಿಗೆ ಯಾವುದೇ ಮೌಲ್ಯದ ಅಗತ್ಯವಿಲ್ಲ ಎಂಬುದು ಆಗಾಗ್ಗೆ ಆಗುತ್ತದೆ, ಆದ್ದರಿಂದ ನೀವು ಬಯಸಿದಲ್ಲಿ `(())` ಅನ್ನು ಟೈಪ್ ಮಾಡುವುದನ್ನು ತಪ್ಪಿಸಲು ಇದು ಒಂದು ಮಾರ್ಗವನ್ನು ಒದಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// let mut partial_sum = 0;
    /// let last_used = (1..10).chain(20..25).try_for_each(|x| {
    ///     partial_sum += x;
    ///     if partial_sum > 100 { ControlFlow::Break(x) }
    ///     else { ControlFlow::CONTINUE }
    /// });
    /// assert_eq!(last_used.break_value(), Some(22));
    /// ```
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub const CONTINUE: Self = ControlFlow::Continue(());
}

impl<C> ControlFlow<(), C> {
    /// `try_for_each` ನಂತಹ API ಗಳಿಗೆ `Break` ನೊಂದಿಗೆ ಮೌಲ್ಯಗಳು ಅಗತ್ಯವಿಲ್ಲ, ಆದ್ದರಿಂದ ನೀವು ಬಯಸಿದಲ್ಲಿ `(())` ಅನ್ನು ಟೈಪ್ ಮಾಡುವುದನ್ನು ತಪ್ಪಿಸಲು ಇದು ಒಂದು ಮಾರ್ಗವನ್ನು ಒದಗಿಸುತ್ತದೆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// let mut partial_sum = 0;
    /// (1..10).chain(20..25).try_for_each(|x| {
    ///     if partial_sum > 100 { ControlFlow::BREAK }
    ///     else { partial_sum += x; ControlFlow::CONTINUE }
    /// });
    /// assert_eq!(partial_sum, 108);
    /// ```
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub const BREAK: Self = ControlFlow::Break(());
}