//! ಕಂಪೈಲರ್ ಆಂತರಿಕ.
//!
//! ಅನುಗುಣವಾದ ವ್ಯಾಖ್ಯಾನಗಳು `compiler/rustc_codegen_llvm/src/intrinsic.rs` ನಲ್ಲಿವೆ.
//! ಅನುಗುಣವಾದ ಕಾನ್ಸ್ ಅನುಷ್ಠಾನಗಳು `compiler/rustc_mir/src/interpret/intrinsics.rs` ನಲ್ಲಿವೆ
//!
//! # ಕಾನ್ಸ್ಟ್ ಆಂತರಿಕ
//!
//! Note: ಆಂತರಿಕತೆಯ ಸ್ಥಿರತೆಗೆ ಯಾವುದೇ ಬದಲಾವಣೆಗಳನ್ನು ಭಾಷಾ ತಂಡದೊಂದಿಗೆ ಚರ್ಚಿಸಬೇಕು.
//! ಇದು ಸ್ಥಿರತೆಯ ಸ್ಥಿರತೆಯ ಬದಲಾವಣೆಗಳನ್ನು ಒಳಗೊಂಡಿದೆ.
//!
//! ಕಂಪೈಲ್ ಸಮಯದಲ್ಲಿ ಆಂತರಿಕವಾಗಿ ಬಳಸಬಹುದಾದಂತೆ ಮಾಡಲು, ಒಬ್ಬರು ಅನುಷ್ಠಾನವನ್ನು <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> ನಿಂದ `compiler/rustc_mir/src/interpret/intrinsics.rs` ಗೆ ನಕಲಿಸಬೇಕು ಮತ್ತು `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ಅನ್ನು ಆಂತರಿಕವಾಗಿ ಸೇರಿಸಬೇಕಾಗುತ್ತದೆ.
//!
//!
//! `rustc_const_stable` ಗುಣಲಕ್ಷಣದೊಂದಿಗೆ `const fn` ನಿಂದ ಆಂತರಿಕವನ್ನು ಬಳಸಬೇಕಾದರೆ, ಆಂತರಿಕ ಗುಣಲಕ್ಷಣವು `rustc_const_stable` ಆಗಿರಬೇಕು.
//! ಟಿ-ಲ್ಯಾಂಗ್ ಸಮಾಲೋಚನೆ ಇಲ್ಲದೆ ಅಂತಹ ಬದಲಾವಣೆಯನ್ನು ಮಾಡಬಾರದು, ಏಕೆಂದರೆ ಇದು ಕಂಪೈಲರ್ ಬೆಂಬಲವಿಲ್ಲದೆ ಬಳಕೆದಾರರ ಕೋಡ್‌ನಲ್ಲಿ ಪುನರಾವರ್ತಿಸಲು ಸಾಧ್ಯವಾಗದಂತಹ ವೈಶಿಷ್ಟ್ಯವನ್ನು ಭಾಷೆಗೆ ಬೇಯಿಸುತ್ತದೆ.
//!
//! # Volatiles
//!
//! ಬಾಷ್ಪಶೀಲ ಆಂತರಿಕತೆಗಳು I/O ಮೆಮೊರಿಯಲ್ಲಿ ಕಾರ್ಯನಿರ್ವಹಿಸಲು ಉದ್ದೇಶಿಸಿರುವ ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಒದಗಿಸುತ್ತವೆ, ಇವುಗಳನ್ನು ಇತರ ಬಾಷ್ಪಶೀಲ ಆಂತರಿಕಗಳಲ್ಲಿ ಕಂಪೈಲರ್ ಮರುಕ್ರಮಗೊಳಿಸುವುದಿಲ್ಲ ಎಂದು ಖಾತರಿಪಡಿಸಲಾಗಿದೆ.[[volatile]] ನಲ್ಲಿ LLVM ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! ಪರಮಾಣು ಆಂತರಿಕವು ಯಂತ್ರ ಪದಗಳಲ್ಲಿ ಸಾಮಾನ್ಯ ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಒದಗಿಸುತ್ತದೆ, ಅನೇಕ ಸಂಭಾವ್ಯ ಮೆಮೊರಿ ಆದೇಶಗಳನ್ನು ನೀಡುತ್ತದೆ.ಅವರು C++ 11 ನಂತೆಯೇ ಅದೇ ಶಬ್ದಾರ್ಥವನ್ನು ಪಾಲಿಸುತ್ತಾರೆ.[[atomics]] ನಲ್ಲಿ LLVM ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! ಮೆಮೊರಿ ಆದೇಶದ ಕುರಿತು ತ್ವರಿತ ರಿಫ್ರೆಶ್:
//!
//! * ಅಕ್ವೈರ್, ಲಾಕ್ ಪಡೆಯಲು ತಡೆ.ನಂತರದ ಓದುವಿಕೆ ಮತ್ತು ಬರಹಗಳು ತಡೆಗೋಡೆಯ ನಂತರ ನಡೆಯುತ್ತವೆ.
//! * ಬಿಡುಗಡೆ, ಲಾಕ್ ಅನ್ನು ಬಿಡುಗಡೆ ಮಾಡಲು ತಡೆ.ಹಿಂದಿನ ಓದುಗಳು ಮತ್ತು ಬರಹಗಳು ತಡೆಗೋಡೆಗೆ ಮೊದಲು ನಡೆಯುತ್ತವೆ.
//! * ಅನುಕ್ರಮವಾಗಿ ಸ್ಥಿರವಾದ, ಅನುಕ್ರಮವಾಗಿ ಸ್ಥಿರವಾದ ಕಾರ್ಯಾಚರಣೆಗಳು ಕ್ರಮದಲ್ಲಿ ನಡೆಯುವ ಭರವಸೆ ಇದೆ.ಪರಮಾಣು ಪ್ರಕಾರಗಳೊಂದಿಗೆ ಕೆಲಸ ಮಾಡಲು ಇದು ಪ್ರಮಾಣಿತ ಮೋಡ್ ಆಗಿದೆ ಮತ್ತು ಇದು Java ನ `volatile` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// ಇಂಟ್ರಾ-ಡಾಕ್ ಲಿಂಕ್‌ಗಳನ್ನು ಸರಳೀಕರಿಸಲು ಈ ಆಮದುಗಳನ್ನು ಬಳಸಲಾಗುತ್ತದೆ
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // ಸುರಕ್ಷತೆ: `ptr::drop_in_place` ನೋಡಿ
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, ಈ ಆಂತರಿಕ ಅಂಶಗಳು ಕಚ್ಚಾ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತವೆ ಏಕೆಂದರೆ ಅವು ಅಲಿಯಾಸ್ಡ್ ಮೆಮೊರಿಯನ್ನು ರೂಪಾಂತರಿಸುತ್ತವೆ, ಇದು `&` ಅಥವಾ `&mut` ಗೆ ಮಾನ್ಯವಾಗಿಲ್ಲ.
    //

    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `old` ಮೌಲ್ಯದಂತೆಯೇ ಇದ್ದರೆ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// [`Ordering::SeqCst`] ಅನ್ನು `success` ಮತ್ತು `failure` ನಿಯತಾಂಕಗಳಂತೆ [`Ordering::SeqCst`] ಅನ್ನು ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ವಿಧಾನದ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯು ಲಭ್ಯವಿದೆ.
    ///
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `old` ಮೌಲ್ಯದಂತೆಯೇ ಇದ್ದರೆ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`Ordering::Acquire`] ಅನ್ನು `compare_exchange` ವಿಧಾನದ ಮೂಲಕ `compare_exchange` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Acquire`] ಅನ್ನು `success` ಮತ್ತು `failure` ಎರಡೂ ನಿಯತಾಂಕಗಳಾಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    ///
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `old` ಮೌಲ್ಯದಂತೆಯೇ ಇದ್ದರೆ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `compare_exchange` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Release`] ಅನ್ನು `success` ಆಗಿ ಮತ್ತು [`Ordering::Relaxed`] ಅನ್ನು `failure` ನಿಯತಾಂಕಗಳಾಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `old` ಮೌಲ್ಯದಂತೆಯೇ ಇದ್ದರೆ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `compare_exchange` ವಿಧಾನದ ಮೂಲಕ [`Ordering::AcqRel`] ಅನ್ನು `success` ಆಗಿ ಮತ್ತು [`Ordering::Acquire`] ಅನ್ನು `failure` ನಿಯತಾಂಕಗಳಾಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `old` ಮೌಲ್ಯದಂತೆಯೇ ಇದ್ದರೆ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// [`Ordering::Relaxed`] ಅನ್ನು `success` ಮತ್ತು `failure` ನಿಯತಾಂಕಗಳಂತೆ [`Ordering::Relaxed`] ಅನ್ನು ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ವಿಧಾನದ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯು ಲಭ್ಯವಿದೆ.
    ///
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `old` ಮೌಲ್ಯದಂತೆಯೇ ಇದ್ದರೆ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `compare_exchange` ವಿಧಾನದ ಮೂಲಕ [`Ordering::SeqCst`] ಅನ್ನು `success` ಆಗಿ ಮತ್ತು [`Ordering::Relaxed`] ಅನ್ನು `failure` ನಿಯತಾಂಕಗಳಾಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `old` ಮೌಲ್ಯದಂತೆಯೇ ಇದ್ದರೆ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `compare_exchange` ವಿಧಾನದ ಮೂಲಕ [`Ordering::SeqCst`] ಅನ್ನು `success` ಆಗಿ ಮತ್ತು [`Ordering::Acquire`] ಅನ್ನು `failure` ನಿಯತಾಂಕಗಳಾಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `old` ಮೌಲ್ಯದಂತೆಯೇ ಇದ್ದರೆ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `compare_exchange` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Acquire`] ಅನ್ನು `success` ಆಗಿ ಮತ್ತು [`Ordering::Relaxed`] ಅನ್ನು `failure` ನಿಯತಾಂಕಗಳಾಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `old` ಮೌಲ್ಯದಂತೆಯೇ ಇದ್ದರೆ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `compare_exchange` ವಿಧಾನದ ಮೂಲಕ [`Ordering::AcqRel`] ಅನ್ನು `success` ಆಗಿ ಮತ್ತು [`Ordering::Relaxed`] ಅನ್ನು `failure` ನಿಯತಾಂಕಗಳಾಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `old` ಮೌಲ್ಯದಂತೆಯೇ ಇದ್ದರೆ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// [`Ordering::SeqCst`] ಅನ್ನು `success` ಮತ್ತು `failure` ನಿಯತಾಂಕಗಳಂತೆ [`Ordering::SeqCst`] ಅನ್ನು ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ವಿಧಾನದ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯು ಲಭ್ಯವಿದೆ.
    ///
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `old` ಮೌಲ್ಯದಂತೆಯೇ ಇದ್ದರೆ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// [`Ordering::Acquire`] ಅನ್ನು `success` ಮತ್ತು `failure` ನಿಯತಾಂಕಗಳಂತೆ [`Ordering::Acquire`] ಅನ್ನು ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ವಿಧಾನದ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯು ಲಭ್ಯವಿದೆ.
    ///
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `old` ಮೌಲ್ಯದಂತೆಯೇ ಇದ್ದರೆ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `compare_exchange_weak` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Release`] ಅನ್ನು `success` ಆಗಿ ಮತ್ತು [`Ordering::Relaxed`] ಅನ್ನು `failure` ನಿಯತಾಂಕಗಳಾಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `old` ಮೌಲ್ಯದಂತೆಯೇ ಇದ್ದರೆ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `compare_exchange_weak` ವಿಧಾನದ ಮೂಲಕ [`Ordering::AcqRel`] ಅನ್ನು `success` ಆಗಿ ಮತ್ತು [`Ordering::Acquire`] ಅನ್ನು `failure` ನಿಯತಾಂಕಗಳಾಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `old` ಮೌಲ್ಯದಂತೆಯೇ ಇದ್ದರೆ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// [`Ordering::Relaxed`] ಅನ್ನು `success` ಮತ್ತು `failure` ನಿಯತಾಂಕಗಳಂತೆ [`Ordering::Relaxed`] ಅನ್ನು ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ವಿಧಾನದ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯು ಲಭ್ಯವಿದೆ.
    ///
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `old` ಮೌಲ್ಯದಂತೆಯೇ ಇದ್ದರೆ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `compare_exchange_weak` ವಿಧಾನದ ಮೂಲಕ [`Ordering::SeqCst`] ಅನ್ನು `success` ಆಗಿ ಮತ್ತು [`Ordering::Relaxed`] ಅನ್ನು `failure` ನಿಯತಾಂಕಗಳಾಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `old` ಮೌಲ್ಯದಂತೆಯೇ ಇದ್ದರೆ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `compare_exchange_weak` ವಿಧಾನದ ಮೂಲಕ [`Ordering::SeqCst`] ಅನ್ನು `success` ಆಗಿ ಮತ್ತು [`Ordering::Acquire`] ಅನ್ನು `failure` ನಿಯತಾಂಕಗಳಾಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `old` ಮೌಲ್ಯದಂತೆಯೇ ಇದ್ದರೆ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `compare_exchange_weak` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Acquire`] ಅನ್ನು `success` ಆಗಿ ಮತ್ತು [`Ordering::Relaxed`] ಅನ್ನು `failure` ನಿಯತಾಂಕಗಳಾಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯವು `old` ಮೌಲ್ಯದಂತೆಯೇ ಇದ್ದರೆ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `compare_exchange_weak` ವಿಧಾನದ ಮೂಲಕ [`Ordering::AcqRel`] ಅನ್ನು `success` ಆಗಿ ಮತ್ತು [`Ordering::Relaxed`] ಅನ್ನು `failure` ನಿಯತಾಂಕಗಳಾಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// ಪಾಯಿಂಟರ್‌ನ ಪ್ರಸ್ತುತ ಮೌಲ್ಯವನ್ನು ಲೋಡ್ ಮಾಡುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `load` ವಿಧಾನದ ಮೂಲಕ [`Ordering::SeqCst`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// ಪಾಯಿಂಟರ್‌ನ ಪ್ರಸ್ತುತ ಮೌಲ್ಯವನ್ನು ಲೋಡ್ ಮಾಡುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `load` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Acquire`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// ಪಾಯಿಂಟರ್‌ನ ಪ್ರಸ್ತುತ ಮೌಲ್ಯವನ್ನು ಲೋಡ್ ಮಾಡುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `load` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Relaxed`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಮೆಮೊರಿ ಸ್ಥಳದಲ್ಲಿ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `store` ವಿಧಾನದ ಮೂಲಕ [`Ordering::SeqCst`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಮೆಮೊರಿ ಸ್ಥಳದಲ್ಲಿ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `store` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Release`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಮೆಮೊರಿ ಸ್ಥಳದಲ್ಲಿ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `store` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Relaxed`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// ಮೌಲ್ಯವನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಮೆಮೊರಿ ಸ್ಥಳದಲ್ಲಿ ಸಂಗ್ರಹಿಸುತ್ತದೆ, ಹಳೆಯ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `swap` ವಿಧಾನದ ಮೂಲಕ [`Ordering::SeqCst`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಮೌಲ್ಯವನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಮೆಮೊರಿ ಸ್ಥಳದಲ್ಲಿ ಸಂಗ್ರಹಿಸುತ್ತದೆ, ಹಳೆಯ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `swap` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Acquire`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಮೌಲ್ಯವನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಮೆಮೊರಿ ಸ್ಥಳದಲ್ಲಿ ಸಂಗ್ರಹಿಸುತ್ತದೆ, ಹಳೆಯ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `swap` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Release`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಮೌಲ್ಯವನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಮೆಮೊರಿ ಸ್ಥಳದಲ್ಲಿ ಸಂಗ್ರಹಿಸುತ್ತದೆ, ಹಳೆಯ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `swap` ವಿಧಾನದ ಮೂಲಕ [`Ordering::AcqRel`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಮೌಲ್ಯವನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಮೆಮೊರಿ ಸ್ಥಳದಲ್ಲಿ ಸಂಗ್ರಹಿಸುತ್ತದೆ, ಹಳೆಯ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `swap` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Relaxed`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯಕ್ಕೆ ಸೇರಿಸುತ್ತದೆ, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_add` ವಿಧಾನದ ಮೂಲಕ [`Ordering::SeqCst`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯಕ್ಕೆ ಸೇರಿಸುತ್ತದೆ, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_add` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Acquire`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯಕ್ಕೆ ಸೇರಿಸುತ್ತದೆ, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_add` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Release`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯಕ್ಕೆ ಸೇರಿಸುತ್ತದೆ, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_add` ವಿಧಾನದ ಮೂಲಕ [`Ordering::AcqRel`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯಕ್ಕೆ ಸೇರಿಸುತ್ತದೆ, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_add` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Relaxed`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದಿಂದ ಕಳೆಯಿರಿ, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_sub` ವಿಧಾನದ ಮೂಲಕ [`Ordering::SeqCst`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದಿಂದ ಕಳೆಯಿರಿ, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_sub` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Acquire`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದಿಂದ ಕಳೆಯಿರಿ, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_sub` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Release`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದಿಂದ ಕಳೆಯಿರಿ, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_sub` ವಿಧಾನದ ಮೂಲಕ [`Ordering::AcqRel`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದಿಂದ ಕಳೆಯಿರಿ, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_sub` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Relaxed`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ಬಿಟ್ವೈಸ್ ಮತ್ತು ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_and` ವಿಧಾನದ ಮೂಲಕ [`Ordering::SeqCst`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಬಿಟ್ವೈಸ್ ಮತ್ತು ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_and` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Acquire`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಬಿಟ್ವೈಸ್ ಮತ್ತು ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_and` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Release`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಬಿಟ್ವೈಸ್ ಮತ್ತು ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_and` ವಿಧಾನದ ಮೂಲಕ [`Ordering::AcqRel`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಬಿಟ್ವೈಸ್ ಮತ್ತು ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_and` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Relaxed`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಬಿಟ್ವೈಸ್ ನಂಡ್, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`AtomicBool`] ಪ್ರಕಾರದಲ್ಲಿ `fetch_nand` ವಿಧಾನದ ಮೂಲಕ [`AtomicBool`] ಪ್ರಕಾರದಲ್ಲಿ [`Ordering::SeqCst`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಬಿಟ್ವೈಸ್ ನಂಡ್, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`AtomicBool`] ಪ್ರಕಾರದಲ್ಲಿ `fetch_nand` ವಿಧಾನದ ಮೂಲಕ [`AtomicBool`] ಪ್ರಕಾರದಲ್ಲಿ [`Ordering::Acquire`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಬಿಟ್ವೈಸ್ ನಂಡ್, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`AtomicBool`] ಪ್ರಕಾರದಲ್ಲಿ `fetch_nand` ವಿಧಾನದ ಮೂಲಕ [`AtomicBool`] ಪ್ರಕಾರದಲ್ಲಿ [`Ordering::Release`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಬಿಟ್ವೈಸ್ ನಂಡ್, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`AtomicBool`] ಪ್ರಕಾರದಲ್ಲಿ `fetch_nand` ವಿಧಾನದ ಮೂಲಕ [`AtomicBool`] ಪ್ರಕಾರದಲ್ಲಿ [`Ordering::AcqRel`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಬಿಟ್ವೈಸ್ ನಂಡ್, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`AtomicBool`] ಪ್ರಕಾರದಲ್ಲಿ `fetch_nand` ವಿಧಾನದ ಮೂಲಕ [`AtomicBool`] ಪ್ರಕಾರದಲ್ಲಿ [`Ordering::Relaxed`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ಬಿಟ್ವೈಸ್ ಅಥವಾ ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_or` ವಿಧಾನದ ಮೂಲಕ [`Ordering::SeqCst`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಬಿಟ್ವೈಸ್ ಅಥವಾ ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_or` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Acquire`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಬಿಟ್ವೈಸ್ ಅಥವಾ ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_or` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Release`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಬಿಟ್ವೈಸ್ ಅಥವಾ ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_or` ವಿಧಾನದ ಮೂಲಕ [`Ordering::AcqRel`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಬಿಟ್ವೈಸ್ ಅಥವಾ ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_or` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Relaxed`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಬಿಟ್ವೈಸ್ xor, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_xor` ವಿಧಾನದ ಮೂಲಕ [`Ordering::SeqCst`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಬಿಟ್ವೈಸ್ xor, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_xor` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Acquire`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಬಿಟ್ವೈಸ್ xor, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_xor` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Release`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಬಿಟ್ವೈಸ್ xor, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_xor` ವಿಧಾನದ ಮೂಲಕ [`Ordering::AcqRel`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಬಿಟ್ವೈಸ್ xor, ಹಿಂದಿನ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_xor` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Relaxed`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic`] ಪ್ರಕಾರಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ಸಹಿ ಮಾಡಿದ ಹೋಲಿಕೆ ಬಳಸಿಕೊಂಡು ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಗರಿಷ್ಠ.
    ///
    /// ಈ ಆಂತರಿಕತೆಯ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`atomic`] ಸಹಿ ಮಾಡಿದ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_max` ವಿಧಾನದ ಮೂಲಕ [`Ordering::SeqCst`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಸಹಿ ಮಾಡಿದ ಹೋಲಿಕೆ ಬಳಸಿಕೊಂಡು ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಗರಿಷ್ಠ.
    ///
    /// ಈ ಆಂತರಿಕತೆಯ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`atomic`] ಸಹಿ ಮಾಡಿದ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_max` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Acquire`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಸಹಿ ಮಾಡಿದ ಹೋಲಿಕೆ ಬಳಸಿಕೊಂಡು ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಗರಿಷ್ಠ.
    ///
    /// ಈ ಆಂತರಿಕತೆಯ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`atomic`] ಸಹಿ ಮಾಡಿದ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_max` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Release`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಸಹಿ ಮಾಡಿದ ಹೋಲಿಕೆ ಬಳಸಿಕೊಂಡು ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಗರಿಷ್ಠ.
    ///
    /// ಈ ಆಂತರಿಕತೆಯ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`atomic`] ಸಹಿ ಮಾಡಿದ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_max` ವಿಧಾನದ ಮೂಲಕ [`Ordering::AcqRel`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಗರಿಷ್ಠ.
    ///
    /// ಈ ಆಂತರಿಕತೆಯ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`atomic`] ಸಹಿ ಮಾಡಿದ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_max` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Relaxed`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ಸಹಿ ಮಾಡಿದ ಹೋಲಿಕೆ ಬಳಸಿಕೊಂಡು ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಕನಿಷ್ಠ.
    ///
    /// ಈ ಆಂತರಿಕತೆಯ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`atomic`] ಸಹಿ ಮಾಡಿದ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_min` ವಿಧಾನದ ಮೂಲಕ [`Ordering::SeqCst`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಸಹಿ ಮಾಡಿದ ಹೋಲಿಕೆ ಬಳಸಿಕೊಂಡು ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಕನಿಷ್ಠ.
    ///
    /// ಈ ಆಂತರಿಕತೆಯ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`atomic`] ಸಹಿ ಮಾಡಿದ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_min` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Acquire`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಸಹಿ ಮಾಡಿದ ಹೋಲಿಕೆ ಬಳಸಿಕೊಂಡು ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಕನಿಷ್ಠ.
    ///
    /// ಈ ಆಂತರಿಕತೆಯ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`atomic`] ಸಹಿ ಮಾಡಿದ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_min` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Release`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಸಹಿ ಮಾಡಿದ ಹೋಲಿಕೆ ಬಳಸಿಕೊಂಡು ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಕನಿಷ್ಠ.
    ///
    /// ಈ ಆಂತರಿಕತೆಯ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`atomic`] ಸಹಿ ಮಾಡಿದ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_min` ವಿಧಾನದ ಮೂಲಕ [`Ordering::AcqRel`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಸಹಿ ಮಾಡಿದ ಹೋಲಿಕೆ ಬಳಸಿಕೊಂಡು ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಕನಿಷ್ಠ.
    ///
    /// ಈ ಆಂತರಿಕತೆಯ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`atomic`] ಸಹಿ ಮಾಡಿದ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_min` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Relaxed`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ಸಹಿ ಮಾಡದ ಹೋಲಿಕೆ ಬಳಸಿಕೊಂಡು ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಕನಿಷ್ಠ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಸಹಿ ಮಾಡದ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_min` ವಿಧಾನದ ಮೂಲಕ [`Ordering::SeqCst`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಸಹಿ ಮಾಡದ ಹೋಲಿಕೆ ಬಳಸಿಕೊಂಡು ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಕನಿಷ್ಠ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಸಹಿ ಮಾಡದ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_min` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Acquire`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಸಹಿ ಮಾಡದ ಹೋಲಿಕೆ ಬಳಸಿಕೊಂಡು ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಕನಿಷ್ಠ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಸಹಿ ಮಾಡದ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_min` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Release`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಸಹಿ ಮಾಡದ ಹೋಲಿಕೆ ಬಳಸಿಕೊಂಡು ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಕನಿಷ್ಠ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಸಹಿ ಮಾಡದ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_min` ವಿಧಾನದ ಮೂಲಕ [`Ordering::AcqRel`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಸಹಿ ಮಾಡದ ಹೋಲಿಕೆ ಬಳಸಿಕೊಂಡು ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಕನಿಷ್ಠ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಸಹಿ ಮಾಡದ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_min` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Relaxed`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ಸಹಿ ಮಾಡದ ಹೋಲಿಕೆ ಬಳಸಿಕೊಂಡು ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಗರಿಷ್ಠ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಸಹಿ ಮಾಡದ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_max` ವಿಧಾನದ ಮೂಲಕ [`Ordering::SeqCst`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಸಹಿ ಮಾಡದ ಹೋಲಿಕೆ ಬಳಸಿಕೊಂಡು ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಗರಿಷ್ಠ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಸಹಿ ಮಾಡದ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_max` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Acquire`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಸಹಿ ಮಾಡದ ಹೋಲಿಕೆ ಬಳಸಿಕೊಂಡು ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಗರಿಷ್ಠ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಸಹಿ ಮಾಡದ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_max` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Release`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಸಹಿ ಮಾಡದ ಹೋಲಿಕೆ ಬಳಸಿಕೊಂಡು ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಗರಿಷ್ಠ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಸಹಿ ಮಾಡದ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_max` ವಿಧಾನದ ಮೂಲಕ [`Ordering::AcqRel`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ಸಹಿ ಮಾಡದ ಹೋಲಿಕೆ ಬಳಸಿಕೊಂಡು ಪ್ರಸ್ತುತ ಮೌಲ್ಯದೊಂದಿಗೆ ಗರಿಷ್ಠ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಯು [`atomic`] ಸಹಿ ಮಾಡದ ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರಗಳಲ್ಲಿ `fetch_max` ವಿಧಾನದ ಮೂಲಕ [`Ordering::Relaxed`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` ಆಂತರಿಕವು ಬೆಂಬಲಿಸಿದರೆ ಪೂರ್ವಭಾವಿ ಸೂಚನೆಯನ್ನು ಸೇರಿಸಲು ಕೋಡ್ ಜನರೇಟರ್ಗೆ ಸುಳಿವು;ಇಲ್ಲದಿದ್ದರೆ, ಇದು ಯಾವುದೇ ಆಪ್ ಅಲ್ಲ.
    /// ಪೂರ್ವಭಾವಿಗಳು ಕಾರ್ಯಕ್ರಮದ ನಡವಳಿಕೆಯ ಮೇಲೆ ಯಾವುದೇ ಪರಿಣಾಮ ಬೀರುವುದಿಲ್ಲ ಆದರೆ ಅದರ ಕಾರ್ಯಕ್ಷಮತೆಯ ಗುಣಲಕ್ಷಣಗಳನ್ನು ಬದಲಾಯಿಸಬಹುದು.
    ///
    /// `locality` ಆರ್ಗ್ಯುಮೆಂಟ್ ಸ್ಥಿರವಾದ ಪೂರ್ಣಾಂಕವಾಗಿರಬೇಕು ಮತ್ತು ಇದು (0) ನಿಂದ ಯಾವುದೇ ಸ್ಥಳವಿಲ್ಲ, (3) ವರೆಗಿನ ತಾತ್ಕಾಲಿಕ ಸ್ಥಳ ನಿರ್ದಿಷ್ಟತೆಯಾಗಿದೆ, ಅತ್ಯಂತ ಸ್ಥಳೀಯ ಸಂಗ್ರಹದಲ್ಲಿರುತ್ತದೆ.
    ///
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` ಆಂತರಿಕವು ಬೆಂಬಲಿಸಿದರೆ ಪೂರ್ವಭಾವಿ ಸೂಚನೆಯನ್ನು ಸೇರಿಸಲು ಕೋಡ್ ಜನರೇಟರ್ಗೆ ಸುಳಿವು;ಇಲ್ಲದಿದ್ದರೆ, ಇದು ಯಾವುದೇ ಆಪ್ ಅಲ್ಲ.
    /// ಪೂರ್ವಭಾವಿಗಳು ಕಾರ್ಯಕ್ರಮದ ನಡವಳಿಕೆಯ ಮೇಲೆ ಯಾವುದೇ ಪರಿಣಾಮ ಬೀರುವುದಿಲ್ಲ ಆದರೆ ಅದರ ಕಾರ್ಯಕ್ಷಮತೆಯ ಗುಣಲಕ್ಷಣಗಳನ್ನು ಬದಲಾಯಿಸಬಹುದು.
    ///
    /// `locality` ಆರ್ಗ್ಯುಮೆಂಟ್ ಸ್ಥಿರವಾದ ಪೂರ್ಣಾಂಕವಾಗಿರಬೇಕು ಮತ್ತು ಇದು (0) ನಿಂದ ಯಾವುದೇ ಸ್ಥಳವಿಲ್ಲ, (3) ವರೆಗಿನ ತಾತ್ಕಾಲಿಕ ಸ್ಥಳ ನಿರ್ದಿಷ್ಟತೆಯಾಗಿದೆ, ಅತ್ಯಂತ ಸ್ಥಳೀಯ ಸಂಗ್ರಹದಲ್ಲಿರುತ್ತದೆ.
    ///
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` ಆಂತರಿಕವು ಬೆಂಬಲಿಸಿದರೆ ಪೂರ್ವಭಾವಿ ಸೂಚನೆಯನ್ನು ಸೇರಿಸಲು ಕೋಡ್ ಜನರೇಟರ್ಗೆ ಸುಳಿವು;ಇಲ್ಲದಿದ್ದರೆ, ಇದು ಯಾವುದೇ ಆಪ್ ಅಲ್ಲ.
    /// ಪೂರ್ವಭಾವಿಗಳು ಕಾರ್ಯಕ್ರಮದ ನಡವಳಿಕೆಯ ಮೇಲೆ ಯಾವುದೇ ಪರಿಣಾಮ ಬೀರುವುದಿಲ್ಲ ಆದರೆ ಅದರ ಕಾರ್ಯಕ್ಷಮತೆಯ ಗುಣಲಕ್ಷಣಗಳನ್ನು ಬದಲಾಯಿಸಬಹುದು.
    ///
    /// `locality` ಆರ್ಗ್ಯುಮೆಂಟ್ ಸ್ಥಿರವಾದ ಪೂರ್ಣಾಂಕವಾಗಿರಬೇಕು ಮತ್ತು ಇದು (0) ನಿಂದ ಯಾವುದೇ ಸ್ಥಳವಿಲ್ಲ, (3) ವರೆಗಿನ ತಾತ್ಕಾಲಿಕ ಸ್ಥಳ ನಿರ್ದಿಷ್ಟತೆಯಾಗಿದೆ, ಅತ್ಯಂತ ಸ್ಥಳೀಯ ಸಂಗ್ರಹದಲ್ಲಿರುತ್ತದೆ.
    ///
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` ಆಂತರಿಕವು ಬೆಂಬಲಿಸಿದರೆ ಪೂರ್ವಭಾವಿ ಸೂಚನೆಯನ್ನು ಸೇರಿಸಲು ಕೋಡ್ ಜನರೇಟರ್ಗೆ ಸುಳಿವು;ಇಲ್ಲದಿದ್ದರೆ, ಇದು ಯಾವುದೇ ಆಪ್ ಅಲ್ಲ.
    /// ಪೂರ್ವಭಾವಿಗಳು ಕಾರ್ಯಕ್ರಮದ ನಡವಳಿಕೆಯ ಮೇಲೆ ಯಾವುದೇ ಪರಿಣಾಮ ಬೀರುವುದಿಲ್ಲ ಆದರೆ ಅದರ ಕಾರ್ಯಕ್ಷಮತೆಯ ಗುಣಲಕ್ಷಣಗಳನ್ನು ಬದಲಾಯಿಸಬಹುದು.
    ///
    /// `locality` ಆರ್ಗ್ಯುಮೆಂಟ್ ಸ್ಥಿರವಾದ ಪೂರ್ಣಾಂಕವಾಗಿರಬೇಕು ಮತ್ತು ಇದು (0) ನಿಂದ ಯಾವುದೇ ಸ್ಥಳವಿಲ್ಲ, (3) ವರೆಗಿನ ತಾತ್ಕಾಲಿಕ ಸ್ಥಳ ನಿರ್ದಿಷ್ಟತೆಯಾಗಿದೆ, ಅತ್ಯಂತ ಸ್ಥಳೀಯ ಸಂಗ್ರಹದಲ್ಲಿರುತ್ತದೆ.
    ///
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// ಪರಮಾಣು ಬೇಲಿ.
    ///
    /// ಈ ಆಂತರಿಕತೆಯ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`Ordering::SeqCst`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic::fence`] ನಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    ///
    ///
    pub fn atomic_fence();
    /// ಪರಮಾಣು ಬೇಲಿ.
    ///
    /// ಈ ಆಂತರಿಕತೆಯ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`Ordering::Acquire`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic::fence`] ನಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    ///
    ///
    pub fn atomic_fence_acq();
    /// ಪರಮಾಣು ಬೇಲಿ.
    ///
    /// ಈ ಆಂತರಿಕತೆಯ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`Ordering::Release`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic::fence`] ನಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    ///
    ///
    pub fn atomic_fence_rel();
    /// ಪರಮಾಣು ಬೇಲಿ.
    ///
    /// ಈ ಆಂತರಿಕತೆಯ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`Ordering::AcqRel`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic::fence`] ನಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// ಕಂಪೈಲರ್-ಮಾತ್ರ ಮೆಮೊರಿ ತಡೆ.
    ///
    /// ಕಂಪೈಲರ್ ಈ ತಡೆಗೋಡೆಗೆ ಮೆಮೊರಿ ಪ್ರವೇಶಗಳನ್ನು ಎಂದಿಗೂ ಮರುಕ್ರಮಗೊಳಿಸುವುದಿಲ್ಲ, ಆದರೆ ಅದಕ್ಕಾಗಿ ಯಾವುದೇ ಸೂಚನೆಗಳನ್ನು ಹೊರಸೂಸಲಾಗುವುದಿಲ್ಲ.
    /// ಸಿಗ್ನಲ್ ಹ್ಯಾಂಡ್ಲರ್‌ಗಳೊಂದಿಗೆ ಸಂವಹನ ನಡೆಸುವಾಗ ಪೂರ್ವಭಾವಿಯಾಗಿರುವ ಅದೇ ಥ್ರೆಡ್‌ನಲ್ಲಿನ ಕಾರ್ಯಾಚರಣೆಗಳಿಗೆ ಇದು ಸೂಕ್ತವಾಗಿದೆ.
    ///
    /// ಈ ಆಂತರಿಕತೆಯ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`Ordering::SeqCst`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic::compiler_fence`] ನಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// ಕಂಪೈಲರ್-ಮಾತ್ರ ಮೆಮೊರಿ ತಡೆ.
    ///
    /// ಕಂಪೈಲರ್ ಈ ತಡೆಗೋಡೆಗೆ ಮೆಮೊರಿ ಪ್ರವೇಶಗಳನ್ನು ಎಂದಿಗೂ ಮರುಕ್ರಮಗೊಳಿಸುವುದಿಲ್ಲ, ಆದರೆ ಅದಕ್ಕಾಗಿ ಯಾವುದೇ ಸೂಚನೆಗಳನ್ನು ಹೊರಸೂಸಲಾಗುವುದಿಲ್ಲ.
    /// ಸಿಗ್ನಲ್ ಹ್ಯಾಂಡ್ಲರ್‌ಗಳೊಂದಿಗೆ ಸಂವಹನ ನಡೆಸುವಾಗ ಪೂರ್ವಭಾವಿಯಾಗಿರುವ ಅದೇ ಥ್ರೆಡ್‌ನಲ್ಲಿನ ಕಾರ್ಯಾಚರಣೆಗಳಿಗೆ ಇದು ಸೂಕ್ತವಾಗಿದೆ.
    ///
    /// ಈ ಆಂತರಿಕತೆಯ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`Ordering::Acquire`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic::compiler_fence`] ನಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// ಕಂಪೈಲರ್-ಮಾತ್ರ ಮೆಮೊರಿ ತಡೆ.
    ///
    /// ಕಂಪೈಲರ್ ಈ ತಡೆಗೋಡೆಗೆ ಮೆಮೊರಿ ಪ್ರವೇಶಗಳನ್ನು ಎಂದಿಗೂ ಮರುಕ್ರಮಗೊಳಿಸುವುದಿಲ್ಲ, ಆದರೆ ಅದಕ್ಕಾಗಿ ಯಾವುದೇ ಸೂಚನೆಗಳನ್ನು ಹೊರಸೂಸಲಾಗುವುದಿಲ್ಲ.
    /// ಸಿಗ್ನಲ್ ಹ್ಯಾಂಡ್ಲರ್‌ಗಳೊಂದಿಗೆ ಸಂವಹನ ನಡೆಸುವಾಗ ಪೂರ್ವಭಾವಿಯಾಗಿರುವ ಅದೇ ಥ್ರೆಡ್‌ನಲ್ಲಿನ ಕಾರ್ಯಾಚರಣೆಗಳಿಗೆ ಇದು ಸೂಕ್ತವಾಗಿದೆ.
    ///
    /// ಈ ಆಂತರಿಕತೆಯ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`Ordering::Release`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic::compiler_fence`] ನಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// ಕಂಪೈಲರ್-ಮಾತ್ರ ಮೆಮೊರಿ ತಡೆ.
    ///
    /// ಕಂಪೈಲರ್ ಈ ತಡೆಗೋಡೆಗೆ ಮೆಮೊರಿ ಪ್ರವೇಶಗಳನ್ನು ಎಂದಿಗೂ ಮರುಕ್ರಮಗೊಳಿಸುವುದಿಲ್ಲ, ಆದರೆ ಅದಕ್ಕಾಗಿ ಯಾವುದೇ ಸೂಚನೆಗಳನ್ನು ಹೊರಸೂಸಲಾಗುವುದಿಲ್ಲ.
    /// ಸಿಗ್ನಲ್ ಹ್ಯಾಂಡ್ಲರ್‌ಗಳೊಂದಿಗೆ ಸಂವಹನ ನಡೆಸುವಾಗ ಪೂರ್ವಭಾವಿಯಾಗಿರುವ ಅದೇ ಥ್ರೆಡ್‌ನಲ್ಲಿನ ಕಾರ್ಯಾಚರಣೆಗಳಿಗೆ ಇದು ಸೂಕ್ತವಾಗಿದೆ.
    ///
    /// ಈ ಆಂತರಿಕತೆಯ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`Ordering::AcqRel`] ಅನ್ನು `order` ಆಗಿ ಹಾದುಹೋಗುವ ಮೂಲಕ [`atomic::compiler_fence`] ನಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// ಕಾರ್ಯಕ್ಕೆ ಜೋಡಿಸಲಾದ ಗುಣಲಕ್ಷಣಗಳಿಂದ ಅದರ ಅರ್ಥವನ್ನು ಪಡೆಯುವ ಮ್ಯಾಜಿಕ್ ಆಂತರಿಕ.
    ///
    /// ಉದಾಹರಣೆಗೆ, ಸ್ಥಿರವಾದ ಪ್ರತಿಪಾದನೆಗಳನ್ನು ಚುಚ್ಚುಮದ್ದು ಮಾಡಲು ಡಾಟಾಫ್ಲೋ ಇದನ್ನು ಬಳಸುತ್ತದೆ, ಇದರಿಂದಾಗಿ ನಿಯಂತ್ರಣ ಹರಿವಿನಲ್ಲಿ ಆ ಸಮಯದಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುವುದಿಲ್ಲ ಎಂದು ಡೇಟಾ ಫ್ಲೋ ವಾಸ್ತವವಾಗಿ ಲೆಕ್ಕಾಚಾರ ಮಾಡಿದೆ ಎಂದು `rustc_peek(potentially_uninitialized)` ಎರಡು ಬಾರಿ ಪರಿಶೀಲಿಸುತ್ತದೆ.
    ///
    ///
    /// ಈ ಆಂತರಿಕವನ್ನು ಕಂಪೈಲರ್ ಹೊರಗೆ ಬಳಸಬಾರದು.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// ಪ್ರಕ್ರಿಯೆಯ ಮರಣದಂಡನೆಯನ್ನು ಸ್ಥಗಿತಗೊಳಿಸುತ್ತದೆ.
    ///
    /// ಈ ಕಾರ್ಯಾಚರಣೆಯ ಹೆಚ್ಚು ಬಳಕೆದಾರ ಸ್ನೇಹಿ ಮತ್ತು ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`std::process::abort`](../../std/process/fn.abort.html) ಆಗಿದೆ.
    ///
    pub fn abort() -> !;

    /// ಕೋಡ್‌ನಲ್ಲಿನ ಈ ಹಂತವನ್ನು ತಲುಪಲಾಗುವುದಿಲ್ಲ ಎಂದು ಆಪ್ಟಿಮೈಜರ್‌ಗೆ ತಿಳಿಸುತ್ತದೆ, ಇದು ಮತ್ತಷ್ಟು ಆಪ್ಟಿಮೈಸೇಷನ್‌ಗಳನ್ನು ಸಕ್ರಿಯಗೊಳಿಸುತ್ತದೆ.
    ///
    /// NB, ಇದು `unreachable!()` ಮ್ಯಾಕ್ರೊಗಿಂತ ಬಹಳ ಭಿನ್ನವಾಗಿದೆ: panics ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದಾಗ ಮ್ಯಾಕ್ರೋಗಿಂತ ಭಿನ್ನವಾಗಿ, ಈ ಕಾರ್ಯದೊಂದಿಗೆ ಗುರುತಿಸಲಾದ ಕೋಡ್ ಅನ್ನು ತಲುಪುವುದು *ವಿವರಿಸಲಾಗದ ನಡವಳಿಕೆ*.
    ///
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked) ಆಗಿದೆ.
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// ಸ್ಥಿತಿಯು ಯಾವಾಗಲೂ ನಿಜ ಎಂದು ಆಪ್ಟಿಮೈಜರ್‌ಗೆ ತಿಳಿಸುತ್ತದೆ.
    /// ಷರತ್ತು ತಪ್ಪಾಗಿದ್ದರೆ, ನಡವಳಿಕೆಯನ್ನು ವಿವರಿಸಲಾಗುವುದಿಲ್ಲ.
    ///
    /// ಈ ಆಂತರಿಕಕ್ಕಾಗಿ ಯಾವುದೇ ಕೋಡ್ ಅನ್ನು ರಚಿಸಲಾಗುವುದಿಲ್ಲ, ಆದರೆ ಆಪ್ಟಿಮೈಜರ್ ಅದನ್ನು ಪಾಸ್ಗಳ ನಡುವೆ (ಮತ್ತು ಅದರ ಸ್ಥಿತಿಯನ್ನು) ಸಂರಕ್ಷಿಸಲು ಪ್ರಯತ್ನಿಸುತ್ತದೆ, ಇದು ಸುತ್ತಮುತ್ತಲಿನ ಕೋಡ್‌ನ ಆಪ್ಟಿಮೈಸೇಶನ್‌ನಲ್ಲಿ ಹಸ್ತಕ್ಷೇಪ ಮಾಡುತ್ತದೆ ಮತ್ತು ಕಾರ್ಯಕ್ಷಮತೆಯನ್ನು ಕಡಿಮೆ ಮಾಡುತ್ತದೆ.
    /// ಅಸ್ಥಿರತೆಯನ್ನು ಆಪ್ಟಿಮೈಜರ್ ತನ್ನದೇ ಆದ ಮೇಲೆ ಕಂಡುಹಿಡಿಯಬಹುದೇ ಅಥವಾ ಯಾವುದೇ ಮಹತ್ವದ ಆಪ್ಟಿಮೈಸೇಶನ್‌ಗಳನ್ನು ಸಕ್ರಿಯಗೊಳಿಸದಿದ್ದರೆ ಅದನ್ನು ಬಳಸಬಾರದು.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// branch ಸ್ಥಿತಿಯು ನಿಜವೆಂದು ಕಂಪೈಲರ್‌ಗೆ ಸುಳಿವು.
    /// ಅದಕ್ಕೆ ರವಾನಿಸಿದ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `if` ಹೇಳಿಕೆಗಳನ್ನು ಹೊರತುಪಡಿಸಿ ಯಾವುದೇ ಬಳಕೆ ಬಹುಶಃ ಪರಿಣಾಮ ಬೀರುವುದಿಲ್ಲ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// branch ಸ್ಥಿತಿಯು ಸುಳ್ಳಾಗಿರಬಹುದು ಎಂದು ಕಂಪೈಲರ್‌ಗೆ ಸುಳಿವು.
    /// ಅದಕ್ಕೆ ರವಾನಿಸಿದ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// `if` ಹೇಳಿಕೆಗಳನ್ನು ಹೊರತುಪಡಿಸಿ ಯಾವುದೇ ಬಳಕೆ ಬಹುಶಃ ಪರಿಣಾಮ ಬೀರುವುದಿಲ್ಲ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// ಡೀಬಗರ್ ಪರಿಶೀಲನೆಗಾಗಿ ಬ್ರೇಕ್‌ಪಾಯಿಂಟ್ ಬಲೆಗೆ ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    pub fn breakpoint();

    /// ಬೈಟ್‌ಗಳಲ್ಲಿ ಒಂದು ಪ್ರಕಾರದ ಗಾತ್ರ.
    ///
    /// ಹೆಚ್ಚು ನಿರ್ದಿಷ್ಟವಾಗಿ ಹೇಳುವುದಾದರೆ, ಜೋಡಣೆ ಪ್ಯಾಡಿಂಗ್ ಸೇರಿದಂತೆ ಒಂದೇ ಪ್ರಕಾರದ ಅನುಕ್ರಮ ವಸ್ತುಗಳ ನಡುವೆ ಬೈಟ್‌ಗಳಲ್ಲಿ ಇದು ಆಫ್‌ಸೆಟ್ ಆಗಿದೆ.
    ///
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`core::mem::size_of`](crate::mem::size_of) ಆಗಿದೆ.
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// ಒಂದು ಪ್ರಕಾರದ ಕನಿಷ್ಠ ಜೋಡಣೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`core::mem::align_of`](crate::mem::align_of) ಆಗಿದೆ.
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// ಒಂದು ಪ್ರಕಾರದ ಆದ್ಯತೆಯ ಜೋಡಣೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// ಬೈಟ್‌ಗಳಲ್ಲಿ ಉಲ್ಲೇಖಿಸಲಾದ ಮೌಲ್ಯದ ಗಾತ್ರ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`mem::size_of_val`] ಆಗಿದೆ.
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// ಉಲ್ಲೇಖಿತ ಮೌಲ್ಯದ ಅಗತ್ಯ ಜೋಡಣೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`core::mem::align_of_val`](crate::mem::align_of_val) ಆಗಿದೆ.
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// ಒಂದು ಪ್ರಕಾರದ ಹೆಸರನ್ನು ಹೊಂದಿರುವ ಸ್ಥಿರ ಸ್ಟ್ರಿಂಗ್ ಸ್ಲೈಸ್ ಪಡೆಯುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`core::any::type_name`](crate::any::type_name) ಆಗಿದೆ.
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// ನಿರ್ದಿಷ್ಟಪಡಿಸಿದ ಪ್ರಕಾರಕ್ಕೆ ಜಾಗತಿಕವಾಗಿ ವಿಶಿಷ್ಟವಾದ ಗುರುತಿಸುವಿಕೆಯನ್ನು ಪಡೆಯುತ್ತದೆ.
    /// ಈ ಕಾರ್ಯವು ಯಾವ ಪ್ರಕಾರದ crate ಅನ್ನು ಲೆಕ್ಕಿಸದೆ ಒಂದು ಪ್ರಕಾರಕ್ಕೆ ಅದೇ ಮೌಲ್ಯವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`core::any::TypeId::of`](crate::any::TypeId::of) ಆಗಿದೆ.
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// `T` ಜನವಸತಿ ಇಲ್ಲದಿದ್ದರೆ ಎಂದಿಗೂ ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗದ ಅಸುರಕ್ಷಿತ ಕಾರ್ಯಗಳಿಗಾಗಿ ಒಂದು ಸಿಬ್ಬಂದಿ:
    /// ಇದು ಸ್ಥಿರವಾಗಿ panic ಆಗುತ್ತದೆ, ಅಥವಾ ಏನನ್ನೂ ಮಾಡುವುದಿಲ್ಲ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// `T` ಶೂನ್ಯ-ಪ್ರಾರಂಭವನ್ನು ಅನುಮತಿಸದಿದ್ದರೆ ಎಂದಿಗೂ ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗದ ಅಸುರಕ್ಷಿತ ಕಾರ್ಯಗಳಿಗಾಗಿ ಒಂದು ಸಿಬ್ಬಂದಿ: ಇದು ಸ್ಥಿರವಾಗಿ panic ಅನ್ನು ಮಾಡುತ್ತದೆ ಅಥವಾ ಏನನ್ನೂ ಮಾಡುವುದಿಲ್ಲ.
    ///
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    pub fn assert_zero_valid<T>();

    /// `T` ಅಮಾನ್ಯ ಬಿಟ್ ಮಾದರಿಗಳನ್ನು ಹೊಂದಿದ್ದರೆ ಎಂದಿಗೂ ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗದ ಅಸುರಕ್ಷಿತ ಕಾರ್ಯಗಳಿಗಾಗಿ ಒಂದು ಸಿಬ್ಬಂದಿ: ಇದು ಸ್ಥಿರವಾಗಿ panic ಅನ್ನು ಮಾಡುತ್ತದೆ ಅಥವಾ ಏನನ್ನೂ ಮಾಡುವುದಿಲ್ಲ.
    ///
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    pub fn assert_uninit_valid<T>();

    /// ಸ್ಥಿರ `Location` ಅನ್ನು ಎಲ್ಲಿ ಕರೆಯಲಾಗಿದೆ ಎಂದು ಸೂಚಿಸುವ ಉಲ್ಲೇಖವನ್ನು ಪಡೆಯುತ್ತದೆ.
    ///
    /// ಬದಲಿಗೆ [`core::panic::Location::caller`](crate::panic::Location::caller) ಬಳಸುವುದನ್ನು ಪರಿಗಣಿಸಿ.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// ಡ್ರಾಪ್ ಅಂಟು ಚಲಾಯಿಸದೆ ಮೌಲ್ಯವನ್ನು ವ್ಯಾಪ್ತಿಯಿಂದ ಸರಿಸುತ್ತದೆ.
    ///
    /// ಇದು ಕೇವಲ [`mem::forget_unsized`] ಗೆ ಅಸ್ತಿತ್ವದಲ್ಲಿದೆ;ಸಾಮಾನ್ಯ `forget` ಬದಲಿಗೆ `ManuallyDrop` ಅನ್ನು ಬಳಸುತ್ತದೆ.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// ಒಂದು ಪ್ರಕಾರದ ಮೌಲ್ಯದ ಬಿಟ್‌ಗಳನ್ನು ಮತ್ತೊಂದು ಪ್ರಕಾರವಾಗಿ ಮರು ವ್ಯಾಖ್ಯಾನಿಸುತ್ತದೆ.
    ///
    /// ಎರಡೂ ವಿಧಗಳು ಒಂದೇ ಗಾತ್ರವನ್ನು ಹೊಂದಿರಬೇಕು.
    /// ಮೂಲವಾಗಲಿ, ಫಲಿತಾಂಶವಾಗಲಿ [invalid value](../../nomicon/what-unsafe-does.html) ಆಗಿರಬಾರದು.
    ///
    /// `transmute` ಶಬ್ದಾರ್ಥವಾಗಿ ಒಂದು ಪ್ರಕಾರದ ಬಿಟ್‌ವೈಸ್ ಚಲಿಸುವಿಕೆಗೆ ಸಮನಾಗಿರುತ್ತದೆ.ಇದು ಮೂಲ ಮೌಲ್ಯದಿಂದ ಬಿಟ್‌ಗಳನ್ನು ಗಮ್ಯಸ್ಥಾನ ಮೌಲ್ಯಕ್ಕೆ ನಕಲಿಸುತ್ತದೆ, ನಂತರ ಮೂಲವನ್ನು ಮರೆತುಬಿಡುತ್ತದೆ.
    /// ಇದು `transmute_copy` ನಂತೆಯೇ ಹುಡ್ ಅಡಿಯಲ್ಲಿ C ನ `memcpy` ಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ.
    ///
    /// `transmute` ಒಂದು ಉಪ-ಮೌಲ್ಯದ ಕಾರ್ಯಾಚರಣೆಯಾಗಿರುವುದರಿಂದ,*ರೂಪಾಂತರಗೊಂಡ ಮೌಲ್ಯಗಳ ಜೋಡಣೆ* ಒಂದು ಕಾಳಜಿಯಲ್ಲ.
    /// ಇತರ ಯಾವುದೇ ಕಾರ್ಯದಂತೆ, ಕಂಪೈಲರ್ ಈಗಾಗಲೇ `T` ಮತ್ತು `U` ಎರಡನ್ನೂ ಸರಿಯಾಗಿ ಜೋಡಿಸಲಾಗಿದೆ ಎಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ.
    /// ಆದಾಗ್ಯೂ, * ಬೇರೆಡೆ ಸೂಚಿಸುವ ಮೌಲ್ಯಗಳನ್ನು (ಪಾಯಿಂಟರ್‌ಗಳು, ಉಲ್ಲೇಖಗಳು, ಪೆಟ್ಟಿಗೆಗಳು…) ರವಾನಿಸುವಾಗ, ಕರೆ ಮಾಡಿದವರು ಸೂಚಿಸಿದ ಮೌಲ್ಯಗಳಿಗೆ ಸರಿಯಾದ ಜೋಡಣೆಯನ್ನು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು.
    ///
    /// `transmute` **ನಂಬಲಾಗದಷ್ಟು** ಅಸುರಕ್ಷಿತವಾಗಿದೆ.ಈ ಕಾರ್ಯದೊಂದಿಗೆ [undefined behavior][ub] ಗೆ ಕಾರಣವಾಗುವ ಅಪಾರ ಸಂಖ್ಯೆಯ ಮಾರ್ಗಗಳಿವೆ.`transmute` ಸಂಪೂರ್ಣ ಕೊನೆಯ ಉಪಾಯವಾಗಿರಬೇಕು.
    ///
    /// [nomicon](../../nomicon/transmutes.html) ಹೆಚ್ಚುವರಿ ದಸ್ತಾವೇಜನ್ನು ಹೊಂದಿದೆ.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// `transmute` ನಿಜವಾಗಿಯೂ ಉಪಯುಕ್ತವಾದ ಕೆಲವು ವಿಷಯಗಳಿವೆ.
    ///
    /// ಪಾಯಿಂಟರ್ ಅನ್ನು ಫಂಕ್ಷನ್ ಪಾಯಿಂಟರ್ ಆಗಿ ಪರಿವರ್ತಿಸುವುದು.ಫಂಕ್ಷನ್ ಪಾಯಿಂಟರ್‌ಗಳು ಮತ್ತು ಡೇಟಾ ಪಾಯಿಂಟರ್‌ಗಳು ವಿಭಿನ್ನ ಗಾತ್ರಗಳನ್ನು ಹೊಂದಿರುವ ಯಂತ್ರಗಳಿಗೆ ಇದು * ಪೋರ್ಟಬಲ್ ಅಲ್ಲ.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// ಜೀವಿತಾವಧಿಯನ್ನು ವಿಸ್ತರಿಸುವುದು, ಅಥವಾ ಅಸ್ಥಿರ ಜೀವಿತಾವಧಿಯನ್ನು ಕಡಿಮೆ ಮಾಡುವುದು.ಇದು ಸುಧಾರಿತ, ತುಂಬಾ ಅಸುರಕ್ಷಿತ Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// ನಿರಾಶೆಗೊಳ್ಳಬೇಡಿ: `transmute` ನ ಅನೇಕ ಉಪಯೋಗಗಳನ್ನು ಇತರ ವಿಧಾನಗಳ ಮೂಲಕ ಸಾಧಿಸಬಹುದು.
    /// `transmute` ನ ಸಾಮಾನ್ಯ ಅಪ್ಲಿಕೇಶನ್‌ಗಳನ್ನು ಕೆಳಗೆ ನೀಡಲಾಗಿದೆ, ಅದನ್ನು ಸುರಕ್ಷಿತ ರಚನೆಗಳೊಂದಿಗೆ ಬದಲಾಯಿಸಬಹುದು.
    ///
    /// ಕಚ್ಚಾ bytes(`&[u8]`) ಅನ್ನು `u32`, `f64`, ಇತ್ಯಾದಿಗಳಿಗೆ ತಿರುಗಿಸುವುದು:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // ಬದಲಿಗೆ `u32::from_ne_bytes` ಬಳಸಿ
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // ಅಥವಾ ಅಂತ್ಯವನ್ನು ಸೂಚಿಸಲು `u32::from_le_bytes` ಅಥವಾ `u32::from_be_bytes` ಬಳಸಿ
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// ಪಾಯಿಂಟರ್ ಅನ್ನು `usize` ಆಗಿ ಪರಿವರ್ತಿಸುವುದು:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // ಬದಲಿಗೆ `as` ಎರಕಹೊಯ್ದವನ್ನು ಬಳಸಿ
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// `*mut T` ಅನ್ನು `&mut T` ಆಗಿ ಪರಿವರ್ತಿಸುವುದು:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // ಬದಲಿಗೆ ರೆಬರೋ ಬಳಸಿ
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// `&mut T` ಅನ್ನು `&mut U` ಆಗಿ ಪರಿವರ್ತಿಸುವುದು:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // ಈಗ, `as` ಅನ್ನು ಒಟ್ಟಿಗೆ ಸೇರಿಸಿ ಮತ್ತು ಮರುಬಳಕೆ ಮಾಡಿ, `as` `as` ನ ಸರಪಳಿಯು ಅಸ್ಥಿರವಲ್ಲ ಎಂಬುದನ್ನು ಗಮನಿಸಿ
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// `&str` ಅನ್ನು `&[u8]` ಆಗಿ ಪರಿವರ್ತಿಸುವುದು:
    ///
    /// ```
    /// // ಇದನ್ನು ಮಾಡಲು ಇದು ಉತ್ತಮ ಮಾರ್ಗವಲ್ಲ.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // ನೀವು `str::as_bytes` ಅನ್ನು ಬಳಸಬಹುದು
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // ಅಥವಾ, ನೀವು ಅಕ್ಷರಶಃ ಸ್ಟ್ರಿಂಗ್ ಮೇಲೆ ನಿಯಂತ್ರಣ ಹೊಂದಿದ್ದರೆ ಬೈಟ್ ಸ್ಟ್ರಿಂಗ್ ಬಳಸಿ
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// `Vec<&T>` ಅನ್ನು `Vec<Option<&T>>` ಆಗಿ ಪರಿವರ್ತಿಸುವುದು.
    ///
    /// ಕಂಟೇನರ್‌ನ ಆಂತರಿಕ ಪ್ರಕಾರವನ್ನು ರವಾನಿಸಲು, ನೀವು ಕಂಟೇನರ್‌ನ ಯಾವುದೇ ಅಸ್ಥಿರತೆಯನ್ನು ಉಲ್ಲಂಘಿಸದಂತೆ ನೋಡಿಕೊಳ್ಳಬೇಕು.
    /// `Vec` ಗಾಗಿ, ಇದರರ್ಥ ಆಂತರಿಕ ಪ್ರಕಾರಗಳ ಗಾತ್ರ *ಮತ್ತು ಜೋಡಣೆ* ಎರಡೂ ಹೊಂದಿಕೆಯಾಗಬೇಕು.
    /// ಇತರ ಕಂಟೇನರ್‌ಗಳು ಪ್ರಕಾರ, ಜೋಡಣೆ, ಅಥವಾ `TypeId` ನ ಗಾತ್ರವನ್ನು ಅವಲಂಬಿಸಿರಬಹುದು, ಈ ಸಂದರ್ಭದಲ್ಲಿ ಕಂಟೇನರ್ ಅಸ್ಥಿರತೆಯನ್ನು ಉಲ್ಲಂಘಿಸದೆ ಪ್ರಸಾರ ಮಾಡುವುದು ಸಾಧ್ಯವಿಲ್ಲ.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // vector ಅನ್ನು ಕ್ಲೋನ್ ಮಾಡಿ ನಂತರ ನಾವು ಅವುಗಳನ್ನು ಮರುಬಳಕೆ ಮಾಡುತ್ತೇವೆ
    /// let v_clone = v_orig.clone();
    ///
    /// // ರೂಪಾಂತರವನ್ನು ಬಳಸುವುದು: ಇದು `Vec` ನ ಅನಿರ್ದಿಷ್ಟ ಡೇಟಾ ವಿನ್ಯಾಸವನ್ನು ಅವಲಂಬಿಸಿದೆ, ಇದು ಕೆಟ್ಟ ಆಲೋಚನೆ ಮತ್ತು ವಿವರಿಸಲಾಗದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗಬಹುದು.
    /////
    /// // ಆದಾಗ್ಯೂ, ಇದು ಯಾವುದೇ ನಕಲು ಅಲ್ಲ.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // ಇದು ಸೂಚಿಸಿದ, ಸುರಕ್ಷಿತ ಮಾರ್ಗವಾಗಿದೆ.
    /// // ಇದು ಸಂಪೂರ್ಣ vector ಅನ್ನು ಹೊಸ ಶ್ರೇಣಿಗೆ ನಕಲಿಸುತ್ತದೆ.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // ಡೇಟಾ ವಿನ್ಯಾಸವನ್ನು ಅವಲಂಬಿಸದೆ, ಇದು "transmuting" ನ `Vec` ನ ಸರಿಯಾದ ನಕಲು, ಅಸುರಕ್ಷಿತ ಮಾರ್ಗವಾಗಿದೆ.
    /// // `transmute` ಅನ್ನು ಅಕ್ಷರಶಃ ಕರೆಯುವ ಬದಲು, ನಾವು ಪಾಯಿಂಟರ್ ಎರಕಹೊಯ್ದವನ್ನು ನಿರ್ವಹಿಸುತ್ತೇವೆ, ಆದರೆ ಮೂಲ ಒಳ ಪ್ರಕಾರದ (`&i32`) ಅನ್ನು ಹೊಸದೊಂದು (`Option<&i32>`) ಗೆ ಪರಿವರ್ತಿಸುವ ದೃಷ್ಟಿಯಿಂದ, ಇದು ಒಂದೇ ರೀತಿಯ ಎಚ್ಚರಿಕೆಗಳನ್ನು ಹೊಂದಿದೆ.
    /////
    /// // ಮೇಲೆ ಒದಗಿಸಿದ ಮಾಹಿತಿಯಲ್ಲದೆ, [`from_raw_parts`] ದಸ್ತಾವೇಜನ್ನು ಸಹ ನೋಡಿ.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME vec_into_raw_parts ಅನ್ನು ಸ್ಥಿರಗೊಳಿಸಿದಾಗ ಇದನ್ನು ನವೀಕರಿಸಿ.
    ///     // ಮೂಲ vector ಅನ್ನು ಕೈಬಿಡಲಾಗಿಲ್ಲ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// `split_at_mut` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗುತ್ತಿದೆ:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // ಇದನ್ನು ಮಾಡಲು ಅನೇಕ ಮಾರ್ಗಗಳಿವೆ, ಮತ್ತು ಈ ಕೆಳಗಿನ (transmute) ರೀತಿಯಲ್ಲಿ ಅನೇಕ ಸಮಸ್ಯೆಗಳಿವೆ.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // ಮೊದಲನೆಯದು: ರೂಪಾಂತರವು ಸುರಕ್ಷಿತವಲ್ಲ;ಅದು ಪರಿಶೀಲಿಸುತ್ತದೆ ಟಿ ಮತ್ತು
    ///         // ಯು ಒಂದೇ ಗಾತ್ರದಲ್ಲಿದೆ.
    ///         // ಎರಡನೆಯದಾಗಿ, ಇಲ್ಲಿಯೇ, ನೀವು ಒಂದೇ ಸ್ಮರಣೆಯನ್ನು ಸೂಚಿಸುವ ಎರಡು ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳನ್ನು ಹೊಂದಿದ್ದೀರಿ.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // ಇದು ಸುರಕ್ಷತಾ ಪ್ರಕಾರವನ್ನು ತೊಡೆದುಹಾಕುತ್ತದೆ;`&mut *` ನಿಮಗೆ `&mut T` ಅಥವಾ `* mut T` ನಿಂದ `&mut T` ಅನ್ನು ಮಾತ್ರ ನೀಡುತ್ತದೆ.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // ಆದಾಗ್ಯೂ, ಒಂದೇ ಸ್ಮರಣೆಯನ್ನು ಸೂಚಿಸುವ ಎರಡು ರೂಪಾಂತರದ ಉಲ್ಲೇಖಗಳನ್ನು ನೀವು ಇನ್ನೂ ಹೊಂದಿದ್ದೀರಿ.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // ಸ್ಟ್ಯಾಂಡರ್ಡ್ ಲೈಬ್ರರಿ ಇದನ್ನು ಹೇಗೆ ಮಾಡುತ್ತದೆ.
    /// // ನೀವು ಈ ರೀತಿಯ ಏನಾದರೂ ಮಾಡಬೇಕಾದರೆ ಇದು ಅತ್ಯುತ್ತಮ ವಿಧಾನವಾಗಿದೆ
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // ಇದು ಈಗ ಒಂದೇ ಸ್ಮರಣೆಯನ್ನು ಸೂಚಿಸುವ ಮೂರು ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳನ್ನು ಹೊಂದಿದೆ.`slice`, rvalue ret.0, ಮತ್ತು rvalue ret.1.
    ///         // `slice` `let ptr = ...` ನಂತರ ಎಂದಿಗೂ ಬಳಸಲಾಗುವುದಿಲ್ಲ, ಮತ್ತು ಆದ್ದರಿಂದ ಇದನ್ನು "dead" ಎಂದು ಪರಿಗಣಿಸಬಹುದು ಮತ್ತು ಆದ್ದರಿಂದ, ನೀವು ಕೇವಲ ಎರಡು ನೈಜ ರೂಪಾಂತರಿತ ಚೂರುಗಳನ್ನು ಹೊಂದಿದ್ದೀರಿ.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: ಇದು ಆಂತರಿಕ ಸಂರಚನೆಯನ್ನು ಸ್ಥಿರವಾಗಿಸುತ್ತದೆಯಾದರೂ, ನಾವು ಕೆಲವು ಕಸ್ಟಮ್ ಕೋಡ್ ಅನ್ನು const fn ನಲ್ಲಿ ಹೊಂದಿದ್ದೇವೆ
    // `const fn` ಒಳಗೆ ಅದರ ಬಳಕೆಯನ್ನು ತಡೆಯುವ ಪರಿಶೀಲನೆಗಳು.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// `T` ಎಂದು ನೀಡಲಾದ ನಿಜವಾದ ಪ್ರಕಾರಕ್ಕೆ ಡ್ರಾಪ್ ಅಂಟು ಅಗತ್ಯವಿದ್ದರೆ `true` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ;`T` ಗಾಗಿ ಒದಗಿಸಲಾದ ನಿಜವಾದ ಪ್ರಕಾರವು `Copy` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದರೆ `false` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// ನಿಜವಾದ ಪ್ರಕಾರಕ್ಕೆ ಡ್ರಾಪ್ ಅಂಟು ಅಗತ್ಯವಿಲ್ಲದಿದ್ದರೆ ಅಥವಾ `Copy` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದರೆ, ಈ ಕಾರ್ಯದ ರಿಟರ್ನ್ ಮೌಲ್ಯವನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಲಾಗಿಲ್ಲ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`mem::needs_drop`](crate::mem::needs_drop) ಆಗಿದೆ.
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// ಪಾಯಿಂಟರ್‌ನಿಂದ ಆಫ್‌ಸೆಟ್ ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ.
    ///
    /// ಪರಿವರ್ತನೆಯು ಅಲಿಯಾಸಿಂಗ್ ಮಾಹಿತಿಯನ್ನು ಎಸೆಯುವ ಕಾರಣ ಪೂರ್ಣಾಂಕಕ್ಕೆ ಮತ್ತು ಅದಕ್ಕೆ ಪರಿವರ್ತಿಸುವುದನ್ನು ತಪ್ಪಿಸಲು ಇದನ್ನು ಆಂತರಿಕವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// ಪ್ರಾರಂಭಿಕ ಮತ್ತು ಫಲಿತಾಂಶದ ಪಾಯಿಂಟರ್ ಎರಡೂ ಗಡಿರೇಖೆಗಳಲ್ಲಿರಬೇಕು ಅಥವಾ ನಿಯೋಜಿಸಲಾದ ವಸ್ತುವಿನ ಕೊನೆಯಲ್ಲಿ ಒಂದು ಬೈಟ್ ಆಗಿರಬೇಕು.
    /// ಪಾಯಿಂಟರ್ ಮಿತಿ ಮೀರಿದ್ದರೆ ಅಥವಾ ಅಂಕಗಣಿತದ ಉಕ್ಕಿ ಹರಿಯುವುದಾದರೆ, ಹಿಂದಿರುಗಿದ ಮೌಲ್ಯದ ಯಾವುದೇ ಹೆಚ್ಚಿನ ಬಳಕೆಯು ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
    ///
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`pointer::offset`] ಆಗಿದೆ.
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// ಪಾಯಿಂಟರ್‌ನಿಂದ ಆಫ್‌ಸೆಟ್ ಅನ್ನು ಲೆಕ್ಕಹಾಕುತ್ತದೆ, ಸಂಭಾವ್ಯವಾಗಿ ಸುತ್ತುತ್ತದೆ.
    ///
    /// ಪರಿವರ್ತನೆಯು ಕೆಲವು ಆಪ್ಟಿಮೈಸೇಷನ್‌ಗಳನ್ನು ತಡೆಯುವುದರಿಂದ, ಪೂರ್ಣಾಂಕಕ್ಕೆ ಮತ್ತು ಅದಕ್ಕೆ ಪರಿವರ್ತಿಸುವುದನ್ನು ತಪ್ಪಿಸಲು ಇದನ್ನು ಆಂತರಿಕವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗುತ್ತದೆ.
    ///
    /// # Safety
    ///
    /// `offset` ಆಂತರಿಕಕ್ಕಿಂತ ಭಿನ್ನವಾಗಿ, ಈ ಆಂತರಿಕ ಫಲಿತಾಂಶದ ಪಾಯಿಂಟರ್ ಅನ್ನು ಸೂಚಿಸಲು ಅಥವಾ ನಿಗದಿಪಡಿಸಿದ ವಸ್ತುವಿನ ಕೊನೆಯಲ್ಲಿ ಒಂದು ಬೈಟ್ ಅನ್ನು ನಿರ್ಬಂಧಿಸುವುದಿಲ್ಲ, ಮತ್ತು ಇದು ಎರಡು ಪೂರಕ ಅಂಕಗಣಿತದೊಂದಿಗೆ ಸುತ್ತುತ್ತದೆ.
    /// ಫಲಿತಾಂಶದ ಮೌಲ್ಯವು ವಾಸ್ತವವಾಗಿ ಮೆಮೊರಿಯನ್ನು ಪ್ರವೇಶಿಸಲು ಬಳಸಬೇಕಾಗಿಲ್ಲ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`pointer::wrapping_offset`] ಆಗಿದೆ.
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// `count`*`size_of::<T>()` ಗಾತ್ರ ಮತ್ತು ಜೋಡಣೆಯೊಂದಿಗೆ ಸೂಕ್ತವಾದ `llvm.memcpy.p0i8.0i8.*` ಆಂತರಿಕಕ್ಕೆ ಸಮನಾಗಿರುತ್ತದೆ
    ///
    /// `min_align_of::<T>()`
    ///
    /// ಬಾಷ್ಪಶೀಲ ನಿಯತಾಂಕವನ್ನು `true` ಗೆ ಹೊಂದಿಸಲಾಗಿದೆ, ಆದ್ದರಿಂದ ಗಾತ್ರವು ಶೂನ್ಯಕ್ಕೆ ಸಮನಾಗಿರದ ಹೊರತು ಅದನ್ನು ಹೊಂದುವಂತೆ ಮಾಡಲಾಗುವುದಿಲ್ಲ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// `count *size_of::<T>()` ಗಾತ್ರ ಮತ್ತು ಅದರ ಜೋಡಣೆಯೊಂದಿಗೆ ಸೂಕ್ತವಾದ `llvm.memmove.p0i8.0i8.*` ಆಂತರಿಕಕ್ಕೆ ಸಮನಾಗಿರುತ್ತದೆ
    ///
    /// `min_align_of::<T>()`
    ///
    /// ಬಾಷ್ಪಶೀಲ ನಿಯತಾಂಕವನ್ನು `true` ಗೆ ಹೊಂದಿಸಲಾಗಿದೆ, ಆದ್ದರಿಂದ ಗಾತ್ರವು ಶೂನ್ಯಕ್ಕೆ ಸಮನಾಗಿರದ ಹೊರತು ಅದನ್ನು ಹೊಂದುವಂತೆ ಮಾಡಲಾಗುವುದಿಲ್ಲ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// `count *size_of::<T>()` ಗಾತ್ರ ಮತ್ತು `min_align_of::<T>()` ನ ಜೋಡಣೆಯೊಂದಿಗೆ ಸೂಕ್ತವಾದ `llvm.memset.p0i8.*` ಆಂತರಿಕಕ್ಕೆ ಸಮನಾಗಿರುತ್ತದೆ.
    ///
    ///
    /// ಬಾಷ್ಪಶೀಲ ನಿಯತಾಂಕವನ್ನು `true` ಗೆ ಹೊಂದಿಸಲಾಗಿದೆ, ಆದ್ದರಿಂದ ಗಾತ್ರವು ಶೂನ್ಯಕ್ಕೆ ಸಮನಾಗಿರದ ಹೊರತು ಅದನ್ನು ಹೊಂದುವಂತೆ ಮಾಡಲಾಗುವುದಿಲ್ಲ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// `src` ಪಾಯಿಂಟರ್‌ನಿಂದ ಬಾಷ್ಪಶೀಲ ಲೋಡ್ ಅನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`core::ptr::read_volatile`](crate::ptr::read_volatile) ಆಗಿದೆ.
    pub fn volatile_load<T>(src: *const T) -> T;
    /// `dst` ಪಾಯಿಂಟರ್‌ಗೆ ಬಾಷ್ಪಶೀಲ ಅಂಗಡಿಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`core::ptr::write_volatile`](crate::ptr::write_volatile) ಆಗಿದೆ.
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// `src` ಪಾಯಿಂಟರ್‌ನಿಂದ ಬಾಷ್ಪಶೀಲ ಲೋಡ್ ಅನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ ಪಾಯಿಂಟರ್ ಅನ್ನು ಜೋಡಿಸಲು ಅಗತ್ಯವಿಲ್ಲ.
    ///
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// `dst` ಪಾಯಿಂಟರ್‌ಗೆ ಬಾಷ್ಪಶೀಲ ಅಂಗಡಿಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ.
    /// ಪಾಯಿಂಟರ್ ಅನ್ನು ಜೋಡಿಸಲು ಅಗತ್ಯವಿಲ್ಲ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// `f32` ನ ವರ್ಗಮೂಲವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// `f64` ನ ವರ್ಗಮೂಲವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// `f32` ಅನ್ನು ಪೂರ್ಣಾಂಕ ಶಕ್ತಿಗೆ ಹೆಚ್ಚಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// `f64` ಅನ್ನು ಪೂರ್ಣಾಂಕ ಶಕ್ತಿಗೆ ಹೆಚ್ಚಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// `f32` ನ ಸೈನ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// `f64` ನ ಸೈನ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// `f32` ನ ಕೊಸೈನ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// `f64` ನ ಕೊಸೈನ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// `f32` ಅನ್ನು `f32` ಶಕ್ತಿಗೆ ಹೆಚ್ಚಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// `f64` ಅನ್ನು `f64` ಶಕ್ತಿಗೆ ಹೆಚ್ಚಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// `f32` ನ ಘಾತಾಂಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// `f64` ನ ಘಾತಾಂಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// `f32` ನ ಶಕ್ತಿಗೆ 2 ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// `f64` ನ ಶಕ್ತಿಗೆ 2 ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// `f32` ನ ನೈಸರ್ಗಿಕ ಲಾಗರಿಥಮ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// `f64` ನ ನೈಸರ್ಗಿಕ ಲಾಗರಿಥಮ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// `f32` ನ ಮೂಲ 10 ಲಾಗರಿಥಮ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// `f64` ನ ಮೂಲ 10 ಲಾಗರಿಥಮ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// `f32` ನ ಮೂಲ 2 ಲಾಗರಿಥಮ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// `f64` ನ ಮೂಲ 2 ಲಾಗರಿಥಮ್ ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// `f32` ಮೌಲ್ಯಗಳಿಗಾಗಿ `a * b + c` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// `f64` ಮೌಲ್ಯಗಳಿಗಾಗಿ `a * b + c` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// `f32` ನ ಸಂಪೂರ್ಣ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// `f64` ನ ಸಂಪೂರ್ಣ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// ಕನಿಷ್ಠ ಎರಡು `f32` ಮೌಲ್ಯಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// ಕನಿಷ್ಠ ಎರಡು `f64` ಮೌಲ್ಯಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// ಗರಿಷ್ಠ ಎರಡು `f32` ಮೌಲ್ಯಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// ಗರಿಷ್ಠ ಎರಡು `f64` ಮೌಲ್ಯಗಳನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// `f32` ಮೌಲ್ಯಗಳಿಗಾಗಿ `y` ನಿಂದ `x` ಗೆ ಚಿಹ್ನೆಯನ್ನು ನಕಲಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// `f64` ಮೌಲ್ಯಗಳಿಗಾಗಿ `y` ನಿಂದ `x` ಗೆ ಚಿಹ್ನೆಯನ್ನು ನಕಲಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// `f32` ಗಿಂತ ಕಡಿಮೆ ಅಥವಾ ಸಮನಾದ ದೊಡ್ಡ ಪೂರ್ಣಾಂಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// `f64` ಗಿಂತ ಕಡಿಮೆ ಅಥವಾ ಸಮನಾದ ದೊಡ್ಡ ಪೂರ್ಣಾಂಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// `f32` ಗಿಂತ ಹೆಚ್ಚಿನ ಅಥವಾ ಸಮನಾದ ಚಿಕ್ಕದಾದ ಪೂರ್ಣಾಂಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// `f64` ಗಿಂತ ಹೆಚ್ಚಿನ ಅಥವಾ ಸಮನಾದ ಚಿಕ್ಕದಾದ ಪೂರ್ಣಾಂಕವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// `f32` ನ ಪೂರ್ಣಾಂಕ ಭಾಗವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// `f64` ನ ಪೂರ್ಣಾಂಕ ಭಾಗವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// ಹತ್ತಿರದ ಪೂರ್ಣಾಂಕವನ್ನು `f32` ಗೆ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ವಾದವು ಪೂರ್ಣಾಂಕವಲ್ಲದಿದ್ದರೆ ನಿಖರವಾದ ಫ್ಲೋಟಿಂಗ್-ಪಾಯಿಂಟ್ ವಿನಾಯಿತಿಯನ್ನು ಹೆಚ್ಚಿಸಬಹುದು.
    pub fn rintf32(x: f32) -> f32;
    /// ಹತ್ತಿರದ ಪೂರ್ಣಾಂಕವನ್ನು `f64` ಗೆ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ವಾದವು ಪೂರ್ಣಾಂಕವಲ್ಲದಿದ್ದರೆ ನಿಖರವಾದ ಫ್ಲೋಟಿಂಗ್-ಪಾಯಿಂಟ್ ವಿನಾಯಿತಿಯನ್ನು ಹೆಚ್ಚಿಸಬಹುದು.
    pub fn rintf64(x: f64) -> f64;

    /// ಹತ್ತಿರದ ಪೂರ್ಣಾಂಕವನ್ನು `f32` ಗೆ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    pub fn nearbyintf32(x: f32) -> f32;
    /// ಹತ್ತಿರದ ಪೂರ್ಣಾಂಕವನ್ನು `f64` ಗೆ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    pub fn nearbyintf64(x: f64) -> f64;

    /// ಹತ್ತಿರದ ಪೂರ್ಣಾಂಕವನ್ನು `f32` ಗೆ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.ಅರ್ಧ-ದಾರಿ ಪ್ರಕರಣಗಳನ್ನು ಶೂನ್ಯದಿಂದ ದೂರವಿರಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// ಹತ್ತಿರದ ಪೂರ್ಣಾಂಕವನ್ನು `f64` ಗೆ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.ಅರ್ಧ-ದಾರಿ ಪ್ರಕರಣಗಳನ್ನು ಶೂನ್ಯದಿಂದ ದೂರವಿರಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯಾಗಿದೆ
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// ಬೀಜಗಣಿತ ನಿಯಮಗಳ ಆಧಾರದ ಮೇಲೆ ಆಪ್ಟಿಮೈಸೇಶನ್ ಅನ್ನು ಅನುಮತಿಸುವ ಫ್ಲೋಟ್ ಸೇರ್ಪಡೆ.
    /// ಒಳಹರಿವು ಸೀಮಿತವಾಗಿದೆ ಎಂದು ಭಾವಿಸಬಹುದು.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// ಬೀಜಗಣಿತ ನಿಯಮಗಳ ಆಧಾರದ ಮೇಲೆ ಆಪ್ಟಿಮೈಸೇಶನ್ ಅನ್ನು ಅನುಮತಿಸುವ ಫ್ಲೋಟ್ ವ್ಯವಕಲನ.
    /// ಒಳಹರಿವು ಸೀಮಿತವಾಗಿದೆ ಎಂದು ಭಾವಿಸಬಹುದು.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// ಬೀಜಗಣಿತ ನಿಯಮಗಳ ಆಧಾರದ ಮೇಲೆ ಆಪ್ಟಿಮೈಸೇಶನ್ ಅನ್ನು ಅನುಮತಿಸುವ ಫ್ಲೋಟ್ ಗುಣಾಕಾರ.
    /// ಒಳಹರಿವು ಸೀಮಿತವಾಗಿದೆ ಎಂದು ಭಾವಿಸಬಹುದು.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// ಬೀಜಗಣಿತ ನಿಯಮಗಳ ಆಧಾರದ ಮೇಲೆ ಆಪ್ಟಿಮೈಸೇಶನ್ ಅನ್ನು ಅನುಮತಿಸುವ ಫ್ಲೋಟ್ ವಿಭಾಗ.
    /// ಒಳಹರಿವು ಸೀಮಿತವಾಗಿದೆ ಎಂದು ಭಾವಿಸಬಹುದು.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// ಬೀಜಗಣಿತ ನಿಯಮಗಳ ಆಧಾರದ ಮೇಲೆ ಆಪ್ಟಿಮೈಸೇಶನ್ ಅನ್ನು ಅನುಮತಿಸುವ ಉಳಿದ ಫ್ಲೋಟ್.
    /// ಒಳಹರಿವು ಸೀಮಿತವಾಗಿದೆ ಎಂದು ಭಾವಿಸಬಹುದು.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// LLVM ನ fptoui/fptosi ನೊಂದಿಗೆ ಪರಿವರ್ತಿಸಿ, ಅದು ಮೌಲ್ಯಗಳಿಗೆ ವ್ಯಾಪ್ತಿಯಿಂದ ಹೊರಗುಳಿಯಬಹುದು
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// [`f32::to_int_unchecked`] ಮತ್ತು [`f64::to_int_unchecked`] ಎಂದು ಸ್ಥಿರಗೊಳಿಸಲಾಗಿದೆ.
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರ `T` ನಲ್ಲಿ ಹೊಂದಿಸಲಾದ ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಗಳು `count_ones` ವಿಧಾನದ ಮೂಲಕ ಪೂರ್ಣಾಂಕದ ಆದಿಮಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರದ `T` ನಲ್ಲಿ ಪ್ರಮುಖ ಅನ್‌ಸೆಟ್ ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆ (zeroes) ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಗಳು `leading_zeros` ವಿಧಾನದ ಮೂಲಕ ಪೂರ್ಣಾಂಕದ ಆದಿಮಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `0` ಮೌಲ್ಯವನ್ನು ಹೊಂದಿರುವ `x` `T` ನ ಬಿಟ್ ಅಗಲವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// `ctlz` ನಂತೆ, ಆದರೆ `0` ಮೌಲ್ಯದೊಂದಿಗೆ `x` ಅನ್ನು ನೀಡಿದಾಗ ಅದು `undef` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರದ `T` ನಲ್ಲಿ (zeroes) ಅನ್ನು ಹಿಂದುಳಿದಿರುವ ಹೊಂದಿಸದ ಬಿಟ್‌ಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಗಳು `trailing_zeros` ವಿಧಾನದ ಮೂಲಕ ಪೂರ್ಣಾಂಕದ ಆದಿಮಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `0` ಮೌಲ್ಯವನ್ನು ಹೊಂದಿರುವ `x` `T` ನ ಬಿಟ್ ಅಗಲವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// `cttz` ನಂತೆ, ಆದರೆ `0` ಮೌಲ್ಯದೊಂದಿಗೆ `x` ಅನ್ನು ನೀಡಿದಾಗ ಅದು `undef` ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// ಬೈಟ್‌ಗಳನ್ನು ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರ `T` ನಲ್ಲಿ ಹಿಮ್ಮುಖಗೊಳಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಗಳು `swap_bytes` ವಿಧಾನದ ಮೂಲಕ ಪೂರ್ಣಾಂಕದ ಆದಿಮಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// ಪೂರ್ಣಾಂಕ ಪ್ರಕಾರದ `T` ನಲ್ಲಿ ಬಿಟ್‌ಗಳನ್ನು ಹಿಮ್ಮುಖಗೊಳಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಗಳು `reverse_bits` ವಿಧಾನದ ಮೂಲಕ ಪೂರ್ಣಾಂಕದ ಆದಿಮಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// ಪರಿಶೀಲಿಸಿದ ಪೂರ್ಣಾಂಕ ಸೇರ್ಪಡೆ ನಿರ್ವಹಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಗಳು `overflowing_add` ವಿಧಾನದ ಮೂಲಕ ಪೂರ್ಣಾಂಕದ ಆದಿಮಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// ಪರಿಶೀಲಿಸಿದ ಪೂರ್ಣಾಂಕ ವ್ಯವಕಲನವನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಗಳು `overflowing_sub` ವಿಧಾನದ ಮೂಲಕ ಪೂರ್ಣಾಂಕದ ಆದಿಮಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// ಪರಿಶೀಲಿಸಿದ ಪೂರ್ಣಾಂಕ ಗುಣಾಕಾರವನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಗಳು `overflowing_mul` ವಿಧಾನದ ಮೂಲಕ ಪೂರ್ಣಾಂಕದ ಆದಿಮಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// ನಿಖರವಾದ ವಿಭಾಗವನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ, ಇದರ ಪರಿಣಾಮವಾಗಿ `x % y != 0` ಅಥವಾ `y == 0` ಅಥವಾ `x == T::MIN && y == -1` ನಲ್ಲಿ ಸ್ಪಷ್ಟೀಕರಿಸದ ನಡವಳಿಕೆಯಾಗುತ್ತದೆ
    ///
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// ಪರಿಶೀಲಿಸದ ವಿಭಾಗವನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ, ಇದರ ಪರಿಣಾಮವಾಗಿ `y == 0` ಅಥವಾ `x == T::MIN && y == -1` ಅಲ್ಲಿ ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಯಾಗುತ್ತದೆ
    ///
    ///
    /// ಈ ಆಂತರಿಕ ಸುರಕ್ಷಿತ ಹೊದಿಕೆಗಳು `checked_div` ವಿಧಾನದ ಮೂಲಕ ಪೂರ್ಣಾಂಕದ ಆದಿಮಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// ಪರಿಶೀಲಿಸದ ವಿಭಾಗದ ಉಳಿದ ಭಾಗವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಇದರ ಪರಿಣಾಮವಾಗಿ `y == 0` ಅಥವಾ `x == T::MIN && y == -1` ಇದ್ದಾಗ ವಿವರಿಸಲಾಗದ ವರ್ತನೆ ಉಂಟಾಗುತ್ತದೆ
    ///
    ///
    /// ಈ ಆಂತರಿಕ ಸುರಕ್ಷಿತ ಹೊದಿಕೆಗಳು `checked_rem` ವಿಧಾನದ ಮೂಲಕ ಪೂರ್ಣಾಂಕದ ಆದಿಮಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// ಪರಿಶೀಲಿಸದ ಎಡ ಶಿಫ್ಟ್ ಅನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ, ಇದರ ಪರಿಣಾಮವಾಗಿ `y < 0` ಅಥವಾ `y >= N` ಆಗಿರುವಾಗ ವಿವರಿಸಲಾಗದ ನಡವಳಿಕೆಯಾಗುತ್ತದೆ, ಇಲ್ಲಿ N ಎಂಬುದು ಬಿಟ್‌ಗಳಲ್ಲಿ T ಯ ಅಗಲವಾಗಿರುತ್ತದೆ.
    ///
    ///
    /// ಈ ಆಂತರಿಕ ಸುರಕ್ಷಿತ ಹೊದಿಕೆಗಳು `checked_shl` ವಿಧಾನದ ಮೂಲಕ ಪೂರ್ಣಾಂಕದ ಆದಿಮಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// ಗುರುತಿಸದ ಬಲ ಬದಲಾವಣೆಯನ್ನು ನಿರ್ವಹಿಸುತ್ತದೆ, ಇದರ ಪರಿಣಾಮವಾಗಿ `y < 0` ಅಥವಾ `y >= N` ಆಗಿರುವಾಗ ವಿವರಿಸಲಾಗದ ನಡವಳಿಕೆಯಾಗುತ್ತದೆ, ಇಲ್ಲಿ N ಎಂಬುದು ಬಿಟ್‌ಗಳಲ್ಲಿ T ಯ ಅಗಲವಾಗಿರುತ್ತದೆ.
    ///
    ///
    /// ಈ ಆಂತರಿಕ ಸುರಕ್ಷಿತ ಹೊದಿಕೆಗಳು `checked_shr` ವಿಧಾನದ ಮೂಲಕ ಪೂರ್ಣಾಂಕದ ಆದಿಮಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// ಪರಿಶೀಲಿಸದ ಸೇರ್ಪಡೆಯ ಫಲಿತಾಂಶವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಇದರ ಪರಿಣಾಮವಾಗಿ `x + y > T::MAX` ಅಥವಾ `x + y < T::MIN` ಇದ್ದಾಗ ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಯಾಗುತ್ತದೆ.
    ///
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// ಪರಿಶೀಲಿಸದ ವ್ಯವಕಲನ ಫಲಿತಾಂಶವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಇದರ ಪರಿಣಾಮವಾಗಿ `x - y > T::MAX` ಅಥವಾ `x - y < T::MIN` ಇದ್ದಾಗ ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಯಾಗುತ್ತದೆ.
    ///
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// ಪರಿಶೀಲಿಸದ ಗುಣಾಕಾರದ ಫಲಿತಾಂಶವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಇದರ ಪರಿಣಾಮವಾಗಿ `x *y > T::MAX` ಅಥವಾ `x* y < T::MIN` ಇದ್ದಾಗ ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಯಾಗುತ್ತದೆ.
    ///
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಪ್ರತಿರೂಪವನ್ನು ಹೊಂದಿಲ್ಲ.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// ಎಡಕ್ಕೆ ತಿರುಗುವಂತೆ ಮಾಡುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಗಳು `rotate_left` ವಿಧಾನದ ಮೂಲಕ ಪೂರ್ಣಾಂಕದ ಆದಿಮಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// ಪ್ರದರ್ಶನಗಳು ಬಲಕ್ಕೆ ತಿರುಗುತ್ತವೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಗಳು `rotate_right` ವಿಧಾನದ ಮೂಲಕ ಪೂರ್ಣಾಂಕದ ಆದಿಮಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// ರಿಟರ್ನ್ಸ್ (a + b) mod 2 <sup>N</sup>, ಇಲ್ಲಿ N ಎಂಬುದು ಬಿಟ್‌ಗಳಲ್ಲಿ T ಯ ಅಗಲವಾಗಿರುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಗಳು `wrapping_add` ವಿಧಾನದ ಮೂಲಕ ಪೂರ್ಣಾಂಕದ ಆದಿಮಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// (ಎ, ಬಿ) ಮೋಡ್ 2 <sup>ಎನ್ ಅನ್ನು</sup> ಹಿಂತಿರುಗಿಸುತ್ತದೆ, ಇಲ್ಲಿ ಎನ್ ಎಂಬುದು ಬಿಟ್‌ಗಳಲ್ಲಿ ಟಿ ಅಗಲವಾಗಿರುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಗಳು `wrapping_sub` ವಿಧಾನದ ಮೂಲಕ ಪೂರ್ಣಾಂಕದ ಆದಿಮಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// ಹಿಂತಿರುಗುತ್ತದೆ (a * b) mod 2 <sup>N</sup>, ಇಲ್ಲಿ N ಎಂಬುದು ಬಿಟ್‌ಗಳಲ್ಲಿ T ಯ ಅಗಲವಾಗಿರುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಗಳು `wrapping_mul` ವಿಧಾನದ ಮೂಲಕ ಪೂರ್ಣಾಂಕದ ಆದಿಮಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// `a + b` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಸಂಖ್ಯಾ ಗಡಿಗಳಲ್ಲಿ ಸ್ಯಾಚುರೇಟಿಂಗ್.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಗಳು `saturating_add` ವಿಧಾನದ ಮೂಲಕ ಪೂರ್ಣಾಂಕದ ಆದಿಮಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// `a - b` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಸಂಖ್ಯಾ ಗಡಿಗಳಲ್ಲಿ ಸ್ಯಾಚುರೇಟಿಂಗ್.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರೀಕೃತ ಆವೃತ್ತಿಗಳು `saturating_sub` ವಿಧಾನದ ಮೂಲಕ ಪೂರ್ಣಾಂಕದ ಆದಿಮಗಳಲ್ಲಿ ಲಭ್ಯವಿದೆ.
    /// ಉದಾಹರಣೆಗೆ,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// 'v' ನಲ್ಲಿನ ರೂಪಾಂತರಕ್ಕಾಗಿ ತಾರತಮ್ಯದ ಮೌಲ್ಯವನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ;
    /// `T` ಗೆ ಯಾವುದೇ ತಾರತಮ್ಯವಿಲ್ಲದಿದ್ದರೆ, `0` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಸ್ಥಿರ ಆವೃತ್ತಿಯು [`core::mem::discriminant`](crate::mem::discriminant) ಆಗಿದೆ.
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// `T` ಎರಕಹೊಯ್ದ ಪ್ರಕಾರದ ರೂಪಾಂತರಗಳ ಸಂಖ್ಯೆಯನ್ನು `usize` ಗೆ ಹಿಂತಿರುಗಿಸುತ್ತದೆ;
    /// `T` ಗೆ ಯಾವುದೇ ರೂಪಾಂತರಗಳಿಲ್ಲದಿದ್ದರೆ, `0` ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.ನಿರ್ಜನ ರೂಪಾಂತರಗಳನ್ನು ಎಣಿಸಲಾಗುತ್ತದೆ.
    ///
    /// ಈ ಆಂತರಿಕ ಆವೃತ್ತಿಯ [`mem::variant_count`] ಆಗಿದೆ.
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust ನ "try catch" ರಚನೆಯು ಡೇಟಾ ಪಾಯಿಂಟರ್ `data` ನೊಂದಿಗೆ ಫಂಕ್ಷನ್ ಪಾಯಿಂಟರ್ `try_fn` ಅನ್ನು ಆಹ್ವಾನಿಸುತ್ತದೆ.
    ///
    /// ಮೂರನೆಯ ಆರ್ಗ್ಯುಮೆಂಟ್ panic ಸಂಭವಿಸಿದಲ್ಲಿ ಕರೆಯಲ್ಪಡುವ ಒಂದು ಕಾರ್ಯವಾಗಿದೆ.
    /// ಈ ಕಾರ್ಯವು ಡೇಟಾ ಪಾಯಿಂಟರ್ ಮತ್ತು ಪಾಯಿಂಟರ್ ಅನ್ನು ಸಿಕ್ಕಿಬಿದ್ದ ಗುರಿ-ನಿರ್ದಿಷ್ಟ ವಿನಾಯಿತಿ ವಸ್ತುವಿಗೆ ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.
    ///
    /// ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ ಕಂಪೈಲರ್ನ ಮೂಲ ಮತ್ತು std ನ ಕ್ಯಾಚ್ ಅನುಷ್ಠಾನವನ್ನು ನೋಡಿ.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// LLVM ಪ್ರಕಾರ `!nontemporal` ಅಂಗಡಿಯನ್ನು ಹೊರಸೂಸುತ್ತದೆ (ಅವುಗಳ ಡಾಕ್ಸ್ ನೋಡಿ).
    /// ಬಹುಶಃ ಎಂದಿಗೂ ಸ್ಥಿರವಾಗುವುದಿಲ್ಲ.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// ವಿವರಗಳಿಗಾಗಿ `<*const T>::offset_from` ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// ವಿವರಗಳಿಗಾಗಿ `<*const T>::guaranteed_eq` ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// ವಿವರಗಳಿಗಾಗಿ `<*const T>::guaranteed_ne` ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// ಕಂಪೈಲ್ ಸಮಯದಲ್ಲಿ ನಿಗದಿಪಡಿಸಿ.ರನ್ಟೈಮ್ನಲ್ಲಿ ಕರೆಯಬಾರದು.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// ಕೆಲವು ಕಾರ್ಯಗಳನ್ನು ಇಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿದೆ ಏಕೆಂದರೆ ಅವು ಆಕಸ್ಮಿಕವಾಗಿ ಈ ಮಾಡ್ಯೂಲ್‌ನಲ್ಲಿ ಸ್ಥಿರವಾಗಿ ಲಭ್ಯವಾಗುತ್ತವೆ.
// <https://github.com/rust-lang/rust/issues/15702> ನೋಡಿ.
// (`transmute` ಸಹ ಈ ವರ್ಗಕ್ಕೆ ಸೇರುತ್ತದೆ, ಆದರೆ `T` ಮತ್ತು `U` ಒಂದೇ ಗಾತ್ರವನ್ನು ಹೊಂದಿದೆಯೆ ಎಂದು ಪರಿಶೀಲಿಸುವ ಕಾರಣ ಅದನ್ನು ಸುತ್ತಲು ಸಾಧ್ಯವಿಲ್ಲ.)
//

/// `align_of::<T>()` ಗೆ ಸಂಬಂಧಿಸಿದಂತೆ `ptr` ಅನ್ನು ಸರಿಯಾಗಿ ಜೋಡಿಸಲಾಗಿದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತದೆ.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// `count *size_of::<T>()` ಬೈಟ್‌ಗಳನ್ನು `src` ನಿಂದ `dst` ಗೆ ನಕಲಿಸುತ್ತದೆ.ಮೂಲ ಮತ್ತು ಗಮ್ಯಸ್ಥಾನವು* ಅತಿಕ್ರಮಿಸಬಾರದು.
///
/// ಅತಿಕ್ರಮಿಸಬಹುದಾದ ಮೆಮೊರಿಯ ಪ್ರದೇಶಗಳಿಗಾಗಿ, ಬದಲಿಗೆ [`copy`] ಬಳಸಿ.
///
/// `copy_nonoverlapping` ಇದು ಸಿ ಯ ಎಕ್ಸ್‌00 ಎಕ್ಸ್‌ಗೆ ಶಬ್ದಾರ್ಥವಾಗಿ ಸಮಾನವಾಗಿರುತ್ತದೆ, ಆದರೆ ಆರ್ಗ್ಯುಮೆಂಟ್ ಆದೇಶವನ್ನು ಬದಲಾಯಿಸಲಾಗಿದೆ.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// ಈ ಕೆಳಗಿನ ಯಾವುದೇ ಷರತ್ತುಗಳನ್ನು ಉಲ್ಲಂಘಿಸಿದರೆ ನಡವಳಿಕೆಯನ್ನು ವಿವರಿಸಲಾಗುವುದಿಲ್ಲ:
///
/// * `src` `count * size_of::<T>()` ಬೈಟ್‌ಗಳ ಓದುವಿಕೆಗಾಗಿ [valid] ಆಗಿರಬೇಕು.
///
/// * `dst` `count * size_of::<T>()` ಬೈಟ್‌ಗಳ ಬರಹಗಳಿಗೆ [valid] ಆಗಿರಬೇಕು.
///
/// * `src` ಮತ್ತು `dst` ಎರಡನ್ನೂ ಸರಿಯಾಗಿ ಜೋಡಿಸಬೇಕು.
///
/// * `ಎಣಿಕೆ ಗಾತ್ರದೊಂದಿಗೆ `src` ನಿಂದ ಪ್ರಾರಂಭವಾಗುವ ಮೆಮೊರಿಯ ಪ್ರದೇಶ *
///   size_of: :<T>() `ಬೈಟ್‌ಗಳು `dst` ನಿಂದ ಪ್ರಾರಂಭವಾಗುವ ಮೆಮೊರಿಯ ಪ್ರದೇಶದೊಂದಿಗೆ ಒಂದೇ ಗಾತ್ರದೊಂದಿಗೆ ಅತಿಕ್ರಮಿಸಬಾರದು.
///
/// [`read`] ನಂತೆ, `copy_nonoverlapping` `T` ನ ಬಿಟ್‌ವೈಸ್ ನಕಲನ್ನು ರಚಿಸುತ್ತದೆ, `T` [`Copy`] ಆಗಿರಲಿ.
/// `T` [`Copy`] ಅಲ್ಲದಿದ್ದರೆ, `*src` ನಿಂದ ಪ್ರಾರಂಭವಾಗುವ ಪ್ರದೇಶದ ಮೌಲ್ಯಗಳು ಮತ್ತು `* dst` ನಿಂದ ಪ್ರಾರಂಭವಾಗುವ ಪ್ರದೇಶವು [violate memory safety][read-ownership] ಅನ್ನು ಮಾಡಬಹುದು.
///
///
/// ಪರಿಣಾಮಕಾರಿಯಾಗಿ ನಕಲಿಸಿದ ಗಾತ್ರವನ್ನು ಸಹ ಗಮನಿಸಿ (`ಎಣಿಕೆ * ಗಾತ್ರ_ಆಫ್: :<T>()`) `0` ಆಗಿದೆ, ಪಾಯಿಂಟರ್‌ಗಳು NULL ಅಲ್ಲದ ಮತ್ತು ಸರಿಯಾಗಿ ಜೋಡಿಸಲ್ಪಟ್ಟಿರಬೇಕು.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// [`Vec::append`] ಅನ್ನು ಹಸ್ತಚಾಲಿತವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸಿ:
///
/// ```
/// use std::ptr;
///
/// /// `src` ನ ಎಲ್ಲಾ ಅಂಶಗಳನ್ನು `dst` ಗೆ ಸರಿಸುತ್ತದೆ, `src` ಖಾಲಿಯಾಗಿರುತ್ತದೆ.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // `dst` ಎಲ್ಲಾ `src` ಅನ್ನು ಹಿಡಿದಿಡಲು ಸಾಕಷ್ಟು ಸಾಮರ್ಥ್ಯವನ್ನು ಹೊಂದಿದೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ.
///     dst.reserve(src_len);
///
///     unsafe {
///         // ಆಫ್‌ಸೆಟ್‌ಗೆ ಕರೆ ಯಾವಾಗಲೂ ಸುರಕ್ಷಿತವಾಗಿದೆ ಏಕೆಂದರೆ `Vec` ಎಂದಿಗೂ `isize::MAX` ಬೈಟ್‌ಗಳಿಗಿಂತ ಹೆಚ್ಚಿನದನ್ನು ನಿಯೋಜಿಸುವುದಿಲ್ಲ.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // `src` ಅನ್ನು ಅದರ ವಿಷಯಗಳನ್ನು ಬಿಡದೆ ಮೊಟಕುಗೊಳಿಸಿ.
///         // panics ಕೆಳಗೆ ಏನಾದರೂ ಕಡಿಮೆಯಾದರೆ ಸಮಸ್ಯೆಗಳನ್ನು ತಪ್ಪಿಸಲು ನಾವು ಇದನ್ನು ಮೊದಲು ಮಾಡುತ್ತೇವೆ.
///         src.set_len(0);
///
///         // ಎರಡು ಪ್ರದೇಶಗಳು ಅತಿಕ್ರಮಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ ಏಕೆಂದರೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳು ಅಲಿಯಾಸ್ ಆಗುವುದಿಲ್ಲ, ಮತ್ತು ಎರಡು ವಿಭಿನ್ನ vectors ಒಂದೇ ಮೆಮೊರಿಯನ್ನು ಹೊಂದಲು ಸಾಧ್ಯವಿಲ್ಲ.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // `dst` ಈಗ `src` ನ ವಿಷಯಗಳನ್ನು ಹೊಂದಿದೆ ಎಂದು ತಿಳಿಸಿ.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: ರನ್ ಸಮಯದಲ್ಲಿ ಮಾತ್ರ ಈ ತಪಾಸಣೆಗಳನ್ನು ಮಾಡಿ
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // ಕೋಡೆಜೆನ್ ಪ್ರಭಾವವನ್ನು ಚಿಕ್ಕದಾಗಿಡಲು ಭಯಪಡುತ್ತಿಲ್ಲ.
        abort();
    }*/

    // ಸುರಕ್ಷತೆ: `copy_nonoverlapping` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದ ಇರಬೇಕು
    // ಕರೆ ಮಾಡಿದವರಿಂದ ಎತ್ತಿಹಿಡಿಯಲಾಗಿದೆ.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// `count * size_of::<T>()` ಬೈಟ್‌ಗಳನ್ನು `src` ನಿಂದ `dst` ಗೆ ನಕಲಿಸುತ್ತದೆ.ಮೂಲ ಮತ್ತು ಗಮ್ಯಸ್ಥಾನವು ಅತಿಕ್ರಮಿಸಬಹುದು.
///
/// ಮೂಲ ಮತ್ತು ಗಮ್ಯಸ್ಥಾನವು *ಎಂದಿಗೂ* ಅತಿಕ್ರಮಿಸದಿದ್ದರೆ, ಬದಲಿಗೆ [`copy_nonoverlapping`] ಅನ್ನು ಬಳಸಬಹುದು.
///
/// `copy` ಇದು ಸಿ ಯ ಎಕ್ಸ್‌00 ಎಕ್ಸ್‌ಗೆ ಶಬ್ದಾರ್ಥವಾಗಿ ಸಮಾನವಾಗಿರುತ್ತದೆ, ಆದರೆ ಆರ್ಗ್ಯುಮೆಂಟ್ ಆದೇಶವನ್ನು ಬದಲಾಯಿಸಲಾಗಿದೆ.
/// `src` ನಿಂದ ತಾತ್ಕಾಲಿಕ ರಚನೆಗೆ ಬೈಟ್‌ಗಳನ್ನು ನಕಲಿಸಲಾಗಿದೆ ಮತ್ತು ನಂತರ ರಚನೆಯಿಂದ `dst` ಗೆ ನಕಲಿಸಿದಂತೆ ನಕಲು ನಡೆಯುತ್ತದೆ.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// ಈ ಕೆಳಗಿನ ಯಾವುದೇ ಷರತ್ತುಗಳನ್ನು ಉಲ್ಲಂಘಿಸಿದರೆ ನಡವಳಿಕೆಯನ್ನು ವಿವರಿಸಲಾಗುವುದಿಲ್ಲ:
///
/// * `src` `count * size_of::<T>()` ಬೈಟ್‌ಗಳ ಓದುವಿಕೆಗಾಗಿ [valid] ಆಗಿರಬೇಕು.
///
/// * `dst` `count * size_of::<T>()` ಬೈಟ್‌ಗಳ ಬರಹಗಳಿಗೆ [valid] ಆಗಿರಬೇಕು.
///
/// * `src` ಮತ್ತು `dst` ಎರಡನ್ನೂ ಸರಿಯಾಗಿ ಜೋಡಿಸಬೇಕು.
///
/// [`read`] ನಂತೆ, `copy` `T` ನ ಬಿಟ್‌ವೈಸ್ ನಕಲನ್ನು ರಚಿಸುತ್ತದೆ, `T` [`Copy`] ಆಗಿರಲಿ.
/// `T` [`Copy`] ಅಲ್ಲದಿದ್ದರೆ, `*src` ನಿಂದ ಪ್ರಾರಂಭವಾಗುವ ಪ್ರದೇಶ ಮತ್ತು `* dst` ನಿಂದ ಪ್ರಾರಂಭವಾಗುವ ಪ್ರದೇಶದಲ್ಲಿನ ಎರಡೂ ಮೌಲ್ಯಗಳನ್ನು ಬಳಸಿ [violate memory safety][read-ownership] ಮಾಡಬಹುದು.
///
///
/// ಪರಿಣಾಮಕಾರಿಯಾಗಿ ನಕಲಿಸಿದ ಗಾತ್ರವನ್ನು ಸಹ ಗಮನಿಸಿ (`ಎಣಿಕೆ * ಗಾತ್ರ_ಆಫ್: :<T>()`) `0` ಆಗಿದೆ, ಪಾಯಿಂಟರ್‌ಗಳು NULL ಅಲ್ಲದ ಮತ್ತು ಸರಿಯಾಗಿ ಜೋಡಿಸಲ್ಪಟ್ಟಿರಬೇಕು.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// ಅಸುರಕ್ಷಿತ ಬಫರ್‌ನಿಂದ Rust vector ಅನ್ನು ಸಮರ್ಥವಾಗಿ ರಚಿಸಿ:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` ಅದರ ಪ್ರಕಾರ ಮತ್ತು ಶೂನ್ಯೇತರಕ್ಕಾಗಿ ಸರಿಯಾಗಿ ಜೋಡಿಸಬೇಕು.
/// /// * `ptr` `T` ಪ್ರಕಾರದ `elts` ಸಮೀಪದ ಅಂಶಗಳ ವಾಚನಗೋಷ್ಠಿಗೆ ಮಾನ್ಯವಾಗಿರಬೇಕು.
/// /// * `T: Copy` ಹೊರತು ಈ ಕಾರ್ಯವನ್ನು ಕರೆದ ನಂತರ ಆ ಅಂಶಗಳನ್ನು ಬಳಸಬಾರದು.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // ಸುರಕ್ಷತೆ: ನಮ್ಮ ಪೂರ್ವಭಾವಿ ಷರತ್ತು ಮೂಲವನ್ನು ಜೋಡಿಸಲಾಗಿದೆ ಮತ್ತು ಮಾನ್ಯವಾಗಿದೆ ಎಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ,
///     // ಮತ್ತು ಅವುಗಳನ್ನು ಬರೆಯಲು ನಮಗೆ ಬಳಸಬಹುದಾದ ಸ್ಥಳವಿದೆ ಎಂದು `Vec::with_capacity` ಖಾತ್ರಿಗೊಳಿಸುತ್ತದೆ.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // ಸುರಕ್ಷತೆ: ನಾವು ಇದನ್ನು ಮೊದಲೇ ಈ ಹೆಚ್ಚಿನ ಸಾಮರ್ಥ್ಯದೊಂದಿಗೆ ರಚಿಸಿದ್ದೇವೆ,
///     // ಮತ್ತು ಹಿಂದಿನ `copy` ಈ ಅಂಶಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದೆ.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: ರನ್ ಸಮಯದಲ್ಲಿ ಮಾತ್ರ ಈ ತಪಾಸಣೆಗಳನ್ನು ಮಾಡಿ
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // ಕೋಡೆಜೆನ್ ಪ್ರಭಾವವನ್ನು ಚಿಕ್ಕದಾಗಿಡಲು ಭಯಪಡುತ್ತಿಲ್ಲ.
        abort();
    }*/

    // ಸುರಕ್ಷತೆ: `copy` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಕರೆ ಮಾಡಿದವರು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
    unsafe { copy(src, dst, count) }
}

/// `dst` ನಿಂದ `val` ನಿಂದ ಪ್ರಾರಂಭವಾಗುವ `count * size_of::<T>()` ಬೈಟ್‌ಗಳ ಮೆಮೊರಿಯನ್ನು ಹೊಂದಿಸುತ್ತದೆ.
///
/// `write_bytes` ಇದು C ನ [`memset`] ಗೆ ಹೋಲುತ್ತದೆ, ಆದರೆ `count * size_of::<T>()` ಬೈಟ್‌ಗಳನ್ನು `val` ಗೆ ಹೊಂದಿಸುತ್ತದೆ.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// ಈ ಕೆಳಗಿನ ಯಾವುದೇ ಷರತ್ತುಗಳನ್ನು ಉಲ್ಲಂಘಿಸಿದರೆ ನಡವಳಿಕೆಯನ್ನು ವಿವರಿಸಲಾಗುವುದಿಲ್ಲ:
///
/// * `dst` `count * size_of::<T>()` ಬೈಟ್‌ಗಳ ಬರಹಗಳಿಗೆ [valid] ಆಗಿರಬೇಕು.
///
/// * `dst` ಸರಿಯಾಗಿ ಜೋಡಿಸಬೇಕು.
///
/// ಹೆಚ್ಚುವರಿಯಾಗಿ, ಕೊಟ್ಟಿರುವವರು ಮೆಮೊರಿಯ ನಿರ್ದಿಷ್ಟ ಪ್ರದೇಶಕ್ಕೆ `count * size_of::<T>()` ಬೈಟ್‌ಗಳನ್ನು ಬರೆಯುವುದರಿಂದ `T` ನ ಮಾನ್ಯ ಮೌಲ್ಯ ಬರುತ್ತದೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಬೇಕು.
/// `T` ನ ಅಮಾನ್ಯ ಮೌಲ್ಯವನ್ನು ಹೊಂದಿರುವ `T` ಎಂದು ಟೈಪ್ ಮಾಡಿದ ಮೆಮೊರಿಯ ಪ್ರದೇಶವನ್ನು ಬಳಸುವುದು ವಿವರಿಸಲಾಗದ ವರ್ತನೆಯಾಗಿದೆ.
///
/// ಪರಿಣಾಮಕಾರಿಯಾಗಿ ನಕಲಿಸಿದ ಗಾತ್ರವನ್ನು ಸಹ ಗಮನಿಸಿ (`ಎಣಿಕೆ * ಗಾತ್ರ_ಆಫ್: :<T>()`) `0` ಆಗಿದೆ, ಪಾಯಿಂಟರ್ NULL ಅಲ್ಲದ ಮತ್ತು ಸರಿಯಾಗಿ ಜೋಡಿಸಲ್ಪಟ್ಟಿರಬೇಕು.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// ಮೂಲ ಬಳಕೆ:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// ಅಮಾನ್ಯ ಮೌಲ್ಯವನ್ನು ರಚಿಸುವುದು:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // `Box<T>` ಅನ್ನು ಶೂನ್ಯ ಪಾಯಿಂಟರ್‌ನೊಂದಿಗೆ ತಿದ್ದಿ ಬರೆಯುವ ಮೂಲಕ ಹಿಂದೆ ಹೊಂದಿದ್ದ ಮೌಲ್ಯವನ್ನು ಸೋರಿಕೆ ಮಾಡುತ್ತದೆ.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // ಈ ಸಮಯದಲ್ಲಿ, `v` ಅನ್ನು ಬಳಸುವುದು ಅಥವಾ ಬಿಡುವುದು ಸ್ಪಷ್ಟೀಕರಿಸದ ವರ್ತನೆಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
/// // drop(v); // ERROR
///
/// // `v` "uses" ಅನ್ನು ಸಹ ಸೋರಿಕೆ ಮಾಡುವುದು, ಮತ್ತು ಆದ್ದರಿಂದ ವಿವರಿಸಲಾಗದ ನಡವಳಿಕೆ.
/// // mem::forget(v); // ERROR
///
/// // ವಾಸ್ತವವಾಗಿ, ಮೂಲ ಪ್ರಕಾರದ ಲೇ layout ಟ್ ಅಸ್ಥಿರಗಳ ಪ್ರಕಾರ `v` ಅಮಾನ್ಯವಾಗಿದೆ, ಆದ್ದರಿಂದ *ಯಾವುದೇ* ಕಾರ್ಯಾಚರಣೆಯನ್ನು ಸ್ಪರ್ಶಿಸುವುದು ಸ್ಪಷ್ಟೀಕರಿಸದ ನಡವಳಿಕೆಯಾಗಿದೆ.
/////
/// // v2 =v;//ದೋಷ
///
/// unsafe {
///     // ಬದಲಿಗೆ ಮಾನ್ಯ ಮೌಲ್ಯವನ್ನು ಇಡೋಣ
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // ಈಗ ಬಾಕ್ಸ್ ಚೆನ್ನಾಗಿದೆ
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // ಸುರಕ್ಷತೆ: `write_bytes` ಗಾಗಿ ಸುರಕ್ಷತಾ ಒಪ್ಪಂದವನ್ನು ಕರೆ ಮಾಡಿದವರು ಎತ್ತಿಹಿಡಿಯಬೇಕು.
    unsafe { write_bytes(dst, val, count) }
}