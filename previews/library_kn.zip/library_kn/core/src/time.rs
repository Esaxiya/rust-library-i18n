#![stable(feature = "duration_core", since = "1.25.0")]

//! ತಾತ್ಕಾಲಿಕ ಪ್ರಮಾಣೀಕರಣ.
//!
//! Example:
//!
//! ```
//! use std::time::Duration;
//!
//! let five_seconds = Duration::new(5, 0);
//! // ಎರಡೂ ಘೋಷಣೆಗಳು ಸಮಾನವಾಗಿವೆ
//! assert_eq!(Duration::new(5, 0), Duration::from_secs(5));
//! ```

use crate::fmt;
use crate::iter::Sum;
use crate::ops::{Add, AddAssign, Div, DivAssign, Mul, MulAssign, Sub, SubAssign};

const NANOS_PER_SEC: u32 = 1_000_000_000;
const NANOS_PER_MILLI: u32 = 1_000_000;
const NANOS_PER_MICRO: u32 = 1_000;
const MILLIS_PER_SEC: u64 = 1_000;
const MICROS_PER_SEC: u64 = 1_000_000;

/// ಸಮಯದ ಅವಧಿಯನ್ನು ಪ್ರತಿನಿಧಿಸಲು `Duration` ಪ್ರಕಾರ, ಇದನ್ನು ಸಾಮಾನ್ಯವಾಗಿ ಸಿಸ್ಟಮ್ ಕಾಲಾವಧಿಗೆ ಬಳಸಲಾಗುತ್ತದೆ.
///
/// ಪ್ರತಿ `Duration` ಸಂಪೂರ್ಣ ಸಂಖ್ಯೆಯ ಸೆಕೆಂಡುಗಳಿಂದ ಕೂಡಿದೆ ಮತ್ತು ನ್ಯಾನೊ ಸೆಕೆಂಡುಗಳಲ್ಲಿ ಪ್ರತಿನಿಧಿಸುವ ಭಾಗಶಃ ಭಾಗವಾಗಿದೆ.
/// ಆಧಾರವಾಗಿರುವ ವ್ಯವಸ್ಥೆಯು ನ್ಯಾನೊಸೆಕೆಂಡ್-ಮಟ್ಟದ ನಿಖರತೆಯನ್ನು ಬೆಂಬಲಿಸದಿದ್ದರೆ, ಸಿಸ್ಟಮ್ ಸಮಯ ಮೀರುವಿಕೆಯನ್ನು ಬಂಧಿಸುವ API ಗಳು ಸಾಮಾನ್ಯವಾಗಿ ನ್ಯಾನೊ ಸೆಕೆಂಡುಗಳ ಸಂಖ್ಯೆಯನ್ನು ಪೂರ್ಣಗೊಳಿಸುತ್ತವೆ.
///
/// [`ಅವಧಿ] [`Add`], [`Sub`], ಮತ್ತು ಇತರ [`ops`] traits ಸೇರಿದಂತೆ ಅನೇಕ ಸಾಮಾನ್ಯ traits ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.ಇದು ಶೂನ್ಯ-ಉದ್ದದ `Duration` ಅನ್ನು ಹಿಂದಿರುಗಿಸುವ ಮೂಲಕ [`Default`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
///
/// [`ops`]: crate::ops
///
/// # Examples
///
/// ```
/// use std::time::Duration;
///
/// let five_seconds = Duration::new(5, 0);
/// let five_seconds_and_five_nanos = five_seconds + Duration::new(0, 5);
///
/// assert_eq!(five_seconds_and_five_nanos.as_secs(), 5);
/// assert_eq!(five_seconds_and_five_nanos.subsec_nanos(), 5);
///
/// let ten_millis = Duration::from_millis(10);
/// ```
///
/// # `Duration` ಮೌಲ್ಯಗಳನ್ನು ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಲಾಗುತ್ತಿದೆ
///
/// `Duration` ಉದ್ದೇಶಪೂರ್ವಕವಾಗಿ `Display` ಇಂಪ್ಲ್ ಅನ್ನು ಹೊಂದಿಲ್ಲ, ಏಕೆಂದರೆ ಮಾನವನ ಓದುವಿಕೆಗಾಗಿ ಸಮಯದ ಅವಧಿಗಳನ್ನು ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಲು ವಿವಿಧ ಮಾರ್ಗಗಳಿವೆ.
/// `Duration` `Debug` impl ಅನ್ನು ಒದಗಿಸುತ್ತದೆ ಅದು ಮೌಲ್ಯದ ಸಂಪೂರ್ಣ ನಿಖರತೆಯನ್ನು ತೋರಿಸುತ್ತದೆ.
///
/// `Debug` output ಟ್‌ಪುಟ್ ಮೈಕ್ರೊ ಸೆಕೆಂಡುಗಳಿಗಾಗಿ ASCII ಅಲ್ಲದ "µs" ಪ್ರತ್ಯಯವನ್ನು ಬಳಸುತ್ತದೆ.
/// ನಿಮ್ಮ ಪ್ರೋಗ್ರಾಂ output ಟ್‌ಪುಟ್ ಪೂರ್ಣ ಯುನಿಕೋಡ್ ಹೊಂದಾಣಿಕೆಯನ್ನು ಅವಲಂಬಿಸದ ಸಂದರ್ಭಗಳಲ್ಲಿ ಕಾಣಿಸಿಕೊಂಡರೆ, ನೀವು `Duration` ಆಬ್ಜೆಕ್ಟ್‌ಗಳನ್ನು ನೀವೇ ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡಲು ಬಯಸಬಹುದು ಅಥವಾ ಹಾಗೆ ಮಾಡಲು crate ಅನ್ನು ಬಳಸಬಹುದು.
///
///
///
///
///
///
///
#[stable(feature = "duration", since = "1.3.0")]
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Default)]
pub struct Duration {
    secs: u64,
    nanos: u32, // ಯಾವಾಗಲೂ 0 <=ನ್ಯಾನೊಗಳು <NANOS_PER_SEC
}

impl Duration {
    /// ಒಂದು ಸೆಕೆಂಡಿನ ಅವಧಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::SECOND, Duration::from_secs(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const SECOND: Duration = Duration::from_secs(1);

    /// ಒಂದು ಮಿಲಿಸೆಕೆಂಡ್ ಅವಧಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MILLISECOND, Duration::from_millis(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MILLISECOND: Duration = Duration::from_millis(1);

    /// ಒಂದು ಮೈಕ್ರೋಸೆಕೆಂಡ್ ಅವಧಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MICROSECOND, Duration::from_micros(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MICROSECOND: Duration = Duration::from_micros(1);

    /// ಒಂದು ನ್ಯಾನೊ ಸೆಕೆಂಡ್‌ನ ಅವಧಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::NANOSECOND, Duration::from_nanos(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const NANOSECOND: Duration = Duration::from_nanos(1);

    /// ಶೂನ್ಯ ಸಮಯದ ಅವಧಿ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// let duration = Duration::ZERO;
    /// assert!(duration.is_zero());
    /// assert_eq!(duration.as_nanos(), 0);
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    pub const ZERO: Duration = Duration::from_nanos(0);

    /// ಗರಿಷ್ಠ ಅವಧಿ.
    ///
    /// ಇದು ಸರಿಸುಮಾರು 584,942,417,355 ವರ್ಷಗಳ ಅವಧಿಗೆ ಸಮಾನವಾಗಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MAX, Duration::new(u64::MAX, 1_000_000_000 - 1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MAX: Duration = Duration::new(u64::MAX, NANOS_PER_SEC - 1);

    /// ನಿಗದಿತ ಸಂಖ್ಯೆಯ ಸಂಪೂರ್ಣ ಸೆಕೆಂಡುಗಳು ಮತ್ತು ಹೆಚ್ಚುವರಿ ನ್ಯಾನೊ ಸೆಕೆಂಡುಗಳಿಂದ ಹೊಸ `Duration` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// ನ್ಯಾನೊ ಸೆಕೆಂಡುಗಳ ಸಂಖ್ಯೆ 1 ಬಿಲಿಯನ್ ಗಿಂತ ಹೆಚ್ಚಿದ್ದರೆ (ಸೆಕೆಂಡಿನಲ್ಲಿ ನ್ಯಾನೊ ಸೆಕೆಂಡುಗಳ ಸಂಖ್ಯೆ), ಅದು ಒದಗಿಸಿದ ಸೆಕೆಂಡುಗಳಲ್ಲಿ ಸಾಗುತ್ತದೆ.
    ///
    ///
    /// # Panics
    ///
    /// ನ್ಯಾನೊ ಸೆಕೆಂಡುಗಳಿಂದ ಕ್ಯಾರಿ ಸೆಕೆಂಡುಗಳ ಕೌಂಟರ್ ಅನ್ನು ಉಕ್ಕಿ ಹರಿಯುತ್ತಿದ್ದರೆ ಈ ಕನ್‌ಸ್ಟ್ರಕ್ಟರ್ panic ಆಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let five_seconds = Duration::new(5, 0);
    /// ```
    ///
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn new(secs: u64, nanos: u32) -> Duration {
        let secs = match secs.checked_add((nanos / NANOS_PER_SEC) as u64) {
            Some(secs) => secs,
            None => panic!("overflow in Duration::new"),
        };
        let nanos = nanos % NANOS_PER_SEC;
        Duration { secs, nanos }
    }

    /// ನಿಗದಿತ ಸಂಖ್ಯೆಯ ಸಂಪೂರ್ಣ ಸೆಕೆಂಡುಗಳಿಂದ ಹೊಸ `Duration` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_secs(5);
    ///
    /// assert_eq!(5, duration.as_secs());
    /// assert_eq!(0, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_secs(secs: u64) -> Duration {
        Duration { secs, nanos: 0 }
    }

    /// ನಿಗದಿತ ಸಂಖ್ಯೆಯ ಮಿಲಿಸೆಕೆಂಡುಗಳಿಂದ ಹೊಸ `Duration` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(2569);
    ///
    /// assert_eq!(2, duration.as_secs());
    /// assert_eq!(569_000_000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_millis(millis: u64) -> Duration {
        Duration {
            secs: millis / MILLIS_PER_SEC,
            nanos: ((millis % MILLIS_PER_SEC) as u32) * NANOS_PER_MILLI,
        }
    }

    /// ನಿಗದಿತ ಸಂಖ್ಯೆಯ ಮೈಕ್ರೊ ಸೆಕೆಂಡುಗಳಿಂದ ಹೊಸ `Duration` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_000_002);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(2000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_from_micros", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_micros(micros: u64) -> Duration {
        Duration {
            secs: micros / MICROS_PER_SEC,
            nanos: ((micros % MICROS_PER_SEC) as u32) * NANOS_PER_MICRO,
        }
    }

    /// ನಿಗದಿತ ಸಂಖ್ಯೆಯ ನ್ಯಾನೊ ಸೆಕೆಂಡುಗಳಿಂದ ಹೊಸ `Duration` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_nanos(1_000_000_123);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(123, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_nanos(nanos: u64) -> Duration {
        Duration {
            secs: nanos / (NANOS_PER_SEC as u64),
            nanos: (nanos % (NANOS_PER_SEC as u64)) as u32,
        }
    }

    /// ಈ `Duration` ಸಮಯವಿಲ್ಲದಿದ್ದರೆ ನಿಜವನ್ನು ನೀಡುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert!(Duration::ZERO.is_zero());
    /// assert!(Duration::new(0, 0).is_zero());
    /// assert!(Duration::from_nanos(0).is_zero());
    /// assert!(Duration::from_secs(0).is_zero());
    ///
    /// assert!(!Duration::new(1, 1).is_zero());
    /// assert!(!Duration::from_nanos(1).is_zero());
    /// assert!(!Duration::from_secs(1).is_zero());
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    #[inline]
    pub const fn is_zero(&self) -> bool {
        self.secs == 0 && self.nanos == 0
    }

    /// ಈ `Duration` ಒಳಗೊಂಡಿರುವ _whole_ ಸೆಕೆಂಡುಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಹಿಂದಿರುಗಿದ ಮೌಲ್ಯವು ಅವಧಿಯ ಭಾಗಶಃ (nanosecond) ಭಾಗವನ್ನು ಒಳಗೊಂಡಿಲ್ಲ, ಇದನ್ನು [`subsec_nanos`] ಬಳಸಿ ಪಡೆಯಬಹುದು.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_secs(), 5);
    /// ```
    ///
    /// `Duration` ಪ್ರತಿನಿಧಿಸುವ ಒಟ್ಟು ಸೆಕೆಂಡುಗಳ ಸಂಖ್ಯೆಯನ್ನು ನಿರ್ಧರಿಸಲು, [`subsec_nanos`] ನೊಂದಿಗೆ `as_secs` ಅನ್ನು ಬಳಸಿ:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    ///
    /// assert_eq!(5.730023852,
    ///            duration.as_secs() as f64
    ///            + duration.subsec_nanos() as f64 * 1e-9);
    /// ```
    ///
    /// [`subsec_nanos`]: Duration::subsec_nanos
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn as_secs(&self) -> u64 {
        self.secs
    }

    /// ಈ `Duration` ನ ಭಾಗಶಃ ಭಾಗವನ್ನು ಸಂಪೂರ್ಣ ಮಿಲಿಸೆಕೆಂಡುಗಳಲ್ಲಿ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ವಿಧಾನವು ಮಿಲಿಸೆಕೆಂಡುಗಳಿಂದ ಪ್ರತಿನಿಧಿಸಿದಾಗ ಅವಧಿಯ ಉದ್ದವನ್ನು ** ಹಿಂದಿರುಗಿಸುವುದಿಲ್ಲ.
    /// ಹಿಂದಿರುಗಿದ ಸಂಖ್ಯೆ ಯಾವಾಗಲೂ ಸೆಕೆಂಡಿನ ಭಾಗಶಃ ಭಾಗವನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ (ಅಂದರೆ, ಇದು ಒಂದು ಸಾವಿರಕ್ಕಿಂತ ಕಡಿಮೆ).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5432);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_millis(), 432);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_millis(&self) -> u32 {
        self.nanos / NANOS_PER_MILLI
    }

    /// ಈ `Duration` ನ ಭಾಗಶಃ ಭಾಗವನ್ನು ಸಂಪೂರ್ಣ ಮೈಕ್ರೊ ಸೆಕೆಂಡುಗಳಲ್ಲಿ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಮೈಕ್ರೊ ಸೆಕೆಂಡುಗಳಿಂದ ಪ್ರತಿನಿಧಿಸುವಾಗ ಈ ವಿಧಾನವು ** ಅವಧಿಯನ್ನು ಹಿಂತಿರುಗಿಸುವುದಿಲ್ಲ.
    /// ಹಿಂದಿರುಗಿದ ಸಂಖ್ಯೆ ಯಾವಾಗಲೂ ಸೆಕೆಂಡಿನ ಭಾಗಶಃ ಭಾಗವನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ (ಅಂದರೆ, ಇದು ಒಂದು ದಶಲಕ್ಷಕ್ಕಿಂತ ಕಡಿಮೆ).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_234_567);
    /// assert_eq!(duration.as_secs(), 1);
    /// assert_eq!(duration.subsec_micros(), 234_567);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_micros(&self) -> u32 {
        self.nanos / NANOS_PER_MICRO
    }

    /// ಈ `Duration` ನ ಭಾಗಶಃ ಭಾಗವನ್ನು ನ್ಯಾನೊ ಸೆಕೆಂಡುಗಳಲ್ಲಿ ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// ಈ ವಿಧಾನವು ನ್ಯಾನೊ ಸೆಕೆಂಡುಗಳಿಂದ ಪ್ರತಿನಿಧಿಸುವಾಗ ಅವಧಿಯ ಉದ್ದವನ್ನು ** ಹಿಂದಿರುಗಿಸುವುದಿಲ್ಲ.
    /// ಹಿಂದಿರುಗಿದ ಸಂಖ್ಯೆ ಯಾವಾಗಲೂ ಸೆಕೆಂಡಿನ ಭಾಗಶಃ ಭಾಗವನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ (ಅಂದರೆ, ಇದು ಒಂದು ಶತಕೋಟಿಗಿಂತ ಕಡಿಮೆ).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5010);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_nanos(), 10_000_000);
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn subsec_nanos(&self) -> u32 {
        self.nanos
    }

    /// ಈ `Duration` ಒಳಗೊಂಡಿರುವ ಒಟ್ಟು ಮಿಲಿಸೆಕೆಂಡುಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_millis(), 5730);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_millis(&self) -> u128 {
        self.secs as u128 * MILLIS_PER_SEC as u128 + (self.nanos / NANOS_PER_MILLI) as u128
    }

    /// ಈ `Duration` ಒಳಗೊಂಡಿರುವ ಒಟ್ಟು ಮೈಕ್ರೊ ಸೆಕೆಂಡುಗಳ ಒಟ್ಟು ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_micros(), 5730023);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_micros(&self) -> u128 {
        self.secs as u128 * MICROS_PER_SEC as u128 + (self.nanos / NANOS_PER_MICRO) as u128
    }

    /// ಈ `Duration` ಒಳಗೊಂಡಿರುವ ಒಟ್ಟು ನ್ಯಾನೊ ಸೆಕೆಂಡುಗಳ ಸಂಖ್ಯೆಯನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_nanos(), 5730023852);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_nanos(&self) -> u128 {
        self.secs as u128 * NANOS_PER_SEC as u128 + self.nanos as u128
    }

    /// `Duration` ಸೇರ್ಪಡೆ ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
    /// `self + other` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಓವರ್‌ಫ್ಲೋ ಸಂಭವಿಸಿದಲ್ಲಿ [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).checked_add(Duration::new(0, 1)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(1, 0).checked_add(Duration::new(u64::MAX, 0)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_add(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_add(rhs.secs) {
            let mut nanos = self.nanos + rhs.nanos;
            if nanos >= NANOS_PER_SEC {
                nanos -= NANOS_PER_SEC;
                if let Some(new_secs) = secs.checked_add(1) {
                    secs = new_secs;
                } else {
                    return None;
                }
            }
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// ಸ್ಯಾಚುರೇಟಿಂಗ್ `Duration` ಸೇರ್ಪಡೆ.
    /// `self + other` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಓವರ್‌ಫ್ಲೋ ಸಂಭವಿಸಿದಲ್ಲಿ [`Duration::MAX`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).saturating_add(Duration::new(0, 1)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(1, 0).saturating_add(Duration::new(u64::MAX, 0)), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_add(self, rhs: Duration) -> Duration {
        match self.checked_add(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// `Duration` ವ್ಯವಕಲನವನ್ನು ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
    /// ಫಲಿತಾಂಶವು negative ಣಾತ್ಮಕವಾಗಿದ್ದರೆ ಅಥವಾ ಉಕ್ಕಿ ಹರಿಯುವುದಾದರೆ `self - other` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, [`None`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).checked_sub(Duration::new(0, 0)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(0, 0).checked_sub(Duration::new(0, 1)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_sub(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_sub(rhs.secs) {
            let nanos = if self.nanos >= rhs.nanos {
                self.nanos - rhs.nanos
            } else {
                if let Some(sub_secs) = secs.checked_sub(1) {
                    secs = sub_secs;
                    self.nanos + NANOS_PER_SEC - rhs.nanos
                } else {
                    return None;
                }
            };
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// ಸ್ಯಾಚುರೇಟಿಂಗ್ `Duration` ವ್ಯವಕಲನ.
    /// ಫಲಿತಾಂಶವು negative ಣಾತ್ಮಕವಾಗಿದ್ದರೆ ಅಥವಾ ಉಕ್ಕಿ ಹರಿಯುವುದಾದರೆ `self - other` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, [`Duration::ZERO`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).saturating_sub(Duration::new(0, 0)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(0, 0).saturating_sub(Duration::new(0, 1)), Duration::ZERO);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_sub(self, rhs: Duration) -> Duration {
        match self.checked_sub(rhs) {
            Some(res) => res,
            None => Duration::ZERO,
        }
    }

    /// `Duration` ಗುಣಾಕಾರವನ್ನು ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
    /// `self * other` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಓವರ್‌ಫ್ಲೋ ಸಂಭವಿಸಿದಲ್ಲಿ [`None`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).checked_mul(2), Some(Duration::new(1, 2)));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).checked_mul(2), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_mul(self, rhs: u32) -> Option<Duration> {
        // ನ್ಯಾನೊ ಸೆಕೆಂಡುಗಳನ್ನು u64 ಎಂದು ಗುಣಿಸಿ, ಏಕೆಂದರೆ ಅದು ಆ ರೀತಿಯಲ್ಲಿ ಉಕ್ಕಿ ಹರಿಯಲು ಸಾಧ್ಯವಿಲ್ಲ.
        let total_nanos = self.nanos as u64 * rhs as u64;
        let extra_secs = total_nanos / (NANOS_PER_SEC as u64);
        let nanos = (total_nanos % (NANOS_PER_SEC as u64)) as u32;
        if let Some(s) = self.secs.checked_mul(rhs as u64) {
            if let Some(secs) = s.checked_add(extra_secs) {
                debug_assert!(nanos < NANOS_PER_SEC);
                return Some(Duration { secs, nanos });
            }
        }
        None
    }

    /// ಸ್ಯಾಚುರೇಟಿಂಗ್ `Duration` ಗುಣಾಕಾರ.
    /// `self * other` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, ಓವರ್‌ಫ್ಲೋ ಸಂಭವಿಸಿದಲ್ಲಿ [`Duration::MAX`] ಅನ್ನು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).saturating_mul(2), Duration::new(1, 2));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).saturating_mul(2), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_mul(self, rhs: u32) -> Duration {
        match self.checked_mul(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// `Duration` ವಿಭಾಗವನ್ನು ಪರಿಶೀಲಿಸಲಾಗಿದೆ.
    /// `self / other` ಅನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುತ್ತದೆ, `other == 0` ಆಗಿದ್ದರೆ [`None`] ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ಮೂಲ ಬಳಕೆ:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(2, 0).checked_div(2), Some(Duration::new(1, 0)));
    /// assert_eq!(Duration::new(1, 0).checked_div(2), Some(Duration::new(0, 500_000_000)));
    /// assert_eq!(Duration::new(2, 0).checked_div(0), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_div(self, rhs: u32) -> Option<Duration> {
        if rhs != 0 {
            let secs = self.secs / (rhs as u64);
            let carry = self.secs - secs * (rhs as u64);
            let extra_nanos = carry * (NANOS_PER_SEC as u64) / (rhs as u64);
            let nanos = self.nanos / rhs + (extra_nanos as u32);
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// ಈ `Duration` ಒಳಗೊಂಡಿರುವ ಸೆಕೆಂಡುಗಳ ಸಂಖ್ಯೆಯನ್ನು `f64` ಎಂದು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಹಿಂದಿರುಗಿದ ಮೌಲ್ಯವು ಅವಧಿಯ ಭಾಗಶಃ (nanosecond) ಭಾಗವನ್ನು ಒಳಗೊಂಡಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f64(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f64(&self) -> f64 {
        (self.secs as f64) + (self.nanos as f64) / (NANOS_PER_SEC as f64)
    }

    /// ಈ `Duration` ಒಳಗೊಂಡಿರುವ ಸೆಕೆಂಡುಗಳ ಸಂಖ್ಯೆಯನ್ನು `f32` ಎಂದು ಹಿಂತಿರುಗಿಸುತ್ತದೆ.
    /// ಹಿಂದಿರುಗಿದ ಮೌಲ್ಯವು ಅವಧಿಯ ಭಾಗಶಃ (nanosecond) ಭಾಗವನ್ನು ಒಳಗೊಂಡಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f32(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f32(&self) -> f32 {
        (self.secs as f32) + (self.nanos as f32) / (NANOS_PER_SEC as f32)
    }

    /// `f64` ಎಂದು ಪ್ರತಿನಿಧಿಸುವ ನಿರ್ದಿಷ್ಟ ಸಂಖ್ಯೆಯ ಸೆಕೆಂಡುಗಳಿಂದ ಹೊಸ `Duration` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Panics
    /// `secs` ಸೀಮಿತ, negative ಣಾತ್ಮಕ ಅಥವಾ `Duration` ಅನ್ನು ಉಕ್ಕಿ ಹರಿಯದಿದ್ದರೆ ಈ ಕನ್‌ಸ್ಟ್ರಕ್ಟರ್ panic ಆಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f64(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f64(secs: f64) -> Duration {
        const MAX_NANOS_F64: f64 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f64;
        let nanos = secs * (NANOS_PER_SEC as f64);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F64 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// `f32` ಎಂದು ಪ್ರತಿನಿಧಿಸುವ ನಿರ್ದಿಷ್ಟ ಸಂಖ್ಯೆಯ ಸೆಕೆಂಡುಗಳಿಂದ ಹೊಸ `Duration` ಅನ್ನು ರಚಿಸುತ್ತದೆ.
    ///
    /// # Panics
    /// `secs` ಸೀಮಿತ, negative ಣಾತ್ಮಕ ಅಥವಾ `Duration` ಅನ್ನು ಉಕ್ಕಿ ಹರಿಯದಿದ್ದರೆ ಈ ಕನ್‌ಸ್ಟ್ರಕ್ಟರ್ panic ಆಗುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f32(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f32(secs: f32) -> Duration {
        const MAX_NANOS_F32: f32 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f32;
        let nanos = secs * (NANOS_PER_SEC as f32);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F32 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// `f64` ನಿಂದ `Duration` ಅನ್ನು ಗುಣಿಸುತ್ತದೆ.
    /// # Panics
    /// ಫಲಿತಾಂಶವು ಸೀಮಿತ, negative ಣಾತ್ಮಕ ಅಥವಾ `Duration` ಅನ್ನು ಉಕ್ಕಿ ಹರಿಯದಿದ್ದರೆ ಈ ವಿಧಾನವು panic ಆಗಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.mul_f64(3.14), Duration::new(8, 478_000_000));
    /// assert_eq!(dur.mul_f64(3.14e5), Duration::new(847_800, 0));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(rhs * self.as_secs_f64())
    }

    /// `f32` ನಿಂದ `Duration` ಅನ್ನು ಗುಣಿಸುತ್ತದೆ.
    /// # Panics
    /// ಫಲಿತಾಂಶವು ಸೀಮಿತ, negative ಣಾತ್ಮಕ ಅಥವಾ `Duration` ಅನ್ನು ಉಕ್ಕಿ ಹರಿಯದಿದ್ದರೆ ಈ ವಿಧಾನವು panic ಆಗಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // ಪೂರ್ಣಾಂಕದ ದೋಷಗಳಿಂದಾಗಿ ಫಲಿತಾಂಶವು 8.478 ಮತ್ತು 847800.0 ಗಿಂತ ಸ್ವಲ್ಪ ಭಿನ್ನವಾಗಿರುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ
    /////
    /// assert_eq!(dur.mul_f32(3.14), Duration::new(8, 478_000_640));
    /// assert_eq!(dur.mul_f32(3.14e5), Duration::new(847799, 969_120_256));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(rhs * self.as_secs_f32())
    }

    /// `Duration` ಅನ್ನು `f64` ನಿಂದ ಭಾಗಿಸಿ.
    /// # Panics
    /// ಫಲಿತಾಂಶವು ಸೀಮಿತ, negative ಣಾತ್ಮಕ ಅಥವಾ `Duration` ಅನ್ನು ಉಕ್ಕಿ ಹರಿಯದಿದ್ದರೆ ಈ ವಿಧಾನವು panic ಆಗಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.div_f64(3.14), Duration::new(0, 859_872_611));
    /// // ಮೊಟಕುಗೊಳಿಸುವಿಕೆಯನ್ನು ಬಳಸಲಾಗಿದೆಯೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ
    /// assert_eq!(dur.div_f64(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(self.as_secs_f64() / rhs)
    }

    /// `Duration` ಅನ್ನು `f32` ನಿಂದ ಭಾಗಿಸಿ.
    /// # Panics
    /// ಫಲಿತಾಂಶವು ಸೀಮಿತ, negative ಣಾತ್ಮಕ ಅಥವಾ `Duration` ಅನ್ನು ಉಕ್ಕಿ ಹರಿಯದಿದ್ದರೆ ಈ ವಿಧಾನವು panic ಆಗಿರುತ್ತದೆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // ಪೂರ್ಣಾಂಕದ ದೋಷಗಳ ಫಲಿತಾಂಶವು 0.859_872_611 ಗಿಂತ ಸ್ವಲ್ಪ ಭಿನ್ನವಾಗಿರುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ
    /////
    /// assert_eq!(dur.div_f32(3.14), Duration::new(0, 859_872_576));
    /// // ಮೊಟಕುಗೊಳಿಸುವಿಕೆಯನ್ನು ಬಳಸಲಾಗಿದೆಯೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ
    /// assert_eq!(dur.div_f32(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(self.as_secs_f32() / rhs)
    }

    /// `Duration` ಅನ್ನು `Duration` ನಿಂದ ಭಾಗಿಸಿ ಮತ್ತು `f64` ಅನ್ನು ಹಿಂತಿರುಗಿ.
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f64(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f64(self, rhs: Duration) -> f64 {
        self.as_secs_f64() / rhs.as_secs_f64()
    }

    /// `Duration` ಅನ್ನು `Duration` ನಿಂದ ಭಾಗಿಸಿ ಮತ್ತು `f32` ಅನ್ನು ಹಿಂತಿರುಗಿ.
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f32(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f32(self, rhs: Duration) -> f32 {
        self.as_secs_f32() / rhs.as_secs_f32()
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Add for Duration {
    type Output = Duration;

    fn add(self, rhs: Duration) -> Duration {
        self.checked_add(rhs).expect("overflow when adding durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl AddAssign for Duration {
    fn add_assign(&mut self, rhs: Duration) {
        *self = *self + rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Sub for Duration {
    type Output = Duration;

    fn sub(self, rhs: Duration) -> Duration {
        self.checked_sub(rhs).expect("overflow when subtracting durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl SubAssign for Duration {
    fn sub_assign(&mut self, rhs: Duration) {
        *self = *self - rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Mul<u32> for Duration {
    type Output = Duration;

    fn mul(self, rhs: u32) -> Duration {
        self.checked_mul(rhs).expect("overflow when multiplying duration by scalar")
    }
}

#[stable(feature = "symmetric_u32_duration_mul", since = "1.31.0")]
impl Mul<Duration> for u32 {
    type Output = Duration;

    fn mul(self, rhs: Duration) -> Duration {
        rhs * self
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl MulAssign<u32> for Duration {
    fn mul_assign(&mut self, rhs: u32) {
        *self = *self * rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Div<u32> for Duration {
    type Output = Duration;

    fn div(self, rhs: u32) -> Duration {
        self.checked_div(rhs).expect("divide by zero error when dividing duration by scalar")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl DivAssign<u32> for Duration {
    fn div_assign(&mut self, rhs: u32) {
        *self = *self / rhs;
    }
}

macro_rules! sum_durations {
    ($iter:expr) => {{
        let mut total_secs: u64 = 0;
        let mut total_nanos: u64 = 0;

        for entry in $iter {
            total_secs =
                total_secs.checked_add(entry.secs).expect("overflow in iter::sum over durations");
            total_nanos = match total_nanos.checked_add(entry.nanos as u64) {
                Some(n) => n,
                None => {
                    total_secs = total_secs
                        .checked_add(total_nanos / NANOS_PER_SEC as u64)
                        .expect("overflow in iter::sum over durations");
                    (total_nanos % NANOS_PER_SEC as u64) + entry.nanos as u64
                }
            };
        }
        total_secs = total_secs
            .checked_add(total_nanos / NANOS_PER_SEC as u64)
            .expect("overflow in iter::sum over durations");
        total_nanos = total_nanos % NANOS_PER_SEC as u64;
        Duration { secs: total_secs, nanos: total_nanos as u32 }
    }};
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl Sum for Duration {
    fn sum<I: Iterator<Item = Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl<'a> Sum<&'a Duration> for Duration {
    fn sum<I: Iterator<Item = &'a Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_debug_impl", since = "1.27.0")]
impl fmt::Debug for Duration {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        /// ದಶಮಾಂಶ ಸಂಕೇತದಲ್ಲಿ ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಸಂಖ್ಯೆಯನ್ನು ಫಾರ್ಮ್ಯಾಟ್ ಮಾಡುತ್ತದೆ.
        ///
        /// ಸಂಖ್ಯೆಯನ್ನು `integer_part` ಮತ್ತು ಭಾಗಶಃ ಭಾಗವಾಗಿ ನೀಡಲಾಗಿದೆ.
        /// ಭಾಗಶಃ ಭಾಗದ ಮೌಲ್ಯ `fractional_part / divisor` ಆಗಿದೆ.
        /// ಆದ್ದರಿಂದ `integer_part` =3, `fractional_part` =12 ಮತ್ತು `divisor` =100 `3.012` ಸಂಖ್ಯೆಯನ್ನು ಪ್ರತಿನಿಧಿಸುತ್ತದೆ.
        /// ಹಿಂದುಳಿದ ಸೊನ್ನೆಗಳನ್ನು ಬಿಟ್ಟುಬಿಡಲಾಗಿದೆ.
        ///
        /// `divisor` 100_000_000 ಗಿಂತ ಹೆಚ್ಚಿರಬಾರದು.
        /// ಇದು 10 ರ ಶಕ್ತಿಯಾಗಿರಬೇಕು, ಉಳಿದಂತೆ ಅರ್ಥವಿಲ್ಲ.
        /// `fractional_part` `10 * divisor` ಗಿಂತ ಕಡಿಮೆಯಿರಬೇಕು!
        fn fmt_decimal(
            f: &mut fmt::Formatter<'_>,
            mut integer_part: u64,
            mut fractional_part: u32,
            mut divisor: u32,
        ) -> fmt::Result {
            // ಭಾಗಶಃ ಭಾಗವನ್ನು ತಾತ್ಕಾಲಿಕ ಬಫರ್‌ಗೆ ಎನ್‌ಕೋಡ್ ಮಾಡಿ.
            // ಬಫರ್ ಕೇವಲ 9 ಅಂಶಗಳನ್ನು ಹಿಡಿದಿಟ್ಟುಕೊಳ್ಳಬೇಕು, ಏಕೆಂದರೆ `fractional_part` 10 ^ 9 ಗಿಂತ ಚಿಕ್ಕದಾಗಿರಬೇಕು.
            //
            // ಕೆಳಗಿನ ಕೋಡ್ ಅನ್ನು ಸರಳೀಕರಿಸಲು ಬಫರ್ ಅನ್ನು '0' ಅಂಕೆಗಳೊಂದಿಗೆ ತುಂಬಿಸಲಾಗುತ್ತದೆ.
            let mut buf = [b'0'; 9];

            // ಮುಂದಿನ ಅಂಕಿಯನ್ನು ಈ ಸ್ಥಾನದಲ್ಲಿ ಬರೆಯಲಾಗಿದೆ
            let mut pos = 0;

            // ಶೂನ್ಯೇತರ ಅಂಕೆಗಳು ಉಳಿದಿರುವಾಗ ನಾವು ಬಫರ್‌ಗೆ ಅಂಕೆಗಳನ್ನು ಬರೆಯುತ್ತಲೇ ಇರುತ್ತೇವೆ ಮತ್ತು ನಾವು ಇನ್ನೂ ಸಾಕಷ್ಟು ಅಂಕೆಗಳನ್ನು ಬರೆದಿಲ್ಲ.
            //
            while fractional_part > 0 && pos < f.precision().unwrap_or(9) {
                // ಬಫರ್‌ಗೆ ಹೊಸ ಅಂಕೆ ಬರೆಯಿರಿ
                buf[pos] = b'0' + (fractional_part / divisor) as u8;

                fractional_part %= divisor;
                divisor /= 10;
                pos += 1;
            }

            // ನಿಖರತೆ <9 ಅನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಿದರೆ, ಬಫರ್‌ನಲ್ಲಿ ಬರೆಯದ ಕೆಲವು ಶೂನ್ಯೇತರ ಅಂಕೆಗಳು ಉಳಿದಿರಬಹುದು.
            // ಅಂತಹ ಸಂದರ್ಭದಲ್ಲಿ ಸಾಮಾನ್ಯ ಫ್ಲೋಟಿಂಗ್ ಪಾಯಿಂಟ್ ಸಂಖ್ಯೆಗಳನ್ನು ಮುದ್ರಿಸುವ ಶಬ್ದಾರ್ಥಕ್ಕೆ ಹೊಂದಿಸಲು ನಾವು ಪೂರ್ಣಾಂಕವನ್ನು ಮಾಡಬೇಕಾಗಿದೆ.
            // ಹೇಗಾದರೂ, ನಾವು ಪೂರ್ಣಗೊಳಿಸುವಾಗ ಮಾತ್ರ ಕೆಲಸ ಮಾಡಬೇಕಾಗಿದೆ.
            // ಉಳಿದವುಗಳ ಮೊದಲ ಅಂಕಿಯು>=5 ಆಗಿದ್ದರೆ ಇದು ಸಂಭವಿಸುತ್ತದೆ.
            //
            //
            if fractional_part > 0 && fractional_part >= divisor * 5 {
                // ಬಫರ್‌ನಲ್ಲಿರುವ ಸಂಖ್ಯೆಯನ್ನು ಪೂರ್ಣಗೊಳಿಸಿ.
                // ನಾವು ಬಫರ್ ಮೂಲಕ ಹಿಂದಕ್ಕೆ ಹೋಗುತ್ತೇವೆ ಮತ್ತು ಕ್ಯಾರಿಯನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡುತ್ತೇವೆ.
                let mut rev_pos = pos;
                let mut carry = true;
                while carry && rev_pos > 0 {
                    rev_pos -= 1;

                    // ಬಫರ್‌ನಲ್ಲಿನ ಅಂಕಿಯು '9' ಅಲ್ಲದಿದ್ದರೆ, ನಾವು ಅದನ್ನು ಹೆಚ್ಚಿಸಬೇಕಾಗಿದೆ ಮತ್ತು ನಂತರ ನಿಲ್ಲಿಸಬಹುದು (ನಮಗೆ ಇನ್ನು ಮುಂದೆ ಕ್ಯಾರಿ ಇಲ್ಲದಿರುವುದರಿಂದ).
                    // ಇಲ್ಲದಿದ್ದರೆ, ನಾವು ಅದನ್ನು '0' (overflow) ಗೆ ಹೊಂದಿಸಿ ಮುಂದುವರಿಸುತ್ತೇವೆ.
                    //
                    //
                    if buf[rev_pos] < b'9' {
                        buf[rev_pos] += 1;
                        carry = false;
                    } else {
                        buf[rev_pos] = b'0';
                    }
                }

                // ನಾವು ಇನ್ನೂ ಕ್ಯಾರಿ ಬಿಟ್ ಸೆಟ್ ಹೊಂದಿದ್ದರೆ, ಇದರರ್ಥ ನಾವು ಇಡೀ ಬಫರ್ ಅನ್ನು '0'ಗಳಿಗೆ ಹೊಂದಿಸುತ್ತೇವೆ ಮತ್ತು ಪೂರ್ಣಾಂಕ ಭಾಗವನ್ನು ಹೆಚ್ಚಿಸುವ ಅಗತ್ಯವಿದೆ.
                //
                //
                if carry {
                    integer_part += 1;
                }
            }

            // ಬಫರ್‌ನ ಅಂತ್ಯವನ್ನು ನಿರ್ಧರಿಸಿ: ನಿಖರತೆಯನ್ನು ಹೊಂದಿಸಿದ್ದರೆ, ನಾವು ಬಫರ್‌ನಿಂದ ಎಷ್ಟು ಅಂಕೆಗಳನ್ನು ಬಳಸುತ್ತೇವೆ (9 ಕ್ಕೆ ಮುಚ್ಚಲಾಗಿದೆ).
            // ಇದನ್ನು ಹೊಂದಿಸದಿದ್ದರೆ, ಕೊನೆಯ ಶೂನ್ಯವಲ್ಲದವರೆಗಿನ ಎಲ್ಲಾ ಅಂಕೆಗಳನ್ನು ಮಾತ್ರ ನಾವು ಬಳಸುತ್ತೇವೆ.
            //
            let end = f.precision().map(|p| crate::cmp::min(p, 9)).unwrap_or(pos);

            // ನಾವು ಒಂದು ಭಾಗಶಃ ಅಂಕಿಯನ್ನು ಹೊರಸೂಸದಿದ್ದರೆ ಮತ್ತು ನಿಖರತೆಯನ್ನು ಶೂನ್ಯೇತರ ಮೌಲ್ಯಕ್ಕೆ ಹೊಂದಿಸದಿದ್ದರೆ, ನಾವು ದಶಮಾಂಶ ಬಿಂದುವನ್ನು ಮುದ್ರಿಸುವುದಿಲ್ಲ.
            //
            if end == 0 {
                write!(f, "{}", integer_part)
            } else {
                // ಸುರಕ್ಷತೆ: ನಾವು ಎಎಸ್ಸಿಐಐ ಅಂಕೆಗಳನ್ನು ಮಾತ್ರ ಬಫರ್‌ಗೆ ಬರೆಯುತ್ತಿದ್ದೇವೆ ಮತ್ತು ಅದು
                // '0 ರೊಂದಿಗೆ ಪ್ರಾರಂಭಿಸಲಾಗಿದೆ, ಆದ್ದರಿಂದ ಇದು ಮಾನ್ಯವಾದ UTF8 ಅನ್ನು ಹೊಂದಿರುತ್ತದೆ.
                let s = unsafe { crate::str::from_utf8_unchecked(&buf[..end]) };

                // ಬಳಕೆದಾರರು ನಿಖರತೆ> 9 ಅನ್ನು ವಿನಂತಿಸಿದರೆ, ನಾವು ಪ್ಯಾಡ್ '0 ನ ಕೊನೆಯಲ್ಲಿ.
                let w = f.precision().unwrap_or(pos);
                write!(f, "{}.{:0<width$}", integer_part, s, width = w)
            }
        }

        // ವಿನಂತಿಸಿದರೆ ಪ್ರಮುಖ '+' ಚಿಹ್ನೆಯನ್ನು ಮುದ್ರಿಸಿ
        if f.sign_plus() {
            write!(f, "+")?;
        }

        if self.secs > 0 {
            fmt_decimal(f, self.secs, self.nanos, NANOS_PER_SEC / 10)?;
            f.write_str("s")
        } else if self.nanos >= NANOS_PER_MILLI {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MILLI) as u64,
                self.nanos % NANOS_PER_MILLI,
                NANOS_PER_MILLI / 10,
            )?;
            f.write_str("ms")
        } else if self.nanos >= NANOS_PER_MICRO {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MICRO) as u64,
                self.nanos % NANOS_PER_MICRO,
                NANOS_PER_MICRO / 10,
            )?;
            f.write_str("µs")
        } else {
            fmt_decimal(f, self.nanos as u64, 0, 1)?;
            f.write_str("ns")
        }
    }
}