//! ಪ್ರಾಚೀನ traits ಮತ್ತು ಪ್ರಕಾರಗಳ ಮೂಲ ಗುಣಲಕ್ಷಣಗಳನ್ನು ಪ್ರತಿನಿಧಿಸುವ ಪ್ರಕಾರಗಳು.
//!
//! Rust ಪ್ರಕಾರಗಳನ್ನು ಅವುಗಳ ಆಂತರಿಕ ಗುಣಲಕ್ಷಣಗಳಿಗೆ ಅನುಗುಣವಾಗಿ ವಿವಿಧ ಉಪಯುಕ್ತ ವಿಧಾನಗಳಲ್ಲಿ ವರ್ಗೀಕರಿಸಬಹುದು.
//! ಈ ವರ್ಗೀಕರಣಗಳನ್ನು traits ಎಂದು ನಿರೂಪಿಸಲಾಗಿದೆ.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// ಥ್ರೆಡ್ ಗಡಿಗಳಲ್ಲಿ ವರ್ಗಾಯಿಸಬಹುದಾದ ಪ್ರಕಾರಗಳು.
///
/// ಕಂಪೈಲರ್ ಇದು ಸೂಕ್ತವೆಂದು ನಿರ್ಧರಿಸಿದಾಗ ಈ trait ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಕಾರ್ಯಗತಗೊಳ್ಳುತ್ತದೆ.
///
/// `ಕಳುಹಿಸದ` ಪ್ರಕಾರದ ಉದಾಹರಣೆಯೆಂದರೆ ಉಲ್ಲೇಖ-ಎಣಿಕೆಯ ಪಾಯಿಂಟರ್ [`rc::Rc`][`Rc`].
/// ಎರಡು ಎಳೆಗಳು ಒಂದೇ ಉಲ್ಲೇಖ-ಎಣಿಸಿದ ಮೌಲ್ಯಕ್ಕೆ ಸೂಚಿಸುವ [`Rc`] ಗಳನ್ನು ಕ್ಲೋನ್ ಮಾಡಲು ಪ್ರಯತ್ನಿಸಿದರೆ, ಅವರು ಒಂದೇ ಸಮಯದಲ್ಲಿ ಉಲ್ಲೇಖ ಎಣಿಕೆಯನ್ನು ನವೀಕರಿಸಲು ಪ್ರಯತ್ನಿಸಬಹುದು, ಅದು [undefined behavior][ub] ಏಕೆಂದರೆ [`Rc`] ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬಳಸುವುದಿಲ್ಲ.
///
/// ಇದರ ಸೋದರಸಂಬಂಧಿ [`sync::Arc`][arc] ಪರಮಾಣು ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ಬಳಸುತ್ತದೆ (ಕೆಲವು ಓವರ್ಹೆಡ್ಗೆ ಒಳಗಾಗುತ್ತದೆ) ಮತ್ತು ಆದ್ದರಿಂದ `Send` ಆಗಿದೆ.
///
/// ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ [the Nomicon](../../nomicon/send-and-sync.html) ನೋಡಿ.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// ಕಂಪೈಲ್ ಸಮಯದಲ್ಲಿ ತಿಳಿದಿರುವ ಸ್ಥಿರ ಗಾತ್ರದ ವಿಧಗಳು.
///
/// ಎಲ್ಲಾ ಪ್ರಕಾರದ ನಿಯತಾಂಕಗಳು `Sized` ನ ಸೂಚ್ಯ ಬೌಂಡ್ ಅನ್ನು ಹೊಂದಿವೆ.ವಿಶೇಷವಾದ ಸಿಂಟ್ಯಾಕ್ಸ್ `?Sized` ಅನ್ನು ಸೂಕ್ತವಲ್ಲದಿದ್ದರೆ ಈ ಬೌಂಡ್ ಅನ್ನು ತೆಗೆದುಹಾಕಲು ಬಳಸಬಹುದು.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//ದೋಷ: [i32] ಗಾಗಿ ಗಾತ್ರವನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗಿಲ್ಲ
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// ಒಂದು ಅಪವಾದವೆಂದರೆ trait ನ ಸೂಚ್ಯ `Self` ಪ್ರಕಾರ.
/// trait ಒಂದು ಸೂಚ್ಯ `Sized` ಅನ್ನು ಹೊಂದಿಲ್ಲ ಏಕೆಂದರೆ ಇದು [trait ಆಬ್ಜೆಕ್ಟ್] ಗಳಿಗೆ ಹೊಂದಿಕೆಯಾಗುವುದಿಲ್ಲ, ಅಲ್ಲಿ ವ್ಯಾಖ್ಯಾನದಿಂದ, trait ಎಲ್ಲಾ ಸಂಭಾವ್ಯ ಅನುಷ್ಠಾನಕಾರರೊಂದಿಗೆ ಕೆಲಸ ಮಾಡಬೇಕಾಗುತ್ತದೆ, ಮತ್ತು ಆದ್ದರಿಂದ ಯಾವುದೇ ಗಾತ್ರವಿರಬಹುದು.
///
///
/// Rust ನಿಮಗೆ `Sized` ಅನ್ನು trait ಗೆ ಬಂಧಿಸಲು ಅನುಮತಿಸಿದರೂ, ನಂತರ trait ವಸ್ತುವನ್ನು ರೂಪಿಸಲು ನೀವು ಅದನ್ನು ಬಳಸಲು ಸಾಧ್ಯವಾಗುವುದಿಲ್ಲ:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // y: &dyn ಬಾರ್= &Impl;//ದೋಷ: trait `Bar` ಅನ್ನು ವಸ್ತುವನ್ನಾಗಿ ಮಾಡಲು ಸಾಧ್ಯವಿಲ್ಲ
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // ಡೀಫಾಲ್ಟ್ಗಾಗಿ, ಉದಾಹರಣೆಗೆ, `[T]: !Default` ಅನ್ನು ಮೌಲ್ಯಮಾಪನ ಮಾಡಬೇಕಾಗುತ್ತದೆ
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// ಕ್ರಿಯಾತ್ಮಕವಾಗಿ ಗಾತ್ರದ "unsized" ಆಗಿರಬಹುದಾದ ಪ್ರಕಾರಗಳು.
///
/// ಉದಾಹರಣೆಗೆ, ಗಾತ್ರದ ರಚನೆಯ ಪ್ರಕಾರ `[i8; 2]` `Unsize<[i8]>` ಮತ್ತು `Unsize<dyn fmt::Debug>` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
///
/// `Unsize` ನ ಎಲ್ಲಾ ಅನುಷ್ಠಾನಗಳನ್ನು ಕಂಪೈಲರ್ ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಒದಗಿಸುತ್ತದೆ.
///
/// `Unsize` ಇದಕ್ಕಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗಿದೆ:
///
/// - `[T; N]` `Unsize<[T]>` ಆಗಿದೆ
/// - `T` `T: Trait` ಇದ್ದಾಗ `Unsize<dyn Trait>` ಆಗಿದೆ
/// - `Foo<..., T, ...>` ಇದು `Unsize<Foo<..., U, ...>>` ಆಗಿದ್ದರೆ:
///   - `T: Unsize<U>`
///   - ಫೂ ಒಂದು ರಚನೆಯಾಗಿದೆ
///   - `Foo` ನ ಕೊನೆಯ ಕ್ಷೇತ್ರ ಮಾತ್ರ `T` ಅನ್ನು ಒಳಗೊಂಡಿರುವ ಪ್ರಕಾರವನ್ನು ಹೊಂದಿದೆ
///   - `T` ಯಾವುದೇ ಕ್ಷೇತ್ರಗಳ ಪ್ರಕಾರವಲ್ಲ
///   - `Bar<T>: Unsize<Bar<U>>`, `Foo` ನ ಕೊನೆಯ ಕ್ಷೇತ್ರವು `Bar<T>` ಪ್ರಕಾರವನ್ನು ಹೊಂದಿದ್ದರೆ
///
/// `Unsize` [`Rc`] ನಂತಹ "user-defined" ಕಂಟೇನರ್‌ಗಳನ್ನು ಕ್ರಿಯಾತ್ಮಕವಾಗಿ ಗಾತ್ರದ ಪ್ರಕಾರಗಳನ್ನು ಹೊಂದಲು ಅನುಮತಿಸಲು [`ops::CoerceUnsized`] ಜೊತೆಗೆ ಬಳಸಲಾಗುತ್ತದೆ.
/// ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ [DST coercion RFC][RFC982] ಮತ್ತು [the nomicon entry on coercion][nomicon-coerce] ನೋಡಿ.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// ಮಾದರಿ ಪಂದ್ಯಗಳಲ್ಲಿ ಬಳಸುವ ಸ್ಥಿರಾಂಕಗಳಿಗೆ trait ಅಗತ್ಯವಿದೆ.
///
/// `PartialEq` ಅನ್ನು ಪಡೆಯುವ ಯಾವುದೇ ಪ್ರಕಾರವು ಈ trait ಅನ್ನು ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ, ಅದರ ಪ್ರಕಾರ-ನಿಯತಾಂಕಗಳು `Eq` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆಯೆ ಎಂದು ಲೆಕ್ಕಿಸದೆ *.
///
/// `const` ಐಟಂ ಈ trait ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸದ ಕೆಲವು ಪ್ರಕಾರವನ್ನು ಹೊಂದಿದ್ದರೆ, ಆ ಪ್ರಕಾರವು (1.) `PartialEq` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದಿಲ್ಲ (ಇದರರ್ಥ ಸ್ಥಿರತೆಯು ಆ ಹೋಲಿಕೆ ವಿಧಾನವನ್ನು ಒದಗಿಸುವುದಿಲ್ಲ, ಯಾವ ಕೋಡ್ ಉತ್ಪಾದನೆ ಲಭ್ಯವಿದೆ ಎಂದು umes ಹಿಸುತ್ತದೆ), ಅಥವಾ (2.) ಅದು ತನ್ನದೇ ಆದ ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ `PartialEq` ನ * ಆವೃತ್ತಿ (ಇದು ರಚನಾತ್ಮಕ-ಸಮಾನತೆಯ ಹೋಲಿಕೆಗೆ ಅನುಗುಣವಾಗಿಲ್ಲ ಎಂದು ನಾವು ಭಾವಿಸುತ್ತೇವೆ).
///
///
/// ಮೇಲಿನ ಎರಡು ಸನ್ನಿವೇಶಗಳಲ್ಲಿ, ಮಾದರಿಯ ಸ್ಥಿರತೆಯಲ್ಲಿ ಅಂತಹ ಸ್ಥಿರ ಬಳಕೆಯನ್ನು ನಾವು ತಿರಸ್ಕರಿಸುತ್ತೇವೆ.
///
/// [structural match RFC][RFC1445], ಮತ್ತು [issue 63438] ಅನ್ನು ಸಹ ನೋಡಿ, ಇದು ಗುಣಲಕ್ಷಣ ಆಧಾರಿತ ವಿನ್ಯಾಸದಿಂದ ಈ trait ಗೆ ವಲಸೆ ಹೋಗಲು ಪ್ರೇರೇಪಿಸಿತು.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// ಮಾದರಿ ಪಂದ್ಯಗಳಲ್ಲಿ ಬಳಸುವ ಸ್ಥಿರಾಂಕಗಳಿಗೆ trait ಅಗತ್ಯವಿದೆ.
///
/// `Eq` ಅನ್ನು ಪಡೆಯುವ ಯಾವುದೇ ಪ್ರಕಾರವು ಈ trait ಅನ್ನು ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ, ಅದರ ಪ್ರಕಾರದ ನಿಯತಾಂಕಗಳು `Eq` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆಯೆ ಎಂದು ಲೆಕ್ಕಿಸದೆ *.
///
/// ನಮ್ಮ ಪ್ರಕಾರದ ವ್ಯವಸ್ಥೆಯಲ್ಲಿ ಮಿತಿಯ ಸುತ್ತ ಕೆಲಸ ಮಾಡಲು ಇದು ಹ್ಯಾಕ್ ಆಗಿದೆ.
///
/// # Background
///
/// ಪ್ಯಾಟರ್ನ್ ಪಂದ್ಯಗಳಲ್ಲಿ ಬಳಸಲಾಗುವ ಕಾನ್ಸ್ಟ್‌ಗಳ ಪ್ರಕಾರಗಳು `#[derive(PartialEq, Eq)]` ಗುಣಲಕ್ಷಣವನ್ನು ಹೊಂದಿರಬೇಕು ಎಂದು ನಾವು ಬಯಸುತ್ತೇವೆ.
///
/// ಹೆಚ್ಚು ಆದರ್ಶ ಜಗತ್ತಿನಲ್ಲಿ, ಕೊಟ್ಟಿರುವ ಪ್ರಕಾರವು `StructuralPartialEq` trait *ಮತ್ತು*`Eq` trait ಎರಡನ್ನೂ ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ ಎಂದು ಪರಿಶೀಲಿಸುವ ಮೂಲಕ ನಾವು ಆ ಅಗತ್ಯವನ್ನು ಪರಿಶೀಲಿಸಬಹುದು.
/// ಆದಾಗ್ಯೂ, ನೀವು * `derive(PartialEq, Eq)` ಮಾಡುವ ADT ಗಳನ್ನು ಹೊಂದಬಹುದು, ಮತ್ತು ಕಂಪೈಲರ್ ಒಪ್ಪಿಕೊಳ್ಳಬೇಕೆಂದು ನಾವು ಬಯಸುತ್ತೇವೆ, ಮತ್ತು ಸ್ಥಿರ ಪ್ರಕಾರವು `Eq` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ವಿಫಲವಾಗಿದೆ.
///
/// ಅವುಗಳೆಂದರೆ, ಈ ರೀತಿಯ ಪ್ರಕರಣ:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (ಮೇಲಿನ ಕೋಡ್‌ನಲ್ಲಿನ ಸಮಸ್ಯೆ ಏನೆಂದರೆ, `Wrap<fn(&())>` `PartialEq` ಅಥವಾ `Eq` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದಿಲ್ಲ, ಏಕೆಂದರೆ `ಫಾರ್ <'a> fn(&'a _)` does not implement those traits.)
///
/// ಆದ್ದರಿಂದ, ನಾವು `StructuralPartialEq` ಮತ್ತು ಕೇವಲ `Eq` ಗಾಗಿ ನಿಷ್ಕಪಟ ಪರಿಶೀಲನೆಯನ್ನು ಅವಲಂಬಿಸಲಾಗುವುದಿಲ್ಲ.
///
/// ಇದರ ಸುತ್ತ ಕೆಲಸ ಮಾಡಲು ಒಂದು ಹ್ಯಾಕ್ ಆಗಿ, ನಾವು ಪ್ರತಿಯೊಂದರಿಂದ ಚುಚ್ಚುಮದ್ದಿನ ಎರಡು ಪ್ರತ್ಯೇಕ traits ಅನ್ನು ಬಳಸುತ್ತೇವೆ (`#[derive(PartialEq)]` ಮತ್ತು `#[derive(Eq)]`) ಮತ್ತು ರಚನಾತ್ಮಕ-ಹೊಂದಾಣಿಕೆಯ ಪರಿಶೀಲನೆಯ ಭಾಗವಾಗಿ ಇವೆರಡೂ ಇದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸುತ್ತೇವೆ.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// ಬಿಟ್‌ಗಳನ್ನು ನಕಲಿಸುವ ಮೂಲಕ ಅದರ ಮೌಲ್ಯಗಳನ್ನು ನಕಲು ಮಾಡಬಹುದಾದ ಪ್ರಕಾರಗಳು.
///
/// ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ, ವೇರಿಯಬಲ್ ಬೈಂಡಿಂಗ್‌ಗಳು 'ಮೂವ್ ಸೆಮ್ಯಾಂಟಿಕ್ಸ್' ಅನ್ನು ಹೊಂದಿವೆ.ಬೇರೆ ಪದಗಳಲ್ಲಿ:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` `y` ಗೆ ಸರಿಸಲಾಗಿದೆ, ಆದ್ದರಿಂದ ಅದನ್ನು ಬಳಸಲಾಗುವುದಿಲ್ಲ
///
/// // println! ("{: ?}", x);//ದೋಷ: ಸರಿಸಿದ ಮೌಲ್ಯದ ಬಳಕೆ
/// ```
///
/// ಆದಾಗ್ಯೂ, ಒಂದು ಪ್ರಕಾರವು `Copy` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದರೆ, ಅದು 'ಕಾಪಿ ಸೆಮ್ಯಾಂಟಿಕ್ಸ್' ಅನ್ನು ಹೊಂದಿರುತ್ತದೆ:
///
/// ```
/// // ನಾವು `Copy` ಅನುಷ್ಠಾನವನ್ನು ಪಡೆಯಬಹುದು.
/// // `Clone` ಇದು ಸಹ ಅಗತ್ಯವಿದೆ, ಏಕೆಂದರೆ ಇದು `Copy` ನ ಸೂಪರ್‌ಟ್ರೇಟ್ ಆಗಿದೆ.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` ಇದು `x` ನ ಪ್ರತಿ
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// ಈ ಎರಡು ಉದಾಹರಣೆಗಳಲ್ಲಿ, ನಿಯೋಜನೆಯ ನಂತರ ನಿಮಗೆ `x` ಅನ್ನು ಪ್ರವೇಶಿಸಲು ಅನುಮತಿಸಲಾಗಿದೆಯೇ ಎಂಬುದು ಒಂದೇ ವ್ಯತ್ಯಾಸ.
/// ಹುಡ್ ಅಡಿಯಲ್ಲಿ, ನಕಲು ಮತ್ತು ಚಲಿಸುವಿಕೆಯು ಬಿಟ್‌ಗಳನ್ನು ಮೆಮೊರಿಯಲ್ಲಿ ನಕಲಿಸಲು ಕಾರಣವಾಗಬಹುದು, ಆದರೂ ಇದನ್ನು ಕೆಲವೊಮ್ಮೆ ಹೊಂದುವಂತೆ ಮಾಡಲಾಗುತ್ತದೆ.
///
/// ## `Copy` ಅನ್ನು ನಾನು ಹೇಗೆ ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು?
///
/// ನಿಮ್ಮ ಪ್ರಕಾರದಲ್ಲಿ `Copy` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ಎರಡು ಮಾರ್ಗಗಳಿವೆ.`derive` ಅನ್ನು ಬಳಸುವುದು ಸರಳವಾಗಿದೆ:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// ನೀವು `Copy` ಮತ್ತು `Clone` ಅನ್ನು ಹಸ್ತಚಾಲಿತವಾಗಿ ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// ಇವೆರಡರ ನಡುವೆ ಒಂದು ಸಣ್ಣ ವ್ಯತ್ಯಾಸವಿದೆ: `derive` ತಂತ್ರವು `Copy` ಅನ್ನು ಟೈಪ್ ನಿಯತಾಂಕಗಳ ಮೇಲೆ ಬಂಧಿಸುತ್ತದೆ, ಅದು ಯಾವಾಗಲೂ ಅಪೇಕ್ಷಿಸುವುದಿಲ್ಲ.
///
/// ## `Copy` ಮತ್ತು `Clone` ನಡುವಿನ ವ್ಯತ್ಯಾಸವೇನು?
///
/// ಪ್ರತಿಗಳು ಸೂಚ್ಯವಾಗಿ ಸಂಭವಿಸುತ್ತವೆ, ಉದಾಹರಣೆಗೆ ನಿಯೋಜನೆಯ `y = x` ನ ಭಾಗವಾಗಿ.`Copy` ನ ವರ್ತನೆಯು ಓವರ್‌ಲೋಡ್ ಆಗುವುದಿಲ್ಲ;ಇದು ಯಾವಾಗಲೂ ಸರಳವಾದ ಬಿಟ್-ಬುದ್ಧಿವಂತ ನಕಲು.
///
/// ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಒಂದು ಸ್ಪಷ್ಟ ಕ್ರಿಯೆಯಾಗಿದೆ, `x.clone()`.[`Clone`] ನ ಅನುಷ್ಠಾನವು ಮೌಲ್ಯಗಳನ್ನು ಸುರಕ್ಷಿತವಾಗಿ ನಕಲು ಮಾಡಲು ಅಗತ್ಯವಿರುವ ಯಾವುದೇ ಪ್ರಕಾರ-ನಿರ್ದಿಷ್ಟ ನಡವಳಿಕೆಯನ್ನು ಒದಗಿಸುತ್ತದೆ.
/// ಉದಾಹರಣೆಗೆ, [`String`] ಗಾಗಿ [`Clone`] ನ ಅನುಷ್ಠಾನವು ರಾಶಿಯಲ್ಲಿ ಪಾಯಿಂಟೆಡ್-ಟು ಸ್ಟ್ರಿಂಗ್ ಬಫರ್ ಅನ್ನು ನಕಲಿಸುವ ಅಗತ್ಯವಿದೆ.
/// [`String`] ಮೌಲ್ಯಗಳ ಸರಳ ಬಿಟ್‌ವೈಸ್ ನಕಲು ಕೇವಲ ಪಾಯಿಂಟರ್ ಅನ್ನು ನಕಲಿಸುತ್ತದೆ, ಇದು ಸಾಲಿನ ಕೆಳಗೆ ಡಬಲ್ ಫ್ರೀಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
/// ಈ ಕಾರಣಕ್ಕಾಗಿ, [`String`] [`Clone`] ಆದರೆ `Copy` ಅಲ್ಲ.
///
/// [`Clone`] ಇದು `Copy` ನ ಸೂಪರ್‌ಟ್ರೇಟ್ ಆಗಿದೆ, ಆದ್ದರಿಂದ `Copy` ಆಗಿರುವ ಎಲ್ಲವೂ [`Clone`] ಅನ್ನು ಸಹ ಕಾರ್ಯಗತಗೊಳಿಸಬೇಕು.
/// ಒಂದು ಪ್ರಕಾರವು `Copy` ಆಗಿದ್ದರೆ ಅದರ [`Clone`] ಅನುಷ್ಠಾನಕ್ಕೆ `*self` ಅನ್ನು ಹಿಂತಿರುಗಿಸಬೇಕಾಗುತ್ತದೆ (ಮೇಲಿನ ಉದಾಹರಣೆಯನ್ನು ನೋಡಿ).
///
/// ## ನನ್ನ ಪ್ರಕಾರ ಯಾವಾಗ `Copy` ಆಗಿರಬಹುದು?
///
/// ಒಂದು ವಿಧವು ಅದರ ಎಲ್ಲಾ ಘಟಕಗಳು `Copy` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದರೆ `Copy` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು.ಉದಾಹರಣೆಗೆ, ಈ ರಚನೆಯು `Copy` ಆಗಿರಬಹುದು:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// ಒಂದು ರಚನೆಯು `Copy` ಆಗಿರಬಹುದು, ಮತ್ತು [`i32`] `Copy` ಆಗಿರುತ್ತದೆ, ಆದ್ದರಿಂದ `Point` `Copy` ಆಗಲು ಅರ್ಹವಾಗಿದೆ.
/// ಇದಕ್ಕೆ ವಿರುದ್ಧವಾಗಿ, ಪರಿಗಣಿಸಿ
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// ಸ್ಟ್ರಕ್ಟ್ `PointList` ಗೆ `Copy` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ, ಏಕೆಂದರೆ [`Vec<T>`] `Copy` ಅಲ್ಲ.ನಾವು `Copy` ಅನುಷ್ಠಾನವನ್ನು ಪಡೆಯಲು ಪ್ರಯತ್ನಿಸಿದರೆ, ನಾವು ದೋಷವನ್ನು ಪಡೆಯುತ್ತೇವೆ:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// ಹಂಚಿದ ಉಲ್ಲೇಖಗಳು (`&T`) ಸಹ `Copy`, ಆದ್ದರಿಂದ ಒಂದು ಪ್ರಕಾರವು `Copy` ಆಗಿರಬಹುದು, ಅದು `T` ಪ್ರಕಾರಗಳ ಹಂಚಿಕೆಯ ಉಲ್ಲೇಖಗಳನ್ನು ಹೊಂದಿದ್ದರೂ ಸಹ *X* X ಅಲ್ಲ * `Copy`.
/// ಈ ಕೆಳಗಿನ ರಚನೆಯನ್ನು ಪರಿಗಣಿಸಿ, ಅದು `Copy` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದು, ಏಕೆಂದರೆ ಇದು ಮೇಲಿನಿಂದ ನಮ್ಮ `ಕಾಪಿ 'ಅಲ್ಲದ `PointList` ಗೆ * ಹಂಚಿದ ಉಲ್ಲೇಖವನ್ನು ಮಾತ್ರ ಹೊಂದಿದೆ:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## ನನ್ನ ಪ್ರಕಾರ `Copy` ಆಗಲು ಸಾಧ್ಯವಿಲ್ಲ *?
///
/// ಕೆಲವು ಪ್ರಕಾರಗಳನ್ನು ಸುರಕ್ಷಿತವಾಗಿ ನಕಲಿಸಲಾಗುವುದಿಲ್ಲ.ಉದಾಹರಣೆಗೆ, `&mut T` ಅನ್ನು ನಕಲಿಸುವುದು ಅಲಿಯಾಸ್ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖವನ್ನು ರಚಿಸುತ್ತದೆ.
/// [`String`] ಅನ್ನು ನಕಲಿಸುವುದು [`ಸ್ಟ್ರಿಂಗ್`] ನ ಬಫರ್ ಅನ್ನು ನಿರ್ವಹಿಸುವ ಜವಾಬ್ದಾರಿಯನ್ನು ನಕಲು ಮಾಡುತ್ತದೆ, ಇದು ಡಬಲ್ ಫ್ರೀಗೆ ಕಾರಣವಾಗುತ್ತದೆ.
///
/// ನಂತರದ ಪ್ರಕರಣವನ್ನು ಸಾಮಾನ್ಯೀಕರಿಸುವುದರಿಂದ, [`Drop`] ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಯಾವುದೇ ಪ್ರಕಾರವು `Copy` ಆಗಿರಬಾರದು, ಏಕೆಂದರೆ ಅದು ತನ್ನದೇ ಆದ [`size_of::<T>`] ಬೈಟ್‌ಗಳಲ್ಲದೆ ಕೆಲವು ಸಂಪನ್ಮೂಲಗಳನ್ನು ನಿರ್ವಹಿಸುತ್ತಿದೆ.
///
/// `ಕಾಪಿ` ಅಲ್ಲದ ಡೇಟಾವನ್ನು ಹೊಂದಿರುವ ಸ್ಟ್ರಕ್ಟ್ ಅಥವಾ ಎನಮ್‌ನಲ್ಲಿ ನೀವು `Copy` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ಪ್ರಯತ್ನಿಸಿದರೆ, ನೀವು [E0204] ದೋಷವನ್ನು ಪಡೆಯುತ್ತೀರಿ.
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## ಯಾವಾಗ ನನ್ನ ಪ್ರಕಾರ `Copy` ಆಗಿರಬೇಕು?
///
/// ಸಾಮಾನ್ಯವಾಗಿ ಹೇಳುವುದಾದರೆ, ನಿಮ್ಮ ಪ್ರಕಾರ _can_ `Copy` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಿದರೆ, ಅದು ಮಾಡಬೇಕು.
/// ಆದಾಗ್ಯೂ, `Copy` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದು ನಿಮ್ಮ ಪ್ರಕಾರದ ಸಾರ್ವಜನಿಕ API ನ ಭಾಗವಾಗಿದೆ ಎಂಬುದನ್ನು ನೆನಪಿನಲ್ಲಿಡಿ.
/// future ನಲ್ಲಿ ಈ ಪ್ರಕಾರವು `ಕಾಪಿ ಅಲ್ಲದವರಾಗಬಹುದು ', ಬ್ರೇಕಿಂಗ್ API ಬದಲಾವಣೆಯನ್ನು ತಪ್ಪಿಸಲು, ಈಗ `Copy` ಅನುಷ್ಠಾನವನ್ನು ಬಿಟ್ಟುಬಿಡುವುದು ವಿವೇಕಯುತವಾಗಿದೆ.
///
/// ## ಹೆಚ್ಚುವರಿ ಅನುಷ್ಠಾನಕಾರರು
///
/// [implementors listed below][impls] ಜೊತೆಗೆ, ಈ ಕೆಳಗಿನ ಪ್ರಕಾರಗಳು `Copy` ಅನ್ನು ಸಹ ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತವೆ:
///
/// * ಕಾರ್ಯ ಐಟಂ ಪ್ರಕಾರಗಳು (ಅಂದರೆ, ಪ್ರತಿ ಕಾರ್ಯಕ್ಕೂ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ವಿಭಿನ್ನ ಪ್ರಕಾರಗಳು)
/// * ಕಾರ್ಯ ಪಾಯಿಂಟರ್ ಪ್ರಕಾರಗಳು (ಉದಾ., `fn() -> i32`)
/// * ಐಟಂ ಪ್ರಕಾರವು `Copy` (ಉದಾ., `[i32; 123456]`) ಅನ್ನು ಸಹ ಕಾರ್ಯಗತಗೊಳಿಸಿದರೆ, ಎಲ್ಲಾ ಗಾತ್ರಗಳಿಗೆ ಅರೇ ಪ್ರಕಾರಗಳು
/// * ಟ್ಯುಪಲ್ ಪ್ರಕಾರಗಳು, ಪ್ರತಿ ಘಟಕವು `Copy` ಅನ್ನು ಸಹ ಕಾರ್ಯಗತಗೊಳಿಸಿದರೆ (ಉದಾ., `()`, `(i32, bool)`)
/// * ಮುಚ್ಚುವ ಪ್ರಕಾರಗಳು, ಅವು ಪರಿಸರದಿಂದ ಯಾವುದೇ ಮೌಲ್ಯವನ್ನು ಸೆರೆಹಿಡಿಯದಿದ್ದರೆ ಅಥವಾ ಅಂತಹ ಎಲ್ಲಾ ಸೆರೆಹಿಡಿದ ಮೌಲ್ಯಗಳು `Copy` ಅನ್ನು ಸ್ವತಃ ಕಾರ್ಯಗತಗೊಳಿಸಿದರೆ.
///   ಹಂಚಿದ ಉಲ್ಲೇಖದಿಂದ ಸೆರೆಹಿಡಿಯಲಾದ ಅಸ್ಥಿರಗಳು ಯಾವಾಗಲೂ `Copy` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತವೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ (ಉಲ್ಲೇಖಿಸದಿದ್ದರೂ ಸಹ), ಆದರೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖದಿಂದ ಸೆರೆಹಿಡಿಯಲಾದ ಅಸ್ಥಿರಗಳು ಎಂದಿಗೂ `Copy` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದಿಲ್ಲ.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) ಅತೃಪ್ತಿಕರ ಜೀವಿತಾವಧಿಯ ಮಿತಿಗಳ ಕಾರಣ `Copy` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸದ ಪ್ರಕಾರವನ್ನು ನಕಲಿಸಲು ಇದು ಅನುಮತಿಸುತ್ತದೆ (`A<'static>: Copy` ಮತ್ತು `A<'_>: Clone` ಮಾತ್ರ ಇದ್ದಾಗ `A<'_>` ಅನ್ನು ನಕಲಿಸುವುದು).
// ಸ್ಟ್ಯಾಂಡರ್ಡ್ ಲೈಬ್ರರಿಯಲ್ಲಿ ಈಗಾಗಲೇ ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ `Copy` ನಲ್ಲಿ ಕೆಲವೇ ಕೆಲವು ವಿಶೇಷತೆಗಳಿವೆ ಮತ್ತು ಇದೀಗ ಈ ನಡವಳಿಕೆಯನ್ನು ಸುರಕ್ಷಿತವಾಗಿ ಹೊಂದಲು ಯಾವುದೇ ಮಾರ್ಗವಿಲ್ಲದ ಕಾರಣ ನಾವು ಈಗ ಈ ಗುಣಲಕ್ಷಣವನ್ನು ಇಲ್ಲಿ ಹೊಂದಿದ್ದೇವೆ.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// trait `Copy` ನ ಇಂಪಲ್ ಅನ್ನು ಉತ್ಪಾದಿಸುವ ಮ್ಯಾಕ್ರೋ ಅನ್ನು ಪಡೆಯಿರಿ.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// ಎಳೆಗಳ ನಡುವೆ ಉಲ್ಲೇಖಗಳನ್ನು ಹಂಚಿಕೊಳ್ಳುವುದು ಸುರಕ್ಷಿತವಾದ ವಿಧಗಳು.
///
/// ಕಂಪೈಲರ್ ಇದು ಸೂಕ್ತವೆಂದು ನಿರ್ಧರಿಸಿದಾಗ ಈ trait ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಕಾರ್ಯಗತಗೊಳ್ಳುತ್ತದೆ.
///
/// ನಿಖರವಾದ ವ್ಯಾಖ್ಯಾನ ಹೀಗಿದೆ: `T` ಪ್ರಕಾರವು [`Sync`] ಆಗಿದ್ದರೆ ಮತ್ತು `&T` [`Send`] ಆಗಿದ್ದರೆ ಮಾತ್ರ.
/// ಬೇರೆ ರೀತಿಯಲ್ಲಿ ಹೇಳುವುದಾದರೆ, ಎಳೆಗಳ ನಡುವೆ `&T` ಉಲ್ಲೇಖಗಳನ್ನು ಹಾದುಹೋಗುವಾಗ [undefined behavior][ub] (ಡೇಟಾ ರೇಸ್ ಸೇರಿದಂತೆ) ಸಾಧ್ಯತೆಯಿಲ್ಲದಿದ್ದರೆ.
///
/// ಒಬ್ಬರು ನಿರೀಕ್ಷಿಸಿದಂತೆ, [`u8`] ಮತ್ತು [`f64`] ನಂತಹ ಪ್ರಾಚೀನ ಪ್ರಕಾರಗಳೆಲ್ಲವೂ [`Sync`], ಮತ್ತು ಟ್ಯುಪಲ್ಸ್, ಸ್ಟ್ರಕ್ಟ್ಸ್ ಮತ್ತು ಎನಮ್‌ಗಳಂತಹ ಸರಳ ಒಟ್ಟು ಪ್ರಕಾರಗಳಾಗಿವೆ.
/// ಮೂಲ [`Sync`] ಪ್ರಕಾರಗಳ ಹೆಚ್ಚಿನ ಉದಾಹರಣೆಗಳಲ್ಲಿ `&T` ನಂತಹ "immutable" ಪ್ರಕಾರಗಳು ಮತ್ತು [`Box<T>`][box], [`Vec<T>`][vec] ಮತ್ತು ಇತರ ಸಂಗ್ರಹ ಪ್ರಕಾರಗಳಂತಹ ಸರಳ ಆನುವಂಶಿಕ ರೂಪಾಂತರವನ್ನು ಹೊಂದಿರುವವರು ಸೇರಿವೆ.
///
/// (ಜೆನೆರಿಕ್ ನಿಯತಾಂಕಗಳು ಅವುಗಳ ಕಂಟೇನರ್ [`ಸಿಂಕ್`] ಆಗಲು [`Sync`] ಆಗಿರಬೇಕು.)
///
/// ವ್ಯಾಖ್ಯಾನದ ಸ್ವಲ್ಪ ಆಶ್ಚರ್ಯಕರ ಪರಿಣಾಮವೆಂದರೆ, `&mut T` ಎಂಬುದು `Sync` (`T` `Sync` ಆಗಿದ್ದರೆ) ಅದು ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡದ ರೂಪಾಂತರವನ್ನು ಒದಗಿಸಬಹುದು ಎಂದು ತೋರುತ್ತದೆಯಾದರೂ.
/// ಟ್ರಿಕ್ ಎಂದರೆ ಹಂಚಿಕೆಯ ಉಲ್ಲೇಖದ ಹಿಂದೆ (ಅಂದರೆ, `& &mut T`) ರೂಪಾಂತರಗೊಳ್ಳುವ ಉಲ್ಲೇಖವು ಓದಲು ಮಾತ್ರ ಆಗುತ್ತದೆ, ಅದು `& &T` ನಂತೆ.
/// ಆದ್ದರಿಂದ ಡೇಟಾ ಓಟದ ಅಪಾಯವಿಲ್ಲ.
///
/// `Sync` ಅಲ್ಲದ ಪ್ರಕಾರಗಳು "interior mutability" ಅನ್ನು ಥ್ರೆಡ್-ಸುರಕ್ಷಿತವಲ್ಲದ [`Cell`][cell] ಮತ್ತು [`RefCell`][refcell] ನಂತಹ "interior mutability" ಅನ್ನು ಹೊಂದಿವೆ.
/// ಈ ಪ್ರಕಾರಗಳು ತಮ್ಮ ವಿಷಯಗಳನ್ನು ಬದಲಾಯಿಸಲಾಗದ, ಹಂಚಿದ ಉಲ್ಲೇಖದ ಮೂಲಕ ರೂಪಾಂತರಗೊಳಿಸಲು ಅನುವು ಮಾಡಿಕೊಡುತ್ತದೆ.
/// ಉದಾಹರಣೆಗೆ, [`Cell<T>`][cell] ನಲ್ಲಿನ `set` ವಿಧಾನವು `&self` ಅನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ, ಆದ್ದರಿಂದ ಇದಕ್ಕೆ ಹಂಚಿದ ಉಲ್ಲೇಖ [`&Cell<T>`][cell] ಮಾತ್ರ ಬೇಕಾಗುತ್ತದೆ.
/// ವಿಧಾನವು ಯಾವುದೇ ಸಿಂಕ್ರೊನೈಸೇಶನ್ ಅನ್ನು ನಿರ್ವಹಿಸುವುದಿಲ್ಲ, ಆದ್ದರಿಂದ [`Cell`][cell] `Sync` ಆಗಿರಬಾರದು.
///
/// `ಸಿಂಕ್` ಅಲ್ಲದ ಮತ್ತೊಂದು ಉದಾಹರಣೆಯೆಂದರೆ ಉಲ್ಲೇಖ-ಎಣಿಕೆಯ ಪಾಯಿಂಟರ್ [`Rc`][rc].
/// ಯಾವುದೇ ಉಲ್ಲೇಖ [`&Rc<T>`][rc] ಅನ್ನು ನೀಡಿದರೆ, ನೀವು ಹೊಸ [`Rc<T>`][rc] ಅನ್ನು ಕ್ಲೋನ್ ಮಾಡಬಹುದು, ಉಲ್ಲೇಖದ ಎಣಿಕೆಗಳನ್ನು ಪರಮಾಣು ರಹಿತ ರೀತಿಯಲ್ಲಿ ಮಾರ್ಪಡಿಸಬಹುದು.
///
/// ಥ್ರೆಡ್-ಸುರಕ್ಷಿತ ಆಂತರಿಕ ರೂಪಾಂತರದ ಅಗತ್ಯವಿರುವಾಗ, Rust [atomic data types] ಅನ್ನು ಒದಗಿಸುತ್ತದೆ, ಜೊತೆಗೆ [`sync::Mutex`][mutex] ಮತ್ತು [`sync::RwLock`][rwlock] ಮೂಲಕ ಸ್ಪಷ್ಟವಾದ ಲಾಕಿಂಗ್ ಅನ್ನು ಒದಗಿಸುತ್ತದೆ.
/// ಈ ರೂಪಾಂತರಗಳು ಯಾವುದೇ ರೂಪಾಂತರವು ಡೇಟಾ ರೇಸ್‌ಗಳಿಗೆ ಕಾರಣವಾಗುವುದಿಲ್ಲ ಎಂದು ಖಚಿತಪಡಿಸುತ್ತದೆ, ಆದ್ದರಿಂದ ಪ್ರಕಾರಗಳು `Sync`.
/// ಅಂತೆಯೇ, [`sync::Arc`][arc] [`Rc`][rc] ನ ಥ್ರೆಡ್-ಸುರಕ್ಷಿತ ಅನಲಾಗ್ ಅನ್ನು ಒದಗಿಸುತ್ತದೆ.
///
/// ಆಂತರಿಕ ರೂಪಾಂತರವನ್ನು ಹೊಂದಿರುವ ಯಾವುದೇ ಪ್ರಕಾರಗಳು value(s) ಸುತ್ತಲೂ [`cell::UnsafeCell`][unsafecell] ಹೊದಿಕೆಯನ್ನು ಸಹ ಬಳಸಬೇಕು, ಇದನ್ನು ಹಂಚಿಕೆಯ ಉಲ್ಲೇಖದ ಮೂಲಕ ಪರಿವರ್ತಿಸಬಹುದು.
/// ಇದನ್ನು ಮಾಡಲು ವಿಫಲವಾದರೆ [undefined behavior][ub] ಆಗಿದೆ.
/// ಉದಾಹರಣೆಗೆ, [`ಪರಿವರ್ತಿಸು`][ಪರಿವರ್ತಿಸು]-ing `&T` ನಿಂದ `&mut T` ಗೆ ಅಮಾನ್ಯವಾಗಿದೆ.
///
/// `Sync` ಕುರಿತು ಹೆಚ್ಚಿನ ವಿವರಗಳಿಗಾಗಿ [the Nomicon][nomicon-send-and-sync] ನೋಡಿ.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): ಬೀಟಾದಲ್ಲಿನ `rustc_on_unimplemented` ಭೂಮಿಯಲ್ಲಿ ಟಿಪ್ಪಣಿಗಳನ್ನು ಸೇರಿಸಲು ಒಮ್ಮೆ ಬೆಂಬಲ, ಮತ್ತು ಅವಶ್ಯಕತೆ ಸರಪಳಿಯಲ್ಲಿ ಮುಚ್ಚುವಿಕೆಯು ಎಲ್ಲಿಯಾದರೂ ಇದೆಯೇ ಎಂದು ಪರಿಶೀಲಿಸಲು ಅದನ್ನು ವಿಸ್ತರಿಸಲಾಗಿದೆ, ಅದನ್ನು ಅಂತಹ (#48534) ನಂತೆ ವಿಸ್ತರಿಸಿ:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// "act like" ಅವರು `T` ಅನ್ನು ಹೊಂದಿರುವ ವಸ್ತುಗಳನ್ನು ಗುರುತಿಸಲು ಬಳಸುವ ಶೂನ್ಯ-ಗಾತ್ರದ ಪ್ರಕಾರ.
///
/// ನಿಮ್ಮ ಪ್ರಕಾರಕ್ಕೆ `PhantomData<T>` ಕ್ಷೇತ್ರವನ್ನು ಸೇರಿಸುವುದರಿಂದ ನಿಮ್ಮ ಪ್ರಕಾರವು `T` ಪ್ರಕಾರದ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸಿದಂತೆ ವರ್ತಿಸುತ್ತದೆ ಎಂದು ಕಂಪೈಲರ್‌ಗೆ ಹೇಳುತ್ತದೆ, ಅದು ನಿಜವಾಗಿಯೂ ಇಲ್ಲದಿದ್ದರೂ ಸಹ.
/// ಕೆಲವು ಸುರಕ್ಷತಾ ಗುಣಲಕ್ಷಣಗಳನ್ನು ಲೆಕ್ಕಾಚಾರ ಮಾಡುವಾಗ ಈ ಮಾಹಿತಿಯನ್ನು ಬಳಸಲಾಗುತ್ತದೆ.
///
/// `PhantomData<T>` ಅನ್ನು ಹೇಗೆ ಬಳಸುವುದು ಎಂಬುದರ ಕುರಿತು ಹೆಚ್ಚು ಆಳವಾದ ವಿವರಣೆಗಾಗಿ, ದಯವಿಟ್ಟು [the Nomicon](../../nomicon/phantom-data.html) ನೋಡಿ.
///
/// # ಭಯಂಕರ ಟಿಪ್ಪಣಿ
///
/// ಅವರಿಬ್ಬರೂ ಭಯಾನಕ ಹೆಸರುಗಳನ್ನು ಹೊಂದಿದ್ದರೂ, `PhantomData` ಮತ್ತು 'ಫ್ಯಾಂಟಮ್ ಪ್ರಕಾರಗಳು' ಸಂಬಂಧಿಸಿವೆ, ಆದರೆ ಒಂದೇ ಆಗಿರುವುದಿಲ್ಲ.ಫ್ಯಾಂಟಮ್ ಪ್ರಕಾರದ ನಿಯತಾಂಕವು ಕೇವಲ ಒಂದು ರೀತಿಯ ನಿಯತಾಂಕವಾಗಿದ್ದು ಅದನ್ನು ಎಂದಿಗೂ ಬಳಸಲಾಗುವುದಿಲ್ಲ.
/// Rust ನಲ್ಲಿ, ಇದು ಆಗಾಗ್ಗೆ ಕಂಪೈಲರ್ ದೂರು ನೀಡಲು ಕಾರಣವಾಗುತ್ತದೆ, ಮತ್ತು `PhantomData` ಮೂಲಕ "dummy" ಬಳಕೆಯನ್ನು ಸೇರಿಸುವುದು ಪರಿಹಾರವಾಗಿದೆ.
///
/// # Examples
///
/// ## ಬಳಕೆಯಾಗದ ಜೀವಿತಾವಧಿಯ ನಿಯತಾಂಕಗಳು
///
/// `PhantomData` ಗಾಗಿ ಸಾಮಾನ್ಯವಾಗಿ ಬಳಸುವ ಸಾಮಾನ್ಯ ಪ್ರಕರಣವೆಂದರೆ ಬಳಕೆಯಾಗದ ಜೀವಮಾನದ ನಿಯತಾಂಕವನ್ನು ಹೊಂದಿರುವ ಒಂದು ರಚನೆ, ಸಾಮಾನ್ಯವಾಗಿ ಕೆಲವು ಅಸುರಕ್ಷಿತ ಕೋಡ್‌ನ ಭಾಗವಾಗಿ.
/// ಉದಾಹರಣೆಗೆ, ಇಲ್ಲಿ `*const T` ಪ್ರಕಾರದ ಎರಡು ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಹೊಂದಿರುವ ಸ್ಟ್ರಕ್ಟ್ `Slice` ಇದೆ, ಬಹುಶಃ ಎಲ್ಲೋ ಒಂದು ಶ್ರೇಣಿಗೆ ಸೂಚಿಸುತ್ತದೆ:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// ಆಧಾರವಾಗಿರುವ ಡೇಟಾವು ಜೀವಿತಾವಧಿಯ `'a` ಗೆ ಮಾತ್ರ ಮಾನ್ಯವಾಗಿರುತ್ತದೆ, ಆದ್ದರಿಂದ `Slice` `'a` ಅನ್ನು ಮೀರಿಸಬಾರದು.
/// ಆದಾಗ್ಯೂ, ಈ ಉದ್ದೇಶವನ್ನು ಕೋಡ್‌ನಲ್ಲಿ ವ್ಯಕ್ತಪಡಿಸಲಾಗಿಲ್ಲ, ಏಕೆಂದರೆ ಜೀವಮಾನದ `'a` ನ ಯಾವುದೇ ಉಪಯೋಗಗಳಿಲ್ಲ ಮತ್ತು ಆದ್ದರಿಂದ ಇದು ಯಾವ ಡೇಟಾಗೆ ಅನ್ವಯಿಸುತ್ತದೆ ಎಂಬುದು ಸ್ಪಷ್ಟವಾಗಿಲ್ಲ.
/// *`Slice` ರಚನೆಯು `&'a T` ಉಲ್ಲೇಖವನ್ನು ಹೊಂದಿರುವಂತೆ* ಕಾರ್ಯನಿರ್ವಹಿಸಲು ಕಂಪೈಲರ್‌ಗೆ ಹೇಳುವ ಮೂಲಕ ನಾವು ಇದನ್ನು ಸರಿಪಡಿಸಬಹುದು:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// ಇದಕ್ಕೆ ಪ್ರತಿಯಾಗಿ `T: 'a` ಎಂಬ ಟಿಪ್ಪಣಿ ಅಗತ್ಯವಿರುತ್ತದೆ, ಇದು `T` ನಲ್ಲಿನ ಯಾವುದೇ ಉಲ್ಲೇಖಗಳು ಜೀವಿತಾವಧಿಯ `'a` ನಲ್ಲಿ ಮಾನ್ಯವಾಗಿರುತ್ತವೆ ಎಂದು ಸೂಚಿಸುತ್ತದೆ.
///
/// `Slice` ಅನ್ನು ಪ್ರಾರಂಭಿಸುವಾಗ ನೀವು `phantom` ಕ್ಷೇತ್ರಕ್ಕೆ `PhantomData` ಮೌಲ್ಯವನ್ನು ಒದಗಿಸುತ್ತೀರಿ:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## ಬಳಕೆಯಾಗದ ಪ್ರಕಾರದ ನಿಯತಾಂಕಗಳು
///
/// ನೀವು ಬಳಸದ ಪ್ರಕಾರದ ನಿಯತಾಂಕಗಳನ್ನು ಹೊಂದಿರುವಿರಿ ಎಂದು ಅದು ಕೆಲವೊಮ್ಮೆ ಸಂಭವಿಸುತ್ತದೆ, ಅದು ರಚನೆಯು "tied" ಗೆ ಯಾವ ರೀತಿಯ ಡೇಟಾವನ್ನು ಸೂಚಿಸುತ್ತದೆ, ಆ ಡೇಟಾವು ರಚನೆಯಲ್ಲಿಯೇ ಕಂಡುಬರದಿದ್ದರೂ ಸಹ.
/// [FFI] ನೊಂದಿಗೆ ಇದು ಉದ್ಭವಿಸುವ ಉದಾಹರಣೆ ಇಲ್ಲಿದೆ.
/// ವಿವಿಧ ರೀತಿಯ Rust ಮೌಲ್ಯಗಳನ್ನು ಉಲ್ಲೇಖಿಸಲು ವಿದೇಶಿ ಇಂಟರ್ಫೇಸ್ `*mut ()` ಪ್ರಕಾರದ ಹ್ಯಾಂಡಲ್‌ಗಳನ್ನು ಬಳಸುತ್ತದೆ.
/// ಹ್ಯಾಂಡಲ್ ಅನ್ನು ಸುತ್ತುವ ಸ್ಟ್ರಕ್ಟ್ `ExternalResource` ನಲ್ಲಿ ಫ್ಯಾಂಟಮ್ ಪ್ರಕಾರದ ನಿಯತಾಂಕವನ್ನು ಬಳಸಿಕೊಂಡು ನಾವು Rust ಪ್ರಕಾರವನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡುತ್ತೇವೆ.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## ಮಾಲೀಕತ್ವ ಮತ್ತು ಡ್ರಾಪ್ ಚೆಕ್
///
/// `PhantomData<T>` ಪ್ರಕಾರದ ಕ್ಷೇತ್ರವನ್ನು ಸೇರಿಸುವುದರಿಂದ ನಿಮ್ಮ ಪ್ರಕಾರವು `T` ಪ್ರಕಾರದ ಡೇಟಾವನ್ನು ಹೊಂದಿದೆ ಎಂದು ಸೂಚಿಸುತ್ತದೆ.ನಿಮ್ಮ ಪ್ರಕಾರವನ್ನು ಕೈಬಿಟ್ಟಾಗ, ಅದು `T` ಪ್ರಕಾರದ ಒಂದು ಅಥವಾ ಹೆಚ್ಚಿನ ನಿದರ್ಶನಗಳನ್ನು ಬಿಡಬಹುದು ಎಂದು ಇದು ಸೂಚಿಸುತ್ತದೆ.
/// ಇದು Rust ಕಂಪೈಲರ್‌ನ [drop check] ವಿಶ್ಲೇಷಣೆಯನ್ನು ಹೊಂದಿದೆ.
///
/// ನಿಮ್ಮ ರಚನೆಯು ವಾಸ್ತವವಾಗಿ `T` ಪ್ರಕಾರದ ಡೇಟಾವನ್ನು ಹೊಂದಿಲ್ಲದಿದ್ದರೆ, ಮಾಲೀಕತ್ವವನ್ನು ಸೂಚಿಸದಂತೆ, `PhantomData<&'a T>` (ideally) ಅಥವಾ `PhantomData<*const T>` (ಯಾವುದೇ ಜೀವಿತಾವಧಿಯು ಅನ್ವಯಿಸದಿದ್ದರೆ) ನಂತಹ ಉಲ್ಲೇಖ ಪ್ರಕಾರವನ್ನು ಬಳಸುವುದು ಉತ್ತಮ.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// ಎನಮ್ ತಾರತಮ್ಯಗಳ ಪ್ರಕಾರವನ್ನು ಸೂಚಿಸಲು ಕಂಪೈಲರ್-ಆಂತರಿಕ trait ಬಳಸಲಾಗುತ್ತದೆ.
///
/// ಈ trait ಪ್ರತಿಯೊಂದು ಪ್ರಕಾರಕ್ಕೂ ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಕಾರ್ಯಗತಗೊಳ್ಳುತ್ತದೆ ಮತ್ತು [`mem::Discriminant`] ಗೆ ಯಾವುದೇ ಖಾತರಿಗಳನ್ನು ಸೇರಿಸುವುದಿಲ್ಲ.
/// `DiscriminantKind::Discriminant` ಮತ್ತು `mem::Discriminant` ನಡುವೆ ಪ್ರಸಾರ ಮಾಡುವುದು **ಸ್ಪಷ್ಟೀಕರಿಸದ ನಡವಳಿಕೆ**.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// ತಾರತಮ್ಯದ ಪ್ರಕಾರ, ಇದು `mem::Discriminant` ಗೆ ಅಗತ್ಯವಿರುವ trait bounds ಅನ್ನು ಪೂರೈಸಬೇಕು.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// ಕಂಪೈಲರ್-ಆಂತರಿಕ trait ಒಂದು ಪ್ರಕಾರವು ಯಾವುದೇ `UnsafeCell` ಅನ್ನು ಆಂತರಿಕವಾಗಿ ಹೊಂದಿದೆಯೆ ಎಂದು ನಿರ್ಧರಿಸಲು ಬಳಸಲಾಗುತ್ತದೆ, ಆದರೆ ಇಂಡೈರೆಕ್ಷನ್ ಮೂಲಕ ಅಲ್ಲ.
///
/// ಉದಾಹರಣೆಗೆ, ಆ ಪ್ರಕಾರದ `static` ಅನ್ನು ಓದಲು-ಮಾತ್ರ ಸ್ಥಿರ ಸ್ಮರಣೆಯಲ್ಲಿ ಅಥವಾ ಬರೆಯಬಹುದಾದ ಸ್ಥಿರ ಸ್ಮರಣೆಯಲ್ಲಿ ಇರಿಸಲಾಗಿದೆಯೆ ಎಂದು ಇದು ಪರಿಣಾಮ ಬೀರುತ್ತದೆ.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// ಪಿನ್ ಮಾಡಿದ ನಂತರ ಸುರಕ್ಷಿತವಾಗಿ ಚಲಿಸಬಹುದಾದ ಪ್ರಕಾರಗಳು.
///
/// Rust ಸ್ವತಃ ಸ್ಥಿರ ಪ್ರಕಾರಗಳ ಬಗ್ಗೆ ಯಾವುದೇ ಕಲ್ಪನೆಯನ್ನು ಹೊಂದಿಲ್ಲ, ಮತ್ತು ಚಲಿಸುವಿಕೆಯನ್ನು (ಉದಾ., ನಿಯೋಜನೆ ಅಥವಾ [`mem::replace`] ಮೂಲಕ) ಯಾವಾಗಲೂ ಸುರಕ್ಷಿತವೆಂದು ಪರಿಗಣಿಸುತ್ತದೆ.
///
/// ಟೈಪ್ ಸಿಸ್ಟಮ್ ಮೂಲಕ ಚಲಿಸುವಿಕೆಯನ್ನು ತಡೆಯಲು [`Pin`][Pin] ಪ್ರಕಾರವನ್ನು ಬಳಸಲಾಗುತ್ತದೆ.[`Pin<P<T>>`][Pin] ಹೊದಿಕೆಗೆ ಸುತ್ತಿದ ಪಾಯಿಂಟರ್ಸ್ `P<T>` ಅನ್ನು ಹೊರಗೆ ಸರಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ.
/// ಪಿನ್ ಮಾಡುವ ಕುರಿತು ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ [`pin` module] ದಸ್ತಾವೇಜನ್ನು ನೋಡಿ.
///
/// `T` ಗಾಗಿ `Unpin` trait ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದರಿಂದ ಪ್ರಕಾರವನ್ನು ಪಿನ್ ಮಾಡುವ ನಿರ್ಬಂಧಗಳನ್ನು ಎತ್ತುತ್ತದೆ, ನಂತರ `T` ಅನ್ನು [`Pin<P<T>>`][Pin] ನಿಂದ [`mem::replace`] ನಂತಹ ಕಾರ್ಯಗಳೊಂದಿಗೆ [`Pin<P<T>>`][Pin] ನಿಂದ ಚಲಿಸಲು ಅನುವು ಮಾಡಿಕೊಡುತ್ತದೆ.
///
///
/// `Unpin` ಪಿನ್ ಮಾಡದ ಡೇಟಾಗೆ ಯಾವುದೇ ಪರಿಣಾಮಗಳಿಲ್ಲ.
/// ನಿರ್ದಿಷ್ಟವಾಗಿ ಹೇಳುವುದಾದರೆ, [`mem::replace`] ಸಂತೋಷದಿಂದ `!Unpin` ಡೇಟಾವನ್ನು ಚಲಿಸುತ್ತದೆ (ಇದು ಯಾವುದೇ `&mut T` ಗಾಗಿ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ, `T: Unpin` ಇದ್ದಾಗ ಮಾತ್ರವಲ್ಲ).
/// ಆದಾಗ್ಯೂ, ನೀವು [`Pin<P<T>>`][Pin] ಒಳಗೆ ಸುತ್ತಿದ ಡೇಟಾದ ಮೇಲೆ [`mem::replace`] ಅನ್ನು ಬಳಸಲಾಗುವುದಿಲ್ಲ ಏಕೆಂದರೆ ಅದಕ್ಕಾಗಿ ನಿಮಗೆ ಅಗತ್ಯವಿರುವ `&mut T` ಅನ್ನು ನೀವು ಪಡೆಯಲು ಸಾಧ್ಯವಿಲ್ಲ, ಮತ್ತು *ಅದು* ಈ ವ್ಯವಸ್ಥೆಯನ್ನು ಕೆಲಸ ಮಾಡುತ್ತದೆ.
///
/// ಆದ್ದರಿಂದ ಇದನ್ನು ಉದಾಹರಣೆಗೆ, `Unpin` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವ ಪ್ರಕಾರಗಳಲ್ಲಿ ಮಾತ್ರ ಮಾಡಬಹುದು:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // `mem::replace` ಗೆ ಕರೆ ಮಾಡಲು ನಮಗೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖ ಬೇಕು.
/// // (implicitly) ಅನ್ನು `Pin::deref_mut` ಅನ್ನು ಆಹ್ವಾನಿಸುವ ಮೂಲಕ ನಾವು ಅಂತಹ ಉಲ್ಲೇಖವನ್ನು ಪಡೆಯಬಹುದು, ಆದರೆ ಅದು ಮಾತ್ರ ಸಾಧ್ಯ ಏಕೆಂದರೆ `String` `Unpin` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// ಈ trait ಪ್ರತಿಯೊಂದು ಪ್ರಕಾರಕ್ಕೂ ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಕಾರ್ಯಗತಗೊಳ್ಳುತ್ತದೆ.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// `Unpin` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸದ ಮಾರ್ಕರ್ ಪ್ರಕಾರ.
///
/// ಒಂದು ಪ್ರಕಾರವು `PhantomPinned` ಅನ್ನು ಹೊಂದಿದ್ದರೆ, ಅದು ಪೂರ್ವನಿಯೋಜಿತವಾಗಿ `Unpin` ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದಿಲ್ಲ.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// ಪ್ರಾಚೀನ ಪ್ರಕಾರಗಳಿಗೆ `Copy` ನ ಅನುಷ್ಠಾನಗಳು.
///
/// Rust ನಲ್ಲಿ ವಿವರಿಸಲಾಗದ ಅನುಷ್ಠಾನಗಳನ್ನು `rustc_trait_selection` ನಲ್ಲಿ `traits::SelectionContext::copy_clone_conditions()` ನಲ್ಲಿ ಅಳವಡಿಸಲಾಗಿದೆ.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// ಹಂಚಿದ ಉಲ್ಲೇಖಗಳನ್ನು ನಕಲಿಸಬಹುದು, ಆದರೆ ರೂಪಾಂತರಿತ ಉಲ್ಲೇಖಗಳು *ಸಾಧ್ಯವಿಲ್ಲ*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}