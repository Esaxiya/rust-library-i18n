use core::task::Poll;

#[test]
fn poll_const() {
    // `Poll` ನ ವಿಧಾನಗಳು ಒಂದು ಸನ್ನಿವೇಶದಲ್ಲಿ ಬಳಸಬಹುದಾದವು ಎಂದು ಪರೀಕ್ಷಿಸಿ

    const POLL: Poll<usize> = Poll::Pending;

    const IS_READY: bool = POLL.is_ready();
    assert!(!IS_READY);

    const IS_PENDING: bool = POLL.is_pending();
    assert!(IS_PENDING);
}