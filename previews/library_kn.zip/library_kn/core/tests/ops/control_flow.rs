use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // ಇದು ಸ್ಥಿರವಾದ ಮೇಲ್ಮೈ ವಿಸ್ತೀರ್ಣವಲ್ಲ, ಆದರೆ LLVM ಯಾವಾಗಲೂ ಅದರ ಲಾಭವನ್ನು ಇದೀಗ ಪಡೆಯಲು ಸಾಧ್ಯವಾಗದಿದ್ದರೂ ಸಹ, ಅವುಗಳ ನಡುವೆ `?` ಅನ್ನು ಅಗ್ಗವಾಗಿಡಲು ಸಹಾಯ ಮಾಡುತ್ತದೆ.
    //
    // (ದುಃಖಕರ ಫಲಿತಾಂಶ ಮತ್ತು ಆಯ್ಕೆ ಅಸಮಂಜಸವಾಗಿದೆ, ಆದ್ದರಿಂದ ಕಂಟ್ರೋಲ್ ಫ್ಲೋ ಎರಡಕ್ಕೂ ಹೊಂದಿಕೆಯಾಗುವುದಿಲ್ಲ.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}