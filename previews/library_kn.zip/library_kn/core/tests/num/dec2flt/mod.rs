#![allow(overflowing_literals)]

mod parse;
mod rawfp;

// ಫ್ಲೋಟ್ ಅಕ್ಷರಶಃ ತೆಗೆದುಕೊಳ್ಳಿ, ಅದನ್ನು ವಿವಿಧ ರೀತಿಯಲ್ಲಿ ಸ್ಟ್ರಿಂಗ್ ಆಗಿ ಪರಿವರ್ತಿಸಿ (ಇವೆಲ್ಲವೂ ಸರಿಯಾಗಿದೆ ಎಂದು ನಂಬಲಾಗಿದೆ) ಮತ್ತು ಆ ತಂತಿಗಳನ್ನು ಅಕ್ಷರಶಃ ಮೌಲ್ಯಕ್ಕೆ ಪಾರ್ಸ್ ಮಾಡಲಾಗಿದೆಯೇ ಎಂದು ನೋಡಿ.
//
// *ಪಾಲಿಮಾರ್ಫಿಕ್ ಅಕ್ಷರಶಃ* ಅಗತ್ಯವಿದೆ, ಅಂದರೆ, f64 ಮತ್ತು f32 ಆಗಿ ಕಾರ್ಯನಿರ್ವಹಿಸಬಲ್ಲದು.
macro_rules! test_literal {
    ($x: expr) => {{
        let x32: f32 = $x;
        let x64: f64 = $x;
        let inputs = &[stringify!($x).into(), format!("{:?}", x64), format!("{:e}", x64)];
        for input in inputs {
            assert_eq!(input.parse(), Ok(x64));
            assert_eq!(input.parse(), Ok(x32));
            let neg_input = &format!("-{}", input);
            assert_eq!(neg_input.parse(), Ok(-x64));
            assert_eq!(neg_input.parse(), Ok(-x32));
        }
    }};
}

#[test]
fn ordinary() {
    test_literal!(1.0);
    test_literal!(3e-5);
    test_literal!(0.1);
    test_literal!(12345.);
    test_literal!(0.9999999);

    if cfg!(miri) {
        // ಮಿರಿ ತುಂಬಾ ನಿಧಾನವಾಗಿದೆ
        return;
    }

    test_literal!(2.2250738585072014e-308);
}

#[test]
fn special_code_paths() {
    test_literal!(36893488147419103229.0); // 2 ^ 65, 3, ಅರ್ಧದಷ್ಟು ಸಮನಾಗಿ ಸಹ ಪ್ರಾಮುಖ್ಯತೆಯೊಂದಿಗೆ ಪ್ರಚೋದಿಸುತ್ತದೆ
    test_literal!(101e-33); // ಅಲ್ಗಾರಿದಮ್ನಲ್ಲಿ ಟ್ರಿಕಿ ಅಂಡರ್ಫ್ಲೋ ಪ್ರಕರಣವನ್ನು ಪ್ರಚೋದಿಸುತ್ತದೆ (f32 ಗಾಗಿ)
    test_literal!(1e23); // ಅಲ್ಗಾರಿದಮ್ ಅನ್ನು ಪ್ರಚೋದಿಸುತ್ತದೆ
    test_literal!(2075e23); // ಅಲ್ಗಾರಿದಮ್ಆರ್ ಮೂಲಕ ಮತ್ತೊಂದು ಮಾರ್ಗವನ್ನು ಪ್ರಚೋದಿಸುತ್ತದೆ
    test_literal!(8713e-23); // ... ಮತ್ತು ಇನ್ನೊಂದು.
}

#[test]
fn large() {
    test_literal!(1e300);
    test_literal!(123456789.34567e250);
    test_literal!(943794359898089732078308743689303290943794359843568973207830874368930329.);
}

#[test]
#[cfg_attr(miri, ignore)] // ಮಿರಿ ತುಂಬಾ ನಿಧಾನವಾಗಿದೆ
fn subnormals() {
    test_literal!(5e-324);
    test_literal!(91e-324);
    test_literal!(1e-322);
    test_literal!(13245643e-320);
    test_literal!(2.22507385851e-308);
    test_literal!(2.1e-308);
    test_literal!(4.9406564584124654e-324);
}

#[test]
#[cfg_attr(miri, ignore)] // ಮಿರಿ ತುಂಬಾ ನಿಧಾನವಾಗಿದೆ
fn infinity() {
    test_literal!(1e400);
    test_literal!(1e309);
    test_literal!(2e308);
    test_literal!(1.7976931348624e308);
}

#[test]
fn zero() {
    test_literal!(0.0);
    test_literal!(1e-325);

    if cfg!(miri) {
        // ಮಿರಿ ತುಂಬಾ ನಿಧಾನವಾಗಿದೆ
        return;
    }

    test_literal!(1e-326);
    test_literal!(1e-500);
}

#[test]
fn fast_path_correct() {
    // ಈ ಸಂಖ್ಯೆ ವೇಗದ ಹಾದಿಯನ್ನು ಪ್ರಚೋದಿಸುತ್ತದೆ ಮತ್ತು SSE2 ಇಲ್ಲದೆ x86 ನಲ್ಲಿ ಕಂಪೈಲ್ ಮಾಡುವಾಗ ತಪ್ಪಾಗಿ ನಿರ್ವಹಿಸಲ್ಪಡುತ್ತದೆ (ಅಂದರೆ, x87 FPU ಸ್ಟ್ಯಾಕ್ ಬಳಸಿ).
    //
    test_literal!(1.448997445238699);
}

#[test]
fn lonely_dot() {
    assert!(".".parse::<f32>().is_err());
    assert!(".".parse::<f64>().is_err());
}

#[test]
fn exponentiated_dot() {
    assert!(".e0".parse::<f32>().is_err());
    assert!(".e0".parse::<f64>().is_err());
}

#[test]
fn lonely_sign() {
    assert!("+".parse::<f32>().is_err());
    assert!("-".parse::<f64>().is_err());
}

#[test]
fn whitespace() {
    assert!(" 1.0".parse::<f32>().is_err());
    assert!("1.0 ".parse::<f64>().is_err());
}

#[test]
fn nan() {
    assert!("NaN".parse::<f32>().unwrap().is_nan());
    assert!("NaN".parse::<f64>().unwrap().is_nan());
}

#[test]
fn inf() {
    assert_eq!("inf".parse(), Ok(f64::INFINITY));
    assert_eq!("-inf".parse(), Ok(f64::NEG_INFINITY));
    assert_eq!("inf".parse(), Ok(f32::INFINITY));
    assert_eq!("-inf".parse(), Ok(f32::NEG_INFINITY));
}

#[test]
fn massive_exponent() {
    let max = i64::MAX;
    assert_eq!(format!("1e{}000", max).parse(), Ok(f64::INFINITY));
    assert_eq!(format!("1e-{}000", max).parse(), Ok(0.0));
    assert_eq!(format!("1e{}000", max).parse(), Ok(f64::INFINITY));
}

#[test]
fn borderline_overflow() {
    let mut s = "0.".to_string();
    for _ in 0..375 {
        s.push('3');
    }
    // ಈ ಬರವಣಿಗೆಯ ಸಮಯದಲ್ಲಿ, ಇದು Err(..) ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ, ಆದರೆ ಇದು ಸರಿಪಡಿಸಬೇಕಾದ ದೋಷವಾಗಿದೆ.
    // ಪರೀಕ್ಷೆಯಲ್ಲಿ, ಪ್ರಮುಖ ಭಾಗವೆಂದರೆ ಅದು panic ಮಾಡುವುದಿಲ್ಲ ಎಂದು ಪ್ರತಿಪಾದಿಸಲು ಇದು ಅರ್ಥವಿಲ್ಲ.
    let _ = s.parse::<f64>();
}