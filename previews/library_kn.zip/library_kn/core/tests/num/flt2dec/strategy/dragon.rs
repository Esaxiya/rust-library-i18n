use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // ಮಿರಿ ತುಂಬಾ ನಿಧಾನವಾಗಿದೆ
fn exact_sanity_test() {
    // ಈ ಪರೀಕ್ಷೆಯು `exp2` ಲೈಬ್ರರಿ ಕಾರ್ಯದ ಕೆಲವು ಕಾರ್ನರ್-ಇಶ್ ಕೇಸ್ ಎಂದು ನಾನು can ಹಿಸಬಲ್ಲೆ, ಅದು ನಾವು ಬಳಸುತ್ತಿರುವ ಯಾವುದೇ ಸಿ ರನ್ಟೈಮ್ನಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿದೆ.
    // ವಿಎಸ್ 2013 ರಲ್ಲಿ ಈ ಕಾರ್ಯವು ದೋಷವನ್ನು ಹೊಂದಿದ್ದು, ಈ ಪರೀಕ್ಷೆಯು ಲಿಂಕ್ ಮಾಡಿದಾಗ ವಿಫಲಗೊಳ್ಳುತ್ತದೆ, ಆದರೆ ವಿಎಸ್ 2015 ರೊಂದಿಗೆ ಪರೀಕ್ಷೆಯು ಉತ್ತಮವಾಗಿ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತಿರುವುದರಿಂದ ದೋಷವು ಸ್ಥಿರವಾಗಿದೆ.
    //
    // ದೋಷವು `exp2(-1057)` ನ ರಿಟರ್ನ್ ಮೌಲ್ಯದಲ್ಲಿ ವ್ಯತ್ಯಾಸವೆಂದು ತೋರುತ್ತದೆ, ಅಲ್ಲಿ ವಿಎಸ್ 2013 ರಲ್ಲಿ ಇದು ಬಿಟ್ ಪ್ಯಾಟರ್ನ್ 0x2 ನೊಂದಿಗೆ ದ್ವಿಗುಣವನ್ನು ನೀಡುತ್ತದೆ ಮತ್ತು ವಿಎಸ್ 2015 ರಲ್ಲಿ ಅದು 0x20000 ಅನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
    //
    //
    // ಇದೀಗ ಈ ಪರೀಕ್ಷೆಯನ್ನು ಸಂಪೂರ್ಣವಾಗಿ ಬೇರೆಡೆ ಪರೀಕ್ಷಿಸಲಾಗಿರುವುದರಿಂದ ಅದನ್ನು ಸಂಪೂರ್ಣವಾಗಿ ನಿರ್ಲಕ್ಷಿಸಿ ಮತ್ತು ಪ್ರತಿ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್‌ನ exp2 ಅನುಷ್ಠಾನವನ್ನು ಪರೀಕ್ಷಿಸಲು ನಾವು ಹೆಚ್ಚು ಆಸಕ್ತಿ ಹೊಂದಿಲ್ಲ.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}