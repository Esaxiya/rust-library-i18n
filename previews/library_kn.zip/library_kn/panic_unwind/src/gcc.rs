//! libgcc/libunwind (ಕೆಲವು ರೂಪದಲ್ಲಿ) ಬೆಂಬಲಿತ panics ಅನುಷ್ಠಾನ.
//!
//! ಎಕ್ಸೆಪ್ಶನ್ ಹ್ಯಾಂಡ್ಲಿಂಗ್ ಮತ್ತು ಸ್ಟ್ಯಾಕ್ ಬಿಚ್ಚುವಿಕೆಯ ಹಿನ್ನೆಲೆಗಾಗಿ ದಯವಿಟ್ಟು "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) ಮತ್ತು ಅದರಿಂದ ಲಿಂಕ್ ಮಾಡಲಾದ ಡಾಕ್ಯುಮೆಂಟ್‌ಗಳನ್ನು ನೋಡಿ.
//! ಇವುಗಳು ಉತ್ತಮವಾದ ಓದುಗಳು:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## ಸಂಕ್ಷಿಪ್ತ ಸಾರಾಂಶ
//!
//! ಎಕ್ಸೆಪ್ಶನ್ ಹ್ಯಾಂಡ್ಲಿಂಗ್ ಎರಡು ಹಂತಗಳಲ್ಲಿ ನಡೆಯುತ್ತದೆ: ಹುಡುಕಾಟ ಹಂತ ಮತ್ತು ಸ್ವಚ್ clean ಗೊಳಿಸುವ ಹಂತ.
//!
//! ಎರಡೂ ಹಂತಗಳಲ್ಲಿ ಅನ್‌ವೈಂಡರ್ ಸ್ಟಾಕ್ ಫ್ರೇಮ್‌ಗಳಿಂದ ಮಾಹಿತಿಯನ್ನು ಬಳಸಿಕೊಂಡು ಸ್ಟ್ಯಾಕ್ ಫ್ರೇಮ್‌ಗಳನ್ನು ಮೇಲಿನಿಂದ ಕೆಳಕ್ಕೆ ನಡೆಯುತ್ತದೆ ಪ್ರಸ್ತುತ ಪ್ರಕ್ರಿಯೆಯ ಮಾಡ್ಯೂಲ್‌ಗಳ ವಿಭಾಗಗಳನ್ನು ಬಿಚ್ಚಿಡುತ್ತದೆ (ಇಲ್ಲಿ "module" ಓಎಸ್ ಮಾಡ್ಯೂಲ್ ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ, ಅಂದರೆ, ಕಾರ್ಯಗತಗೊಳಿಸಬಹುದಾದ ಅಥವಾ ಕ್ರಿಯಾತ್ಮಕ ಗ್ರಂಥಾಲಯ).
//!
//!
//! ಪ್ರತಿ ಸ್ಟಾಕ್ ಫ್ರೇಮ್‌ಗಾಗಿ, ಇದು ಸಂಬಂಧಿತ "personality routine" ಅನ್ನು ಆಹ್ವಾನಿಸುತ್ತದೆ, ಇದರ ವಿಳಾಸವನ್ನು ಬಿಚ್ಚುವ ಮಾಹಿತಿ ವಿಭಾಗದಲ್ಲಿ ಸಂಗ್ರಹಿಸಲಾಗುತ್ತದೆ.
//!
//! ಹುಡುಕಾಟ ಹಂತದಲ್ಲಿ, ಎಕ್ಸೆಪ್ಶನ್ ಆಬ್ಜೆಕ್ಟ್ ಅನ್ನು ಎಸೆಯಲಾಗಿದೆಯೆ ಎಂದು ಪರೀಕ್ಷಿಸುವುದು ಮತ್ತು ಅದನ್ನು ಆ ಸ್ಟಾಕ್ ಫ್ರೇಮ್‌ನಲ್ಲಿ ಹಿಡಿಯಬೇಕೆ ಎಂದು ನಿರ್ಧರಿಸುವುದು ವ್ಯಕ್ತಿತ್ವದ ದಿನಚರಿಯ ಕೆಲಸ.ಹ್ಯಾಂಡ್ಲರ್ ಫ್ರೇಮ್ ಅನ್ನು ಗುರುತಿಸಿದ ನಂತರ, ಸ್ವಚ್ clean ಗೊಳಿಸುವ ಹಂತವು ಪ್ರಾರಂಭವಾಗುತ್ತದೆ.
//!
//! ಸ್ವಚ್ up ಗೊಳಿಸುವ ಹಂತದಲ್ಲಿ, ಬಿಚ್ಚುವಿಕೆಯು ಪ್ರತಿ ವ್ಯಕ್ತಿತ್ವದ ದಿನಚರಿಯನ್ನು ಮತ್ತೆ ಆಹ್ವಾನಿಸುತ್ತದೆ.
//! ಪ್ರಸ್ತುತ ಸ್ಟಾಕ್ ಫ್ರೇಮ್‌ಗಾಗಿ ಯಾವ (ಯಾವುದಾದರೂ ಇದ್ದರೆ) ಸ್ವಚ್ clean ಗೊಳಿಸುವ ಕೋಡ್ ಅನ್ನು ಚಲಾಯಿಸಬೇಕೆಂದು ಇದು ನಿರ್ಧರಿಸುತ್ತದೆ.ಹಾಗಿದ್ದಲ್ಲಿ, ನಿಯಂತ್ರಣವನ್ನು ಫಂಕ್ಷನ್ ಬಾಡಿ ಯಲ್ಲಿರುವ ವಿಶೇಷ branch ಗೆ ವರ್ಗಾಯಿಸಲಾಗುತ್ತದೆ, ಇದು "landing pad", ಇದು ವಿನಾಶಕಾರರನ್ನು ಆಹ್ವಾನಿಸುತ್ತದೆ, ಮೆಮೊರಿಯನ್ನು ಮುಕ್ತಗೊಳಿಸುತ್ತದೆ.
//! ಲ್ಯಾಂಡಿಂಗ್ ಪ್ಯಾಡ್‌ನ ಕೊನೆಯಲ್ಲಿ, ನಿಯಂತ್ರಣವನ್ನು ಬಿಚ್ಚುವ ಮತ್ತು ಬಿಚ್ಚುವ ಪುನರಾರಂಭಗಳಿಗೆ ಹಿಂತಿರುಗಿಸಲಾಗುತ್ತದೆ.
//!
//! ಸ್ಟಾಕ್ ಅನ್ನು ಹ್ಯಾಂಡ್ಲರ್ ಫ್ರೇಮ್ ಮಟ್ಟಕ್ಕೆ ಇಳಿಸಿದ ನಂತರ, ಬಿಚ್ಚುವ ನಿಲುಗಡೆಗಳು ಮತ್ತು ಕೊನೆಯ ವ್ಯಕ್ತಿತ್ವದ ವಾಡಿಕೆಯು ನಿಯಂತ್ರಣವನ್ನು ಕ್ಯಾಚ್ ಬ್ಲಾಕ್‌ಗೆ ವರ್ಗಾಯಿಸುತ್ತದೆ.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Rust ನ ಎಕ್ಸೆಪ್ಶನ್ ಕ್ಲಾಸ್ ಐಡೆಂಟಿಫೈಯರ್.
// ವಿನಾಯಿತಿಯನ್ನು ತಮ್ಮದೇ ಆದ ಚಾಲನಾಸಮಯದಿಂದ ಎಸೆಯಲಾಗಿದೆಯೆ ಎಂದು ನಿರ್ಧರಿಸಲು ಇದನ್ನು ವ್ಯಕ್ತಿತ್ವ ವಾಡಿಕೆಯಿಂದ ಬಳಸಲಾಗುತ್ತದೆ.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-ಮಾರಾಟಗಾರ, ಭಾಷೆ
    0x4d4f5a_00_52555354
}

// ಪ್ರತಿ ವಾಸ್ತುಶಿಲ್ಪಕ್ಕೆ LLVM ನ TargetLowering::getExceptionPointerRegister() ಮತ್ತು TargetLowering::getExceptionSelectorRegister() ನಿಂದ ರಿಜಿಸ್ಟರ್ ಐಡಿಗಳನ್ನು ಎತ್ತಲಾಯಿತು, ನಂತರ ರಿಜಿಸ್ಟರ್ ಡೆಫಿನಿಷನ್ ಕೋಷ್ಟಕಗಳ ಮೂಲಕ DWARF ರಿಜಿಸ್ಟರ್ ಸಂಖ್ಯೆಗಳಿಗೆ ಮ್ಯಾಪ್ ಮಾಡಲಾಗಿದೆ (ಸಾಮಾನ್ಯವಾಗಿ<arch>ರಿಜಿಸ್ಟರ್ಇನ್ಫೋ.ಟಿಡಿ, ಎಕ್ಸ್ 02 ಎಕ್ಸ್ ಗಾಗಿ ಹುಡುಕಿ).
//
// http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register ಸಹ ನೋಡಿ.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // ಇಎಎಕ್ಸ್, ಇಡಿಎಕ್ಸ್

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // ರಾಕ್ಸ್, ಆರ್ಡಿಎಕ್ಸ್

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// ಕೆಳಗಿನ ಕೋಡ್ GCC ನ C ಮತ್ತು C++ ವ್ಯಕ್ತಿತ್ವ ದಿನಚರಿಗಳನ್ನು ಆಧರಿಸಿದೆ.ಉಲ್ಲೇಖಕ್ಕಾಗಿ, ನೋಡಿ:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM ಇಹಾಬಿ ವ್ಯಕ್ತಿತ್ವ ದಿನಚರಿ.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS SjLj ಬಿಚ್ಚುವಿಕೆಯನ್ನು ಬಳಸುವುದರಿಂದ ಡೀಫಾಲ್ಟ್ ದಿನಚರಿಯನ್ನು ಬಳಸುತ್ತದೆ.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // ARM ನಲ್ಲಿನ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ಗಳು ವ್ಯಕ್ತಿತ್ವದ ದಿನಚರಿಯನ್ನು ರಾಜ್ಯ==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // ಅಂತಹ ಸಂದರ್ಭಗಳಲ್ಲಿ ನಾವು ಸ್ಟಾಕ್ ಅನ್ನು ಬಿಚ್ಚುವುದನ್ನು ಮುಂದುವರಿಸಲು ಬಯಸುತ್ತೇವೆ, ಇಲ್ಲದಿದ್ದರೆ ನಮ್ಮ ಎಲ್ಲಾ ಬ್ಯಾಕ್‌ಟ್ರೇಸ್‌ಗಳು __rust_try ನಲ್ಲಿ ಕೊನೆಗೊಳ್ಳುತ್ತವೆ
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // _ಅನ್‌ವಿಂಡ್_ಕಾಂಟೆಕ್ಸ್ಟ್ ಕಾರ್ಯ ಮತ್ತು ಎಲ್‌ಎಸ್‌ಡಿಎ ಪಾಯಿಂಟರ್‌ಗಳಂತಹ ವಿಷಯಗಳನ್ನು ಹೊಂದಿದೆ ಎಂದು ಡಿಡಬ್ಲ್ಯುಎಆರ್ಎಫ್ ಅನ್‌ವೈಂಡರ್ umes ಹಿಸುತ್ತದೆ, ಆದರೆ ಎಆರ್ಎಂ ಇಹಾಬಿ ಅವುಗಳನ್ನು ಎಕ್ಸೆಪ್ಶನ್ ಆಬ್ಜೆಕ್ಟ್‌ನಲ್ಲಿ ಇರಿಸುತ್ತದೆ.
            // ಸನ್ನಿವೇಶ ಪಾಯಿಂಟರ್ ಅನ್ನು ಮಾತ್ರ ತೆಗೆದುಕೊಳ್ಳುವ _Unwind_GetLanguageSpecificData() ನಂತಹ ಕಾರ್ಯಗಳ ಸಹಿಯನ್ನು ಸಂರಕ್ಷಿಸಲು, ARM ನ "scratch register" (r12) ಗಾಗಿ ಕಾಯ್ದಿರಿಸಿದ ಸ್ಥಳವನ್ನು ಬಳಸಿಕೊಂಡು, GCC ವ್ಯಕ್ತಿತ್ವ ವಾಡಿಕೆಯು ಸನ್ನಿವೇಶದಲ್ಲಿ ಎಕ್ಸೆಪ್ಶನ್_ಆಬ್ಜೆಕ್ಟ್ಗೆ ಪಾಯಿಂಟರ್ ಅನ್ನು ಜೋಡಿಸುತ್ತದೆ.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... ನಮ್ಮ ಲಿಬನ್‌ವಿಂಡ್ ಬೈಂಡಿಂಗ್‌ಗಳಲ್ಲಿ ARM ನ _ಅನ್‌ವಿಂಡ್_ಕಾಂಟೆಕ್ಸ್ಟ್‌ನ ಸಂಪೂರ್ಣ ವ್ಯಾಖ್ಯಾನವನ್ನು ಒದಗಿಸುವುದು ಮತ್ತು ಅಗತ್ಯವಿರುವ ಡೇಟಾವನ್ನು ಅಲ್ಲಿಂದ ನೇರವಾಗಿ ಪಡೆದುಕೊಳ್ಳುವುದು, DWARF ಹೊಂದಾಣಿಕೆ ಕಾರ್ಯಗಳನ್ನು ಬೈಪಾಸ್ ಮಾಡುವುದು ಹೆಚ್ಚು ತತ್ವಬದ್ಧ ವಿಧಾನವಾಗಿದೆ.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // ಎಕ್ಸೆಪ್ಶನ್ ಆಬ್ಜೆಕ್ಟ್ನ ತಡೆಗೋಡೆ ಸಂಗ್ರಹದಲ್ಲಿ ಎಸ್ಪಿ ಮೌಲ್ಯವನ್ನು ನವೀಕರಿಸಲು EHABI ಗೆ ವ್ಯಕ್ತಿತ್ವ ವಾಡಿಕೆಯ ಅಗತ್ಯವಿದೆ.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // ARM EHABI ನಲ್ಲಿ, ಹಿಂದಿರುಗುವ ಮೊದಲು ಒಂದೇ ಸ್ಟಾಕ್ ಫ್ರೇಮ್ ಅನ್ನು ಬಿಚ್ಚಲು ವ್ಯಕ್ತಿತ್ವದ ದಿನಚರಿಯು ಕಾರಣವಾಗಿದೆ (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // libgcc ನಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿದೆ
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // ಡೀಫಾಲ್ಟ್ ವ್ಯಕ್ತಿತ್ವ ದಿನಚರಿ, ಇದನ್ನು ಹೆಚ್ಚಿನ ಗುರಿಗಳಲ್ಲಿ ನೇರವಾಗಿ ಮತ್ತು ಪರೋಕ್ಷವಾಗಿ SEH ಮೂಲಕ Windows x86_64 ನಲ್ಲಿ ಬಳಸಲಾಗುತ್ತದೆ.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // x86_64 MinGW ಗುರಿಗಳಲ್ಲಿ, ಬಿಚ್ಚುವ ಕಾರ್ಯವಿಧಾನವು SEH ಆಗಿದೆ, ಆದರೆ ಬಿಚ್ಚುವ ಹ್ಯಾಂಡ್ಲರ್ ಡೇಟಾ (ಅಕಾ LSDA) GCC-ಹೊಂದಾಣಿಕೆಯ ಎನ್‌ಕೋಡಿಂಗ್ ಅನ್ನು ಬಳಸುತ್ತದೆ.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // ನಮ್ಮ ಹೆಚ್ಚಿನ ಗುರಿಗಳಿಗೆ ವ್ಯಕ್ತಿತ್ವದ ದಿನಚರಿ.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // ರಿಟರ್ನ್ ವಿಳಾಸವು ಕರೆ ಸೂಚನೆಯ ಹಿಂದೆ 1 ಬೈಟ್ ಅನ್ನು ಸೂಚಿಸುತ್ತದೆ, ಇದು ಎಲ್ಎಸ್ಡಿಎ ಶ್ರೇಣಿ ಕೋಷ್ಟಕದಲ್ಲಿ ಮುಂದಿನ ಐಪಿ ಶ್ರೇಣಿಯಲ್ಲಿರಬಹುದು.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// ಫ್ರೇಮ್ ಬಿಚ್ಚುವ ಮಾಹಿತಿ ನೋಂದಣಿ
//
// ಪ್ರತಿಯೊಂದು ಮಾಡ್ಯೂಲ್ನ ಚಿತ್ರವು ಫ್ರೇಮ್ ಬಿಚ್ಚುವ ಮಾಹಿತಿ ವಿಭಾಗವನ್ನು ಹೊಂದಿರುತ್ತದೆ (ಸಾಮಾನ್ಯವಾಗಿ ".eh_frame").ಮಾಡ್ಯೂಲ್ ಪ್ರಕ್ರಿಯೆಯಲ್ಲಿ loaded/unloaded ಆಗಿದ್ದಾಗ, ಮೆಮೊರಿಯಲ್ಲಿ ಈ ವಿಭಾಗದ ಸ್ಥಳದ ಬಗ್ಗೆ ಅನ್‌ವೈಂಡರ್ಗೆ ತಿಳಿಸಬೇಕು.ಅದನ್ನು ಸಾಧಿಸುವ ವಿಧಾನಗಳು ವೇದಿಕೆಯಿಂದ ಬದಲಾಗುತ್ತವೆ.
// ಕೆಲವು (ಉದಾ., Linux) ನಲ್ಲಿ, ಬಿಚ್ಚುವ ಮಾಹಿತಿಯ ವಿಭಾಗಗಳನ್ನು ತನ್ನದೇ ಆದ ಮೇಲೆ ಕಂಡುಹಿಡಿಯಬಹುದು (ಪ್ರಸ್ತುತ ಲೋಡ್ ಮಾಡಲಾದ ಮಾಡ್ಯೂಲ್‌ಗಳನ್ನು dl_iterate_phdr() API and finding their ".eh_frame" sections) ಮೂಲಕ ಕ್ರಿಯಾತ್ಮಕವಾಗಿ ಎಣಿಸುವ ಮೂಲಕ; Windows ನಂತಹ ಇತರರಿಗೆ, ಅನ್‌ವೈಂಡರ್ API ಮೂಲಕ ತಮ್ಮ ಬಿಚ್ಚಿದ ಮಾಹಿತಿ ವಿಭಾಗಗಳನ್ನು ಸಕ್ರಿಯವಾಗಿ ನೋಂದಾಯಿಸಲು ಮಾಡ್ಯೂಲ್‌ಗಳು ಬೇಕಾಗುತ್ತವೆ.
//
//
// ಈ ಮಾಡ್ಯೂಲ್ ನಮ್ಮ ಚಿಹ್ನೆಗಳನ್ನು GCC ರನ್ಟೈಮ್ನೊಂದಿಗೆ ನೋಂದಾಯಿಸಲು rsbegin.rs ನಿಂದ ಉಲ್ಲೇಖಿಸಲ್ಪಟ್ಟ ಮತ್ತು ಕರೆಯಲ್ಪಡುವ ಎರಡು ಚಿಹ್ನೆಗಳನ್ನು ವ್ಯಾಖ್ಯಾನಿಸುತ್ತದೆ.
// ಸ್ಟಾಕ್ ಬಿಚ್ಚುವಿಕೆಯ ಅನುಷ್ಠಾನವನ್ನು (ಸದ್ಯಕ್ಕೆ) libgcc_eh ಗೆ ಮುಂದೂಡಲಾಗಿದೆ, ಆದಾಗ್ಯೂ Rust crates ಯಾವುದೇ GCC ರನ್ಟೈಮ್‌ನೊಂದಿಗೆ ಸಂಭಾವ್ಯ ಘರ್ಷಣೆಯನ್ನು ತಪ್ಪಿಸಲು ಈ Rust-ನಿರ್ದಿಷ್ಟ ಪ್ರವೇಶ ಬಿಂದುಗಳನ್ನು ಬಳಸುತ್ತದೆ.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}