//! *Wasm32* ಗುರಿಗಾಗಿ ಬಿಚ್ಚುವುದು.
//!
//! ಇದೀಗ ನಾವು ಇದನ್ನು ಬೆಂಬಲಿಸುವುದಿಲ್ಲ, ಆದ್ದರಿಂದ ಇದು ಕೇವಲ ಸ್ಟಬ್‌ಗಳು.

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;

pub unsafe fn cleanup(_ptr: *mut u8) -> Box<dyn Any + Send> {
    intrinsics::abort()
}

pub unsafe fn panic(_data: Box<dyn Any + Send>) -> u32 {
    intrinsics::abort()
}