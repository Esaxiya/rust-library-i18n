//! DWARF-ಎನ್ಕೋಡ್ ಮಾಡಿದ ಡೇಟಾ ಸ್ಟ್ರೀಮ್‌ಗಳನ್ನು ಪಾರ್ಸ್ ಮಾಡುವ ಉಪಯುಕ್ತತೆಗಳು.
//! <http://www.dwarfstd.org>, DWARF-4 ಸ್ಟ್ಯಾಂಡರ್ಡ್, ವಿಭಾಗ 7, "Data Representation" ನೋಡಿ
//!

// ಈ ಮಾಡ್ಯೂಲ್ ಅನ್ನು ಇದೀಗ x86_64-pc-windows-gnu ಮಾತ್ರ ಬಳಸುತ್ತದೆ, ಆದರೆ ಹಿಂಜರಿತಗಳನ್ನು ತಪ್ಪಿಸಲು ನಾವು ಅದನ್ನು ಎಲ್ಲೆಡೆ ಕಂಪೈಲ್ ಮಾಡುತ್ತಿದ್ದೇವೆ.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // DWARF ಸ್ಟ್ರೀಮ್‌ಗಳು ಪ್ಯಾಕ್ ಆಗಿವೆ, ಆದ್ದರಿಂದ ಉದಾ., u32 ಅನ್ನು 4-ಬೈಟ್ ಗಡಿಯಲ್ಲಿ ಜೋಡಿಸಬೇಕಾಗಿಲ್ಲ.
    // ಕಟ್ಟುನಿಟ್ಟಾದ ಜೋಡಣೆ ಅವಶ್ಯಕತೆಗಳನ್ನು ಹೊಂದಿರುವ ಪ್ಲ್ಯಾಟ್‌ಫಾರ್ಮ್‌ಗಳಲ್ಲಿ ಇದು ಸಮಸ್ಯೆಗಳನ್ನು ಉಂಟುಮಾಡಬಹುದು.
    // "packed" struct ನಲ್ಲಿ ಡೇಟಾವನ್ನು ಸುತ್ತುವ ಮೂಲಕ, ನಾವು "misalignment-safe" ಕೋಡ್ ಅನ್ನು ರಚಿಸಲು ಬ್ಯಾಕೆಂಡ್‌ಗೆ ಹೇಳುತ್ತಿದ್ದೇವೆ.
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ULEB128 ಮತ್ತು SLEB128 ಎನ್‌ಕೋಡಿಂಗ್‌ಗಳನ್ನು ವಿಭಾಗ 7.6, "Variable Length Data" ನಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿದೆ.
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}