//! Windows SEH
//!
//! Windows ನಲ್ಲಿ (ಪ್ರಸ್ತುತ MSVC ಯಲ್ಲಿ ಮಾತ್ರ), ಡೀಫಾಲ್ಟ್ ಎಕ್ಸೆಪ್ಶನ್ ಹ್ಯಾಂಡ್ಲಿಂಗ್ ಯಾಂತ್ರಿಕತೆಯು ಸ್ಟ್ರಕ್ಚರ್ಡ್ ಎಕ್ಸೆಪ್ಶನ್ ಹ್ಯಾಂಡ್ಲಿಂಗ್ (SEH) ಆಗಿದೆ.
//! ಕಂಪೈಲರ್ ಇಂಟರ್ನಲ್‌ಗಳ ವಿಷಯದಲ್ಲಿ ಇದು ಡ್ವಾರ್ಫ್-ಆಧಾರಿತ ಎಕ್ಸೆಪ್ಶನ್ ಹ್ಯಾಂಡ್ಲಿಂಗ್ (ಉದಾ. ಇತರ unix ಪ್ಲಾಟ್‌ಫಾರ್ಮ್‌ಗಳು) ಗಿಂತ ಸಾಕಷ್ಟು ಭಿನ್ನವಾಗಿದೆ, ಆದ್ದರಿಂದ ಎಸ್‌ಎಚ್‌ಗೆ ಎಲ್‌ಎಲ್‌ವಿಎಂ ಉತ್ತಮ ಹೆಚ್ಚುವರಿ ಬೆಂಬಲವನ್ನು ಹೊಂದಿರಬೇಕು.
//!
//! ಸಂಕ್ಷಿಪ್ತವಾಗಿ, ಇಲ್ಲಿ ಏನಾಗುತ್ತದೆ:
//!
//! 1. `panic` ಕಾರ್ಯವು C++ ಅನ್ನು ಎಸೆಯಲು ಸ್ಟ್ಯಾಂಡರ್ಡ್ Windows ಫಂಕ್ಷನ್ `_CxxThrowException` ಅನ್ನು ಕರೆಯುತ್ತದೆ-ವಿನಾಯಿತಿಯಂತೆ, ಬಿಚ್ಚುವ ಪ್ರಕ್ರಿಯೆಯನ್ನು ಪ್ರಚೋದಿಸುತ್ತದೆ.
//! 2.
//! ಕಂಪೈಲರ್‌ನಿಂದ ಉತ್ಪತ್ತಿಯಾಗುವ ಎಲ್ಲಾ ಲ್ಯಾಂಡಿಂಗ್ ಪ್ಯಾಡ್‌ಗಳು ಸಿಆರ್‌ಟಿಯಲ್ಲಿನ ಫಂಕ್ಷನ್ ಪರ್ಸನಾಲಿಟಿ ಫಂಕ್ಷನ್ ಎಕ್ಸ್‌00 ಎಕ್ಸ್ ಅನ್ನು ಬಳಸುತ್ತವೆ ಮತ್ತು ಎಕ್ಸ್‌01 ಎಕ್ಸ್‌ನಲ್ಲಿನ ಬಿಚ್ಚುವ ಕೋಡ್ ಈ ವ್ಯಕ್ತಿತ್ವ ಕಾರ್ಯವನ್ನು ಸ್ಟಾಕ್‌ನಲ್ಲಿ ಎಲ್ಲಾ ಕ್ಲೀನಪ್ ಕೋಡ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲು ಬಳಸುತ್ತದೆ.
//!
//! 3. `invoke` ಗೆ ಎಲ್ಲಾ ಕಂಪೈಲರ್-ರಚಿತ ಕರೆಗಳು ಲ್ಯಾಂಡಿಂಗ್ ಪ್ಯಾಡ್ ಅನ್ನು `cleanuppad` LLVM ಸೂಚನೆಯಂತೆ ಹೊಂದಿಸಿವೆ, ಇದು ಸ್ವಚ್ clean ಗೊಳಿಸುವ ದಿನಚರಿಯ ಪ್ರಾರಂಭವನ್ನು ಸೂಚಿಸುತ್ತದೆ.
//! ವ್ಯಕ್ತಿತ್ವ (ಹಂತ 2 ರಲ್ಲಿ, ಸಿಆರ್‌ಟಿಯಲ್ಲಿ ವ್ಯಾಖ್ಯಾನಿಸಲಾಗಿದೆ) ಸ್ವಚ್ clean ಗೊಳಿಸುವ ದಿನಚರಿಯನ್ನು ನಡೆಸಲು ಕಾರಣವಾಗಿದೆ.
//! 4. ಅಂತಿಮವಾಗಿ `try` ಆಂತರಿಕ (ಕಂಪೈಲರ್‌ನಿಂದ ಉತ್ಪತ್ತಿಯಾಗುತ್ತದೆ) ನಲ್ಲಿನ "catch" ಕೋಡ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ನಿಯಂತ್ರಣವು Rust ಗೆ ಹಿಂತಿರುಗಬೇಕು ಎಂದು ಸೂಚಿಸುತ್ತದೆ.
//! ಇದನ್ನು LLVM IR ಪರಿಭಾಷೆಯಲ್ಲಿ `catchswitch` ಜೊತೆಗೆ `catchpad` ಸೂಚನೆಯ ಮೂಲಕ ಮಾಡಲಾಗುತ್ತದೆ, ಅಂತಿಮವಾಗಿ `catchret` ಸೂಚನೆಯೊಂದಿಗೆ ಪ್ರೋಗ್ರಾಂಗೆ ಸಾಮಾನ್ಯ ನಿಯಂತ್ರಣವನ್ನು ಹಿಂದಿರುಗಿಸುತ್ತದೆ.
//!
//! gcc-ಆಧಾರಿತ ಎಕ್ಸೆಪ್ಶನ್ ಹ್ಯಾಂಡ್ಲಿಂಗ್‌ನಿಂದ ಕೆಲವು ನಿರ್ದಿಷ್ಟ ವ್ಯತ್ಯಾಸಗಳು:
//!
//! * Rust ಯಾವುದೇ ಕಸ್ಟಮ್ ವ್ಯಕ್ತಿತ್ವ ಕಾರ್ಯವನ್ನು ಹೊಂದಿಲ್ಲ, ಬದಲಿಗೆ *ಯಾವಾಗಲೂ*`__CxxFrameHandler3` ಆಗಿದೆ.ಹೆಚ್ಚುವರಿಯಾಗಿ, ಯಾವುದೇ ಹೆಚ್ಚುವರಿ ಫಿಲ್ಟರಿಂಗ್ ಅನ್ನು ನಿರ್ವಹಿಸಲಾಗುವುದಿಲ್ಲ, ಆದ್ದರಿಂದ ನಾವು ಎಸೆಯುವ ರೀತಿಯಂತೆ ಕಾಣುವ ಯಾವುದೇ ಸಿ ++ ವಿನಾಯಿತಿಗಳನ್ನು ನಾವು ಹಿಡಿಯುತ್ತೇವೆ.
//! Rust ಗೆ ಒಂದು ವಿನಾಯಿತಿಯನ್ನು ಎಸೆಯುವುದು ಹೇಗಾದರೂ ವಿವರಿಸಲಾಗದ ವರ್ತನೆಯಾಗಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಆದ್ದರಿಂದ ಇದು ಉತ್ತಮವಾಗಿರಬೇಕು.
//! * ಬಿಚ್ಚುವ ಗಡಿಯುದ್ದಕ್ಕೂ ನಿರ್ದಿಷ್ಟವಾಗಿ `Box<dyn Any + Send>` ರವಾನಿಸಲು ನಮಗೆ ಕೆಲವು ಡೇಟಾ ಸಿಕ್ಕಿದೆ.ಡ್ವಾರ್ಫ್ ವಿನಾಯಿತಿಗಳಂತೆ ಈ ಎರಡು ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ವಿನಾಯಿತಿಯಲ್ಲಿಯೇ ಪೇಲೋಡ್ ಆಗಿ ಸಂಗ್ರಹಿಸಲಾಗುತ್ತದೆ.
//! ಆದಾಗ್ಯೂ, MSVC ಯಲ್ಲಿ, ಹೆಚ್ಚುವರಿ ರಾಶಿ ಹಂಚಿಕೆಯ ಅಗತ್ಯವಿಲ್ಲ ಏಕೆಂದರೆ ಫಿಲ್ಟರ್ ಕಾರ್ಯಗಳನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವಾಗ ಕರೆ ಸ್ಟಾಕ್ ಅನ್ನು ಸಂರಕ್ಷಿಸಲಾಗಿದೆ.
//! ಇದರರ್ಥ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ನೇರವಾಗಿ `_CxxThrowException` ಗೆ ರವಾನಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ನಂತರ ಅದನ್ನು ಫಿಲ್ಟರ್ ಕಾರ್ಯದಲ್ಲಿ ಮರುಪಡೆಯಲಾಗುತ್ತದೆ ಮತ್ತು `try` ಆಂತರಿಕ ಸ್ಟಾಕ್ ಫ್ರೇಮ್‌ಗೆ ಬರೆಯಲಾಗುತ್ತದೆ.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // ಇದು ಒಂದು ಆಯ್ಕೆಯಾಗಿರಬೇಕು ಏಕೆಂದರೆ ನಾವು ವಿನಾಯಿತಿಯನ್ನು ಉಲ್ಲೇಖದಿಂದ ಹಿಡಿಯುತ್ತೇವೆ ಮತ್ತು ಅದರ ವಿನಾಶಕವನ್ನು C++ ರನ್ಟೈಮ್ನಿಂದ ಕಾರ್ಯಗತಗೊಳಿಸಲಾಗುತ್ತದೆ.
    // ನಾವು ಬಾಕ್ಸ್ ಅನ್ನು ವಿನಾಯಿತಿಯಿಂದ ತೆಗೆದುಕೊಂಡಾಗ, ಬಾಕ್ಸ್ ಅನ್ನು ಡಬಲ್ ಡ್ರಾಪ್ ಮಾಡದೆಯೇ ಅದರ ವಿನಾಶಕವು ಚಲಾಯಿಸಲು ನಾವು ವಿನಾಯಿತಿಯನ್ನು ಮಾನ್ಯ ಸ್ಥಿತಿಯಲ್ಲಿ ಬಿಡಬೇಕಾಗುತ್ತದೆ.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// ಮೊದಲಿಗೆ, ಟೈಪ್ ವ್ಯಾಖ್ಯಾನಗಳ ಸಂಪೂರ್ಣ ಗುಂಪೇ.ಇಲ್ಲಿ ಕೆಲವು ಪ್ಲಾಟ್‌ಫಾರ್ಮ್-ನಿರ್ದಿಷ್ಟ ವಿಚಿತ್ರತೆಗಳಿವೆ, ಮತ್ತು ಎಲ್‌ಎಲ್‌ವಿಎಂನಿಂದ ಕೇವಲ ನಕಲಾಗಿ ನಕಲಿಸಲಾಗಿದೆ.ಈ ಎಲ್ಲದರ ಉದ್ದೇಶವು ಕೆಳಗಿನ `panic` ಕಾರ್ಯವನ್ನು `_CxxThrowException` ಗೆ ಕರೆ ಮಾಡುವ ಮೂಲಕ ಕಾರ್ಯಗತಗೊಳಿಸುವುದು.
//
// ಈ ಕಾರ್ಯವು ಎರಡು ವಾದಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳುತ್ತದೆ.ಮೊದಲನೆಯದು ನಾವು ಹಾದುಹೋಗುವ ಡೇಟಾಗೆ ಪಾಯಿಂಟರ್ ಆಗಿದೆ, ಈ ಸಂದರ್ಭದಲ್ಲಿ ಅದು ನಮ್ಮ trait ಆಬ್ಜೆಕ್ಟ್ ಆಗಿದೆ.ಹುಡುಕಲು ಬಹಳ ಸುಲಭ!ಆದಾಗ್ಯೂ, ಮುಂದಿನದು ಹೆಚ್ಚು ಜಟಿಲವಾಗಿದೆ.
// ಇದು `_ThrowInfo` ರಚನೆಗೆ ಪಾಯಿಂಟರ್ ಆಗಿದೆ, ಮತ್ತು ಇದು ಸಾಮಾನ್ಯವಾಗಿ ಎಸೆಯಲ್ಪಟ್ಟ ವಿನಾಯಿತಿಯನ್ನು ವಿವರಿಸಲು ಉದ್ದೇಶಿಸಲಾಗಿದೆ.
//
// ಪ್ರಸ್ತುತ ಈ ಪ್ರಕಾರದ [1] ನ ವ್ಯಾಖ್ಯಾನವು ಸ್ವಲ್ಪ ಕೂದಲುಳ್ಳದ್ದಾಗಿದೆ, ಮತ್ತು ಮುಖ್ಯ ವಿಚಿತ್ರವೆಂದರೆ (ಮತ್ತು ಆನ್‌ಲೈನ್ ಲೇಖನದಿಂದ ವ್ಯತ್ಯಾಸ) 32-ಬಿಟ್‌ನಲ್ಲಿ ಪಾಯಿಂಟರ್‌ಗಳು ಪಾಯಿಂಟರ್‌ಗಳಾಗಿವೆ ಆದರೆ 64-ಬಿಟ್‌ನಲ್ಲಿ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು 32-ಬಿಟ್ ಆಫ್‌ಸೆಟ್‌ಗಳಾಗಿ ವ್ಯಕ್ತಪಡಿಸಲಾಗುತ್ತದೆ `__ImageBase` ಚಿಹ್ನೆ.
//
// ಇದನ್ನು ವ್ಯಕ್ತಪಡಿಸಲು ಕೆಳಗಿನ ಮಾಡ್ಯೂಲ್‌ಗಳಲ್ಲಿನ `ptr_t` ಮತ್ತು `ptr!` ಮ್ಯಾಕ್ರೋವನ್ನು ಬಳಸಲಾಗುತ್ತದೆ.
//
// ಪ್ರಕಾರದ ವ್ಯಾಖ್ಯಾನಗಳ ಜಟಿಲವು ಈ ರೀತಿಯ ಕಾರ್ಯಾಚರಣೆಗೆ ಎಲ್ಎಲ್ವಿಎಂ ಹೊರಸೂಸುವದನ್ನು ಸಹ ನಿಕಟವಾಗಿ ಅನುಸರಿಸುತ್ತದೆ.ಉದಾಹರಣೆಗೆ, ನೀವು ಈ ಸಿ ++ ಕೋಡ್ ಅನ್ನು ಎಂಎಸ್‌ವಿಸಿಯಲ್ಲಿ ಕಂಪೈಲ್ ಮಾಡಿ ಮತ್ತು ಎಲ್‌ಎಲ್‌ವಿಎಂ ಐಆರ್ ಅನ್ನು ಹೊರಸೂಸಿದರೆ:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      ಅನೂರ್ಜಿತ foo() { rust_panic a = {0, 1};
//          ಎಸೆಯಿರಿ;}
//
// ಮೂಲಭೂತವಾಗಿ ನಾವು ಅನುಕರಿಸಲು ಪ್ರಯತ್ನಿಸುತ್ತಿದ್ದೇವೆ.ಕೆಳಗಿನ ಹೆಚ್ಚಿನ ಸ್ಥಿರ ಮೌಲ್ಯಗಳನ್ನು ಕೇವಲ LLVM ನಿಂದ ನಕಲಿಸಲಾಗಿದೆ,
//
// ಯಾವುದೇ ಸಂದರ್ಭದಲ್ಲಿ, ಈ ರಚನೆಗಳೆಲ್ಲವೂ ಒಂದೇ ರೀತಿಯಾಗಿ ನಿರ್ಮಿಸಲ್ಪಟ್ಟಿವೆ, ಮತ್ತು ಇದು ನಮಗೆ ಸ್ವಲ್ಪ ಮಟ್ಟಿಗೆ ಮಾತಿನಂತಿದೆ.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// ಇಲ್ಲಿ ಹೆಸರು ಮ್ಯಾಂಗ್ಲಿಂಗ್ ನಿಯಮಗಳನ್ನು ನಾವು ಉದ್ದೇಶಪೂರ್ವಕವಾಗಿ ನಿರ್ಲಕ್ಷಿಸುತ್ತೇವೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ: `struct rust_panic` ಅನ್ನು ಸರಳವಾಗಿ ಘೋಷಿಸುವ ಮೂಲಕ C++ Rust panics ಅನ್ನು ಹಿಡಿಯಲು ನಾವು ಬಯಸುವುದಿಲ್ಲ.
//
//
// ಮಾರ್ಪಡಿಸುವಾಗ, ಟೈಪ್ ನೇಮ್ ಸ್ಟ್ರಿಂಗ್ `compiler/rustc_codegen_llvm/src/intrinsic.rs` ನಲ್ಲಿ ಬಳಸಿದ ಒಂದಕ್ಕೆ ನಿಖರವಾಗಿ ಹೊಂದಿಕೆಯಾಗಿದೆಯೆ ಎಂದು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಿ.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // ಇಲ್ಲಿರುವ ಪ್ರಮುಖ `\x01` ಬೈಟ್ ವಾಸ್ತವವಾಗಿ LLVM ಗೆ ಮಾಂತ್ರಿಕ ಸಂಕೇತವಾಗಿದ್ದು, `_` ಅಕ್ಷರದೊಂದಿಗೆ ಪೂರ್ವಪ್ರತ್ಯಯದಂತಹ ಯಾವುದೇ ಮಾಂಗ್ಲಿಂಗ್ ಅನ್ನು ಅನ್ವಯಿಸಬಾರದು.
    //
    //
    // ಈ ಚಿಹ್ನೆಯು C++ ನ `std::type_info` ಬಳಸುವ vtable ಆಗಿದೆ.
    // ಟೈಪ್ `std::type_info` ನ ಆಬ್ಜೆಕ್ಟ್‌ಗಳು, ಟೈಪ್ ಡಿಸ್ಕ್ರಿಪ್ಟರ್‌ಗಳು ಈ ಟೇಬಲ್‌ಗೆ ಪಾಯಿಂಟರ್ ಅನ್ನು ಹೊಂದಿವೆ.
    // ಟೈಪ್ ಡಿಸ್ಕ್ರಿಪ್ಟರ್‌ಗಳನ್ನು ಮೇಲೆ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ಸಿ ++ ಇಹೆಚ್ ರಚನೆಗಳಿಂದ ಉಲ್ಲೇಖಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ನಾವು ಕೆಳಗೆ ನಿರ್ಮಿಸುತ್ತೇವೆ.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// ವಿನಾಯಿತಿಯನ್ನು ಎಸೆಯುವಾಗ ಮಾತ್ರ ಈ ಪ್ರಕಾರದ ವಿವರಣೆಯನ್ನು ಬಳಸಲಾಗುತ್ತದೆ.
// ಕ್ಯಾಚ್ ಭಾಗವನ್ನು ತನ್ನದೇ ಆದ ಟೈಪ್‌ಡೆಸ್ಕ್ರಿಪ್ಟರ್ ಅನ್ನು ಉತ್ಪಾದಿಸುವ ಪ್ರಯತ್ನ ಆಂತರಿಕ ನಿರ್ವಹಿಸುತ್ತದೆ.
//
// ಎಂಎಸ್ವಿಸಿ ರನ್ಟೈಮ್ ಪಾಯಿಂಟರ್ ಸಮಾನತೆಗೆ ಬದಲಾಗಿ ಟೈಪ್ ಡಿಸ್ಕ್ರಿಪ್ಟರ್ಗಳಿಗೆ ಹೊಂದಿಸಲು ಟೈಪ್ ಹೆಸರಿನ ಸ್ಟ್ರಿಂಗ್ ಹೋಲಿಕೆಯನ್ನು ಬಳಸುವುದರಿಂದ ಇದು ಉತ್ತಮವಾಗಿದೆ.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// ಸಿ ++ ಕೋಡ್ ವಿನಾಯಿತಿಯನ್ನು ಸೆರೆಹಿಡಿಯಲು ಮತ್ತು ಅದನ್ನು ಪ್ರಚಾರ ಮಾಡದೆ ಬಿಡಲು ನಿರ್ಧರಿಸಿದರೆ ಡಿಸ್ಟ್ರಕ್ಟರ್ ಬಳಸಲಾಗುತ್ತದೆ.
// ಪ್ರಯತ್ನದ ಕ್ಯಾಚ್ ಭಾಗವು ಎಕ್ಸೆಪ್ಶನ್ ಆಬ್ಜೆಕ್ಟ್ನ ಮೊದಲ ಪದವನ್ನು 0 ಗೆ ಹೊಂದಿಸುತ್ತದೆ ಇದರಿಂದ ಅದನ್ನು ಡಿಸ್ಟ್ರಕ್ಟರ್‌ನಿಂದ ಬಿಡಲಾಗುತ್ತದೆ.
//
// x86 Windows ಡೀಫಾಲ್ಟ್ "C" ಕರೆ ಸಮಾವೇಶದ ಬದಲು C++ ಸದಸ್ಯ ಕಾರ್ಯಗಳಿಗಾಗಿ "thiscall" ಕರೆ ಸಮಾವೇಶವನ್ನು ಬಳಸುತ್ತದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ.
//
// ಎಕ್ಸೆಪ್ಶನ್_ಕೋಪಿ ಕಾರ್ಯವು ಇಲ್ಲಿ ಸ್ವಲ್ಪ ವಿಶೇಷವಾಗಿದೆ: ಇದನ್ನು try/catch ಬ್ಲಾಕ್ ಅಡಿಯಲ್ಲಿ ಎಂಎಸ್ವಿಸಿ ರನ್ಟೈಮ್ನಿಂದ ಆಹ್ವಾನಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ನಾವು ಇಲ್ಲಿ ಉತ್ಪಾದಿಸುವ panic ಅನ್ನು ಎಕ್ಸೆಪ್ಶನ್ ನಕಲಿನ ಪರಿಣಾಮವಾಗಿ ಬಳಸಲಾಗುತ್ತದೆ.
//
// std::exception_ptr ನೊಂದಿಗೆ ವಿನಾಯಿತಿಗಳನ್ನು ಸೆರೆಹಿಡಿಯಲು ಸಿ ++ ರನ್ಟೈಮ್ ಇದನ್ನು ಬಳಸುತ್ತದೆ, ಇದನ್ನು ನಾವು ಬೆಂಬಲಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ ಏಕೆಂದರೆ ಬಾಕ್ಸ್<dyn Any>ಅಬೀಜ ಸಂತಾನೋತ್ಪತ್ತಿ ಅಲ್ಲ.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException ಈ ಸ್ಟಾಕ್ ಫ್ರೇಮ್‌ನಲ್ಲಿ ಸಂಪೂರ್ಣವಾಗಿ ಕಾರ್ಯಗತಗೊಳ್ಳುತ್ತದೆ, ಆದ್ದರಿಂದ `data` ಅನ್ನು ರಾಶಿಗೆ ವರ್ಗಾಯಿಸುವ ಅಗತ್ಯವಿಲ್ಲ.
    // ನಾವು ಈ ಕಾರ್ಯಕ್ಕೆ ಸ್ಟಾಕ್ ಪಾಯಿಂಟರ್ ಅನ್ನು ರವಾನಿಸುತ್ತೇವೆ.
    //
    // ಕೈಯಾರೆ ಡ್ರಾಪ್ ಇಲ್ಲಿ ಅಗತ್ಯವಿದೆ ಏಕೆಂದರೆ ಬಿಚ್ಚುವಾಗ ಎಕ್ಸೆಪ್ಶನ್ ಅನ್ನು ಕೈಬಿಡಬೇಕೆಂದು ನಾವು ಬಯಸುವುದಿಲ್ಲ.
    // ಬದಲಾಗಿ ಇದನ್ನು ಸಿ ++ ರನ್ಟೈಮ್ನಿಂದ ಆಹ್ವಾನಿಸಲಾಗಿರುವ ಎಕ್ಸೆಪ್ಶನ್_ಕ್ಲೀನಪ್ ಮೂಲಕ ಕೈಬಿಡಲಾಗುತ್ತದೆ.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // ಇದು ... ಆಶ್ಚರ್ಯಕರವೆಂದು ತೋರುತ್ತದೆ, ಮತ್ತು ಸಮರ್ಥನೀಯವಾಗಿ.32-ಬಿಟ್ ಎಂಎಸ್‌ವಿಸಿ ಯಲ್ಲಿ ಈ ರಚನೆಯ ನಡುವಿನ ಪಾಯಿಂಟರ್‌ಗಳು ಕೇವಲ, ಪಾಯಿಂಟರ್‌ಗಳು.
    // ಆದಾಗ್ಯೂ, 64-ಬಿಟ್ ಎಂಎಸ್‌ವಿಸಿಯಲ್ಲಿ, ರಚನೆಗಳ ನಡುವಿನ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು `__ImageBase` ನಿಂದ 32-ಬಿಟ್ ಆಫ್‌ಸೆಟ್‌ಗಳಾಗಿ ವ್ಯಕ್ತಪಡಿಸಲಾಗುತ್ತದೆ.
    //
    // ಪರಿಣಾಮವಾಗಿ, 32-ಬಿಟ್ ಎಂಎಸ್‌ವಿಸಿ ಯಲ್ಲಿ ನಾವು ಈ ಎಲ್ಲಾ ಪಾಯಿಂಟರ್‌ಗಳನ್ನು ಮೇಲಿನ `ಸ್ಥಿರ'ದಲ್ಲಿ ಘೋಷಿಸಬಹುದು.
    // 64-ಬಿಟ್ MSVC ಯಲ್ಲಿ, ನಾವು ಅಂಕಿಅಂಶಗಳಲ್ಲಿ ಪಾಯಿಂಟರ್‌ಗಳ ವ್ಯವಕಲನವನ್ನು ವ್ಯಕ್ತಪಡಿಸಬೇಕಾಗಿತ್ತು, ಅದು Rust ಪ್ರಸ್ತುತ ಅನುಮತಿಸುವುದಿಲ್ಲ, ಆದ್ದರಿಂದ ನಾವು ಅದನ್ನು ನಿಜವಾಗಿ ಮಾಡಲು ಸಾಧ್ಯವಿಲ್ಲ.
    //
    // ಮುಂದಿನ ಅತ್ಯುತ್ತಮ ವಿಷಯವೆಂದರೆ, ಈ ರಚನೆಗಳನ್ನು ರನ್ಟೈಮ್ನಲ್ಲಿ ಭರ್ತಿ ಮಾಡುವುದು (ಪ್ಯಾನಿಕ್ ಮಾಡುವುದು ಈಗಾಗಲೇ "slow path" ಆಗಿದೆ).
    // ಆದ್ದರಿಂದ ಇಲ್ಲಿ ನಾವು ಈ ಎಲ್ಲಾ ಪಾಯಿಂಟರ್ ಕ್ಷೇತ್ರಗಳನ್ನು 32-ಬಿಟ್ ಪೂರ್ಣಾಂಕಗಳಾಗಿ ಮರು ವ್ಯಾಖ್ಯಾನಿಸುತ್ತೇವೆ ಮತ್ತು ನಂತರ ಅದರಲ್ಲಿ ಸಂಬಂಧಿತ ಮೌಲ್ಯವನ್ನು ಸಂಗ್ರಹಿಸುತ್ತೇವೆ (ಪರಮಾಣು, ಏಕಕಾಲೀನ panics ಸಂಭವಿಸುತ್ತಿರಬಹುದು).
    //
    // ತಾಂತ್ರಿಕವಾಗಿ ಚಾಲನಾಸಮಯವು ಬಹುಶಃ ಈ ಕ್ಷೇತ್ರಗಳ ನಾನ್‌ಟಾಮಿಕ್ ಓದುವಿಕೆಯನ್ನು ಮಾಡುತ್ತದೆ, ಆದರೆ ಸಿದ್ಧಾಂತದಲ್ಲಿ ಅವರು ಎಂದಿಗೂ *ತಪ್ಪು* ಮೌಲ್ಯವನ್ನು ಓದುವುದಿಲ್ಲ ಆದ್ದರಿಂದ ಅದು ತುಂಬಾ ಕೆಟ್ಟದಾಗಿರಬಾರದು ...
    //
    // ಯಾವುದೇ ಸಂದರ್ಭದಲ್ಲಿ, ನಾವು ಅಂಕಿಅಂಶಗಳಲ್ಲಿ ಹೆಚ್ಚಿನ ಕಾರ್ಯಾಚರಣೆಗಳನ್ನು ವ್ಯಕ್ತಪಡಿಸುವವರೆಗೆ ನಾವು ಮೂಲತಃ ಈ ರೀತಿಯ ಕೆಲಸವನ್ನು ಮಾಡಬೇಕಾಗಿದೆ (ಮತ್ತು ನಮಗೆ ಎಂದಿಗೂ ಸಾಧ್ಯವಾಗದಿರಬಹುದು).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // ಇಲ್ಲಿ NULL ಪೇಲೋಡ್ ಎಂದರೆ __rust_try ಯ ಕ್ಯಾಚ್ (...) ನಿಂದ ನಾವು ಇಲ್ಲಿಗೆ ಬಂದಿದ್ದೇವೆ.
    // Rust ಅಲ್ಲದ ವಿದೇಶಿ ವಿನಾಯಿತಿ ಸಿಕ್ಕಿಬಿದ್ದಾಗ ಇದು ಸಂಭವಿಸುತ್ತದೆ.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// ಕಂಪೈಲರ್ ಅಸ್ತಿತ್ವದಲ್ಲಿರಲು ಇದು ಅಗತ್ಯವಾಗಿರುತ್ತದೆ (ಉದಾ., ಇದು ಲ್ಯಾಂಗ್ ಐಟಂ), ಆದರೆ ಇದನ್ನು ಕಂಪೈಲರ್ ಎಂದಿಗೂ ಕರೆಯುವುದಿಲ್ಲ ಏಕೆಂದರೆ __C_specific_handler ಅಥವಾ _except_handler3 ಯಾವಾಗಲೂ ಬಳಸುವ ವ್ಯಕ್ತಿತ್ವ ಕಾರ್ಯವಾಗಿದೆ.
//
// ಆದ್ದರಿಂದ ಇದು ಕೇವಲ ಸ್ಥಗಿತಗೊಳಿಸುವ ಸ್ಟಬ್ ಆಗಿದೆ.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}