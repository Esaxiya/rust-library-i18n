//! ಸ್ಟಾಕ್ ಬಿಚ್ಚುವಿಕೆಯ ಮೂಲಕ panics ನ ಅನುಷ್ಠಾನ
//!
//! ಈ crate ಇದು Rust ನಲ್ಲಿ panics ನ ಅನುಷ್ಠಾನವಾಗಿದ್ದು, ಇದನ್ನು ಸಂಕಲಿಸಲಾಗುತ್ತಿರುವ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್‌ನ "most native" ಸ್ಟಾಕ್ ಬಿಚ್ಚುವ ಕಾರ್ಯವಿಧಾನವನ್ನು ಬಳಸುತ್ತದೆ.
//! ಇದು ಮೂಲಭೂತವಾಗಿ ಪ್ರಸ್ತುತ ಮೂರು ಬಕೆಟ್‌ಗಳಾಗಿ ವರ್ಗೀಕರಿಸಲ್ಪಡುತ್ತದೆ:
//!
//! 1. MSVC ಗುರಿಗಳು `seh.rs` ಫೈಲ್‌ನಲ್ಲಿ SEH ಅನ್ನು ಬಳಸುತ್ತವೆ.
//! 2. ಎಮ್‌ಸ್ಕ್ರಿಪ್ಟನ್ `emcc.rs` ಫೈಲ್‌ನಲ್ಲಿ ಸಿ ++ ವಿನಾಯಿತಿಗಳನ್ನು ಬಳಸುತ್ತದೆ.
//! 3. ಎಲ್ಲಾ ಇತರ ಗುರಿಗಳು `gcc.rs` ಫೈಲ್‌ನಲ್ಲಿ libunwind/libgcc ಅನ್ನು ಬಳಸುತ್ತವೆ.
//!
//! ಪ್ರತಿ ಅನುಷ್ಠಾನದ ಬಗ್ಗೆ ಹೆಚ್ಚಿನ ದಾಖಲಾತಿಗಳನ್ನು ಆಯಾ ಮಾಡ್ಯೂಲ್‌ನಲ್ಲಿ ಕಾಣಬಹುದು.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` ಮಿರಿಯೊಂದಿಗೆ ಬಳಸಲಾಗುವುದಿಲ್ಲ, ಆದ್ದರಿಂದ ಮೌನ ಎಚ್ಚರಿಕೆಗಳು.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust ರನ್ಟೈಮ್ನ ಆರಂಭಿಕ ವಸ್ತುಗಳು ಈ ಚಿಹ್ನೆಗಳನ್ನು ಅವಲಂಬಿಸಿರುತ್ತದೆ, ಆದ್ದರಿಂದ ಅವುಗಳನ್ನು ಸಾರ್ವಜನಿಕಗೊಳಿಸಿ.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // ಬಿಚ್ಚುವಿಕೆಯನ್ನು ಬೆಂಬಲಿಸದ ಗುರಿಗಳು.
        // - arch=wasm32
        // - os=ಯಾವುದೂ ಇಲ್ಲ ("bare metal" ಗುರಿಗಳು)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // ಮಿರಿ ರನ್ಟೈಮ್ ಬಳಸಿ.
        // ಮೇಲಿನ ರನ್ಟೈಮ್ ಅನ್ನು ನಾವು ಇನ್ನೂ ಲೋಡ್ ಮಾಡಬೇಕಾಗಿದೆ, ಏಕೆಂದರೆ rustc ಅಲ್ಲಿಂದ ಕೆಲವು ಲ್ಯಾಂಗ್ ವಸ್ತುಗಳನ್ನು ವ್ಯಾಖ್ಯಾನಿಸುತ್ತದೆ ಎಂದು ನಿರೀಕ್ಷಿಸುತ್ತದೆ.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // ನಿಜವಾದ ಚಾಲನಾಸಮಯವನ್ನು ಬಳಸಿ.
        use real_imp as imp;
    }
}

extern "C" {
    /// `catch_unwind` ನ ಹೊರಗೆ panic ಆಬ್ಜೆಕ್ಟ್ ಅನ್ನು ಕೈಬಿಟ್ಟಾಗ libstd ನಲ್ಲಿ ಹ್ಯಾಂಡ್ಲರ್ ಎಂದು ಕರೆಯಲಾಗುತ್ತದೆ.
    ///
    fn __rust_drop_panic() -> !;

    /// ವಿದೇಶಿ ವಿನಾಯಿತಿ ಸಿಕ್ಕಿಬಿದ್ದಾಗ libstd ನಲ್ಲಿ ಹ್ಯಾಂಡ್ಲರ್ ಎಂದು ಕರೆಯುತ್ತಾರೆ.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// ವಿನಾಯಿತಿಯನ್ನು ಹೆಚ್ಚಿಸಲು ಪ್ರವೇಶ ಬಿಂದು, ಪ್ಲಾಟ್‌ಫಾರ್ಮ್-ನಿರ್ದಿಷ್ಟ ಅನುಷ್ಠಾನಕ್ಕೆ ಪ್ರತಿನಿಧಿಗಳು.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}