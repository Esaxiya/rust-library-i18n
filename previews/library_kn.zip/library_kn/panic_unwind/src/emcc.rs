//! *Emscripten* ಗುರಿಗಾಗಿ ಬಿಚ್ಚುವುದು.
//!
//! Unix ಪ್ಲಾಟ್‌ಫಾರ್ಮ್‌ಗಳಿಗಾಗಿ Rust ನ ಸಾಮಾನ್ಯ ಬಿಚ್ಚುವಿಕೆಯ ಅನುಷ್ಠಾನವು ನೇರವಾಗಿ ಲಿಬನ್‌ವಿಂಡ್ API ಗಳಿಗೆ ಕರೆ ಮಾಡುತ್ತದೆ, ಎಮ್‌ಸ್ಕ್ರಿಪ್ಟನ್‌ನಲ್ಲಿ ನಾವು ಬದಲಿಗೆ C++ ಬಿಚ್ಚುವ API ಗಳಿಗೆ ಕರೆಯುತ್ತೇವೆ.
//! ಎಮ್ಸ್‌ಸ್ಕ್ರಿಪ್ಟನ್‌ನ ಚಾಲನಾಸಮಯವು ಯಾವಾಗಲೂ ಆ API ಗಳನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುತ್ತದೆ ಮತ್ತು ಲಿಬನ್‌ವಿಂಡ್ ಅನ್ನು ಕಾರ್ಯಗತಗೊಳಿಸುವುದಿಲ್ಲವಾದ್ದರಿಂದ ಇದು ಕೇವಲ ಒಂದು ಪ್ರಯೋಜನವಾಗಿದೆ.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// ಇದು C++ ನಲ್ಲಿನ std::type_info ನ ವಿನ್ಯಾಸಕ್ಕೆ ಹೊಂದಿಕೆಯಾಗುತ್ತದೆ
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // ಇಲ್ಲಿರುವ ಪ್ರಮುಖ `\x01` ಬೈಟ್ ವಾಸ್ತವವಾಗಿ LLVM ಗೆ ಮಾಂತ್ರಿಕ ಸಂಕೇತವಾಗಿದ್ದು, `_` ಅಕ್ಷರದೊಂದಿಗೆ ಪೂರ್ವಪ್ರತ್ಯಯದಂತಹ ಯಾವುದೇ ಮಾಂಗ್ಲಿಂಗ್ ಅನ್ನು ಅನ್ವಯಿಸಬಾರದು.
    //
    //
    // ಈ ಚಿಹ್ನೆಯು C++ ನ `std::type_info` ಬಳಸುವ vtable ಆಗಿದೆ.
    // ಟೈಪ್ `std::type_info` ನ ಆಬ್ಜೆಕ್ಟ್‌ಗಳು, ಟೈಪ್ ಡಿಸ್ಕ್ರಿಪ್ಟರ್‌ಗಳು ಈ ಟೇಬಲ್‌ಗೆ ಪಾಯಿಂಟರ್ ಅನ್ನು ಹೊಂದಿವೆ.
    // ಟೈಪ್ ಡಿಸ್ಕ್ರಿಪ್ಟರ್‌ಗಳನ್ನು ಮೇಲೆ ವ್ಯಾಖ್ಯಾನಿಸಲಾದ ಸಿ ++ ಇಹೆಚ್ ರಚನೆಗಳಿಂದ ಉಲ್ಲೇಖಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ನಾವು ಕೆಳಗೆ ನಿರ್ಮಿಸುತ್ತೇವೆ.
    //
    // ನೈಜ ಗಾತ್ರವು 3 ಬಳಕೆಗಿಂತ ದೊಡ್ಡದಾಗಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿ, ಆದರೆ ಮೂರನೇ ಅಂಶವನ್ನು ಸೂಚಿಸಲು ನಮಗೆ ನಮ್ಮ vtable ಅಗತ್ಯವಿದೆ.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info ತುಕ್ಕು_ಪಾನಿಕ್ ವರ್ಗಕ್ಕಾಗಿ
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // ಸಾಮಾನ್ಯವಾಗಿ ನಾವು .as_ptr().add(2) ಅನ್ನು ಬಳಸುತ್ತೇವೆ ಆದರೆ ಇದು ಒಂದು ಸನ್ನಿವೇಶದಲ್ಲಿ ಕಾರ್ಯನಿರ್ವಹಿಸುವುದಿಲ್ಲ.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // ಇದು ಉದ್ದೇಶಪೂರ್ವಕವಾಗಿ ಸಾಮಾನ್ಯ ಹೆಸರಿನ ಮ್ಯಾಂಗ್ಲಿಂಗ್ ಸ್ಕೀಮ್ ಅನ್ನು ಬಳಸುವುದಿಲ್ಲ ಏಕೆಂದರೆ ಸಿ ++ Rust panics ಅನ್ನು ಉತ್ಪಾದಿಸಲು ಅಥವಾ ಹಿಡಿಯಲು ನಾವು ಬಯಸುವುದಿಲ್ಲ.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // ಇದು ಅವಶ್ಯಕವಾಗಿದೆ ಏಕೆಂದರೆ ಸಿ ++ ಕೋಡ್ ನಮ್ಮ ಮರಣದಂಡನೆಯನ್ನು std::exception_ptr ನೊಂದಿಗೆ ಸೆರೆಹಿಡಿಯಬಹುದು ಮತ್ತು ಅದನ್ನು ಅನೇಕ ಬಾರಿ ಮರುಹಂಚಿಕೊಳ್ಳಬಹುದು, ಬಹುಶಃ ಇನ್ನೊಂದು ಥ್ರೆಡ್‌ನಲ್ಲಿಯೂ ಸಹ.
    //
    //
    caught: AtomicBool,

    // ಇದು ಒಂದು ಆಯ್ಕೆಯಾಗಿರಬೇಕು ಏಕೆಂದರೆ ವಸ್ತುವಿನ ಜೀವಿತಾವಧಿಯು ಸಿ ++ ಶಬ್ದಾರ್ಥಗಳನ್ನು ಅನುಸರಿಸುತ್ತದೆ: ಕ್ಯಾಚ್_ಅನ್ವಿಂಡ್ ಬಾಕ್ಸ್ ಅನ್ನು ವಿನಾಯಿತಿಯಿಂದ ಹೊರಕ್ಕೆ ಸರಿಸಿದಾಗ ಅದು ಇನ್ನೂ ಎಕ್ಸೆಪ್ಶನ್ ವಸ್ತುವನ್ನು ಮಾನ್ಯ ಸ್ಥಿತಿಯಲ್ಲಿ ಬಿಡಬೇಕು ಏಕೆಂದರೆ ಅದರ ವಿನಾಶಕವನ್ನು ಇನ್ನೂ __cxa_end_catch ಕರೆಯುತ್ತದೆ.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try ವಾಸ್ತವವಾಗಿ ಈ ರಚನೆಗೆ ನಮಗೆ ಪಾಯಿಂಟರ್ ನೀಡುತ್ತದೆ.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // cleanup() ಅನ್ನು panic ಗೆ ಅನುಮತಿಸದ ಕಾರಣ, ನಾವು ಬದಲಿಗೆ ಸ್ಥಗಿತಗೊಳಿಸುತ್ತೇವೆ.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}