//! ಮಿರಿಗಾಗಿ panics ಅನ್ನು ಬಿಚ್ಚುವುದು.
use alloc::boxed::Box;
use core::any::Any;

// ಮಿರಿ ಎಂಜಿನ್ ನಮಗೆ ಬಿಚ್ಚುವ ಮೂಲಕ ಪ್ರಸಾರ ಮಾಡುವ ಪೇಲೋಡ್ ಪ್ರಕಾರ.
// ಪಾಯಿಂಟರ್ ಗಾತ್ರದಲ್ಲಿರಬೇಕು.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// ಬಿಚ್ಚುವಿಕೆಯನ್ನು ಪ್ರಾರಂಭಿಸಲು ಮಿರಿ ಒದಗಿಸಿದ ಬಾಹ್ಯ ಕಾರ್ಯ.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // ನಾವು `miri_start_panic` ಗೆ ಹಾದುಹೋಗುವ ಪೇಲೋಡ್ ನಿಖರವಾಗಿ ಕೆಳಗಿನ `cleanup` ನಲ್ಲಿ ನಾವು ಪಡೆಯುವ ವಾದವಾಗಿರುತ್ತದೆ.
    // ಆದ್ದರಿಂದ ನಾವು ಪಾಯಿಂಟರ್ ಗಾತ್ರದ ಏನನ್ನಾದರೂ ಪಡೆಯಲು ಅದನ್ನು ಒಮ್ಮೆ ಬಾಕ್ಸ್ ಮಾಡಿ.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // ಆಧಾರವಾಗಿರುವ `Box` ಅನ್ನು ಮರುಪಡೆಯಿರಿ.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}