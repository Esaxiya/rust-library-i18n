#![feature(no_core)]
#![no_core]

// ಈ crate ಏಕೆ ಬೇಕು ಎಂದು rustc-std-ಕಾರ್ಯಕ್ಷೇತ್ರ-ಕೋರ್ ನೋಡಿ.

// ಲಿಬಾಲೋಕ್‌ನಲ್ಲಿ ಹಂಚಿಕೆ ಮಾಡ್ಯೂಲ್‌ನೊಂದಿಗೆ ಸಂಘರ್ಷವನ್ನು ತಪ್ಪಿಸಲು crate ಅನ್ನು ಮರುಹೆಸರಿಸಿ.
extern crate alloc as foo;

pub use foo::*;