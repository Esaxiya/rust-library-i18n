# `rustc-std-workspace-std` crate

راجع وثائق `rustc-std-workspace-core` crate.