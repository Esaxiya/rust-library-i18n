use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // ميري بطيئة للغاية
fn exact_sanity_test() {
    // ينتهي هذا الاختبار بتشغيل ما يمكن أن أفترضه فقط هو بعض الحالات الركنية لوظيفة مكتبة `exp2` ، المحددة في أي وقت تشغيل C نستخدمه.
    // في VS 2013 ، يبدو أن هذه الوظيفة بها خطأ حيث فشل هذا الاختبار عند الربط ، ولكن مع VS 2015 ، يبدو الخطأ ثابتًا حيث يعمل الاختبار بشكل جيد.
    //
    // يبدو أن الخطأ هو اختلاف في القيمة المرجعة لـ `exp2(-1057)` ، حيث في VS 2013 تُرجع ضعفًا بنمط البت 0x2 وفي VS 2015 تُرجع 0x20000.
    //
    //
    // في الوقت الحالي ، تجاهل هذا الاختبار تمامًا على MSVC لأنه تم اختباره في مكان آخر على أي حال ، ولسنا مهتمين جدًا باختبار تطبيق exp2 لكل منصة.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}