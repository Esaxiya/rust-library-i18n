use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // هذه ليست مساحة سطح مستقرة ، ولكنها تساعد في إبقاء `?` رخيصًا بينها ، حتى لو لم تستطع LLVM دائمًا الاستفادة منها في الوقت الحالي.
    //
    // (النتيجة المحزنة والخيار غير متسقين ، لذلك لا يمكن أن يتطابق ControlFlow مع كليهما.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}