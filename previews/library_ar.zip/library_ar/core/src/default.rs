//! `Default` trait للأنواع التي قد تحتوي على قيم افتراضية ذات معنى.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait لإعطاء نوع قيمة افتراضية مفيدة.
///
/// في بعض الأحيان ، تريد الرجوع إلى نوع من القيمة الافتراضية ، ولا تهتم بشكل خاص بما هي عليه.
/// يأتي هذا غالبًا مع "البنية" التي تحدد مجموعة من الخيارات:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// كيف يمكننا تحديد بعض القيم الافتراضية؟يمكنك استخدام `Default`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// الآن ، تحصل على جميع القيم الافتراضية.تقوم Rust بتنفيذ `Default` لأنواع بدائية مختلفة.
///
/// إذا كنت تريد تجاوز خيار معين ، مع الاحتفاظ بالإعدادات الافتراضية الأخرى:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// يمكن استخدام trait مع `#[derive]` إذا كانت جميع حقول النوع تنفذ `Default`.
/// عند `derive`d ، ستستخدم القيمة الافتراضية لنوع كل حقل.
///
/// ## كيف يمكنني تنفيذ `Default`؟
///
/// قدم تنفيذًا لطريقة `default()` التي تُرجع قيمة النوع الخاص بك والتي يجب أن تكون هي القيمة الافتراضية:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// إرجاع "default value" لنوع.
    ///
    /// غالبًا ما تكون القيم الافتراضية نوعًا من القيمة الأولية أو قيمة الهوية أو أي شيء آخر قد يكون منطقيًا كقيمة افتراضية.
    ///
    ///
    /// # Examples
    ///
    /// باستخدام القيم الافتراضية المضمنة:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// صنع بنفسك:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// قم بإرجاع القيمة الافتراضية لنوع وفقًا لـ `Default` trait.
///
/// يُستدل على النوع المراد إرجاعه من السياق ؛هذا يعادل `Default::default()` ولكنه أقصر في الكتابة.
///
/// على سبيل المثال:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// اشتق الماكرو لتوليد إشارة من trait `Default`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }