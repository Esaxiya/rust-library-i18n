use crate::iter::FromIterator;

/// تصغير جميع عناصر الوحدة من مكرر إلى عنصر واحد.
///
/// يكون هذا أكثر فائدة عند دمجه مع التجريدات ذات المستوى الأعلى ، مثل التجميع إلى `Result<(), E>` حيث تهتم فقط بالأخطاء:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}