//! دعم Panic لـ libcore
//!
//! لا تستطيع المكتبة الأساسية تحديد الذعر ، لكنها *تعلن* الذعر.
//! هذا يعني أن الوظائف داخل libcore مسموح بها لـ panic ، ولكن لكي تكون مفيدة ، يجب أن تحدد crate المنبع الذعر لاستخدام libcore.
//! الواجهة الحالية للهلع هي:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! يسمح هذا التعريف بالذعر من أي رسالة عامة ، لكنه لا يسمح بالفشل بقيمة `Box<Any>`.
//! (يحتوي `PanicInfo` فقط على `&(dyn Any + Send)` ، والذي نملأ له قيمة وهمية في `PanicInfo: : internal_constructor`.) والسبب في ذلك هو أن libcore غير مسموح له بالتخصيص.
//!
//!
//! تحتوي هذه الوحدة على بعض وظائف الذعر الأخرى ، ولكن هذه ليست سوى عناصر اللغة الضرورية للمترجم.يتم توجيه جميع panics من خلال هذه الوظيفة الواحدة.
//! يتم التصريح عن الرمز الفعلي من خلال سمة `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// التطبيق الأساسي لماكرو libcore's `panic!` عند عدم استخدام أي تنسيق.
#[cold]
// لا يتم تضمينه أبدًا ما لم panic_immediate_abort لتجنب سخام التعليمات البرمجية في مواقع الاتصال قدر الإمكان
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // مطلوب بواسطة codegen لـ panic في overflow وغيرها من أجهزة إنهاء `Assert` MIR
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // استخدم Arguments::new_v1 بدلاً من format_args! ("{}"، expr) لتقليل حجم الحمل المحتمل.
    // التنسيق_args!يستخدم الماكرو str's Display trait لكتابة expr ، والذي يستدعي Formatter::pad ، والذي يجب أن يتلاءم مع اقتطاع السلسلة والحشو (على الرغم من عدم استخدام أي منها هنا).
    //
    // قد يسمح استخدام Arguments::new_v1 للمترجم بحذف Formatter::pad من ثنائي الإخراج ، مما يوفر ما يصل إلى بضعة كيلوبايت.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // اللازمة ل panics تقييمها المستمر
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // مطلوب بواسطة codegen لـ panic على وصول OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// التطبيق الأساسي لماكرو libcore's `panic!` عند استخدام التنسيق.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // ملاحظة: لا تتجاوز هذه الوظيفة أبدًا حدود FFI ؛إنها مكالمة Rust-to-Rust يتم حلها إلى وظيفة `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // الأمان: يتم تعريف `panic_impl` برمز Rust الآمن وبالتالي فهو آمن للاتصال به.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// الوظيفة الداخلية لوحدات الماكرو `assert_eq!` و `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}