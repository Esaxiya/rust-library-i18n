use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// في حين يتم استخدام هذه الوظيفة في مكان واحد ويمكن تأكيد تنفيذها ، فإن المحاولات السابقة للقيام بذلك جعلت rustc أبطأ:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// تخطيط كتلة من الذاكرة.
///
/// يصف مثيل `Layout` تخطيطًا معينًا للذاكرة.
/// تقوم ببناء `Layout` كمدخل لإعطاءه للمخصص.
///
/// كل التخطيطات لها حجم مقترن ومحاذاة بقوة اثنين.
///
/// (لاحظ أن التخطيطات *ليست* مطلوبة لتكون بحجم غير صفري ، على الرغم من أن `GlobalAlloc` يتطلب أن تكون جميع طلبات الذاكرة بحجم غير صفري.
/// يجب على المتصل إما التأكد من تلبية مثل هذه الشروط ، أو استخدام مخصصات محددة بمتطلبات أكثر مرونة ، أو استخدام واجهة `Allocator` الأكثر تساهلاً.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // حجم الكتلة المطلوبة من الذاكرة ، مقاسة بالبايت.
    size_: usize,

    // محاذاة الكتلة المطلوبة من الذاكرة ، مقاسة بالبايت.
    // نحن نضمن أن يكون هذا دائمًا قوة من اثنين ، لأن واجهة برمجة التطبيقات مثل `posix_memalign` تتطلب ذلك وهو قيد معقول لفرضه على منشئي التخطيط.
    //
    //
    // (ومع ذلك ، فإننا لا نطلب بشكل متماثل "محاذاة>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// تنشئ `Layout` من `size` و `align` ، أو تُرجع `LayoutError` إذا لم يتم استيفاء أي من الشروط التالية:
    ///
    /// * `align` يجب ألا تكون صفرًا ،
    ///
    /// * `align` يجب أن تكون قوة اثنين ،
    ///
    /// * `size`, عند التقريب إلى أقرب مضاعف لـ `align` ، يجب عدم تجاوز السعة (على سبيل المثال ، يجب أن تكون القيمة المقربة أقل من أو تساوي `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (قوة اثنين تعني محاذاة!=0.)

        // حجم التقريب هو:
        //   size_rounded_up=(الحجم + محاذاة ، 1)&! (محاذاة ، 1) ؛
        //
        // نعلم من الأعلى أن المحاذاة!=0.
        // إذا لم يتم تجاوز إضافة (محاذاة ، 1) ، فسيكون التقريب لأعلى أمرًا جيدًا.
        //
        // على العكس من ذلك ،&-التقنيع مع! (محاذاة ، 1) ستطرح فقط وحدات البت ذات الترتيب المنخفض.
        // وبالتالي في حالة حدوث تجاوز مع المجموع ، لا يمكن للقناع&-طرح ما يكفي للتراجع عن هذا الفائض.
        //
        //
        // أعلاه يشير إلى أن التحقق من فائض التجميع ضروري وكاف.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // الأمان: شروط `from_size_align_unchecked` كانت
        // فحص أعلاه.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// ينشئ تخطيطًا ، متجاوزًا جميع عمليات التحقق.
    ///
    /// # Safety
    ///
    /// هذه الوظيفة غير آمنة لأنها لا تتحقق من الشروط المسبقة من [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // الأمان: يجب على المتصل التأكد من أن `align` أكبر من الصفر.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// الحد الأدنى للحجم بالبايت لكتلة ذاكرة لهذا التخطيط.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// الحد الأدنى لمحاذاة البايت لكتلة ذاكرة لهذا التخطيط.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// ينشئ `Layout` مناسبًا للاحتفاظ بقيمة من النوع `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // الأمان: يتم ضمان المحاذاة بواسطة Rust لتكون بقوة اثنين و
        // حجم + محاذاة التحرير والسرد مضمونة لتناسب مساحة العنوان لدينا.
        // نتيجة لذلك ، استخدم المُنشئ غير المحدد هنا لتجنب إدخال رمز panics إذا لم يتم تحسينه بشكل كافٍ.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// ينتج تخطيطًا يصف سجلًا يمكن استخدامه لتخصيص بنية الدعم لـ `T` (والتي يمكن أن تكون trait أو أي نوع آخر غير بحجم مثل شريحة).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // الأمان: راجع الأساس المنطقي في `new` لمعرفة سبب استخدام هذا المتغير غير الآمن
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// ينتج تخطيطًا يصف سجلًا يمكن استخدامه لتخصيص بنية الدعم لـ `T` (والتي يمكن أن تكون trait أو أي نوع آخر غير بحجم مثل شريحة).
    ///
    /// # Safety
    ///
    /// هذه الوظيفة آمنة فقط للاتصال إذا استمرت الشروط التالية:
    ///
    /// - إذا كان `T` هو `Sized` ، فهذه الوظيفة آمنة دائمًا للاتصال.
    /// - إذا كان الذيل غير الحجم لـ `T` هو:
    ///     - a [slice] ، يجب أن يكون طول ذيل الشريحة عددًا صحيحًا مُكوّنًا ، ويجب أن يتناسب حجم *القيمة الكاملة*(طول الذيل الديناميكي + بادئة الحجم الثابت) في `isize`.
    ///     - أ [trait object] ، ثم يجب أن يشير الجزء vtable من المؤشر إلى جدول vtable صالح للنوع `T` المكتسب من خلال تكوين غير متغير ، ويجب أن يتناسب حجم *القيمة الكاملة*(طول الذيل الديناميكي + بادئة الحجم الثابت) في `isize`.
    ///
    ///     - (unstable) [extern type] ، فهذه الوظيفة آمنة دائمًا للاتصال بها ، ولكن قد panic أو إرجاع قيمة خاطئة بطريقة أخرى ، لأن تخطيط النوع الخارجي غير معروف.
    ///     هذا هو نفس سلوك [`Layout::for_value`] في مرجع إلى ذيل نوع خارجي.
    ///     - خلافًا لذلك ، لا يُسمح بشكل متحفظ باستدعاء هذه الوظيفة.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // الأمان: نقوم بتمرير المتطلبات الأساسية لهذه الوظائف إلى المتصل
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // الأمان: راجع الأساس المنطقي في `new` لمعرفة سبب استخدام هذا المتغير غير الآمن
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// ينشئ `NonNull` متدليًا ، ولكنه محاذٍ جيدًا لهذا التخطيط.
    ///
    /// لاحظ أن قيمة المؤشر قد تمثل مؤشرًا صالحًا ، مما يعني أنه لا يجب استخدام هذا كقيمة "not yet initialized" الحارس.
    /// يجب أن تتبع الأنواع التي تخصصها بتكاسل التهيئة من خلال بعض الوسائل الأخرى.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // السلامة: المحاذاة مضمونة لتكون غير صفرية
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// ينشئ تخطيطًا يصف السجل الذي يمكن أن يحتوي على قيمة من نفس التخطيط مثل `self` ، ولكن يتم محاذاته أيضًا لمحاذاة `align` (مقاسة بالبايت).
    ///
    ///
    /// إذا كان `self` يلبي بالفعل المحاذاة المحددة ، فسيقوم بإرجاع `self`.
    ///
    /// لاحظ أن هذه الطريقة لا تضيف أي حشوة إلى الحجم الكلي ، بغض النظر عما إذا كان التخطيط الذي تم إرجاعه له محاذاة مختلفة.
    /// بمعنى آخر ، إذا كان `K` بحجم 16 ، فسيظل `K.align_to(32)` * بحجم 16.
    ///
    /// تُرجع خطأ إذا كانت مجموعة `self.size()` و `align` المعطاة تنتهك الشروط المدرجة في [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// تُرجع مقدار المساحة المتروكة التي يجب إدخالها بعد `self` للتأكد من أن العنوان التالي سيلبي `align` (مُقاسًا بالبايت).
    ///
    /// على سبيل المثال ، إذا كانت `self.size()` تساوي 9 ، فإن `self.padding_needed_for(4)` تُرجع 3 ، لأن هذا هو الحد الأدنى لعدد بايتات الحشو المطلوب للحصول على عنوان محاذي 4 (بافتراض أن كتلة الذاكرة المقابلة تبدأ عند عنوان محاذي 4).
    ///
    ///
    /// لا معنى لقيمة الإرجاع لهذه الوظيفة إذا لم يكن `align` قوة اثنين.
    ///
    /// لاحظ أن الأداة المساعدة للقيمة التي تم إرجاعها تتطلب أن يكون `align` أقل من أو يساوي محاذاة عنوان البداية للكتلة المخصصة بالكامل من الذاكرة.طريقة واحدة لتلبية هذا القيد هي ضمان `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // القيمة المقربة هي:
        //   len_rounded_up=(len + align، 1)&! (align، 1)؛
        // ثم نعيد فرق الحشو: `len_rounded_up - len`.
        //
        // نستخدم الحساب النمطي في جميع أنحاء:
        //
        // 1. المحاذاة مضمونة لتكون> 0 ، لذا فإن المحاذاة ، 1 صالحة دائمًا
        //
        // 2.
        // `len + align - 1` يمكن أن يتجاوز `align - 1` على الأكثر ، لذا فإن&-mask مع `!(align - 1)` سيضمن أنه في حالة الفائض ، سيكون `len_rounded_up` نفسه 0.
        //
        //    وبالتالي فإن الحشوة المرتجعة ، عند إضافتها إلى `len` ، تنتج 0 ، والتي ترضي بشكل تافه المحاذاة `align`.
        //
        // (بالطبع ، يجب أن تتسبب محاولات تخصيص كتل من الذاكرة التي يتجاوز حجمها وحجمها في الحشو بالطريقة المذكورة أعلاه في أن يتسبب المخصص في حدوث خطأ على أي حال.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// ينشئ تخطيطًا بتقريب حجم هذا التخطيط إلى مضاعفات محاذاة التخطيط.
    ///
    ///
    /// هذا يعادل إضافة نتيجة `padding_needed_for` إلى الحجم الحالي للتخطيط.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // هذا لا يمكن أن يفيض.نقلا عن ثابت التخطيط:
        // > `size`, عند التقريب إلى أقرب مضاعف لـ `align` ،
        // > يجب ألا يتجاوز (أي يجب أن تكون القيمة المقربة أقل من
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// ينشئ تخطيطًا يصف السجل لمثيلات `n` لـ `self` ، مع مقدار مناسب من الحشو بين كل مثيل لضمان إعطاء كل مثيل الحجم والمحاذاة المطلوبة.
    /// عند النجاح ، تُرجع `(k, offs)` حيث `k` هي تخطيط المصفوفة و `offs` هي المسافة بين بداية كل عنصر في المصفوفة.
    ///
    /// عند تجاوز السعة الحسابية ، تُرجع `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // هذا لا يمكن أن يفيض.نقلا عن ثابت التخطيط:
        // > `size`, عند التقريب إلى أقرب مضاعف لـ `align` ،
        // > يجب ألا يتجاوز (أي يجب أن تكون القيمة المقربة أقل من
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // الأمان: من المعروف بالفعل أن self.align صالح وقد تم تخصيص حجم_الحجم
        // مبطن بالفعل.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// ينشئ تخطيطًا يصف سجل `self` متبوعًا بـ `next` ، بما في ذلك أي حشوة ضرورية لضمان محاذاة `next` بشكل صحيح ، ولكن *بدون حشوة زائدة*.
    ///
    /// لمطابقة تخطيط تمثيل C `repr(C)` ، يجب عليك الاتصال بـ `pad_to_align` بعد توسيع التخطيط بجميع الحقول.
    /// (لا توجد طريقة لمطابقة تخطيط تمثيل Rust الافتراضي `repr(Rust)`, as it is unspecified.)
    ///
    /// لاحظ أن محاذاة التخطيط الناتج ستكون الحد الأقصى لتلك الخاصة بـ `self` و `next` ، من أجل ضمان محاذاة كلا الجزأين.
    ///
    /// إرجاع `Ok((k, offset))` ، حيث `k` هو تخطيط السجل المتسلسل و `offset` هو الموقع النسبي ، بالبايت ، لبداية `next` المضمنة في السجل المتسلسل (بافتراض أن السجل نفسه يبدأ عند الإزاحة 0).
    ///
    ///
    /// عند تجاوز السعة الحسابية ، تُرجع `LayoutError`.
    ///
    /// # Examples
    ///
    /// لحساب تخطيط بنية `#[repr(C)]` وإزاحات الحقول من تخطيطات الحقول الخاصة بها:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // تذكر أن تنتهي مع `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // اختبار أنها تعمل
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// ينشئ تخطيطًا يصف السجل لمثيلات `n` لـ `self` ، بدون ترك مساحة بين كل مثيل.
    ///
    /// لاحظ أنه ، بخلاف `repeat` ، لا يضمن `repeat_packed` أن المثيلات المتكررة لـ `self` ستتم محاذاة بشكل صحيح ، حتى إذا تمت محاذاة مثيل `self` بشكل صحيح.
    /// بمعنى آخر ، إذا تم استخدام التخطيط الذي تم إرجاعه بواسطة `repeat_packed` لتخصيص مصفوفة ، فلا يمكن ضمان محاذاة جميع العناصر في المصفوفة بشكل صحيح.
    ///
    /// عند تجاوز السعة الحسابية ، تُرجع `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// ينشئ تخطيطًا يصف سجل `self` متبوعًا بـ `next` بدون ترك مساحة إضافية بينهما.
    /// نظرًا لعدم إدخال أي حشوة ، فإن محاذاة `next` غير ذات صلة ، ولم يتم دمجها *على الإطلاق* في التخطيط الناتج.
    ///
    ///
    /// عند تجاوز السعة الحسابية ، تُرجع `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// ينشئ تخطيطًا يصف السجل لـ `[T; n]`.
    ///
    /// عند تجاوز السعة الحسابية ، تُرجع `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// المعلمات المعطاة لـ `Layout::from_size_align` أو بعض مُنشئ `Layout` الآخر لا تفي بقيودها الموثقة.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (نحن بحاجة إلى هذا من أجل التنبيه المصب لخطأ trait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}