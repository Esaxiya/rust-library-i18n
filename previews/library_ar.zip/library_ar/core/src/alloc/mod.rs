//! واجهات برمجة تطبيقات تخصيص الذاكرة

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// يشير الخطأ `AllocError` إلى فشل التخصيص الذي قد يكون بسبب استنفاد الموارد أو لشيء خاطئ عند دمج وسيطات الإدخال المحددة مع هذا المخصص.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (نحن بحاجة إلى هذا من أجل التنبيه المصب لخطأ trait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// يمكن لتطبيق `Allocator` تخصيص كتل عشوائية من البيانات الموصوفة عبر [`Layout`][] وتنميتها وتقليصها وإلغاء تخصيصها.
///
/// `Allocator` تم تصميمه ليتم تنفيذه على ZSTs أو المراجع أو المؤشرات الذكية لأن وجود مُخصص مثل `MyAlloc([u8; N])` لا يمكن نقله ، دون تحديث المؤشرات إلى الذاكرة المخصصة.
///
/// بخلاف [`GlobalAlloc`][] ، يُسمح بالتخصيصات ذات الحجم الصفري في `Allocator`.
/// إذا كان المخصص الأساسي لا يدعم هذا (مثل jemalloc) أو أعاد مؤشر فارغ (مثل `libc::malloc`) ، فيجب أن يتم اكتشاف ذلك من خلال التطبيق.
///
/// ### الذاكرة المخصصة حاليا
///
/// تتطلب بعض الطرق أن يتم *تخصيص كتلة الذاكرة* حاليًا * عبر مُخصص.هذا يعني ذاك:
///
/// * تم إرجاع عنوان البداية لكتلة الذاكرة مسبقًا بواسطة [`allocate`] أو [`grow`] أو [`shrink`] ، و
///
/// * لم يتم إلغاء تخصيص كتلة الذاكرة لاحقًا ، حيث يتم إما إلغاء تخصيص الكتل مباشرةً عن طريق تمريرها إلى [`deallocate`] أو تغييرها عن طريق تمريرها إلى [`grow`] أو [`shrink`] التي تُرجع `Ok`.
///
/// إذا قام `grow` أو `shrink` بإرجاع `Err` ، فسيظل المؤشر الذي تم تمريره صالحًا.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### تركيب الذاكرة
///
/// تتطلب بعض الطرق أن يكون التنسيق *مناسبًا* لكتلة الذاكرة.
/// ما يعنيه التخطيط لـ "fit" يعني كتلة الذاكرة (أو ما يعادله ، بالنسبة لكتلة الذاكرة إلى تخطيط "fit") هو أن الشروط التالية يجب أن تحتوي:
///
/// * يجب تخصيص الكتلة بنفس المحاذاة مثل [`layout.align()`] و
///
/// * يجب أن يقع [`layout.size()`] المقدم في النطاق `min ..= max` ، حيث:
///   - `min` هو حجم التخطيط المستخدم مؤخرًا لتخصيص الكتلة ، و
///   - `max` هو أحدث حجم فعلي تم إرجاعه من [`allocate`] أو [`grow`] أو [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * يجب أن تشير كتل الذاكرة التي يتم إرجاعها من المُخصص إلى ذاكرة صالحة وتحتفظ بصلاحيتها حتى يتم إسقاط المثيل وجميع النسخ المستنسخة الخاصة به ،
///
/// * يجب ألا يؤدي الاستنساخ أو نقل المخصص إلى إبطال كتل الذاكرة التي تم إرجاعها من هذا المخصص.يجب أن يتصرف المخصص المستنسخ مثل نفس المخصص ، و
///
/// * يمكن تمرير أي مؤشر إلى كتلة ذاكرة وهي [*currently allocated*] إلى أي طريقة أخرى للمخصص.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// محاولات لتخصيص كتلة من الذاكرة.
    ///
    /// عند النجاح ، تُرجع [`NonNull<[u8]>`][NonNull] التي تفي بالحجم وضمانات المحاذاة لـ `layout`.
    ///
    /// قد يكون للكتلة التي تم إرجاعها حجم أكبر من المحدد بواسطة `layout.size()` ، وقد تتم تهيئة محتوياتها أو لا.
    ///
    /// # Errors
    ///
    /// يشير إرجاع `Err` إلى نفاد الذاكرة أو أن `layout` لا يلبي حجم المخصص أو قيود المحاذاة.
    ///
    /// يتم تشجيع التطبيقات على إرجاع `Err` عند استنفاد الذاكرة بدلاً من الذعر أو الإجهاض ، لكن هذا ليس مطلبًا صارمًا.
    /// (على وجه التحديد:*قانوني* تنفيذ trait هذا فوق مكتبة تخصيص أصلية أساسية يتم إجهاضها عند استنفاد الذاكرة.)
    ///
    /// يتم تشجيع العملاء الذين يرغبون في إحباط الحساب استجابةً لخطأ في التخصيص على استدعاء دالة [`handle_alloc_error`] ، بدلاً من استدعاء `panic!` أو ما شابه ذلك مباشرةً.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// يتصرف مثل `allocate` ، ولكنه يضمن أيضًا عدم تهيئة الذاكرة التي تم إرجاعها.
    ///
    /// # Errors
    ///
    /// يشير إرجاع `Err` إلى نفاد الذاكرة أو أن `layout` لا يلبي حجم المخصص أو قيود المحاذاة.
    ///
    /// يتم تشجيع التطبيقات على إرجاع `Err` عند استنفاد الذاكرة بدلاً من الذعر أو الإجهاض ، لكن هذا ليس مطلبًا صارمًا.
    /// (على وجه التحديد:*قانوني* تنفيذ trait هذا فوق مكتبة تخصيص أصلية أساسية يتم إجهاضها عند استنفاد الذاكرة.)
    ///
    /// يتم تشجيع العملاء الذين يرغبون في إحباط الحساب استجابةً لخطأ في التخصيص على استدعاء دالة [`handle_alloc_error`] ، بدلاً من استدعاء `panic!` أو ما شابه ذلك مباشرةً.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // الأمان: إرجاع `alloc` كتلة ذاكرة صالحة
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// إلغاء تخصيص الذاكرة المشار إليها بواسطة `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` يجب أن يشير إلى كتلة من الذاكرة [*currently allocated*] عبر هذا المخصص ، و
    /// * `layout` يجب أن [*fit*] كتلة من الذاكرة.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// محاولات لتوسيع كتلة الذاكرة.
    ///
    /// يُرجع [`NonNull<[u8]>`][NonNull] جديدًا يحتوي على مؤشر والحجم الفعلي للذاكرة المخصصة.المؤشر مناسب للاحتفاظ بالبيانات الموصوفة بواسطة `new_layout`.
    /// لتحقيق ذلك ، قد يقوم المُخصص بتوسيع التخصيص المشار إليه بواسطة `ptr` لملاءمة التخطيط الجديد.
    ///
    /// إذا أعاد هذا `Ok` ، فسيتم نقل ملكية كتلة الذاكرة المشار إليها بواسطة `ptr` إلى هذا المخصص.
    /// قد يتم تحرير الذاكرة أو عدم تحريرها ، ويجب اعتبارها غير صالحة للاستعمال ما لم يتم نقلها مرة أخرى إلى المتصل من خلال القيمة المعادة لهذه الطريقة.
    ///
    /// إذا أرجعت هذه الطريقة `Err` ، فهذا يعني أنه لم يتم نقل ملكية كتلة الذاكرة إلى هذا المخصص ، ولن يتم تغيير محتويات كتلة الذاكرة.
    ///
    /// # Safety
    ///
    /// * `ptr` يجب أن يشير إلى كتلة من الذاكرة [*currently allocated*] عبر هذا المخصص.
    /// * `old_layout` يجب أن [*fit*] تلك الكتلة من الذاكرة (لا تحتاج وسيطة `new_layout` إلى احتوائها.).
    /// * `new_layout.size()` يجب أن تكون أكبر من أو تساوي `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// تُرجع `Err` إذا كان التخطيط الجديد لا يلبي حجم المخصص وقيود المحاذاة للمخصص ، أو إذا فشلت عملية النمو بطريقة أخرى.
    ///
    /// يتم تشجيع التطبيقات على إرجاع `Err` عند استنفاد الذاكرة بدلاً من الذعر أو الإجهاض ، لكن هذا ليس مطلبًا صارمًا.
    /// (على وجه التحديد:*قانوني* تنفيذ trait هذا فوق مكتبة تخصيص أصلية أساسية يتم إجهاضها عند استنفاد الذاكرة.)
    ///
    /// يتم تشجيع العملاء الذين يرغبون في إحباط الحساب استجابةً لخطأ في التخصيص على استدعاء دالة [`handle_alloc_error`] ، بدلاً من استدعاء `panic!` أو ما شابه ذلك مباشرةً.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // الأمان: لأن `new_layout.size()` يجب أن يكون أكبر من أو يساوي
        // `old_layout.size()`, كل من تخصيص الذاكرة القديم والجديد صالح للقراءة والكتابة لـ `old_layout.size()` بايت.
        // أيضًا ، نظرًا لأن التخصيص القديم لم يتم إلغاء تخصيصه بعد ، فلا يمكن أن يتداخل مع `new_ptr`.
        // وبالتالي ، فإن الاتصال بـ `copy_nonoverlapping` آمن.
        // يجب أن يتم دعم عقد الأمان الخاص بـ `dealloc` من قبل المتصل.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// يتصرف مثل `grow` ، ولكنه يضمن أيضًا ضبط المحتويات الجديدة على الصفر قبل إعادتها.
    ///
    /// ستحتوي كتلة الذاكرة على المحتويات التالية بعد إجراء مكالمة ناجحة إلى
    /// `grow_zeroed`:
    ///   * يتم الاحتفاظ بالبايتات `0..old_layout.size()` من التخصيص الأصلي.
    ///   * سيتم الاحتفاظ بالبايتات `old_layout.size()..old_size` أو يتم صفيرها ، اعتمادًا على تطبيق المخصص.
    ///   `old_size` يشير إلى حجم كتلة الذاكرة قبل استدعاء `grow_zeroed` ، والتي قد تكون أكبر من الحجم الذي تم طلبه في الأصل عندما تم تخصيصها.
    ///   * البايت `old_size..new_size` صفرية.يشير `new_size` إلى حجم كتلة الذاكرة التي أرجعها استدعاء `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` يجب أن يشير إلى كتلة من الذاكرة [*currently allocated*] عبر هذا المخصص.
    /// * `old_layout` يجب أن [*fit*] تلك الكتلة من الذاكرة (لا تحتاج وسيطة `new_layout` إلى احتوائها.).
    /// * `new_layout.size()` يجب أن تكون أكبر من أو تساوي `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// تُرجع `Err` إذا كان التخطيط الجديد لا يلبي حجم المخصص وقيود المحاذاة للمخصص ، أو إذا فشلت عملية النمو بطريقة أخرى.
    ///
    /// يتم تشجيع التطبيقات على إرجاع `Err` عند استنفاد الذاكرة بدلاً من الذعر أو الإجهاض ، لكن هذا ليس مطلبًا صارمًا.
    /// (على وجه التحديد:*قانوني* تنفيذ trait هذا فوق مكتبة تخصيص أصلية أساسية يتم إجهاضها عند استنفاد الذاكرة.)
    ///
    /// يتم تشجيع العملاء الذين يرغبون في إحباط الحساب استجابةً لخطأ في التخصيص على استدعاء دالة [`handle_alloc_error`] ، بدلاً من استدعاء `panic!` أو ما شابه ذلك مباشرةً.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // الأمان: لأن `new_layout.size()` يجب أن يكون أكبر من أو يساوي
        // `old_layout.size()`, كل من تخصيص الذاكرة القديم والجديد صالح للقراءة والكتابة لـ `old_layout.size()` بايت.
        // أيضًا ، نظرًا لأن التخصيص القديم لم يتم إلغاء تخصيصه بعد ، فلا يمكن أن يتداخل مع `new_ptr`.
        // وبالتالي ، فإن الاتصال بـ `copy_nonoverlapping` آمن.
        // يجب أن يتم دعم عقد الأمان الخاص بـ `dealloc` من قبل المتصل.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// محاولات لتقليص كتلة الذاكرة.
    ///
    /// يُرجع [`NonNull<[u8]>`][NonNull] جديدًا يحتوي على مؤشر والحجم الفعلي للذاكرة المخصصة.المؤشر مناسب للاحتفاظ بالبيانات الموصوفة بواسطة `new_layout`.
    /// لتحقيق ذلك ، قد يقوم المُخصص بتقليص التخصيص المشار إليه بواسطة `ptr` لملاءمة التخطيط الجديد.
    ///
    /// إذا أعاد هذا `Ok` ، فسيتم نقل ملكية كتلة الذاكرة المشار إليها بواسطة `ptr` إلى هذا المخصص.
    /// قد يتم تحرير الذاكرة أو عدم تحريرها ، ويجب اعتبارها غير صالحة للاستعمال ما لم يتم نقلها مرة أخرى إلى المتصل من خلال القيمة المعادة لهذه الطريقة.
    ///
    /// إذا أرجعت هذه الطريقة `Err` ، فهذا يعني أنه لم يتم نقل ملكية كتلة الذاكرة إلى هذا المخصص ، ولن يتم تغيير محتويات كتلة الذاكرة.
    ///
    /// # Safety
    ///
    /// * `ptr` يجب أن يشير إلى كتلة من الذاكرة [*currently allocated*] عبر هذا المخصص.
    /// * `old_layout` يجب أن [*fit*] تلك الكتلة من الذاكرة (لا تحتاج وسيطة `new_layout` إلى احتوائها.).
    /// * `new_layout.size()` يجب أن تكون أصغر من أو تساوي `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// تُرجع `Err` إذا كان التخطيط الجديد لا يتوافق مع حجم المخصص وقيود المحاذاة للمخصص ، أو إذا فشل التقليص بطريقة أخرى.
    ///
    /// يتم تشجيع التطبيقات على إرجاع `Err` عند استنفاد الذاكرة بدلاً من الذعر أو الإجهاض ، لكن هذا ليس مطلبًا صارمًا.
    /// (على وجه التحديد:*قانوني* تنفيذ trait هذا فوق مكتبة تخصيص أصلية أساسية يتم إجهاضها عند استنفاد الذاكرة.)
    ///
    /// يتم تشجيع العملاء الذين يرغبون في إحباط الحساب استجابةً لخطأ في التخصيص على استدعاء دالة [`handle_alloc_error`] ، بدلاً من استدعاء `panic!` أو ما شابه ذلك مباشرةً.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // الأمان: لأن `new_layout.size()` يجب أن يكون أقل من أو يساوي
        // `old_layout.size()`, كل من تخصيص الذاكرة القديم والجديد صالح للقراءة والكتابة لـ `new_layout.size()` بايت.
        // أيضًا ، نظرًا لأن التخصيص القديم لم يتم إلغاء تخصيصه بعد ، فلا يمكن أن يتداخل مع `new_ptr`.
        // وبالتالي ، فإن الاتصال بـ `copy_nonoverlapping` آمن.
        // يجب أن يتم دعم عقد الأمان الخاص بـ `dealloc` من قبل المتصل.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// ينشئ محول "by reference" لهذا المثيل من `Allocator`.
    ///
    /// يقوم المحول المرتجع أيضًا بتنفيذ `Allocator` وسيقوم ببساطة باستعارة هذا.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // الأمان: يجب أن يتم دعم عقد الأمان من قبل المتصل
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // الأمان: يجب أن يتم دعم عقد الأمان من قبل المتصل
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // الأمان: يجب أن يتم دعم عقد الأمان من قبل المتصل
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // الأمان: يجب أن يتم دعم عقد الأمان من قبل المتصل
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}