//! Traits للتحويلات بين الأنواع.
//!
//! توفر traits في هذه الوحدة طريقة للتحويل من نوع إلى نوع آخر.
//! يخدم كل trait غرضًا مختلفًا:
//!
//! - قم بتطبيق [`AsRef`] trait لتحويلات مرجعية إلى مرجعية رخيصة
//! - قم بتطبيق [`AsMut`] trait للحصول على تحويلات رخيصة قابلة للتغيير
//! - قم بتطبيق [`From`] trait لاستهلاك تحويلات القيمة إلى القيمة
//! - قم بتطبيق [`Into`] trait لاستهلاك تحويلات القيمة إلى القيمة لأنواع خارج crate الحالي
//! - يتصرف كل من [`TryFrom`] و [`TryInto`] traits مثل [`From`] و [`Into`] ، ولكن يجب تنفيذه عندما يفشل التحويل.
//!
//! غالبًا ما يتم استخدام traits في هذه الوحدة على أنها trait bounds للوظائف العامة مثل الوسائط المتعددة المدعومة.راجع توثيق كل trait للحصول على أمثلة.
//!
//! بصفتك مؤلف مكتبة ، يجب أن تفضل دائمًا تنفيذ [`From<T>`][`From`] أو [`TryFrom<T>`][`TryFrom`] بدلاً من [`Into<U>`][`Into`] أو [`TryInto<U>`][`TryInto`] ، حيث يوفر [`From`] و [`TryFrom`] قدرًا أكبر من المرونة ويقدمان تطبيقات [`Into`] أو [`TryInto`] مكافئة مجانًا ، وذلك بفضل التنفيذ الشامل في المكتبة القياسية.
//! عند استهداف إصدار سابق لـ Rust 1.41 ، قد يكون من الضروري تنفيذ [`Into`] أو [`TryInto`] مباشرة عند التحويل إلى نوع خارج crate الحالي.
//!
//! # تطبيقات عامة
//!
//! - [`AsRef`] و [`AsMut`] auto-dereference إذا كان النوع الداخلي مرجعًا
//! - [`From`]`<U>لـ T` يعني [`Into`]`</u><T><U>لأجلك</u>
//! - [`TryFrom`]`<U>لـ T` يعني [`TryInto`]`</u><T><U>لأجلك</u>
//! - [`From`] و [`Into`] انعكاسيان ، مما يعني أن جميع الأنواع يمكنها `into` نفسها و `from` نفسها
//!
//! شاهد كل trait للحصول على أمثلة الاستخدام.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// وظيفة الهوية.
///
/// هناك شيئان مهمان يجب ملاحظتهما حول هذه الوظيفة:
///
/// - إنه لا يساوي دائمًا إغلاقًا مثل `|x| x` ، نظرًا لأن الإغلاق قد يجبر `x` على نوع مختلف.
///
/// - يقوم بتحريك الإدخال `x` الذي تم تمريره إلى الوظيفة.
///
/// في حين أنه قد يبدو من الغريب أن يكون لديك وظيفة تعيد الإدخال مرة أخرى ، إلا أن هناك بعض الاستخدامات المثيرة للاهتمام.
///
///
/// # Examples
///
/// استخدام `identity` لعدم القيام بأي شيء في سلسلة من الوظائف الأخرى المثيرة للاهتمام:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // لنتخيل أن إضافة واحدة مهمة مثيرة للاهتمام.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// استخدام `identity` كحالة أساسية "do nothing" في حالة مشروطة:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // قم بأشياء أكثر إثارة للاهتمام ...
///
/// let _results = do_stuff(42);
/// ```
///
/// استخدام `identity` للاحتفاظ بمتغيرات `Some` لمكرر `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// تستخدم للقيام بتحويل مرجعي إلى مرجع رخيص.
///
/// يشبه trait [`AsMut`] الذي يستخدم للتحويل بين المراجع القابلة للتغيير.
/// إذا كنت بحاجة إلى إجراء تحويل مكلف ، فمن الأفضل تنفيذ [`From`] من النوع `&T` أو كتابة وظيفة مخصصة.
///
/// `AsRef` له نفس توقيع [`Borrow`] ، لكن [`Borrow`] يختلف في جوانب قليلة:
///
/// - على عكس `AsRef` ، يحتوي [`Borrow`] على ضمانة شاملة لأي `T` ، ويمكن استخدامه لقبول إما مرجع أو قيمة.
/// - [`Borrow`] يتطلب أيضًا أن تكون [`Hash`] و [`Eq`] و [`Ord`] للقيمة المقترضة معادلة للقيمة المملوكة.
/// لهذا السبب ، إذا كنت ترغب في استعارة حقل واحد فقط من البنية ، يمكنك تنفيذ `AsRef` ، ولكن ليس [`Borrow`].
///
/// **Note: يجب ألا تفشل trait **.إذا فشل التحويل ، فاستخدم طريقة مخصصة تُرجع [`Option<T>`] أو [`Result<T, E>`].
///
/// # تطبيقات عامة
///
/// - `AsRef` المراجع التلقائية إذا كان النوع الداخلي مرجعًا أو مرجعًا متغيرًا (على سبيل المثال: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// باستخدام trait bounds يمكننا قبول وسيطات من أنواع مختلفة طالما أنه يمكن تحويلها إلى النوع المحدد `T`.
///
/// على سبيل المثال: من خلال إنشاء دالة عامة تأخذ `AsRef<str>` فإننا نعبر عن رغبتنا في قبول جميع المراجع التي يمكن تحويلها إلى [`&str`] كوسيطة.
/// نظرًا لأن كلاً من [`String`] و [`&str`] يطبقان `AsRef<str>` ، يمكننا قبول كلاهما كوسيطة إدخال.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// ينفذ التحويل.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// تستخدم للقيام بتحويل مرجعي رخيص قابل للتغيير إلى قابل للتغيير.
///
/// يشبه trait [`AsRef`] ولكنه يستخدم للتحويل بين المراجع القابلة للتغيير.
/// إذا كنت بحاجة إلى إجراء تحويل مكلف ، فمن الأفضل تنفيذ [`From`] من النوع `&mut T` أو كتابة وظيفة مخصصة.
///
/// **Note: يجب ألا تفشل trait **.إذا فشل التحويل ، فاستخدم طريقة مخصصة تُرجع [`Option<T>`] أو [`Result<T, E>`].
///
/// # تطبيقات عامة
///
/// - `AsMut` المراجع التلقائية إذا كان النوع الداخلي مرجعًا متغيرًا (على سبيل المثال: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// باستخدام `AsMut` كـ trait bound لوظيفة عامة يمكننا قبول جميع المراجع القابلة للتغيير التي يمكن تحويلها إلى نوع `&mut T`.
/// نظرًا لأن [`Box<T>`] تنفذ `AsMut<T>` ، يمكننا كتابة دالة `add_one` تأخذ جميع الوسائط التي يمكن تحويلها إلى `&mut u64`.
/// نظرًا لأن [`Box<T>`] يستخدم `AsMut<T>` ، يقبل `add_one` وسيطات من النوع `&mut Box<u64>` أيضًا:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// ينفذ التحويل.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// تحويل من قيمة إلى قيمة يستهلك قيمة الإدخال.عكس [`From`].
///
/// يجب على المرء تجنب تنفيذ [`Into`] وتنفيذ [`From`] بدلاً من ذلك.
/// يوفر تنفيذ [`From`] تلقائيًا تنفيذ [`Into`] بفضل التنفيذ الشامل في المكتبة القياسية.
///
/// يفضل استخدام [`Into`] على [`From`] عند تحديد trait bounds على وظيفة عامة لضمان استخدام الأنواع التي تطبق [`Into`] فقط.
///
/// **Note: يجب ألا تفشل trait **.إذا فشل التحويل ، فاستخدم [`TryInto`].
///
/// # تطبيقات عامة
///
/// - [`من`]`<T>لـ U` يعني `Into<U> for T`
/// - [`Into`] هو انعكاسي ، مما يعني أن `Into<T> for T` مطبق
///
/// # تنفيذ [`Into`] للتحويلات إلى أنواع خارجية في الإصدارات القديمة من Rust
///
/// قبل Rust 1.41 ، إذا لم يكن نوع الوجهة جزءًا من crate الحالي ، فلا يمكنك تنفيذ [`From`] مباشرة.
/// على سبيل المثال ، خذ هذا الرمز:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// سيفشل هذا في الترجمة في الإصدارات القديمة من اللغة لأن قواعد Rust المعزولة كانت أكثر صرامة بعض الشيء.
/// لتجاوز هذا ، يمكنك تنفيذ [`Into`] مباشرة:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// من المهم أن نفهم أن [`Into`] لا يوفر تطبيق [`From`] (كما يفعل [`From`] مع [`Into`]).
/// لذلك ، يجب أن تحاول دائمًا تنفيذ [`From`] ثم العودة إلى [`Into`] إذا تعذر تنفيذ [`From`].
///
/// # Examples
///
/// [`String`] تنفذ [`Into`]`<`[`Vec`] `<` [`u8`]` >>:
///
/// للتعبير عن رغبتنا في أن تأخذ وظيفة عامة جميع الوسائط التي يمكن تحويلها إلى نوع محدد `T` ، يمكننا استخدام trait bound من [`Into`]`<T>".
///
/// على سبيل المثال: تأخذ الدالة `is_hello` جميع الوسائط التي يمكن تحويلها إلى [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// ينفذ التحويل.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// تُستخدم لإجراء تحويلات من قيمة إلى قيمة أثناء استهلاك قيمة الإدخال.إنه مقلوب [`Into`].
///
/// يجب أن يفضل المرء دائمًا تنفيذ `From` على [`Into`] لأن تنفيذ `From` يوفر تلقائيًا تنفيذ [`Into`] بفضل التنفيذ الشامل في المكتبة القياسية.
///
///
/// قم بتنفيذ [`Into`] فقط عند استهداف إصدار سابق لـ Rust 1.41 والتحويل إلى نوع خارج crate الحالي.
/// `From` لم يكن قادرًا على إجراء هذه الأنواع من التحويلات في الإصدارات السابقة بسبب قواعد Rust المعزولة.
/// انظر [`Into`] لمزيد من التفاصيل.
///
/// يفضل استخدام [`Into`] على استخدام `From` عند تحديد trait bounds على وظيفة عامة.
/// بهذه الطريقة ، يمكن استخدام الأنواع التي تطبق [`Into`] مباشرةً كوسيطات أيضًا.
///
/// يعتبر `From` مفيدًا جدًا أيضًا عند إجراء معالجة الأخطاء.عند إنشاء دالة قادرة على الفشل ، سيكون نوع الإرجاع بشكل عام على شكل `Result<T, E>`.
/// يبسط `From` trait معالجة الأخطاء من خلال السماح لوظيفة بإرجاع نوع خطأ واحد يغلف أنواع أخطاء متعددة.راجع قسم "Examples" و [the book][book] لمزيد من التفاصيل.
///
/// **Note: يجب ألا تفشل trait **.إذا فشل التحويل ، فاستخدم [`TryFrom`].
///
/// # تطبيقات عامة
///
/// - `From<T> for U` يشير إلى [`Into`]`<U>لـ T`</u>
/// - `From` هو انعكاسي ، مما يعني أن `From<T> for T` مطبق
///
/// # Examples
///
/// [`String`] تنفذ `From<&str>`:
///
/// يتم إجراء تحويل صريح من `&str` إلى سلسلة على النحو التالي:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// أثناء تنفيذ معالجة الأخطاء ، غالبًا ما يكون من المفيد تنفيذ `From` لنوع الخطأ الخاص بك.
/// من خلال تحويل أنواع الأخطاء الأساسية إلى نوع الخطأ المخصص الخاص بنا والذي يغلف نوع الخطأ الأساسي ، يمكننا إرجاع نوع خطأ واحد دون فقد المعلومات حول السبب الأساسي.
/// يقوم عامل التشغيل '?' تلقائيًا بتحويل نوع الخطأ الأساسي إلى نوع الخطأ المخصص لدينا عن طريق استدعاء `Into<CliError>::into` والذي يتم توفيره تلقائيًا عند تنفيذ `From`.
/// يستنتج المترجم بعد ذلك أي تنفيذ لـ `Into` يجب استخدامه.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// ينفذ التحويل.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// محاولة تحويل تستهلك `self` ، وقد تكون باهظة الثمن وقد لا تكون كذلك.
///
/// يجب ألا يقوم مؤلفو المكتبة عادةً بتنفيذ trait مباشرةً ، ولكن يجب أن يفضلوا تطبيق [`TryFrom`] trait ، والذي يوفر مرونة أكبر ويوفر تطبيق `TryInto` مكافئًا مجانًا ، وذلك بفضل التنفيذ الشامل في المكتبة القياسية.
/// لمزيد من المعلومات حول هذا الأمر ، راجع وثائق [`Into`].
///
/// # تنفيذ `TryInto`
///
/// هذا يعاني من نفس القيود والمنطق مثل تنفيذ [`Into`] ، انظر هناك للحصول على التفاصيل.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// النوع الذي تم إرجاعه في حالة حدوث خطأ في التحويل.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// ينفذ التحويل.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// تحويلات بسيطة وآمنة قد تفشل بطريقة محكومة في بعض الظروف.إنه مقلوب [`TryInto`].
///
/// يكون هذا مفيدًا عندما تقوم بتحويل نوع قد ينجح بشكل طفيف ولكنه قد يحتاج أيضًا إلى معالجة خاصة.
/// على سبيل المثال ، لا توجد طريقة لتحويل [`i64`] إلى [`i32`] باستخدام [`From`] trait ، لأن [`i64`] قد يحتوي على قيمة لا يمكن لـ [`i32`] تمثيلها وبالتالي يفقد التحويل البيانات.
///
/// يمكن التعامل مع هذا عن طريق اقتطاع [`i64`] إلى [`i32`] (يعطي بشكل أساسي معيار القيمة [`i64`] [`i32::MAX`]) أو ببساطة عن طريق إرجاع [`i32::MAX`] ، أو بطريقة أخرى.
/// تم تصميم [`From`] trait لإجراء تحويلات مثالية ، لذا فإن `TryFrom` trait تخبر المبرمج عندما يمكن أن يفسد تحويل النوع ويتيح لهم تحديد كيفية التعامل معه.
///
/// # تطبيقات عامة
///
/// - `TryFrom<T> for U` يتضمن [`TryInto`]`<U>لـ T`</u>
/// - [`try_from`] انعكاسي ، مما يعني أن `TryFrom<T> for T` مطبق ولا يمكن أن يفشل-نوع `Error` المرتبط لاستدعاء `T::try_from()` بقيمة من النوع `T` هو [`Infallible`].
/// عندما يكون النوع [`!`] مستقرًا ، سيكون [`Infallible`] و [`!`] مكافئًا.
///
/// `TryFrom<T>` يمكن تنفيذها على النحو التالي:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// كما هو موضح ، يقوم [`i32`] بتنفيذ `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // يقطع `big_number` بصمت ، ويتطلب الكشف عن الاقتطاع والتعامل معه بعد الحقيقة.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // إرجاع خطأ لأن `big_number` أكبر من أن يلائم `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // إرجاع `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// النوع الذي تم إرجاعه في حالة حدوث خطأ في التحويل.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// ينفذ التحويل.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// الضمانات العامة
////////////////////////////////////////////////////////////////////////////////

// كالمصاعد و
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// كرافعات فوق &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): استبدل الأدوات المذكورة أعلاه لـ&/&mut بما يلي أكثر عمومية:
// // كرافعات فوق ديريف
// ضمني <D: ?Sized + Deref<Target: AsRef<U>>، U:؟ Sized> AsRef <U>لـ D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// يرفع AsMut أكثر من &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): استبدل الأداة الموضحة أعلاه لـ &mut بالأخرى العامة التالية:
// // AsMut يرفع فوق DerefMut
// ضمني <D: ?Sized + Deref<Target: AsMut<U>>، U:؟ Sized> AsMut <U>لـ D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// من يعني إلى
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// من (وبالتالي إلى) هو انعكاسي
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **ملاحظة الاستقرار:** هذا التضمين غير موجود بعد ، لكننا سنستخدم "reserving space" لإضافته في future.
/// راجع [rust-lang/rust#64715][#64715] للحصول على التفاصيل.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): بدلاً من ذلك ، قم بإصلاح مبدئي.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// يشير TryFrom إلى TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// التحويلات المعصومة هي مكافئة لغويًا للتحويلات غير المعصومة مع نوع خطأ غير مأهول.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// الضمانات الخرسانية
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// نوع الخطأ "NO-ERROR"
////////////////////////////////////////////////////////////////////////////////

/// نوع الخطأ للأخطاء التي لا يمكن أن تحدث أبدًا.
///
/// نظرًا لعدم وجود متغير في هذا التعداد ، لا يمكن أبدًا أن توجد قيمة من هذا النوع في الواقع.
/// يمكن أن يكون هذا مفيدًا لواجهات برمجة التطبيقات العامة التي تستخدم [`Result`] وتحدد نوع الخطأ ، للإشارة إلى أن النتيجة دائمًا هي [`Ok`].
///
/// على سبيل المثال ، يحتوي [`TryFrom`] trait (التحويل الذي يعيد [`Result`]) على تطبيق شامل لجميع الأنواع حيث يوجد تطبيق [`Into`] عكسي.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # التوافق مع Future
///
/// هذا التعداد له نفس دور [the `!`“never”type][never] ، وهو غير مستقر في هذا الإصدار من Rust.
/// عندما يستقر `!` ، نخطط لجعل `Infallible` اسمًا مستعارًا له:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... وإهمال `Infallible` في النهاية.
///
/// ومع ذلك ، هناك حالة واحدة حيث يمكن استخدام بناء جملة `!` قبل تثبيت `!` كنوع كامل: في موضع نوع إرجاع الوظيفة.
/// على وجه التحديد ، من الممكن تنفيذ نوعين مختلفين من مؤشرات الوظائف:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// مع كون `Infallible` تعدادًا ، فإن هذا الرمز صالح.
/// ومع ذلك ، عندما يصبح `Infallible` اسمًا مستعارًا لـ never type ، سيبدأ `` الضمانيان '' في التداخل ، وبالتالي لن يتم السماح بهما بواسطة قواعد تماسك اللغة trait.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}