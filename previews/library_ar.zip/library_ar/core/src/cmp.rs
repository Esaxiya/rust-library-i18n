//! وظائف الطلب والمقارنة.
//!
//! تحتوي هذه الوحدة على أدوات مختلفة لترتيب ومقارنة القيم.باختصار:
//!
//! * [`Eq`] و [`PartialEq`] هما traits اللذان يسمحان لك بتحديد المساواة الكلية والجزئية بين القيم ، على التوالي.
//! يؤدي تنفيذها إلى زيادة التحميل على مشغلي `==` و `!=`.
//! * [`Ord`] و [`PartialOrd`] هما traits اللذان يسمحان لك بتحديد الطلبات الكلية والجزئية بين القيم ، على التوالي.
//!
//! يؤدي تنفيذها إلى زيادة التحميل على مشغلي `<` و `<=` و `>` و `>=`.
//! * [`Ordering`] هو تعداد تم إرجاعه بواسطة الوظائف الرئيسية لـ [`Ord`] و [`PartialOrd`] ، ويصف الأمر.
//! * [`Reverse`] هي بنية تسمح لك بعكس الطلب بسهولة.
//! * [`max`] و [`min`] هي دالات تبني [`Ord`] وتسمح لك بالعثور على قيمتين كحد أقصى أو أدنى.
//!
//! لمزيد من التفاصيل ، راجع الوثائق الخاصة بكل عنصر في القائمة.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait لمقارنات المساواة التي هي [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// يسمح trait بالمساواة الجزئية للأنواع التي ليس لها علاقة تكافؤ كاملة.
/// على سبيل المثال ، في أرقام الفاصلة العائمة `NaN != NaN` ، فإن أنواع الفاصلة العائمة تطبق `PartialEq` وليس [`trait@Eq`].
///
/// بشكل رسمي ، يجب أن تكون المساواة (لجميع `a` ، `b` ، `c` من النوع `A` ، `B` ، `C`):
///
/// - **متماثل**: إذا كان `A: PartialEq<B>` و `B: PartialEq<A>` ، فإن **`a==b` يعني`b==a`**؛و
///
/// - **متعدية**: إذا كان `A: PartialEq<B>` و `B: PartialEq<C>` و `A:
///   جزئية<C>`، ثم يشير **` a==b`و `b == c` إلى`a==c`**.
///
/// لاحظ أن الضمانات `B: PartialEq<A>` (symmetric) و `A: PartialEq<C>` (transitive) ليست مجبرة على الوجود ، ولكن هذه المتطلبات تنطبق متى وجدت.
///
/// ## Derivable
///
/// يمكن استخدام trait مع `#[derive]`.عند `derive`d على البُنى ، فإن مثيلين متساويين إذا كانت جميع الحقول متساوية وغير متساوية إذا لم تتساوى أي من الحقول.عند `اشتقاق`d على التعدادات ، فإن كل متغير يساوي نفسه ولا يساوي المتغيرات الأخرى.
///
/// ## كيف يمكنني تنفيذ `PartialEq`؟
///
/// `PartialEq` يتطلب فقط تنفيذ طريقة [`eq`] ؛يتم تعريف [`ne`] من حيث ذلك بشكل افتراضي.يجب أن يحترم أي تطبيق يدوي لـ [`ne`] * القاعدة القائلة بأن [`eq`] هو معكوس صارم لـ [`ne`] ؛هذا هو ، `!(a == b)` فقط إذا كان `a != b`.
///
/// يجب أن تتوافق تطبيقات `PartialEq` و [`PartialOrd`] و [`Ord`] * مع بعضها البعض.من السهل جعلهم يختلفون عن طريق الخطأ عن طريق اشتقاق بعض traits وتنفيذ البعض الآخر يدويًا.
///
/// مثال على التنفيذ لنطاق يتم فيه اعتبار كتابين نفس الكتاب إذا تطابق رقم ISBN الخاص بهما ، حتى إذا كانت التنسيقات مختلفة:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## كيف يمكنني المقارنة بين نوعين مختلفين؟
///
/// يتم التحكم في النوع الذي يمكنك مقارنته بواسطة معلمة النوع "PartialEq".
/// على سبيل المثال ، دعنا نعدل الكود السابق قليلاً:
///
/// ```
/// // أدوات الاشتقاق<BookFormat>==<BookFormat>مقارنات
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // ينفذ<Book>==<BookFormat>مقارنات
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // ينفذ<BookFormat>==<Book>مقارنات
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// بتغيير `impl PartialEq for Book` إلى `impl PartialEq<BookFormat> for Book` ، نسمح بمقارنة تنسيق BookFormat مع "Book".
///
/// يمكن أن تكون المقارنة مثل تلك أعلاه ، والتي تتجاهل بعض حقول البنية ، خطيرة.يمكن أن يؤدي بسهولة إلى انتهاك غير مقصود لمتطلبات علاقة التكافؤ الجزئية.
/// على سبيل المثال ، إذا احتفظنا بالتطبيق أعلاه لـ `PartialEq<Book>` لـ `BookFormat` وأضفنا تطبيق `PartialEq<Book>` لـ `Book` (إما عبر `#[derive]` أو عبر التنفيذ اليدوي من المثال الأول) ، فإن النتيجة تنتهك العبور:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// تختبر هذه الطريقة قيم `self` و `other` لتكون متساوية ويتم استخدامها بواسطة `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// تختبر هذه الطريقة لـ `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// اشتق الماكرو لتوليد إشارة من trait `PartialEq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait لمقارنات المساواة التي هي [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// هذا يعني أنه بالإضافة إلى `a == b` و `a != b` كونها مقلوبة صارمة ، يجب أن تكون المساواة (لجميع `a` و `b` و `c`):
///
/// - reflexive: `a == a`;
/// - متماثل: `a == b` يعني `b == a` ؛و
/// - متعدية: `a == b` و `b == c` تعني `a == c`.
///
/// لا يمكن للمترجم التحقق من هذه الخاصية ، وبالتالي فإن `Eq` تتضمن [`PartialEq`] ، وليس لها طرق إضافية.
///
/// ## Derivable
///
/// يمكن استخدام trait مع `#[derive]`.
/// عندما "اشتقاق" ، نظرًا لعدم وجود طرق إضافية لـ `Eq` ، يتم إعلام المترجم فقط بأن هذه علاقة تكافؤ وليست علاقة تكافؤ جزئية.
///
/// لاحظ أن استراتيجية `derive` تتطلب أن تكون جميع الحقول `Eq` ، وهو أمر غير مرغوب فيه دائمًا.
///
/// ## كيف يمكنني تنفيذ `Eq`؟
///
/// إذا لم تتمكن من استخدام إستراتيجية `derive` ، فحدد أن النوع الخاص بك يقوم بتنفيذ `Eq` ، والذي لا يحتوي على طرق:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // تُستخدم هذه الطريقة فقط عن طريق#[اشتقاق] للتأكيد على أن كل مكون من نوع ما ينفذ#[اشتقاق] نفسه ، والبنية التحتية المشتقة الحالية تعني القيام بهذا التأكيد دون استخدام طريقة على trait يكاد يكون مستحيلًا.
    //
    //
    // هذا لا ينبغي أن يتم تنفيذه باليد.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// اشتق الماكرو لتوليد إشارة من trait `Eq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: يتم استخدام هذا الهيكل فقط بواسطة#[اشتقاق] إلى
// أكد أن كل مكون من نوع ما يطبق المعادلة.
//
// يجب ألا تظهر هذه البنية في كود المستخدم.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Ordering` هو نتيجة المقارنة بين قيمتين.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// طلب تكون فيه القيمة المقارنة أقل من قيمة أخرى.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// ترتيب حيث تكون القيمة المقارنة مساوية لأخرى.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// ترتيب تكون فيه القيمة المقارنة أكبر من قيمة أخرى.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// تُرجع `true` إذا كان الأمر هو متغير `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// تُرجع `true` إذا لم يكن الأمر متغير `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// تُرجع `true` إذا كان الأمر هو متغير `Less`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// تُرجع `true` إذا كان الأمر هو متغير `Greater`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// تُرجع `true` إذا كان الأمر هو المتغير `Less` أو `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// تُرجع `true` إذا كان الأمر هو المتغير `Greater` أو `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// يعكس `Ordering`.
    ///
    /// * `Less` يصبح `Greater`.
    /// * `Greater` يصبح `Less`.
    /// * `Equal` يصبح `Equal`.
    ///
    /// # Examples
    ///
    /// السلوك الأساسي:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// يمكن استخدام هذه الطريقة لعكس المقارنة:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // رتب المصفوفة من الأكبر إلى الأصغر.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// سلاسل طلبيتين.
    ///
    /// تُرجع `self` عندما لا تكون `Equal`.وإلا ترجع `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// يربط الترتيب بالدالة المحددة.
    ///
    /// تُرجع `self` عندما لا تكون `Equal`.
    /// بخلاف ذلك ، يستدعي `f` ويعيد النتيجة.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// هيكل مساعد للترتيب العكسي.
///
/// هذا الهيكل عبارة عن مساعد يتم استخدامه مع وظائف مثل [`Vec::sort_by_key`] ويمكن استخدامه لعكس ترتيب جزء من المفتاح.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait للأنواع التي تشكل [total order](https://en.wikipedia.org/wiki/Total_order).
///
/// الطلب هو أمر إجمالي إذا كان (لجميع `a` و `b` و `c`):
///
/// - الإجمالي وغير المتماثل: واحد بالضبط من `a < b` أو `a == b` أو `a > b` صحيح ؛و
/// - متعدية ، `a < b` و `b < c` تعني `a < c`.يجب أن ينطبق الشيء نفسه على كل من `==` و `>`.
///
/// ## Derivable
///
/// يمكن استخدام trait مع `#[derive]`.
/// عندما `اشتقاق`d على البنى ، سينتج أمر [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) بناءً على ترتيب الإعلان من أعلى إلى أسفل لأعضاء الهيكل.
///
/// عند `الاشتقاق`d على التعدادات ، يتم ترتيب المتغيرات بترتيب التمايز من أعلى إلى أسفل.
///
/// ## مقارنة معجمية
///
/// المقارنة المعجمية هي عملية بالخصائص التالية:
///  - يتم مقارنة تسلسلين عنصرًا عنصرًا.
///  - يحدد عنصر عدم التطابق الأول التسلسل الذي يكون أقل أو أكبر من الآخر من الناحية المعجمية.
///  - إذا كان أحد التسلسل هو بادئة لسلسلة أخرى ، فإن التسلسل الأقصر يكون أقل من الآخر من الناحية المعجمية.
///  - إذا كان هناك تسلسلان لهما عناصر متكافئة وكانا من نفس الطول ، فإن التسلسل يكون متساويًا في المعجم.
///  - التسلسل الفارغ هو أقل معجمياً من أي تسلسل غير فارغ.
///  - تسلسلان فارغان متساويان في المعجم.
///
/// ## كيف يمكنني تنفيذ `Ord`؟
///
/// `Ord` يتطلب أن يكون النوع أيضًا [`PartialOrd`] و [`Eq`] (والذي يتطلب [`PartialEq`]).
///
/// ثم يجب عليك تحديد تطبيق لـ [`cmp`].قد تجد أنه من المفيد استخدام [`cmp`] في حقول النوع الخاص بك.
///
/// يجب أن تتوافق تطبيقات [`PartialEq`] و [`PartialOrd`] و `Ord` * مع بعضها البعض.
/// هذا هو ، `a.cmp(b) == Ordering::Equal` فقط إذا كان `a == b` و `Some(a.cmp(b)) == a.partial_cmp(b)` لجميع `a` و `b`.
/// من السهل جعلهم يختلفون عن طريق الخطأ عن طريق اشتقاق بعض traits وتنفيذ البعض الآخر يدويًا.
///
/// إليك مثال حيث تريد تصنيف الأشخاص حسب الارتفاع فقط ، بغض النظر عن `id` و `name`:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// تقوم هذه الطريقة بإرجاع [`Ordering`] بين `self` و `other`.
    ///
    /// حسب الاصطلاح ، تُرجع `self.cmp(&other)` الترتيب المطابق للتعبير `self <operator> other` إذا كان صحيحًا.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// يقارن ويعيد الحد الأقصى من قيمتين.
    ///
    /// لعرض الوسيطة الثانية إذا حددت المقارنة أنها متساوية.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// يقارن ويعيد الحد الأدنى من قيمتين.
    ///
    /// تُرجع الوسيطة الأولى إذا حددت المقارنة أنها متساوية.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// قصر قيمة على فترة زمنية معينة.
    ///
    /// تُرجع `max` إذا كان `self` أكبر من `max` و `min` إذا كان `self` أقل من `min`.
    /// وإلا فإن هذا يعيد `self`.
    ///
    /// # Panics
    ///
    /// Panics إذا كان `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// اشتق الماكرو لتوليد إشارة من trait `Ord`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait للقيم التي يمكن مقارنتها بترتيب الفرز.
///
/// يجب أن تفي المقارنة ، لجميع `a` و `b` و `c`:
///
/// - عدم التناسق: إذا كان `a < b` ثم `!(a > b)` ، وكذلك `a > b` يعني `!(a < b)` ؛و
/// - العبور: `a < b` و `b < c` تعني `a < c`.يجب أن ينطبق الشيء نفسه على كل من `==` و `>`.
///
/// لاحظ أن هذه المتطلبات تعني أنه يجب تنفيذ trait نفسه بشكل متماثل وعابر: إذا كان `T: PartialOrd<U>` و `U: PartialOrd<V>` ثم `U: PartialOrd<T>` و `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// يمكن استخدام trait مع `#[derive]`.عندما "اشتقاق" على البنى ، سينتج ترتيبًا معجميًا بناءً على ترتيب التصريح من أعلى إلى أسفل لأعضاء الهيكل.
/// عند `الاشتقاق`d على التعدادات ، يتم ترتيب المتغيرات بترتيب التمايز من أعلى إلى أسفل.
///
/// ## كيف يمكنني تنفيذ `PartialOrd`؟
///
/// `PartialOrd` يتطلب فقط تنفيذ طريقة [`partial_cmp`] ، مع الطرق الأخرى التي تم إنشاؤها من عمليات التنفيذ الافتراضية.
///
/// ومع ذلك ، يظل من الممكن تنفيذ الآخرين بشكل منفصل للأنواع التي لا تحتوي على ترتيب إجمالي.
/// على سبيل المثال ، لأرقام الفاصلة العائمة ، `NaN < 0 == false` و `NaN >= 0 == false` (راجع.
/// IEEE 754-2008 القسم 5.11).
///
/// `PartialOrd` يتطلب أن يكون النوع الخاص بك [`PartialEq`].
///
/// يجب أن تتوافق تطبيقات [`PartialEq`] و `PartialOrd` و [`Ord`] * مع بعضها البعض.
/// من السهل جعلهم يختلفون عن طريق الخطأ عن طريق اشتقاق بعض traits وتنفيذ البعض الآخر يدويًا.
///
/// إذا كان النوع الخاص بك هو [`Ord`] ، فيمكنك تنفيذ [`partial_cmp`] باستخدام [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// قد تجد أيضًا أنه من المفيد استخدام [`partial_cmp`] في حقول النوع الخاص بك.
/// فيما يلي مثال لأنواع `Person` التي لديها حقل `height` فاصلة عائمة وهو الحقل الوحيد الذي سيتم استخدامه للفرز:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// تقوم هذه الطريقة بإرجاع طلب بين قيم `self` و `other` في حالة وجود أحدهما.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// عندما تكون المقارنة مستحيلة:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// تختبر هذه الطريقة أقل من (لـ `self` و `other`) ويستخدمها عامل التشغيل `<`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// تختبر هذه الطريقة أقل من أو يساوي (لـ `self` و `other`) ويستخدمها عامل التشغيل `<=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// تختبر هذه الطريقة أكبر من (لـ `self` و `other`) ويستخدمها عامل التشغيل `>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// تختبر هذه الطريقة أكبر من أو يساوي (لـ `self` و `other`) ويستخدمها عامل التشغيل `>=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// اشتق الماكرو لتوليد إشارة من trait `PartialOrd`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// يقارن ويعيد الحد الأدنى من قيمتين.
///
/// تُرجع الوسيطة الأولى إذا حددت المقارنة أنها متساوية.
///
/// يستخدم داخليًا اسمًا مستعارًا لـ [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// تُرجع الحد الأدنى من قيمتين فيما يتعلق بدالة المقارنة المحددة.
///
/// تُرجع الوسيطة الأولى إذا حددت المقارنة أنها متساوية.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// تُرجع العنصر الذي يعطي الحد الأدنى من القيمة من الوظيفة المحددة.
///
/// تُرجع الوسيطة الأولى إذا حددت المقارنة أنها متساوية.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// يقارن ويعيد الحد الأقصى من قيمتين.
///
/// لعرض الوسيطة الثانية إذا حددت المقارنة أنها متساوية.
///
/// يستخدم داخليًا اسمًا مستعارًا لـ [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// تُرجع الحد الأقصى من قيمتين فيما يتعلق بدالة المقارنة المحددة.
///
/// لعرض الوسيطة الثانية إذا حددت المقارنة أنها متساوية.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// تُرجع العنصر الذي يعطي القيمة القصوى من الوظيفة المحددة.
///
/// لعرض الوسيطة الثانية إذا حددت المقارنة أنها متساوية.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// تنفيذ PartialEq و Eq و PartialOrd و Ord للأنواع البدائية
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // الترتيب هنا مهم لتوليد تجميع أمثل.
                    // انظر <https://github.com/rust-lang/rust/issues/63758> لمزيد من المعلومات.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // يؤدي الإرسال إلى i8 وتحويل الفرق إلى ترتيب إلى إنشاء تجميع أمثل.
            //
            // انظر <https://github.com/rust-lang/rust/issues/66780> لمزيد من المعلومات.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // الأمان: bool حيث تقوم i8 بإرجاع 0 أو 1 ، لذلك لا يمكن أن يكون الفرق أي شيء آخر
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &المؤشرات

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}