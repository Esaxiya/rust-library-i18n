//! شار {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// أعلى نقطة رمز صالحة يمكن أن يمتلكها `char`.
    ///
    /// A `char` هو [Unicode Scalar Value] ، مما يعني أنه [Code Point] ، ولكنه فقط ضمن نطاق معين.
    /// `MAX` هي أعلى نقطة رمز صالحة وهي [Unicode Scalar Value] صالحة.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` يتم استخدام () في Unicode لتمثيل خطأ في فك التشفير.
    ///
    /// يمكن أن يحدث ، على سبيل المثال ، عند إعطاء UTF-8 بايت غير صحيح إلى [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// إصدار [Unicode](http://www.unicode.org/) الذي تستند إليه أجزاء Unicode من طرق `char` و `str`.
    ///
    /// يتم إصدار إصدارات جديدة من Unicode بانتظام وبالتالي يتم تحديث جميع الطرق في المكتبة القياسية اعتمادًا على Unicode.
    /// لذلك يتغير سلوك بعض طرق `char` و `str` وقيمة هذا الثابت بمرور الوقت.
    /// هذا *لا* يعتبر تغيير جذري.
    ///
    /// تم شرح نظام ترقيم الإصدارات في [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// ينشئ مكررًا فوق نقاط الرمز UTF-16 المشفرة في `iter` ، ويعيد البدائل غير المزاوجة كـ `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// يمكن الحصول على وحدة فك الترميز المفقودة عن طريق استبدال نتائج `Err` بحرف الاستبدال:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// يحول `u32` إلى `char`.
    ///
    /// لاحظ أن جميع أحرف `u32` صالحة ويمكن تحويلها إلى واحدة بها
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// ومع ذلك ، فإن العكس ليس صحيحًا: ليست كل الـ [`u32`] الصالحة هي`char`s الصالحة.
    /// `from_u32()` سيعيد `None` إذا لم يكن الإدخال قيمة صالحة لـ `char`.
    ///
    /// للحصول على إصدار غير آمن من هذه الوظيفة يتجاهل هذه الفحوصات ، راجع [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// إرجاع `None` عندما لا يكون الإدخال `char` صالحًا:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// يحول `u32` إلى `char` ، متجاهلاً الصلاحية.
    ///
    /// لاحظ أن جميع أحرف `u32` صالحة ويمكن تحويلها إلى واحدة بها
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// ومع ذلك ، فإن العكس ليس صحيحًا: ليست كل الـ [`u32`] الصالحة هي`char`s الصالحة.
    /// `from_u32_unchecked()` سوف يتجاهل هذا ، ويلقي بشكل أعمى إلى `char` ، مما قد يؤدي إلى إنشاء واحدة غير صالحة.
    ///
    ///
    /// # Safety
    ///
    /// هذه الوظيفة غير آمنة ، لأنها قد تنشئ قيم `char` غير صالحة.
    ///
    /// للحصول على نسخة آمنة من هذه الوظيفة ، راجع وظيفة [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // الأمان: يجب أن يتم دعم عقد الأمان من قبل المتصل.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// تحويل رقم في الأصل المحدد إلى `char`.
    ///
    /// يُطلق على 'radix' هنا أحيانًا اسم 'base'.
    /// يشير الجذر المكون من اثنين إلى رقم ثنائي ، وجذر مكون من عشرة ، وكسر عشري ، وجذر مكون من ستة عشر ، سداسي عشري ، لإعطاء بعض القيم المشتركة.
    ///
    /// يتم دعم الإشعاع التعسفي.
    ///
    /// `from_digit()` سيعيد `None` إذا لم يكن الإدخال رقمًا في الجذر المحدد.
    ///
    /// # Panics
    ///
    /// Panics إذا أعطيت جذرًا أكبر من 36.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // العدد العشري 11 هو رقم واحد في الأساس 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// إرجاع `None` عندما لا يكون الإدخال رقمًا:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// اجتياز جذع كبير ، مما تسبب في ظهور panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// للتحقق مما إذا كان `char` هو رقم في الأصل المحدد.
    ///
    /// يُطلق على 'radix' هنا أحيانًا اسم 'base'.
    /// يشير الجذر المكون من اثنين إلى رقم ثنائي ، وجذر مكون من عشرة ، وكسر عشري ، وجذر مكون من ستة عشر ، سداسي عشري ، لإعطاء بعض القيم المشتركة.
    ///
    /// يتم دعم الإشعاع التعسفي.
    ///
    /// بالمقارنة مع [`is_numeric()`] ، تتعرف هذه الوظيفة فقط على الأحرف `0-9` و `a-z` و `A-Z`.
    ///
    /// 'Digit' تم تعريفه على أنه الأحرف التالية فقط:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// للحصول على فهم أكثر شمولاً لـ 'digit' ، راجع [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics إذا أعطيت جذرًا أكبر من 36.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// اجتياز جذع كبير ، مما تسبب في ظهور panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// تحويل `char` إلى رقم في الأصل المحدد.
    ///
    /// يُطلق على 'radix' هنا أحيانًا اسم 'base'.
    /// يشير الجذر المكون من اثنين إلى رقم ثنائي ، وجذر مكون من عشرة ، وكسر عشري ، وجذر مكون من ستة عشر ، سداسي عشري ، لإعطاء بعض القيم المشتركة.
    ///
    /// يتم دعم الإشعاع التعسفي.
    ///
    /// 'Digit' تم تعريفه على أنه الأحرف التالية فقط:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// تُرجع `None` إذا كان `char` لا يشير إلى رقم في الأصل المحدد.
    ///
    /// # Panics
    ///
    /// Panics إذا أعطيت جذرًا أكبر من 36.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// يؤدي اجتياز رقم غير رقمي إلى الفشل:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// اجتياز جذع كبير ، مما تسبب في ظهور panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // يتم تقسيم الكود هنا لتحسين سرعة التنفيذ للحالات التي يكون فيها `radix` ثابتًا و 10 أو أصغر
        //
        let val = if likely(radix <= 10) {
            // إذا لم يكن رقمًا ، فسيتم إنشاء رقم أكبر من الجذر.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// إرجاع مكرر ينتج عنه هروب Unicode السداسي العشري للحرف كـ `char`s.
    ///
    /// سيؤدي هذا إلى إفلات الأحرف باستخدام بناء جملة Rust للنموذج `\u{NNNNNN}` حيث يمثل `NNNNNN` تمثيلًا سداسيًا عشريًا.
    ///
    ///
    /// # Examples
    ///
    /// كمكرر:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// باستخدام `println!` مباشرة:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// كلاهما يعادل:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// باستخدام `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // يضمن or-ing 1 أنه بالنسبة لـ c==0 ، يحسب الرمز أنه يجب طباعة رقم واحد و (وهو نفسه) يتجنب التدفق السفلي (31 ، 32)
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // مؤشر أهم رقم سداسي عشري
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// إصدار ممتد من `escape_debug` يسمح اختياريًا بالهروب من نقاط كود Grapheme الموسعة.
    /// يتيح لنا ذلك تنسيق الأحرف مثل علامات عدم التباعد بشكل أفضل عندما تكون في بداية سلسلة.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// يُرجع مكررًا ينتج عنه رمز الهروب الحرفي للحرف على هيئة حرف `char`s.
    ///
    /// سيؤدي هذا إلى الهروب من الأحرف المشابهة لتطبيقات `Debug` لـ `str` أو `char`.
    ///
    ///
    /// # Examples
    ///
    /// كمكرر:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// باستخدام `println!` مباشرة:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// كلاهما يعادل:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// باستخدام `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// يُرجع مكررًا ينتج عنه رمز الهروب الحرفي للحرف على هيئة حرف `char`s.
    ///
    /// يتم اختيار الإعداد الافتراضي مع وجود انحياز نحو إنتاج حرفية قانونية في مجموعة متنوعة من اللغات ، بما في ذلك C++ 11 ولغات عائلة C المماثلة.
    /// القواعد الدقيقة هي:
    ///
    /// * تم تخطي علامة التبويب `\t`.
    /// * تم إفلات حرف الإرجاع كـ `\r`.
    /// * تم تخطي تغذية السطر كـ `\n`.
    /// * تم تخطي الاقتباس الفردي كـ `\'`.
    /// * تم تخطي الاقتباس المزدوج كـ `\"`.
    /// * يتم تخطي الشرطة المائلة للخلف كـ `\\`.
    /// * أي حرف في النطاق "ASCII القابل للطباعة" `0x20` .. لا يتم تخطي `0x7e`.
    /// * يتم إعطاء جميع الأحرف الأخرى عمليات هروب Unicode سداسية عشرية ؛انظر [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// كمكرر:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// باستخدام `println!` مباشرة:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// كلاهما يعادل:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// باستخدام `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// لعرض عدد البايتات التي سيحتاجها `char` هذا إذا تم ترميزه في UTF-8.
    ///
    /// هذا العدد من البايت يكون دائمًا بين 1 و 4 ، ضمناً.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// يضمن النوع `&str` أن محتوياته هي UTF-8 ، ولذا يمكننا مقارنة الطول الذي قد يستغرقه إذا تم تمثيل كل نقطة رمز على أنها `char` مقابل `&str` نفسها:
    ///
    ///
    /// ```
    /// // كحرف
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // يمكن تمثيل كلاهما بثلاثة بايت
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // ك &str ، يتم ترميز هذين في UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // يمكننا أن نرى أنها تأخذ إجمالي ستة بايت ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... تمامًا مثل &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// تُرجع عدد وحدات التعليمات البرمجية ذات 16 بت التي سيحتاجها `char` إذا تم ترميزها في UTF-16.
    ///
    ///
    /// راجع وثائق [`len_utf8()`] لمزيد من الشرح لهذا المفهوم.
    /// هذه الوظيفة هي مرآة ، ولكن UTF-16 بدلاً من UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// يقوم بترميز هذا الحرف كـ UTF-8 في المخزن المؤقت للبايت المتوفر ، ثم يقوم بإرجاع الشريحة الفرعية للمخزن المؤقت الذي يحتوي على الحرف المشفر.
    ///
    ///
    /// # Panics
    ///
    /// Panics إذا لم يكن المخزن المؤقت كبيرًا بدرجة كافية.
    /// مخزن مؤقت بطول أربعة كبير بما يكفي لترميز أي `char`.
    ///
    /// # Examples
    ///
    /// في كلا المثالين ، يأخذ 'ß' وحدتي بايت للتشفير.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// مخزن مؤقت صغير جدًا:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // الأمان: `char` ليس بديلاً ، لذلك هذا UTF-8 صالح.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// يقوم بترميز هذا الحرف كـ UTF-16 في المخزن المؤقت `u16` المتوفر ، ثم يقوم بإرجاع الشريحة الفرعية للمخزن المؤقت الذي يحتوي على الحرف المشفر.
    ///
    ///
    /// # Panics
    ///
    /// Panics إذا لم يكن المخزن المؤقت كبيرًا بدرجة كافية.
    /// مخزن مؤقت بطول 2 كبير بما يكفي لترميز أي `char`.
    ///
    /// # Examples
    ///
    /// في كلا المثالين ، يأخذ '𝕊' حرفين من "u16" للتشفير.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// مخزن مؤقت صغير جدًا:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// ترجع `true` إذا كان `char` هذا يحتوي على خاصية `Alphabetic`.
    ///
    /// `Alphabetic` موصوفة في الفصل 4 (خصائص الأحرف) من [Unicode Standard] ومحددة في [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // الحب أشياء كثيرة ، لكنه ليس أبجديًا
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// ترجع `true` إذا كان `char` هذا يحتوي على خاصية `Lowercase`.
    ///
    /// `Lowercase` موصوفة في الفصل 4 (خصائص الأحرف) من [Unicode Standard] ومحددة في [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // لا تحتوي النصوص الصينية المختلفة وعلامات الترقيم على حالة ، وهكذا:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// ترجع `true` إذا كان `char` هذا يحتوي على خاصية `Uppercase`.
    ///
    /// `Uppercase` موصوفة في الفصل 4 (خصائص الأحرف) من [Unicode Standard] ومحددة في [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // لا تحتوي النصوص الصينية المختلفة وعلامات الترقيم على حالة ، وهكذا:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// ترجع `true` إذا كان `char` هذا يحتوي على خاصية `White_Space`.
    ///
    /// `White_Space` محدد في [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // مساحة غير منقسمة
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// تُرجع `true` إذا كان `char` يتوافق مع [`is_alphabetic()`] أو [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// تُرجع `true` إذا كان `char` يحتوي على الفئة العامة لرموز التحكم.
    ///
    /// تم وصف أكواد التحكم (نقاط الرمز مع الفئة العامة لـ `Cc`) في الفصل 4 (خصائص الأحرف) من [Unicode Standard] ومحددة في [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// // U + 009C ، STRING المنهي
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// ترجع `true` إذا كان `char` هذا يحتوي على خاصية `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` موصوفة في [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] ومحددة في [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// تُرجع `true` إذا كان `char` يحتوي على إحدى الفئات العامة للأرقام.
    ///
    /// تم تحديد الفئات العامة للأرقام (`Nd` للأرقام العشرية ، `Nl` للأحرف الرقمية الشبيهة بالأحرف ، و `No` للأحرف الرقمية الأخرى) في [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// إرجاع مكرر ينتج عنه تعيين الأحرف الصغيرة لـ `char` كواحد أو أكثر
    /// `char`s.
    ///
    /// إذا لم يكن `char` هذا يحتوي على تعيين أحرف صغيرة ، فسيقوم المكرر بإنتاج نفس `char`.
    ///
    /// إذا كان `char` هذا يحتوي على تعيين حرف صغير واحد لواحد معطى بواسطة [Unicode Character Database][ucd] [`UnicodeData.txt`] ، فإن المكرر ينتج ذلك `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// إذا تطلب `char` هذا اعتبارات خاصة (مثل "حرف" متعددة) ، فسيقوم المكرر بإنتاج "الحرف" (الأحرف) التي يوفرها [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// تؤدي هذه العملية تخطيطًا غير مشروط بدون تفصيل.أي أن التحويل مستقل عن السياق واللغة.
    ///
    /// في [Unicode Standard] ، يناقش الفصل 4 (خصائص الأحرف) تعيين الحالة بشكل عام ويناقش الفصل 3 (Conformance) الخوارزمية الافتراضية لتحويل الحالة.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// كمكرر:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// باستخدام `println!` مباشرة:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// كلاهما يعادل:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// باستخدام `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // في بعض الأحيان تكون النتيجة أكثر من شخصية واحدة:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // يتم تحويل الأحرف التي لا تحتوي على أحرف كبيرة وصغيرة إلى نفسها.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// إرجاع مكرر ينتج عنه تعيين الأحرف الكبيرة لـ `char` كواحد أو أكثر
    /// `char`s.
    ///
    /// إذا كان `char` هذا لا يحتوي على تعيين أحرف كبيرة ، فإن المكرر ينتج نفس `char`.
    ///
    /// إذا كان `char` هذا يحتوي على تعيين أحرف كبيرة واحد لواحد معطى بواسطة [Unicode Character Database][ucd] [`UnicodeData.txt`] ، فإن المكرر ينتج ذلك `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// إذا تطلب `char` هذا اعتبارات خاصة (مثل "حرف" متعددة) ، فسيقوم المكرر بإنتاج "الحرف" (الأحرف) التي يوفرها [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// تؤدي هذه العملية تخطيطًا غير مشروط بدون تفصيل.أي أن التحويل مستقل عن السياق واللغة.
    ///
    /// في [Unicode Standard] ، يناقش الفصل 4 (خصائص الأحرف) تعيين الحالة بشكل عام ويناقش الفصل 3 (Conformance) الخوارزمية الافتراضية لتحويل الحالة.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// كمكرر:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// باستخدام `println!` مباشرة:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// كلاهما يعادل:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// باستخدام `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // في بعض الأحيان تكون النتيجة أكثر من شخصية واحدة:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // يتم تحويل الأحرف التي لا تحتوي على أحرف كبيرة وصغيرة إلى نفسها.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # ملاحظة حول اللغة
    ///
    /// في التركية ، ما يعادل 'i' باللاتينية له خمسة أشكال بدلاً من شكلين:
    ///
    /// * 'Dotless': أنا/أنا ، مكتوبة في بعض الأحيان ï
    /// * 'Dotted': أنا/أنا
    ///
    /// لاحظ أن 'i' منقط بالأحرف الصغيرة هو نفسه اللاتينية.لذلك:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// تعتمد قيمة `upper_i` هنا على لغة النص: إذا كنا في `en-US` ، فيجب أن تكون `"I"` ، ولكن إذا كنا في `tr_TR` ، فيجب أن تكون `"İ"`.
    /// `to_uppercase()` لا تأخذ ذلك في الحسبان ، ولذا:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// يحمل عبر اللغات.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// للتحقق مما إذا كانت القيمة ضمن نطاق ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// يجعل نسخة من القيمة في أحرفها الكبيرة ASCII مكافئة.
    ///
    /// يتم تعيين أحرف ASCII من 'a' إلى 'z' إلى 'A' إلى 'Z' ، لكن الأحرف غير ASCII لم تتغير.
    ///
    /// لتكبير القيمة في نفس المكان ، استخدم [`make_ascii_uppercase()`].
    ///
    /// لأحرف ASCII الكبيرة بالإضافة إلى الأحرف غير ASCII ، استخدم [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// عمل نسخة من القيمة بمكافئتها بأحرف صغيرة ASCII.
    ///
    /// يتم تعيين أحرف ASCII من 'A' إلى 'Z' إلى 'a' إلى 'z' ، لكن الأحرف غير ASCII لم تتغير.
    ///
    /// لتصغير القيمة في نفس المكان ، استخدم [`make_ascii_lowercase()`].
    ///
    /// لأحرف ASCII الصغيرة بالإضافة إلى الأحرف غير ASCII ، استخدم [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// للتحقق من تطابق قيمتين مع ASCII غير حساس لحالة الأحرف.
    ///
    /// يكافئ `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// يحول هذا النوع إلى ما يعادله بأحرف كبيرة ASCII في المكان.
    ///
    /// يتم تعيين أحرف ASCII من 'a' إلى 'z' إلى 'A' إلى 'Z' ، لكن الأحرف غير ASCII لم تتغير.
    ///
    /// لإرجاع قيمة كبيرة جديدة بدون تعديل القيمة الحالية ، استخدم [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// يحول هذا النوع إلى ما يعادله بأحرف صغيرة ASCII في المكان.
    ///
    /// يتم تعيين أحرف ASCII من 'A' إلى 'Z' إلى 'a' إلى 'z' ، لكن الأحرف غير ASCII لم تتغير.
    ///
    /// لإرجاع قيمة صغيرة جديدة بدون تعديل القيمة الحالية ، استخدم [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// للتحقق مما إذا كانت القيمة حرف أبجدي ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' أو
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// للتحقق مما إذا كانت القيمة أحرف ASCII كبيرة:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// للتحقق مما إذا كانت القيمة حرفًا صغيرًا من نوع ASCII:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// للتحقق مما إذا كانت القيمة حرفًا أبجديًا رقميًا ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' أو
    /// - U + 0061 'a' ..=U + 007A 'z' أو
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// للتحقق مما إذا كانت القيمة عبارة عن رقم عشري ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// للتحقق مما إذا كانت القيمة عبارة عن رقم سداسي عشري ASCII:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9' أو
    /// - U + 0041 'A' ..=U + 0046 'F' أو
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// للتحقق مما إذا كانت القيمة حرف ترقيم ASCII:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /` أو
    /// - U + 003A ..=U + 0040 `: ; < = > ? @` أو
    /// - U + 005B ..=U + 0060 `[\] ^ _` `` ، أو
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// للتحقق مما إذا كانت القيمة حرف رسومي ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// للتحقق مما إذا كانت القيمة عبارة عن حرف مسافة بيضاء ASCII:
    /// U + 0020 SPACE أو U + 0009 HORIZONTAL TAB أو U + 000A LINE FEED أو U + 000C FORM FEED أو U + 000D CARRIAGE RETURN.
    ///
    /// يستخدم Rust [definition of ASCII whitespace][infra-aw] الخاص بـ WhatWG Infra Standard.هناك العديد من التعريفات الأخرى المستخدمة على نطاق واسع.
    /// على سبيل المثال ، يتضمن [the POSIX locale][pct] U + 000B VERTICAL TAB بالإضافة إلى جميع الأحرف المذكورة أعلاه ، ولكن-من نفس المواصفات تمامًا-[القاعدة الافتراضية لـ "field splitting" في Bourne shell][bfs] تعتبر *فقط* SPACE و HORIZONTAL TAB و LINE FEED كمسافة بيضاء.
    ///
    ///
    /// إذا كنت تكتب برنامجًا سيعالج تنسيق ملف موجود ، فتحقق من تعريف هذا التنسيق للمسافة البيضاء قبل استخدام هذه الوظيفة.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// للتحقق مما إذا كانت القيمة هي حرف تحكم ASCII:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR ، أو U + 007F DELETE.
    /// لاحظ أن معظم أحرف المسافات البيضاء ASCII هي أحرف تحكم ، لكن المسافة ليست كذلك.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// ترميز قيمة u32 خام كـ UTF-8 في المخزن المؤقت للبايت المتوفر ، ثم تُرجع الشريحة الفرعية للمخزن المؤقت الذي يحتوي على الحرف المشفر.
///
///
/// على عكس `char::encode_utf8` ، تتعامل هذه الطريقة أيضًا مع نقاط الرموز في النطاق البديل.
/// (إنشاء `char` في النطاق البديل هو UB.) والنتيجة هي [generalized UTF-8] صالحة ولكنها ليست UTF-8 صالحة.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics إذا لم يكن المخزن المؤقت كبيرًا بدرجة كافية.
/// مخزن مؤقت بطول أربعة كبير بما يكفي لترميز أي `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// يقوم بتشفير قيمة u32 خام كـ UTF-16 في المخزن المؤقت `u16` المتوفر ، ثم يقوم بإرجاع الشريحة الفرعية للمخزن المؤقت الذي يحتوي على الحرف المشفر.
///
///
/// على عكس `char::encode_utf16` ، تتعامل هذه الطريقة أيضًا مع نقاط الرموز في النطاق البديل.
/// (إنشاء `char` في النطاق البديل هو UB.)
///
/// # Panics
///
/// Panics إذا لم يكن المخزن المؤقت كبيرًا بدرجة كافية.
/// مخزن مؤقت بطول 2 كبير بما يكفي لترميز أي `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // الأمان: يتحقق كل ذراع مما إذا كان هناك ما يكفي من البتات للكتابة فيها
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // فشل BMP
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // الطائرات التكميلية تقتحم بدائل.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}