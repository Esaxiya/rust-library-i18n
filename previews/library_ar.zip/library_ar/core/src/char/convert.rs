//! تحويلات الشخصية.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// يحول `u32` إلى `char`.
///
/// لاحظ أن جميع [`char`] صالحة [`u32`] ويمكن تحويلها إلى واحدة بها
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// ومع ذلك ، فإن العكس ليس صحيحًا: ليست كل ملفات [`u32`] الصالحة صالحة [`char`].
/// `from_u32()` سيعيد `None` إذا لم يكن الإدخال قيمة صالحة لـ [`char`].
///
/// للحصول على إصدار غير آمن من هذه الوظيفة يتجاهل هذه الفحوصات ، راجع [`from_u32_unchecked`].
///
///
/// # Examples
///
/// الاستخدام الأساسي:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// إرجاع `None` عندما لا يكون الإدخال [`char`] صالحًا:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// يحول `u32` إلى `char` ، متجاهلاً الصلاحية.
///
/// لاحظ أن جميع [`char`] صالحة [`u32`] ويمكن تحويلها إلى واحدة بها
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// ومع ذلك ، فإن العكس ليس صحيحًا: ليست كل ملفات [`u32`] الصالحة صالحة [`char`].
/// `from_u32_unchecked()` سوف يتجاهل هذا ، ويلقي بشكل أعمى إلى [`char`] ، مما قد يؤدي إلى إنشاء واحدة غير صالحة.
///
///
/// # Safety
///
/// هذه الوظيفة غير آمنة ، لأنها قد تنشئ قيم `char` غير صالحة.
///
/// للحصول على نسخة آمنة من هذه الوظيفة ، راجع وظيفة [`from_u32`].
///
/// # Examples
///
/// الاستخدام الأساسي:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // الأمان: يجب أن يضمن المتصل أن `i` قيمة حرف صالحة.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// يحول [`char`] إلى [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// يحول [`char`] إلى [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // يتم تحويل الحرف إلى قيمة نقطة الرمز ، ثم يتم تمديده بصفر إلى 64 بت.
        // انظر [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// يحول [`char`] إلى [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // يتم تحويل الحرف إلى قيمة نقطة الرمز ، ثم يتم تمديده بصفر إلى 128 بت.
        // انظر [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// تعيين بايت في 0x00 ..=0xFF إلى `char` الذي يكون لنقطة الرمز الخاصة به نفس القيمة ، في U + 0000 ..=U + 00FF.
///
/// تم تصميم Unicode بحيث يقوم هذا بفك تشفير البايت بشكل فعال مع ترميز الأحرف الذي تسميه IANA ISO-8859-1.
/// يتوافق هذا الترميز مع ASCII.
///
/// لاحظ أن هذا يختلف عن ISO/IEC 8859-1 الملقب
/// ISO 8859-1 (بواصلة واحدة أقل) ، مما يترك بعض قيم البايت التي لم يتم تعيينها لأي حرف في "blanks".
/// تقوم ISO-8859-1 (IANA one) بتعيينها إلى رموز التحكم C0 و C1.
///
/// لاحظ أن هذا *أيضًا* يختلف عن Windows-1252 المعروف أيضًا باسم
/// صفحة الرموز 1252 ، وهي مجموعة شاملة ISO/IEC 8859-1 تقوم بتعيين بعض الفراغات (وليس كلها!) إلى علامات الترقيم والأحرف اللاتينية المختلفة.
///
/// لمزيد من الخلط بين الأشياء ، فإن [on the Web](https://encoding.spec.whatwg.org/) `ascii` و `iso-8859-1` و `windows-1252` كلها أسماء مستعارة لمجموعة شاملة من Windows-1252 تملأ الفراغات المتبقية برموز التحكم C0 و C1 المقابلة.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// يحول [`u8`] إلى [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// خطأ يمكن إرجاعه عند تحليل حرف.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // الأمان: تم التحقق من أنها قيمة Unicode قانونية
            Ok(unsafe { transmute(i) })
        }
    }
}

/// تم إرجاع نوع الخطأ عند فشل تحويل من u32 إلى حرف.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// تحويل رقم في الأصل المحدد إلى `char`.
///
/// يُطلق على 'radix' هنا أحيانًا اسم 'base'.
/// يشير الجذر المكون من اثنين إلى رقم ثنائي ، وجذر مكون من عشرة ، وكسر عشري ، وجذر مكون من ستة عشر ، سداسي عشري ، لإعطاء بعض القيم المشتركة.
///
/// يتم دعم الإشعاع التعسفي.
///
/// `from_digit()` سيعيد `None` إذا لم يكن الإدخال رقمًا في الجذر المحدد.
///
/// # Panics
///
/// Panics إذا أعطيت جذرًا أكبر من 36.
///
/// # Examples
///
/// الاستخدام الأساسي:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // العدد العشري 11 هو رقم واحد في الأساس 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// إرجاع `None` عندما لا يكون الإدخال رقمًا:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// اجتياز جذع كبير ، مما تسبب في ظهور panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}