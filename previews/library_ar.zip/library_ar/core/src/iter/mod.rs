//! التكرار الخارجي المركب.
//!
//! إذا وجدت نفسك مع مجموعة من نوع ما ، وتحتاج إلى إجراء عملية على عناصر المجموعة المذكورة ، فسوف تصادف بسرعة 'iterators'.
//! تُستخدم التكرارات بكثرة في كود Rust الاصطلاحي ، لذا يجدر التعرف عليها.
//!
//! قبل الشرح أكثر ، دعنا نتحدث عن كيفية تنظيم هذه الوحدة:
//!
//! # Organization
//!
//! يتم تنظيم هذه الوحدة إلى حد كبير حسب النوع:
//!
//! * [Traits] هي الجزء الأساسي: تحدد traits نوع التكرارات الموجودة وما يمكنك فعله بها.تستحق أساليب traits هذه وضع بعض وقت الدراسة الإضافي فيها.
//! * [Functions] تقدم بعض الطرق المفيدة لإنشاء بعض التكرارات الأساسية.
//! * [Structs] غالبًا ما تكون أنواع الإرجاع للطرق المختلفة على traits لهذه الوحدة.ستحتاج عادةً إلى إلقاء نظرة على الطريقة التي تنشئ `struct` ، بدلاً من `struct` نفسها.
//! لمزيد من التفاصيل حول السبب ، راجع "[تنفيذ التكرار](#Implementation-iterator)".
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! هذا هو!دعنا نتعمق في التكرارات.
//!
//! # Iterator
//!
//! قلب وروح هذه الوحدة هو [`Iterator`] trait.يبدو جوهر [`Iterator`] كما يلي:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! يحتوي المكرر على طريقة ، [`next`] ، والتي عند استدعائها ، تُرجع [`الخيار`]`<Item>".
//! [`next`] سيعيد [`Some(Item)`] طالما أن هناك عناصر ، وبمجرد استنفادها جميعًا ، ستعيد `None` للإشارة إلى انتهاء التكرار.
//! قد يختار المتكررون الفرديون استئناف التكرار ، وبالتالي فإن استدعاء [`next`] مرة أخرى قد يبدأ أو لا يبدأ في النهاية في إرجاع [`Some(Item)`] مرة أخرى في مرحلة ما (على سبيل المثال ، انظر [`TryIter`]).
//!
//!
//! يتضمن التعريف الكامل لـ [`Iterator`] عددًا من الطرق الأخرى أيضًا ، لكنها طرق افتراضية ، مبنية على أعلى [`next`] ، وبالتالي تحصل عليها مجانًا.
//!
//! التكرارات قابلة للتكوين أيضًا ، ومن الشائع ربطها معًا للقيام بأشكال أكثر تعقيدًا من المعالجة.راجع قسم [Adapters](#adapters) أدناه للحصول على مزيد من التفاصيل.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # الأشكال الثلاثة للتكرار
//!
//! هناك ثلاث طرق شائعة يمكنها إنشاء مكررات من مجموعة:
//!
//! * `iter()`, الذي يتكرر أكثر من `&T`.
//! * `iter_mut()`, الذي يتكرر أكثر من `&mut T`.
//! * `into_iter()`, الذي يتكرر أكثر من `T`.
//!
//! أشياء مختلفة في المكتبة القياسية قد تنفذ واحدًا أو أكثر من الثلاثة ، عند الاقتضاء.
//!
//! # تنفيذ التكرار
//!
//! يتضمن إنشاء مكرر خاص بك خطوتين: إنشاء `struct` للاحتفاظ بحالة المكرر ، ثم تنفيذ [`Iterator`] لذلك `struct`.
//! هذا هو سبب وجود العديد من "الهيكل" في هذه الوحدة: يوجد واحد لكل مكرر ومحول مكرر.
//!
//! لنصنع مكررًا باسم `Counter` يتم احتسابه من `1` إلى `5`:
//!
//! ```
//! // أولاً ، الهيكل:
//!
//! /// مكرر يعد من واحد إلى خمسة
//! struct Counter {
//!     count: usize,
//! }
//!
//! // نريد أن يبدأ العد من واحد ، لذلك دعونا نضيف طريقة new() للمساعدة.
//! // هذا ليس ضروريًا تمامًا ، ولكنه مناسب.
//! // لاحظ أننا نبدأ `count` عند الصفر ، وسنرى السبب في تنفيذ `next()`'s أدناه.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // بعد ذلك ، نطبق `Iterator` لـ `Counter` الخاص بنا:
//!
//! impl Iterator for Counter {
//!     // سنحسب مع usize
//!     type Item = usize;
//!
//!     // next() هي الطريقة الوحيدة المطلوبة
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // زيادة العد لدينا.هذا هو السبب في أننا بدأنا من الصفر.
//!         self.count += 1;
//!
//!         // تحقق لمعرفة ما إذا كنا قد انتهينا من العد أم لا.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // والآن يمكننا استخدامه!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! استدعاء [`next`] بهذه الطريقة يصبح متكررًا.يحتوي Rust على بنية يمكنها استدعاء [`next`] على مكررك ، حتى تصل إلى `None`.دعنا ننتقل إلى ما يلي.
//!
//! لاحظ أيضًا أن `Iterator` يوفر تطبيقًا افتراضيًا لطرق مثل `nth` و `fold` التي تستدعي `next` داخليًا.
//! ومع ذلك ، من الممكن أيضًا كتابة تنفيذ مخصص لطرق مثل `nth` و `fold` إذا كان بإمكان المكرر حسابها بشكل أكثر كفاءة دون استدعاء `next`.
//!
//! # `for` الحلقات و `IntoIterator`
//!
//! إن بنية الحلقة `for` الخاصة بـ Rust هي في الواقع سكر للمكررات.فيما يلي مثال أساسي على `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! سيؤدي هذا إلى طباعة الأرقام من واحد إلى خمسة ، كل على سطر خاص به.لكن ستلاحظ شيئًا هنا: لم نطلب مطلقًا أي شيء على vector لإنتاج مكرر.ما يعطي؟
//!
//! يوجد trait في المكتبة القياسية لتحويل شيء ما إلى مكرر: [`IntoIterator`].
//! يحتوي trait على طريقة واحدة ، [`into_iter`] ، والتي تحول الشيء الذي ينفذ [`IntoIterator`] إلى مكرر.
//! دعنا نلقي نظرة على حلقة `for` مرة أخرى ، وما يحولها المترجم إلى:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust يزيل هذا السكر إلى:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! أولاً ، نسمي `into_iter()` على القيمة.بعد ذلك ، نتطابق مع المكرر الذي يعود ، واستدعاء [`next`] مرارًا وتكرارًا حتى نرى `None`.
//! في هذه المرحلة ، خرجنا `break` من الحلقة ، وقد انتهينا من التكرار.
//!
//! يوجد جزء أكثر دقة هنا: تحتوي المكتبة القياسية على تطبيق مثير للاهتمام لـ [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! بعبارة أخرى ، كل ["التكرار"] يطبق [`IntoIterator`] ، بمجرد إرجاع أنفسهم.هذا يعني شيئين:
//!
//! 1. إذا كنت تكتب [`Iterator`] ، فيمكنك استخدامه مع حلقة `for`.
//! 2. إذا كنت تقوم بإنشاء مجموعة ، فإن تنفيذ [`IntoIterator`] لها سيسمح باستخدام مجموعتك مع حلقة `for`.
//!
//! # التكرار بالإشارة
//!
//! نظرًا لأن [`into_iter()`] يأخذ `self` من حيث القيمة ، فإن استخدام حلقة `for` للتكرار على مجموعة يستهلك هذه المجموعة.في كثير من الأحيان ، قد ترغب في التكرار على مجموعة دون استهلاكها.
//! تقدم العديد من المجموعات طرقًا توفر مكررات على المراجع ، تسمى تقليديًا `iter()` و `iter_mut()` على التوالي:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` لا تزال مملوكة لهذه الوظيفة.
//! ```
//!
//! إذا كان نوع المجموعة `C` يوفر `iter()` ، فإنه عادةً ما يقوم أيضًا بتنفيذ `IntoIterator` لـ `&C` ، مع تطبيق يستدعي `iter()` فقط.
//! وبالمثل ، فإن المجموعة `C` التي توفر `iter_mut()` تنفذ بشكل عام `IntoIterator` لـ `&mut C` من خلال التفويض إلى `iter_mut()`.هذا يتيح اختصارًا مناسبًا:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // نفس `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // نفس `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! بينما تقدم العديد من المجموعات `iter()` ، لا تقدم جميعها `iter_mut()`.
//! على سبيل المثال ، قد يؤدي تغيير مفاتيح [`HashSet<T>`] أو [`HashMap<K, V>`] إلى وضع المجموعة في حالة غير متسقة إذا تغيرت تجزئة المفتاح ، لذلك لا تقدم هذه المجموعات سوى `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! غالبًا ما تسمى الوظائف التي تأخذ [`Iterator`] وتعود [`Iterator`] آخر بـ "محولات التكرار" ، لأنها شكل من أشكال "المحول"
//! pattern'.
//!
//! تتضمن محولات التكرار الشائعة [`map`] و [`take`] و [`filter`].
//! لمزيد من المعلومات ، راجع وثائقهم.
//!
//! إذا كان محول المكرر panics ، فسيكون المكرر في حالة غير محددة (لكن الذاكرة آمنة).
//! هذه الحالة أيضًا غير مضمونة للبقاء كما هي عبر إصدارات Rust ، لذلك يجب تجنب الاعتماد على القيم الدقيقة التي أرجعها مكرر أصاب بالذعر.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! التكرارات (والمكرر [adapters](#adapters))*كسالى*. هذا يعني أن مجرد إنشاء مكرر لا يصل إلى _do_ كثيرًا. لا شيء يحدث حقًا حتى تتصل بـ [`next`].
//! يكون هذا أحيانًا مصدر ارتباك عند إنشاء مكرر فقط بسبب آثاره الجانبية.
//! على سبيل المثال ، تستدعي طريقة [`map`] إغلاقًا لكل عنصر تكرره:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! لن يؤدي هذا إلى طباعة أي قيم ، لأننا أنشأنا فقط مكررًا ، بدلاً من استخدامه.سيحذرنا المترجم من هذا النوع من السلوك:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! الطريقة الاصطلاحية لكتابة [`map`] لتأثيراتها الجانبية هي استخدام حلقة `for` أو استدعاء طريقة [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! هناك طريقة شائعة أخرى لتقييم المكرر وهي استخدام طريقة [`collect`] لإنتاج مجموعة جديدة.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! التكرارات لا يجب أن تكون محدودة.كمثال ، النطاق المفتوح هو مكرر لانهائي:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! من الشائع استخدام محول مكرر [`take`] لتحويل مكرر لانهائي إلى مكرر محدود:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! سيؤدي ذلك إلى طباعة الأرقام من `0` إلى `4` ، كل على خط خاص به.
//!
//! ضع في اعتبارك أن الأساليب على التكرارات اللانهائية ، حتى تلك التي يمكن تحديد نتيجة لها رياضيًا في وقت محدد ، قد لا تنتهي.
//! على وجه التحديد ، من المحتمل ألا تعود طرق مثل [`min`] ، والتي تتطلب في الحالة العامة اجتياز كل عنصر في المكرر ، بنجاح لأي مكررات لا نهائية.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // أوه لا!حلقة لا نهائية!
//! // `ones.min()` يتسبب في حلقة لا نهائية ، لذلك لن نصل إلى هذه النقطة!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;