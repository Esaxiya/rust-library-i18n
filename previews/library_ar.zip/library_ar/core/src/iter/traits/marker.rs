/// مكرر يستمر دائمًا في إنتاج `None` عند استنفاده.
///
/// الاتصال التالي على مكرر مدمج أعاد `None` مرة واحدة مضمون لإرجاع [`None`] مرة أخرى.
/// يجب تنفيذ trait بواسطة جميع التكرارات التي تتصرف بهذه الطريقة لأنها تسمح بتحسين [`Iterator::fuse()`].
///
///
/// Note: بشكل عام ، يجب ألا تستخدم `FusedIterator` في الحدود العامة إذا كنت بحاجة إلى مكرر مدمج.
/// بدلاً من ذلك ، يجب عليك فقط الاتصال بـ [`Iterator::fuse()`] على المكرر.
/// إذا كان المكرر مدمجًا بالفعل ، فسيكون غلاف [`Fuse`] الإضافي بدون تشغيل بدون أي عقوبة على الأداء.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// مكرر يبلغ عن طول دقيق باستخدام size_hint.
///
/// يبلغ المكرر عن تلميح الحجم حيث يكون إما دقيقًا (الحد الأدنى يساوي الحد الأعلى) ، أو الحد الأعلى هو [`None`].
///
/// يجب أن يكون الحد الأعلى [`None`] فقط إذا كان طول المكرر الفعلي أكبر من [`usize::MAX`].
/// في هذه الحالة ، يجب أن يكون الحد الأدنى هو [`usize::MAX`] ، مما ينتج عنه [`Iterator::size_hint()`] من `(usize::MAX, None)`.
///
/// يجب أن ينتج المكرر بالضبط عدد العناصر التي أبلغ عنها أو يتباعد قبل الوصول إلى النهاية.
///
/// # Safety
///
/// يجب تنفيذ trait فقط عند التمسك بالعقد.
/// يجب على مستهلكي trait فحص الحد الأعلى لـ [`Iterator::size_hint()`]’s.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// مكرر أنه عند إعطاء عنصر ما ، فسيكون قد أخذ عنصرًا واحدًا على الأقل من [`SourceIter`] الأساسي الخاص به.
///
/// استدعاء أي طريقة تعمل على تقدم المكرر ، على سبيل المثال
/// [`next()`] أو [`try_fold()`] ، يضمن أنه لكل خطوة على الأقل قيمة واحدة من المصدر الأساسي للمكرر قد تم نقلها ويمكن إدراج نتيجة سلسلة التكرار في مكانها ، على افتراض أن القيود الهيكلية للمصدر تسمح بهذا الإدراج.
///
/// بعبارة أخرى ، يشير trait هذا إلى أنه يمكن تجميع خط أنابيب مكرر في مكانه.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}