/// مكرر يعرف طوله بالضبط.
///
/// كثير من [المكررون] لا يعرفون عدد المرات التي سيتكررون فيها ، لكن البعض يعرف.
/// إذا كان المكرر يعرف عدد المرات التي يمكنه فيها التكرار ، فقد يكون توفير الوصول إلى هذه المعلومات مفيدًا.
/// على سبيل المثال ، إذا كنت تريد التكرار للخلف ، فإن البداية الجيدة هي معرفة مكان النهاية.
///
/// عند تنفيذ `ExactSizeIterator` ، يجب عليك أيضًا تنفيذ [`Iterator`].
/// عند القيام بذلك ، يجب أن يؤدي تنفيذ [`Iterator::size_hint`]* * إلى إرجاع الحجم الدقيق للمكرر.
///
/// طريقة [`len`] لها تطبيق افتراضي ، لذلك لا يجب عليك عادة تنفيذها.
/// ومع ذلك ، قد تكون قادرًا على توفير تنفيذ أكثر فاعلية من الافتراضي ، لذا فإن تجاوزه في هذه الحالة أمر منطقي.
///
///
/// لاحظ أن trait هو trait آمن وعلى هذا النحو *لا* و * لا يضمن أن الطول الذي تم إرجاعه صحيح.
/// هذا يعني أن كود `unsafe`**يجب ألا** يعتمد على صحة [`Iterator::size_hint`].
/// يوفر [`TrustedLen`](super::marker::TrustedLen) trait غير المستقر وغير الآمن هذا الضمان الإضافي.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// الاستخدام الأساسي:
///
/// ```
/// // النطاق المحدود يعرف بالضبط عدد المرات التي سيتكرر فيها
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// في [module-level docs] ، قمنا بتطبيق [`Iterator`] ، `Counter`.
/// دعنا ننفذ `ExactSizeIterator` لذلك أيضًا:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // يمكننا بسهولة حساب العدد المتبقي من التكرارات.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // والآن يمكننا استخدامه!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// إرجاع الطول الدقيق للمكرر.
    ///
    /// يضمن التنفيذ أن المكرر سيعيد `len()` بالضبط أكثر من قيمة [`Some(T)`] ، قبل إرجاع [`None`].
    ///
    /// هذه الطريقة لها تطبيق افتراضي ، لذلك لا يجب عليك عادةً تنفيذها بشكل مباشر.
    /// ومع ذلك ، إذا كان بإمكانك توفير تنفيذ أكثر كفاءة ، فيمكنك القيام بذلك.
    /// راجع مستندات [trait-level] للحصول على مثال.
    ///
    /// هذه الوظيفة لها نفس ضمانات السلامة مثل وظيفة [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// // النطاق المحدود يعرف بالضبط عدد المرات التي سيتكرر فيها
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: هذا التأكيد دفاعي بشكل مفرط ، لكنه يتحقق من الثابت
        // بضمان trait.
        // إذا كانت trait هي rust-internal ، فيمكننا استخدام debug_assert !؛assert_eq!سيتحقق من جميع تطبيقات مستخدم Rust أيضًا.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// تُرجع `true` إذا كان المكرر فارغًا.
    ///
    /// هذه الطريقة لها تطبيق افتراضي باستخدام [`ExactSizeIterator::len()`] ، لذلك لا تحتاج إلى تنفيذها بنفسك.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}