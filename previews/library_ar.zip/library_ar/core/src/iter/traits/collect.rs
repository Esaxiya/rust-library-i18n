/// التحويل من [`Iterator`].
///
/// من خلال تنفيذ `FromIterator` لنوع ما ، فإنك تحدد كيفية إنشائه من مكرر.
/// هذا شائع للأنواع التي تصف مجموعة من نوع ما.
///
/// [`FromIterator::from_iter()`] نادرًا ما يتم استدعاؤه صراحة ، ويتم استخدامه بدلاً من ذلك من خلال طريقة [`Iterator::collect()`]
///
/// راجع وثائق [`Iterator::collect()`]'s لمزيد من الأمثلة.
///
/// أنظر أيضا: [`IntoIterator`].
///
/// # Examples
///
/// الاستخدام الأساسي:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// استخدام [`Iterator::collect()`] لاستخدام `FromIterator` ضمنيًا:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// تنفيذ `FromIterator` لنوعك:
///
/// ```
/// use std::iter::FromIterator;
///
/// // مجموعة عينات ، هذا مجرد غلاف فوق Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // دعنا نعطيها بعض الطرق حتى نتمكن من إنشاء واحدة وإضافة أشياء إليها.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // وسننفذ FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // الآن يمكننا إنشاء مكرر جديد ...
/// let iter = (0..5).into_iter();
///
/// // ... واصنع MyCollection منه
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // جمع الأعمال أيضا!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// ينشئ قيمة من مكرر.
    ///
    /// شاهد [module-level documentation] للمزيد.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// التحويل إلى [`Iterator`].
///
/// من خلال تنفيذ `IntoIterator` لنوع ما ، فإنك تحدد كيفية تحويله إلى مكرر.
/// هذا شائع للأنواع التي تصف مجموعة من نوع ما.
///
/// إحدى فوائد تنفيذ `IntoIterator` هي أن النوع الخاص بك سوف [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// أنظر أيضا: [`FromIterator`].
///
/// # Examples
///
/// الاستخدام الأساسي:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// تنفيذ `IntoIterator` لنوعك:
///
/// ```
/// // مجموعة عينات ، هذا مجرد غلاف فوق Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // دعنا نعطيها بعض الطرق حتى نتمكن من إنشاء واحدة وإضافة أشياء إليها.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // وسنقوم بتطبيق IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // الآن يمكننا صنع مجموعة جديدة ...
/// let mut c = MyCollection::new();
///
/// // ... أضف بعض الأشياء إليه ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // .. ثم حوله إلى مكرر:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// من الشائع استخدام `IntoIterator` باعتباره trait bound.يسمح هذا لنوع مجموعة الإدخال بالتغيير ، طالما أنه لا يزال مكررًا.
/// يمكن تحديد حدود إضافية عن طريق التقييد على
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// نوع العناصر التي يتم تكرارها.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// أي نوع من المكرر سنحول هذا إليه؟
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// ينشئ مكررًا من قيمة.
    ///
    /// شاهد [module-level documentation] للمزيد.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// قم بتوسيع مجموعة بمحتويات مكرر.
///
/// ينتج التكرارات سلسلة من القيم ، ويمكن أيضًا اعتبار المجموعات على أنها سلسلة من القيم.
/// يسد `Extend` trait هذه الفجوة ، مما يسمح لك بتوسيع مجموعة من خلال تضمين محتويات هذا المكرر.
/// عند توسيع مجموعة بمفتاح موجود بالفعل ، يتم تحديث هذا الإدخال أو ، في حالة المجموعات التي تسمح بإدخالات متعددة بمفاتيح متساوية ، يتم إدخال هذا الإدخال.
///
///
/// # Examples
///
/// الاستخدام الأساسي:
///
/// ```
/// // يمكنك تمديد سلسلة ببعض الأحرف:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// تنفيذ `Extend`:
///
/// ```
/// // مجموعة عينات ، هذا مجرد غلاف فوق Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // دعنا نعطيها بعض الطرق حتى نتمكن من إنشاء واحدة وإضافة أشياء إليها.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // نظرًا لأن MyCollection يحتوي على قائمة من i32s ، فإننا نطبق Extend لـ i32
/// impl Extend<i32> for MyCollection {
///
///     // هذا أبسط قليلاً مع توقيع النوع الملموس: يمكننا أن نطلق عليه تمديد على أي شيء يمكن تحويله إلى مكرر يعطينا i32s.
///     // لأننا بحاجة إلى i32s لوضعها في MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // التنفيذ بسيط للغاية: قم بالمرور عبر المكرر ، و add() لكل عنصر لأنفسنا.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // دعنا نوسع مجموعتنا بثلاثة أرقام أخرى
/// c.extend(vec![1, 2, 3]);
///
/// // أضفنا هذه العناصر في النهاية
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// يوسع مجموعة بمحتويات مكرر.
    ///
    /// نظرًا لأن هذه هي الطريقة الوحيدة المطلوبة لهذا trait ، تحتوي مستندات [trait-level] على مزيد من التفاصيل.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// // يمكنك تمديد سلسلة ببعض الأحرف:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// يوسع مجموعة تحتوي على عنصر واحد بالضبط.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// سعة الاحتياطيات في مجموعة لعدد معين من العناصر الإضافية.
    ///
    /// تطبيق الافتراضي لا يفعل شيئا.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}