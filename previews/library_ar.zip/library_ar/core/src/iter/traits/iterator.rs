// ignore-tidy-filelength يتكون هذا الملف بشكل حصري تقريبًا من تعريف `Iterator`.
// لا يمكننا تقسيم ذلك إلى عدة ملفات.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// واجهة للتعامل مع التكرارات.
///
/// هذا هو المكرر الرئيسي trait.
/// لمزيد من المعلومات حول مفهوم التكرارات بشكل عام ، يرجى الاطلاع على [module-level documentation].
/// على وجه الخصوص ، قد ترغب في معرفة كيفية [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// نوع العناصر التي يتم تكرارها.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// تقدم المكرر وإرجاع القيمة التالية.
    ///
    /// تُرجع [`None`] عند انتهاء التكرار.
    /// قد تختار تطبيقات المكرر الفردية استئناف التكرار ، وبالتالي فإن استدعاء `next()` مرة أخرى قد يبدأ أو لا يبدأ في النهاية في إرجاع [`Some(Item)`] مرة أخرى في مرحلة ما.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // ترجع استدعاء next() القيمة التالية ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... ثم لا شيء بمجرد أن ينتهي.
    /// assert_eq!(None, iter.next());
    ///
    /// // المزيد من المكالمات قد تعيد أو لا تعود `None`.هنا ، سيفعلون ذلك دائمًا.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// إرجاع حدود الطول المتبقي للمكرر.
    ///
    /// على وجه التحديد ، تُرجع `size_hint()` مجموعة حيث يكون العنصر الأول هو الحد الأدنى والعنصر الثاني هو الحد الأعلى.
    ///
    /// النصف الثاني من المجموعة التي تم إرجاعها هو [`خيار`]`<`[`usize`] `>`.
    /// يعني [`None`] هنا إما أنه لا يوجد حد أعلى معروف ، أو أن الحد الأعلى أكبر من [`usize`].
    ///
    /// # ملاحظات التنفيذ
    ///
    /// لا يتم فرض أن يؤدي تنفيذ المكرر إلى العدد المعلن من العناصر.قد ينتج عن مكرر عربات التي تجرها الدواب أقل من الحد الأدنى أو أكثر من الحد الأعلى للعناصر.
    ///
    /// `size_hint()` الغرض الأساسي منه هو استخدامه للتحسينات مثل حجز مساحة لعناصر المكرر ، ولكن يجب عدم الوثوق به على سبيل المثال ، حذف عمليات التحقق من الحدود في التعليمات البرمجية غير الآمنة.
    /// يجب ألا يؤدي التنفيذ غير الصحيح لـ `size_hint()` إلى انتهاكات أمان الذاكرة.
    ///
    /// ومع ذلك ، يجب أن يوفر التطبيق تقديرًا صحيحًا ، وإلا فسيكون انتهاكًا لبروتوكول trait.
    ///
    /// يُرجع التنفيذ الافتراضي `(0،` [`بلا`]`)`وهو الصحيح لأي مكرر.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// مثال أكثر تعقيدًا:
    ///
    /// ```
    /// // الأعداد الزوجية من صفر إلى عشرة.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // يمكننا التكرار من صفر إلى عشر مرات.
    /// // مع العلم أن العدد خمسة بالضبط لن يكون ممكنًا بدون تنفيذ filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // دعنا نضيف خمسة أرقام أخرى باستخدام chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // الآن يتم زيادة كلا الحدين بمقدار خمسة
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// إرجاع `None` للحد الأعلى:
    ///
    /// ```
    /// // ليس للمكرر اللانهائي حد أعلى وحد أدنى ممكن
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// يستهلك المكرر ، ويحسب عدد التكرارات ويعيدها.
    ///
    /// ستستدعي هذه الطريقة [`next`] بشكل متكرر حتى تتم مصادفة [`None`] ، مع إعادة عدد المرات التي شاهدت فيها [`Some`].
    /// لاحظ أنه يجب استدعاء [`next`] مرة واحدة على الأقل حتى إذا لم يكن للمكرر أي عناصر.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # سلوك تجاوز
    ///
    /// لا تحمي هذه الطريقة من الفيضانات ، لذا فإن حساب عناصر مكرر يحتوي على أكثر من عناصر [`usize::MAX`] ينتج إما نتيجة خاطئة أو panics.
    ///
    /// إذا تم تمكين تأكيدات تصحيح الأخطاء ، يتم ضمان panic.
    ///
    /// # Panics
    ///
    /// قد تكون هذه الوظيفة panic إذا كان المكرر يحتوي على أكثر من عناصر [`usize::MAX`].
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// يستهلك المكرر ، ويعيد العنصر الأخير.
    ///
    /// ستقوم هذه الطريقة بتقييم المكرر حتى تقوم بإرجاع [`None`].
    /// أثناء القيام بذلك ، فإنه يتتبع العنصر الحالي.
    /// بعد إرجاع [`None`] ، سيعيد `last()` بعد ذلك العنصر الأخير الذي شاهده.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// تقدم المكرر بواسطة عناصر `n`.
    ///
    /// ستتخطى هذه الطريقة عناصر `n` بفارغ الصبر عن طريق استدعاء [`next`] حتى `n` مرة حتى يتم مواجهة [`None`].
    ///
    /// `advance_by(n)` سيعيد [`Ok(())`][Ok] إذا تقدم المكرر بنجاح بواسطة عناصر `n` ، أو [`Err(k)`][Err] إذا تمت مصادفة [`None`] ، حيث `k` هو عدد العناصر التي تقدم بها المكرر قبل نفاد العناصر (أي
    /// طول المكرر).
    /// لاحظ أن `k` دائمًا أقل من `n`.
    ///
    /// لا يستهلك استدعاء `advance_by(0)` أي عناصر ويعيد [`Ok(())`][Ok] دائمًا.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // تم تخطي `&4` فقط
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// لعرض العنصر `n` للمكرر.
    ///
    /// مثل معظم عمليات الفهرسة ، يبدأ العد من الصفر ، لذا فإن `nth(0)` تُرجع القيمة الأولى ، `nth(1)` الثانية ، وهكذا.
    ///
    /// لاحظ أنه سيتم استهلاك جميع العناصر السابقة ، بالإضافة إلى العنصر المرتجع ، من المكرر.
    /// هذا يعني أنه سيتم تجاهل العناصر السابقة ، وأيضًا أن استدعاء `nth(0)` عدة مرات على نفس المكرر سيعيد عناصر مختلفة.
    ///
    ///
    /// `nth()` سيعيد [`None`] إذا كان `n` أكبر من أو يساوي طول المكرر.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// لا يؤدي استدعاء `nth()` عدة مرات إلى إرجاع المكرر:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// إرجاع `None` إذا كان هناك أقل من `n + 1` من العناصر:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// ينشئ مكررًا يبدأ من نفس النقطة ، لكن يتنقل بالمقدار المحدد في كل تكرار.
    ///
    /// ملاحظة 1: سيتم دائمًا إرجاع العنصر الأول في المكرر ، بغض النظر عن الخطوة المحددة.
    ///
    /// ملاحظة 2: الوقت الذي يتم فيه سحب العناصر التي تم تجاهلها غير ثابت.
    /// `StepBy` يتصرف مثل التسلسل `next(), nth(step-1), nth(step-1),…` ، ولكنه أيضًا حر في التصرف مثل التسلسل
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// قد تتغير الطريقة المستخدمة لبعض التكرارات لأسباب تتعلق بالأداء.
    /// الطريقة الثانية ستقدم المكرر في وقت سابق وقد تستهلك المزيد من العناصر.
    ///
    /// `advance_n_and_return_first` يعادل:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// الطريقة سوف panic إذا كانت الخطوة المعطاة هي `0`.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// يأخذ مكررين وينشئ مكررًا جديدًا على كليهما بالتسلسل.
    ///
    /// `chain()` سيعيد مكررًا جديدًا والذي سيكرر أولاً القيم من المكرر الأول ثم فوق القيم من المكرر الثاني.
    ///
    /// بمعنى آخر ، يربط بين مكررين معًا في سلسلة.🔗
    ///
    /// [`once`] يستخدم بشكل شائع لتكييف قيمة واحدة في سلسلة من أنواع التكرار الأخرى.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// نظرًا لأن الوسيطة إلى `chain()` تستخدم [`IntoIterator`] ، يمكننا تمرير أي شيء يمكن تحويله إلى [`Iterator`] ، وليس مجرد [`Iterator`] نفسه.
    /// على سبيل المثال ، الشرائح (`&[T]`) تنفذ [`IntoIterator`] ، وبالتالي يمكن تمريرها إلى `chain()` مباشرة:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// إذا كنت تعمل مع Windows API ، فقد ترغب في تحويل [`OsStr`] إلى `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// "Zips up" مكرران في مكرر واحد من الأزواج.
    ///
    /// `zip()` يُرجع مكررًا جديدًا يتكرر على مكررين آخرين ، ويعيد مجموعة حيث يأتي العنصر الأول من مكرر الأول ، ويأتي العنصر الثاني من مكرر ثاني.
    ///
    ///
    /// بمعنى آخر ، يقوم بضغط مكررين معًا ، في واحد.
    ///
    /// إذا قام أي مكرر بإرجاع [`None`] ، فسيعيد [`next`] من مكرر مضغوط [`None`].
    /// إذا أعاد المكرر الأول [`None`] ، فإن `zip` سوف تقصر الدائرة ولن يتم استدعاء `next` في المكرر الثاني.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// نظرًا لأن الوسيطة إلى `zip()` تستخدم [`IntoIterator`] ، يمكننا تمرير أي شيء يمكن تحويله إلى [`Iterator`] ، وليس مجرد [`Iterator`] نفسه.
    /// على سبيل المثال ، الشرائح (`&[T]`) تنفذ [`IntoIterator`] ، وبالتالي يمكن تمريرها إلى `zip()` مباشرة:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` غالبًا ما يتم استخدامه لضغط مكرر لانهائي إلى مكرر محدود.
    /// يعمل هذا لأن المكرر المحدود سيعيد [`None`] في النهاية ، وينهي السحاب.يمكن أن يبدو الضغط باستخدام `(0..)` كثيرًا مثل [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// ينشئ مكررًا جديدًا يضع نسخة من `separator` بين العناصر المتجاورة للمكرر الأصلي.
    ///
    /// في حالة عدم قيام `separator` بتنفيذ [`Clone`] أو يحتاج إلى حساب في كل مرة ، استخدم [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // العنصر الأول من `a`.
    /// assert_eq!(a.next(), Some(&100)); // الفاصل.
    /// assert_eq!(a.next(), Some(&1));   // العنصر التالي من `a`.
    /// assert_eq!(a.next(), Some(&100)); // الفاصل.
    /// assert_eq!(a.next(), Some(&2));   // العنصر الأخير من `a`.
    /// assert_eq!(a.next(), None);       // تم الانتهاء من المكرر.
    /// ```
    ///
    /// `intersperse` يمكن أن يكون مفيدًا جدًا لضم عناصر المكرر باستخدام عنصر مشترك:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// ينشئ مكررًا جديدًا يضع عنصرًا تم إنشاؤه بواسطة `separator` بين العناصر المجاورة للمكرر الأصلي.
    ///
    /// سيتم استدعاء الإغلاق مرة واحدة بالضبط في كل مرة يتم فيها وضع عنصر بين عنصرين متجاورين من المكرر الأساسي ؛
    /// على وجه التحديد ، لا يتم استدعاء الإغلاق إذا كان المكرر الأساسي ينتج أقل من عنصرين وبعد إنتاج العنصر الأخير.
    ///
    ///
    /// إذا كان عنصر المكرر يقوم بتنفيذ [`Clone`] ، فقد يكون من الأسهل استخدام [`intersperse`].
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // العنصر الأول من `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // الفاصل.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // العنصر التالي من `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // الفاصل.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // العنصر الأخير من `v`.
    /// assert_eq!(it.next(), None);               // تم الانتهاء من المكرر.
    /// ```
    ///
    /// `intersperse_with` يمكن استخدامها في المواقف التي يلزم فيها حساب الفاصل:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // يستعير الإغلاق بشكل متبادل سياقه لإنشاء عنصر.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// يأخذ إغلاقًا وينشئ مكررًا يستدعي هذا الإغلاق على كل عنصر.
    ///
    /// `map()` يحول مكررًا إلى آخر ، عن طريق حجته:
    /// شيء يطبق [`FnMut`].ينتج مكررًا جديدًا يستدعي هذا الإغلاق على كل عنصر من عناصر التكرار الأصلي.
    ///
    /// إذا كنت جيدًا في التفكير في الأنواع ، فيمكنك التفكير في `map()` على النحو التالي:
    /// إذا كان لديك مكرر يمنحك عناصر من نوع `A` ، وتريد مكررًا من نوع آخر `B` ، يمكنك استخدام `map()` ، ويمرر إغلاقًا يأخذ `A` ويعيد `B`.
    ///
    ///
    /// `map()` يشبه من الناحية المفاهيمية حلقة [`for`].ومع ذلك ، نظرًا لأن `map()` كسول ، فمن الأفضل استخدامه عندما تعمل بالفعل مع مكررات أخرى.
    /// إذا كنت تفعل نوعًا من الحلقات للحصول على تأثير جانبي ، فيُعتبر استخدام [`for`] أكثر من `map()` اصطلاحيًا.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// إذا كنت تقوم ببعض الآثار الجانبية ، تفضل [`for`] على `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // لا تفعل هذا:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // لن يتم تنفيذه ، لأنه كسول.سوف يحذرك Rust من هذا.
    ///
    /// // بدلاً من ذلك ، استخدم لـ:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// يستدعي إغلاقًا لكل عنصر من عناصر المكرر.
    ///
    /// هذا يعادل استخدام حلقة [`for`] على المكرر ، على الرغم من أن `break` و `continue` غير ممكنين من الإغلاق.
    /// من الاصطلاح عمومًا استخدام حلقة `for` ، ولكن قد يكون `for_each` أكثر وضوحًا عند معالجة العناصر في نهاية سلاسل التكرار الأطول.
    ///
    /// في بعض الحالات ، قد يكون `for_each` أسرع أيضًا من الحلقة ، لأنه سيستخدم التكرار الداخلي على محولات مثل `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// لمثل هذا المثال الصغير ، قد تكون حلقة `for` أكثر نظافة ، ولكن قد يكون من الأفضل `for_each` للحفاظ على نمط وظيفي مع مكررات أطول:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// ينشئ مكررًا يستخدم الإغلاق لتحديد ما إذا كان يجب إنتاج عنصر.
    ///
    /// بالنظر إلى عنصر ، يجب أن يعيد الإغلاق `true` أو `false`.سينتج عن المكرر المرتجع فقط العناصر التي يعود الإغلاق صحيحًا لها.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// نظرًا لأن الإغلاق الذي تم تمريره إلى `filter()` يأخذ مرجعًا ، ويتكرر العديد من التكرارات على المراجع ، فإن هذا يؤدي إلى موقف محتمل محتمل ، حيث يكون نوع الإغلاق مرجعًا مزدوجًا:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // تحتاج اثنين * ق!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// من الشائع بدلاً من ذلك استخدام التدمير في الحجة لتجريد واحد:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // كلاهما و *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// او كلاهما:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // اثنان &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// من هذه الطبقات.
    ///
    /// لاحظ أن `iter.filter(f).next()` يعادل `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// ينشئ مكررًا لكل من عوامل التصفية والخرائط.
    ///
    /// ينتج عن المكرر الذي تم إرجاعه فقط `القيمة` التي يُرجع لها الإغلاق المقدم `Some(value)`.
    ///
    /// `filter_map` يمكن استخدامها لجعل سلاسل [`filter`] و [`map`] أكثر إيجازًا.
    /// يوضح المثال أدناه كيف يمكن تقصير `map().filter().map()` إلى مكالمة واحدة إلى `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// إليك نفس المثال ، ولكن مع [`filter`] و [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// ينشئ مكررًا يعطي عدد التكرار الحالي بالإضافة إلى القيمة التالية.
    ///
    /// ينتج المكرر عن أزواج `(i, val)` ، حيث `i` هو مؤشر التكرار الحالي و `val` هي القيمة التي أرجعها المكرر.
    ///
    ///
    /// `enumerate()` يحافظ على حسابه باعتباره [`usize`].
    /// إذا كنت تريد العد بعدد صحيح مختلف الحجم ، فإن وظيفة [`zip`] توفر وظائف مماثلة.
    ///
    /// # سلوك تجاوز
    ///
    /// لا تحمي الطريقة من الفيضانات ، لذا فإن تعداد أكثر من [`usize::MAX`] من العناصر ينتج إما نتيجة خاطئة أو panics.
    /// إذا تم تمكين تأكيدات تصحيح الأخطاء ، يتم ضمان panic.
    ///
    /// # Panics
    ///
    /// قد يكون المكرر الذي تم إرجاعه panic إذا تجاوز الفهرس الذي سيتم إرجاعه [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// ينشئ مكررًا يمكنه استخدام [`peek`] للنظر في العنصر التالي للمكرر دون استهلاكه.
    ///
    /// يضيف طريقة [`peek`] إلى مكرر.انظر وثائقها لمزيد من المعلومات.
    ///
    /// لاحظ أن المكرر الأساسي لا يزال متقدمًا عند استدعاء [`peek`] لأول مرة: لاسترداد العنصر التالي ، يتم استدعاء [`next`] في المكرر الأساسي ، ومن ثم أي آثار جانبية (على سبيل المثال)
    ///
    /// أي شيء بخلاف جلب القيمة التالية) لطريقة [`next`] سيحدث.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() يتيح لنا رؤية future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // يمكننا peek() عدة مرات ، لن يتقدم المكرر
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // بعد انتهاء المكرر ، كذلك peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// ينشئ مكررًا [`يتخطى`] العناصر بناءً على المسند.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` يأخذ الخاتمة كحجة.سوف يستدعي هذا الإغلاق على كل عنصر من عناصر المكرر ، ويتجاهل العناصر حتى يقوم بإرجاع `false`.
    ///
    /// بعد إرجاع `false` ، تنتهي مهمة `skip_while()`'s ، ويتم إنتاج باقي العناصر.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// نظرًا لأن الإغلاق الذي تم تمريره إلى `skip_while()` يأخذ مرجعًا ، ويتكرر العديد من التكرارات على المراجع ، فإن هذا يؤدي إلى موقف محتمل محتمل ، حيث يكون نوع وسيطة الإغلاق مرجعًا مزدوجًا:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // تحتاج اثنين * ق!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// التوقف بعد `false` الأولي:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // في حين أن هذا سيكون خطأ ، نظرًا لأننا حصلنا بالفعل على خطأ ، لم يعد يتم استخدام skip_while()
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// ينشئ مكررًا ينتج عنه عناصر بناءً على المسند.
    ///
    /// `take_while()` يأخذ الخاتمة كحجة.سوف يستدعي هذا الإغلاق على كل عنصر من عناصر المكرر ، وينتج عن العناصر أثناء إرجاع `true`.
    ///
    /// بعد إرجاع `false` ، تنتهي مهمة `take_while()`'s ، ويتم تجاهل باقي العناصر.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// نظرًا لأن الإغلاق الذي تم تمريره إلى `take_while()` يأخذ مرجعًا ، ويتكرر العديد من التكرارات على المراجع ، فإن هذا يؤدي إلى موقف محتمل محتمل ، حيث يكون نوع الإغلاق مرجعًا مزدوجًا:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // تحتاج اثنين * ق!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// التوقف بعد `false` الأولي:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // لدينا المزيد من العناصر التي تقل عن الصفر ، ولكن نظرًا لأننا حصلنا بالفعل على خطأ خاطئ ، لم يعد يتم استخدام take_while()
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// نظرًا لأن `take_while()` يحتاج إلى إلقاء نظرة على القيمة لمعرفة ما إذا كان يجب تضمينها أم لا ، فإن التكرارات المستهلكة سترى أنه تمت إزالتها:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// لم يعد `3` موجودًا ، لأنه تم استهلاكه لمعرفة ما إذا كان يجب أن يتوقف التكرار ، ولكن لم يتم إعادته إلى المكرر.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// يُنشئ مكررًا ينتج عنه كلاهما عناصر بناءً على المسند والخرائط.
    ///
    /// `map_while()` يأخذ الخاتمة كحجة.
    /// سوف يستدعي هذا الإغلاق على كل عنصر من عناصر المكرر ، وينتج عن العناصر أثناء إرجاع [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// إليك نفس المثال ، ولكن مع [`take_while`] و [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// التوقف بعد [`None`] الأولي:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // لدينا المزيد من العناصر التي يمكن أن تناسب u32 (4 ، 5) ، لكن `map_while` أعاد `None` لـ `-3` (حيث أعاد `predicate` `None`) و `collect` توقف عند أول `None` واجهته.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// نظرًا لأن `map_while()` يحتاج إلى إلقاء نظرة على القيمة لمعرفة ما إذا كان يجب تضمينها أم لا ، فإن التكرارات المستهلكة سترى أنه تمت إزالتها:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// لم يعد `-3` موجودًا ، لأنه تم استهلاكه لمعرفة ما إذا كان يجب أن يتوقف التكرار ، ولكن لم يتم إعادته إلى المكرر.
    ///
    /// لاحظ أنه على عكس [`take_while`] ، فإن هذا المكرر **ليس** مدمج.
    /// كما أنه لم يتم تحديد ما يعود إليه هذا المكرر بعد إرجاع [`None`] الأول.
    /// إذا كنت بحاجة إلى مكرر مدمج ، فاستخدم [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// يقوم بإنشاء مكرر يتخطى عناصر `n` الأولى.
    ///
    /// بعد أن يتم استهلاكها ، يتم إنتاج بقية العناصر.
    /// بدلاً من تجاوز هذه الطريقة مباشرةً ، تجاوز طريقة `nth` بدلاً من ذلك.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// ينشئ مكررًا ينتج عنه عناصر `n` الأولى.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` غالبًا ما يستخدم مع مكرر لانهائي ، لجعله محدودًا:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// إذا توفر أقل من `n` من العناصر ، فإن `take` سيقتصر على حجم المكرر الأساسي:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// محول مكرر مشابه لـ [`fold`] يحمل الحالة الداخلية وينتج مكررًا جديدًا.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` تأخذ حجتين: القيمة الأولية التي تزرع الحالة الداخلية ، والإغلاق مع وسيطتين ، الأولى هي إشارة قابلة للتغيير إلى الحالة الداخلية والثانية عنصر مكرر.
    ///
    /// يمكن تعيين الإغلاق للحالة الداخلية لمشاركة الحالة بين التكرارات.
    ///
    /// عند التكرار ، سيتم تطبيق الإغلاق على كل عنصر من عناصر المكرر ويتم إنتاج قيمة الإرجاع من الإغلاق ، [`Option`] ، بواسطة المكرر.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // في كل تكرار ، سنضرب الحالة في العنصر
    ///     *state = *state * x;
    ///
    ///     // بعد ذلك ، سوف نتخلى عن نفي الدولة
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// ينشئ مكررًا يعمل مثل الخريطة ، لكنه يعمل على تسوية البنية المتداخلة.
    ///
    /// يعتبر محول [`map`] مفيدًا جدًا ، ولكن فقط عندما تنتج وسيطة الإغلاق القيم.
    /// إذا أنتج مكررًا بدلاً من ذلك ، فهناك طبقة إضافية من المراوغة.
    /// `flat_map()` سيزيل هذه الطبقة الإضافية من تلقاء نفسه.
    ///
    /// يمكنك التفكير في `flat_map(f)` كمكافئ دلالي لـ ping [`map`] ، ثم [`flatten`] كما في `map(f).flatten()`.
    ///
    /// طريقة أخرى للتفكير في `flat_map()`: يُرجع إغلاق [`الخريطة`] عنصرًا واحدًا لكل عنصر ، ويعيد إغلاق `flat_map()`'s مكررًا لكل عنصر.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() إرجاع مكرر
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// يقوم بإنشاء مكرر يقوم بتسوية البنية المتداخلة.
    ///
    /// يكون هذا مفيدًا عندما يكون لديك مكرر من التكرارات أو مكرر لأشياء يمكن تحويلها إلى مكررات وتريد إزالة مستوى واحد من المراوغة.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// رسم الخرائط ثم التسطيح:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() إرجاع مكرر
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// يمكنك أيضًا إعادة كتابة هذا من حيث [`flat_map()`] ، وهو الأفضل في هذه الحالة لأنه ينقل النية بشكل أكثر وضوحًا:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() إرجاع مكرر
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// يزيل التسطيح مستوى واحدًا فقط من التداخل في كل مرة:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// هنا نرى أن `flatten()` لا يقوم بتسوية "deep".
    /// بدلاً من ذلك ، تتم إزالة مستوى واحد فقط من التداخل.أي ، إذا كنت `flatten()` مصفوفة ثلاثية الأبعاد ، فإن النتيجة ستكون ثنائية الأبعاد وليست أحادية البعد.
    /// للحصول على هيكل أحادي البعد ، يجب عليك `flatten()` مرة أخرى.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// ينشئ مكررًا ينتهي بعد [`None`] الأول.
    ///
    /// بعد أن يقوم مكرر بإرجاع [`None`] ، قد ينتج عن استدعاءات future أو لا ينتج [`Some(T)`] مرة أخرى.
    /// `fuse()` يتكيف مع مكرر ، مما يضمن أنه بعد إعطاء [`None`] ، فإنه سيعيد [`None`] دائمًا إلى الأبد.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// // مكرر يتناوب بين Some و None
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // إذا كان حتى ، Some(i32) ، وإلا لا شيء
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // يمكننا أن نرى مكررنا يتأرجح ذهابًا وإيابًا
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // ومع ذلك ، بمجرد أن ندمجها ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // سيعود دائمًا `None` بعد المرة الأولى.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// يفعل شيئًا مع كل عنصر من عناصر المكرر ، ويمرر القيمة.
    ///
    /// عند استخدام التكرارات ، ستقوم في الغالب بربط العديد منها معًا.
    /// أثناء العمل على مثل هذا الرمز ، قد ترغب في التحقق مما يحدث في أجزاء مختلفة في خط الأنابيب.للقيام بذلك ، أدخل مكالمة إلى `inspect()`.
    ///
    /// من الشائع استخدام `inspect()` كأداة لتصحيح الأخطاء أكثر من استخدامه في الكود النهائي الخاص بك ، ولكن قد تجده التطبيقات مفيدة في مواقف معينة عندما تحتاج إلى تسجيل الأخطاء قبل التخلص منها.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // تسلسل المكرر هذا معقد.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // دعنا نضيف بعض مكالمات inspect() للتحقيق في ما يحدث
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// هذا سوف يطبع:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// تسجيل الأخطاء قبل التخلص منها:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// هذا سوف يطبع:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// يستعير مكررًا بدلاً من استهلاكه.
    ///
    /// هذا مفيد للسماح بتطبيق محولات التكرار مع الاحتفاظ بملكية المكرر الأصلي.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // إذا حاولنا استخدام iter مرة أخرى ، فلن يعمل.
    /// // يعطي السطر التالي "خطأ: استخدام القيمة المنقولة: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // دعونا نحاول ذلك مرة أخرى
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // بدلاً من ذلك ، نضيف .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // الآن هذا جيد:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// يحول مكررًا إلى مجموعة.
    ///
    /// `collect()` يمكن أن يأخذ أي شيء متكرر ، وتحويله إلى مجموعة ذات صلة.
    /// هذه واحدة من أكثر الطرق فعالية في المكتبة القياسية ، وتستخدم في مجموعة متنوعة من السياقات.
    ///
    /// النمط الأساسي الذي يستخدم فيه `collect()` هو تحويل مجموعة إلى أخرى.
    /// تأخذ مجموعة ، وتتصل بـ [`iter`] عليها ، وتقوم بمجموعة من التحولات ، ثم `collect()` في النهاية.
    ///
    /// `collect()` يمكن أيضًا إنشاء مثيلات لأنواع ليست مجموعات نموذجية.
    /// على سبيل المثال ، يمكن إنشاء [`String`] من [`char`] s ، ويمكن تجميع مكرر لعناصر [`Result<T, E>`][`Result`] في `Result<Collection<T>, E>`.
    ///
    /// انظر الأمثلة أدناه للمزيد.
    ///
    /// نظرًا لأن `collect()` عام جدًا ، فقد يتسبب في حدوث مشكلات في الاستدلال على الكتابة.
    /// على هذا النحو ، `collect()` هي واحدة من المرات القليلة التي سترى فيها بناء الجملة المعروف باسم 'turbofish': `::<>`.
    /// يساعد هذا خوارزمية الاستدلال على فهم المجموعة التي تحاول جمعها على وجه التحديد.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// لاحظ أننا بحاجة إلى `: Vec<i32>` على الجانب الأيسر.هذا لأنه يمكننا تجميع ، على سبيل المثال ، [`VecDeque<T>`] بدلاً من ذلك:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// استخدام 'turbofish' بدلاً من التعليق على `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// نظرًا لأن `collect()` يهتم فقط بما تقوم بتجميعه فيه ، فلا يزال بإمكانك استخدام تلميح من النوع الجزئي ، `_` ، مع التربو:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// استخدام `collect()` لعمل [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// إذا كان لديك قائمة [`نتيجة<T, E>`][`النتائج`] ، يمكنك استخدام `collect()` لمعرفة ما إذا كان أي منها قد فشل:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // يعطينا الخطأ الأول
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // يعطينا قائمة الإجابات
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// يستهلك مكررًا ، ينشئ مجموعتين منه.
    ///
    /// يمكن للمسند الذي تم تمريره إلى `partition()` إرجاع `true` أو `false`.
    /// `partition()` تقوم بإرجاع زوج ، وجميع العناصر التي قامت بإرجاع `true` لها ، وجميع العناصر التي قامت بإرجاع `false` لها.
    ///
    ///
    /// راجع أيضًا [`is_partitioned()`] و [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// يعيد ترتيب عناصر هذا المكرر *في المكان* وفقًا للمسند المحدد ، بحيث يسبق كل العناصر التي ترجع `true` كل العناصر التي ترجع `false`.
    ///
    /// إرجاع عدد عناصر `true` التي تم العثور عليها.
    ///
    /// لا يتم الاحتفاظ بالترتيب النسبي للعناصر المقسمة.
    ///
    /// راجع أيضًا [`is_partitioned()`] و [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // التقسيم في المكان بين التسويات والاحتمالات
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: هل يجب أن نقلق بشأن فائض العد؟الطريقة الوحيدة للحصول على أكثر من
        // `usize::MAX` المراجع القابلة للتغيير تكون مع ZSTs ، والتي لا تفيد في التقسيم ...

        // توجد وظائف الإغلاق "factory" هذه لتجنب التعميم في `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // ابحث بشكل متكرر عن أول `false` وقم بتبديله بآخر `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// للتحقق مما إذا كانت عناصر هذا المكرر مقسمة وفقًا للمسند المحدد ، بحيث يسبق كل العناصر التي ترجع `true` كل العناصر التي ترجع `false`.
    ///
    ///
    /// راجع أيضًا [`partition()`] و [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // إما أن تختبر جميع العناصر `true` ، أو تتوقف الفقرة الأولى عند `false` ونتحقق من عدم وجود المزيد من عناصر `true` بعد ذلك.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// طريقة مكررة تطبق دالة طالما أنها تعود بنجاح ، وتنتج قيمة واحدة نهائية.
    ///
    /// `try_fold()` يأخذ وسيطتين: قيمة أولية ، وإغلاق مع وسيطين: 'accumulator' ، وعنصر
    /// يعود الإغلاق إما بنجاح ، مع القيمة التي يجب أن يمتلكها المُجمع للتكرار التالي ، أو يُرجع الفشل ، مع قيمة خطأ يتم نشرها مرة أخرى إلى المتصل على الفور (short-circuiting).
    ///
    ///
    /// القيمة الأولية هي القيمة التي سيحصل عليها المجمع في المكالمة الأولى.إذا نجح تطبيق الإغلاق على كل عنصر من عناصر المكرر ، فإن `try_fold()` تُرجع المُجمع النهائي كنجاح.
    ///
    /// يكون الطي مفيدًا عندما يكون لديك مجموعة من شيء ما ، وتريد إنتاج قيمة واحدة منه.
    ///
    /// # ملاحظة للمنفذين
    ///
    /// تحتوي العديد من طرق (forward) الأخرى على تطبيقات افتراضية من حيث هذه الطريقة ، لذا حاول تنفيذ ذلك بشكل صريح إذا كان بإمكانه فعل شيء أفضل من تنفيذ حلقة `for` الافتراضية.
    ///
    /// على وجه الخصوص ، حاول أن يكون هذا الاستدعاء `try_fold()` على الأجزاء الداخلية التي يتكون منها هذا المكرر.
    /// إذا كانت هناك حاجة إلى مكالمات متعددة ، فقد يكون عامل تشغيل `?` مناسبًا لتسلسل قيمة المجمع ، ولكن احذر من أي متغيرات يجب دعمها قبل تلك العوائد المبكرة.
    /// هذه طريقة `&mut self` ، لذا يجب استئناف التكرار بعد حدوث خطأ هنا.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // المجموع المحدد لجميع عناصر المصفوفة
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // يتم تجاوز هذا المجموع عند إضافة عنصر 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // نظرًا لقصر الدائرة ، تظل العناصر المتبقية متاحة من خلال المكرر.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// أسلوب مكرر يطبق دالة غير معصومة على كل عنصر في المكرر ، ويتوقف عند الخطأ الأول ويعيد هذا الخطأ.
    ///
    ///
    /// يمكن اعتبار هذا أيضًا شكل [`for_each()`] غير معصوم أو كإصدار عديم الحالة من [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // لقد تم قصر الدائرة ، وبالتالي فإن العناصر المتبقية لا تزال في المكرر:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// يطوي كل عنصر في مجمع من خلال تطبيق عملية ، وإرجاع النتيجة النهائية.
    ///
    /// `fold()` يأخذ وسيطتين: قيمة أولية ، وإغلاق مع وسيطين: 'accumulator' ، وعنصر
    /// يُرجع الإغلاق القيمة التي يجب أن يمتلكها المُجمّع للتكرار التالي.
    ///
    /// القيمة الأولية هي القيمة التي سيحصل عليها المجمع في المكالمة الأولى.
    ///
    /// بعد تطبيق هذا الإغلاق على كل عنصر من عناصر المكرر ، يقوم `fold()` بإرجاع المركب.
    ///
    /// تسمى هذه العملية أحيانًا 'reduce' أو 'inject'.
    ///
    /// يكون الطي مفيدًا عندما يكون لديك مجموعة من شيء ما ، وتريد إنتاج قيمة واحدة منه.
    ///
    /// Note: قد لا تنتهي `fold()` ، والطرق المشابهة التي تجتاز المكرر بأكمله ، لمكررات لا نهائية ، حتى في traits التي يمكن تحديد نتيجة لها في وقت محدد.
    ///
    /// Note: يمكن استخدام [`reduce()`] لاستخدام العنصر الأول كقيمة أولية ، إذا كان نوع المركب ونوع العنصر متماثلين.
    ///
    /// # ملاحظة للمنفذين
    ///
    /// تحتوي العديد من طرق (forward) الأخرى على تطبيقات افتراضية من حيث هذه الطريقة ، لذا حاول تنفيذ ذلك بشكل صريح إذا كان بإمكانه فعل شيء أفضل من تنفيذ حلقة `for` الافتراضية.
    ///
    ///
    /// على وجه الخصوص ، حاول أن يكون هذا الاستدعاء `fold()` على الأجزاء الداخلية التي يتكون منها هذا المكرر.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // مجموع كل عناصر المصفوفة
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// دعنا نتصفح كل خطوة من خطوات التكرار هنا:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// وهكذا ، فإن النتيجة النهائية ، `6`.
    ///
    /// من الشائع للأشخاص الذين لم يستخدموا التكرارات كثيرًا استخدام حلقة `for` مع قائمة بالأشياء لبناء نتيجة.يمكن تحويلها إلى `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // لحلقة:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // هم نفس الشيء
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// يقلل العناصر إلى عنصر واحد ، عن طريق تطبيق عملية تصغير بشكل متكرر.
    ///
    /// إذا كان المكرر فارغًا ، يتم إرجاع [`None`] ؛وإلا ، تُرجع نتيجة التخفيض.
    ///
    /// بالنسبة للمكررات التي تحتوي على عنصر واحد على الأقل ، يكون هذا هو نفسه [`fold()`] مع العنصر الأول للمكرر كقيمة أولية ، مع طي كل عنصر لاحق فيه.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// ابحث عن القيمة القصوى:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// يختبر ما إذا كان كل عنصر في المكرر يتطابق مع المسند.
    ///
    /// `all()` يأخذ الإغلاق الذي يُرجع `true` أو `false`.يتم تطبيق هذا الإغلاق على كل عنصر من عناصر المكرر ، وإذا قاموا جميعًا بإرجاع `true` ، فإن `all()` يفعل ذلك أيضًا.
    /// إذا قام أي منهم بإرجاع `false` ، فإنه يقوم بإرجاع `false`.
    ///
    /// `all()` هو قصر الدائرة.بمعنى آخر ، ستتوقف المعالجة بمجرد العثور على `false` ، نظرًا لأنه بغض النظر عما يحدث ، ستكون النتيجة أيضًا `false`.
    ///
    ///
    /// يقوم مكرر فارغ بإرجاع `true`.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// التوقف عند أول `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // لا يزال بإمكاننا استخدام `iter` ، حيث يوجد المزيد من العناصر.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// يختبر ما إذا كان أي عنصر في المكرر يتطابق مع المسند.
    ///
    /// `any()` يأخذ الإغلاق الذي يُرجع `true` أو `false`.يتم تطبيق هذا الإغلاق على كل عنصر من عناصر المكرر ، وإذا قام أي منهم بإرجاع `true` ، فإن `any()` يفعل ذلك أيضًا.
    /// إذا قاموا جميعًا بإرجاع `false` ، فسيتم إرجاع `false`.
    ///
    /// `any()` هو قصر الدائرة.بمعنى آخر ، ستتوقف المعالجة بمجرد العثور على `true` ، نظرًا لأنه بغض النظر عما يحدث ، ستكون النتيجة أيضًا `true`.
    ///
    ///
    /// يقوم مكرر فارغ بإرجاع `false`.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// التوقف عند أول `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // لا يزال بإمكاننا استخدام `iter` ، حيث يوجد المزيد من العناصر.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// يبحث عن عنصر مكرر يرضي المسند.
    ///
    /// `find()` يأخذ الإغلاق الذي يُرجع `true` أو `false`.
    /// يتم تطبيق هذا الإغلاق على كل عنصر من عناصر المكرر ، وإذا قام أي منها بإرجاع `true` ، فإن `find()` تقوم بإرجاع [`Some(element)`].
    /// إذا قاموا جميعًا بإرجاع `false` ، فسيتم إرجاع [`None`].
    ///
    /// `find()` هو قصر الدائرة.بمعنى آخر ، ستتوقف المعالجة بمجرد إرجاع الإغلاق `true`.
    ///
    /// نظرًا لأن `find()` يأخذ مرجعًا ، ويقوم العديد من التكرارات بالتكرار على المراجع ، فإن هذا يؤدي إلى موقف محير محتمل حيث تكون الوسيطة مرجعًا مزدوجًا.
    ///
    /// يمكنك رؤية هذا التأثير في الأمثلة أدناه ، مع `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// التوقف عند أول `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // لا يزال بإمكاننا استخدام `iter` ، حيث يوجد المزيد من العناصر.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// لاحظ أن `iter.find(f)` يعادل `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// يطبق الدالة على عناصر المكرر ويعيد النتيجة الأولى غير اللاشيئة.
    ///
    ///
    /// `iter.find_map(f)` يعادل `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// يطبق الوظيفة على عناصر المكرر ويعيد النتيجة الحقيقية الأولى أو الخطأ الأول.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// يبحث عن عنصر في مكرر ، ويعيد فهرسه.
    ///
    /// `position()` يأخذ الإغلاق الذي يُرجع `true` أو `false`.
    /// يتم تطبيق هذا الإغلاق على كل عنصر من عناصر المكرر ، وإذا قام أحدهم بإرجاع `true` ، فإن `position()` ترجع [`Some(index)`].
    /// إذا قام كل منهم بإرجاع `false` ، فسيتم إرجاع [`None`].
    ///
    /// `position()` هو قصر الدائرة.بمعنى آخر ، ستتوقف المعالجة بمجرد العثور على `true`.
    ///
    /// # سلوك تجاوز
    ///
    /// لا تحمي هذه الطريقة من الفائض ، لذلك إذا كان هناك أكثر من [`usize::MAX`] من العناصر غير المتطابقة ، فإنها إما تنتج نتيجة خاطئة أو panics.
    ///
    /// إذا تم تمكين تأكيدات تصحيح الأخطاء ، يتم ضمان panic.
    ///
    /// # Panics
    ///
    /// قد تكون هذه الوظيفة panic إذا كان المكرر يحتوي على أكثر من `usize::MAX` من العناصر غير المطابقة.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// التوقف عند أول `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // لا يزال بإمكاننا استخدام `iter` ، حيث يوجد المزيد من العناصر.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // يعتمد الفهرس الذي تم إرجاعه على حالة التكرار
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// يبحث عن عنصر في مكرر من اليمين ، ويعيد فهرسه.
    ///
    /// `rposition()` يأخذ الإغلاق الذي يُرجع `true` أو `false`.
    /// يتم تطبيق هذا الإغلاق على كل عنصر من عناصر المكرر ، بدءًا من النهاية ، وإذا قام أحدهم بإرجاع `true` ، فإن `rposition()` ترجع [`Some(index)`].
    ///
    /// إذا قام كل منهم بإرجاع `false` ، فسيتم إرجاع [`None`].
    ///
    /// `rposition()` هو قصر الدائرة.بمعنى آخر ، ستتوقف المعالجة بمجرد العثور على `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// التوقف عند أول `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // لا يزال بإمكاننا استخدام `iter` ، حيث يوجد المزيد من العناصر.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // لا حاجة لفحص تجاوز السعة هنا ، لأن `ExactSizeIterator` يعني أن عدد العناصر يتناسب مع `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// إرجاع الحد الأقصى لعنصر مكرر.
    ///
    /// إذا كانت عدة عناصر متساوية في الحد الأقصى ، فسيتم إرجاع العنصر الأخير.
    /// إذا كان المكرر فارغًا ، يتم إرجاع [`None`].
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// إرجاع الحد الأدنى لعنصر مكرر.
    ///
    /// إذا كانت عدة عناصر متساوية في الحد الأدنى ، فسيتم إرجاع العنصر الأول.
    /// إذا كان المكرر فارغًا ، يتم إرجاع [`None`].
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// تُرجع العنصر الذي يعطي القيمة القصوى من الوظيفة المحددة.
    ///
    ///
    /// إذا كانت عدة عناصر متساوية في الحد الأقصى ، فسيتم إرجاع العنصر الأخير.
    /// إذا كان المكرر فارغًا ، يتم إرجاع [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// إرجاع العنصر الذي يعطي القيمة القصوى فيما يتعلق بوظيفة المقارنة المحددة.
    ///
    ///
    /// إذا كانت عدة عناصر متساوية في الحد الأقصى ، فسيتم إرجاع العنصر الأخير.
    /// إذا كان المكرر فارغًا ، يتم إرجاع [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// تُرجع العنصر الذي يعطي الحد الأدنى من القيمة من الوظيفة المحددة.
    ///
    ///
    /// إذا كانت عدة عناصر متساوية في الحد الأدنى ، فسيتم إرجاع العنصر الأول.
    /// إذا كان المكرر فارغًا ، يتم إرجاع [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// إرجاع العنصر الذي يعطي الحد الأدنى للقيمة فيما يتعلق بدالة المقارنة المحددة.
    ///
    ///
    /// إذا كانت عدة عناصر متساوية في الحد الأدنى ، فسيتم إرجاع العنصر الأول.
    /// إذا كان المكرر فارغًا ، يتم إرجاع [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// يعكس اتجاه المكرر.
    ///
    /// عادةً ما تتكرر التكرارات من اليسار إلى اليمين.
    /// بعد استخدام `rev()` ، سيقوم المكرر بدلاً من ذلك بالتكرار من اليمين إلى اليسار.
    ///
    /// هذا ممكن فقط إذا كان للمكرر نهاية ، لذلك يعمل `rev()` فقط على [`DoubleEndedIterator`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// يحول مكرر الأزواج إلى زوج من الحاويات.
    ///
    /// `unzip()` يستهلك مكررًا كاملاً من الأزواج ، وينتج مجموعتين: واحدة من العناصر اليسرى للأزواج ، والأخرى من العناصر اليمنى.
    ///
    ///
    /// هذه الوظيفة ، إلى حد ما ، هي عكس [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// ينشئ مكررًا ينسخ جميع عناصره.
    ///
    /// يكون هذا مفيدًا عندما يكون لديك مكرر فوق `&T` ، لكنك تحتاج إلى مكرر فوق `T`.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // نسخ هو نفس .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// ينشئ مكررًا ["ينسخ"] جميع عناصره.
    ///
    /// يكون هذا مفيدًا عندما يكون لديك مكرر فوق `&T` ، لكنك تحتاج إلى مكرر فوق `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // المستنسخة هي نفسها .map(|&x| x) ، للأعداد الصحيحة
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// يكرر مكرر إلى ما لا نهاية.
    ///
    /// بدلاً من التوقف عند [`None`] ، سيبدأ المكرر بدلاً من ذلك مرة أخرى من البداية.بعد التكرار مرة أخرى ، سيبدأ من البداية مرة أخرى.ومره اخرى.
    /// ومره اخرى.
    /// Forever.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// جمع عناصر المكرر.
    ///
    /// يأخذ كل عنصر ويجمعهم معًا ويعيد النتيجة.
    ///
    /// ترجع أداة التكرار الفارغة القيمة الصفرية للنوع.
    ///
    /// # Panics
    ///
    /// عند استدعاء `sum()` ويتم إرجاع نوع عدد صحيح أولي ، فإن هذه الطريقة سوف panic إذا تم تمكين تجاوزات الحساب وتأكيدات تصحيح الأخطاء.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// يتكرر على المكرر بأكمله ، ويضرب كل العناصر
    ///
    /// يقوم مكرر فارغ بإرجاع قيمة واحدة من النوع.
    ///
    /// # Panics
    ///
    /// عند استدعاء `product()` ويتم إرجاع نوع عدد صحيح أولي ، فإن الطريقة سوف panic إذا تم تمكين تجاوزات الحساب وتصحيح الأخطاء.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) يقارن عناصر [`Iterator`] بعناصر أخرى.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) يقارن عناصر [`Iterator`] بعناصر أخرى فيما يتعلق بوظيفة المقارنة المحددة.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) يقارن عناصر [`Iterator`] بعناصر أخرى.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) يقارن عناصر [`Iterator`] بعناصر أخرى فيما يتعلق بوظيفة المقارنة المحددة.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// يحدد ما إذا كانت عناصر [`Iterator`] هذه تساوي تلك الخاصة بعناصر أخرى.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// يحدد ما إذا كانت عناصر [`Iterator`] هذه تساوي تلك الخاصة بعناصر أخرى فيما يتعلق بوظيفة المساواة المحددة.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// يحدد ما إذا كانت عناصر [`Iterator`] غير متساوية مع عناصر أخرى.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// تحديد ما إذا كانت عناصر [`Iterator`] هذه أقل بـ [lexicographically](Ord#lexicographical-comparison) من عناصر أخرى.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// يحدد ما إذا كانت عناصر [`Iterator`] هذه [lexicographically](Ord#lexicographical-comparison) أقل أو مساوية لعناصر أخرى.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// تحديد ما إذا كانت عناصر [`Iterator`] أكبر بمقدار [lexicographically](Ord#lexicographical-comparison) من عناصر أخرى.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// تحديد ما إذا كانت عناصر [`Iterator`] هذه أكبر بمقدار [lexicographically](Ord#lexicographical-comparison) من أو تساوي عناصر عنصر آخر.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// للتحقق مما إذا كانت عناصر هذا المكرر مرتبة.
    ///
    /// أي ، لكل عنصر `a` وعنصره التالي `b` ، يجب أن يحتفظ `a <= b`.إذا كان المكرر ينتج صفرًا بالضبط أو عنصرًا واحدًا ، فسيتم إرجاع `true`.
    ///
    /// لاحظ أنه إذا كان `Self::Item` هو `PartialOrd` فقط ، ولكن ليس `Ord` ، فإن التعريف أعلاه يعني أن هذه الدالة تقوم بإرجاع `false` إذا كان أي عنصرين متتاليين غير قابلين للمقارنة.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// للتحقق مما إذا كانت عناصر هذا المكرر مرتبة باستخدام دالة المقارنة المحددة.
    ///
    /// بدلاً من استخدام `PartialOrd::partial_cmp` ، تستخدم هذه الوظيفة الدالة `compare` المحددة لتحديد ترتيب عنصرين.
    /// بصرف النظر عن ذلك ، فهو يعادل [`is_sorted`] ؛انظر وثائقها لمزيد من المعلومات.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// للتحقق مما إذا كانت عناصر هذا المكرر مرتبة باستخدام وظيفة استخراج المفتاح المحددة.
    ///
    /// بدلاً من مقارنة عناصر المكرر مباشرةً ، تقارن هذه الوظيفة مفاتيح العناصر ، كما هو محدد بواسطة `f`.
    /// بصرف النظر عن ذلك ، فهو يعادل [`is_sorted`] ؛انظر وثائقها لمزيد من المعلومات.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// انظر [TrustedRandomAccess]
    // الاسم غير المعتاد هو تجنب تضارب الأسماء في دقة الأسلوب ، راجع #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}