use crate::ops::{ControlFlow, Try};

/// مكرر قادر على إنتاج عناصر من كلا الطرفين.
///
/// يمتلك الشيء الذي ينفذ `DoubleEndedIterator` قدرة إضافية واحدة على شيء يستخدم [`Iterator`]: القدرة أيضًا على أخذ `العناصر من الخلف ، وكذلك من الأمام.
///
///
/// من المهم ملاحظة أن كلا من العمل ذهابًا وإيابًا على نفس النطاق ، ولا يتقاطعان: ينتهي التكرار عندما يلتقيان في المنتصف.
///
/// بطريقة مماثلة لبروتوكول [`Iterator`] ، بمجرد إرجاع `DoubleEndedIterator` لـ [`None`] من [`next_back()`] ، قد يؤدي الاتصال به مرة أخرى أو قد لا يعيد [`Some`] مرة أخرى.
/// [`next()`] و [`next_back()`] قابلة للتبديل لهذا الغرض.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// الاستخدام الأساسي:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// يزيل عنصرًا ويعيده من نهاية المكرر.
    ///
    /// تُرجع `None` في حالة عدم وجود المزيد من العناصر.
    ///
    /// تحتوي مستندات [trait-level] على مزيد من التفاصيل.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// قد تختلف العناصر الناتجة عن طرق "DoubleEndedIterator" عن تلك الناتجة عن طرق [`Iterator`]:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// تقدم المكرر من الخلف بواسطة عناصر `n`.
    ///
    /// `advance_back_by` هو الإصدار العكسي من [`advance_by`].ستتخطى هذه الطريقة بشغف عناصر `n` بدءًا من الخلف عن طريق استدعاء [`next_back`] حتى `n` مرة حتى يتم مواجهة [`None`].
    ///
    /// `advance_back_by(n)` سيعيد [`Ok(())`] إذا تقدم المكرر بنجاح بواسطة عناصر `n` ، أو [`Err(k)`] إذا تمت مصادفة [`None`] ، حيث `k` هو عدد العناصر التي تقدم بها المكرر قبل نفاد العناصر (أي
    /// طول المكرر).
    /// لاحظ أن `k` دائمًا أقل من `n`.
    ///
    /// لا يستهلك استدعاء `advance_back_by(0)` أي عناصر ويعيد [`Ok(())`] دائمًا.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // تم تخطي `&3` فقط
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// لعرض العنصر `n` من نهاية المكرر.
    ///
    /// هذا هو في الأساس الإصدار المعكوس من [`Iterator::nth()`].
    /// على الرغم من أنه مثل معظم عمليات الفهرسة ، فإن العد يبدأ من الصفر ، لذا فإن `nth_back(0)` ترجع القيمة الأولى من النهاية ، `nth_back(1)` الثانية ، وهكذا.
    ///
    ///
    /// لاحظ أنه سيتم استهلاك جميع العناصر بين النهاية والعنصر المرتجع ، بما في ذلك العنصر المرتجع.
    /// هذا يعني أيضًا أن استدعاء `nth_back(0)` عدة مرات على نفس المكرر سيعيد عناصر مختلفة.
    ///
    /// `nth_back()` سيعيد [`None`] إذا كان `n` أكبر من أو يساوي طول المكرر.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// لا يؤدي استدعاء `nth_back()` عدة مرات إلى إرجاع المكرر:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// إرجاع `None` إذا كان هناك أقل من `n + 1` من العناصر:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// هذا هو الإصدار العكسي من [`Iterator::try_fold()`]: يأخذ عناصر تبدأ من الجزء الخلفي من المكرر.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // نظرًا لقصر الدائرة ، تظل العناصر المتبقية متاحة من خلال المكرر.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// طريقة مكرر تقلل من عناصر المكرر إلى قيمة واحدة نهائية ، بدءًا من الخلف.
    ///
    /// هذا هو الإصدار العكسي من [`Iterator::fold()`]: يأخذ عناصر تبدأ من الجزء الخلفي من المكرر.
    ///
    /// `rfold()` يأخذ وسيطتين: قيمة أولية ، وإغلاق مع وسيطين: 'accumulator' ، وعنصر
    /// يُرجع الإغلاق القيمة التي يجب أن يمتلكها المُجمّع للتكرار التالي.
    ///
    /// القيمة الأولية هي القيمة التي سيحصل عليها المجمع في المكالمة الأولى.
    ///
    /// بعد تطبيق هذا الإغلاق على كل عنصر من عناصر المكرر ، يقوم `rfold()` بإرجاع المركب.
    ///
    /// تسمى هذه العملية أحيانًا 'reduce' أو 'inject'.
    ///
    /// يكون الطي مفيدًا عندما يكون لديك مجموعة من شيء ما ، وتريد إنتاج قيمة واحدة منه.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // مجموع كل عناصر أ
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// هذا المثال يبني سلسلة ، تبدأ بقيمة أولية وتستمر مع كل عنصر من الخلف حتى المقدمة:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// يبحث عن عنصر مكرر من الخلف يرضي المسند.
    ///
    /// `rfind()` يأخذ الإغلاق الذي يُرجع `true` أو `false`.
    /// يتم تطبيق هذا الإغلاق على كل عنصر من عناصر المكرر ، بدءًا من النهاية ، وإذا قام أي منها بإرجاع `true` ، فإن `rfind()` تقوم بإرجاع [`Some(element)`].
    /// إذا قاموا جميعًا بإرجاع `false` ، فسيتم إرجاع [`None`].
    ///
    /// `rfind()` هو قصر الدائرة.بمعنى آخر ، ستتوقف المعالجة بمجرد إرجاع الإغلاق `true`.
    ///
    /// نظرًا لأن `rfind()` يأخذ مرجعًا ، ويقوم العديد من التكرارات بالتكرار على المراجع ، فإن هذا يؤدي إلى موقف محير محتمل حيث تكون الوسيطة مرجعًا مزدوجًا.
    ///
    /// يمكنك رؤية هذا التأثير في الأمثلة أدناه ، مع `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// التوقف عند أول `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // لا يزال بإمكاننا استخدام `iter` ، حيث يوجد المزيد من العناصر.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}