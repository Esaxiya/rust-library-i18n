use crate::iter::{FusedIterator, TrustedLen};

/// ينشئ مكررًا جديدًا يكرر عناصر من النوع `A` إلى ما لا نهاية من خلال تطبيق الإغلاق المقدم ، المكرر ، `F: FnMut() -> A`.
///
/// تستدعي وظيفة `repeat_with()` المكرر مرارًا وتكرارًا.
///
/// غالبًا ما يتم استخدام التكرارات اللانهائية مثل `repeat_with()` مع محولات مثل [`Iterator::take()`] لجعلها محدودة.
///
/// إذا كان نوع عنصر المكرر الذي تحتاجه يستخدم [`Clone`] ، ولا بأس من الاحتفاظ بالعنصر المصدر في الذاكرة ، فيجب عليك بدلاً من ذلك استخدام وظيفة [`repeat()`].
///
///
/// المكرر الذي تم إنتاجه بواسطة `repeat_with()` ليس [`DoubleEndedIterator`].
/// إذا كنت بحاجة إلى `repeat_with()` لإرجاع [`DoubleEndedIterator`] ، فالرجاء فتح مشكلة GitHub لشرح حالة الاستخدام الخاصة بك.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// الاستخدام الأساسي:
///
/// ```
/// use std::iter;
///
/// // لنفترض أن لدينا بعض القيمة من نوع ليس `Clone` أو لا ترغب في حفظها في الذاكرة حتى الآن لأنها باهظة الثمن:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // قيمة خاصة إلى الأبد:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// باستخدام الطفرة والذهاب إلى نهايته:
///
/// ```rust
/// use std::iter;
///
/// // من الصفر إلى القوة الثالثة لاثنين:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... والآن انتهينا
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// مكرر يكرر عناصر من النوع `A` إلى ما لا نهاية من خلال تطبيق الإغلاق المقدم `F: FnMut() -> A`.
///
///
/// يتم إنشاء `struct` بواسطة وظيفة [`repeat_with()`].
/// انظر وثائقها للمزيد.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}