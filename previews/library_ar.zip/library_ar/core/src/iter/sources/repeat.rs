use crate::iter::{FusedIterator, TrustedLen};

/// ينشئ مكررًا جديدًا يكرر عنصرًا واحدًا إلى ما لا نهاية.
///
/// تكرر الدالة `repeat()` قيمة واحدة مرارًا وتكرارًا.
///
/// غالبًا ما يتم استخدام التكرارات اللانهائية مثل `repeat()` مع محولات مثل [`Iterator::take()`] لجعلها محدودة.
///
/// إذا كان نوع عنصر المكرر الذي تحتاجه لا يستخدم `Clone` ، أو إذا كنت لا تريد الاحتفاظ بالعنصر المكرر في الذاكرة ، فيمكنك بدلاً من ذلك استخدام وظيفة [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// الاستخدام الأساسي:
///
/// ```
/// use std::iter;
///
/// // الرقم أربعة 4:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // نعم ، ما زلت أربعة
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// الذهاب إلى النهاية مع [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // كان المثال الأخير أربع مرات أكثر من اللازم.دعونا نمتلك أربعة أرباع فقط.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... والآن انتهينا
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// مكرر يكرر عنصرًا إلى ما لا نهاية.
///
/// يتم إنشاء `struct` بواسطة وظيفة [`repeat()`].انظر وثائقها للمزيد.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}