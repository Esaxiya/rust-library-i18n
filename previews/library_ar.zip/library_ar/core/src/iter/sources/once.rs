use crate::iter::{FusedIterator, TrustedLen};

/// ينشئ مكررًا ينتج عنه عنصر مرة واحدة بالضبط.
///
/// يستخدم هذا بشكل شائع لتكييف قيمة واحدة في [`chain()`] لأنواع أخرى من التكرار.
/// ربما لديك مكرر يغطي كل شيء تقريبًا ، لكنك تحتاج إلى حالة خاصة إضافية.
/// ربما لديك وظيفة تعمل على التكرارات ، لكنك تحتاج فقط إلى معالجة قيمة واحدة.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// الاستخدام الأساسي:
///
/// ```
/// use std::iter;
///
/// // واحد هو الرقم الأكثر وحدة
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // واحد فقط ، هذا كل ما نحصل عليه
/// assert_eq!(None, one.next());
/// ```
///
/// التسلسل مع مكرر آخر.
/// لنفترض أننا نريد تكرار كل ملف من ملفات دليل `.foo` ، ولكن أيضًا ملف تكوين ،
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // نحتاج إلى التحويل من مكرر لـ DirEntry-s إلى مكرر لـ PathBufs ، لذلك نستخدم map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // الآن ، مكررنا فقط لملف التكوين الخاص بنا
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // اربط المكرر معًا في مكرر واحد كبير
/// let files = dirs.chain(config);
///
/// // سيعطينا هذا جميع الملفات الموجودة في .foo بالإضافة إلى .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// مكرر ينتج عنصرًا مرة واحدة بالضبط.
///
/// يتم إنشاء `struct` بواسطة وظيفة [`once()`].انظر وثائقها للمزيد.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}