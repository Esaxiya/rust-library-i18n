use crate::fmt;

/// ينشئ مكررًا جديدًا حيث يستدعي كل تكرار الإغلاق المقدم `F: FnMut() -> Option<T>`.
///
/// يتيح ذلك إنشاء مكرر مخصص بأي سلوك دون استخدام صيغة مطولة أكثر لإنشاء نوع مخصص وتنفيذ [`Iterator`] trait له.
///
/// لاحظ أن مكرر `FromFn` لا يضع افتراضات حول سلوك الإغلاق ، وبالتالي لا يطبق [`FusedIterator`] بشكل متحفظ ، أو يتجاوز [`Iterator::size_hint()`] من `(0, None)` الافتراضي الخاص به.
///
///
/// يمكن أن يستخدم الإغلاق الالتقاطات وبيئته لتعقب الحالة عبر التكرارات.اعتمادًا على كيفية استخدام المكرر ، قد يتطلب ذلك تحديد الكلمة الأساسية [`move`] عند الإغلاق.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// دعنا نعيد تنفيذ مكرر العداد من [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // زيادة العد لدينا.هذا هو السبب في أننا بدأنا من الصفر.
///     count += 1;
///
///     // تحقق لمعرفة ما إذا كنا قد انتهينا من العد أم لا.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// مكرر حيث يستدعي كل تكرار الإغلاق المقدم `F: FnMut() -> Option<T>`.
///
/// يتم إنشاء `struct` بواسطة وظيفة [`iter::from_fn()`].
/// انظر وثائقها للمزيد.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}