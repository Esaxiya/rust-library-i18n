use crate::iter::{FusedIterator, TrustedLen};

/// ينشئ مكررًا يقوم بتوليد قيمة مرة واحدة تمامًا عن طريق استدعاء الإغلاق المقدم.
///
/// يستخدم هذا بشكل شائع لتكييف منشئ قيمة واحدة في [`chain()`] لأنواع أخرى من التكرار.
/// ربما لديك مكرر يغطي كل شيء تقريبًا ، لكنك تحتاج إلى حالة خاصة إضافية.
/// ربما لديك وظيفة تعمل على التكرارات ، لكنك تحتاج فقط إلى معالجة قيمة واحدة.
///
/// على عكس [`once()`] ، ستولد هذه الوظيفة القيمة عند الطلب بتكاسل.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// الاستخدام الأساسي:
///
/// ```
/// use std::iter;
///
/// // واحد هو الرقم الأكثر وحدة
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // واحد فقط ، هذا كل ما نحصل عليه
/// assert_eq!(None, one.next());
/// ```
///
/// التسلسل مع مكرر آخر.
/// لنفترض أننا نريد تكرار كل ملف من ملفات دليل `.foo` ، ولكن أيضًا ملف تكوين ،
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // نحتاج إلى التحويل من مكرر لـ DirEntry-s إلى مكرر لـ PathBufs ، لذلك نستخدم map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // الآن ، مكررنا فقط لملف التكوين الخاص بنا
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // اربط المكرر معًا في مكرر واحد كبير
/// let files = dirs.chain(config);
///
/// // سيعطينا هذا جميع الملفات الموجودة في .foo بالإضافة إلى .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// مكرر ينتج عنصرًا واحدًا من النوع `A` عن طريق تطبيق الإغلاق المقدم `F: FnOnce() -> A`.
///
///
/// يتم إنشاء `struct` بواسطة وظيفة [`once_with()`].
/// انظر وثائقها للمزيد.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}