#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// يمثل future حسابًا غير متزامن.
///
/// A future هي قيمة ربما لم تنته بعد من الحوسبة.
/// هذا النوع من "asynchronous value" يجعل من الممكن لمؤشر الترابط أن يستمر في القيام بعمل مفيد بينما ينتظر أن تصبح القيمة متاحة.
///
///
/// # طريقة `poll`
///
/// الأسلوب الأساسي لـ future ، `poll` ،*يحاول* حل future إلى قيمة نهائية.
/// لا يتم حظر هذه الطريقة إذا كانت القيمة غير جاهزة.
/// بدلاً من ذلك ، تمت جدولة المهمة الحالية ليتم إيقاظها عندما يكون من الممكن تحقيق مزيد من التقدم عن طريق "الاستطلاع" مرة أخرى.
/// يمكن أن يوفر `context` الذي تم تمريره إلى طريقة `poll` [`Waker`] ، وهو مقبض لإيقاظ المهمة الحالية.
///
/// عند استخدام future ، لن تتصل بشكل عام بـ `poll` مباشرة ، ولكن بدلاً من ذلك ، `.await` القيمة.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// نوع القيمة المنتجة عند الانتهاء.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// محاولة حل future إلى قيمة نهائية ، وتسجيل المهمة الحالية للتنبيه إذا لم تكن القيمة متاحة بعد.
    ///
    /// # قيمة الإرجاع
    ///
    /// ترجع هذه الوظيفة:
    ///
    /// - [`Poll::Pending`] إذا لم يكن future جاهزًا بعد
    /// - [`Poll::Ready(val)`] مع نتيجة `val` من future إذا انتهى بنجاح.
    ///
    /// بمجرد انتهاء future ، يجب على العملاء عدم `poll` مرة أخرى.
    ///
    /// عندما لا يكون future جاهزًا بعد ، تقوم `poll` بإرجاع `Poll::Pending` وتخزين نسخة من [`Waker`] منسوخة من [`Context`] الحالي.
    /// يتم بعد ذلك إيقاظ [`Waker`] بمجرد أن يتمكن future من إحراز تقدم.
    /// على سبيل المثال ، فإن future الذي ينتظر أن يصبح المقبس قابلاً للقراءة سوف يستدعي `.clone()` على [`Waker`] ويخزنه.
    /// عندما تصل إشارة إلى مكان آخر تشير إلى أن المقبس قابل للقراءة ، يتم استدعاء [`Waker::wake`] ويتم إيقاظ مهمة المقبس future.
    /// بمجرد إيقاظ المهمة ، يجب أن تحاول `poll` future مرة أخرى ، والتي قد تنتج أو لا تنتج قيمة نهائية.
    ///
    /// لاحظ أنه في المكالمات المتعددة إلى `poll` ، يجب جدولة [`Waker`] فقط من [`Context`] الذي تم تمريره إلى أحدث مكالمة لتلقي التنبيه.
    ///
    /// # خصائص وقت التشغيل
    ///
    /// Futures وحدها *خاملة*؛يجب أن يكونوا *نشطًا*`استطلاعًا` لإحراز تقدم ، مما يعني أنه في كل مرة يتم فيها إيقاظ المهمة الحالية ، يجب إعادة"تسجيل"تعليق futures الذي لا يزال مهتمًا به في كل مرة.
    ///
    /// لا يتم استدعاء وظيفة `poll` بشكل متكرر في حلقة ضيقة-بدلاً من ذلك ، يجب استدعاؤها فقط عندما تشير future إلى أنها جاهزة لإحراز تقدم (عن طريق استدعاء `wake()`).
    /// إذا كنت معتادًا على عمليات syscalls `poll(2)` أو `select(2)` على Unix ، فمن الجدير بالذكر أن futures عادةً *لا* تعاني من نفس مشكلات "all wakeups must poll all events" ؛هم أشبه بـ `epoll(4)`.
    ///
    /// يجب أن يسعى تطبيق `poll` إلى العودة بسرعة ، ويجب ألا يتم حظره.تؤدي العودة بسرعة إلى منع انسداد الخيوط أو حلقات الأحداث بلا داعٍ.
    /// إذا كان من المعروف مسبقًا أن الاتصال بـ `poll` قد يستغرق بعض الوقت ، فيجب إلغاء تحميل العمل إلى مجموعة مؤشرات الترابط (أو شيء مشابه) لضمان عودة `poll` بسرعة.
    ///
    /// # Panics
    ///
    /// بمجرد اكتمال future (تم إرجاع `Ready` من `poll`) ، قد يؤدي استدعاء طريقة `poll` مرة أخرى إلى panic أو حظره إلى الأبد أو يسبب أنواعًا أخرى من المشكلات ؛لا تضع `Future` trait أي متطلبات على تأثيرات مثل هذه المكالمة.
    /// ومع ذلك ، نظرًا لأن طريقة `poll` لم يتم وضع علامة `unsafe` عليها ، تنطبق القواعد المعتادة لـ Rust: يجب ألا تتسبب المكالمات مطلقًا في سلوك غير محدد (تلف الذاكرة ، أو الاستخدام غير الصحيح لوظائف `unsafe` ، أو ما شابه) ، بغض النظر عن حالة future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}