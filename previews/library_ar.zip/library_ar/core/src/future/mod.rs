#![stable(feature = "futures_api", since = "1.36.0")]

//! القيم غير المتزامنة.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// هذا النوع مطلوب للأسباب التالية:
///
/// أ) لا تستطيع المولدات تنفيذ `for<'a, 'b> Generator<&'a mut Context<'b>>` ، لذلك نحتاج إلى تمرير مؤشر خام (انظر <https://github.com/rust-lang/rust/issues/68923>).
///
/// ب) المؤشرات الأولية و `NonNull` ليست `Send` أو `Sync` ، لذلك من شأن ذلك أن يجعل كل future non-Send/Sync واحدًا أيضًا ، ونحن لا نريد ذلك.
///
/// كما أنه يبسط خفض HIR لـ `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// لف المولد في future.
///
/// تقوم هذه الوظيفة بإرجاع `GenFuture` تحتها ، ولكنها تخفيها في `impl Trait` لإعطاء رسائل خطأ أفضل (`impl Future` بدلاً من `GenFuture<[closure.....]>`).
///
// هذا هو `const` لتجنب الأخطاء الإضافية بعد التعافي من `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // نحن نعتمد على حقيقة أن async/await futures غير منقولة من أجل إنشاء قروض مرجعية ذاتية في المولد الأساسي.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // الأمان: آمن لأننا !Unpin + !Drop ، وهذا مجرد إسقاط ميداني.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // استأنف المولد وتحول `&mut Context` إلى مؤشر `NonNull` خام.
            // سيؤدي خفض `.await` إلى إعادة ذلك بأمان إلى `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // الأمان: يجب أن يضمن المتصل أن `cx.0` هو مؤشر صالح
    // التي تفي بجميع متطلبات مرجعية قابلة للتغيير.
    unsafe { &mut *cx.0.as_ptr().cast() }
}