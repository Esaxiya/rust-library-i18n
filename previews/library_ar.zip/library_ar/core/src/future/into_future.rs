use crate::future::Future;

/// التحويل إلى `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// الناتج الذي ستنتجه future عند اكتماله.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// أي نوع من future نحول هذا إليه؟
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// ينشئ future من قيمة.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}