#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! يحتوي على تعريفات هيكلية لتخطيط الأنواع المضمنة في المحول البرمجي.
//!
//! يمكن استخدامها كأهداف لعمليات التحويل في التعليمات البرمجية غير الآمنة لمعالجة التمثيلات الأولية مباشرة.
//!
//!
//! يجب أن يتطابق تعريفهم دائمًا مع ABI المحدد في `rustc_middle::ty::layout`.
//!

/// تمثيل كائن trait مثل `&dyn SomeTrait`.
///
/// هذا الهيكل له نفس تخطيط أنواع مثل `&dyn SomeTrait` و `Box<dyn AnotherTrait>`.
///
/// `TraitObject` مضمون لمطابقة التخطيطات ، ولكنه ليس نوع كائنات trait (على سبيل المثال ، لا يمكن الوصول إلى الحقول مباشرة على `&dyn SomeTrait`) ولا يتحكم في هذا التخطيط (لن يؤدي تغيير التعريف إلى تغيير تخطيط `&dyn SomeTrait`).
///
/// تم تصميمه فقط ليتم استخدامه بواسطة رمز غير آمن يحتاج إلى معالجة التفاصيل منخفضة المستوى.
///
/// لا توجد طريقة للإشارة إلى جميع كائنات trait بشكل عام ، لذا فإن الطريقة الوحيدة لإنشاء قيم من هذا النوع هي باستخدام وظائف مثل [`std::mem::transmute`][transmute].
/// وبالمثل ، فإن الطريقة الوحيدة لإنشاء كائن trait حقيقي من قيمة `TraitObject` هي باستخدام `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// إن تركيب كائن trait مع أنواع غير متطابقة-حيث لا يتوافق الجدول vtable مع نوع القيمة التي يشير إليها مؤشر البيانات-من المرجح أن يؤدي إلى سلوك غير محدد.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // مثال trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // دع المترجم يصنع كائن trait
/// let object: &dyn Foo = &value;
///
/// // انظر إلى التمثيل الخام
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // مؤشر البيانات هو عنوان `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // أنشئ كائنًا جديدًا ، مشيرًا إلى `i32` مختلف ، مع الحرص على استخدام `i32` vtable من `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // يجب أن يعمل كما لو كنا قد أنشأنا كائن trait من `other_value` مباشرة
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}