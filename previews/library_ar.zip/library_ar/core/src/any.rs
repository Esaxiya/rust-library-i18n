//! تطبق هذه الوحدة `Any` trait ، والتي تتيح الكتابة الديناميكية لأي نوع `'static` من خلال انعكاس وقت التشغيل.
//!
//! `Any` نفسها يمكن استخدامها للحصول على `TypeId` ، ولديها المزيد من الميزات عند استخدامها ككائن trait.
//! نظرًا لأن `&dyn Any` (كائن trait مستعار) ، فإنه يحتوي على طرق `is` و `downcast_ref` ، لاختبار ما إذا كانت القيمة المضمنة من نوع معين ، وللحصول على مرجع للقيمة الداخلية كنوع.
//! مثل `&mut dyn Any` ، هناك أيضًا طريقة `downcast_mut` ، للحصول على مرجع متغير للقيمة الداخلية.
//! `Box<dyn Any>` يضيف طريقة `downcast` ، التي تحاول التحويل إلى `Box<T>`.
//! راجع وثائق [`Box`] للحصول على التفاصيل الكاملة.
//!
//! لاحظ أن `&dyn Any` مقصور على اختبار ما إذا كانت القيمة من نوع ملموس محدد ، ولا يمكن استخدامها لاختبار ما إذا كان النوع يطبق trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # المؤشرات الذكية و `dyn Any`
//!
//! أحد السلوكيات التي يجب مراعاتها عند استخدام `Any` ككائن trait ، خاصة مع أنواع مثل `Box<dyn Any>` أو `Arc<dyn Any>` ، هو أن مجرد استدعاء `.type_id()` على القيمة سينتج `TypeId` للحاوية * ، وليس كائن trait الأساسي.
//!
//! يمكن تجنب ذلك عن طريق تحويل المؤشر الذكي إلى `&dyn Any` بدلاً من ذلك ، والذي سيعيد `TypeId` للكائن.
//! على سبيل المثال:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // من المرجح أنك تريد هذا:
//! let actual_id = (&*boxed).type_id();
//! // ... من هذا:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! ضع في اعتبارك موقفًا نريد فيه تسجيل الخروج من قيمة تم تمريرها إلى دالة.
//! نحن نعلم القيمة التي نعمل عليها في تنفيذ Debug ، لكننا لا نعرف نوعه الملموس.نريد أن نعطي معاملة خاصة لأنواع معينة: في هذه الحالة نطبع طول قيم السلسلة قبل قيمتها.
//! لا نعرف النوع الملموس لقيمتنا في وقت التجميع ، لذلك نحتاج إلى استخدام انعكاس وقت التشغيل بدلاً من ذلك.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // وظيفة المسجل لأي نوع يقوم بتنفيذ التصحيح.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // حاول تحويل قيمتنا إلى `String`.
//!     // إذا نجحت ، فنحن نريد إخراج طول السلسلة بالإضافة إلى قيمتها.
//!     // إذا لم يكن الأمر كذلك ، فهو نوع مختلف: فقط اطبعه بدون زخرفة.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // تريد هذه الوظيفة تسجيل خروج المعلمة الخاصة بها قبل العمل معها.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... القيام ببعض الأعمال الأخرى
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// أي trait
///////////////////////////////////////////////////////////////////////////////

/// trait لمحاكاة الكتابة الديناميكية.
///
/// معظم الأنواع تنفذ `Any`.ومع ذلك ، فإن أي نوع يحتوي على مرجع غير "ثابت" لا يحتوي على هذا المرجع.
/// انظر [module-level documentation][mod] لمزيد من التفاصيل.
///
/// [mod]: crate::any
// trait هذا ليس غير آمن ، على الرغم من أننا نعتمد على تفاصيل وظيفة `type_id` الخاصة ببرنامجها الوحيد في كود غير آمن (على سبيل المثال ، `downcast`).عادة ، قد تكون هذه مشكلة ، ولكن نظرًا لأن الضمانة الوحيدة لـ `Any` هي تطبيق شامل ، فلا يوجد رمز آخر يمكنه تنفيذ `Any`.
//
// يمكننا أن نجعل trait غير آمن بشكل معقول-لن يتسبب ذلك في حدوث كسر ، لأننا نتحكم في جميع التطبيقات-لكننا نختار عدم القيام بذلك لأن هذا ليس ضروريًا حقًا وقد يربك المستخدمين حول التمييز بين traits غير الآمنة والطرق غير الآمنة (على سبيل المثال ، سيظل الاتصال بـ `type_id` آمنًا ، ولكن من المحتمل أن نشير إلى ذلك في الوثائق).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// يحصل على `TypeId` من `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// طرق الامتداد لأي كائنات trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// تأكد من أنه يمكن طباعة نتيجة ، على سبيل المثال ، الانضمام إلى خيط ومن ثم استخدامها مع `unwrap`.
// قد لا تكون هناك حاجة في النهاية إذا كان الإرسال يعمل مع التنبيه.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// تُرجع `true` إذا كان النوع المعبأ هو نفسه `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // احصل على `TypeId` من النوع الذي يتم إنشاء هذه الوظيفة به.
        let t = TypeId::of::<T>();

        // احصل على `TypeId` من النوع الموجود في كائن trait (`self`).
        let concrete = self.type_id();

        // قارن بين "TypeId" على قدم المساواة.
        t == concrete
    }

    /// تُرجع بعض المراجع إلى القيمة المعبأة إذا كانت من النوع `T` أو `None` إذا لم تكن كذلك.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // الأمان: تحقق فقط مما إذا كنا نشير إلى النوع الصحيح ، ويمكننا الاعتماد عليه
            // التي تتحقق من سلامة الذاكرة لأننا قمنا بتنفيذ أي لجميع الأنواع ؛لا توجد إشارات أخرى يمكن أن توجد لأنها قد تتعارض مع ضمنيتنا.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// تُرجع بعض المراجع القابلة للتغيير إلى القيمة المعبأة إذا كانت من النوع `T` أو `None` إذا لم تكن كذلك.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // الأمان: تحقق فقط مما إذا كنا نشير إلى النوع الصحيح ، ويمكننا الاعتماد عليه
            // التي تتحقق من سلامة الذاكرة لأننا قمنا بتنفيذ أي لجميع الأنواع ؛لا توجد إشارات أخرى يمكن أن توجد لأنها قد تتعارض مع ضمنيتنا.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// يعيد التوجيه إلى الطريقة المحددة في النوع `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// يعيد التوجيه إلى الطريقة المحددة في النوع `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// يعيد التوجيه إلى الطريقة المحددة في النوع `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// يعيد التوجيه إلى الطريقة المحددة في النوع `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// يعيد التوجيه إلى الطريقة المحددة في النوع `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// يعيد التوجيه إلى الطريقة المحددة في النوع `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID وطرقه
///////////////////////////////////////////////////////////////////////////////

/// يمثل `TypeId` معرّفًا فريدًا عالميًا للنوع.
///
/// كل `TypeId` عبارة عن كائن معتم لا يسمح بفحص ما بداخله ولكنه يسمح بالعمليات الأساسية مثل الاستنساخ والمقارنة والطباعة والعرض.
///
///
/// يتوفر `TypeId` حاليًا فقط للأنواع التي تنسب إلى `'static` ، ولكن يمكن إزالة هذا القيد في future.
///
/// بينما يقوم `TypeId` بتنفيذ `Hash` و `PartialOrd` و `Ord` ، تجدر الإشارة إلى أن التجزئة والطلب ستختلف بين إصدارات Rust.
/// احذر من الاعتماد عليها داخل الكود الخاص بك!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// تُرجع `TypeId` من النوع الذي تم إنشاء مثيل له لهذه الوظيفة العامة.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// تُرجع اسم النوع على هيئة شريحة سلسلة.
///
/// # Note
///
/// هذا مخصص للاستخدام التشخيصي.
/// لم يتم تحديد المحتويات والصيغة الدقيقة للسلسلة التي تم إرجاعها ، بخلاف كونها وصفًا لأفضل مجهود للنوع.
/// على سبيل المثال ، من بين السلاسل التي قد تعرضها `type_name::<Option<String>>()` هي `"Option<String>"` و `"std::option::Option<std::string::String>"`.
///
///
/// يجب ألا تعتبر السلسلة التي تم إرجاعها معرفًا فريدًا للنوع حيث قد يتم تعيين أنواع متعددة إلى نفس اسم النوع.
/// وبالمثل ، لا يوجد ضمان بأن جميع أجزاء نوع ما ستظهر في السلسلة التي تم إرجاعها: على سبيل المثال ، محددات العمر غير مدرجة حاليًا.
/// بالإضافة إلى ذلك ، قد يتغير الإخراج بين إصدارات المترجم.
///
/// يستخدم التنفيذ الحالي نفس البنية الأساسية مثل تشخيصات المترجم ومعلومات التصحيح ، ولكن هذا غير مضمون.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// إرجاع اسم نوع القيمة المشار إليها كشريحة سلسلة.
/// هذا هو نفسه `type_name::<T>()` ، ولكن يمكن استخدامه حيث لا يتوفر نوع المتغير بسهولة.
///
/// # Note
///
/// هذا مخصص للاستخدام التشخيصي.لم يتم تحديد محتويات وتنسيق السلسلة بالضبط ، بخلاف وصف أفضل جهد للنوع.
/// على سبيل المثال ، يمكن لـ `type_name_of_val::<Option<String>>(None)` إرجاع `"Option<String>"` أو `"std::option::Option<std::string::String>"` ، ولكن ليس `"foobar"`.
///
/// بالإضافة إلى ذلك ، قد يتغير الإخراج بين إصدارات المترجم.
///
/// هذه الوظيفة لا تحل كائنات trait ، مما يعني أن `type_name_of_val(&7u32 as &dyn Debug)` قد ترجع `"dyn Debug"` ، ولكن ليس `"u32"`.
///
/// لا ينبغي اعتبار اسم النوع معرفًا فريدًا للنوع ؛
/// قد تشترك أنواع متعددة في نفس اسم النوع.
///
/// يستخدم التنفيذ الحالي نفس البنية الأساسية مثل تشخيصات المترجم ومعلومات التصحيح ، ولكن هذا غير مضمون.
///
/// # Examples
///
/// يطبع عدد صحيح وأنواع عدد عشري افتراضي.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}