#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // يتم توسيعه إلى `$crate::panic::panic_2015` أو `$crate::panic::panic_2021` اعتمادًا على إصدار المتصل.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// يؤكد أن تعبيرين متساويين (باستخدام [`PartialEq`]).
///
/// في panic ، سيقوم هذا الماكرو بطباعة قيم التعبيرات مع تمثيلات التصحيح الخاصة بهم.
///
///
/// مثل [`assert!`] ، يحتوي هذا الماكرو على نموذج ثانٍ ، حيث يمكن توفير رسالة panic مخصصة.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // عمليات إعادة الاقتراض أدناه مقصودة.
                    // بدونها ، يتم تهيئة فتحة المكدس الخاصة بالاقتراض حتى قبل مقارنة القيم ، مما يؤدي إلى تباطؤ ملحوظ.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // عمليات إعادة الاقتراض أدناه مقصودة.
                    // بدونها ، يتم تهيئة فتحة المكدس الخاصة بالاقتراض حتى قبل مقارنة القيم ، مما يؤدي إلى تباطؤ ملحوظ.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// يؤكد عدم تساوي تعبيرين (باستخدام [`PartialEq`]).
///
/// في panic ، سيقوم هذا الماكرو بطباعة قيم التعبيرات مع تمثيلات التصحيح الخاصة بهم.
///
///
/// مثل [`assert!`] ، يحتوي هذا الماكرو على نموذج ثانٍ ، حيث يمكن توفير رسالة panic مخصصة.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // عمليات إعادة الاقتراض أدناه مقصودة.
                    // بدونها ، يتم تهيئة فتحة المكدس الخاصة بالاقتراض حتى قبل مقارنة القيم ، مما يؤدي إلى تباطؤ ملحوظ.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // عمليات إعادة الاقتراض أدناه مقصودة.
                    // بدونها ، يتم تهيئة فتحة المكدس الخاصة بالاقتراض حتى قبل مقارنة القيم ، مما يؤدي إلى تباطؤ ملحوظ.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// يؤكد أن التعبير المنطقي هو `true` في وقت التشغيل.
///
/// سيؤدي هذا إلى استدعاء ماكرو [`panic!`] إذا كان التعبير المقدم لا يمكن تقييمه إلى `true` في وقت التشغيل.
///
/// مثل [`assert!`] ، يحتوي هذا الماكرو أيضًا على إصدار ثانٍ ، حيث يمكن توفير رسالة panic مخصصة.
///
/// # Uses
///
/// على عكس [`assert!`] ، يتم تمكين عبارات `debug_assert!` فقط في الإنشاءات غير المحسّنة افتراضيًا.
/// لن يقوم البناء المحسن بتنفيذ عبارات `debug_assert!` ما لم يتم تمرير `-C debug-assertions` إلى المترجم.
/// هذا يجعل `debug_assert!` مفيدًا لعمليات التحقق التي تكون باهظة الثمن للغاية بحيث لا يمكن أن تكون موجودة في إصدار الإصدار ولكنها قد تكون مفيدة أثناء التطوير.
/// يتم دائمًا فحص نتيجة توسيع `debug_assert!`.
///
/// يسمح التأكيد غير المدقق لبرنامج في حالة غير متسقة بالاستمرار في العمل ، مما قد يكون له عواقب غير متوقعة ولكنه لا يؤدي إلى عدم الأمان طالما أن هذا يحدث فقط في رمز آمن.
///
/// ومع ذلك ، فإن تكلفة أداء التأكيدات لا يمكن قياسها بشكل عام.
/// لذلك لا يتم تشجيع استبدال [`assert!`] بـ `debug_assert!` إلا بعد التنميط الشامل ، والأهم من ذلك ، فقط في كود آمن!
///
/// # Examples
///
/// ```
/// // الرسالة panic لهذه التأكيدات هي القيمة المشددة للتعبير المعطى.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // وظيفة بسيطة للغاية
/// debug_assert!(some_expensive_computation());
///
/// // التأكيد برسالة مخصصة
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// يؤكد أن تعبيرين متساويين.
///
/// في panic ، سيقوم هذا الماكرو بطباعة قيم التعبيرات مع تمثيلات التصحيح الخاصة بهم.
///
/// على عكس [`assert_eq!`] ، يتم تمكين عبارات `debug_assert_eq!` فقط في الإنشاءات غير المحسّنة افتراضيًا.
/// لن يقوم البناء المحسن بتنفيذ عبارات `debug_assert_eq!` ما لم يتم تمرير `-C debug-assertions` إلى المترجم.
/// هذا يجعل `debug_assert_eq!` مفيدًا لعمليات التحقق التي تكون باهظة الثمن للغاية بحيث لا يمكن أن تكون موجودة في إصدار الإصدار ولكنها قد تكون مفيدة أثناء التطوير.
///
/// يتم دائمًا فحص نتيجة توسيع `debug_assert_eq!`.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// يؤكد عدم تساوي تعبيرين.
///
/// في panic ، سيقوم هذا الماكرو بطباعة قيم التعبيرات مع تمثيلات التصحيح الخاصة بهم.
///
/// على عكس [`assert_ne!`] ، يتم تمكين عبارات `debug_assert_ne!` فقط في الإنشاءات غير المحسّنة افتراضيًا.
/// لن يقوم البناء المحسن بتنفيذ عبارات `debug_assert_ne!` ما لم يتم تمرير `-C debug-assertions` إلى المترجم.
/// هذا يجعل `debug_assert_ne!` مفيدًا لعمليات التحقق التي تكون باهظة الثمن للغاية بحيث لا يمكن أن تكون موجودة في إصدار الإصدار ولكنها قد تكون مفيدة أثناء التطوير.
///
/// يتم دائمًا فحص نتيجة توسيع `debug_assert_ne!`.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// تُرجع ما إذا كان التعبير المحدد يطابق أيًا من الأنماط المحددة.
///
/// كما هو الحال في تعبير `match` ، يمكن أن يتبع النمط اختياريًا `if` وتعبير حارس له حق الوصول إلى الأسماء المرتبطة بالنمط.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// يكشف نتيجة أو ينشر خطأها.
///
/// تمت إضافة عامل التشغيل `?` ليحل محل `try!` ويجب استخدامه بدلاً من ذلك.
/// علاوة على ذلك ، `try` هي كلمة محجوزة في Rust 2018 ، لذلك إذا كان يجب عليك استخدامها ، فستحتاج إلى استخدام [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` يطابق [`Result`] المحدد.في حالة المتغير `Ok` ، يكون للتعبير قيمة القيمة المغلفة.
///
/// في حالة المتغير `Err` ، يقوم باسترداد الخطأ الداخلي.ثم يقوم `try!` بإجراء التحويل باستخدام `From`.
/// يوفر هذا التحويل التلقائي بين الأخطاء المتخصصة والأخطاء العامة.
/// ثم يتم إرجاع الخطأ الناتج على الفور.
///
/// نظرًا للإرجاع المبكر ، لا يمكن استخدام `try!` إلا في الوظائف التي تُرجع [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // الطريقة المفضلة للإرجاع السريع للأخطاء
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // الطريقة السابقة للإرجاع السريع للأخطاء
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // هذا يعادل:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// يكتب البيانات المنسقة في مخزن مؤقت.
///
/// يقبل هذا الماكرو 'writer' وسلسلة تنسيق وقائمة من الوسائط.
/// سيتم تنسيق الوسائط وفقًا لسلسلة التنسيق المحددة وسيتم تمرير النتيجة إلى الكاتب.
/// قد يكون الكاتب أي قيمة باستخدام طريقة `write_fmt` ؛يأتي هذا بشكل عام من تنفيذ إما [`fmt::Write`] أو [`io::Write`] trait.
/// يقوم الماكرو بإرجاع كل ما ترجعه طريقة `write_fmt` ؛عادة [`fmt::Result`] ، أو [`io::Result`].
///
/// راجع [`std::fmt`] للحصول على مزيد من المعلومات حول بناء جملة سلسلة التنسيق.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// يمكن للوحدة أن تستورد كلاً من `std::fmt::Write` و `std::io::Write` وتستدعي `write!` على كائنات تنفذ أيًا منهما ، لأن الكائنات لا تطبق كليهما عادةً.
///
/// ومع ذلك ، يجب أن تستورد الوحدة النمطية traits المؤهلة حتى لا تتعارض أسماؤها:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // يستخدم fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // يستخدم io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: يمكن استخدام هذا الماكرو في إعدادات `no_std` أيضًا.
/// في إعداد `no_std` ، تكون مسؤولاً عن تفاصيل تنفيذ المكونات.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// اكتب البيانات المنسقة في مخزن مؤقت ، مع إلحاق سطر جديد.
///
/// على جميع الأنظمة الأساسية ، يكون السطر الجديد هو حرف LINE FEED (`\n`/`U+000A`) وحده (لا يوجد CARRIAGE RETURN (`\r`/`U+000D`) إضافي.
///
/// لمزيد من المعلومات ، راجع [`write!`].للحصول على معلومات حول بناء جملة سلسلة التنسيق ، راجع [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// يمكن للوحدة أن تستورد كلاً من `std::fmt::Write` و `std::io::Write` وتستدعي `write!` على كائنات تنفذ أيًا منهما ، لأن الكائنات لا تطبق كليهما عادةً.
/// ومع ذلك ، يجب أن تستورد الوحدة النمطية traits المؤهلة حتى لا تتعارض أسماؤها:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // يستخدم fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // يستخدم io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// يشير إلى رمز لا يمكن الوصول إليه.
///
/// هذا مفيد في أي وقت لا يستطيع فيه المترجم تحديد أن بعض التعليمات البرمجية لا يمكن الوصول إليها.على سبيل المثال:
///
/// * تطابق الأسلحة مع ظروف الحراسة.
/// * الحلقات التي تنتهي ديناميكيًا.
/// * التكرارات التي تنتهي ديناميكيًا.
///
/// إذا ثبت أن تحديد أن الشفرة غير قابلة للوصول غير صحيح ، فسينتهي البرنامج فورًا باستخدام [`panic!`].
///
/// النظير غير الآمن لهذا الماكرو هو دالة [`unreachable_unchecked`] ، والتي ستؤدي إلى سلوك غير محدد إذا تم الوصول إلى الرمز.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// سيكون هذا دائمًا [`panic!`].
///
/// # Examples
///
/// أسلحة المباراة:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // تجميع خطأ إذا علق بها
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // أحد أفقر تطبيقات x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// يشير إلى رمز لم يتم تنفيذه عن طريق الذعر برسالة "not implemented".
///
/// يسمح هذا للكود الخاص بك بالتحقق من الكتابة ، وهو أمر مفيد إذا كنت تقوم بإنشاء نماذج أولية أو تنفيذ trait الذي يتطلب طرقًا متعددة لا تخطط لاستخدامها كلها.
///
/// الفرق بين `unimplemented!` و [`todo!`] هو أنه بينما ينقل `todo!` نية تنفيذ الوظيفة لاحقًا والرسالة هي "not yet implemented" ، لا يقدم `unimplemented!` مثل هذه الادعاءات.
/// رسالتها هي "not implemented".
/// كما ستحدد بعض IDEs علامة `` todo! 's.
///
/// # Panics
///
/// سيكون هذا دائمًا [`panic!`] لأن `unimplemented!` هو مجرد اختصار لـ `panic!` برسالة ثابتة ومحددة.
///
/// مثل `panic!` ، يحتوي هذا الماكرو على نموذج ثانٍ لعرض القيم المخصصة.
///
/// # Examples
///
/// لنفترض أن لدينا trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// نريد تنفيذ `Foo` لـ 'MyStruct' ، لكن لسبب ما يكون من المنطقي فقط تنفيذ وظيفة `bar()`.
/// `baz()` سيظل `qux()` بحاجة إلى التحديد في تطبيقنا لـ `Foo` ، لكن يمكننا استخدام `unimplemented!` في تعريفاتهم للسماح بتجميع الكود الخاص بنا.
///
/// ما زلنا نرغب في إيقاف تشغيل برنامجنا إذا تم الوصول إلى الأساليب غير المطبقة.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // لا معنى لـ `baz` a `MyStruct` ، لذلك ليس لدينا منطق هنا على الإطلاق.
/////
///         // سيعرض هذا "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // لدينا بعض المنطق هنا ، يمكننا إضافة رسالة إلى عدم التنفيذ!لعرض إغفالنا.
///         // سيعرض هذا: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// يشير إلى رمز غير مكتمل.
///
/// يمكن أن يكون هذا مفيدًا إذا كنت تقوم بعمل نماذج أولية وتتطلع فقط إلى فحص نوع الرمز الخاص بك.
///
/// الفرق بين [`unimplemented!`] و `todo!` هو أنه بينما ينقل `todo!` نية تنفيذ الوظيفة لاحقًا والرسالة هي "not yet implemented" ، لا يقدم `unimplemented!` مثل هذه الادعاءات.
/// رسالتها هي "not implemented".
/// كما ستحدد بعض IDEs علامة `` todo! 's.
///
/// # Panics
///
/// سيكون هذا دائمًا [`panic!`].
///
/// # Examples
///
/// فيما يلي مثال على بعض التعليمات البرمجية قيد التقدم.لدينا trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// نريد تطبيق `Foo` على أحد أنواعنا ، لكننا نريد أيضًا العمل على `bar()` فقط أولاً.لكي يتم تجميع الكود الخاص بنا ، نحتاج إلى تنفيذ `baz()` ، حتى نتمكن من استخدام `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // التنفيذ يذهب هنا
///     }
///
///     fn baz(&self) {
///         // دعنا لا نقلق بشأن تنفيذ baz() في الوقت الحالي
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // نحن لا نستخدم baz() حتى ، لذلك هذا جيد.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// تعريفات وحدات الماكرو المضمنة.
///
/// يتم أخذ معظم خصائص الماكرو (الاستقرار والرؤية وما إلى ذلك) من التعليمات البرمجية المصدر هنا ، باستثناء وظائف التوسيع التي تحول مدخلات الماكرو إلى مخرجات ، يتم توفير هذه الوظائف بواسطة المترجم.
///
///
pub(crate) mod builtin {

    /// يؤدي إلى فشل التحويل البرمجي مع ظهور رسالة الخطأ المقدمة عند مواجهتها.
    ///
    /// يجب استخدام هذا الماكرو عندما يستخدم crate استراتيجية ترجمة شرطية لتقديم رسائل خطأ أفضل للحالات الخاطئة.
    ///
    /// إنه شكل [`panic!`] على مستوى المترجم ، ولكنه يصدر خطأ أثناء *التحويل البرمجي* بدلاً من *وقت التشغيل*.
    ///
    /// # Examples
    ///
    /// اثنان من هذه الأمثلة هما وحدات الماكرو وبيئات `#[cfg]`.
    ///
    /// إرسال خطأ مترجم أفضل إذا تم تمرير ماكرو قيم غير صالحة.
    /// بدون branch النهائي ، سيظل المترجم يرسل خطأ ، لكن رسالة الخطأ لن تذكر القيمتين الصالحتين.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// انبعث خطأ في المترجم إذا كانت إحدى الميزات غير متوفرة.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// إنشاء معلمات لوحدات الماكرو الأخرى لتنسيق السلسلة.
    ///
    /// يعمل هذا الماكرو عن طريق أخذ سلسلة تنسيق حرفية تحتوي على `{}` لكل وسيطة إضافية تم تمريرها.
    /// `format_args!` تعد المعلمات الإضافية لضمان إمكانية تفسير الإخراج كسلسلة وتوحيد الوسائط في نوع واحد.
    /// يمكن تمرير أي قيمة تنفذ [`Display`] trait إلى `format_args!` ، كما يمكن تمرير أي تطبيق [`Debug`] إلى `{:?}` ضمن سلسلة التنسيق.
    ///
    ///
    /// ينتج عن هذا الماكرو قيمة من النوع [`fmt::Arguments`].يمكن تمرير هذه القيمة إلى وحدات الماكرو داخل [`std::fmt`] لإجراء إعادة توجيه مفيدة.
    /// جميع وحدات ماكرو التنسيق الأخرى ([`format!`] ، [`write!`] ، [`println!`] ، إلخ) يتم تمثيلها بالوكيل من خلال هذا.
    /// `format_args!`, على عكس وحدات الماكرو المشتقة ، يتجنب عمليات تخصيص الكومة.
    ///
    /// يمكنك استخدام قيمة [`fmt::Arguments`] التي تعرضها `format_args!` في سياقات `Debug` و `Display` كما هو موضح أدناه.
    /// يوضح المثال أيضًا أن تنسيق `Debug` و `Display` لنفس الشيء: سلسلة التنسيق المحرف في `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// لمزيد من المعلومات ، راجع الوثائق في [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// مثل `format_args` ، لكنه يضيف سطرًا جديدًا في النهاية.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// يفحص متغير البيئة في وقت الترجمة.
    ///
    /// سيتم توسيع هذا الماكرو إلى قيمة متغير البيئة المسمى في وقت الترجمة ، مما ينتج عنه تعبير من النوع `&'static str`.
    ///
    ///
    /// إذا لم يتم تعريف متغير البيئة ، فسيتم إصدار خطأ تجميع.
    /// لعدم إرسال خطأ ترجمة ، استخدم الماكرو [`option_env!`] بدلاً من ذلك.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// يمكنك تخصيص رسالة الخطأ بتمرير سلسلة كمعامل ثاني:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// إذا لم يتم تعريف متغير البيئة `documentation` ، فستتلقى الخطأ التالي:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// يتفقد بشكل اختياري متغير البيئة في وقت الترجمة.
    ///
    /// إذا كان متغير البيئة المسمى موجودًا في وقت الترجمة ، فسيتم توسيعه إلى تعبير من النوع `Option<&'static str>` الذي تبلغ قيمته `Some` من قيمة متغير البيئة.
    /// إذا لم يكن متغير البيئة موجودًا ، فسيتم توسيعه إلى `None`.
    /// راجع [`Option<T>`][Option] لمزيد من المعلومات حول هذا النوع.
    ///
    /// لا يتم إطلاق خطأ وقت الترجمة عند استخدام هذا الماكرو بغض النظر عما إذا كان متغير البيئة موجودًا أم لا.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// تسلسل المعرفات في معرف واحد.
    ///
    /// يأخذ هذا الماكرو أي عدد من المعرفات المفصولة بفواصل ، ويجمعها جميعًا في واحد ، مما ينتج عنه تعبير يمثل معرّفًا جديدًا.
    /// لاحظ أن النظافة تجعلها بحيث لا يمكن لهذا الماكرو التقاط المتغيرات المحلية.
    /// أيضًا ، كقاعدة عامة ، لا يُسمح بوحدات الماكرو إلا في موضع العنصر أو العبارة أو التعبير.
    /// هذا يعني أنه بينما يمكنك استخدام هذا الماكرو للإشارة إلى المتغيرات أو الوظائف أو الوحدات النمطية الموجودة وما إلى ذلك ، لا يمكنك تحديد متغير جديد به.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (جديد ، مرح ، اسم) { }//غير قابل للاستخدام بهذه الطريقة!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// تسلسل العناصر الحرفية في شريحة سلسلة ثابتة.
    ///
    /// يأخذ هذا الماكرو أي عدد من القيم الحرفية المفصولة بفواصل ، مما ينتج عنه تعبير من النوع `&'static str` والذي يمثل جميع القيم الحرفية المتسلسلة من اليسار إلى اليمين.
    ///
    ///
    /// يتم ترتيب القيم الحرفية الصحيحة والنقطة العائمة من أجل أن تكون متسلسلة.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// يوسع إلى رقم السطر الذي تم استدعاءه فيه.
    ///
    /// مع [`column!`] و [`file!`] ، توفر وحدات الماكرو هذه معلومات تصحيح الأخطاء للمطورين حول الموقع داخل المصدر.
    ///
    /// يحتوي التعبير الموسع على النوع `u32` وهو مستند إلى 1 ، لذلك يتم تقييم السطر الأول في كل ملف إلى 1 ، والثاني إلى 2 ، إلخ.
    /// هذا يتفق مع رسائل الخطأ من قبل المجمعين المشتركين أو المحررين المشهورين
    /// السطر الذي تم إرجاعه *ليس بالضرورة* خط استدعاء `line!` نفسه ، بل هو أول استدعاء ماكرو يؤدي إلى استدعاء الماكرو `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// يوسع إلى رقم العمود الذي تم استدعاءه عنده.
    ///
    /// مع [`line!`] و [`file!`] ، توفر وحدات الماكرو هذه معلومات تصحيح الأخطاء للمطورين حول الموقع داخل المصدر.
    ///
    /// يحتوي التعبير الموسع على النوع `u32` وهو مستند إلى 1 ، لذلك يتم تقييم العمود الأول في كل سطر إلى 1 ، والثاني إلى 2 ، إلخ.
    /// هذا يتفق مع رسائل الخطأ من قبل المجمعين المشتركين أو المحررين المشهورين
    /// العمود الذي تم إرجاعه *ليس بالضرورة* سطر استدعاء `column!` نفسه ، بل هو أول استدعاء ماكرو يؤدي إلى استدعاء الماكرو `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// يمتد إلى اسم الملف الذي تم استدعاءه فيه.
    ///
    /// مع [`line!`] و [`column!`] ، توفر وحدات الماكرو هذه معلومات تصحيح الأخطاء للمطورين حول الموقع داخل المصدر.
    ///
    /// يحتوي التعبير الموسع على النوع `&'static str` ، والملف الذي تم إرجاعه ليس استدعاء الماكرو `file!` نفسه ، بل هو استدعاء الماكرو الأول الذي أدى إلى استدعاء الماكرو `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// يؤكد حججه.
    ///
    /// سينتج عن هذا الماكرو تعبير من النوع `&'static str` وهو تشديد جميع tokens التي تم تمريرها إلى الماكرو.
    /// لم يتم وضع قيود على بناء جملة استدعاء الماكرو نفسه.
    ///
    /// لاحظ أن النتائج الموسعة للمدخلات tokens قد تتغير في future.يجب أن تكون حذرًا إذا كنت تعتمد على الإخراج.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// يتضمن ملف UTF-8 مشفر كسلسلة.
    ///
    /// يوجد الملف بالنسبة إلى الملف الحالي (بشكل مشابه لكيفية العثور على الوحدات النمطية).
    /// يتم تفسير المسار المقدم بطريقة خاصة بالنظام الأساسي في وقت الترجمة.
    /// لذلك ، على سبيل المثال ، استدعاء بمسار Windows يحتوي على خطوط مائلة عكسية `\` لن يتم تجميعه بشكل صحيح على Unix.
    ///
    ///
    /// سينتج عن هذا الماكرو تعبير من النوع `&'static str` وهو محتويات الملف.
    ///
    /// # Examples
    ///
    /// افترض أن هناك ملفين في نفس الدليل بالمحتويات التالية:
    ///
    /// ملف 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// ملف 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// سيؤدي تجميع 'main.rs' وتشغيل الثنائي الناتج إلى طباعة "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// يتضمن ملفًا كمرجع إلى صفيف بايت.
    ///
    /// يوجد الملف بالنسبة إلى الملف الحالي (بشكل مشابه لكيفية العثور على الوحدات النمطية).
    /// يتم تفسير المسار المقدم بطريقة خاصة بالنظام الأساسي في وقت الترجمة.
    /// لذلك ، على سبيل المثال ، استدعاء بمسار Windows يحتوي على خطوط مائلة عكسية `\` لن يتم تجميعه بشكل صحيح على Unix.
    ///
    ///
    /// سينتج عن هذا الماكرو تعبير من النوع `&'static [u8; N]` وهو محتويات الملف.
    ///
    /// # Examples
    ///
    /// افترض أن هناك ملفين في نفس الدليل بالمحتويات التالية:
    ///
    /// ملف 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// ملف 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// سيؤدي تجميع 'main.rs' وتشغيل الثنائي الناتج إلى طباعة "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// يمتد إلى سلسلة تمثل مسار الوحدة النمطية الحالي.
    ///
    /// يمكن اعتبار مسار الوحدة الحالية بمثابة التسلسل الهرمي للوحدات التي تؤدي إلى الرجوع إلى crate root.
    /// المكون الأول للمسار الذي تم إرجاعه هو اسم crate الذي يتم تجميعه حاليًا.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// يقوم بتقييم المجموعات المنطقية لعلامات التكوين في وقت الترجمة.
    ///
    /// بالإضافة إلى السمة `#[cfg]` ، يتم توفير هذا الماكرو للسماح بتقييم التعبير المنطقي لعلامات التكوين.
    /// هذا يؤدي في كثير من الأحيان إلى رمز أقل تكرار.
    ///
    /// بناء الجملة المعطى لهذا الماكرو هو نفس بناء جملة السمة [`cfg`].
    ///
    /// `cfg!`, على عكس `#[cfg]` ، لا يزيل أي رمز ويتم تقييمه فقط إلى صواب أو خطأ.
    /// على سبيل المثال ، يجب أن تكون جميع الكتل في تعبير if/else صالحة عند استخدام `cfg!` للشرط ، بصرف النظر عن تقييم `cfg!`.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// يوزع ملف كتعبير أو عنصر وفقًا للسياق.
    ///
    /// يوجد الملف بالنسبة إلى الملف الحالي (بشكل مشابه لكيفية العثور على الوحدات النمطية).يتم تفسير المسار المقدم بطريقة خاصة بالنظام الأساسي في وقت الترجمة.
    /// لذلك ، على سبيل المثال ، استدعاء بمسار Windows يحتوي على خطوط مائلة عكسية `\` لن يتم تجميعه بشكل صحيح على Unix.
    ///
    /// غالبًا ما يكون استخدام هذا الماكرو فكرة سيئة ، لأنه إذا تم تحليل الملف كتعبير ، فسيتم وضعه في الكود المحيط بطريقة غير صحية.
    /// قد يؤدي ذلك إلى اختلاف المتغيرات أو الوظائف عما يتوقعه الملف إذا كانت هناك متغيرات أو وظائف لها نفس الاسم في الملف الحالي.
    ///
    ///
    /// # Examples
    ///
    /// افترض أن هناك ملفين في نفس الدليل بالمحتويات التالية:
    ///
    /// ملف 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// ملف 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// سيؤدي تجميع 'main.rs' وتشغيل الثنائي الناتج إلى طباعة "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// يؤكد أن التعبير المنطقي هو `true` في وقت التشغيل.
    ///
    /// سيؤدي هذا إلى استدعاء ماكرو [`panic!`] إذا كان التعبير المقدم لا يمكن تقييمه إلى `true` في وقت التشغيل.
    ///
    /// # Uses
    ///
    /// يتم التحقق من التأكيدات دائمًا في كل من إصدارات التصحيح والإصدار ، ولا يمكن تعطيلها.
    /// راجع [`debug_assert!`] للتأكيدات التي لم يتم تمكينها في إصدارات الإصدارات افتراضيًا.
    ///
    /// قد تعتمد التعليمات البرمجية غير الآمنة على `assert!` لفرض ثوابت وقت التشغيل التي ، في حالة انتهاكها ، قد تؤدي إلى عدم الأمان.
    ///
    /// تتضمن حالات الاستخدام الأخرى لـ `assert!` اختبار وفرض ثوابت وقت التشغيل في رمز آمن (لا يمكن أن يؤدي انتهاكها إلى عدم الأمان).
    ///
    ///
    /// # الرسائل المخصصة
    ///
    /// يحتوي هذا الماكرو على نموذج ثانٍ ، حيث يمكن توفير رسالة panic مخصصة مع أو بدون وسيطات للتنسيق.
    /// راجع [`std::fmt`] للحصول على بناء الجملة لهذا النموذج.
    /// سيتم تقييم التعبيرات المستخدمة كوسيطات تنسيق فقط في حالة فشل التأكيد.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // الرسالة panic لهذه التأكيدات هي القيمة المشددة للتعبير المعطى.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // وظيفة بسيطة للغاية
    ///
    /// assert!(some_computation());
    ///
    /// // التأكيد برسالة مخصصة
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// التجميع المضمن.
    ///
    /// اقرأ [unstable book] لمعرفة الاستخدام.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// الجمعية المضمنة على غرار LLVM.
    ///
    /// اقرأ [unstable book] لمعرفة الاستخدام.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// التجميع المضمن على مستوى الوحدة النمطية.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// مرت المطبوعات tokens في الإخراج القياسي.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// تمكين أو تعطيل وظيفة التتبع المستخدمة لتصحيح أخطاء وحدات الماكرو الأخرى.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// ماكرو السمة المستخدم لتطبيق اشتقاق وحدات الماكرو.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// تم تطبيق ماكرو السمة على دالة لتحويلها إلى اختبار وحدة.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// تم تطبيق ماكرو السمة على دالة لتحويلها إلى اختبار معياري.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// تفاصيل تنفيذ لوحدات الماكرو `#[test]` و `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// تم تطبيق ماكرو السمة على ثابت لتسجيله كمخصص عالمي.
    ///
    /// راجع أيضًا [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// يحتفظ بالعنصر الذي يتم تطبيقه عليه إذا كان المسار الذي تم تمريره يمكن الوصول إليه ، ويزيله بخلاف ذلك.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// يوسع كل سمات `#[cfg]` و `#[cfg_attr]` في جزء التعليمات البرمجية التي يتم تطبيقها عليه.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// تفاصيل التنفيذ غير المستقرة للمترجم `rustc` ، لا تستخدم.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// تفاصيل التنفيذ غير المستقرة للمترجم `rustc` ، لا تستخدم.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}