Panics الموضوع الحالي.

يسمح هذا للبرنامج بالإنهاء فورًا وتقديم ملاحظات لمتصل البرنامج.
`panic!` يجب استخدامه عندما يصل البرنامج إلى حالة غير قابلة للاسترداد.

هذا الماكرو هو الطريقة المثلى لتأكيد الشروط في مثال التعليمات البرمجية وفي الاختبارات.
`panic!` يرتبط ارتباطًا وثيقًا بطريقة `unwrap` لكل من تعدادات [`Option`][ounwrap] و [`Result`][runwrap].
يستدعي كلا التطبيقين `panic!` عند تعيينهما على متغيرات [`None`] أو [`Err`].

عند استخدام `panic!()` ، يمكنك تحديد حمولة سلسلة ، تم إنشاؤها باستخدام بناء جملة [`format!`].
يتم استخدام هذه الحمولة عند حقن panic في مؤشر ترابط Rust الذي يستدعي ، مما يتسبب في وصول مؤشر الترابط إلى panic تمامًا.

سلوك `std` hook الافتراضي ، أي
الرمز الذي يتم تشغيله مباشرة بعد استدعاء panic ، هو طباعة حمولة الرسالة إلى `stderr` مع معلومات file/line/column لاستدعاء `panic!()`.

يمكنك تجاوز panic hook باستخدام [`std::panic::set_hook()`].
داخل hook ، يمكن الوصول إلى panic باعتباره `&dyn Any + Send` ، والذي يحتوي إما على `&str` أو `String` لاستدعاءات `panic!()` العادية.
إلى panic بقيمة نوع آخر ، يمكن استخدام [`panic_any`].

[`Result`] يعد enum حلاً أفضل للتعافي من الأخطاء بدلاً من استخدام ماكرو `panic!`.
يجب استخدام هذا الماكرو لتجنب المتابعة باستخدام قيم غير صحيحة ، مثل من مصادر خارجية.
تم العثور على معلومات مفصلة حول معالجة الأخطاء في [book].

راجع أيضًا الماكرو [`compile_error!`] ، لإثارة الأخطاء أثناء التجميع.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# التنفيذ الحالي

إذا كان الخيط الرئيسي panics فإنه سينهي جميع سلاسل الرسائل الخاصة بك وينهي برنامجك برمز `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





