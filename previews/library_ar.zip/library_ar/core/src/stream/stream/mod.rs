use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// واجهة للتعامل مع التكرارات غير المتزامنة.
///
/// هذا هو التدفق الرئيسي trait.
/// لمزيد من المعلومات حول مفهوم التدفقات بشكل عام ، يرجى الاطلاع على [module-level documentation].
/// على وجه الخصوص ، قد ترغب في معرفة كيفية [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// نوع العناصر الناتجة عن الدفق.
    type Item;

    /// حاول سحب القيمة التالية لهذا الدفق ، وتسجيل المهمة الحالية للاستيقاظ إذا لم تكن القيمة متاحة بعد ، وإرجاع `None` إذا تم استنفاد الدفق.
    ///
    /// # قيمة الإرجاع
    ///
    /// هناك العديد من قيم الإرجاع المحتملة ، كل منها يشير إلى حالة دفق مميزة:
    ///
    /// - `Poll::Pending` يعني أن القيمة التالية لهذا البث ليست جاهزة بعد.ستضمن عمليات التنفيذ إخطار المهمة الحالية عندما تكون القيمة التالية جاهزة.
    ///
    /// - `Poll::Ready(Some(val))` يعني أن الدفق قد أنتج قيمة بنجاح ، `val` ، وقد ينتج قيمًا إضافية في مكالمات `poll_next` اللاحقة.
    ///
    /// - `Poll::Ready(None)` يعني أن الدفق قد انتهى ، ولا يجب استدعاء `poll_next` مرة أخرى.
    ///
    /// # Panics
    ///
    /// بمجرد انتهاء الدفق (تم إرجاع `Ready(None)` from `poll_next`) ، قد يؤدي استدعاء طريقة `poll_next` مرة أخرى إلى منع panic أو حظره إلى الأبد أو التسبب في أنواع أخرى من المشاكل ؛ لا تضع `Stream` trait أي متطلبات على تأثيرات مثل هذه المكالمة.
    ///
    /// ومع ذلك ، نظرًا لأن طريقة `poll_next` لم يتم وضع علامة `unsafe` عليها ، فإن القواعد المعتادة لـ Rust تنطبق: يجب ألا تتسبب المكالمات مطلقًا في سلوك غير محدد (تلف الذاكرة أو الاستخدام غير الصحيح لوظائف `unsafe` أو ما شابه) ، بغض النظر عن حالة الدفق.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// ترجع حدود الطول المتبقي للدفق.
    ///
    /// على وجه التحديد ، تُرجع `size_hint()` مجموعة حيث يكون العنصر الأول هو الحد الأدنى والعنصر الثاني هو الحد الأعلى.
    ///
    /// النصف الثاني من المجموعة التي تم إرجاعها هو [`خيار`]`<`[`usize`] `>`.
    /// يعني [`None`] هنا إما أنه لا يوجد حد أعلى معروف ، أو أن الحد الأعلى أكبر من [`usize`].
    ///
    /// # ملاحظات التنفيذ
    ///
    /// لا يتم فرض أن ينتج عن تنفيذ التدفق العدد المعلن من العناصر.قد ينتج تيار عربات التي تجرها الدواب أقل من الحد الأدنى أو أكثر من الحد الأعلى للعناصر.
    ///
    /// `size_hint()` الغرض الأساسي منه هو استخدامه للتحسينات مثل حجز مساحة لعناصر التدفق ، ولكن يجب عدم الوثوق به على سبيل المثال ، حذف عمليات التحقق من الحدود في التعليمات البرمجية غير الآمنة.
    /// يجب ألا يؤدي التنفيذ غير الصحيح لـ `size_hint()` إلى انتهاكات أمان الذاكرة.
    ///
    /// ومع ذلك ، يجب أن يوفر التطبيق تقديرًا صحيحًا ، وإلا فسيكون انتهاكًا لبروتوكول trait.
    ///
    /// يعرض التنفيذ الافتراضي `(0،` [`بلا`]`)`وهو الصحيح لأي بث.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}