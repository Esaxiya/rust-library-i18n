//! لعبة libcore prelude
//!
//! هذه الوحدة مخصصة لمستخدمي libcore الذين لا يرتبطون بـ libstd أيضًا.
//! يتم استيراد هذه الوحدة بشكل افتراضي عند استخدام `#![no_std]` بنفس طريقة استخدام prelude للمكتبة القياسية.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// نسخة 2015 من النواة prelude.
///
/// شاهد [module-level documentation](self) للمزيد.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// نسخة 2018 من النواة prelude.
///
/// شاهد [module-level documentation](self) للمزيد.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// نسخة 2021 الأساسية من prelude.
///
/// شاهد [module-level documentation](self) للمزيد.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: أضف المزيد من الأشياء.
}