//! التلاعب بالسلسلة.
//!
//! لمزيد من التفاصيل ، راجع وحدة [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. خارج الحدود
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. تبدأ <=النهاية
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. حدود الشخصية
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // ابحث عن الشخصية
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` يجب أن يكون أقل من len وحدود شار
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// إرجاع طول `self`.
    ///
    /// هذا الطول بالبايت ، وليس [`char`] s أو graphemes.
    /// بمعنى آخر ، قد لا يكون طول الوتر هو ما يعتبره الإنسان.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // و يتوهم!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// تُرجع `true` إذا كان طول `self` يساوي صفر بايت.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// للتحقق من أن `index`-th byte هو البايت الأول في تسلسل نقطة رمز UTF-8 أو نهاية السلسلة.
    ///
    ///
    /// بداية السلسلة النصية ونهايتها (عندما يُعتبر `index== self.len()`) حدودًا.
    ///
    /// تُرجع `false` إذا كان `index` أكبر من `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // بداية `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // البايت الثاني من `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // البايت الثالث من `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 و لين دائما على ما يرام.
        // اختبر الرقم 0 بشكل صريح حتى يتمكن من تحسين الفحص بسهولة وتخطي قراءة بيانات السلسلة لهذه الحالة.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // هذا سحر بت يعادل: b <128 ||ب>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// يحول شريحة سلسلة إلى شريحة بايت.
    /// لتحويل شريحة البايت مرة أخرى إلى شريحة سلسلة ، استخدم الدالة [`from_utf8`].
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // الأمان: صوت ثابت لأننا ننقل نوعين بنفس التخطيط
        unsafe { mem::transmute(self) }
    }

    /// يحول شريحة سلسلة قابلة للتغيير إلى شريحة بايت قابلة للتغيير.
    ///
    /// # Safety
    ///
    /// يجب على المتصل التأكد من أن محتوى الشريحة صالح UTF-8 قبل انتهاء الاقتراض واستخدام `str` الأساسي.
    ///
    ///
    /// استخدام `str` محتوياته غير صالحة UTF-8 هو سلوك غير معرف.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // الأمان: يعتبر طاقم الممثلين من `&str` إلى `&[u8]` آمنًا منذ `str`
        // له نفس تخطيط `&[u8]` (فقط libstd يمكنه تقديم هذا الضمان).
        // يعد مرجع المؤشر آمنًا لأنه يأتي من مرجع قابل للتغيير والذي يضمن صلاحيته للكتابات.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// يحول شريحة سلسلة إلى مؤشر خام.
    ///
    /// نظرًا لأن شرائح السلسلة عبارة عن شريحة من البايت ، فإن المؤشر الأولي يشير إلى [`u8`].
    /// سيشير هذا المؤشر إلى البايت الأول من شريحة السلسلة.
    ///
    /// يجب أن يتأكد المتصل من عدم كتابة المؤشر الذي تم إرجاعه إليه مطلقًا.
    /// إذا كنت تريد تغيير محتويات شريحة السلسلة ، فاستخدم [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// يحول شريحة سلسلة قابلة للتغيير إلى مؤشر خام.
    ///
    /// نظرًا لأن شرائح السلسلة عبارة عن شريحة من البايت ، فإن المؤشر الأولي يشير إلى [`u8`].
    /// سيشير هذا المؤشر إلى البايت الأول من شريحة السلسلة.
    ///
    /// تقع على عاتقك مسؤولية التأكد من أن شريحة السلسلة يتم تعديلها فقط بطريقة تظل UTF-8 صالحة.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// إرجاع شريحة فرعية لـ `str`.
    ///
    /// هذا هو البديل غير المخيف لفهرسة `str`.
    /// تُرجع [`None`] عندما تكون عملية الفهرسة المكافئة لـ panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // المؤشرات ليست على حدود تسلسل UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // خارج الحدود
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// إرجاع شريحة فرعية قابلة للتغيير لـ `str`.
    ///
    /// هذا هو البديل غير المخيف لفهرسة `str`.
    /// تُرجع [`None`] عندما تكون عملية الفهرسة المكافئة لـ panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // الطول الصحيح
    /// assert!(v.get_mut(0..5).is_some());
    /// // خارج الحدود
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// إرجاع شريحة فرعية غير محددة لـ `str`.
    ///
    /// هذا هو البديل غير المحدد لفهرسة `str`.
    ///
    /// # Safety
    ///
    /// المتصلون بهذه الوظيفة مسؤولون عن استيفاء هذه الشروط المسبقة:
    ///
    /// * يجب ألا يتجاوز فهرس البداية مؤشر النهاية ؛
    /// * يجب أن تكون الفهارس ضمن حدود الشريحة الأصلية ؛
    /// * يجب أن تقع الفهارس على حدود تسلسل UTF-8.
    ///
    /// إذا تعذر ذلك ، فقد تشير شريحة السلسلة التي تم إرجاعها إلى ذاكرة غير صالحة أو تنتهك الثوابت التي يتم توصيلها بواسطة نوع `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `get_unchecked` ؛
        // الشريحة قابلة للإلغاء لأن `self` مرجع آمن.
        // المؤشر الذي تم إرجاعه آمن لأن ملحقات `SliceIndex` يجب أن تضمن أنه كذلك.
        unsafe { &*i.get_unchecked(self) }
    }

    /// تُرجع شريحة فرعية قابلة للتغيير وغير محددة لـ `str`.
    ///
    /// هذا هو البديل غير المحدد لفهرسة `str`.
    ///
    /// # Safety
    ///
    /// المتصلون بهذه الوظيفة مسؤولون عن استيفاء هذه الشروط المسبقة:
    ///
    /// * يجب ألا يتجاوز فهرس البداية مؤشر النهاية ؛
    /// * يجب أن تكون الفهارس ضمن حدود الشريحة الأصلية ؛
    /// * يجب أن تقع الفهارس على حدود تسلسل UTF-8.
    ///
    /// إذا تعذر ذلك ، فقد تشير شريحة السلسلة التي تم إرجاعها إلى ذاكرة غير صالحة أو تنتهك الثوابت التي يتم توصيلها بواسطة نوع `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `get_unchecked_mut` ؛
        // الشريحة قابلة للإلغاء لأن `self` مرجع آمن.
        // المؤشر الذي تم إرجاعه آمن لأن ملحقات `SliceIndex` يجب أن تضمن أنه كذلك.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// ينشئ شريحة سلسلة من شريحة سلسلة أخرى ، متجاوزة فحوصات الأمان.
    ///
    /// لا ينصح بهذا بشكل عام ، استخدمه بحذر!للحصول على بديل آمن ، راجع [`str`] و [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// تنتقل هذه الشريحة الجديدة من `begin` إلى `end` ، بما في ذلك `begin` ولكن باستثناء `end`.
    ///
    /// للحصول على شريحة سلسلة قابلة للتغيير بدلاً من ذلك ، راجع طريقة [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// المتصلون بهذه الوظيفة مسؤولون عن استيفاء ثلاثة شروط مسبقة:
    ///
    /// * `begin` يجب ألا يتجاوز `end`.
    /// * `begin` و `end` يجب أن تكون مواضع بايت داخل شريحة السلسلة.
    /// * `begin` يجب أن تقع و `end` على حدود تسلسل UTF-8.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `get_unchecked` ؛
        // الشريحة قابلة للإلغاء لأن `self` مرجع آمن.
        // المؤشر الذي تم إرجاعه آمن لأن ملحقات `SliceIndex` يجب أن تضمن أنه كذلك.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// ينشئ شريحة سلسلة من شريحة سلسلة أخرى ، متجاوزة فحوصات الأمان.
    /// لا ينصح بهذا بشكل عام ، استخدمه بحذر!للحصول على بديل آمن ، راجع [`str`] و [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// تنتقل هذه الشريحة الجديدة من `begin` إلى `end` ، بما في ذلك `begin` ولكن باستثناء `end`.
    ///
    /// للحصول على شريحة سلسلة ثابتة بدلاً من ذلك ، راجع طريقة [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// المتصلون بهذه الوظيفة مسؤولون عن استيفاء ثلاثة شروط مسبقة:
    ///
    /// * `begin` يجب ألا يتجاوز `end`.
    /// * `begin` و `end` يجب أن تكون مواضع بايت داخل شريحة السلسلة.
    /// * `begin` يجب أن تقع و `end` على حدود تسلسل UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `get_unchecked_mut` ؛
        // الشريحة قابلة للإلغاء لأن `self` مرجع آمن.
        // المؤشر الذي تم إرجاعه آمن لأن ملحقات `SliceIndex` يجب أن تضمن أنه كذلك.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// قسّم شريحة سلسلة واحدة إلى قسمين في فهرس.
    ///
    /// يجب أن تكون الوسيطة `mid` عبارة عن إزاحة بايت من بداية السلسلة.
    /// يجب أن يكون أيضًا على حدود نقطة رمز UTF-8.
    ///
    /// تنتقل الشريحتان اللتان تم إرجاعهما من بداية شريحة السلسلة إلى `mid` ، ومن `mid` إلى نهاية شريحة السلسلة.
    ///
    /// للحصول على شرائح سلسلة قابلة للتغيير بدلاً من ذلك ، راجع طريقة [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics إذا لم يكن `mid` على حدود نقطة رمز UTF-8 ، أو إذا تجاوز نهاية آخر نقطة رمز من شريحة السلسلة.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // يتحقق is_char_boundary من أن الفهرس في [0 ، .len()]
        if self.is_char_boundary(mid) {
            // الأمان: تحقق فقط من أن `mid` على حدود char.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// قسّم شريحة سلسلة واحدة قابلة للتغيير إلى قسمين في فهرس.
    ///
    /// يجب أن تكون الوسيطة `mid` عبارة عن إزاحة بايت من بداية السلسلة.
    /// يجب أن يكون أيضًا على حدود نقطة رمز UTF-8.
    ///
    /// تنتقل الشريحتان اللتان تم إرجاعهما من بداية شريحة السلسلة إلى `mid` ، ومن `mid` إلى نهاية شريحة السلسلة.
    ///
    /// للحصول على شرائح سلسلة ثابتة بدلاً من ذلك ، راجع طريقة [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics إذا لم يكن `mid` على حدود نقطة رمز UTF-8 ، أو إذا تجاوز نهاية آخر نقطة رمز من شريحة السلسلة.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // يتحقق is_char_boundary من أن الفهرس في [0 ، .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // الأمان: تحقق فقط من أن `mid` على حدود char.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// إرجاع مكرر على [`الحرف`] لشريحة سلسلة.
    ///
    /// نظرًا لأن شريحة السلسلة تتكون من UTF-8 صالح ، يمكننا التكرار من خلال شريحة سلسلة بواسطة [`char`].
    /// هذه الطريقة ترجع مثل هذا المكرر.
    ///
    /// من المهم أن تتذكر أن [`char`] تمثل قيمة Unicode العددية ، وقد لا تتطابق مع فكرتك عن ماهية 'character'.
    ///
    /// قد يكون التكرار على مجموعات حروف الكتابة هو ما تريده بالفعل.
    /// لا يتم توفير هذه الوظيفة بواسطة مكتبة Rust القياسية ، تحقق من crates.io بدلاً من ذلك.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// تذكر أن [`char`] قد لا تتطابق مع حدسك حول الشخصيات:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // لا 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// إرجاع مكرر على [`الحرف] لشريحة سلسلة ، ومواضعها.
    ///
    /// نظرًا لأن شريحة السلسلة تتكون من UTF-8 صالح ، يمكننا التكرار من خلال شريحة سلسلة بواسطة [`char`].
    /// تُرجع هذه الطريقة مكررًا لكلٍّ من [الأحرف] هذه ، بالإضافة إلى مواضع البايت الخاصة بها.
    ///
    /// ينتج عن المكرر مجموعات tuple.الموضع الأول ، [`char`] هو الثاني.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// تذكر أن [`char`] قد لا تتطابق مع حدسك حول الشخصيات:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // لا (0 ، 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // لاحظ الرقم 3 هنا ، استغرق الحرف الأخير 2 بايت
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// مكرر فوق بايت شريحة سلسلة.
    ///
    /// نظرًا لأن شريحة السلسلة تتكون من سلسلة من البايتات ، فيمكننا التكرار من خلال شريحة سلسلة بايت.
    /// هذه الطريقة ترجع مثل هذا المكرر.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// يقسم شريحة سلسلة بمسافة بيضاء.
    ///
    /// سيعيد المكرر الذي تم إرجاعه شرائح سلسلة عبارة عن شرائح فرعية من شريحة السلسلة الأصلية ، مفصولة بأي مقدار من المسافات البيضاء.
    ///
    ///
    /// 'Whitespace' يتم تعريفها وفقًا لشروط الخاصية الأساسية المشتقة من Unicode `White_Space`.
    /// إذا كنت تريد فقط التقسيم على مسافة بيضاء ASCII بدلاً من ذلك ، فاستخدم [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// تعتبر جميع أنواع المسافات:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// يقسم شريحة سلسلة بمسافة بيضاء ASCII.
    ///
    /// سيعيد المكرر الناتج شرائح سلسلة هي شرائح فرعية من شريحة السلسلة الأصلية ، مفصولة بأي مقدار من المسافات البيضاء ASCII.
    ///
    ///
    /// للتقسيم بواسطة Unicode `Whitespace` بدلاً من ذلك ، استخدم [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// تعتبر جميع أنواع المسافات البيضاء ASCII:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// مكرر على خطوط سلسلة ، كشرائح سلسلة.
    ///
    /// تنتهي الأسطر إما بسطر جديد (`\n`) أو حرف إرجاع بسطر تغذية (`\r\n`).
    ///
    /// نهاية السطر الأخير اختيارية.
    /// ستعيد السلسلة التي تنتهي بنهاية سطر نهائي نفس الأسطر كسلسلة متطابقة بدون نهاية سطر نهائي.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// نهاية السطر الأخير غير مطلوبة:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// مكرر على خطوط سلسلة.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// إرجاع مكرر `u16` عبر السلسلة المشفرة كـ UTF-16.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// تُرجع `true` إذا تطابق النمط المحدد مع شريحة فرعية من شريحة السلسلة هذه.
    ///
    /// يعود `false` إذا لم يكن كذلك.
    ///
    /// يمكن أن يكون [pattern] عبارة عن `&str` أو [`char`] أو شريحة من [`char`] أو دالة أو إغلاق يحدد ما إذا كان الحرف مطابقًا أم لا.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// تُرجع `true` إذا تطابق النمط المحدد مع بادئة من شريحة السلسلة هذه.
    ///
    /// يعود `false` إذا لم يكن كذلك.
    ///
    /// يمكن أن يكون [pattern] عبارة عن `&str` أو [`char`] أو شريحة من [`char`] أو دالة أو إغلاق يحدد ما إذا كان الحرف مطابقًا أم لا.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// تُرجع `true` إذا تطابق النمط المحدد مع لاحقة شريحة السلسلة هذه.
    ///
    /// يعود `false` إذا لم يكن كذلك.
    ///
    /// يمكن أن يكون [pattern] عبارة عن `&str` أو [`char`] أو شريحة من [`char`] أو دالة أو إغلاق يحدد ما إذا كان الحرف مطابقًا أم لا.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// تُرجع فهرس البايت للحرف الأول من شريحة السلسلة التي تطابق النمط.
    ///
    /// تُرجع [`None`] إذا لم يتطابق النمط.
    ///
    /// يمكن أن يكون [pattern] عبارة عن `&str` أو [`char`] أو شريحة من [`char`] أو دالة أو إغلاق يحدد ما إذا كان الحرف مطابقًا أم لا.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// أنماط بسيطة:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// أنماط أكثر تعقيدًا باستخدام أسلوب وإغلاق بدون نقاط:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// عدم العثور على النمط:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// تُرجع فهرس البايت للحرف الأول من التطابق الموجود في أقصى اليمين للنمط في شريحة السلسلة هذه.
    ///
    /// تُرجع [`None`] إذا لم يتطابق النمط.
    ///
    /// يمكن أن يكون [pattern] عبارة عن `&str` أو [`char`] أو شريحة من [`char`] أو دالة أو إغلاق يحدد ما إذا كان الحرف مطابقًا أم لا.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// أنماط بسيطة:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// أنماط أكثر تعقيدًا مع الإغلاق:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// عدم العثور على النمط:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// مكرر فوق السلاسل الفرعية لشريحة السلسلة هذه ، مفصولة بأحرف مطابقة بنمط.
    ///
    /// يمكن أن يكون [pattern] عبارة عن `&str` أو [`char`] أو شريحة من [`char`] أو دالة أو إغلاق يحدد ما إذا كان الحرف مطابقًا أم لا.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # سلوك التكرار
    ///
    /// سيكون المكرر الذي تم إرجاعه هو [`DoubleEndedIterator`] إذا كان النمط يسمح ببحث عكسي وكان بحث forward/reverse ينتج نفس العناصر.
    /// هذا صحيح بالنسبة ، على سبيل المثال ، [`char`] ، ولكن ليس لـ `&str`.
    ///
    /// إذا كان النمط يسمح بالبحث العكسي ولكن نتائجه قد تختلف عن البحث الأمامي ، فيمكن استخدام طريقة [`rsplit`].
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// أنماط بسيطة:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// إذا كان النمط عبارة عن شريحة من الأحرف ، فقسّمها على كل تكرار لأي من الأحرف:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// نمط أكثر تعقيدًا باستخدام الإغلاق:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// إذا كانت السلسلة تحتوي على فواصل متجاورة متعددة ، فسوف ينتهي بك الأمر بسلاسل فارغة في الإخراج:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// يتم فصل الفواصل المجاورة بسلسلة فارغة.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// تتم محاذاة الفواصل الموجودة في بداية السلسلة أو نهايتها بسلاسل فارغة.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// عند استخدام السلسلة الفارغة كفاصل ، فإنها تفصل بين كل حرف في السلسلة ، جنبًا إلى جنب مع بداية السلسلة ونهايتها.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// يمكن أن تؤدي الفواصل المتجاورة إلى سلوك مفاجئ عند استخدام المسافة البيضاء كفاصل.هذا الرمز صحيح:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// يمنحك _not_:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// استخدم [`split_whitespace`] لهذا السلوك.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// مكرر فوق السلاسل الفرعية لشريحة السلسلة هذه ، مفصولة بأحرف مطابقة بنمط.
    /// يختلف الاختلاف عن المكرر الذي تنتجه `split` في أن `split_inclusive` يترك الجزء المطابق باعتباره فاصل السلسلة الفرعية.
    ///
    ///
    /// يمكن أن يكون [pattern] عبارة عن `&str` أو [`char`] أو شريحة من [`char`] أو دالة أو إغلاق يحدد ما إذا كان الحرف مطابقًا أم لا.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// إذا تمت مطابقة العنصر الأخير من السلسلة ، فسيتم اعتبار هذا العنصر فاصل السلسلة الفرعية السابقة.
    /// ستكون هذه السلسلة الفرعية هي آخر عنصر يتم إرجاعه بواسطة المكرر.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// مكرر فوق سلاسل فرعية لشريحة سلسلة معينة ، مفصولة بأحرف مطابقة بنمط ويتم إنتاجها بترتيب عكسي.
    ///
    /// يمكن أن يكون [pattern] عبارة عن `&str` أو [`char`] أو شريحة من [`char`] أو دالة أو إغلاق يحدد ما إذا كان الحرف مطابقًا أم لا.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # سلوك التكرار
    ///
    /// يتطلب المكرر الناتج أن يدعم النمط بحثًا عكسيًا ، وسيكون [`DoubleEndedIterator`] إذا أسفر بحث forward/reverse عن نفس العناصر.
    ///
    ///
    /// للتكرار من الأمام ، يمكن استخدام طريقة [`split`].
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// أنماط بسيطة:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// نمط أكثر تعقيدًا باستخدام الإغلاق:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// مكرر فوق السلاسل الفرعية لشريحة السلسلة المحددة ، مفصولة بأحرف مطابقة بنمط.
    ///
    /// يمكن أن يكون [pattern] عبارة عن `&str` أو [`char`] أو شريحة من [`char`] أو دالة أو إغلاق يحدد ما إذا كان الحرف مطابقًا أم لا.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// يكافئ [`split`] ، فيما عدا أنه يتم تخطي السلسلة الفرعية اللاحقة إذا كانت فارغة.
    ///
    /// [`split`]: str::split
    ///
    /// يمكن استخدام هذه الطريقة لبيانات السلسلة التي تكون _terminated_ ، بدلاً من _separated_ بواسطة نمط.
    ///
    /// # سلوك التكرار
    ///
    /// سيكون المكرر الذي تم إرجاعه هو [`DoubleEndedIterator`] إذا كان النمط يسمح ببحث عكسي وكان بحث forward/reverse ينتج نفس العناصر.
    /// هذا صحيح بالنسبة ، على سبيل المثال ، [`char`] ، ولكن ليس لـ `&str`.
    ///
    /// إذا كان النمط يسمح بالبحث العكسي ولكن نتائجه قد تختلف عن البحث الأمامي ، فيمكن استخدام طريقة [`rsplit_terminator`].
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// مكرر فوق سلاسل فرعية لـ `self` ، مفصولة بأحرف مطابقة بنمط ويتم إنتاجها بترتيب عكسي.
    ///
    /// يمكن أن يكون [pattern] عبارة عن `&str` أو [`char`] أو شريحة من [`char`] أو دالة أو إغلاق يحدد ما إذا كان الحرف مطابقًا أم لا.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// يكافئ [`split`] ، فيما عدا أنه يتم تخطي السلسلة الفرعية اللاحقة إذا كانت فارغة.
    ///
    /// [`split`]: str::split
    ///
    /// يمكن استخدام هذه الطريقة لبيانات السلسلة التي تكون _terminated_ ، بدلاً من _separated_ بواسطة نمط.
    ///
    /// # سلوك التكرار
    ///
    /// تتطلب أداة التكرار التي تم إرجاعها أن يدعم النمط بحثًا عكسيًا ، وستنتهي مرتين إذا أسفر بحث forward/reverse عن نفس العناصر.
    ///
    ///
    /// للتكرار من الأمام ، يمكن استخدام طريقة [`split_terminator`].
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// مكرر فوق السلاسل الفرعية لشريحة السلسلة المحددة ، مفصولة بنمط ، مقيد بإرجاع معظم عناصر `n`.
    ///
    /// إذا تم إرجاع سلاسل `n` الفرعية ، فستحتوي السلسلة الفرعية الأخيرة (السلسلة الفرعية `n`) على باقي السلسلة.
    ///
    /// يمكن أن يكون [pattern] عبارة عن `&str` أو [`char`] أو شريحة من [`char`] أو دالة أو إغلاق يحدد ما إذا كان الحرف مطابقًا أم لا.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # سلوك التكرار
    ///
    /// لن يكون المكرر الذي تم إرجاعه ذو نهاية مزدوجة ، لأنه ليس فعالاً في الدعم.
    ///
    /// إذا كان النمط يسمح بالبحث العكسي ، فيمكن استخدام طريقة [`rsplitn`].
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// أنماط بسيطة:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// نمط أكثر تعقيدًا باستخدام الإغلاق:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// مكرر على السلاسل الفرعية لشريحة السلسلة ، مفصولة بنمط ، بدءًا من نهاية السلسلة ، مقيدًا بإرجاع أكثر من `n` من العناصر.
    ///
    ///
    /// إذا تم إرجاع سلاسل `n` الفرعية ، فستحتوي السلسلة الفرعية الأخيرة (السلسلة الفرعية `n`) على باقي السلسلة.
    ///
    /// يمكن أن يكون [pattern] عبارة عن `&str` أو [`char`] أو شريحة من [`char`] أو دالة أو إغلاق يحدد ما إذا كان الحرف مطابقًا أم لا.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # سلوك التكرار
    ///
    /// لن يكون المكرر الذي تم إرجاعه ذو نهاية مزدوجة ، لأنه ليس فعالاً في الدعم.
    ///
    /// يمكن استخدام طريقة [`splitn`] للانفصال من الأمام.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// أنماط بسيطة:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// نمط أكثر تعقيدًا باستخدام الإغلاق:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// يقسم السلسلة عند التواجد الأول للمحدد المحدد ويعيد البادئة قبل المحدد واللاحقة بعد المحدد.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// يقسم السلسلة عند التواجد الأخير للمحدد المحدد ويعيد البادئة قبل المحدد واللاحقة بعد المحدد.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// مكرر فوق التطابقات المنفصلة لنمط داخل شريحة السلسلة المحددة.
    ///
    /// يمكن أن يكون [pattern] عبارة عن `&str` أو [`char`] أو شريحة من [`char`] أو دالة أو إغلاق يحدد ما إذا كان الحرف مطابقًا أم لا.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # سلوك التكرار
    ///
    /// سيكون المكرر الذي تم إرجاعه هو [`DoubleEndedIterator`] إذا كان النمط يسمح ببحث عكسي وكان بحث forward/reverse ينتج نفس العناصر.
    /// هذا صحيح بالنسبة ، على سبيل المثال ، [`char`] ، ولكن ليس لـ `&str`.
    ///
    /// إذا كان النمط يسمح بالبحث العكسي ولكن نتائجه قد تختلف عن البحث الأمامي ، فيمكن استخدام طريقة [`rmatches`].
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// مكرر فوق التطابقات المنفصلة لنمط داخل شريحة السلسلة هذه ، ينتج بترتيب عكسي.
    ///
    /// يمكن أن يكون [pattern] عبارة عن `&str` أو [`char`] أو شريحة من [`char`] أو دالة أو إغلاق يحدد ما إذا كان الحرف مطابقًا أم لا.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # سلوك التكرار
    ///
    /// يتطلب المكرر الناتج أن يدعم النمط بحثًا عكسيًا ، وسيكون [`DoubleEndedIterator`] إذا أسفر بحث forward/reverse عن نفس العناصر.
    ///
    ///
    /// للتكرار من الأمام ، يمكن استخدام طريقة [`matches`].
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// مكرر فوق التطابقات المنفصلة لنمط داخل شريحة السلسلة هذه بالإضافة إلى الفهرس الذي تبدأ عنده المطابقة.
    ///
    /// بالنسبة لمطابقات `pat` داخل `self` التي تتداخل ، يتم إرجاع المؤشرات المقابلة للمطابقة الأولى فقط.
    ///
    /// يمكن أن يكون [pattern] عبارة عن `&str` أو [`char`] أو شريحة من [`char`] أو دالة أو إغلاق يحدد ما إذا كان الحرف مطابقًا أم لا.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # سلوك التكرار
    ///
    /// سيكون المكرر الذي تم إرجاعه هو [`DoubleEndedIterator`] إذا كان النمط يسمح ببحث عكسي وكان بحث forward/reverse ينتج نفس العناصر.
    /// هذا صحيح بالنسبة ، على سبيل المثال ، [`char`] ، ولكن ليس لـ `&str`.
    ///
    /// إذا كان النمط يسمح بالبحث العكسي ولكن نتائجه قد تختلف عن البحث الأمامي ، فيمكن استخدام طريقة [`rmatch_indices`].
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // فقط `aba` الأول
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// مكرر فوق التطابقات المنفصلة لنمط داخل `self` ، ينتج بترتيب عكسي مع فهرس المطابقة.
    ///
    /// بالنسبة لمطابقات `pat` داخل `self` التي تتداخل ، يتم إرجاع المؤشرات المقابلة للمطابقة الأخيرة فقط.
    ///
    /// يمكن أن يكون [pattern] عبارة عن `&str` أو [`char`] أو شريحة من [`char`] أو دالة أو إغلاق يحدد ما إذا كان الحرف مطابقًا أم لا.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # سلوك التكرار
    ///
    /// يتطلب المكرر الناتج أن يدعم النمط بحثًا عكسيًا ، وسيكون [`DoubleEndedIterator`] إذا أسفر بحث forward/reverse عن نفس العناصر.
    ///
    ///
    /// للتكرار من الأمام ، يمكن استخدام طريقة [`match_indices`].
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // فقط `aba` الماضي
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// تُرجع شريحة سلسلة مع إزالة المسافة البيضاء البادئة واللاحقة.
    ///
    /// 'Whitespace' يتم تعريفها وفقًا لشروط الخاصية الأساسية المشتقة من Unicode `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// إرجاع شريحة سلسلة مع إزالة المسافة البيضاء البادئة.
    ///
    /// 'Whitespace' يتم تعريفها وفقًا لشروط الخاصية الأساسية المشتقة من Unicode `White_Space`.
    ///
    /// # اتجاه النص
    ///
    /// السلسلة هي سلسلة من البايتات.
    /// `start` في هذا السياق يعني الموضع الأول من سلسلة البايت هذه ؛بالنسبة للغات التي تكتب من اليسار إلى اليمين مثل الإنجليزية أو الروسية ، سيكون هذا الجانب الأيسر ، وبالنسبة للغات التي تكتب من اليمين إلى اليسار مثل العربية أو العبرية ، فسيكون هذا الجانب الأيمن.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// تُرجع شريحة سلسلة مع إزالة مسافة بيضاء لاحقة.
    ///
    /// 'Whitespace' يتم تعريفها وفقًا لشروط الخاصية الأساسية المشتقة من Unicode `White_Space`.
    ///
    /// # اتجاه النص
    ///
    /// السلسلة هي سلسلة من البايتات.
    /// `end` في هذا السياق يعني الموضع الأخير لسلسلة البايت هذه ؛بالنسبة للغات التي تكتب من اليسار إلى اليمين مثل الإنجليزية أو الروسية ، سيكون هذا الجانب الأيمن ، وبالنسبة للغات التي تكتب من اليمين إلى اليسار مثل العربية أو العبرية ، فسيكون هذا الجانب الأيسر.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// إرجاع شريحة سلسلة مع إزالة المسافة البيضاء البادئة.
    ///
    /// 'Whitespace' يتم تعريفها وفقًا لشروط الخاصية الأساسية المشتقة من Unicode `White_Space`.
    ///
    /// # اتجاه النص
    ///
    /// السلسلة هي سلسلة من البايتات.
    /// 'Left' في هذا السياق يعني الموضع الأول من سلسلة البايت هذه ؛بالنسبة للغة مثل العربية أو العبرية التي تكون "من اليمين إلى اليسار" بدلاً من "اليسار إلى اليمين" ، فسيكون هذا الجانب _right_ ، وليس الجانب الأيسر.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// تُرجع شريحة سلسلة مع إزالة مسافة بيضاء لاحقة.
    ///
    /// 'Whitespace' يتم تعريفها وفقًا لشروط الخاصية الأساسية المشتقة من Unicode `White_Space`.
    ///
    /// # اتجاه النص
    ///
    /// السلسلة هي سلسلة من البايتات.
    /// 'Right' في هذا السياق يعني الموضع الأخير لسلسلة البايت هذه ؛بالنسبة للغة مثل العربية أو العبرية التي تكون "من اليمين إلى اليسار" بدلاً من "من اليسار إلى اليمين" ، فسيكون هذا الجانب _left_ ، وليس الجانب الأيمن.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// تُرجع شريحة سلسلة بكل البادئات واللواحق التي تتطابق مع نمط تمت إزالته بشكل متكرر.
    ///
    /// يمكن أن يكون [pattern] عبارة عن [`char`] ، أو شريحة من [`char`] s ، أو دالة أو إغلاق يحدد ما إذا كان الحرف مطابقًا أم لا.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// أنماط بسيطة:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// نمط أكثر تعقيدًا باستخدام الإغلاق:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // تذكر أقرب تطابق معروف ، وصححه أدناه إذا
            // آخر مباراة مختلفة
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // الأمان: يُعرف `Searcher` بإرجاع مؤشرات صالحة.
        unsafe { self.get_unchecked(i..j) }
    }

    /// إرجاع شريحة سلسلة مع إزالة كل البادئات التي تطابق نمط بشكل متكرر.
    ///
    /// يمكن أن يكون [pattern] عبارة عن `&str` أو [`char`] أو شريحة من [`char`] أو دالة أو إغلاق يحدد ما إذا كان الحرف مطابقًا أم لا.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # اتجاه النص
    ///
    /// السلسلة هي سلسلة من البايتات.
    /// `start` في هذا السياق يعني الموضع الأول من سلسلة البايت هذه ؛بالنسبة للغات التي تكتب من اليسار إلى اليمين مثل الإنجليزية أو الروسية ، سيكون هذا الجانب الأيسر ، وبالنسبة للغات التي تكتب من اليمين إلى اليسار مثل العربية أو العبرية ، فسيكون هذا الجانب الأيمن.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // الأمان: يُعرف `Searcher` بإرجاع مؤشرات صالحة.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// إرجاع شريحة سلسلة مع إزالة البادئة.
    ///
    /// إذا بدأت السلسلة بالنمط `prefix` ، فتُرجع السلسلة الفرعية بعد البادئة ، ملفوفة في `Some`.
    /// على عكس `trim_start_matches` ، فإن هذه الطريقة تزيل البادئة مرة واحدة بالضبط.
    ///
    /// إذا لم تبدأ السلسلة بـ `prefix` ، فتُرجع `None`.
    ///
    /// يمكن أن يكون [pattern] عبارة عن `&str` أو [`char`] أو شريحة من [`char`] أو دالة أو إغلاق يحدد ما إذا كان الحرف مطابقًا أم لا.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// إرجاع شريحة سلسلة مع إزالة اللاحقة.
    ///
    /// إذا كانت السلسلة تنتهي بالنمط `suffix` ، فتُرجع السلسلة الفرعية قبل اللاحقة ، ملفوفة في `Some`.
    /// على عكس `trim_end_matches` ، تزيل هذه الطريقة اللاحقة مرة واحدة تمامًا.
    ///
    /// إذا كانت السلسلة لا تنتهي بـ `suffix` ، فتُرجع `None`.
    ///
    /// يمكن أن يكون [pattern] عبارة عن `&str` أو [`char`] أو شريحة من [`char`] أو دالة أو إغلاق يحدد ما إذا كان الحرف مطابقًا أم لا.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// إرجاع شريحة سلسلة مع إزالة جميع اللواحق التي تطابق نمط بشكل متكرر.
    ///
    /// يمكن أن يكون [pattern] عبارة عن `&str` أو [`char`] أو شريحة من [`char`] أو دالة أو إغلاق يحدد ما إذا كان الحرف مطابقًا أم لا.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # اتجاه النص
    ///
    /// السلسلة هي سلسلة من البايتات.
    /// `end` في هذا السياق يعني الموضع الأخير لسلسلة البايت هذه ؛بالنسبة للغات التي تكتب من اليسار إلى اليمين مثل الإنجليزية أو الروسية ، سيكون هذا الجانب الأيمن ، وبالنسبة للغات التي تكتب من اليمين إلى اليسار مثل العربية أو العبرية ، فسيكون هذا الجانب الأيسر.
    ///
    ///
    /// # Examples
    ///
    /// أنماط بسيطة:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// نمط أكثر تعقيدًا باستخدام الإغلاق:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // الأمان: يُعرف `Searcher` بإرجاع مؤشرات صالحة.
        unsafe { self.get_unchecked(0..j) }
    }

    /// إرجاع شريحة سلسلة مع إزالة كل البادئات التي تطابق نمط بشكل متكرر.
    ///
    /// يمكن أن يكون [pattern] عبارة عن `&str` أو [`char`] أو شريحة من [`char`] أو دالة أو إغلاق يحدد ما إذا كان الحرف مطابقًا أم لا.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # اتجاه النص
    ///
    /// السلسلة هي سلسلة من البايتات.
    /// 'Left' في هذا السياق يعني الموضع الأول من سلسلة البايت هذه ؛بالنسبة للغة مثل العربية أو العبرية التي تكون "من اليمين إلى اليسار" بدلاً من "اليسار إلى اليمين" ، فسيكون هذا الجانب _right_ ، وليس الجانب الأيسر.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// إرجاع شريحة سلسلة مع إزالة جميع اللواحق التي تطابق نمط بشكل متكرر.
    ///
    /// يمكن أن يكون [pattern] عبارة عن `&str` أو [`char`] أو شريحة من [`char`] أو دالة أو إغلاق يحدد ما إذا كان الحرف مطابقًا أم لا.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # اتجاه النص
    ///
    /// السلسلة هي سلسلة من البايتات.
    /// 'Right' في هذا السياق يعني الموضع الأخير لسلسلة البايت هذه ؛بالنسبة للغة مثل العربية أو العبرية التي تكون "من اليمين إلى اليسار" بدلاً من "من اليسار إلى اليمين" ، فسيكون هذا الجانب _left_ ، وليس الجانب الأيمن.
    ///
    ///
    /// # Examples
    ///
    /// أنماط بسيطة:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// نمط أكثر تعقيدًا باستخدام الإغلاق:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// يوزع شريحة السلسلة هذه إلى نوع آخر.
    ///
    /// نظرًا لأن `parse` عام جدًا ، فقد يتسبب في حدوث مشكلات في الاستدلال على الكتابة.
    /// على هذا النحو ، `parse` هي واحدة من المرات القليلة التي سترى فيها بناء الجملة المعروف باسم 'turbofish': `::<>`.
    ///
    /// يساعد هذا خوارزمية الاستدلال في فهم النوع الذي تحاول تحليله على وجه التحديد.
    ///
    /// `parse` يمكن تحليل أي نوع يقوم بتنفيذ [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// سيعيد [`Err`] إذا لم يكن من الممكن تحليل شريحة السلسلة هذه إلى النوع المطلوب.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// استخدام 'turbofish' بدلاً من التعليق على `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// فشل التحليل:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// للتحقق مما إذا كانت جميع الأحرف في هذه السلسلة ضمن نطاق ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // يمكننا التعامل مع كل بايت على أنه حرف هنا: تبدأ جميع الأحرف متعددة البايت ببايت ليس في نطاق ascii ، لذلك سنتوقف عند هذا الحد بالفعل.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// للتحقق من تطابق سلسلتين مع ASCII غير حساسة لحالة الأحرف.
    ///
    /// مثل `to_ascii_lowercase(a) == to_ascii_lowercase(b)` ، ولكن بدون تخصيص ونسخ الموقتات.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// يحول هذه السلسلة إلى ما يعادلها بأحرف كبيرة ASCII في المكان.
    ///
    /// يتم تعيين أحرف ASCII من 'a' إلى 'z' إلى 'A' إلى 'Z' ، لكن الأحرف غير ASCII لم تتغير.
    ///
    /// لإرجاع قيمة كبيرة جديدة بدون تعديل القيمة الحالية ، استخدم [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // الأمان: آمن لأننا نحول نوعين بنفس التصميم.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// تحويل هذه السلسلة إلى مكافئها بأحرف صغيرة ASCII في المكان.
    ///
    /// يتم تعيين أحرف ASCII من 'A' إلى 'Z' إلى 'a' إلى 'z' ، لكن الأحرف غير ASCII لم تتغير.
    ///
    /// لإرجاع قيمة صغيرة جديدة بدون تعديل القيمة الحالية ، استخدم [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // الأمان: آمن لأننا نحول نوعين بنفس التصميم.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// أعد مكررًا يهرب من كل حرف في `self` مع [`char::escape_debug`].
    ///
    ///
    /// Note: لن يتم إفلات سوى نقاط الترميز الحرفية الموسعة التي تبدأ السلسلة.
    ///
    /// # Examples
    ///
    /// كمكرر:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// باستخدام `println!` مباشرة:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// كلاهما يعادل:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// باستخدام `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// أعد مكررًا يهرب من كل حرف في `self` مع [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// كمكرر:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// باستخدام `println!` مباشرة:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// كلاهما يعادل:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// باستخدام `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// أعد مكررًا يهرب من كل حرف في `self` مع [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// كمكرر:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// باستخدام `println!` مباشرة:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// كلاهما يعادل:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// باستخدام `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// ينشئ سلسلة فارغة
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// يُنشئ سلسلة متغيرة فارغة
    #[inline]
    fn default() -> Self {
        // الأمان: السلسلة الفارغة هي UTF-8 صالحة.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// نوع fn قابل للتسمية وقابل للاستنساخ
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // الأمان: غير آمن
        unsafe { from_utf8_unchecked(bytes) }
    };
}