//! تطبيقات Trait لـ `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// تنفذ ترتيب السلاسل.
///
/// يتم ترتيب السلاسل [lexicographically](Ord#lexicographical-comparison) حسب قيم البايت الخاصة بها.
/// يؤدي هذا إلى ترتيب نقاط رمز Unicode بناءً على مواقعها في مخططات الكود.
/// هذا ليس بالضرورة نفس ترتيب "alphabetical" ، والذي يختلف حسب اللغة والإعدادات المحلية.
/// يتطلب فرز السلاسل وفقًا للمعايير المقبولة ثقافيًا بيانات خاصة بالإعدادات المحلية تقع خارج نطاق نوع `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// تنفذ عمليات المقارنة على السلاسل.
///
/// تتم مقارنة السلاسل [lexicographically](Ord#lexicographical-comparison) بقيم البايت الخاصة بها.
/// هذا يقارن نقاط رمز Unicode بناءً على مواقعها في مخططات الكود.
/// هذا ليس بالضرورة نفس ترتيب "alphabetical" ، والذي يختلف حسب اللغة والإعدادات المحلية.
/// تتطلب مقارنة السلاسل وفقًا للمعايير المقبولة ثقافيًا بيانات خاصة بالإعدادات المحلية خارج نطاق نوع `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// ينفذ تقطيع السلاسل الفرعية باستخدام بناء الجملة `&self[..]` أو `&mut self[..]`.
///
/// تُرجع شريحة من السلسلة بأكملها ، على سبيل المثال ، تُرجع `&self` أو `&mut self`.يعادل `&self [0 ..
/// len] `أو`&mut self [0 ..
/// len]`.
/// على عكس عمليات الفهرسة الأخرى ، فإن هذا لا يمكن أن يكون panic.
///
/// هذه العملية هي *O*(1).
///
/// قبل 1.20.0 ، كانت عمليات الفهرسة هذه لا تزال مدعومة بالتنفيذ المباشر لـ `Index` و `IndexMut`.
///
/// يكافئ `&self[0 .. len]` أو `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// ينفذ تقطيع السلاسل الفرعية باستخدام بناء الجملة `&self[begin .. end]` أو `&mut self[begin .. end]`.
///
/// لعرض شريحة من السلسلة المحددة من نطاق البايت [`البدء` ، `end`).
///
/// هذه العملية هي *O*(1).
///
/// قبل 1.20.0 ، كانت عمليات الفهرسة هذه لا تزال مدعومة بالتنفيذ المباشر لـ `Index` و `IndexMut`.
///
/// # Panics
///
/// Panics إذا كان `begin` أو `end` لا يشير إلى إزاحة بايت البداية للحرف (كما هو محدد بواسطة `is_char_boundary`) ، إذا كان `begin > end` ، أو إذا كان `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // هذه سوف panic:
/// // البايت 2 يقع داخل `ö`:
/// // &ق [2 ..3] ؛
///
/// // البايت 8 يقع داخل `老`&s [1 ..
/// // 8];
///
/// // البايت 100 خارج السلسلة النصية [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // الأمان: تحقق فقط من أن `start` و `end` على حدود char ،
            // ونحن نمرر في مرجع آمن ، وبالتالي فإن القيمة المعادة ستكون واحدة أيضًا.
            // لقد تحققنا أيضًا من حدود char ، لذلك يعد هذا UTF-8 صالحًا.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // الأمان: تحقق فقط من أن `start` و `end` على حدود char.
            // نحن نعلم أن المؤشر فريد لأننا حصلنا عليه من `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // الأمان: يضمن المتصل أن `self` في حدود `slice`
        // الذي يفي بجميع شروط `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // السلامة: انظر التعليقات على `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // يتحقق is_char_boundary من وجود الفهرس في [0 ، ولا يمكن لـ .len()] إعادة استخدام `get` على النحو الوارد أعلاه ، بسبب مشكلة NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // الأمان: تحقق فقط من أن `start` و `end` على حدود char ،
            // ونحن نمرر في مرجع آمن ، وبالتالي فإن القيمة المعادة ستكون واحدة أيضًا.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// ينفذ تقطيع السلاسل الفرعية باستخدام بناء الجملة `&self[.. end]` أو `&mut self[.. end]`.
///
/// لعرض شريحة من السلسلة المحددة من نطاق البايت [`0` ، `end`).
/// يكافئ `&self[0 .. end]` أو `&mut self[0 .. end]`.
///
/// هذه العملية هي *O*(1).
///
/// قبل 1.20.0 ، كانت عمليات الفهرسة هذه لا تزال مدعومة بالتنفيذ المباشر لـ `Index` و `IndexMut`.
///
/// # Panics
///
/// Panics إذا كان `end` لا يشير إلى إزاحة بايت البداية للحرف (كما هو محدد بواسطة `is_char_boundary`) ، أو إذا كان `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // الأمان: تحقق فقط من أن `end` على حدود char ،
            // ونحن نمرر في مرجع آمن ، وبالتالي فإن القيمة المعادة ستكون واحدة أيضًا.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // الأمان: تحقق فقط من أن `end` على حدود char ،
            // ونحن نمرر في مرجع آمن ، وبالتالي فإن القيمة المعادة ستكون واحدة أيضًا.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // الأمان: تحقق فقط من أن `end` على حدود char ،
            // ونحن نمرر في مرجع آمن ، وبالتالي فإن القيمة المعادة ستكون واحدة أيضًا.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// ينفذ تقطيع السلاسل الفرعية باستخدام بناء الجملة `&self[begin ..]` أو `&mut self[begin ..]`.
///
/// لعرض شريحة من السلسلة المحددة من نطاق البايت [`البدء` ، `len`).يعادل `&self [begin ..
/// len] `أو"&mut self [begin ..
/// len]`.
///
/// هذه العملية هي *O*(1).
///
/// قبل 1.20.0 ، كانت عمليات الفهرسة هذه لا تزال مدعومة بالتنفيذ المباشر لـ `Index` و `IndexMut`.
///
/// # Panics
///
/// Panics إذا كان `begin` لا يشير إلى إزاحة بايت البداية للحرف (كما هو محدد بواسطة `is_char_boundary`) ، أو إذا كان `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // الأمان: تحقق فقط من أن `start` على حدود char ،
            // ونحن نمرر في مرجع آمن ، وبالتالي فإن القيمة المعادة ستكون واحدة أيضًا.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // الأمان: تحقق فقط من أن `start` على حدود char ،
            // ونحن نمرر في مرجع آمن ، وبالتالي فإن القيمة المعادة ستكون واحدة أيضًا.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // الأمان: يضمن المتصل أن `self` في حدود `slice`
        // الذي يفي بجميع شروط `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // الأمان: مطابق لـ `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // الأمان: تحقق فقط من أن `start` على حدود char ،
            // ونحن نمرر في مرجع آمن ، وبالتالي فإن القيمة المعادة ستكون واحدة أيضًا.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// ينفذ تقطيع السلاسل الفرعية باستخدام بناء الجملة `&self[begin ..= end]` أو `&mut self[begin ..= end]`.
///
/// ترجع شريحة من السلسلة المحددة من نطاق البايت [`begin`, `end`].يكافئ `&self [begin .. end + 1]` أو `&mut self[begin .. end + 1]` ، إلا إذا كان `end` به القيمة القصوى لـ `usize`.
///
/// هذه العملية هي *O*(1).
///
/// # Panics
///
/// Panics إذا كان `begin` لا يشير إلى إزاحة بايت البداية للحرف (كما هو محدد بواسطة `is_char_boundary`) ، إذا كان `end` لا يشير إلى إزاحة بايت النهاية للحرف (`end + 1` إما إزاحة بايت بداية أو يساوي `len`) ، إذا كان `begin > end` ، أو إذا كان `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// ينفذ تقطيع السلاسل الفرعية باستخدام بناء الجملة `&self[..= end]` أو `&mut self[..= end]`.
///
/// تُرجع شريحة من السلسلة المحددة من نطاق البايت [0, `end`].
/// يكافئ `&self [0 .. end + 1]` ، إلا إذا كان `end` به القيمة القصوى لـ `usize`.
///
/// هذه العملية هي *O*(1).
///
/// # Panics
///
/// Panics إذا كان `end` لا يشير إلى إزاحة بايت النهاية للحرف (`end + 1` إما إزاحة بايت بداية كما هو محدد بواسطة `is_char_boundary` ، أو يساوي `len`) ، أو إذا كان `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// تحليل قيمة من سلسلة
///
/// غالبًا ما تُستخدم طريقة [`from_str`] الخاصة بـ "FromStr" ضمنيًا ، من خلال طريقة [`parse`] لـ [`str`].
/// راجع وثائق [`parse`] للحصول على أمثلة.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` لا يحتوي على معلمة مدى الحياة ، وبالتالي يمكنك فقط تحليل الأنواع التي لا تحتوي على معلمة مدى الحياة نفسها.
///
/// بمعنى آخر ، يمكنك تحليل `i32` مع `FromStr` ، ولكن ليس `&i32`.
/// يمكنك تحليل بنية تحتوي على `i32` ، لكن لا يمكنك تحليل بنية تحتوي على `&i32`.
///
/// # Examples
///
/// التنفيذ الأساسي لـ `FromStr` على مثال من نوع `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// الخطأ المصاحب الذي يمكن إرجاعه من التحليل.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// يوزع سلسلة `s` لإرجاع قيمة من هذا النوع.
    ///
    /// إذا نجح التحليل ، فقم بإرجاع القيمة داخل [`Ok`] ، وإلا عندما تكون السلسلة غير منسقة ، يتم إرجاع خطأ خاص بـ [`Err`] الداخلي.
    /// نوع الخطأ خاص بتنفيذ trait.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي مع [`i32`] ، وهو نوع يستخدم `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// تحليل `bool` من سلسلة.
    ///
    /// تنتج `Result<bool, ParseBoolError>` ، لأن `s` قد يكون أو لا يكون قابلاً للتحليل في الواقع.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// لاحظ أنه في كثير من الحالات ، تكون طريقة `.parse()` على `str` أكثر ملاءمة.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}