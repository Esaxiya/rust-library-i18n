//! يحدد نوع الخطأ utf8.

use crate::fmt;

/// الأخطاء التي يمكن أن تحدث عند محاولة تفسير تسلسل [`u8`] كسلسلة.
///
/// على هذا النحو ، تستخدم عائلة `from_utf8` من الوظائف والطرق لكل من [`String`] s و [`&str`] هذا الخطأ ، على سبيل المثال.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// يمكن استخدام أساليب نوع الخطأ هذا لإنشاء وظائف مشابهة لـ `String::from_utf8_lossy` دون تخصيص ذاكرة كومة:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// إرجاع الفهرس في السلسلة المحددة التي تم التحقق من UTF-8 صالح لها.
    ///
    /// هذا هو الحد الأقصى للفهرس بحيث يقوم `from_utf8(&input[..index])` بإرجاع `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::str;
    ///
    /// // بعض البايتات غير الصالحة في vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 إرجاع Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // البايت الثاني غير صالح هنا
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// يوفر مزيدًا من المعلومات حول الفشل:
    ///
    /// * `None`: تم الوصول إلى نهاية الإدخال بشكل غير متوقع.
    ///   `self.valid_up_to()` من 1 إلى 3 بايت من نهاية الإدخال.
    ///   إذا تم فك تشفير دفق بايت (مثل ملف أو مقبس شبكة) بشكل تدريجي ، فقد يكون هذا `char` صالحًا يمتد تسلسل بايت UTF-8 الخاص به إلى أجزاء متعددة.
    ///
    ///
    /// * `Some(len)`: تمت مصادفة بايت غير متوقع.
    ///   الطول المقدم هو طول تسلسل البايت غير الصحيح الذي يبدأ من الفهرس المعطى بواسطة `valid_up_to()`.
    ///   يجب استئناف فك التشفير بعد هذا التسلسل (بعد إدخال [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) في حالة فك التشفير المفقود.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// تم إرجاع خطأ عند فشل تحليل `bool` باستخدام [`from_str`]
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}