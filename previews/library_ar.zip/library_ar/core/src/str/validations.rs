//! العمليات المتعلقة بالتحقق من صحة UTF-8.

use crate::mem;

use super::Utf8Error;

/// إرجاع مجمع نقطة الرمز الأولي للبايت الأول.
/// البايت الأول خاص ، لا يريد سوى 5 بتات سفلية للعرض 2 ، و 4 بتات للعرض 3 ، و 3 بتات للعرض 4.
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// تُرجع قيمة `ch` المحدثة ببايت الاستمرارية `byte`.
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// للتحقق مما إذا كان البايت عبارة عن بايت استمرار UTF-8 (أي يبدأ بالبتات `10`).
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// يقرأ نقطة الكود التالية من مكرر البايت (بافتراض ترميز يشبه UTF-8).
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // فك شفرة UTF-8
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // تتبع حالة Multibyte Decode من مجموعة بايت من: [[[x y] z] w]
    //
    // NOTE: الأداء حساس للصياغة الدقيقة هنا
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] w] القضية
        // البتة الخامسة في 0xE0 .. 0xEF واضحة دائمًا ، لذا لا يزال `init` صالحًا
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] استخدم العلبة فقط 3 بتات أقل من `init`
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// يقرأ آخر نقطة رمز من مكرر البايت (بافتراض ترميز يشبه UTF-8).
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // فك شفرة UTF-8
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // تتبع حالة Multibyte Decode من مجموعة بايت من: [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// استخدام الاقتطاع لملاءمة u64 في الاستخدام
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// لعرض `true` إذا كان أي بايت في الكلمة `x` هو nonascii (>=128).
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// يمر عبر `v` للتحقق من أنه تسلسل UTF-8 صالح ، أو إرجاع `Ok(())` في هذه الحالة ، أو إذا كان غير صالح ، `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // كنا بحاجة إلى بيانات ، لكن لم يكن هناك أي منها: خطأ!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // الترميز 2 بايت مخصص لنقاط الترميز\u {0080} إلى\u {07ff} أول C2 80 آخر DF BF
            // الترميز ثلاثي البايت مخصص لنقاط التشفير\u {0800} إلى\u {ffff} أول E0 A0 80 آخر EF BF BF باستثناء نقاط الترميز البديلة\u {d800} إلى\u {dfff} ED A0 80 إلى ED BF BF
            // تشفير 4 بايت مخصص لنقاط الترميز\u {1000} 0\u {10ff} ff الأول F0 90 80 80 آخر F4 8F BF BF
            //
            // استخدم بناء جملة UTF-8 من RFC
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=٪ x00-7F UTF8-2=٪ xC2-DF UTF8-tail UTF8-3= %xE0٪ xA0-BF UTF8-tail/٪ xE1-EC 2( UTF8-tail )/%xED٪ x80-9F UTF8-tail/٪ xEE-EF 2( UTF8-tail ) UTF8-4= %xF0٪ x90-BF 2( UTF8-tail )/٪ xF1-F3 3( UTF8-tail )/%xF4٪ x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // حالة Ascii ، حاول التخطي للأمام بسرعة.
            // عند محاذاة المؤشر ، اقرأ كلمتين من البيانات لكل تكرار حتى نجد كلمة تحتوي على بايت غير أسكي.
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // الأمان: منذ `align - index` و `ascii_block_size`
                    // يتم دائمًا محاذاة مضاعفات `usize_bytes` ، `block = ptr.add(index)` مع `usize` لذلك من الآمن الرجوع إلى كل من `block` و `block.offset(1)`.
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // كسر إذا كان هناك بايت nonascii
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // خطوة من النقطة التي توقفت عندها الحلقة اللفظية
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// بالنظر إلى البايت الأول ، يحدد عدد البايت في حرف UTF-8 هذا.
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// قناع بتات القيمة لبايت الاستمرارية.
const CONT_MASK: u8 = 0b0011_1111;
/// قيمة بتات العلامة (قناع العلامة هو !CONT_MASK) لبايت الاستمرارية.
const TAG_CONT_U8: u8 = 0b1000_0000;

// اقتطاع `&str` إلى الطول على الأكثر يساوي `max` وإرجاع `true` إذا تم اقتطاعه ، والشريط الجديد.
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}