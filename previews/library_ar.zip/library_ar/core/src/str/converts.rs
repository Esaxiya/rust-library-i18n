//! طرق إنشاء `str` من شريحة بايت.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// يحول شريحة من البايت إلى شريحة سلسلة.
///
/// شريحة السلسلة ([`&str`]) تتكون من بايت ([`u8`]) ، وشريحة البايت ([`&[u8]`][byteslice]) مصنوعة من البايتات ، لذلك يتم تحويل هذه الوظيفة بين الاثنين.
/// ليست كل شرائح البايت عبارة عن شرائح سلسلة صالحة ، على الرغم من ذلك: يتطلب [`&str`] أن يكون UTF-8 صالحًا.
/// `from_utf8()` يتحقق للتأكد من أن البايت هي UTF-8 صالحة ، ثم يقوم بالتحويل.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// إذا كنت متأكدًا من أن شريحة البايت صالحة UTF-8 ، ولا تريد تحمل النفقات العامة للتحقق من الصلاحية ، فهناك إصدار غير آمن من هذه الوظيفة ، [`from_utf8_unchecked`] ، له نفس السلوك ولكنه يتخطى الفحص.
///
///
/// إذا كنت بحاجة إلى `String` بدلاً من `&str` ، ففكر في [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// نظرًا لأنه يمكنك تخصيص مكدس `[u8; N]` ، ويمكنك أخذ [`&[u8]`][byteslice] منه ، فإن هذه الوظيفة هي إحدى الطرق للحصول على سلسلة مخصصة للمكدس.يوجد مثال على ذلك في قسم الأمثلة أدناه.
///
/// [byteslice]: slice
///
/// # Errors
///
/// تُرجع `Err` إذا كانت الشريحة ليست UTF-8 مع وصف لماذا الشريحة المقدمة ليست UTF-8.
///
/// # Examples
///
/// الاستخدام الأساسي:
///
/// ```
/// use std::str;
///
/// // بعض البايتات في vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // نحن نعلم أن هذه البايتات صالحة ، لذا استخدم `unwrap()` فقط.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// بايت غير صحيح:
///
/// ```
/// use std::str;
///
/// // بعض البايتات غير الصالحة في vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// راجع مستندات [`Utf8Error`] للحصول على مزيد من التفاصيل حول أنواع الأخطاء التي يمكن إرجاعها.
///
/// أ "stack allocated string":
///
/// ```
/// use std::str;
///
/// // بعض البايتات في مصفوفة مخصصة للمكدس
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // نحن نعلم أن هذه البايتات صالحة ، لذا استخدم `unwrap()` فقط.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // الأمان: تم تشغيل التحقق من الصحة.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// يحول شريحة قابلة للتغيير من البايت إلى شريحة سلسلة قابلة للتغيير.
///
/// # Examples
///
/// الاستخدام الأساسي:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" باعتباره vector متغير
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // كما نعلم أن هذه البايتات صالحة ، يمكننا استخدام `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// بايت غير صحيح:
///
/// ```
/// use std::str;
///
/// // بعض البايت غير الصالحة في vector قابل للتغيير
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// راجع مستندات [`Utf8Error`] للحصول على مزيد من التفاصيل حول أنواع الأخطاء التي يمكن إرجاعها.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // الأمان: تم تشغيل التحقق من الصحة.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// يحول شريحة من البايت إلى شريحة سلسلة دون التحقق من احتواء السلسلة على UTF-8 صالح.
///
/// راجع الإصدار الآمن [`from_utf8`] لمزيد من المعلومات.
///
/// # Safety
///
/// هذه الوظيفة غير آمنة لأنها لا تتحقق من أن وحدات البايت التي تم تمريرها إليها هي UTF-8 صالحة.
/// في حالة انتهاك هذا القيد ، ينتج عن سلوك غير معرف ، حيث تفترض بقية Rust أن [`&str`] هي UTF-8 صالحة.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// الاستخدام الأساسي:
///
/// ```
/// use std::str;
///
/// // بعض البايتات في vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // الأمان: يجب أن يضمن المتصل أن البايتات `v` صالحة UTF-8.
    // يعتمد أيضًا على `&str` و `&[u8]` لهما نفس التخطيط.
    unsafe { mem::transmute(v) }
}

/// تحويل شريحة من البايت إلى شريحة سلسلة دون التحقق من احتواء السلسلة على UTF-8 صالح ؛نسخة قابلة للتغيير.
///
///
/// راجع الإصدار الثابت [`from_utf8_unchecked()`] لمزيد من المعلومات.
///
/// # Examples
///
/// الاستخدام الأساسي:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // الأمان: يجب أن يضمن المتصل أن بايت `v`
    // هي UTF-8 صالحة ، وبالتالي فإن المصبوب إلى `*mut str` آمن.
    // أيضًا ، يعد مرجع المؤشر آمنًا لأن هذا المؤشر يأتي من مرجع مضمون أن يكون صالحًا للكتابة.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}