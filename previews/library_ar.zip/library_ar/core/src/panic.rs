//! دعم Panic في المكتبة القياسية.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// هيكل يوفر معلومات حول panic.
///
/// `PanicInfo` يتم تمرير البنية إلى panic hook التي تم تعيينها بواسطة الدالة [`set_hook`].
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// تُرجع الحمولة المرتبطة بـ panic.
    ///
    /// سيكون هذا عادةً ، ولكن ليس دائمًا ، `&'static str` أو [`String`].
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// إذا تم استخدام الماكرو `panic!` من `core` crate (وليس من `std`) مع سلسلة تنسيق وبعض الوسائط الإضافية ، فتُرجع هذه الرسالة جاهزة للاستخدام على سبيل المثال مع [`fmt::write`]
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// تُرجع معلومات حول الموقع الذي نشأت منه panic ، إذا كان ذلك متاحًا.
    ///
    /// ستعيد هذه الطريقة دائمًا [`Some`] حاليًا ، ولكن قد يتغير هذا في إصدارات future.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: إذا تم تغيير هذا لإرجاع لا شيء في بعض الأحيان ،
        // التعامل مع هذه الحالة في std::panicking::default_hook و std::panicking::begin_panic_fmt.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: لا يمكننا استخدام downcast_ref: :<String>() هنا
        // منذ String غير متوفر في libcore!
        // الحمولة عبارة عن سلسلة عندما يتم استدعاء `std::panic!` بوسائط متعددة ، ولكن في هذه الحالة تكون الرسالة متاحة أيضًا.
        //

        self.location.fmt(formatter)
    }
}

/// هيكل يحتوي على معلومات حول موقع panic.
///
/// تم إنشاء هذا الهيكل بواسطة [`PanicInfo::location()`].
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// يتم إجراء مقارنات للمساواة والترتيب في أولوية الملف ، السطر ، ثم العمود.
/// تتم مقارنة الملفات كسلاسل ، وليس `Path` ، والتي قد تكون غير متوقعة.
/// راجع وثائق [الموقع: : file`] لمزيد من المناقشة.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// يُرجع موقع المصدر الخاص بالمستدعي لهذه الوظيفة.
    /// إذا تم وضع تعليق توضيحي على المتصل بهذه الوظيفة ، فسيتم إرجاع موقع الاستدعاء الخاص به ، وهكذا يصل المكدس إلى المكالمة الأولى داخل جسم وظيفة غير متعقب.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// تُرجع [`Location`] التي تم استدعاؤها عندها.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// تُرجع [`Location`] من داخل تعريف هذه الوظيفة.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // تشغيل نفس الوظيفة غير المتعقبة في موقع مختلف يعطينا نفس النتيجة
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // تشغيل الوظيفة المتعقبة في موقع مختلف ينتج قيمة مختلفة
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// تُرجع اسم الملف المصدر الذي نشأت منه panic.
    ///
    /// # `&str`, لا `&Path`
    ///
    /// يشير الاسم الذي تم إرجاعه إلى مسار المصدر على نظام التحويل البرمجي ، ولكن ليس من الصحيح تمثيل ذلك مباشرةً على أنه `&Path`.
    /// يمكن تشغيل الكود المترجم على نظام مختلف بتطبيق `Path` مختلف عن النظام الذي يوفر المحتويات ولا تحتوي هذه المكتبة حاليًا على نوع "host path" مختلف.
    ///
    /// يحدث السلوك الأكثر إثارة للدهشة عندما يمكن الوصول إلى ملف "the same" عبر مسارات متعددة في نظام الوحدة النمطية (عادةً باستخدام السمة `#[path = "..."]` أو ما شابه ذلك) ، مما قد يتسبب في ما يبدو أنه رمز متطابق لإرجاع قيم مختلفة من هذه الوظيفة.
    ///
    ///
    /// # Cross-compilation
    ///
    /// هذه القيمة غير مناسبة للتمرير إلى `Path::new` أو المنشئات المماثلة عندما يختلف النظام الأساسي المضيف والنظام الأساسي الهدف.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// لعرض رقم السطر الذي نشأت منه panic.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// لعرض العمود الذي نشأت منه panic.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// trait داخلي يستخدمه libstd لتمرير البيانات من libstd إلى `panic_unwind` وأوقات تشغيل panic الأخرى.
/// لا يقصد الاستقرار في أي وقت قريب ، لا تستخدمه.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// الحصول على الملكية الكاملة للمحتويات.
    /// نوع الإرجاع هو `Box<dyn Any + Send>` بالفعل ، لكن لا يمكننا استخدام `Box` في libcore.
    ///
    /// بعد استدعاء هذه الطريقة ، لم يتبق سوى بعض القيمة الافتراضية الوهمية في `self`.
    /// استدعاء هذه الطريقة مرتين ، أو استدعاء `get` بعد استدعاء هذه الطريقة ، يعد خطأ.
    ///
    /// يتم استعارة الحجة لأن وقت تشغيل panic (`__rust_start_panic`) يحصل فقط على `dyn BoxMeUp` مستعار.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// فقط استعارة المحتويات.
    fn get(&mut self) -> &(dyn Any + Send);
}