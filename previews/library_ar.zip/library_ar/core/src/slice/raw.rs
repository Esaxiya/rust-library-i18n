//! وظائف مجانية لإنشاء `&[T]` و `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// يشكل شريحة من مؤشر وطول.
///
/// الوسيطة `len` هي عدد **العناصر**، وليس عدد البايت.
///
/// # Safety
///
/// السلوك غير محدد في حالة انتهاك أي من الشروط التالية:
///
/// * `data` يجب أن يكون [valid] للقراءات لـ `len * mem::size_of::<T>()` من العديد من البايت ، ويجب محاذاته بشكل صحيح.وهذا يعني على وجه الخصوص:
///
///     * يجب احتواء نطاق الذاكرة الكامل لهذه الشريحة في كائن مخصص واحد!
///       لا يمكن للشرائح أبدًا أن تمتد عبر كائنات مخصصة متعددة.انظر [below](#incorrect-usage) للحصول على مثال بشكل غير صحيح لا يأخذ هذا في الاعتبار.
///     * `data` يجب أن تكون غير خالية ومحاذاة حتى للشرائح ذات الطول الصفري.
///     أحد أسباب ذلك هو أن تحسينات تخطيط التعداد قد تعتمد على محاذاة المراجع (بما في ذلك الشرائح من أي طول) وغير الفارغة لتمييزها عن البيانات الأخرى.
///     يمكنك الحصول على مؤشر يمكن استخدامه مثل `data` للشرائح ذات الطول الصفري باستخدام [`NonNull::dangling()`].
///
/// * `data` يجب أن يشير إلى قيم `len` متتالية تمت تهيئتها بشكل صحيح من النوع `T`.
///
/// * يجب ألا يتم تحوير الذاكرة المشار إليها بواسطة الشريحة التي تم إرجاعها طوال مدة عمر `'a` ، باستثناء داخل `UnsafeCell`.
///
/// * يجب ألا يزيد الحجم الإجمالي للشريحة `len * mem::size_of::<T>()` عن `isize::MAX`.
///   راجع وثائق الأمان الخاصة بـ [`pointer::offset`].
///
/// # Caveat
///
/// يتم الاستدلال على عمر الشريحة المرتجعة من استخدامها.
/// لمنع إساءة الاستخدام العرضي ، يُقترح ربط العمر بأي عمر مصدر آمن في السياق ، على سبيل المثال من خلال توفير وظيفة مساعدة تأخذ عمر قيمة المضيف للشريحة ، أو عن طريق التعليق التوضيحي الصريح.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // أظهر شريحة لعنصر واحد
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### استخدام غير صحيح
///
/// وظيفة `join_slices` التالية **غير سليمة** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // التأكيد أعلاه يضمن أن `fst` و `snd` متجاورتان ، ولكن ربما لا تزال موجودة في _different allocated objects_ ، وفي هذه الحالة يكون إنشاء هذه الشريحة سلوكًا غير محدد.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` و `b` كائنات مخصصة مختلفة ...
///     let a = 42;
///     let b = 27;
///     // ... التي يمكن مع ذلك وضعها بشكل متواصل في الذاكرة: |أ |ب |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// يؤدي نفس الوظيفة مثل [`from_raw_parts`] ، فيما عدا أنه يتم إرجاع شريحة قابلة للتغيير.
///
/// # Safety
///
/// السلوك غير محدد في حالة انتهاك أي من الشروط التالية:
///
/// * `data` يجب أن يكون [valid] لكل من عمليات القراءة والكتابة لـ `len * mem::size_of::<T>()` العديد من البايت ، ويجب محاذاته بشكل صحيح.وهذا يعني على وجه الخصوص:
///
///     * يجب احتواء نطاق الذاكرة الكامل لهذه الشريحة في كائن مخصص واحد!
///       لا يمكن للشرائح أبدًا أن تمتد عبر كائنات مخصصة متعددة.
///     * `data` يجب أن تكون غير خالية ومحاذاة حتى للشرائح ذات الطول الصفري.
///     أحد أسباب ذلك هو أن تحسينات تخطيط التعداد قد تعتمد على محاذاة المراجع (بما في ذلك الشرائح من أي طول) وغير الفارغة لتمييزها عن البيانات الأخرى.
///
///     يمكنك الحصول على مؤشر يمكن استخدامه مثل `data` للشرائح ذات الطول الصفري باستخدام [`NonNull::dangling()`].
///
/// * `data` يجب أن يشير إلى قيم `len` متتالية تمت تهيئتها بشكل صحيح من النوع `T`.
///
/// * يجب ألا يتم الوصول إلى الذاكرة المشار إليها بواسطة الشريحة التي تم إرجاعها من خلال أي مؤشر آخر (غير مشتق من قيمة الإرجاع) طوال مدة العمر `'a`.
///   كلا الوصول للقراءة والكتابة ممنوع.
///
/// * يجب ألا يزيد الحجم الإجمالي للشريحة `len * mem::size_of::<T>()` عن `isize::MAX`.
///   راجع وثائق الأمان الخاصة بـ [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// يحول مرجعًا إلى T إلى شريحة بطول 1 (بدون نسخ).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// يحول مرجعًا إلى T إلى شريحة بطول 1 (بدون نسخ).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}