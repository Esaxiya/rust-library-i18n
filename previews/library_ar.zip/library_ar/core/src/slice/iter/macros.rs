//! وحدات الماكرو المستخدمة بواسطة مكررات الشريحة.

// يُحدث التضمين فارغًا ولين فرقًا كبيرًا في الأداء
macro_rules! is_empty {
    // الطريقة التي نشفّر بها طول مكرر ZST ، يعمل هذا مع كل من ZST وغير ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// للتخلص من بعض عمليات التحقق من الحدود (انظر `position`) ، نحسب الطول بطريقة غير متوقعة إلى حد ما.
// (تم الاختبار عن طريق "codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // نحن نستخدم أحيانًا داخل كتلة غير آمنة

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // يستخدم _cannot_ `unchecked_sub` لأننا نعتمد على الالتفاف لتمثيل طول مكررات شريحة ZST الطويلة.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // نحن نعلم أن `start <= end` ، لذلك يمكن أن تفعل ما هو أفضل من `offset_from` ، والذي يحتاج إلى التعامل مع التوقيع.
            // من خلال تحديد العلامات المناسبة هنا ، يمكننا إخبار LLVM بذلك ، مما يساعده على إزالة عمليات التحقق من الحدود.
            // الأمان: حسب النوع الثابت ، `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // من خلال إخبار LLVM أيضًا أن المؤشرات متباعدة عن طريق مضاعف دقيق لحجم النوع ، يمكنه تحسين `len() == 0` وصولاً إلى `start == end` بدلاً من `(end - start) < size`.
            //
            // الأمان: حسب النوع الثابت ، تتم محاذاة المؤشرات بحيث يكون ملف
            //         يجب أن تكون المسافة بينهما من مضاعفات حجم النقطة
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// التعريف المشترك لمكررات `Iter` و `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // يُرجع العنصر الأول ويحرك بداية المكرر للأمام بمقدار 1.
        // يحسن الأداء بشكل كبير مقارنة بوظيفة مضمنة.
        // يجب ألا يكون المكرر فارغًا.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // تُرجع العنصر الأخير وتحرك نهاية المكرر للخلف بمقدار 1.
        // يحسن الأداء بشكل كبير مقارنة بوظيفة مضمنة.
        // يجب ألا يكون المكرر فارغًا.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // يقلص المكرر عندما يكون T هو ZST ، عن طريق تحريك نهاية المكرر للخلف بمقدار `n`.
        // `n` يجب ألا يتجاوز `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // وظيفة المساعد لإنشاء شريحة من المكرر.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // الأمان: تم إنشاء المكرر من شريحة بمؤشر
                // `self.ptr` وطول `len!(self)`.
                // هذا يضمن استيفاء جميع المتطلبات الأساسية لـ `from_raw_parts`.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // وظيفة المساعد لتحريك بداية المكرر للأمام بواسطة عناصر `offset` ، وإرجاع البداية القديمة.
            //
            // غير آمن لأن الإزاحة يجب ألا تتجاوز `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // الأمان: يضمن المتصل أن `offset` لا يتجاوز `self.len()` ،
                    // لذلك هذا المؤشر الجديد داخل `self` وبالتالي مضمون أنه غير فارغ.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // وظيفة المساعد لتحريك نهاية المكرر للخلف بواسطة عناصر `offset` ، وإرجاع النهاية الجديدة.
            //
            // غير آمن لأن الإزاحة يجب ألا تتجاوز `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // الأمان: يضمن المتصل أن `offset` لا يتجاوز `self.len()` ،
                    // وهو مضمون لعدم تجاوز `isize`.
                    // أيضًا ، يكون المؤشر الناتج في حدود `slice` ، والذي يفي بالمتطلبات الأخرى لـ `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // يمكن تنفيذه مع الشرائح ، ولكن هذا يتجنب عمليات التحقق من الحدود

                // الأمان: مكالمات `assume` آمنة منذ مؤشر بدء الشريحة
                // يجب أن تكون غير خالية ، ويجب أن تحتوي الشرائح التي تزيد عن ZST أيضًا على مؤشر نهاية غير فارغ.
                // يعد الاتصال بـ `next_unchecked!` آمنًا لأننا نتحقق مما إذا كان المكرر فارغًا أولاً.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // هذا المكرر فارغ الآن.
                    if mem::size_of::<T>() == 0 {
                        // يتعين علينا القيام بذلك بهذه الطريقة لأن `ptr` قد لا يكون أبدًا 0 ، ولكن `end` يمكن أن يكون (بسبب التغليف).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // الأمان: لا يمكن أن تكون النهاية 0 إذا لم يكن T ليس ZST لأن ptr ليس 0 والنهاية>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // السلامة: نحن في الحدود.`post_inc_start` يفعل الشيء الصحيح حتى مع ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // نتجاوز التنفيذ الافتراضي ، الذي يستخدم `try_fold` ، لأن هذا التنفيذ البسيط يولد أقل من LLVM IR ويكون التجميع أسرع.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // نتجاوز التنفيذ الافتراضي ، الذي يستخدم `try_fold` ، لأن هذا التنفيذ البسيط يولد أقل من LLVM IR ويكون التجميع أسرع.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // نتجاوز التنفيذ الافتراضي ، الذي يستخدم `try_fold` ، لأن هذا التنفيذ البسيط يولد أقل من LLVM IR ويكون التجميع أسرع.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // نتجاوز التنفيذ الافتراضي ، الذي يستخدم `try_fold` ، لأن هذا التنفيذ البسيط يولد أقل من LLVM IR ويكون التجميع أسرع.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // نتجاوز التنفيذ الافتراضي ، الذي يستخدم `try_fold` ، لأن هذا التنفيذ البسيط يولد أقل من LLVM IR ويكون التجميع أسرع.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // نتجاوز التنفيذ الافتراضي ، الذي يستخدم `try_fold` ، لأن هذا التنفيذ البسيط يولد أقل من LLVM IR ويكون التجميع أسرع.
            // أيضًا ، يتجنب `assume` فحص الحدود.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // السلامة: نحن نضمن أن نكون في حدود الحلقة الثابتة:
                        // عندما تقوم `i >= n` ، `self.next()` بإرجاع `None` وتنكسر الحلقة.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // نتجاوز التنفيذ الافتراضي ، الذي يستخدم `try_fold` ، لأن هذا التنفيذ البسيط يولد أقل من LLVM IR ويكون التجميع أسرع.
            // أيضًا ، يتجنب `assume` فحص الحدود.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // الأمان: يجب أن يكون `i` أقل من `n` نظرًا لأنه يبدأ من `n`
                        // وهو يتناقص فقط.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // الأمان: يجب أن يضمن المتصل أن `i` في حدود
                // الشريحة الأساسية ، لذلك لا يمكن لـ `i` تجاوز `isize` ، والمراجع التي تم إرجاعها مضمونة للإشارة إلى عنصر من الشريحة ، وبالتالي فهي مضمونة لتكون صالحة.
                //
                // لاحظ أيضًا أن المتصل يضمن أيضًا عدم استدعائنا مطلقًا بنفس الفهرس مرة أخرى ، وأنه لا يتم استدعاء أي طرق أخرى من شأنها الوصول إلى هذه الشريحة الفرعية ، لذلك فمن الصحيح أن يكون المرجع المُعاد قابلاً للتغيير في حالة
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // يمكن تنفيذه مع الشرائح ، ولكن هذا يتجنب عمليات التحقق من الحدود

                // الأمان: مكالمات `assume` آمنة لأن مؤشر بدء الشريحة يجب أن يكون غير فارغ ،
                // والشرائح فوق ZSTs يجب أن تحتوي أيضًا على مؤشر نهاية غير فارغ.
                // يعد الاتصال بـ `next_back_unchecked!` آمنًا لأننا نتحقق مما إذا كان المكرر فارغًا أولاً.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // هذا المكرر فارغ الآن.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // السلامة: نحن في الحدود.`pre_dec_end` يفعل الشيء الصحيح حتى مع ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}