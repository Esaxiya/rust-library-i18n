// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// يقوم بتدوير النطاق `[mid-left, mid+right)` بحيث يصبح العنصر عند `mid` هو العنصر الأول.بالتساوي ، قم بتدوير عناصر النطاق `left` إلى اليسار أو عناصر `right` إلى اليمين.
///
/// # Safety
///
/// يجب أن يكون النطاق المحدد صالحًا للقراءة والكتابة.
///
/// # Algorithm
///
/// الخوارزمية 1 تستخدم للقيم الصغيرة لـ `left + right` أو `T` الكبيرة.
/// يتم نقل العناصر إلى مواضعها النهائية واحدًا تلو الآخر بدءًا من `mid - left` وتتقدم بمقدار `right` خطوات modulo `left + right` ، بحيث يلزم مؤقت واحد فقط.
/// في النهاية ، نعود إلى `mid - left`.
/// ومع ذلك ، إذا لم يكن `gcd(left + right, right)` 1 ، فإن الخطوات المذكورة أعلاه تخطت العناصر.
/// على سبيل المثال:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// لحسن الحظ ، يكون عدد العناصر التي تم تخطيها بين العناصر النهائية متساويًا دائمًا ، لذلك يمكننا فقط موازنة موضع البداية وإجراء المزيد من الجولات (إجمالي عدد الجولات هو `gcd(left + right, right)` value).
///
/// والنتيجة النهائية هي أن جميع العناصر يتم الانتهاء منها مرة واحدة فقط.
///
/// يتم استخدام الخوارزمية 2 إذا كان `left + right` كبيرًا ولكن `min(left, right)` صغير بما يكفي ليلائم المخزن المؤقت المكدس.
/// يتم نسخ عناصر `min(left, right)` إلى المخزن المؤقت ، ويتم تطبيق `memmove` على العناصر الأخرى ، ويتم نقل العناصر الموجودة على المخزن المؤقت إلى الفتحة الموجودة على الجانب الآخر من المكان الذي نشأت فيه.
///
/// تتفوق الخوارزميات التي يمكن توجيهها على ما سبق بمجرد أن يصبح `left + right` كبيرًا بدرجة كافية.
/// يمكن توجيه الخوارزمية 1 عن طريق التقسيم وإجراء العديد من الجولات في وقت واحد ، ولكن هناك عدد قليل جدًا من الجولات في المتوسط حتى يصبح `left + right` هائلاً ، وتكون أسوأ حالة لجولة واحدة دائمًا.
/// بدلاً من ذلك ، تستخدم الخوارزمية 3 التبديل المتكرر لعناصر `min(left, right)` حتى يتم ترك مشكلة تدوير أصغر.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// عندما `left < right` يحدث التبادل من اليسار بدلاً من ذلك.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. يمكن أن تفشل الخوارزميات أدناه إذا لم يتم التحقق من هذه الحالات
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // الخوارزمية 1 تشير علامات الفرشاة الدقيقة إلى أن متوسط الأداء للتحولات العشوائية أفضل على طول الطريق حتى حوالي `left + right == 32` ، ولكن أسوأ أداء للحالة يصل إلى حوالي 16.
            // تم اختيار 24 كأرض وسطي.
            // إذا كان حجم `T` أكبر من 4 `usize`s ، فإن هذه الخوارزمية تتفوق أيضًا على الخوارزميات الأخرى.
            //
            //
            let x = unsafe { mid.sub(left) };
            // بداية الجولة الأولى
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` يمكن العثور عليها مسبقًا عن طريق حساب `gcd(left + right, right)` ، ولكن من الأسرع القيام بحلقة واحدة تحسب gcd كأثر جانبي ، ثم القيام بباقي القطعة
            //
            //
            let mut gcd = right;
            // تكشف المعايير أنه من الأسرع تبديل المؤقتات على طول الطريق بدلاً من قراءة واحدة مؤقتة مرة واحدة ، والنسخ إلى الوراء ، ثم كتابة ذلك المؤقت في النهاية.
            // ربما يرجع ذلك إلى حقيقة أن تبديل أو استبدال المؤقتات يستخدم عنوان ذاكرة واحدًا فقط في الحلقة بدلاً من الحاجة إلى إدارة اثنين.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // بدلاً من زيادة `i` ثم التحقق مما إذا كان خارج الحدود ، نتحقق مما إذا كان `i` سيخرج عن الحدود في الزيادة التالية.
                // هذا يمنع أي التفاف للمؤشرات أو `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // نهاية الجولة الأولى
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // يجب أن يكون هذا الشرط هنا إذا كان `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // قم بإنهاء القطعة بمزيد من الجولات
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` ليس من النوع ذي الحجم الصفري ، لذا لا بأس من القسمة على حجمه.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // الخوارزمية 2 إن `[T; 0]` هنا لضمان محاذاة بشكل مناسب لـ T.
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // الخوارزمية 3 هناك طريقة بديلة للمبادلة تتضمن إيجاد مكان آخر تبادل لهذه الخوارزمية ، والتبديل باستخدام ذلك الجزء الأخير بدلاً من تبديل الأجزاء المجاورة مثل هذه الخوارزمية ، ولكن هذه الطريقة لا تزال أسرع.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // الخوارزمية 3 `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}