// التنفيذ الأصلي مأخوذ من rust-memchr.
// حقوق الطبع والنشر 2015 أندرو جالانت وبلوس ونيكولاس كوخ

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// استخدم الاقتطاع.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// تُرجع `true` إذا احتوى `x` على أي بايت صفري.
///
/// من *المسائل الحسابية*، ج. أرندت:
///
/// "الفكرة هي طرح واحد من كل بايت ثم البحث عن البايت حيث انتشر الاقتراض على طول الطريق إلى أهم
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// إرجاع الفهرس الأول المطابق للبايت `x` في `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // مسار سريع للشرائح الصغيرة
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // ابحث عن قيمة بايت واحد من خلال قراءة كلمتين `usize` في وقت واحد.
    //
    // تقسيم `text` إلى ثلاثة أجزاء
    // - الجزء الأولي غير المحاذي ، قبل محاذاة الكلمة الأولى في النص
    // - الجسم ، مسح بواسطة كلمتين في وقت واحد
    // - الجزء المتبقي الأخير ، <حجم كلمتين

    // البحث حتى حد محاذي
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // ابحث في النص الأساسي للنص
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // الأمان: يضمن مسند الوقت مسافة لا تقل عن 2 * usize_bytes
        // بين الإزاحة ونهاية الشريحة.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // كسر إذا كان هناك بايت مطابق
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // أوجد البايت بعد النقطة التي توقفت فيها حلقة الجسم.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// تُرجع الفهرس الأخير المطابق للبايت `x` في `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // ابحث عن قيمة بايت واحد من خلال قراءة كلمتين `usize` في وقت واحد.
    //
    // تقسيم `text` إلى ثلاثة أجزاء:
    // - ذيل غير محاذي ، بعد آخر عنوان محاذي للكلمة في النص ،
    // - الجسم ، مسحًا ضوئيًا بكلمتين في وقت واحد ،
    // - البايتات الأولى المتبقية ، <حجم الكلمة 2.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // نسمي هذا فقط للحصول على طول البادئة واللاحقة.
        // في المنتصف نقوم دائمًا بمعالجة قطعتين في وقت واحد.
        // الأمان: يعد تحويل `[u8]` إلى `[usize]` آمنًا باستثناء اختلافات الحجم التي يتم التعامل معها بواسطة `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // ابحث في نص النص ، وتأكد من أننا لا نتخطى min_aligned_offset.
    // تتم محاذاة الإزاحة دائمًا ، لذا فإن مجرد اختبار `>` يكفي وتجنب الفائض المحتمل.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // الأمان: يبدأ الإزاحة من len ، suffix.len() ، طالما أنها أكبر من
        // min_aligned_offset (prefix.len()) المسافة المتبقية هي على الأقل 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // استراحة إذا كان هناك بايت مطابق.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // ابحث عن البايت قبل النقطة التي توقفت فيها حلقة الجسم.
    text[..offset].iter().rposition(|elt| *elt == x)
}