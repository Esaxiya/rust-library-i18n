//! العمليات على ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// للتحقق مما إذا كانت جميع البايتات في هذه الشريحة ضمن نطاق ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// التحقق من أن شريحتين متطابقتان مع ASCII غير حساس لحالة الأحرف.
    ///
    /// مثل `to_ascii_lowercase(a) == to_ascii_lowercase(b)` ، ولكن بدون تخصيص ونسخ الموقتات.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// يحول هذه الشريحة إلى ما يعادلها بأحرف كبيرة ASCII في الموضع.
    ///
    /// يتم تعيين أحرف ASCII من 'a' إلى 'z' إلى 'A' إلى 'Z' ، لكن الأحرف غير ASCII لم تتغير.
    ///
    /// لإرجاع قيمة كبيرة جديدة بدون تعديل القيمة الحالية ، استخدم [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// يحول هذه الشريحة إلى مكافئها بأحرف صغيرة ASCII في المكان.
    ///
    /// يتم تعيين أحرف ASCII من 'A' إلى 'Z' إلى 'a' إلى 'z' ، لكن الأحرف غير ASCII لم تتغير.
    ///
    /// لإرجاع قيمة صغيرة جديدة بدون تعديل القيمة الحالية ، استخدم [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// لعرض `true` إذا كان أي بايت في الكلمة `v` هو nonascii (>=128).
/// Snarfed من `../str/mod.rs` ، والذي يفعل شيئًا مشابهًا للتحقق من صحة utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// اختبار ASCII المحسن الذي سيستخدم عمليات الاستخدام في وقت واحد بدلاً من عمليات البايت في كل مرة (إن أمكن).
///
/// الخوارزمية التي نستخدمها هنا بسيطة جدًا.إذا كان `s` قصيرًا جدًا ، فنحن فقط نتحقق من كل بايت وننتهي من ذلك.غير ذلك:
///
/// - اقرأ الكلمة الأولى بحمل غير محاذي.
/// - قم بمحاذاة المؤشر ، واقرأ الكلمات التالية حتى تنتهي بأحمال محاذاة.
/// - اقرأ آخر `usize` من `s` بحمل غير متوازي.
///
/// إذا كان أي من هذه الأحمال ينتج شيئًا ما يعود `contains_nonascii` (above) به صحيحًا ، فإننا نعلم أن الإجابة خاطئة.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // إذا لم نحصل على أي شيء من تنفيذ كلمة في وقت ، فارجع إلى الحلقة العددية.
    //
    // نقوم بذلك أيضًا للبنى حيث لا يكون `size_of::<usize>()` محاذاة كافية لـ `usize` ، لأنها حالة edge غريبة.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // نقرأ دائمًا الكلمة الأولى غير المحاذاة ، مما يعني أن `align_offset` هي
    // 0 ، فسنقرأ نفس القيمة مرة أخرى للقراءة المحاذاة.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // الأمان: نتحقق من `len < USIZE_SIZE` أعلاه.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // لقد فحصنا هذا أعلاه ، ضمنيًا إلى حد ما.
    // لاحظ أن `offset_to_aligned` إما `align_offset` أو `USIZE_SIZE` ، وكلاهما تم التحقق منه صراحةً أعلاه.
    //
    debug_assert!(offset_to_aligned <= len);

    // الأمان: word_ptr هو ptr المستخدم (المحاذاة بشكل صحيح) الذي نستخدمه لقراءة ملف
    // الجزء الأوسط من الشريحة.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` هو فهرس بايت لـ `word_ptr` ، يستخدم لفحص نهاية الحلقة.
    let mut byte_pos = offset_to_aligned;

    // تتحقق البارانويا من المحاذاة ، لأننا على وشك القيام بمجموعة من الأحمال غير المحاذية.
    // من الناحية العملية ، يجب أن يكون هذا مستحيلًا باستثناء وجود خطأ في `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // اقرأ الكلمات اللاحقة حتى آخر كلمة تمت محاذاتها ، باستثناء آخر كلمة تمت محاذاتها بمفردها ليتم إجراؤها في فحص الذيل لاحقًا ، للتأكد من أن الذيل دائمًا `usize` واحد على الأكثر إلى branch `byte_pos == len` الإضافي.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // تحقق من صحة ما إذا كانت القراءة في الحدود
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // وأن افتراضاتنا حول `byte_pos` تصمد.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // الأمان: نحن نعلم أن `word_ptr` محاذي بشكل صحيح (بسبب
        // "align_offset") ، ونعلم أن لدينا بايتات كافية بين `word_ptr` والنهاية
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // الأمان: نحن نعلم أن `byte_pos <= len - USIZE_SIZE` ، مما يعني ذلك
        // بعد `add` ، سيكون `word_ptr` في النهاية على الأكثر.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // تحقق من السلامة الصحية للتأكد من أنه لم يتبق سوى `usize` واحد.
    // يجب ضمان ذلك من خلال حالة الحلقة الخاصة بنا.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // الأمان: يعتمد هذا على `len >= USIZE_SIZE` ، والذي نتحقق منه في البداية.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}