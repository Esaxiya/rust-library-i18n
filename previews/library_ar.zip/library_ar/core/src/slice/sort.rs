//! فرز الشرائح
//!
//! تحتوي هذه الوحدة على خوارزمية فرز تعتمد على الفرز السريع لأورسون بيترز ، والذي تم نشره في: <https://github.com/orlp/pdqsort>
//!
//!
//! الفرز غير المستقر متوافق مع libcore لأنه لا يخصص ذاكرة ، على عكس تطبيق الفرز المستقر.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// عند إسقاطها ، يتم النسخ من `src` إلى `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // الأمان: هذه فئة مساعد.
        //          يرجى الرجوع إلى استخدامه للصحة.
        //          وبالتحديد ، يجب التأكد من أن `src` و `dst` لا يتداخلان كما هو مطلوب بواسطة `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// ينقل العنصر الأول إلى اليمين حتى يواجه عنصرًا أكبر أو مساويًا.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // الأمان: تتضمن العمليات غير الآمنة أدناه فهرسة بدون فحص ملزم (`get_unchecked` و `get_unchecked_mut`)
    // ونسخ ذاكرة (`ptr::copy_nonoverlapping`).
    //
    // أ.الفهرسة:
    //  1. تحققنا من حجم المصفوفة إلى>=2.
    //  2. كل الفهرسة التي سنفعلها ستكون دائمًا بين {0 <= index < len} على الأكثر.
    //
    // ب.نسخ الذاكرة
    //  1. نحصل على مؤشرات للمراجع التي نضمن صحتها.
    //  2. لا يمكن أن تتداخل لأننا نحصل على مؤشرات للاختلاف في مؤشرات الشريحة.
    //     وهي `i` و `i-1`.
    //  3. إذا تمت محاذاة الشريحة بشكل صحيح ، يتم محاذاة العناصر بشكل صحيح.
    //     يتحمل المتصل مسؤولية التأكد من محاذاة الشريحة بشكل صحيح.
    //
    // انظر التعليقات أدناه لمزيد من التفاصيل.
    unsafe {
        // إذا كان العنصران الأولان خارج الترتيب ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // اقرأ العنصر الأول في متغير مخصص للمكدس.
            // إذا كانت عملية المقارنة التالية panics ، فسيتم إسقاط `hole` وكتابة العنصر تلقائيًا في الشريحة.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // انقل العنصر `i`-th مكانًا واحدًا إلى اليسار ، وبالتالي نقل الفتحة إلى اليمين.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` يتم إسقاطها وبالتالي نسخ `tmp` في الفتحة المتبقية في `v`.
        }
    }
}

/// ينقل العنصر الأخير إلى اليسار حتى يواجه عنصرًا أصغر أو متساويًا.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // الأمان: تتضمن العمليات غير الآمنة أدناه فهرسة بدون فحص ملزم (`get_unchecked` و `get_unchecked_mut`)
    // ونسخ ذاكرة (`ptr::copy_nonoverlapping`).
    //
    // أ.الفهرسة:
    //  1. تحققنا من حجم المصفوفة إلى>=2.
    //  2. كل الفهرسة التي سنفعلها ستكون دائمًا بين `0 <= index < len-1` على الأكثر.
    //
    // ب.نسخ الذاكرة
    //  1. نحصل على مؤشرات للمراجع التي نضمن صحتها.
    //  2. لا يمكن أن تتداخل لأننا نحصل على مؤشرات للاختلاف في مؤشرات الشريحة.
    //     وهي `i` و `i+1`.
    //  3. إذا تمت محاذاة الشريحة بشكل صحيح ، يتم محاذاة العناصر بشكل صحيح.
    //     يتحمل المتصل مسؤولية التأكد من محاذاة الشريحة بشكل صحيح.
    //
    // انظر التعليقات أدناه لمزيد من التفاصيل.
    unsafe {
        // إذا كان العنصران الأخيران خارج الترتيب ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // اقرأ العنصر الأخير في متغير مخصص للمكدس.
            // إذا كانت عملية المقارنة التالية panics ، فسيتم إسقاط `hole` وكتابة العنصر تلقائيًا في الشريحة.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // انقل العنصر `i`-th مكانًا واحدًا إلى اليمين ، وبالتالي نقل الفتحة إلى اليسار.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` يتم إسقاطها وبالتالي نسخ `tmp` في الفتحة المتبقية في `v`.
        }
    }
}

/// يفرز شريحة جزئيًا عن طريق إزاحة عدة عناصر خارج الترتيب حولها.
///
/// تُرجع `true` إذا تم فرز الشريحة في النهاية.هذه الوظيفة هي *O*(*n*) أسوأ حالة.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // العدد الأقصى للأزواج المتجاورة خارج الترتيب التي سيتم إزاحتها.
    const MAX_STEPS: usize = 5;
    // إذا كانت الشريحة أقصر من ذلك ، فلا تقم بإزاحة أي عناصر.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // الأمان: لقد قمنا بالفعل صراحةً بالتحقق الملزم باستخدام `i < len`.
        // جميع الفهرسة اللاحقة لدينا هي فقط في النطاق `0 <= index < len`
        unsafe {
            // أوجد الزوج التالي من العناصر المجاورة خارج الترتيب.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // هل انتهينا؟
        if i == len {
            return true;
        }

        // لا تنقل العناصر على المصفوفات القصيرة ، حيث أن لها تكلفة أداء.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // قم بتبديل زوج العناصر الموجود.هذا يضعهم في الترتيب الصحيح.
        v.swap(i - 1, i);

        // انقل العنصر الأصغر إلى اليسار.
        shift_tail(&mut v[..i], is_less);
        // انقل العنصر الأكبر إلى اليمين.
        shift_head(&mut v[i..], is_less);
    }

    // لم ينجح في فرز الشريحة في عدد محدود من الخطوات.
    false
}

/// يفرز شريحة باستخدام فرز الإدخال ، وهو *O*(*n*^ 2) أسوأ حالة.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// يفرز `v` باستخدام heapsort ، والذي يضمن *O*(*n*\*log(* n*)) أسوأ حالة.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // هذه الكومة الثنائية تحترم `parent >= child` الثابت.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // أطفال `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // اختر الطفل الأكبر.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // توقف إذا كان الثابت ثابتًا عند `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // قم بتبديل `node` مع الطفل الأكبر ، وتحرك خطوة واحدة لأسفل ، واستمر في الغربلة.
            v.swap(node, greater);
            node = greater;
        }
    };

    // بناء الكومة في الوقت الخطي.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // انبثق أقصى عدد من العناصر من الكومة.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// تقسم `v` إلى عناصر أصغر من `pivot` ، متبوعة بعناصر أكبر من أو تساوي `pivot`.
///
///
/// تُرجع عدد العناصر الأصغر من `pivot`.
///
/// يتم تنفيذ التقسيم كتلة تلو كتلة لتقليل تكلفة عمليات التفريع.
/// يتم تقديم هذه الفكرة في ورقة [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // عدد العناصر في الكتلة النموذجية.
    const BLOCK: usize = 128;

    // تكرر خوارزمية التقسيم الخطوات التالية حتى الاكتمال:
    //
    // 1. تتبع كتلة من الجانب الأيسر لتحديد العناصر الأكبر من أو المساوية للمحور.
    // 2. تتبع كتلة من الجانب الأيمن لتحديد العناصر الأصغر من المحور.
    // 3. تبادل العناصر المحددة بين الجانب الأيسر والأيمن.
    //
    // نحتفظ بالمتغيرات التالية لكتلة من العناصر:
    //
    // 1. `block` - عدد العناصر في الكتلة.
    // 2. `start` - ابدأ المؤشر في صفيف `offsets`.
    // 3. `end` - مؤشر النهاية في صفيف `offsets`.
    // 4. `تعويضات ، مؤشرات العناصر خارج الترتيب داخل الكتلة.

    // الكتلة الحالية على الجانب الأيسر (من `l` إلى `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // الكتلة الحالية على الجانب الأيمن (من `r.sub(block_r)` to `r`).
    // الأمان: تشير وثائق .add() على وجه التحديد إلى أن `vec.as_ptr().add(vec.len())` آمن دائمًا
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: عندما نحصل على VLAs ، حاول إنشاء مجموعة واحدة بطول `min(v.len() ، 2 * BLOCK) بدلاً من ذلك
    // من صفيفتين ثابتتين الحجم بطول `BLOCK`.قد تكون VLA أكثر كفاءة في التخزين المؤقت.

    // إرجاع عدد العناصر بين المؤشرات `l` (inclusive) و `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // لقد انتهينا من التقسيم كتلة تلو الأخرى عندما يقترب `l` و `r` جدًا.
        // ثم نقوم ببعض أعمال التصحيح من أجل تقسيم العناصر المتبقية بينهما.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // عدد العناصر المتبقية (لا يزال غير مقارن بالمحور).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // اضبط أحجام الكتلة بحيث لا تتداخل الكتلة اليمنى واليسرى ، ولكن اجعلها محاذاة تمامًا لتغطية الفجوة المتبقية بالكامل.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // تتبع عناصر `block_l` من الجانب الأيسر.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // الأمان: تتضمن عمليات عدم الأمان أدناه استخدام `offset`.
                //         وفقًا للشروط التي تتطلبها الوظيفة ، فإننا نلبيها للأسباب التالية:
                //         1. `offsets_l` مكدس مخصص ، وبالتالي يعتبر كائنًا مخصصًا منفصلاً.
                //         2. تقوم الدالة `is_less` بإرجاع `bool`.
                //            لن يؤدي إرسال `bool` إلى تجاوز `isize` مطلقًا.
                //         3. لقد ضمننا أن `block_l` سيكون `<= BLOCK`.
                //            بالإضافة إلى ذلك ، تم ضبط `end_l` مبدئيًا على مؤشر البداية لـ `offsets_` الذي تم الإعلان عنه في المكدس.
                //            وبالتالي ، نعلم أنه حتى في أسوأ الحالات (جميع استدعاءات `is_less` ترجع كاذبة) سنكون فقط 1 بايت على الأكثر في النهاية.
                //        هناك عملية أخرى غير آمنة هنا وهي إلغاء الإشارة إلى `elem`.
                //        ومع ذلك ، كان `elem` في البداية مؤشر البداية للشريحة وهو صالح دائمًا.
                unsafe {
                    // مقارنة بدون فروع.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // تتبع عناصر `block_r` من الجانب الأيمن.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // الأمان: تتضمن عمليات عدم الأمان أدناه استخدام `offset`.
                //         وفقًا للشروط التي تتطلبها الوظيفة ، فإننا نلبيها للأسباب التالية:
                //         1. `offsets_r` مكدس مخصص ، وبالتالي يعتبر كائنًا مخصصًا منفصلاً.
                //         2. تقوم الدالة `is_less` بإرجاع `bool`.
                //            لن يؤدي إرسال `bool` إلى تجاوز `isize` مطلقًا.
                //         3. لقد ضمننا أن `block_r` سيكون `<= BLOCK`.
                //            بالإضافة إلى ذلك ، تم ضبط `end_r` مبدئيًا على مؤشر البداية لـ `offsets_` الذي تم الإعلان عنه في المكدس.
                //            وبالتالي ، نعلم أنه حتى في أسوأ الحالات (جميع استدعاءات `is_less` تعود صحيحًا) سنكون فقط 1 بايت على الأكثر في النهاية.
                //        هناك عملية أخرى غير آمنة هنا وهي إلغاء الإشارة إلى `elem`.
                //        ومع ذلك ، كان `elem` في البداية `1 *sizeof(T)` بعد النهاية وقمنا بإنقاصه بمقدار `1* sizeof(T)` قبل الوصول إليه.
                //        بالإضافة إلى ذلك ، تم التأكيد على أن `block_r` أقل من `BLOCK` وبالتالي فإن `elem` ستشير على الأكثر إلى بداية الشريحة.
                unsafe {
                    // مقارنة بدون فروع.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // عدد العناصر خارج الترتيب المطلوب تبديلها بين الجانب الأيسر والأيمن.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // بدلاً من تبديل زوج واحد في ذلك الوقت ، يكون إجراء تبديل دوري أكثر كفاءة.
            // لا يعد هذا مكافئًا تمامًا للتبديل ، ولكنه ينتج نتيجة مماثلة باستخدام عمليات ذاكرة أقل.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // تم نقل جميع العناصر خارج الترتيب في الكتلة اليسرى.انتقل إلى الكتلة التالية.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // تم نقل جميع العناصر خارج الترتيب في الكتلة اليمنى.انتقل إلى الكتلة السابقة.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // كل ما تبقى الآن هو على الأكثر كتلة واحدة (إما اليسار أو اليمين) مع عناصر خارج الترتيب يجب نقلها.
    // يمكن ببساطة نقل هذه العناصر المتبقية إلى النهاية داخل الكتلة الخاصة بهم.
    //

    if start_l < end_l {
        // الكتلة اليسرى باقية.
        // انقل العناصر المتبقية خارج الترتيب إلى أقصى اليمين.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // تبقى الكتلة الصحيحة.
        // انقل العناصر المتبقية خارج الترتيب إلى أقصى اليسار.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // لا شيء آخر لنفعله ، لقد انتهينا.
        width(v.as_mut_ptr(), l)
    }
}

/// تقسم `v` إلى عناصر أصغر من `v[pivot]` ، متبوعة بعناصر أكبر من أو تساوي `v[pivot]`.
///
///
/// تُرجع مجموعة من:
///
/// 1. عدد العناصر الأصغر من `v[pivot]`.
/// 2. صحيح إذا تم تقسيم `v` بالفعل.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // ضع المحور في بداية الشريحة.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // اقرأ المحور في متغير مخصص للمكدس لتحقيق الكفاءة.
        // إذا كانت عملية المقارنة التالية panics ، فستتم إعادة كتابة المحور تلقائيًا في الشريحة.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // ابحث عن أول زوج من العناصر خارج الترتيب.
        let mut l = 0;
        let mut r = v.len();

        // الأمان: يتضمن عدم الأمان أدناه فهرسة مصفوفة.
        // بالنسبة للأول: لقد قمنا بالفعل بفحص الحدود هنا باستخدام `l < r`.
        // بالنسبة للثاني: لدينا في البداية `l == 0` و `r == v.len()` وتحققنا من `l < r` في كل عملية فهرسة.
        //                     من هنا نعلم أن `r` يجب أن يكون `r == l` على الأقل والذي ثبت أنه صالح من الأول.
        unsafe {
            // أوجد العنصر الأول أكبر من أو يساوي المحور.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // أوجد العنصر الأخير الأصغر من المحور.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` يخرج عن النطاق ويكتب المحور (وهو متغير مخصص للمكدس) مرة أخرى في الشريحة حيث كان في الأصل.
        // هذه الخطوة حاسمة في ضمان السلامة!
        //
    };

    // ضع المحور بين القسمين.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// يقسم `v` إلى عناصر تساوي `v[pivot]` متبوعة بعناصر أكبر من `v[pivot]`.
///
/// تُرجع عدد العناصر التي تساوي المحور.
/// من المفترض أن `v` لا يحتوي على عناصر أصغر من المحور.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // ضع المحور في بداية الشريحة.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // اقرأ المحور في متغير مخصص للمكدس لتحقيق الكفاءة.
    // إذا كانت عملية المقارنة التالية panics ، فستتم إعادة كتابة المحور تلقائيًا في الشريحة.
    // الأمان: المؤشر هنا صالح لأنه تم الحصول عليه من مرجع إلى شريحة.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // الآن قم بتقسيم الشريحة.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // الأمان: يتضمن عدم الأمان أدناه فهرسة مصفوفة.
        // بالنسبة للأول: لقد قمنا بالفعل بفحص الحدود هنا باستخدام `l < r`.
        // بالنسبة للثاني: لدينا في البداية `l == 0` و `r == v.len()` وتحققنا من `l < r` في كل عملية فهرسة.
        //                     من هنا نعلم أن `r` يجب أن يكون `r == l` على الأقل والذي ثبت أنه صالح من الأول.
        unsafe {
            // أوجد العنصر الأول أكبر من المحور.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // أوجد العنصر الأخير الذي يساوي المحور.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // هل انتهينا؟
            if l >= r {
                break;
            }

            // قم بتبديل الزوج الموجود من العناصر خارج الترتيب.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // وجدنا عناصر `l` تساوي المحور.أضف 1 لحساب المحور نفسه.
    l + 1

    // `_pivot_guard` يخرج عن النطاق ويكتب المحور (وهو متغير مخصص للمكدس) مرة أخرى في الشريحة حيث كان في الأصل.
    // هذه الخطوة حاسمة في ضمان السلامة!
}

/// ينثر بعض العناصر في محاولة لكسر الأنماط التي قد تسبب أقسامًا غير متوازنة في الترتيب السريع.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // مولد رقم عشوائي من ورقة "Xorshift RNGs" لجورج مارساجليا.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // خذ أرقامًا عشوائية من هذا الرقم.
        // الرقم يلائم `usize` لأن `len` ليس أكبر من `isize::MAX`.
        let modulus = len.next_power_of_two();

        // سيكون بعض المرشحين المحوريين في مكان قريب من هذا الفهرس.دعونا نختارهم بشكل عشوائي.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // توليد رقم عشوائي modulo `len`.
            // ومع ذلك ، من أجل تجنب العمليات المكلفة ، فإننا نأخذها أولاً مع قوة اثنين ، ثم ننخفض بمقدار `len` حتى تتناسب مع النطاق `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` مضمون أن يكون أقل من `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// يختار محورًا في `v` ويعيد الفهرس و `true` إذا كان من المحتمل أن تكون الشريحة مرتبة بالفعل.
///
/// قد تتم إعادة ترتيب العناصر في `v` في هذه العملية.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // الطول الأدنى لاختيار طريقة الوسيط.
    // تستخدم الشرائح الأقصر طريقة الوسيط البسيط من ثلاثة.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // الحد الأقصى لعدد المقايضات التي يمكن إجراؤها في هذه الوظيفة.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // ثلاثة مؤشرات سنختار محورًا بالقرب منها.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // تحسب إجمالي عدد المقايضات التي نحن على وشك القيام بها أثناء فرز المؤشرات.
    let mut swaps = 0;

    if len >= 8 {
        // مقايضة المؤشرات بحيث `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // مقايضة المؤشرات بحيث `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // يبحث عن وسيط `v[a - 1], v[a], v[a + 1]` ويخزن الفهرس في `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // ابحث عن المتوسطات في أحياء `a` و `b` و `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // ابحث عن الوسيط بين `a` و `b` و `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // تم تنفيذ الحد الأقصى لعدد المقايضات.
        // من المحتمل أن تكون الشريحة تنازلية أو تنازلية في الغالب ، لذا من المحتمل أن يساعد الانعكاس في فرزها بشكل أسرع.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// يفرز `v` بشكل متكرر.
///
/// إذا كان للشريحة سابقة في المصفوفة الأصلية ، يتم تحديدها على أنها `pred`.
///
/// `limit` هو عدد الأقسام غير المتوازنة المسموح بها قبل التبديل إلى `heapsort`.
/// إذا كانت صفرًا ، فستتحول هذه الوظيفة فورًا إلى الترتيب المتراكم.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // يتم فرز الشرائح حتى هذا الطول باستخدام فرز الإدخال.
    const MAX_INSERTION: usize = 20;

    // صحيح إذا كان التقسيم الأخير متوازنًا بشكل معقول.
    let mut was_balanced = true;
    // صحيح إذا كان التقسيم الأخير لا يخلط بين العناصر (تم تقسيم الشريحة بالفعل).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // يتم فرز الشرائح القصيرة جدًا باستخدام فرز الإدخال.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // إذا تم إجراء عدد كبير جدًا من الخيارات المحورية السيئة ، فقم ببساطة بالرجوع إلى الترتيب المتراكم لضمان أسوأ حالة لـ `O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // إذا كان التقسيم الأخير غير متوازن ، فحاول كسر الأنماط في الشريحة عن طريق خلط بعض العناصر.
        // نأمل أن نختار محورًا أفضل هذه المرة.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // اختر محورًا وحاول تخمين ما إذا كانت الشريحة مرتبة بالفعل.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // إذا كان التقسيم الأخير متوازنًا بشكل لائق ولم يخلط بين العناصر ، وإذا توقع التحديد المحوري أن الشريحة قد تم فرزها بالفعل ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // حاول تحديد عدة عناصر خارج الترتيب وتحويلها إلى مواضع صحيحة.
            // إذا انتهى الأمر بفرز الشريحة بالكامل ، فقد انتهينا.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // إذا كان المحور المختار يساوي السابق ، فهو أصغر عنصر في الشريحة.
        // قسّم الشريحة إلى عناصر مساوية لـ وعناصر أكبر من المحور.
        // عادة ما يتم ضرب هذه الحالة عندما تحتوي الشريحة على العديد من العناصر المكررة.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // استمر في فرز العناصر الأكبر من المحور.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // قسّم الشريحة.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // قسّم الشريحة إلى `left` و `pivot` و `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // كرر إلى الجانب الأقصر فقط لتقليل العدد الإجمالي للمكالمات المتكررة واستهلاك مساحة أقل من المكدس.
        // ثم تابع فقط مع الجانب الأطول (هذا أقرب إلى الذيل العودي).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// يفرز `v` باستخدام فرز سريع يتغلب على النمط ، وهو *O*(*n*\*log(* n*)) أسوأ حالة.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // الفرز ليس له أي سلوك ذي معنى على الأنواع ذات الحجم الصفري.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // حدد عدد الأقسام غير المتوازنة بـ `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // بالنسبة للشرائح التي يصل طولها إلى هذا الطول ، من الأسرع على الأرجح فرزها ببساطة.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // اختر محورًا
        let (pivot, _) = choose_pivot(v, is_less);

        // إذا كان المحور المختار يساوي السابق ، فهو أصغر عنصر في الشريحة.
        // قسّم الشريحة إلى عناصر مساوية لـ وعناصر أكبر من المحور.
        // عادة ما يتم ضرب هذه الحالة عندما تحتوي الشريحة على العديد من العناصر المكررة.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // إذا تجاوزنا الفهرس ، فنحن بخير.
                if mid > index {
                    return;
                }

                // وإلا ، فاستمر في فرز العناصر الأكبر من المحور.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // قسّم الشريحة إلى `left` و `pivot` و `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // إذا كان مؤشر mid==، فقد انتهينا ، لأن partition() ضمنت أن جميع العناصر بعد الوسط أكبر من أو تساوي الوسط.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // الفرز ليس له أي سلوك ذي معنى على الأنواع ذات الحجم الصفري.لا تفعل شيئا.
    } else if index == v.len() - 1 {
        // ابحث عن الحد الأقصى للعنصر وضعه في الموضع الأخير من المصفوفة.
        // نحن أحرار في استخدام `unwrap()` هنا لأننا نعلم أن v يجب ألا يكون فارغًا.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // ابحث عن عنصر min وضعه في الموضع الأول من المصفوفة.
        // نحن أحرار في استخدام `unwrap()` هنا لأننا نعلم أن v يجب ألا يكون فارغًا.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}