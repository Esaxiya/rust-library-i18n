//! الثوابت لنوع عدد صحيح ذي إشارة 8 بت.
//!
//! *[See also the `i8` primitive type][i8].*
//!
//! يجب أن يستخدم الكود الجديد الثوابت المرتبطة مباشرة على النوع البدائي.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i8`"
)]

int_module! { i8 }