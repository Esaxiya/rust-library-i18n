//! الثوابت لنوع عدد صحيح بدون إشارة 16 بت.
//!
//! *[See also the `u16` primitive type][u16].*
//!
//! يجب أن يستخدم الكود الجديد الثوابت المرتبطة مباشرة على النوع البدائي.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u16`"
)]

int_module! { u16 }