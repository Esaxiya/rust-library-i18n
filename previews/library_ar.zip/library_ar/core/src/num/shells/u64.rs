//! الثوابت لنوع عدد صحيح بدون إشارة 64 بت.
//!
//! *[See also the `u64` primitive type][u64].*
//!
//! يجب أن يستخدم الكود الجديد الثوابت المرتبطة مباشرة على النوع البدائي.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u64`"
)]

int_module! { u64 }