//! الثوابت لنوع عدد صحيح ذي إشارة بحجم المؤشر.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! يجب أن يستخدم الكود الجديد الثوابت المرتبطة مباشرة على النوع البدائي.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }