//! الثوابت لنوع العدد الصحيح ذو الإشارة 32 بت.
//!
//! *[See also the `i32` primitive type][i32].*
//!
//! يجب أن يستخدم الكود الجديد الثوابت المرتبطة مباشرة على النوع البدائي.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i32`"
)]

int_module! { i32 }