//! تكييف Rust لخوارزمية Grisu3 الموضحة في "طباعة أرقام الفاصلة العائمة بسرعة وبدقة باستخدام الأعداد الصحيحة" [^ 1].
//! يستخدم حوالي 1 كيلوبايت من الجدول المحسوب مسبقًا ، وهو بدوره سريع جدًا لمعظم المدخلات.
//!
//! [^1]: Florian لويتش.2010. طباعة أرقام الفاصلة العائمة بسرعة و
//!   بدقة مع الأعداد الصحيحة.SIGPLAN لا.45 ، 6 (يونيو 2010) ، 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// انظر التعليقات في `format_shortest_opt` للأساس المنطقي.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-أنا ؛ه=4* ط ، 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (و ، هـ ، ك)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// بالنظر إلى `x > 0` ، يتم إرجاع `(k, 10^k)` مثل `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// أقصر وضع لتنفيذ Grisu.
///
/// تقوم بإرجاع `None` عندما تقوم بإرجاع تمثيل غير دقيق بطريقة أخرى.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // نحن بحاجة إلى ثلاث بتات على الأقل من الدقة الإضافية

    // ابدأ بالقيم التي تم تسويتها مع الأس المشترك
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // العثور على أي `cached = 10^minusk` مثل أن `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // نظرًا لأن `plus` تم تطبيعه ، فهذا يعني `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)` ؛
    // نظرًا لاختياراتنا من `ALPHA` و `GAMMA` ، فإن هذا يضع `plus * cached` في `[4, 2^32)`.
    //
    // من الواضح أنه من المستحسن تعظيم `GAMMA - ALPHA` ، بحيث لا نحتاج إلى العديد من الصلاحيات المخزنة مؤقتًا لـ 10 ، ولكن هناك بعض الاعتبارات:
    //
    //
    // 1. نريد إبقاء `floor(plus * cached)` ضمن `u32` لأنه يحتاج إلى قسم مكلف.
    //    (هذا لا يمكن تجنبه حقًا ، والباقي مطلوب لتقدير الدقة.)
    // 2.
    // يتم ضرب ما تبقى من `floor(plus * cached)` بشكل متكرر بمقدار 10 ، ولا يجب تجاوزه.
    //
    // الأول يعطي `64 + GAMMA <= 32` ، بينما يعطي الثاني `10 * 2^-ALPHA <= 2^64` ؛
    // -60 و -32 هو النطاق الأقصى مع هذا القيد ، ويستخدمها V8 أيضًا.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // مقياس fps.هذا يعطي الخطأ الأقصى 1 ulp (تم إثباته من Theorem 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-النطاق الفعلي للسالب
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // أعلى من `minus` و `v` و `plus`*هي تقريبية* تقريبية (خطأ <1 ulp).
    // نظرًا لأننا لا نعلم أن الخطأ موجب أو سالب ، فإننا نستخدم تقريبين متباعدتين بشكل متساوٍ ويكون الحد الأقصى للخطأ 2 أب.
    //
    // "unsafe region" هو فاصل زمني ليبرالي نقوم بإنشائه في البداية.
    // "safe region" هو فاصل زمني متحفظ نقبله فقط.
    // نبدأ بالنسخ الصحيح داخل المنطقة غير الآمنة ، ونحاول العثور على أقرب نسخة إلى `v` والتي تقع أيضًا داخل المنطقة الآمنة.
    // إذا لم نستطع ، فإننا نستسلم.
    //
    let plus1 = plus.f + 1;
    // دع plus0 = plus.f ، 1 ؛//فقط للتوضيح دع minus0 = minus.f + 1 ؛//فقط للتوضيح
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // الأس المشترك

    // قسّم `plus1` إلى أجزاء متكاملة وجزئية.
    // الأجزاء المتكاملة مضمونة لتناسب u32 ، نظرًا لأن الطاقة المخزنة مؤقتًا تضمن `plus < 2^32` و `plus.f` الطبيعي دائمًا أقل من `2^64 - 2^4` نظرًا لمتطلبات الدقة.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // احسب أكبر `10^max_kappa` لا يزيد عن `plus1` (وبالتالي `plus1 < 10^(max_kappa+1)`).
    // هذا هو الحد الأعلى لـ `kappa` أدناه.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // نظرية 6.2: إذا كان `k` هو أكبر عدد صحيح st
    // `0 <= y mod 10^k <= y - x`,              ثم `V = floor(y / 10^k) * 10^k` في `[x, y]` وواحد من أقصر التمثيلات (مع أقل عدد من الأرقام المعنوية) في هذا النطاق.
    //
    //
    // أوجد طول الرقم `kappa` بين `(minus1, plus1)` حسب Theorem 6.2.
    // يمكن اعتماد نظرية 6.2 لاستبعاد `x` من خلال طلب `y mod 10^k < y - x` بدلاً من ذلك.
    // (على سبيل المثال ، `x` =32000 ، `y` =32777 ؛ `kappa` =2 منذ `y mod 10 ^ 3=777 <y ، x=777`.) تعتمد الخوارزمية على مرحلة التحقق اللاحقة لاستبعاد `y`.
    //
    let delta1 = plus1 - minus1;
    // دع delta1int=(delta1>> e) حسب الاستخدام ؛//فقط للتوضيح
    let delta1frac = delta1 & ((1 << e) - 1);

    // تقديم أجزاء متكاملة ، مع التحقق من الدقة في كل خطوة.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // أرقام لم يتم تقديمها بعد
    loop {
        // لدينا دائمًا رقمًا واحدًا على الأقل لتقديمه ، مثل `plus1 >= 10^kappa` ثوابت:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (يتبع ذلك `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // قسّم `remainder` على `10^kappa`.كلاهما يتم تحجيمهما بواسطة `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1٪ 10 ^ كابا) * 2 ^ هـ
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; وجدنا `kappa` الصحيح.
            let ten_kappa = (ten_kappa as u64) << e; // مقياس 10 ^ kappa يعود إلى الأس المشترك
            return round_and_weed(
                // الأمان: قمنا بتهيئة تلك الذاكرة أعلاه.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // كسر الحلقة عندما نكون قد قدمنا جميع الأرقام المتكاملة.
        // العدد الدقيق للأرقام هو `max_kappa + 1` مثل `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // استعادة الثوابت
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // تقديم الأجزاء الكسرية ، مع التحقق من الدقة في كل خطوة.
    // هذه المرة نعتمد على الضرب المتكرر ، لأن القسمة ستفقد الدقة.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // يجب أن يكون الرقم التالي مهمًا حيث اختبرنا ذلك قبل كسر الثوابت ، حيث `m = max_kappa + 1` (عدد الأرقام في الجزء المتكامل):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // لن تفيض ، `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // قسّم `remainder` على `10^kappa`.
        // يتم تحجيم كلاهما بواسطة `2^e / 10^kappa` ، لذا فإن الأخير ضمني هنا.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // القاسم الضمني
            return round_and_weed(
                // الأمان: قمنا بتهيئة تلك الذاكرة أعلاه.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // استعادة الثوابت
        kappa -= 1;
        remainder = r;
    }

    // لقد أنشأنا جميع الأرقام المهمة لـ `plus1` ، لكننا غير متأكدين مما إذا كان هو الرقم الأمثل.
    // على سبيل المثال ، إذا كانت `minus1` تساوي 3.14153 ... و `plus1` تساوي 3.14158 ... ، فهناك 5 أقصر تمثيل مختلف من 3.14154 إلى 3.14158 ولكن لدينا فقط أكبر تمثيل.
    // يتعين علينا إنقاص الرقم الأخير على التوالي والتحقق مما إذا كان هذا هو التكرار الأمثل.
    // يوجد على الأكثر 9 مرشحين (..1 إلى ..9) ، لذلك هذا سريع إلى حد ما.(المرحلة "rounding")
    //
    // تتحقق الوظيفة مما إذا كان "optimal" repr يقع بالفعل ضمن نطاقات ulp ، وأيضًا ، من الممكن أن يكون "second-to-optimal" repr هو الأمثل بالفعل بسبب خطأ التقريب.
    // في كلتا الحالتين هذا يعيد `None`.
    // (المرحلة "weeding")
    //
    // يتم قياس جميع الوسائط هنا من خلال القيمة المشتركة (ولكن الضمنية) `k` ، بحيث:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (وأيضًا ، `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (وأيضًا ، `threshold > plus1v` من الثوابت السابقة)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // ينتج تقريبيان لـ `v` (في الواقع `plus1 - v`) ضمن 1.5 ulps.
        // يجب أن يكون التمثيل الناتج هو أقرب تمثيل لكليهما.
        //
        // يتم استخدام `plus1 - v` هنا نظرًا لأن الحسابات تتم فيما يتعلق بـ `plus1` لتجنب overflow/underflow (ومن هنا جاءت الأسماء التي تم تبديلها على ما يبدو).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v ، 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // إنقاص الرقم الأخير وتوقف عند أقرب تمثيل لـ `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1 ، w(n)
        {
            let last = buf.last_mut().unwrap();

            // نحن نعمل مع الأرقام التقريبية `w(n)` ، والتي تساوي في البداية `plus1 - plus1 % 10^kappa`.بعد تشغيل حلقة الجسم `n` مرات ، `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // قمنا بتعيين `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (وبالتالي `` الباقي= plus1w(0)`) لتبسيط الشيكات.
            // لاحظ أن `plus1w(n)` يتزايد دائمًا.
            //
            // لدينا ثلاثة شروط للإنهاء.أي منها سيجعل الحلقة غير قادرة على المتابعة ، ولكن لدينا بعد ذلك تمثيل صالح واحد على الأقل معروف بأنه الأقرب إلى `v + 1 ulp` على أي حال.
            // سنشير إليها على أنها TC1 من خلال TC3 للإيجاز.
            //
            // TC1: `w(n) <= v + 1 ulp` ، أي ، هذا هو آخر تكرار يمكن أن يكون الأقرب.
            // هذا يعادل `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // جنبًا إلى جنب مع TC2 (الذي يتحقق مما إذا كان `w(n+1)` is valid) ، فإن هذا يمنع الفائض المحتمل عند حساب `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1` ، أي ، النسخ التالية بالتأكيد لا تقرب إلى `v`.
            // هذا يعادل `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // يمكن أن يفيض الجانب الأيسر ، لكننا نعرف `threshold > plus1v` ، لذلك إذا كان TC1 خطأ ، `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` ويمكننا اختبار `threshold - plus1w(n) < 10^kappa` بأمان.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))` ، أي الممثل التالي هو
            // لا أقرب إلى `v + 1 ulp` من النسخ الحالي.
            // بالنظر إلى `z(n) = plus1v_up - plus1w(n)` ، يصبح هذا `abs(z(n)) <= abs(z(n+1))`.مرة أخرى بافتراض أن TC1 خطأ ، لدينا `z(n) > 0`.لدينا حالتان يجب مراعاتهما:
            //
            // - عندما يصبح `z(n+1) >= 0`: TC3 `z(n) <= z(n+1)`.
            // نظرًا لأن `plus1w(n)` يتزايد ، يجب أن يتناقص `z(n)` وهذا خطأ بشكل واضح.
            // - عندما `z(n+1) < 0`:
            //   - TC3a: الشرط المسبق هو `plus1v_up < plus1w(n) + 10^kappa`.بافتراض أن TC2 خطأ ، `threshold >= plus1w(n) + 10^kappa` لذلك لا يمكن تجاوزها.
            //   - TC3b: TC3 يصبح `z(n) <= -z(n+1)` ، أي `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   يعطي TC1 المنفي `plus1v_up > plus1w(n)` ، لذلك لا يمكن أن يفيض أو ينخفض عند دمجه مع TC3a.
            //
            // وبالتالي ، يجب أن نتوقف عند `TC1 || TC2 || (TC3a && TC3b)`.ما يلي يساوي معكوسها ، `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // لا يمكن أن ينتهي أقصر تكرار بـ `0`
                plus1w += ten_kappa;
            }
        }

        // تحقق مما إذا كان هذا التمثيل هو أيضًا أقرب تمثيل لـ `v - 1 ulp`.
        //
        // هذا هو نفس شروط الإنهاء لـ `v + 1 ulp` ، مع استبدال `plus1v_up` بالكامل بـ `plus1v_down` بدلاً من ذلك.
        // تحليل الفائض يحمل على قدم المساواة.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // الآن لدينا أقرب تمثيل لـ `v` بين `plus1` و `minus1`.
        // هذا ليبرالي للغاية ، على الرغم من ذلك ، لذلك نحن نرفض أي `w(n)` ليس بين `plus0` و `minus0` ، أي `plus1 - plus1w(n) <= minus0` أو `plus1 - plus1w(n) >= plus0`.
        // نحن نستخدم الحقائق التي `threshold = plus1 - minus1` و `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// أقصر تطبيق لوضع Grisu مع Dragon الاحتياطية.
///
/// يجب استخدام هذا في معظم الحالات.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // الأمان: مدقق الاستعارة ليس ذكيًا بما يكفي للسماح لنا باستخدام `buf`
    // في branch الثاني ، لذلك نقوم بغسل العمر هنا.
    // لكننا نعيد استخدام `buf` فقط إذا أعاد `format_shortest_opt` `None` لذلك هذا جيد.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// تطبيق الوضع الدقيق والثابت لـ Grisu.
///
/// تقوم بإرجاع `None` عندما تقوم بإرجاع تمثيل غير دقيق بطريقة أخرى.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // نحن بحاجة إلى ثلاث بتات على الأقل من الدقة الإضافية
    assert!(!buf.is_empty());

    // تطبيع ومقياس `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // قسّم `v` إلى أجزاء متكاملة وجزئية.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // كل من `v` القديم و `v` الجديد (تم تحجيمهما بواسطة `10^-k`) بهما خطأ <1 ulp (Theorem 5.1).
    // نظرًا لأننا لا نعلم أن الخطأ موجب أو سالب ، فإننا نستخدم تقريبين متباعدتين بشكل متساو ولدينا أقصى خطأ 2 أب (نفس الحالة الأقصر).
    //
    //
    // الهدف هو العثور على سلسلة الأرقام المقربة تمامًا المشتركة بين كل من `v - 1 ulp` و `v + 1 ulp` ، بحيث نكون واثقين إلى أقصى حد.
    // إذا لم يكن ذلك ممكنًا ، فنحن لا نعرف أيهما هو الإخراج الصحيح لـ `v` ، لذلك نستسلم ونتراجع.
    //
    // `err` يتم تعريفه على أنه `1 ulp * 2^e` هنا (مثل ulp في `vfrac`) ، وسنقوم بتوسيعه كلما تم تحجيم `v`.
    //
    //
    //
    let mut err = 1;

    // احسب أكبر `10^max_kappa` لا يزيد عن `v` (وبالتالي `v < 10^(max_kappa+1)`).
    // هذا هو الحد الأعلى لـ `kappa` أدناه.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // إذا كنا نعمل مع تحديد الرقم الأخير ، فنحن بحاجة إلى تقصير المخزن المؤقت قبل العرض الفعلي لتجنب التقريب المزدوج.
    //
    // لاحظ أنه يتعين علينا تكبير المخزن المؤقت مرة أخرى عند حدوث التقريب!
    let len = if exp <= limit {
        // عفوًا ، لا يمكننا حتى إنتاج رقم *واحد*.
        // هذا ممكن ، على سبيل المثال ، عندما يكون لدينا شيء مثل 9.5 ويتم تقريبه إلى 10.
        //
        // من حيث المبدأ ، يمكننا الاتصال على الفور بـ `possibly_round` مع وجود مخزن مؤقت فارغ ، ولكن قياس `max_ten_kappa << e` بمقدار 10 يمكن أن يؤدي إلى تجاوز.
        //
        // وبالتالي نحن هنا مهملين ونوسع نطاق الخطأ بعامل 10.
        // سيؤدي هذا إلى زيادة المعدل السلبي الخاطئ ، ولكن فقط جدًا ،*جدًا* قليلاً ؛
        // يمكن أن يكون مهمًا بشكل ملحوظ فقط عندما يكون الجزء العشري أكبر من 60 بتًا.
        //
        // الأمان: `len=0` ، لذا فإن الالتزام بتهيئة هذه الذاكرة أمر تافه.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // تقديم أجزاء متكاملة.
    // الخطأ كسري تمامًا ، لذلك لا نحتاج إلى التحقق منه في هذا الجزء.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // أرقام لم يتم تقديمها بعد
    loop {
        // لدينا دائمًا رقم واحد على الأقل لتقديم الثوابت:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (يتبع ذلك `remainder = vint % 10^(kappa+1)`)
        //
        //

        // قسّم `remainder` على `10^kappa`.كلاهما يتم تحجيمهما بواسطة `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // هل المخزن المؤقت ممتلئ؟قم بتشغيل التمريرة التقريبية مع الباقي.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v٪ 10 ^ kappa) * 2 ^ e
            // الأمان: لقد قمنا بتهيئة `len` العديد من البايت.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // كسر الحلقة عندما نكون قد قدمنا جميع الأرقام المتكاملة.
        // العدد الدقيق للأرقام هو `max_kappa + 1` مثل `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // استعادة الثوابت
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // تقديم الأجزاء الكسرية.
    //
    // من حيث المبدأ ، يمكننا المتابعة حتى آخر رقم متاح والتحقق من الدقة.
    // لسوء الحظ ، نحن نعمل مع الأعداد الصحيحة ذات الحجم المحدود ، لذلك نحتاج إلى بعض المعايير لاكتشاف الفائض.
    // V8 يستخدم `remainder > err` ، والذي يصبح خطأ عندما تختلف الأرقام المهمة الأولى `i` من `v - 1 ulp` و `v`.
    // لكن هذا يرفض الكثير من المدخلات الصالحة.
    //
    // نظرًا لأن المرحلة اللاحقة تحتوي على اكتشاف تجاوز صحيح ، فإننا بدلاً من ذلك نستخدم معيارًا أكثر إحكامًا:
    // نواصل حتى يتجاوز `err` `10^kappa / 2` ، بحيث يحتوي النطاق بين `v - 1 ulp` و `v + 1 ulp` بالتأكيد على تمثيلين دائريين أو أكثر.
    //
    // هذا هو نفسه للمقارنات الأولين من `possibly_round` ، للإشارة.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // الثوابت ، حيث `m = max_kappa + 1` (عدد الأرقام في الجزء المتكامل):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // لن تفيض ، `2^e * 10 < 2^64`
        err *= 10; // لن تفيض ، `err * 10 < 2^e * 5 < 2^64`

        // قسّم `remainder` على `10^kappa`.
        // يتم تحجيم كلاهما بواسطة `2^e / 10^kappa` ، لذا فإن الأخير ضمني هنا.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // هل المخزن المؤقت ممتلئ؟قم بتشغيل التمريرة التقريبية مع الباقي.
        if i == len {
            // الأمان: لقد قمنا بتهيئة `len` العديد من البايت.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // استعادة الثوابت
        remainder = r;
    }

    // المزيد من الحسابات غير مجدية (فشل `possibly_round` بالتأكيد) ، لذلك نستسلم.
    return None;

    // لقد أنشأنا جميع الأرقام المطلوبة لـ `v` ، والتي يجب أن تكون أيضًا مماثلة للأرقام المقابلة لـ `v - 1 ulp`.
    // نتحقق الآن مما إذا كان هناك تمثيل فريد مشترك بين كل من `v - 1 ulp` و `v + 1 ulp` ؛يمكن أن يكون هذا إما هو نفسه للأرقام التي تم إنشاؤها ، أو للنسخة المقربة لأعلى من تلك الأرقام.
    //
    // إذا كان النطاق يحتوي على تمثيلات متعددة من نفس الطول ، فلا يمكننا التأكد ويجب أن نعيد `None` بدلاً من ذلك.
    //
    // يتم قياس جميع الوسائط هنا من خلال القيمة المشتركة (ولكن الضمنية) `k` ، بحيث:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // الأمان: يجب تهيئة أول `len` بايت من `buf`.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (بالنسبة للمرجع ، يشير الخط المنقط إلى القيمة الدقيقة للتمثيلات الممكنة في عدد معين من الأرقام.)
        //
        //
        // الخطأ كبير جدًا بحيث يوجد على الأقل ثلاثة تمثيلات محتملة بين `v - 1 ulp` و `v + 1 ulp`.
        // لا يمكننا تحديد أيهما صحيح.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // في الواقع ، 1/2 ulp كافٍ لتقديم تمثيلين محتملين.
        // (تذكر أننا بحاجة إلى تمثيل فريد لكل من `v - 1 ulp` و `v + 1 ulp`.) لن يتجاوز هذا الحد ، مثل `ulp < ten_kappa` من الفحص الأول.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ كابا---------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // إذا كان `v + 1 ulp` أقرب إلى التمثيل التقريبي (الموجود بالفعل في `buf`) ، فيمكننا العودة بأمان.
        // لاحظ أن `v - 1 ulp` * يمكن أن يكون أقل من التمثيل الحالي ، ولكن مثل `1 ulp < 10^kappa / 2` ، هذا الشرط كافٍ:
        // لا يمكن أن تتجاوز المسافة بين `v - 1 ulp` والتمثيل الحالي `10^kappa / 2`.
        //
        // الشرط يساوي `remainder + ulp < 10^kappa / 2`.
        // نظرًا لأن هذا يمكن أن يفيض بسهولة ، تحقق أولاً مما إذا كان `remainder < 10^kappa / 2`.
        // لقد تحققنا بالفعل من أن `ulp < 10^kappa / 2` ، طالما أن `10^kappa` لم يفيض بعد كل شيء ، فإن الفحص الثاني جيد.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // الأمان: قام المتصل بتهيئة تلك الذاكرة.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------باقي------> |:
        //   :                          |   :
        //   : <---------10 ^ كابا--------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // من ناحية أخرى ، إذا كان `v - 1 ulp` أقرب إلى التمثيل التقريبي ، فيجب علينا التقريب والعودة.
        // للسبب نفسه ، لا نحتاج إلى التحقق من `v + 1 ulp`.
        //
        // الشرط يساوي `remainder - ulp >= 10^kappa / 2`.
        // مرة أخرى نتحقق أولاً مما إذا كان `remainder > ulp` (لاحظ أن هذا ليس `remainder >= ulp` ، لأن `10^kappa` ليس صفرًا أبدًا).
        //
        // لاحظ أيضًا أن `remainder - ulp <= 10^kappa` ، لذلك لا يتجاوز الفحص الثاني.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // الأمان: يجب أن يكون المتصل قد قام بتهيئة تلك الذاكرة.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // أضف رقمًا إضافيًا فقط عندما يُطلب منا الدقة الثابتة.
                // نحتاج أيضًا إلى التحقق من أنه إذا كان المخزن المؤقت الأصلي فارغًا ، فلا يمكن إضافة الرقم الإضافي إلا عند `exp == limit` (حالة edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // الأمان: قمنا نحن والمتصل بتهيئة تلك الذاكرة.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // وإلا فإننا محكوم علينا بالفشل (على سبيل المثال ، يتم تقريب بعض القيم بين `v - 1 ulp` و `v + 1 ulp` لأسفل والبعض الآخر يتم تقريبه لأعلى) ونستسلم.
        //
        None
    }
}

/// تطبيق الوضع الدقيق والثابت لـ Grisu with Dragon الاحتياطية.
///
/// يجب استخدام هذا في معظم الحالات.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // الأمان: مدقق الاستعارة ليس ذكيًا بما يكفي للسماح لنا باستخدام `buf`
    // في branch الثاني ، لذلك نقوم بغسل العمر هنا.
    // لكننا نعيد استخدام `buf` فقط إذا أعاد `format_exact_opt` `None` لذلك هذا جيد.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}