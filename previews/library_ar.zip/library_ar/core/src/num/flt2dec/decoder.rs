//! يقوم بفك ترميز قيمة النقطة العائمة إلى أجزاء فردية ونطاقات خطأ.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// القيمة المحددة غير الموقعة التي تم فك ترميزها ، مثل:
///
/// - القيمة الأصلية تساوي `mant * 2^exp`.
///
/// - سيتم تقريب أي رقم من `(mant - minus)*2^exp` إلى `(mant + plus)* 2^exp` إلى القيمة الأصلية.
/// النطاق شامل فقط عندما يكون `inclusive` هو `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// الجزء العشري المتدرج.
    pub mant: u64,
    /// نطاق الخطأ الأدنى.
    pub minus: u64,
    /// نطاق الخطأ العلوي.
    pub plus: u64,
    /// الأس المشترك في الأساس 2.
    pub exp: i16,
    /// صحيح عندما يكون نطاق الخطأ شاملاً.
    ///
    /// في IEEE 754 ، يكون هذا صحيحًا عندما كان الجزء العشري الأصلي متساويًا.
    pub inclusive: bool,
}

/// قيمة غير موقعة فك ترميزها.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// اللانهائيات ، سواء كانت موجبة أو سلبية.
    Infinite,
    /// صفر ، سواء موجب أو سالب.
    Zero,
    /// أرقام محدودة مع مزيد من الحقول التي تم فك تشفيرها.
    Finite(Decoded),
}

/// نوع النقطة العائمة يمكن أن يكون "فك" د.
pub trait DecodableFloat: RawFloat + Copy {
    /// الحد الأدنى للقيمة الطبيعية الموجبة.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// ترجع علامة (صواب عندما تكون سالبة) وقيمة `FullDecoded` من رقم فاصلة عائمة محدد.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // الجيران: (mant، 2، exp)-(mant، exp)-(mant + 2، exp)
            // Float::integer_decode يحافظ دائمًا على الأس ، لذلك يتم تحجيم الجزء العشري للأشكال الفرعية.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // الجيران: (maxmant، exp، 1)-(minnormmant، exp)-(minnormmant + 1، exp)
                // حيث maxmant=minnormmant * 2، 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // الجيران: (mant، 1، exp)-(mant، exp)-(mant + 1، exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}