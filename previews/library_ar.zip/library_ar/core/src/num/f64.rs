//! الثوابت الخاصة بنوع النقطة العائمة مزدوجة الدقة `f64`.
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! يتم توفير أرقام مهمة رياضيًا في الوحدة الفرعية `consts`.
//!
//! بالنسبة للثوابت المحددة مباشرةً في هذه الوحدة (على خلاف تلك المحددة في الوحدة الفرعية `consts`) ، يجب أن يستخدم الكود الجديد بدلاً من ذلك الثوابت المرتبطة المحددة مباشرةً في النوع `f64`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// أساس أو قاعدة التمثيل الداخلي لـ `f64`.
/// استخدم [`f64::RADIX`] بدلاً من ذلك.
///
/// # Examples
///
/// ```rust
/// // طريقة مهملة
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // الطريقة المقصودة
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// عدد الأرقام المعنوية في الأساس 2.
/// استخدم [`f64::MANTISSA_DIGITS`] بدلاً من ذلك.
///
/// # Examples
///
/// ```rust
/// // طريقة مهملة
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // الطريقة المقصودة
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// العدد التقريبي للأرقام المعنوية في الأساس 10.
/// استخدم [`f64::DIGITS`] بدلاً من ذلك.
///
/// # Examples
///
/// ```rust
/// // طريقة مهملة
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // الطريقة المقصودة
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] قيمة `f64`.
/// استخدم [`f64::EPSILON`] بدلاً من ذلك.
///
/// هذا هو الفرق بين `1.0` والرقم القابل للتمثيل الأكبر التالي.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // طريقة مهملة
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // الطريقة المقصودة
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f64`"
)]
pub const EPSILON: f64 = f64::EPSILON;

/// أصغر قيمة `f64` محدودة.
/// استخدم [`f64::MIN`] بدلاً من ذلك.
///
/// # Examples
///
/// ```rust
/// // طريقة مهملة
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // الطريقة المقصودة
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// أصغر قيمة `f64` طبيعية موجبة.
/// استخدم [`f64::MIN_POSITIVE`] بدلاً من ذلك.
///
/// # Examples
///
/// ```rust
/// // طريقة مهملة
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // الطريقة المقصودة
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f64`"
)]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// أكبر قيمة `f64` محدودة.
/// استخدم [`f64::MAX`] بدلاً من ذلك.
///
/// # Examples
///
/// ```rust
/// // طريقة مهملة
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // الطريقة المقصودة
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// واحد أكبر من الحد الأدنى الممكن للقوة العادية التي تبلغ 2 أس.
/// استخدم [`f64::MIN_EXP`] بدلاً من ذلك.
///
/// # Examples
///
/// ```rust
/// // طريقة مهملة
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // الطريقة المقصودة
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f64`"
)]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// أقصى قوة ممكنة 2 أس.
/// استخدم [`f64::MAX_EXP`] بدلاً من ذلك.
///
/// # Examples
///
/// ```rust
/// // طريقة مهملة
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // الطريقة المقصودة
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f64`"
)]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// أقل قوة عادية ممكنة مقدارها 10 أس.
/// استخدم [`f64::MIN_10_EXP`] بدلاً من ذلك.
///
/// # Examples
///
/// ```rust
/// // طريقة مهملة
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // الطريقة المقصودة
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f64`"
)]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// أقصى قوة ممكنة مقدارها 10 أس.
/// استخدم [`f64::MAX_10_EXP`] بدلاً من ذلك.
///
/// # Examples
///
/// ```rust
/// // طريقة مهملة
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // الطريقة المقصودة
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f64`"
)]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// ليس رقم (NaN).
/// استخدم [`f64::NAN`] بدلاً من ذلك.
///
/// # Examples
///
/// ```rust
/// // طريقة مهملة
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // الطريقة المقصودة
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// إنفينيتي (∞).
/// استخدم [`f64::INFINITY`] بدلاً من ذلك.
///
/// # Examples
///
/// ```rust
/// // طريقة مهملة
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // الطريقة المقصودة
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f64`"
)]
pub const INFINITY: f64 = f64::INFINITY;

/// سالب اللانهاية (−∞).
/// استخدم [`f64::NEG_INFINITY`] بدلاً من ذلك.
///
/// # Examples
///
/// ```rust
/// // طريقة مهملة
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // الطريقة المقصودة
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f64`"
)]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// الثوابت الرياضية الأساسية.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: استبدل بالثوابت الرياضية من cmath.

    /// (π) ثابت أرخميدس
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// ثابت الدائرة الكاملة (τ)
    ///
    /// يساوي 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// رقم أويلر (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[lang = "f64"]
#[cfg(not(test))]
impl f64 {
    /// أساس أو قاعدة التمثيل الداخلي لـ `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// عدد الأرقام المعنوية في الأساس 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// العدد التقريبي للأرقام المعنوية في الأساس 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] قيمة `f64`.
    ///
    /// هذا هو الفرق بين `1.0` والرقم القابل للتمثيل الأكبر التالي.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// أصغر قيمة `f64` محدودة.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// أصغر قيمة `f64` طبيعية موجبة.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// أكبر قيمة `f64` محدودة.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// واحد أكبر من الحد الأدنى الممكن للقوة العادية التي تبلغ 2 أس.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// أقصى قوة ممكنة 2 أس.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// أقل قوة عادية ممكنة مقدارها 10 أس.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// أقصى قوة ممكنة مقدارها 10 أس.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// ليس رقم (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// إنفينيتي (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// سالب اللانهاية (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// تُرجع `true` إذا كانت هذه القيمة هي `NaN`.
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` غير متاح للجمهور في libcore بسبب مخاوف بشأن قابلية النقل ، لذلك هذا التطبيق للاستخدام الخاص داخليًا.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f64 {
        f64::from_bits(self.to_bits() & 0x7fff_ffff_ffff_ffff)
    }

    /// تُرجع `true` إذا كانت هذه القيمة هي ما لا نهاية موجب أو ما لا نهاية سالب ، وتعيد `false` في الحالات الأخرى.
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// تُرجع `true` إذا لم يكن هذا الرقم لا نهائيًا ولا `NaN`.
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // ليست هناك حاجة للتعامل مع NaN بشكل منفصل: إذا كانت self هي NaN ، فإن المقارنة غير صحيحة ، تمامًا كما هو مطلوب.
        //
        self.abs_private() < Self::INFINITY
    }

    /// تُرجع `true` إذا كان الرقم [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // القيم بين `0` و `min` غير طبيعية.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// تُرجع `true` إذا لم يكن الرقم صفرًا أو لانهائيًا أو [subnormal] أو `NaN`.
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // القيم بين `0` و `min` غير طبيعية.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// إرجاع فئة النقطة العائمة للرقم.
    /// إذا كان سيتم اختبار خاصية واحدة فقط ، فمن الأسرع عمومًا استخدام المسند المحدد بدلاً من ذلك.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// تُرجع `true` إذا كان لدى `self` علامة موجبة ، بما في ذلك `+0.0` و` NaN بتة إشارة موجبة ولانهاية موجبة.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// تُرجع `true` إذا كان `self` به علامة سالبة ، بما في ذلك `-0.0` و `NaN` بتة إشارة سالبة ولانهاية سالبة.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        self.to_bits() & 0x8000_0000_0000_0000 != 0
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// يأخذ مقلوب (inverse) لرقم ، `1/x`.
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// تحويل التقدير الدائري إلى درجات.
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // تم تقريب القسمة هنا بشكل صحيح فيما يتعلق بالقيمة الحقيقية 180/.
        // (يختلف هذا عن f32 ، حيث يجب استخدام ثابت لضمان نتيجة تقريب صحيحة.)
        //
        self * (180.0f64 / consts::PI)
    }

    /// تحويل الدرجات إلى راديان.
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// تُرجع الحد الأقصى للرقمين.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// إذا كانت إحدى الوسيطتين هي NaN ، فسيتم إرجاع الوسيطة الأخرى.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// تُرجع الحد الأدنى من الرقمين.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// إذا كانت إحدى الوسيطتين هي NaN ، فسيتم إرجاع الوسيطة الأخرى.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// تقترب من الصفر وتتحول إلى أي نوع من أنواع الأعداد الصحيحة الأولية ، بافتراض أن القيمة محدودة وتناسب هذا النوع.
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// يجب أن تكون القيمة:
    ///
    /// * لا يكون `NaN`
    /// * لا تكون لانهائية
    /// * تكون قابلة للتمثيل في نوع الإرجاع `Int` ، بعد اقتطاع الجزء الكسري
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// تحويل الخام إلى `u64`.
    ///
    /// هذا مطابق حاليًا لـ `transmute::<f64, u64>(self)` على جميع الأنظمة الأساسية.
    ///
    /// راجع `from_bits` للحصول على بعض المناقشات حول إمكانية نقل هذه العملية (لا توجد مشكلات تقريبًا).
    ///
    /// لاحظ أن هذه الوظيفة مميزة عن إرسال `as` ، الذي يحاول الحفاظ على القيمة *الرقمية*، وليس قيمة البت.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() لا يتم الإرسال!
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // الأمان: `u64` هو نوع بيانات قديم بسيط لذا يمكننا دائمًا التحويل إليه
        unsafe { mem::transmute(self) }
    }

    /// التحويل الخام من `u64`.
    ///
    /// هذا مطابق حاليًا لـ `transmute::<u64, f64>(v)` على جميع الأنظمة الأساسية.
    /// اتضح أن هذا محمول بشكل لا يصدق ، لسببين:
    ///
    /// * تتمتع Floats و Ints بنفس الجودة على جميع الأنظمة الأساسية المدعومة.
    /// * يحدد IEEE-754 بدقة شديدة تخطيط البت للعوامات.
    ///
    /// ومع ذلك ، هناك تحذير واحد: قبل إصدار 2008 من IEEE-754 ، لم يتم تحديد كيفية تفسير بت إشارة NaN بالفعل.
    /// اختارت معظم الأنظمة الأساسية (لا سيما x86 و ARM) التفسير الذي تم توحيده في نهاية المطاف في عام 2008 ، لكن البعض الآخر لم يفعل ذلك (لا سيما MIPS).
    /// نتيجة لذلك ، فإن جميع NaNs للإشارة على MIPS هي NaNs هادئة على x86 ، والعكس صحيح.
    ///
    /// بدلاً من محاولة الحفاظ على النظام الأساسي المتقاطع للإشارات ، يفضل هذا التنفيذ الحفاظ على البتات الدقيقة.
    /// هذا يعني أنه سيتم الاحتفاظ بأي حمولات مشفرة في NaNs حتى إذا تم إرسال نتيجة هذه الطريقة عبر الشبكة من جهاز x86 إلى جهاز MIPS.
    ///
    ///
    /// إذا تم التلاعب بنتائج هذه الطريقة فقط من خلال نفس البنية التي أنتجتها ، فلا داعي للقلق بشأن قابلية النقل.
    ///
    /// إذا لم يكن الإدخال هو NaN ، فلا داعي للقلق بشأن قابلية النقل.
    ///
    /// إذا كنت لا تهتم بالإشارة (من المحتمل جدًا) ، فلا داعي للقلق بشأن قابلية النقل.
    ///
    /// لاحظ أن هذه الوظيفة مميزة عن إرسال `as` ، الذي يحاول الحفاظ على القيمة *الرقمية*، وليس قيمة البت.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // الأمان: `u64` هو نوع بيانات قديم بسيط لذا يمكننا دائمًا التحويل منه
        // اتضح أن مشكلات السلامة مع sNaN مبالغ فيها!الصيحة!
        unsafe { mem::transmute(v) }
    }

    /// قم بإرجاع تمثيل الذاكرة لرقم النقطة العائمة هذا كمصفوفة بايت بترتيب بايت (network) كبير الحجم.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// قم بإرجاع تمثيل الذاكرة لرقم النقطة العائمة هذا كمصفوفة بايت بترتيب بايت صغير.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// إرجاع تمثيل الذاكرة لرقم الفاصلة العائمة كمصفوفة بايت بترتيب البايت الأصلي.
    ///
    /// نظرًا لاستخدام النهاية الأصلية للنظام الأساسي المستهدف ، يجب أن يستخدم الكود المحمول [`to_be_bytes`] أو [`to_le_bytes`] ، حسب الاقتضاء ، بدلاً من ذلك.
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// إرجاع تمثيل الذاكرة لرقم الفاصلة العائمة كمصفوفة بايت بترتيب البايت الأصلي.
    ///
    ///
    /// [`to_ne_bytes`] يجب تفضيله على هذا كلما أمكن ذلك.
    ///
    /// [`to_ne_bytes`]: f64::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f64;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 8] {
        // الأمان: `f64` هو نوع بيانات قديم بسيط لذا يمكننا دائمًا التحويل إليه
        unsafe { &*(self as *const Self as *const _) }
    }

    /// قم بإنشاء قيمة النقطة العائمة من تمثيلها كمصفوفة بايت في endian الكبير.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// قم بإنشاء قيمة النقطة العائمة من تمثيلها كمصفوفة بايت في endian الصغير.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// إنشاء قيمة النقطة العائمة من تمثيلها كمصفوفة بايت في endian الأصلي.
    ///
    /// نظرًا لاستخدام endianness الأصلي للنظام الأساسي المستهدف ، من المحتمل أن يرغب الكود المحمول في استخدام [`from_be_bytes`] أو [`from_le_bytes`] ، حسب الاقتضاء بدلاً من ذلك.
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// إرجاع ترتيب بين القيم الذاتية والقيم الأخرى.
    /// على عكس المقارنة الجزئية القياسية بين أرقام الفاصلة العائمة ، فإن هذه المقارنة تنتج دائمًا أمرًا وفقًا لمسند إجمالي الطلب كما هو محدد في معيار النقطة العائمة IEEE 754 (مراجعة 2008).
    /// تم ترتيب القيم بالترتيب التالي:
    /// - سلبي الهدوء NaN
    /// - إشارة سلبية NaN
    /// - اللانهاية السلبية
    /// - الأعداد السالبة
    /// - أرقام غير طبيعية سالبة
    /// - صفر سالب
    /// - صفر موجب
    /// - أعداد غير طبيعية موجبة
    /// - الأعداد الموجبة
    /// - اللانهاية الإيجابية
    /// - إشارة إيجابية NaN
    /// - الهدوء الإيجابي NaN
    ///
    /// لاحظ أن هذه الوظيفة لا تتوافق دائمًا مع تطبيقات [`PartialOrd`] و [`PartialEq`] لـ `f64`.على وجه الخصوص ، يعتبرون الصفر السالب والموجب متساويين ، بينما `total_cmp` لا.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // في حالة السلبيات ، اقلب كل البتات باستثناء الإشارة لتحقيق تخطيط مشابه لأعداد صحيحة مكملة لاثنين
        //
        // لماذا هذا العمل؟تتكون عوامات IEEE 754 من ثلاثة حقول:
        // بت التوقيع ، الأس والجزء العشري.تمتلك مجموعة حقول الأس والجزء العشري ككل خاصية أن ترتيب أحادياتهما يساوي المقدار الرقمي حيث يتم تحديد المقدار.
        // لا يتم تحديد المقدار عادةً على قيم NaN ، ولكن IEEE 754 totalOrder تحدد قيم NaN أيضًا لاتباع ترتيب البت.يؤدي هذا إلى شرح الأمر في تعليق المستند.
        // ومع ذلك ، فإن تمثيل المقدار هو نفسه للأرقام السالبة والموجبة-فقط بت الإشارة هي مختلفة.
        // لمقارنة العوامات بسهولة كأعداد صحيحة موقعة ، نحتاج إلى قلب بت الأس والجزء العشري في حالة الأرقام السالبة.
        // نقوم بتحويل الأرقام إلى شكل "two's complement" بشكل فعال.
        //
        // للقيام بالتقليب ، نقوم ببناء قناع و XOR ضده.
        // نحن نحسب قناع "all-ones except for the sign bit" بدون فروع من قيم موقعة سالبة: تمدد إشارة الإزاحة لليمين العدد الصحيح ، لذلك نحن "fill" القناع مع بتات الإشارة ، ثم نحول إلى غير موقعة لدفع بت واحد إضافي صفري.
        //
        // بالنسبة للقيم الموجبة ، يكون القناع عبارة عن جميع الأصفار ، لذا فهو غير متاح.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// قصر قيمة على فترة زمنية معينة ما لم تكن NaN.
    ///
    /// تُرجع `max` إذا كان `self` أكبر من `max` و `min` إذا كان `self` أقل من `min`.
    /// وإلا فإن هذا يعيد `self`.
    ///
    /// لاحظ أن هذه الدالة ترجع NaN إذا كانت القيمة الأولية هي NaN أيضًا.
    ///
    /// # Panics
    ///
    /// Panics إذا كانت `min > max` أو `min` هي NaN أو `max` هي NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}