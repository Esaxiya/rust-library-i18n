//! مخصص الدقة التعسفية تنفيذ (bignum).
//!
//! تم تصميم هذا لتجنب تخصيص الكومة على حساب ذاكرة المكدس.
//! نوع Bignum الأكثر استخدامًا ، `Big32x40` ، محدود بـ 32 × 40=1،280 بت وسيستغرق 160 بايت على الأكثر من ذاكرة المكدس.
//! هذا أكثر من كافٍ لتقريب جميع قيم `f64` المحدودة الممكنة.
//!
//! من حيث المبدأ ، من الممكن أن يكون لديك أنواع متعددة من bignum لمدخلات مختلفة ، لكننا لا نفعل ذلك لتجنب تضخم الكود.
//!
//! لا يزال يتم تعقب كل bignum للاستخدامات الفعلية ، لذلك لا يهم عادةً.
//!

// هذه الوحدة هي فقط من أجل dec2flt و flt2dec ، وهي عامة فقط بسبب اختبارات coretests.
// لا يُقصد منه أن يستقر أبدًا.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// العمليات الحسابية التي تتطلبها bignums.
pub trait FullOps: Sized {
    /// تُرجع `(carry', v')` مثل `carry' * 2^W + v' = self + other + carry` ، حيث `W` هو عدد وحدات البت في `Self`.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// تُرجع `(carry', v')` مثل `carry'*2^W + v' = self* other + carry` ، حيث `W` هو عدد وحدات البت في `Self`.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// تُرجع `(carry', v')` مثل `carry'*2^W + v' = self* other + other2 + carry` ، حيث `W` هو عدد وحدات البت في `Self`.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// تُرجع `(quo, rem)` مثل `borrow *2^W + self = quo* other + rem` و `0 <= rem < other` ، حيث `W` هو عدد وحدات البت في `Self`.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // هذا لا يمكن تجاوز.الإخراج بين `0` و `2 * 2^nbits - 1`.
                    // FIXME: هل ستقوم LLVM بتحسين هذا إلى ADC أو ما شابه ذلك؟
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // هذا لا يمكن تجاوز.
                    // الإخراج بين `0` و `2^nbits * (2^nbits - 1)`.
                    // FIXME: هل ستقوم LLVM بتحسين هذا إلى ADC أو ما شابه ذلك؟
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // هذا لا يمكن تجاوز.
                    // الإخراج بين `0` و `2^nbits * (2^nbits - 1)`.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // هذا لا يمكن تجاوز.الإخراج بين `0` و `other * (2^nbits - 1)`.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // راجع RFC #521 لتمكين ذلك.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// جدول قوى العدد 5 الذي يمكن تمثيله بالأرقام.على وجه التحديد ، أكبر قيمة {u8, u16, u32} هي قوة خمسة ، بالإضافة إلى الأس المقابل.
/// تستخدم في `mul_pow5`.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// دقة عشوائية مخصصة للمكدس (حتى حد معين).
        ///
        /// هذا مدعوم بمصفوفة ذات حجم ثابت من النوع المحدد ("digit").
        /// على الرغم من أن المصفوفة ليست كبيرة جدًا (عادةً ما تكون مئات البايتات) ، إلا أن نسخها بشكل متهور قد يؤدي إلى إصابة الأداء.
        ///
        /// وبالتالي هذا ليس عن قصد `Copy`.
        ///
        /// جميع العمليات المتاحة لـ bignums panic في حالة الفائض.
        /// المتصل مسؤول عن استخدام أنواع كبيرة بما فيه الكفاية.
        pub struct $name {
            /// واحد بالإضافة إلى الإزاحة إلى أقصى حد "digit" قيد الاستخدام.
            /// هذا لا ينقص ، لذا كن على دراية بترتيب الحساب.
            /// `base[size..]` يجب أن تكون صفرًا.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` يمثل `a + b *2^W + c* 2^(2W) + ...` حيث `W` هو عدد البتات في نوع الرقم.
            base: [$ty; $n],
        }

        impl $name {
            /// يصنع bignum من رقم واحد.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// يصنع قطعة صغيرة من قيمة `u64`.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// تُرجع الأرقام الداخلية كشريحة `[a, b, c, ...]` بحيث تكون القيمة الرقمية `a + b *2^W + c* 2^(2W) + ...` حيث `W` هي عدد وحدات البت في نوع الرقم.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// لعرض بت `i`-th حيث تكون البتة 0 هي الأقل أهمية.
            /// بمعنى آخر ، البتة ذات الوزن `2^i`.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// تُرجع `true` إذا كان الحجم الصغير صفرًا.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// تُرجع عدد وحدات البت اللازمة لتمثيل هذه القيمة.
            /// لاحظ أن الصفر يعتبر بحاجة إلى 0 بت.
            pub fn bit_length(&self) -> usize {
                // تخطي أهم الأرقام التي تساوي صفرًا.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // لا توجد أرقام غير صفرية ، أي أن الرقم صفر.
                    return 0;
                }
                // يمكن تحسين ذلك باستخدام leading_zeros() وتحولات بت ، ولكن ربما لا يستحق ذلك العناء.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// يضيف `other` لنفسه ويعيد مرجع التغيير الخاص به.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// يطرح `other` من نفسه ويعيد مرجعها القابل للتغيير.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// يضاعف نفسه بـ `other` بحجم رقمي ويعيد مرجعه القابل للتغيير.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// يضاعف نفسه بـ `2^bits` ويعيد مرجعه القابل للتغيير.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // التحول بمقدار `digits * digitbits` بت
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // التحول بمقدار `bits` بت
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [.. أرقام] هو صفر ، لا حاجة للتحويل
                }

                self.size = sz;
                self
            }

            /// يضاعف نفسه بـ `5^e` ويعيد مرجعه القابل للتغيير.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // هناك n بالضبط أصفار زائدة على 2 ^ n ، وأحجام الأرقام الوحيدة ذات الصلة هي قوى متتالية لاثنين ، لذلك هذا مؤشر مناسب تمامًا للجدول.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // اضرب بأكبر قوة أحادية الرقم لأطول فترة ممكنة ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... ثم أكمل الباقي.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// يضاعف نفسه برقم موصوف بواسطة `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (حيث `W` هو عدد البتات في نوع الرقم) ويعيد مرجعه القابل للتغيير.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // الروتين الداخلي.يعمل بشكل أفضل عندما aa.len() <= bb.len().
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// تقسم نفسها على `other` بحجم رقمي وتُرجع مرجعها القابل للتغيير *و* الباقي.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// قسّم الذات على كتلة أخرى ، واستبدل `q` بالحاصل و `r` بالباقي.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // قسمة طويلة بطيئة غبية base-2 مأخوذة من
                // https://en.wikipedia.org/wiki/Division_algorithm
                // تستخدم FIXME قاعدة أكبر ($ty) للقسمة الطويلة.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // قم بتعيين البت `i` من q إلى 1.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// نوع الرقم لـ `Big32x40`.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// هذا واحد يستخدم للاختبار فقط.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}