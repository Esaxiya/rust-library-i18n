//! التحقق من صحة سلسلة عشرية من النموذج وتفكيكها:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! بمعنى آخر ، بناء جملة الفاصلة العائمة القياسي ، مع استثناءين: بدون علامة ، وعدم معالجة "inf" و "NaN".يتم التعامل مع هذه بواسطة وظيفة السائق (super::dec2flt).
//!
//! على الرغم من أن التعرف على المدخلات الصالحة أمر سهل نسبيًا ، إلا أنه يتعين على هذه الوحدة أيضًا رفض التباينات غير الصالحة التي لا تعد ولا تحصى ، وعدم استخدام panic مطلقًا ، وإجراء العديد من الفحوصات التي تعتمد عليها الوحدات النمطية الأخرى لعدم استخدام panic (أو تجاوز سعة) بدورها.
//!
//! لجعل الأمور أسوأ ، كل هذا يحدث في تمريرة واحدة فوق المدخلات.
//! لذا ، كن حذرًا عند تعديل أي شيء ، وتحقق مرة أخرى من الوحدات النمطية الأخرى.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// الأجزاء المثيرة للاهتمام من السلسلة العشرية.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// الأس العشري ، مضمون أن يحتوي على أقل من 18 رقمًا عشريًا.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// للتحقق مما إذا كانت سلسلة الإدخال رقمًا صالحًا للفاصلة العائمة ، وإذا كان الأمر كذلك ، فحدد موقع الجزء المتكامل والجزء الكسري والأس فيه.
/// لا يتعامل مع العلامات.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // لا توجد أرقام قبل 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // نحن نطلب رقمًا واحدًا على الأقل قبل النقطة أو بعدها.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // خردة زائدة بعد جزء كسري
            }
        }
        _ => Invalid, // خردة زائدة بعد سلسلة الرقم الأول
    }
}

/// ينحت من الأرقام العشرية حتى الحرف الأول غير الرقمي.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// استخراج الأس وفحص الأخطاء.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // خردة زائدة بعد الأس
    }
    if number.is_empty() {
        return Invalid; // الأس الفارغ
    }
    // في هذه المرحلة ، لدينا بالتأكيد سلسلة صالحة من الأرقام.قد يستغرق الأمر وقتًا طويلاً جدًا لوضعه في `i64` ، ولكن إذا كان هذا الحجم ضخمًا ، فمن المؤكد أن الإدخال هو صفر أو لا نهاية.
    // نظرًا لأن كل صفر في الأرقام العشرية يضبط الأس بمقدار +/-1 ، عند exp=10 ^ 18 يجب أن يكون الإدخال 17 إكسابايت (!) من الأصفار حتى تقترب عن بعد من كونها محدودة.
    //
    // هذه ليست حالة استخدام بالضبط نحتاج إلى تلبيتها.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}