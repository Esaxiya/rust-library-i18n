//! وظائف المنفعة لـ bignums التي ليس من المنطقي تحويلها إلى طرق.

// FIXME اسم هذه الوحدة مؤسف بعض الشيء ، لأن الوحدات الأخرى تستورد أيضًا `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// اختبر ما إذا كان اقتطاع كل وحدات البت الأقل أهمية من `ones_place` يؤدي إلى حدوث خطأ نسبي أقل أو يساوي أو أكبر من 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // إذا كانت جميع وحدات البت المتبقية صفرًا ، فهي= 0.5 ULP ، وإلا> 0.5 إذا لم يكن هناك المزيد من البتات (half_bit==0) ، فإن الجزء التالي يُرجع أيضًا Equal بشكل صحيح.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// يحول سلسلة ASCII التي تحتوي على أرقام عشرية فقط إلى `u64`.
///
/// لا يقوم بإجراء عمليات التحقق من الأحرف الفائضة أو غير الصالحة ، لذلك إذا لم يكن المتصل حريصًا ، فإن النتيجة زائفة ويمكن أن يكون panic (على الرغم من أنه لن يكون `unsafe`).
/// بالإضافة إلى ذلك ، يتم التعامل مع السلاسل الفارغة على أنها صفر.
/// هذه الوظيفة موجودة لأن
///
/// 1. يتطلب استخدام `FromStr` على `&[u8]` `from_utf8_unchecked` ، وهو أمر سيء ، و
/// 2. يعد تجميع نتائج `integral.parse()` و `fractional.parse()` معًا أكثر تعقيدًا من هذه الوظيفة بأكملها.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// يحول سلسلة من أرقام ASCII إلى bignum.
///
/// مثل `from_str_unchecked` ، تعتمد هذه الوظيفة على المحلل اللغوي للتخلص من غير الأرقام.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// يفك التفاف bignum في عدد صحيح 64 بت.Panics إذا كان الرقم كبيرًا جدًا.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// يستخرج مجموعة من البتات.

/// المؤشر 0 هو البت الأقل أهمية والنطاق نصف مفتوح كالمعتاد.
/// Panics إذا طُلب منه استخراج المزيد من البتات أكثر مما يناسب نوع الإرجاع.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}