//! تلاعب بت على تعويم IEEE 754 الموجب.الأرقام السالبة ليست ولا يلزم التعامل معها.
//! أرقام الفاصلة العائمة العادية لها تمثيل قانوني مثل (frac ، exp) بحيث تكون القيمة 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) حيث N هو عدد البتات.
//!
//! تختلف الحالات غير الطبيعية قليلاً وغريبة ، لكن نفس المبدأ ينطبق.
//!
//! ومع ذلك ، فإننا نمثلهم هنا على أنهم (sig ، k) مع f موجب ، بحيث تكون القيمة f *
//! 2 <sup>هـ</sup> .إلى جانب جعل "hidden bit" صريحًا ، فإن هذا يغير الأس من خلال ما يسمى بزاحة الجزء العشري.
//!
//! بعبارة أخرى ، عادةً ما تتم كتابة العوامات كـ (1) ولكن هنا تتم كتابتها كـ (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! نسمي (1)**التمثيل الكسري** و (2)**التمثيل المتكامل**.
//!
//! تتعامل العديد من الوظائف في هذه الوحدة مع الأرقام العادية فقط.تأخذ إجراءات dec2flt بشكل متحفظ المسار البطيء الصحيح عالميًا (الخوارزمية M) للأعداد الصغيرة جدًا والكبيرة جدًا.
//! تحتاج هذه الخوارزمية إلى next_float() فقط والتي تتعامل مع العناصر الفرعية والأصفار.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// مساعد trait لتجنب تكرار كل كود التحويل لـ `f32` و `f64` بشكل أساسي.
///
/// راجع تعليق مستند الوحدة الرئيسية لمعرفة سبب ضرورة ذلك.
///
/// يجب ألا يتم تطبيق **أبدًا** مطلقًا مع أنواع أخرى أو استخدامه خارج وحدة dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// النوع المستخدم من قبل `to_bits` و `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// ينفذ تحويل خام إلى عدد صحيح.
    fn to_bits(self) -> Self::Bits;

    /// ينفذ تحويل خام من عدد صحيح.
    fn from_bits(v: Self::Bits) -> Self;

    /// إرجاع الفئة التي يقع فيها هذا الرقم.
    fn classify(self) -> FpCategory;

    /// تُرجع الجزء العشري والأس وعلامة كأعداد صحيحة.
    fn integer_decode(self) -> (u64, i16, i8);

    /// يفك تعويم.
    fn unpack(self) -> Unpacked;

    /// يلقي من عدد صحيح صغير يمكن تمثيله بالضبط.
    /// Panic إذا تعذر تمثيل العدد الصحيح ، فإن الكود الآخر في هذه الوحدة يتأكد من عدم السماح بحدوث ذلك أبدًا.
    fn from_int(x: u64) -> Self;

    /// الحصول على القيمة 10 <sup>e</sup> من جدول محسوب مسبقًا.
    /// Panics لـ `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// ماذا يقول الاسم.
    /// من الأسهل كتابة التعليمات البرمجية الصلبة بدلاً من التلاعب بالأشياء الجوهرية على أمل أن يطويها ثابت LLVM.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // حد متحفظ على الأرقام العشرية للمدخلات التي لا يمكنها إنتاج تجاوز أو صفر أو
    /// شذوذ.من المحتمل أن يكون الأس العشري للحد الأقصى للقيمة العادية ، ومن هنا جاء الاسم.
    const MAX_NORMAL_DIGITS: usize;

    /// عندما يكون لأهم رقم عشري قيمة مكانية أكبر من هذا ، يتم تقريب الرقم بالتأكيد إلى ما لا نهاية.
    ///
    const INF_CUTOFF: i64;

    /// عندما يكون لأكبر رقم عشري قيمة مكانية أقل من هذا ، يتم بالتأكيد تقريب الرقم إلى الصفر.
    ///
    const ZERO_CUTOFF: i64;

    /// عدد البتات في الأس.
    const EXP_BITS: u8;

    /// عدد البتات في المعنى ،*بما في ذلك* البتة المخفية.
    const SIG_BITS: u8;

    /// عدد البتات في المعنى ،*باستثناء* البتة المخفية.
    const EXPLICIT_SIG_BITS: u8;

    /// الحد الأقصى للأس القانوني في التمثيل الجزئي.
    const MAX_EXP: i16;

    /// الحد الأدنى للأس القانوني في التمثيل الكسري ، باستثناء القيم الفرعية.
    const MIN_EXP: i16;

    /// `MAX_EXP` للتمثيل المتكامل ، أي مع تطبيق التحول.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` مشفر (على سبيل المثال ، مع انحياز تعويض)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` للتمثيل المتكامل ، أي مع تطبيق التحول.
    const MIN_EXP_INT: i16;

    /// الحد الأقصى المقيس للدلالة في التمثيل المتكامل.
    const MAX_SIG: u64;

    /// الحد الأدنى المقيس للدلالة في التمثيل المتكامل.
    const MIN_SIG: u64;
}

// في الغالب حل بديل لـ #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// تُرجع الجزء العشري والأس وعلامة كأعداد صحيحة.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // تحيز الأس + إزاحة الجزء العشري
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe غير مؤكد ما إذا كان `as` يدور بشكل صحيح على جميع المنصات.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// تُرجع الجزء العشري والأس وعلامة كأعداد صحيحة.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // تحيز الأس + إزاحة الجزء العشري
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe غير مؤكد ما إذا كان `as` يدور بشكل صحيح على جميع المنصات.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// يحول `Fp` إلى أقرب نوع تعويم للجهاز.
/// لا يعالج نتائج غير طبيعية.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f هو 64 بت ، لذا فإن xe لديه إزاحة الجزء العشري من 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// قم بتدوير الدلالة 64 بت و T::SIG_BITS بتات من النصف إلى الزوج.
/// لا يتعامل مع تجاوز الأس.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // ضبط تحول الجزء العشري
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// معكوس `RawFloat::unpack()` للأرقام المقيسة.
/// Panics إذا كان الدلالة أو الأس غير صالحين للأرقام المقيسة.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // قم بإزالة البت المخفي
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // ضبط الأس لتحيز الأس وتحول الجزء العشري
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // اترك بت تسجيل الدخول عند 0 ("+") ، جميع أرقامنا موجبة
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// بناء غير طبيعي.يُسمح باستخدام الجزء العشري من 0 ويقوم ببناء الصفر.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // الأس المشفر هو 0 ، بت الإشارة هو 0 ، لذلك علينا فقط إعادة تفسير البتات.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// تقريب bignum مع Fp.تدور في نطاق 0.5 ULP بنصف زوجي.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // لقد قطعنا جميع وحدات البت قبل المؤشر `start` ، أي أننا نحول بشكل فعال إلى اليمين بمقدار `start` ، لذلك هذا أيضًا هو الأس الذي نحتاجه.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Round (half-to-even) اعتمادًا على البتات المقطوعة.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// إيجاد أكبر رقم فاصلة عائمة أصغر من الوسيطة.
/// لا يتعامل مع العناصر الفرعية ، أو الصفرية ، أو التدفق الأسّي.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// أوجد أصغر رقم فاصلة عائمة أكبر من المتغير.
// هذه العملية مشبعة ، أي next_float(inf) ==inf.
// على عكس معظم الكود في هذه الوحدة ، فإن هذه الوظيفة لا تتعامل مع الصفر ، والقيم الفرعية ، واللانهائية.
// ومع ذلك ، مثل جميع الكودات الأخرى هنا ، فإنها لا تتعامل مع NaN والأرقام السالبة.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // هذا يبدو جيدًا جدًا لدرجة يصعب تصديقه ، لكنه يعمل.
        // 0.0 يتم ترميزها على أنها كلمة صفرية بالكامل.الشذوذ الثانوي هو 0x000m ... m حيث m هو الجزء العشري.
        // على وجه الخصوص ، أصغر غير طبيعي هو 0x0 ... 01 وأكبرها هو 0x000F ... F.
        // أصغر رقم عادي هو 0x0010 ... 0 ، لذا تعمل حالة الزاوية هذه أيضًا.
        // إذا تجاوزت الزيادة الجزء العشري ، فإن بتة الحمل تزيد الأس كما نريد ، وتصبح بتات الجزء العشري صفرًا.
        // بسبب اصطلاح البت المخفي ، هذا أيضًا ما نريده بالضبط!
        // أخيرًا ، f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}