//! تحويل السلاسل العشرية إلى أرقام فاصلة عائمة ثنائية IEEE 754.
//!
//! # عرض المشكلة
//!
//! لدينا سلسلة عشرية مثل `12.34e56`.
//! تتكون هذه السلسلة من أجزاء (`12`) متكاملة و (`34`) كسري وأجزاء الأس (`56`).جميع الأجزاء اختيارية ويتم تفسيرها على أنها صفر عند فقدها.
//!
//! نسعى للحصول على رقم الفاصلة العائمة IEEE 754 الأقرب إلى القيمة الدقيقة للسلسلة العشرية.
//! من المعروف أن العديد من السلاسل العشرية لا تحتوي على تمثيلات نهائية في الأساس الثاني ، لذلك نقرب إلى وحدات 0.5 في المكان الأخير (بمعنى آخر ، قدر الإمكان).
//! يتم حل الروابط ، وهي قيم عشرية بالضبط في منتصف الطريق بين تعويمين متتاليين ، باستخدام استراتيجية النصف إلى الزوج ، والمعروفة أيضًا باسم التقريب المصرفي.
//!
//! وغني عن القول ، أن هذا صعب للغاية ، سواء من حيث تعقيد التنفيذ أو من حيث دورات وحدة المعالجة المركزية التي يتم أخذها.
//!
//! # Implementation
//!
//! أولاً ، نتجاهل العلامات.أو بالأحرى ، نقوم بإزالته في بداية عملية التحويل وإعادة تطبيقه في النهاية.
//! هذا صحيح في جميع حالات edge نظرًا لأن عوامات IEEE متماثلة حول الصفر ، مما يؤدي إلى إبطال واحد يقلب البتة الأولى.
//!
//! ثم نزيل الفاصلة العشرية بضبط الأس: من الناحية المفاهيمية ، يتحول `12.34e56` إلى `1234e54` ، والذي نصفه بعدد صحيح موجب `f = 1234` وعدد صحيح `e = 54`.
//! يتم استخدام تمثيل `(f, e)` بواسطة جميع التعليمات البرمجية تقريبًا بعد مرحلة التحليل.
//!
//! نحاول بعد ذلك سلسلة طويلة من الحالات الخاصة الأكثر عمومية وباهظة التكلفة بشكل تدريجي باستخدام أعداد صحيحة بحجم الآلة وأرقام فاصلة عائمة صغيرة وثابتة الحجم (أول `f32`/`f64` ، ثم نوع ذو 64 بت كبير ، `Fp`).
//!
//! عندما تفشل كل هذه الأمور ، فإننا نلجأ إلى خوارزمية بسيطة ولكنها بطيئة للغاية تتضمن حساب `f * 10^e` بالكامل وإجراء بحث تكراري للحصول على أفضل تقريب.
//!
//! بشكل أساسي ، تقوم هذه الوحدة وأبناؤها بتنفيذ الخوارزميات الموضحة في:
//! "How to Read Floating Point Numbers Accurately" بواسطة William D.
//! Clinger ، متاح على الإنترنت: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! بالإضافة إلى ذلك ، هناك العديد من الوظائف المساعدة التي يتم استخدامها في الورق ولكنها غير متوفرة في Rust (أو على الأقل في النواة).
//! بالإضافة إلى ذلك ، فإن نسختنا معقدة بسبب الحاجة إلى التعامل مع التدفق الزائد والنقصان والرغبة في التعامل مع الأرقام غير الطبيعية.
//! يواجه Bellerophon و Algorithm R مشكلة في التدفق الزائد ، والتشوهات الفرعية ، والتدفق السفلي.
//! ننتقل بشكل متحفظ إلى الخوارزمية M (مع التعديلات الموضحة في القسم 8 من الورقة) قبل أن تدخل المدخلات في المنطقة الحرجة.
//!
//! هناك جانب آخر يحتاج إلى الاهتمام وهو `` RawFloat '' trait الذي يتم من خلاله تحديد جميع الوظائف تقريبًا.قد يعتقد المرء أنه يكفي التحليل إلى `f64` وإلقاء النتيجة على `f32`.
//! لسوء الحظ ، هذا ليس العالم الذي نعيش فيه ، وهذا ليس له علاقة باستخدام تقريب القاعدة اثنين أو نصف إلى زوجي.
//!
//! ضع في اعتبارك على سبيل المثال نوعين `d2` و `d4` يمثلان نوعًا عشريًا يتكون من رقمين عشريين وأربعة أرقام عشرية لكل منهما وأخذ "0.01499" كمدخل.دعنا نستخدم التقريب النصفي.
//! بالانتقال مباشرة إلى رقمين عشريين ، نحصل على `0.01` ، ولكن إذا قمنا بالتقريب إلى أربعة أرقام أولاً ، نحصل على `0.0150` ، والذي يتم تقريبه بعد ذلك إلى `0.02`.
//! ينطبق نفس المبدأ على العمليات الأخرى أيضًا ، إذا كنت تريد دقة 0.5 ULP ، فأنت بحاجة إلى القيام *بكل شيء* بدقة كاملة ودور *مرة واحدة بالضبط ، في النهاية*، من خلال النظر في جميع البتات المقتطعة مرة واحدة.
//!
//! FIXME: على الرغم من ضرورة تكرار بعض التعليمات البرمجية ، ربما يمكن تبديل أجزاء من الشفرة بشكل عشوائي بحيث يتم تكرار عدد أقل من التعليمات البرمجية.
//! أجزاء كبيرة من الخوارزميات مستقلة عن نوع الطفو للإخراج ، أو تحتاج فقط إلى الوصول إلى عدد قليل من الثوابت ، والتي يمكن تمريرها كمعلمات.
//!
//! # Other
//!
//! يجب ألا يتم التحويل *أبدًا* panic.
//! هناك تأكيدات و panics صريحة في الكود ، لكن لا ينبغي إطلاقها مطلقًا ، وتعمل فقط كفحص داخلي للسلامة.يجب اعتبار أي panics خطأ.
//!
//! هناك اختبارات وحدة لكنها غير كافية على الإطلاق لضمان صحتها ، فهي لا تغطي سوى نسبة صغيرة من الأخطاء المحتملة.
//! توجد اختبارات أكثر شمولاً في الدليل `src/etc/test-float-parse` كنص Python.
//!
//! ملاحظة حول تجاوز عدد صحيح: تؤدي أجزاء كثيرة من هذا الملف العمليات الحسابية باستخدام الأس العشري `e`.
//! في المقام الأول ، نقوم بإزاحة الفاصلة العشرية حول: قبل أول رقم عشري ، بعد آخر رقم عشري ، وهكذا.هذا يمكن أن يفيض إذا تم بإهمال.
//! نحن نعتمد على وحدة التحليل الفرعية لتوزيع الأسس الصغيرة بشكل كافٍ فقط ، حيث "sufficient" تعني "such that the exponent +/- the number of decimal digits fits into a 64 bit integer".
//! يتم قبول الأس الأكبر ، لكننا لا نقوم بالحسابات معهم ، يتم تحويلهم على الفور إلى {positive,negative} {zero,infinity}.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// هذان الاثنان لديهم اختباراتهم الخاصة.
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// تحويل سلسلة في الأساس 10 إلى عدد عشري.
            /// يقبل أسًا عشريًا اختياريًا.
            ///
            /// تقبل هذه الوظيفة سلاسل مثل
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', أو مكافئ، '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', أو مكافئ، '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// المسافة البيضاء البادئة والزائدة تمثل خطأ.
            ///
            /// # Grammar
            ///
            /// ستؤدي جميع السلاسل التي تلتزم بقواعد [EBNF] التالية إلى إرجاع [`Ok`]:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # الأخطاء المعروفة
            ///
            /// في بعض الحالات ، بعض السلاسل التي يجب أن تنشئ عددًا صحيحًا عائمًا تُرجع خطأً.
            /// راجع [issue #31407] للحصول على التفاصيل.
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src ، سلسلة
            ///
            /// # قيمة الإرجاع
            ///
            /// `Err(ParseFloatError)` إذا كانت السلسلة لا تمثل رقمًا صالحًا.
            /// خلاف ذلك ، `Ok(n)` حيث `n` هو رقم الفاصلة العائمة الذي يمثله `src`.
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// خطأ يمكن إرجاعه عند تحليل عدد عشري.
///
/// يتم استخدام هذا الخطأ كنوع الخطأ لتطبيق [`FromStr`] لـ [`f32`] و [`f64`].
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// يقسم السلسلة العشرية إلى علامة والباقي ، دون فحص الباقي أو التحقق من صحته.
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // إذا كانت السلسلة غير صالحة ، فلن نستخدم العلامة أبدًا ، لذلك لا نحتاج إلى التحقق من صحتها هنا.
        _ => (Sign::Positive, s),
    }
}

/// تحويل سلسلة عشرية إلى رقم فاصلة عائمة.
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// العامل الرئيسي للتحويل من عشري إلى عائم: تنظيم جميع عمليات المعالجة المسبقة ومعرفة الخوارزمية التي يجب أن تقوم بالتحويل الفعلي.
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift خارج الفاصلة العشرية.
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40 محدود بـ 1280 بت ، وهو ما يترجم إلى حوالي 385 رقمًا عشريًا.
    // إذا تجاوزنا هذا ، فسوف نتعطل ، لذلك نخطئ قبل الاقتراب جدًا (في غضون 10 ^ 10).
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // الآن الأس يناسب بالتأكيد 16 بت ، والذي يستخدم في جميع الخوارزميات الرئيسية.
    let e = e as i16;
    // FIXME هذه الحدود متحفظة نوعًا ما.
    // يمكن أن يسمح التحليل الأكثر دقة لأنماط فشل Bellerophon باستخدامه في المزيد من الحالات لتسريع كبير.
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// كما هو مكتوب ، يتحسن هذا بشكل سيء (انظر #27130 ، على الرغم من أنه يشير إلى إصدار قديم من الكود).
// `inline(always)` هو حل بديل لذلك.
// لا يوجد سوى موقعين للاتصال بشكل عام ولا يجعل حجم الشفرة أسوأ.

/// اخلع الأصفار قدر الإمكان ، حتى عندما يتطلب ذلك تغيير الأس
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // لا يؤدي اقتطاع هذه الأصفار إلى تغيير أي شيء ولكنه قد يؤدي إلى تمكين المسار السريع (أقل من 15 رقمًا).
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // بسّط الأرقام على شكل 0.0 ... x و x ... 0.0 ، واضبط الأس وفقًا لذلك.
    // قد لا يكون هذا دائمًا فوزًا (ربما يدفع بعض الأرقام خارج المسار السريع) ، لكنه يبسط الأجزاء الأخرى بشكل كبير (على وجه الخصوص ، تقريب حجم القيمة).
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// تُرجع حدًا علويًا سريعًا متسخًا على الحجم (log10) لأكبر قيمة ستحسبها الخوارزمية R والخوارزمية M أثناء العمل على الرقم العشري المحدد.
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // لا داعي للقلق كثيرًا بشأن الفائض هنا بفضل trivial_cases() والمحلل اللغوي ، الذي يقوم بتصفية المدخلات الأكثر تطرفًا بالنسبة لنا.
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // في الحالة e>=0 ، تحسب كلتا الخوارزميتين حوالي `f * 10^e`.
        // تستمر الخوارزمية R في إجراء بعض العمليات الحسابية المعقدة مع هذا ولكن يمكننا تجاهل ذلك للحد الأعلى لأنه يقلل أيضًا من الكسر مسبقًا ، لذلك لدينا الكثير من المخزن المؤقت هناك.
        //
        f_len + (e as u64)
    } else {
        // إذا كانت e <0 ، فإن الخوارزمية R تفعل نفس الشيء تقريبًا ، لكن الخوارزمية M تختلف:
        // يحاول العثور على رقم موجب k بحيث يكون `f << k / 10^e` عبارة عن أهمية ضمن النطاق.
        // سينتج عن ذلك حوالي `2^53 *f* 10^e` <`10^17 *f* 10^e`.
        // أحد المدخلات التي تؤدي إلى هذا هو 0.33 ... 33 (375 × 3).
        f_len + e.unsigned_abs() + 17
    }
}

/// يكتشف الفيضانات والتدفقات السفلية الواضحة دون النظر إلى الأرقام العشرية.
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // كانت هناك أصفار لكن تم تجريدها بواسطة simplify()
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // هذا تقدير تقريبي لـ ceil(log10(the real value)).
    // لا داعي للقلق كثيرًا بشأن الفائض هنا لأن طول الإدخال صغير (على الأقل مقارنة بـ 2 ^ 64) ويتعامل المحلل اللغوي بالفعل مع الأسس التي تكون قيمتها المطلقة أكبر من 10 ^ 18 (والتي لا تزال 10 ^ 19 قصيرة من 2 ^ 64).
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}