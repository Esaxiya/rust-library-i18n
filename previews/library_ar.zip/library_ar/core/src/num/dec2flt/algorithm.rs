//! الخوارزميات المختلفة من الورقة.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// عدد بتات الدلالة في Fp
const P: u32 = 64;

// نقوم ببساطة بتخزين أفضل تقدير تقريبي لجميع الأسس ، لذلك يمكن حذف المتغير "h" والشروط المرتبطة به.
// هذا يتاجر بالأداء لبضعة كيلو بايت من المساحة.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// في معظم الأبنية ، يكون لعمليات الفاصلة العائمة حجم بت واضح ، وبالتالي يتم تحديد دقة الحساب على أساس كل عملية.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// في x86 ، يتم استخدام x87 FPU لعمليات الطفو في حالة عدم توفر امتدادات SSE/SSE2.
// تعمل x87 FPU بدقة 80 بت افتراضيًا ، مما يعني أن العمليات ستقرب إلى 80 بت مما يؤدي إلى حدوث تقريب مزدوج عندما يتم تمثيل القيم في النهاية على أنها
//
// 32/64 قيم بت عائم.للتغلب على هذا ، يمكن ضبط كلمة تحكم FPU بحيث يتم إجراء الحسابات بالدقة المطلوبة.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// هيكل يستخدم للحفاظ على القيمة الأصلية لكلمة تحكم FPU ، بحيث يمكن استعادتها عند إسقاط الهيكل.
    ///
    ///
    /// x87 FPU عبارة عن سجل مكون من 16 بت تكون حقولها كما يلي:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// تتوفر الوثائق الخاصة بكل الحقول في دليل مطور برامج IA-32 Architectures (المجلد 1).
    ///
    /// الحقل الوحيد المناسب للرمز التالي هو الكمبيوتر ، التحكم الدقيق.
    /// يحدد هذا الحقل دقة العمليات التي تقوم بها FPU.
    /// يمكن ضبطه على:
    ///  - 0b00 ، دقة فردية أي 32 بت
    ///  - 0b10 ، دقة مزدوجة أي 64 بت
    ///  - 0b11 ، دقة مزدوجة ممتدة ، أي 80 بت (الحالة الافتراضية) القيمة 0b01 محفوظة ويجب عدم استخدامها.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // الأمان: تم تدقيق تعليمات `fldcw` لتتمكن من العمل بشكل صحيح معها
        // أي `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: نحن نستخدم صيغة ATT لدعم LLVM 8 و LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// يضبط مجال الدقة لوحدة FPU على `T` ويعيد `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // احسب قيمة حقل التحكم الدقيق المناسب لـ `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 بت
            8 => 0x0200, // 64 بت
            _ => 0x0300, // الافتراضي ، 80 بت
        };

        // احصل على القيمة الأصلية لكلمة التحكم لاستعادتها لاحقًا ، عندما يتم إسقاط بنية `FPUControlWord` السلامة: تم تدقيق تعليمات `fnstcw` لتتمكن من العمل بشكل صحيح مع أي `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: نحن نستخدم صيغة ATT لدعم LLVM 8 و LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // اضبط كلمة التحكم على الدقة المطلوبة.
        // يتم تحقيق ذلك عن طريق إخفاء الدقة القديمة (البتتان 8 و 9 ، 0x300) واستبدالها بعلامة الدقة المحسوبة أعلاه.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// المسار السريع لـ Bellerophon باستخدام الأعداد الصحيحة والعائمة بحجم الآلة.
///
/// يتم استخراج هذا في دالة منفصلة بحيث يمكن تجربتها قبل إنشاء bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // قارنا القيمة الدقيقة بـ MAX_SIG قرب النهاية ، وهذا مجرد رفض سريع ورخيص (كما أنه يحرر بقية الشفرة من القلق بشأن التدفق السفلي).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // يعتمد المسار السريع بشكل أساسي على تقريب الحساب إلى العدد الصحيح من البتات دون أي تقريب وسيط.
    // في x86 (بدون SSE أو SSE2) يتطلب ذلك تغيير دقة مكدس x87 FPU بحيث يتم تقريبه مباشرة إلى 64/32 بت.
    // تهتم وظيفة `set_precision` بضبط الدقة على البنى التي تتطلب تعيينها عن طريق تغيير الحالة العامة (مثل كلمة التحكم في x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // لا يمكن طي الحالة e <0 في branch الأخرى.
    // تؤدي القوى السلبية إلى تكرار الجزء الكسري في النظام الثنائي ، والذي يتم تقريبه ، مما يتسبب في أخطاء حقيقية (وأحيانًا كبيرة جدًا!) في النتيجة النهائية.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// خوارزمية Bellerophon هو رمز تافه يبرره تحليل رقمي غير تافه.
///
/// تقوم بتقريب `` f '' إلى عوامة ذات دلالة 64 بت وتضربها بأفضل تقريب لـ `10^e` (بنفس تنسيق النقطة العائمة).غالبًا ما يكون هذا كافيًا للحصول على النتيجة الصحيحة.
/// ومع ذلك ، عندما تكون النتيجة قريبة من منتصف المسافة بين طائرتين متجاورتين (ordinary) ، فإن خطأ التقريب المركب الناتج عن ضرب تقريبين يعني أن النتيجة قد تكون بعيدة ببضع بتات.
/// عندما يحدث هذا ، فإن الخوارزمية التكرارية R تصلح الأمور.
///
/// تم جعل "close to halfway" المموج يدويًا دقيقًا من خلال التحليل الرقمي في الورقة.
/// على حد تعبير كلينجر:
///
/// > الانحدار ، معبراً عنه بوحدات البت الأقل دلالة ، هو حد شامل للخطأ
/// > المتراكمة أثناء حساب النقطة العائمة للتقريب إلى f * 10 ^ e.(Slop هو
/// > ليس حدًا للخطأ الحقيقي ، ولكنه يحد من الفرق بين التقريب z و
/// > أفضل تقريب ممكن يستخدم p بت من الدلالة و.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // الحالات abs(e) <log5(2^N) في fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // هل المنحدر كبير بما يكفي لإحداث فرق عند التقريب إلى عدد n بت؟
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// خوارزمية تكرارية تعمل على تحسين تقريب النقطة العائمة لـ `f * 10^e`.
///
/// تقترب كل عملية تكرار من وحدة واحدة في المكان الأخير ، والتي تستغرق بالطبع وقتًا طويلاً للتقارب إذا تم إيقاف تشغيل `z0` بشكل معتدل.
/// لحسن الحظ ، عند استخدامه كبديل لـ Bellerophon ، يتم إيقاف تقريب البداية بمقدار ULP واحد على الأكثر.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // أوجد الأعداد الصحيحة الموجبة `x` ، `y` بحيث يكون `x / y` هو `(f *10^e) / (m* 2^k)` بالضبط.
        // هذا لا يتجنب فقط التعامل مع علامات `e` و `k` ، بل نلغي أيضًا القوة المشتركة بين `10^e` و `2^k` لجعل الأرقام أصغر.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // هذا مكتوب بشكل محرج بعض الشيء لأن bignums لدينا لا تدعم الأرقام السالبة ، لذلك نستخدم القيمة المطلقة + معلومات الإشارة.
        // لا يمكن أن يتجاوز الضرب بـ m_digits.
        // إذا كانت `x` أو `y` كبيرة بما يكفي لدرجة أننا نحتاج إلى القلق بشأن الفائض ، فهي أيضًا كبيرة بما يكفي لأن `make_ratio` قد خفضت الكسر بمعامل 2 ^ 64 أو أكثر.
        //
        //
        let (d2, d_negative) = if x >= y {
            // لا تحتاج x أكثر ، احفظ clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // ما زلت بحاجة ذ ، قم بعمل نسخة.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// بالنظر إلى `x = f` و `y = m` حيث يمثل `f` إدخال أرقام عشرية كالمعتاد و `m` هو دلالة تقريب الفاصلة العائمة ، اجعل النسبة `x / y` تساوي `(f *10^e) / (m* 2^k)` ، وربما يتم تقليلها بقوة اثنين وهما مشتركان.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e ، y=m* 2 ^ k ، باستثناء أننا اختزلنا الكسر ببعض الأس اثنين.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k)، y=m لا يمكن تجاوز هذا لأنه يتطلب `e` موجبًا وسالب `k` ، والذي يمكن أن يحدث فقط للقيم القريبة جدًا من 1 ، مما يعني أن `e` و `k` سيكونان صغيران نسبيًا.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f، y=m *10^abs(e)* 2 ^ k هذا لا يمكن أن يفيض أيضًا ، انظر أعلاه.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k) ، y=m* 10^abs(e) ، مرة أخرى يتم تقليلها بقوة مشتركة لاثنين.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// من الناحية المفاهيمية ، تعد الخوارزمية M هي أبسط طريقة لتحويل عدد عشري إلى عدد عشري.
///
/// نشكل نسبة تساوي `f * 10^e` ، ثم نضع أس اثنين حتى نحصل على قيمة عائمة صحيحة.
/// الأس الثنائي `k` هو عدد المرات التي ضربنا فيها البسط أو المقام في اثنين ، أي في جميع الأوقات `f *10^e` يساوي `(u / v)* 2^k`.
/// عندما نكتشف المعنى والدلالة ، نحتاج فقط إلى التقريب بفحص باقي القسمة ، وهو ما يتم في الدوال المساعدة أدناه.
///
///
/// هذه الخوارزمية بطيئة للغاية ، حتى مع التحسين الموصوف في `quick_start()`.
/// ومع ذلك ، فإن أبسط الخوارزميات للتكيف مع الفائض والتدفق والنتائج غير الطبيعية.
/// يتم تنفيذ هذا التنفيذ عندما تكون Bellerophon و Algorithm R غارقين.
/// يعد اكتشاف التدفق السفلي والفيضان أمرًا سهلاً: لا تزال النسبة ليست ذات أهمية في النطاق ، ومع ذلك تم الوصول إلى الأس minimum/maximum.
/// في حالة الفائض ، نعيد ببساطة اللانهاية.
///
/// يعتبر التعامل مع التدفق السفلي والأوضاع غير الطبيعية أكثر صعوبة.
/// تتمثل إحدى المشكلات الكبيرة في أنه مع الحد الأدنى للأس ، قد تظل النسبة كبيرة جدًا بالنسبة إلى الدلالة.
/// راجع underflow() للحصول على التفاصيل.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // تحسينات FIXME الممكنة: قم بتعميم big_to_fp حتى نتمكن من عمل ما يعادل fp_to_float(big_to_fp(u)) هنا ، فقط بدون التقريب المزدوج.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // يجب أن نتوقف عند الحد الأدنى للأس ، إذا انتظرنا حتى `k < T::MIN_EXP_INT` ، فسنكون خارجًا بمقدار ضعفين.
            // لسوء الحظ ، هذا يعني أنه يتعين علينا وضع أرقام عادية ذات حالة خاصة مع الحد الأدنى من الأس.
            // تجد FIXME تركيبة أكثر أناقة ، ولكن قم بإجراء اختبار `tiny-pow10` للتأكد من أنها صحيحة بالفعل!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// يتخطى معظم تكرارات الخوارزمية M بالتحقق من طول البت.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // طول البت هو تقدير للوغاريتم الأساسي الثاني ، و log(u / v) = log(u) ، log(v).
    // يتم إيقاف التقدير بمقدار 1 على الأكثر ، ولكنه دائمًا ما يكون أقل من التقدير ، لذا فإن الخطأ في log(u) و log(v) لهما نفس العلامة ويلغيان (إذا كان كلاهما كبيرًا).
    // لذلك فإن الخطأ log(u / v) هو واحد على الأكثر.
    // النسبة المستهدفة هي التي يكون فيها u/v ضمن دلالة النطاق.وبالتالي فإن شرط الإنهاء الخاص بنا هو log2(u / v) كونه الدلالة والبتات ، plus/minus واحد.
    // FIXME يمكن أن يؤدي النظر إلى البت الثاني إلى تحسين التقدير وتجنب المزيد من التقسيمات.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // تحت الجريان أو غير طبيعي.اتركه للوظيفة الرئيسية.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // تجاوز.اتركه للوظيفة الرئيسية.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // النسبة ليست دلالة ضمن النطاق مع الحد الأدنى للأس ، لذلك نحتاج إلى تقريب البتات الزائدة وتعديل الأس وفقًا لذلك.
    // تبدو القيمة الحقيقية الآن كما يلي:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    ف ترونك.(يمثله rem)
    //
    // لذلك ، عندما تكون البتات المستديرة!= 0.5 ULP ، فإنها تقرر التقريب بمفردها.
    // عندما تكون متساوية والباقي غير صفري ، تظل القيمة بحاجة إلى تقريبها لأعلى.
    // فقط عندما تكون البتات المدورة هي 1/2 والباقي صفر ، يكون لدينا وضع نصف زوجي.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// جولة عادية إلى زوجية ، مشوشة بسبب الاضطرار إلى التقريب بناءً على ما تبقى من القسمة.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}