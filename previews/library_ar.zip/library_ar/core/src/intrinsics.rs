//! جوهر المترجم.
//!
//! التعريفات المقابلة في `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! تطبيقات const المقابلة في `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # جوهره Const
//!
//! Note: يجب مناقشة أي تغييرات في ثبات الجوهر مع فريق اللغة.
//! يتضمن هذا تغييرات في ثبات الثبات.
//!
//! من أجل جعل استخدام جوهري في وقت الترجمة ، يحتاج المرء إلى نسخ التنفيذ من <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> إلى `compiler/rustc_mir/src/interpret/intrinsics.rs` وإضافة `#[rustc_const_unstable(feature = "foo", issue = "01234")]` إلى الجوهر.
//!
//!
//! إذا كان من المفترض استخدام مضمن من `const fn` بسمة `rustc_const_stable` ، فيجب أن تكون سمة الجوهر `rustc_const_stable` أيضًا.
//! لا ينبغي إجراء مثل هذا التغيير بدون استشارة T-lang ، لأنه يخبز ميزة في اللغة لا يمكن تكرارها في كود المستخدم دون دعم المترجم.
//!
//! # Volatiles
//!
//! توفر المكونات الداخلية المتقلبة عمليات تهدف إلى العمل على ذاكرة I/O ، والتي تضمن عدم إعادة ترتيبها بواسطة المترجم عبر عناصر داخلية متقلبة أخرى.راجع وثائق LLVM على [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! توفر الجوهرات الذرية عمليات ذرية مشتركة على كلمات الآلة ، مع العديد من أوامر الذاكرة الممكنة.يخضعون لنفس دلالات C++ 11.راجع وثائق LLVM على [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! تجديد سريع حول ترتيب الذاكرة:
//!
//! * الحصول على حاجز للحصول على قفل.تتم عمليات القراءة والكتابة اللاحقة بعد الحاجز.
//! * حرر ، حاجزًا لتحرير القفل.تتم القراءة والكتابة السابقة قبل الحاجز.
//! * يتم ضمان حدوث عمليات متسقة بشكل تسلسلي ومتناسقة تسلسليًا بالترتيب.هذا هو الوضع القياسي للعمل مع الأنواع الذرية وهو مكافئ لـ Java's `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// يتم استخدام هذه الواردات لتبسيط الارتباطات داخل المستند
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // الأمان: انظر `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // ملاحظة: تأخذ هذه العناصر الجوهرية مؤشرات أولية لأنها تحور الذاكرة ذات الأسماء المستعارة ، وهي غير صالحة لأي من `&` أو `&mut`.
    //

    /// يخزن قيمة إذا كانت القيمة الحالية مماثلة لقيمة `old`.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهر على أنواع [`atomic`] عبر طريقة `compare_exchange` بتمرير [`Ordering::SeqCst`] كمعلمات `success` و `failure`.
    ///
    /// على سبيل المثال، [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// يخزن قيمة إذا كانت القيمة الحالية مماثلة لقيمة `old`.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهر على أنواع [`atomic`] عبر طريقة `compare_exchange` بتمرير [`Ordering::Acquire`] كمعلمات `success` و `failure`.
    ///
    /// على سبيل المثال، [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// يخزن قيمة إذا كانت القيمة الحالية مماثلة لقيمة `old`.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهر على أنواع [`atomic`] عبر طريقة `compare_exchange` بتمرير [`Ordering::Release`] باعتباره `success` و [`Ordering::Relaxed`] كمعلمات `failure`.
    /// على سبيل المثال، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// يخزن قيمة إذا كانت القيمة الحالية مماثلة لقيمة `old`.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهر على أنواع [`atomic`] عبر طريقة `compare_exchange` بتمرير [`Ordering::AcqRel`] باعتباره `success` و [`Ordering::Acquire`] كمعلمات `failure`.
    /// على سبيل المثال، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// يخزن قيمة إذا كانت القيمة الحالية مماثلة لقيمة `old`.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهر على أنواع [`atomic`] عبر طريقة `compare_exchange` بتمرير [`Ordering::Relaxed`] كمعلمات `success` و `failure`.
    ///
    /// على سبيل المثال، [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// يخزن قيمة إذا كانت القيمة الحالية مماثلة لقيمة `old`.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهر على أنواع [`atomic`] عبر طريقة `compare_exchange` بتمرير [`Ordering::SeqCst`] باعتباره `success` و [`Ordering::Relaxed`] كمعلمات `failure`.
    /// على سبيل المثال، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// يخزن قيمة إذا كانت القيمة الحالية مماثلة لقيمة `old`.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهر على أنواع [`atomic`] عبر طريقة `compare_exchange` بتمرير [`Ordering::SeqCst`] باعتباره `success` و [`Ordering::Acquire`] كمعلمات `failure`.
    /// على سبيل المثال، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// يخزن قيمة إذا كانت القيمة الحالية مماثلة لقيمة `old`.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهر على أنواع [`atomic`] عبر طريقة `compare_exchange` بتمرير [`Ordering::Acquire`] باعتباره `success` و [`Ordering::Relaxed`] كمعلمات `failure`.
    /// على سبيل المثال، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// يخزن قيمة إذا كانت القيمة الحالية مماثلة لقيمة `old`.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهر على أنواع [`atomic`] عبر طريقة `compare_exchange` بتمرير [`Ordering::AcqRel`] باعتباره `success` و [`Ordering::Relaxed`] كمعلمات `failure`.
    /// على سبيل المثال، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// يخزن قيمة إذا كانت القيمة الحالية مماثلة لقيمة `old`.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهر على أنواع [`atomic`] عبر طريقة `compare_exchange_weak` بتمرير [`Ordering::SeqCst`] كمعلمات `success` و `failure`.
    ///
    /// على سبيل المثال، [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// يخزن قيمة إذا كانت القيمة الحالية مماثلة لقيمة `old`.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهر على أنواع [`atomic`] عبر طريقة `compare_exchange_weak` بتمرير [`Ordering::Acquire`] كمعلمات `success` و `failure`.
    ///
    /// على سبيل المثال، [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// يخزن قيمة إذا كانت القيمة الحالية مماثلة لقيمة `old`.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهر على أنواع [`atomic`] عبر طريقة `compare_exchange_weak` بتمرير [`Ordering::Release`] باعتباره `success` و [`Ordering::Relaxed`] كمعلمات `failure`.
    /// على سبيل المثال، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// يخزن قيمة إذا كانت القيمة الحالية مماثلة لقيمة `old`.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهر على أنواع [`atomic`] عبر طريقة `compare_exchange_weak` بتمرير [`Ordering::AcqRel`] باعتباره `success` و [`Ordering::Acquire`] كمعلمات `failure`.
    /// على سبيل المثال، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// يخزن قيمة إذا كانت القيمة الحالية مماثلة لقيمة `old`.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهر على أنواع [`atomic`] عبر طريقة `compare_exchange_weak` بتمرير [`Ordering::Relaxed`] كمعلمات `success` و `failure`.
    ///
    /// على سبيل المثال، [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// يخزن قيمة إذا كانت القيمة الحالية مماثلة لقيمة `old`.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهر على أنواع [`atomic`] عبر طريقة `compare_exchange_weak` بتمرير [`Ordering::SeqCst`] باعتباره `success` و [`Ordering::Relaxed`] كمعلمات `failure`.
    /// على سبيل المثال، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// يخزن قيمة إذا كانت القيمة الحالية مماثلة لقيمة `old`.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهر على أنواع [`atomic`] عبر طريقة `compare_exchange_weak` بتمرير [`Ordering::SeqCst`] باعتباره `success` و [`Ordering::Acquire`] كمعلمات `failure`.
    /// على سبيل المثال، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// يخزن قيمة إذا كانت القيمة الحالية مماثلة لقيمة `old`.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `compare_exchange_weak` بتمرير [`Ordering::Acquire`] باعتباره `success` و [`Ordering::Relaxed`] كمعلمات `failure`.
    /// على سبيل المثال، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// يخزن قيمة إذا كانت القيمة الحالية مماثلة لقيمة `old`.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهر على أنواع [`atomic`] عبر طريقة `compare_exchange_weak` بتمرير [`Ordering::AcqRel`] باعتباره `success` و [`Ordering::Relaxed`] كمعلمات `failure`.
    /// على سبيل المثال، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// يقوم بتحميل القيمة الحالية للمؤشر.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `load` بتمرير [`Ordering::SeqCst`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// يقوم بتحميل القيمة الحالية للمؤشر.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `load` بتمرير [`Ordering::Acquire`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// يقوم بتحميل القيمة الحالية للمؤشر.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `load` بتمرير [`Ordering::Relaxed`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// يخزن القيمة في موقع الذاكرة المحدد.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `store` بتمرير [`Ordering::SeqCst`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// يخزن القيمة في موقع الذاكرة المحدد.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `store` بتمرير [`Ordering::Release`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// يخزن القيمة في موقع الذاكرة المحدد.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `store` بتمرير [`Ordering::Relaxed`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// يخزن القيمة في موقع الذاكرة المحدد ، ويعيد القيمة القديمة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `swap` بتمرير [`Ordering::SeqCst`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// يخزن القيمة في موقع الذاكرة المحدد ، ويعيد القيمة القديمة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `swap` بتمرير [`Ordering::Acquire`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// يخزن القيمة في موقع الذاكرة المحدد ، ويعيد القيمة القديمة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `swap` بتمرير [`Ordering::Release`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// يخزن القيمة في موقع الذاكرة المحدد ، ويعيد القيمة القديمة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `swap` بتمرير [`Ordering::AcqRel`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// يخزن القيمة في موقع الذاكرة المحدد ، ويعيد القيمة القديمة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `swap` بتمرير [`Ordering::Relaxed`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// يضيف إلى القيمة الحالية ، ويعيد القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_add` بتمرير [`Ordering::SeqCst`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// يضيف إلى القيمة الحالية ، ويعيد القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_add` بتمرير [`Ordering::Acquire`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// يضيف إلى القيمة الحالية ، ويعيد القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_add` بتمرير [`Ordering::Release`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// يضيف إلى القيمة الحالية ، ويعيد القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_add` بتمرير [`Ordering::AcqRel`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// يضيف إلى القيمة الحالية ، ويعيد القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_add` بتمرير [`Ordering::Relaxed`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// اطرح من القيمة الحالية ، مع إرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_sub` بتمرير [`Ordering::SeqCst`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// اطرح من القيمة الحالية ، مع إرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_sub` بتمرير [`Ordering::Acquire`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// اطرح من القيمة الحالية ، مع إرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_sub` بتمرير [`Ordering::Release`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// اطرح من القيمة الحالية ، مع إرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_sub` بتمرير [`Ordering::AcqRel`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// اطرح من القيمة الحالية ، مع إرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_sub` بتمرير [`Ordering::Relaxed`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// على مستوى البت وبالقيمة الحالية ، يتم إرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_and` بتمرير [`Ordering::SeqCst`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// على مستوى البت وبالقيمة الحالية ، يتم إرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_and` بتمرير [`Ordering::Acquire`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// على مستوى البت وبالقيمة الحالية ، يتم إرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_and` بتمرير [`Ordering::Release`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// على مستوى البت وبالقيمة الحالية ، يتم إرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_and` بتمرير [`Ordering::AcqRel`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// على مستوى البت وبالقيمة الحالية ، يتم إرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_and` بتمرير [`Ordering::Relaxed`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// على مستوى البت nand مع القيمة الحالية ، وإرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على نوع [`AtomicBool`] عبر طريقة `fetch_nand` بتمرير [`Ordering::SeqCst`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// على مستوى البت nand مع القيمة الحالية ، وإرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على نوع [`AtomicBool`] عبر طريقة `fetch_nand` بتمرير [`Ordering::Acquire`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// على مستوى البت nand مع القيمة الحالية ، وإرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على نوع [`AtomicBool`] عبر طريقة `fetch_nand` بتمرير [`Ordering::Release`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// على مستوى البت nand مع القيمة الحالية ، وإرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على نوع [`AtomicBool`] عبر طريقة `fetch_nand` بتمرير [`Ordering::AcqRel`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// على مستوى البت nand مع القيمة الحالية ، وإرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على نوع [`AtomicBool`] عبر طريقة `fetch_nand` بتمرير [`Ordering::Relaxed`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// على مستوى البت أو بالقيمة الحالية ، مع إرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_or` بتمرير [`Ordering::SeqCst`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// على مستوى البت أو بالقيمة الحالية ، مع إرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_or` بتمرير [`Ordering::Acquire`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// على مستوى البت أو بالقيمة الحالية ، مع إرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_or` بتمرير [`Ordering::Release`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// على مستوى البت أو بالقيمة الحالية ، مع إرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_or` بتمرير [`Ordering::AcqRel`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// على مستوى البت أو بالقيمة الحالية ، مع إرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_or` بتمرير [`Ordering::Relaxed`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor بالقيمة الحالية ، مع إرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_xor` بتمرير [`Ordering::SeqCst`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor بالقيمة الحالية ، مع إرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_xor` بتمرير [`Ordering::Acquire`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor بالقيمة الحالية ، مع إرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_xor` بتمرير [`Ordering::Release`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor بالقيمة الحالية ، مع إرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_xor` بتمرير [`Ordering::AcqRel`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor بالقيمة الحالية ، مع إرجاع القيمة السابقة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع [`atomic`] عبر طريقة `fetch_xor` بتمرير [`Ordering::Relaxed`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// الحد الأقصى مع القيمة الحالية باستخدام مقارنة موقعة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع الأعداد الصحيحة الموقعة [`atomic`] عبر طريقة `fetch_max` بتمرير [`Ordering::SeqCst`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// الحد الأقصى مع القيمة الحالية باستخدام مقارنة موقعة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع الأعداد الصحيحة الموقعة [`atomic`] عبر طريقة `fetch_max` بتمرير [`Ordering::Acquire`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// الحد الأقصى مع القيمة الحالية باستخدام مقارنة موقعة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع الأعداد الصحيحة الموقعة [`atomic`] عبر طريقة `fetch_max` بتمرير [`Ordering::Release`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// الحد الأقصى مع القيمة الحالية باستخدام مقارنة موقعة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع الأعداد الصحيحة الموقعة [`atomic`] عبر طريقة `fetch_max` بتمرير [`Ordering::AcqRel`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// الحد الأقصى مع القيمة الحالية.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع الأعداد الصحيحة الموقعة [`atomic`] عبر طريقة `fetch_max` بتمرير [`Ordering::Relaxed`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// الحد الأدنى للقيمة الحالية باستخدام مقارنة موقعة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع الأعداد الصحيحة الموقعة [`atomic`] عبر طريقة `fetch_min` بتمرير [`Ordering::SeqCst`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// الحد الأدنى للقيمة الحالية باستخدام مقارنة موقعة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع الأعداد الصحيحة الموقعة [`atomic`] عبر طريقة `fetch_min` بتمرير [`Ordering::Acquire`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// الحد الأدنى للقيمة الحالية باستخدام مقارنة موقعة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع الأعداد الصحيحة الموقعة [`atomic`] عبر طريقة `fetch_min` بتمرير [`Ordering::Release`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// الحد الأدنى للقيمة الحالية باستخدام مقارنة موقعة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع الأعداد الصحيحة الموقعة [`atomic`] عبر طريقة `fetch_min` بتمرير [`Ordering::AcqRel`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// الحد الأدنى للقيمة الحالية باستخدام مقارنة موقعة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع الأعداد الصحيحة الموقعة [`atomic`] عبر طريقة `fetch_min` بتمرير [`Ordering::Relaxed`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// الحد الأدنى للقيمة الحالية باستخدام مقارنة غير موقعة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع الأعداد الصحيحة غير الموقعة [`atomic`] عبر طريقة `fetch_min` بتمرير [`Ordering::SeqCst`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// الحد الأدنى للقيمة الحالية باستخدام مقارنة غير موقعة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع الأعداد الصحيحة غير الموقعة [`atomic`] عبر طريقة `fetch_min` بتمرير [`Ordering::Acquire`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// الحد الأدنى للقيمة الحالية باستخدام مقارنة غير موقعة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع الأعداد الصحيحة غير الموقعة [`atomic`] عبر طريقة `fetch_min` بتمرير [`Ordering::Release`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// الحد الأدنى للقيمة الحالية باستخدام مقارنة غير موقعة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع الأعداد الصحيحة غير الموقعة [`atomic`] عبر طريقة `fetch_min` بتمرير [`Ordering::AcqRel`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// الحد الأدنى للقيمة الحالية باستخدام مقارنة غير موقعة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع الأعداد الصحيحة غير الموقعة [`atomic`] عبر طريقة `fetch_min` بتمرير [`Ordering::Relaxed`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// الحد الأقصى للقيمة الحالية باستخدام مقارنة غير موقعة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع الأعداد الصحيحة غير الموقعة [`atomic`] عبر طريقة `fetch_max` بتمرير [`Ordering::SeqCst`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// الحد الأقصى للقيمة الحالية باستخدام مقارنة غير موقعة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع الأعداد الصحيحة غير الموقعة [`atomic`] عبر طريقة `fetch_max` بتمرير [`Ordering::Acquire`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// الحد الأقصى للقيمة الحالية باستخدام مقارنة غير موقعة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع الأعداد الصحيحة غير الموقعة [`atomic`] عبر طريقة `fetch_max` بتمرير [`Ordering::Release`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// الحد الأقصى للقيمة الحالية باستخدام مقارنة غير موقعة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع الأعداد الصحيحة غير الموقعة [`atomic`] عبر طريقة `fetch_max` بتمرير [`Ordering::AcqRel`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// الحد الأقصى للقيمة الحالية باستخدام مقارنة غير موقعة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري على أنواع الأعداد الصحيحة غير الموقعة [`atomic`] عبر طريقة `fetch_max` بتمرير [`Ordering::Relaxed`] باعتباره `order`.
    /// على سبيل المثال، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// يعد `prefetch` مضمنًا تلميحًا لمولد الشفرة لإدراج تعليمات الجلب المسبق إذا كانت مدعومة ؛خلاف ذلك ، هو no-op.
    /// ليس للإعدادات المسبقة أي تأثير على سلوك البرنامج ولكن يمكنها تغيير خصائص أدائه.
    ///
    /// يجب أن تكون الوسيطة `locality` عددًا صحيحًا ثابتًا وأن تكون محدد منطقة زمنية تتراوح من (0) ، بدون منطقة محلية ، إلى (3) ، يتم الاحتفاظ بها محليًا للغاية في ذاكرة التخزين المؤقت.
    ///
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// يعد `prefetch` مضمنًا تلميحًا لمولد الشفرة لإدراج تعليمات الجلب المسبق إذا كانت مدعومة ؛خلاف ذلك ، هو no-op.
    /// ليس للإعدادات المسبقة أي تأثير على سلوك البرنامج ولكن يمكنها تغيير خصائص أدائه.
    ///
    /// يجب أن تكون الوسيطة `locality` عددًا صحيحًا ثابتًا وأن تكون محدد منطقة زمنية تتراوح من (0) ، بدون منطقة محلية ، إلى (3) ، يتم الاحتفاظ بها محليًا للغاية في ذاكرة التخزين المؤقت.
    ///
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// يعد `prefetch` مضمنًا تلميحًا لمولد الشفرة لإدراج تعليمات الجلب المسبق إذا كانت مدعومة ؛خلاف ذلك ، هو no-op.
    /// ليس للإعدادات المسبقة أي تأثير على سلوك البرنامج ولكن يمكنها تغيير خصائص أدائه.
    ///
    /// يجب أن تكون الوسيطة `locality` عددًا صحيحًا ثابتًا وأن تكون محدد منطقة زمنية تتراوح من (0) ، بدون منطقة محلية ، إلى (3) ، يتم الاحتفاظ بها محليًا للغاية في ذاكرة التخزين المؤقت.
    ///
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// يعد `prefetch` مضمنًا تلميحًا لمولد الشفرة لإدراج تعليمات الجلب المسبق إذا كانت مدعومة ؛خلاف ذلك ، هو no-op.
    /// ليس للإعدادات المسبقة أي تأثير على سلوك البرنامج ولكن يمكنها تغيير خصائص أدائه.
    ///
    /// يجب أن تكون الوسيطة `locality` عددًا صحيحًا ثابتًا وأن تكون محدد منطقة زمنية تتراوح من (0) ، بدون منطقة محلية ، إلى (3) ، يتم الاحتفاظ بها محليًا للغاية في ذاكرة التخزين المؤقت.
    ///
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// سياج ذري.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري في [`atomic::fence`] عن طريق تمرير [`Ordering::SeqCst`] باعتباره `order`.
    ///
    ///
    pub fn atomic_fence();
    /// سياج ذري.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري في [`atomic::fence`] عن طريق تمرير [`Ordering::Acquire`] باعتباره `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// سياج ذري.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري في [`atomic::fence`] عن طريق تمرير [`Ordering::Release`] باعتباره `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// سياج ذري.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري في [`atomic::fence`] عن طريق تمرير [`Ordering::AcqRel`] باعتباره `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// حاجز ذاكرة للمترجم فقط.
    ///
    /// لن يتم إعادة ترتيب عمليات الوصول إلى الذاكرة عبر هذا الحاجز من قبل المترجم ، ولكن لن يتم إصدار أي تعليمات لذلك.
    /// هذا مناسب للعمليات على نفس الخيط الذي قد يتم استباقه ، مثل عند التفاعل مع معالجات الإشارة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري في [`atomic::compiler_fence`] عن طريق تمرير [`Ordering::SeqCst`] باعتباره `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// حاجز ذاكرة للمترجم فقط.
    ///
    /// لن يتم إعادة ترتيب عمليات الوصول إلى الذاكرة عبر هذا الحاجز من قبل المترجم ، ولكن لن يتم إصدار أي تعليمات لذلك.
    /// هذا مناسب للعمليات على نفس الخيط الذي قد يتم استباقه ، مثل عند التفاعل مع معالجات الإشارة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري في [`atomic::compiler_fence`] عن طريق تمرير [`Ordering::Acquire`] باعتباره `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// حاجز ذاكرة للمترجم فقط.
    ///
    /// لن يتم إعادة ترتيب عمليات الوصول إلى الذاكرة عبر هذا الحاجز من قبل المترجم ، ولكن لن يتم إصدار أي تعليمات لذلك.
    /// هذا مناسب للعمليات على نفس الخيط الذي قد يتم استباقه ، مثل عند التفاعل مع معالجات الإشارة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري في [`atomic::compiler_fence`] عن طريق تمرير [`Ordering::Release`] باعتباره `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// حاجز ذاكرة للمترجم فقط.
    ///
    /// لن يتم إعادة ترتيب عمليات الوصول إلى الذاكرة عبر هذا الحاجز من قبل المترجم ، ولكن لن يتم إصدار أي تعليمات لذلك.
    /// هذا مناسب للعمليات على نفس الخيط الذي قد يتم استباقه ، مثل عند التفاعل مع معالجات الإشارة.
    ///
    /// يتوفر الإصدار المستقر من هذا الجوهري في [`atomic::compiler_fence`] عن طريق تمرير [`Ordering::AcqRel`] باعتباره `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// السحر الجوهري الذي يستمد معناه من السمات المرتبطة بالوظيفة.
    ///
    /// على سبيل المثال ، يستخدم تدفق البيانات هذا لإدخال تأكيدات ثابتة بحيث يقوم `rustc_peek(potentially_uninitialized)` بالفعل بالتحقق مرة أخرى من أن تدفق البيانات قد قام بالفعل بحساب أنه غير مهيأ في تلك النقطة في تدفق التحكم.
    ///
    ///
    /// لا ينبغي استخدام هذا الجوهر خارج المترجم.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// يحبط تنفيذ العملية.
    ///
    /// إصدار أكثر سهولة وثباتًا من هذه العملية هو [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// يُعلم المُحسِّن أن هذه النقطة في الكود لا يمكن الوصول إليها ، مما يتيح مزيدًا من التحسينات.
    ///
    /// ملحوظة: هذا مختلف تمامًا عن ماكرو `unreachable!()`: على عكس الماكرو ، الذي panics عند تنفيذه ، فإنه *سلوك غير محدد* للوصول إلى رمز مميز بهذه الوظيفة.
    ///
    ///
    /// النسخة المستقرة من هذا الجوهر هي [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// يُعلم المُحسِّن أن الشرط صحيح دائمًا.
    /// إذا كانت الحالة خاطئة ، يكون السلوك غير محدد.
    ///
    /// لم يتم إنشاء أي رمز لهذا الجوهر ، ولكن المحسن سيحاول الحفاظ عليه (وحالته) بين التمريرات ، مما قد يتداخل مع تحسين الكود المحيط ويقلل من الأداء.
    /// لا ينبغي استخدامه إذا كان من الممكن اكتشاف الثابت بواسطة المُحسِّن بمفرده ، أو إذا لم يُفعِّل أي تحسينات مهمة.
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// تلميحات للمترجم أن شرط branch من المحتمل أن يكون صحيحًا.
    /// إرجاع القيمة التي تم تمريرها إليها.
    ///
    /// من المحتمل ألا يكون لأي استخدام بخلاف عبارات `if` أي تأثير.
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// تلميحات للمترجم أن شرط branch من المحتمل أن يكون خاطئًا.
    /// إرجاع القيمة التي تم تمريرها إليها.
    ///
    /// من المحتمل ألا يكون لأي استخدام بخلاف عبارات `if` أي تأثير.
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// ينفذ فخ نقطة توقف للفحص بواسطة مصحح أخطاء.
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    pub fn breakpoint();

    /// حجم النوع بالبايت.
    ///
    /// وبشكل أكثر تحديدًا ، هذا هو الإزاحة بالبايت بين العناصر المتتالية من نفس النوع ، بما في ذلك مساحة المحاذاة.
    ///
    ///
    /// النسخة المستقرة من هذا الجوهر هي [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// الحد الأدنى من محاذاة النوع.
    ///
    /// النسخة المستقرة من هذا الجوهر هي [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// المحاذاة المفضلة للنوع.
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// حجم القيمة المرجعية بالبايت.
    ///
    /// النسخة المستقرة من هذا الجوهر هي [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// المحاذاة المطلوبة للقيمة المرجعية.
    ///
    /// النسخة المستقرة من هذا الجوهر هي [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// يحصل على شريحة سلسلة ثابتة تحتوي على اسم النوع.
    ///
    /// النسخة المستقرة من هذا الجوهر هي [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// يحصل على معرف فريد عالميًا للنوع المحدد.
    /// ستُرجع هذه الوظيفة نفس القيمة لأي نوع بغض النظر عن crate التي يتم استدعاءها فيه.
    ///
    ///
    /// النسخة المستقرة من هذا الجوهر هي [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// حارس للوظائف غير الآمنة التي لا يمكن تنفيذها على الإطلاق إذا كان `T` غير مأهول:
    /// سيؤدي هذا بشكل ثابت إما إلى panic ، أو لا يفعل شيئًا.
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// حارس للوظائف غير الآمنة التي لا يمكن تنفيذها على الإطلاق إذا كان `T` لا يسمح بالتهيئة الصفرية: سيؤدي هذا بشكل ثابت إما إلى panic ، أو لا يفعل شيئًا.
    ///
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    pub fn assert_zero_valid<T>();

    /// حارس للوظائف غير الآمنة التي لا يمكن تنفيذها على الإطلاق إذا كان `T` به أنماط بت غير صالحة: هذا إما panic بشكل ثابت ، أو لا يفعل شيئًا.
    ///
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    pub fn assert_uninit_valid<T>();

    /// الحصول على مرجع إلى `Location` ثابت يشير إلى مكان استدعائه.
    ///
    /// ضع في اعتبارك استخدام [`core::panic::Location::caller`](crate::panic::Location::caller) بدلاً من ذلك.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// ينقل قيمة خارج النطاق بدون تشغيل الغراء المسقط.
    ///
    /// هذا موجود فقط لـ [`mem::forget_unsized`]؛يستخدم `forget` العادي `ManuallyDrop` بدلاً من ذلك.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// يعيد تفسير بتات قيمة نوع ما كنوع آخر.
    ///
    /// كلا النوعين يجب أن يكون لهما نفس الحجم.
    /// قد لا تكون النسخة الأصلية ولا النتيجة هي [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` يكافئ من الناحية اللغوية حركة بت من نوع إلى آخر.يقوم بنسخ وحدات البت من القيمة المصدر إلى القيمة الوجهة ، ثم ينسى الأصل.
    /// إنه يعادل C's `memcpy` تحت الغطاء ، تمامًا مثل `transmute_copy`.
    ///
    /// نظرًا لأن `transmute` هي عملية حسب القيمة ، فإن محاذاة *القيم المحولة نفسها* ليست مصدر قلق.
    /// كما هو الحال مع أي وظيفة أخرى ، يضمن المترجم بالفعل محاذاة كل من `T` و `U` بشكل صحيح.
    /// ومع ذلك ، عند تحويل القيم التي *تشير إلى مكان آخر*(مثل المؤشرات والمراجع والمربعات ...) ، يجب على المتصل ضمان المحاذاة الصحيحة للقيم المشار إليها.
    ///
    /// `transmute` غير آمن **بشكل لا يصدق**.هناك عدد كبير من الطرق لإحداث [undefined behavior][ub] بهذه الوظيفة.يجب أن يكون `transmute` هو الملاذ الأخير المطلق.
    ///
    /// يحتوي [nomicon](../../nomicon/transmutes.html) على وثائق إضافية.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// هناك بعض الأشياء التي يعد `transmute` مفيدة حقًا لها.
    ///
    /// تحويل المؤشر إلى مؤشر دالة.هذا *ليس* محمولًا للآلات حيث يكون للمؤشرات الوظيفية ومؤشرات البيانات أحجام مختلفة.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// إطالة العمر أو تقصير العمر الثابت.هذا هو Rust متقدم وغير آمن للغاية!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// لا تيأس: يمكن تحقيق العديد من استخدامات `transmute` من خلال وسائل أخرى.
    /// فيما يلي التطبيقات الشائعة لـ `transmute` والتي يمكن استبدالها بتركيبات أكثر أمانًا.
    ///
    /// تحويل bytes(`&[u8]`) الخام إلى `u32` ، `f64` ، إلخ:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // استخدم `u32::from_ne_bytes` بدلاً من ذلك
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // أو استخدم `u32::from_le_bytes` أو `u32::from_be_bytes` لتحديد قيمة النهاية
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// تحويل المؤشر إلى `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // استخدم قالب `as` بدلاً من ذلك
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// تحويل `*mut T` إلى `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // استخدم إعادة الاستعارة بدلاً من ذلك
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// تحويل `&mut T` إلى `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // الآن ، ضع `as` معًا وإعادة الاقتراض ، لاحظ أن تسلسل `as` `as` ليس متعدٍ
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// تحويل `&str` إلى `&[u8]`:
    ///
    /// ```
    /// // هذه ليست طريقة جيدة للقيام بذلك.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // يمكنك استخدام `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // أو استخدم سلسلة بايت فقط ، إذا كنت تتحكم في السلسلة الحرفية
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// تحويل `Vec<&T>` إلى `Vec<Option<&T>>`.
    ///
    /// لتحويل النوع الداخلي لمحتويات الحاوية ، يجب عليك التأكد من عدم انتهاك أي من ثوابت الحاوية.
    /// بالنسبة إلى `Vec` ، هذا يعني أنه يجب أن يتطابق الحجم *والمحاذاة* للأنواع الداخلية.
    /// قد تعتمد الحاويات الأخرى على حجم النوع أو المحاذاة أو حتى `TypeId` ، وفي هذه الحالة لن يكون النقل ممكنًا على الإطلاق دون انتهاك ثوابت الحاوية.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // استنساخ vector حيث سنعيد استخدامها لاحقًا
    /// let v_clone = v_orig.clone();
    ///
    /// // استخدام التحويل: يعتمد هذا على تخطيط البيانات غير المحدد لـ `Vec` ، وهي فكرة سيئة ويمكن أن تسبب سلوكًا غير محدد.
    /////
    /// // ومع ذلك ، فهو ليس نسخة.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // هذه هي الطريقة الآمنة المقترحة.
    /// // إنه ينسخ vector بالكامل ، رغم ذلك ، في مصفوفة جديدة.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // هذه هي الطريقة الصحيحة لعدم النسخ وغير الآمنة لـ "transmuting" a `Vec` ، دون الاعتماد على تخطيط البيانات.
    /// // بدلاً من استدعاء `transmute` حرفيًا ، نقوم بإجراء قالب المؤشر ، ولكن من حيث تحويل النوع الداخلي الأصلي (`&i32`) إلى النوع الجديد (`Option<&i32>`) ، فإن هذا له نفس التحذيرات.
    /////
    /// // إلى جانب المعلومات الواردة أعلاه ، راجع أيضًا وثائق [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME قم بتحديث هذا عند استقرار vec_into_raw_parts.
    ///     // تأكد من عدم إسقاط vector الأصلي.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// تنفيذ `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // هناك طرق متعددة للقيام بذلك ، وهناك العديد من المشاكل مع طريقة (transmute) التالية.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // أولاً: التحويل ليس من النوع الآمن ؛كل ما يتحقق هو أن T و
    ///         // U من نفس الحجم.
    ///         // ثانيًا ، هنا ، لديك مرجعين قابلين للتغيير يشيران إلى نفس الذاكرة.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // هذا يتخلص من مشاكل سلامة النوع ؛`&mut *`* فقط *يمنحك `&mut T` من `&mut T` أو `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // ومع ذلك ، لا يزال لديك مرجعين قابلين للتغيير يشيران إلى نفس الذاكرة.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // هذه هي الطريقة التي تقوم بها المكتبة القياسية.
    /// // هذه هي أفضل طريقة ، إذا كنت تريد أن تفعل شيئًا كهذا
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // يحتوي هذا الآن على ثلاثة مراجع قابلة للتغيير تشير إلى نفس الذاكرة.`slice` و rvalue ret.0 و rvalue ret.1.
    ///         // `slice` لا يتم استخدامه أبدًا بعد `let ptr = ...` ، وبالتالي يمكن التعامل معه على أنه "dead" ، وبالتالي ، لديك شريحتان حقيقيتان قابلتان للتغيير.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: في حين أن هذا يجعل الثابت الجوهري مستقرًا ، لدينا بعض التعليمات البرمجية المخصصة في const fn
    // الشيكات التي تمنع استخدامه داخل `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// تُرجع `true` إذا كان النوع الفعلي المعطى كـ `T` يتطلب إسقاط الغراء ؛تقوم بإرجاع `false` إذا كان النوع الفعلي المقدم لـ `T` يطبق `Copy`.
    ///
    ///
    /// إذا كان النوع الفعلي لا يتطلب إسقاط الغراء ولا يطبق `Copy` ، فإن القيمة المرجعة لهذه الوظيفة غير محددة.
    ///
    /// النسخة المستقرة من هذا الجوهر هي [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// تحسب الإزاحة من المؤشر.
    ///
    /// يتم تنفيذ هذا كإجراء جوهري لتجنب التحويل من وإلى عدد صحيح ، حيث أن التحويل سوف يتخلص من معلومات الاسم المستعار.
    ///
    /// # Safety
    ///
    /// يجب أن يكون كل من مؤشر البداية والناتج إما في حدود أو ببايت واحد بعد نهاية الكائن المخصص.
    /// إذا كان أي من المؤشر خارج الحدود أو حدث تجاوز حسابي ، فإن أي استخدام آخر للقيمة التي تم إرجاعها سيؤدي إلى سلوك غير محدد.
    ///
    ///
    /// النسخة المستقرة من هذا الجوهر هي [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// تحسب الإزاحة من مؤشر ، ومن المحتمل أن تلتف.
    ///
    /// يتم تنفيذ هذا كإجراء جوهري لتجنب التحويل من وإلى عدد صحيح ، لأن التحويل يمنع بعض التحسينات.
    ///
    /// # Safety
    ///
    /// على عكس `offset` الجوهري ، لا يقيد هذا الجوهري المؤشر الناتج للإشارة إلى أو بايت واحد بعد نهاية كائن مخصص ، ويلتف بحساب مكمل اثنين.
    /// القيمة الناتجة ليست بالضرورة صالحة لاستخدامها للوصول إلى الذاكرة بالفعل.
    ///
    /// النسخة المستقرة من هذا الجوهر هي [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// ما يعادل `llvm.memcpy.p0i8.0i8.*` جوهريًا مناسبًا ، بحجم `count`*`size_of::<T>()` ومحاذاة
    ///
    /// `min_align_of::<T>()`
    ///
    /// تم تعيين المعلمة المتغيرة على `true` ، لذلك لن يتم تحسينها ما لم يكن الحجم مساويًا للصفر.
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// أي ما يعادل `llvm.memmove.p0i8.0i8.*` جوهريًا مناسبًا ، بحجم `count* size_of::<T>()` ومحاذاة
    ///
    /// `min_align_of::<T>()`
    ///
    /// تم تعيين المعلمة المتغيرة على `true` ، لذلك لن يتم تحسينها ما لم يكن الحجم مساويًا للصفر.
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// أي ما يعادل `llvm.memset.p0i8.*` الجوهري المناسب ، بحجم `count* size_of::<T>()` ومحاذاة `min_align_of::<T>()`.
    ///
    ///
    /// تم تعيين المعلمة المتغيرة على `true` ، لذلك لن يتم تحسينها ما لم يكن الحجم مساويًا للصفر.
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// يقوم بحمل متغير من مؤشر `src`.
    ///
    /// النسخة المستقرة من هذا الجوهر هي [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// يقوم بتخزين متغير لمؤشر `dst`.
    ///
    /// النسخة المستقرة من هذا الجوهر هي [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// يقوم بحمل متغير من مؤشر `src` لا يلزم محاذاة المؤشر.
    ///
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// يقوم بتخزين متغير لمؤشر `dst`.
    /// المؤشر غير مطلوب للمحاذاة.
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// إرجاع الجذر التربيعي لـ `f32`
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// إرجاع الجذر التربيعي لـ `f64`
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// ترفع `f32` إلى قوة عدد صحيح.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// ترفع `f64` إلى قوة عدد صحيح.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// تُرجع جيب الزاوية لـ `f32`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// تُرجع جيب الزاوية لـ `f64`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// إرجاع جيب التمام لـ `f32`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// إرجاع جيب التمام لـ `f64`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// ترفع `f32` إلى قوة `f32`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// ترفع `f64` إلى قوة `f64`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// ترجع الأسي لـ `f32`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// ترجع الأسي لـ `f64`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// ترجع 2 مرفوعة إلى قوة `f32`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// ترجع 2 مرفوعة إلى قوة `f64`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// تُرجع اللوغاريتم الطبيعي لـ `f32`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// تُرجع اللوغاريتم الطبيعي لـ `f64`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// تُرجع اللوغاريتم الأساسي 10 لـ `f32`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// تُرجع اللوغاريتم الأساسي 10 لـ `f64`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// تُرجع اللوغاريتم الأساسي 2 لـ `f32`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// تُرجع اللوغاريتم الأساسي 2 لـ `f64`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// تُرجع `a * b + c` لقيم `f32`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// تُرجع `a * b + c` لقيم `f64`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// تُرجع القيمة المطلقة لـ `f32`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// تُرجع القيمة المطلقة لـ `f64`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// تُرجع الحد الأدنى من قيمتي `f32`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// تُرجع الحد الأدنى من قيمتي `f64`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// تُرجع الحد الأقصى لقيمتي `f32`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// تُرجع الحد الأقصى لقيمتي `f64`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// ينسخ العلامة من `y` إلى `x` لقيم `f32`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// ينسخ العلامة من `y` إلى `x` لقيم `f64`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// تُرجع أكبر عدد صحيح أصغر من أو يساوي `f32`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// تُرجع أكبر عدد صحيح أصغر من أو يساوي `f64`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// تُرجع أصغر عدد صحيح أكبر من أو يساوي `f32`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// تُرجع أصغر عدد صحيح أكبر من أو يساوي `f64`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// إرجاع الجزء الصحيح من `f32`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// إرجاع الجزء الصحيح من `f64`.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// إرجاع أقرب عدد صحيح إلى `f32`.
    /// قد تثير استثناء فاصلة عائمة غير دقيق إذا لم تكن الوسيطة عددًا صحيحًا.
    pub fn rintf32(x: f32) -> f32;
    /// إرجاع أقرب عدد صحيح إلى `f64`.
    /// قد تثير استثناء فاصلة عائمة غير دقيق إذا لم تكن الوسيطة عددًا صحيحًا.
    pub fn rintf64(x: f64) -> f64;

    /// إرجاع أقرب عدد صحيح إلى `f32`.
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    pub fn nearbyintf32(x: f32) -> f32;
    /// إرجاع أقرب عدد صحيح إلى `f64`.
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    pub fn nearbyintf64(x: f64) -> f64;

    /// إرجاع أقرب عدد صحيح إلى `f32`.تقريب حالات نصف الطريق بعيدًا عن الصفر.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// إرجاع أقرب عدد صحيح إلى `f64`.تقريب حالات نصف الطريق بعيدًا عن الصفر.
    ///
    /// النسخة المستقرة من هذا الجوهر
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// إضافة عائمة تسمح بالتحسينات على أساس القواعد الجبرية.
    /// قد يفترض أن المدخلات محدودة.
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// الطرح العائم الذي يسمح بالتحسينات بناءً على القواعد الجبرية.
    /// قد يفترض أن المدخلات محدودة.
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// الضرب العائم الذي يسمح بالتحسينات بناءً على القواعد الجبرية.
    /// قد يفترض أن المدخلات محدودة.
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// القسمة العائمة التي تسمح بالتحسينات على أساس القواعد الجبرية.
    /// قد يفترض أن المدخلات محدودة.
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// عائم الباقي الذي يسمح بالتحسينات على أساس القواعد الجبرية.
    /// قد يفترض أن المدخلات محدودة.
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// قم بالتحويل باستخدام fptoui/fptosi الخاص بـ LLVM ، والذي قد يُرجع قيمة undef للقيم خارج النطاق
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// مستقر كـ [`f32::to_int_unchecked`] و [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// تُرجع عدد وحدات البت المعينة في نوع عدد صحيح `T`
    ///
    /// تتوفر الإصدارات المستقرة من هذا الجوهر على الأعداد الصحيحة الأولية عبر طريقة `count_ones`.
    /// على سبيل المثال،
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// تُرجع عدد وحدات البت (zeroes) التي لم يتم ضبطها أولاً في نوع عدد صحيح `T`.
    ///
    /// تتوفر الإصدارات المستقرة من هذا الجوهر على الأعداد الصحيحة الأولية عبر طريقة `leading_zeros`.
    /// على سبيل المثال،
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// سيعود `x` بقيمة `0` إلى عرض البت لـ `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// مثل `ctlz` ، ولكنه غير آمن للغاية لأنه يُرجع `undef` عند إعطائه `x` بقيمة `0`.
    ///
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// إرجاع عدد وحدات البت الزائدة غير المحددة (zeroes) في نوع عدد صحيح `T`.
    ///
    /// تتوفر الإصدارات المستقرة من هذا الجوهر على الأعداد الصحيحة الأولية عبر طريقة `trailing_zeros`.
    /// على سبيل المثال،
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// سيعود `x` بالقيمة `0` عرض البت لـ `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// مثل `cttz` ، ولكنه غير آمن للغاية لأنه يُرجع `undef` عند إعطائه `x` بقيمة `0`.
    ///
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// يعكس البايت في عدد صحيح من النوع `T`.
    ///
    /// تتوفر الإصدارات المستقرة من هذا الجوهر على الأعداد الصحيحة الأولية عبر طريقة `swap_bytes`.
    /// على سبيل المثال،
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// يعكس البتات في عدد صحيح من النوع `T`.
    ///
    /// تتوفر الإصدارات المستقرة من هذا الجوهر على الأعداد الصحيحة الأولية عبر طريقة `reverse_bits`.
    /// على سبيل المثال،
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// يقوم بجمع عدد صحيح تم التحقق منه.
    ///
    /// تتوفر الإصدارات المستقرة من هذا الجوهر على الأعداد الصحيحة الأولية عبر طريقة `overflowing_add`.
    /// على سبيل المثال،
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// يقوم بطرح عدد صحيح محدد
    ///
    /// تتوفر الإصدارات المستقرة من هذا الجوهر على الأعداد الصحيحة الأولية عبر طريقة `overflowing_sub`.
    /// على سبيل المثال،
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// يقوم بضرب عدد صحيح تم التحقق منه
    ///
    /// تتوفر الإصدارات المستقرة من هذا الجوهر على الأعداد الصحيحة الأولية عبر طريقة `overflowing_mul`.
    /// على سبيل المثال،
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// يقوم بإجراء قسمة دقيقة ، مما يؤدي إلى سلوك غير معرف حيث `x % y != 0` أو `y == 0` أو `x == T::MIN && y == -1`
    ///
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// يقوم بإجراء قسمة غير محددة ، مما يؤدي إلى سلوك غير محدد حيث `y == 0` أو `x == T::MIN && y == -1`
    ///
    ///
    /// تتوفر أغلفة آمنة لهذا الجوهر على الأعداد الصحيحة الأولية عبر طريقة `checked_div`.
    /// على سبيل المثال،
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// تُرجع ما تبقى من قسمة غير محددة ، مما يؤدي إلى سلوك غير محدد عند `y == 0` أو `x == T::MIN && y == -1`
    ///
    ///
    /// تتوفر أغلفة آمنة لهذا الجوهر على الأعداد الصحيحة الأولية عبر طريقة `checked_rem`.
    /// على سبيل المثال،
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// ينفذ إزاحة لليسار غير محددة ، مما يؤدي إلى سلوك غير محدد عندما يكون `y < 0` أو `y >= N` ، حيث N هو عرض T بالبتات.
    ///
    ///
    /// تتوفر أغلفة آمنة لهذا الجوهر على الأعداد الصحيحة الأولية عبر طريقة `checked_shl`.
    /// على سبيل المثال،
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// ينفذ إزاحة لليمين غير محددة ، مما يؤدي إلى سلوك غير محدد عند `y < 0` أو `y >= N` ، حيث N هو عرض T بالبتات.
    ///
    ///
    /// تتوفر أغلفة آمنة لهذا الجوهر على الأعداد الصحيحة الأولية عبر طريقة `checked_shr`.
    /// على سبيل المثال،
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// تُرجع نتيجة إضافة غير محددة ، مما يؤدي إلى سلوك غير معرف عند `x + y > T::MAX` أو `x + y < T::MIN`.
    ///
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// تُرجع نتيجة طرح غير محدد ، مما يؤدي إلى سلوك غير محدد عند `x - y > T::MAX` أو `x - y < T::MIN`.
    ///
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// تُرجع نتيجة الضرب غير المحدد ، مما يؤدي إلى سلوك غير محدد عند `x *y > T::MAX` أو `x* y < T::MIN`.
    ///
    ///
    /// هذا الجوهر ليس له نظير مستقر.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// يؤدي استدارة لليسار.
    ///
    /// تتوفر الإصدارات المستقرة من هذا الجوهر على الأعداد الصحيحة الأولية عبر طريقة `rotate_left`.
    /// على سبيل المثال،
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// يقوم بالتناوب إلى اليمين.
    ///
    /// تتوفر الإصدارات المستقرة من هذا الجوهر على الأعداد الصحيحة الأولية عبر طريقة `rotate_right`.
    /// على سبيل المثال،
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// إرجاع (a + b) mod 2 <sup>N</sup> ، حيث N هو عرض T بالبتات.
    ///
    /// تتوفر الإصدارات المستقرة من هذا الجوهر على الأعداد الصحيحة الأولية عبر طريقة `wrapping_add`.
    /// على سبيل المثال،
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// تُرجع (أ ، ب) mod 2 <sup>N</sup> ، حيث N هو عرض T بالبتات.
    ///
    /// تتوفر الإصدارات المستقرة من هذا الجوهر على الأعداد الصحيحة الأولية عبر طريقة `wrapping_sub`.
    /// على سبيل المثال،
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// إرجاع (a * b) mod 2 <sup>N</sup> ، حيث N هو عرض T بالبتات.
    ///
    /// تتوفر الإصدارات المستقرة من هذا الجوهر على الأعداد الصحيحة الأولية عبر طريقة `wrapping_mul`.
    /// على سبيل المثال،
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// يحسب `a + b` ، التشبع في حدود رقمية.
    ///
    /// تتوفر الإصدارات المستقرة من هذا الجوهر على الأعداد الصحيحة الأولية عبر طريقة `saturating_add`.
    /// على سبيل المثال،
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// يحسب `a - b` ، التشبع في حدود رقمية.
    ///
    /// تتوفر الإصدارات المستقرة من هذا الجوهر على الأعداد الصحيحة الأولية عبر طريقة `saturating_sub`.
    /// على سبيل المثال،
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// تُرجع قيمة المميز للمتغير في 'v' ؛
    /// إذا لم يكن لدى `T` أي تمييز ، يتم إرجاع `0`.
    ///
    /// النسخة المستقرة من هذا الجوهر هي [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// تُرجع عدد المتغيرات من النوع `T` المصبوب إلى `usize` ؛
    /// إذا كان `T` لا يحتوي على متغيرات ، يتم إرجاع `0`.سيتم احتساب المتغيرات غير المأهولة.
    ///
    /// الإصدار المستقر من هذا الجوهر هو [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// بناء "try catch" الخاص بـ Rust والذي يستدعي مؤشر الوظيفة `try_fn` بمؤشر البيانات `data`.
    ///
    /// الوسيطة الثالثة هي دالة تسمى في حالة حدوث panic.
    /// تأخذ هذه الوظيفة مؤشر البيانات ومؤشرًا إلى كائن الاستثناء المحدد للهدف الذي تم التقاطه.
    ///
    /// لمزيد من المعلومات ، راجع مصدر المترجم وكذلك تنفيذ std للقبض.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// يصدر متجر `!nontemporal` وفقًا لـ LLVM (انظر مستنداتهم).
    /// ربما لن تصبح مستقرة أبدًا.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// راجع وثائق `<*const T>::offset_from` للحصول على التفاصيل.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// راجع وثائق `<*const T>::guaranteed_eq` للحصول على التفاصيل.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// راجع وثائق `<*const T>::guaranteed_ne` للحصول على التفاصيل.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// تخصيص وقت الترجمة.لا ينبغي استدعاؤه في وقت التشغيل.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// يتم تعريف بعض الوظائف هنا لأنها تم توفيرها عن طريق الخطأ في هذه الوحدة على موقع ثابت.
// انظر <https://github.com/rust-lang/rust/issues/15702>.
// (يقع `transmute` أيضًا في هذه الفئة ، ولكن لا يمكن لفه بسبب التحقق من أن `T` و `U` لهما نفس الحجم.)
//

/// للتحقق مما إذا كان `ptr` محاذيًا بشكل صحيح فيما يتعلق بـ `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// ينسخ `count * size_of::<T>()` بايت من `src` إلى `dst`.يجب ألا يتداخل المصدر والوجهة.
///
/// بالنسبة لمناطق الذاكرة التي قد تتداخل ، استخدم [`copy`] بدلاً من ذلك.
///
/// `copy_nonoverlapping` مكافئ لغويًا لـ [`memcpy`] من C ، ولكن مع تبديل ترتيب الوسيطة.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// السلوك غير محدد في حالة انتهاك أي من الشروط التالية:
///
/// * `src` يجب أن يكون [valid] لقراءات من `count * size_of::<T>()` بايت.
///
/// * `dst` يجب أن يكون [valid] لعمليات الكتابة من `count * size_of::<T>()` بايت.
///
/// * يجب محاذاة كل من `src` و `dst` بشكل صحيح.
///
/// * منطقة الذاكرة التي تبدأ من `src` بحجم `count *
///   حجم: :<T>() `يجب ألا * تتداخل البايت مع منطقة الذاكرة التي تبدأ من `dst` بنفس الحجم.
///
/// مثل [`read`] ، يقوم `copy_nonoverlapping` بإنشاء نسخة بت من `T` ، بغض النظر عما إذا كان `T` هو [`Copy`].
/// إذا لم يكن `T` هو [`Copy`] ، فإن استخدام *كلاهما* القيم في المنطقة التي تبدأ من `*src` والمنطقة التي تبدأ في `* dst` يمكن أن [violate memory safety][read-ownership].
///
///
/// لاحظ أنه حتى إذا كان الحجم المنسوخ بشكل فعال (`count * size_of: :<T>()`) تساوي `0` ، يجب أن تكون المؤشرات غير فارغة ومحاذاة بشكل صحيح.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// قم بتطبيق [`Vec::append`] يدويًا:
///
/// ```
/// use std::ptr;
///
/// /// ينقل جميع عناصر `src` إلى `dst` ، ويترك `src` فارغًا.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // تأكد من أن `dst` لديه سعة كافية لاستيعاب كل `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // يكون استدعاء الإزاحة آمنًا دائمًا لأن `Vec` لن يخصص أبدًا أكثر من `isize::MAX` بايت.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // اقتطاع `src` دون إسقاط محتوياته.
///         // نقوم بذلك أولاً ، لتجنب المشاكل في حالة حدوث شيء ما أسفل panics.
///         src.set_len(0);
///
///         // لا يمكن أن تتداخل المنطقتان لأن المراجع القابلة للتغيير لا تحمل اسمًا مستعارًا ، ولا يمكن لمجهزي vectors مختلفين امتلاك نفس الذاكرة.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // قم بإخطار `dst` بأنه يحتفظ الآن بمحتويات `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: قم بإجراء هذه الفحوصات فقط في وقت التشغيل
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // لا داعي للذعر للحفاظ على تأثير codegen أصغر.
        abort();
    }*/

    // الأمان: يجب أن يكون عقد الأمان لـ `copy_nonoverlapping`
    // أيده المتصل.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// ينسخ `count * size_of::<T>()` بايت من `src` إلى `dst`.قد يتداخل المصدر والوجهة.
///
/// إذا لم يتداخل المصدر والوجهة أبدًا ، فيمكن استخدام [`copy_nonoverlapping`] بدلاً من ذلك.
///
/// `copy` مكافئ لغويًا لـ [`memmove`] من C ، ولكن مع تبديل ترتيب الوسيطة.
/// يحدث النسخ كما لو تم نسخ البايت من `src` إلى صفيف مؤقت ثم نسخها من المصفوفة إلى `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// السلوك غير محدد في حالة انتهاك أي من الشروط التالية:
///
/// * `src` يجب أن يكون [valid] لقراءات من `count * size_of::<T>()` بايت.
///
/// * `dst` يجب أن يكون [valid] لعمليات الكتابة من `count * size_of::<T>()` بايت.
///
/// * يجب محاذاة كل من `src` و `dst` بشكل صحيح.
///
/// مثل [`read`] ، يقوم `copy` بإنشاء نسخة بت من `T` ، بغض النظر عما إذا كان `T` هو [`Copy`].
/// إذا لم يكن `T` هو [`Copy`] ، فإن استخدام كل من القيم في المنطقة التي تبدأ من `*src` والمنطقة التي تبدأ في `* dst` يمكن أن [violate memory safety][read-ownership].
///
///
/// لاحظ أنه حتى إذا كان الحجم المنسوخ بشكل فعال (`count * size_of: :<T>()`) تساوي `0` ، يجب أن تكون المؤشرات غير فارغة ومحاذاة بشكل صحيح.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// قم بإنشاء Rust vector بكفاءة من مخزن مؤقت غير آمن:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` يجب أن يكون محاذيًا بشكل صحيح لنوعه وغير صفري.
/// /// * `ptr` يجب أن تكون صالحة لقراءات العناصر المتجاورة `elts` من النوع `T`.
/// /// * يجب عدم استخدام هذه العناصر بعد استدعاء هذه الوظيفة ما لم يكن `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // الأمان: يضمن شرطنا المسبق أن يكون المصدر متوافقًا وصالحًا ،
///     // يضمن `Vec::with_capacity` أن لدينا مساحة قابلة للاستخدام لكتابتها.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // الأمان: لقد أنشأناها بهذه السعة الكبيرة في وقت سابق ،
///     // وقد قام `copy` السابق بتهيئة هذه العناصر.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: قم بإجراء هذه الفحوصات فقط في وقت التشغيل
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // لا داعي للذعر للحفاظ على تأثير codegen أصغر.
        abort();
    }*/

    // الأمان: يجب أن يتم دعم عقد الأمان الخاص بـ `copy` من قبل المتصل.
    unsafe { copy(src, dst, count) }
}

/// يضبط `count * size_of::<T>()` بايت من الذاكرة بدءًا من `dst` إلى `val`.
///
/// `write_bytes` مشابه لـ C's [`memset`] ، لكنه يحدد `count * size_of::<T>()` بايت إلى `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// السلوك غير محدد في حالة انتهاك أي من الشروط التالية:
///
/// * `dst` يجب أن يكون [valid] لعمليات الكتابة من `count * size_of::<T>()` بايت.
///
/// * `dst` يجب محاذاة بشكل صحيح.
///
/// بالإضافة إلى ذلك ، يجب على المتصل التأكد من أن كتابة `count * size_of::<T>()` بايت إلى منطقة معينة من الذاكرة ينتج عنه قيمة صالحة تبلغ `T`.
/// يعد استخدام منطقة من الذاكرة تمت كتابتها كـ `T` تحتوي على قيمة غير صالحة لـ `T` سلوكًا غير محدد.
///
/// لاحظ أنه حتى إذا كان الحجم المنسوخ بشكل فعال (`count * size_of: :<T>()`) هي `0` ، يجب أن يكون المؤشر غير فارغ ومحاذاة بشكل صحيح.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// الاستخدام الأساسي:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// إنشاء قيمة غير صالحة:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // تسريب القيمة المحتفظ بها مسبقًا عن طريق الكتابة فوق `Box<T>` بمؤشر فارغ.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // في هذه المرحلة ، يؤدي استخدام `v` أو إسقاطه إلى سلوك غير محدد.
/// // drop(v); // ERROR
///
/// // حتى تسريب `v` "uses" ، وبالتالي هو سلوك غير محدد.
/// // mem::forget(v); // ERROR
///
/// // في الواقع ، `v` غير صالح وفقًا لثوابت تخطيط النوع الأساسي ، لذلك * أي عملية تمسها هي سلوك غير محدد.
/////
/// // دع v2 =v ؛//خطأ
///
/// unsafe {
///     // دعونا بدلاً من ذلك نضع قيمة صالحة
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // الآن الصندوق على ما يرام
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // الأمان: يجب أن يتم دعم عقد الأمان الخاص بـ `write_bytes` من قبل المتصل.
    unsafe { write_bytes(dst, val, count) }
}