#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// يسمح `RawWaker` لمنفذ تنفيذ المهام بإنشاء [`Waker`] الذي يوفر سلوك تنبيه مخصص.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// يتكون من مؤشر بيانات و [virtual function pointer table (vtable)][vtable] الذي يخصص سلوك `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// مؤشر البيانات ، والذي يمكن استخدامه لتخزين البيانات التعسفية كما هو مطلوب من قبل المنفذ.
    /// يمكن أن يكون هذا على سبيل المثال
    /// مؤشر تم مسحه من النوع إلى `Arc` مقترن بالمهمة.
    /// يتم تمرير قيمة هذا الحقل إلى جميع الوظائف التي تعد جزءًا من vtable كمعامل أول.
    ///
    data: *const (),
    /// جدول مؤشر الوظيفة الافتراضية الذي يخصص سلوك هذا المستيقظ.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// ينشئ `RawWaker` جديدًا من مؤشر `data` المقدم و `vtable`.
    ///
    /// يمكن استخدام مؤشر `data` لتخزين البيانات التعسفية كما هو مطلوب من قبل المنفذ.يمكن أن يكون هذا على سبيل المثال
    /// مؤشر تم مسحه من النوع إلى `Arc` مقترن بالمهمة.
    /// سيتم تمرير قيمة هذا المؤشر إلى جميع الوظائف التي تعد جزءًا من `vtable` كمعامل أول.
    ///
    /// يقوم `vtable` بتخصيص سلوك `Waker` الذي يتم إنشاؤه من `RawWaker`.
    /// لكل عملية على `Waker` ، سيتم استدعاء الوظيفة المرتبطة في `vtable` من `RawWaker` الأساسي.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// جدول مؤشر دالة ظاهرية (vtable) يحدد سلوك [`RawWaker`].
///
/// المؤشر الذي تم تمريره إلى جميع الوظائف داخل vtable هو مؤشر `data` من كائن [`RawWaker`] المرفق.
///
/// الوظائف الموجودة داخل هذا الهيكل مخصصة فقط ليتم استدعاؤها على مؤشر `data` لكائن [`RawWaker`] تم إنشاؤه بشكل صحيح من داخل تطبيق [`RawWaker`].
/// سيؤدي استدعاء إحدى الوظائف المضمنة باستخدام أي مؤشر `data` آخر إلى حدوث سلوك غير محدد.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// سيتم استدعاء هذه الوظيفة عند استنساخ [`RawWaker`] ، على سبيل المثال عند استنساخ [`Waker`] الذي تم تخزين [`RawWaker`] فيه.
    ///
    /// يجب أن يحتفظ تنفيذ هذه الوظيفة بكافة الموارد المطلوبة لهذا المثيل الإضافي لـ [`RawWaker`] والمهمة المرتبطة.
    /// يجب أن يؤدي استدعاء `wake` على [`RawWaker`] الناتج إلى تنبيه نفس المهمة التي كان يمكن إيقاظها بواسطة [`RawWaker`] الأصلي.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// سيتم استدعاء هذه الوظيفة عندما يتم استدعاء `wake` على [`Waker`].
    /// يجب أن يستيقظ المهمة المرتبطة بهذا [`RawWaker`].
    ///
    /// يجب أن يتأكد تنفيذ هذه الوظيفة من تحرير أي موارد مرتبطة بهذا المثيل لـ [`RawWaker`] والمهمة المرتبطة به.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// سيتم استدعاء هذه الوظيفة عندما يتم استدعاء `wake_by_ref` على [`Waker`].
    /// يجب أن يستيقظ المهمة المرتبطة بهذا [`RawWaker`].
    ///
    /// تشبه هذه الوظيفة `wake` ، لكن يجب ألا تستهلك مؤشر البيانات المقدم.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// يتم استدعاء هذه الوظيفة عندما يتم إسقاط [`RawWaker`].
    ///
    /// يجب أن يتأكد تنفيذ هذه الوظيفة من تحرير أي موارد مرتبطة بهذا المثيل لـ [`RawWaker`] والمهمة المرتبطة به.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// ينشئ `RawWakerVTable` جديدًا من وظائف `clone` و `wake` و `wake_by_ref` و `drop` المتوفرة.
    ///
    /// # `clone`
    ///
    /// سيتم استدعاء هذه الوظيفة عند استنساخ [`RawWaker`] ، على سبيل المثال عند استنساخ [`Waker`] الذي تم تخزين [`RawWaker`] فيه.
    ///
    /// يجب أن يحتفظ تنفيذ هذه الوظيفة بكافة الموارد المطلوبة لهذا المثيل الإضافي لـ [`RawWaker`] والمهمة المرتبطة.
    /// يجب أن يؤدي استدعاء `wake` على [`RawWaker`] الناتج إلى تنبيه نفس المهمة التي كان يمكن إيقاظها بواسطة [`RawWaker`] الأصلي.
    ///
    /// # `wake`
    ///
    /// سيتم استدعاء هذه الوظيفة عندما يتم استدعاء `wake` على [`Waker`].
    /// يجب أن يستيقظ المهمة المرتبطة بهذا [`RawWaker`].
    ///
    /// يجب أن يتأكد تنفيذ هذه الوظيفة من تحرير أي موارد مرتبطة بهذا المثيل لـ [`RawWaker`] والمهمة المرتبطة به.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// سيتم استدعاء هذه الوظيفة عندما يتم استدعاء `wake_by_ref` على [`Waker`].
    /// يجب أن يستيقظ المهمة المرتبطة بهذا [`RawWaker`].
    ///
    /// تشبه هذه الوظيفة `wake` ، لكن يجب ألا تستهلك مؤشر البيانات المقدم.
    ///
    /// # `drop`
    ///
    /// يتم استدعاء هذه الوظيفة عندما يتم إسقاط [`RawWaker`].
    ///
    /// يجب أن يتأكد تنفيذ هذه الوظيفة من تحرير أي موارد مرتبطة بهذا المثيل لـ [`RawWaker`] والمهمة المرتبطة به.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` لمهمة غير متزامنة.
///
/// حاليًا ، يعمل `Context` فقط على توفير الوصول إلى `&Waker` الذي يمكن استخدامه لتنبيه المهمة الحالية.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // تأكد من أننا future ضد تغييرات التباين من خلال إجبار العمر على أن يكون ثابتًا (تكون فترات عمر موقف الحجة متناقضة بينما تكون فترات عودة موضع الإرجاع متغيرة).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// قم بإنشاء `Context` جديد من `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// إرجاع مرجع إلى `Waker` للمهمة الحالية.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` عبارة عن مقبض لإيقاظ مهمة بإخطار المنفذ بأنها جاهزة للتشغيل.
///
/// يقوم هذا المقبض بتغليف مثيل [`RawWaker`] ، والذي يحدد سلوك التنبيه الخاص بالمنفذ.
///
///
/// ينفذ [`Clone`] و [`Send`] و [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// استيقظ على المهمة المرتبطة بهذا `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // يتم تفويض استدعاء التنبيه الفعلي من خلال استدعاء دالة ظاهرية للتنفيذ الذي يحدده المنفذ.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // لا تتصل بـ `drop`-سوف يستهلك `wake` المستيقظ.
        crate::mem::forget(self);

        // الأمان: هذا آمن لأن `Waker::from_raw` هو الطريقة الوحيدة
        // لتهيئة `wake` و `data` تتطلب من المستخدم الإقرار بأن عقد `RawWaker` مؤيد.
        //
        unsafe { (wake)(data) };
    }

    /// استيقظ على المهمة المرتبطة بهذا `Waker` دون استهلاك `Waker`.
    ///
    /// هذا مشابه لـ `wake` ، ولكنه قد يكون أقل كفاءة قليلاً في حالة توفر `Waker` المملوك.
    /// يجب تفضيل هذه الطريقة على استدعاء `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // يتم تفويض استدعاء التنبيه الفعلي من خلال استدعاء دالة ظاهرية للتنفيذ الذي يحدده المنفذ.
        //

        // الأمان: انظر `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// تُرجع `true` إذا قام `Waker` و `Waker` آخر بإيقاظ نفس المهمة.
    ///
    /// تعمل هذه الوظيفة على أساس أفضل جهد ، وقد ترجع خطأ حتى عندما يوقظ "Waker" نفس المهمة.
    /// ومع ذلك ، إذا قامت هذه الدالة بإرجاع `true` ، فمن المؤكد أن "Waker" سوف يوقظ نفس المهمة.
    ///
    /// تستخدم هذه الوظيفة بشكل أساسي لأغراض التحسين.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// ينشئ `Waker` جديدًا من [`RawWaker`].
    ///
    /// سلوك `Waker` الذي تم إرجاعه غير محدد إذا لم يتم دعم العقد المحدد في وثائق [RawWaker`] و [RawWakerVTable`].
    ///
    /// لذلك هذه الطريقة غير آمنة.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // الأمان: هذا آمن لأن `Waker::from_raw` هو الطريقة الوحيدة
            // لتهيئة `clone` و `data` تتطلب من المستخدم الإقرار بأن عقد [`RawWaker`] مؤيد.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // الأمان: هذا آمن لأن `Waker::from_raw` هو الطريقة الوحيدة
        // لتهيئة `drop` و `data` تتطلب من المستخدم الإقرار بأن عقد `RawWaker` مؤيد.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}