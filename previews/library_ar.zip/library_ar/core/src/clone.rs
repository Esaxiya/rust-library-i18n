//! `Clone` trait للأنواع التي لا يمكن "نسخها ضمنيًا".
//!
//! في Rust ، بعض الأنواع البسيطة هي "implicitly copyable" وعندما تقوم بتعيينها أو تمريرها كوسيطات ، سيحصل المتلقي على نسخة ، تاركًا القيمة الأصلية في مكانها.
//! لا تتطلب هذه الأنواع تخصيصًا للنسخ ولا تحتوي على مواد نهائية (أي أنها لا تحتوي على مربعات مملوكة أو تنفذ [`Drop`]) ، لذلك يعتبرها المترجم رخيصة وآمنة للنسخ.
//!
//! بالنسبة للأنواع الأخرى ، يجب عمل نسخ بشكل صريح ، من خلال تطبيق [`Clone`] trait واستدعاء طريقة [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! مثال على الاستخدام الأساسي:
//!
//! ```
//! let s = String::new(); // نوع السلسلة يطبق Clone
//! let copy = s.clone(); // حتى نتمكن من استنساخه
//! ```
//!
//! لتنفيذ Clone trait بسهولة ، يمكنك أيضًا استخدام `#[derive(Clone)]`.مثال:
//!
//! ```
//! #[derive(Clone)] // نضيف Clone trait إلى بنية Morpheus
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // والآن يمكننا استنساخه!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// trait مشترك للقدرة على تكرار كائن بشكل صريح.
///
/// يختلف عن [`Copy`] في أن [`Copy`] ضمني وغير مكلف للغاية ، في حين أن `Clone` دائمًا ما يكون صريحًا وقد يكون أو لا يكون مكلفًا.
/// من أجل فرض هذه الخصائص ، لا يسمح لك Rust بإعادة تنفيذ [`Copy`] ، ولكن يمكنك إعادة تطبيق `Clone` وتشغيل تعليمات برمجية عشوائية.
///
/// نظرًا لأن `Clone` أكثر عمومية من [`Copy`] ، يمكنك تلقائيًا جعل أي شيء [`Copy`] هو `Clone` أيضًا.
///
/// ## Derivable
///
/// يمكن استخدام trait مع `#[derive]` إذا كانت جميع الحقول `Clone`.يستدعي تطبيق `الاشتقاق`d لـ [`Clone`] [`clone`] في كل حقل.
///
/// [`clone`]: Clone::clone
///
/// بالنسبة للهيكل العام ، يقوم `#[derive]` بتنفيذ `Clone` بشكل مشروط عن طريق إضافة `Clone` منضم على المعلمات العامة.
///
/// ```
/// // `derive` تنفذ استنساخ للقراءة<T>عندما يكون T هو Clone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## كيف يمكنني تنفيذ `Clone`؟
///
/// يجب أن يكون للأنواع التي هي [`Copy`] تطبيق تافه لـ `Clone`.أكثر رسميا:
/// إذا كانت `T: Copy` و `x: T` و `y: &T` ، فإن `let x = y.clone();` تساوي `let x = *y;`.
/// يجب أن تكون عمليات التنفيذ اليدوية حذرة لدعم هذا الثابت ؛ومع ذلك ، يجب ألا تعتمد التعليمات البرمجية غير الآمنة عليها لضمان سلامة الذاكرة.
///
/// مثال على ذلك هو هيكل عام يحمل مؤشر وظيفة.في هذه الحالة ، لا يمكن اشتقاق تنفيذ `Clone` ، ولكن يمكن تنفيذه على النحو التالي:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## المنفذين الإضافيين
///
/// بالإضافة إلى [implementors listed below][impls] ، تستخدم الأنواع التالية أيضًا `Clone`:
///
/// * أنواع عناصر الوظائف (على سبيل المثال ، الأنواع المميزة المحددة لكل وظيفة)
/// * أنواع مؤشرات الوظائف (على سبيل المثال ، `fn() -> i32`)
/// * أنواع المصفوفات ، لجميع الأحجام ، إذا كان نوع العنصر يستخدم أيضًا `Clone` (على سبيل المثال ، `[i32; 123456]`)
/// * أنواع Tuple ، إذا كان كل مكون يستخدم أيضًا `Clone` (على سبيل المثال ، `()` ، `(i32, bool)`)
/// * أنواع الإغلاق ، إذا كانت لا تلتقط أي قيمة من البيئة أو إذا كانت جميع هذه القيم الملتقطة تطبق `Clone` نفسها.
///   لاحظ أن المتغيرات الملتقطة بواسطة المرجع المشترك تنفذ دائمًا `Clone` (حتى لو لم يكن المرجع) ، بينما المتغيرات التي تم التقاطها بواسطة المرجع المتغير لا تنفذ `Clone` أبدًا.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// ترجع نسخة من القيمة.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str تنفذ Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// ينفذ مهمة نسخ من `source`.
    ///
    /// `a.clone_from(&b)` يعادل `a = b.clone()` في الوظائف ، ولكن يمكن تجاوزه لإعادة استخدام موارد `a` لتجنب عمليات التخصيص غير الضرورية.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// اشتق الماكرو لتوليد إشارة من trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): تُستخدم هذه الهياكل فقط بواسطة#[اشتقاق] للتأكيد على أن كل مكون من نوع ما يطبق Clone أو Copy.
//
//
// يجب ألا تظهر هذه الهياكل أبدًا في كود المستخدم.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// تطبيقات `Clone` للأنواع البدائية.
///
/// يتم تنفيذ التطبيقات التي لا يمكن وصفها في Rust في `traits::SelectionContext::copy_clone_conditions()` في `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// يمكن استنساخ المراجع المشتركة ، لكن المراجع القابلة للتغيير *لا يمكن*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// يمكن استنساخ المراجع المشتركة ، لكن المراجع القابلة للتغيير *لا يمكن*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}