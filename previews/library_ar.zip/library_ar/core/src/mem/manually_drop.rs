use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// غلاف لمنع المترجم من استدعاء أداة التدمير "T" تلقائيًا.
/// هذا المجمع هو 0 التكلفة.
///
/// `ManuallyDrop<T>` يخضع لنفس التخطيط الأمثل مثل `T`.
/// نتيجة لذلك ،*ليس لها تأثير* على الافتراضات التي يضعها المترجم حول محتوياته.
/// على سبيل المثال ، تهيئة `ManuallyDrop<&mut T>` مع [`mem::zeroed`] هي سلوك غير محدد.
/// إذا كنت بحاجة إلى معالجة البيانات غير المهيأة ، فاستخدم [`MaybeUninit<T>`] بدلاً من ذلك.
///
/// لاحظ أن الوصول إلى القيمة داخل `ManuallyDrop<T>` آمن.
/// هذا يعني أنه يجب عدم كشف `ManuallyDrop<T>` الذي تم إسقاط محتواه من خلال واجهة برمجة تطبيقات آمنة عامة.
/// في المقابل ، `ManuallyDrop::drop` غير آمن.
///
/// # `ManuallyDrop` وإسقاط الطلب.
///
/// يحتوي Rust على قيم [drop order] محددة جيدًا.
/// للتأكد من إسقاط الحقول أو السكان المحليين بترتيب معين ، أعد ترتيب الإعلانات بحيث يكون ترتيب الإسقاط الضمني هو الصحيح.
///
/// من الممكن استخدام `ManuallyDrop` للتحكم في أمر الإفلات ، لكن هذا يتطلب رمزًا غير آمن ويصعب القيام به بشكل صحيح في وجود حل.
///
///
/// على سبيل المثال ، إذا كنت تريد التأكد من إسقاط حقل معين بعد الحقول الأخرى ، فاجعله الحقل الأخير في البنية:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` سيتم إسقاطها بعد `children`.
///     // يضمن Rust إسقاط الحقول بترتيب الإعلان.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// قم بلف قيمة ليتم إسقاطها يدويًا.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // لا يزال بإمكانك العمل بأمان على القيمة
    /// assert_eq!(*x, "Hello");
    /// // لكن لن يتم تشغيل `Drop` هنا
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// يستخرج القيمة من حاوية `ManuallyDrop`.
    ///
    /// هذا يسمح بإسقاط القيمة مرة أخرى.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // هذا يسقط `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// إخراج القيمة من حاوية `ManuallyDrop<T>`.
    ///
    /// تهدف هذه الطريقة بشكل أساسي إلى نقل القيم المتساقطة.
    /// بدلاً من استخدام [`ManuallyDrop::drop`] لإسقاط القيمة يدويًا ، يمكنك استخدام هذه الطريقة لأخذ القيمة واستخدامها كما تشاء.
    ///
    /// كلما أمكن ، يفضل استخدام [`into_inner`][`ManuallyDrop::into_inner`] بدلاً من ذلك ، مما يمنع تكرار محتوى `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// تقوم هذه الوظيفة بنقل القيمة المضمنة بشكل دلالي دون منع المزيد من الاستخدام ، مع ترك حالة هذه الحاوية دون تغيير.
    /// تقع على عاتقك مسؤولية التأكد من عدم استخدام `ManuallyDrop` مرة أخرى.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // الأمان: نحن نقرأ من المرجع ، وهو مضمون
        // لتكون صالحة للقراءات.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// يسقط القيمة المضمنة يدويًا.هذا يعادل تمامًا استدعاء [`ptr::drop_in_place`] بمؤشر إلى القيمة المضمنة.
    /// على هذا النحو ، ما لم تكن القيمة المضمنة عبارة عن بنية معبأة ، فسيتم استدعاء أداة التدمير في مكانها دون نقل القيمة ، وبالتالي يمكن استخدامها لإسقاط بيانات [pinned] بأمان.
    ///
    /// إذا كانت لديك ملكية القيمة ، فيمكنك استخدام [`ManuallyDrop::into_inner`] بدلاً من ذلك.
    ///
    /// # Safety
    ///
    /// تعمل هذه الوظيفة على تشغيل أداة تدمير القيمة المضمنة.
    /// بخلاف التغييرات التي تم إجراؤها بواسطة أداة التدمير نفسها ، يتم ترك الذاكرة دون تغيير ، وبقدر ما يتعلق الأمر بالمترجم لا يزال يحتفظ بنمط بت صالح للنوع `T`.
    ///
    ///
    /// ومع ذلك ، لا ينبغي تعريض قيمة "zombie" هذه إلى رمز آمن ، ويجب عدم استدعاء هذه الوظيفة أكثر من مرة.
    /// قد يؤدي استخدام قيمة بعد إسقاطها أو إسقاطها عدة مرات إلى سلوك غير محدد (اعتمادًا على ما يفعله `drop`).
    /// عادة ما يتم منع هذا بواسطة نظام النوع ، ولكن يجب على مستخدمي `ManuallyDrop` دعم هذه الضمانات دون مساعدة من المترجم.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // الأمان: نحن نسقط القيمة المشار إليها بواسطة مرجع قابل للتغيير
        // وهو مضمون لصلاحيته للكتابة.
        // الأمر متروك للمتصل للتأكد من عدم إسقاط `slot` مرة أخرى.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}