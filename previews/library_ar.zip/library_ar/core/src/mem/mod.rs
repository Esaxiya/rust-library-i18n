//! الوظائف الأساسية للتعامل مع الذاكرة.
//!
//! تحتوي هذه الوحدة على وظائف للاستعلام عن حجم الأنواع ومواءمتها ، وتهيئة الذاكرة ومعالجتها.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// يحصل على ملكية و "forgets" حول القيمة **دون تشغيل أداة التدمير**.
///
/// أي موارد تديرها القيمة ، مثل ذاكرة الكومة أو مقبض الملف ، ستبقى إلى الأبد في حالة لا يمكن الوصول إليها.ومع ذلك ، فإنه لا يضمن أن المؤشرات إلى هذه الذاكرة ستبقى صالحة.
///
/// * إذا كنت تريد تسريب الذاكرة ، فراجع [`Box::leak`].
/// * إذا كنت ترغب في الحصول على مؤشر خام للذاكرة ، فراجع [`Box::into_raw`].
/// * إذا كنت تريد التخلص من قيمة بشكل صحيح ، وتشغيل أداة التدمير الخاصة بها ، فراجع [`mem::drop`].
///
/// # Safety
///
/// `forget` لم يتم وضع علامة `unsafe` عليه ، لأن ضمانات أمان Rust لا تتضمن ضمانًا بأن المدمرات ستعمل دائمًا.
/// على سبيل المثال ، يمكن للبرنامج إنشاء دورة مرجعية باستخدام [`Rc`][rc] ، أو الاتصال بـ [`process::exit`][exit] للخروج بدون تشغيل المدمرات.
/// وبالتالي ، فإن السماح لـ `mem::forget` من التعليمات البرمجية الآمنة لا يغير بشكل أساسي ضمانات السلامة الخاصة بـ Rust.
///
/// ومع ذلك ، فإن تسريب الموارد مثل الذاكرة أو كائنات I/O عادة ما يكون غير مرغوب فيه.
/// تظهر الحاجة في بعض حالات الاستخدام المتخصصة لـ FFI أو الكود غير الآمن ، ولكن حتى ذلك الحين ، يفضل [`ManuallyDrop`] عادةً.
///
/// نظرًا لأن نسيان القيمة مسموح به ، يجب أن يسمح أي كود `unsafe` تكتبه بهذا الاحتمال.لا يمكنك إرجاع قيمة وتتوقع أن يقوم المتصل بالضرورة بتشغيل أداة تدمير القيمة.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// الاستخدام الآمن المتعارف عليه لـ `mem::forget` هو التحايل على أداة تدمير القيمة المطبقة بواسطة `Drop` trait.على سبيل المثال ، سيؤدي هذا إلى تسريب `File` ، أي
/// استعادة المساحة التي يشغلها المتغير ولكن لا تغلق مورد النظام الأساسي:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// يكون هذا مفيدًا عندما تم نقل ملكية المورد الأساسي مسبقًا إلى رمز خارج Rust ، على سبيل المثال عن طريق إرسال واصف الملف الأولي إلى كود C.
///
/// # العلاقة مع `ManuallyDrop`
///
/// بينما يمكن أيضًا استخدام `mem::forget` لنقل ملكية *الذاكرة*، فإن القيام بذلك يكون عرضة للخطأ.
/// [`ManuallyDrop`] يجب أن تستخدم بدلا من ذلك.ضع في اعتبارك ، على سبيل المثال ، هذا الرمز:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // قم ببناء `String` باستخدام محتويات `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // تسرب `v` لأن ذاكرته تدار الآن بواسطة `s`
/// mem::forget(v);  // خطأ ، v غير صالح ويجب عدم تمريره إلى دالة
/// assert_eq!(s, "Az");
/// // `s` تم إسقاطه ضمنيًا وإلغاء تخصيص ذاكرته.
/// ```
///
/// هناك مشكلتان في المثال أعلاه:
///
/// * إذا تمت إضافة المزيد من التعليمات البرمجية بين إنشاء `String` واستدعاء `mem::forget()` ، فإن panic داخلها قد يتسبب في ضعف حر لأن الذاكرة نفسها يتم التعامل معها بواسطة كل من `v` و `s`.
/// * بعد استدعاء `v.as_mut_ptr()` ونقل ملكية البيانات إلى `s` ، تكون قيمة `v` غير صالحة.
/// حتى عندما يتم نقل قيمة إلى `mem::forget` (والتي لن تفحصها) ، فإن بعض الأنواع لديها متطلبات صارمة بشأن قيمها تجعلها غير صالحة عند التعلق أو لم تعد مملوكة.
/// إن استخدام القيم غير الصالحة بأي شكل من الأشكال ، بما في ذلك تمريرها إلى الوظائف أو إعادتها إليها ، يشكل سلوكًا غير محدد وقد يكسر الافتراضات التي وضعها المترجم.
///
/// يؤدي التبديل إلى `ManuallyDrop` إلى تجنب كلتا المشكلتين:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // قبل أن نفكك `v` في أجزائه الخام ، تأكد من عدم سقوطه!
/////
/// let mut v = ManuallyDrop::new(v);
/// // الآن تفكيك `v`.هذه العمليات لا يمكن أن يكون panic ، لذلك لا يمكن أن يكون هناك تسرب.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // أخيرًا ، قم ببناء `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` تم إسقاطه ضمنيًا وإلغاء تخصيص ذاكرته.
/// ```
///
/// `ManuallyDrop` يمنع بشدة الاستخدام الخالي من المضاعفات لأننا نعطل أداة "v" التدمير قبل القيام بأي شيء آخر.
/// `mem::forget()` لا يسمح بذلك لأنه يستهلك حجته ، مما يجبرنا على الاتصال به فقط بعد استخراج أي شيء نحتاجه من `v`.
/// حتى إذا تم إدخال panic بين بناء `ManuallyDrop` وبناء السلسلة (وهو ما لا يمكن أن يحدث في الكود كما هو موضح) ، فإنه سيؤدي إلى تسرب وليس حرًا مزدوجًا.
/// بمعنى آخر ، يخطئ `ManuallyDrop` في جانب التسرب بدلاً من الخطأ في جانب السقوط (المزدوج).
///
/// أيضًا ، يمنعنا `ManuallyDrop` من الاضطرار إلى "touch" `v` بعد نقل الملكية إلى `s`-يتم تجنب الخطوة الأخيرة للتفاعل مع `v` للتخلص منه دون تشغيل أداة التدمير الخاصة به تمامًا.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// مثل [`forget`] ، ولكنه يقبل أيضًا القيم غير الحجم.
///
/// هذه الوظيفة هي مجرد رقاقة يتم إزالتها عند استقرار ميزة `unsized_locals`.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// ترجع حجم نوع بالبايت.
///
/// وبشكل أكثر تحديدًا ، هذا هو الإزاحة بالبايت بين العناصر المتتالية في مصفوفة بنوع العنصر هذا بما في ذلك مساحة المحاذاة.
///
/// وبالتالي ، بالنسبة لأي نوع `T` وطول `n` ، يكون حجم `[T; n]` `n * size_of::<T>()`.
///
/// بشكل عام ، حجم النوع غير مستقر عبر التجميعات ، لكن الأنواع المحددة مثل الأوليات تكون كذلك.
///
/// الجدول التالي يوضح حجم الأوليات.
///
/// اكتب |حجم: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 × 03 × |8 u128 |16 i8 |1 i16 |2 i32 |4 × 07 × |8 i128 |16 f32 |4 f64 |8 شار |4
///
/// علاوة على ذلك ، فإن `usize` و `isize` لهما نفس الحجم.
///
/// الأنواع `*const T` و `&T` و `Box<T>` و `Option<&T>` و `Option<Box<T>>` جميعها لها نفس الحجم.
/// إذا كان `T` بحجم ، فإن كل هذه الأنواع لها نفس حجم `usize`.
///
/// إن قابلية تغيير المؤشر لا يغير حجمه.على هذا النحو ، فإن `&T` و `&mut T` لهما نفس الحجم.
/// وبالمثل بالنسبة لـ `*const T` و `* mut T`.
///
/// # حجم العناصر `#[repr(C)]`
///
/// تمثيل `C` للعناصر له تخطيط محدد.
/// باستخدام هذا التخطيط ، يكون حجم العناصر مستقرًا أيضًا طالما أن جميع الحقول لها حجم ثابت.
///
/// ## حجم الهياكل
///
/// بالنسبة إلى `structs` ، يتم تحديد الحجم من خلال الخوارزمية التالية.
///
/// لكل حقل في الهيكل مرتب بأمر الإعلان:
///
/// 1. أضف حجم الحقل.
/// 2. تقريب الحجم الحالي إلى أقرب مضاعف للحقل التالي [alignment].
///
/// أخيرًا ، قم بتدوير حجم الهيكل إلى أقرب مضاعف لـ [alignment].
/// عادة ما تكون محاذاة الهيكل هي أكبر محاذاة لجميع مجالاتها ؛يمكن تغيير هذا باستخدام `repr(align(N))`.
///
/// على عكس `C` ، لا يتم تقريب الهياكل ذات الحجم الصفري إلى بايت واحد في الحجم.
///
/// ## حجم Enums
///
/// التعدادات التي لا تحمل أي بيانات بخلاف المميز لها نفس حجم تعدادات C على النظام الأساسي التي تم تجميعها من أجلها.
///
/// ## حجم النقابات
///
/// حجم الاتحاد هو حجم حقله الأكبر.
///
/// على عكس `C` ، لا يتم تقريب النقابات ذات الحجم الصفري إلى بايت واحد في الحجم.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // بعض الأوليات
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // بعض المصفوفات
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // المساواة في حجم المؤشر
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// باستخدام `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // حجم الحقل الأول هو 1 ، لذا أضف 1 إلى الحجم.الحجم 1.
/// // محاذاة الحقل الثاني هي 2 ، لذا أضف 1 إلى حجم المساحة المتروكة.الحجم 2.
/// // حجم الحقل الثاني هو 2 ، لذا أضف 2 إلى الحجم.الحجم 4.
/// // محاذاة الحقل الثالث هي 1 ، لذا أضف 0 إلى حجم المساحة المتروكة.الحجم 4.
/// // حجم الحقل الثالث هو 1 ، لذا أضف 1 إلى الحجم.الحجم 5.
/// // أخيرًا ، محاذاة الهيكل هي 2 (لأن أكبر محاذاة بين حقولها هي 2) ، لذا أضف 1 إلى حجم الحشو.
/// // الحجم 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // تتبع هياكل Tuple نفس القواعد.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // لاحظ أن إعادة ترتيب الحقول يمكن أن يقلل الحجم.
/// // يمكننا إزالة كلتا بايتات المساحة المتروكة بوضع `third` قبل `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // حجم الاتحاد هو حجم أكبر حقل.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// إرجاع حجم القيمة المشار إليها بالبايت.
///
/// عادة ما يكون هذا هو نفس `size_of::<T>()`.
/// ومع ذلك ، عندما لا يحتوي `T`* * على حجم معروف بشكل ثابت ، على سبيل المثال ، شريحة [`[T]`][slice] أو [trait object] ، فيمكن استخدام `size_of_val` للحصول على الحجم المعروف ديناميكيًا.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // الأمان: `val` هو مرجع ، لذا فهو مؤشر خام صالح
    unsafe { intrinsics::size_of_val(val) }
}

/// إرجاع حجم القيمة المشار إليها بالبايت.
///
/// عادة ما يكون هذا هو نفس `size_of::<T>()`.ومع ذلك ، عندما لا يحتوي `T`* * على حجم معروف بشكل ثابت ، على سبيل المثال ، شريحة [`[T]`][slice] أو [trait object] ، فيمكن استخدام `size_of_val_raw` للحصول على الحجم المعروف ديناميكيًا.
///
/// # Safety
///
/// هذه الوظيفة آمنة فقط للاتصال إذا استمرت الشروط التالية:
///
/// - إذا كان `T` هو `Sized` ، فهذه الوظيفة آمنة دائمًا للاتصال.
/// - إذا كان الذيل غير الحجم لـ `T` هو:
///     - a [slice] ، يجب أن يكون طول ذيل الشريحة عددًا صحيحًا مُهيأ ، ويجب أن يتناسب حجم *القيمة الكاملة*(طول الذيل الديناميكي + بادئة الحجم الثابت) في `isize`.
///     - a [trait object] ، ثم يجب أن يشير جزء vtable من المؤشر إلى vtable صالح تم الحصول عليه من خلال إكراه غير متغير ، ويجب أن يتناسب حجم *القيمة الكاملة*(طول الذيل الديناميكي + بادئة الحجم الثابت) في `isize`.
///
///     - (unstable) [extern type] ، فهذه الوظيفة آمنة دائمًا للاتصال بها ، ولكن قد panic أو إرجاع قيمة خاطئة بطريقة أخرى ، لأن تخطيط النوع الخارجي غير معروف.
///     هذا هو نفس سلوك [`size_of_val`] في مرجع لنوع ذي نوع خارجي خلفي.
///     - خلافًا لذلك ، لا يُسمح بشكل متحفظ باستدعاء هذه الوظيفة.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // الأمان: يجب أن يقدم المتصل مؤشرًا أوليًا صالحًا
    unsafe { intrinsics::size_of_val(val) }
}

/// لعرض الحد الأدنى من المحاذاة المطلوبة لنوع من النوع [ABI].
///
/// يجب أن يكون كل مرجع لقيمة من النوع `T` من مضاعفات هذا الرقم.
///
/// هذا هو المحاذاة المستخدمة للحقول الهيكلية.قد يكون أصغر من المحاذاة المفضلة.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// لعرض الحد الأدنى من المحاذاة المطلوبة لنوع القيمة التي يشير `val` إليها بواسطة [ABI].
///
/// يجب أن يكون كل مرجع لقيمة من النوع `T` من مضاعفات هذا الرقم.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // الأمان: val هو مرجع ، لذا فهو مؤشر خام صالح
    unsafe { intrinsics::min_align_of_val(val) }
}

/// لعرض الحد الأدنى من المحاذاة المطلوبة لنوع من النوع [ABI].
///
/// يجب أن يكون كل مرجع لقيمة من النوع `T` من مضاعفات هذا الرقم.
///
/// هذا هو المحاذاة المستخدمة للحقول الهيكلية.قد يكون أصغر من المحاذاة المفضلة.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// لعرض الحد الأدنى من المحاذاة المطلوبة لنوع القيمة التي يشير `val` إليها بواسطة [ABI].
///
/// يجب أن يكون كل مرجع لقيمة من النوع `T` من مضاعفات هذا الرقم.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // الأمان: val هو مرجع ، لذا فهو مؤشر خام صالح
    unsafe { intrinsics::min_align_of_val(val) }
}

/// لعرض الحد الأدنى من المحاذاة المطلوبة لنوع القيمة التي يشير `val` إليها بواسطة [ABI].
///
/// يجب أن يكون كل مرجع لقيمة من النوع `T` من مضاعفات هذا الرقم.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// هذه الوظيفة آمنة فقط للاتصال إذا استمرت الشروط التالية:
///
/// - إذا كان `T` هو `Sized` ، فهذه الوظيفة آمنة دائمًا للاتصال.
/// - إذا كان الذيل غير الحجم لـ `T` هو:
///     - a [slice] ، يجب أن يكون طول ذيل الشريحة عددًا صحيحًا مُهيأ ، ويجب أن يتناسب حجم *القيمة الكاملة*(طول الذيل الديناميكي + بادئة الحجم الثابت) في `isize`.
///     - a [trait object] ، ثم يجب أن يشير جزء vtable من المؤشر إلى vtable صالح تم الحصول عليه من خلال إكراه غير متغير ، ويجب أن يتناسب حجم *القيمة الكاملة*(طول الذيل الديناميكي + بادئة الحجم الثابت) في `isize`.
///
///     - (unstable) [extern type] ، فهذه الوظيفة آمنة دائمًا للاتصال بها ، ولكن قد panic أو إرجاع قيمة خاطئة بطريقة أخرى ، لأن تخطيط النوع الخارجي غير معروف.
///     هذا هو نفس سلوك [`align_of_val`] في مرجع لنوع ذي نوع خارجي خلفي.
///     - خلافًا لذلك ، لا يُسمح بشكل متحفظ باستدعاء هذه الوظيفة.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // الأمان: يجب أن يقدم المتصل مؤشرًا أوليًا صالحًا
    unsafe { intrinsics::min_align_of_val(val) }
}

/// تُرجع `true` إذا كان إسقاط قيم من النوع `T` مهمًا.
///
/// هذا تلميح تحسين بحت ، ويمكن تنفيذه بشكل متحفظ:
/// قد يعيد `true` لأنواع لا تحتاج بالفعل إلى إسقاطها.
/// على هذا النحو ، فإن إعادة `true` دائمًا سيكون تنفيذًا صالحًا لهذه الوظيفة.ومع ذلك ، إذا كانت هذه الوظيفة ترجع بالفعل `false` ، فيمكنك أن تكون على يقين من أن إسقاط `T` ليس له أي آثار جانبية.
///
/// يجب أن تستخدم التطبيقات منخفضة المستوى لأشياء مثل المجموعات ، والتي تحتاج إلى إسقاط بياناتها يدويًا ، هذه الوظيفة لتجنب محاولة إسقاط جميع محتوياتها دون داعٍ عند إتلافها.
///
/// قد لا يحدث هذا فرقًا في تصميمات الإصدار (حيث يتم اكتشاف الحلقة التي ليس لها آثار جانبية بسهولة وإزالتها) ، ولكنها غالبًا ما تكون بمثابة فوز كبير لبناءات التصحيح.
///
/// لاحظ أن [`drop_in_place`] يقوم بالفعل بهذا الفحص ، لذلك إذا كان من الممكن تقليل عبء العمل الخاص بك إلى عدد صغير من مكالمات [`drop_in_place`] ، فإن استخدام هذا غير ضروري.
/// لاحظ على وجه الخصوص أنه يمكنك [`drop_in_place`] شريحة ، وهذا سيفحص احتياجات_قطرة واحدة لجميع القيم.
///
/// لذلك فإن الأنواع مثل Vec فقط `drop_in_place(&mut self[..])` دون استخدام `needs_drop` بشكل صريح.
/// من ناحية أخرى ، يتعين على أنواع مثل [`HashMap`] إسقاط القيم واحدة تلو الأخرى ويجب أن تستخدم واجهة برمجة التطبيقات هذه.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// فيما يلي مثال لكيفية استخدام المجموعة لـ `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // إسقاط البيانات
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// لعرض قيمة النوع `T` الذي يمثله نمط البايت الخالي من الصفر.
///
/// هذا يعني ، على سبيل المثال ، أن بايت الحشو في `(u8, u16)` ليس بالضرورة صفريًا.
///
/// ليس هناك ما يضمن أن يمثل نمط البايت الصفري بالكامل قيمة صالحة لنوع من أنواع `T`.
/// على سبيل المثال ، نمط البايت الصفري بالكامل ليس قيمة صالحة لأنواع المراجع (`&T` ، `&mut T`) ومؤشرات الدوال.
/// يؤدي استخدام `zeroed` على مثل هذه الأنواع إلى [undefined behavior][ub] الفوري لأن [the Rust compiler assumes][inv] توجد دائمًا قيمة صالحة في متغير يعتبره مهيئًا.
///
///
/// هذا له نفس تأثير [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// يكون مفيدًا للأرق المعيشية أحيانًا ، ولكن يجب تجنبه بشكل عام.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// الاستخدام الصحيح لهذه الوظيفة: تهيئة عدد صحيح بصفر.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *استخدام غير صحيح* لهذه الوظيفة: تهيئة مرجع بصفر.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // سلوك غير محدد!
/// let _y: fn() = unsafe { mem::zeroed() }; // ومره اخرى!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // الأمان: يجب أن يضمن المتصل أن القيمة الصفرية الكاملة صالحة لـ `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// يتجاوز اختبارات تهيئة الذاكرة العادية لـ Rust من خلال التظاهر بإنتاج قيمة من النوع `T` ، مع عدم القيام بأي شيء على الإطلاق.
///
/// **تم إهمال هذه الوظيفة.** استخدم [`MaybeUninit<T>`] بدلاً من ذلك.
///
/// سبب الإهمال هو أنه لا يمكن استخدام الوظيفة بشكل صحيح: لها نفس تأثير [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// كما يوضح [`assume_init` documentation][assume_init] ، [the Rust compiler assumes][inv] يتم تهيئة القيم بشكل صحيح.
/// نتيجة لذلك ، استدعاء على سبيل المثال
/// `mem::uninitialized::<bool>()` يتسبب في سلوك فوري غير محدد لإرجاع `bool` ليس بالتأكيد إما `true` أو `false`.
/// والأسوأ من ذلك ، أن الذاكرة غير المهيأة حقًا مثل ما يتم إرجاعه هنا هي ذاكرة خاصة من حيث أن المترجم يعرف أنه ليس لها قيمة ثابتة.
/// هذا يجعل من السلوك غير المحدد الحصول على بيانات غير مهيأة في متغير حتى لو كان هذا المتغير من نوع عدد صحيح.
/// (لاحظ أن القواعد المتعلقة بالأعداد الصحيحة غير المهيأة لم يتم الانتهاء منها بعد ، ولكن حتى يتم الانتهاء منها ، فمن المستحسن تجنبها.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // الأمان: يجب أن يضمن المتصل أن القيمة الموحدة صالحة لـ `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// لمبادلة القيم في موقعين قابلين للتغيير ، بدون إلغاء تهيئة أي منهما.
///
/// * إذا كنت تريد المبادلة بقيمة افتراضية أو وهمية ، فراجع [`take`].
/// * إذا كنت تريد المبادلة بقيمة تم تمريرها ، وإرجاع القيمة القديمة ، فراجع [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // الأمان: تم إنشاء المؤشرات الأولية من مراجع قابلة للتغيير آمنة ترضي جميع ملفات
    // قيود على `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// يستبدل `dest` بالقيمة الافتراضية لـ `T` ، ويعيد قيمة `dest` السابقة.
///
/// * إذا كنت تريد استبدال قيم متغيرين ، فراجع [`swap`].
/// * إذا كنت تريد الاستبدال بقيمة تم تمريرها بدلاً من القيمة الافتراضية ، فراجع [`replace`].
///
/// # Examples
///
/// مثال بسيط:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` يسمح بالحصول على ملكية حقل هيكلي عن طريق استبداله بقيمة "empty".
/// بدون `take` ، يمكنك مواجهة مشكلات مثل هذه:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// لاحظ أن `T` لا ينفذ بالضرورة [`Clone`] ، لذلك لا يمكنه حتى استنساخ `self.buf` وإعادة تعيينه.
/// ولكن يمكن استخدام `take` لفصل القيمة الأصلية لـ `self.buf` عن `self` ، مما يسمح بإعادتها:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// ينقل `src` إلى `dest` المشار إليه ، ويعيد قيمة `dest` السابقة.
///
/// لم يتم إسقاط أي من القيمتين.
///
/// * إذا كنت تريد استبدال قيم متغيرين ، فراجع [`swap`].
/// * إذا كنت تريد الاستبدال بقيمة افتراضية ، فراجع [`take`].
///
/// # Examples
///
/// مثال بسيط:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` يسمح باستهلاك حقل هيكلي عن طريق استبداله بقيمة أخرى.
/// بدون `replace` ، يمكنك مواجهة مشكلات مثل هذه:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// لاحظ أن `T` لا ينفذ بالضرورة [`Clone`] ، لذلك لا يمكننا حتى استنساخ `self.buf[i]` لتجنب هذه الخطوة.
/// ولكن يمكن استخدام `replace` لفصل القيمة الأصلية في هذا الفهرس عن `self` ، مما يسمح بإعادتها:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // الأمان: نقرأ من `dest` ولكن نكتب `src` مباشرة بعد ذلك ،
    // بحيث لا يتم تكرار القيمة القديمة.
    // لم يتم إسقاط أي شيء ولا شيء هنا يمكن لـ panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// التصرفات ذات القيمة.
///
/// يقوم بذلك عن طريق استدعاء تطبيق الوسيطة لـ [`Drop`][drop].
///
/// هذا لا يفعل شيئًا بشكل فعال للأنواع التي تطبق `Copy` ، على سبيل المثال
/// integers.
/// يتم نسخ هذه القيم ونقل _then_ إلى الدالة ، لذلك تستمر القيمة بعد استدعاء الوظيفة.
///
///
/// هذه الوظيفة ليست سحرية.يتم تعريفه حرفيا على أنه
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// نظرًا لنقل `_x` إلى الوظيفة ، يتم إسقاطها تلقائيًا قبل إرجاع الوظيفة.
///
/// [drop]: Drop
///
/// # Examples
///
/// الاستخدام الأساسي:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // قم بإسقاط vector بشكل صريح
/// ```
///
/// نظرًا لأن [`RefCell`] يفرض قواعد الاستعارة في وقت التشغيل ، يمكن لـ `drop` إصدار استعارة [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // التخلي عن الاقتراض القابل للتغيير في هذه الفتحة
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// الأعداد الصحيحة والأنواع الأخرى التي تطبق [`Copy`] لا تتأثر بـ `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // تم نقل نسخة من `x` وإسقاطها
/// drop(y); // تم نقل نسخة من `y` وإسقاطها
///
/// println!("x: {}, y: {}", x, y.0); // مازال متاحا
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// يفسر `src` على أنه من النوع `&U` ، ثم يقرأ `src` بدون نقل القيمة المضمنة.
///
/// ستفترض هذه الوظيفة بشكل غير آمن أن المؤشر `src` صالح لـ [`size_of::<U>`][size_of] بايت عن طريق نقل `&T` إلى `&U` ثم قراءة `&U` (باستثناء أن هذا يتم بطريقة صحيحة حتى عندما يقوم `&U` بعمل متطلبات محاذاة أكثر صرامة من `&T`).
/// سيؤدي أيضًا إلى إنشاء نسخة من القيمة المضمنة بشكل غير آمن بدلاً من الخروج من `src`.
///
/// لا يعد خطأ وقت الترجمة إذا كان `T` و `U` لهما أحجام مختلفة ، ولكن يُنصح بشدة باستدعاء هذه الوظيفة فقط حيث يكون `T` و `U` بنفس الحجم.تقوم هذه الوظيفة بتشغيل [undefined behavior][ub] إذا كان `U` أكبر من `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // انسخ البيانات من 'foo_array' وتعامل معها على أنها 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // قم بتعديل البيانات المنسوخة
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // يجب ألا تتغير محتويات 'foo_array'
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // إذا كان لدى U متطلبات محاذاة أعلى ، فقد لا يتم محاذاة src بشكل مناسب.
    if align_of::<U>() > align_of::<T>() {
        // الأمان: `src` هو مرجع مضمون أن يكون صالحًا للقراءات.
        // يجب أن يضمن المتصل أن التحويل الفعلي آمن.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // الأمان: `src` هو مرجع مضمون أن يكون صالحًا للقراءات.
        // لقد تحققنا للتو من محاذاة `src as *const U` بشكل صحيح.
        // يجب أن يضمن المتصل أن التحويل الفعلي آمن.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// نوع معتم يمثل مميز التعداد.
///
/// راجع وظيفة [`discriminant`] في هذه الوحدة لمزيد من المعلومات.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. لا يمكن اشتقاق تطبيقات trait لأننا لا نريد أي حدود على T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// تُرجع قيمة تحدد متغير التعداد بشكل فريد في `v`.
///
/// إذا لم يكن `T` تعدادًا ، فلن يؤدي استدعاء هذه الوظيفة إلى سلوك غير محدد ، ولكن القيمة المعادة غير محددة.
///
///
/// # Stability
///
/// قد يتغير تمييز متغير التعداد إذا تغير تعريف التعداد.
/// لن يتغير تمييز بعض المتغيرات بين التجميعات باستخدام نفس المترجم.
///
/// # Examples
///
/// يمكن استخدام هذا لمقارنة التعدادات التي تحمل البيانات ، مع تجاهل البيانات الفعلية:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// تُرجع عدد المتغيرات في نوع التعداد `T`.
///
/// إذا لم يكن `T` تعدادًا ، فلن يؤدي استدعاء هذه الوظيفة إلى سلوك غير محدد ، ولكن القيمة المعادة غير محددة.
/// بالتساوي ، إذا كان `T` عبارة عن تعداد يحتوي على متغيرات أكثر من `usize::MAX` ، فإن قيمة الإرجاع غير محددة.
/// سيتم احتساب المتغيرات غير المأهولة.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}