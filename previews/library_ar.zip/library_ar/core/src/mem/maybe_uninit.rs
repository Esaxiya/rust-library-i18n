use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// نوع مجمّع لإنشاء مثيلات غير مهيأة لـ `T`.
///
/// # تهيئة ثابتة
///
/// يفترض المترجم بشكل عام أن المتغير تمت تهيئته بشكل صحيح وفقًا لمتطلبات نوع المتغير.على سبيل المثال ، يجب محاذاة متغير نوع المرجع وغير NULL.
/// هذا أمر ثابت يجب دعمه *دائمًا*، حتى في التعليمات البرمجية غير الآمنة.
/// نتيجة لذلك ، يؤدي التهيئة الصفرية لمتغير من النوع المرجعي إلى [undefined behavior][ub] لحظيًا ، بغض النظر عما إذا كان هذا المرجع قد تم استخدامه للوصول إلى الذاكرة:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // سلوك غير محدد!⚠️
/// // الكود المكافئ مع `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // سلوك غير محدد!⚠️
/// ```
///
/// يتم استغلال هذا من قبل المترجم للتحسينات المختلفة ، مثل إلغاء عمليات فحص وقت التشغيل وتحسين تخطيط `enum`.
///
/// وبالمثل ، قد تحتوي الذاكرة غير المهيأة تمامًا على أي محتوى ، بينما يجب أن يكون `bool` دائمًا `true` أو `false`.ومن ثم ، فإن إنشاء `bool` غير مهيأ هو سلوك غير محدد:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // سلوك غير محدد!⚠️
/// // الكود المكافئ مع `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // سلوك غير محدد!⚠️
/// ```
///
/// علاوة على ذلك ، تعتبر الذاكرة غير المهيأة خاصة لأنها لا تحتوي على قيمة ثابتة ("fixed" تعني "it won't change without being written to").يمكن أن تؤدي قراءة نفس البايت غير المهيأ عدة مرات إلى نتائج مختلفة.
/// هذا يجعل من السلوك غير المحدد الحصول على بيانات غير مهيأة في متغير حتى لو كان هذا المتغير يحتوي على نوع عدد صحيح ، والذي بخلاف ذلك يمكنه الاحتفاظ بأي نمط بت *ثابت*:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // سلوك غير محدد!⚠️
/// // الكود المكافئ مع `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // سلوك غير محدد!⚠️
/// ```
/// (لاحظ أن القواعد المتعلقة بالأعداد الصحيحة غير المهيأة لم يتم الانتهاء منها بعد ، ولكن حتى يتم الانتهاء منها ، فمن المستحسن تجنبها.)
///
/// علاوة على ذلك ، تذكر أن معظم الأنواع لها ثوابت إضافية تتجاوز مجرد اعتبارها مهيأة على مستوى النوع.
/// على سبيل المثال ، يعتبر [`Vec<T>`] الذي تمت تهيئته "1" مهيأ (في ظل التنفيذ الحالي ؛ هذا لا يشكل ضمانًا ثابتًا) لأن المطلب الوحيد الذي يعرفه المترجم عنه هو أن مؤشر البيانات يجب أن يكون غير فارغ.
/// لا يتسبب إنشاء مثل هذا `Vec<T>` في سلوك *فوري* غير محدد ، ولكنه سيؤدي إلى سلوك غير محدد في معظم العمليات الآمنة (بما في ذلك إسقاطه).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` يعمل على تمكين رمز غير آمن للتعامل مع البيانات غير المهيأة.
/// إنها إشارة إلى المترجم تشير إلى أن البيانات هنا قد *لا* يتم تهيئتها:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // إنشاء مرجع غير مهيأ بشكل صريح.
/// // يعرف المترجم أن البيانات الموجودة داخل `MaybeUninit<T>` قد تكون غير صالحة ، وبالتالي هذا ليس UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // اضبطه على قيمة صالحة.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // استخراج البيانات التي تمت تهيئتها-هذا مسموح به فقط *بعد* تهيئة `x` بشكل صحيح!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// يعرف المترجم بعد ذلك أنه لا يقوم بأي افتراضات أو تحسينات غير صحيحة على هذا الكود.
///
/// يمكنك التفكير في `MaybeUninit<T>` على أنه يشبه إلى حد ما `Option<T>` ولكن بدون أي تتبع لوقت التشغيل وبدون أي من فحوصات السلامة.
///
/// ## out-pointers
///
/// يمكنك استخدام `MaybeUninit<T>` لتنفيذ "out-pointers": بدلاً من إرجاع البيانات من دالة ، قم بتمريرها بمؤشر إلى بعض ذاكرة (uninitialized) لوضع النتيجة فيها.
/// يمكن أن يكون هذا مفيدًا عندما يكون من المهم أن يتحكم المتصل في كيفية تخصيص الذاكرة التي يتم تخزين النتيجة فيها ، وتريد تجنب الحركات غير الضرورية.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` لا تسقط المحتويات القديمة ، وهو أمر مهم.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // الآن نعلم أن `v` مهيأ!هذا أيضًا يضمن سقوط vector بشكل صحيح.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## تهيئة مصفوفة عنصرًا عنصرًا
///
/// `MaybeUninit<T>` يمكن استخدامها لتهيئة عنصر مصفوفة كبيرة عنصرًا تلو الآخر:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // قم بإنشاء صفيف غير مهيأ لـ `MaybeUninit`.
///     // `assume_init` آمن لأن النوع الذي ندعي أنه تمت تهيئته هنا هو مجموعة من "ربما Uninit" ، والتي لا تتطلب التهيئة.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // إسقاط `MaybeUninit` لا يفعل شيئًا.
///     // وبالتالي ، فإن استخدام تعيين المؤشر الأولي بدلاً من `ptr::write` لا يتسبب في إسقاط القيمة القديمة غير المهيأة.
/////
///     // أيضًا في حالة وجود panic أثناء هذه الحلقة ، يكون لدينا تسرب للذاكرة ، ولكن لا توجد مشكلة تتعلق بأمان الذاكرة.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // كل شيء مهيأ.
///     // تحويل المصفوفة إلى النوع الذي تمت تهيئته.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// يمكنك أيضًا العمل مع المصفوفات التي تمت تهيئتها جزئيًا ، والتي يمكن العثور عليها في هياكل البيانات منخفضة المستوى.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // قم بإنشاء صفيف غير مهيأ لـ `MaybeUninit`.
/// // `assume_init` آمن لأن النوع الذي ندعي أنه تمت تهيئته هنا هو مجموعة من "ربما Uninit" ، والتي لا تتطلب التهيئة.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // احسب عدد العناصر التي خصصناها.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // لكل عنصر في المصفوفة ، قم بإسقاطه إذا قمنا بتخصيصه.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## تهيئة هيكلة مجالاً تلو الآخر
///
/// يمكنك استخدام `MaybeUninit<T>` و [`std::ptr::addr_of_mut`] الماكرو لتهيئة المجالس حسب المجال:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // تهيئة الحقل `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // تهيئة الحقل `list` إذا كان هناك panic هنا ، فإن `String` في الحقل `name` يتسرب.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // تمت تهيئة جميع الحقول ، لذلك نقوم باستدعاء `assume_init` للحصول على Foo مهيأ.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` مضمون أن يكون له نفس الحجم والمحاذاة و ABI مثل `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// ومع ذلك ، تذكر أن النوع *الذي يحتوي على* a `MaybeUninit<T>` ليس بالضرورة نفس التخطيط ؛لا تضمن Rust بشكل عام أن حقول `Foo<T>` لها نفس الترتيب مثل `Foo<U>` حتى لو كان `T` و `U` بنفس الحجم والمحاذاة.
///
/// علاوة على ذلك ، نظرًا لأن أي قيمة بت صالحة لـ `MaybeUninit<T>` ، لا يستطيع المترجم تطبيق تحسينات non-zero/niche-filling ، مما قد يؤدي إلى حجم أكبر:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// إذا كان `T` آمنًا من حيث FFI ، فسيكون `MaybeUninit<T>` كذلك.
///
/// بينما `MaybeUninit` هو `#[repr(transparent)]` (مما يشير إلى أنه يضمن نفس الحجم والمحاذاة و ABI مثل `T`) ، هذا *لا* يغير أيًا من التحذيرات السابقة.
/// `Option<T>` قد لا يزال `Option<MaybeUninit<T>>` لهما أحجام مختلفة ، وقد يتم تخطيط الأنواع التي تحتوي على حقل من النوع `T` (وحجمها) بشكل مختلف عما لو كان هذا الحقل `MaybeUninit<T>`.
/// `MaybeUninit` هو نوع اتحاد ، و `#[repr(transparent)]` على النقابات غير مستقر (انظر [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// بمرور الوقت ، قد تتطور الضمانات الدقيقة لـ `#[repr(transparent)]` على النقابات ، وقد تظل `MaybeUninit` أو لا تظل `#[repr(transparent)]`.
/// ومع ذلك ، سيضمن `MaybeUninit<T>`*دائمًا* أن يكون له نفس الحجم والمحاذاة و ABI مثل `T` ؛إن الطريقة التي تنفذ بها `MaybeUninit` قد تتطور فقط.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// عنصر لانج حتى نتمكن من التفاف الأنواع الأخرى فيه.هذا مفيد للمولدات.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // لا نتصل بـ `T::clone()` ، لا يمكننا معرفة ما إذا كنا مهيئين بما يكفي لذلك.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// ينشئ `MaybeUninit<T>` جديد مهيأ بالقيمة المحددة.
    /// من الآمن استدعاء [`assume_init`] على قيمة الإرجاع لهذه الوظيفة.
    ///
    /// لاحظ أن إسقاط `MaybeUninit<T>` لن يؤدي مطلقًا إلى استدعاء رمز إسقاط `T`.
    /// تقع على عاتقك مسؤولية التأكد من إسقاط `T` إذا تمت تهيئته.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// ينشئ `MaybeUninit<T>` جديدًا في حالة غير مهيأة.
    ///
    /// لاحظ أن إسقاط `MaybeUninit<T>` لن يؤدي مطلقًا إلى استدعاء رمز إسقاط `T`.
    /// تقع على عاتقك مسؤولية التأكد من إسقاط `T` إذا تمت تهيئته.
    ///
    /// راجع [type-level documentation][MaybeUninit] للحصول على بعض الأمثلة.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// قم بإنشاء صفيف جديد من عناصر `MaybeUninit<T>` ، في حالة غير مهيأة.
    ///
    /// Note: في إصدار future Rust ، قد تصبح هذه الطريقة غير ضرورية عندما تسمح البنية الحرفية للصفيف بـ [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// يمكن أن يستخدم المثال أدناه `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// لعرض شريحة (ربما أصغر) من البيانات التي تمت قراءتها بالفعل
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // الأمان: `[MaybeUninit<_>; LEN]` غير مهيأ صالحًا.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// ينشئ `MaybeUninit<T>` جديدًا في حالة غير مهيأة ، مع ملء الذاكرة بـ `0` بايت.يعتمد ذلك على `T` ما إذا كان ذلك يؤدي بالفعل إلى التهيئة الصحيحة.
    ///
    /// على سبيل المثال ، تمت تهيئة `MaybeUninit<usize>::zeroed()` ، لكن `MaybeUninit<&'static i32>::zeroed()` ليس لأن المراجع يجب ألا تكون خالية.
    ///
    /// لاحظ أن إسقاط `MaybeUninit<T>` لن يؤدي مطلقًا إلى استدعاء رمز إسقاط `T`.
    /// تقع على عاتقك مسؤولية التأكد من إسقاط `T` إذا تمت تهيئته.
    ///
    /// # Example
    ///
    /// الاستخدام الصحيح لهذه الوظيفة: تهيئة بنية بصفر ، حيث يمكن لجميع حقول البنية الاحتفاظ بنمط البت 0 كقيمة صالحة.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *استخدام غير صحيح* لهذه الوظيفة: استدعاء `x.zeroed().assume_init()` عندما لا يكون `0` نمط بت صالحًا للنوع:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // داخل زوج ، نقوم بإنشاء `NotZero` لا يحتوي على مميز صالح.
    /// // هذا سلوك غير محدد.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // الأمان: `u.as_mut_ptr()` نقطة للذاكرة المخصصة.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// يضبط قيمة `MaybeUninit<T>`.
    /// يؤدي هذا إلى استبدال أي قيمة سابقة دون إهمالها ، لذا احرص على عدم استخدام هذا مرتين إلا إذا كنت تريد تخطي تشغيل أداة التدمير.
    ///
    /// من أجل راحتك ، يُرجع هذا أيضًا مرجعًا متغيرًا لمحتويات `self` (التي تمت تهيئتها بأمان الآن).
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // الأمان: لقد قمنا للتو بتهيئة هذه القيمة.
        unsafe { self.assume_init_mut() }
    }

    /// يحصل على مؤشر للقيمة المضمنة.
    /// القراءة من هذا المؤشر أو تحويله إلى مرجع هي سلوك غير محدد ما لم تتم تهيئة `MaybeUninit<T>`.
    /// الكتابة في الذاكرة التي يشير إليها هذا المؤشر (non-transitively) هي سلوك غير محدد (باستثناء داخل `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// الاستخدام الصحيح لهذه الطريقة:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // قم بإنشاء مرجع في `MaybeUninit<T>`.هذا جيد لأننا بدأناه.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *استخدام غير صحيح* لهذه الطريقة:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // لقد أنشأنا إشارة إلى vector غير مهيأ!هذا سلوك غير محدد.⚠️
    /// ```
    ///
    /// (لاحظ أن القواعد المتعلقة بالإشارات إلى البيانات غير المهيأة لم يتم الانتهاء منها بعد ، ولكن حتى يتم ذلك ، يُنصح بتجنبها.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` و `ManuallyDrop` كلاهما `repr(transparent)` حتى نتمكن من إلقاء المؤشر.
        self as *const _ as *const T
    }

    /// يحصل على مؤشر قابل للتغيير للقيمة المضمنة.
    /// القراءة من هذا المؤشر أو تحويله إلى مرجع هي سلوك غير محدد ما لم تتم تهيئة `MaybeUninit<T>`.
    ///
    /// # Examples
    ///
    /// الاستخدام الصحيح لهذه الطريقة:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // قم بإنشاء مرجع في `MaybeUninit<Vec<u32>>`.
    /// // هذا جيد لأننا بدأناه.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *استخدام غير صحيح* لهذه الطريقة:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // لقد أنشأنا إشارة إلى vector غير مهيأ!هذا سلوك غير محدد.⚠️
    /// ```
    ///
    /// (لاحظ أن القواعد المتعلقة بالإشارات إلى البيانات غير المهيأة لم يتم الانتهاء منها بعد ، ولكن حتى يتم ذلك ، يُنصح بتجنبها.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` و `ManuallyDrop` كلاهما `repr(transparent)` حتى نتمكن من إلقاء المؤشر.
        self as *mut _ as *mut T
    }

    /// يستخرج القيمة من حاوية `MaybeUninit<T>`.هذه طريقة رائعة لضمان إسقاط البيانات ، لأن `T` الناتج يخضع لمعالجة الإسقاط المعتادة.
    ///
    /// # Safety
    ///
    /// الأمر متروك للمتصل لضمان أن `MaybeUninit<T>` بالفعل في حالة تهيئة.يؤدي استدعاء هذا في حالة عدم تهيئة المحتوى بشكل كامل إلى حدوث سلوك فوري غير محدد.
    /// يحتوي [type-level documentation][inv] على مزيد من المعلومات حول ثابت التهيئة هذا.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// علاوة على ذلك ، تذكر أن معظم الأنواع لها ثوابت إضافية تتجاوز مجرد اعتبارها مهيأة على مستوى النوع.
    /// على سبيل المثال ، يعتبر [`Vec<T>`] الذي تمت تهيئته "1" مهيأ (في ظل التنفيذ الحالي ؛ هذا لا يشكل ضمانًا ثابتًا) لأن المطلب الوحيد الذي يعرفه المترجم عنه هو أن مؤشر البيانات يجب أن يكون غير فارغ.
    ///
    /// لا يتسبب إنشاء مثل هذا `Vec<T>` في سلوك *فوري* غير محدد ، ولكنه سيؤدي إلى سلوك غير محدد في معظم العمليات الآمنة (بما في ذلك إسقاطه).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// الاستخدام الصحيح لهذه الطريقة:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *استخدام غير صحيح* لهذه الطريقة:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` لم تتم تهيئته بعد ، لذلك تسبب هذا السطر الأخير في سلوك غير محدد.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // الأمان: يجب أن يضمن المتصل تهيئة `self`.
        // هذا يعني أيضًا أن `self` يجب أن يكون متغير `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// يقرأ القيمة من حاوية `MaybeUninit<T>`.يخضع `T` الناتج للتعامل مع الإسقاط المعتاد.
    ///
    /// كلما أمكن ، يفضل استخدام [`assume_init`] بدلاً من ذلك ، مما يمنع تكرار محتوى `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// الأمر متروك للمتصل لضمان أن `MaybeUninit<T>` بالفعل في حالة تهيئة.يؤدي استدعاء هذا عندما لا تتم تهيئة المحتوى بالكامل بعد إلى حدوث سلوك غير محدد.
    /// يحتوي [type-level documentation][inv] على مزيد من المعلومات حول ثابت التهيئة هذا.
    ///
    /// علاوة على ذلك ، فإن هذا يترك نسخة من نفس البيانات في `MaybeUninit<T>`.
    /// عند استخدام نسخ متعددة من البيانات (عن طريق الاتصال بـ `assume_init_read` عدة مرات ، أو الاتصال أولاً بـ `assume_init_read` ثم [`assume_init`]) ، تقع على عاتقك مسؤولية التأكد من إمكانية تكرار هذه البيانات بالفعل.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// الاستخدام الصحيح لهذه الطريقة:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` هو `Copy` ، لذلك قد نقرأ عدة مرات.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // لا بأس من تكرار قيمة `None` ، لذلك قد نقرأ عدة مرات.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *استخدام غير صحيح* لهذه الطريقة:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // لقد أنشأنا الآن نسختين من نفس vector ، مما أدى إلى نسخة مزدوجة خالية عندما يتم إسقاط كلاهما!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // الأمان: يجب أن يضمن المتصل تهيئة `self`.
        // القراءة من `self.as_ptr()` آمنة حيث يجب تهيئة `self`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// يسقط القيمة المضمنة في مكانها.
    ///
    /// إذا كان لديك ملكية `MaybeUninit` ، فيمكنك استخدام [`assume_init`] بدلاً من ذلك.
    ///
    /// # Safety
    ///
    /// الأمر متروك للمتصل لضمان أن `MaybeUninit<T>` بالفعل في حالة تهيئة.يؤدي استدعاء هذا عندما لا تتم تهيئة المحتوى بالكامل بعد إلى حدوث سلوك غير محدد.
    ///
    /// علاوة على ذلك ، يجب استيفاء جميع الثوابت الإضافية من النوع `T` ، حيث قد يعتمد تنفيذ `Drop` لـ `T` (أو أعضائه) على ذلك.
    /// على سبيل المثال ، يعتبر [`Vec<T>`] الذي تمت تهيئته "1" مهيأ (في ظل التنفيذ الحالي ؛ هذا لا يشكل ضمانًا ثابتًا) لأن المطلب الوحيد الذي يعرفه المترجم عنه هو أن مؤشر البيانات يجب أن يكون غير فارغ.
    ///
    /// ومع ذلك ، فإن إسقاط مثل `Vec<T>` سيؤدي إلى سلوك غير محدد.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // الأمان: يجب أن يضمن المتصل تهيئة `self` و
        // يفي بجميع ثوابت `T`.
        // يعتبر إسقاط القيمة في مكانها آمنًا إذا كان هذا هو الحال.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// يحصل على مرجع مشترك للقيمة المضمنة.
    ///
    /// يمكن أن يكون هذا مفيدًا عندما نريد الوصول إلى `MaybeUninit` الذي تمت تهيئته ولكن ليس لدينا ملكية `MaybeUninit` (مما يمنع استخدام `.assume_init()`).
    ///
    /// # Safety
    ///
    /// يؤدي استدعاء هذا عندما لا تتم تهيئة المحتوى بالكامل بعد إلى حدوث سلوك غير محدد: الأمر متروك للمتصل لضمان أن `MaybeUninit<T>` بالفعل في حالة تهيئة.
    ///
    ///
    /// # Examples
    ///
    /// ### الاستخدام الصحيح لهذه الطريقة:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // تهيئة `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // الآن وقد عُرف أن `MaybeUninit<_>` الخاص بنا قد تمت تهيئته ، فلا بأس من إنشاء مرجع مشترك له:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // الأمان: تمت تهيئة `x`.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *استخدامات غير صحيحة* لهذه الطريقة:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // لقد أنشأنا إشارة إلى vector غير مهيأ!هذا سلوك غير محدد.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // تهيئة `MaybeUninit` باستخدام `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // إشارة إلى `Cell<bool>` غير مهيأ: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // الأمان: يجب أن يضمن المتصل تهيئة `self`.
        // هذا يعني أيضًا أن `self` يجب أن يكون متغير `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// الحصول على مرجع (unique) قابل للتغيير للقيمة المضمنة.
    ///
    /// يمكن أن يكون هذا مفيدًا عندما نريد الوصول إلى `MaybeUninit` الذي تمت تهيئته ولكن ليس لدينا ملكية `MaybeUninit` (مما يمنع استخدام `.assume_init()`).
    ///
    /// # Safety
    ///
    /// يؤدي استدعاء هذا عندما لا تتم تهيئة المحتوى بالكامل بعد إلى حدوث سلوك غير محدد: الأمر متروك للمتصل لضمان أن `MaybeUninit<T>` بالفعل في حالة تهيئة.
    /// على سبيل المثال ، لا يمكن استخدام `.assume_init_mut()` لتهيئة `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### الاستخدام الصحيح لهذه الطريقة:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// يقوم بتهيئة *كل* بايت مخزن الإدخال المؤقت.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // تهيئة `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // نحن نعلم الآن أن `buf` قد تمت تهيئته ، لذا يمكننا `.assume_init()` منه.
    /// // ومع ذلك ، قد يؤدي استخدام `.assume_init()` إلى تشغيل `memcpy` من 2048 بايت.
    /// // لتأكيد أن المخزن المؤقت لدينا قد تمت تهيئته دون نسخه ، نقوم بترقية `&mut MaybeUninit<[u8; 2048]>` إلى `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // الأمان: تمت تهيئة `buf`.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // الآن يمكننا استخدام `buf` كشريحة عادية:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *استخدامات غير صحيحة* لهذه الطريقة:
    ///
    /// لا يمكنك استخدام `.assume_init_mut()` لتهيئة قيمة:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // لقد أنشأنا إشارة (mutable) إلى `bool` غير مهيأ!
    ///     // هذا سلوك غير محدد.⚠️
    /// }
    /// ```
    ///
    /// على سبيل المثال ، لا يمكنك وضع [`Read`] في مخزن مؤقت غير مهيأ:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) إشارة إلى ذاكرة غير مهيأة!
    ///                             // هذا سلوك غير محدد.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// ولا يمكنك استخدام الوصول المباشر إلى الحقل لإجراء التهيئة التدريجية لكل حقل على حدة:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) إشارة إلى ذاكرة غير مهيأة!
    ///                  // هذا سلوك غير محدد.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) إشارة إلى ذاكرة غير مهيأة!
    ///                  // هذا سلوك غير محدد.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): نحن نعتمد حاليًا على أن ما ورد أعلاه غير صحيح ، على سبيل المثال ، لدينا مراجع للبيانات غير المهيأة (على سبيل المثال ، في `libcore/fmt/float.rs`).
    // يجب أن نتخذ قرارًا نهائيًا بشأن القواعد قبل التثبيت.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // الأمان: يجب أن يضمن المتصل تهيئة `self`.
        // هذا يعني أيضًا أن `self` يجب أن يكون متغير `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// يستخرج القيم من صفيف حاويات `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// الأمر متروك للمتصل لضمان أن جميع عناصر المصفوفة في حالة تهيئة.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // الأمان: الآن آمن حيث قمنا بتهيئة جميع العناصر
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * يضمن المتصل تهيئة جميع عناصر المصفوفة
        // * `MaybeUninit<T>` و T مضمون أن يكون لهما نفس التصميم
        // * ربما لا تسقط ربما Unint ، لذلك لا توجد عمليات تحرير مزدوجة وبالتالي يكون التحويل آمنًا
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// بافتراض أن جميع العناصر قد تمت تهيئتها ، احصل على شريحة لها.
    ///
    /// # Safety
    ///
    /// الأمر متروك للمتصل لضمان أن عناصر `MaybeUninit<T>` بالفعل في حالة تهيئة.
    ///
    /// يؤدي استدعاء هذا عندما لا تتم تهيئة المحتوى بالكامل بعد إلى حدوث سلوك غير محدد.
    ///
    /// راجع [`assume_init_ref`] لمزيد من التفاصيل والأمثلة.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // الأمان: يعد إرسال شريحة إلى `*const [T]` آمنًا لأن المتصل يضمن ذلك
        // `slice` مهيأ ، ويضمن أن يكون لـ "ربما تكون غير منتهية" نفس تخطيط `T`.
        // المؤشر الذي تم الحصول عليه صالح لأنه يشير إلى الذاكرة المملوكة لـ `slice` والتي تعد مرجعًا وبالتالي فهي مضمونة لتكون صالحة للقراءات.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// بافتراض أن جميع العناصر قد تمت تهيئتها ، احصل على شريحة قابلة للتغيير.
    ///
    /// # Safety
    ///
    /// الأمر متروك للمتصل لضمان أن عناصر `MaybeUninit<T>` بالفعل في حالة تهيئة.
    ///
    /// يؤدي استدعاء هذا عندما لا تتم تهيئة المحتوى بالكامل بعد إلى حدوث سلوك غير محدد.
    ///
    /// راجع [`assume_init_mut`] لمزيد من التفاصيل والأمثلة.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // الأمان: مشابه لملاحظات الأمان الخاصة بـ `slice_get_ref` ، ولكن لدينا ملف
        // مرجع قابل للتغيير وهو مضمون أيضًا ليكون صالحًا للكتابات.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// الحصول على مؤشر للعنصر الأول من المصفوفة.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// الحصول على مؤشر قابل للتغيير للعنصر الأول من المصفوفة.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// ينسخ العناصر من `src` إلى `this` ، ويعيد مرجعًا متغيرًا إلى محتويات `this` التي تم تنشيطها الآن.
    ///
    /// إذا لم يقم `T` بتطبيق `Copy` ، فاستخدم [`write_slice_cloned`]
    ///
    /// هذا مشابه لـ [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// هذه الوظيفة سوف panic إذا كان للشريحتين أطوال مختلفة.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // الأمان: لقد قمنا للتو بنسخ جميع عناصر لين في السعة الاحتياطية
    /// // عناصر src.len() الأولى من vec صالحة الآن.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // الأمان: &[T] و&[ربما Uninit<T>] لها نفس التخطيط
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // الأمان: تم نسخ العناصر الصالحة إلى `this` حتى يتم تنشيطها
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// يستنسخ العناصر من `src` إلى `this` ، ويعيد مرجعًا متغيرًا إلى محتويات `this` التي تم تنشيطها الآن.
    /// لن يتم إسقاط أي عناصر تم تنشيطها بالفعل.
    ///
    /// إذا كان `T` يطبق `Copy` ، فاستخدم [`write_slice`]
    ///
    /// هذا مشابه لـ [`slice::clone_from_slice`] ولكنه لا يسقط العناصر الموجودة.
    ///
    /// # Panics
    ///
    /// هذه الوظيفة سوف panic إذا كان للشريحتين أطوال مختلفة ، أو إذا كان تنفيذ `Clone` panics.
    ///
    /// إذا كان هناك panic ، فسيتم إسقاط العناصر المستنسخة بالفعل.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // السلامة: لقد قمنا للتو باستنساخ جميع عناصر لين في السعة الاحتياطية
    /// // عناصر src.len() الأولى من vec صالحة الآن.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // على عكس copy_from_slice ، فإن هذا لا يستدعي clone_from_slice على الشريحة ، وذلك لأن `MaybeUninit<T: Clone>` لا يقوم بتطبيق Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // الأمان: ستحتوي هذه الشريحة الأولية فقط على كائنات مهيأة
                // لهذا السبب ، يُسمح بإسقاطها.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: نحن بحاجة إلى قطعها صراحة بنفس الطول
        // لإلغاء فحص الحدود ، سيقوم المُحسِّن بإنشاء memcpy للحالات البسيطة (على سبيل المثال T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // هناك حاجة إلى حارس قد يحدث b/c panic أثناء الاستنساخ
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // الأمان: تمت كتابة العناصر الصالحة في `this` حتى يتم تنشيطها
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}