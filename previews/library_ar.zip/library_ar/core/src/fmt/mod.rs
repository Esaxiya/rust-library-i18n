//! أدوات لتنسيق وطباعة السلاسل.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// تم إرجاع المحاذاة المحتملة بواسطة `Formatter::align`
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// الإشارة إلى ضرورة محاذاة المحتويات إلى اليسار.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// الإشارة إلى أن المحتويات يجب أن تكون محاذية لليمين.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// الإشارة إلى وجوب محاذاة المحتويات إلى المنتصف.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// النوع الذي تم إرجاعه بواسطة طرق المنسق.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// نوع الخطأ الذي يتم إرجاعه من تنسيق رسالة في دفق.
///
/// لا يدعم هذا النوع إرسال خطأ بخلاف ذلك الخطأ الذي حدث.
/// يجب ترتيب أي معلومات إضافية ليتم نقلها من خلال بعض الوسائل الأخرى.
///
/// الشيء المهم الذي يجب تذكره هو أنه لا ينبغي الخلط بين النوع `fmt::Error` و [`std::io::Error`] أو [`std::error::Error`] ، وهو ما قد يكون لديك أيضًا في النطاق.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// trait للكتابة أو التنسيق في المخازن المؤقتة أو التدفقات التي تقبل Unicode.
///
/// لا يقبل trait هذا إلا البيانات المشفرة UTF-8 وليس [flushable].
/// إذا كنت تريد قبول Unicode فقط ولا تحتاج إلى التنظيف ، فيجب عليك تنفيذ trait ؛
/// وإلا يجب عليك تنفيذ [`std::io::Write`].
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// يكتب شريحة سلسلة في هذا الكاتب ، ويعيد ما إذا كانت الكتابة قد نجحت.
    ///
    /// لا يمكن أن تنجح هذه الطريقة إلا إذا تمت كتابة شريحة السلسلة بأكملها بنجاح ، ولن يتم إرجاع هذه الطريقة حتى تتم كتابة جميع البيانات أو حدوث خطأ.
    ///
    ///
    /// # Errors
    ///
    /// ستعيد هذه الوظيفة مثيل [`Error`] عند حدوث خطأ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// يكتب [`char`] في هذا الكاتب ، ويعيد ما إذا كانت الكتابة قد نجحت.
    ///
    /// يمكن ترميز [`char`] واحد على أنه أكثر من بايت واحد.
    /// لا يمكن أن تنجح هذه الطريقة إلا إذا تمت كتابة تسلسل البايت بأكمله بنجاح ، ولن يتم إرجاع هذه الطريقة حتى تتم كتابة جميع البيانات أو حدوث خطأ.
    ///
    ///
    /// # Errors
    ///
    /// ستعيد هذه الوظيفة مثيل [`Error`] عند حدوث خطأ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// صمغ لاستخدام الماكرو [`write!`] مع منفذي trait.
    ///
    /// يجب عمومًا عدم استدعاء هذه الطريقة يدويًا ، ولكن من خلال الماكرو [`write!`] نفسه.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// التكوين من أجل التنسيق.
///
/// يمثل `Formatter` خيارات متنوعة متعلقة بالتنسيق.
/// لا يقوم المستخدمون بتكوين "المنسق" مباشرةً ؛يتم تمرير إشارة قابلة للتغيير إلى طريقة `fmt` لجميع التنسيقات traits ، مثل [`Debug`] و [`Display`].
///
///
/// للتفاعل مع `Formatter` ، ستتصل بطرق مختلفة لتغيير الخيارات المختلفة المتعلقة بالتنسيق.
/// للحصول على أمثلة ، يرجى الاطلاع على وثائق الطرق المحددة في `Formatter` أدناه.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// الوسيطة هي في الأساس وظيفة تنسيق مطبقة جزئيًا محسّنة ، تعادل `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result`.

extern "C" {
    type Opaque;
}

/// يمثل هذا الهيكل "argument" العام الذي تأخذه عائلة وظائف Xprintf.يحتوي على وظيفة لتنسيق القيمة المحددة.
/// في وقت الترجمة ، يتم التأكد من أن الوظيفة والقيمة لها الأنواع الصحيحة ، ثم يتم استخدام هذه البنية لتوحيد الحجج لنوع واحد.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// هذا يضمن قيمة ثابتة واحدة لمؤشر الوظيفة المرتبط بـ indices/counts في البنية الأساسية للتنسيق.
//
// لاحظ أن الوظيفة التي تم تعريفها على هذا النحو لن تكون صحيحة حيث يتم دائمًا وضع علامة على الدالات على أنها غير مسماة بالعنوان الحالي لخفض إلى LLVM IR ، لذلك لا يعتبر عنوانها مهمًا لـ LLVM وعلى هذا النحو قد يكون قد تم تجميع ملف as_usize بشكل خاطئ.
//
// في الممارسة العملية ، لا نسمي as_usize على بيانات غير مخصصة للاستخدام (كمسألة توليد ثابت لوسائط التنسيق) ، لذلك هذا مجرد فحص إضافي.
//
// نريد في المقام الأول التأكد من أن مؤشر الوظيفة في `USIZE_MARKER` له عنوان مطابق *فقط* للوظائف التي تأخذ أيضًا `&usize` كوسيطة أولى.
// يضمن read_volatile هنا أنه يمكننا أن نجهز استخدامًا آمنًا من المرجع الذي تم تمريره وأن هذا العنوان لا يشير إلى وظيفة أخذ غير مفيدة.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // السلامة: ptr هو مرجع
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // الأمان: `mem::transmute(x)` آمن لأن
        //     1. `&'b T` يحافظ على العمر الذي نشأ مع `'b` (حتى لا يكون له عمر غير محدود)
        //     2.
        //     `&'b T` و `&'b Opaque` لهما نفس تخطيط الذاكرة (عندما يكون `T` هو `Sized` ، كما هو هنا) `mem::transmute(f)` آمن لأن `fn(&T, &mut Formatter<'_>) -> Result` و `fn(&Opaque, &mut Formatter<'_>) -> Result` لهما نفس ABI (طالما أن `T` هو `Sized`)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // الأمان: يتم تعيين الحقل `formatter` فقط على USIZE_MARKER إذا
            // القيمة هي استخدام ، لذلك هذا آمن
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// تتوفر الأعلام بتنسيق v1 بتنسيق format_args
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// عند استخدام الماكرو format_args! () ، يتم استخدام هذه الوظيفة لإنشاء بنية الوسائط.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// تُستخدم هذه الوظيفة لتحديد معلمات التنسيق غير القياسية.
    /// يجب أن يكون طول صفيف `pieces` على الأقل مثل `fmt` لإنشاء بنية وسيطات صالحة.
    /// أيضًا ، يجب أن يشير أي `Count` داخل `fmt` وهو `CountIsParam` أو `CountIsNextParam` إلى وسيطة تم إنشاؤها باستخدام `argumentusize`.
    ///
    /// ومع ذلك ، فإن عدم القيام بذلك لا يسبب عدم الأمان ، ولكنه سيتجاهل عدم الصلاحية.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// تقدير طول النص المنسق.
    ///
    /// الغرض من هذا هو استخدامه لضبط سعة `String` الأولية عند استخدام `format!`.
    /// Note: هذا ليس الحد الأدنى ولا الأعلى.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // إذا بدأت سلسلة التنسيق بمعامل ، فلا تخصص أي شيء مسبقًا ، ما لم يكن طول القطع كبيرًا.
            //
            //
            0
        } else {
            // هناك بعض الحجج ، لذا فإن أي دفعة إضافية ستعيد تخصيص السلسلة.
            //
            // لتجنب ذلك ، نحن "pre-doubling" السعة هنا.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// تمثل هذه البنية إصدارًا مترجمًا مسبقًا بأمان لسلسلة التنسيق ووسائطها.
/// لا يمكن إنشاء هذا في وقت التشغيل لأنه لا يمكن إجراؤه بأمان ، لذلك لم يتم إعطاء مُنشئ والحقول خاصة لمنع التعديل.
///
///
/// سينشئ الماكرو [`format_args!`] مثيلاً لهذه البنية بأمان.
/// يقوم الماكرو بالتحقق من صحة سلسلة التنسيق في وقت التحويل بحيث يمكن تنفيذ استخدام الدالتين [`write()`] و [`format()`] بأمان.
///
/// يمكنك استخدام `Arguments<'a>` الذي يعرضه [`format_args!`] في سياقات `Debug` و `Display` كما هو موضح أدناه.
/// يوضح المثال أيضًا أن تنسيق `Debug` و `Display` لنفس الشيء: سلسلة التنسيق المحرف في `format_args!`.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // تنسيق قطع السلسلة للطباعة.
    pieces: &'a [&'static str],

    // مواصفات العنصر النائب ، أو `None` إذا كانت جميع المواصفات افتراضية (كما في "{}{}").
    fmt: Option<&'a [rt::v1::Argument]>,

    // الحجج الديناميكية للاستيفاء ، ليتم تشذيرها بقطع الوتر.
    // (كل وسيطة مسبوقة بقطعة سلسلة.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// احصل على السلسلة المنسقة ، إذا لم يكن بها وسيطات ليتم تنسيقها.
    ///
    /// يمكن استخدام هذا لتجنب التخصيصات في أكثر الحالات تافهة.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` يجب تنسيق الإخراج في سياق تصحيح الأخطاء الذي يواجه المبرمج.
///
/// بشكل عام ، يجب عليك فقط تنفيذ `derive` a `Debug`.
///
/// عند استخدامه مع محدد التنسيق البديل `#?` ، يكون الإخراج مطبوعًا بشكل جيد.
///
/// لمزيد من المعلومات حول المُنسِّقات ، راجع [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// يمكن استخدام trait مع `#[derive]` إذا كانت جميع الحقول تنفذ `Debug`.
/// عند `اشتقاق`d للبُنى ، سيستخدم اسم `struct` ، ثم `{` ، ثم قائمة مفصولة بفواصل لاسم كل حقل وقيمة `Debug` ، ثم `}`.
/// بالنسبة لـ `enum`s ، سيستخدم اسم المتغير ، وإن أمكن ، `(` ، ثم قيم `Debug` للحقول ، ثم `)`.
///
/// # Stability
///
/// تنسيقات `Debug` المشتقة ليست مستقرة ، وبالتالي قد تتغير مع إصدارات future Rust.
/// بالإضافة إلى ذلك ، تطبيقات `Debug` للأنواع التي توفرها المكتبة القياسية (`libstd` ، `libcore` ، `liballoc` ، إلخ) ليست مستقرة ، وقد تتغير أيضًا مع إصدارات future Rust.
///
///
/// # Examples
///
/// اشتقاق التنفيذ:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// التنفيذ اليدوي:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// هناك عدد من الطرق المساعدة في هيكل [`Formatter`] لمساعدتك في عمليات التنفيذ اليدوية ، مثل [`debug_struct`].
///
/// `Debug` تدعم التطبيقات التي تستخدم إما `derive` أو API منشئ التصحيح على [`Formatter`] الطباعة الجميلة باستخدام العلم البديل: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// طباعة جميلة باستخدام `#?`:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// ينسق القيمة باستخدام المنسق المحدد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// وحدة منفصلة لإعادة تصدير الماكرو `Debug` من prelude بدون trait `Debug`.
pub(crate) mod macros {
    /// اشتق الماكرو لتوليد إشارة من trait `Debug`.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// تنسيق trait لتنسيق فارغ ، `{}`.
///
/// `Display` يشبه [`Debug`] ، لكن `Display` مخصص للإخراج الذي يواجه المستخدم ، وبالتالي لا يمكن اشتقاقه.
///
///
/// لمزيد من المعلومات حول المُنسِّقات ، راجع [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// تنفيذ `Display` على نوع:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// ينسق القيمة باستخدام المنسق المحدد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// يجب أن يقوم `Octal` trait بتنسيق الإخراج كرقم في base-8.
///
/// بالنسبة للأعداد الصحيحة الأولية الموقعة (`i8` إلى `i128` و `isize`) ، يتم تنسيق القيم السالبة كتمثيل مكمل للاثنين.
///
///
/// تضيف العلامة البديلة ، `#` ، `0o` أمام الإخراج.
///
/// لمزيد من المعلومات حول المُنسِّقات ، راجع [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// الاستخدام الأساسي مع `i32`:
///
/// ```
/// let x = 42; // 42 هو '52' في ثماني
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// تنفيذ `Octal` على نوع:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // مندوب لتنفيذ i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// ينسق القيمة باستخدام المنسق المحدد.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// يجب أن تنسيق `Binary` trait إخراجها كرقم في ثنائي.
///
/// بالنسبة للأعداد الصحيحة الأولية الموقعة ([`i8`] إلى [`i128`] و [`isize`]) ، يتم تنسيق القيم السالبة كتمثيل مكمل للاثنين.
///
///
/// تضيف العلامة البديلة ، `#` ، `0b` أمام الإخراج.
///
/// لمزيد من المعلومات حول المُنسِّقات ، راجع [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// الاستخدام الأساسي مع [`i32`]:
///
/// ```
/// let x = 42; // 42 هو '101010' في ثنائي
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// تنفيذ `Binary` على نوع:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // مندوب لتنفيذ i32
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// ينسق القيمة باستخدام المنسق المحدد.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// يجب أن تنسق `LowerHex` trait إخراجها كرقم سداسي عشري ، مع `a` إلى `f` في حالة الأحرف الصغيرة.
///
/// بالنسبة للأعداد الصحيحة الأولية الموقعة (`i8` إلى `i128` و `isize`) ، يتم تنسيق القيم السالبة كتمثيل مكمل للاثنين.
///
///
/// تضيف العلامة البديلة ، `#` ، `0x` أمام الإخراج.
///
/// لمزيد من المعلومات حول المُنسِّقات ، راجع [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// الاستخدام الأساسي مع `i32`:
///
/// ```
/// let x = 42; // 42 هو '2a' في سداسي عشري
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// تنفيذ `LowerHex` على نوع:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // مندوب لتنفيذ i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// ينسق القيمة باستخدام المنسق المحدد.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// يجب أن تنسق `UpperHex` trait إخراجها كرقم سداسي عشري ، مع `A` إلى `F` في الحالة الكبيرة.
///
/// بالنسبة للأعداد الصحيحة الأولية الموقعة (`i8` إلى `i128` و `isize`) ، يتم تنسيق القيم السالبة كتمثيل مكمل للاثنين.
///
///
/// تضيف العلامة البديلة ، `#` ، `0x` أمام الإخراج.
///
/// لمزيد من المعلومات حول المُنسِّقات ، راجع [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// الاستخدام الأساسي مع `i32`:
///
/// ```
/// let x = 42; // 42 هو '2A' في سداسي عشري
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// تنفيذ `UpperHex` على نوع:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // مندوب لتنفيذ i32
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// ينسق القيمة باستخدام المنسق المحدد.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// يجب أن يقوم `Pointer` trait بتنسيق الإخراج الخاص به كموقع ذاكرة.
/// يتم تقديم هذا بشكل شائع على أنه سداسي عشري.
///
/// لمزيد من المعلومات حول المُنسِّقات ، راجع [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// الاستخدام الأساسي مع `&i32`:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // ينتج عن هذا شيء مثل '0x7f06092ac6d0'
/// ```
///
/// تنفيذ `Pointer` على نوع:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // استخدم `as` للتحويل إلى `*const T` ، والذي يقوم بتنفيذ Pointer ، والذي يمكننا استخدامه
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// ينسق القيمة باستخدام المنسق المحدد.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// يجب أن يقوم `LowerExp` trait بتنسيق مخرجاته بترميز علمي باستخدام حالة الأحرف الصغيرة `e`.
///
/// لمزيد من المعلومات حول المُنسِّقات ، راجع [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// الاستخدام الأساسي مع `f64`:
///
/// ```
/// let x = 42.0; // 42.0 هو '4.2e1' في التدوين العلمي
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// تنفيذ `LowerExp` على نوع:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // مندوب لتنفيذ f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// ينسق القيمة باستخدام المنسق المحدد.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// يجب أن يقوم `UpperExp` trait بتنسيق مخرجاته بترميز علمي باستخدام الأحرف الكبيرة `E`.
///
/// لمزيد من المعلومات حول المُنسِّقات ، راجع [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// الاستخدام الأساسي مع `f64`:
///
/// ```
/// let x = 42.0; // 42.0 هو '4.2E1' في التدوين العلمي
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// تنفيذ `UpperExp` على نوع:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // مندوب لتنفيذ f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// ينسق القيمة باستخدام المنسق المحدد.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// تأخذ الدالة `write` دفق إخراج ، وبنية `Arguments` يمكن تجميعها مسبقًا باستخدام ماكرو `format_args!`.
///
///
/// سيتم تنسيق الوسائط وفقًا لسلسلة التنسيق المحددة في تدفق الإخراج المقدم.
///
/// # Examples
///
/// الاستخدام الأساسي:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// يرجى ملاحظة أن استخدام [`write!`] قد يكون من الأفضل.مثال:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // يمكننا استخدام معلمات التنسيق الافتراضية لجميع الوسائط.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // كل مواصفات لها وسيطة مقابلة مسبوقة بقطعة سلسلة.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // الأمان: يأتي arg و args.args من نفس الوسيطات ،
                // مما يضمن أن تكون الفهارس ضمن الحدود دائمًا.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // لا يمكن أن يكون هناك سوى قطعة سلسلة زائدة واحدة متبقية.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // السلامة: تأتي الحجج والجدل من نفس الحجج ،
    // مما يضمن أن تكون الفهارس ضمن الحدود دائمًا.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // استخرج الوسيطة الصحيحة
    debug_assert!(arg.position < args.len());
    // السلامة: تأتي الحجج والجدل من نفس الحجج ،
    // مما يضمن أن يكون فهرسها دائمًا ضمن الحدود.
    let value = unsafe { args.get_unchecked(arg.position) };

    // ثم فعل بعض الطباعة
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // السلامة: cnt و args تأتيان من نفس الحجج ،
            // مما يضمن أن يكون هذا الفهرس دائمًا ضمن الحدود.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// الحشو بعد نهاية شيء ما.تم إرجاعه بواسطة `Formatter::padding`.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// اكتب هذا الحشو بعد.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // نريد تغيير هذا
            buf: wrap(self.buf),

            // وتحافظ على هذه
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // الأساليب المساعدة المستخدمة في الحشو ومعالجة وسيطات التنسيق التي يمكن أن تستخدمها جميع التنسيقات traits.
    //

    /// تنفيذ المساحة المتروكة الصحيحة لعدد صحيح تم إرساله بالفعل إلى سلسلة.
    /// يجب أن *لا* تحتوي السلسلة على علامة العدد الصحيح الذي سيتم إضافته بواسطة هذه الطريقة.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative ، سواء كان العدد الصحيح الأصلي موجبًا أو صفرًا.
    /// * البادئة ، إذا تم توفير الحرف '#' (Alternate) ، فهذه هي البادئة التي يجب وضعها أمام الرقم.
    ///
    /// * buf ، صفيف البايت الذي تم تنسيق الرقم فيه
    ///
    /// ستحسب هذه الوظيفة بشكل صحيح العلامات المقدمة بالإضافة إلى الحد الأدنى للعرض.
    /// لن تأخذ الدقة في الاعتبار.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // نحتاج إلى إزالة "-" من إخراج الرقم.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // يكتب العلامة إذا كانت موجودة ، ثم البادئة إذا طُلب ذلك
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // يعد الحقل `width` أكثر من معلمة `min-width` في هذه المرحلة.
        match self.width {
            // إذا لم يكن هناك حد أدنى لمتطلبات الطول ، فيمكننا كتابة البايت فقط.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // تحقق مما إذا كنا فوق الحد الأدنى للعرض ، إذا كان الأمر كذلك ، فيمكننا أيضًا كتابة البايت.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // تظهر الإشارة والبادئة قبل المساحة المتروكة إذا كان حرف التعبئة صفرًا
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // خلاف ذلك ، فإن العلامة والبادئة تذهب بعد المساحة المتروكة
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// تأخذ هذه الوظيفة شريحة سلسلة وترسلها إلى المخزن المؤقت الداخلي بعد تطبيق علامات التنسيق ذات الصلة المحددة.
    /// العلامات المعترف بها للسلاسل العامة هي:
    ///
    /// * العرض ، الحد الأدنى لعرض ما ينبعث
    /// * fill/align - ما الذي يجب إرساله وأين يتم إرساله إذا كانت السلسلة المقدمة بحاجة إلى أن تكون مبطنة
    /// * الدقة ، أقصى طول للإصدار ، يتم قطع السلسلة إذا كانت أطول من هذا الطول
    ///
    /// وتجدر الإشارة إلى أن هذه الوظيفة تتجاهل معلمات `flag`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // تأكد من وجود مسار سريع في المقدمة
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // يمكن تفسير الحقل `precision` على أنه `max-width` للسلسلة التي يتم تنسيقها.
        //
        let s = if let Some(max) = self.precision {
            // إذا كانت الخيط الخاص بنا أطول من الدقة ، فيجب أن يكون لدينا اقتطاع.
            // ومع ذلك ، يجب أن تعمل العلامات الأخرى مثل `fill` و `width` و `align` كما هو الحال دائمًا.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // لا يمكن لـ LLVM هنا إثبات أن `..i` لن يكون panic `&s[..i]` ، لكننا نعلم أنه لا يمكن لـ panic.
                // استخدم `get` + `unwrap_or` لتجنب `unsafe` وإلا فلا ترسل أي رمز متعلق بـ panic هنا.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // يعد الحقل `width` أكثر من معلمة `min-width` في هذه المرحلة.
        match self.width {
            // إذا كنا تحت الحد الأقصى للطول ، ولا توجد متطلبات حد أدنى للطول ، فيمكننا فقط إرسال السلسلة
            //
            None => self.buf.write_str(s),
            // إذا كنا تحت الحد الأقصى للعرض ، فتحقق مما إذا كنا تجاوزنا الحد الأدنى للعرض ، وإذا كان الأمر كذلك ، فسيكون ذلك سهلاً مثل إصدار السلسلة.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // إذا كنا أقل من الحد الأقصى والحد الأدنى للعرض ، فقم بملء الحد الأدنى للعرض بالسلسلة المحددة + بعض المحاذاة.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// اكتب الحشو المسبق وأعد الحشو اللاحق غير المكتوب.
    /// المتصلون مسؤولون عن ضمان كتابة الحشو اللاحق بعد الشيء المبطّن.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// يأخذ الأجزاء المنسقة ويطبق المساحة المتروكة.
    /// يفترض أن المتصل قد قدم بالفعل الأجزاء بالدقة المطلوبة ، بحيث يمكن تجاهل `self.precision`.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // بالنسبة إلى المساحة المتروكة للصفر ، فإننا نعرض العلامة أولاً ونتصرف كما لو لم يكن لدينا أي علامة من البداية.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // علامة تذهب دائما أولا
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // قم بإزالة العلامة من الأجزاء المنسقة
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // الأجزاء المتبقية تمر بعملية الحشو العادية.
            let len = formatted.len();
            let ret = if width <= len {
                // لا حشوة
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // هذه هي الحالة الشائعة ونأخذ اختصارًا
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // الأمان: يستخدم هذا في `flt2dec::Part::Num` و `flt2dec::Part::Copy`.
            // من الآمن استخدام `flt2dec::Part::Num` لأن كل حرف `c` يقع بين `b'0'` و `b'9'` ، مما يعني أن `s` صالح UTF-8.
            // من المحتمل أيضًا أن يكون استخدام `flt2dec::Part::Copy(buf)` آمنًا من الناحية العملية نظرًا لأن `buf` يجب أن يكون ASCII عاديًا ، ولكن من الممكن أن يقوم شخص ما بتمرير قيمة سيئة لـ `buf` إلى `flt2dec::to_shortest_str` لأنها وظيفة عامة.
            //
            // FIXME: حدد ما إذا كان هذا يمكن أن يؤدي إلى UB.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 صفرًا
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// يكتب بعض البيانات إلى المخزن المؤقت الأساسي الموجود داخل هذا المنسق.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // هذا يعادل:
    ///         // اكتب! (المنسق ، "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// يكتب بعض المعلومات المنسقة في هذا المثال.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// إشارات للتنسيق
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// الحرف المستخدم كـ 'fill' كلما كان هناك محاذاة.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // وضعنا المحاذاة إلى اليمين مع ">".
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// علامة تشير إلى شكل المحاذاة المطلوب.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// اختياريا عرض عدد صحيح يجب أن يكون الناتج.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // إذا تلقينا عرضًا ، فإننا نستخدمه
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // وإلا فإننا لا نفعل شيئًا مميزًا
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// الدقة المحددة اختياريًا للأنواع الرقمية.
    /// بدلاً من ذلك ، أقصى عرض لأنواع السلسلة.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // إذا تلقينا دقة ، فإننا نستخدمها.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // وإلا فإننا افتراضيًا على 2.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// تحديد ما إذا كان قد تم تحديد علامة `+`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// تحديد ما إذا كان قد تم تحديد علامة `-`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // تريد علامة ناقص؟لديك واحدة!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// تحديد ما إذا كان قد تم تحديد علامة `#`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// تحديد ما إذا كان قد تم تحديد علامة `0`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // نتجاهل خيارات المنسق.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: حدد واجهة برمجة التطبيقات العامة التي نريدها لهاتين العلامتين.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// ينشئ مُنشئ [`DebugStruct`] مصممًا للمساعدة في إنشاء تطبيقات [`fmt::Debug`] للهياكل.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// ينشئ مُنشئ `DebugTuple` مصممًا للمساعدة في إنشاء تطبيقات `fmt::Debug` لهياكل المجموعات.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// ينشئ مُنشئ `DebugList` مصممًا للمساعدة في إنشاء تطبيقات `fmt::Debug` لهياكل تشبه القائمة.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// ينشئ مُنشئ `DebugSet` مصممًا للمساعدة في إنشاء تطبيقات `fmt::Debug` لهياكل تشبه المجموعة.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// في هذا المثال الأكثر تعقيدًا ، نستخدم [`format_args!`] و `.debug_set()` لإنشاء قائمة بأذرع التطابق:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// ينشئ مُنشئ `DebugMap` مصممًا للمساعدة في إنشاء تطبيقات `fmt::Debug` للهياكل الشبيهة بالخريطة.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// تطبيقات التنسيق الأساسي traits

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // إذا احتاج الحرف إلى الهروب ، فقم بالتدفق المتراكم حتى الآن واكتب ، وإلا تخطي
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // يتم التعامل مع العلامة البديلة بالفعل بواسطة LowerHex على أنها خاصة-فهي تشير إلى ما إذا كان سيتم البادئة بـ 0x.
        // نستخدمها لمعرفة ما إذا كان سيتم تمديد الصفر أم لا ، ثم نضبطه دون قيد أو شرط للحصول على البادئة.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// تنفيذ Display/Debug لأنواع أساسية مختلفة

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // يتم استعارة RefCell بشكل متبادل لذلك لا يمكننا النظر إلى قيمتها هنا.
                // أظهر عنصرًا نائبًا بدلاً من ذلك.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// إذا كنت تتوقع أن تكون الاختبارات هنا ، فابحث بدلاً من ذلك في ملف core/tests/fmt.rs ، فهو أسهل كثيرًا من إنشاء جميع هياكل rt::Piece هنا.
//
// كما توجد اختبارات في crate لمن يحتاجون تخصيصات.