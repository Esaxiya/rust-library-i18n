//! هذه وحدة داخلية يستخدمها ifmt!مدة العرض.يتم إرسال هذه الهياكل إلى مصفوفات ثابتة لتجميع سلاسل التنسيق مسبقًا في وقت مبكر.
//!
//! تشبه هذه التعريفات معادلاتها `ct` ، ولكنها تختلف من حيث أنه يمكن تخصيصها بشكل ثابت وتم تحسينها قليلاً لوقت التشغيل
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// المحاذاة المحتملة التي يمكن طلبها كجزء من توجيه التنسيق.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// الإشارة إلى ضرورة محاذاة المحتويات إلى اليسار.
    Left,
    /// الإشارة إلى أن المحتويات يجب أن تكون محاذية لليمين.
    Right,
    /// الإشارة إلى وجوب محاذاة المحتويات إلى المنتصف.
    Center,
    /// لم يتم طلب محاذاة.
    Unknown,
}

/// تستخدم بواسطة محددات [width](https://doc.rust-lang.org/std/fmt/#width) و [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// المحدد برقم حرفي ، يخزن القيمة
    Is(usize),
    /// المحدد باستخدام صيغ `$` و `*` ، يخزن الفهرس في `args`
    Param(usize),
    /// غير محدد
    Implied,
}