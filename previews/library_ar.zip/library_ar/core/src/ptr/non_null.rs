use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` لكن غير صفري ومتغير.
///
/// غالبًا ما يكون هذا هو الشيء الصحيح الذي يجب استخدامه عند إنشاء هياكل البيانات باستخدام المؤشرات الأولية ، ولكنه في النهاية أكثر خطورة في الاستخدام بسبب خصائصه الإضافية.إذا لم تكن متأكدًا مما إذا كان يجب عليك استخدام `NonNull<T>` ، فما عليك سوى استخدام `*mut T`!
///
/// على عكس `*mut T` ، يجب أن يكون المؤشر دائمًا غير فارغ ، حتى إذا لم يتم إلغاء الإشارة إلى المؤشر مطلقًا.هذا حتى يمكن للتعدادات استخدام هذه القيمة المحظورة كمميز-`Option<NonNull<T>>` له نفس حجم `* mut T`.
/// ومع ذلك ، قد يظل المؤشر متدليًا إذا لم يتم إلغاء الإشارة إليه.
///
/// على عكس `*mut T` ، تم اختيار `NonNull<T>` ليكون متغيرًا على `T`.هذا يجعل من الممكن استخدام `NonNull<T>` عند بناء أنواع متغيرة ، ولكنه يعرض مخاطر عدم السلامة إذا تم استخدامه في نوع لا ينبغي أن يكون متغيرًا في الواقع.
/// (تم إجراء الخيار المعاكس لـ `*mut T` على الرغم من أنه من الناحية الفنية لا يمكن إلا أن يكون سبب عدم السلامة هو استدعاء وظائف غير آمنة.
///
/// التباين الصحيح لمعظم التجريدات الآمنة ، مثل `Box` و `Rc` و `Arc` و `Vec` و `LinkedList`.هذه هي الحالة لأنها توفر واجهة برمجة تطبيقات عامة تتبع قواعد XOR المشتركة العادية القابلة للتغيير في Rust.
///
/// إذا كان لا يمكن أن يكون النوع الخاص بك متغيرًا بأمان ، فيجب عليك التأكد من أنه يحتوي على بعض الحقول الإضافية لتوفير الثبات.غالبًا ما يكون هذا الحقل من النوع [`PhantomData`] مثل `PhantomData<Cell<T>>` أو `PhantomData<&'a mut T>`.
///
/// لاحظ أن `NonNull<T>` به مثيل `From` لـ `&T`.ومع ذلك ، فإن هذا لا يغير حقيقة أن التحور من خلال (مؤشر مشتق من) مرجع مشترك هو سلوك غير محدد ما لم تحدث الطفرة داخل [`UnsafeCell<T>`].الشيء نفسه ينطبق على إنشاء مرجع متغير من مرجع مشترك.
///
/// عند استخدام مثيل `From` هذا بدون `UnsafeCell<T>` ، تقع على عاتقك مسؤولية التأكد من عدم استدعاء `as_mut` مطلقًا ، وعدم استخدام `as_ptr` مطلقًا للطفرة.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` المؤشرات ليست `Send` لأن البيانات التي تشير إليها قد تكون مستعارة.
// ملاحظة: هذا الضمني غير ضروري ، ولكن يجب أن يوفر رسائل خطأ أفضل.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` المؤشرات ليست `Sync` لأن البيانات التي تشير إليها قد تكون مستعارة.
// ملاحظة: هذا الضمني غير ضروري ، ولكن يجب أن يوفر رسائل خطأ أفضل.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// يُنشئ `NonNull` جديدًا متدليًا ، ولكنه متناسق جيدًا.
    ///
    /// هذا مفيد لتهيئة الأنواع التي تخصص بتكاسل ، كما يفعل `Vec::new`.
    ///
    /// لاحظ أن قيمة المؤشر قد تمثل مؤشرًا صالحًا لـ `T` ، مما يعني أنه لا يجب استخدام هذا كقيمة خفر "not yet initialized".
    /// يجب أن تتبع الأنواع التي تخصصها بتكاسل التهيئة من خلال بعض الوسائل الأخرى.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // الأمان: يُرجع mem::align_of() استخدامًا غير صفري يتم بعد ذلك تحويله
        // إلى a * mut T.
        // لذلك ، `ptr` ليس فارغًا ويتم احترام شروط استدعاء new_unchecked().
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// إرجاع مراجع مشتركة إلى القيمة.على عكس [`as_ref`] ، لا يتطلب هذا تهيئة القيمة.
    ///
    /// للنظير المتغير ، انظر [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// عند استدعاء هذه الطريقة ، عليك التأكد من صحة كل ما يلي:
    ///
    /// * يجب محاذاة المؤشر بشكل صحيح.
    ///
    /// * يجب أن يكون "dereferencable" بالمعنى المحدد في [the module documentation].
    ///
    /// * يجب عليك فرض قواعد التسمية المستعارة الخاصة بـ Rust ، حيث يتم اختيار العمر الذي تم إرجاعه `'a` بشكل تعسفي ولا يعكس بالضرورة العمر الفعلي للبيانات.
    ///
    ///   على وجه الخصوص ، طوال مدة هذه الحياة ، يجب ألا يتم تحور الذاكرة التي يشير إليها المؤشر (باستثناء داخل `UnsafeCell`).
    ///
    /// وينطبق هذا حتى لو كانت نتيجة هذه الطريقة غير مستخدمة!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // الأمان: يجب أن يضمن المتصل أن `self` يلبي جميع
        // متطلبات كمرجع.
        unsafe { &*self.cast().as_ptr() }
    }

    /// إرجاع مراجع فريدة للقيمة.على عكس [`as_mut`] ، لا يتطلب هذا تهيئة القيمة.
    ///
    /// للنظير المشترك انظر [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// عند استدعاء هذه الطريقة ، عليك التأكد من صحة كل ما يلي:
    ///
    /// * يجب محاذاة المؤشر بشكل صحيح.
    ///
    /// * يجب أن يكون "dereferencable" بالمعنى المحدد في [the module documentation].
    ///
    /// * يجب عليك فرض قواعد التسمية المستعارة الخاصة بـ Rust ، حيث يتم اختيار العمر الذي تم إرجاعه `'a` بشكل تعسفي ولا يعكس بالضرورة العمر الفعلي للبيانات.
    ///
    ///   على وجه الخصوص ، طوال مدة هذه الحياة ، يجب ألا يتم الوصول إلى الذاكرة التي يشير إليها المؤشر (قراءتها أو كتابتها) من خلال أي مؤشر آخر.
    ///
    /// وينطبق هذا حتى لو كانت نتيجة هذه الطريقة غير مستخدمة!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // الأمان: يجب أن يضمن المتصل أن `self` يلبي جميع
        // متطلبات كمرجع.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// ينشئ `NonNull` جديد.
    ///
    /// # Safety
    ///
    /// `ptr` يجب أن يكون غير فارغ.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // الأمان: يجب أن يضمن المتصل أن `ptr` غير فارغة.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// ينشئ `NonNull` جديدًا إذا كان `ptr` غير فارغ.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // الأمان: تم تحديد المؤشر بالفعل وليس فارغًا
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// يؤدي نفس الوظيفة مثل [`std::ptr::from_raw_parts`] ، باستثناء أنه يتم إرجاع مؤشر `NonNull` ، بدلاً من مؤشر `*const` الأولي.
    ///
    ///
    /// راجع وثائق [`std::ptr::from_raw_parts`] لمزيد من التفاصيل.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // الأمان: نتيجة `ptr::from::raw_parts_mut` غير خالية لأن `data_address` هي.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// حلل مؤشر (ربما واسع) إلى مكونات العنوان وبيانات التعريف.
    ///
    /// يمكن إعادة إنشاء المؤشر لاحقًا باستخدام [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// يكتسب المؤشر `*mut` الأساسي.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// إرجاع مرجع مشترك إلى القيمة.إذا كانت القيمة غير مهيأة ، فيجب استخدام [`as_uninit_ref`] بدلاً من ذلك.
    ///
    /// للنظير المتغير ، انظر [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// عند استدعاء هذه الطريقة ، عليك التأكد من صحة كل ما يلي:
    ///
    /// * يجب محاذاة المؤشر بشكل صحيح.
    ///
    /// * يجب أن يكون "dereferencable" بالمعنى المحدد في [the module documentation].
    ///
    /// * يجب أن يشير المؤشر إلى مثيل مهيأ لـ `T`.
    ///
    /// * يجب عليك فرض قواعد التسمية المستعارة الخاصة بـ Rust ، حيث يتم اختيار العمر الذي تم إرجاعه `'a` بشكل تعسفي ولا يعكس بالضرورة العمر الفعلي للبيانات.
    ///
    ///   على وجه الخصوص ، طوال مدة هذه الحياة ، يجب ألا يتم تحور الذاكرة التي يشير إليها المؤشر (باستثناء داخل `UnsafeCell`).
    ///
    /// وينطبق هذا حتى لو كانت نتيجة هذه الطريقة غير مستخدمة!
    /// (لم يتم تحديد الجزء المتعلق بالتهيئة بالكامل بعد ، ولكن حتى يتم ذلك ، فإن الطريقة الآمنة الوحيدة هي التأكد من أنها قد تمت تهيئتها بالفعل).
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // الأمان: يجب أن يضمن المتصل أن `self` يلبي جميع
        // متطلبات كمرجع.
        unsafe { &*self.as_ptr() }
    }

    /// إرجاع مرجع فريد للقيمة.إذا كانت القيمة غير مهيأة ، فيجب استخدام [`as_uninit_mut`] بدلاً من ذلك.
    ///
    /// للنظير المشترك انظر [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// عند استدعاء هذه الطريقة ، عليك التأكد من صحة كل ما يلي:
    ///
    /// * يجب محاذاة المؤشر بشكل صحيح.
    ///
    /// * يجب أن يكون "dereferencable" بالمعنى المحدد في [the module documentation].
    ///
    /// * يجب أن يشير المؤشر إلى مثيل مهيأ لـ `T`.
    ///
    /// * يجب عليك فرض قواعد التسمية المستعارة الخاصة بـ Rust ، حيث يتم اختيار العمر الذي تم إرجاعه `'a` بشكل تعسفي ولا يعكس بالضرورة العمر الفعلي للبيانات.
    ///
    ///   على وجه الخصوص ، طوال مدة هذه الحياة ، يجب ألا يتم الوصول إلى الذاكرة التي يشير إليها المؤشر (قراءتها أو كتابتها) من خلال أي مؤشر آخر.
    ///
    /// وينطبق هذا حتى لو كانت نتيجة هذه الطريقة غير مستخدمة!
    /// (لم يتم تحديد الجزء المتعلق بالتهيئة بالكامل بعد ، ولكن حتى يتم ذلك ، فإن الطريقة الآمنة الوحيدة هي التأكد من أنها قد تمت تهيئتها بالفعل).
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // الأمان: يجب أن يضمن المتصل أن `self` يلبي جميع
        // متطلبات مرجعية قابلة للتغيير.
        unsafe { &mut *self.as_ptr() }
    }

    /// يلقي بمؤشر من نوع آخر.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // الأمان: `self` هو مؤشر `NonNull` وهو بالضرورة غير فارغ
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// ينشئ شريحة خام غير فارغة من مؤشر رفيع وطول.
    ///
    /// الوسيطة `len` هي عدد **العناصر**، وليس عدد البايت.
    ///
    /// هذه الوظيفة آمنة ، لكن إلغاء الإشارة إلى قيمة الإرجاع غير آمن.
    /// راجع وثائق [`slice::from_raw_parts`] للتعرف على متطلبات أمان الشريحة.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // قم بإنشاء مؤشر شريحة عند البدء بمؤشر للعنصر الأول
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (لاحظ أن هذا المثال يوضح بشكل مصطنع استخدام هذه الطريقة ، ولكن `دع الشريحة= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // الأمان: `data` هو مؤشر `NonNull` وهو بالضرورة غير فارغ
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// تُرجع طول شريحة خام غير خالية.
    ///
    /// القيمة التي تم إرجاعها هي عدد **العناصر**، وليس عدد البايت.
    ///
    /// هذه الوظيفة آمنة ، حتى عندما لا يمكن إلغاء الإشارة إلى شريحة أولية غير فارغة إلى شريحة لأن المؤشر ليس له عنوان صالح.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// إرجاع مؤشر غير فارغ إلى المخزن المؤقت للشريحة.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // الأمان: نعلم أن `self` غير فارغ.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// إرجاع مؤشر خام إلى المخزن المؤقت للشريحة.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// إرجاع مرجع مشترك إلى شريحة من القيم غير المهيأة على الأرجح.على عكس [`as_ref`] ، لا يتطلب هذا تهيئة القيمة.
    ///
    /// للنظير المتغير ، انظر [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// عند استدعاء هذه الطريقة ، عليك التأكد من صحة كل ما يلي:
    ///
    /// * يجب أن يكون المؤشر [valid] للقراءات لـ `ptr.len() * mem::size_of::<T>()` العديد من البايت ، ويجب محاذاته بشكل صحيح.وهذا يعني على وجه الخصوص:
    ///
    ///     * يجب احتواء نطاق الذاكرة الكامل لهذه الشريحة في كائن مخصص واحد!
    ///       لا يمكن للشرائح أبدًا أن تمتد عبر كائنات مخصصة متعددة.
    ///
    ///     * يجب محاذاة المؤشر حتى بالنسبة للشرائح ذات الطول الصفري.
    ///     أحد أسباب ذلك هو أن تحسينات تخطيط التعداد قد تعتمد على محاذاة المراجع (بما في ذلك الشرائح من أي طول) وغير الفارغة لتمييزها عن البيانات الأخرى.
    ///
    ///     يمكنك الحصول على مؤشر يمكن استخدامه مثل `data` للشرائح ذات الطول الصفري باستخدام [`NonNull::dangling()`].
    ///
    /// * يجب ألا يزيد الحجم الإجمالي للشريحة `ptr.len() * mem::size_of::<T>()` عن `isize::MAX`.
    ///   راجع وثائق الأمان الخاصة بـ [`pointer::offset`].
    ///
    /// * يجب عليك فرض قواعد التسمية المستعارة الخاصة بـ Rust ، حيث يتم اختيار العمر الذي تم إرجاعه `'a` بشكل تعسفي ولا يعكس بالضرورة العمر الفعلي للبيانات.
    ///   على وجه الخصوص ، طوال مدة هذه الحياة ، يجب ألا يتم تحور الذاكرة التي يشير إليها المؤشر (باستثناء داخل `UnsafeCell`).
    ///
    /// وينطبق هذا حتى لو كانت نتيجة هذه الطريقة غير مستخدمة!
    ///
    /// راجع أيضًا [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// إرجاع مرجع فريد إلى شريحة من القيم غير المهيأة على الأرجح.على عكس [`as_mut`] ، لا يتطلب هذا تهيئة القيمة.
    ///
    /// للنظير المشترك انظر [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// عند استدعاء هذه الطريقة ، عليك التأكد من صحة كل ما يلي:
    ///
    /// * يجب أن يكون المؤشر [valid] للقراءة والكتابة لـ `ptr.len() * mem::size_of::<T>()` العديد من البايت ، ويجب محاذاته بشكل صحيح.وهذا يعني على وجه الخصوص:
    ///
    ///     * يجب احتواء نطاق الذاكرة الكامل لهذه الشريحة في كائن مخصص واحد!
    ///       لا يمكن للشرائح أبدًا أن تمتد عبر كائنات مخصصة متعددة.
    ///
    ///     * يجب محاذاة المؤشر حتى بالنسبة للشرائح ذات الطول الصفري.
    ///     أحد أسباب ذلك هو أن تحسينات تخطيط التعداد قد تعتمد على محاذاة المراجع (بما في ذلك الشرائح من أي طول) وغير الفارغة لتمييزها عن البيانات الأخرى.
    ///
    ///     يمكنك الحصول على مؤشر يمكن استخدامه مثل `data` للشرائح ذات الطول الصفري باستخدام [`NonNull::dangling()`].
    ///
    /// * يجب ألا يزيد الحجم الإجمالي للشريحة `ptr.len() * mem::size_of::<T>()` عن `isize::MAX`.
    ///   راجع وثائق الأمان الخاصة بـ [`pointer::offset`].
    ///
    /// * يجب عليك فرض قواعد التسمية المستعارة الخاصة بـ Rust ، حيث يتم اختيار العمر الذي تم إرجاعه `'a` بشكل تعسفي ولا يعكس بالضرورة العمر الفعلي للبيانات.
    ///   على وجه الخصوص ، طوال مدة هذه الحياة ، يجب ألا يتم الوصول إلى الذاكرة التي يشير إليها المؤشر (قراءتها أو كتابتها) من خلال أي مؤشر آخر.
    ///
    /// وينطبق هذا حتى لو كانت نتيجة هذه الطريقة غير مستخدمة!
    ///
    /// راجع أيضًا [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // هذا آمن لأن `memory` صالح للقراءة والكتابة لـ `memory.len()` العديد من البايت.
    /// // لاحظ أن استدعاء `memory.as_mut()` غير مسموح به هنا حيث قد يكون المحتوى غير مهيأ.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// يُرجع مؤشرًا أوليًا إلى عنصر أو شريحة فرعية ، بدون إجراء فحص للحدود.
    ///
    /// استدعاء هذه الطريقة بمؤشر خارج الحدود أو عندما يكون `self` غير قابل للإلغاء هو *[سلوك غير محدد]* حتى إذا لم يتم استخدام المؤشر الناتج.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // الأمان: يضمن المتصل أن `self` قابل للإلغاء و `index` داخل الحدود.
        // نتيجة لذلك ، لا يمكن أن يكون المؤشر الناتج فارغًا.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // الأمان: لا يمكن أن يكون المؤشر الفريد فارغًا ، لذا فإن شروط
        // new_unchecked() محترمة.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // الأمان: لا يمكن أن يكون المرجع القابل للتغيير فارغًا.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // الأمان: لا يمكن أن يكون المرجع فارغًا ، لذا فإن شروط
        // new_unchecked() محترمة.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}