use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// غلاف حول `*mut T` خام غير خالي يشير إلى أن مالك هذا الغلاف يمتلك المرجع.
/// مفيد لبناء التجريدات مثل `Box<T>` و `Vec<T>` و `String` و `HashMap<K, V>`.
///
/// على عكس `*mut T` ، يتصرف `Unique<T>` مع "as if" كان مثيلًا لـ `T`.
/// يقوم بتنفيذ `Send`/`Sync` إذا كان `T` هو `Send`/`Sync`.
/// كما يشير أيضًا إلى نوع الضمانات القوية التي يمكن أن يتوقعها مثيل `T`:
/// لا ينبغي تعديل مرجع المؤشر بدون مسار فريد لامتلاكه الفريد.
///
/// إذا لم تكن متأكدًا مما إذا كان من الصحيح استخدام `Unique` لأغراضك ، ففكر في استخدام `NonNull` ، الذي يحتوي على دلالات أضعف.
///
///
/// على عكس `*mut T` ، يجب أن يكون المؤشر دائمًا غير فارغ ، حتى إذا لم يتم إلغاء الإشارة إلى المؤشر مطلقًا.
/// هذا حتى يمكن للتعدادات استخدام هذه القيمة المحظورة كمميز-`Option<Unique<T>>` له نفس حجم `Unique<T>`.
/// ومع ذلك ، قد يظل المؤشر متدليًا إذا لم يتم إلغاء الإشارة إليه.
///
/// على عكس `*mut T` ، يعتبر `Unique<T>` متغيرًا على `T`.
/// يجب أن يكون هذا دائمًا صحيحًا لأي نوع يدعم متطلبات التعرج الخاصة بـ Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: هذه العلامة ليس لها عواقب على التباين ، ولكنها ضرورية
    // لكي يفهم Dropck أننا نمتلك `T` منطقيًا.
    //
    // لمزيد من التفاصيل ، انظر:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` المؤشرات هي `Send` إذا كان `T` هو `Send` لأن البيانات التي تشير إليها غير مصنفة.
/// لاحظ أن ثابت التعرج هذا لا يتم فرضه بواسطة نظام النوع ؛يجب أن يقوم التجريد باستخدام `Unique` بفرضه.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` المؤشرات هي `Sync` إذا كان `T` هو `Sync` لأن البيانات التي تشير إليها غير مصنفة.
/// لاحظ أن ثابت التعرج هذا لا يتم فرضه بواسطة نظام النوع ؛يجب أن يقوم التجريد باستخدام `Unique` بفرضه.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// يُنشئ `Unique` جديدًا متدليًا ، ولكنه متناسق جيدًا.
    ///
    /// هذا مفيد لتهيئة الأنواع التي تخصص بتكاسل ، كما يفعل `Vec::new`.
    ///
    /// لاحظ أن قيمة المؤشر قد تمثل مؤشرًا صالحًا لـ `T` ، مما يعني أنه لا يجب استخدام هذا كقيمة خفر "not yet initialized".
    /// يجب أن تتبع الأنواع التي تخصصها بتكاسل التهيئة من خلال بعض الوسائل الأخرى.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // الأمان: يُرجع mem::align_of() مؤشرًا صالحًا غير فارغ.ال
        // وبالتالي يتم احترام شروط الاتصال بـ new_unchecked().
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// ينشئ `Unique` جديد.
    ///
    /// # Safety
    ///
    /// `ptr` يجب أن يكون غير فارغ.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // الأمان: يجب أن يضمن المتصل أن `ptr` غير فارغة.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// ينشئ `Unique` جديدًا إذا كان `ptr` غير فارغ.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // الأمان: تم بالفعل التحقق من المؤشر وهو ليس فارغًا.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// يكتسب المؤشر `*mut` الأساسي.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// يشتق من المحتوى.
    ///
    /// العمر الناتج مرتبط بالذات ، لذا فإن هذا يتصرف "as if" كان في الواقع مثالًا على T يتم استعارته.
    /// إذا كانت هناك حاجة إلى عمر أطول لـ (unbound) ، فاستخدم `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // الأمان: يجب أن يضمن المتصل أن `self` يلبي جميع
        // متطلبات كمرجع.
        unsafe { &*self.as_ptr() }
    }

    /// يرجح المحتوى بشكل قابل للتغيير.
    ///
    /// العمر الناتج مرتبط بالذات ، لذا فإن هذا يتصرف "as if" كان في الواقع مثالًا على T يتم استعارته.
    /// إذا كانت هناك حاجة إلى عمر أطول لـ (unbound) ، فاستخدم `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // الأمان: يجب أن يضمن المتصل أن `self` يلبي جميع
        // متطلبات مرجعية قابلة للتغيير.
        unsafe { &mut *self.as_ptr() }
    }

    /// يلقي بمؤشر من نوع آخر.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // الأمان: Unique::new_unchecked() يخلق احتياجات فريدة جديدة
        // المؤشر المحدد لا يكون فارغًا.
        // نظرًا لأننا نمرر الذات كمؤشر ، فلا يمكن أن تكون خالية.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // الأمان: لا يمكن أن يكون المرجع القابل للتغيير فارغًا
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}