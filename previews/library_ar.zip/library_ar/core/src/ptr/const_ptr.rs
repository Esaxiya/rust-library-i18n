use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// تُرجع `true` إذا كان المؤشر فارغًا.
    ///
    /// لاحظ أن الأنواع غير الحجم تحتوي على العديد من المؤشرات الفارغة المحتملة ، حيث يتم اعتبار مؤشر البيانات الأولية فقط ، وليس طولها ، أو جدول vt ، وما إلى ذلك.
    /// لذلك ، قد لا يزال لا يمكن مقارنة مؤشرين فارغين متساويين مع بعضهما البعض.
    ///
    /// ## السلوك أثناء التقييم المستمر
    ///
    /// عند استخدام هذه الوظيفة أثناء تقييم const ، فقد ترجع `false` للمؤشرات التي تبين أنها فارغة في وقت التشغيل.
    /// على وجه التحديد ، عندما يتم إزاحة مؤشر إلى ذاكرة ما خارج حدودها بطريقة تجعل المؤشر الناتج فارغًا ، ستستمر الوظيفة في إرجاع `false`.
    ///
    /// لا توجد طريقة لـ CTFE لمعرفة الموضع المطلق لتلك الذاكرة ، لذلك لا يمكننا معرفة ما إذا كان المؤشر فارغًا أم لا.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // قارن عبر قالب بمؤشر رفيع ، لذا فإن المؤشرات الدهنية تفكر فقط في جزء "data" الخاص بها من أجل العدم.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// يلقي بمؤشر من نوع آخر.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// حلل مؤشر (ربما واسع) إلى مكونات العنوان وبيانات التعريف.
    ///
    /// يمكن إعادة إنشاء المؤشر لاحقًا باستخدام [`from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// تُرجع `None` إذا كان المؤشر فارغًا ، أو تُرجع مرجعًا مشتركًا للقيمة الملتفة في `Some`.إذا كانت القيمة غير مهيأة ، فيجب استخدام [`as_uninit_ref`] بدلاً من ذلك.
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// عند استدعاء هذه الطريقة ، يجب عليك التأكد من أن المؤشر *إما* هو NULL *أو* كل ما يلي صحيح:
    ///
    /// * يجب محاذاة المؤشر بشكل صحيح.
    ///
    /// * يجب أن يكون "dereferencable" بالمعنى المحدد في [the module documentation].
    ///
    /// * يجب أن يشير المؤشر إلى مثيل مهيأ لـ `T`.
    ///
    /// * يجب عليك فرض قواعد التسمية المستعارة الخاصة بـ Rust ، حيث يتم اختيار العمر الذي تم إرجاعه `'a` بشكل تعسفي ولا يعكس بالضرورة العمر الفعلي للبيانات.
    ///   على وجه الخصوص ، طوال مدة هذه الحياة ، يجب ألا يتم تحور الذاكرة التي يشير إليها المؤشر (باستثناء داخل `UnsafeCell`).
    ///
    /// وينطبق هذا حتى لو كانت نتيجة هذه الطريقة غير مستخدمة!
    /// (لم يتم تحديد الجزء المتعلق بالتهيئة بالكامل بعد ، ولكن حتى يتم ذلك ، فإن الطريقة الآمنة الوحيدة هي التأكد من أنها قد تمت تهيئتها بالفعل).
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # نسخة خالية لم يتم التحقق منها
    ///
    /// إذا كنت متأكدًا من أن المؤشر لا يمكن أبدًا أن يكون فارغًا وتبحث عن نوع من `as_ref_unchecked` يُرجع `&T` بدلاً من `Option<&T>` ، فاعلم أنه يمكنك الرجوع إلى المؤشر مباشرةً.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // الأمان: يجب أن يضمن المتصل صلاحية `self`
        // كمرجع إذا لم يكن فارغًا.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// تُرجع `None` إذا كان المؤشر فارغًا ، أو تقوم بإرجاع مرجع مشترك إلى القيمة الملتفة في `Some`.
    /// على عكس [`as_ref`] ، لا يتطلب هذا تهيئة القيمة.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// عند استدعاء هذه الطريقة ، يجب عليك التأكد من أن المؤشر *إما* هو NULL *أو* كل ما يلي صحيح:
    ///
    /// * يجب محاذاة المؤشر بشكل صحيح.
    ///
    /// * يجب أن يكون "dereferencable" بالمعنى المحدد في [the module documentation].
    ///
    /// * يجب عليك فرض قواعد التسمية المستعارة الخاصة بـ Rust ، حيث يتم اختيار العمر الذي تم إرجاعه `'a` بشكل تعسفي ولا يعكس بالضرورة العمر الفعلي للبيانات.
    ///
    ///   على وجه الخصوص ، طوال مدة هذه الحياة ، يجب ألا يتم تحور الذاكرة التي يشير إليها المؤشر (باستثناء داخل `UnsafeCell`).
    ///
    /// وينطبق هذا حتى لو كانت نتيجة هذه الطريقة غير مستخدمة!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // الأمان: يجب أن يضمن المتصل أن `self` يلبي جميع
        // متطلبات كمرجع.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// تحسب الإزاحة من المؤشر.
    ///
    /// `count` في وحدات T ؛على سبيل المثال ، يمثل `count` من 3 إزاحة مؤشر من `3 * size_of::<T>()` بايت.
    ///
    /// # Safety
    ///
    /// في حالة انتهاك أي من الشروط التالية ، تكون النتيجة سلوك غير محدد:
    ///
    /// * يجب أن يكون كل من مؤشر البداية والناتج إما في حدود أو بايت واحد بعد نهاية نفس الكائن المخصص.
    /// لاحظ أنه في Rust ، يعتبر كل متغير (stack-allocated) كائنًا مخصصًا منفصلاً.
    ///
    /// * لا يمكن للإزاحة المحسوبة ،**بالبايت**، تجاوز `isize`.
    ///
    /// * الإزاحة الموجودة في الحدود لا يمكن أن تعتمد على "wrapping around" في مساحة العنوان.وهذا يعني أن مجموع الدقة اللانهائي **بالبايت** يجب أن يتناسب مع الاستخدام.
    ///
    /// يحاول المترجم والمكتبة القياسية عمومًا ضمان عدم وصول المخصصات أبدًا إلى الحجم الذي يمثل فيه الإزاحة مصدر قلق.
    /// على سبيل المثال ، تضمن `Vec` و `Box` عدم تخصيص أكثر من `isize::MAX` بايت ، لذا فإن `vec.as_ptr().add(vec.len())` آمن دائمًا.
    ///
    /// لا تستطيع معظم الأنظمة الأساسية بشكل أساسي إنشاء مثل هذا التخصيص.
    /// على سبيل المثال ، لا يمكن لأي نظام أساسي 64 بت معروف تقديم طلب لـ <sup>263</sup> بايت بسبب قيود جدول الصفحة أو تقسيم مساحة العنوان.
    /// ومع ذلك ، قد تخدم بعض الأنظمة الأساسية 32 بت و 16 بت بنجاح طلبًا يزيد عن `isize::MAX` بايت مع أشياء مثل ملحق العنوان الفعلي.
    ///
    /// على هذا النحو ، الذاكرة المكتسبة مباشرة من المخصصات أو الملفات المعينة للذاكرة * قد تكون كبيرة جدًا بحيث لا يمكن التعامل معها مع هذه الوظيفة.
    ///
    /// ضع في اعتبارك استخدام [`wrapping_offset`] بدلاً من ذلك إذا كان من الصعب تلبية هذه القيود.
    /// الميزة الوحيدة لهذه الطريقة هي أنها تتيح تحسينات أكثر قوة للمترجم.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `offset`.
        unsafe { intrinsics::offset(self, count) }
    }

    /// تحسب الإزاحة من مؤشر باستخدام حساب الالتفاف.
    ///
    /// `count` في وحدات T ؛على سبيل المثال ، يمثل `count` من 3 إزاحة مؤشر من `3 * size_of::<T>()` بايت.
    ///
    /// # Safety
    ///
    /// هذه العملية نفسها آمنة دائمًا ، لكن استخدام المؤشر الناتج ليس كذلك.
    ///
    /// يظل المؤشر الناتج مرتبطًا بنفس الكائن المخصص الذي يشير إليه `self`.
    /// لا يجوز استخدامه للوصول إلى كائن مخصص مختلف.لاحظ أنه في Rust ، يعتبر كل متغير (stack-allocated) كائنًا مخصصًا منفصلاً.
    ///
    /// بمعنى آخر ، `let z = x.wrapping_offset((y as isize) - (x as isize))` لا * * تجعل `z` هو نفسه `y` حتى لو افترضنا أن `T` بحجم `1` ولا يوجد تجاوز: `z` لا يزال مرتبطًا بالكائن `x` ، وإلغاء الإشارة إليه هو سلوك غير محدد ما لم يكن `x` نقطة `y` في نفس الكائن المخصص.
    ///
    /// مقارنةً بـ [`offset`] ، تؤخر هذه الطريقة أساسًا متطلبات البقاء داخل نفس الكائن المخصص: [`offset`] هو سلوك فوري غير محدد عند عبور حدود الكائن ؛ينتج `wrapping_offset` مؤشرًا ولكنه لا يزال يؤدي إلى سلوك غير محدد إذا تم إلغاء الإشارة إلى المؤشر عندما يكون خارج حدود الكائن المرتبط به.
    /// [`offset`] يمكن تحسينها بشكل أفضل وبالتالي فهي مفضلة في التعليمات البرمجية الحساسة للأداء.
    ///
    /// يأخذ الفحص المؤجل في الاعتبار فقط قيمة المؤشر الذي تم إلغاء الإشارة إليه ، وليس القيم الوسيطة المستخدمة أثناء حساب النتيجة النهائية.
    /// على سبيل المثال ، يكون `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` دائمًا هو نفسه `x`.بمعنى آخر ، يُسمح بترك الكائن المخصص ثم إعادة إدخاله لاحقًا.
    ///
    /// إذا كنت بحاجة إلى عبور حدود الكائن ، فقم بإلقاء المؤشر على عدد صحيح وقم بإجراء العمليات الحسابية هناك.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// // كرر باستخدام مؤشر خام بزيادات من عنصرين
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // هذه الحلقة تطبع "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // الأمان: `arith_offset` جوهري ليس له متطلبات مسبقة ليتم استدعاؤها.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// تحسب المسافة بين مؤشرين.القيمة التي تم إرجاعها بوحدات T: المسافة بالبايت مقسومة على `mem::size_of::<T>()`.
    ///
    /// هذه الوظيفة هي معكوس [`offset`].
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// في حالة انتهاك أي من الشروط التالية ، تكون النتيجة سلوك غير محدد:
    ///
    /// * يجب أن يكون كل من مؤشر البداية والمؤشر الآخر إما في حدود أو ببايت واحد بعد نهاية نفس الكائن المخصص.
    /// لاحظ أنه في Rust ، يعتبر كل متغير (stack-allocated) كائنًا مخصصًا منفصلاً.
    ///
    /// * يجب أن يكون كلا المؤشرين *مشتقًا من* مؤشر لنفس الكائن.
    ///   (إنظر في الأسفل للمثال.)
    ///
    /// * يجب أن تكون المسافة بين المؤشرات ، بالبايت ، مضاعفًا دقيقًا لحجم `T`.
    ///
    /// * لا يمكن أن تتجاوز المسافة بين المؤشرات ،**بالبايت**، `isize`.
    ///
    /// * لا يمكن أن تعتمد المسافة الموجودة في الحدود على مساحة العنوان "wrapping around".
    ///
    /// لا تكون أنواع Rust أكبر من `isize::MAX` ولا تلتف تخصيصات Rust أبدًا حول مساحة العنوان ، لذا فإن مؤشرين ضمن قيمة معينة من أي نوع Rust `T` سوف يفيان دائمًا بالشرطين الأخيرين.
    ///
    /// تضمن المكتبة القياسية أيضًا عمومًا ألا تصل التخصيصات أبدًا إلى الحجم الذي يمثل فيه الإزاحة مصدر قلق.
    /// على سبيل المثال ، تضمن `Vec` و `Box` عدم تخصيص أكثر من `isize::MAX` بايت ، لذا فإن `ptr_into_vec.offset_from(vec.as_ptr())` تفي دائمًا بالشرطين الأخيرين.
    ///
    /// لا تستطيع معظم الأنظمة الأساسية بشكل أساسي إنشاء مثل هذا التخصيص الكبير.
    /// على سبيل المثال ، لا يمكن لأي نظام أساسي 64 بت معروف تقديم طلب لـ <sup>263</sup> بايت بسبب قيود جدول الصفحة أو تقسيم مساحة العنوان.
    /// ومع ذلك ، قد تخدم بعض الأنظمة الأساسية 32 بت و 16 بت بنجاح طلبًا يزيد عن `isize::MAX` بايت مع أشياء مثل ملحق العنوان الفعلي.
    /// على هذا النحو ، الذاكرة المكتسبة مباشرة من المخصصات أو الملفات المعينة للذاكرة * قد تكون كبيرة جدًا بحيث لا يمكن التعامل معها مع هذه الوظيفة.
    /// (لاحظ أن [`offset`] و [`add`] لهما أيضًا قيود مماثلة وبالتالي لا يمكن استخدامها في مثل هذه التخصيصات الكبيرة أيضًا.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// هذه الوظيفة panics إذا كان `T` من النوع ("ZST") صفر الحجم.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *استخدام غير صحيح*:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // اجعل ptr2_other "alias" من ptr2 ، ولكن مشتق من ptr1.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // نظرًا لأن ptr2_other و ptr2 مشتق من مؤشرات إلى كائنات مختلفة ، فإن حساب إزاحتها يعد سلوكًا غير محدد ، على الرغم من أنها تشير إلى نفس العنوان!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // سلوك غير محدد
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `ptr_offset_from`.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// لعرض ما إذا كان هناك مؤشرين مضمونين ليكونا متساويين.
    ///
    /// في وقت التشغيل ، تتصرف هذه الوظيفة مثل `self == other`.
    /// ومع ذلك ، في بعض السياقات (على سبيل المثال ، تقييم وقت الترجمة) ، ليس من الممكن دائمًا تحديد المساواة بين مؤشرين ، لذلك قد تقوم هذه الوظيفة بإرجاع `false` بشكل خاطئ للمؤشرات التي تبين لاحقًا أنها متساوية.
    ///
    /// ولكن عند إرجاع `true` ، يتم ضمان تساوي المؤشرات.
    ///
    /// هذه الوظيفة هي مرآة [`guaranteed_ne`] ، لكنها ليست معكوسة.توجد مقارنات بين المؤشرات حيث تقوم كلتا الوظيفتين بإرجاع `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// قد تتغير قيمة الإرجاع اعتمادًا على إصدار المحول البرمجي وقد لا يعتمد الرمز غير الآمن على نتيجة هذه الوظيفة من أجل السلامة.
    /// يُقترح استخدام هذه الوظيفة فقط لتحسين الأداء حيث لا تؤثر قيم إرجاع `false` الزائفة بواسطة هذه الوظيفة على النتيجة ، ولكن على الأداء فقط.
    /// لم يتم استكشاف عواقب استخدام هذه الطريقة لجعل وقت التشغيل وكود وقت الترجمة يتصرفان بشكل مختلف.
    /// لا ينبغي استخدام هذه الطريقة لإدخال مثل هذه الاختلافات ، كما يجب عدم استقرارها قبل أن يكون لدينا فهم أفضل لهذه المشكلة.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// لعرض ما إذا كان هناك مؤشرين مضمونين ليكونا غير متساويين.
    ///
    /// في وقت التشغيل ، تتصرف هذه الوظيفة مثل `self != other`.
    /// ومع ذلك ، في بعض السياقات (على سبيل المثال ، تقييم وقت الترجمة) ، ليس من الممكن دائمًا تحديد عدم المساواة بين مؤشرين ، لذلك قد تعيد هذه الوظيفة بشكل زائف `false` للمؤشرات التي تبين لاحقًا أنها غير متكافئة.
    ///
    /// ولكن عند إرجاع `true` ، يتم ضمان عدم تكافؤ المؤشرات.
    ///
    /// هذه الوظيفة هي مرآة [`guaranteed_eq`] ، لكنها ليست معكوسة.توجد مقارنات بين المؤشرات حيث تقوم كلتا الوظيفتين بإرجاع `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// قد تتغير قيمة الإرجاع اعتمادًا على إصدار المحول البرمجي وقد لا يعتمد الرمز غير الآمن على نتيجة هذه الوظيفة من أجل السلامة.
    /// يُقترح استخدام هذه الوظيفة فقط لتحسين الأداء حيث لا تؤثر قيم إرجاع `false` الزائفة بواسطة هذه الوظيفة على النتيجة ، ولكن على الأداء فقط.
    /// لم يتم استكشاف عواقب استخدام هذه الطريقة لجعل وقت التشغيل وكود وقت الترجمة يتصرفان بشكل مختلف.
    /// لا ينبغي استخدام هذه الطريقة لإدخال مثل هذه الاختلافات ، كما يجب عدم استقرارها قبل أن يكون لدينا فهم أفضل لهذه المشكلة.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// تحسب الإزاحة من مؤشر (ملائم لـ `.offset(count as isize)`).
    ///
    /// `count` في وحدات T ؛على سبيل المثال ، يمثل `count` من 3 إزاحة مؤشر من `3 * size_of::<T>()` بايت.
    ///
    /// # Safety
    ///
    /// في حالة انتهاك أي من الشروط التالية ، تكون النتيجة سلوك غير محدد:
    ///
    /// * يجب أن يكون كل من مؤشر البداية والناتج إما في حدود أو بايت واحد بعد نهاية نفس الكائن المخصص.
    /// لاحظ أنه في Rust ، يعتبر كل متغير (stack-allocated) كائنًا مخصصًا منفصلاً.
    ///
    /// * لا يمكن للإزاحة المحسوبة ،**بالبايت**، تجاوز `isize`.
    ///
    /// * الإزاحة الموجودة في الحدود لا يمكن أن تعتمد على "wrapping around" في مساحة العنوان.وهذا يعني أن مجموع الدقة اللانهائية يجب أن يتناسب مع `usize`.
    ///
    /// يحاول المترجم والمكتبة القياسية عمومًا ضمان عدم وصول المخصصات أبدًا إلى الحجم الذي يمثل فيه الإزاحة مصدر قلق.
    /// على سبيل المثال ، تضمن `Vec` و `Box` عدم تخصيص أكثر من `isize::MAX` بايت ، لذا فإن `vec.as_ptr().add(vec.len())` آمن دائمًا.
    ///
    /// لا تستطيع معظم الأنظمة الأساسية بشكل أساسي إنشاء مثل هذا التخصيص.
    /// على سبيل المثال ، لا يمكن لأي نظام أساسي 64 بت معروف تقديم طلب لـ <sup>263</sup> بايت بسبب قيود جدول الصفحة أو تقسيم مساحة العنوان.
    /// ومع ذلك ، قد تخدم بعض الأنظمة الأساسية 32 بت و 16 بت بنجاح طلبًا يزيد عن `isize::MAX` بايت مع أشياء مثل ملحق العنوان الفعلي.
    ///
    /// على هذا النحو ، الذاكرة المكتسبة مباشرة من المخصصات أو الملفات المعينة للذاكرة * قد تكون كبيرة جدًا بحيث لا يمكن التعامل معها مع هذه الوظيفة.
    ///
    /// ضع في اعتبارك استخدام [`wrapping_add`] بدلاً من ذلك إذا كان من الصعب تلبية هذه القيود.
    /// الميزة الوحيدة لهذه الطريقة هي أنها تتيح تحسينات أكثر قوة للمترجم.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// تحسب الإزاحة من مؤشر (ملائمة لـ ".offset ((تعد isize).wrapping_neg())`).
    ///
    /// `count` في وحدات T ؛على سبيل المثال ، يمثل `count` من 3 إزاحة مؤشر من `3 * size_of::<T>()` بايت.
    ///
    /// # Safety
    ///
    /// في حالة انتهاك أي من الشروط التالية ، تكون النتيجة سلوك غير محدد:
    ///
    /// * يجب أن يكون كل من مؤشر البداية والناتج إما في حدود أو بايت واحد بعد نهاية نفس الكائن المخصص.
    /// لاحظ أنه في Rust ، يعتبر كل متغير (stack-allocated) كائنًا مخصصًا منفصلاً.
    ///
    /// * لا يمكن أن يتجاوز الإزاحة المحسوبة `isize::MAX`**بايت**.
    ///
    /// * الإزاحة الموجودة في الحدود لا يمكن أن تعتمد على "wrapping around" في مساحة العنوان.وهذا يعني أن مجموع الدقة اللانهائية يجب أن يتناسب مع الاستخدام.
    ///
    /// يحاول المترجم والمكتبة القياسية عمومًا ضمان عدم وصول المخصصات أبدًا إلى الحجم الذي يمثل فيه الإزاحة مصدر قلق.
    /// على سبيل المثال ، تضمن `Vec` و `Box` عدم تخصيص أكثر من `isize::MAX` بايت ، لذا فإن `vec.as_ptr().add(vec.len()).sub(vec.len())` آمن دائمًا.
    ///
    /// لا تستطيع معظم الأنظمة الأساسية بشكل أساسي إنشاء مثل هذا التخصيص.
    /// على سبيل المثال ، لا يمكن لأي نظام أساسي 64 بت معروف تقديم طلب لـ <sup>263</sup> بايت بسبب قيود جدول الصفحة أو تقسيم مساحة العنوان.
    /// ومع ذلك ، قد تخدم بعض الأنظمة الأساسية 32 بت و 16 بت بنجاح طلبًا يزيد عن `isize::MAX` بايت مع أشياء مثل ملحق العنوان الفعلي.
    ///
    /// على هذا النحو ، الذاكرة المكتسبة مباشرة من المخصصات أو الملفات المعينة للذاكرة * قد تكون كبيرة جدًا بحيث لا يمكن التعامل معها مع هذه الوظيفة.
    ///
    /// ضع في اعتبارك استخدام [`wrapping_sub`] بدلاً من ذلك إذا كان من الصعب تلبية هذه القيود.
    /// الميزة الوحيدة لهذه الطريقة هي أنها تتيح تحسينات أكثر قوة للمترجم.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// تحسب الإزاحة من مؤشر باستخدام حساب الالتفاف.
    /// (الراحة لـ `.wrapping_offset(count as isize)`)
    ///
    /// `count` في وحدات T ؛على سبيل المثال ، يمثل `count` من 3 إزاحة مؤشر من `3 * size_of::<T>()` بايت.
    ///
    /// # Safety
    ///
    /// هذه العملية نفسها آمنة دائمًا ، لكن استخدام المؤشر الناتج ليس كذلك.
    ///
    /// يظل المؤشر الناتج مرتبطًا بنفس الكائن المخصص الذي يشير إليه `self`.
    /// لا يجوز استخدامه للوصول إلى كائن مخصص مختلف.لاحظ أنه في Rust ، يعتبر كل متغير (stack-allocated) كائنًا مخصصًا منفصلاً.
    ///
    /// بمعنى آخر ، `let z = x.wrapping_add((y as usize) - (x as usize))` لا * * يجعل `z` هو نفسه `y` حتى لو افترضنا أن `T` بحجم `1` ولا يوجد تجاوز: `z` لا يزال مرتبطًا بالكائن `x` ، وإلغاء الإشارة إليه هو سلوك غير محدد ما لم يكن `x` و نقطة `y` في نفس الكائن المخصص.
    ///
    /// مقارنةً بـ [`add`] ، تؤخر هذه الطريقة أساسًا متطلبات البقاء داخل نفس الكائن المخصص: [`add`] هو سلوك فوري غير محدد عند عبور حدود الكائن ؛ينتج `wrapping_add` مؤشرًا ولكنه لا يزال يؤدي إلى سلوك غير محدد إذا تم إلغاء الإشارة إلى المؤشر عندما يكون خارج حدود الكائن المرتبط به.
    /// [`add`] يمكن تحسينها بشكل أفضل وبالتالي فهي مفضلة في التعليمات البرمجية الحساسة للأداء.
    ///
    /// يأخذ الفحص المؤجل في الاعتبار فقط قيمة المؤشر الذي تم إلغاء الإشارة إليه ، وليس القيم الوسيطة المستخدمة أثناء حساب النتيجة النهائية.
    /// على سبيل المثال ، يكون `x.wrapping_add(o).wrapping_sub(o)` دائمًا هو نفسه `x`.بمعنى آخر ، يُسمح بترك الكائن المخصص ثم إعادة إدخاله لاحقًا.
    ///
    /// إذا كنت بحاجة إلى عبور حدود الكائن ، فقم بإلقاء المؤشر على عدد صحيح وقم بإجراء العمليات الحسابية هناك.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// // كرر باستخدام مؤشر خام بزيادات من عنصرين
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // هذه الحلقة تطبع "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// تحسب الإزاحة من مؤشر باستخدام حساب الالتفاف.
    /// (ملائمة لـ ".wrapping_offset ((تعد isize).wrapping_neg())`)
    ///
    /// `count` في وحدات T ؛على سبيل المثال ، يمثل `count` من 3 إزاحة مؤشر من `3 * size_of::<T>()` بايت.
    ///
    /// # Safety
    ///
    /// هذه العملية نفسها آمنة دائمًا ، لكن استخدام المؤشر الناتج ليس كذلك.
    ///
    /// يظل المؤشر الناتج مرتبطًا بنفس الكائن المخصص الذي يشير إليه `self`.
    /// لا يجوز استخدامه للوصول إلى كائن مخصص مختلف.لاحظ أنه في Rust ، يعتبر كل متغير (stack-allocated) كائنًا مخصصًا منفصلاً.
    ///
    /// بمعنى آخر ، `let z = x.wrapping_sub((x as usize) - (y as usize))` لا * * يجعل `z` هو نفسه `y` حتى لو افترضنا أن `T` بحجم `1` ولا يوجد تجاوز: لا يزال `z` مرتبطًا بالكائن `x` ، وإلغاء الإشارة إليه هو سلوك غير محدد ما لم يكن `x` و نقطة `y` في نفس الكائن المخصص.
    ///
    /// مقارنةً بـ [`sub`] ، تؤخر هذه الطريقة أساسًا متطلبات البقاء داخل نفس الكائن المخصص: [`sub`] هو سلوك فوري غير محدد عند عبور حدود الكائن ؛ينتج `wrapping_sub` مؤشرًا ولكنه لا يزال يؤدي إلى سلوك غير محدد إذا تم إلغاء الإشارة إلى المؤشر عندما يكون خارج حدود الكائن المرتبط به.
    /// [`sub`] يمكن تحسينها بشكل أفضل وبالتالي فهي مفضلة في التعليمات البرمجية الحساسة للأداء.
    ///
    /// يأخذ الفحص المؤجل في الاعتبار فقط قيمة المؤشر الذي تم إلغاء الإشارة إليه ، وليس القيم الوسيطة المستخدمة أثناء حساب النتيجة النهائية.
    /// على سبيل المثال ، يكون `x.wrapping_add(o).wrapping_sub(o)` دائمًا هو نفسه `x`.بمعنى آخر ، يُسمح بترك الكائن المخصص ثم إعادة إدخاله لاحقًا.
    ///
    /// إذا كنت بحاجة إلى عبور حدود الكائن ، فقم بإلقاء المؤشر على عدد صحيح وقم بإجراء العمليات الحسابية هناك.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// // كرر باستخدام مؤشر خام بزيادات من عنصرين (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // هذه الحلقة تطبع "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// يضبط قيمة المؤشر على `ptr`.
    ///
    /// في حالة كون `self` هو مؤشر (fat) لنوع غير بحجم ، فإن هذه العملية ستؤثر فقط على جزء المؤشر ، بينما بالنسبة لمؤشرات (thin) لأنواع الأحجام ، فإن هذا له نفس تأثير التعيين البسيط.
    ///
    /// سيكون للمؤشر الناتج مصدر `val` ، أي بالنسبة لمؤشر الدهون ، فإن هذه العملية هي نفس الدلالة لإنشاء مؤشر دهون جديد بقيمة مؤشر البيانات `val` ولكن البيانات الوصفية لـ `self`.
    ///
    ///
    /// # Examples
    ///
    /// هذه الوظيفة مفيدة بشكل أساسي للسماح بحساب مؤشر البايت على المؤشرات التي يحتمل أن تكون دهنية:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // سوف تطبع "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // الأمان: في حالة وجود مؤشر رفيع ، تكون هذه العمليات متطابقة
        // لمهمة بسيطة.
        // في حالة وجود مؤشر سمين ، مع تنفيذ تخطيط مؤشر الدهون الحالي ، يكون الحقل الأول لهذا المؤشر دائمًا هو مؤشر البيانات ، والذي يتم تعيينه بالمثل.
        //
        unsafe { *thin = val };
        self
    }

    /// يقرأ القيمة من `self` دون تحريكها.
    /// هذا يترك الذاكرة في `self` دون تغيير.
    ///
    /// راجع [`ptr::read`] للحصول على أمثلة ومخاوف تتعلق بالسلامة.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `read`.
        unsafe { read(self) }
    }

    /// يقوم بقراءة متقلبة للقيمة من `self` دون تحريكها.هذا يترك الذاكرة في `self` دون تغيير.
    ///
    /// تهدف العمليات المتقلبة إلى العمل على ذاكرة I/O ، وهي مضمونة لعدم إهمالها أو إعادة ترتيبها من قبل المترجم عبر العمليات المتقلبة الأخرى.
    ///
    ///
    /// راجع [`ptr::read_volatile`] للحصول على أمثلة ومخاوف تتعلق بالسلامة.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// يقرأ القيمة من `self` دون تحريكها.
    /// هذا يترك الذاكرة في `self` دون تغيير.
    ///
    /// على عكس `read` ، قد يكون المؤشر غير محاذي.
    ///
    /// راجع [`ptr::read_unaligned`] للحصول على أمثلة ومخاوف تتعلق بالسلامة.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// ينسخ `count * size_of<T>` بايت من `self` إلى `dest`.
    /// قد يتداخل المصدر والوجهة.
    ///
    /// NOTE: هذا له نفس ترتيب الوسيطة * مثل [`ptr::copy`].
    ///
    /// راجع [`ptr::copy`] للحصول على أمثلة ومخاوف تتعلق بالسلامة.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// ينسخ `count * size_of<T>` بايت من `self` إلى `dest`.
    /// المصدر والوجهة قد *لا* يتداخلان.
    ///
    /// NOTE: هذا له نفس ترتيب الوسيطة * مثل [`ptr::copy_nonoverlapping`].
    ///
    /// راجع [`ptr::copy_nonoverlapping`] للحصول على أمثلة ومخاوف تتعلق بالسلامة.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// يحسب الإزاحة التي يجب تطبيقها على المؤشر لجعله محاذيًا لـ `align`.
    ///
    /// إذا لم يكن من الممكن محاذاة المؤشر ، يقوم التطبيق بإرجاع `usize::MAX`.
    /// يجوز للتنفيذ *دائمًا* إرجاع `usize::MAX`.
    /// يمكن أن يعتمد أداء الخوارزمية فقط على الحصول على تعويض قابل للاستخدام هنا ، وليس على صحته.
    ///
    /// يتم التعبير عن الإزاحة بعدد عناصر `T` وليس بالبايت.يمكن استخدام القيمة التي تم إرجاعها مع طريقة `wrapping_add`.
    ///
    /// لا توجد ضمانات على الإطلاق بأن موازنة المؤشر لن تتجاوز أو تتجاوز التخصيص الذي يشير إليه المؤشر.
    ///
    /// الأمر متروك للمتصل للتأكد من أن الإزاحة التي تم إرجاعها صحيحة في جميع المصطلحات بخلاف المحاذاة.
    ///
    /// # Panics
    ///
    /// الوظيفة panics إذا كانت `align` ليست قوة من اثنين.
    ///
    /// # Examples
    ///
    /// الوصول إلى `u8` المجاور مثل `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // بينما يمكن محاذاة المؤشر عبر `offset` ، فإنه يشير إلى خارج التخصيص
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // الأمان: تم التحقق من `align` لتكون قوة 2 أعلاه
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// إرجاع طول الشريحة الخام.
    ///
    /// القيمة التي تم إرجاعها هي عدد **العناصر**، وليس عدد البايت.
    ///
    /// هذه الوظيفة آمنة ، حتى عندما لا يمكن تحويل الشريحة الأولية إلى مرجع شريحة لأن المؤشر فارغ أو غير محاذي.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // الأمان: هذا آمن لأن `*const [T]` و `FatPtr<T>` لهما نفس التصميم.
            // يمكن لـ `std` فقط تقديم هذا الضمان.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// إرجاع مؤشر خام إلى المخزن المؤقت للشريحة.
    ///
    /// هذا يعادل تحويل `self` إلى `*const T` ، ولكنه أكثر أمانًا من النوع.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// يُرجع مؤشرًا أوليًا إلى عنصر أو شريحة فرعية ، بدون إجراء فحص للحدود.
    ///
    /// استدعاء هذه الطريقة بمؤشر خارج الحدود أو عندما يكون `self` غير قابل للإلغاء هو *[سلوك غير محدد]* حتى إذا لم يتم استخدام المؤشر الناتج.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // الأمان: يضمن المتصل أن `self` قابل للإلغاء و `index` داخل الحدود.
        unsafe { index.get_unchecked(self) }
    }

    /// تُرجع `None` إذا كان المؤشر فارغًا ، أو تُرجع شريحة مشتركة إلى القيمة الملتفة في `Some`.
    /// على عكس [`as_ref`] ، لا يتطلب هذا تهيئة القيمة.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// عند استدعاء هذه الطريقة ، يجب عليك التأكد من أن المؤشر *إما* هو NULL *أو* كل ما يلي صحيح:
    ///
    /// * يجب أن يكون المؤشر [valid] للقراءات لـ `ptr.len() * mem::size_of::<T>()` العديد من البايت ، ويجب محاذاته بشكل صحيح.وهذا يعني على وجه الخصوص:
    ///
    ///     * يجب احتواء نطاق الذاكرة الكامل لهذه الشريحة في كائن مخصص واحد!
    ///       لا يمكن للشرائح أبدًا أن تمتد عبر كائنات مخصصة متعددة.
    ///
    ///     * يجب محاذاة المؤشر حتى بالنسبة للشرائح ذات الطول الصفري.
    ///     أحد أسباب ذلك هو أن تحسينات تخطيط التعداد قد تعتمد على محاذاة المراجع (بما في ذلك الشرائح من أي طول) وغير الفارغة لتمييزها عن البيانات الأخرى.
    ///
    ///     يمكنك الحصول على مؤشر يمكن استخدامه مثل `data` للشرائح ذات الطول الصفري باستخدام [`NonNull::dangling()`].
    ///
    /// * يجب ألا يزيد الحجم الإجمالي للشريحة `ptr.len() * mem::size_of::<T>()` عن `isize::MAX`.
    ///   راجع وثائق الأمان الخاصة بـ [`pointer::offset`].
    ///
    /// * يجب عليك فرض قواعد التسمية المستعارة الخاصة بـ Rust ، حيث يتم اختيار العمر الذي تم إرجاعه `'a` بشكل تعسفي ولا يعكس بالضرورة العمر الفعلي للبيانات.
    ///   على وجه الخصوص ، طوال مدة هذه الحياة ، يجب ألا يتم تحور الذاكرة التي يشير إليها المؤشر (باستثناء داخل `UnsafeCell`).
    ///
    /// وينطبق هذا حتى لو كانت نتيجة هذه الطريقة غير مستخدمة!
    ///
    /// راجع أيضًا [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// المساواة للمؤشرات
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// مقارنة للمؤشرات
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}