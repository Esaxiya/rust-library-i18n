/// تُستخدم لعمليات إلغاء الإسناد غير القابلة للتغيير ، مثل `*v`.
///
/// بالإضافة إلى استخدامه لعمليات إلغاء المراجع الصريحة مع عامل التشغيل (unary) `*` في سياقات ثابتة ، يتم استخدام `Deref` أيضًا ضمنيًا بواسطة المترجم في العديد من الظروف.
/// هذه الآلية تسمى ['`Deref` coercion'][more].
/// في السياقات المتغيرة ، يتم استخدام [`DerefMut`].
///
/// يجعل تطبيق `Deref` للمؤشرات الذكية الوصول إلى البيانات الموجودة خلفها أمرًا مريحًا ، ولهذا السبب قاموا بتطبيق `Deref`.
/// من ناحية أخرى ، تم تصميم القواعد المتعلقة بـ `Deref` و [`DerefMut`] خصيصًا لتلائم المؤشرات الذكية.
/// لهذا السبب ، يجب تنفيذ **`Deref` فقط للمؤشرات الذكية** لتجنب الالتباس.
///
/// لأسباب مماثلة ،**يجب ألا تفشل** trait **.يمكن أن يكون الفشل أثناء إلغاء المرجع مربكًا للغاية عند استدعاء `Deref` ضمنيًا.
///
/// # المزيد عن إكراه `Deref`
///
/// إذا كان `T` يطبق `Deref<Target = U>` ، وكان `x` قيمة من النوع `T` ، إذن:
///
/// * في السياقات غير القابلة للتغيير ، `*x` (حيث `T` ليس مرجعًا ولا مؤشرًا خامًا) يكافئ `* Deref::deref(&x)`.
/// * يتم فرض قيم النوع `&T` على قيم من النوع `&U`
/// * `T` يطبق ضمنيًا جميع طرق (immutable) من النوع `U`.
///
/// لمزيد من التفاصيل ، قم بزيارة [the chapter in *The Rust Programming Language*][book] بالإضافة إلى الأقسام المرجعية في [the dereference operator][ref-deref-op] و [method resolution] و [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// هيكل بحقل واحد يمكن الوصول إليه عن طريق إلغاء الإشارة إلى البنية.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// النوع الناتج بعد إلغاء الإسناد.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// تنسب القيمة.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// تستخدم لعمليات إلغاء الإسناد المتغيرة ، كما هو الحال في `*v = 1;`.
///
/// بالإضافة إلى استخدامه لعمليات إلغاء المراجع الصريحة مع عامل التشغيل (unary) `*` في سياقات قابلة للتغيير ، يتم استخدام `DerefMut` أيضًا ضمنيًا بواسطة المترجم في العديد من الظروف.
/// هذه الآلية تسمى ['`Deref` coercion'][more].
/// في السياقات غير القابلة للتغيير ، يتم استخدام [`Deref`].
///
/// يجعل تطبيق `DerefMut` للمؤشرات الذكية تغيير البيانات الموجودة خلفها أمرًا مريحًا ، وهذا هو سبب قيامهم بتنفيذ `DerefMut`.
/// من ناحية أخرى ، تم تصميم القواعد المتعلقة بـ [`Deref`] و `DerefMut` خصيصًا لتلائم المؤشرات الذكية.
/// لهذا السبب ، يجب تنفيذ **`DerefMut` فقط للمؤشرات الذكية** لتجنب الالتباس.
///
/// لأسباب مماثلة ،**يجب ألا تفشل** trait **.يمكن أن يكون الفشل أثناء إلغاء المرجع مربكًا للغاية عند استدعاء `DerefMut` ضمنيًا.
///
/// # المزيد عن إكراه `Deref`
///
/// إذا كان `T` يطبق `DerefMut<Target = U>` ، وكان `x` قيمة من النوع `T` ، إذن:
///
/// * في السياقات المتغيرة ، `*x` (حيث `T` ليس مرجعًا ولا مؤشرًا أوليًا) يكافئ `* DerefMut::deref_mut(&mut x)`.
/// * يتم فرض قيم النوع `&mut T` على قيم من النوع `&mut U`
/// * `T` يطبق ضمنيًا جميع طرق (mutable) من النوع `U`.
///
/// لمزيد من التفاصيل ، قم بزيارة [the chapter in *The Rust Programming Language*][book] بالإضافة إلى الأقسام المرجعية في [the dereference operator][ref-deref-op] و [method resolution] و [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// هيكل بحقل واحد يمكن تعديله عن طريق إلغاء الإشارة إلى البنية.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// يشتق القيمة بشكل قابل للتغيير.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// يشير إلى أنه يمكن استخدام البنية كجهاز استقبال للطريقة ، بدون ميزة `arbitrary_self_types`.
///
/// يتم تنفيذ ذلك بواسطة أنواع مؤشرات stdlib مثل `Box<T>` و `Rc<T>` و `&T` و `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}