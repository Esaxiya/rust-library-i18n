use crate::marker::Unpin;
use crate::pin::Pin;

/// نتيجة استئناف المولد.
///
/// يتم إرجاع هذا التعداد من طريقة `Generator::resume` ويشير إلى قيم الإرجاع المحتملة للمولد.
/// هذا يتوافق حاليًا مع إما نقطة تعليق (`Yielded`) أو نقطة إنهاء (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// المولد معلق بقيمة.
    ///
    /// تشير هذه الحالة إلى أنه تم تعليق أحد المولد ، وعادةً ما يتوافق مع عبارة `yield`.
    /// تتوافق القيمة المقدمة في هذا المتغير مع التعبير الذي تم تمريره إلى `yield` وتسمح للمولدات بتوفير قيمة في كل مرة تنتج فيها.
    ///
    ///
    Yielded(Y),

    /// المولد مكتمل بقيمة مرتجعة.
    ///
    /// تشير هذه الحالة إلى أن المولد قد انتهى من التنفيذ بالقيمة المقدمة.
    /// بمجرد إرجاع المولد `Complete` ، يعتبر خطأ مبرمج للاتصال بـ `resume` مرة أخرى.
    ///
    Complete(R),
}

/// تم تنفيذ trait بواسطة أنواع المولدات المدمجة.
///
/// المولدات ، التي يشار إليها أيضًا باسم coroutines ، هي حاليًا ميزة لغوية تجريبية في Rust.
/// تمت إضافة مولدات [RFC 2033] حاليًا لتوفير لبنة بناء لبناء جملة async/await ولكن من المحتمل أن تمتد لتشمل أيضًا تعريفًا مريحًا للمكررات والأولويات الأخرى.
///
///
/// التركيب اللغوي والدلالات للمولدات غير مستقر وسيتطلب مزيدًا من RFC لتحقيق الاستقرار.في هذا الوقت ، على الرغم من ذلك ، فإن بناء الجملة يشبه الإغلاق:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// يمكن العثور على المزيد من وثائق المولدات في الكتاب غير المستقر.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// نوع القيمة التي ينتجها هذا المولد.
    ///
    /// يتوافق هذا النوع المرتبط مع تعبير `yield` والقيم التي يُسمح بإعادتها في كل مرة ينتج فيها المولد.
    ///
    /// على سبيل المثال ، من المحتمل أن يكون للمكرر كمولد هذا النوع مثل `T` ، النوع الذي يتم تكراره.
    ///
    type Yield;

    /// نوع القيمة التي يعيدها هذا المولد.
    ///
    /// يتوافق هذا مع النوع الذي يتم إرجاعه من المولد إما بعبارة `return` أو ضمنيًا كالتعبير الأخير للمولد الحرفي.
    /// على سبيل المثال ، قد يستخدم futures هذا كـ `Result<T, E>` لأنه يمثل future مكتملًا.
    ///
    ///
    type Return;

    /// يستأنف تنفيذ هذا المولد.
    ///
    /// ستستأنف هذه الوظيفة تنفيذ المولد أو تبدأ التنفيذ إذا لم يكن كذلك بالفعل.
    /// ستعود هذه المكالمة إلى نقطة التعليق الأخيرة للمولد ، وتستأنف التنفيذ من أحدث `yield`.
    /// سيستمر المولد في التنفيذ حتى ينتج أو يعود ، وعند هذه النقطة ستعود هذه الوظيفة.
    ///
    /// # قيمة الإرجاع
    ///
    /// يشير تعداد `GeneratorState` الذي تم إرجاعه من هذه الوظيفة إلى حالة المولد عند العودة.
    /// إذا تم إرجاع متغير `Yielded` ، فهذا يعني أن المولد قد وصل إلى نقطة تعليق وتم إنتاج قيمة.
    /// المولدات في هذه الحالة متاحة للاستئناف في وقت لاحق.
    ///
    /// إذا تم إرجاع `Complete` ، فهذا يعني أن المولد قد انتهى تمامًا بالقيمة المقدمة.غير صالح لاستئناف المولد مرة أخرى.
    ///
    /// # Panics
    ///
    /// قد تكون هذه الوظيفة panic إذا تم استدعاؤها بعد إرجاع متغير `Complete` مسبقًا.
    /// في حين أن القيم الحرفية للمولد في اللغة مضمونة لـ panic عند الاستئناف بعد `Complete` ، فإن هذا غير مضمون لجميع تطبيقات `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}