/// إصدار مشغل المكالمة الذي يأخذ جهاز استقبال ثابتًا.
///
/// يمكن استدعاء مثيلات `Fn` بشكل متكرر بدون تغيير الحالة.
///
/// *لا ينبغي الخلط بين trait (`Fn`) و [function pointers] (`fn`).*
///
/// `Fn` يتم تنفيذه تلقائيًا عن طريق عمليات الإغلاق التي تأخذ فقط إشارات غير قابلة للتغيير للمتغيرات الملتقطة أو لا تلتقط أي شيء على الإطلاق ، بالإضافة إلى (safe) [function pointers] (مع بعض التحذيرات ، راجع وثائقها لمزيد من التفاصيل).
///
/// بالإضافة إلى ذلك ، بالنسبة لأي نوع `F` يستخدم `Fn` ، يقوم `&F` بتنفيذ `Fn` أيضًا.
///
/// نظرًا لأن كلاً من [`FnMut`] و [`FnOnce`] عبارة عن صورتين فائقتين من `Fn` ، يمكن استخدام أي مثيل لـ `Fn` كمعامل حيث يُتوقع وجود [`FnMut`] أو [`FnOnce`].
///
/// استخدم `Fn` كقيد عندما تريد قبول معلمة من نوع يشبه الوظيفة وتحتاج إلى استدعائها بشكل متكرر وبدون تغيير الحالة (على سبيل المثال ، عند استدعائها بشكل متزامن).
/// إذا لم تكن بحاجة إلى مثل هذه المتطلبات الصارمة ، فاستخدم [`FnMut`] أو [`FnOnce`] كحدود.
///
/// راجع [chapter on closures in *The Rust Programming Language*][book] للحصول على مزيد من المعلومات حول هذا الموضوع.
///
/// وتجدر الإشارة أيضًا إلى البنية الخاصة لـ `Fn` traits (على سبيل المثال
/// `Fn(usize, bool) -> usize`).يمكن للمهتمين بالتفاصيل الفنية لهذا الرجوع إلى [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## استدعاء الإغلاق
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## استخدام معلمة `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // بحيث يمكن لـ regex الاعتماد على `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// ينفذ عملية المكالمة.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// إصدار مشغل المكالمة الذي يأخذ جهاز استقبال قابل للتغيير.
///
/// يمكن استدعاء مثيلات `FnMut` بشكل متكرر وقد تؤدي إلى تغيير الحالة.
///
/// `FnMut` يتم تنفيذه تلقائيًا عن طريق عمليات الإغلاق التي تأخذ إشارات قابلة للتغيير إلى المتغيرات الملتقطة ، بالإضافة إلى جميع الأنواع التي تنفذ [`Fn`] ، على سبيل المثال ، (safe) [function pointers] (نظرًا لأن `FnMut` عبارة عن صورة علوية لـ [`Fn`]).
/// بالإضافة إلى ذلك ، بالنسبة لأي نوع `F` يستخدم `FnMut` ، يقوم `&mut F` بتنفيذ `FnMut` أيضًا.
///
/// نظرًا لأن [`FnOnce`] عبارة عن صورة علوية لـ `FnMut` ، يمكن استخدام أي مثيل لـ `FnMut` حيث يتوقع [`FnOnce`] ، وبما أن [`Fn`] عبارة عن صورة فرعية لـ `FnMut` ، يمكن استخدام أي مثيل لـ [`Fn`] حيث يتوقع `FnMut`.
///
/// استخدم `FnMut` كقيد عندما تريد قبول معلمة من نوع يشبه الوظيفة وتحتاج إلى استدعائها بشكل متكرر ، مع السماح لها بتغيير الحالة.
/// إذا كنت لا تريد تغيير حالة المعلمة ، فاستخدم [`Fn`] كقيد ؛إذا لم تكن بحاجة إلى الاتصال به بشكل متكرر ، فاستخدم [`FnOnce`].
///
/// راجع [chapter on closures in *The Rust Programming Language*][book] للحصول على مزيد من المعلومات حول هذا الموضوع.
///
/// وتجدر الإشارة أيضًا إلى البنية الخاصة لـ `Fn` traits (على سبيل المثال
/// `Fn(usize, bool) -> usize`).يمكن للمهتمين بالتفاصيل الفنية لهذا الرجوع إلى [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## استدعاء إغلاق التقاط متبادل
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## استخدام معلمة `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // بحيث يمكن لـ regex الاعتماد على `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// ينفذ عملية المكالمة.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// إصدار عامل الاتصال الذي يأخذ جهاز استقبال حسب القيمة.
///
/// يمكن استدعاء مثيلات `FnOnce` ، ولكن قد لا يتم استدعاءها عدة مرات.لهذا السبب ، إذا كان الشيء الوحيد المعروف عن النوع هو أنه يستخدم `FnOnce` ، فيمكن استدعاؤه مرة واحدة فقط.
///
/// `FnOnce` يتم تنفيذه تلقائيًا عن طريق عمليات الإغلاق التي قد تستهلك المتغيرات الملتقطة ، بالإضافة إلى جميع الأنواع التي تنفذ [`FnMut`] ، على سبيل المثال ، (safe) [function pointers] (نظرًا لأن `FnOnce` عبارة عن صورة علوية لـ [`FnMut`]).
///
///
/// نظرًا لأن كلاً من [`Fn`] و [`FnMut`] عبارة عن علامات فرعية لـ `FnOnce` ، يمكن استخدام أي مثيل لـ [`Fn`] أو [`FnMut`] حيث يُتوقع وجود `FnOnce`.
///
/// استخدم `FnOnce` كقيد عندما تريد قبول معلمة من نوع يشبه الوظيفة وتحتاج فقط إلى الاتصال بها مرة واحدة.
/// إذا كنت بحاجة إلى استدعاء المعلمة بشكل متكرر ، فاستخدم [`FnMut`] كقيد ؛إذا كنت بحاجة أيضًا إلى عدم تغيير الحالة ، فاستخدم [`Fn`].
///
/// راجع [chapter on closures in *The Rust Programming Language*][book] للحصول على مزيد من المعلومات حول هذا الموضوع.
///
/// وتجدر الإشارة أيضًا إلى البنية الخاصة لـ `Fn` traits (على سبيل المثال
/// `Fn(usize, bool) -> usize`).يمكن للمهتمين بالتفاصيل الفنية لهذا الرجوع إلى [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## استخدام معلمة `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` يستهلك المتغيرات الملتقطة ، لذلك لا يمكن تشغيله أكثر من مرة.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // ستؤدي محاولة استدعاء `func()` مرة أخرى إلى ظهور خطأ `use of moved value` لـ `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` لم يعد من الممكن الاحتجاج به في هذه المرحلة
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // بحيث يمكن لـ regex الاعتماد على `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// النوع الذي تم إرجاعه بعد استخدام عامل الاتصال.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// ينفذ عملية المكالمة.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}