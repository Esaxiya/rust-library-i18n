//! مشغلي التحميل الزائد.
//!
//! يتيح لك تطبيق traits تحميل بعض المشغلين بشكل زائد.
//!
//! تم استيراد بعض traits بواسطة prelude ، لذا فهي متوفرة في كل برنامج من برامج Rust.فقط المشغلين المدعومين بـ traits يمكن تحميلهم فوق طاقتها
//! على سبيل المثال ، يمكن تحميل عامل الإضافة (`+`) بشكل زائد من خلال [`Add`] trait ، ولكن نظرًا لأن مشغل التخصيص (`=`) لا يدعم trait ، فلا توجد طريقة لزيادة تحميل دلالاته.
//! بالإضافة إلى ذلك ، لا توفر هذه الوحدة أي آلية لإنشاء مشغلين جدد.
//! إذا كانت هناك حاجة إلى تحميل زائد بدون سمة أو عوامل تشغيل مخصصة ، فيجب أن تنظر إلى وحدات الماكرو أو المكونات الإضافية للمترجم لتوسيع بناء جملة Rust.
//!
//! يجب أن تكون تطبيقات المشغل traits غير مفاجئة في سياقاتها الخاصة ، مع الأخذ في الاعتبار معانيها المعتادة و [operator precedence].
//! على سبيل المثال ، عند تنفيذ [`Mul`] ، يجب أن يكون للعملية بعض التشابه مع الضرب (ومشاركة الخصائص المتوقعة مثل الارتباط).
//!
//! لاحظ أن مشغلي `&&` و `||` يقصرون دائرة القصر ، أي أنهم يقيّمون المعامل الثاني فقط إذا كان يساهم في النتيجة.نظرًا لأن هذا السلوك غير قابل للتنفيذ بواسطة traits ، فإن `&&` و `||` لا يتم دعمهما كمعاملين قابلين للحمل الزائد.
//!
//! يأخذ العديد من المشغلين معاملاتهم بالقيمة.في السياقات غير العامة التي تتضمن أنواعًا مضمنة ، لا يمثل هذا عادةً مشكلة.
//! ومع ذلك ، فإن استخدام هذه العوامل في رمز عام يتطلب بعض الاهتمام إذا كان لابد من إعادة استخدام القيم بدلاً من السماح للمشغلين باستهلاكها.أحد الخيارات هو استخدام [`clone`] من حين لآخر.
//! خيار آخر هو الاعتماد على الأنواع المتضمنة توفير تطبيقات مشغل إضافية للمراجع.
//! على سبيل المثال ، بالنسبة للنوع `T` الذي يحدده المستخدم والذي من المفترض أن يدعم الإضافة ، فمن الأفضل أن يكون كل من `T` و `&T` يطبقان traits [`Add<T>`][`Add`] و [`Add<&T>`][`Add`] بحيث يمكن كتابة الكود العام دون استنساخ غير ضروري.
//!
//!
//! # Examples
//!
//! ينشئ هذا المثال بنية `Point` التي تنفذ [`Add`] و [`Sub`] ، ثم توضح إضافة وطرح جهازي `Point`s.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! راجع الوثائق الخاصة بكل trait للحصول على مثال للتنفيذ.
//!
//! يتم تنفيذ [`Fn`] و [`FnMut`] و [`FnOnce`] traits بواسطة أنواع يمكن استدعاءها مثل الدوال.لاحظ أن [`Fn`] يأخذ `&self` ، [`FnMut`] يأخذ `&mut self` و [`FnOnce`] يأخذ `self`.
//! تتوافق هذه مع الأنواع الثلاثة من الطرق التي يمكن استدعاؤها في مثيل: استدعاء بمرجع ، استدعاء بمرجع قابل للتغيير ، واستدعاء حسب القيمة.
//! الاستخدام الأكثر شيوعًا لـ traits هو العمل كحدود لوظائف المستوى الأعلى التي تأخذ الدوال أو الإغلاق كوسيطات.
//!
//! أخذ [`Fn`] كمعامل:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! أخذ [`FnMut`] كمعامل:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! أخذ [`FnOnce`] كمعامل:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` يستهلك المتغيرات الملتقطة ، لذلك لا يمكن تشغيله أكثر من مرة
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // ستؤدي محاولة استدعاء `func()` مرة أخرى إلى ظهور خطأ `use of moved value` لـ `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` لم يعد من الممكن الاحتجاج به في هذه المرحلة
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;