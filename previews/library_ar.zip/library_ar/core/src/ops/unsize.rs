use crate::marker::Unsize;

/// Trait يشير إلى أن هذا مؤشر أو غلاف لأحدهما ، حيث يمكن إجراء عدم تغيير الحجم على النقطة.
///
/// راجع [DST coercion RFC][dst-coerce] و [the nomicon entry on coercion][nomicon-coerce] لمزيد من التفاصيل.
///
/// بالنسبة لأنواع المؤشرات المضمنة ، ستفرض المؤشرات إلى `T` على المؤشرات إلى `U` إذا كان `T: Unsize<U>` عن طريق التحويل من مؤشر رفيع إلى مؤشر سمين.
///
/// بالنسبة للأنواع المخصصة ، يعمل الإكراه هنا عن طريق إجبار `Foo<T>` على `Foo<U>` بشرط وجود إشارة لـ `CoerceUnsized<Foo<U>> for Foo<T>`.
/// لا يمكن كتابة مثل هذا الضمانة إلا إذا كان `Foo<T>` يحتوي على حقل بيانات واحد غير وهمي يشتمل على `T`.
/// إذا كان نوع هذا الحقل هو `Bar<T>` ، فيجب أن يكون هناك تطبيق لـ `CoerceUnsized<Bar<U>> for Bar<T>`.
/// سيعمل الإكراه عن طريق إجبار حقل `Bar<T>` على `Bar<U>` وملء باقي الحقول من `Foo<T>` لإنشاء `Foo<U>`.
/// سيؤدي هذا بشكل فعال إلى الانتقال إلى حقل المؤشر وإجباره على ذلك.
///
/// بشكل عام ، بالنسبة للمؤشرات الذكية ، ستقوم بتنفيذ `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` ، مع `?Sized` اختياري مرتبط بـ `T` نفسه.
/// بالنسبة لأنواع المجمعات التي تتضمن `T` مباشرة مثل `Cell<T>` و `RefCell<T>` ، يمكنك تنفيذ `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` مباشرة.
///
/// سيسمح هذا لأنواع مثل `Cell<Box<T>>` بالعمل.
///
/// [`Unsize`][unsize] تُستخدم لتمييز الأنواع التي يمكن إجبارها على DSTs إذا كانت خلف المؤشرات.يتم تنفيذه تلقائيًا بواسطة المترجم.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut تي> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut تي> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// يستخدم هذا من أجل سلامة الكائن ، للتحقق من إمكانية إرسال نوع مستقبل الأسلوب.
///
/// مثال على تنفيذ trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut تي> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}