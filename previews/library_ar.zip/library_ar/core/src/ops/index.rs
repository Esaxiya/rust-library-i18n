/// تستخدم لفهرسة العمليات (`container[index]`) في سياقات غير قابلة للتغيير.
///
/// `container[index]` هو في الواقع سكر نحوي لـ `*container.index(index)` ، ولكن فقط عند استخدامه كقيمة غير قابلة للتغيير.
/// في حالة طلب قيمة قابلة للتغيير ، يتم استخدام [`IndexMut`] بدلاً من ذلك.
/// هذا يسمح بأشياء لطيفة مثل `let value = v[index]` إذا كان نوع `value` يستخدم [`Copy`].
///
/// # Examples
///
/// يقوم المثال التالي بتنفيذ `Index` على حاوية `NucleotideCount` للقراءة فقط ، مما يتيح استرداد الأعداد الفردية باستخدام صيغة الفهرس.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// النوع الذي تم إرجاعه بعد الفهرسة.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// ينفذ عملية فهرسة (`container[index]`).
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// تستخدم لفهرسة العمليات (`container[index]`) في سياقات قابلة للتغيير.
///
/// `container[index]` هو في الواقع سكر نحوي لـ `*container.index_mut(index)` ، ولكن فقط عند استخدامه كقيمة قابلة للتغيير.
/// إذا تم طلب قيمة غير قابلة للتغيير ، فسيتم استخدام [`Index`] trait بدلاً من ذلك.
/// هذا يسمح بأشياء جميلة مثل `v[index] = value`.
///
/// # Examples
///
/// تطبيق بسيط للغاية لهيكل `Balance` له جانبان ، حيث يمكن فهرسة كل منهما بشكل قابل للتغيير وغير قابل للتغيير.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // في هذه الحالة ، يعتبر `balance[Side::Right]` سكرًا لـ `*balance.index(Side::Right)` ، نظرًا لأننا نقرأ فقط*`balance[Side::Right]` ، ولا نكتبه.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // ومع ذلك ، في هذه الحالة ، يكون `balance[Side::Left]` سكرًا لـ `*balance.index_mut(Side::Left)` ، نظرًا لأننا نكتب `balance[Side::Left]`.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// ينفذ عملية (`container[index]`) للفهرسة القابلة للتغيير.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}