//! يحدد مكرر `IntoIter` المملوك للصفائف.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// مكرر [array] حسب القيمة.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// هذه هي المصفوفة التي نكررها.
    ///
    /// العناصر ذات الفهرس `i` حيث لم يتم إنتاج `alive.start <= i < alive.end` بعد وهي إدخالات صفيف صالحة.
    /// تم إنتاج العناصر ذات المؤشرات `i < alive.start` أو `i >= alive.end` بالفعل ويجب عدم الوصول إليها بعد الآن!قد تكون هذه العناصر الميتة في حالة غير مهيأة تمامًا!
    ///
    ///
    /// فالثوابت هي:
    /// - `data[alive]` حي (أي يحتوي على عناصر صالحة)
    /// - `data[..alive.start]` و `data[alive.end..]` ميتة (على سبيل المثال ، تمت قراءة العناصر بالفعل ويجب عدم لمسها بعد الآن!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// العناصر في `data` التي لم يتم إنتاجها بعد.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// ينشئ مكررًا جديدًا على `array` المحدد.
    ///
    /// *ملاحظة*: قد يتم إهمال هذه الطريقة في future بعد [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // نوع `value` هو `i32` هنا ، بدلاً من `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // الأمان: التحويل هنا آمن بالفعل.مستندات `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` مضمون أن يكون له نفس الحجم والمحاذاة
        // > مثل `T`.
        //
        // تُظهر المستندات تحويلاً من مصفوفة `MaybeUninit<T>` إلى مصفوفة `T`.
        //
        //
        // مع ذلك ، يفي هذا التهيئة بالثوابت.

        // FIXME(LukasKalbertodt): في الواقع استخدم `mem::transmute` هنا ، بمجرد أن يعمل مع الأدوية العامة الثابتة:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // حتى ذلك الحين ، يمكننا استخدام `mem::transmute_copy` لإنشاء نسخة بت كنوع مختلف ، ثم ننسى `array` حتى لا يتم إسقاطها.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// تُرجع شريحة غير قابلة للتغيير لكل العناصر التي لم يتم إنتاجها بعد.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // الأمان: نحن نعلم أن جميع العناصر داخل `alive` مهيأة بشكل صحيح.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// تُرجع شريحة قابلة للتغيير لجميع العناصر التي لم يتم إنتاجها بعد.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // الأمان: نحن نعلم أن جميع العناصر داخل `alive` مهيأة بشكل صحيح.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // احصل على الفهرس التالي من الأمام.
        //
        // تؤدي زيادة `alive.start` بمقدار 1 إلى الحفاظ على الثابت فيما يتعلق بـ `alive`.
        // ومع ذلك ، بسبب هذا التغيير ، لفترة قصيرة ، لم تعد المنطقة الحية `data[alive]` بعد الآن ، ولكن `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // اقرأ العنصر من المصفوفة.
            // الأمان: `idx` عبارة عن فهرس في منطقة "alive" السابقة من
            // مجموعة مصفوفة.قراءة هذا العنصر تعني أن `data[idx]` يعتبر ميتًا الآن (أي لا تلمس).
            // نظرًا لأن `idx` كان بداية منطقة الحياة ، أصبحت المنطقة الحية الآن `data[alive]` مرة أخرى ، مع استعادة جميع الثوابت.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // احصل على الفهرس التالي من الخلف.
        //
        // يؤدي خفض `alive.end` بمقدار 1 إلى الحفاظ على الثابت فيما يتعلق بـ `alive`.
        // ومع ذلك ، بسبب هذا التغيير ، لفترة قصيرة ، لم تعد المنطقة الحية `data[alive]` بعد الآن ، ولكن `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // اقرأ العنصر من المصفوفة.
            // الأمان: `idx` عبارة عن فهرس في منطقة "alive" السابقة من
            // مجموعة مصفوفة.قراءة هذا العنصر تعني أن `data[idx]` يعتبر ميتًا الآن (أي لا تلمس).
            // نظرًا لأن `idx` كان نهاية منطقة الحياة ، أصبحت المنطقة الحية الآن `data[alive]` مرة أخرى ، واستعادة جميع الثوابت.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // الأمان: هذا آمن: يقوم `as_mut_slice` بإرجاع الشريحة الفرعية بالضبط
        // من العناصر التي لم يتم نقلها بعد والتي لا يزال يتعين إسقاطها.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // لن ينخفض أبدًا بسبب الثابت `` على قيد الحياة.بدء <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// يقوم المكرر بالفعل بالإبلاغ عن الطول الصحيح.
// عدد عناصر "alive" (التي سيظل إنتاجها) هو طول النطاق `alive`.
// يتم تقليل هذا النطاق في الطول إما في `next` أو `next_back`.
// يتم إنقاصها دائمًا بمقدار 1 في تلك الطرق ، ولكن فقط إذا تم إرجاع `Some(_)`.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // لاحظ أننا لا نحتاج حقًا إلى مطابقة نفس النطاق الحي تمامًا ، لذلك يمكننا فقط استنساخه في الإزاحة 0 بغض النظر عن مكان `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // استنساخ جميع العناصر الحية.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // اكتب استنساخًا في المصفوفة الجديدة ، ثم حدِّث نطاقها الحي.
            // إذا تم استنساخ panics ، فسنقوم بإسقاط العناصر السابقة بشكل صحيح.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // اطبع فقط العناصر التي لم يتم إنتاجها بعد: لا يمكننا الوصول إلى العناصر الناتجة بعد الآن.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}