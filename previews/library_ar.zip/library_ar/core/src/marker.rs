//! traits البدائية وأنواع تمثل الخصائص الأساسية للأنواع.
//!
//! يمكن تصنيف أنواع Rust بطرق مفيدة مختلفة وفقًا لخصائصها الجوهرية.
//! يتم تمثيل هذه التصنيفات على أنها traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// الأنواع التي يمكن نقلها عبر حدود الخيط.
///
/// يتم تطبيق trait تلقائيًا عندما يقرر المترجم أنه مناسب.
///
/// مثال على نوع غير "إرسال" هو مؤشر عد الإشارة [`rc::Rc`][`Rc`].
/// إذا حاولت خيوطان استنساخ [`Rc`] التي تشير إلى نفس القيمة المحسوبة بالمرجع ، فقد يحاولان تحديث عدد المرجع في نفس الوقت ، وهو [undefined behavior][ub] لأن [`Rc`] لا يستخدم العمليات الذرية.
///
/// يستخدم ابن عمه [`sync::Arc`][arc] العمليات الذرية (تكبد بعض النفقات العامة) وبالتالي هو `Send`.
///
/// انظر [the Nomicon](../../nomicon/send-and-sync.html) لمزيد من التفاصيل.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// الأنواع ذات الحجم الثابت المعروف في وقت الترجمة.
///
/// جميع معلمات النوع لها حد ضمني لـ `Sized`.يمكن استخدام الصيغة الخاصة `?Sized` لإزالة هذا الربط إذا لم يكن ذلك مناسبًا.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // هيكل FooUse(Foo<[i32]>) ؛//خطأ: الحجم غير مطبق لـ [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// الاستثناء الوحيد هو نوع `Self` الضمني لـ trait.
/// لا يحتوي trait على ربط `Sized` ضمنيًا لأن هذا غير متوافق مع [كائن trait] حيث ، بحكم التعريف ، يحتاج trait إلى العمل مع جميع المنفذات الممكنة ، وبالتالي يمكن أن يكون بأي حجم.
///
///
/// على الرغم من أن Rust ستتيح لك ربط `Sized` بـ trait ، فلن تتمكن من استخدامه لتكوين كائن trait لاحقًا:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // دع y: شريط &dyn = &Impl ؛//خطأ: لا يمكن تحويل trait `Bar` إلى كائن
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // للإعداد الافتراضي ، على سبيل المثال ، والذي يتطلب أن يكون `[T]: !Default` قابلاً للتقييم
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// الأنواع التي يمكن أن تكون "unsized" إلى نوع ذي حجم ديناميكي.
///
/// على سبيل المثال ، يقوم نوع الصفيف ذي الحجم `[i8; 2]` بتنفيذ `Unsize<[i8]>` و `Unsize<dyn fmt::Debug>`.
///
/// يتم توفير جميع تطبيقات `Unsize` تلقائيًا بواسطة المترجم.
///
/// `Unsize` يتم تنفيذه من أجل:
///
/// - `[T; N]` هو `Unsize<[T]>`
/// - `T` هو `Unsize<dyn Trait>` عندما `T: Trait`
/// - `Foo<..., T, ...>` هو `Unsize<Foo<..., U, ...>>` إذا:
///   - `T: Unsize<U>`
///   - فو هو هيكل
///   - يحتوي الحقل الأخير من `Foo` فقط على نوع يتضمن `T`
///   - `T` ليس جزءًا من نوع أي حقول أخرى
///   - `Bar<T>: Unsize<Bar<U>>`, إذا كان الحقل الأخير من `Foo` من النوع `Bar<T>`
///
/// `Unsize` يتم استخدامه مع [`ops::CoerceUnsized`] للسماح لحاويات "user-defined" مثل [`Rc`] لاحتواء أنواع ذات حجم ديناميكي.
/// راجع [DST coercion RFC][RFC982] و [the nomicon entry on coercion][nomicon-coerce] لمزيد من التفاصيل.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// مطلوب trait للثوابت المستخدمة في تطابقات النمط.
///
/// أي نوع يشتق `PartialEq` يقوم تلقائيًا بتنفيذ trait هذا ،*بغض النظر* عما إذا كانت معلمات النوع الخاصة به تنفذ `Eq`.
///
/// إذا كان عنصر `const` يحتوي على نوع ما لا يطبق trait هذا ، فإن هذا النوع إما (1.) لا يطبق `PartialEq` (مما يعني أن الثابت لن يوفر طريقة المقارنة هذه ، والتي يفترض إنشاء الكود أنها متوفرة) ، أو (2.) ينفذها *الخاصة بها* إصدار `PartialEq` (الذي نفترض أنه لا يتوافق مع مقارنة المساواة الهيكلية).
///
///
/// في أي من السيناريوهين أعلاه ، نرفض استخدام مثل هذا الثابت في تطابق النمط.
///
/// راجع أيضًا [structural match RFC][RFC1445] و [issue 63438] اللذان حفزا الهجرة من التصميم المستند إلى السمات إلى trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// مطلوب trait للثوابت المستخدمة في تطابقات النمط.
///
/// أي نوع يشتق `Eq` يقوم تلقائيًا بتنفيذ trait هذا ،*بغض النظر* عما إذا كانت معلمات النوع الخاصة به تنفذ `Eq`.
///
/// يعد هذا اختراقًا للتغلب على قيود في نظام النوع الخاص بنا.
///
/// # Background
///
/// نريد أن نطلب أن يكون لهذه الأنواع من الثوابت المستخدمة في تطابقات النمط السمة `#[derive(PartialEq, Eq)]`.
///
/// في عالم أكثر مثالية ، يمكننا التحقق من هذا المطلب بمجرد التحقق من أن النوع المحدد يستخدم كلاً من `StructuralPartialEq` trait *و*`Eq` trait.
/// ومع ذلك ، يمكن أن يكون لديك ADTs التي *تفعل*`derive(PartialEq, Eq)` ، وتكون حالة نريد أن يقبلها المترجم ، ومع ذلك يفشل نوع الثابت في تنفيذ `Eq`.
///
/// وهي حالة مثل هذه:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (المشكلة في الكود أعلاه هي أن `Wrap<fn(&())>` لا يطبق `PartialEq` ولا `Eq` ، لأن `` لـ <'a> fn(&'a _)` does not implement those traits.)
///
/// لذلك ، لا يمكننا الاعتماد على فحص ساذج لـ `StructuralPartialEq` و `Eq` فقط.
///
/// كاختراق للتغلب على هذا ، نستخدم نوعين منفصلين من traits يتم حقنها بواسطة كل من المشتقين (`#[derive(PartialEq)]` و `#[derive(Eq)]`) والتحقق من وجودهما كجزء من فحص المطابقة الهيكلية.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// الأنواع التي يمكن تكرار قيمها ببساطة عن طريق نسخ البتات.
///
/// بشكل افتراضي ، تحتوي الارتباطات المتغيرة على "نقل دلالات".بعبارات أخرى:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` انتقل إلى `y` ، وبالتالي لا يمكن استخدامه
///
/// // println! ("{: ؟}"، x) ؛//خطأ: استخدام القيمة المنقولة
/// ```
///
/// ومع ذلك ، إذا كان النوع يطبق `Copy` ، فإنه يحتوي بدلاً من ذلك على "نسخ دلالات":
///
/// ```
/// // يمكننا اشتقاق تطبيق `Copy`.
/// // `Clone` مطلوب أيضًا ، لأنه صورة عالية لـ `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` هي نسخة من `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// من المهم ملاحظة أنه في هذين المثالين ، يكون الاختلاف الوحيد هو ما إذا كان يُسمح لك بالوصول إلى `x` بعد المهمة.
/// تحت غطاء المحرك ، يمكن أن ينتج عن كل من النسخ والحركة نسخ وحدات بت في الذاكرة ، على الرغم من أن هذا يتم تحسينه بعيدًا في بعض الأحيان.
///
/// ## كيف يمكنني تنفيذ `Copy`؟
///
/// هناك طريقتان لتطبيق `Copy` على النوع الخاص بك.أبسطها هو استخدام `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// يمكنك أيضًا تنفيذ `Copy` و `Clone` يدويًا:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// هناك فرق بسيط بين الاثنين: ستضع إستراتيجية `derive` أيضًا `Copy` مرتبطًا بمعلمات النوع ، وهو أمر غير مرغوب فيه دائمًا.
///
/// ## ما الفرق بين `Copy` و `Clone`؟
///
/// تحدث النسخ بشكل ضمني ، على سبيل المثال كجزء من مهمة `y = x`.سلوك `Copy` ليس مفرط التحميل ؛إنها دائمًا نسخة بسيطة من الحكمة.
///
/// الاستنساخ إجراء صريح ، `x.clone()`.يمكن أن يوفر تنفيذ [`Clone`] أي سلوك خاص بالنوع ضروري لتكرار القيم بأمان.
/// على سبيل المثال ، يحتاج تطبيق [`Clone`] لـ [`String`] إلى نسخ المخزن المؤقت للسلسلة المشار إليها في الكومة.
/// ستؤدي نسخة بسيطة من قيم [`String`] إلى نسخ المؤشر ، مما يؤدي إلى تحرير مزدوج أسفل الخط.
/// لهذا السبب ، [`String`] هو [`Clone`] وليس `Copy`.
///
/// [`Clone`] هي صورة عمودية لـ `Copy` ، لذا يجب أن يستخدم كل شيء `Copy` أيضًا [`Clone`].
/// إذا كان النوع هو `Copy` ، فإن تطبيق [`Clone`] الخاص به يحتاج فقط إلى إرجاع `*self` (انظر المثال أعلاه).
///
/// ## متى يمكن أن يكون نوعي `Copy`؟
///
/// يمكن أن يقوم النوع بتنفيذ `Copy` إذا كانت جميع مكوناته تنفذ `Copy`.على سبيل المثال ، يمكن أن تكون هذه البنية `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// يمكن أن يكون الهيكل `Copy` ، و [`i32`] هو `Copy` ، وبالتالي فإن `Point` مؤهل ليكون `Copy`.
/// على النقيض من ذلك ، ضع في اعتبارك
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// لا يمكن للبنية `PointList` تنفيذ `Copy` ، لأن [`Vec<T>`] ليس `Copy`.إذا حاولنا اشتقاق تطبيق `Copy` ، فسنحصل على خطأ:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// المراجع المشتركة (`&T`) هي أيضًا `Copy` ، لذلك يمكن أن يكون النوع `Copy` ، حتى عندما يحتوي على مراجع مشتركة من الأنواع `T` التي *ليست*`Copy`.
/// ضع في اعتبارك الهيكل التالي ، الذي يمكنه تنفيذ `Copy` ، لأنه يحتوي فقط على مرجع *مشترك* لنوع `PointList` غير "نسخ" من أعلى:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## متى *لا يمكن* أن يكون نوعي `Copy`؟
///
/// لا يمكن نسخ بعض الأنواع بأمان.على سبيل المثال ، قد يؤدي نسخ `&mut T` إلى إنشاء مرجع مستعار قابل للتغيير.
/// قد يؤدي نسخ [`String`] إلى تكرار المسؤولية عن إدارة المخزن المؤقت لـ [`String`] ، مما يؤدي إلى ضعف مجاني.
///
/// بتعميم الحالة الأخيرة ، لا يمكن أن يكون أي نوع يقوم بتنفيذ [`Drop`] هو `Copy` ، لأنه يدير بعض الموارد إلى جانب وحدات بايت [`size_of::<T>`] الخاصة به.
///
/// إذا حاولت تنفيذ `Copy` على بنية أو تعداد يحتوي على بيانات غير "نسخ" ، فستتلقى الخطأ [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## متى *يجب* أن يكون نوعي `Copy`؟
///
/// بشكل عام ، إذا كان نوع _can_ الخاص بك يطبق `Copy` ، فيجب أن يكون.
/// ومع ذلك ، ضع في اعتبارك أن تنفيذ `Copy` هو جزء من واجهة برمجة التطبيقات العامة من نوعك.
/// إذا كان النوع غير "نسخ" في future ، فقد يكون من الحكمة حذف تنفيذ `Copy` الآن ، لتجنب تغيير واجهة برمجة التطبيقات معطل.
///
/// ## المنفذين الإضافيين
///
/// بالإضافة إلى [implementors listed below][impls] ، تستخدم الأنواع التالية أيضًا `Copy`:
///
/// * أنواع عناصر الوظائف (على سبيل المثال ، الأنواع المميزة المحددة لكل وظيفة)
/// * أنواع مؤشرات الوظائف (على سبيل المثال ، `fn() -> i32`)
/// * أنواع المصفوفات ، لجميع الأحجام ، إذا كان نوع العنصر يستخدم أيضًا `Copy` (على سبيل المثال ، `[i32; 123456]`)
/// * أنواع Tuple ، إذا كان كل مكون يستخدم أيضًا `Copy` (على سبيل المثال ، `()` ، `(i32, bool)`)
/// * أنواع الإغلاق ، إذا كانت لا تلتقط أي قيمة من البيئة أو إذا كانت جميع هذه القيم الملتقطة تطبق `Copy` نفسها.
///   لاحظ أن المتغيرات الملتقطة بواسطة المرجع المشترك تنفذ دائمًا `Copy` (حتى لو لم يكن المرجع) ، بينما المتغيرات التي تم التقاطها بواسطة المرجع المتغير لا تنفذ `Copy` أبدًا.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) يسمح هذا بنسخ نوع لا يطبق `Copy` بسبب حدود عمر غير مرضية (نسخ `A<'_>` عند `A<'static>: Copy` و `A<'_>: Clone` فقط).
// لدينا هذه السمة هنا في الوقت الحالي فقط لأن هناك عددًا قليلاً من التخصصات الموجودة على `Copy` الموجودة بالفعل في المكتبة القياسية ، ولا توجد طريقة للحصول على هذا السلوك بأمان في الوقت الحالي.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// اشتق الماكرو لتوليد إشارة من trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// الأنواع التي من الآمن مشاركة المراجع بين سلاسل الرسائل لها.
///
/// يتم تطبيق trait تلقائيًا عندما يقرر المترجم أنه مناسب.
///
/// التعريف الدقيق هو: النوع `T` هو [`Sync`] إذا وفقط إذا كان `&T` هو [`Send`].
/// بمعنى آخر ، إذا لم يكن هناك احتمال لـ [undefined behavior][ub] (بما في ذلك سباقات البيانات) عند تمرير مراجع `&T` بين سلاسل العمليات.
///
/// كما قد يتوقع المرء ، فإن الأنواع البدائية مثل [`u8`] و [`f64`] كلها [`Sync`] ، وكذلك الأنواع التجميعية البسيطة التي تحتوي عليها ، مثل المجموعات والبنى والتعدادات.
/// تتضمن المزيد من الأمثلة على أنواع [`Sync`] الأساسية أنواع "immutable" مثل `&T` ، وتلك التي تحتوي على قابلية تغيير وراثية بسيطة ، مثل [`Box<T>`][box] و [`Vec<T>`][vec] ومعظم أنواع المجموعات الأخرى.
///
/// (يجب أن تكون المعلمات العامة [`Sync`] لكي تكون الحاوية الخاصة بهم [`Sync`].)
///
/// النتيجة المفاجئة إلى حد ما للتعريف هي أن `&mut T` هو `Sync` (إذا كان `T` هو `Sync`) على الرغم من أنه يبدو أن هذا قد يوفر طفرة غير متزامنة.
/// الحيلة هي أن المرجع القابل للتغيير خلف مرجع مشترك (أي ، `& &mut T`) يصبح للقراءة فقط ، كما لو كان `& &T`.
/// ومن ثم لا يوجد خطر حدوث سباق بيانات.
///
/// الأنواع التي ليست `Sync` هي تلك التي تحتوي على "interior mutability" في شكل غير آمن لمؤشر الترابط ، مثل [`Cell`][cell] و [`RefCell`][refcell].
/// تسمح هذه الأنواع بتغيير محتوياتها حتى من خلال مرجع مشترك غير قابل للتغيير.
/// على سبيل المثال ، تأخذ طريقة `set` على [`Cell<T>`][cell] `&self` ، لذا فهي تتطلب فقط مرجعًا مشتركًا [`&Cell<T>`][cell].
/// لا تؤدي الطريقة أي مزامنة ، وبالتالي لا يمكن أن يكون [`Cell`][cell] `Sync`.
///
/// مثال آخر على النوع غير "المزامنة" هو مؤشر عدّ المرجع [`Rc`][rc].
/// بالنظر إلى أي مرجع [`&Rc<T>`][rc] ، يمكنك استنساخ [`Rc<T>`][rc] جديد ، وتعديل عدد المراجع بطريقة غير ذرية.
///
/// بالنسبة للحالات التي يحتاج فيها المرء إلى تغيير داخلي آمن للخيط ، يوفر Rust [atomic data types] ، بالإضافة إلى قفل صريح عبر [`sync::Mutex`][mutex] و [`sync::RwLock`][rwlock].
/// تضمن هذه الأنواع أن أي طفرة لا يمكن أن تسبب سباقات البيانات ، وبالتالي الأنواع هي `Sync`.
/// وبالمثل ، يوفر [`sync::Arc`][arc] تناظريًا آمنًا لمؤشر [`Rc`][rc].
///
/// يجب أن تستخدم أي أنواع ذات قابلية تغيير داخلية أيضًا غلاف [`cell::UnsafeCell`][unsafecell] حول value(s) والذي يمكن تغييره من خلال مرجع مشترك.
/// فشل في القيام بذلك هو [undefined behavior][ub].
/// على سبيل المثال ، [`تحويل`][نقل]-ing من `&T` إلى `&mut T` غير صالح.
///
/// راجع [the Nomicon][nomicon-send-and-sync] لمزيد من التفاصيل حول `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): بمجرد وصول الدعم لإضافة ملاحظات في `rustc_on_unimplemented` إلى الإصدار التجريبي ، وتم تمديده للتحقق مما إذا كان الإغلاق في أي مكان في سلسلة المتطلبات ، قم بتوسيعه على هذا النحو (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// النوع ذو الحجم الصفري المستخدم لتمييز الأشياء التي "act like" يمتلكونها `T`.
///
/// إضافة حقل `PhantomData<T>` إلى النوع الخاص بك يخبر المترجم أن النوع الخاص بك يعمل كما لو أنه يخزن قيمة من النوع `T` ، على الرغم من أنها ليست كذلك بالفعل.
/// يتم استخدام هذه المعلومات عند حساب خصائص أمان معينة.
///
/// للحصول على شرح أكثر تفصيلاً حول كيفية استخدام `PhantomData<T>` ، يرجى مراجعة [the Nomicon](../../nomicon/phantom-data.html).
///
/// # ملاحظة مروعة 👻👻👻
///
/// على الرغم من أن كلاهما لهما أسماء مخيفة ، إلا أن `PhantomData` و "الأنواع الوهمية" مرتبطان ببعضهما البعض ولكنهما غير متطابقين.معلمة النوع الوهمي هي ببساطة معلمة نوع لا يتم استخدامها أبدًا.
/// في Rust ، غالبًا ما يتسبب هذا في شكوى المترجم ، والحل هو إضافة استخدام "dummy" عن طريق `PhantomData`.
///
/// # Examples
///
/// ## معلمات العمر غير المستخدمة
///
/// ربما تكون حالة الاستخدام الأكثر شيوعًا لـ `PhantomData` هي بنية بها معلمة عمر غير مستخدمة ، عادةً كجزء من بعض التعليمات البرمجية غير الآمنة.
/// على سبيل المثال ، يوجد هنا هيكل `Slice` يحتوي على مؤشرين من النوع `*const T` ، يفترض أنه يشير إلى مصفوفة في مكان ما:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// القصد من ذلك هو أن البيانات الأساسية صالحة فقط لعمر `'a` ، لذلك يجب ألا يتجاوز `Slice` `'a`.
/// ومع ذلك ، لا يتم التعبير عن هذه النية في الكود ، نظرًا لعدم وجود استخدامات لعمر `'a` وبالتالي ليس من الواضح ما هي البيانات التي تنطبق عليها.
/// يمكننا تصحيح ذلك عن طريق إخبار المترجم بالتصرف *كما لو أن* بنية `Slice` تحتوي على مرجع `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// وهذا بدوره يتطلب التعليق التوضيحي `T: 'a` ، مما يشير إلى أن أي مراجع في `T` صالحة طوال عمر `'a`.
///
/// عند تهيئة `Slice` ، يمكنك ببساطة توفير القيمة `PhantomData` للحقل `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## معلمات النوع غير المستخدمة
///
/// يحدث أحيانًا أن يكون لديك معلمات نوع غير مستخدمة تشير إلى نوع البيانات التي يستخدمها الهيكل "tied" ، على الرغم من أن هذه البيانات غير موجودة بالفعل في البنية نفسها.
/// هنا مثال حيث ينشأ هذا مع [FFI].
/// تستخدم الواجهة الخارجية مقابض من النوع `*mut ()` للإشارة إلى قيم Rust لأنواع مختلفة.
/// نتعقب نوع Rust باستخدام معلمة نوع وهمي على الهيكل `ExternalResource` الذي يلف المقبض.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## الملكية وقطرة الشيك
///
/// تشير إضافة حقل من النوع `PhantomData<T>` إلى أن النوع الخاص بك يمتلك بيانات من النوع `T`.وهذا بدوره يعني أنه عند إسقاط النوع الخاص بك ، فقد يسقط مثيل واحد أو أكثر من النوع `T`.
/// هذا له تأثير على تحليل [drop check] للمجمع Rust.
///
/// إذا لم يكن الهيكل الخاص بك في الواقع *يمتلك* بيانات من النوع `T` ، فمن الأفضل استخدام نوع مرجعي ، مثل `PhantomData<&'a T>` (ideally) أو `PhantomData<*const T>` (إذا لم يكن هناك عمر مطبق) ، حتى لا تشير إلى الملكية.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// يستخدم المترجم الداخلي trait للإشارة إلى نوع مميِّزات التعداد.
///
/// يتم تنفيذ trait تلقائيًا لكل نوع ولا يضيف أي ضمانات إلى [`mem::Discriminant`].
/// إنه **سلوك غير محدد** للتحويل بين `DiscriminantKind::Discriminant` و `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// نوع المميز ، الذي يجب أن يفي بـ trait bounds المطلوبة بواسطة `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// يستخدم المترجم الداخلي trait لتحديد ما إذا كان النوع يحتوي على أي `UnsafeCell` داخليًا ، ولكن ليس من خلال المراوغة.
///
/// يؤثر هذا ، على سبيل المثال ، على ما إذا كان `static` من هذا النوع يتم وضعه في ذاكرة ثابتة للقراءة فقط أو ذاكرة ثابتة قابلة للكتابة.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// الأنواع التي يمكن نقلها بأمان بعد تثبيتها.
///
/// Rust نفسها ليس لديها فكرة عن الأنواع غير المنقولة ، وتعتبر التحركات (على سبيل المثال ، من خلال التعيين أو [`mem::replace`]) آمنة دائمًا.
///
/// يتم استخدام النوع [`Pin`][Pin] بدلاً من ذلك لمنع التحركات عبر نظام الكتابة.لا يمكن نقل المؤشرات `P<T>` الملفوفة في غلاف [`Pin<P<T>>`][Pin] خارج.
/// راجع وثائق [`pin` module] للحصول على مزيد من المعلومات حول التثبيت.
///
/// يؤدي تطبيق `Unpin` trait لـ `T` إلى رفع قيود تثبيت النوع ، مما يسمح بعد ذلك بنقل `T` من [`Pin<P<T>>`][Pin] بوظائف مثل [`mem::replace`].
///
///
/// `Unpin` ليس له أي عواقب على الإطلاق بالنسبة للبيانات غير المثبتة.
/// على وجه الخصوص ، ينقل [`mem::replace`] بسعادة بيانات `!Unpin` (يعمل مع أي `&mut T` ، وليس فقط عند `T: Unpin`).
/// ومع ذلك ، لا يمكنك استخدام [`mem::replace`] على البيانات الملفوفة داخل [`Pin<P<T>>`][Pin] لأنه لا يمكنك الحصول على `&mut T` الذي تحتاجه لذلك ، و *هذا* هو ما يجعل هذا النظام يعمل.
///
/// لذلك ، على سبيل المثال ، لا يمكن القيام بذلك إلا على الأنواع التي تطبق `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // نحتاج إلى مرجع متغير لاستدعاء `mem::replace`.
/// // يمكننا الحصول على مثل هذا المرجع عن طريق استدعاء (implicitly) لاستدعاء `Pin::deref_mut` ، لكن هذا ممكن فقط لأن `String` يستخدم `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// يتم تنفيذ trait تلقائيًا لكل نوع تقريبًا.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// نوع محدد لا يقوم بتطبيق `Unpin`.
///
/// إذا كان النوع يحتوي على `PhantomPinned` ، فلن يقوم بتطبيق `Unpin` افتراضيًا.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// تطبيقات `Copy` للأنواع البدائية.
///
/// يتم تنفيذ التطبيقات التي لا يمكن وصفها في Rust في `traits::SelectionContext::copy_clone_conditions()` في `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// يمكن نسخ المراجع المشتركة ، لكن المراجع القابلة للتغيير *لا يمكن*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}