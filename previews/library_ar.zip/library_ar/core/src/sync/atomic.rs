//! الأنواع الذرية
//!
//! توفر الأنواع الذرية اتصالات الذاكرة المشتركة البدائية بين الخيوط ، وهي اللبنات الأساسية للأنواع المتزامنة الأخرى.
//!
//! تحدد هذه الوحدة الإصدارات الذرية لعدد محدد من الأنواع البدائية ، بما في ذلك [`AtomicBool`] و [`AtomicIsize`] و [`AtomicUsize`] و [`AtomicI8`] و [`AtomicU16`] وما إلى ذلك.
//! تقدم الأنواع الذرية العمليات التي ، عند استخدامها بشكل صحيح ، تقوم بمزامنة التحديثات بين مؤشرات الترابط.
//!
//! تأخذ كل طريقة [`Ordering`] والتي تمثل قوة حاجز الذاكرة لتلك العملية.هذه الطلبات هي نفس [C++20 atomic orderings][1].لمزيد من المعلومات راجع [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! المتغيرات الذرية آمنة للمشاركة بين الخيوط (تنفذ [`Sync`]) لكنها لا توفر آلية للمشاركة واتباع [threading model](../../../std/thread/index.html#the-threading-model) من Rust.
//!
//! الطريقة الأكثر شيوعًا لمشاركة متغير ذري هي وضعه في [`Arc`][arc] (مؤشر مشترك محسوب بمرجع ذري).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! يمكن تخزين الأنواع الذرية في متغيرات ثابتة ، يتم تهيئتها باستخدام المبدئ الثابت مثل [`AtomicBool::new`].غالبًا ما تُستخدم الإحصائيات الذرية للتهيئة العامة البطيئة.
//!
//! # Portability
//!
//! جميع الأنواع الذرية في هذه الوحدة مضمونة لتكون [lock-free] إذا كانت متوفرة.هذا يعني أنهم لا يكتسبون داخليًا كائن مزامنة عالمي.لا يمكن ضمان عدم انتظار الأنواع والعمليات الذرية.
//! هذا يعني أنه يمكن تنفيذ عمليات مثل `fetch_or` باستخدام حلقة مقارنة ومبادلة.
//!
//! يمكن تنفيذ العمليات الذرية في طبقة التعليمات باستخدام ذرات أكبر حجمًا.على سبيل المثال ، تستخدم بعض الأنظمة الأساسية تعليمات ذرية 4 بايت لتنفيذ `AtomicI8`.
//! لاحظ أن هذه المحاكاة لا ينبغي أن يكون لها تأثير على صحة الكود ، إنها مجرد شيء يجب أن تكون على دراية به.
//!
//! قد لا تتوفر الأنواع الذرية في هذه الوحدة على جميع الأنظمة الأساسية.الأنواع الذرية هنا متاحة على نطاق واسع ، ومع ذلك ، يمكن الاعتماد عليها بشكل عام.بعض الاستثناءات البارزة هي:
//!
//! * PowerPC لا تحتوي الأنظمة الأساسية MIPS ذات المؤشرات 32 بت على أنواع `AtomicU64` أو `AtomicI64`.
//! * ARM توفر الأنظمة الأساسية مثل `armv5te` غير المخصصة لـ Linux عمليات `load` و `store` فقط ، ولا تدعم عمليات المقارنة و Swap (CAS) ، مثل `swap` و `fetch_add` وما إلى ذلك.
//! بالإضافة إلى ذلك في Linux ، يتم تنفيذ عمليات CAS هذه عبر [operating system support] ، والتي قد تأتي مع غرامة الأداء.
//! * ARM الأهداف مع `thumbv6m` توفر فقط عمليات `load` و `store` ، ولا تدعم عمليات المقارنة و Swap (CAS) ، مثل `swap` ، `fetch_add` ، إلخ.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! لاحظ أنه يمكن إضافة منصات future التي لا تدعم أيضًا بعض العمليات الذرية.ستحتاج الشفرة المحمولة القصوى إلى توخي الحذر بشأن الأنواع الذرية المستخدمة.
//! `AtomicUsize` و `AtomicIsize` هما الأكثر قابلية للحمل بشكل عام ، لكنهما غير متاحين في كل مكان.
//! كمرجع ، تتطلب مكتبة `std` ذرات بحجم المؤشر ، على الرغم من أن `core` لا تفعل ذلك.
//!
//! ستحتاج حاليًا إلى استخدام `#[cfg(target_arch)]` بشكل أساسي للتجميع المشروط في التعليمات البرمجية باستخدام الذرة.هناك أيضًا `#[cfg(target_has_atomic)]` غير مستقر والذي قد يكون مستقرًا في future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! سبينلوك بسيط:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // انتظر حتى يقوم الخيط الآخر بتحرير القفل
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! احتفظ بإحصاء عالمي للخيوط الحية:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// نوع منطقي يمكن مشاركته بأمان بين الخيوط.
///
/// هذا النوع له نفس التمثيل في الذاكرة مثل [`bool`].
///
/// **ملاحظة**: هذا النوع متاح فقط على المنصات التي تدعم الأحمال الذرية ومخازن `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// ينشئ `AtomicBool` مهيأ إلى `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// يتم تطبيق الإرسال بشكل ضمني لـ AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// نوع مؤشر خام يمكن مشاركته بأمان بين سلاسل الرسائل.
///
/// هذا النوع له نفس التمثيل في الذاكرة مثل `*mut T`.
///
/// **ملاحظة**: هذا النوع متاح فقط على المنصات التي تدعم الأحمال الذرية ومخازن المؤشرات.
/// يعتمد حجمه على حجم المؤشر المستهدف.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// ينشئ `AtomicPtr<T>` فارغة.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// ترتيب الذاكرة الذرية
///
/// تحدد أوامر الذاكرة الطريقة التي تزامن بها العمليات الذرية الذاكرة.
/// في أضعف [`Ordering::Relaxed`] ، تتم مزامنة الذاكرة التي تم لمسها مباشرة بالعملية فقط.
/// من ناحية أخرى ، يقوم زوج من عمليات [`Ordering::SeqCst`] بتحميل المخزن بمزامنة الذاكرة الأخرى مع الاحتفاظ أيضًا بترتيب إجمالي لهذه العمليات عبر جميع مؤشرات الترابط.
///
///
/// طلبات ذاكرة Rust هي [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// لمزيد من المعلومات راجع [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// لا توجد قيود على الطلب ، فقط العمليات الذرية.
    ///
    /// يتوافق مع [`memory_order_relaxed`] في C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// عند الاقتران بمتجر ، يتم ترتيب جميع العمليات السابقة قبل أي تحميل بهذه القيمة مع طلب [`Acquire`] (أو أقوى).
    ///
    /// على وجه الخصوص ، تصبح جميع عمليات الكتابة السابقة مرئية لجميع مؤشرات الترابط التي تؤدي تحميل [`Acquire`] (أو أقوى) من هذه القيمة.
    ///
    /// لاحظ أن استخدام هذا الترتيب لعملية تجمع بين الأحمال والمخازن يؤدي إلى عملية تحميل [`Relaxed`]!
    ///
    /// هذا الطلب قابل للتطبيق فقط للعمليات التي يمكن أن تؤدي متجرًا.
    ///
    /// يتوافق مع [`memory_order_release`] في C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// عند اقترانها بحمل ، إذا تمت كتابة القيمة المحملة بواسطة عملية تخزين مع طلب [`Release`] (أو أقوى) ، فسيتم ترتيب جميع العمليات اللاحقة بعد هذا المخزن.
    /// على وجه الخصوص ، ستشاهد جميع الأحمال اللاحقة البيانات المكتوبة قبل المتجر.
    ///
    /// لاحظ أن استخدام هذا الطلب لعملية تجمع بين الأحمال والمخازن يؤدي إلى تشغيل متجر [`Relaxed`]!
    ///
    /// هذا الترتيب قابل للتطبيق فقط للعمليات التي يمكن أن تؤدي حمولة.
    ///
    /// يتوافق مع [`memory_order_acquire`] في C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// له تأثيرات كل من [`Acquire`] و [`Release`] معًا:
    /// بالنسبة للأحمال ، يستخدم ترتيب [`Acquire`].بالنسبة للمخازن ، فإنه يستخدم ترتيب [`Release`].
    ///
    /// لاحظ أنه في حالة `compare_and_swap` ، من الممكن أن تنتهي العملية بعدم تنفيذ أي متجر ، وبالتالي فهي تحتوي فقط على طلب [`Acquire`].
    ///
    /// ومع ذلك ، لن يقوم `AcqRel` مطلقًا بتنفيذ عمليات الوصول إلى [`Relaxed`].
    ///
    /// هذا الترتيب قابل للتطبيق فقط للعمليات التي تجمع بين كل من الأحمال والمخازن.
    ///
    /// يتوافق مع [`memory_order_acq_rel`] في C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// مثل [`Acquire`]/[`Release`]/[`AcqRel`](لعمليات التحميل والتخزين والتحميل مع المتجر ، على التوالي) مع ضمان إضافي بأن جميع سلاسل العمليات ترى جميع العمليات المتسقة بالتتابع بنفس الترتيب .
    ///
    ///
    /// يتوافق مع [`memory_order_seq_cst`] في C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// تم تهيئة [`AtomicBool`] إلى `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// ينشئ `AtomicBool` جديد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// إرجاع مرجع قابل للتغيير إلى [`bool`] الأساسي.
    ///
    /// هذا آمن لأن المرجع القابل للتغيير يضمن عدم وصول أي خيوط أخرى بشكل متزامن إلى البيانات الذرية.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // الأمان: يضمن المرجع القابل للتغيير ملكية فريدة.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// احصل على وصول ذري إلى `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // الأمان: يضمن المرجع القابل للتغيير ملكية فريدة ، و
        // محاذاة كل من `bool` و `Self` هي 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// تستهلك الذرة وترجع القيمة المضمنة.
    ///
    /// هذا آمن لأن تمرير `self` بالقيمة يضمن عدم وصول أي خيوط أخرى بشكل متزامن إلى البيانات الذرية.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// يقوم بتحميل قيمة من bool.
    ///
    /// `load` يأخذ وسيطة [`Ordering`] التي تصف ترتيب الذاكرة لهذه العملية.
    /// القيم الممكنة هي [`SeqCst`] و [`Acquire`] و [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics إذا كان `order` هو [`Release`] أو [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // الأمان: يتم منع أي سباقات للبيانات من خلال الجوهر الذري والخام
        // المؤشر الذي تم تمريره صالح لأننا حصلنا عليه من مرجع.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// يخزن قيمة في bool.
    ///
    /// `store` يأخذ وسيطة [`Ordering`] التي تصف ترتيب الذاكرة لهذه العملية.
    /// القيم الممكنة هي [`SeqCst`] و [`Release`] و [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics إذا كان `order` هو [`Acquire`] أو [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // الأمان: يتم منع أي سباقات للبيانات من خلال الجوهر الذري والخام
        // المؤشر الذي تم تمريره صالح لأننا حصلنا عليه من مرجع.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// يخزن قيمة في bool ، ويعيد القيمة السابقة.
    ///
    /// `swap` يأخذ وسيطة [`Ordering`] التي تصف ترتيب الذاكرة لهذه العملية.جميع أوضاع الطلب ممكنة.
    /// لاحظ أن استخدام [`Acquire`] يجعل المخزن جزءًا من هذه العملية [`Relaxed`] ، واستخدام [`Release`] يجعل جزء التحميل [`Relaxed`].
    ///
    ///
    /// **Note:** هذه الطريقة متاحة فقط على الأنظمة الأساسية التي تدعم العمليات الذرية على `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // السلامة: يتم منع سباقات البيانات بواسطة الجوهرات الذرية.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// يخزن قيمة في [`bool`] إذا كانت القيمة الحالية هي نفس قيمة `current`.
    ///
    /// القيمة المعادة هي القيمة السابقة دائمًا.إذا كانت تساوي `current` ، فقد تم تحديث القيمة.
    ///
    /// `compare_and_swap` يأخذ أيضًا وسيطة [`Ordering`] التي تصف ترتيب الذاكرة لهذه العملية.
    /// لاحظ أنه حتى عند استخدام [`AcqRel`] ، قد تفشل العملية وبالتالي تؤدي فقط تحميل `Acquire` ، ولكن لا تحتوي على دلالات `Release`.
    /// يؤدي استخدام [`Acquire`] إلى جعل المخزن جزءًا من هذه العملية [`Relaxed`] إذا حدثت ، واستخدام [`Release`] يجعل جزء التحميل [`Relaxed`].
    ///
    /// **Note:** هذه الطريقة متاحة فقط على الأنظمة الأساسية التي تدعم العمليات الذرية على `u8`.
    ///
    /// # الترحيل إلى `compare_exchange` و `compare_exchange_weak`
    ///
    /// `compare_and_swap` يعادل `compare_exchange` بالتعيين التالي لطلبات الذاكرة:
    ///
    /// الأصل |نجاح |بالفشل
    /// -------- | ------- | -------
    /// استرخاء |استرخاء |استرخاء اكتساب |اكتساب |الحصول على الإصدار |الإصدار |استرخاء AcqRel |AcqRel |اكتساب SeqCst |تسلسل |تسلسل
    ///
    /// `compare_exchange_weak` يُسمح بالفشل الزائف حتى عندما تنجح المقارنة ، مما يسمح للمترجم بإنشاء كود تجميع أفضل عند استخدام المقارنة والمبادلة في حلقة.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// يخزن قيمة في [`bool`] إذا كانت القيمة الحالية هي نفس قيمة `current`.
    ///
    /// القيمة المعادة هي نتيجة تشير إلى ما إذا كانت القيمة الجديدة قد تمت كتابتها وتحتوي على القيمة السابقة.
    /// عند النجاح ، يتم ضمان هذه القيمة لتكون مساوية لـ `current`.
    ///
    /// `compare_exchange` يأخذ وسيطتين [`Ordering`] لوصف ترتيب الذاكرة لهذه العملية.
    /// `success` يصف الطلب المطلوب لعملية القراءة والتعديل والكتابة التي تحدث في حالة نجاح المقارنة مع `current`.
    /// `failure` يصف الطلب المطلوب لعملية التحميل التي تحدث عند فشل المقارنة.
    /// استخدام [`Acquire`] كطلب ناجح يجعل المخزن جزءًا من هذه العملية [`Relaxed`] ، واستخدام [`Release`] يجعل التحميل الناجح [`Relaxed`].
    ///
    /// يمكن أن يكون ترتيب الفشل [`SeqCst`] أو [`Acquire`] أو [`Relaxed`] فقط ويجب أن يكون مكافئًا أو أضعف من ترتيب النجاح.
    ///
    /// **Note:** هذه الطريقة متاحة فقط على الأنظمة الأساسية التي تدعم العمليات الذرية على `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // السلامة: يتم منع سباقات البيانات بواسطة الجوهرات الذرية.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// يخزن قيمة في [`bool`] إذا كانت القيمة الحالية هي نفس قيمة `current`.
    ///
    /// على عكس [`AtomicBool::compare_exchange`] ، يُسمح لهذه الوظيفة بالفشل بشكل زائف حتى عند نجاح المقارنة ، مما قد يؤدي إلى رمز أكثر كفاءة في بعض الأنظمة الأساسية.
    ///
    /// القيمة المعادة هي نتيجة تشير إلى ما إذا كانت القيمة الجديدة قد تمت كتابتها وتحتوي على القيمة السابقة.
    ///
    /// `compare_exchange_weak` يأخذ وسيطتين [`Ordering`] لوصف ترتيب الذاكرة لهذه العملية.
    /// `success` يصف الطلب المطلوب لعملية القراءة والتعديل والكتابة التي تحدث في حالة نجاح المقارنة مع `current`.
    /// `failure` يصف الطلب المطلوب لعملية التحميل التي تحدث عند فشل المقارنة.
    /// استخدام [`Acquire`] كطلب ناجح يجعل المخزن جزءًا من هذه العملية [`Relaxed`] ، واستخدام [`Release`] يجعل التحميل الناجح [`Relaxed`].
    /// يمكن أن يكون ترتيب الفشل [`SeqCst`] أو [`Acquire`] أو [`Relaxed`] فقط ويجب أن يكون مكافئًا أو أضعف من ترتيب النجاح.
    ///
    /// **Note:** هذه الطريقة متاحة فقط على الأنظمة الأساسية التي تدعم العمليات الذرية على `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // السلامة: يتم منع سباقات البيانات بواسطة الجوهرات الذرية.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// "and" المنطقي بقيمة منطقية.
    ///
    /// تنفيذ عملية "and" منطقية على القيمة الحالية والوسيطة `val` ، وتعيين القيمة الجديدة للنتيجة.
    ///
    /// إرجاع القيمة السابقة.
    ///
    /// `fetch_and` يأخذ وسيطة [`Ordering`] التي تصف ترتيب الذاكرة لهذه العملية.جميع أوضاع الطلب ممكنة.
    /// لاحظ أن استخدام [`Acquire`] يجعل المخزن جزءًا من هذه العملية [`Relaxed`] ، واستخدام [`Release`] يجعل جزء التحميل [`Relaxed`].
    ///
    ///
    /// **Note:** هذه الطريقة متاحة فقط على الأنظمة الأساسية التي تدعم العمليات الذرية على `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // السلامة: يتم منع سباقات البيانات بواسطة الجوهرات الذرية.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// "nand" المنطقي بقيمة منطقية.
    ///
    /// ينفذ عملية "nand" منطقية على القيمة الحالية والوسيطة `val` ، ويعين القيمة الجديدة على النتيجة.
    ///
    /// إرجاع القيمة السابقة.
    ///
    /// `fetch_nand` يأخذ وسيطة [`Ordering`] التي تصف ترتيب الذاكرة لهذه العملية.جميع أوضاع الطلب ممكنة.
    /// لاحظ أن استخدام [`Acquire`] يجعل المخزن جزءًا من هذه العملية [`Relaxed`] ، واستخدام [`Release`] يجعل جزء التحميل [`Relaxed`].
    ///
    ///
    /// **Note:** هذه الطريقة متاحة فقط على الأنظمة الأساسية التي تدعم العمليات الذرية على `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // لا يمكننا استخدام atomic_nand هنا لأنه يمكن أن ينتج عنه bool بقيمة غير صالحة.
        // يحدث هذا لأن العملية الذرية تتم باستخدام عدد صحيح داخليًا مكون من 8 بتات ، والذي من شأنه تعيين البتات السبعة العليا.
        //
        // لذلك نحن فقط نستخدم fetch_xor أو swap بدلاً من ذلك.
        if val {
            // ! (x&true)== !x يجب أن نعكس قيمة bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true يجب علينا ضبط bool على true.
            //
            self.swap(true, order)
        }
    }

    /// "or" المنطقي بقيمة منطقية.
    ///
    /// تنفيذ عملية "or" منطقية على القيمة الحالية والوسيطة `val` ، وتعيين القيمة الجديدة للنتيجة.
    ///
    /// إرجاع القيمة السابقة.
    ///
    /// `fetch_or` يأخذ وسيطة [`Ordering`] التي تصف ترتيب الذاكرة لهذه العملية.جميع أوضاع الطلب ممكنة.
    /// لاحظ أن استخدام [`Acquire`] يجعل المخزن جزءًا من هذه العملية [`Relaxed`] ، واستخدام [`Release`] يجعل جزء التحميل [`Relaxed`].
    ///
    ///
    /// **Note:** هذه الطريقة متاحة فقط على الأنظمة الأساسية التي تدعم العمليات الذرية على `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // السلامة: يتم منع سباقات البيانات بواسطة الجوهرات الذرية.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// "xor" المنطقي بقيمة منطقية.
    ///
    /// تنفيذ عملية "xor" منطقية على القيمة الحالية والوسيطة `val` ، وتعيين القيمة الجديدة للنتيجة.
    ///
    /// إرجاع القيمة السابقة.
    ///
    /// `fetch_xor` يأخذ وسيطة [`Ordering`] التي تصف ترتيب الذاكرة لهذه العملية.جميع أوضاع الطلب ممكنة.
    /// لاحظ أن استخدام [`Acquire`] يجعل المخزن جزءًا من هذه العملية [`Relaxed`] ، واستخدام [`Release`] يجعل جزء التحميل [`Relaxed`].
    ///
    ///
    /// **Note:** هذه الطريقة متاحة فقط على الأنظمة الأساسية التي تدعم العمليات الذرية على `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // السلامة: يتم منع سباقات البيانات بواسطة الجوهرات الذرية.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// إرجاع مؤشر قابل للتغيير إلى [`bool`] الأساسي.
    ///
    /// يمكن أن يكون القيام بالقراءات والكتابة غير الذرية على العدد الصحيح الناتج سباق بيانات.
    /// هذه الطريقة مفيدة في الغالب لـ FFI ، حيث قد يستخدم توقيع الوظيفة `*mut bool` بدلاً من `&AtomicBool`.
    ///
    /// يعد إرجاع مؤشر `*mut` من مرجع مشترك إلى هذه الذرة أمرًا آمنًا لأن الأنواع الذرية تعمل مع قابلية التغيير الداخلية.
    /// جميع التعديلات الذرية تغير القيمة من خلال مرجع مشترك ، ويمكن أن تفعل ذلك بأمان طالما أنها تستخدم العمليات الذرية.
    /// يتطلب أي استخدام لمؤشر خام تم إرجاعه كتلة `unsafe` ولا يزال يتعين عليه دعم نفس التقييد: يجب أن تكون العمليات عليه ذرية.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// يجلب القيمة ، ويطبق عليها دالة تُرجع قيمة جديدة اختيارية.تُرجع `Result` لـ `Ok(previous_value)` إذا قامت الدالة بإرجاع `Some(_)` ، وإلا `Err(previous_value)`.
    ///
    /// Note: قد يستدعي هذا الوظيفة عدة مرات إذا تم تغيير القيمة من مؤشرات الترابط الأخرى في غضون ذلك ، طالما أن الوظيفة ترجع `Some(_)` ، ولكن سيتم تطبيق الوظيفة مرة واحدة فقط على القيمة المخزنة.
    ///
    ///
    /// `fetch_update` يأخذ وسيطتين [`Ordering`] لوصف ترتيب الذاكرة لهذه العملية.
    /// يصف الأول الطلب المطلوب عندما تنجح العملية أخيرًا بينما يصف الثاني الترتيب المطلوب للأحمال.
    /// تتوافق هذه مع أوامر النجاح والفشل لـ [`AtomicBool::compare_exchange`] على التوالي.
    ///
    /// استخدام [`Acquire`] كطلب ناجح يجعل المخزن جزءًا من هذه العملية [`Relaxed`] ، واستخدام [`Release`] يجعل التحميل النهائي الناجح [`Relaxed`].
    /// يمكن أن يكون ترتيب تحميل (failed) [`SeqCst`] أو [`Acquire`] أو [`Relaxed`] فقط ويجب أن يكون مكافئًا للطلب الناجح أو أضعف منه.
    ///
    /// **Note:** هذه الطريقة متاحة فقط على الأنظمة الأساسية التي تدعم العمليات الذرية على `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// ينشئ `AtomicPtr` جديد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// إرجاع مرجع قابل للتغيير إلى المؤشر الأساسي.
    ///
    /// هذا آمن لأن المرجع القابل للتغيير يضمن عدم وصول أي خيوط أخرى بشكل متزامن إلى البيانات الذرية.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// احصل على وصول ذري إلى مؤشر.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - يضمن المرجع القابل للتغيير ملكية فريدة.
        //  - محاذاة `*mut T` و `Self` هي نفسها على جميع الأنظمة الأساسية التي تدعمها rust ، كما تم التحقق من ذلك أعلاه.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// تستهلك الذرة وترجع القيمة المضمنة.
    ///
    /// هذا آمن لأن تمرير `self` بالقيمة يضمن عدم وصول أي خيوط أخرى بشكل متزامن إلى البيانات الذرية.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// يقوم بتحميل قيمة من المؤشر.
    ///
    /// `load` يأخذ وسيطة [`Ordering`] التي تصف ترتيب الذاكرة لهذه العملية.
    /// القيم الممكنة هي [`SeqCst`] و [`Acquire`] و [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics إذا كان `order` هو [`Release`] أو [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // السلامة: يتم منع سباقات البيانات بواسطة الجوهرات الذرية.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// يخزن قيمة في المؤشر.
    ///
    /// `store` يأخذ وسيطة [`Ordering`] التي تصف ترتيب الذاكرة لهذه العملية.
    /// القيم الممكنة هي [`SeqCst`] و [`Release`] و [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics إذا كان `order` هو [`Acquire`] أو [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // السلامة: يتم منع سباقات البيانات بواسطة الجوهرات الذرية.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// يخزن قيمة في المؤشر ، ويعيد القيمة السابقة.
    ///
    /// `swap` يأخذ وسيطة [`Ordering`] التي تصف ترتيب الذاكرة لهذه العملية.جميع أوضاع الطلب ممكنة.
    /// لاحظ أن استخدام [`Acquire`] يجعل المخزن جزءًا من هذه العملية [`Relaxed`] ، واستخدام [`Release`] يجعل جزء التحميل [`Relaxed`].
    ///
    ///
    /// **Note:** هذه الطريقة متاحة فقط على الأنظمة الأساسية التي تدعم العمليات الذرية على المؤشرات.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // السلامة: يتم منع سباقات البيانات بواسطة الجوهرات الذرية.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// يخزن قيمة في المؤشر إذا كانت القيمة الحالية هي نفس قيمة `current`.
    ///
    /// القيمة المعادة هي القيمة السابقة دائمًا.إذا كانت تساوي `current` ، فقد تم تحديث القيمة.
    ///
    /// `compare_and_swap` يأخذ أيضًا وسيطة [`Ordering`] التي تصف ترتيب الذاكرة لهذه العملية.
    /// لاحظ أنه حتى عند استخدام [`AcqRel`] ، قد تفشل العملية وبالتالي تؤدي فقط تحميل `Acquire` ، ولكن لا تحتوي على دلالات `Release`.
    /// يؤدي استخدام [`Acquire`] إلى جعل المخزن جزءًا من هذه العملية [`Relaxed`] إذا حدثت ، واستخدام [`Release`] يجعل جزء التحميل [`Relaxed`].
    ///
    /// **Note:** هذه الطريقة متاحة فقط على الأنظمة الأساسية التي تدعم العمليات الذرية على المؤشرات.
    ///
    /// # الترحيل إلى `compare_exchange` و `compare_exchange_weak`
    ///
    /// `compare_and_swap` يعادل `compare_exchange` بالتعيين التالي لطلبات الذاكرة:
    ///
    /// الأصل |نجاح |بالفشل
    /// -------- | ------- | -------
    /// استرخاء |استرخاء |استرخاء اكتساب |اكتساب |الحصول على الإصدار |الإصدار |استرخاء AcqRel |AcqRel |اكتساب SeqCst |تسلسل |تسلسل
    ///
    /// `compare_exchange_weak` يُسمح بالفشل الزائف حتى عندما تنجح المقارنة ، مما يسمح للمترجم بإنشاء كود تجميع أفضل عند استخدام المقارنة والمبادلة في حلقة.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// يخزن قيمة في المؤشر إذا كانت القيمة الحالية هي نفس قيمة `current`.
    ///
    /// القيمة المعادة هي نتيجة تشير إلى ما إذا كانت القيمة الجديدة قد تمت كتابتها وتحتوي على القيمة السابقة.
    /// عند النجاح ، يتم ضمان هذه القيمة لتكون مساوية لـ `current`.
    ///
    /// `compare_exchange` يأخذ وسيطتين [`Ordering`] لوصف ترتيب الذاكرة لهذه العملية.
    /// `success` يصف الطلب المطلوب لعملية القراءة والتعديل والكتابة التي تحدث في حالة نجاح المقارنة مع `current`.
    /// `failure` يصف الطلب المطلوب لعملية التحميل التي تحدث عند فشل المقارنة.
    /// استخدام [`Acquire`] كطلب ناجح يجعل المخزن جزءًا من هذه العملية [`Relaxed`] ، واستخدام [`Release`] يجعل التحميل الناجح [`Relaxed`].
    ///
    /// يمكن أن يكون ترتيب الفشل [`SeqCst`] أو [`Acquire`] أو [`Relaxed`] فقط ويجب أن يكون مكافئًا أو أضعف من ترتيب النجاح.
    ///
    /// **Note:** هذه الطريقة متاحة فقط على الأنظمة الأساسية التي تدعم العمليات الذرية على المؤشرات.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // السلامة: يتم منع سباقات البيانات بواسطة الجوهرات الذرية.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// يخزن قيمة في المؤشر إذا كانت القيمة الحالية هي نفس قيمة `current`.
    ///
    /// على عكس [`AtomicPtr::compare_exchange`] ، يُسمح لهذه الوظيفة بالفشل بشكل زائف حتى عند نجاح المقارنة ، مما قد يؤدي إلى رمز أكثر كفاءة في بعض الأنظمة الأساسية.
    ///
    /// القيمة المعادة هي نتيجة تشير إلى ما إذا كانت القيمة الجديدة قد تمت كتابتها وتحتوي على القيمة السابقة.
    ///
    /// `compare_exchange_weak` يأخذ وسيطتين [`Ordering`] لوصف ترتيب الذاكرة لهذه العملية.
    /// `success` يصف الطلب المطلوب لعملية القراءة والتعديل والكتابة التي تحدث في حالة نجاح المقارنة مع `current`.
    /// `failure` يصف الطلب المطلوب لعملية التحميل التي تحدث عند فشل المقارنة.
    /// استخدام [`Acquire`] كطلب ناجح يجعل المخزن جزءًا من هذه العملية [`Relaxed`] ، واستخدام [`Release`] يجعل التحميل الناجح [`Relaxed`].
    /// يمكن أن يكون ترتيب الفشل [`SeqCst`] أو [`Acquire`] أو [`Relaxed`] فقط ويجب أن يكون مكافئًا أو أضعف من ترتيب النجاح.
    ///
    /// **Note:** هذه الطريقة متاحة فقط على الأنظمة الأساسية التي تدعم العمليات الذرية على المؤشرات.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // الأمان: هذا الجوهر غير آمن لأنه يعمل على مؤشر خام
        // لكننا نعلم على وجه اليقين أن المؤشر صالح (لقد حصلنا عليه للتو من `UnsafeCell` لدينا بالمرجع) وأن العملية الذرية نفسها تسمح لنا بتغيير محتويات `UnsafeCell` بأمان.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// يجلب القيمة ، ويطبق عليها دالة تُرجع قيمة جديدة اختيارية.تُرجع `Result` لـ `Ok(previous_value)` إذا قامت الدالة بإرجاع `Some(_)` ، وإلا `Err(previous_value)`.
    ///
    /// Note: قد يستدعي هذا الوظيفة عدة مرات إذا تم تغيير القيمة من مؤشرات الترابط الأخرى في غضون ذلك ، طالما أن الوظيفة ترجع `Some(_)` ، ولكن سيتم تطبيق الوظيفة مرة واحدة فقط على القيمة المخزنة.
    ///
    ///
    /// `fetch_update` يأخذ وسيطتين [`Ordering`] لوصف ترتيب الذاكرة لهذه العملية.
    /// يصف الأول الطلب المطلوب عندما تنجح العملية أخيرًا بينما يصف الثاني الترتيب المطلوب للأحمال.
    /// تتوافق هذه مع أوامر النجاح والفشل لـ [`AtomicPtr::compare_exchange`] على التوالي.
    ///
    /// استخدام [`Acquire`] كطلب ناجح يجعل المخزن جزءًا من هذه العملية [`Relaxed`] ، واستخدام [`Release`] يجعل التحميل النهائي الناجح [`Relaxed`].
    /// يمكن أن يكون ترتيب تحميل (failed) [`SeqCst`] أو [`Acquire`] أو [`Relaxed`] فقط ويجب أن يكون مكافئًا للطلب الناجح أو أضعف منه.
    ///
    /// **Note:** هذه الطريقة متاحة فقط على الأنظمة الأساسية التي تدعم العمليات الذرية على المؤشرات.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// يحول `bool` إلى `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // ينتهي هذا الماكرو بعدم استخدامه في بعض البنى.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// نوع عدد صحيح يمكن مشاركته بأمان بين المواضيع.
        ///
        /// هذا النوع له نفس التمثيل في الذاكرة مثل نوع العدد الصحيح الأساسي ، [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// لمزيد من المعلومات حول الاختلافات بين الأنواع الذرية والأنواع غير الذرية بالإضافة إلى معلومات حول إمكانية النقل من هذا النوع ، يرجى الاطلاع على [module-level documentation].
        ///
        ///
        /// **Note:** هذا النوع متاح فقط على الأنظمة الأساسية التي تدعم الأحمال الذرية ومخازن [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// عدد صحيح ذري مهيأ إلى `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // يتم تنفيذ الإرسال ضمنيًا.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// ينشئ عددًا صحيحًا ذريًا جديدًا.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// إرجاع مرجع قابل للتغيير إلى العدد الصحيح الأساسي.
            ///
            /// هذا آمن لأن المرجع القابل للتغيير يضمن عدم وصول أي خيوط أخرى بشكل متزامن إلى البيانات الذرية.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5 ؛
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// دعونا mut some_int=123 ؛
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int، 100) ؛
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - يضمن المرجع القابل للتغيير ملكية فريدة.
                //  - محاذاة `$int_type` و `Self` هي نفسها ، كما وعدت $cfg_align وتم التحقق منها أعلاه.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// تستهلك الذرة وترجع القيمة المضمنة.
            ///
            /// هذا آمن لأن تمرير `self` بالقيمة يضمن عدم وصول أي خيوط أخرى بشكل متزامن إلى البيانات الذرية.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// يقوم بتحميل قيمة من العدد الصحيح الذري.
            ///
            /// `load` يأخذ وسيطة [`Ordering`] التي تصف ترتيب الذاكرة لهذه العملية.
            /// القيم الممكنة هي [`SeqCst`] و [`Acquire`] و [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics إذا كان `order` هو [`Release`] أو [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // السلامة: يتم منع سباقات البيانات بواسطة الجوهرات الذرية.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// يخزن قيمة في العدد الصحيح الذري.
            ///
            /// `store` يأخذ وسيطة [`Ordering`] التي تصف ترتيب الذاكرة لهذه العملية.
            ///  القيم الممكنة هي [`SeqCst`] و [`Release`] و [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics إذا كان `order` هو [`Acquire`] أو [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // السلامة: يتم منع سباقات البيانات بواسطة الجوهرات الذرية.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// يخزن قيمة في العدد الصحيح الذري ، ويعيد القيمة السابقة.
            ///
            /// `swap` يأخذ وسيطة [`Ordering`] التي تصف ترتيب الذاكرة لهذه العملية.جميع أوضاع الطلب ممكنة.
            /// لاحظ أن استخدام [`Acquire`] يجعل المخزن جزءًا من هذه العملية [`Relaxed`] ، واستخدام [`Release`] يجعل جزء التحميل [`Relaxed`].
            ///
            ///
            /// **ملاحظة**: هذه الطريقة متاحة فقط على المنصات التي تدعم العمليات الذرية
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // السلامة: يتم منع سباقات البيانات بواسطة الجوهرات الذرية.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// يخزن قيمة في العدد الصحيح الذري إذا كانت القيمة الحالية هي نفس قيمة `current`.
            ///
            /// القيمة المعادة هي القيمة السابقة دائمًا.إذا كانت تساوي `current` ، فقد تم تحديث القيمة.
            ///
            /// `compare_and_swap` يأخذ أيضًا وسيطة [`Ordering`] التي تصف ترتيب الذاكرة لهذه العملية.
            /// لاحظ أنه حتى عند استخدام [`AcqRel`] ، قد تفشل العملية وبالتالي تؤدي فقط تحميل `Acquire` ، ولكن لا تحتوي على دلالات `Release`.
            ///
            /// يؤدي استخدام [`Acquire`] إلى جعل المخزن جزءًا من هذه العملية [`Relaxed`] إذا حدثت ، واستخدام [`Release`] يجعل جزء التحميل [`Relaxed`].
            ///
            /// **ملاحظة**: هذه الطريقة متاحة فقط على المنصات التي تدعم العمليات الذرية
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # الترحيل إلى `compare_exchange` و `compare_exchange_weak`
            ///
            /// `compare_and_swap` يعادل `compare_exchange` بالتعيين التالي لطلبات الذاكرة:
            ///
            /// الأصل |نجاح |بالفشل
            /// -------- | ------- | -------
            /// استرخاء |استرخاء |استرخاء اكتساب |اكتساب |الحصول على الإصدار |الإصدار |استرخاء AcqRel |AcqRel |اكتساب SeqCst |تسلسل |تسلسل
            ///
            /// `compare_exchange_weak` يُسمح بالفشل الزائف حتى عندما تنجح المقارنة ، مما يسمح للمترجم بإنشاء كود تجميع أفضل عند استخدام المقارنة والمبادلة في حلقة.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// يخزن قيمة في العدد الصحيح الذري إذا كانت القيمة الحالية هي نفس قيمة `current`.
            ///
            /// القيمة المعادة هي نتيجة تشير إلى ما إذا كانت القيمة الجديدة قد تمت كتابتها وتحتوي على القيمة السابقة.
            /// عند النجاح ، يتم ضمان هذه القيمة لتكون مساوية لـ `current`.
            ///
            /// `compare_exchange` يأخذ وسيطتين [`Ordering`] لوصف ترتيب الذاكرة لهذه العملية.
            /// `success` يصف الطلب المطلوب لعملية القراءة والتعديل والكتابة التي تحدث في حالة نجاح المقارنة مع `current`.
            /// `failure` يصف الطلب المطلوب لعملية التحميل التي تحدث عند فشل المقارنة.
            /// استخدام [`Acquire`] كطلب ناجح يجعل المخزن جزءًا من هذه العملية [`Relaxed`] ، واستخدام [`Release`] يجعل التحميل الناجح [`Relaxed`].
            ///
            /// يمكن أن يكون ترتيب الفشل [`SeqCst`] أو [`Acquire`] أو [`Relaxed`] فقط ويجب أن يكون مكافئًا أو أضعف من ترتيب النجاح.
            ///
            /// **ملاحظة**: هذه الطريقة متاحة فقط على المنصات التي تدعم العمليات الذرية
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // السلامة: يتم منع سباقات البيانات بواسطة الجوهرات الذرية.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// يخزن قيمة في العدد الصحيح الذري إذا كانت القيمة الحالية هي نفس قيمة `current`.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// يُسمح لهذه الوظيفة بالفشل بشكل زائف حتى عند نجاح المقارنة ، مما قد يؤدي إلى رمز أكثر كفاءة في بعض الأنظمة الأساسية.
            /// القيمة المعادة هي نتيجة تشير إلى ما إذا كانت القيمة الجديدة قد تمت كتابتها وتحتوي على القيمة السابقة.
            ///
            /// `compare_exchange_weak` يأخذ وسيطتين [`Ordering`] لوصف ترتيب الذاكرة لهذه العملية.
            /// `success` يصف الطلب المطلوب لعملية القراءة والتعديل والكتابة التي تحدث في حالة نجاح المقارنة مع `current`.
            /// `failure` يصف الطلب المطلوب لعملية التحميل التي تحدث عند فشل المقارنة.
            /// استخدام [`Acquire`] كطلب ناجح يجعل المخزن جزءًا من هذه العملية [`Relaxed`] ، واستخدام [`Release`] يجعل التحميل الناجح [`Relaxed`].
            ///
            /// يمكن أن يكون ترتيب الفشل [`SeqCst`] أو [`Acquire`] أو [`Relaxed`] فقط ويجب أن يكون مكافئًا أو أضعف من ترتيب النجاح.
            ///
            /// **ملاحظة**: هذه الطريقة متاحة فقط على المنصات التي تدعم العمليات الذرية
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// اسمحوا mut old= val.load(Ordering::Relaxed) ؛
            /// حلقة {let new=old * 2 ؛
            ///     تطابق val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // السلامة: يتم منع سباقات البيانات بواسطة الجوهرات الذرية.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// يضيف إلى القيمة الحالية ، ويعيد القيمة السابقة.
            ///
            /// هذه العملية تلتف حول الفائض.
            ///
            /// `fetch_add` يأخذ وسيطة [`Ordering`] التي تصف ترتيب الذاكرة لهذه العملية.جميع أوضاع الطلب ممكنة.
            /// لاحظ أن استخدام [`Acquire`] يجعل المخزن جزءًا من هذه العملية [`Relaxed`] ، واستخدام [`Release`] يجعل جزء التحميل [`Relaxed`].
            ///
            ///
            /// **ملاحظة**: هذه الطريقة متاحة فقط على المنصات التي تدعم العمليات الذرية
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // السلامة: يتم منع سباقات البيانات بواسطة الجوهرات الذرية.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// يطرح من القيمة الحالية ، ويعيد القيمة السابقة.
            ///
            /// هذه العملية تلتف حول الفائض.
            ///
            /// `fetch_sub` يأخذ وسيطة [`Ordering`] التي تصف ترتيب الذاكرة لهذه العملية.جميع أوضاع الطلب ممكنة.
            /// لاحظ أن استخدام [`Acquire`] يجعل المخزن جزءًا من هذه العملية [`Relaxed`] ، واستخدام [`Release`] يجعل جزء التحميل [`Relaxed`].
            ///
            ///
            /// **ملاحظة**: هذه الطريقة متاحة فقط على المنصات التي تدعم العمليات الذرية
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // السلامة: يتم منع سباقات البيانات بواسطة الجوهرات الذرية.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" بالقيمة الحالية.
            ///
            /// تنفيذ عملية bitwise "and" على القيمة الحالية والوسيطة `val` ، وتعيين القيمة الجديدة على النتيجة.
            ///
            /// إرجاع القيمة السابقة.
            ///
            /// `fetch_and` يأخذ وسيطة [`Ordering`] التي تصف ترتيب الذاكرة لهذه العملية.جميع أوضاع الطلب ممكنة.
            /// لاحظ أن استخدام [`Acquire`] يجعل المخزن جزءًا من هذه العملية [`Relaxed`] ، واستخدام [`Release`] يجعل جزء التحميل [`Relaxed`].
            ///
            ///
            /// **ملاحظة**: هذه الطريقة متاحة فقط على المنصات التي تدعم العمليات الذرية
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // السلامة: يتم منع سباقات البيانات بواسطة الجوهرات الذرية.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" بالقيمة الحالية.
            ///
            /// تنفيذ عملية bitwise "nand" على القيمة الحالية والوسيطة `val` ، وتعيين القيمة الجديدة على النتيجة.
            ///
            /// إرجاع القيمة السابقة.
            ///
            /// `fetch_nand` يأخذ وسيطة [`Ordering`] التي تصف ترتيب الذاكرة لهذه العملية.جميع أوضاع الطلب ممكنة.
            /// لاحظ أن استخدام [`Acquire`] يجعل المخزن جزءًا من هذه العملية [`Relaxed`] ، واستخدام [`Release`] يجعل جزء التحميل [`Relaxed`].
            ///
            ///
            /// **ملاحظة**: هذه الطريقة متاحة فقط على المنصات التي تدعم العمليات الذرية
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31)) ؛
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // السلامة: يتم منع سباقات البيانات بواسطة الجوهرات الذرية.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" بالقيمة الحالية.
            ///
            /// تنفيذ عملية bitwise "or" على القيمة الحالية والوسيطة `val` ، وتعيين القيمة الجديدة على النتيجة.
            ///
            /// إرجاع القيمة السابقة.
            ///
            /// `fetch_or` يأخذ وسيطة [`Ordering`] التي تصف ترتيب الذاكرة لهذه العملية.جميع أوضاع الطلب ممكنة.
            /// لاحظ أن استخدام [`Acquire`] يجعل المخزن جزءًا من هذه العملية [`Relaxed`] ، واستخدام [`Release`] يجعل جزء التحميل [`Relaxed`].
            ///
            ///
            /// **ملاحظة**: هذه الطريقة متاحة فقط على المنصات التي تدعم العمليات الذرية
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // السلامة: يتم منع سباقات البيانات بواسطة الجوهرات الذرية.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" بالقيمة الحالية.
            ///
            /// تنفيذ عملية bitwise "xor" على القيمة الحالية والوسيطة `val` ، وتعيين القيمة الجديدة على النتيجة.
            ///
            /// إرجاع القيمة السابقة.
            ///
            /// `fetch_xor` يأخذ وسيطة [`Ordering`] التي تصف ترتيب الذاكرة لهذه العملية.جميع أوضاع الطلب ممكنة.
            /// لاحظ أن استخدام [`Acquire`] يجعل المخزن جزءًا من هذه العملية [`Relaxed`] ، واستخدام [`Release`] يجعل جزء التحميل [`Relaxed`].
            ///
            ///
            /// **ملاحظة**: هذه الطريقة متاحة فقط على المنصات التي تدعم العمليات الذرية
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // السلامة: يتم منع سباقات البيانات بواسطة الجوهرات الذرية.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// يجلب القيمة ، ويطبق عليها دالة تُرجع قيمة جديدة اختيارية.تُرجع `Result` لـ `Ok(previous_value)` إذا قامت الدالة بإرجاع `Some(_)` ، وإلا `Err(previous_value)`.
            ///
            /// Note: قد يستدعي هذا الوظيفة عدة مرات إذا تم تغيير القيمة من مؤشرات الترابط الأخرى في غضون ذلك ، طالما أن الوظيفة ترجع `Some(_)` ، ولكن سيتم تطبيق الوظيفة مرة واحدة فقط على القيمة المخزنة.
            ///
            ///
            /// `fetch_update` يأخذ وسيطتين [`Ordering`] لوصف ترتيب الذاكرة لهذه العملية.
            /// يصف الأول الطلب المطلوب عندما تنجح العملية أخيرًا بينما يصف الثاني الترتيب المطلوب للأحمال.تتوافق هذه مع أوامر النجاح والفشل لـ
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// استخدام [`Acquire`] كطلب ناجح يجعل المخزن جزءًا من هذه العملية [`Relaxed`] ، واستخدام [`Release`] يجعل التحميل النهائي الناجح [`Relaxed`].
            /// يمكن أن يكون ترتيب تحميل (failed) [`SeqCst`] أو [`Acquire`] أو [`Relaxed`] فقط ويجب أن يكون مكافئًا للطلب الناجح أو أضعف منه.
            ///
            /// **ملاحظة**: هذه الطريقة متاحة فقط على المنصات التي تدعم العمليات الذرية
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (ترتيب: : SeqCst، Ordering::SeqCst، | x | Some(x + 1))، Ok(7));
            /// assert_eq! (x.fetch_update (ترتيب: : SeqCst، Ordering::SeqCst، | x | Some(x + 1))، Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// الحد الأقصى مع القيمة الحالية.
            ///
            /// يبحث عن الحد الأقصى للقيمة الحالية والوسيطة `val` ، ويعين القيمة الجديدة على النتيجة.
            ///
            /// إرجاع القيمة السابقة.
            ///
            /// `fetch_max` يأخذ وسيطة [`Ordering`] التي تصف ترتيب الذاكرة لهذه العملية.جميع أوضاع الطلب ممكنة.
            /// لاحظ أن استخدام [`Acquire`] يجعل المخزن جزءًا من هذه العملية [`Relaxed`] ، واستخدام [`Release`] يجعل جزء التحميل [`Relaxed`].
            ///
            ///
            /// **ملاحظة**: هذه الطريقة متاحة فقط على المنصات التي تدعم العمليات الذرية
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// دع شريط=42 ؛
            /// دع max_foo=foo.fetch_max (شريط ، Ordering::SeqCst).max(bar);
            /// تأكيد! (max_foo==42) ؛
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // السلامة: يتم منع سباقات البيانات بواسطة الجوهرات الذرية.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// الحد الأدنى مع القيمة الحالية.
            ///
            /// البحث عن الحد الأدنى للقيمة الحالية والوسيطة `val` ، وتعيين القيمة الجديدة للنتيجة.
            ///
            /// إرجاع القيمة السابقة.
            ///
            /// `fetch_min` يأخذ وسيطة [`Ordering`] التي تصف ترتيب الذاكرة لهذه العملية.جميع أوضاع الطلب ممكنة.
            /// لاحظ أن استخدام [`Acquire`] يجعل المخزن جزءًا من هذه العملية [`Relaxed`] ، واستخدام [`Release`] يجعل جزء التحميل [`Relaxed`].
            ///
            ///
            /// **ملاحظة**: هذه الطريقة متاحة فقط على المنصات التي تدعم العمليات الذرية
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// دع شريط=12 ؛
            /// دع min_foo=foo.fetch_min (شريط ، Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo ، 12) ؛
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // السلامة: يتم منع سباقات البيانات بواسطة الجوهرات الذرية.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// إرجاع مؤشر قابل للتغيير إلى العدد الصحيح الأساسي.
            ///
            /// يمكن أن يكون القيام بالقراءات والكتابة غير الذرية على العدد الصحيح الناتج سباق بيانات.
            /// هذه الطريقة مفيدة في الغالب لـ FFI ، حيث يمكن استخدام توقيع الوظيفة
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// يعد إرجاع مؤشر `*mut` من مرجع مشترك إلى هذه الذرة أمرًا آمنًا لأن الأنواع الذرية تعمل مع قابلية التغيير الداخلية.
            /// جميع التعديلات الذرية تغير القيمة من خلال مرجع مشترك ، ويمكن أن تفعل ذلك بأمان طالما أنها تستخدم العمليات الذرية.
            /// يتطلب أي استخدام لمؤشر خام تم إرجاعه كتلة `unsafe` ولا يزال يتعين عليه دعم نفس التقييد: يجب أن تكون العمليات عليه ذرية.
            ///
            ///
            /// # Examples
            ///
            /// تجاهل (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// "C" خارجي {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // الأمان: آمن طالما أن `my_atomic_op` ذري.
            /// غير آمن {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// تُرجع القيمة السابقة (مثل __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// تُرجع القيمة السابقة (مثل __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// إرجاع القيمة القصوى (مقارنة موقعة)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// إرجاع القيمة الدنيا (مقارنة موقعة)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// إرجاع القيمة القصوى (مقارنة غير موقعة)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// إرجاع القيمة الدنيا (مقارنة غير موقعة)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // الأمان: يجب على المتصل التمسك بعقد الأمان لـ `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// سياج ذري.
///
/// اعتمادًا على الترتيب المحدد ، يمنع السور المحول البرمجي ووحدة المعالجة المركزية من إعادة ترتيب أنواع معينة من عمليات الذاكرة حولها.
/// يؤدي ذلك إلى تزامن العلاقات بينه وبين العمليات الذرية أو الأسوار في خيوط أخرى.
///
/// السور 'A' الذي يحتوي (على الأقل) [`Release`] ترتيب دلالات ، يتزامن مع السور 'B' (على الأقل) دلالات [`Acquire`] ، إذا وفقط في حالة وجود عمليات X و Y ، كلاهما يعمل على بعض الكائنات الذرية 'M' بحيث يتم تسلسل A من قبل تتم مزامنة X ، Y قبل أن يلاحظ B و Y التغيير إلى M.
/// يوفر هذا اعتمادًا يحدث قبل حدوثه بين A و B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// يمكن أيضًا مزامنة العمليات الذرية باستخدام دلالات [`Release`] أو [`Acquire`] مع السياج.
///
/// السياج الذي يحتوي على ترتيب [`SeqCst`] ، بالإضافة إلى وجود دلالات [`Acquire`] و [`Release`] ، يشارك في ترتيب البرنامج العالمي لعمليات و/أو أسوار [`SeqCst`] الأخرى.
///
/// يقبل طلبات [`Acquire`] و [`Release`] و [`AcqRel`] و [`SeqCst`].
///
/// # Panics
///
/// Panics إذا كان `order` يساوي [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // بدائية استبعاد متبادل على أساس السبينلوك.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // انتظر حتى تصبح القيمة القديمة `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // يتزامن هذا السور مع المتجر في `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // السلامة: استخدام السياج الذري آمن.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// سور ذاكرة المترجم.
///
/// `compiler_fence` لا يصدر أي رمز آلة ، ولكنه يقيد أنواع الذاكرة التي يُسمح للمترجم بإعادة ترتيبها.على وجه التحديد ، اعتمادًا على دلالات [`Ordering`] المحددة ، قد يُمنع المترجم من نقل القراءة أو الكتابة من قبل أو بعد الاستدعاء إلى الجانب الآخر من الاستدعاء إلى `compiler_fence`.لاحظ أنه **لا** يمنع *الأجهزة* من القيام بإعادة الطلب هذه.
///
/// هذه ليست مشكلة في سياق تنفيذ مترابط واحد ، ولكن عندما تقوم مؤشرات ترابط أخرى بتعديل الذاكرة في نفس الوقت ، يلزم وجود أساسيات مزامنة أقوى مثل [`fence`].
///
/// إعادة الترتيب التي تمنعها دلالات الترتيب المختلفة هي:
///
///  - مع [`SeqCst`] ، لا يُسمح بإعادة ترتيب عمليات القراءة والكتابة عبر هذه النقطة.
///  - مع [`Release`] ، لا يمكن نقل عمليات القراءة والكتابة السابقة إلى ما بعد عمليات الكتابة اللاحقة.
///  - مع [`Acquire`] ، لا يمكن نقل عمليات القراءة والكتابة اللاحقة قبل القراءات السابقة.
///  - مع [`AcqRel`] ، يتم فرض كل من القواعد المذكورة أعلاه.
///
/// `compiler_fence` بشكل عام مفيد فقط لمنع الخيط من السباق *مع نفسه*.أي ، إذا كان هناك سلسلة رسائل معينة تنفذ جزءًا واحدًا من التعليمات البرمجية ، ثم تمت مقاطعتها ، وبدأت في تنفيذ التعليمات البرمجية في مكان آخر (بينما لا تزال في نفس السلسلة ، ولا تزال من الناحية النظرية على نفس النواة).في البرامج التقليدية ، يمكن أن يحدث هذا فقط عند تسجيل معالج إشارة.
/// في المزيد من التعليمات البرمجية ذات المستوى المنخفض ، يمكن أن تنشأ مثل هذه المواقف أيضًا عند التعامل مع المقاطعات ، عند تنفيذ الخيوط الخضراء مع الاستباقية ، إلخ.
/// يتم تشجيع القراء الفضوليين على قراءة مناقشة نواة Linux الخاصة بـ [memory barriers].
///
/// # Panics
///
/// Panics إذا كان `order` يساوي [`Relaxed`].
///
/// # Examples
///
/// بدون `compiler_fence` ، فإن `assert_eq!` في الكود التالي *غير* مضمون للنجاح ، على الرغم من كل شيء يحدث في سلسلة واحدة.
/// لمعرفة السبب ، تذكر أن المترجم له الحرية في تبديل المتاجر إلى `IMPORTANT_VARIABLE` و `IS_READ` نظرًا لأن كلاهما `Ordering::Relaxed`.إذا حدث ذلك ، وتم استدعاء معالج الإشارة مباشرةً بعد تحديث `IS_READY` ، فسيرى معالج الإشارة `IS_READY=1` ، ولكن `IMPORTANT_VARIABLE=0`.
/// استخدام `compiler_fence` يعالج هذا الموقف.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // منع عمليات الكتابة السابقة من الانتقال إلى ما وراء هذه النقطة
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // السلامة: استخدام السياج الذري آمن.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// يشير إلى المعالج أنه داخل حلقة دوارة مشغول الانتظار ("قفل الدوران").
///
/// تم إهمال هذه الوظيفة لصالح [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}