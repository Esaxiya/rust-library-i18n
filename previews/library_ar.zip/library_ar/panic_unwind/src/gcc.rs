//! تنفيذ panics مدعوم بـ libgcc/libunwind (في شكل ما).
//!
//! للحصول على معلومات أساسية حول معالجة الاستثناءات وفك المكدس ، يرجى الاطلاع على "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) والمستندات المرتبطة به.
//! هذه أيضًا قراءات جيدة:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## ملخص موجز
//!
//! تحدث معالجة الاستثناءات على مرحلتين: مرحلة البحث ومرحلة التنظيف.
//!
//! في كلتا المرحلتين ، يقوم برنامج فك اللفة بتكديس الإطارات من أعلى إلى أسفل باستخدام معلومات من أقسام فك إطار المكدس من وحدات العملية الحالية (يشير "module" هنا إلى وحدة نظام تشغيل ، أي مكتبة قابلة للتنفيذ أو مكتبة ديناميكية).
//!
//!
//! لكل إطار مكدس ، فإنه يستدعي "personality routine" المرتبط به ، والذي يتم تخزين عنوانه أيضًا في قسم معلومات الاسترخاء.
//!
//! في مرحلة البحث ، تتمثل وظيفة روتين الشخصية في فحص كائن الاستثناء الذي يتم طرحه ، وتحديد ما إذا كان يجب التقاطه في إطار المكدس هذا.بمجرد تحديد إطار المعالج ، تبدأ مرحلة التنظيف.
//!
//! في مرحلة التنظيف ، تستدعي أداة فك اللفة كل روتين شخصية مرة أخرى.
//! هذه المرة تقرر أي كود تنظيف (إن وجد) يجب تشغيله لإطار المكدس الحالي.إذا كان الأمر كذلك ، يتم نقل عنصر التحكم إلى branch خاص في جسم الوظيفة ، وهو "landing pad" ، والذي يستدعي المدمرات ويحرر الذاكرة ، إلخ.
//! في نهاية منصة الهبوط ، يتم نقل التحكم مرة أخرى إلى وحدة فك اللفة ويستأنف الفك.
//!
//! بمجرد فك المكدس وصولاً إلى مستوى إطار المعالج ، يتوقف فك اللفة وينقل روتين الشخصية الأخير التحكم إلى كتلة الالتقاط.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// معرف فئة استثناء Rust.
// يتم استخدام هذا بواسطة إجراءات الشخصية لتحديد ما إذا كان قد تم طرح الاستثناء من خلال وقت التشغيل الخاص بهم.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-البائع ، اللغة
    0x4d4f5a_00_52555354
}

// تم رفع معرفات التسجيل من TargetLowering::getExceptionPointerRegister() و TargetLowering::getExceptionSelectorRegister() من LLVM لكل بنية ، ثم تم تعيينها إلى أرقام تسجيل DWARF عبر جداول تعريف السجل (عادةً<arch>RegisterInfo.td ، ابحث عن "DwarfRegNum").
//
// راجع أيضًا http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX ، EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX ، RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0 ، X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3 ، X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// يعتمد الكود التالي على إجراءات شخصية C و C++ الخاصة بـ GCC.للرجوع اليها ، انظر:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM روتين شخصية إيهابي.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS يستخدم الروتين الافتراضي بدلاً من ذلك لأنه يستخدم فك SjLj.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // سوف تستدعي backtraces على ARM روتين الشخصية مع الحالة==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // في هذه الحالات ، نرغب في الاستمرار في فك المكدس ، وإلا ستنتهي جميع مساراتنا الخلفية عند __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // يفترض برنامج فك DWARF أن _Unwind_Context يحمل أشياء مثل الوظيفة ومؤشرات LSDA ، ولكن ARM EHABI يضعها في كائن الاستثناء.
            // للحفاظ على تواقيع وظائف مثل _Unwind_GetLanguageSpecificData() ، والتي تأخذ فقط مؤشر السياق ، فإن إجراءات شخصية GCC تخفي مؤشرًا لكائن الاستثناء في السياق ، باستخدام الموقع المحجوز لـ ARM's "scratch register" (r12).
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... قد يكون النهج الأكثر مبدئيًا هو توفير التعريف الكامل لـ ARM's_Unwind_Context في ارتباطات libunwind الخاصة بنا وجلب البيانات المطلوبة من هناك مباشرةً ، متجاوزًا وظائف توافق DWARF.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // يتطلب EHABI روتين الشخصية لتحديث قيمة SP في ذاكرة التخزين المؤقت الحاجز لكائن الاستثناء.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // في ARM EHABI ، يكون روتين الشخصية مسؤولاً عن فك إطار مكدس واحد فعليًا قبل العودة (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // المعرفة في libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // روتين الشخصية الافتراضي ، والذي يتم استخدامه بشكل مباشر على معظم الأهداف وبشكل غير مباشر على Windows x86_64 عبر SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // بالنسبة لأهداف x86_64 MinGW ، فإن آلية فك اللفة هي SEH ، لكن بيانات معالج الفك (المعروف أيضًا باسم LSDA) تستخدم تشفيرًا متوافقًا مع GCC.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // روتين الشخصية لمعظم أهدافنا.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // يشير عنوان المرسل إلى 1 بايت بعد تعليمات الاستدعاء ، والتي يمكن أن تكون في نطاق IP التالي في جدول نطاق LSDA.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// استرخاء معلومات التسجيل
//
// تحتوي كل صورة وحدة نمطية على قسم معلومات استرخاء الإطار (عادةً ".eh_frame").عندما تكون الوحدة النمطية loaded/unloaded في العملية ، يجب إعلام وحدة فك اللفة بموقع هذا القسم في الذاكرة.تختلف طرق تحقيق ذلك حسب المنصة.
// في بعض الحالات (على سبيل المثال ، Linux) ، يمكن لوحدة فك اللفة اكتشاف أقسام معلومات الاستراحة من تلقاء نفسها (من خلال تعداد الوحدات النمطية المحملة حاليًا بشكل ديناميكي عبر dl_iterate_phdr() API and finding their ".eh_frame" sections) ؛ تتطلب أجهزة أخرى ، مثل Windows ، وحدات لتسجيل أقسام معلومات الاسترخاء بشكل نشط عبر واجهة برمجة تطبيقات إلغاء اللف.
//
//
// تحدد هذه الوحدة رمزين تمت الإشارة إليهما واستدعائهما من rsbegin.rs لتسجيل معلوماتنا في وقت تشغيل GCC.
// تم تأجيل تنفيذ فك تجميع المكدس (في الوقت الحالي) إلى libgcc_eh ، ولكن Rust crates تستخدم نقاط الإدخال الخاصة بـ Rust هذه لتجنب التعارضات المحتملة مع أي وقت تشغيل لـ GCC
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}