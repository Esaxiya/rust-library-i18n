//! Windows SEH
//!
//! في Windows (حاليًا على MSVC فقط) ، تكون آلية معالجة الاستثناءات الافتراضية هي معالجة الاستثناءات الهيكلية (SEH).
//! هذا يختلف تمامًا عن معالجة الاستثناء المستندة إلى Dwarf (على سبيل المثال ، ما تستخدمه منصات unix الأخرى) من حيث المكونات الداخلية للمترجم ، لذا فإن LLVM مطلوب للحصول على قدر كبير من الدعم الإضافي لـ SEH.
//!
//! باختصار ، ما يحدث هنا هو:
//!
//! 1. تستدعي الدالة `panic` وظيفة Windows القياسية `_CxxThrowException` لإلقاء استثناء مثل C++ ، مما يؤدي إلى بدء عملية فك اللفة.
//! 2.
//! تستخدم جميع منصات الهبوط التي تم إنشاؤها بواسطة المترجم وظيفة السمات `__CxxFrameHandler3` ، وهي وظيفة في CRT ، وسيستخدم رمز فك اللف في Windows هذه الوظيفة الشخصية لتنفيذ جميع رموز التنظيف على المكدس.
//!
//! 3. تحتوي جميع المكالمات التي تم إنشاؤها بواسطة المترجم إلى `invoke` على لوحة هبوط تم تعيينها كتعليمات `cleanuppad` LLVM ، والتي تشير إلى بدء روتين التنظيف.
//! الشخصية (في الخطوة 2 ، المحددة في CRT) هي المسؤولة عن تشغيل إجراءات التنظيف.
//! 4. في النهاية ، يتم تنفيذ كود "catch" في `try` الجوهري (الذي تم إنشاؤه بواسطة المترجم) ويشير إلى أن التحكم يجب أن يعود إلى Rust.
//! يتم ذلك عبر تعليمات `catchswitch` بالإضافة إلى تعليمات `catchpad` بمصطلحات LLVM IR ، وأخيرًا إعادة التحكم العادي إلى البرنامج بتعليمات `catchret`.
//!
//! بعض الاختلافات المحددة عن معالجة الاستثناء المستندة إلى gcc هي:
//!
//! * لا يحتوي Rust على وظيفة شخصية مخصصة ، فهو بدلاً من ذلك *دائمًا*`__CxxFrameHandler3`.بالإضافة إلى ذلك ، لا يتم إجراء أي تصفية إضافية ، لذلك ينتهي بنا المطاف بإمساك أي استثناءات C++ التي تبدو مثل النوع الذي نرميها.
//! لاحظ أن طرح استثناء في Rust هو سلوك غير محدد على أي حال ، لذا يجب أن يكون هذا جيدًا.
//! * لدينا بعض البيانات التي يجب نقلها عبر حدود التفكيك ، وتحديداً `Box<dyn Any + Send>`.كما هو الحال مع استثناءات Dwarf ، يتم تخزين هذين المؤشرين كحمولة في الاستثناء نفسه.
//! ومع ذلك ، في MSVC ، ليست هناك حاجة لتخصيص كومة إضافية لأنه يتم الاحتفاظ بمكدس الاستدعاءات أثناء تنفيذ وظائف التصفية.
//! هذا يعني أنه يتم تمرير المؤشرات مباشرة إلى `_CxxThrowException` والتي يتم استعادتها بعد ذلك في وظيفة المرشح ليتم كتابتها في إطار المكدس الخاص بـ `try` المضمن.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // يجب أن يكون هذا خيارًا لأننا نلتقط الاستثناء من خلال المرجع ويتم تنفيذ المدمر الخاص به بواسطة وقت تشغيل C++ .
    // عندما نخرج المربع من الاستثناء ، نحتاج إلى ترك الاستثناء في حالة صالحة لتشغيل أداة التدمير الخاصة به دون إسقاط المربع مرتين.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// أولاً ، مجموعة كاملة من تعريفات الأنواع.هناك عدد قليل من الشذوذ الخاص بالمنصة هنا ، والكثير منها تم نسخه بشكل صارخ من LLVM.الغرض من كل هذا هو تنفيذ وظيفة `panic` أدناه من خلال استدعاء `_CxxThrowException`.
//
// هذه الوظيفة تأخذ حجتين.الأول هو مؤشر للبيانات التي نمررها ، وهو في هذه الحالة كائن trait.من السهل جدا أن تجد!لكن التالي أكثر تعقيدًا.
// هذا مؤشر إلى بنية `_ThrowInfo` ، ويقصد به عمومًا وصف الاستثناء الذي يتم طرحه فقط.
//
// تعريف هذا النوع [1] حاليًا مشعر قليلاً ، والغريب الرئيسي (والاختلاف عن المقالة عبر الإنترنت) هو أن المؤشرات في 32 بت هي مؤشرات ولكن في 64 بت ، يتم التعبير عن المؤشرات على أنها إزاحات 32 بت من رمز `__ImageBase`.
//
// يتم استخدام الماكرو `ptr_t` و `ptr!` في الوحدات النمطية أدناه للتعبير عن هذا.
//
// تتبع متاهة تعريفات الأنواع أيضًا عن كثب ما يصدره LLVM لهذا النوع من العمليات.على سبيل المثال ، إذا جمعت كود C++ هذا على MSVC وأرسلت LLVM IR:
//
//      #include <stdint.h>
//
//      هيكل rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2] ؛} ؛
//
//      foo() { rust_panic a = {0, 1} باطل ؛
//          اقذف ال؛}
//
// هذا في الأساس ما نحاول محاكاته.تم نسخ معظم القيم الثابتة أدناه من LLVM ،
//
// على أي حال ، يتم إنشاء جميع هذه الهياكل بطريقة مماثلة ، وهي مطولة إلى حد ما بالنسبة لنا.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// لاحظ أننا نتجاهل عمدًا قواعد تغيير الاسم هنا: لا نريد أن تتمكن C++ من التقاط Rust panics بمجرد الإعلان عن `struct rust_panic`.
//
//
// عند التعديل ، تأكد من أن سلسلة اسم النوع تطابق تمامًا تلك المستخدمة في `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // البايت `\x01` الرائد هنا هو في الواقع إشارة سحرية لـ LLVM من أجل *عدم* تطبيق أي تشويش آخر مثل البادئة بحرف `_`.
    //
    //
    // هذا الرمز هو vtable المستخدم بواسطة `std::type_info` الخاص بـ C++ .
    // كائنات من النوع `std::type_info` ، اكتب واصفات ، لها مؤشر لهذا الجدول.
    // تتم الإشارة إلى واصفات النوع بواسطة هياكل C++ EH المحددة أعلاه والتي نبنيها أدناه.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// يستخدم هذا النوع من الواصف فقط عند طرح استثناء.
// يتم التعامل مع جزء الالتقاط من خلال المحاولة الجوهرية ، والتي تنشئ TypeDescriptor الخاص بها.
//
// هذا جيد لأن وقت تشغيل MSVC يستخدم مقارنة سلسلة على اسم النوع لمطابقة TypeDescriptors بدلاً من مساواة المؤشر.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// يتم استخدام Destructor إذا قررت شفرة C++ التقاط الاستثناء وإفلاته دون نشره.
// سيؤدي جزء الالتقاط من المحاولة الجوهرية إلى تعيين الكلمة الأولى من كائن الاستثناء إلى 0 بحيث يتم تخطيها بواسطة أداة التدمير.
//
// لاحظ أن x86 Windows يستخدم اصطلاح استدعاء "thiscall" لوظائف عضو C++ بدلاً من اصطلاح استدعاء "C" الافتراضي.
//
// تعتبر وظيفة استثناء_copy خاصة بعض الشيء هنا: يتم استدعاؤها بواسطة وقت تشغيل MSVC ضمن كتلة try/catch وسيتم استخدام panic الذي قمنا بإنشائه هنا كنتيجة لنسخة الاستثناء.
//
// يتم استخدام هذا في وقت تشغيل C++ لدعم استثناءات الالتقاط مع std::exception_ptr ، والتي لا يمكننا دعمها لأن Box<dyn Any>لا يمكن استنساخه.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException يتم تنفيذه بالكامل على إطار المكدس هذا ، لذلك لا داعي لنقل `data` إلى الكومة.
    // نحن فقط نمرر مؤشر مكدس لهذه الوظيفة.
    //
    // هناك حاجة إلى ManuallyDrop هنا لأننا لا نريد حذف الاستثناء عند فك الارتباط.
    // وبدلاً من ذلك ، سيتم إسقاطه من خلال exception_cleanup الذي يتم استدعاؤه بواسطة C++ runtime.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // قد يبدو هذا مفاجئًا ، وله ما يبرره.في MSVC 32 بت ، تكون المؤشرات بين هذه البنية مجرد مؤشرات.
    // على الرغم من ذلك ، في MSVC 64 بت ، يتم التعبير عن المؤشرات بين الهياكل على أنها إزاحات 32 بت من `__ImageBase`.
    //
    // وبالتالي ، في MSVC 32 بت ، يمكننا أن نعلن عن كل هذه المؤشرات في `ثابت` أعلاه.
    // في MSVC 64 بت ، سيتعين علينا التعبير عن طرح المؤشرات في الإحصائيات ، وهو ما لا يسمح به Rust حاليًا ، لذلك لا يمكننا فعل ذلك في الواقع.
    //
    // أفضل شيء بعد ذلك هو ملء هذه الهياكل في وقت التشغيل (الذعر هو بالفعل "slow path" على أي حال).
    // لذلك نحن هنا نعيد تفسير كل حقول المؤشر هذه على أنها أعداد صحيحة 32 بت ثم نخزن القيمة ذات الصلة فيها (ذريًا ، كما قد يحدث panics المتزامن).
    //
    // من الناحية الفنية ، من المحتمل أن يقوم وقت التشغيل بقراءة غير ذرية لهذه الحقول ، لكن من الناحية النظرية لم يقرؤوا أبدًا القيمة *الخطأ* لذا لا ينبغي أن تكون سيئة للغاية ...
    //
    // على أي حال ، نحتاج أساسًا إلى القيام بشيء من هذا القبيل حتى نتمكن من التعبير عن المزيد من العمليات في الإحصائيات (وقد لا نتمكن أبدًا من ذلك).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // تعني الحمولة الفارغة هنا أننا وصلنا إلى هنا من (...) من __rust_try.
    // يحدث هذا عندما يتم اكتشاف استثناء خارجي غير Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// هذا مطلوب من قبل المترجم ليكون موجودًا (على سبيل المثال ، عنصر lang) ، ولكن لم يتم استدعاؤه فعليًا من قبل المترجم لأن __C_specific_handler أو _except_handler3 هي وظيفة الشخصية التي يتم استخدامها دائمًا.
//
// ومن ثم فإن هذا مجرد كعب مُجهض.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}