//! استرخاء لهدف *emscripten*.
//!
//! في حين أن تنفيذ Rust المعتاد لفك الارتباط لأنظمة Unix يستدعي واجهات برمجة تطبيقات libunwind مباشرة ، فإننا في Emscripten ندعو بدلاً من ذلك إلى واجهات برمجة تطبيقات فك C++ .
//! هذه مجرد وسيلة نفعية لأن وقت تشغيل Emscripten يطبق دائمًا واجهات برمجة التطبيقات تلك ولا يقوم بتطبيق libunwind.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// هذا يطابق تخطيط std::type_info في C++
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // البايت `\x01` الرائد هنا هو في الواقع إشارة سحرية لـ LLVM من أجل *عدم* تطبيق أي تشويش آخر مثل البادئة بحرف `_`.
    //
    //
    // هذا الرمز هو vtable المستخدم بواسطة `std::type_info` الخاص بـ C++ .
    // كائنات من النوع `std::type_info` ، اكتب واصفات ، لها مؤشر لهذا الجدول.
    // تتم الإشارة إلى واصفات النوع بواسطة هياكل C++ EH المحددة أعلاه والتي نبنيها أدناه.
    //
    // لاحظ أن الحجم الحقيقي أكبر من 3 استخدامات ، لكننا نحتاج فقط إلى vtable للإشارة إلى العنصر الثالث.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info لفئة rust_panic
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // عادةً ما نستخدم .as_ptr().add(2) ولكن هذا لا يعمل في سياق ثابت.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // هذا لا يستخدم عن قصد مخطط تشويش الاسم العادي لأننا لا نريد أن تكون C++ قادرة على إنتاج أو التقاط Rust panics.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // يعد هذا ضروريًا لأن كود C++ يمكنه التقاط استثناءنا مع std::exception_ptr وإعادة طرحه عدة مرات ، وربما حتى في مؤشر ترابط آخر.
    //
    //
    caught: AtomicBool,

    // يجب أن يكون هذا خيارًا لأن عمر الكائن يتبع دلالات C++ : عندما يحرك catch_unwind المربع خارج الاستثناء ، لا يزال يتعين عليه ترك كائن الاستثناء في حالة صالحة لأن المدمر الخاص به لا يزال سيتم استدعاؤه بواسطة __cxa_end_catch.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try في الواقع يعطينا مؤشرًا لهذه البنية.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // نظرًا لأن cleanup() غير مسموح به لـ panic ، فإننا نجهض بدلاً من ذلك.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}