//! فك panics لميري.
use alloc::boxed::Box;
use core::any::Any;

// نوع الحمولة التي ينشرها محرك ميري من خلال تفكيكها لنا.
// يجب أن يكون بحجم المؤشر.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// وظيفة خارجية مقدمة من Miri لبدء الفك.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // ستكون الحمولة التي نمررها إلى `miri_start_panic` هي بالضبط الحجة التي سنحصل عليها في `cleanup` أدناه.
    // لذلك نحن فقط نضعها في صندوق مرة واحدة ، للحصول على شيء بحجم المؤشر.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // استرجع `Box` الأساسي.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}