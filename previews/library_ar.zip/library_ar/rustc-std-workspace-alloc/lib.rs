#![feature(no_core)]
#![no_core]

// راجع rustc-std-workspace-core لمعرفة سبب الحاجة إلى crate.

// أعد تسمية crate لتجنب التعارض مع وحدة التخصيص في liballoc.
extern crate alloc as foo;

pub use foo::*;