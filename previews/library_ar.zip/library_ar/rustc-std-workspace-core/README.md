# `rustc-std-workspace-core` crate

crate هذا عبارة عن crate فارغ وفارغ ويعتمد ببساطة على `libcore` ويعيد تصدير جميع محتوياته.
crate هو جوهر تمكين المكتبة القياسية من الاعتماد على crates من crates.io

Crates على crates.io أن المكتبة القياسية تعتمد على الحاجة إلى الاعتماد على `rustc-std-workspace-core` crate من crates.io ، وهي فارغة.

نستخدم `[patch]` لتجاوزه إلى crate هذا في هذا المستودع.
نتيجة لذلك ، سوف يرسم crates على crates.io تبعية edge إلى `libcore` ، الإصدار المحدد في هذا المستودع.
يجب أن يرسم ذلك كل حواف التبعية لضمان أن يبني Cargo crates بنجاح!

لاحظ أن crates على crates.io تحتاج إلى الاعتماد على crate بالاسم `core` لكي يعمل كل شيء بشكل صحيح.للقيام بذلك يمكنهم استخدام:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

من خلال استخدام مفتاح `package` ، تمت إعادة تسمية crate إلى `core` ، مما يعني أنها ستبدو مثل

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

عندما يستدعي Cargo المترجم ، يلبي توجيه `extern crate core` الضمني الذي تم حقنه بواسطة المترجم.




