# المساهمة في stdarch

`stdarch` crate أكثر من مستعد لقبول المساهمات!أولاً ، ربما ترغب في التحقق من المستودع والتأكد من اجتياز الاختبارات لك:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

حيث `<your-target-arch>` هو الهدف الثلاثي كما هو مستخدم بواسطة `rustup` ، على سبيل المثال `x86_x64-unknown-linux-gnu` (بدون أي سابق `nightly-` أو ما شابه).
تذكر أيضًا أن هذا المستودع يتطلب قناة Rust الليلية!
تتطلب الاختبارات المذكورة أعلاه في الواقع أن يكون rust الليلي هو الإعداد الافتراضي على نظامك ، لتعيين استخدام `rustup default nightly` (و `rustup default stable` للعودة).

إذا لم تنجح أي من الخطوات المذكورة أعلاه ، [please let us know][new]!

بعد ذلك ، يمكنك [find an issue][issues] للمساعدة ، لقد اخترنا عددًا قليلاً باستخدام علامتي [`help wanted`][help] و [`impl-period`][impl] والتي يمكن أن تستخدم بعض المساعدة بشكل خاص. 
قد تكون مهتمًا أكثر بـ [#40][vendor] ، حيث تقوم بتنفيذ كافة مضمنات البائع على x86.تحتوي هذه المشكلة على بعض المؤشرات الجيدة حول من أين تبدأ!

إذا كانت لديك أسئلة عامة ، فلا تتردد في استخدام [join us on gitter][gitter] واسأل من حولك!لا تتردد في إجراء اختبار ping إماBurntSushi أوalexcrichton مع الأسئلة.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# كيفية كتابة أمثلة لجوهر stdarch

هناك عدد قليل من الميزات التي يجب تمكينها لكي يعمل الجوهر المحدد بشكل صحيح ويجب تشغيل المثال بواسطة `cargo test --doc` فقط عندما تكون الميزة مدعومة بواسطة وحدة المعالجة المركزية.

نتيجة لذلك ، لن يعمل `fn main` الافتراضي الذي تم إنشاؤه بواسطة `rustdoc` (في معظم الحالات).
ضع في اعتبارك استخدام ما يلي كدليل للتأكد من أن المثال الخاص بك يعمل كما هو متوقع.

```rust
/// # // نحتاج إلى cfg_target_feature للتأكد من أن المثال هو فقط
/// # // يعمل بواسطة `cargo test --doc` عندما تدعم وحدة المعالجة المركزية هذه الميزة
/// # #![feature(cfg_target_feature)]
/// # // نحن بحاجة إلى target_feature لكي يعمل الجوهر
/// # #![feature(target_feature)]
/// #
/// # // يستخدم rustdoc افتراضيًا `extern crate stdarch` ، لكننا نحتاج إلى ملف
/// # // `#[macro_use]`
/// # # [macro_use] خارجي crate stdarch ؛
/// #
/// # // الوظيفة الرئيسية الحقيقية
/// # fn main() {
/// #     // قم بتشغيل هذا فقط إذا كان `<target feature>` مدعومًا
/// #     إذا كان cfg_feature_enabled! ("<target feature>"){
/// #         // قم بإنشاء دالة `worker` التي سيتم تشغيلها فقط إذا كانت الميزة الهدف
/// #         // مدعوم وتأكد من تمكين `target_feature` للعاملين لديك
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         غير آمنة fn worker() {
/// // اكتب مثالك هنا.ستعمل العناصر المضمنة الخاصة بالميزات هنا!الذهاب البرية!
///
/// #         }
///
/// #         { worker(); } غير آمن
/// #     }
/// # }
```

إذا كانت بعض الصيغ أعلاه لا تبدو مألوفة ، فإن قسم [Documentation as tests] من [Rust Book] يصف بناء جملة `rustdoc` جيدًا.
كما هو الحال دائمًا ، لا تتردد في [join us on gitter][gitter] واسألنا إذا واجهت أي عقبات ، وشكرًا لك على المساعدة في تحسين توثيق `stdarch`!

# تعليمات الاختبار البديل

يوصى عمومًا باستخدام `ci/run.sh` لتشغيل الاختبارات.
ومع ذلك ، قد لا يعمل هذا من أجلك ، على سبيل المثال إذا كنت تستخدم Windows.

في هذه الحالة ، يمكنك الرجوع إلى تشغيل `cargo +nightly test` و `cargo +nightly test --release -p core_arch` لاختبار إنشاء الكود.
لاحظ أن هذه تتطلب تثبيت سلسلة الأدوات الليلية ولكي يعرف `rustc` عن الثلاثي المستهدف ووحدة المعالجة المركزية الخاصة به.
على وجه الخصوص ، تحتاج إلى تعيين متغير البيئة `TARGET` كما تفعل مع `ci/run.sh`.
بالإضافة إلى ذلك ، تحتاج إلى ضبط `RUSTCFLAGS` (تحتاج إلى `C`) للإشارة إلى الميزات المستهدفة ، على سبيل المثال `RUSTCFLAGS="-C -target-features=+avx2"`.
يمكنك أيضًا تعيين `-C -target-cpu=native` إذا كنت تقوم بتطوير "just" مقابل وحدة المعالجة المركزية الحالية.

كن حذرًا من أنه عند استخدام هذه الإرشادات البديلة ، فإن [things may go less smoothly than they would with `ci/run.sh`][ci-run-good] ، على سبيل المثال
قد تفشل اختبارات توليد التعليمات لأن المفكك أطلق عليها اسمًا مختلفًا ، على سبيل المثال
قد تولد `vaesenc` بدلاً من تعليمات `aesenc` على الرغم من أنها تتصرف بنفس الطريقة.
تقوم هذه التعليمات أيضًا بتنفيذ اختبارات أقل مما يتم إجراؤه عادةً ، لذلك لا تندهش من أنه عند طلب السحب في النهاية ، قد تظهر بعض الأخطاء للاختبارات التي لم يتم تناولها هنا.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






