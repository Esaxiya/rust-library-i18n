use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // تُستخدم لإخبار تعليقات `#[assert_instr]` التوضيحية الخاصة بنا بأن جميع مداخلات simd متاحة لاختبار كودها ، نظرًا لأن بعضها محصور خلف `-Ctarget-feature=+unimplemented-simd128` إضافي لا يحتوي على أي مكافئ في `#[target_feature]` في الوقت الحالي.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}