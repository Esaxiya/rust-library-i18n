#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// انظر [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_READ: i32 = 0;

/// انظر [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_WRITE: i32 = 1;

/// انظر [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// انظر [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// انظر [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// انظر [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// قم بإحضار سطر ذاكرة التخزين المؤقت الذي يحتوي على العنوان `p` باستخدام `rw` و `locality` المحدد.
///
/// يجب أن يكون `rw` واحدًا مما يلي:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): الجلب المسبق يستعد للقراءة.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): الجلب المسبق يستعد للكتابة.
///
/// يجب أن يكون `locality` واحدًا مما يلي:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): الجلب المسبق المتدفق أو غير الزمني للبيانات التي يتم استخدامها مرة واحدة فقط.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): إحضار إلى المستوى 3 مخبأ.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): إحضار إلى المستوى 2 من ذاكرة التخزين المؤقت.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): إحضار إلى ذاكرة التخزين المؤقت المستوى 1.
///
/// إشارة تعليمات ذاكرة الجلب المسبق إلى نظام الذاكرة التي تصل إليها الذاكرة من عنوان محدد من المحتمل أن تحدث بالقرب من future.
/// يمكن لنظام الذاكرة الاستجابة عن طريق اتخاذ الإجراءات التي من المتوقع أن تسرع الوصول إلى الذاكرة عند حدوثها ، مثل التحميل المسبق للعنوان المحدد في ذاكرة تخزين مؤقت واحدة أو أكثر.
///
/// نظرًا لأن هذه الإشارات ليست سوى تلميحات ، فمن الصحيح لوحدة معالجة مركزية معينة أن تتعامل مع أي أو كل تعليمات الجلب المسبق على أنها NOP.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // نستخدم `llvm.prefetch` instrinsic مع `cache type` =1 (ذاكرة التخزين المؤقت للبيانات).
    // `rw` و `strategy` تعتمد على معلمات الوظيفة.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}