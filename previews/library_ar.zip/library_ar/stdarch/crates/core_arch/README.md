`core::arch` - العناصر الداخلية الخاصة بهندسة المكتبات الأساسية Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

تقوم الوحدة النمطية `core::arch` بتنفيذ العناصر الداخلية المعتمدة على البنية (مثل SIMD).

# Usage 

`core::arch` متاح كجزء من `libcore` ويتم إعادة تصديره بواسطة `libstd`.يفضل استخدامه عبر `core::arch` أو `std::arch` بدلاً من استخدام crate.
غالبًا ما تتوفر الميزات غير المستقرة في Rust ليلاً عبر `feature(stdsimd)`.

يتطلب استخدام `core::arch` عبر crate هذا Rust ليلاً ، ويمكن أن ينكسر (ويفعل) كثيرًا.الحالات الوحيدة التي يجب أن تفكر فيها في استخدامه عبر crate هي:

* إذا كنت بحاجة إلى إعادة تجميع `core::arch` بنفسك ، على سبيل المثال ، مع تمكين ميزات هدف معينة لم يتم تمكينها لـ `libcore`/`libstd`.
Note: إذا كنت بحاجة إلى إعادة تجميعه لهدف غير قياسي ، فيرجى تفضيل استخدام `xargo` وإعادة تجميع `libcore`/`libstd` حسب الاقتضاء بدلاً من استخدام crate.
  
* باستخدام بعض الميزات التي قد لا تكون متاحة حتى في ظل ميزات Rust غير المستقرة.نحاول التقليل من هذه الأمور.
إذا كنت بحاجة إلى استخدام بعض هذه الميزات ، فيرجى فتح مشكلة حتى نتمكن من كشفها ليلاً في Rust ويمكنك استخدامها من هناك.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` يتم توزيعها بشكل أساسي بموجب شروط كل من ترخيص MIT وترخيص Apache (الإصدار 2.0) ، مع أجزاء مغطاة بالعديد من التراخيص المشابهة لـ BSD.

راجع LICENSE-APACHE و LICENSE-MIT للحصول على التفاصيل.

# Contribution

ما لم تنص صراحة على خلاف ذلك ، فإن أي مساهمة يتم تقديمها عن قصد لإدراجها في `core_arch` بواسطتك ، كما هو محدد في ترخيص Apache-2.0 ، يجب أن تكون مرخصة بشكل مزدوج على النحو الوارد أعلاه ، دون أي شروط أو شروط إضافية.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












