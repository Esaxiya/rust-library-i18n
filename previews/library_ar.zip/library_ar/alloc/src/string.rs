//! سلسلة قابلة للنمو بترميز UTF-8.
//!
//! تحتوي هذه الوحدة على النوع [`String`] ، و [`ToString`] trait للتحويل إلى سلاسل ، والعديد من أنواع الأخطاء التي قد تنتج عن العمل مع [`String`].
//!
//!
//! # Examples
//!
//! هناك عدة طرق لإنشاء [`String`] جديد من سلسلة حرفية:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! يمكنك إنشاء [`String`] جديد من واحد موجود عن طريق التسلسل مع
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! إذا كان لديك vector من UTF-8 بايت صالح ، فيمكنك إنشاء [`String`] منه.يمكنك القيام بالعكس أيضا.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // نحن نعلم أن هذه البايتات صالحة ، لذلك سنستخدم `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// سلسلة قابلة للنمو بترميز UTF-8.
///
/// النوع `String` هو أكثر أنواع السلسلة شيوعًا التي لها ملكية على محتويات السلسلة.له علاقة وثيقة مع نظيره المقترض ، [`str`] البدائي.
///
/// # Examples
///
/// يمكنك إنشاء `String` من [a literal string][`str`] باستخدام [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// يمكنك إلحاق [`char`] بـ `String` باستخدام طريقة [`push`] ، وإلحاق [`&str`] بطريقة [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// إذا كان لديك vector من UTF-8 بايت ، فيمكنك إنشاء `String` منه باستخدام طريقة [`from_utf8`]:
///
/// ```
/// // بعض البايتات في vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // نحن نعلم أن هذه البايتات صالحة ، لذلك سنستخدم `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// دائمًا ما تكون `String`s صالحة UTF-8.هذا له آثار قليلة ، أولها أنه إذا كنت بحاجة إلى سلسلة غير UTF-8 ، ففكر في [`OsString`].إنه مشابه ، لكن بدون قيود UTF-8.المعنى الثاني هو أنه لا يمكنك الفهرسة في `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// يُقصد من الفهرسة أن تكون عملية ذات وقت ثابت ، لكن ترميز UTF-8 لا يسمح لنا بالقيام بذلك.علاوة على ذلك ، ليس من الواضح أي نوع من الأشياء يجب أن يعود الفهرس: بايت ، أو نقطة كود ، أو مجموعة حروف.
/// تعيد الطريقتان [`bytes`] و [`chars`] التكرارات على الأولين ، على التوالي.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// "String`s تنفذ [`Deref`] `<Target=str>`، وبالتالي ترث جميع طرق [`str`].بالإضافة إلى ذلك ، هذا يعني أنه يمكنك تمرير `String` إلى وظيفة تأخذ [`&str`] باستخدام علامة العطف (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// سيؤدي هذا إلى إنشاء [`&str`] من `String` وتمريره. هذا التحويل غير مكلف للغاية ، وبشكل عام ، ستقبل الدوال [`&str`] كوسيطات ما لم تكن بحاجة إلى `String` لسبب معين.
///
/// في بعض الحالات ، لا يتوفر لدى Rust معلومات كافية لإجراء هذا التحويل ، المعروف باسم إكراه [`Deref`].في المثال التالي ، تقوم شريحة السلسلة [`&'a str`][`&str`] بتنفيذ trait `TraitExample` ، وتأخذ الوظيفة `example_func` أي شيء يقوم بتنفيذ trait.
/// في هذه الحالة ، ستحتاج Rust إلى إجراء تحويلين ضمنيين ، وهو ما لا يملك Rust الوسائل للقيام بهما.
/// لهذا السبب ، لن يتم ترجمة المثال التالي.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// هناك خياران يعملان بدلاً من ذلك.الأول هو تغيير السطر `example_func(&example_string);` إلى `example_func(example_string.as_str());` ، باستخدام الطريقة [`as_str()`] لاستخراج شريحة السلسلة التي تحتوي على السلسلة بشكل صريح.
/// الطريقة الثانية تتغير من `example_func(&example_string);` إلى `example_func(&*example_string);`.
/// في هذه الحالة ، نلغي الإشارة إلى `String` إلى [`str`][`&str`] ، ثم نرجع [`str`][`&str`] إلى [`&str`].
/// الطريقة الثانية هي أكثر اصطلاحية ، ولكن كلاهما يعمل على إجراء التحويل بشكل صريح بدلاً من الاعتماد على التحويل الضمني.
///
/// # Representation
///
/// يتكون `String` من ثلاثة مكونات: مؤشر إلى بعض البايتات ، وطول ، وسعة.يشير المؤشر إلى مخزن مؤقت داخلي يستخدمه `String` لتخزين بياناته.الطول هو عدد البايتات المخزنة حاليًا في المخزن المؤقت ، والسعة هي حجم المخزن المؤقت بالبايت.
///
/// على هذا النحو ، سيكون الطول دائمًا أقل من السعة أو مساويًا لها.
///
/// يتم تخزين هذا المخزن المؤقت دائمًا على الكومة.
///
/// يمكنك إلقاء نظرة عليها باستخدام طرق [`as_ptr`] و [`len`] و [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME قم بتحديث هذا عند استقرار vec_into_raw_parts.
/// // منع إسقاط بيانات السلسلة تلقائيًا
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // القصة تسعة عشر بايت
/// assert_eq!(19, len);
///
/// // يمكننا إعادة بناء سلسلة من ptr و len والقدرة.
/// // هذا كله غير آمن لأننا مسؤولون عن التأكد من صحة المكونات:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// إذا كان لدى `String` سعة كافية ، فلن يتم إعادة تخصيص إضافة عناصر إليه.على سبيل المثال ، ضع في اعتبارك هذا البرنامج:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// سينتج هذا ما يلي:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// في البداية ، ليست لدينا ذاكرة مخصصة على الإطلاق ، ولكن عندما نلحق السلسلة ، فإنها تزيد من قدرتها بشكل مناسب.إذا استخدمنا طريقة [`with_capacity`] بدلاً من ذلك لتخصيص السعة الصحيحة في البداية:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// ننتهي بإخراج مختلف:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// هنا ، ليست هناك حاجة لتخصيص المزيد من الذاكرة داخل الحلقة.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// قيمة خطأ محتملة عند تحويل `String` من UTF-8 بايت vector.
///
/// هذا النوع هو نوع الخطأ لطريقة [`from_utf8`] على [`String`].
/// تم تصميمه بطريقة لتجنب إعادة التخصيص بعناية: طريقة [`into_bytes`] ستعيد البايت vector الذي تم استخدامه في محاولة التحويل.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// يمثل النوع [`Utf8Error`] المقدم من [`std::str`] خطأ قد يحدث عند تحويل شريحة من [`u8`] s إلى [`&str`].
/// بهذا المعنى ، إنه تناظري لـ `FromUtf8Error` ، ويمكنك الحصول على واحد من `FromUtf8Error` عبر طريقة [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// الاستخدام الأساسي:
///
/// ```
/// // بعض البايتات غير الصالحة في vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// قيمة خطأ محتملة عند تحويل `String` من شريحة بايت UTF-16.
///
/// هذا النوع هو نوع الخطأ لطريقة [`from_utf16`] على [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// الاستخدام الأساسي:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// ينشئ `String` فارغًا جديدًا.
    ///
    /// نظرًا لأن `String` فارغ ، فلن يتم تخصيص أي مخزن مؤقت أولي.في حين أن هذا يعني أن هذه العملية الأولية غير مكلفة للغاية ، إلا أنها قد تتسبب في تخصيص مفرط لاحقًا عند إضافة البيانات.
    ///
    /// إذا كانت لديك فكرة عن مقدار البيانات التي سيحتفظ بها `String` ، ففكر في طريقة [`with_capacity`] لمنع إعادة التخصيص المفرط.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// ينشئ `String` فارغًا جديدًا بسعة معينة.
    ///
    /// تحتوي "السلسلة" على مخزن مؤقت داخلي للاحتفاظ ببياناتها.
    /// السعة هي طول ذلك المخزن المؤقت ، ويمكن الاستعلام عنها بطريقة [`capacity`].
    /// ينشئ هذا الأسلوب `String` فارغًا ، ولكن يحتوي على مخزن مؤقت أولي يمكنه الاحتفاظ بـ `capacity` بايت.
    /// يكون هذا مفيدًا عندما تقوم بإلحاق مجموعة من البيانات إلى `String` ، مما يقلل من عدد عمليات إعادة التخصيص التي يتعين القيام بها.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// إذا كانت السعة المحددة هي `0` ، فلن يحدث أي تخصيص ، وهذه الطريقة مماثلة لطريقة [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // لا تحتوي السلسلة على أحرف ، على الرغم من أن لديها القدرة على المزيد
    /// assert_eq!(s.len(), 0);
    ///
    /// // كل هذا يتم دون إعادة تخصيص ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... ولكن هذا قد يؤدي إلى إعادة تخصيص السلسلة
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): مع cfg(test) ، طريقة `[T]::to_vec` المتأصلة ، المطلوبة لتعريف الأسلوب هذا ، غير متوفرة.
    // نظرًا لأننا لا نطلب هذه الطريقة لأغراض الاختبار ، سأقوم فقط بإيقافها NB ، انظر الوحدة النمطية slice::hack في slice.rs لمزيد من المعلومات
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// تحويل vector بايت إلى `String`.
    ///
    /// السلسلة ([`String`]) مكونة من بايت ([`u8`]) ، و vector من بايت ([`Vec<u8>`]) مصنوع من بايت ، لذلك يتم تحويل هذه الوظيفة بين الاثنين.
    /// ليست كل شرائح البايت صالحة `String`s ، ومع ذلك: يتطلب `String` أن يكون UTF-8 صالحًا.
    /// `from_utf8()` يتحقق للتأكد من أن البايت هي UTF-8 صالحة ، ثم يقوم بالتحويل.
    ///
    /// إذا كنت متأكدًا من أن شريحة البايت صالحة UTF-8 ، ولا تريد تحمل النفقات العامة للتحقق من الصلاحية ، فهناك إصدار غير آمن من هذه الوظيفة ، [`from_utf8_unchecked`] ، له نفس السلوك ولكنه يتخطى الفحص.
    ///
    ///
    /// ستحرص هذه الطريقة على عدم نسخ vector ، من أجل الكفاءة.
    ///
    /// إذا كنت بحاجة إلى [`&str`] بدلاً من `String` ، ففكر في [`str::from_utf8`].
    ///
    /// معكوس هذه الطريقة هو [`into_bytes`].
    ///
    /// # Errors
    ///
    /// تُرجع [`Err`] إذا كانت الشريحة ليست UTF-8 مع وصف لماذا البايتات المقدمة ليست UTF-8.يتم أيضًا تضمين vector الذي انتقلت إليه.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// // بعض البايتات في vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // نحن نعلم أن هذه البايتات صالحة ، لذلك سنستخدم `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// بايت غير صحيح:
    ///
    /// ```
    /// // بعض البايتات غير الصالحة في vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// راجع مستندات [`FromUtf8Error`] للحصول على مزيد من التفاصيل حول ما يمكنك القيام به مع هذا الخطأ.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// يحول شريحة من البايت إلى سلسلة ، بما في ذلك الأحرف غير الصالحة.
    ///
    /// تتكون السلاسل من بايت ([`u8`]) ، وشريحة بايت ([`&[u8]`][byteslice]) مصنوعة من بايت ، لذلك يتم تحويل هذه الوظيفة بين الاثنين.ليست كل شرائح البايت عبارة عن سلاسل صالحة ، ومع ذلك: يجب أن تكون السلاسل UTF-8 صالحة.
    /// أثناء هذا التحويل ، سيستبدل `from_utf8_lossy()` أي تسلسلات UTF-8 غير صالحة بـ [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] ، والتي تبدو كالتالي:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// إذا كنت متأكدًا من أن شريحة البايت صالحة UTF-8 ، ولا ترغب في تحمل عبء التحويل ، فهناك إصدار غير آمن من هذه الوظيفة ، [`from_utf8_unchecked`] ، له نفس السلوك ولكنه يتخطى عمليات التحقق.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// تقوم هذه الدالة بإرجاع [`Cow<'a, str>`].إذا كانت شريحة البايت الخاصة بنا غير صالحة UTF-8 ، فإننا نحتاج إلى إدخال الأحرف البديلة ، والتي ستغير حجم السلسلة ، وبالتالي تتطلب `String`.
    /// ولكن إذا كان UTF-8 صالحًا بالفعل ، فلن نحتاج إلى تخصيص جديد.
    /// نوع الإرجاع هذا يسمح لنا بالتعامل مع كلتا الحالتين.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// // بعض البايتات في vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// بايت غير صحيح:
    ///
    /// ```
    /// // بعض البايتات غير الصالحة
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// قم بفك تشفير vector `v` بترميز UTF-16 إلى `String` ، وإرجاع [`Err`] إذا احتوى `v` على أي بيانات غير صالحة.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // لم يتم ذلك عن طريق الجمع: : <Result<_, _>> () لأسباب تتعلق بالأداء.
        // FIXME: يمكن تبسيط الوظيفة مرة أخرى عند إغلاق #48994.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// فك شفرة `v` شريحة UTF-16 المشفرة إلى `String` ، مع استبدال البيانات غير الصالحة بـ [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// بخلاف [`from_utf8_lossy`] التي تُرجع [`Cow<'a, str>`] ، تُرجع `from_utf16_lossy` `String` لأن التحويل من UTF-16 إلى UTF-8 يتطلب تخصيص ذاكرة.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// يحلل `String` إلى مكوناته الخام.
    ///
    /// إرجاع المؤشر الأولي إلى البيانات الأساسية ، وطول السلسلة (بالبايت) ، والسعة المخصصة للبيانات (بالبايت).
    /// هذه هي نفس الوسيطات بنفس ترتيب وسيطات [`from_raw_parts`].
    ///
    /// بعد استدعاء هذه الوظيفة ، يكون المتصل مسؤولاً عن الذاكرة التي يديرها `String` مسبقًا.
    /// الطريقة الوحيدة للقيام بذلك هي تحويل المؤشر الخام والطول والسعة مرة أخرى إلى `String` باستخدام وظيفة [`from_raw_parts`] ، مما يسمح للمدمر بإجراء التنظيف.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// ينشئ `String` جديدًا من الطول والسعة والمؤشر.
    ///
    /// # Safety
    ///
    /// هذا غير آمن للغاية ، نظرًا لعدد الثوابت التي لم يتم التحقق منها:
    ///
    /// * يجب تخصيص الذاكرة في `buf` مسبقًا بواسطة نفس المُخصص الذي تستخدمه المكتبة القياسية ، مع محاذاة مطلوبة تبلغ 1 بالضبط.
    /// * `length` يجب أن يكون أقل من أو يساوي `capacity`.
    /// * `capacity` يجب أن تكون القيمة الصحيحة.
    /// * يجب أن يكون أول بايت `length` عند `buf` UTF-8 صالحًا.
    ///
    /// قد يؤدي انتهاك هذه المشكلات إلى إتلاف هياكل البيانات الداخلية للمخصص.
    ///
    /// يتم نقل ملكية `buf` بشكل فعال إلى `String` والذي قد يقوم بعد ذلك بإلغاء تخصيص أو إعادة تخصيص أو تغيير محتويات الذاكرة التي يشير إليها المؤشر حسب الرغبة.
    /// تأكد من عدم استخدام المؤشر لأي شيء آخر بعد استدعاء هذه الوظيفة.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME قم بتحديث هذا عند استقرار vec_into_raw_parts.
    ///     // منع إسقاط بيانات السلسلة تلقائيًا
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// يحول vector من البايت إلى `String` دون التحقق من احتواء السلسلة على UTF-8 صالح.
    ///
    /// راجع الإصدار الآمن [`from_utf8`] لمزيد من التفاصيل.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// هذه الوظيفة غير آمنة لأنها لا تتحقق من أن وحدات البايت التي تم تمريرها إليها هي UTF-8 صالحة.
    /// إذا تم انتهاك هذا القيد ، فقد يتسبب ذلك في حدوث مشكلات تتعلق بعدم أمان الذاكرة مع مستخدمي future في `String` ، حيث تفترض بقية المكتبة القياسية أن `String`s صالحة UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// // بعض البايتات في vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// يحول `String` إلى بايت vector.
    ///
    /// هذا يستهلك `String` ، لذلك لا نحتاج إلى نسخ محتوياته.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// يستخرج شريحة سلسلة تحتوي على `String` بالكامل.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// يحول `String` إلى شريحة سلسلة قابلة للتغيير.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// يلحق شريحة سلسلة معينة بنهاية `String`.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// لعرض سعة "السلسلة" بالبايت.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// يضمن أن سعة "السلسلة" هذه أكبر من طولها بمقدار `additional` بايت على الأقل.
    ///
    /// يمكن زيادة السعة بأكثر من `additional` بايت إذا اختارت ، لمنع إعادة التخصيص المتكررة.
    ///
    ///
    /// إذا كنت لا تريد سلوك "at least" هذا ، فراجع طريقة [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics إذا تجاوز السعة الجديدة [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// قد لا يؤدي هذا في الواقع إلى زيادة السعة:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // يبلغ طول s الآن 2 وسعة 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // نظرًا لأن لدينا بالفعل سعة 8 إضافية ، فإن استدعاء هذا ...
    /// s.reserve(8);
    ///
    /// // ... لا تزيد في الواقع.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// يضمن أن سعة "السلسلة" هذه أكبر من طولها بمقدار `additional` بايت.
    ///
    /// ضع في اعتبارك استخدام طريقة [`reserve`] ما لم تكن تعرف تمامًا أفضل من المخصص.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics إذا تجاوزت السعة الجديدة `usize`.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// قد لا يؤدي هذا في الواقع إلى زيادة السعة:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // يبلغ طول s الآن 2 وسعة 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // نظرًا لأن لدينا بالفعل سعة 8 إضافية ، فإن استدعاء هذا ...
    /// s.reserve_exact(8);
    ///
    /// // ... لا تزيد في الواقع.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// يحاول الاحتفاظ بالسعة لما لا يقل عن `additional` من العناصر لإدراجها في `String` المحدد.
    /// قد تحتفظ المجموعة بمساحة أكبر لتجنب إعادة التخصيص المتكررة.
    /// بعد استدعاء `reserve` ، ستكون السعة أكبر من أو تساوي `self.len() + additional`.
    /// لا تفعل شيئًا إذا كانت السعة كافية بالفعل.
    ///
    /// # Errors
    ///
    /// إذا تجاوزت السعة ، أو أبلغ المخصص عن فشل ، فسيتم إرجاع خطأ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // احتفظ مسبقًا بالذاكرة ، واخرج إذا لم نتمكن من ذلك
    ///     output.try_reserve(data.len())?;
    ///
    ///     // الآن نعلم أن هذا لا يمكن أن يكون OOM في منتصف عملنا المعقد
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// يحاول حجز الحد الأدنى من السعة لـ `additional` بالضبط المزيد من العناصر ليتم إدراجها في `String` المحدد.
    ///
    /// بعد استدعاء `reserve_exact` ، ستكون السعة أكبر من أو تساوي `self.len() + additional`.
    /// لا تفعل شيئًا إذا كانت السعة كافية بالفعل.
    ///
    /// لاحظ أن المخصص قد يمنح المجموعة مساحة أكبر مما تطلب.
    /// لذلك ، لا يمكن الاعتماد على السعة لتكون في حدها الأدنى على وجه التحديد.
    /// تفضل `reserve` إذا كان من المتوقع إدخال future.
    ///
    /// # Errors
    ///
    /// إذا تجاوزت السعة ، أو أبلغ المخصص عن فشل ، فسيتم إرجاع خطأ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // احتفظ مسبقًا بالذاكرة ، واخرج إذا لم نتمكن من ذلك
    ///     output.try_reserve(data.len())?;
    ///
    ///     // الآن نعلم أن هذا لا يمكن أن يكون OOM في منتصف عملنا المعقد
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// تقلص سعة `String` لتتناسب مع طولها.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// تقلص سعة `String` بحد أدنى.
    ///
    /// ستظل السعة كبيرة على الأقل مثل الطول والقيمة المقدمة.
    ///
    ///
    /// إذا كانت السعة الحالية أقل من الحد الأدنى ، فهذا أمر محظور.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// يقوم بإلحاق [`char`] المحدد بنهاية `String`.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// إرجاع شريحة بايت لمحتويات `السلسلة`.
    ///
    /// معكوس هذه الطريقة هو [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// يقصر `String` هذا إلى الطول المحدد.
    ///
    /// إذا كان `new_len` أكبر من الطول الحالي للسلسلة ، فلن يكون لذلك أي تأثير.
    ///
    ///
    /// لاحظ أن هذه الطريقة ليس لها أي تأثير على السعة المخصصة للسلسلة
    ///
    /// # Panics
    ///
    /// Panics إذا كان `new_len` لا يقع على حدود [`char`].
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// يزيل الحرف الأخير من المخزن المؤقت للسلسلة ويعيده.
    ///
    /// تُرجع [`None`] إذا كان `String` فارغًا.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// يزيل [`char`] من `String` هذا عند موضع بايت ويعيده.
    ///
    /// هذه عملية *O*(*n*) ، لأنها تتطلب نسخ كل عنصر في المخزن المؤقت.
    ///
    /// # Panics
    ///
    /// Panics إذا كان `idx` أكبر من أو يساوي طول "السلسلة" ، أو إذا كان لا يقع على حد [`char`].
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// قم بإزالة جميع مباريات النمط `pat` في `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// سيتم الكشف عن التطابقات وإزالتها بشكل متكرر ، لذلك في الحالات التي تتداخل فيها الأنماط ، ستتم إزالة النمط الأول فقط:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // الأمان: ستكون البداية والنهاية على حدود utf8 بايت لكل
        // الباحث في المستندات
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// يحتفظ فقط بالأحرف المحددة بواسطة المسند.
    ///
    /// بمعنى آخر ، قم بإزالة كافة الأحرف `c` بحيث تقوم `f(c)` بإرجاع `false`.
    /// تعمل هذه الطريقة في مكانها ، حيث تزور كل حرف مرة واحدة بالضبط بالترتيب الأصلي ، وتحافظ على ترتيب الأحرف المحتجزة.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// قد يكون الترتيب الدقيق مفيدًا لتتبع الحالة الخارجية ، مثل الفهرس.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // نقطة idx إلى الحرف التالي
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// لإدراج حرف في `String` هذا في موضع بايت.
    ///
    /// هذه عملية *O*(*n*) لأنها تتطلب نسخ كل عنصر في المخزن المؤقت.
    ///
    /// # Panics
    ///
    /// Panics إذا كان `idx` أكبر من طول "السلسلة" ، أو إذا كان لا يقع على حدود [`char`].
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// يُدرج شريحة سلسلة في `String` هذا عند موضع بايت.
    ///
    /// هذه عملية *O*(*n*) لأنها تتطلب نسخ كل عنصر في المخزن المؤقت.
    ///
    /// # Panics
    ///
    /// Panics إذا كان `idx` أكبر من طول "السلسلة" ، أو إذا كان لا يقع على حدود [`char`].
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// إرجاع مرجع متغير لمحتويات `String`.
    ///
    /// # Safety
    ///
    /// هذه الوظيفة غير آمنة لأنها لا تتحقق من أن وحدات البايت التي تم تمريرها إليها هي UTF-8 صالحة.
    /// إذا تم انتهاك هذا القيد ، فقد يتسبب ذلك في حدوث مشكلات تتعلق بعدم أمان الذاكرة مع مستخدمي future في `String` ، حيث تفترض بقية المكتبة القياسية أن `String`s صالحة UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// لعرض طول `String` بالبايت وليس [`char`] أو حروف الحروف.
    /// بمعنى آخر ، قد لا يكون طول الوتر هو ما يعتبره الإنسان.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// تُرجع `true` إذا كان طول `String` هذا يساوي صفرًا و `false` بخلاف ذلك.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// يقسم السلسلة إلى قسمين عند فهرس البايت المحدد.
    ///
    /// إرجاع `String` المخصصة حديثًا.
    /// `self` يحتوي على بايت `[0, at)` ، ويحتوي `String` الذي تم إرجاعه على بايت `[at, len)`.
    /// `at` يجب أن يكون على حدود نقطة رمز UTF-8.
    ///
    /// لاحظ أن سعة `self` لا تتغير.
    ///
    /// # Panics
    ///
    /// Panics إذا لم يكن `at` على حدود نقطة رمز `UTF-8` ، أو إذا كان خارج آخر نقطة رمز من السلسلة.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// يقطع `String` هذا ويزيل كافة المحتويات.
    ///
    /// في حين أن هذا يعني أن `String` سيبلغ طوله صفرًا ، إلا أنه لا يمس سعته.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// ينشئ مكرر استنزاف يزيل النطاق المحدد في `String` وينتج `chars` الذي تمت إزالته.
    ///
    ///
    /// Note: تتم إزالة نطاق العناصر حتى إذا لم يتم استهلاك المكرر حتى النهاية.
    ///
    /// # Panics
    ///
    /// Panics إذا كانت نقطة البداية أو نقطة النهاية لا تقع على حدود [`char`] ، أو إذا كانت خارج الحدود.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // قم بإزالة النطاق لأعلى حتى β من السلسلة
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // المدى الكامل يزيل السلسلة
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // سلامة الذاكرة
        //
        // لا يحتوي إصدار String من Drain على مشكلات أمان الذاكرة الخاصة بإصدار vector.
        // البيانات مجرد بايت.
        // نظرًا لأن إزالة النطاق تحدث في Drop ، إذا تم تسريب مكرر Drain ، فلن تحدث الإزالة.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // خذ اقتراضين متزامنين.
        // لن يتم الوصول إلى سلسلة &mut حتى ينتهي التكرار ، في Drop.
        let self_ptr = self as *mut _;
        // الأمان: يقوم `slice::range` و `is_char_boundary` بإجراء فحوصات الحدود المناسبة.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// يزيل النطاق المحدد في السلسلة ، ويستبدلها بالسلسلة المحددة.
    /// لا يلزم أن تكون السلسلة المحددة بنفس طول النطاق.
    ///
    /// # Panics
    ///
    /// Panics إذا كانت نقطة البداية أو نقطة النهاية لا تقع على حدود [`char`] ، أو إذا كانت خارج الحدود.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // استبدل النطاق لأعلى حتى β من السلسلة
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // سلامة الذاكرة
        //
        // لا يحتوي Replace_range على مشكلات أمان الذاكرة الخاصة بـ vector Splice.
        // من إصدار vector.البيانات مجرد بايت.

        // تحذير: قد يكون تضمين هذا المتغير غير سليم (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // تحذير: قد يكون تضمين هذا المتغير غير سليم (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // استخدام `range` مرة أخرى سيكون غير سليم (#81138) نفترض أن الحدود التي أبلغ عنها `range` تظل كما هي ، ولكن يمكن أن يتغير التنفيذ العدائي بين المكالمات
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// يحول `String` هذا إلى [`Box`]`<`[`str`] `>`.
    ///
    /// سيؤدي هذا إلى إسقاط أي سعة فائضة.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// لعرض شريحة من [`u8`] بايت تمت محاولة تحويلها إلى `String`.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// // بعض البايتات غير الصالحة في vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// إرجاع وحدات البايت التي تمت محاولة تحويلها إلى `String`.
    ///
    /// تم تصميم هذه الطريقة بعناية لتجنب التخصيص.
    /// سوف يستهلك الخطأ ، ويخرج البايت ، بحيث لا يلزم عمل نسخة من البايت.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// // بعض البايتات غير الصالحة في vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// قم بإحضار `Utf8Error` للحصول على مزيد من التفاصيل حول فشل التحويل.
    ///
    /// يمثل النوع [`Utf8Error`] المقدم من [`std::str`] خطأ قد يحدث عند تحويل شريحة من [`u8`] s إلى [`&str`].
    /// بهذا المعنى ، إنه تناظرية لـ `FromUtf8Error`.
    /// انظر وثائقه لمزيد من التفاصيل حول استخدامه.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// // بعض البايتات غير الصالحة في vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // البايت الأول غير صالح هنا
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // نظرًا لأننا نكرر عملية `String`s ، يمكننا تجنب تخصيص واحد على الأقل عن طريق الحصول على السلسلة الأولى من المكرر وإلحاق جميع السلاسل اللاحقة بها.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // نظرًا لأننا نقوم بالتكرار على CoWs ، يمكننا (potentially) تجنب تخصيص واحد على الأقل عن طريق الحصول على العنصر الأول وإلحاق جميع العناصر اللاحقة به.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// من الملاءمة أن المفوضين إلى الضمانات لـ `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// ينشئ `String` فارغًا.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// ينفذ عامل التشغيل `+` لسلسلة سلسلتين.
///
/// هذا يستهلك `String` على الجانب الأيسر ويعيد استخدام المخزن المؤقت الخاص به (ينمو إذا لزم الأمر).
/// يتم ذلك لتجنب تخصيص `String` جديد ونسخ المحتويات بالكامل في كل عملية ، مما يؤدي إلى *O*(*n*^ 2) وقت التشغيل عند إنشاء سلسلة *n* بايت عن طريق التسلسل المتكرر.
///
///
/// يتم استعارة الخيط الموجود على الجانب الأيمن فقط ؛يتم نسخ محتوياته إلى `String` الذي تم إرجاعه.
///
/// # Examples
///
/// تأخذ سلسلة `String`s الأولى من حيث القيمة وتستعير الثانية:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` تم نقله ولم يعد من الممكن استخدامه هنا.
/// ```
///
/// إذا كنت ترغب في الاستمرار في استخدام `String` الأول ، فيمكنك استنساخه وإلحاقه بالنسخة بدلاً من ذلك:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` لا يزال ساريًا هنا.
/// ```
///
/// يمكن إجراء تسلسل شرائح `&str` عن طريق تحويل الأول إلى `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// ينفذ عامل التشغيل `+=` للإلحاق بـ `String`.
///
/// هذا له نفس سلوك أسلوب [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// نوع مستعار لـ [`Infallible`].
///
/// هذا الاسم المستعار موجود للتوافق مع الإصدارات السابقة ، وقد يتم إهماله في النهاية.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// trait لتحويل قيمة إلى `String`.
///
/// يتم تنفيذ trait تلقائيًا لأي نوع يستخدم [`Display`] trait.
/// على هذا النحو ، لا ينبغي تنفيذ `ToString` مباشرة:
/// [`Display`] يجب أن يتم تنفيذه بدلاً من ذلك ، وستحصل على تطبيق `ToString` مجانًا.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// تحويل القيمة المحددة إلى `String`.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// في هذا التطبيق ، طريقة `to_string` panics إذا قام تطبيق `Display` بإرجاع خطأ.
/// يشير هذا إلى تطبيق `Display` غير صحيح لأن `fmt::Write for String` لا يُرجع خطأ بحد ذاته.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // المبدأ التوجيهي الشائع هو عدم تضمين الوظائف العامة.
    // ومع ذلك ، تؤدي إزالة `#[inline]` من هذه الطريقة إلى حدوث انحدارات غير مهمة.
    // انظر <https://github.com/rust-lang/rust/pull/74852> ، المحاولة الأخيرة لإزالته.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// يحول `&mut str` إلى `String`.
    ///
    /// يتم تخصيص النتيجة على الكومة.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: يسحب الاختبار في libstd ، مما يتسبب في حدوث أخطاء هنا
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// تحويل شريحة `str` المعطاة إلى `String`.
    /// من الجدير بالذكر أن شريحة `str` مملوكة.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// يحول `String` المعطى إلى شريحة `str` محاصر مملوكة.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// يحول شريحة سلسلة إلى متغير مقترض.
    /// لا يتم إجراء تخصيص كومة ، ولا يتم نسخ السلسلة.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// يحول سلسلة إلى متغير مملوك.
    /// لا يتم إجراء تخصيص كومة ، ولا يتم نسخ السلسلة.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// يحول مرجع سلسلة إلى متغير مستعار.
    /// لا يتم إجراء تخصيص كومة ، ولا يتم نسخ السلسلة.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// يحول `String` المعطى إلى vector `Vec` الذي يحتفظ بقيم من النوع `u8`.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// مكرر تجفيف لـ `String`.
///
/// تم إنشاء هذا الهيكل بطريقة [`drain`] على [`String`].
/// انظر وثائقها للمزيد.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// سيتم استخدامها كـ&'سلسلة متغيرة في أداة التدمير
    string: *mut String,
    /// بداية الجزء المراد إزالته
    start: usize,
    /// نهاية الجزء المراد إزالته
    end: usize,
    /// النطاق الحالي المتبقي المطلوب إزالته
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // استخدم Vec::drain.
            // "Reaffirm" يتحقق الحدود لتجنب إدخال رمز panic مرة أخرى.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// تُرجع السلسلة (الفرعية) المتبقية من هذا المكرر على هيئة شريحة.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: uncomment AsRef يشير أدناه عند الاستقرار.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// أزل التعليق عند تثبيت `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// ضمني <'a> AsRef<str>لـ Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> لـ Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}