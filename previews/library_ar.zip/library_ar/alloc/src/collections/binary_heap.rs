//! تم تطبيق قائمة انتظار ذات أولوية باستخدام كومة ثنائية.
//!
//! إدخال وتفرقع أكبر عنصر له تعقيد زمني *O*(log(*n*)).
//! فحص العنصر الأكبر هو *O*(1).يمكن أن يتم تحويل vector إلى كومة ثنائية في المكان ، وله تعقيد *O*(*n*).
//! يمكن أيضًا تحويل الكومة الثنائية إلى vector تم فرزه في المكان ، مما يسمح باستخدامه لفرز *O*(*n*\*log(* n*)) في المكان.
//!
//! # Examples
//!
//! هذا مثال أكبر يقوم بتنفيذ [Dijkstra's algorithm][dijkstra] لحل [shortest path problem][sssp] على [directed graph][dir_graph].
//!
//! يوضح كيفية استخدام [`BinaryHeap`] مع الأنواع المخصصة.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // قائمة انتظار الأولوية تعتمد على `Ord`.
//! // قم بتنفيذ trait بشكل صريح بحيث تصبح قائمة الانتظار min-heap بدلاً من max-heap.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // لاحظ أننا نقلب الطلب على التكاليف.
//!         // في حالة التعادل نقارن المواقف ، هذه الخطوة ضرورية لجعل تطبيقات `PartialEq` و `Ord` متسقة.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` يحتاج إلى تنفيذه كذلك.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // يتم تمثيل كل عقدة على أنها `usize` ، لتنفيذ أقصر.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // أقصر خوارزمية مسار Dijkstra.
//!
//! // ابدأ من `start` واستخدم `dist` لتتبع أقصر مسافة حالية لكل عقدة.هذا التنفيذ ليس فعالًا في الذاكرة لأنه قد يترك عقدًا مكررة في قائمة الانتظار.
//! //
//! // كما أنه يستخدم `usize::MAX` كقيمة خفر ، من أجل تنفيذ أبسط.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [عقدة]=أقصر مسافة حالية من `start` إلى `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // نحن في `start` ، بدون تكلفة
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // افحص الحدود ذات العقد الأقل تكلفة أولاً (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // بدلاً من ذلك ، كان بإمكاننا الاستمرار في العثور على أقصر الطرق
//!         if position == goal { return Some(cost); }
//!
//!         // مهم لأننا وجدنا بالفعل طريقة أفضل
//!         if cost > dist[position] { continue; }
//!
//!         // لكل عقدة يمكننا الوصول إليها ، تحقق مما إذا كان بإمكاننا إيجاد طريقة بتكلفة أقل تمر عبر هذه العقدة
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // إذا كان الأمر كذلك ، فقم بإضافته إلى الحدود واستمر
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // الاسترخاء ، وجدنا الآن طريقة أفضل
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // الهدف غير قابل للوصول
//!     None
//! }
//!
//! fn main() {
//!     // هذا هو الرسم البياني الموجه الذي سنستخدمه.
//!     // تتوافق أرقام العقد مع الحالات المختلفة ، وترمز أوزان edge إلى تكلفة الانتقال من عقدة إلى أخرى.
//!     //
//!     // لاحظ أن الحواف أحادية الاتجاه.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          الخامس 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // يتم تمثيل الرسم البياني كقائمة مجاورة حيث يحتوي كل فهرس ، المقابل لقيمة عقدة ، على قائمة من الحواف الصادرة.
//!     // تم اختيارها لكفاءتها.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // العقدة 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // العقدة 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // العقدة 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // العقدة 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // العقدة 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// تم تطبيق قائمة انتظار ذات أولوية باستخدام كومة ثنائية.
///
/// سيكون هذا كومة قصوى.
///
/// يعد تعديل عنصر ما خطأ منطقيًا بحيث يتغير ترتيب العنصر بالنسبة إلى أي عنصر آخر ، كما هو محدد بواسطة `Ord` trait ، أثناء وجوده في الكومة.
///
/// عادةً ما يكون هذا ممكنًا فقط من خلال `Cell` أو `RefCell` أو الحالة العالمية أو I/O أو رمز غير آمن.
/// لم يتم تحديد السلوك الناتج عن مثل هذا الخطأ المنطقي ، ولكنه لن يؤدي إلى سلوك غير محدد.
/// قد يشمل ذلك panics ، والنتائج غير الصحيحة ، والإحباط ، وتسرب الذاكرة ، وعدم الإنهاء.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // يتيح لنا الاستدلال بالنوع حذف توقيع كتابة صريح (والذي سيكون `BinaryHeap<i32>` في هذا المثال).
/////
/// let mut heap = BinaryHeap::new();
///
/// // يمكننا استخدام نظرة خاطفة لإلقاء نظرة على العنصر التالي في الكومة.
/// // في هذه الحالة ، لا توجد عناصر هناك حتى الآن ، لذا نحصل على لا شيء.
/// assert_eq!(heap.peek(), None);
///
/// // دعونا نضيف بعض الدرجات ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // الآن نظرة خاطفة تظهر العنصر الأكثر أهمية في الكومة.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // يمكننا التحقق من طول الكومة.
/// assert_eq!(heap.len(), 3);
///
/// // يمكننا تكرار العناصر الموجودة في الكومة ، على الرغم من إعادتها بترتيب عشوائي.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // إذا قمنا بدلاً من ذلك بتحقيق هذه النتائج ، فيجب أن تعود بالترتيب.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // يمكننا مسح كومة أي عناصر متبقية.
/// heap.clear();
///
/// // يجب أن تكون الكومة فارغة الآن.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// يمكن استخدام تنفيذ `std::cmp::Reverse` أو `Ord` المخصص لجعل `BinaryHeap` كومة دقيقة.
/// هذا يجعل `heap.pop()` ترجع أصغر قيمة بدلاً من أكبر قيمة.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // قيم التفاف في `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // إذا حققنا هذه النتائج الآن ، فيجب أن تعود بالترتيب العكسي.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # تعقيد الوقت
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// قيمة `push` هي تكلفة متوقعة ؛يعطي توثيق الطريقة تحليلاً أكثر تفصيلاً.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// هيكل التفاف مرجع متغير لأكبر عنصر في `BinaryHeap`.
///
///
/// تم إنشاء هذا `struct` بطريقة [`peek_mut`] على [`BinaryHeap`].
/// انظر وثائقها للمزيد.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // الأمان: يتم إنشاء مثيل PeekMut فقط للأكوام غير الفارغة.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // آمن: يتم إنشاء مثيل PeekMut فقط للأكوام غير الفارغة
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // آمن: يتم إنشاء مثيل PeekMut فقط للأكوام غير الفارغة
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// يزيل القيمة المطلقة من الكومة ويعيدها.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// ينشئ `BinaryHeap<T>` فارغًا.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// ينشئ `BinaryHeap` فارغًا كحد أقصى كومة.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// ينشئ `BinaryHeap` فارغًا بسعة محددة.
    /// يقوم هذا مسبقًا بتخصيص ذاكرة كافية لعناصر `capacity` ، بحيث لا يلزم إعادة تخصيص `BinaryHeap` حتى يحتوي على العديد من القيم على الأقل.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// إرجاع مرجع قابل للتغيير إلى أكبر عنصر في الكومة الثنائية ، أو `None` إذا كان فارغًا.
    ///
    /// Note: إذا تم تسريب قيمة `PeekMut` ، فقد تكون الكومة في حالة غير متناسقة.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # تعقيد الوقت
    ///
    /// إذا تم تعديل العنصر ، فإن أسوأ تعقيد زمني للحالة هو *O*(log(*n*)) ، وإلا فهو *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// يزيل أكبر عنصر من الكومة الثنائية ويعيده ، أو `None` إذا كان فارغًا.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # تعقيد الوقت
    ///
    /// أسوأ تكلفة حالة لـ `pop` على كومة تحتوي على عناصر *n* هي *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // الأمان: !self.is_empty() يعني أن self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// يدفع عنصرًا إلى الكومة الثنائية.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # تعقيد الوقت
    ///
    /// التكلفة المتوقعة لـ `push` ، بمتوسط كل ترتيب محتمل للعناصر التي يتم دفعها ، وعلى عدد كبير من الدفعات ، هي *O*(1).
    ///
    /// هذا هو مقياس التكلفة الأكثر أهمية عند دفع العناصر التي *ليست* موجودة بالفعل في أي نمط تم فرزه.
    ///
    /// يتحلل تعقيد الوقت إذا تم دفع العناصر بترتيب تصاعدي في الغالب.
    /// في أسوأ الحالات ، يتم دفع العناصر بترتيب فرز تصاعدي وتكون التكلفة المطفأة لكل دفعة *O*(log(*n*)) مقابل كومة تحتوي على عناصر *n*.
    ///
    /// أسوأ تكلفة مكالمة *فردية* إلى `push` هي *O*(*n*).تحدث أسوأ حالة عند استنفاد السعة وتحتاج إلى تغيير الحجم.
    /// تم إطفاء تكلفة تغيير الحجم في الأرقام السابقة.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // الأمان: نظرًا لأننا دفعنا عنصرًا جديدًا ، فهذا يعني ذلك
        //  old_len= self.len() ، 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// تستهلك `BinaryHeap` وترجع vector بترتيب (ascending) مفروز.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // الأمان: ينتقل `end` من `self.len() - 1` إلى 1 (كلاهما مضمن) ،
            //  لذلك فهو دائمًا فهرس صالح للوصول إليه.
            //  من الآمن الوصول إلى الفهرس 0 (أي `ptr`) ، لأن
            //  1 <=end <self.len() ، مما يعني self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // الأمان: ينتقل `end` من `self.len() - 1` إلى 1 (كلاهما مضمن) لذلك:
            //  0 <1 <=end <= self.len()، 1 <self.len() مما يعني 0 <نهاية ونهاية <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // تستخدم تطبيقات sift_up و sift_down كتل غير آمنة من أجل تحريك عنصر خارج vector (تاركًا وراءه ثقبًا) ، والتحول على طول العناصر الأخرى ونقل العنصر الذي تمت إزالته مرة أخرى إلى vector في الموقع النهائي للفتحة.
    //
    // يتم استخدام نوع `Hole` لتمثيل هذا ، والتأكد من ملء الفتحة مرة أخرى في نهاية نطاقها ، حتى على panic.
    // يؤدي استخدام الثقب إلى تقليل العامل الثابت مقارنة باستخدام المقايضات ، والتي تتضمن ضعف عدد الحركات.
    //
    //
    //
    //

    /// # Safety
    ///
    /// يجب أن يضمن المتصل أن `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // اخرج القيمة في `pos` وقم بإنشاء ثقب.
        // الأمان: يضمن المتصل أن الموضع <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // الأمان: hole.pos()> بدء>=0 ، مما يعني hole.pos()> 0
            //  وهكذا لا يمكن لـ hole.pos() ، 1 أن يتدفق.
            //  هذا يضمن أن الأصل <hole.pos() لذا فهو فهرس صالح وأيضًا!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // الأمان: نفس ما ورد أعلاه
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// خذ عنصرًا في `pos` وانقله إلى أسفل الكومة ، بينما يكون أطفاله أكبر.
    ///
    ///
    /// # Safety
    ///
    /// يجب أن يضمن المتصل أن `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // الأمان: يضمن المتصل أن الموضع <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // الحلقة الثابتة: الطفل==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // قارن مع أكبر من الطفلين SAFETY: child <end و 1 <self.len() و child + 1 <end <= self.len() ، لذا فهي فهارس صالحة.
            //
            //  طفل==2 *hole.pos() + 1!= hole.pos() والطفل + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 أو 2* hole.pos() + 2 يمكن أن تفيض إذا كان T هو ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // إذا كنا بالفعل في النظام ، توقف.
            // الأمان: أصبح الطفل الآن إما الطفل الأكبر سنًا أو الطفل الأكبر سنًا + 1
            //  لقد أثبتنا بالفعل أن كلاهما <self.len() و!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // الأمان: نفس ما ورد أعلاه.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // الأمان: &&ماس كهربائى ، مما يعني أنه في
        //  الشرط الثاني صحيح بالفعل أن الطفل==النهاية ، 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // الأمان: تم إثبات أن child هو بالفعل فهرس صالح و
            //  طفل==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// يجب أن يضمن المتصل أن `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // الأمان: يتم ضمان نقاط البيع من قبل المتصل و
        //  من الواضح أن len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// خذ عنصرًا في `pos` وحركه على طول الطريق إلى أسفل الكومة ، ثم نخله إلى موضعه.
    ///
    ///
    /// Note: يكون هذا أسرع عندما يكون من المعروف أن العنصر كبير/يجب أن يكون أقرب إلى الأسفل.
    ///
    /// # Safety
    ///
    /// يجب أن يضمن المتصل أن `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // الأمان: يضمن المتصل أن الموضع <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // الحلقة الثابتة: الطفل==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // الأمان: child <end و 1 <self.len() و
            //  child + 1 <end <= self.len() ، لذا فهي فهارس صالحة.
            //  طفل==2 *hole.pos() + 1!= hole.pos() والطفل + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 أو 2* hole.pos() + 2 يمكن أن تفيض إذا كان T هو ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // الأمان: نفس ما ورد أعلاه
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // الأمان: child==end ، 1 <self.len() ، لذا فهو فهرس صالح
            //  والطفل==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // الأمان: الموضع هو الموضع في الحفرة وقد تم إثباته بالفعل
        //  ليكون فهرسًا صالحًا.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // الأمان: يبدأ n من self.len()/2 وينخفض إلى 0.
            //  الحالة الوحيدة عندما! (n <self.len()) هي إذا كانت self.len() ==0 ، لكنها مستبعدة بواسطة شرط الحلقة.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// ينقل جميع عناصر `other` إلى `self` ، ويترك `other` فارغًا.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` يأخذ عمليات O(len1 + len2) وحوالي 2 *(len1 + len2) مقارنات في أسوأ الحالات بينما `extend` يأخذ عمليات O(len2* log(len1)) وحوالي 1 *len2* log_2(len1) مقارنات في أسوأ الحالات ، بافتراض len1>= len2.
        // بالنسبة للأكوام الأكبر ، لم تعد نقطة العبور تتبع هذا المنطق وتم تحديدها تجريبيًا.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// إرجاع مكرر يقوم باسترداد العناصر بترتيب كومة الذاكرة المؤقتة.
    /// تتم إزالة العناصر المستردة من الكومة الأصلية.
    /// ستتم إزالة العناصر المتبقية عند الإسقاط في ترتيب الكومة.
    ///
    /// Note:
    /// * `.drain_sorted()` هو *O*(*n*\*log(* n*)) ؛ أبطأ بكثير من `.drain()`.
    ///   يجب عليك استخدام هذا الأخير في معظم الحالات.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // يزيل كل العناصر في ترتيب الكومة
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// يحتفظ فقط بالعناصر المحددة بواسطة المسند.
    ///
    /// بمعنى آخر ، قم بإزالة كافة العناصر `e` بحيث تقوم `f(&e)` بإرجاع `false`.
    /// تتم زيارة العناصر بترتيب غير مصنف (وغير محدد).
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // فقط احتفظ بالأرقام الزوجية
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// إرجاع مكرر يزور جميع القيم في vector الأساسي ، بترتيب عشوائي.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // اطبع 1 ، 2 ، 3 ، 4 بترتيب تعسفي
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// إرجاع مكرر يقوم باسترداد العناصر بترتيب كومة الذاكرة المؤقتة.
    /// تستهلك هذه الطريقة الكومة الأصلية.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// تُرجع أكبر عنصر في الكومة الثنائية ، أو `None` إذا كانت فارغة.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # تعقيد الوقت
    ///
    /// التكلفة *O*(1) في أسوأ الحالات.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// تُرجع عدد العناصر التي يمكن أن تحتفظ بها الكومة الثنائية بدون إعادة تخصيص.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// يحتفظ بالحد الأدنى من السعة لـ `additional` بالضبط المزيد من العناصر ليتم إدراجها في `BinaryHeap` المحدد.
    /// لا تفعل شيئًا إذا كانت السعة كافية بالفعل.
    ///
    /// لاحظ أن المخصص قد يمنح المجموعة مساحة أكبر مما تطلب.
    /// لذلك لا يمكن الاعتماد على السعة لتكون في حدها الأدنى على وجه التحديد.
    /// تفضل [`reserve`] إذا كان من المتوقع إدخال future.
    ///
    /// # Panics
    ///
    /// Panics إذا تجاوزت السعة الجديدة `usize`.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// يحتفظ بسعة `additional` على الأقل لإدراج المزيد من العناصر في `BinaryHeap`.
    /// قد تحتفظ المجموعة بمساحة أكبر لتجنب إعادة التخصيص المتكررة.
    ///
    /// # Panics
    ///
    /// Panics إذا تجاوزت السعة الجديدة `usize`.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// يتجاهل أكبر قدر ممكن من السعة الإضافية.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// يتجاهل السعة بحد أدنى.
    ///
    /// ستظل السعة كبيرة على الأقل مثل الطول والقيمة المقدمة.
    ///
    ///
    /// إذا كانت السعة الحالية أقل من الحد الأدنى ، فهذا أمر محظور.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// تستهلك `BinaryHeap` وترجع vector الأساسي بترتيب عشوائي.
    ///
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // سوف تطبع في بعض الترتيب
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// تُرجع طول الكومة الثنائية.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// للتحقق مما إذا كانت الكومة الثنائية فارغة.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// يمسح الكومة الثنائية ، ويعيد مكررًا على العناصر التي تمت إزالتها.
    ///
    /// تتم إزالة العناصر بترتيب تعسفي.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// يسقط كل العناصر من الكومة الثنائية.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// يمثل الثقب ثقبًا في شريحة أي فهرس بدون قيمة صالحة (لأنه تم نقله أو تكراره).
///
/// في حالة الإفلات ، سيستعيد `Hole` الشريحة عن طريق ملء موضع الفتحة بالقيمة التي تمت إزالتها في الأصل.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// قم بإنشاء `Hole` جديد في الفهرس `pos`.
    ///
    /// غير آمن لأن نقاط البيع يجب أن تكون ضمن شريحة البيانات.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // آمن: يجب أن يكون نقاط البيع داخل الشريحة
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// إرجاع مرجع للعنصر الذي تمت إزالته.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// إرجاع مرجع للعنصر عند `index`.
    ///
    /// غير آمن لأن الفهرس يجب أن يكون ضمن شريحة البيانات ولا يساوي نقاط البيع.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// انقل الفتحة إلى مكان جديد
    ///
    /// غير آمن لأن الفهرس يجب أن يكون ضمن شريحة البيانات ولا يساوي نقاط البيع.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // املأ الحفرة مرة أخرى
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// مكرر فوق عناصر `BinaryHeap`.
///
/// تم إنشاء هذا `struct` بواسطة [`BinaryHeap::iter()`].
/// انظر وثائقها للمزيد.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) إزالة لصالح `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// مكرر امتلاك فوق عناصر `BinaryHeap`.
///
/// تم إنشاء `struct` بواسطة [`BinaryHeap::into_iter()`] (المقدمة بواسطة `IntoIterator` trait).
/// انظر وثائقها للمزيد.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// مكرر تصريف فوق عناصر `BinaryHeap`.
///
/// تم إنشاء هذا `struct` بواسطة [`BinaryHeap::drain()`].
/// انظر وثائقها للمزيد.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// مكرر تصريف فوق عناصر `BinaryHeap`.
///
/// تم إنشاء هذا `struct` بواسطة [`BinaryHeap::drain_sorted()`].
/// انظر وثائقها للمزيد.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// يزيل عناصر الكومة في ترتيب الكومة.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// يحول `Vec<T>` إلى `BinaryHeap<T>`.
    ///
    /// يحدث هذا التحويل في مكانه ، وله تعقيد زمني *O*(*n*).
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// يحول `BinaryHeap<T>` إلى `Vec<T>`.
    ///
    /// لا يتطلب هذا التحويل نقل البيانات أو تخصيصها ، وله تعقيد زمني ثابت.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// ينشئ مكررًا مستهلكًا ، أي واحدًا ينقل كل قيمة من الكومة الثنائية بترتيب عشوائي.
    /// لا يمكن استخدام الكومة الثنائية بعد استدعاء هذا.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // اطبع 1 ، 2 ، 3 ، 4 بترتيب تعسفي
    /// for x in heap.into_iter() {
    ///     // x من النوع i32 ، وليس &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}