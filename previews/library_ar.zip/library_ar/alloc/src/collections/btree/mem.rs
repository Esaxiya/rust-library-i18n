use core::intrinsics;
use core::mem;
use core::ptr;

/// هذا يستبدل القيمة الكامنة وراء المرجع الفريد `v` عن طريق استدعاء الوظيفة ذات الصلة.
///
///
/// إذا حدث panic في إغلاق `change` ، فسيتم إحباط العملية بأكملها.
#[allow(dead_code)] // احتفظ بها كتوضيح ولاستخدام future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// يستبدل هذا القيمة الكامنة وراء المرجع الفريد `v` عن طريق استدعاء الوظيفة ذات الصلة ، وإرجاع النتيجة التي تم الحصول عليها على طول الطريق.
///
///
/// إذا حدث panic في إغلاق `change` ، فسيتم إحباط العملية بأكملها.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}