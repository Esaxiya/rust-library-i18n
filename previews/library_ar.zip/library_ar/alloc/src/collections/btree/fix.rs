use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// يخزن ربما عقدة ناقصة عن طريق الاندماج أو السرقة من الأخ.
    /// إذا كانت ناجحة ولكن على حساب تقلص العقدة الأصلية ، يتم إرجاع تلك العقدة الأصل المنكمشة.
    /// تُرجع `Err` إذا كانت العقدة جذرًا فارغًا.
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// يخزن ربما عقدة ناقصة ، وإذا تسبب ذلك في تقلص العقدة الأصلية ، فقم بتخزين الأصل ، بشكل متكرر.
    /// تُرجع `true` إذا أصلحت الشجرة ، `false` إذا لم تستطع لأن عقدة الجذر أصبحت فارغة.
    ///
    /// لا تتوقع هذه الطريقة أن يكون الأسلاف بالفعل غير مكتمل عند الدخول و panics إذا واجه سلفًا فارغًا.
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// يزيل المستويات الفارغة في الأعلى ، لكنه يحتفظ بورقة فارغة إذا كانت الشجرة بأكملها فارغة.
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// يخزن أو يدمج أي عقد ناقصة على الحد الأيمن للشجرة.
    /// العقد الأخرى ، تلك التي لا تمثل الجذر ولا edge في أقصى اليمين ، يجب أن تحتوي بالفعل على MIN_LEN من العناصر على الأقل.
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// استنساخ متماثل لـ `fix_right_border`.
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// قم بتخزين أي عقد غير كاملة على الحد الأيمن للشجرة.
    /// يجب أن تكون العقد الأخرى ، التي لا تمثل الجذر ولا تمثل edge في أقصى اليمين ، على استعداد لسرقة ما يصل إلى MIN_LEN من العناصر.
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // تحقق مما إذا كان الطفل الأكثر حقًا غير كامل.
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // نحن بحاجة للسرقة.
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // اذهب إلى أسفل أكثر.
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// يخزن الطفل الأيسر ، بافتراض أن الطفل المناسب ليس كاملاً ، ويوفر عنصرًا إضافيًا للسماح بدمج أطفاله بدوره دون أن يصبح غير مكتمل.
    ///
    /// إرجاع الطفل الأيسر.
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` لتجنب إعادة الضبط إذا حدث الدمج في المستوى التالي.
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// يخزن الطفل الأيمن ، بافتراض أن الطفل الأيسر ليس كاملاً ، ويوفر عنصرًا إضافيًا للسماح بدمج أطفاله بدوره دون أن يصبح غير مكتمل.
    ///
    /// يعود حيثما انتهى الأمر بالطفل المناسب.
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` لتجنب إعادة الضبط إذا حدث الدمج في المستوى التالي.
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}