use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// يأخذ مؤقتًا مكافئًا آخر غير قابل للتغيير من نفس النطاق.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// يبحث عن حواف الأوراق المميزة التي تحدد نطاقًا محددًا في شجرة.
    /// تُرجع إما زوج من المقابض المختلفة إلى نفس الشجرة أو زوج من الخيارات الفارغة.
    ///
    /// # Safety
    ///
    /// ما لم يكن `BorrowType` هو `Immut` ، لا تستخدم المقابض المكررة لزيارة نفس KV مرتين.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// يكافئ `(root1.first_leaf_edge() و root2.last_leaf_edge())` ولكنه أكثر كفاءة.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// يبحث عن زوج من حواف الأوراق التي تحدد نطاقًا معينًا في شجرة.
    ///
    /// تكون النتيجة ذات معنى فقط إذا تم ترتيب الشجرة حسب المفتاح ، مثل الشجرة في `BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // الأمان: نوع الاستعارة الخاص بنا غير قابل للتغيير.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// يبحث عن زوج من حواف الأوراق التي تحدد شجرة بأكملها.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// يقسم مرجعًا فريدًا إلى زوج من حواف الأوراق لتحديد نطاق محدد.
    /// والنتيجة هي مراجع غير فريدة تسمح بطفرة (some) ، والتي يجب استخدامها بعناية.
    ///
    /// تكون النتيجة ذات معنى فقط إذا تم ترتيب الشجرة حسب المفتاح ، مثل الشجرة في `BTreeMap`.
    ///
    ///
    /// # Safety
    /// لا تستخدم المقابض المكررة لزيارة نفس KV مرتين.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// يقسم مرجعًا فريدًا إلى زوج من حواف الأوراق لتحديد النطاق الكامل للشجرة.
    /// النتائج مراجع غير فريدة تسمح بالتحول (للقيم فقط) ، لذا يجب استخدامها بحذر.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // نحن نكرر NodeRef الجذر هنا-لن نزور نفس KV مرتين ، ولن ينتهي بنا الأمر بتداخل مراجع القيم.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// يقسم مرجعًا فريدًا إلى زوج من حواف الأوراق لتحديد النطاق الكامل للشجرة.
    /// النتائج مراجع غير فريدة تسمح بطفرة مدمرة على نطاق واسع ، لذلك يجب استخدامها بعناية فائقة.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // نحن نكرر NodeRef الجذر هنا-لن نصل إليه أبدًا بطريقة تتداخل مع المراجع التي تم الحصول عليها من الجذر.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// بالنظر إلى مقبض الورقة edge ، يتم إرجاع [`Result::Ok`] بمقبض إلى KV المجاور على الجانب الأيمن ، والذي يكون إما في نفس العقدة الطرفية أو في عقدة سلف.
    ///
    /// إذا كانت الورقة edge هي الأخيرة في الشجرة ، يتم إرجاع [`Result::Err`] مع عقدة الجذر.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// بالنظر إلى مقبض الورقة edge ، يتم إرجاع [`Result::Ok`] بمقبض إلى KV المجاور على الجانب الأيسر ، والذي يكون إما في نفس العقدة الطرفية أو في عقدة سلف.
    ///
    /// إذا كانت الورقة edge هي الأولى في الشجرة ، يتم إرجاع [`Result::Err`] مع العقدة الجذرية.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// بالنظر إلى مقبض edge الداخلي ، يتم إرجاع [`Result::Ok`] بمقبض إلى KV المجاور على الجانب الأيمن ، والذي يكون إما في نفس العقدة الداخلية أو في عقدة سلف.
    ///
    /// إذا كان edge الداخلي هو الأخير في الشجرة ، يتم إرجاع [`Result::Err`] مع عقدة الجذر.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// بالنظر إلى مقبض الورقة edge في شجرة محتضرة ، يتم إرجاع الورقة التالية edge على الجانب الأيمن ، وزوج قيمة المفتاح بينهما ، والذي يكون إما في نفس العقدة الورقية ، في عقدة سلف ، أو غير موجود.
    ///
    ///
    /// تقوم هذه الطريقة أيضًا بإلغاء تخصيص أي node(s) تصل إلى نهاية.
    /// هذا يعني أنه في حالة عدم وجود المزيد من أزواج القيمة الرئيسية ، فسيتم إلغاء تخصيص الجزء المتبقي من الشجرة بالكامل ولن يتبقى أي شيء يمكن إرجاعه.
    ///
    /// # Safety
    /// يجب ألا يكون edge قد تم إرجاعه مسبقًا بواسطة النظير `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// بالنظر إلى مقبض الورقة edge في شجرة ميتة ، يتم إرجاع الورقة التالية edge على الجانب الأيسر ، وزوج القيمة الرئيسية بينهما ، والذي يكون إما في نفس العقدة الورقية ، في عقدة سلف ، أو غير موجود.
    ///
    ///
    /// تقوم هذه الطريقة أيضًا بإلغاء تخصيص أي node(s) تصل إلى نهاية.
    /// هذا يعني أنه في حالة عدم وجود المزيد من أزواج القيمة الرئيسية ، فسيتم إلغاء تخصيص الجزء المتبقي من الشجرة بالكامل ولن يتبقى أي شيء يمكن إرجاعه.
    ///
    /// # Safety
    /// يجب ألا يكون edge قد تم إرجاعه مسبقًا بواسطة النظير `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// يخصص كومة من العقد من الورقة حتى الجذر.
    /// هذه هي الطريقة الوحيدة لإلغاء تخصيص ما تبقى من الشجرة بعد أن كان `deallocating_next` و `deallocating_next_back` يقضمان على جانبي الشجرة ، وضربوا نفس edge.
    /// نظرًا لأنه من المفترض أن يتم استدعاؤه فقط عند إرجاع جميع المفاتيح والقيم ، فلا يتم إجراء أي تنظيف على أي من المفاتيح أو القيم.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ينقل مقبض الطرف edge إلى الورقة التالية edge ويعيد المراجع إلى المفتاح والقيمة الموجودة بينهما.
    ///
    ///
    /// # Safety
    /// يجب أن يكون هناك KV آخر في الاتجاه الذي تم قطعه.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// ينقل مقبض الطرف edge إلى الجزء السابق edge ويعيد المراجع إلى المفتاح والقيمة الموجودة بينهما.
    ///
    ///
    /// # Safety
    /// يجب أن يكون هناك KV آخر في الاتجاه الذي تم قطعه.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ينقل مقبض الطرف edge إلى الورقة التالية edge ويعيد المراجع إلى المفتاح والقيمة الموجودة بينهما.
    ///
    ///
    /// # Safety
    /// يجب أن يكون هناك KV آخر في الاتجاه الذي تم قطعه.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // القيام بهذا الأخير يكون أسرع ، وفقًا للمعايير.
        kv.into_kv_valmut()
    }

    /// ينقل مقبض الطرف edge إلى الجزء السابق ويعيد المراجع إلى المفتاح والقيمة الواقعة بينهما.
    ///
    ///
    /// # Safety
    /// يجب أن يكون هناك KV آخر في الاتجاه الذي تم قطعه.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // القيام بهذا الأخير يكون أسرع ، وفقًا للمعايير.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// ينقل مقبض الورقة edge إلى الورقة التالية edge ويعيد المفتاح والقيمة بينهما ، مع إلغاء تخصيص أي عقدة متخلفة مع ترك edge المقابل في العقدة الأصلية متدلية.
    ///
    /// # Safety
    /// - يجب أن يكون هناك KV آخر في الاتجاه الذي تم قطعه.
    /// - لم يتم إرجاع KV مسبقًا بواسطة النظير `next_back_unchecked` على أي نسخة من المقابض المستخدمة لاجتياز الشجرة.
    ///
    /// الطريقة الآمنة الوحيدة للمضي قدمًا في المقبض المحدث هي مقارنته أو إسقاطه أو استدعاء هذه الطريقة مرة أخرى وفقًا لشروط السلامة الخاصة به أو الاتصال بالنظير `next_back_unchecked` وفقًا لشروط السلامة الخاصة به.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// ينقل مقبض الورقة edge إلى الورقة السابقة edge ويعيد المفتاح والقيمة بينهما ، مع إلغاء تخصيص أي عقدة متخلفة مع ترك edge المقابل في العقدة الأصلية متدلية.
    ///
    /// # Safety
    /// - يجب أن يكون هناك KV آخر في الاتجاه الذي تم قطعه.
    /// - لم يتم إرجاع تلك الورقة edge مسبقًا بواسطة النظير `next_unchecked` على أي نسخة من المقابض المستخدمة لاجتياز الشجرة.
    ///
    /// الطريقة الآمنة الوحيدة للمضي قدمًا في المقبض المحدث هي مقارنته أو إسقاطه أو استدعاء هذه الطريقة مرة أخرى وفقًا لشروط السلامة الخاصة به أو الاتصال بالنظير `next_unchecked` وفقًا لشروط السلامة الخاصة به.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// تُرجع الورقة الموجودة في أقصى اليسار edge في العقدة أو تحتها ، بمعنى آخر ، edge الذي تحتاجه أولاً عند التنقل للأمام (أو أخيرًا عند التنقل للخلف).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// تُرجع الورقة edge الموجودة في أقصى اليمين في العقدة أو تحتها ، بمعنى آخر ، edge الذي تحتاجه أخيرًا عند التنقل للأمام (أو أولاً عند التنقل للخلف).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// يزور العقد الورقية و KVs الداخلية بترتيب المفاتيح التصاعدية ، وكذلك يزور العقد الداخلية ككل بعمق من الدرجة الأولى ، مما يعني أن العقد الداخلية تسبق KVs الفردية وعقدها الفرعية.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// تحسب عدد العناصر في شجرة (فرعية).
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// تُرجع الورقة edge الأقرب إلى KV للتنقل إلى الأمام.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// تُرجع الورقة edge الأقرب إلى KV للتنقل للخلف.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}