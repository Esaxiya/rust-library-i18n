use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// لإلحاق جميع أزواج القيمة الرئيسية من اتحاد مكررين تصاعديين ، مما يؤدي إلى زيادة متغير `length` على طول الطريق.هذا الأخير يجعل من السهل على المتصل تجنب التسرب عند ذعر معالج السقوط.
    ///
    /// إذا أنتج كلا المتكررين نفس المفتاح ، فإن هذه الطريقة تسقط الزوج من المكرر الأيسر وتقوم بإلحاق الزوج من المكرر الأيمن.
    ///
    /// إذا كنت تريد أن ينتهي الأمر بالشجرة بترتيب تصاعدي صارم ، مثل `BTreeMap` ، يجب أن ينتج كلا المتكررين مفاتيح بترتيب تصاعدي صارم ، كل منها أكبر من جميع المفاتيح في الشجرة ، بما في ذلك أي مفاتيح موجودة بالفعل في الشجرة عند الدخول.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // نحن نستعد لدمج `left` و `right` في تسلسل مرتبة في الوقت الخطي.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // في غضون ذلك ، نبني شجرة من التسلسل المصنف في الوقت الخطي.
        self.bulk_push(iter, length)
    }

    /// يدفع جميع أزواج المفتاح والقيمة إلى نهاية الشجرة ، مما يؤدي إلى زيادة متغير `length` على طول الطريق.
    /// هذا الأخير يجعل من السهل على المتصل تجنب التسرب عند ذعر المكرر.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // كرر من خلال جميع أزواج القيمة الرئيسية ، ودفعهم إلى العقد في المستوى الصحيح.
        for (key, value) in iter {
            // حاول دفع زوج المفتاح ذي القيمة إلى العقدة الطرفية الحالية.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // لم يتبق مساحة ، اصعد وادفع هناك.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // وجدت عقدة مع ترك مسافة ، اضغط هنا.
                                open_node = parent;
                                break;
                            } else {
                                // اصعد مرة أخرى.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // نحن في القمة ، وننشئ عقدة جذر جديدة وندفع هناك.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // ادفع زوج القيمة الرئيسية والشجرة الفرعية اليمنى الجديدة.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // إهبطْ إلى أقصى اليمين ثانيةً.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // قم بزيادة الطول مع كل تكرار ، للتأكد من أن الخريطة تسقط العناصر الملحقة حتى في حالة تقدم لوحات المكرر.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// مكرر لدمج تسلسلين مفروزين في تسلسل واحد
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// في حالة تساوي مفتاحين ، يتم إرجاع زوج المفتاح والقيمة من المصدر الصحيح.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}