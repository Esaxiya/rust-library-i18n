//! واجهات برمجة تطبيقات تخصيص الذاكرة

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // هذه هي الرموز السحرية لاستدعاء المخصص العالمي.تقوم rustc بتوليدهم لاستدعاء `__rg_alloc` وما إلى ذلك.
    // إذا كانت هناك سمة `#[global_allocator]` (يولد الكود الذي يوسع ماكرو السمة تلك الوظائف) ، أو لاستدعاء التطبيقات الافتراضية في libstd (`__rdl_alloc` إلخ.
    //
    // في `library/std/src/alloc.rs`) وإلا.
    // rustc fork من LLVM أيضًا حالات خاصة لأسماء الوظائف هذه لتتمكن من تحسينها مثل `malloc` و `realloc` و `free` ، على التوالي.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// مخصص الذاكرة العالمية.
///
/// يقوم هذا النوع بتنفيذ [`Allocator`] trait عن طريق إعادة توجيه المكالمات إلى المخصص المسجل مع السمة `#[global_allocator]` إذا كان هناك واحد ، أو `std` crate الافتراضي.
///
///
/// Note: في حين أن هذا النوع غير مستقر ، يمكن الوصول إلى الوظيفة التي يوفرها من خلال [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// تخصيص الذاكرة مع المخصص العام.
///
/// تقوم هذه الوظيفة بإعادة توجيه المكالمات إلى طريقة [`GlobalAlloc::alloc`] للمخصص المسجل مع السمة `#[global_allocator]` إذا كان هناك واحد ، أو `std` crate الافتراضي.
///
///
/// من المتوقع أن يتم إهمال هذه الوظيفة لصالح طريقة `alloc` من النوع [`Global`] عندما تصبح [`Allocator`] trait مستقرة.
///
/// # Safety
///
/// انظر [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// قم بإلغاء تخصيص الذاكرة باستخدام المُخصص العام.
///
/// تقوم هذه الوظيفة بإعادة توجيه المكالمات إلى طريقة [`GlobalAlloc::dealloc`] للمخصص المسجل مع السمة `#[global_allocator]` إذا كان هناك واحد ، أو `std` crate الافتراضي.
///
///
/// من المتوقع أن يتم إهمال هذه الوظيفة لصالح طريقة `dealloc` من النوع [`Global`] عندما تصبح [`Allocator`] trait مستقرة.
///
/// # Safety
///
/// انظر [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// أعد تخصيص الذاكرة باستخدام المُخصص العام.
///
/// تقوم هذه الوظيفة بإعادة توجيه المكالمات إلى طريقة [`GlobalAlloc::realloc`] للمخصص المسجل مع السمة `#[global_allocator]` إذا كان هناك واحد ، أو `std` crate الافتراضي.
///
///
/// من المتوقع أن يتم إهمال هذه الوظيفة لصالح طريقة `realloc` من النوع [`Global`] عندما تصبح [`Allocator`] trait مستقرة.
///
/// # Safety
///
/// انظر [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// تخصيص الذاكرة الصفرية التهيئة باستخدام المخصص العمومي.
///
/// تقوم هذه الوظيفة بإعادة توجيه المكالمات إلى طريقة [`GlobalAlloc::alloc_zeroed`] للمخصص المسجل مع السمة `#[global_allocator]` إذا كان هناك واحد ، أو `std` crate الافتراضي.
///
///
/// من المتوقع أن يتم إهمال هذه الوظيفة لصالح طريقة `alloc_zeroed` من النوع [`Global`] عندما تصبح [`Allocator`] trait مستقرة.
///
/// # Safety
///
/// انظر [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // الأمان: حجم `layout` غير صفري ،
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // الأمان: مثل `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // الأمان: `new_size` غير صفري لأن `old_size` أكبر من أو يساوي `new_size`
            // كما هو مطلوب بشروط السلامة.الشروط الأخرى يجب أن يلتزم بها المتصل
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` ربما يتحقق من `new_size >= old_layout.size()` أو شيء مشابه.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // الأمان: لأن `new_layout.size()` يجب أن يكون أكبر من أو يساوي `old_size` ،
            // كل من تخصيص الذاكرة القديم والجديد صالح للقراءة والكتابة لـ `old_size` بايت.
            // أيضًا ، نظرًا لأن التخصيص القديم لم يتم إلغاء تخصيصه بعد ، فلا يمكن أن يتداخل مع `new_ptr`.
            // وبالتالي ، فإن الاتصال بـ `copy_nonoverlapping` آمن.
            // يجب أن يتم دعم عقد الأمان الخاص بـ `dealloc` من قبل المتصل.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // الأمان: حجم `layout` غير صفري ،
            // الشروط الأخرى يجب أن يلتزم بها المتصل
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // الأمان: يجب أن يلتزم المتصل بجميع الشروط
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // الأمان: يجب أن يلتزم المتصل بجميع الشروط
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // الأمان: يجب أن يتمسك المتصل بالشروط
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // الأمان: `new_size` غير صفري.الشروط الأخرى يجب أن يلتزم بها المتصل
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` ربما يتحقق من `new_size <= old_layout.size()` أو شيء مشابه.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // الأمان: لأن `new_size` يجب أن يكون أصغر من أو يساوي `old_layout.size()` ،
            // كل من تخصيص الذاكرة القديم والجديد صالح للقراءة والكتابة لـ `new_size` بايت.
            // أيضًا ، نظرًا لأن التخصيص القديم لم يتم إلغاء تخصيصه بعد ، فلا يمكن أن يتداخل مع `new_ptr`.
            // وبالتالي ، فإن الاتصال بـ `copy_nonoverlapping` آمن.
            // يجب أن يتم دعم عقد الأمان الخاص بـ `dealloc` من قبل المتصل.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// مخصص المؤشرات الفريدة.
// هذه الوظيفة يجب ألا تسترخي.إذا حدث ذلك ، فسيفشل برنامج تشفير MIR.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// يجب أن يكون هذا التوقيع هو نفسه `Box` ، وإلا سيحدث ICE.
// عند إضافة معلمة إضافية إلى `Box` (مثل `A: Allocator`) ، يجب إضافة هذا هنا أيضًا.
// على سبيل المثال ، إذا تم تغيير `Box` إلى `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` ، فيجب تغيير هذه الوظيفة إلى `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` أيضًا.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # معالج خطأ التخصيص

extern "Rust" {
    // هذا هو الرمز السحري لاستدعاء معالج خطأ التخصيص العام.
    // يقوم rustc بإنشائه للاتصال بـ `__rg_oom` إذا كان هناك `#[alloc_error_handler]` ، أو للاتصال بالتطبيقات الافتراضية أدناه (`__rdl_oom`) خلاف ذلك.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// إحباط عند تخصيص الذاكرة خطأ أو فشل.
///
/// يتم تشجيع مستدعي واجهات برمجة تطبيقات تخصيص الذاكرة الراغبين في إحباط الحساب استجابةً لخطأ في التخصيص على استدعاء هذه الوظيفة ، بدلاً من استدعاء `panic!` أو ما شابه ذلك مباشرةً.
///
///
/// يتمثل السلوك الافتراضي لهذه الوظيفة في طباعة رسالة إلى الخطأ القياسي وإحباط العملية.
/// يمكن استبداله بـ [`set_alloc_error_hook`] و [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// للتخصيص ، يمكن استخدام اختبار `std::alloc::handle_alloc_error` مباشرة.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // تم استدعاؤه عبر `__rust_alloc_error_handler` الذي تم إنشاؤه

    // إذا لم يكن هناك `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // إذا كان هناك `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// تخصص النسخ في ذاكرة مخصصة مسبقًا وغير مهيأة.
/// تستخدم من قبل `Box::clone` و `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // قد يسمح تخصيص *أولاً* للمحسن بإنشاء القيمة المستنسخة في مكانها ، وتخطي المحلي والتحرك.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // يمكننا دائمًا النسخ في نفس المكان ، دون الحاجة إلى أي قيمة محلية.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}