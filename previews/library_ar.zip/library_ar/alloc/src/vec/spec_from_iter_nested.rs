use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// تخصص آخر trait لـ Vec::from_iter ضروري لتحديد أولويات التخصصات المتداخلة يدويًا ، راجع [`SpecFromIter`](super::SpecFromIter) للحصول على التفاصيل.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // قم بفك التكرار الأول ، حيث سيتم توسيع vector في هذا التكرار في كل حالة عندما لا يكون التكرار فارغًا ، لكن الحلقة في extend_desugared() لن ترى vector ممتلئًا في التكرارات القليلة اللاحقة.
        //
        // لذلك نحصل على تنبؤات branch أفضل.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // يجب أن يفوض إلى spec_extend() لأن extend() نفسه يفوض إلى spec_from من أجل Vecs الفارغة
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // يجب أن يفوض إلى spec_extend() لأن extend() نفسه يفوض إلى spec_from من أجل Vecs الفارغة
        //
        vector.spec_extend(iterator);
        vector
    }
}