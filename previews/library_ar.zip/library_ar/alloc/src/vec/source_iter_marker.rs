use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// علامة التخصص لتجميع خط أنابيب مكرر في Vec أثناء إعادة استخدام تخصيص المصدر ، أي
/// تنفيذ خط الأنابيب في مكانه.
///
/// يعد trait الأصل من SourceIter ضروريًا لوظيفة التخصص للوصول إلى التخصيص الذي سيتم إعادة استخدامه.
/// لكن لا يكفي أن يكون التخصص صحيحًا.
/// انظر الحدود الإضافية على الضمانات.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// يتم تنفيذ SourceIter/InPlaceIterable traits الداخلي std فقط عن طريق سلاسل المحول <Adapter<Adapter<IntoIter>>> (جميعها مملوكة لـ core/std).
// تعتمد الحدود الإضافية على تطبيقات المحول (بعد `impl<I: Trait> Trait for Adapter<I>`) فقط على traits الأخرى التي تم تمييزها بالفعل على أنها تخصص traits (نسخ ، TrustedRandomAccess ، FusedIterator).
//
// I.e. لا تعتمد العلامة على عمر الأنواع التي يوفرها المستخدم.Modulo the Copy hole ، والتي تعتمد عليها بالفعل العديد من التخصصات الأخرى.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // المتطلبات الإضافية التي لا يمكن التعبير عنها عبر trait bounds.نحن نعتمد على قيمة const بدلاً من ذلك:
        // أ) لا توجد ZSTs حيث لن يكون هناك تخصيص لإعادة الاستخدام وسوف يكون حساب المؤشر panic ب) تطابق الحجم كما هو مطلوب في عقد التخصيص ج) تطابق المحاذاة كما هو مطلوب بموجب عقد التخصيص
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // الرجوع إلى عمليات التنفيذ الأكثر عمومية
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // استخدم try-fold منذ ذلك الحين
        // - يتجه بشكل أفضل لبعض محولات المكرر
        // - على عكس معظم طرق التكرار الداخلية ، لا يستغرق الأمر سوى &mut
        // - يتيح لنا تمرير مؤشر الكتابة عبر أحشائه وإعادته في النهاية
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // نجح التكرار ، فلا تسقط رأسك
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // تحقق مما إذا كان عقد SourceIter قد تم تأييده: إذا لم يكن الأمر كذلك ، فقد لا نصل إلى هذه النقطة
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // check InPlace عقد قابل للتغيير.هذا ممكن فقط إذا قدم المكرر مؤشر المصدر على الإطلاق.
        // إذا كان يستخدم وصولاً غير محدد عبر TrustedRandomAccess ، فسيظل مؤشر المصدر في موضعه الأولي ولا يمكننا استخدامه كمرجع
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // قم بإسقاط أي قيم متبقية في ذيل المصدر ولكن منع إسقاط التخصيص نفسه بمجرد خروج IntoIter عن النطاق إذا تم إسقاط panics ثم نقوم أيضًا بتسريب أي عناصر تم جمعها في dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // لا يمكن التحقق من عقد InPlaceIterable هنا على وجه التحديد نظرًا لأن try_fold يحتوي على مرجع حصري لمؤشر المصدر ، كل ما يمكننا فعله هو التحقق مما إذا كان لا يزال في النطاق
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}