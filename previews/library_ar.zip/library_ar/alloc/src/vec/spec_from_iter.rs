use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// تخصص trait المستخدم لـ Vec::from_iter
///
/// ## الرسم البياني التفويض:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // من الحالات الشائعة تمرير vector إلى دالة يتم إعادة تجميعها فورًا في vector.
        // يمكننا قصر هذا إذا لم يتم تطوير IntoIter على الإطلاق.
        // عندما يتم التقدم ، يمكننا أيضًا إعادة استخدام الذاكرة ونقل البيانات إلى المقدمة.
        // لكننا نفعل ذلك فقط عندما لا يكون لدى Vec الناتج سعة غير مستخدمة أكثر من إنشائها من خلال تنفيذ FromIterator العام.
        //
        // هذا القيد ليس ضروريًا تمامًا لأن سلوك تخصيص Vec غير محدد عن قصد.
        // لكنه اختيار محافظ.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // يجب أن يفوض إلى spec_extend() لأن extend() نفسه يفوض إلى spec_from من أجل Vecs الفارغة
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// يستخدم هذا `iterator.as_slice().to_vec()` نظرًا لأن spec_extend يجب أن تتخذ المزيد من الخطوات للتفكير حول السعة النهائية + الطول وبالتالي القيام بالمزيد من العمل.
// `to_vec()` يخصص بشكل مباشر المبلغ الصحيح ويملأه بالضبط.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): مع cfg(test) ، طريقة `[T]::to_vec` المتأصلة ، المطلوبة لتعريف الأسلوب هذا ، غير متوفرة.
    // بدلاً من ذلك ، استخدم وظيفة `slice::to_vec` المتوفرة فقط مع cfg(test) NB ، راجع الوحدة النمطية slice::hack في slice.rs لمزيد من المعلومات
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}