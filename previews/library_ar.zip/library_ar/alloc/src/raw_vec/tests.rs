use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // تعد كتابة اختبار للتكامل بين مخصصات الجهات الخارجية و `RawVec` أمرًا صعبًا بعض الشيء لأن واجهة برمجة تطبيقات `RawVec` لا تكشف طرق تخصيص غير معصومة ، لذلك لا يمكننا التحقق مما يحدث عند استنفاد المخصص (بعد اكتشاف panic).
    //
    //
    // بدلاً من ذلك ، يتحقق هذا فقط من أن طرق `RawVec` تمر على الأقل عبر واجهة برمجة تطبيقات Allocator عندما تحتفظ بالتخزين.
    //
    //
    //
    //
    //

    // مخصص غبي يستهلك كمية ثابتة من الوقود قبل أن تبدأ محاولات التخصيص بالفشل.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (يتسبب في إعادة التخصيص ، وبالتالي استخدام 50 + 150=200 وحدة من الوقود)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // أولاً ، يخصص `reserve` مثل `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 أكثر من ضعف 7 ، لذا يجب أن يعمل `reserve` مثل `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 أقل من نصف 12 ، لذا يجب أن ينمو `reserve` أضعافًا مضاعفة.
        // في وقت كتابة هذا الاختبار ، كان عامل النمو هو 2 ، لذا فإن السعة الجديدة هي 24 ، ومع ذلك ، فإن عامل النمو 1.5 لا بأس به أيضًا.
        //
        // ومن ثم `>= 18` في التأكيد.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}