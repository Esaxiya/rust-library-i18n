//! يتم تخصيص Prelude
//!
//! الغرض من هذه الوحدة هو التخفيف من واردات العناصر شائعة الاستخدام من `alloc` crate عن طريق إضافة استيراد الكرة الأرضية إلى الجزء العلوي من الوحدات:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;