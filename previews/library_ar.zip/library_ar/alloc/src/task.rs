#![stable(feature = "wake_trait", since = "1.51.0")]
//! أنواع و Traits للعمل مع المهام غير المتزامنة.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// تنفيذ مهمة اليقظة على المنفذ.
///
/// يمكن استخدام trait لإنشاء [`Waker`].
/// يمكن للمنفذ تعريف تطبيق trait هذا ، واستخدامه لإنشاء Waker للتمرير إلى المهام التي يتم تنفيذها على هذا المنفذ.
///
/// يعد trait بديلاً آمنًا للذاكرة ومريحًا لبناء [`RawWaker`].
/// وهو يدعم تصميم المنفذ المشترك الذي يتم فيه تخزين البيانات المستخدمة لإيقاظ مهمة ما في [`Arc`].
/// لا يستطيع بعض المنفذين (خاصةً الأنظمة المضمنة) استخدام واجهة برمجة التطبيقات هذه ، وهذا هو سبب وجود [`RawWaker`] كبديل لتلك الأنظمة.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// دالة `block_on` أساسية تأخذ future وتقوم بتشغيلها حتى اكتمالها في مؤشر الترابط الحالي.
///
/// **Note:** هذا المثال يتاجر في الصواب من أجل البساطة.
/// من أجل منع حالات الجمود ، ستحتاج عمليات التنفيذ على مستوى الإنتاج أيضًا إلى معالجة المكالمات الوسيطة إلى `thread::unpark` بالإضافة إلى الاستدعاءات المتداخلة.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// المستيقظ الذي يوقظ الخيط الحالي عند استدعائه.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// قم بتشغيل future لإكمال الموضوع الحالي.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // ثبّت future حتى يمكن استقصاءها.
///     let mut fut = Box::pin(fut);
///
///     // قم بإنشاء سياق جديد ليتم تمريره إلى future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // قم بتشغيل future حتى الاكتمال.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// استيقظ على هذه المهمة.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// استيقظ على هذه المهمة دون استهلاك المستيقظ.
    ///
    /// إذا كان المنفذ يدعم طريقة أرخص للاستيقاظ دون استهلاك المستيقظ ، فيجب أن يتجاوز هذه الطريقة.
    /// بشكل افتراضي ، يستنسخ [`Arc`] ويستدعي [`wake`] على النسخة.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // الأمان: هذا آمن لأن raw_waker يبني بأمان
        // a RawWaker من Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: يتم استخدام هذه الوظيفة الخاصة لإنشاء RawWaker بدلاً من
// تضمين هذا في `From<Arc<W>> for RawWaker` الضمني ، للتأكد من أن سلامة `From<Arc<W>> for Waker` لا تعتمد على إرسال trait الصحيح ، بدلاً من ذلك يستدعي كلاهما هذه الوظيفة بشكل مباشر وصريح.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // قم بزيادة العد المرجعي للقوس لاستنساخه.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // استيقظ من حيث القيمة ، انقل القوس إلى وظيفة Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // استيقظ بالإشارة ، لف المستيقظ في ManuallyDrop لتجنب إسقاطه
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // إنقاص العدد المرجعي للقوس عند الإسقاط
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}