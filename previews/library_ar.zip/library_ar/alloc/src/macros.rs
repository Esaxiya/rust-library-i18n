/// ينشئ [`Vec`] يحتوي على الوسائط.
///
/// `vec!` يسمح بتعريف `Vec`s بنفس بنية تعبيرات المصفوفة.
/// هناك نوعان من هذا الماكرو:
///
/// - قم بإنشاء [`Vec`] يحتوي على قائمة معينة من العناصر:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - قم بإنشاء [`Vec`] من عنصر وحجم معينين:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// لاحظ أنه على عكس تعبيرات المصفوفة ، تدعم هذه البنية جميع العناصر التي تنفذ [`Clone`] ولا يجب أن يكون عدد العناصر ثابتًا.
///
/// سيستخدم هذا `clone` لتكرار تعبير ، لذلك يجب على المرء أن يكون حذرًا عند استخدامه مع الأنواع التي لها تطبيق `Clone` غير قياسي.
/// على سبيل المثال ، `vec![Rc::new(1) ؛5] `سيُنشئ vector من خمسة مراجع لنفس قيمة العدد الصحيح المربّع ، وليس خمسة مراجع تشير إلى أعداد صحيحة مربوطة بشكل مستقل.
///
///
/// لاحظ أيضًا أن `vec![expr; 0]` مسموح به ، وينتج vector فارغًا.
/// سيظل هذا يقيّم `expr` ، ومع ذلك ، ويسقط القيمة الناتجة على الفور ، لذا كن على دراية بالآثار الجانبية.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): مع cfg(test) ، طريقة `[T]::into_vec` المتأصلة ، المطلوبة لتعريف الماكرو هذا ، غير متوفرة.
// بدلاً من ذلك ، استخدم وظيفة `slice::into_vec` المتوفرة فقط مع cfg(test) NB ، راجع الوحدة النمطية slice::hack في slice.rs لمزيد من المعلومات
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// ينشئ `String` باستخدام الإقحام لتعبيرات وقت التشغيل.
///
/// الوسيطة الأولى التي يتلقاها `format!` هي سلسلة تنسيق.يجب أن تكون هذه سلسلة حرفية.قوة سلسلة التنسيق موجودة في `{} ق.
///
/// تحل المعلمات الإضافية التي تم تمريرها إلى `format!` محل "{}" ضمن سلسلة التنسيق بالترتيب المعطى ما لم يتم استخدام معلمات محددة أو موضعية ؛انظر [`std::fmt`] لمزيد من المعلومات.
///
///
/// الاستخدام الشائع لـ `format!` هو تسلسل واستيفاء السلاسل.
/// يتم استخدام نفس الاصطلاح مع وحدات الماكرو [`print!`] و [`write!`] ، اعتمادًا على الوجهة المقصودة للسلسلة.
///
/// لتحويل قيمة واحدة إلى سلسلة ، استخدم طريقة [`to_string`].سيستخدم هذا تنسيق [`Display`] trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics إذا أرجع تطبيق التنسيق trait خطأ.
/// يشير هذا إلى تطبيق غير صحيح لأن `fmt::Write for String` لا يُرجع خطأ بحد ذاته.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// فرض عقدة AST على تعبير لتحسين التشخيص في موضع النمط.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}