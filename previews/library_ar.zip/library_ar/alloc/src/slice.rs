//! عرض ديناميكي الحجم في تسلسل متجاور ، `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! الشرائح عبارة عن عرض لكتلة من الذاكرة يتم تمثيلها كمؤشر وطول.
//!
//! ```
//! // تقطيع Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // إكراه مصفوفة على شريحة
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! الشرائح إما قابلة للتغيير أو مشتركة.
//! نوع الشريحة المشتركة هو `&[T]` ، بينما نوع الشريحة القابلة للتغيير هو `&mut [T]` ، حيث يمثل `T` نوع العنصر.
//! على سبيل المثال ، يمكنك تغيير كتلة الذاكرة التي تشير إليها الشريحة القابلة للتغيير:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! فيما يلي بعض الأشياء التي تحتوي عليها هذه الوحدة:
//!
//! ## Structs
//!
//! هناك العديد من الهياكل المفيدة للشرائح ، مثل [`Iter`] ، والتي تمثل التكرار على شريحة.
//!
//! ## تطبيقات Trait
//!
//! هناك العديد من تطبيقات traits الشائعة للشرائح.تتضمن بعض الأمثلة ما يلي:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`] ، للشرائح التي يكون نوع عنصرها [`Eq`] أو [`Ord`].
//! * [`Hash`] - للشرائح التي يكون نوع عنصرها [`Hash`].
//!
//! ## Iteration
//!
//! الشرائح تنفذ `IntoIterator`.ينتج عن المكرر مراجع لعناصر الشريحة.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! تنتج الشريحة القابلة للتغيير إشارات قابلة للتغيير إلى العناصر:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! ينتج عن هذا المكرر مراجع قابلة للتغيير لعناصر الشريحة ، لذلك بينما يكون نوع عنصر الشريحة هو `i32` ، يكون نوع عنصر المكرر هو `&mut i32`.
//!
//!
//! * [`.iter`] و [`.iter_mut`] هما طريقتان صريحتان لإرجاع التكرارات الافتراضية.
//! * الطرق الأخرى التي تقوم بإرجاع التكرارات هي [`.split`] و [`.splitn`] و [`.chunks`] و [`.windows`] والمزيد.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// يتم استخدام العديد من الاستخدامات في هذه الوحدة فقط في تكوين الاختبار.
// من الأنظف إيقاف تشغيل تحذير الاستيراد غير المستخدم بدلاً من إصلاحه.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// طرق تمديد الشريحة الأساسية
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) مطلوب لتنفيذ ماكرو `vec!` أثناء اختبار NB ، راجع الوحدة النمطية `hack` في هذا الملف لمزيد من التفاصيل.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) مطلوب لتنفيذ `Vec::clone` أثناء اختبار NB ، راجع الوحدة النمطية `hack` في هذا الملف لمزيد من التفاصيل.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): مع عدم توفر cfg(test) `impl [T]` ، فهذه الوظائف الثلاث هي في الواقع طرق موجودة في `impl [T]` ولكن ليس في `core::slice::SliceExt` ، نحتاج إلى توفير هذه الوظائف لاختبار `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // لا ينبغي أن نضيف سمة مضمنة إلى هذا نظرًا لأنه يتم استخدامه في ماكرو `vec!` في الغالب ويسبب انحدار الأداء.
    // انظر #71204 للمناقشة ونتائج الأداء.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // تم وضع علامة على العناصر تمت تهيئتها في الحلقة أدناه
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) ضروري لـ LLVM لإزالة عمليات التحقق من الحدود ولديه رمز تشفير أفضل من الرمز البريدي.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // تم تخصيص vec وتهيئته أعلاه إلى هذا الطول على الأقل.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // المخصصة أعلاه بسعة `s` ، وقم بالتهيئة إلى `s.len()` في ptr::copy_to_non_overlapping أدناه.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// يفرز الشريحة.
    ///
    /// هذا النوع مستقر (أي لا يعيد ترتيب العناصر المتساوية) و *O*(*n*\*log(* n*)) أسوأ حالة.
    ///
    /// عند الاقتضاء ، يُفضل الفرز غير المستقر لأنه عمومًا أسرع من الفرز المستقر ولا يخصص ذاكرة مساعدة.
    /// انظر [`sort_unstable`](slice::sort_unstable).
    ///
    /// # التنفيذ الحالي
    ///
    /// الخوارزمية الحالية عبارة عن نوع دمج تكراري تكيفي مستوحى من [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// إنه مصمم ليكون سريعًا جدًا في الحالات التي يتم فيها فرز الشريحة تقريبًا ، أو تتكون من تسلسلين أو أكثر تم فرزها متسلسلة واحدة تلو الأخرى.
    ///
    ///
    /// أيضًا ، يخصص تخزينًا مؤقتًا نصف حجم `self` ، ولكن بالنسبة للشرائح القصيرة ، يتم استخدام فرز إدخال غير مخصص بدلاً من ذلك.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// يفرز الشريحة بوظيفة المقارنة.
    ///
    /// هذا النوع مستقر (أي لا يعيد ترتيب العناصر المتساوية) و *O*(*n*\*log(* n*)) أسوأ حالة.
    ///
    /// يجب أن تحدد وظيفة المقارنة ترتيبًا إجماليًا للعناصر الموجودة في الشريحة.إذا لم يكن الترتيب إجماليًا ، فسيكون ترتيب العناصر غير محدد.
    /// الطلب هو أمر إجمالي إذا كان (لجميع `a` و `b` و `c`):
    ///
    /// * الإجمالي وغير المتماثل: واحد بالضبط من `a < b` أو `a == b` أو `a > b` صحيح ، و
    /// * متعدية ، `a < b` و `b < c` تعني `a < c`.يجب أن ينطبق الشيء نفسه على كل من `==` و `>`.
    ///
    /// على سبيل المثال ، بينما لا يقوم [`f64`] بتنفيذ [`Ord`] لأن `NaN != NaN` ، يمكننا استخدام `partial_cmp` كدالة فرز عندما نعلم أن الشريحة لا تحتوي على `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// عند الاقتضاء ، يُفضل الفرز غير المستقر لأنه عمومًا أسرع من الفرز المستقر ولا يخصص ذاكرة مساعدة.
    /// انظر [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # التنفيذ الحالي
    ///
    /// الخوارزمية الحالية عبارة عن نوع دمج تكراري تكيفي مستوحى من [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// إنه مصمم ليكون سريعًا جدًا في الحالات التي يتم فيها فرز الشريحة تقريبًا ، أو تتكون من تسلسلين أو أكثر تم فرزها متسلسلة واحدة تلو الأخرى.
    ///
    /// أيضًا ، يخصص تخزينًا مؤقتًا نصف حجم `self` ، ولكن بالنسبة للشرائح القصيرة ، يتم استخدام فرز إدخال غير مخصص بدلاً من ذلك.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // الفرز العكسي
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// يفرز الشريحة بوظيفة الاستخراج الرئيسية.
    ///
    /// هذا النوع مستقر (على سبيل المثال ، لا يعيد ترتيب العناصر المتساوية) و *O*(*m*\* * n *\* log(*n*)) أسوأ حالة ، حيث تكون الوظيفة الرئيسية *O*(*m*).
    ///
    /// للوظائف الرئيسية باهظة الثمن (على سبيل المثال
    /// الوظائف التي ليست عمليات وصول بسيطة للممتلكات أو عمليات أساسية) ، من المحتمل أن يكون [`sort_by_cached_key`](slice::sort_by_cached_key) أسرع بشكل ملحوظ ، حيث لا يعيد حساب مفاتيح العناصر.
    ///
    ///
    /// عند الاقتضاء ، يُفضل الفرز غير المستقر لأنه عمومًا أسرع من الفرز المستقر ولا يخصص ذاكرة مساعدة.
    /// انظر [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # التنفيذ الحالي
    ///
    /// الخوارزمية الحالية عبارة عن نوع دمج تكراري تكيفي مستوحى من [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// إنه مصمم ليكون سريعًا جدًا في الحالات التي يتم فيها فرز الشريحة تقريبًا ، أو تتكون من تسلسلين أو أكثر تم فرزها متسلسلة واحدة تلو الأخرى.
    ///
    /// أيضًا ، يخصص تخزينًا مؤقتًا نصف حجم `self` ، ولكن بالنسبة للشرائح القصيرة ، يتم استخدام فرز إدخال غير مخصص بدلاً من ذلك.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// يفرز الشريحة بوظيفة الاستخراج الرئيسية.
    ///
    /// أثناء الفرز ، يتم استدعاء الوظيفة الرئيسية مرة واحدة فقط لكل عنصر.
    ///
    /// هذا الفرز مستقر (على سبيل المثال ، لا يعيد ترتيب العناصر المتساوية) و *O*(*m*\* * n *+* n *\* log(*n*)) أسوأ حالة ، حيث تكون الوظيفة الرئيسية *O*(*m*) .
    ///
    /// بالنسبة للوظائف الأساسية البسيطة (على سبيل المثال ، الوظائف التي تعتبر وصولاً للممتلكات أو العمليات الأساسية) ، من المرجح أن يكون [`sort_by_key`](slice::sort_by_key) أسرع.
    ///
    /// # التنفيذ الحالي
    ///
    /// تعتمد الخوارزمية الحالية على [pattern-defeating quicksort][pdqsort] بواسطة Orson Peters ، والتي تجمع بين متوسط حالة السرعة العشوائية السريعة مع أسوأ حالة من الفرز السريع ، مع تحقيق الوقت الخطي على الشرائح بأنماط معينة.
    /// يستخدم بعض التوزيع العشوائي لتجنب الحالات المتدهورة ، ولكن مع seed ثابت لتوفير سلوك حتمي دائمًا.
    ///
    /// في أسوأ الحالات ، تخصص الخوارزمية تخزينًا مؤقتًا في `Vec<(K, usize)>` بطول الشريحة.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // ماكرو مساعد لفهرسة vector لدينا من خلال أصغر نوع ممكن ، لتقليل التخصيص.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // تعتبر عناصر `indices` فريدة من نوعها ، حيث تمت فهرستها ، لذا فإن أي نوع سيكون مستقرًا بالنسبة للشريحة الأصلية.
                // نستخدم `sort_unstable` هنا لأنه يتطلب تخصيصًا أقل للذاكرة.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// ينسخ `self` إلى `Vec` جديد.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // هنا ، يمكن تعديل `s` و `x` بشكل مستقل.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// ينسخ `self` إلى `Vec` جديد باستخدام مُخصص.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // هنا ، يمكن تعديل `s` و `x` بشكل مستقل.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // ملحوظة ، راجع وحدة `hack` في هذا الملف لمزيد من التفاصيل.
        hack::to_vec(self, alloc)
    }

    /// يحول `self` إلى vector بدون نسخ أو تخصيص.
    ///
    /// يمكن تحويل vector الناتج مرة أخرى إلى صندوق عبر Vec<T>طريقة `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` لا يمكن استخدامه بعد الآن لأنه تم تحويله إلى `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // ملحوظة ، راجع وحدة `hack` في هذا الملف لمزيد من التفاصيل.
        hack::into_vec(self)
    }

    /// ينشئ vector بتكرار شريحة `n` مرة.
    ///
    /// # Panics
    ///
    /// هذه الوظيفة سوف panic إذا تجاوزت السعة.
    ///
    /// # Examples
    ///
    /// الاستخدام الأساسي:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// A panic عند الفائض:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // إذا كان `n` أكبر من الصفر ، فيمكن تقسيمه كـ `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` هو الرقم الذي يمثله أقصى اليسار بت '1' من `n` ، و `rem` هو الجزء المتبقي من `n`.
        //
        //

        // استخدام `Vec` للوصول إلى `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` يتم التكرار بمضاعفة `buf` `expn` مرات.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // إذا كان `m > 0` ، فهناك وحدات بت متبقية تصل إلى أقصى اليسار '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` بسعة `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` ("=n، 2 ^ expn") يتم التكرار عن طريق نسخ التكرارات الأولى لـ `rem` من `buf` نفسه.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // هذا غير متداخل منذ `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` يساوي `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// يسوي شريحة `T` في قيمة واحدة `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// يسوي شريحة `T` في قيمة واحدة `Self::Output` ، مع وضع فاصل معين بين كل شريحة.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// يسوي شريحة `T` في قيمة واحدة `Self::Output` ، مع وضع فاصل معين بين كل شريحة.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// إرجاع vector الذي يحتوي على نسخة من هذه الشريحة حيث يتم تعيين كل بايت إلى مكافئها بأحرف كبيرة ASCII.
    ///
    ///
    /// يتم تعيين أحرف ASCII من 'a' إلى 'z' إلى 'A' إلى 'Z' ، لكن الأحرف غير ASCII لم تتغير.
    ///
    /// لتكبير القيمة في نفس المكان ، استخدم [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// إرجاع vector الذي يحتوي على نسخة من هذه الشريحة حيث يتم تعيين كل بايت إلى مكافئها بأحرف صغيرة ASCII.
    ///
    ///
    /// يتم تعيين أحرف ASCII من 'A' إلى 'Z' إلى 'a' إلى 'z' ، لكن الأحرف غير ASCII لم تتغير.
    ///
    /// لتصغير القيمة في نفس المكان ، استخدم [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// امتداد traits للشرائح على أنواع معينة من البيانات
////////////////////////////////////////////////////////////////////////////////

/// trait المساعد لـ [`[T]: : concat`](شريحة::concat).
///
/// Note: لا يتم استخدام معلمة نوع `Item` في trait هذا ، ولكنها تسمح بأن تكون الضمانات أكثر عمومية.
/// بدونها ، نحصل على هذا الخطأ:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// هذا لأنه قد توجد أنواع `V` مع العديد من الضمانات `Borrow<[_]>` ، بحيث يتم تطبيق أنواع `T` المتعددة:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// النوع الناتج بعد التسلسل
    type Output;

    /// تنفيذ [`[T]: : concat`](شريحة::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// المساعد trait لـ [`[T]: : Join`](شريحة::الانضمام)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// النوع الناتج بعد التسلسل
    type Output;

    /// تنفيذ [`[T]: : Join`](شريحة::الانضمام)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// تطبيقات trait القياسية للشرائح
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // قم بإسقاط أي شيء في الهدف لن يتم الكتابة فوقه
        target.truncate(self.len());

        // target.len <= self.len بسبب الاقتطاع أعلاه ، لذا فإن الشرائح هنا دائمًا ما تكون داخل الحدود.
        //
        let (init, tail) = self.split_at(target.len());

        // إعادة استخدام القيم المضمنة allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// يقوم بإدراج `v[0]` في تسلسل مفرز مسبقًا `v[1..]` بحيث يتم فرز `v[..]` بالكامل.
///
/// هذا هو الروتين الفرعي المتكامل لنوع الإدراج.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // هناك ثلاث طرق لتنفيذ الإدراج هنا:
            //
            // 1. قم بتبديل العناصر المجاورة حتى يصل العنصر الأول إلى وجهته النهائية.
            //    ومع ذلك ، بهذه الطريقة نقوم بنسخ البيانات حول أكثر مما هو ضروري.
            //    إذا كانت العناصر عبارة عن هياكل كبيرة (مكلفة للنسخ) ، فستكون هذه الطريقة بطيئة.
            //
            // 2. كرر حتى يتم العثور على المكان المناسب للعنصر الأول.
            // ثم انقل العناصر التي تلاها لإفساح المجال لها وأخيراً ضعها في الفتحة المتبقية.
            // هذه طريقة جيدة.
            //
            // 3. انسخ العنصر الأول في متغير مؤقت.كرر حتى يتم العثور على المكان المناسب لها.
            // بينما نمضي قدمًا ، انسخ كل عنصر تم اجتيازه في الفتحة التي تسبقه.
            // أخيرًا ، انسخ البيانات من المتغير المؤقت إلى الفتحة المتبقية.
            // هذه الطريقة جيدة جدا.
            // أظهرت المعايير أداءً أفضل قليلاً من الطريقة الثانية.
            //
            // تم قياس جميع الطرق ، وأظهرت الطريقة الثالثة أفضل النتائج.لذلك اخترنا ذلك.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // يتم دائمًا تتبع الحالة الوسيطة لعملية الإدراج بواسطة `hole` ، والذي يخدم غرضين:
            // 1. يحمي سلامة `v` من panics في `is_less`.
            // 2. يملأ الفتحة المتبقية في `v` في النهاية.
            //
            // سلامة Panic:
            //
            // إذا كان `is_less` panics في أي وقت أثناء العملية ، فسوف يتم إسقاط `hole` وملء الفتحة في `v` بـ `tmp` ، وبالتالي ضمان أن `v` لا يزال يحتفظ بكل كائن كان يحمله في البداية مرة واحدة بالضبط.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` يتم إسقاطها وبالتالي نسخ `tmp` في الفتحة المتبقية في `v`.
        }
    }

    // عند إسقاطها ، يتم النسخ من `src` إلى `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// يدمج التشغيل غير المتناقص `v[..mid]` و `v[mid..]` باستخدام `buf` كتخزين مؤقت ، ويخزن النتيجة في `v[..]`.
///
/// # Safety
///
/// يجب ألا تكون الشريحتان فارغتين ويجب أن تكون `mid` داخل الحدود.
/// يجب أن يكون المخزن المؤقت `buf` طويلاً بما يكفي لاحتواء نسخة من الشريحة الأقصر.
/// أيضًا ، يجب ألا يكون `T` من النوع ذي الحجم الصفري.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // تقوم عملية الدمج أولاً بنسخ المدى الأقصر إلى `buf`.
    // ثم يتتبع المدى الذي تم نسخه حديثًا والتشغيل الأطول للأمام (أو للخلف) ، ويقارن العناصر غير المستهلكة التالية ونسخ العنصر الأقل (أو الأكبر) في `v`.
    //
    // بمجرد أن يتم استهلاك المدى الأقصر بالكامل ، تتم العملية.إذا تم استهلاك المدى الأطول أولاً ، فيجب علينا نسخ ما تبقى من المدى الأقصر في الفتحة المتبقية في `v`.
    //
    // يتم دائمًا تتبع الحالة الوسيطة للعملية بواسطة `hole` ، والذي يخدم غرضين:
    // 1. يحمي سلامة `v` من panics في `is_less`.
    // 2. يملأ الفتحة المتبقية في `v` إذا تم استهلاك المدى الأطول أولاً.
    //
    // سلامة Panic:
    //
    // إذا كان `is_less` panics في أي وقت أثناء العملية ، فسيتم إسقاط `hole` وملء الفتحة في `v` بالنطاق غير المستهلك في `buf` ، وبالتالي ضمان أن `v` لا يزال يحتفظ بكل كائن كان يحمله في البداية مرة واحدة بالضبط.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // المدى الأيسر أقصر.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // في البداية ، تشير هذه المؤشرات إلى بدايات مصفوفاتهم.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // تستهلك الجانب الأقل.
            // إذا كانت متساوية ، تفضل المدى الأيسر للحفاظ على الاستقرار.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // المدى الصحيح أقصر.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // في البداية ، تشير هذه المؤشرات إلى ما بعد نهايات المصفوفات.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // تستهلك الجانب الأكبر.
            // إذا كانت متساوية ، تفضل المدى الصحيح للحفاظ على الاستقرار.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // أخيرًا ، يتم إسقاط `hole`.
    // إذا لم يتم استهلاك المدى الأقصر بالكامل ، فسيتم الآن نسخ أي بقايا منه في الفتحة الموجودة في `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // عند إسقاطه ، انسخ النطاق `start..end` إلى `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` ليس من النوع ذي الحجم الصفري ، لذا لا بأس من القسمة على حجمه.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// يستعير هذا النوع من الدمج بعض الأفكار (وليس كلها) من TimSort ، الموصوفة بالتفصيل [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// تحدد الخوارزمية بدقة التباينات اللاحقة التنازلية وغير التنازلية ، والتي تسمى عمليات التشغيل الطبيعية.هناك كومة من عمليات التشغيل المعلقة لم يتم دمجها بعد.
/// يتم دفع كل شوط تم العثور عليه حديثًا على المكدس ، ثم يتم دمج بعض أزواج المسارات المتجاورة حتى يتم استيفاء هذين المتغيرين:
///
/// 1. لكل `i` في `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. لكل `i` في `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// تضمن الثوابت أن إجمالي وقت التشغيل هو *O*(*n*\*log(* n*)) أسوأ حالة.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // يتم فرز الشرائح حتى هذا الطول باستخدام فرز الإدخال.
    const MAX_INSERTION: usize = 20;
    // يتم تمديد فترات التشغيل القصيرة جدًا باستخدام فرز الإدراج ليشمل على الأقل العديد من العناصر.
    const MIN_RUN: usize = 10;

    // الفرز ليس له أي سلوك ذي معنى على الأنواع ذات الحجم الصفري.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // يتم فرز المصفوفات القصيرة في مكانها عن طريق فرز الإدراج لتجنب عمليات التخصيص.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // قم بتخصيص مخزن مؤقت لاستخدامه كذاكرة خدش.نحتفظ بالطول 0 حتى نتمكن من الاحتفاظ بنسخ ضحلة من محتويات `v` دون المخاطرة بتشغيل dtors على النسخ إذا كانت `is_less` panics.
    //
    // عند دمج مرحلتين مرتبة ، يحتفظ هذا المخزن المؤقت بنسخة من المدى الأقصر ، والذي سيكون دائمًا بطول `len / 2` على الأكثر.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // من أجل تحديد المسارات الطبيعية في `v` ، نقوم باجتيازها للخلف.
    // قد يبدو هذا قرارًا غريبًا ، لكن ضع في اعتبارك حقيقة أن عمليات الدمج غالبًا ما تذهب في الاتجاه المعاكس (forwards).
    // وفقًا للمعايير ، يكون الدمج للأمام أسرع قليلاً من الدمج للخلف.
    // في الختام ، فإن تحديد عمليات التشغيل عن طريق الانتقال للخلف يحسن الأداء.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // ابحث عن المسار الطبيعي التالي ، وعكسه إذا كان تنازليًا تمامًا.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // أدخل بعض العناصر الإضافية في المجموعة إذا كانت قصيرة جدًا.
        // يعتبر فرز الإدراج أسرع من فرز الدمج في التسلسلات القصيرة ، وبالتالي يؤدي ذلك إلى تحسين الأداء بشكل ملحوظ.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // ادفع هذا الجري على المكدس.
        runs.push(Run { start, len: end - start });
        end = start;

        // ادمج بعض الأزواج المتجاورة لإرضاء الثوابت.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // أخيرًا ، يجب أن يظل تشغيل واحد بالضبط في المكدس.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // يفحص كومة الأشواط ويحدد الزوج التالي من الأشواط المراد دمجها.
    // وبشكل أكثر تحديدًا ، إذا تم إرجاع `Some(r)` ، فهذا يعني أنه يجب دمج `runs[r]` و `runs[r + 1]` بعد ذلك.
    // إذا استمرت الخوارزمية في إنشاء تشغيل جديد بدلاً من ذلك ، فسيتم إرجاع `None`.
    //
    // TimSort مشهور بتطبيقات عربات التي تجرها الدواب ، كما هو موضح هنا:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // جوهر القصة هو: يجب علينا فرض الثوابت على الأربعة أشواط الأولى على المكدس.
    // إن فرضها في المراكز الثلاثة الأولى فقط ليس كافيًا للتأكد من أن الثوابت ستظل صامدة لـ *كل* عمليات التشغيل في المكدس.
    //
    // تتحقق هذه الوظيفة بشكل صحيح من الثوابت لأربعة أشواط.
    // بالإضافة إلى ذلك ، إذا بدأ التشغيل العلوي في الفهرس 0 ، فسيطلب دائمًا عملية دمج حتى يتم طي المكدس بالكامل ، من أجل إكمال الفرز.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}