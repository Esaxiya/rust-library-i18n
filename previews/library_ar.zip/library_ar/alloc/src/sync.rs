#![stable(feature = "rust1", since = "1.0.0")]

//! مؤشرات عد مرجع الخيط الآمن.
//!
//! راجع وثائق [`Arc<T>`][Arc] لمزيد من التفاصيل.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// حد ضعيف على مقدار المراجع التي يمكن إجراؤها على `Arc`.
///
/// سيؤدي تجاوز هذا الحد إلى إجهاض البرنامج (وإن لم يكن بالضرورة) عند مراجع _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// لا يدعم ThreadSanitizer أسوار الذاكرة.
// لتجنب التقارير الإيجابية الكاذبة في تطبيق Arc/Weak ، استخدم الأحمال الذرية للمزامنة بدلاً من ذلك.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// مؤشر عد مرجعي آمن للخيط.يرمز 'Arc' إلى "تم حساب المرجع الذري".
///
/// يوفر النوع `Arc<T>` ملكية مشتركة لقيمة من النوع `T` ، مخصصة في الكومة.ينتج عن استدعاء [`clone`][clone] على `Arc` مثيل `Arc` جديد ، والذي يشير إلى نفس التخصيص على الكومة مثل `Arc` المصدر ، مع زيادة عدد المراجع.
/// عندما يتم إتلاف آخر مؤشر `Arc` لتخصيص معين ، يتم أيضًا إسقاط القيمة المخزنة في هذا التخصيص (يشار إليه غالبًا باسم "inner value").
///
/// لا تسمح المراجع المشتركة في Rust بالطفرة افتراضيًا ، و `Arc` ليست استثناءً: لا يمكنك عمومًا الحصول على مرجع قابل للتغيير لشيء ما داخل `Arc`.إذا كنت بحاجة إلى التحول من خلال `Arc` ، فاستخدم [`Mutex`][mutex] أو [`RwLock`][rwlock] أو أحد أنواع [`Atomic`][atomic].
///
/// ## سلامة الخيط
///
/// على عكس [`Rc<T>`] ، يستخدم `Arc<T>` العمليات الذرية لحساب المرجع الخاص به.هذا يعني أنه آمن للخيط.العيب هو أن العمليات الذرية أغلى من عمليات الوصول إلى الذاكرة العادية.إذا كنت لا تشارك عمليات التخصيص التي تم احتسابها كمرجع بين سلاسل العمليات ، ففكر في استخدام [`Rc<T>`] للحصول على حمل أقل.
/// [`Rc<T>`] هو افتراضي آمن ، لأن المحول البرمجي سيلتقط أي محاولة لإرسال [`Rc<T>`] بين سلاسل العمليات.
/// ومع ذلك ، قد تختار مكتبة `Arc<T>` لمنح مستخدمي المكتبة مرونة أكبر.
///
/// `Arc<T>` سيطبق [`Send`] و [`Sync`] طالما أن `T` تنفذ [`Send`] و [`Sync`].
/// لماذا لا يمكنك وضع نوع `T` غير آمن للخيط في `Arc<T>` لجعله آمنًا؟قد يكون هذا غير بديهي بعض الشيء في البداية: بعد كل شيء ، أليس موضوع سلامة خيط `Arc<T>`؟المفتاح هو هذا: `Arc<T>` يجعل من الخيط الآمن أن يكون لديك ملكية متعددة لنفس البيانات ، لكنه لا يضيف أمان مؤشر الترابط إلى بياناته.
///
/// ضع في اعتبارك `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] ليس [`Sync`] ، وإذا كان `Arc<T>` دائمًا [`Send`] ، `Arc <` [`RefCell<T>سيكون كذلك`]`>`.
/// ولكن بعد ذلك ستكون لدينا مشكلة:
/// [`RefCell<T>`] ليس موضوع آمن ؛يتتبع عدد الاقتراض باستخدام العمليات غير الذرية.
///
/// في النهاية ، هذا يعني أنك قد تحتاج إلى إقران `Arc<T>` بنوع من نوع [`std::sync`] ، عادةً [`Mutex<T>`][mutex].
///
/// ## دورات كسر مع `Weak`
///
/// يمكن استخدام طريقة [`downgrade`][downgrade] لإنشاء مؤشر [`Weak`] غير مملوك.يمكن أن يكون مؤشر [`Weak`] [`ترقية`][ترقية] د إلى `Arc` ، ولكن هذا سيعيد [`None`] إذا تم إسقاط القيمة المخزنة في التخصيص بالفعل.
/// بمعنى آخر ، لا تحافظ مؤشرات `Weak` على القيمة داخل التخصيص على قيد الحياة ؛ومع ذلك ، فإنهم *يفعلون* يحافظون على التخصيص (مخزن الدعم للقيمة) على قيد الحياة.
///
/// لن يتم إلغاء تخصيص دورة بين مؤشرات `Arc`.
/// لهذا السبب ، يتم استخدام [`Weak`] لكسر الدورات.على سبيل المثال ، يمكن أن تحتوي الشجرة على مؤشرات `Arc` قوية من العقد الأصلية إلى الأطفال ، ومؤشرات [`Weak`] من الأطفال إلى والديهم.
///
/// # مراجع الاستنساخ
///
/// يتم إنشاء مرجع جديد من مؤشر جرد مرجعي موجود باستخدام `Clone` trait المطبق لـ [`Arc<T>`][Arc] و [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // الصيغتان أدناه متكافئتان.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a و b و foo كلها أقواس تشير إلى نفس موقع الذاكرة
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` يشير تلقائيًا إلى `T` (عبر [`Deref`][deref] trait) ، لذا يمكنك استدعاء أساليب `T` على قيمة من النوع `Arc<T>`.لتجنب تضارب الأسماء مع طرق `T` ، فإن طرق `Arc<T>` نفسها هي وظائف مرتبطة ، تسمى باستخدام [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// قوس<T>يمكن أيضًا استدعاء تطبيقات traits مثل `Clone` باستخدام بناء جملة مؤهل بالكامل.
/// يفضل بعض الأشخاص استخدام بناء جملة مؤهل تمامًا ، بينما يفضل البعض الآخر استخدام أسلوب استدعاء الأسلوب.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // طريقة استدعاء الأسلوب
/// let arc2 = arc.clone();
/// // تركيب مؤهل بالكامل
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] لا يقوم بالرجوع التلقائي إلى `T` ، لأن القيمة الداخلية ربما تم إسقاطها بالفعل.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// مشاركة بعض البيانات الثابتة بين المواضيع:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// لاحظ أننا **لا** نجري هذه الاختبارات هنا.
// يصبح منشئو windows غير سعداء للغاية إذا تجاوز الخيط الخيط الرئيسي ثم خرج في نفس الوقت (شيء ما توقف عن العمل) لذلك نتجنب هذا تمامًا من خلال عدم إجراء هذه الاختبارات.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// مشاركة [`AtomicUsize`] متغير:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// راجع [`rc` documentation][rc_examples] لمزيد من الأمثلة على حساب المرجع بشكل عام.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` هو إصدار من [`Arc`] يحتوي على مرجع غير مالك للتخصيص المُدار.
/// يتم الوصول إلى التخصيص عن طريق استدعاء [`upgrade`] على مؤشر `Weak` ، والذي يعرض [`الخيار`]`<`[`Arc`] `<T>>`.
///
/// نظرًا لأن مرجع `Weak` لا يُحتسب ضمن الملكية ، فلن يمنع إسقاط القيمة المخزنة في التخصيص ، ولا يقدم `Weak` نفسه أي ضمانات بشأن استمرار وجود القيمة.
///
/// وبالتالي فإنه قد يعيد [`None`] عند [`ترقية`] د.
/// لاحظ مع ذلك أن مرجع `Weak`*لا* يمنع التخصيص نفسه (مخزن الدعم) من إلغاء تخصيصه.
///
/// يفيد مؤشر `Weak` في الاحتفاظ بمرجع مؤقت للتخصيص الذي تتم إدارته بواسطة [`Arc`] دون منع انخفاض قيمته الداخلية.
/// يتم استخدامه أيضًا لمنع المراجع الدائرية بين مؤشرات [`Arc`] ، نظرًا لأن مراجع الملكية المتبادلة لن تسمح مطلقًا بإسقاط [`Arc`].
/// على سبيل المثال ، يمكن أن تحتوي الشجرة على مؤشرات [`Arc`] قوية من العقد الأصلية إلى الأطفال ، ومؤشرات `Weak` من الأطفال إلى والديهم.
///
/// الطريقة النموذجية للحصول على مؤشر `Weak` هي استدعاء [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // هذا هو `NonNull` للسماح بتحسين حجم هذا النوع في التعدادات ، ولكنه ليس بالضرورة مؤشرًا صالحًا.
    //
    // `Weak::new` يضبط هذا على `usize::MAX` بحيث لا يحتاج إلى تخصيص مساحة على الكومة.
    // هذه ليست قيمة سيحصل عليها المؤشر الحقيقي على الإطلاق لأن RcBox لديه محاذاة على الأقل 2.
    // هذا ممكن فقط عندما `T: Sized`؛`T` غير المقاس لا يتدلى أبدًا.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// هذا هو repr(C) إلى future مقاوم لإعادة ترتيب المجال المحتمل ، والذي قد يتداخل مع [into|from]_raw() الآمن للأنواع الداخلية القابلة للتحويل.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // تعمل القيمة usize::MAX كحارس لـ "locking" مؤقتًا القدرة على ترقية المؤشرات الضعيفة أو تقليل المؤشرات القوية ؛يستخدم هذا لتجنب السباقات في `make_mut` و `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// يبني `Arc<T>` جديد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // ابدأ عد المؤشر الضعيف كـ 1 وهو المؤشر الضعيف الذي تحتفظ به جميع المؤشرات القوية (kinda) ، راجع std/rc.rs لمزيد من المعلومات
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// يبني `Arc<T>` جديد باستخدام مرجع ضعيف لنفسه.
    /// ستؤدي محاولة ترقية المرجع الضعيف قبل إرجاع هذه الدالة إلى قيمة `None`.
    /// ومع ذلك ، يمكن استنساخ المرجع الضعيف بحرية وتخزينه للاستخدام في وقت لاحق.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // قم ببناء الجزء الداخلي في حالة "uninitialized" بمرجع ضعيف واحد.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // من المهم ألا نتخلى عن ملكية المؤشر الضعيف ، وإلا فقد يتم تحرير الذاكرة بحلول الوقت الذي يعود فيه `data_fn`.
        // إذا أردنا حقًا تمرير الملكية ، فيمكننا إنشاء مؤشر ضعيف إضافي لأنفسنا ، ولكن هذا سيؤدي إلى تحديثات إضافية لعدد المرجع الضعيف الذي قد لا يكون ضروريًا بخلاف ذلك.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // الآن يمكننا تهيئة القيمة الداخلية بشكل صحيح وتحويل مرجعنا الضعيف إلى مرجع قوي.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // يجب أن تكون الكتابة أعلاه في حقل البيانات مرئية لأي سلاسل رسائل تلاحظ عددًا قويًا غير صفري.
            // لذلك نحن بحاجة إلى ترتيب "Release" على الأقل من أجل المزامنة مع `compare_exchange_weak` في `Weak::upgrade`.
            //
            // "Acquire" الطلب غير مطلوب.
            // عند النظر في السلوكيات المحتملة لـ `data_fn` ، نحتاج فقط إلى النظر إلى ما يمكن أن يفعله بالإشارة إلى `Weak` غير قابل للترقية:
            //
            // - يمكنه *استنساخ*`Weak` ، مما يزيد من عدد المراجع الضعيفة.
            // - يمكنه إسقاط تلك الحيوانات المستنسخة ، مما يقلل من عدد المراجع الضعيفة (ولكن لا تصل أبدًا إلى الصفر).
            //
            // هذه الآثار الجانبية لا تؤثر علينا بأي شكل من الأشكال ، ولا توجد آثار جانبية أخرى ممكنة باستخدام الكود الآمن وحده.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // يجب أن تمتلك المراجع القوية بشكل جماعي مرجعًا ضعيفًا مشتركًا ، لذلك لا تقم بتشغيل أداة التدمير لمرجعنا القديم الضعيف.
        //
        mem::forget(weak);
        strong
    }

    /// يقوم بإنشاء `Arc` جديد بمحتويات غير مهيأة.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // التهيئة المؤجلة:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// ينشئ `Arc` جديدًا بمحتويات غير مهيأة ، مع ملء الذاكرة بـ `0` بايت.
    ///
    ///
    /// راجع [`MaybeUninit::zeroed`][zeroed] للحصول على أمثلة للاستخدام الصحيح وغير الصحيح لهذه الطريقة.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// يبني `Pin<Arc<T>>` جديد.
    /// إذا لم يطبق `T` `Unpin` ، فسيتم تثبيت `data` في الذاكرة ولا يمكن نقله.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// ينشئ `Arc<T>` جديدًا ، ويعيد خطأ إذا فشل التخصيص.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // ابدأ عد المؤشر الضعيف كـ 1 وهو المؤشر الضعيف الذي تحتفظ به جميع المؤشرات القوية (kinda) ، راجع std/rc.rs لمزيد من المعلومات
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// ينشئ `Arc` جديدًا بمحتويات غير مهيأة ، ويعيد خطأ إذا فشل التخصيص.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // التهيئة المؤجلة:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// ينشئ `Arc` جديدًا بمحتويات غير مهيأة ، مع ملء الذاكرة بـ `0` بايت ، وإرجاع خطأ إذا فشل التخصيص.
    ///
    ///
    /// راجع [`MaybeUninit::zeroed`][zeroed] للحصول على أمثلة للاستخدام الصحيح وغير الصحيح لهذه الطريقة.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// تُرجع القيمة الداخلية ، إذا كان `Arc` يحتوي على مرجع قوي واحد بالضبط.
    ///
    /// خلاف ذلك ، يتم إرجاع [`Err`] بنفس `Arc` الذي تم تمريره.
    ///
    ///
    /// سينجح هذا حتى لو كانت هناك مراجع ضعيفة بارزة.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // قم بعمل مؤشر ضعيف لتنظيف المرجع الضمني القوي-الضعيف
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// يُنشئ شريحة جديدة معدودة ذريًا بمحتويات غير مهيأة.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // التهيئة المؤجلة:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// يُنشئ شريحة جديدة معدودة ذريًا بمحتويات غير مهيأة ، مع ملء الذاكرة بـ `0` بايت.
    ///
    ///
    /// راجع [`MaybeUninit::zeroed`][zeroed] للحصول على أمثلة للاستخدام الصحيح وغير الصحيح لهذه الطريقة.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// يحول إلى `Arc<T>`.
    ///
    /// # Safety
    ///
    /// كما هو الحال مع [`MaybeUninit::assume_init`] ، فإن الأمر متروك للمتصل لضمان أن القيمة الداخلية بالفعل في حالة تهيئة.
    ///
    /// يؤدي استدعاء هذا في حالة عدم تهيئة المحتوى بشكل كامل إلى حدوث سلوك فوري غير محدد.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // التهيئة المؤجلة:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// يحول إلى `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// كما هو الحال مع [`MaybeUninit::assume_init`] ، فإن الأمر متروك للمتصل لضمان أن القيمة الداخلية بالفعل في حالة تهيئة.
    ///
    /// يؤدي استدعاء هذا في حالة عدم تهيئة المحتوى بشكل كامل إلى حدوث سلوك فوري غير محدد.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // التهيئة المؤجلة:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// يستهلك `Arc` ، ويعيد المؤشر المغلف.
    ///
    /// لتجنب حدوث تسرب للذاكرة ، يجب تحويل المؤشر مرة أخرى إلى `Arc` باستخدام [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// يوفر مؤشرًا أوليًا للبيانات.
    ///
    /// لا تتأثر التهم بأي شكل من الأشكال ولا يتم استهلاك `Arc`.
    /// المؤشر صالح طالما أن هناك تعدادات قوية في `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // الأمان: لا يمكن أن يمر هذا عبر Deref::deref أو RcBoxPtr::inner بسبب
        // هذا مطلوب للاحتفاظ بمصدر raw/mut مثل
        // `get_mut` يمكن الكتابة من خلال المؤشر بعد استعادة Rc من خلال `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// تنشئ `Arc<T>` من مؤشر خام.
    ///
    /// يجب أن يكون المؤشر الأولي قد تم إرجاعه مسبقًا عن طريق استدعاء [`Arc<U>::into_raw`][into_raw] حيث يجب أن يكون لـ `U` نفس الحجم والمحاذاة مثل `T`.
    /// هذا صحيح إلى حد ما إذا كان `U` هو `T`.
    /// لاحظ أنه إذا لم يكن `U` هو `T` ولكن له نفس الحجم والمحاذاة ، فهذا يشبه في الأساس نقل المراجع من أنواع مختلفة.
    /// راجع [`mem::transmute`][transmute] للحصول على مزيد من المعلومات حول القيود المطبقة في هذه الحالة.
    ///
    /// يتعين على مستخدم `from_raw` التأكد من إسقاط قيمة محددة لـ `T` مرة واحدة فقط.
    ///
    /// هذه الوظيفة غير آمنة لأن الاستخدام غير السليم قد يؤدي إلى عدم أمان الذاكرة ، حتى إذا لم يتم الوصول إلى `Arc<T>` الذي تم إرجاعه مطلقًا.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // قم بالتحويل مرة أخرى إلى `Arc` لمنع التسرب.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // قد تكون المكالمات الإضافية إلى `Arc::from_raw(x_ptr)` غير آمنة للذاكرة.
    /// }
    ///
    /// // تم تحرير الذاكرة عندما خرج `x` عن النطاق أعلاه ، لذا فإن `x_ptr` يتدلى الآن!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // اعكس الإزاحة للعثور على ArcInner الأصلي.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// ينشئ مؤشر [`Weak`] جديدًا لهذا التخصيص.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // هذا "الاسترخاء" لا بأس به لأننا نتحقق من القيمة في CAS أدناه.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // تحقق مما إذا كان العداد الضعيف هو "locked" حاليًا ؛إذا كان الأمر كذلك ، تدور.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: يتجاهل هذا الرمز حاليًا إمكانية تجاوز السعة
            // في usize::MAX ؛بشكل عام ، يجب تعديل كل من Rc و Arc للتعامل مع الفائض.
            //

            // على عكس Clone() ، نحتاج إلى أن يكون هذا قراءة اكتساب للمزامنة مع الكتابة القادمة من `is_unique` ، بحيث تحدث الأحداث السابقة لهذا الكتابة قبل هذه القراءة.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // تأكد من أننا لا نخلق ضعيفًا متدليًا
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// الحصول على عدد مؤشرات [`Weak`] لهذا التخصيص.
    ///
    /// # Safety
    ///
    /// هذه الطريقة في حد ذاتها آمنة ، لكن استخدامها بشكل صحيح يتطلب عناية إضافية.
    /// يمكن أن يؤدي مؤشر ترابط آخر إلى تغيير العد الضعيف في أي وقت ، بما في ذلك بين استدعاء هذه الطريقة والعمل على النتيجة.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // هذا التأكيد حتمي لأننا لم نشارك `Arc` أو `Weak` بين سلاسل العمليات.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // إذا كان العد الضعيف مغلقًا حاليًا ، فإن قيمة العد كانت 0 قبل أخذ القفل مباشرة.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// الحصول على عدد مؤشرات (`Arc`) القوية لهذا التخصيص.
    ///
    /// # Safety
    ///
    /// هذه الطريقة في حد ذاتها آمنة ، لكن استخدامها بشكل صحيح يتطلب عناية إضافية.
    /// يمكن أن يغير مؤشر ترابط آخر العد القوي في أي وقت ، بما في ذلك بين استدعاء هذه الطريقة والعمل على النتيجة.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // هذا التأكيد حتمي لأننا لم نشارك `Arc` بين سلاسل العمليات.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// يعمل على زيادة عدد المرجع القوي على `Arc<T>` المرتبط بالمؤشر المقدم بمقدار واحد.
    ///
    /// # Safety
    ///
    /// يجب الحصول على المؤشر من خلال `Arc::into_raw` ، ويجب أن يكون مثيل `Arc` المرتبط صالحًا (على سبيل المثال
    /// يجب أن يكون العد القوي على الأقل 1) طوال مدة هذه الطريقة.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // هذا التأكيد حتمي لأننا لم نشارك `Arc` بين سلاسل العمليات.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // احتفظ بـ Arc ، لكن لا تلمس إعادة العد عن طريق الالتفاف في ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // الآن قم بزيادة refcount ، ولكن لا تقم بإسقاط refcount الجديد أيضًا
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// يقلل عدد المرجع القوي على `Arc<T>` المرتبط بالمؤشر المقدم بواحد.
    ///
    /// # Safety
    ///
    /// يجب الحصول على المؤشر من خلال `Arc::into_raw` ، ويجب أن يكون مثيل `Arc` المرتبط صالحًا (على سبيل المثال
    /// يجب أن يكون العد القوي على الأقل 1) عند استدعاء هذه الطريقة.
    /// يمكن استخدام هذه الطريقة لتحرير `Arc` النهائي وتخزين النسخ الاحتياطي ، ولكن **لا ينبغي أن يتم استدعاؤها** بعد إصدار `Arc` النهائي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // هذه التأكيدات حتمية لأننا لم نشارك `Arc` بين سلاسل العمليات.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // هذا عدم الأمان على ما يرام لأنه بينما يكون هذا القوس على قيد الحياة ، فإننا نضمن أن المؤشر الداخلي صالح.
        // علاوة على ذلك ، نحن نعلم أن بنية `ArcInner` نفسها هي `Sync` لأن البيانات الداخلية هي `Sync` أيضًا ، لذلك نحن على ما يرام بإعارة مؤشر غير قابل للتغيير لهذه المحتويات.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // جزء غير مضمن من `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // قم بتدمير البيانات في هذا الوقت ، على الرغم من أننا قد لا نحرر تخصيص المربع نفسه (قد لا تزال هناك مؤشرات ضعيفة حولها).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // إسقاط المرجع الضعيف بشكل جماعي من قبل جميع المراجع القوية
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// تُرجع `true` إذا كان الحرفان "Arc" يشيران إلى نفس التخصيص (في وريد مشابه لـ [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// يخصص `ArcInner<T>` بمساحة كافية لقيمة داخلية غير بحجم محتمل حيث تم توفير التخطيط للقيمة.
    ///
    /// يتم استدعاء الوظيفة `mem_to_arcinner` بمؤشر البيانات ويجب أن تعيد مؤشرًا (يحتمل أن يكون سمينًا) لـ `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // حساب التخطيط باستخدام تخطيط القيمة المحدد.
        // في السابق ، تم حساب التخطيط على التعبير `&*(ptr as* const ArcInner<T>)` ، ولكن هذا أدى إلى إنشاء مرجع غير محاذي (انظر #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// يخصص `ArcInner<T>` بمساحة كافية لقيمة داخلية غير بحجم محتمل حيث تم توفير التخطيط للقيمة ، ويعيد خطأ إذا فشل التخصيص.
    ///
    ///
    /// يتم استدعاء الوظيفة `mem_to_arcinner` بمؤشر البيانات ويجب أن تعيد مؤشرًا (يحتمل أن يكون سمينًا) لـ `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // حساب التخطيط باستخدام تخطيط القيمة المحدد.
        // في السابق ، تم حساب التخطيط على التعبير `&*(ptr as* const ArcInner<T>)` ، ولكن هذا أدى إلى إنشاء مرجع غير محاذي (انظر #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // تهيئة ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// يخصص `ArcInner<T>` بمساحة كافية لقيمة داخلية غير بحجم.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // قم بتخصيص `ArcInner<T>` باستخدام القيمة المحددة.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // انسخ القيمة على هيئة بايت
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // حرر التخصيص دون إسقاط محتوياته
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// يخصص `ArcInner<[T]>` بالطول المحدد.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// انسخ العناصر من الشريحة إلى القوس المخصص حديثًا <\[T\]>
    ///
    /// غير آمن لأن المتصل يجب أن يأخذ الملكية أو يلتزم `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// تنشئ `Arc<[T]>` من مكرر معروف بحجم معين.
    ///
    /// السلوك غير محدد إذا كان الحجم خاطئًا.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // حماية Panic أثناء استنساخ عناصر T.
        // في حالة وجود panic ، سيتم إسقاط العناصر التي تمت كتابتها في ArcInner الجديد ، ثم يتم تحرير الذاكرة.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // المؤشر إلى العنصر الأول
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // كله واضح.انسَ الحارس حتى لا يحرر ArcInner الجديد.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// تخصص trait المستخدم لـ `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// يقوم بعمل نسخة من المؤشر `Arc`.
    ///
    /// يؤدي هذا إلى إنشاء مؤشر آخر لنفس التخصيص ، مما يؤدي إلى زيادة عدد المراجع القوية.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // لا بأس باستخدام ترتيب مريح هنا ، لأن معرفة المرجع الأصلي يمنع سلاسل الرسائل الأخرى من حذف الكائن عن طريق الخطأ.
        //
        // كما هو موضح في [Boost documentation][1] ، يمكن دائمًا زيادة العداد المرجعي باستخدام memory_order_relaxed: لا يمكن تكوين المراجع الجديدة لكائن إلا من مرجع موجود ، ويجب أن يوفر تمرير مرجع موجود من مؤشر ترابط إلى آخر أي مزامنة مطلوبة بالفعل.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // ومع ذلك ، نحن بحاجة للحماية من عمليات إعادة الحساب الضخمة في حالة ما إذا كان شخص ما "mem: : forget`ing" Arcs.
        // إذا لم نفعل ذلك ، فقد يتجاوز العدد وسيستخدمه المستخدمون مجانًا.
        // نحن نشبع بشكل كبير إلى `isize::MAX` على افتراض أنه لا يوجد ~2 مليار من الخيوط التي تزيد من العدد المرجعي مرة واحدة.
        //
        // لن يتم أخذ branch هذا في أي برنامج واقعي.
        //
        // نحن نجهض لأن مثل هذا البرنامج متدهور بشكل لا يصدق ، ولا نهتم بدعمه.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// يجعل مرجعًا متغيرًا في `Arc` المحدد.
    ///
    /// إذا كانت هناك مؤشرات `Arc` أو [`Weak`] أخرى لنفس التخصيص ، فسيقوم `make_mut` بإنشاء تخصيص جديد واستدعاء [`clone`][clone] على القيمة الداخلية لضمان الملكية الفريدة.
    /// يشار إلى هذا أيضًا باسم استنساخ عند الكتابة.
    ///
    /// لاحظ أن هذا يختلف عن سلوك [`Rc::make_mut`] الذي يفصل أي مؤشرات `Weak` متبقية.
    ///
    /// راجع أيضًا [`get_mut`][get_mut] ، والذي سيفشل بدلاً من الاستنساخ.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // لن استنساخ أي شيء
    /// let mut other_data = Arc::clone(&data); // لن استنساخ البيانات الداخلية
    /// *Arc::make_mut(&mut data) += 1;         // استنساخ البيانات الداخلية
    /// *Arc::make_mut(&mut data) += 1;         // لن استنساخ أي شيء
    /// *Arc::make_mut(&mut other_data) *= 2;   // لن استنساخ أي شيء
    ///
    /// // يشير `data` و `other_data` الآن إلى تخصيصات مختلفة.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // لاحظ أننا نحمل مرجعًا قويًا ومرجعًا ضعيفًا.
        // وبالتالي ، فإن إطلاق مرجعنا القوي فقط لن يؤدي في حد ذاته إلى إلغاء تخصيص الذاكرة.
        //
        // استخدم Acquire للتأكد من أننا نرى أي عمليات كتابة إلى `weak` تحدث قبل أن يكتب الإصدار (على سبيل المثال ، decrements) إلى `strong`.
        // نظرًا لأننا نحمل عددًا ضعيفًا ، فليس هناك فرصة لإلغاء تخصيص ArcInner نفسه.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // يوجد مؤشر قوي آخر ، لذلك يجب علينا استنساخه.
            // قم بتخصيص الذاكرة مسبقًا للسماح بكتابة القيمة المستنسخة مباشرةً.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // يكفي ما ورد أعلاه لأن هذا هو تحسين أساسي: نحن نتسابق دائمًا مع إسقاط المؤشرات الضعيفة.
            // أسوأ الحالات ، انتهى بنا الأمر إلى تخصيص قوس جديد دون داع.
            //

            // لقد أزلنا آخر مرجع قوي ، ولكن هناك مراجع ضعيفة إضافية متبقية.
            // سننقل المحتويات إلى قوس جديد ، ونبطل المراجع الضعيفة الأخرى.
            //

            // لاحظ أنه من غير الممكن لقراءة `weak` أن تنتج usize::MAX (على سبيل المثال ، مقفل) ، حيث لا يمكن قفل العدد الضعيف إلا بواسطة مؤشر ترابط ذي مرجع قوي.
            //
            //

            // قم بتجسيد مؤشرنا الضعيف الضمني ، بحيث يمكنه تنظيف ArcInner حسب الحاجة.
            //
            let _weak = Weak { ptr: this.ptr };

            // يمكنه فقط سرقة البيانات ، كل ما تبقى هو الضعف
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // كنا المرجع الوحيد من أي نوع.عثرة احتياطيًا لعدد المرجع القوي.
            //
            this.inner().strong.store(1, Release);
        }

        // كما هو الحال مع `get_mut()` ، فإن عدم الأمان على ما يرام لأن مرجعنا كان إما فريدًا في البداية ، أو أصبح واحدًا عند استنساخ المحتويات.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// تُرجع مرجعًا متغيرًا إلى `Arc` المحدد ، إذا لم تكن هناك مؤشرات `Arc` أو [`Weak`] أخرى لنفس التخصيص.
    ///
    ///
    /// تُرجع [`None`] بخلاف ذلك ، لأنه ليس من الآمن تغيير قيمة مشتركة.
    ///
    /// راجع أيضًا [`make_mut`][make_mut] ، والذي سيحدد [`clone`][clone] القيمة الداخلية عندما تكون هناك مؤشرات أخرى.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // عدم الأمان هذا على ما يرام لأننا نضمن أن المؤشر الذي تم إرجاعه هو المؤشر *الوحيد* الذي سيتم إرجاعه إلى T.
            // يُضمن أن يكون عدد المراجع لدينا هو 1 في هذه المرحلة ، وقد طلبنا أن يكون Arc نفسه `mut` ، لذلك نعيد المرجع الوحيد الممكن إلى البيانات الداخلية.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// تُرجع مرجعًا متغيرًا إلى `Arc` المحدد ، بدون أي فحص.
    ///
    /// راجع أيضًا [`get_mut`] ، وهو آمن ويقوم بالفحوصات المناسبة.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// يجب عدم إلغاء الإشارة إلى أي مؤشرات `Arc` أو [`Weak`] أخرى لنفس التخصيص طوال مدة الاقتراض المرتجع.
    ///
    /// هذا هو الحال بشكل تافه إذا لم توجد مثل هذه المؤشرات ، على سبيل المثال بعد `Arc::new` مباشرة.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // نحن حريصون على *عدم* إنشاء مرجع يغطي حقول "count" ، لأن هذا من شأنه أن يكون اسمًا مستعارًا مع وصول متزامن إلى عدد المراجع (على سبيل المثال
        // بواسطة `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// حدد ما إذا كان هذا هو المرجع الفريد (بما في ذلك المراجع الضعيفة) للبيانات الأساسية.
    ///
    ///
    /// لاحظ أن هذا يتطلب قفل عدد المرجع الضعيف.
    fn is_unique(&mut self) -> bool {
        // قفل عدد المؤشر الضعيف إذا ظهر أننا حامل المؤشر الضعيف الوحيد.
        //
        // تضمن تسمية الاكتساب هنا وجود علاقة تحدث قبل أي عمليات كتابة إلى `strong` (على وجه الخصوص في `Weak::upgrade`) قبل إنقاص عدد `weak` (عبر `Weak::drop` ، والذي يستخدم الإصدار).
        // إذا لم يتم إسقاط المرجع الضعيف الذي تمت ترقيته مطلقًا ، فستفشل CAS هنا لذلك لا نهتم بالمزامنة.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // يجب أن يكون هذا `Acquire` للمزامنة مع إنقاص عداد `strong` في `drop`-الوصول الوحيد الذي يحدث عندما يتم إسقاط أي مرجع باستثناء المرجع الأخير.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // تتم مزامنة كتابة الإصدار هنا مع قراءة في `downgrade` ، مما يمنع بشكل فعال قراءة `strong` أعلاه من الحدوث بعد الكتابة.
            //
            //
            self.inner().weak.store(1, Release); // حرر القفل
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// يسقط `Arc`.
    ///
    /// سيؤدي هذا إلى إنقاص عدد المرجع القوي.
    /// إذا وصل عدد المرجع القوي إلى الصفر ، فإن المراجع الأخرى الوحيدة (إن وجدت) هي [`Weak`] ، لذلك نحن `drop` القيمة الداخلية.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // لا يطبع أي شيء
    /// drop(foo2);   // يطبع "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // نظرًا لأن `fetch_sub` ذري بالفعل ، لا نحتاج إلى المزامنة مع مؤشرات ترابط أخرى إلا إذا كنا سنحذف الكائن.
        // ينطبق هذا المنطق نفسه على `fetch_sub` أدناه على عدد `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // هذا السياج ضروري لمنع إعادة ترتيب استخدام البيانات وحذف البيانات.
        // نظرًا لأنه تم وضع علامة `Release` عليه ، يتزامن تقليل عدد المرجع مع سياج `Acquire` هذا.
        // وهذا يعني أن استخدام البيانات يحدث قبل تقليل العدد المرجعي ، وهو ما يحدث قبل هذا السياج ، والذي يحدث قبل حذف البيانات.
        //
        // كما هو موضح في [Boost documentation][1] ،
        //
        // > من المهم فرض أي وصول محتمل إلى الكائن في واحد
        // > موضوع (من خلال مرجع موجود)*يحدث قبل* الحذف
        // > الكائن في موضوع مختلف.يتم تحقيق ذلك بواسطة "release"
        // > العملية بعد إسقاط مرجع (أي وصول إلى الكائن
        // > من خلال هذا المرجع يجب أن يحدث بوضوح من قبل) ، و
        // > "acquire" العملية قبل حذف الكائن.
        //
        // على وجه الخصوص ، في حين أن محتويات القوس غير قابلة للتغيير عادةً ، فمن الممكن أن يكون لديك كتابات داخلية لشيء مثل Mutex<T>.
        // نظرًا لأنه لا يتم الحصول على كائن المزامنة عند حذفه ، فلا يمكننا الاعتماد على منطق المزامنة الخاص به لجعل عمليات الكتابة في مؤشر الترابط A مرئية لمدمِّر يعمل في مؤشر ترابط B.
        //
        //
        // لاحظ أيضًا أنه من المحتمل أن يتم استبدال سياج الاستحواذ هنا بحمل اكتساب ، مما قد يؤدي إلى تحسين الأداء في المواقف شديدة الخلاف.انظر [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// حاول خفض `Arc<dyn Any + Send + Sync>` إلى نوع ملموس.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// يبني `Weak<T>` جديد ، دون تخصيص أي ذاكرة.
    /// استدعاء [`upgrade`] على قيمة الإرجاع يعطي دائمًا [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// نوع المساعد للسماح بالوصول إلى أعداد المرجع دون إجراء أي تأكيدات حول حقل البيانات.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// إرجاع مؤشر خام إلى الكائن `T` المشار إليه بواسطة `Weak<T>` هذا.
    ///
    /// المؤشر صالح فقط في حالة وجود بعض المراجع القوية.
    /// قد يكون المؤشر متدليًا أو غير محاذي أو حتى [`null`] خلاف ذلك.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // كلاهما يشير إلى نفس الشيء
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // القوي هنا يبقيه على قيد الحياة ، لذلك لا يزال بإمكاننا الوصول إلى الكائن.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // لكن ليس بعد الآن.
    /// // يمكننا عمل weak.as_ptr() ، لكن الوصول إلى المؤشر سيؤدي إلى سلوك غير محدد.
    /// // assert_eq! ("مرحبًا" ، غير آمن {&*weak.as_ptr() }) ؛
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // إذا كان المؤشر متدليًا ، نعيد الحارس مباشرة.
            // لا يمكن أن يكون هذا عنوان حمولة صالحًا ، لأن الحمولة تكون على الأقل محاذاة مثل ArcInner (usize).
            ptr as *const T
        } else {
            // الأمان: إذا كانت قيمة is_dangling خاطئة ، فسيكون المؤشر غير قابل للإشارة.
            // قد يتم إسقاط الحمولة الصافية في هذه المرحلة ، وعلينا الحفاظ على المصدر ، لذلك استخدم معالجة المؤشر الخام.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// يستهلك `Weak<T>` ويحوله إلى مؤشر خام.
    ///
    /// هذا يحول المؤشر الضعيف إلى مؤشر خام ، مع الحفاظ على ملكية مرجع ضعيف واحد (لا يتم تعديل العد الضعيف من خلال هذه العملية).
    /// يمكن إعادته إلى `Weak<T>` مع [`from_raw`].
    ///
    /// تنطبق نفس قيود الوصول إلى هدف المؤشر كما هو الحال مع [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// يحول المؤشر الأولي الذي تم إنشاؤه مسبقًا بواسطة [`into_raw`] مرة أخرى إلى `Weak<T>`.
    ///
    /// يمكن استخدام هذا للحصول على مرجع قوي بأمان (عن طريق الاتصال بـ [`upgrade`] لاحقًا) أو لإلغاء تخصيص العدد الضعيف بإسقاط `Weak<T>`.
    ///
    /// يأخذ ملكية مرجع ضعيف واحد (باستثناء المؤشرات التي تم إنشاؤها بواسطة [`new`] ، حيث لا تمتلك هذه المؤشرات أي شيء ؛ لا تزال الطريقة تعمل عليها).
    ///
    /// # Safety
    ///
    /// يجب أن يكون المؤشر قد نشأ من [`into_raw`] ولا يزال يجب أن يمتلك مرجعًا ضعيفًا محتملاً.
    ///
    /// يُسمح بأن يكون العد القوي 0 في وقت استدعاء هذا.
    /// ومع ذلك ، فإن هذا يأخذ ملكية مرجع ضعيف واحد يتم تمثيله حاليًا كمؤشر خام (لا يتم تعديل العد الضعيف بواسطة هذه العملية) وبالتالي يجب إقرانه باستدعاء سابق لـ [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // إنقاص آخر عدد ضعيف.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // راجع Weak::as_ptr للحصول على سياق حول كيفية اشتقاق مؤشر الإدخال.

        let ptr = if is_dangling(ptr as *mut T) {
            // هذا هو الضعف المتدلي.
            ptr as *mut ArcInner<T>
        } else {
            // خلاف ذلك ، نضمن أن المؤشر جاء من ضعيف غير متشابك.
            // الأمان: من الآمن استدعاء data_offset ، حيث يشير ptr إلى T.
            let offset = unsafe { data_offset(ptr) };
            // وبالتالي ، فإننا نعكس الإزاحة للحصول على RcBox بالكامل.
            // الأمان: نشأ المؤشر من ضعيف ، لذا فإن هذه الإزاحة آمنة.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // الأمان: لقد استعدنا الآن المؤشر الضعيف الأصلي ، لذا يمكننا إنشاء المؤشر الضعيف.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// يحاول ترقية المؤشر `Weak` إلى [`Arc`] ، مما يؤخر إسقاط القيمة الداخلية إذا نجح.
    ///
    ///
    /// تُرجع [`None`] إذا تم إسقاط القيمة الداخلية منذ ذلك الحين.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // دمر كل المؤشرات القوية.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // نستخدم حلقة CAS لزيادة العد القوي بدلاً من fetch_add لأن هذه الوظيفة يجب ألا تأخذ العدد المرجعي من صفر إلى واحد.
        //
        //
        let inner = self.inner()?;

        // تحميل مريح لأن أي كتابة للصفر يمكننا ملاحظتها تترك الحقل في حالة صفر بشكل دائم (لذا فإن قراءة "stale" للصفر جيدة) ، ويتم تأكيد أي قيمة أخرى عبر CAS أدناه.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // شاهد التعليقات في `Arc::clone` لمعرفة سبب قيامنا بذلك (لـ `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // لا بأس في حالة الفشل لأنه ليس لدينا أي توقعات بشأن الحالة الجديدة.
            // يعد الاكتساب ضروريًا لحالة النجاح للمزامنة مع `Arc::new_cyclic` ، عندما يمكن تهيئة القيمة الداخلية بعد إنشاء مراجع `Weak` بالفعل.
            // في هذه الحالة ، نتوقع ملاحظة القيمة التي تمت تهيئتها بالكامل.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // فحص فارغ أعلاه
                Err(old) => n = old,
            }
        }
    }

    /// الحصول على عدد مؤشرات (`Arc`) القوية التي تشير إلى هذا التخصيص.
    ///
    /// إذا تم إنشاء `self` باستخدام [`Weak::new`] ، فسيؤدي ذلك إلى إرجاع 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// الحصول على تقدير تقريبي لعدد مؤشرات `Weak` التي تشير إلى هذا التخصيص.
    ///
    /// إذا تم إنشاء `self` باستخدام [`Weak::new`] ، أو إذا لم تكن هناك مؤشرات قوية متبقية ، فسيؤدي ذلك إلى إرجاع 0.
    ///
    /// # Accuracy
    ///
    /// نظرًا لتفاصيل التنفيذ ، يمكن إيقاف القيمة التي تم إرجاعها بمقدار 1 في أيٍّ من الاتجاهين عندما تقوم سلاسل العمليات الأخرى بمعالجة أي "قوس" أو "ضعيف" يشير إلى نفس التخصيص.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // نظرًا لأننا لاحظنا وجود مؤشر قوي واحد على الأقل بعد قراءة العدد الضعيف ، فإننا نعلم أن المرجع الضعيف الضمني (موجود كلما كانت أي مراجع قوية على قيد الحياة) كان لا يزال موجودًا عندما لاحظنا العدد الضعيف ، وبالتالي يمكننا طرحه بأمان.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// تُرجع `None` عندما يكون المؤشر متدليًا ولا يوجد `ArcInner` مخصص ، (على سبيل المثال ، عندما تم إنشاء `Weak` بواسطة `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // نحن حريصون على *عدم* إنشاء مرجع يغطي حقل "data" ، حيث قد يتم تغيير الحقل بشكل متزامن (على سبيل المثال ، إذا تم إسقاط آخر `Arc` ، فسيتم إسقاط حقل البيانات في مكانه).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// تُرجع `true` إذا كان `الضعيفان يشيران إلى نفس التخصيص (مشابه لـ [`ptr::eq`]) ، أو إذا كان كلاهما لا يشيران إلى أي تخصيص (لأنه تم إنشاؤهما باستخدام `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// نظرًا لأن هذا يقارن المؤشرات ، فهذا يعني أن `Weak::new()` ستساوي بعضها البعض ، على الرغم من أنها لا تشير إلى أي تخصيص.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// مقارنة `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// يقوم بعمل نسخة من المؤشر `Weak` الذي يشير إلى نفس التخصيص.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // شاهد التعليقات في Arc::clone() لمعرفة سبب الاسترخاء.
        // يمكن أن يستخدم هذا الأمر fetch_add (تجاهل القفل) لأن العدد الضعيف مغلق فقط حيث * لا توجد مؤشرات ضعيفة أخرى.
        //
        // (لذلك لا يمكننا تشغيل هذا الرمز في هذه الحالة).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // شاهد التعليقات في Arc::clone() لمعرفة سبب قيامنا بذلك (لـ mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// يبني `Weak<T>` جديد ، دون تخصيص ذاكرة.
    /// استدعاء [`upgrade`] على قيمة الإرجاع يعطي دائمًا [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// يسقط المؤشر `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // لا يطبع أي شيء
    /// drop(foo);        // يطبع "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // إذا اكتشفنا أننا كنا المؤشر الضعيف الأخير ، فقد حان الوقت لإلغاء تخصيص البيانات بالكامل.انظر المناقشة في Arc::drop() حول ترتيب الذاكرة
        //
        // ليس من الضروري التحقق من حالة القفل هنا ، لأنه لا يمكن قفل العدد الضعيف إلا إذا كان هناك مرجع ضعيف واحد على وجه التحديد ، مما يعني أن هذا الانخفاض يمكن تشغيله لاحقًا فقط في ذلك المرجع الضعيف المتبقي ، والذي يمكن أن يحدث فقط بعد تحرير القفل.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// نحن نقوم بهذا التخصص هنا ، وليس كتحسين أكثر عمومية على `&T` ، لأنه بخلاف ذلك سيضيف تكلفة لجميع عمليات التحقق من المساواة في المراجع.
/// نحن نفترض أن "Arc" تُستخدم لتخزين القيم الكبيرة التي تكون بطيئة في الاستنساخ ، ولكنها أيضًا ثقيلة للتحقق من المساواة ، مما يؤدي إلى دفع هذه التكلفة بسهولة أكبر.
///
/// من المرجح أيضًا أن يكون لديك نسختان من `Arc` ، تشير إلى نفس القيمة ، أكثر من نسختين `&T.
///
/// لا يمكننا القيام بذلك إلا عندما يكون `T: Eq` باعتباره `PartialEq` غير منعكس عن عمد.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// المساواة بين قوسين.
    ///
    /// يتساوى "قوس" إذا تساوت قيمهما الداخلية ، حتى لو تم تخزينهما في تخصيص مختلف.
    ///
    /// إذا قام `T` أيضًا بتنفيذ `Eq` (مما يعني انعكاسية المساواة) ، فإن اثنين من "القوس" اللذين يشيران إلى نفس التخصيص متساويان دائمًا.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// عدم المساواة لقسمين "قوس".
    ///
    /// اثنان من "القوس" غير متساويين إذا كانت قيمهما الداخلية غير متساوية.
    ///
    /// إذا قام `T` أيضًا بتنفيذ `Eq` (مما يعني انعكاسية المساواة) ، فإن اثنين من "القوس" اللذين يشيران إلى نفس القيمة لن يكونا غير متكافئين أبدًا.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// مقارنة جزئية لاثنين من "القوس".
    ///
    /// تتم مقارنة الاثنين عن طريق استدعاء `partial_cmp()` على قيمهما الداخلية.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// أقل من المقارنة بين "قوسين".
    ///
    /// تتم مقارنة الاثنين عن طريق استدعاء `<` على قيمهما الداخلية.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// مقارنة بين "أقل من أو يساوي" بين "قوسين".
    ///
    /// تتم مقارنة الاثنين عن طريق استدعاء `<=` على قيمهما الداخلية.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// أكبر من المقارنة بين "قوسين".
    ///
    /// تتم مقارنة الاثنين عن طريق استدعاء `>` على قيمهما الداخلية.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// مقارنة "أكبر من أو يساوي" بين "قوسين".
    ///
    /// تتم مقارنة الاثنين عن طريق استدعاء `>=` على قيمهما الداخلية.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// مقارنة بين اثنين من "قوس".
    ///
    /// تتم مقارنة الاثنين عن طريق استدعاء `cmp()` على قيمهما الداخلية.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// ينشئ `Arc<T>` جديدًا بقيمة `Default` لـ `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// قم بتخصيص شريحة معدودة بالمرجع واملأها عن طريق استنساخ عناصر `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// قم بتخصيص `str` ذي المرجع ونسخ `v` فيه.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// قم بتخصيص `str` ذي المرجع ونسخ `v` فيه.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// انقل كائنًا محاصرًا إلى تخصيص جديد محسوب بالمرجع.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// قم بتخصيص شريحة تم عدها بالمرجع وانقل عناصر `v` إليها.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // اسمح لـ Vec بتحرير ذاكرتها ، ولكن لا تدمر محتوياتها
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// يأخذ كل عنصر في `Iterator` ويجمعه في `Arc<[T]>`.
    ///
    /// # خصائص الأداء
    ///
    /// ## الحالة العامة
    ///
    /// في الحالة العامة ، يتم التجميع في `Arc<[T]>` عن طريق التجميع أولاً في `Vec<T>`.أي عند كتابة ما يلي:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// هذا يتصرف كما لو كتبنا:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // تحدث المجموعة الأولى من عمليات التخصيص هنا.
    ///     .into(); // يحدث تخصيص ثانٍ لـ `Arc<[T]>` هنا.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// سيخصص هذا عدة مرات حسب الحاجة لإنشاء `Vec<T>` وبعد ذلك سيتم تخصيصه مرة واحدة لتحويل `Vec<T>` إلى `Arc<[T]>`.
    ///
    ///
    /// ## التكرارات ذات الطول المعروف
    ///
    /// عندما يقوم `Iterator` بتنفيذ `TrustedLen` ويكون بحجم دقيق ، سيتم تخصيص تخصيص واحد لـ `Arc<[T]>`.على سبيل المثال:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // فقط تخصيص واحد يحدث هنا.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// تخصص trait يستخدم للتجميع في `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // هذا هو الحال بالنسبة لمكرر `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // الأمان: نحتاج إلى التأكد من أن المكرر له طول دقيق ولدينا.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // العودة إلى التنفيذ العادي.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// احصل على الإزاحة داخل `ArcInner` للحمولة خلف المؤشر.
///
/// # Safety
///
/// يجب أن يشير المؤشر إلى (وأن يحتوي على بيانات وصفية صالحة) لمثيل صالح سابقًا لـ T ، ولكن يُسمح بإسقاط حرف T.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // قم بمحاذاة القيمة غير الحجم مع نهاية ArcInner.
    // نظرًا لأن RcBox هو repr(C) ، فسيكون دائمًا الحقل الأخير في الذاكرة.
    // الأمان: نظرًا لأن الأنواع الوحيدة غير الحجم الممكنة هي الشرائح ، وكائنات trait ،
    // والأنواع الخارجية ، فإن متطلبات أمان المدخلات كافية حاليًا لتلبية متطلبات align_of_val_raw ؛هذه تفاصيل تنفيذية للغة لا يمكن الاعتماد عليها خارج std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}