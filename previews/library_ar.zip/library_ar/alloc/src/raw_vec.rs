#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// محتويات الذاكرة الجديدة غير مهيأة.
    Uninitialized,
    /// الذاكرة الجديدة مضمونة للصفر.
    Zeroed,
}

/// أداة مساعدة منخفضة المستوى لتخصيص ، وإعادة تخصيص ، وإلغاء تخصيص مخزن مؤقت للذاكرة بشكل مريح على الكومة دون الحاجة إلى القلق بشأن جميع حالات الركن المعنية.
///
/// هذا النوع ممتاز لبناء هياكل البيانات الخاصة بك مثل Vec و VecDeque.
/// خاصه:
///
/// * تنتج `Unique::dangling()` على أنواع ذات حجم صفري.
/// * تنتج `Unique::dangling()` على عمليات تخصيص ذات طول صفري.
/// * يتجنب تحرير `Unique::dangling()`.
/// * يلتقط جميع الفائض في حسابات السعة (يقوم بترقيتها إلى "capacity overflow" panics).
/// * الحماية من أنظمة 32 بت التي تخصص أكثر من isize::MAX بايت.
/// * يحمي من تفيض طولك.
/// * يستدعي `handle_alloc_error` للحصول على تخصيصات غير معصومة.
/// * يحتوي على `ptr::Unique` وبالتالي يمنح المستخدم جميع المزايا ذات الصلة.
/// * يستخدم الفائض العائد من المخصص لاستخدام أكبر سعة متاحة.
///
/// هذا النوع لا يفحص بأي حال الذاكرة التي يديرها.عندما يتم إسقاطها *ستحرر ذاكرتها ، لكنها* لن * تحاول إسقاط محتوياتها.
/// الأمر متروك لمستخدم `RawVec` للتعامل مع الأشياء الفعلية *المخزنة* داخل `RawVec`.
///
/// لاحظ أن الزيادة في الأنواع ذات الحجم الصفري دائمًا ما تكون لانهائية ، لذلك تقوم `capacity()` دائمًا بإرجاع `usize::MAX`.
/// هذا يعني أنك بحاجة إلى توخي الحذر عند القيام بجولة في هذا النوع باستخدام `Box<[T]>` ، نظرًا لأن `capacity()` لن ينتج عنه الطول.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): هذا موجود لأن `#[unstable]` `const fn`s لا تحتاج إلى التوافق مع `min_const_fn` وبالتالي لا يمكن استدعاؤها في`min_const_fn`s أيضًا.
    ///
    /// إذا قمت بتغيير `RawVec<T>::new` أو التبعيات ، فالرجاء الحرص على عدم إدخال أي شيء ينتهك حقًا `min_const_fn`.
    ///
    /// NOTE: يمكننا تجنب هذا الاختراق والتحقق من التوافق مع بعض سمات `#[rustc_force_min_const_fn]` التي تتطلب التوافق مع `min_const_fn` ولكنها لا تسمح بالضرورة باستدعائها في `stable(...) const fn`/رمز المستخدم لا يمكّن `foo` عندما يكون `#[rustc_const_unstable(feature = "foo", issue = "01234")]` موجودًا.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// ينشئ أكبر `RawVec` ممكن (على كومة النظام) دون تخصيص.
    /// إذا كان `T` بحجم موجب ، فهذا يجعل `RawVec` بسعة `0`.
    /// إذا كان `T` بحجم صفري ، فإنه يصنع `RawVec` بسعة `usize::MAX`.
    /// مفيد لتنفيذ التخصيص المتأخر.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// ينشئ `RawVec` (على كومة النظام) بالسعة ومتطلبات المحاذاة تمامًا لـ `[T; capacity]`.
    /// هذا يعادل استدعاء `RawVec::new` عندما يكون `capacity` هو `0` أو `T` بحجم صفري.
    /// لاحظ أنه إذا كان `T` بحجم صفري ، فهذا يعني أنك لن * * تحصل على `RawVec` بالسعة المطلوبة.
    ///
    /// # Panics
    ///
    /// Panics إذا تجاوزت السعة المطلوبة `isize::MAX` بايت.
    ///
    /// # Aborts
    ///
    /// يجهض في OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// مثل `with_capacity` ، لكنه يضمن أن المخزن المؤقت صفري.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// يعيد تكوين `RawVec` من المؤشر والسعة.
    ///
    /// # Safety
    ///
    /// يجب تخصيص `ptr` (على كومة النظام) ، وباستخدام `capacity` المحدد.
    /// لا يمكن أن يتجاوز `capacity` `isize::MAX` لأنواع الأحجام.(فقط مصدر قلق لأنظمة 32 بت).
    /// قد تتمتع ZST vectors بسعة تصل إلى `usize::MAX`.
    /// إذا جاء `ptr` و `capacity` من `RawVec` ، فهذا مضمون.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Tiny Vecs غبية.انتقل إلى:
    // - 8 إذا كان حجم العنصر هو 1 ، لأنه من المحتمل أن يقوم أي مخصصات كومة بتقريب طلب أقل من 8 بايت إلى 8 بايت على الأقل.
    //
    // - 4 إذا كانت العناصر متوسطة الحجم (<=1 كيلوبايت).
    // - 1 بخلاف ذلك ، لتجنب إهدار مساحة كبيرة جدًا لفترات قصيرة جدًا.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// مثل `new` ، ولكن يتم تحديد معلماته على اختيار المخصص لـ `RawVec` الذي تم إرجاعه.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` يعني "unallocated".يتم تجاهل الأنواع ذات الحجم الصفري.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// مثل `with_capacity` ، ولكن يتم تحديد معلماته على اختيار المخصص لـ `RawVec` الذي تم إرجاعه.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// مثل `with_capacity_zeroed` ، ولكن يتم تحديد معلماته على اختيار المخصص لـ `RawVec` الذي تم إرجاعه.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// يحول `Box<[T]>` إلى `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// يحول المخزن المؤقت بالكامل إلى `Box<[MaybeUninit<T>]>` باستخدام `len` المحدد.
    ///
    /// لاحظ أن هذا سيعيد تكوين أي تغييرات `cap` التي ربما تم إجراؤها بشكل صحيح.(انظر وصف النوع للحصول على التفاصيل.)
    ///
    /// # Safety
    ///
    /// * `len` يجب أن تكون أكبر من أو تساوي أحدث سعة مطلوبة ، و
    /// * `len` يجب أن تكون أقل من أو تساوي `self.capacity()`.
    ///
    /// لاحظ أن السعة المطلوبة و `self.capacity()` يمكن أن تختلف ، حيث يمكن للمخصص زيادة المساحة وإرجاع كتلة ذاكرة أكبر من المطلوب.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // تحقق من صحة نصف متطلبات السلامة (لا يمكننا التحقق من النصف الآخر).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // نتجنب `unwrap_or_else` هنا لأنه ينفخ كمية LLVM IR المتولدة.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// يعيد تكوين `RawVec` من مؤشر وسعة ومخصص.
    ///
    /// # Safety
    ///
    /// يجب تخصيص `ptr` (عبر المخصص المحدد `alloc`) ، ومع `capacity` المحدد.
    /// لا يمكن أن يتجاوز `capacity` `isize::MAX` لأنواع الأحجام.
    /// (فقط مصدر قلق لأنظمة 32 بت).
    /// قد تتمتع ZST vectors بسعة تصل إلى `usize::MAX`.
    /// إذا جاء `ptr` و `capacity` من `RawVec` تم إنشاؤه عبر `alloc` ، فهذا مضمون.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// يحصل على مؤشر خام لبداية التخصيص.
    /// لاحظ أن هذا هو `Unique::dangling()` إذا كان `capacity == 0` أو `T` بحجم صفري.
    /// في الحالة الأولى ، يجب أن تكون حذرًا.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// يحصل على قدرة التخصيص.
    ///
    /// سيكون هذا دائمًا `usize::MAX` إذا كان `T` بحجم صفر.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// إرجاع مرجع مشترك للمخصص الذي يدعم `RawVec` هذا.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // لدينا جزء مخصص من الذاكرة ، حتى نتمكن من تجاوز فحوصات وقت التشغيل للحصول على تخطيطنا الحالي.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// يضمن احتواء المخزن المؤقت على مساحة كافية على الأقل لاستيعاب عناصر `len + additional`.
    /// إذا لم يكن لديها سعة كافية بالفعل ، فسيتم إعادة تخصيص مساحة كافية بالإضافة إلى مساحة مريحة مريحة لاستهلاك سلوك *O*(1).
    ///
    /// سوف يحد من هذا السلوك إذا كان سيؤدي إلى panic دون داع.
    ///
    /// إذا تجاوز `len` `self.capacity()` ، فقد يفشل ذلك في تخصيص المساحة المطلوبة بالفعل.
    /// هذا ليس غير آمن حقًا ، ولكن قد يتعطل الرمز غير الآمن *الذي تكتبه* والذي يعتمد على سلوك هذه الوظيفة.
    ///
    /// هذا مثالي لتنفيذ عملية الدفع الجماعي مثل `extend`.
    ///
    /// # Panics
    ///
    /// Panics إذا تجاوزت السعة الجديدة `isize::MAX` بايت.
    ///
    /// # Aborts
    ///
    /// يجهض في OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // كان الاحتياطي قد تم إجهاضه أو ذعره إذا تجاوز len `isize::MAX` ، لذلك من الآمن القيام بذلك دون رادع الآن.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// مثل `reserve` ، لكنه يعود عند حدوث أخطاء بدلاً من الذعر أو الإحباط.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// يضمن احتواء المخزن المؤقت على مساحة كافية على الأقل لاستيعاب عناصر `len + additional`.
    /// إذا لم يحدث ذلك بالفعل ، فسيتم إعادة تخصيص الحد الأدنى من الذاكرة اللازمة.
    /// بشكل عام ، سيكون هذا هو مقدار الذاكرة اللازمة بالضبط ، ولكن من حيث المبدأ ، يكون المخصص حرًا في رد أكثر مما طلبناه.
    ///
    ///
    /// إذا تجاوز `len` `self.capacity()` ، فقد يفشل ذلك في تخصيص المساحة المطلوبة بالفعل.
    /// هذا ليس غير آمن حقًا ، ولكن قد يتعطل الرمز غير الآمن *الذي تكتبه* والذي يعتمد على سلوك هذه الوظيفة.
    ///
    /// # Panics
    ///
    /// Panics إذا تجاوزت السعة الجديدة `isize::MAX` بايت.
    ///
    /// # Aborts
    ///
    /// يجهض في OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// مثل `reserve_exact` ، لكنه يعود عند حدوث أخطاء بدلاً من الذعر أو الإحباط.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// تقليص التخصيص إلى المقدار المحدد.
    /// إذا كان المبلغ المحدد هو 0 ، في الواقع يتم إلغاء التخصيص بالكامل.
    ///
    /// # Panics
    ///
    /// Panics إذا كانت الكمية المعطاة *أكبر* من السعة الحالية.
    ///
    /// # Aborts
    ///
    /// يجهض في OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// يعود إذا كان المخزن المؤقت بحاجة إلى النمو لتلبية السعة الإضافية المطلوبة.
    /// تُستخدم بشكل أساسي لإجراء مكالمات حجز مضمنة ممكنة دون تضمين `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // عادة ما يتم إنشاء مثيل لهذه الطريقة عدة مرات.لذلك نريد أن تكون صغيرة قدر الإمكان ، لتحسين أوقات الترجمة.
    // لكننا نريد أيضًا أن تكون محتوياتها قابلة للحساب بشكل ثابت قدر الإمكان ، لجعل الكود الذي تم إنشاؤه يعمل بشكل أسرع.
    // لذلك ، تمت كتابة هذه الطريقة بعناية بحيث تكون كل التعليمات البرمجية التي تعتمد على `T` بداخلها ، في حين أن أكبر قدر ممكن من الشفرة التي لا تعتمد على `T` قدر الإمكان في وظائف غير عامة فوق `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // يتم ضمان ذلك من خلال سياقات الاستدعاء.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // نظرًا لأننا نعيد سعة `usize::MAX` عندما يكون `elem_size`
            // 0 ، الوصول إلى هنا يعني بالضرورة أن `RawVec` ممتلئ.
            return Err(CapacityOverflow);
        }

        // لا شيء يمكننا فعله حقًا بشأن هذه الشيكات ، للأسف.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // هذا يضمن النمو المتسارع.
        // لا يمكن أن تتجاوز المضاعفة لأن `cap <= isize::MAX` ونوع `cap` هو `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` غير عام على `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // القيود المفروضة على هذه الطريقة مماثلة إلى حد كبير لتلك الموجودة على `grow_amortized` ، ولكن عادةً ما يتم إنشاء مثيل لهذه الطريقة في كثير من الأحيان ، لذا فهي أقل أهمية.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // نظرًا لأننا نعيد سعة `usize::MAX` عندما يكون حجم النوع
            // 0 ، الوصول إلى هنا يعني بالضرورة أن `RawVec` ممتلئ.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` غير عام على `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// هذه الوظيفة خارج `RawVec` لتقليل أوقات الترجمة.انظر التعليق أعلاه `RawVec::grow_amortized` للحصول على التفاصيل.
// (المعلمة `A` ليست مهمة ، لأن عدد أنواع `A` المختلفة التي تظهر في الممارسة أقل بكثير من عدد أنواع `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // تحقق من الخطأ هنا لتقليل حجم `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // يتحقق المخصص من مساواة المحاذاة
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// يحرر الذاكرة التي يمتلكها `RawVec`*دون محاولة* إسقاط محتوياتها.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// وظيفة مركزية لمعالجة الأخطاء الاحتياطية.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// نحتاج إلى ضمان ما يلي:
// * لا نخصص أبدًا كائنات بحجم `> isize::MAX` بايت.
// * نحن لا نتجاوز `usize::MAX` ونخصص القليل جدًا في الواقع.
//
// في 64 بت ، نحتاج فقط إلى التحقق من وجود تجاوز لأن محاولة تخصيص `> isize::MAX` بايت ستفشل بالتأكيد.
// في الإصدارين 32 بت و 16 بت ، نحتاج إلى إضافة حماية إضافية لهذا في حالة تشغيلنا على نظام أساسي يمكنه استخدام كل 4 غيغابايت في مساحة المستخدم ، على سبيل المثال ، PAE أو x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// وظيفة مركزية واحدة مسؤولة عن الإبلاغ عن فائض القدرات.
// سيضمن هذا أن إنشاء الكود المرتبط بـ panics ضئيل للغاية نظرًا لوجود موقع واحد فقط وهو panics بدلاً من مجموعة في جميع أنحاء الوحدة النمطية.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}