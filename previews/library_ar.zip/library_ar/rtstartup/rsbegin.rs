// rsbegin.o و rsend.o هي ما يسمى "compiler runtime startup objects".
// أنها تحتوي على التعليمات البرمجية اللازمة لتهيئة وقت تشغيل المترجم بشكل صحيح.
//
// عندما يتم ربط صورة قابلة للتنفيذ أو dylib ، تكون جميع التعليمات البرمجية والمكتبات الخاصة بالمستخدم "sandwiched" بين هذين الملفين الكائنين ، لذلك تصبح التعليمات البرمجية أو البيانات من rsbegin.o الأولى في الأقسام المعنية من الصورة ، بينما تصبح التعليمات البرمجية والبيانات من rsend.o هي الأخيرة.
// يمكن استخدام هذا التأثير لوضع الرموز في بداية القسم أو في نهايته ، وكذلك لإدراج أي رؤوس أو تذييلات مطلوبة.
//
// لاحظ أن نقطة إدخال الوحدة الفعلية تقع في كائن بدء تشغيل C (عادةً ما يسمى `crtX.o`) ، والذي يستدعي بعد ذلك عمليات إعادة الاتصال التهيئة لمكونات وقت التشغيل الأخرى (المسجلة عبر قسم صورة خاص آخر).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // يشير إلى بداية قسم معلومات فك إطار المكدس
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // مساحة خدش لحفظ الدفاتر الداخلية لفك اللفة.
    // يتم تعريف هذا على أنه `struct object` في $ GCC/relax-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // استرخِ إجراءات معلومات registration/deregistration.
    // راجع مستندات libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // تسجيل معلومات استرخاء عند بدء تشغيل الوحدة
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // إلغاء التسجيل عند الإغلاق
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // تسجيل روتين init/uninit الخاص بـ MinGW
    pub mod mingw_init {
        // ستستدعي كائنات بدء تشغيل MinGW (crt0.o/dllcrt0.o) المُنشئين العامين في أقسام .ctors و .dtors عند بدء التشغيل والخروج.
        // في حالة مكتبات DLL ، يتم ذلك عندما يتم تحميل DLL وإلغاء تحميله.
        //
        // سيقوم الرابط بفرز الأقسام ، مما يضمن وجود عمليات الاسترجاعات الخاصة بنا في نهاية القائمة.
        // نظرًا لأنه يتم تشغيل المُنشئين بترتيب عكسي ، فهذا يضمن أن عمليات الاسترجاعات الخاصة بنا هي الأولى والأخيرة التي تم تنفيذها.
        //
        //

        #[link_section = ".ctors.65535"] // . مفاعلات. *: عمليات رد نداء التهيئة C.
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: عمليات رد نداء إنهاء C.
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}