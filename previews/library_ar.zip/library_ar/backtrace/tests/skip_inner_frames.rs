use backtrace::Backtrace;

// يعمل هذا الاختبار فقط على الأنظمة الأساسية التي تعمل بوظيفة `symbol_address` للإطارات التي تُبلغ عن عنوان بداية الرمز.
// نتيجة لذلك ، يتم تمكينه فقط على عدد قليل من الأنظمة الأساسية.
//
const ENABLED: bool = cfg!(all(
    // Windows لم يتم اختباره حقًا ، و OSX لا يدعم البحث الفعلي لإطار مغلق ، لذا قم بتعطيل هذا
    //
    target_os = "linux",
    // في ARM ، فإن العثور على وظيفة التضمين هو ببساطة إرجاع عنوان IP نفسه.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}