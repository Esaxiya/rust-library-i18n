//! وحدة للمساعدة في إدارة ارتباطات dbghelp على Windows
//!
//! يتم تشغيل Backtraces على Windows (على الأقل لـ MSVC) إلى حد كبير من خلال `dbghelp.dll` والوظائف المختلفة التي يحتوي عليها.
//! يتم تحميل هذه الوظائف حاليًا *ديناميكيًا* بدلاً من الارتباط بـ `dbghelp.dll` بشكل ثابت.
//! يتم ذلك حاليًا بواسطة المكتبة القياسية (وهو مطلوب من الناحية النظرية هناك) ، ولكنه محاولة للمساعدة في تقليل تبعيات dll الثابتة للمكتبة نظرًا لأن backtraces عادةً ما تكون اختيارية جدًا.
//!
//! ومع ذلك ، يتم تحميل `dbghelp.dll` دائمًا بنجاح على Windows.
//!
//! لاحظ أنه نظرًا لأننا نقوم بتحميل كل هذا الدعم ديناميكيًا ، فلا يمكننا في الواقع استخدام التعريفات الأولية في `winapi` ، ولكننا نحتاج إلى تحديد أنواع مؤشر الوظيفة بأنفسنا واستخدامها.
//! لا نريد حقًا أن نكون في مجال نسخ Winapi ، لذلك لدينا ميزة Cargo `verify-winapi` التي تؤكد أن جميع الارتباطات تتطابق مع تلك الموجودة في Winapi ويتم تمكين هذه الميزة على CI.
//!
//! أخيرًا ، ستلاحظ هنا أن dll الخاص بـ `dbghelp.dll` لا يتم تفريغه أبدًا ، وهذا أمر مقصود حاليًا.
//! يتمثل التفكير في أنه يمكننا تخزينه مؤقتًا واستخدامه بين عمليات الاستدعاء لواجهة برمجة التطبيقات ، وتجنب loads/unloads باهظ الثمن.
//! إذا كانت هذه مشكلة في أجهزة كشف التسرب أو شيء من هذا القبيل ، فيمكننا عبور الجسر عندما نصل إلى هناك.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// العمل حول `SymGetOptions` و `SymSetOptions` غير موجود في Winapi نفسه.
// بخلاف ذلك ، يتم استخدام هذا فقط عندما نتحقق مرة أخرى من الأنواع مقابل winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // لم يتم تعريفها في Winapi حتى الآن
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // تم تعريف هذا في Winapi ، لكنه غير صحيح (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // لم يتم تعريفها في Winapi حتى الآن
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// يستخدم هذا الماكرو لتحديد بنية `Dbghelp` التي تحتوي داخليًا على جميع مؤشرات الوظائف التي قد نقوم بتحميلها.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// تحميل DLL لـ `dbghelp.dll`
            dll: HMODULE,

            // كل مؤشر دالة لكل دالة قد نستخدمها
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // في البداية لم نحمل DLL
            dll: 0 as *mut _,
            // يتم تعيين Initiall جميع الوظائف على الصفر لتقول إنها بحاجة إلى تحميل ديناميكي.
            //
            $($name: 0,)*
        };

        // تعريف محرف مناسب لكل نوع وظيفة.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// يحاول فتح `dbghelp.dll`.
            /// ترجع النجاح إذا نجح أو حدث خطأ إذا فشل `LoadLibraryW`.
            ///
            /// Panics إذا تم تحميل المكتبة بالفعل.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // وظيفة لكل طريقة نرغب في استخدامها.
            // عند استدعائها ، إما أن تقرأ مؤشر الوظيفة المخزنة مؤقتًا أو تقوم بتحميلها وإرجاع القيمة المحملة.
            // تم التأكيد على نجاح الأحمال.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // وكيل ملائم لاستخدام أقفال التنظيف للإشارة إلى وظائف dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// قم بتهيئة كل الدعم اللازم للوصول إلى وظائف واجهة برمجة تطبيقات `dbghelp` من crate.
///
///
/// لاحظ أن هذه الوظيفة **آمنة**، ولها مزامنة خاصة بها داخليًا.
/// لاحظ أيضًا أنه من الآمن استدعاء هذه الوظيفة عدة مرات بشكل متكرر.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // أول شيء علينا القيام به هو مزامنة هذه الوظيفة.يمكن استدعاء هذا بشكل متزامن من خيوط أخرى أو بشكل متكرر داخل سلسلة واحدة.
        // لاحظ أن الأمر أصعب من ذلك لأن ما نستخدمه هنا ، `dbghelp` ،*أيضًا* يحتاج إلى المزامنة مع جميع المتصلين الآخرين بـ `dbghelp` في هذه العملية.
        //
        // عادةً لا توجد بالفعل العديد من المكالمات إلى `dbghelp` في نفس العملية ويمكننا على الأرجح أن نفترض بأمان أننا الوحيدين الذين يصلون إليها.
        // ومع ذلك ، هناك مستخدم أساسي آخر علينا أن نقلق بشأنه ، ومن المفارقات أننا نحن ، ولكن في المكتبة القياسية.
        // تعتمد مكتبة Rust القياسية على crate لدعم backtrace ، وهذا crate موجود أيضًا على crates.io.
        // هذا يعني أنه إذا كانت المكتبة القياسية تطبع panic backtrace ، فقد تتسابق مع crate القادمة من crates.io ، مما يتسبب في حدوث أخطاء.
        //
        // للمساعدة في حل مشكلة المزامنة هذه ، نستخدم خدعة خاصة بـ Windows هنا (فهي ، بعد كل شيء ، قيود خاصة بـ Windows حول المزامنة).
        // نقوم بإنشاء *جلسة محلية* باسم كائن المزامنة (mutex) لحماية هذه المكالمة.
        // القصد هنا هو أن المكتبة القياسية و crate لا يتعين عليهما مشاركة واجهات برمجة التطبيقات على مستوى Rust للمزامنة هنا ولكن يمكن بدلاً من ذلك العمل خلف الكواليس للتأكد من أنهما متزامنان مع بعضهما البعض.
        //
        // بهذه الطريقة عندما يتم استدعاء هذه الوظيفة من خلال المكتبة القياسية أو من خلال crates.io يمكننا التأكد من الحصول على نفس كائن المزامنة.
        //
        // كل هذا يعني أن أول شيء نقوم به هنا هو إنشاء `HANDLE` ذريًا وهو كائن مزمن مسمى على Windows.
        // نقوم بالمزامنة قليلاً مع مؤشرات الترابط الأخرى التي تشارك هذه الوظيفة على وجه التحديد ونضمن إنشاء مقبض واحد فقط لكل مثيل لهذه الوظيفة.
        // لاحظ أنه لا يتم إغلاق المقبض أبدًا بمجرد تخزينه في الملف العام.
        //
        // بعد أن نذهب بالفعل إلى القفل ، نكتسبه ببساطة ، وسيكون مقبض `Init` الذي سلمناه مسؤولاً عن إسقاطه في النهاية.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // حسنًا ، يا صغار!الآن وقد تمت مزامنتنا جميعًا بأمان ، فلنبدأ بالفعل في معالجة كل شيء.
        // أولاً ، نحتاج إلى التأكد من تحميل `dbghelp.dll` بالفعل في هذه العملية.
        // نقوم بذلك ديناميكيًا لتجنب التبعية الثابتة.
        // تم إجراء هذا تاريخيًا للتغلب على مشكلات الربط الغريبة ويهدف إلى جعل الثنائيات أكثر قابلية للنقل نظرًا لأن هذا هو إلى حد كبير مجرد أداة مساعدة لتصحيح الأخطاء.
        //
        //
        // بمجرد فتح `dbghelp.dll` ، نحتاج إلى استدعاء بعض وظائف التهيئة فيه ، وهذا مفصل أكثر أدناه.
        // نحن نفعل هذا مرة واحدة فقط ، لذلك لدينا قيمة منطقية عالمية تشير إلى ما إذا كنا قد انتهينا من ذلك أم لا.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // تأكد من تعيين علامة `SYMOPT_DEFERRED_LOADS` ، لأنه وفقًا لمستندات MSVC الخاصة بهذا الأمر: "This is the fastest, most efficient way to use the symbol handler." ، فلنقم بذلك!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // في الواقع تهيئة الرموز باستخدام MSVC.لاحظ أن هذا يمكن أن يفشل ، لكننا نتجاهله.
        // لا يوجد الكثير من الأعمال الفنية السابقة لهذا في حد ذاته ، ولكن يبدو أن LLVM داخليًا يتجاهل قيمة الإرجاع هنا وتطبع إحدى مكتبات المطهرات في LLVM تحذيرًا مخيفًا إذا فشل ذلك ولكنه يتجاهله بشكل أساسي على المدى الطويل.
        //
        //
        // هناك حالة واحدة تأتي كثيرًا بالنسبة إلى Rust وهي أن المكتبة القياسية و crate على crates.io يرغبان في التنافس على `SymInitializeW`.
        // أرادت المكتبة القياسية تاريخياً التهيئة ثم التنظيف في معظم الأوقات ، ولكن الآن بعد أن استخدمت crate هذا ، فهذا يعني أن شخصًا ما سيبدأ التهيئة أولاً وسيتلقى الآخر هذه التهيئة.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}