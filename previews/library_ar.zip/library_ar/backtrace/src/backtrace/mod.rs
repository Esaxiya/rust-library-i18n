use core::ffi::c_void;
use core::fmt;

/// يفحص مكدس الاستدعاء الحالي ، ويمرر كل الإطارات النشطة في الإغلاق المتوفر لحساب تتبع المكدس.
///
/// هذه الوظيفة هي العمود الفقري لهذه المكتبة في حساب آثار المكدس لبرنامج.يُعطى الإغلاق المحدد `cb` مثيلات من `Frame` والتي تمثل معلومات حول إطار الاستدعاء هذا على المكدس.
/// يُنتج الإغلاق إطارات بأسلوب تنازلي (يُطلق عليه مؤخرًا اسم الوظائف أولاً).
///
/// قيمة الإرجاع للإغلاق هي إشارة إلى ما إذا كان يجب أن يستمر التتبع الخلفي.ستؤدي القيمة المرجعة لـ `false` إلى إنهاء التتبع الخلفي والعودة على الفور.
///
/// بمجرد الحصول على `Frame` ، من المحتمل أن ترغب في الاتصال بـ `backtrace::resolve` لتحويل `ip` (مؤشر التعليمات) أو عنوان الرمز إلى `Symbol` يمكن من خلاله التعرف على الاسم و/أو اسم الملف/رقم السطر.
///
///
/// لاحظ أن هذه وظيفة ذات مستوى منخفض نسبيًا ، وإذا كنت ترغب ، على سبيل المثال ، في التقاط تتبع خلفي ليتم فحصه لاحقًا ، فقد يكون نوع `Backtrace` أكثر ملاءمة.
///
/// # الميزات المطلوبة
///
/// تتطلب هذه الوظيفة تمكين ميزة `std` الخاصة بـ `backtrace` crate ، ويتم تمكين ميزة `std` افتراضيًا.
///
/// # Panics
///
/// تسعى هذه الوظيفة جاهدة لعدم استخدام panic مطلقًا ، ولكن إذا قدم `cb` panics ، فإن بعض الأنظمة الأساسية ستجبر panic مزدوجًا على إجهاض العملية.
/// تستخدم بعض الأنظمة الأساسية مكتبة C التي تستخدم داخليًا عمليات الاسترجاعات التي لا يمكن التخلص منها ، لذا فإن الذعر من `cb` قد يؤدي إلى إحباط العملية.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // تواصل backtrace
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// مثل `trace` ، غير آمن فقط لأنه غير متزامن.
///
/// لا تحتوي هذه الوظيفة على أدوات ضمان للمزامنة ولكنها متاحة عندما لا يتم تجميع ميزة `std` الخاصة بـ crate.
/// راجع وظيفة `trace` لمزيد من الوثائق والأمثلة.
///
/// # Panics
///
/// راجع المعلومات الخاصة بـ `trace` للحصول على تحذيرات بشأن الذعر `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// يمثل trait إطارًا واحدًا من backtrace ، ينتج عن وظيفة `trace` في crate.
///
/// سيتم إنتاج إطارات لإغلاق وظيفة التتبع ، ويتم إرسال الإطار تقريبًا نظرًا لأن التطبيق الأساسي لا يكون معروفًا دائمًا حتى وقت التشغيل.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// إرجاع مؤشر التعليمات الحالي لهذا الإطار.
    ///
    /// عادةً ما تكون هذه هي التعليمات التالية التي يجب تنفيذها في الإطار ، ولكن ليس كل التطبيقات تسرد ذلك بدقة 100٪ (لكنها قريبة جدًا بشكل عام).
    ///
    ///
    /// يوصى بتمرير هذه القيمة إلى `backtrace::resolve` لتحويلها إلى اسم رمز.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// تُرجع مؤشر المكدس الحالي لهذا الإطار.
    ///
    /// في حالة عدم تمكن الواجهة الخلفية من استرداد مؤشر المكدس لهذا الإطار ، يتم إرجاع مؤشر فارغ.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// تُرجع عنوان رمز البداية لإطار هذه الوظيفة.
    ///
    /// سيحاول هذا إرجاع مؤشر التعليمات الذي تم إرجاعه بواسطة `ip` إلى بداية الوظيفة ، وإرجاع تلك القيمة.
    ///
    /// ومع ذلك ، في بعض الحالات ، ستعيد الخلفيات فقط `ip` من هذه الوظيفة.
    ///
    /// يمكن أحيانًا استخدام القيمة التي تم إرجاعها إذا فشل `backtrace::resolve` في `ip` المذكور أعلاه.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// تُرجع العنوان الأساسي للوحدة النمطية التي ينتمي إليها الإطار.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // يجب أن يأتي هذا أولاً ، للتأكد من أن Miri تأخذ الأولوية على النظام الأساسي المضيف
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // تستخدم فقط في dbghelp ترمز
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}