use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// تمثيل backtrace مملوك ومكتفي بذاته.
///
/// يمكن استخدام هذه البنية لالتقاط backtrace في نقاط مختلفة في البرنامج واستخدامها لاحقًا لفحص ما كان backtrace في ذلك الوقت.
///
///
/// `Backtrace` يدعم الطباعة الجميلة للخلفيات من خلال تطبيق `Debug`.
///
/// # الميزات المطلوبة
///
/// تتطلب هذه الوظيفة تمكين ميزة `std` الخاصة بـ `backtrace` crate ، ويتم تمكين ميزة `std` افتراضيًا.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // الإطارات هنا مدرجة من أعلى إلى أسفل المكدس
    frames: Vec<BacktraceFrame>,
    // نعتقد أن الفهرس هو البداية الفعلية للتتبع الخلفي ، مع حذف الإطارات مثل `Backtrace::new` و `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// نسخة ملتقطة من إطار في backtrace.
///
/// يتم إرجاع هذا النوع كقائمة من `Backtrace::frames` ويمثل إطار مكدس واحد في تتبع خلفي تم التقاطه.
///
/// # الميزات المطلوبة
///
/// تتطلب هذه الوظيفة تمكين ميزة `std` الخاصة بـ `backtrace` crate ، ويتم تمكين ميزة `std` افتراضيًا.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// نسخة ملتقطة من رمز في backtrace.
///
/// يتم إرجاع هذا النوع كقائمة من `BacktraceFrame::symbols` ويمثل البيانات الأولية لرمز في backtrace.
///
/// # الميزات المطلوبة
///
/// تتطلب هذه الوظيفة تمكين ميزة `std` الخاصة بـ `backtrace` crate ، ويتم تمكين ميزة `std` افتراضيًا.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// يلتقط backtrace في موقع استدعاء هذه الوظيفة ، ويعيد تمثيلاً مملوكًا.
    ///
    /// هذه الوظيفة مفيدة لتمثيل backtrace ككائن في Rust.يمكن إرسال هذه القيمة التي تم إرجاعها عبر مؤشرات الترابط وطباعتها في مكان آخر ، والغرض من هذه القيمة هو أن تكون محتواة ذاتيًا تمامًا.
    ///
    /// لاحظ أنه في بعض الأنظمة الأساسية ، قد يكون الحصول على إجراء خلفي كامل وحلها مكلفًا للغاية.
    /// إذا كانت التكلفة كبيرة بالنسبة للتطبيق الخاص بك ، فمن المستحسن استخدام `Backtrace::new_unresolved()` بدلاً من ذلك والذي يتجنب خطوة دقة الرمز (التي تستغرق عادةً أطول مدة) ويسمح بتأجيل ذلك إلى تاريخ لاحق.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # الميزات المطلوبة
    ///
    /// تتطلب هذه الوظيفة تمكين ميزة `std` الخاصة بـ `backtrace` crate ، ويتم تمكين ميزة `std` افتراضيًا.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // تريد التأكد من وجود إطار هنا لإزالته
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// على غرار `new` فيما عدا أن هذا لا يحل أي رموز ، فإن هذا ببساطة يلتقط backtrace كقائمة من العناوين.
    ///
    /// في وقت لاحق ، يمكن استدعاء وظيفة `resolve` لحل رموز هذا التتبع الخلفي إلى أسماء قابلة للقراءة.
    /// توجد هذه الوظيفة لأن عملية الدقة قد تستغرق أحيانًا وقتًا طويلاً بينما نادرًا ما تتم طباعة أي تتبع خلفي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // لا توجد أسماء رمزية
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // أسماء الرموز موجودة الآن
    /// ```
    ///
    /// # الميزات المطلوبة
    ///
    /// تتطلب هذه الوظيفة تمكين ميزة `std` الخاصة بـ `backtrace` crate ، ويتم تمكين ميزة `std` افتراضيًا.
    ///
    ///
    ///
    #[inline(never)] // تريد التأكد من وجود إطار هنا لإزالته
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// إرجاع الإطارات من وقت التقاط هذا التتبع الخلفي.
    ///
    /// من المحتمل أن يكون الإدخال الأول لهذه الشريحة هو الوظيفة `Backtrace::new` ، ومن المحتمل أن يكون الإطار الأخير يتعلق بكيفية بدء هذا الخيط أو الوظيفة الرئيسية.
    ///
    ///
    /// # الميزات المطلوبة
    ///
    /// تتطلب هذه الوظيفة تمكين ميزة `std` الخاصة بـ `backtrace` crate ، ويتم تمكين ميزة `std` افتراضيًا.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// إذا تم إنشاء هذا التتبع الخلفي من `new_unresolved` ، فستعمل هذه الوظيفة على حل جميع العناوين الموجودة في التتبع الخلفي لأسمائها الرمزية.
    ///
    ///
    /// إذا تم حل هذا التتبع الخلفي مسبقًا أو تم إنشاؤه من خلال `new` ، فإن هذه الوظيفة لا تفعل شيئًا.
    ///
    /// # الميزات المطلوبة
    ///
    /// تتطلب هذه الوظيفة تمكين ميزة `std` الخاصة بـ `backtrace` crate ، ويتم تمكين ميزة `std` افتراضيًا.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// مثل `Frame::ip`
    ///
    /// # الميزات المطلوبة
    ///
    /// تتطلب هذه الوظيفة تمكين ميزة `std` الخاصة بـ `backtrace` crate ، ويتم تمكين ميزة `std` افتراضيًا.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// مثل `Frame::symbol_address`
    ///
    /// # الميزات المطلوبة
    ///
    /// تتطلب هذه الوظيفة تمكين ميزة `std` الخاصة بـ `backtrace` crate ، ويتم تمكين ميزة `std` افتراضيًا.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// مثل `Frame::module_base_address`
    ///
    /// # الميزات المطلوبة
    ///
    /// تتطلب هذه الوظيفة تمكين ميزة `std` الخاصة بـ `backtrace` crate ، ويتم تمكين ميزة `std` افتراضيًا.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// تُرجع قائمة الرموز التي يتوافق معها هذا الإطار.
    ///
    /// عادةً ما يكون هناك رمز واحد فقط لكل إطار ، ولكن في بعض الأحيان إذا تم تضمين عدد من الوظائف في إطار واحد ، فسيتم إرجاع رموز متعددة.
    /// الرمز الأول المدرج هو "innermost function" ، بينما الرمز الأخير هو الأبعد (آخر متصل).
    ///
    /// لاحظ أنه إذا جاء هذا الإطار من تتبع عكسي لم يتم حله ، فسيؤدي ذلك إلى إرجاع قائمة فارغة.
    ///
    /// # الميزات المطلوبة
    ///
    /// تتطلب هذه الوظيفة تمكين ميزة `std` الخاصة بـ `backtrace` crate ، ويتم تمكين ميزة `std` افتراضيًا.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// مثل `Symbol::name`
    ///
    /// # الميزات المطلوبة
    ///
    /// تتطلب هذه الوظيفة تمكين ميزة `std` الخاصة بـ `backtrace` crate ، ويتم تمكين ميزة `std` افتراضيًا.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// مثل `Symbol::addr`
    ///
    /// # الميزات المطلوبة
    ///
    /// تتطلب هذه الوظيفة تمكين ميزة `std` الخاصة بـ `backtrace` crate ، ويتم تمكين ميزة `std` افتراضيًا.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// مثل `Symbol::filename`
    ///
    /// # الميزات المطلوبة
    ///
    /// تتطلب هذه الوظيفة تمكين ميزة `std` الخاصة بـ `backtrace` crate ، ويتم تمكين ميزة `std` افتراضيًا.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// مثل `Symbol::lineno`
    ///
    /// # الميزات المطلوبة
    ///
    /// تتطلب هذه الوظيفة تمكين ميزة `std` الخاصة بـ `backtrace` crate ، ويتم تمكين ميزة `std` افتراضيًا.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// مثل `Symbol::colno`
    ///
    /// # الميزات المطلوبة
    ///
    /// تتطلب هذه الوظيفة تمكين ميزة `std` الخاصة بـ `backtrace` crate ، ويتم تمكين ميزة `std` افتراضيًا.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // عند طباعة المسارات ، نحاول تجريد cwd إذا كان موجودًا ، وإلا فإننا نطبع المسار كما هو.
        // لاحظ أننا نقوم بذلك أيضًا للتنسيق القصير ، لأنه إذا كان ممتلئًا ، فمن المفترض أننا نريد طباعة كل شيء.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}