use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// قم بحل عنوان إلى رمز ، وتمرير الرمز إلى الإغلاق المحدد.
///
/// ستبحث هذه الوظيفة عن العنوان المحدد في مناطق مثل جدول الرموز المحلي ، أو جدول الرموز الديناميكية ، أو معلومات تصحيح أخطاء DWARF (اعتمادًا على التنفيذ النشط) للعثور على الرموز التي تريد الحصول عليها.
///
///
/// قد لا يتم استدعاء الإغلاق إذا تعذر تنفيذ القرار ، ويمكن أيضًا استدعاؤه أكثر من مرة في حالة الوظائف المضمنة.
///
/// تمثل الرموز الناتجة التنفيذ في `addr` المحدد ، وإرجاع أزواج file/line لهذا العنوان (إذا كان متاحًا).
///
/// لاحظ أنه إذا كان لديك `Frame` ، فمن المستحسن استخدام وظيفة `resolve_frame` بدلاً من هذه.
///
/// # الميزات المطلوبة
///
/// تتطلب هذه الوظيفة تمكين ميزة `std` الخاصة بـ `backtrace` crate ، ويتم تمكين ميزة `std` افتراضيًا.
///
/// # Panics
///
/// تسعى هذه الوظيفة جاهدة لعدم استخدام panic مطلقًا ، ولكن إذا قدم `cb` panics ، فإن بعض الأنظمة الأساسية ستجبر panic مزدوجًا على إجهاض العملية.
/// تستخدم بعض الأنظمة الأساسية مكتبة C التي تستخدم داخليًا عمليات الاسترجاعات التي لا يمكن التخلص منها ، لذا فإن الذعر من `cb` قد يؤدي إلى إحباط العملية.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // انظر فقط إلى الإطار العلوي
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// حل إطار الالتقاط السابق إلى رمز ، وتمرير الرمز إلى الإغلاق المحدد.
///
/// يؤدي هذا functin نفس وظيفة `resolve` فيما عدا أنه يأخذ `Frame` كوسيطة بدلاً من عنوان.
/// يمكن أن يسمح ذلك لبعض تطبيقات النظام الأساسي للتتبع الخلفي لتوفير معلومات أكثر دقة عن الرموز أو معلومات حول الإطارات المضمنة على سبيل المثال.
///
/// يوصى باستخدام هذا إذا استطعت.
///
/// # الميزات المطلوبة
///
/// تتطلب هذه الوظيفة تمكين ميزة `std` الخاصة بـ `backtrace` crate ، ويتم تمكين ميزة `std` افتراضيًا.
///
/// # Panics
///
/// تسعى هذه الوظيفة جاهدة لعدم استخدام panic مطلقًا ، ولكن إذا قدم `cb` panics ، فإن بعض الأنظمة الأساسية ستجبر panic مزدوجًا على إجهاض العملية.
/// تستخدم بعض الأنظمة الأساسية مكتبة C التي تستخدم داخليًا عمليات الاسترجاعات التي لا يمكن التخلص منها ، لذا فإن الذعر من `cb` قد يؤدي إلى إحباط العملية.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // انظر فقط إلى الإطار العلوي
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// عادةً ما تكون قيم IP من إطارات المكدس (always?) هي التعليمات *بعد* الاستدعاء الذي يمثل تتبع المكدس الفعلي.
// يؤدي ترميز هذا إلى جعل رقم filename/line متقدمًا وربما في الفراغ إذا كان قريبًا من نهاية الوظيفة.
//
// يبدو أن هذا هو الحال دائمًا في جميع الأنظمة الأساسية ، لذلك نقوم دائمًا بطرح واحدة من عنوان IP تم حله لحلها إلى تعليمات الاستدعاء السابقة بدلاً من إرجاع التعليمات إلى.
//
//
// من الناحية المثالية لن نفعل هذا.
// من الناحية المثالية ، سنطلب من المتصلين بواجهات `resolve` API هنا القيام يدويًا بـ -1 والحساب الذي يريدون معلومات الموقع للتعليمات *السابقة*، وليس الحالية.
// من الناحية المثالية ، سنكشف أيضًا عن `Frame` إذا كنا بالفعل عنوان التعليمات التالية أو الحالية.
//
// في الوقت الحالي ، على الرغم من أن هذا مصدر قلق خاص جدًا ، لذا فنحن دائمًا ما نطرح واحدًا داخليًا.
// يجب على المستهلكين الاستمرار في العمل والحصول على نتائج جيدة ، لذلك يجب أن نكون جيدين بما فيه الكفاية.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// مثل `resolve` ، غير آمن فقط لأنه غير متزامن.
///
/// لا تحتوي هذه الوظيفة على أدوات ضمان للمزامنة ولكنها متاحة عندما لا يتم تجميع ميزة `std` الخاصة بـ crate.
/// راجع وظيفة `resolve` لمزيد من الوثائق والأمثلة.
///
/// # Panics
///
/// راجع المعلومات الخاصة بـ `resolve` للحصول على تحذيرات بشأن الذعر `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// مثل `resolve_frame` ، غير آمن فقط لأنه غير متزامن.
///
/// لا تحتوي هذه الوظيفة على أدوات ضمان للمزامنة ولكنها متاحة عندما لا يتم تجميع ميزة `std` الخاصة بـ crate.
/// راجع وظيفة `resolve_frame` لمزيد من الوثائق والأمثلة.
///
/// # Panics
///
/// راجع المعلومات الخاصة بـ `resolve_frame` للحصول على تحذيرات بشأن الذعر `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// يمثل trait دقة رمز في ملف.
///
/// يتم إنتاج trait ككائن trait للإغلاق الممنوح لوظيفة `backtrace::resolve` ، ويتم إرساله فعليًا لأنه من غير المعروف ما هو التنفيذ وراءه.
///
///
/// يمكن أن يعطي الرمز معلومات سياقية حول وظيفة ، على سبيل المثال الاسم واسم الملف ورقم السطر والعنوان الدقيق وما إلى ذلك.
/// لا تتوفر جميع المعلومات دائمًا في رمز ، ومع ذلك ، فإن كل الطرق ترجع `Option`.
///
///
pub struct Symbol {
    // TODO: يجب أن يستمر هذا الالتزام مدى الحياة في النهاية إلى `Symbol` ،
    // لكن هذا تغيير جذري في الوقت الحالي.
    // في الوقت الحالي ، يعد هذا آمنًا نظرًا لأن `Symbol` لا يتم تسليمه إلا بالإشارة ولا يمكن استنساخه.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// ترجع اسم هذه الوظيفة.
    ///
    /// يمكن استخدام البنية التي تم إرجاعها للاستعلام عن خصائص مختلفة حول اسم الرمز:
    ///
    ///
    /// * سيقوم تطبيق `Display` بطباعة الرمز غير المتشابك.
    /// * يمكن الوصول إلى قيمة `str` الأولية للرمز (إذا كانت utf-8 صالحة).
    /// * يمكن الوصول إلى وحدات البايت الأولية لاسم الرمز.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// إرجاع عنوان بداية هذه الوظيفة.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// إرجاع اسم الملف الخام على هيئة شريحة.
    /// هذا مفيد بشكل أساسي لبيئات `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// إرجاع رقم العمود للمكان الذي يتم فيه تنفيذ هذا الرمز حاليًا.
    ///
    /// يوفر gimli حاليًا قيمة فقط هنا وحتى ذلك الحين فقط إذا قام `filename` بإرجاع `Some` ، وبالتالي فهو بالتالي يخضع لتحذيرات مماثلة.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// إرجاع رقم السطر للمكان الذي يتم فيه تنفيذ هذا الرمز حاليًا.
    ///
    /// عادةً ما تكون قيمة الإرجاع هذه `Some` إذا قام `filename` بإرجاع `Some` ، وبالتالي تخضع لتحذيرات مماثلة.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// إرجاع اسم الملف حيث تم تعريف هذه الوظيفة.
    ///
    /// لا يتوفر هذا حاليًا إلا عند استخدام libbacktrace أو gimli (على سبيل المثال
    /// unix منصات أخرى) وعندما يتم تجميع ثنائي باستخدام debuginfo.
    /// إذا لم يتم استيفاء أي من هذه الشروط ، فمن المحتمل أن يؤدي ذلك إلى إرجاع `None`.
    ///
    /// # الميزات المطلوبة
    ///
    /// تتطلب هذه الوظيفة تمكين ميزة `std` الخاصة بـ `backtrace` crate ، ويتم تمكين ميزة `std` افتراضيًا.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // ربما رمز C++ محلل ، إذا فشل تحليل الرمز المشوه مثل Rust.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // تأكد من الاحتفاظ بهذا الحجم الصفري ، بحيث لا تكون هناك تكلفة لميزة `cpp_demangle` عند تعطيلها.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// غلاف حول اسم رمز لتوفير مداخل مريحة للاسم غير المتشابك والبايتات الخام والسلسلة الأولية وما إلى ذلك.
///
// السماح بالرمز الميت في حالة عدم تمكين ميزة `cpp_demangle`.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// ينشئ اسم رمز جديدًا من وحدات البايت الأساسية الأساسية.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// تُرجع اسم رمز (mangled) الخام كـ `str` إذا كان الرمز utf-8 صالحًا.
    ///
    /// استخدم تطبيق `Display` إذا كنت تريد الإصدار غير المتشابك.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// تُرجع اسم الرمز الأولي على هيئة قائمة من وحدات البايت
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // قد تتم طباعة هذا إذا لم يكن الرمز الذي تم فك تشابكه صالحًا بالفعل ، لذا تعامل مع الخطأ هنا بأمان من خلال عدم نشره للخارج.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// حاول استعادة الذاكرة المخبأة المستخدمة في ترميز العناوين.
///
/// ستحاول هذه الطريقة تحرير أي هياكل بيانات عالمية تم تخزينها مؤقتًا بشكل عام أو في الخيط الذي يمثل عادةً معلومات DWARF الموزعة أو ما شابه ذلك.
///
///
/// # Caveats
///
/// في حين أن هذه الوظيفة متاحة دائمًا ، إلا أنها لا تفعل أي شيء في معظم التطبيقات.
/// لا توفر المكتبات مثل dbghelp أو libbacktrace تسهيلات لإلغاء تخصيص الحالة وإدارة الذاكرة المخصصة.
/// في الوقت الحالي ، تعد ميزة `gimli-symbolize` الخاصة بـ crate هي الميزة الوحيدة التي يكون لهذه الوظيفة فيها أي تأثير.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}