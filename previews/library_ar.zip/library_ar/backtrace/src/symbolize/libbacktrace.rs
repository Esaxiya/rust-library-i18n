//! استراتيجية الترميز باستخدام كود DWARF في libbacktrace.
//!
//! مكتبة libbacktrace C ، الموزعة عادةً مع gcc ، لا تدعم فقط إنشاء backtrace (الذي لا نستخدمه في الواقع) ولكن أيضًا ترمز إلى backtrace ومعالجة معلومات تصحيح الأخطاء القزمية حول أشياء مثل الإطارات المضمنة وغير ذلك.
//!
//!
//! هذا معقد نسبيًا بسبب الكثير من الاهتمامات المختلفة هنا ، لكن الفكرة الأساسية هي:
//!
//! * أولاً نسمي `backtrace_syminfo`.هذا يحصل على معلومات الرمز من جدول الرموز الديناميكي إذا استطعنا.
//! * بعد ذلك نسمي `backtrace_pcinfo`.سيؤدي هذا إلى تحليل جداول معلومات التصحيح إذا كانت متوفرة ويسمح لنا باستعادة المعلومات حول الإطارات المضمنة وأسماء الملفات وأرقام الأسطر وما إلى ذلك.
//!
//! هناك الكثير من الحيل حول تحويل الطاولات القزمية إلى libbacktrace ، ولكن نأمل ألا تكون هذه نهاية العالم وتكون واضحة بما يكفي عند القراءة أدناه.
//!
//! هذه هي استراتيجية الترميز الافتراضية للأنظمة الأساسية بخلاف MSVC وغير OSX.في libstd على الرغم من أن هذه هي الإستراتيجية الافتراضية لـ OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // إذا أمكن ، تفضل اسم `function` الذي يأتي من معلومات التصحيح ويمكن أن يكون أكثر دقة للإطارات المضمنة على سبيل المثال.
                // إذا لم يكن ذلك موجودًا على الرغم من الرجوع إلى اسم جدول الرموز المحدد في `symname`.
                //
                // لاحظ أنه في بعض الأحيان يمكن أن تشعر `function` بأنها أقل دقة إلى حد ما ، على سبيل المثال أن يتم إدراجها على أنها `try<i32,closure>` ليست بعيدة عن `std::panicking::try::do_call`.
                //
                // ليس من الواضح حقًا السبب ، ولكن بشكل عام يبدو اسم `function` أكثر دقة.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // لا تفعل شيئًا في الوقت الحالي
}

/// نوع المؤشر `data` الذي تم تمريره إلى `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // بمجرد استدعاء رد الاتصال هذا من `backtrace_syminfo` عندما نبدأ في الحل ، نذهب إلى أبعد من ذلك للاتصال بـ `backtrace_pcinfo`.
    // ستراجع الدالة `backtrace_pcinfo` معلومات تصحيح الأخطاء وتحاول القيام بأشياء مثل استعادة معلومات file/line بالإضافة إلى الإطارات المضمنة.
    // لاحظ أنه على الرغم من أن `backtrace_pcinfo` يمكن أن يفشل أو لا يفعل الكثير إذا لم تكن هناك معلومات تصحيح الأخطاء ، لذلك إذا حدث ذلك ، فنحن على يقين من استدعاء رد الاتصال برمز واحد على الأقل من `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// نوع المؤشر `data` الذي تم تمريره إلى `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// تدعم واجهة برمجة تطبيقات libbacktrace إنشاء حالة ، لكنها لا تدعم تدمير الحالة.
// أنا شخصياً أفهم هذا على أنه يعني أن الدولة يجب أن تُخلق ثم تعيش إلى الأبد.
//
// أرغب في تسجيل معالج at_exit() الذي ينظف هذه الحالة ، لكن libbacktrace لا يوفر طريقة للقيام بذلك.
//
// مع هذه القيود ، تحتوي هذه الوظيفة على حالة مخزنة مؤقتًا بشكل ثابت يتم حسابها في المرة الأولى التي يُطلب فيها ذلك.
//
// تذكر أن التتبع الخلفي يحدث بشكل متسلسل (قفل عام واحد).
//
// لاحظ أن نقص المزامنة هنا يرجع إلى متطلبات مزامنة `resolve` خارجيًا.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // لا تمارس إمكانيات الخيط لـ libbacktrace لأننا نسميها دائمًا بطريقة متزامنة.
        //
        0,
        error_cb,
        ptr::null_mut(), // لا توجد بيانات اضافية
    );

    return STATE;

    // لاحظ أنه لكي يعمل libbacktrace على الإطلاق ، فإنه يحتاج إلى العثور على معلومات تصحيح أخطاء DWARF للملف التنفيذي الحالي.يقوم بذلك عادةً عبر عدد من الآليات بما في ذلك ، على سبيل المثال لا الحصر:
    //
    // * /proc/self/exe على المنصات المدعومة
    // * تم تمرير اسم الملف بشكل صريح عند إنشاء الحالة
    //
    // مكتبة libbacktrace عبارة عن رزمة كبيرة من كود C.هذا يعني بطبيعة الحال أنه يحتوي على ثغرات أمنية في الذاكرة ، خاصة عند التعامل مع معلومات تصحيح الأخطاء التالفة.
    // واجهت Libstd الكثير من هذه تاريخيًا.
    //
    // إذا تم استخدام /proc/self/exe ، فيمكننا عادةً تجاهل هذه لأننا نفترض أن libbacktrace هو "mostly correct" وبخلاف ذلك لا يقوم بأشياء غريبة باستخدام معلومات تصحيح أخطاء "attempted to be correct" القزم.
    //
    //
    // ومع ذلك ، إذا مررنا اسم ملف ، فمن الممكن في بعض الأنظمة الأساسية (مثل BSDs) حيث يمكن لممثل ضار أن يتسبب في وضع ملف تعسفي في هذا الموقع.
    // هذا يعني أنه إذا أخبرنا libbacktrace عن اسم ملف ، فربما يستخدم ملفًا عشوائيًا ، مما قد يتسبب في حدوث segfaults.
    // إذا لم نخبر libbacktrace بأي شيء ، فلن يفعل أي شيء على الأنظمة الأساسية التي لا تدعم مسارات مثل /proc/self/exe!
    //
    // بالنظر إلى كل ما نحاول جاهدين قدر الإمكان *عدم* تمرير اسم ملف ، ولكن يجب علينا على الأنظمة الأساسية التي لا تدعم /proc/self/exe على الإطلاق.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // لاحظ أننا سنستخدم `std::env::current_exe` بشكل مثالي ، لكن لا يمكننا طلب `std` هنا.
            //
            // استخدم `_NSGetExecutablePath` لتحميل المسار الحالي القابل للتنفيذ في منطقة ثابتة (والتي إذا كانت صغيرة جدًا فاستسلم لها).
            //
            //
            // لاحظ أننا نثق بجدية في libbacktrace هنا حتى لا تموت على الملفات التنفيذية الفاسدة ، لكنها بالتأكيد تفعل ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows لديه وضع فتح الملفات حيث لا يمكن حذفه بعد فتحه.
            // هذا ما نريده هنا بشكل عام لأننا نريد التأكد من أن الملف التنفيذي الخاص بنا لا يتغير من تحتنا بعد أن نسلمه إلى libbacktrace ، ونأمل أن نخفف من القدرة على تمرير البيانات التعسفية إلى libbacktrace (والذي قد يتم التعامل معه بشكل خاطئ).
            //
            //
            // بالنظر إلى أننا نقوم ببعض الرقص هنا لمحاولة الحصول على نوع من القفل على صورتنا:
            //
            // * احصل على معالجة للعملية الحالية ، وقم بتحميل اسم الملف الخاص بها.
            // * افتح ملفًا باسم هذا الملف باستخدام العلامات الصحيحة.
            // * أعد تحميل اسم ملف العملية الحالية ، وتأكد من تماثله
            //
            // إذا مر كل هذا ، فنحن من الناحية النظرية فتحنا بالفعل ملف العملية الخاصة بنا ونحن نضمن أنه لن يتغير.FWIW تم نسخ مجموعة من هذا من libstd تاريخيًا ، لذلك هذا هو أفضل تفسير لي لما كان يحدث.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // هذا يعيش في ذاكرة ثابتة حتى نتمكن من إعادته ..
                static mut BUF: [i8; N] = [0; N];
                // ... وهذا يعيش على المكدس لأنه مؤقت
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // تسرب `handle` عمدًا هنا لأن فتح هذا يجب أن يحافظ على قفل اسم الملف هذا.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // نريد إرجاع الشريحة التي تم إنهاؤها nul ، لذلك إذا تم ملء كل شيء وكان يساوي الطول الإجمالي ، فعندئذٍ نساوي ذلك بالفشل.
                //
                //
                // وإلا عند إرجاع النجاح ، تأكد من تضمين بايت nul في الشريحة.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // تم مسح أخطاء backtrace حاليًا تحت السجادة
    let state = init_state();
    if state.is_null() {
        return;
    }

    // اتصل بواجهة برمجة تطبيقات `backtrace_syminfo` والتي (من خلال قراءة الكود) يجب أن تستدعي `syminfo_cb` مرة واحدة بالضبط (أو تفشل بسبب خطأ مفترض).
    // ثم نتعامل مع المزيد داخل `syminfo_cb`.
    //
    // لاحظ أننا نقوم بذلك لأن `syminfo` سوف يستشير جدول الرموز ، ويعثر على أسماء الرموز حتى إذا لم تكن هناك معلومات تصحيح في الملف الثنائي.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}