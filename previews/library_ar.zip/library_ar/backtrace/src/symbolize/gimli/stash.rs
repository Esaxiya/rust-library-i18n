// تستخدم فقط على Linux الآن ، لذا اسمح بالرمز الميت في مكان آخر
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// مخصص حلبة بسيط للمخازن المؤقتة للبايت.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// يخصص مخزنًا مؤقتًا بالحجم المحدد ويعيد مرجعًا متغيرًا إليه.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // الأمان: هذه هي الوظيفة الوحيدة التي تبني متغيرًا
        // إشارة إلى `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // الأمان: لا نزيل العناصر من `self.buffers` أبدًا ، لذلك مرجع
        // إلى البيانات الموجودة داخل أي مخزن مؤقت سيعيش طالما يعمل `self`.
        &mut buffers[i]
    }
}