//! دعم الترميز باستخدام `gimli` crate على crates.io
//!
//! هذا هو تطبيق الرمز الافتراضي لـ Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // العمر الثابت هو كذبة يمكن اختراقها حول نقص الدعم للهياكل المرجعية الذاتية.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // قم بالتحويل إلى "الأعمار الثابتة لأن الرموز يجب أن تقترض فقط `map` و `stash` ونحن نحتفظ بها أدناه.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // لتحميل المكتبات الأصلية على Windows ، راجع بعض المناقشات حول rust-lang/rust#71060 للاستراتيجيات المختلفة هنا.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // لا تدعم مكتبات MinGW حاليًا ASLR (rust-lang/rust#16514) ، ولكن لا يزال من الممكن تغيير مواقع مكتبات DLL في مساحة العنوان.
            // يبدو أن جميع العناوين في معلومات التصحيح كما لو تم تحميل هذه المكتبة في "image base" ، وهو حقل في رؤوس ملفات COFF الخاصة بها.
            // نظرًا لأن هذا هو ما يبدو أن debuginfo يسرده ، فإننا نحلل جدول الرموز وعناوين المتجر كما لو تم تحميل المكتبة في "image base" أيضًا.
            //
            // ومع ذلك ، قد لا يتم تحميل المكتبة في "image base".
            // (من المفترض أن يتم تحميل شيء آخر هناك؟) هذا هو المكان الذي يلعب فيه حقل `bias` ، ونحتاج إلى معرفة قيمة `bias` هنا.لسوء الحظ ، ليس من الواضح كيفية الحصول على هذا من وحدة محملة.
            // ومع ذلك ، ما لدينا هو عنوان التحميل الفعلي (`modBaseAddr`).
            //
            // كنوع من النسخ في الوقت الحالي ، نقوم بتخطيط الملف ، وقراءة معلومات رأس الملف ، ثم إسقاط mmap.هذا هدر لأننا ربما نعيد فتح mmap لاحقًا ، لكن هذا يجب أن يعمل بشكل جيد بما فيه الكفاية في الوقت الحالي.
            //
            // بمجرد حصولنا على `image_base` (موقع التحميل المطلوب) و `base_addr` (موقع التحميل الفعلي) يمكننا ملء `bias` (الفرق بين الفعلي والمطلوب) ثم العنوان المحدد لكل مقطع هو `image_base` لأن هذا ما يقوله الملف.
            //
            //
            // في الوقت الحالي ، يبدو أنه على عكس ELF/MachO ، يمكننا القيام بجزء واحد لكل مكتبة ، باستخدام `modBaseSize` كحجم كامل.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS يستخدم تنسيق ملف Mach-O ويستخدم واجهات برمجة تطبيقات خاصة بـ DYLD لتحميل قائمة بالمكتبات الأصلية التي تعد جزءًا من التطبيق.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // قم بإحضار اسم هذه المكتبة الذي يتوافق مع مسار مكان تحميلها أيضًا.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // قم بتحميل رأس الصورة لهذه المكتبة وفوض إلى `object` لتحليل جميع أوامر التحميل حتى نتمكن من معرفة جميع الأجزاء المعنية هنا.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // كرر عبر المقاطع وسجل المناطق المعروفة للأجزاء التي نجدها.
            // بالإضافة إلى ذلك ، قم بتسجيل المعلومات حول مقاطع نصية للمعالجة لاحقًا ، انظر التعليقات أدناه.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // حدد "slide" لهذه المكتبة والذي ينتهي به الأمر باعتباره التحيز الذي نستخدمه لمعرفة مكان تحميل كائنات الذاكرة.
            // هذا حساب غريب بعض الشيء وهو نتيجة تجربة بعض الأشياء في البرية ورؤية ما يعلق.
            //
            // الفكرة العامة هي أن `bias` بالإضافة إلى `stated_virtual_memory_address` للقطعة ستكون في مكان وجود المقطع في مساحة العنوان الفعلية.
            // الشيء الآخر الذي نعتمد عليه هو أن العنوان الحقيقي مطروحًا منه `bias` هو الفهرس الذي يجب البحث عنه في جدول الرموز وتصحيح الأخطاء.
            //
            // ومع ذلك ، اتضح أن هذه الحسابات غير صحيحة للمكتبات المحملة بالنظام.بالنسبة للملفات التنفيذية الأصلية ، يبدو أنها صحيحة.
            // رفع بعض المنطق من مصدر LLDB ، فإنه يحتوي على بعض الغلاف الخاص لقسم `__TEXT` الأول الذي تم تحميله من ملف الإزاحة 0 بحجم غير صفري.
            // لأي سبب من الأسباب عندما يكون هذا موجودًا ، يبدو أنه يعني أن جدول الرموز متعلق فقط بشريحة vmaddr للمكتبة.
            // إذا لم يكن * موجودًا ، فسيكون جدول الرموز مرتبطًا بشريحة vmaddr بالإضافة إلى العنوان المحدد للقطاع.
            //
            // للتعامل مع هذا الموقف إذا *لم* نجد قسمًا نصيًا في ملف إزاحة الصفر ، فإننا نزيد التحيز من خلال العنوان المحدد لأقسام النص الأول ونخفض جميع العناوين المذكورة بهذا المقدار أيضًا.
            //
            // بهذه الطريقة يظهر جدول الرموز دائمًا بالنسبة إلى مقدار انحياز المكتبة.
            // يبدو أن هذا يحتوي على النتائج الصحيحة للترميز عبر جدول الرموز.
            //
            // بصراحة ، لست متأكدًا تمامًا مما إذا كان هذا صحيحًا أو إذا كان هناك شيء آخر يجب أن يشير إلى كيفية القيام بذلك.
            // في الوقت الحالي ، يبدو أن هذا يعمل بشكل جيد بما فيه الكفاية (?) ويجب أن نكون قادرين دائمًا على تعديل هذا بمرور الوقت إذا لزم الأمر.
            //
            // لمزيد من المعلومات راجع #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Unix أخرى (على سبيل المثال
        // Linux) تستخدم الأنظمة الأساسية ELF كتنسيق ملف كائن وعادة ما تنفذ واجهة برمجة تطبيقات تسمى `dl_iterate_phdr` لتحميل المكتبات الأصلية.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` يجب أن تكون مؤشرات صالحة.
        // `vec` يجب أن يكون مؤشرًا صالحًا لـ `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 لا يدعم معلومات التصحيح أصلاً ، لكن نظام الإنشاء سيضع معلومات تصحيح الأخطاء في المسار `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // كل شيء آخر يجب أن يستخدم ELF ، لكنه لا يعرف كيفية تحميل المكتبات الأصلية.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// جميع المكتبات المشتركة المعروفة التي تم تحميلها.
    libraries: Vec<Library>,

    /// ذاكرة التخزين المؤقت للتعيينات حيث نحتفظ بمعلومات قزم تم تحليلها.
    ///
    /// تتمتع هذه القائمة بقدرة ثابتة طوال مدة الرفع التي لا تزيد أبدًا.
    /// عنصر `usize` لكل زوج هو مؤشر في `libraries` أعلاه حيث يمثل `usize::max_value()` الملف التنفيذي الحالي.
    ///
    /// `Mapping` هي معلومات قزم تحليل المقابلة.
    ///
    /// لاحظ أن هذا في الأساس عبارة عن ذاكرة تخزين مؤقت LRU وسنقوم بتحويل الأشياء هنا لأننا نرمز إلى العناوين.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// يتم تحميل أجزاء من هذه المكتبة في الذاكرة ومكان تحميلها.
    segments: Vec<LibrarySegment>,
    /// "bias" من هذه المكتبة ، حيث يتم عادةً تحميلها في الذاكرة.
    /// تتم إضافة هذه القيمة إلى العنوان المحدد لكل مقطع للحصول على عنوان الذاكرة الظاهرية الفعلي الذي تم تحميل المقطع فيه.
    /// بالإضافة إلى ذلك ، يتم طرح هذا التحيز من عناوين الذاكرة الظاهرية الحقيقية للفهرسة في معلومات التصحيح وجدول الرموز.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// العنوان المذكور لهذا المقطع في ملف الكائن.
    /// هذا ليس في الواقع المكان الذي يتم فيه تحميل المقطع ، ولكن هذا العنوان بالإضافة إلى `bias` للمكتبة المحتوية هو مكان العثور عليه.
    ///
    stated_virtual_memory_address: usize,
    /// حجم مقطع ths في الذاكرة.
    len: usize,
}

// غير آمن لأن هذا مطلوب لتتم مزامنته خارجيًا
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // غير آمن لأن هذا مطلوب لتتم مزامنته خارجيًا
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // ذاكرة تخزين مؤقت LRU صغيرة جدًا وبسيطة جدًا لتعيينات معلومات تصحيح الأخطاء.
        //
        // يجب أن يكون معدل الدخول مرتفعًا جدًا ، نظرًا لأن المكدس النموذجي لا يتقاطع بين العديد من المكتبات المشتركة.
        //
        // هياكل `addr2line::Context` باهظة الثمن جدًا.
        // من المتوقع أن يتم إطفاء تكلفتها من خلال استعلامات `locate` اللاحقة ، والتي تستفيد من الهياكل التي تم إنشاؤها عند إنشاء `addr2line: : Context`s للحصول على تسريع لطيف.
        //
        // إذا لم يكن لدينا ذاكرة التخزين المؤقت هذه ، فلن يحدث هذا الاستهلاك أبدًا ، وستكون عمليات backtra التي ترمز إلى ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // أولاً ، اختبر ما إذا كان `lib` يحتوي على أي مقطع يحتوي على `addr` (معالجة النقل).إذا نجح هذا التحقق ، فيمكننا المتابعة أدناه وترجمة العنوان فعليًا.
                //
                // لاحظ أننا نستخدم `wrapping_add` هنا لتجنب عمليات فحص الفائض.لقد لوحظ في البرية أن حساب تحيز SVMA + يفيض.
                // قد يبدو الأمر غريبًا بعض الشيء ، لكن لا يوجد قدر كبير يمكننا القيام به حيال ذلك بخلاف تجاهل تلك المقاطع على الأرجح لأنها تشير على الأرجح إلى الفضاء.
                //
                // جاء هذا في الأصل في rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // الآن بعد أن علمنا أن `lib` يحتوي على `addr` ، يمكننا تعويضه بالتحيز للعثور على عنوان الذاكرة الظاهرية المذكور.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // ثابت: بعد اكتمال هذا الشرط دون العودة المبكرة
        // من خطأ ، يكون إدخال ذاكرة التخزين المؤقت لهذا المسار في الفهرس 0.

        if let Some(idx) = idx {
            // عندما يكون التعيين موجودًا بالفعل في ذاكرة التخزين المؤقت ، انقله إلى المقدمة.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // عندما لا يكون التعيين في ذاكرة التخزين المؤقت ، أنشئ تعيينًا جديدًا ، وأدخله في مقدمة ذاكرة التخزين المؤقت ، واستبعد أقدم إدخال لذاكرة التخزين المؤقت إذا لزم الأمر.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // لا تتسرب من عمر `'static` ، فتأكد من أنها مخصصة لأنفسنا فقط
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // قم بتمديد عمر `sym` إلى `'static` نظرًا لأننا مطالبون هنا للأسف ، ولكنه خرج كمرجع لذلك لا ينبغي الاستمرار في الإشارة إليه خارج هذا الإطار على أي حال.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // أخيرًا ، احصل على تعيين مخبأ أو أنشئ تعيينًا جديدًا لهذا الملف ، وقم بتقييم معلومات DWARF للعثور على file/line/name لهذا العنوان.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// تمكنا من تحديد موقع معلومات الإطار لهذا الرمز ، ويحتوي إطار "addr2line" داخليًا على جميع التفاصيل الدقيقة.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// تعذر العثور على معلومات التصحيح ، لكننا وجدناها في جدول الرموز في الملف القابل للتنفيذ elf.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}