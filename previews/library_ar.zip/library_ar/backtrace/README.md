# backtrace-rs

[Documentation](https://docs.rs/backtrace)

مكتبة للحصول على backtraces في وقت تشغيل Rust.
تهدف هذه المكتبة إلى تعزيز دعم المكتبة القياسية من خلال توفير واجهة برمجية للعمل معها ، ولكنها تدعم أيضًا بسهولة طباعة الخلفية الخلفية الحالية مثل panics الخاص بـ libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

ببساطة لالتقاط تتبع خلفي وتأجيل التعامل معه حتى وقت لاحق ، يمكنك استخدام المستوى الأعلى من نوع `Backtrace`.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

ومع ذلك ، إذا كنت تريد المزيد من الوصول الأولي إلى وظيفة التتبع الفعلية ، فيمكنك استخدام وظائف `trace` و `resolve` مباشرةً.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // حل مؤشر التعليمات هذا إلى اسم رمز
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // استمر في الانتقال إلى الإطار التالي
    });
}
```

# License

هذا المشروع مرخص بموجب أي من

 * ترخيص Apache ، الإصدار 2.0 أو ([LICENSE-APACHE](LICENSE-APACHE) أو http://www.apache.org/licenses/LICENSE-2.0)
 * ترخيص MIT ([LICENSE-MIT](LICENSE-MIT) أو http://opensource.org/licenses/MIT)

حسب اختيارك.

### Contribution

ما لم تنص صراحة على خلاف ذلك ، فإن أي مساهمة مقدمة عن قصد لإدراجها في backtrace-rs بواسطتك ، على النحو المحدد في ترخيص Apache-2.0 ، يجب أن تكون مرخصة بشكل مزدوج على النحو الوارد أعلاه ، دون أي شروط أو شروط إضافية.







