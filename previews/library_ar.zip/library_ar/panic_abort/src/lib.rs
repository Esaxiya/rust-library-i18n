//! تنفيذ Rust panics عبر إحباط العملية
//!
//! عند مقارنتها بالتنفيذ عن طريق فك اللف ، فإن crate هذا أبسط بكثير!ومع ذلك ، فهو ليس متعدد الاستخدامات تمامًا ، ولكن هنا يذهب!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" الحمولة والرقائق إلى الإحباط ذي الصلة على المنصة المعنية.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // اتصل بـ std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // في Windows ، استخدم آلية __ fastfail الخاصة بالمعالج.في Windows 8 والإصدارات الأحدث ، سيؤدي هذا إلى إنهاء العملية على الفور دون تشغيل أي معالجات استثناء قيد التشغيل.
            // في الإصدارات السابقة من Windows ، سيتم التعامل مع هذا التسلسل من التعليمات على أنه انتهاك وصول ، مما يؤدي إلى إنهاء العملية ولكن دون بالضرورة تجاوز كافة معالجات الاستثناءات.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: هذا هو نفس التطبيق كما في libstd's `abort_internal`
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// هذا ... نوع من الغرابة.TL ؛ د.هو أن هذا مطلوب للربط بشكل صحيح ، الشرح الأطول أدناه.
//
// الآن تم تجميع جميع ثنائيات libcore/libstd التي نشحنها باستخدام `-C panic=unwind`.يتم ذلك للتأكد من أن الثنائيات متوافقة إلى أقصى حد مع أكبر عدد ممكن من المواقف.
// ومع ذلك ، يتطلب المترجم "personality function" لجميع الوظائف المترجمة مع `-C panic=unwind`.يتم ترميز وظيفة الشخصية هذه إلى الرمز `rust_eh_personality` ويتم تحديدها بواسطة عنصر `eh_personality` lang.
//
// So...
// لماذا لا تحدد عنصر lang هذا هنا؟سؤال جيد!الطريقة التي ترتبط بها أوقات تشغيل panic هي في الواقع دقيقة بعض الشيء من حيث أنها "sort of" في متجر المترجم crate ، ولكنها مرتبطة فعليًا فقط إذا لم يتم ربط الآخر فعليًا.
//
// ينتهي هذا الأمر بمعنى أن كلاً من crate و panic_unwind crate يمكن أن يظهران في متجر crate الخاص بالمترجم ، وإذا حدد كلاهما عنصر `eh_personality` lang ، فسيظهر خطأ.
//
// للتعامل مع هذا ، يتطلب المترجم فقط تحديد `eh_personality` إذا كان وقت تشغيل panic المرتبط هو وقت تشغيل فك اللفة ، وإلا فإنه لا يلزم تحديده (بشكل صحيح).
// ومع ذلك ، في هذه الحالة ، تحدد هذه المكتبة هذا الرمز فقط ، لذلك هناك على الأقل بعض الشخصية في مكان ما.
//
// تم تعريف هذا الرمز بشكل أساسي للتوصل إلى ثنائيات libcore/libstd ، ولكن لا ينبغي أبدًا استدعاؤها لأننا لا نربطها في وقت تشغيل فك الارتباط على الإطلاق.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // في x86_64-pc-windows-gnu ، نستخدم وظيفة الشخصية الخاصة بنا والتي تحتاج إلى إرجاع `ExceptionContinueSearch` بينما نمرر جميع الإطارات الخاصة بنا.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // على غرار ما ورد أعلاه ، يتوافق هذا مع عنصر `eh_catch_typeinfo` lang المستخدم فقط في Emscripten حاليًا.
    //
    // نظرًا لأن panics لا تنشئ استثناءات والاستثناءات الأجنبية هي حاليًا UB مع -C panic=abort (على الرغم من أن هذا قد يكون عرضة للتغيير) ، فلن تستخدم أي مكالمات catch_unwind هذا النوع أبدًا.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // يتم استدعاء هذين الاثنين بواسطة كائنات بدء التشغيل الخاصة بنا على i686-pc-windows-gnu ، لكنهما لا يحتاجان إلى فعل أي شيء حتى تكون الأجساد nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}