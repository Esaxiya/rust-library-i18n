# `rustc-std-workspace-core` crate

Šis crate ir tukšs un tukšs crate, kas vienkārši ir atkarīgs no `libcore` un reeksportē visu tā saturu.
crate ir galvenais elements, piešķirot standarta bibliotēkai iespēju būt atkarīgai no crates no crates.io

Crates uz crates.io, ka standarta bibliotēka ir atkarīga no nepieciešamības būt atkarīgai no `rustc-std-workspace-core` crate no crates.io, kas ir tukšs.

Mēs izmantojam `[patch]`, lai to ignorētu šim crate šajā repozitorijā.
Rezultātā crates uz crates.io piesaistīs atkarību edge līdz `libcore`-versijai, kas definēta šajā repozitorijā.
Tam vajadzētu uzzīmēt visas atkarības malas, lai nodrošinātu, ka Cargo veiksmīgi izveido crates!

Ņemiet vērā, ka crates operētājsistēmā crates.io ir atkarīgs no šī crate ar nosaukumu `core`, lai viss darbotos pareizi.Lai to izdarītu, viņi var izmantot:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Izmantojot `package` taustiņu, crate tiek pārdēvēts par `core`, tas nozīmē, ka tas izskatīsies

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

kad Cargo izsauc kompilatoru, izpildot netiešo `extern crate core` direktīvu, kuru injicējis kompilators.




