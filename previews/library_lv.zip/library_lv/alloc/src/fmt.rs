//! Pakalpojumi `Stīgu` formatēšanai un drukāšanai.
//!
//! Šis modulis satur izpildlaika atbalstu [`format!`] sintakses paplašinājumam.
//! Šis makro ir ieviests kompilatorā, lai veiktu izsaukumus uz šo moduli, lai izpildes laikā argumentus formatētu virknēs.
//!
//! # Usage
//!
//! [`format!`] makro ir paredzēts, lai būtu pazīstams tiem, kas nāk no C `printf`/`fprintf` funkcijām vai Python `str.format` funkcijas.
//!
//! Daži [`format!`] paplašinājuma piemēri ir:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" ar vadošajām nullēm
//! ```
//!
//! No tiem jūs varat redzēt, ka pirmais arguments ir formāta virkne.Kompilators pieprasa, lai tas būtu virknes literāls;tas nevar būt mainīgais, kas ievadīts (lai veiktu derīguma pārbaudi).
//! Tad kompilators parsēs formāta virkni un noteiks, vai sniegtais argumentu saraksts ir piemērots nodošanai šai formāta virknei.
//!
//! Lai pārveidotu atsevišķu vērtību virknē, izmantojiet metodi [`to_string`].Tam tiks izmantots [`Display`] formatējums trait.
//!
//! ## Pozicionālie parametri
//!
//! Katram formatēšanas argumentam ir atļauts norādīt vērtības argumentu, uz kuru tas atsaucas, un, ja tas tiek izlaists, tiek pieņemts, ka tas ir "the next argument".
//! Piemēram, formāta virknei `{} {} {}` būtu nepieciešami trīs parametri, un tie tiktu formatēti tādā pašā secībā, kādā tie ir doti.
//! Tomēr formāta virkne `{2} {1} {0}` argumentus formatētu apgrieztā secībā.
//!
//! Lietas var kļūt nedaudz grūts, kad sākat sajaukt divu veidu pozicionēšanas specifikatorus."next argument" specifikatoru var uzskatīt par argumenta atkārtotāju.
//! Katru reizi, kad tiek parādīts "next argument" specifikators, atkārtotājs virzās uz priekšu.Tas noved pie šādas uzvedības:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Iekšējais iterators par argumentu nav uzlabots līdz brīdim, kad tiek parādīts pirmais `{}`, tāpēc tas izdrukā pirmo argumentu.Tad, sasniedzot otro `{}`, iterators ir virzījies uz priekšu līdz otrajam argumentam.
//! Būtībā parametri, kas skaidri nosauc savu argumentu, neietekmē parametrus, kas nenosauc argumentu pozicionālo parametru ziņā.
//!
//! Lai izmantotu visus argumentus, ir nepieciešama formāta virkne, pretējā gadījumā tā ir sastādīšanas laika kļūda.Jūs varat atsaukties uz vienu un to pašu argumentu vairāk nekā vienu reizi formāta virknē.
//!
//! ## Nosauktie parametri
//!
//! Pašai Rust nav Python līdzīga nosaukto parametru ekvivalenta funkcijai, bet [`format!`] makro ir sintakses paplašinājums, kas ļauj tam izmantot nosauktos parametrus.
//! Nosauktie parametri ir uzskaitīti argumentu saraksta beigās, un tiem ir sintakse:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Piemēram, šādās [`format!`] izteiksmēs tiek izmantots nosauktais arguments:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Nav derīgi pozicionēšanas parametrus (tos, kuriem nav vārdu) likt aiz argumentiem, kuriem ir nosaukumi.Tāpat kā ar pozicionālajiem parametriem, nav derīgi norādīt nosauktos parametrus, kurus formāta virkne neizmanto.
//!
//! # Parametru formatēšana
//!
//! Katru formatējamo argumentu var pārveidot ar vairākiem formatēšanas parametriem ([the syntax](#syntax)) atbilst `format_spec`. Šie parametri ietekmē formāta virknes attēlojumu.
//!
//! ## Width
//!
//! ```
//! // Visi šie izdrukā "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Šis ir parametrs "minimum width", kas formātam būtu jāpieņem.
//! Ja vērtības virkne neaizpilda tik daudz rakstzīmju, nepieciešamās vietas aizņemšanai tiks izmantots fill/alignment norādītais polsterējums (skat. Zemāk).
//!
//! Platuma vērtību parametru sarakstā var norādīt arī kā [`usize`], pievienojot postfix `$`, norādot, ka otrais arguments ir [`usize`], kas norāda platumu.
//!
//! Atsauce uz argumentu ar dolāra sintaksi neietekmē "next argument" skaitītāju, tāpēc parasti ir ieteicams atsaukties uz argumentiem pēc pozīcijas vai izmantot nosauktos argumentus.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Papildu aizpildīšanas rakstzīmi un izlīdzināšanu parasti nodrošina kopā ar parametru [`width`](#width).Tas jādefinē pirms `width`, tūlīt pēc `:`.
//! Tas norāda, ka, ja formatējamā vērtība ir mazāka par `width`, ap to tiks drukātas dažas papildu rakstzīmes.
//! Dažādiem izlīdzinājumiem ir šādi varianti:
//!
//! * `[fill]<` - arguments ir līdzināts pa kreisi `width` kolonnās
//! * `[fill]^` - arguments ir līdzināts centrā `width` kolonnās
//! * `[fill]>` - arguments ir taisnots pa labi `width` kolonnās
//!
//! Noklusējuma skaitlis [fill/alignment](#fillalignment) ir atstarpe un līdzinājums pa kreisi.Skaitlisko formatētāju noklusējums ir arī atstarpes raksturs, bet ar labo līdzinājumu.
//! Ja cipariem ir norādīts karodziņš `0` (skatīt zemāk), netiešais aizpildīšanas raksturs ir `0`.
//!
//! Ņemiet vērā, ka dažu veidu izlīdzināšana var nebūt ieviesta.Jo īpaši tas nav ieviests `Debug` trait.
//! Labs veids, kā nodrošināt, ka tiek izmantots polsterējums, ir formatēt ievadi, pēc tam spilventināt šo iegūto virkni, lai iegūtu izvadi:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Sveiki, Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Tie visi ir karodziņi, kas maina formatētāja uzvedību.
//!
//! * `+` - Tas ir paredzēts ciparu tipiem un norāda, ka zīme vienmēr ir jādrukā.Pozitīvas zīmes pēc noklusējuma nekad netiek drukātas, un negatīvā zīme pēc noklusējuma tiek drukāta tikai `Signed` trait.
//! Šis karodziņš norāda, ka vienmēr ir jādrukā pareizā zīme (`+` vai `-`).
//! * `-` - Pašlaik netiek izmantots
//! * `#` - Šis karodziņš norāda, ka jāizmanto drukāšanas forma "alternate".Alternatīvās formas ir:
//!     * `#?` - diezgan izdrukājiet [`Debug`] formatējumu
//!     * `#x` - pirms argumenta ar `0x`
//!     * `#X` - pirms argumenta ar `0x`
//!     * `#b` - pirms argumenta ar `0b`
//!     * `#o` - pirms argumenta ar `0o`
//! * `0` - Tas tiek izmantots, lai norādītu veselu skaitļu formātiem, ka `width` aizpildīšana jāveic gan ar `0` rakstzīmi, gan arī ir jāzina par zīmēm.
//! Tāds formāts kā `{:08}` iegūtu `00000001` skaitlim `1`, bet tas pats formāts `-0000001`-skaitlim `-1`.
//! Ievērojiet, ka negatīvajai versijai ir par vienu nulli mazāk nekā pozitīvajai versijai.
//!         Ņemiet vērā, ka polsterējuma nulles vienmēr tiek ievietotas aiz zīmes (ja tāda ir) un pirms cipariem.Lietojot kopā ar karogu `#`, tiek piemērots līdzīgs noteikums: polsterējuma nulles tiek ievietotas aiz prefiksa, bet pirms cipariem.
//!         Prefikss ir iekļauts kopējā platumā.
//!
//! ## Precision
//!
//! Bez ciparu tipiem to var uzskatīt par "maximum width".
//! Ja iegūtā virkne ir garāka par šo platumu, tā tiek saīsināta līdz šīm daudzajām rakstzīmēm un šī saīsinātā vērtība tiek izstarota ar pareizām `fill`, `alignment` un `width`, ja šie parametri ir iestatīti.
//!
//! Neatņemamiem tipiem tas tiek ignorēts.
//!
//! Peldošā komata tipiem tas norāda, cik ciparu aiz komata ir jādrukā.
//!
//! Ir trīs iespējamie veidi, kā norādīt vēlamo `precision`:
//!
//! 1. Vesels skaitlis `.N`:
//!
//!    pats skaitlis `N` ir precizitāte.
//!
//! 2. Vesels skaitlis vai nosaukums, kam seko dolāra zīme `.N$`:
//!
//!    kā precizitāti izmantojiet formātu *arguments*`N` (kuram jābūt `usize`).
//!
//! 3. Zvaigznīte `.*`:
//!
//!    `.*` nozīmē, ka šī `{...}` ir saistīta ar *divām* formāta ieejām, nevis ar vienu: pirmajai ieejai ir `usize` precizitāte, bet otrajai-drukājamā vērtība.
//!    Ņemiet vērā, ka šajā gadījumā, ja tiek izmantota formāta virkne `{<arg>:<spec>.*}`, tad `<arg>` daļa attiecas uz* vērtību *, lai drukātu, un `precision` jānāk ievadē pirms `<arg>`.
//!
//! Piemēram, visi šie zvani drukā vienu un to pašu `Hello x is 0.01000`:
//!
//! ```
//! // Sveiki, {arg 0 ("x")} ir {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Sveiki, {arg 1 ("x")} ir {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Sveiki, {arg 0 ("x")} ir {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Sveiki, {next arg ("x")} ir {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Sveiki, {next arg ("x")} ir {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Sveiki, {next arg ("x")} ir {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Lai gan šie:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! izdrukājiet trīs ievērojami atšķirīgas lietas:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Dažās programmēšanas valodās virkņu formatēšanas funkciju darbība ir atkarīga no operētājsistēmas lokalizācijas iestatījuma.
//! Rust standarta bibliotēkas piedāvātajām formāta funkcijām nav lokalizācijas jēdziena, un tās nodrošinās vienādus rezultātus visās sistēmās neatkarīgi no lietotāja konfigurācijas.
//!
//! Piemēram, šāds kods vienmēr izdrukās `1.5`, pat ja sistēmas lokalizācijā tiek izmantots decimālskaitlis, nevis punkts.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Burtiskās rakstzīmes `{` un `}` var iekļaut virknē, aiz tām aizvietojot to pašu rakstzīmi.Piemēram, rakstzīme `{` tiek izvadīta ar `{{`, bet rakstzīme `}` tiek izdzēsta ar `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Apkopojot, šeit varat atrast pilnu formāta virkņu gramatiku.
//! Izmantotās formatēšanas valodas sintakse ir iegūta no citām valodām, tāpēc tai nevajadzētu būt pārāk svešai.Argumenti ir formatēti ar Python līdzīgu sintaksi, kas nozīmē, ka argumentus C X veida X vietā ieskauj `{}`.
//! Faktiskā formatēšanas sintakses gramatika ir šāda:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Iepriekš minētajā gramatikā `text` nedrīkst saturēt `'{'` vai `'}'` rakstzīmes.
//!
//! # traits formatēšana
//!
//! Pieprasot argumenta formatēšanu ar noteiktu tipu, jūs faktiski pieprasāt, lai arguments tiktu attiecināts uz konkrētu trait.
//! Tas ļauj formatēt vairākus faktiskos veidus, izmantojot `{:x}` (piemēram, [`i8`], kā arī [`isize`]).Pašreizējā tipu kartēšana ar traits ir:
//!
//! * *nekas* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] ar mazajiem burtiem heksadecimālos skaitļus
//! * `X?` ⇒ [`Debug`] ar lielajiem burtiem heksadecimālajiem skaitļiem
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Tas nozīmē, ka jebkura veida argumentus, kas īsteno [`fmt::Binary`][`Binary`] trait, var formatēt ar `{:b}`.Standarta bibliotēka nodrošina arī šo traits ieviešanu vairākiem primitīviem tipiem.
//!
//! Ja formāts nav norādīts (kā `{}` vai `{:6}`), tad izmantotais formāts trait ir [`Display`] trait.
//!
//! Īstenojot sava veida formātu trait, jums būs jāievieš paraksta metode:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // mūsu pielāgotais tips
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Jūsu tips tiks nodots kā atsauce uz `self`, un pēc tam funkcijai vajadzētu izstarot `f.buf` straumē.Pareizi ievērot pieprasītos formatēšanas parametrus ir katra trait ieviešanas formāta ziņā.
//! Šo parametru vērtības tiks uzskaitītas [`Formatter`] struktūras laukos.Lai to palīdzētu, [`Formatter`] struct nodrošina arī dažas palīgu metodes.
//!
//! Turklāt šīs funkcijas atgriešanās vērtība ir [`fmt::Result`], kas ir tipa aizstājvārds: [Result`] <<(),`[`std::Error`] `` `.
//! Īstenošanas formatēšanai jānodrošina, lai tās izplatītu kļūdas no [`Formatter`] (piemēram, izsaucot [`write!`]).
//! Tomēr viņiem nekad nevajadzētu kļūdaini atgriezties pie kļūdām.
//! Tas nozīmē, ka formatēšanas ieviešanai ir jāatgriež kļūda tikai tad, ja ievadītā [`Formatter`] atgriež kļūdu.
//! Tas ir tāpēc, ka pretēji tam, ko varētu ieteikt funkcijas paraksts, virknes formatēšana ir nekļūdīga darbība.
//! Šī funkcija atgriež rezultātu tikai tāpēc, ka rakstīšana pamatā esošajā straumē var neizdoties, un tai jānodrošina veids, kā izplatīt faktu, ka dublējuma kaudzē ir notikusi kļūda.
//!
//! Formatēšanas traits ieviešanas piemērs varētu izskatīties šādi:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // `f` vērtība ievieš `Write` trait, ko raksta!makro gaida.
//!         // Ņemiet vērā, ka šis formatējums ignorē dažādus karodziņus, kas tiek piedāvāti virkņu formatēšanai.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Dažādi traits pieļauj dažādas veida izvades formas.
//! // Šī formāta nozīme ir vector lieluma drukāšanai.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Ievērojiet formatēšanas karodziņus, izmantojot Formatter objektā palīgmetodi `pad_integral`.
//!         // Sīkāku informāciju skatiet metodes dokumentācijā, un funkciju `pad` var izmantot virkņu pildīšanai.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` pret `fmt::Debug`
//!
//! Šiem diviem traits formatējumiem ir atšķirīgi mērķi:
//!
//! - [`fmt::Display`][`Display`] implementācijas apgalvo, ka veidu vienmēr var uzticami attēlot kā UTF-8 virkni.** Nav paredzams, ka visi tipi ieviesīs [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] ieviešana jāievieš **visiem** publiskajiem tipiem.
//!   Rezultāts parasti pēc iespējas ticamāk atspoguļo iekšējo stāvokli.
//!   [`Debug`] trait mērķis ir atvieglot Rust koda atkļūdošanu.Vairumā gadījumu `#[derive(Debug)]` lietošana ir pietiekama un ieteicama.
//!
//! Daži izejas no abiem traits piemēri:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Saistītie makro
//!
//! [`format!`] saimē ir vairāki saistīti makro.Pašlaik tiek ieviesti šādi:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Šis un [`writeln!`] ir divi makro, kurus izmanto formāta virknes izstarošanai noteiktā straumē.To lieto, lai novērstu formāta virkņu starpposma piešķiršanu un tā vietā tieši uzrakstītu izvadi.
//! Zem pārsega šī funkcija faktiski atsaucas uz funkciju [`write_fmt`], kas definēta [`std::io::Write`] trait.
//! Lietojuma piemērs ir:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Šis un [`println!`] izstaro to izvadi uz stdout.Līdzīgi kā makro [`write!`], šo makro mērķis ir izvairīties no starpposma piešķiršanas, izdrukājot izvadi.Lietojuma piemērs ir:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! [`eprint!`] un [`eprintln!`] makro ir identiski attiecīgi [`print!`] un [`println!`], izņemot to, ka tie izstaro savu izvadi uz stderr.
//!
//! ### `format_args!`
//!
//! Šis ir ziņkārīgs makro, ko izmanto, lai droši apietu necaurspīdīgu objektu, kas apraksta formāta virkni.Lai izveidotu šo objektu, nav nepieciešami kaudzes piešķīrumi, un tas atsaucas tikai uz informāciju kaudzē.
//! Zem pārsega visi saistītie makro tiek ieviesti šajā ziņā.
//! Pirmkārt, daži lietošanas piemēri ir:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! [`format_args!`] makro rezultāts ir [`fmt::Arguments`] tipa vērtība.
//! Pēc tam šo struktūru var nodot [`write`] un [`format`] funkcijām šajā modulī, lai apstrādātu formāta virkni.
//! Šī makro mērķis ir vēl vairāk novērst starpposma piešķiršanu, rīkojoties ar virkņu formatēšanu.
//!
//! Piemēram, reģistrēšanas bibliotēkā varētu izmantot standarta formatēšanas sintaksi, taču tā iekšēji apietu šo struktūru līdz brīdim, kad būs noteikts, kurp jāiziet izejai.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Funkcija `format` aizņem [`Arguments`] struktūru un atgriež iegūto formatēto virkni.
///
///
/// [`Arguments`] instanci var izveidot ar [`format_args!`] makro.
///
/// # Examples
///
/// Pamata lietojums:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Lūdzu, ņemiet vērā, ka ieteicams izmantot [`format!`].
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}