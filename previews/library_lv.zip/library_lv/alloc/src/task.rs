#![stable(feature = "wake_trait", since = "1.51.0")]
//! Veidi un Traits darbam ar asinhroniem uzdevumiem.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Izpildītāja modināšanas uzdevuma izpilde.
///
/// Šo trait var izmantot, lai izveidotu [`Waker`].
/// Izpildītājs var definēt šī trait ieviešanu un izmantot to, lai izveidotu modinātāju, kas nodotu uzdevumus, kas tiek izpildīti šim izpildītājam.
///
/// Šis trait ir atmiņā droša un ergonomiska alternatīva [`RawWaker`] konstruēšanai.
/// Tas atbalsta parasto izpildītāja dizainu, kurā dati, kas tiek izmantoti, lai pamodinātu uzdevumu, tiek saglabāti [`Arc`].
/// Daži izpildītāji (īpaši iegulto sistēmu izpildītāji) nevar izmantot šo API, tāpēc [`RawWaker`] pastāv kā alternatīva šīm sistēmām.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Pamata `block_on` funkcija, kas aizņem future un palaiž to līdz pašreizējam pavedienam.
///
/// **Note:** Šis piemērs tirgo pareizību vienkāršības labad.
/// Lai novērstu strupceļus, ražošanas līmeņa ieviešanai būs jāapstrādā arī starpzvani uz `thread::unpark`, kā arī ligzdoti izsaukumi.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Modinātājs, kurš pamodina pašreizējo pavedienu, kad viņu izsauc.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Palaidiet future līdz pabeigšanai pašreizējā pavedienā.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Piespraudiet future, lai to varētu aptaujāt.
///     let mut fut = Box::pin(fut);
///
///     // Izveidojiet jaunu kontekstu, kas jānodod future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Palaidiet future līdz beigām.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Pamodiniet šo uzdevumu.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Veiciet šo uzdevumu, neizmantojot modinātāju.
    ///
    /// Ja izpildītājs atbalsta lētāku modināšanas veidu, neizmantojot modinātāju, tam vajadzētu ignorēt šo metodi.
    /// Pēc noklusējuma tas klonē [`Arc`] un uz klona izsauc [`wake`].
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // DROŠĪBA: Tas ir droši, jo raw_waker droši konstruē
        // RawWaker no Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Šī privātā funkcija RawWaker izveidošanai tiek izmantota nevis
// iekļaujot to `From<Arc<W>> for RawWaker` impl, lai nodrošinātu, ka `From<Arc<W>> for Waker` drošība nav atkarīga no pareizas trait nosūtīšanas, tā vietā abi impli šo funkciju izsauc tieši un nepārprotami.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Palieliniet loka atskaites skaitu, lai to klonētu.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Pamodieties pēc vērtības, pārvietojot loku uz funkciju Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Pamodiniet ar atsauci, ietiniet modinātāju ManuallyDrop, lai izvairītos no tā nomešanas
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Samaziniet loka atskaites skaitu kritiena laikā
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}