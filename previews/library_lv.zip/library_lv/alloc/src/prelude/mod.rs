//! Piešķīrums Prelude
//!
//! Šī moduļa mērķis ir atvieglot `alloc` crate parasti izmantoto vienumu importu, moduļu augšdaļā pievienojot globālo importu:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;