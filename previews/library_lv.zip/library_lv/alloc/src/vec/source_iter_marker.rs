use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Specializācijas marķieris iteratora cauruļvada savākšanai Vec, atkārtoti izmantojot avota sadalījumu, ti
/// izpildot cauruļvadu vietā.
///
/// SourceIter vecāks trait ir nepieciešams specializācijas funkcijai, lai piekļūtu atkārtoti izmantojamajam piešķīrumam.
/// Bet nepietiek, lai specializācija būtu derīga.
/// Skatiet implanta papildu robežas.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std iekšējo SourceIter/InPlaceIterable traits ievieš tikai adaptera ķēdes <Adapter<Adapter<IntoIter>>> (visi pieder core/std).
// Papildu robežas adaptera ieviešanā (ārpus `impl<I: Trait> Trait for Adapter<I>`) ir atkarīgas tikai no citiem traits, kas jau ir atzīmēti kā specializācija traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. marķieris nav atkarīgs no lietotāju piegādāto tipu dzīves ilguma.Modulo the Copy hole, no kura jau ir atkarīgas vairākas citas specializācijas.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Papildu prasības, kuras nevar izteikt, izmantojot trait bound.Mēs tā vietā paļaujamies uz const eval:
        // a) nav ZST, jo netiktu piešķirta atkārtota izmantošana, un rādītāju aritmētika būtu panic b) lieluma atbilstība, kā to prasa Alloc līgums, c) izlīdzinājumi sakrīt, kā prasīts Alloc līgumā
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // alternatīvāka ieviešana
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // izmantojiet try-fold kopš tā laika
        // - tas labāk vektorizējas dažiem iteratora adapteriem
        // - atšķirībā no vairuma iekšējo iterācijas metožu, tas prasa tikai &mut sevi
        // - tas ļauj mums pavedināt rakstīšanas rādītāju caur iekšpusi un beigās to atgūt
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // atkārtojums izdevās, nenomet galvu
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // pārbaudiet, vai SourceIter līgums tika ievērots, ievērojot atrunu: ja viņi nebūtu, mēs, iespējams, pat nenokļūsim līdz šai vietai
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // pārbaudiet InPlaceIterable līgumu.Tas ir iespējams tikai tad, ja iterators vispār izvirza avota rādītāju.
        // Ja tas izmanto nepārbaudītu piekļuvi, izmantojot TrustedRandomAccess, avota rādītājs paliks sākotnējā pozīcijā, un mēs to nevaram izmantot kā atsauci
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // nometiet visas atlikušās vērtības avota astē, bet novērsiet pašas piešķiršanas kritumu, kad IntoIter izies no darbības jomas, ja kritums panics tad mēs arī noplūdīsim visus dst_buf savāktos elementus
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // InPlaceIterable līgumu šeit nevar precīzi pārbaudīt, jo try_fold ir ekskluzīva atsauce uz avota rādītāju, un mēs varam tikai pārbaudīt, vai tas joprojām ir diapazonā
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}