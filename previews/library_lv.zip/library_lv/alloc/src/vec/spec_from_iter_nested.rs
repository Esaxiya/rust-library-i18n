use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// Vēl viena specializācija trait Vec::from_iter, kas nepieciešama, lai manuāli piešķirtu prioritāti pārklāšanās specializācijām, detalizētu informāciju skatiet [`SpecFromIter`](super::SpecFromIter).
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Ritiniet pirmo atkārtojumu, jo vector tiks paplašināts šajā iterācijā visos gadījumos, kad iterācija nav tukša, bet extend_desugared() cilpa neredzēs, ka vector ir pilns dažās nākamajās cilpu atkārtojumos.
        //
        // Tātad mēs saņemam labāku branch prognozi.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // jādeleģē spec_extend(), jo extend() pati deleģē spec_from tukšām Vecs
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // jādeleģē spec_extend(), jo extend() pati deleģē spec_from tukšām Vecs
        //
        vector.spec_extend(iterator);
        vector
    }
}