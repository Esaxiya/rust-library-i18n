use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Specializācija trait, ko izmanto Vec::from_iter
///
/// ## Delegācijas grafiks:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Izplatīts gadījums ir vector nodošana funkcijā, kas nekavējoties atkal tiek savākta vector.
        // Mēs varam to īssavienot, ja IntoIter vispār nav uzlabots.
        // Kad tas ir uzlabots, mēs varam arī atkārtoti izmantot atmiņu un pārvietot datus uz priekšu.
        // Bet mēs to darām tikai tad, ja iegūtajam Vecam nebūtu vairāk neizmantotas jaudas nekā to izveidot, izmantojot vispārējo FromIterator ieviešanu.
        //
        // Šis ierobežojums nav absolūti nepieciešams, jo Veca rīcība ir apzināti nenoteikta.
        // Bet tā ir konservatīva izvēle.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // jādeleģē spec_extend(), jo extend() pati deleģē spec_from tukšām Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Tas izmanto `iterator.as_slice().to_vec()`, jo spec_extend ir jāveic vairākas darbības, lai apsvērtu galīgo jaudu + garumu, un tādējādi jāpaveic vairāk darba.
// `to_vec()` tieši piešķir pareizo summu un precīzi to aizpilda.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): ar cfg(test) raksturīgā metode `[T]::to_vec`, kas nepieciešama šīs metodes definēšanai, nav pieejama.
    // Tā vietā izmantojiet funkciju `slice::to_vec`, kas ir pieejama tikai ar cfg(test) NB, lai iegūtu papildinformāciju, skatiet slice::hack moduli slice.rs.
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}