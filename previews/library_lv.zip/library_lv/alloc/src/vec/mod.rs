//! Blakus augams masīva tips ar kaudzei piešķirtu saturu, uzrakstīts `Vec<T>`.
//!
//! Vectors ir `O(1)` indeksēšana, amortizēta `O(1)` push (līdz beigām) un `O(1)` pop (no beigām).
//!
//!
//! Vectors nodrošina, ka tie nekad nepiešķir vairāk par `isize::MAX` baitiem.
//!
//! # Examples
//!
//! Varat skaidri izveidot [`Vec`] ar [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... vai izmantojot [`vec!`] makro:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // desmit nulles
//! ```
//!
//! [`push`] vērtības varat ievietot vector galā (kas pēc vajadzības palielinās vector):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Popping vērtības darbojas gandrīz tāpat:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors atbalsta arī indeksēšanu (izmantojot [`Index`] un [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Blakus augams masīva tips, kas rakstīts kā `Vec<T>` un izteikts kā 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Lai atvieglotu inicializēšanu, tiek nodrošināts [`vec!`] makro:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Tas var arī inicializēt katru `Vec<T>` elementu ar noteiktu vērtību.
/// Tas var būt efektīvāk nekā veikt piešķiršanu un inicializēšanu atsevišķās darbībās, it īpaši, inicializējot nulles vector:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Šis ir līdzvērtīgs, bet potenciāli lēnāks:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Lai iegūtu papildinformāciju, skatiet [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Izmantojiet `Vec<T>` kā efektīvu kaudzīti:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Izdrukā 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// `Vec` tips ļauj piekļūt vērtībām pēc indeksa, jo tas ievieš [`Index`] trait.Piemērs būs precīzāks:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // tas parādīs '2'
/// ```
///
/// Tomēr esiet piesardzīgs: ja mēģināt piekļūt indeksam, kas nav `Vec`, jūsu programmatūra būs panic!Jūs to nevarat izdarīt:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Izmantojiet [`get`] un [`get_mut`], ja vēlaties pārbaudīt, vai indekss atrodas `Vec`.
///
/// # Slicing
///
/// `Vec` var būt maināms.No otras puses, šķēles ir tikai lasāmi objekti.
/// Lai iegūtu [slice][prim@slice], izmantojiet [`&`].Piemērs:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... un tas arī viss!
/// // to var izdarīt arī šādi:
/// let u: &[usize] = &v;
/// // vai šādi:
/// let u: &[_] = &v;
/// ```
///
/// Programmā Rust biežāk šķēles tiek nodotas kā argumenti, nevis vectors, ja vēlaties tikai nodrošināt piekļuvi lasīšanai.Tas pats attiecas uz [`String`] un [`&str`].
///
/// # Jauda un pārdale
///
/// vector ietilpība ir vietas daudzums, kas piešķirts visiem future elementiem, kas tiks pievienoti vector.To nedrīkst sajaukt ar vector *garumu*, kas norāda faktisko elementu skaitu vector.
/// Ja vector garums pārsniedz tā jaudu, tā jauda tiks automātiski palielināta, bet tā elementi būs jāpārdala.
///
/// Piemēram, vector ar ietilpību 10 un garumu 0 būtu tukšs vector ar vietu vēl 10 elementiem.10 vai mazāk elementu nospiešana uz vector nemainīs tā jaudu un neradīs pārdali.
/// Tomēr, ja vector garums tiks palielināts līdz 11, tas būs jāpārdala, kas var būt lēns.Šī iemesla dēļ ieteicams izmantot [`Vec::with_capacity`], kad vien iespējams, lai norādītu, cik liels ir vector lielums.
///
/// # Guarantees
///
/// Neticami fundamentālā rakstura dēļ `Vec` sniedz daudz garantiju par tā dizainu.Tas nodrošina, ka tā vispārējā gadījumā ir pēc iespējas zemāka par vispārējām izmaksām, un ar nedrošu kodu to var pareizi manipulēt primitīvos veidos.Ņemiet vērā, ka šīs garantijas attiecas uz nekvalificētu `Vec<T>`.
/// Ja tiek pievienoti papildu tipa parametri (piemēram, lai atbalstītu pielāgotus sadalītājus), to noklusējuma ignorēšana var mainīt uzvedību.
///
/// Būtībā `Vec` ir un vienmēr būs (rādītājs, ietilpība, garums) triplets.Ne vairāk, ne mazāk.Šo lauku secība ir pilnīgi nenoteikta, un, lai tos modificētu, izmantojiet atbilstošās metodes.
/// Rādītājs nekad nebūs null, tāpēc šis tips ir optimizēts ar nulli.
///
/// Tomēr rādītājs var faktiski nenorādīt uz piešķirto atmiņu.
/// Jo īpaši, ja jūs izveidojat `Vec` ar jaudu 0, izmantojot [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`] vai izsaucot [`shrink_to_fit`] tukšā Vec, tas nepiešķirs atmiņu.Līdzīgi, ja `Vec` glabājat nulles izmēra tipus, tas tiem nepiešķirs vietu.
/// *Ņemiet vērā, ka šajā gadījumā `Vec` var neziņot par [`capacity`] ar 0*.
/// `Vec` piešķirs tikai tad, ja [`mem: : size_of::<T>"](() * capacity()> 0".
/// Kopumā `Vec` piešķiršanas informācija ir ļoti smalka-ja jūs plānojat piešķirt atmiņu, izmantojot `Vec`, un izmantot to kaut kam citam (vai nu nodošanai nedrošam kodam, vai arī izveidot savu atmiņā atbalstītu kolekciju), pārliecinieties, ka lai atdalītu šo atmiņu, izmantojot `from_raw_parts`, lai atjaunotu `Vec`, un pēc tam to nometot.
///
/// Ja `Vec`*ir* piešķirta atmiņa, tad atmiņa, uz kuru tā norāda, atrodas uz kaudzes (kā noteicis sadalītājs Rust ir konfigurēts lietošanai pēc noklusējuma), un tās rādītājs norāda uz [`len`] inicializētus, blakus esošus elementus secībā (kā jūs gribētu redziet, vai jūs to piespiedāt šķēlei), kam seko [`kapacitāte`]`,`[``len`] loģiski neinicializēti, blakus esošie elementi.
///
///
/// vector, kas satur elementus `'a'` un `'b'` ar ietilpību 4, var vizualizēt, kā parādīts zemāk.Augšējā daļa ir `Vec` struktūra, tajā ir norāde uz sadalījuma galvu kaudzē, garumā un ietilpībā.
/// Apakšējā daļa ir sadalījums uz kaudzes, blakus esošais atmiņas bloks.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** apzīmē atmiņu, kas nav inicializēta, skatiet [`MaybeUninit`].
/// - Note: ABI nav stabils, un `Vec` nedod nekādas garantijas par tā atmiņas izkārtojumu (ieskaitot lauku secību).
///
/// `Vec` nekad neveiks "small optimization", ja elementi faktiski tiek glabāti kaudzē divu iemeslu dēļ:
///
/// * Nedrošam kodam būtu grūtāk pareizi manipulēt ar `Vec`.`Vec` saturam nebūtu stabilas adreses, ja to tikai pārvietotu, un būtu grūtāk noteikt, vai `Vec` tiešām ir piešķīris atmiņu.
///
/// * Tas sodītu vispārējo gadījumu, katrai piekļuvei radot papildu branch.
///
/// `Vec` nekad automātiski nesamazināsies pati, pat ja tā būs pilnīgi tukša.Tas nodrošina nevajadzīgu sadali vai darījumu izvietošanu.Iztukšojot `Vec` un pēc tam to aizpildot līdz tam pašam [`len`], nevajadzētu izsaucējiem izsaukt.Ja vēlaties atbrīvot neizmantoto atmiņu, izmantojiet [`shrink_to_fit`] vai [`shrink_to`].
///
/// [`push`] un [`insert`] nekad (atkārtoti) nepiešķirs, ja norādītā jauda ir pietiekama.[`push`] un [`insert`] * tiks (atkārtoti) piešķirti, ja [`len`]`==`[`kapacitāte`].Tas ir, ziņotā jauda ir pilnīgi precīza, un uz to var paļauties.Ja vēlaties, to var pat izmantot, lai manuāli atbrīvotu `Vec` piešķirto atmiņu.
/// Lielapjoma ievietošanas metodes *var* pārdalīt, pat ja tas nav nepieciešams.
///
/// `Vec` negarantē nekādu īpašu izaugsmes stratēģiju, pārdalot tos pilnībā vai arī tad, kad tiek izsaukts [`reserve`].Pašreizējā stratēģija ir pamata, un var izrādīties vēlams izmantot nemainīgu izaugsmes faktoru.Jebkura izmantotā stratēģija, protams, garantēs *O*(1) amortizēto [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]` un [`Vec::with_capacity(n)`][`Vec::with_capacity`] visi ražos `Vec` ar tieši nepieciešamo jaudu.
/// Ja [`len`]`==`[`kapacitāte`](kā tas ir makro [`vec!`] gadījumā), tad `Vec<T>` var pārveidot par [`Box<[T]>`][owned slice] un no tā, nepārdalot vai nepārvietojot elementus.
///
/// `Vec` īpaši nepārrakstīs no tā noņemtos datus, bet arī tos īpaši nesaglabās.Tās neinicializētā atmiņa ir vieta, no kuras tā var izlietot, kā vēlas.Parasti tā darīs visu, kas ir visefektīvākais vai kā citādi viegli īstenojams.Nepaļaujieties uz noņemto datu izdzēšanu drošības nolūkos.
/// Pat ja jūs nomest `Vec`, tā buferi var vienkārši atkārtoti izmantot cits `Vec`.
/// Pat ja vispirms nulle esat `Vec` atmiņā, tas var nenotikt, jo optimizētājs to neuzskata par blakus efektu, kas jāsaglabā.
/// Tomēr ir viens gadījums, kuru mēs nepārkāpsim: `unsafe` koda izmantošana, lai ierakstītu jaudas pārsniegšanā, un pēc tam garuma palielināšana, lai tas atbilstu, vienmēr ir derīgs.
///
/// Pašlaik `Vec` negarantē elementu nomešanas kārtību.
/// Kārtība agrāk ir mainījusies un var mainīties vēlreiz.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Raksturīgas metodes
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Konstruē jaunu, tukšu `Vec<T>`.
    ///
    /// vector netiks piešķirts, kamēr elementi uz to nav piespiesti.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Konstruē jaunu, tukšu `Vec<T>` ar norādīto ietilpību.
    ///
    /// vector varēs turēt tieši `capacity` elementus, nepārdalot tos citādi.
    /// Ja `capacity` ir 0, vector netiks piešķirts.
    ///
    /// Ir svarīgi atzīmēt, ka, lai arī atgrieztajam vector ir norādītā *ietilpība*, vector būs nulle *garums*.
    ///
    /// Skaidrojumu par atšķirību starp garumu un ietilpību skatiet *[Jauda un pārdalīšana]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector nesatur vienumus, kaut arī tajā ir iespējas vairāk
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Tie visi tiek veikti, nepārdalot ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... bet tas var padarīt vector pārdalītu
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Izveido `Vec<T>` tieši no cita vector neapstrādātiem komponentiem.
    ///
    /// # Safety
    ///
    /// Tas ir ļoti nedroši, jo netiek pārbaudīti invarianti:
    ///
    /// * `ptr` iepriekš jāpiešķir, izmantojot [`String`]/`Vec<T>"(Vismaz, visticamāk, tas būs nepareizi, ja tā nebūtu).
    /// * `T` jābūt tādam pašam izmēram un izlīdzinājumam kā `ptr`.
    ///   (`T` ar mazāk stingru izlīdzināšanu nav pietiekami, izlīdzināšanai patiešām jābūt vienādai, lai izpildītu [`dealloc`] prasību, ka atmiņa jāpiešķir un jānovieto ar tādu pašu izkārtojumu.)
    ///
    /// * `length` jābūt mazākam vai vienādam ar `capacity`.
    /// * `capacity` jābūt jaudai, ar kuru rādītājs tika piešķirts.
    ///
    /// To pārkāpšana var radīt tādas problēmas kā sadalītāja iekšējo datu struktūru bojāšana.Piemēram,**nav** droši veidot `Vec<u8>` no rādītāja uz masīvu C `char` ar garumu `size_t`.
    /// Nav arī droši to izveidot no `Vec<u16>` un tā garuma, jo sadalītājam ir svarīga izlīdzināšana, un šiem diviem veidiem ir atšķirīgi izlīdzinājumi.
    /// Buferis tika piešķirts ar 2. izlīdzināšanu (`u16`), bet pēc tā pārveidošanas par `Vec<u8>` tas tiks sadalīts ar 1. izlīdzināšanu.
    ///
    /// Īpašumtiesības uz `ptr` faktiski tiek nodotas `Vec<T>`, kas pēc tam var sadalīt, pārdalīt vai mainīt atmiņas saturu, uz kuru norāda rādītājs pēc vēlēšanās.
    /// Pēc šīs funkcijas izsaukšanas pārliecinieties, ka nekas cits neizmanto rādītāju.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Atjauniniet to, kad vec_into_raw_parts ir stabilizēts.
    ///     // Neļaujiet darbināt `v` destruktoru, lai mēs pilnībā kontrolētu piešķiršanu.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Izvelciet dažādu svarīgu informāciju par `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Pārrakstīt atmiņu ar 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Salieciet visu kopā Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Konstruē jaunu, tukšu `Vec<T, A>`.
    ///
    /// vector netiks piešķirts, kamēr elementi uz to nav piespiesti.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Ar paredzēto sadalītāju izveido jaunu, tukšu `Vec<T, A>` ar norādīto ietilpību.
    ///
    /// vector varēs turēt tieši `capacity` elementus, nepārdalot tos citādi.
    /// Ja `capacity` ir 0, vector netiks piešķirts.
    ///
    /// Ir svarīgi atzīmēt, ka, lai arī atgrieztajam vector ir norādītā *ietilpība*, vector būs nulle *garums*.
    ///
    /// Skaidrojumu par atšķirību starp garumu un ietilpību skatiet *[Jauda un pārdalīšana]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector nesatur vienumus, kaut arī tajā ir iespējas vairāk
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Tie visi tiek veikti, nepārdalot ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... bet tas var padarīt vector pārdalītu
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Izveido `Vec<T, A>` tieši no cita vector neapstrādātiem komponentiem.
    ///
    /// # Safety
    ///
    /// Tas ir ļoti nedroši, jo netiek pārbaudīti invarianti:
    ///
    /// * `ptr` iepriekš jāpiešķir, izmantojot [`String`]/`Vec<T>"(Vismaz, visticamāk, tas būs nepareizi, ja tā nebūtu).
    /// * `T` jābūt tādam pašam izmēram un izlīdzinājumam kā `ptr`.
    ///   (`T` ar mazāk stingru izlīdzināšanu nav pietiekami, izlīdzināšanai patiešām jābūt vienādai, lai izpildītu [`dealloc`] prasību, ka atmiņa jāpiešķir un jānovieto ar tādu pašu izkārtojumu.)
    ///
    /// * `length` jābūt mazākam vai vienādam ar `capacity`.
    /// * `capacity` jābūt jaudai, ar kuru rādītājs tika piešķirts.
    ///
    /// To pārkāpšana var radīt tādas problēmas kā sadalītāja iekšējo datu struktūru bojāšana.Piemēram,**nav** droši veidot `Vec<u8>` no rādītāja uz masīvu C `char` ar garumu `size_t`.
    /// Nav arī droši to izveidot no `Vec<u16>` un tā garuma, jo sadalītājam ir svarīga izlīdzināšana, un šiem diviem veidiem ir atšķirīgi izlīdzinājumi.
    /// Buferis tika piešķirts ar 2. izlīdzināšanu (`u16`), bet pēc tā pārveidošanas par `Vec<u8>` tas tiks sadalīts ar 1. izlīdzināšanu.
    ///
    /// Īpašumtiesības uz `ptr` faktiski tiek nodotas `Vec<T>`, kas pēc tam var sadalīt, pārdalīt vai mainīt atmiņas saturu, uz kuru norāda rādītājs pēc vēlēšanās.
    /// Pēc šīs funkcijas izsaukšanas pārliecinieties, ka nekas cits neizmanto rādītāju.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Atjauniniet to, kad vec_into_raw_parts ir stabilizēts.
    ///     // Neļaujiet darbināt `v` destruktoru, lai mēs pilnībā kontrolētu piešķiršanu.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Izvelciet dažādu svarīgu informāciju par `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Pārrakstīt atmiņu ar 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Salieciet visu kopā Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Sadalās `Vec<T>` tā izejvielās.
    ///
    /// Atgriež sākotnējo rādītāju pamatā esošajiem datiem, vector garumam (elementos) un datu piešķirtajai jaudai (elementos).
    /// Šie ir tie paši argumenti tādā pašā secībā kā argumenti [`from_raw_parts`].
    ///
    /// Pēc šīs funkcijas izsaukšanas zvanītājs ir atbildīgs par atmiņu, kuru iepriekš pārvaldīja `Vec`.
    /// Vienīgais veids, kā to izdarīt, ir neapstrādātu rādītāju, garumu un ietilpību pārveidot atpakaļ par `Vec` ar funkciju [`from_raw_parts`], ļaujot iznīcinātājam veikt tīrīšanu.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Tagad mēs varam veikt izmaiņas komponentos, piemēram, pārveidot neapstrādātu rādītāju uz saderīgu tipu.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Sadalās `Vec<T>` tā izejvielās.
    ///
    /// Atgriež neapstrādāto rādītāju pamatā esošajiem datiem, vector garumam (elementos), datu piešķirtajai jaudai (elementos) un sadalītājam.
    /// Šie ir tie paši argumenti tādā pašā secībā kā argumenti [`from_raw_parts_in`].
    ///
    /// Pēc šīs funkcijas izsaukšanas zvanītājs ir atbildīgs par atmiņu, kuru iepriekš pārvaldīja `Vec`.
    /// Vienīgais veids, kā to izdarīt, ir neapstrādātu rādītāju, garumu un ietilpību pārveidot atpakaļ par `Vec` ar funkciju [`from_raw_parts_in`], ļaujot iznīcinātājam veikt tīrīšanu.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Tagad mēs varam veikt izmaiņas komponentos, piemēram, pārveidot neapstrādātu rādītāju uz saderīgu tipu.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Atgriež to elementu skaitu, kurus vector var turēt, nepārdalot citus.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Rezervē jaudu vismaz vēl `additional` elementiem, kas jāievieto dotajā `Vec<T>`.
    /// Kolekcijā var būt vairāk vietas, lai izvairītos no biežas pārdalīšanas.
    /// Pēc `reserve` izsaukšanas jauda būs lielāka vai vienāda ar `self.len() + additional`.
    /// Neko nedara, ja jauda jau ir pietiekama.
    ///
    /// # Panics
    ///
    /// Panics, ja jaunā jauda pārsniedz `isize::MAX` baitus.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Rezervē minimālo ietilpību precīzi `additional` vairāk elementu ievietošanai dotajā `Vec<T>`.
    ///
    /// Pēc `reserve_exact` izsaukšanas jauda būs lielāka vai vienāda ar `self.len() + additional`.
    /// Neko nedara, ja jauda jau ir pietiekama.
    ///
    /// Ņemiet vērā, ka piešķīrējs var piešķirt kolekcijai vairāk vietas, nekā tas prasa.
    /// Tāpēc nevar paļauties, ka jauda ir precīzi minimāla.
    /// Dodiet priekšroku `reserve`, ja ir paredzami future ievietojumi.
    ///
    /// # Panics
    ///
    /// Panics, ja jaunā jauda pārpilda `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Mēģina rezervēt jaudu vismaz `additional` vairāk elementu ievietošanai dotajā `Vec<T>`.
    /// Kolekcijā var būt vairāk vietas, lai izvairītos no biežas pārdalīšanas.
    /// Pēc `try_reserve` izsaukšanas jauda būs lielāka vai vienāda ar `self.len() + additional`.
    /// Neko nedara, ja jauda jau ir pietiekama.
    ///
    /// # Errors
    ///
    /// Ja jauda pārpilda vai ja sadalītājs ziņo par kļūmi, tiek atgriezta kļūda.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Iepriekš rezervējiet atmiņu, aizverot, ja mēs to nevaram
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Tagad mēs zinām, ka tas nevar OOM mūsu sarežģītā darba vidū
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ļoti sarežģīti
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Mēģina rezervēt minimālo jaudu tieši `additional` elementiem, kas jāievieto dotajā `Vec<T>`.
    /// Pēc `try_reserve_exact` izsaukšanas jauda būs lielāka vai vienāda ar `self.len() + additional`, ja tā atgriezīs vērtību `Ok(())`.
    ///
    /// Neko nedara, ja jauda jau ir pietiekama.
    ///
    /// Ņemiet vērā, ka piešķīrējs var piešķirt kolekcijai vairāk vietas, nekā tas prasa.
    /// Tāpēc nevar paļauties, ka jauda ir precīzi minimāla.
    /// Dodiet priekšroku `reserve`, ja ir paredzami future ievietojumi.
    ///
    /// # Errors
    ///
    /// Ja jauda pārpilda vai ja sadalītājs ziņo par kļūmi, tiek atgriezta kļūda.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Iepriekš rezervējiet atmiņu, aizverot, ja mēs to nevaram
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Tagad mēs zinām, ka tas nevar OOM mūsu sarežģītā darba vidū
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ļoti sarežģīti
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Cik vien iespējams samazina vector jaudu.
    ///
    /// Tas nokritīs pēc iespējas tuvāk garumam, taču sadalītājs joprojām var informēt vector, ka ir vieta vēl dažiem elementiem.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Jauda nekad nav mazāka par garumu, un nekas nav jādara, ja tie ir vienādi, tāpēc mēs varam izvairīties no panic korpusa `RawVec::shrink_to_fit`, izsaucot to tikai ar lielāku jaudu.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Samazina vector jaudu ar apakšējo robežu.
    ///
    /// Jauda paliks vismaz tikpat liela kā garums, tā piegādātā vērtība.
    ///
    ///
    /// Ja pašreizējā jauda ir mazāka par apakšējo robežu, tas ir aizliegts.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Pārvērš vector par [`Box<[T]>`][owned slice].
    ///
    /// Ņemiet vērā, ka tas samazinās visas jaudas pārpalikumu.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Jebkura liekā jauda tiek noņemta:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Saīsina vector, saglabājot pirmos `len` elementus, bet pārējos nometot.
    ///
    /// Ja `len` ir lielāks par vector pašreizējo garumu, tas neietekmē.
    ///
    /// [`drain`] metode var atdarināt `truncate`, taču lieko elementu atdošana, nevis nomest.
    ///
    ///
    /// Ņemiet vērā, ka šī metode neietekmē vector piešķirto jaudu.
    ///
    /// # Examples
    ///
    /// Piecu elementu vector saīsināšana līdz diviem elementiem:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Ja `len` ir lielāks par vector pašreizējo garumu, tas netiek saīsināts:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Saīsināšana, kad `len == 0` ir ekvivalents [`clear`] metodes izsaukšanai.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Tas ir droši, jo:
        //
        // * `drop_in_place` nodotā šķēle ir derīga;`len > self.len` gadījumā izvairās no nederīgas šķēles izveidošanas un
        // * vector `len` pirms sarunas `drop_in_place` tiek samazināts tā, ka divas reizes netiek pazemināta vērtība, ja `drop_in_place` būtu panic vienreiz (ja panics divreiz, programma pārtrauc darbību).
        //
        //
        //
        unsafe {
            // Note: Tas ir ar nodomu, ka tas ir `>`, nevis `>=`.
            //       Dažos gadījumos tā nomaiņa uz `>=` negatīvi ietekmē veiktspēju.
            //       Lai uzzinātu vairāk, skatiet #78884.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Izvelk šķēli, kas satur visu vector.
    ///
    /// Ekvivalents `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Izrāda maināmu visa vector šķēli.
    ///
    /// Ekvivalents `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Atgriež neapstrādātu rādītāju vector buferī.
    ///
    /// Zvanītājam jāpārliecinās, ka vector pārdzīvo rādītāju, kuru šī funkcija atgriež, pretējā gadījumā tas galu galā norādīs uz atkritumiem.
    /// vector modificēšana var izraisīt tā bufera pārdali, kas arī padarītu visus norādes uz to nederīgu.
    ///
    /// Zvanītājam ir arī jānodrošina, lai atmiņa, uz kuru norāda rādītājs (non-transitively), nekad netiktu ierakstīta (izņemot `UnsafeCell` iekšpusē), izmantojot šo rādītāju vai jebkuru no tā atvasinātu rādītāju.
    /// Ja jums ir nepieciešams pārveidot šķēles saturu, izmantojiet [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Mēs ēnojam tāda paša nosaukuma šķēles metodi, lai izvairītos no `deref`, kas rada starpposma atsauci.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Atgriež nedrošu maināmu rādītāju vector buferī.
    ///
    /// Zvanītājam jāpārliecinās, ka vector pārdzīvo rādītāju, kuru šī funkcija atgriež, pretējā gadījumā tas galu galā norādīs uz atkritumiem.
    ///
    /// vector modificēšana var izraisīt tā bufera pārdali, kas arī padarītu visus norādes uz to nederīgu.
    ///
    /// # Examples
    ///
    /// ```
    /// // Piešķiriet vector pietiekami lielu daudzumu 4 elementiem.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Inicializējiet elementus, izmantojot neapstrādātu rādītāju rakstīšanu, pēc tam iestatiet garumu.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Mēs ēnojam tāda paša nosaukuma šķēles metodi, lai izvairītos no `deref_mut`, kas rada starpposma atsauci.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Atgriež atsauci pamatā esošajam sadalītājam.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Piespiež vector garumu līdz `new_len`.
    ///
    /// Šī ir zema līmeņa darbība, kas uztur nevienu no parastajiem šāda veida invariantiem.
    /// Parasti vector garuma maiņa tiek veikta, izmantojot kādu no drošajām darbībām, piemēram, [`truncate`], [`resize`], [`extend`] vai [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` jābūt mazākai vai vienādai ar [`capacity()`].
    /// - `old_len..new_len` elementi ir jāinicializē.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Šī metode var būt noderīga situācijās, kad vector kalpo kā buferis citam kodam, it īpaši FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Tas ir tikai minimāls skelets doc piemēram;
    /// # // nelietojiet to kā sākumpunktu reālai bibliotēkai.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Saskaņā ar FFI metodes dokumentiem "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // DROŠĪBA: Kad `deflateGetDictionary` atgriež `Z_OK`, tā uzskata, ka:
    ///     // 1. `dict_length` elementi tika inicializēti.
    ///     // 2.
    ///     // `dict_length` <=ietilpība (32_768), kas padara `set_len` drošu zvanīšanu.
    ///     unsafe {
    ///         // Zvaniet FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... un atjauniniet tā garumu, kas tika inicializēts.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Lai gan šis piemērs ir labs, atmiņā ir noplūde, jo iekšējie vectors netika atbrīvoti pirms `set_len` zvana:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` ir tukšs, tāpēc nav nepieciešams inicializēt nevienu elementu.
    /// // 2. `0 <= capacity` vienmēr tur visu, kas ir `capacity`.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Parasti šeit būtu jāizmanto [`clear`], lai pareizi nomestu saturu un tādējādi nepieļautu atmiņas noplūdi.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Noņem elementu no vector un atgriež to.
    ///
    /// Noņemto elementu aizstāj ar vector pēdējo elementu.
    ///
    /// Tas neuztur pasūtīšanu, bet ir O(1).
    ///
    /// # Panics
    ///
    /// Panics, ja `index` ir ārpus robežas.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Mēs aizstājam sevi [indeksu] ar pēdējo elementu.
            // Ņemiet vērā, ka, ja robežu pārbaude izdodas iepriekš, ir jābūt pēdējam elementam (kas var būt pats [indekss]).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// vector ievieto elementu `index` pozīcijā, visus elementus aiz tā nobīdot pa labi.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ja `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // vieta jaunajam elementam
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // nekļūdīgs Vieta, kur likt jauno vērtību
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Pārvietojiet visu, lai atbrīvotu vietu.
                // ("Index" elementa kopēšana divās vietās pēc kārtas.)
                ptr::copy(p, p.offset(1), len - index);
                // Ierakstiet to, pārrakstot elementa `index` pirmo kopiju.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Noņem un atgriež elementu pozīcijā `index` vector robežās, visus elementus pēc tā novirzot pa kreisi.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ja `index` ir ārpus robežas.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // vietu, no kuras mēs ejam.
                let ptr = self.as_mut_ptr().add(index);
                // nokopējiet to, nedroši vienlaikus saglabājot vērtības kopiju kaudzē un vector.
                //
                ret = ptr::read(ptr);

                // Pārvietojiet visu uz leju, lai aizpildītu šo vietu.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Saglabā tikai predikātā norādītos elementus.
    ///
    /// Citiem vārdiem sakot, noņemiet visus elementus `e` tā, lai `f(&e)` atgrieztu `false`.
    /// Šī metode darbojas vietā, katru elementu apmeklējot precīzi vienreiz sākotnējā secībā, un saglabā saglabāto elementu secību.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Tā kā elementi sākotnējā secībā tiek apmeklēti precīzi vienu reizi, lai izlemtu, kurus elementus paturēt, var izmantot ārējo stāvokli.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Izvairieties no dubultas kritiena, ja nolaišanās aizsargs netiek izpildīts, jo procesa laikā mēs varam izveidot dažas bedrītes.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-apstrādāts len-> |^-blakus, lai pārbaudītu
        //                  | <-dzēsts cnt-> |
        //      | <-original_len-> |Saglabāts: elementi, kuru predikāts atgriežas.
        //
        // Atvere: pārvietots vai nomests elementa slots.
        // Neatzīmēts: nav pārbaudīti derīgi elementi.
        //
        // Šis kritiena aizsargs tiks izmantots, kad panikā nonāks elementa predikāts vai `drop`.
        // Tas pārvieto nepārbaudītus elementus, lai nosegtu caurumus un `set_len` pareizā garumā.
        // Gadījumos, kad predikāts un `drop` nekad nav panikā, tas tiks optimizēts.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // DROŠĪBA: Nepārbaudītu priekšmetu aizmugurei jābūt derīgai, jo mēs tos nekad nepieskaramies.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // DROŠĪBA: Pēc urbumu aizpildīšanas visi priekšmeti atrodas blakus atmiņā.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // DROŠĪBA: Nepārbaudītam elementam jābūt derīgam.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Virzieties agri, lai izvairītos no dubultas kritiena, ja `drop_in_place` panikā.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // DROŠĪBA: Mēs nekad vairs nepieskaramies šim elementam pēc nokrišanas.
                unsafe { ptr::drop_in_place(cur) };
                // Mēs jau virzījām leti.
                continue;
            }
            if g.deleted_cnt > 0 {
                // DROŠĪBA: `deleted_cnt`> 0, tāpēc urbuma sprauga nedrīkst pārklāties ar pašreizējo elementu.
                // Mēs izmantojam kopiju pārvietošanai un nekad vairs nepieskaramies šim elementam.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Visi vienumi tiek apstrādāti.LLVM to var optimizēt `set_len`.
        drop(g);
    }

    /// Tiek noņemti visi vector secīgie elementi, izņemot pirmo, kas darbojas ar vienu un to pašu atslēgu.
    ///
    ///
    /// Ja vector ir sakārtots, tas noņem visus dublikātus.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Noņem visus vector secīgos elementus, izņemot pirmo, kas atbilst noteiktajai vienlīdzības attiecībai.
    ///
    /// `same_bucket` funkcija tiek nodota atsaucēm uz diviem vector elementiem, un tai jānosaka, vai elementi ir vienādi.
    /// Elementi tiek nodoti pretējā secībā nekā to secība šķēlē, tādēļ, ja `same_bucket(a, b)` atgriež vērtību `true`, `a` tiek noņemts.
    ///
    ///
    /// Ja vector ir sakārtots, tas noņem visus dublikātus.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Pievieno elementu kolekcijas aizmugurē.
    ///
    /// # Panics
    ///
    /// Panics, ja jaunā jauda pārsniedz `isize::MAX` baitus.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Tas panic vai pārtrauks darbību, ja mēs piešķirtu> isize::MAX baitus vai ja garuma pieaugums pārpildīsies nulles lieluma tipiem.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Noņem pēdējo elementu no vector un atgriež to vai [`None`], ja tas ir tukšs.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Pārvieto visus `other` elementus uz `Self`, atstājot `other` tukšu.
    ///
    /// # Panics
    ///
    /// Panics, ja vector elementu skaits pārsniedz `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Pievieno elementus `Self` no cita bufera.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Izveido iztukšošanas atkārtotāju, kas noņem norādīto diapazonu vector un dod noņemtos vienumus.
    ///
    /// Kad iterators **tiek nomests**, visi diapazona elementi tiek noņemti no vector, pat ja iterators nav pilnībā iztērēts.
    /// Ja iterators **netiek** nomests (piemēram, ar [`mem::forget`]), nav norādīts, cik elementu noņem.
    ///
    /// # Panics
    ///
    /// Panics, ja sākuma punkts ir lielāks par beigu punktu vai ja beigu punkts ir lielāks par vector garumu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Pilns diapazons notīra vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Atmiņas drošība
        //
        // Kad Drain tiek pirmo reizi izveidots, tas saīsina avota vector garumu, lai pārliecinātos, ka neviens inicializēts vai pārvietots elements nav pieejams vispār, ja Drain iznīcinātājs nekad nedarbojas.
        //
        //
        // Drain ptr::read veic noņemamās vērtības.
        // Kad tas ir pabeigts, vecā atlikušā aste tiek kopēta atpakaļ, lai segtu caurumu, un vector garums tiek atjaunots jaunā garumā.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // iestatiet self.vec garumu, lai sāktu, lai būtu droši gadījumā, ja Drain ir noplūdis
            self.set_len(start);
            // Izmantojiet aizņēmumu IterMut, lai norādītu visa Drain iteratora aizņemšanās uzvedību (piemēram, &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Notīra vector, noņemot visas vērtības.
    ///
    /// Ņemiet vērā, ka šī metode neietekmē vector piešķirto jaudu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Atgriež vector elementu skaitu, sauktu arī par tā 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Atgriež `true`, ja vector nav elementu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Sadalījums kolekcijā divās pie norādītā indeksa.
    ///
    /// Atgriež tikko piešķirto vector, kas satur elementus diapazonā `[at, len)`.
    /// Pēc zvana tiks atstāts sākotnējais vector, kas satur elementus `[0, at)` ar tā iepriekšējo jaudu nemainītu.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ja `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // jaunais vector var pārņemt sākotnējo buferi un izvairīties no kopijas
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Nedroši `set_len` un kopējiet vienumus uz `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Maina `Vec` izmēru vietā tā, lai `len` būtu vienāds ar `new_len`.
    ///
    /// Ja `new_len` ir lielāks par `len`, `Vec` tiek pagarināts par starpību, katru papildu slotu piepildot ar rezultātu, izsaucot slēgšanu `f`.
    ///
    /// Atgriešanās vērtības no `f` nonāks `Vec` tādā secībā, kādā tās ir ģenerētas.
    ///
    /// Ja `new_len` ir mazāks par `len`, `Vec` tiek vienkārši saīsināts.
    ///
    /// Šī metode izmanto slēgšanu, lai izveidotu jaunas vērtības katrā grūdienā.Ja vēlaties, lai [`Clone`] dotu vērtību, izmantojiet [`Vec::resize`].
    /// Ja vērtību ģenerēšanai vēlaties izmantot [`Default`] trait, kā otro argumentu varat nodot [`Default::default`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Patērē un noplūdina `Vec`, atgriežot maināmu atsauci uz saturu, `&'a mut [T]`.
    /// Ievērojiet, ka `T` tipam ir jāpārsniedz izvēlētais `'a` kalpošanas laiks.
    /// Ja tipam ir tikai statiskas atsauces vai vispār nav, tad to var izvēlēties `'static`.
    ///
    /// Šī funkcija ir līdzīga [`leak`][Box::leak] funkcijai [`Box`], izņemot to, ka nav iespējas atgūt noplūdušo atmiņu.
    ///
    ///
    /// Šī funkcija galvenokārt ir noderīga datiem, kas dzīvo programmas atlikušajā daļā.
    /// Atmestās atsauces nomešana izraisīs atmiņas noplūdi.
    ///
    /// # Examples
    ///
    /// Vienkārša lietošana:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Atgriež vector atlikušo rezerves jaudu kā `MaybeUninit<T>` šķēli.
    ///
    /// Atgriezto šķēli var izmantot, lai aizpildītu vector ar datiem (piem.,
    /// lasot no faila), pirms atzīmējat datus kā inicializētus, izmantojot [`set_len`] metodi.
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Piešķiriet vector pietiekami lielu daudzumu 10 elementiem.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Aizpildiet pirmos 3 elementus.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Atzīmējiet pirmos 3 vector elementus kā inicializētus.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Šī metode nav ieviesta `split_at_spare_mut` izteiksmē, lai novērstu buferī esošo norāžu nederēšanu.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Atgriež vector saturu kā `T` šķēli, kā arī atlikušo vector rezerves jaudu kā `MaybeUninit<T>` šķēli.
    ///
    /// Atgriezto rezerves jaudas šķēli var izmantot, lai aizpildītu vector ar datiem (piemēram, nolasot no faila), pirms dati tiek atzīmēti kā inicializēti, izmantojot metodi [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Ņemiet vērā, ka šī ir zema līmeņa API, kas optimizācijas nolūkos jāizmanto uzmanīgi.
    /// Ja `Vec` ir jāpievieno dati, varat izmantot [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] vai [`resize_with`], atkarībā no jūsu precīzajām vajadzībām.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Rezervējiet pietiekami lielu vietu 10 elementiem.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Aizpildiet nākamos 4 elementus.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Atzīmējiet 4 vector elementus kā inicializētus.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len tiek ignorēts un tāpēc nekad nav mainīts
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Drošība: atgriezto .2 (&mut usize) maiņa tiek uzskatīta par to pašu, kas izsaukt `.set_len(_)`.
    ///
    /// Šo metodi izmanto, lai `extend_from_within` būtu unikāla piekļuve visām vecajām daļām vienlaikus.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` tiek garantēta, ka tā ir derīga `len` elementiem
        // - `spare_ptr` norāda vienu elementu gar buferi, tāpēc tas nepārklājas ar `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Maina `Vec` izmēru vietā tā, lai `len` būtu vienāds ar `new_len`.
    ///
    /// Ja `new_len` ir lielāks par `len`, `Vec` tiek pagarināts par starpību, katru papildu slotu piepildot ar `value`.
    ///
    /// Ja `new_len` ir mazāks par `len`, `Vec` tiek vienkārši saīsināts.
    ///
    /// Šai metodei `T` ir nepieciešams ieviest [`Clone`], lai varētu klonēt nodoto vērtību.
    /// Ja jums nepieciešama lielāka elastība (vai vēlaties paļauties uz [`Default`], nevis uz [`Clone`]), izmantojiet [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Klonē un pievieno visus elementus `Vec` šķēlē.
    ///
    /// Atkārtojas pa `other` šķēli, katru elementu klonē un pēc tam pievieno šim `Vec`.
    /// `other` vector tiek pārvietots secīgi.
    ///
    /// Ņemiet vērā, ka šī funkcija ir tāda pati kā [`extend`], izņemot to, ka tā ir specializēta darbam ar šķēlītēm.
    ///
    /// Ja un kad Rust iegūst specializāciju, šī funkcija, visticamāk, būs novecojusi (bet joprojām ir pieejama).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Kopē elementus no `src` diapazona līdz vector beigām.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` garantē, ka dotais diapazons ir derīgs, lai indeksētu sevi
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Šis kods vispārina `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Paplašiniet vector par `n` vērtībām, izmantojot doto ģeneratoru.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Izmantojiet SetLenOnDrop, lai apietu kļūdu, kur kompilators, iespējams, neapzinās veikalu, izmantojot `ptr` līdz self.set_len(), nav aizstājvārds.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Uzrakstiet visus elementus, izņemot pēdējo
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Palieliniet garumu katrā solī gadījumā, ja next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Pēdējo elementu mēs varam uzrakstīt tieši, bez nevajadzīgas klonēšanas
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len, ko nosaka darbības sargs
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Noņem secīgus atkārtotus elementus vector atbilstoši [`PartialEq`] trait ieviešanai.
    ///
    ///
    /// Ja vector ir sakārtots, tas noņem visus dublikātus.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Iekšējās metodes un funkcijas
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` jābūt derīgam indeksam
    /// - `self.capacity() - self.len()` jābūt `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len tiek palielināts tikai pēc elementu inicializācijas
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - zvanītājs garantē, ka src ir derīgs indekss
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Element tikko tika inicializēts ar `MaybeUninit::write`, tāpēc ir pareizi palielināt len
            // - len, pēc katra elementa tiek palielināts, lai novērstu noplūdi (sk. #82533 izdevumu)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - zvanītājs garantē, ka `src` ir derīgs indekss
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Abi rādītāji tiek veidoti no unikālām sadaļu atsaucēm (`&mut [_]`), tāpēc tie ir derīgi un nepārklājas.
            //
            // - Elementi ir: Kopēt, tāpēc ir pareizi tos kopēt, neko nedarot ar sākotnējām vērtībām
            // - `count` ir vienāds ar `source` len, tāpēc avots ir derīgs `count` lasījumiem
            // - `.reserve(count)` garantē, ka `spare.len() >= count` tik rezerves ir derīga `count` rakstiem
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Elementus tikko inicializēja `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Kopējā trait ieviešana Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): ar cfg(test) raksturīgā metode `[T]::to_vec`, kas nepieciešama šīs metodes definēšanai, nav pieejama.
    // Tā vietā izmantojiet funkciju `slice::to_vec`, kas ir pieejama tikai ar cfg(test) NB, lai iegūtu papildinformāciju, skatiet slice::hack moduli slice.rs.
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // nomet visu, kas netiks pārrakstīts
        self.truncate(other.len());

        // self.len <= other.len iepriekš minētā saīsinājuma dēļ, tāpēc šeit esošās šķēles vienmēr ir robežās.
        //
        let (init, tail) = other.split_at(self.len());

        // atkārtoti izmantojiet ietvertās vērtības allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Izveido patērējošu iteratoru, tas ir, kas katru vērtību pārvieto no vector (no sākuma līdz beigām).
    /// vector nevar izmantot pēc šī izsaukšanas.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s ir virkne, nevis &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // lapu metode, kuru deleģē dažādas SpecFrom/SpecExtend ieviešanas, kad tām vairs nav piemērojamas optimizācijas
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Tas attiecas uz vispārēju iteratoru.
        //
        // Šai funkcijai jābūt morāles ekvivalentam:
        //
        //      vienumam iteratorā {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB nevar pārplūst, jo mums būtu bijis jāpiešķir adreses vieta
                self.set_len(len + 1);
            }
        }
    }

    /// Izveido savienojuma atkārtotāju, kas aizstāj norādīto diapazonu vector ar norādīto `replace_with` atkārtotāju un dod noņemtos vienumus.
    ///
    /// `replace_with` nav jābūt vienādam ar `range`.
    ///
    /// `range` tiek noņemts pat tad, ja iterators netiek patērēts līdz beigām.
    ///
    /// Nav norādīts, cik daudz elementu tiek noņemti no vector, ja `Splice` vērtība ir noplūdusi.
    ///
    /// Ievades iterators `replace_with` tiek patērēts tikai tad, kad tiek pazemināta `Splice` vērtība.
    ///
    /// Tas ir optimāli, ja:
    ///
    /// * Aste (vector elementi pēc `range`) ir tukša,
    /// * vai `replace_with` dod mazāk vai vienādu elementu nekā "diapazona" garums
    /// * vai tā `size_hint()` apakšējā robeža ir precīza.
    ///
    /// Pretējā gadījumā tiek piešķirts pagaidu vector, un asti divreiz pārvieto.
    ///
    /// # Panics
    ///
    /// Panics, ja sākuma punkts ir lielāks par beigu punktu vai ja beigu punkts ir lielāks par vector garumu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Izveido iteratoru, kas izmanto slēgšanu, lai noteiktu, vai elements ir jānoņem.
    ///
    /// Ja aizvēršanās atgriežas taisnība, tad elements tiek noņemts un iegūts.
    /// Ja aizvēršana atgriež kļūdaini, elements paliks vector un iterators to nedos.
    ///
    /// Šīs metodes izmantošana ir līdzvērtīga šim kodam:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // savu kodu šeit
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Bet `drain_filter` ir vieglāk izmantot.
    /// `drain_filter` ir arī efektīvāka, jo tā var masīvā elementus pārslēgt vairumā.
    ///
    /// Ņemiet vērā, ka `drain_filter` ļauj mutēt katru filtru aizvēršanas elementu neatkarīgi no tā, vai izvēlaties to paturēt vai noņemt.
    ///
    ///
    /// # Examples
    ///
    /// Masīva sadalīšana pa izlīdzinājumiem un izredzes, atkārtoti izmantojot sākotnējo sadalījumu:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Aizsardzība pret mums noplūdi (noplūdes pastiprināšana)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Paplašiniet ieviešanu, kas kopē elementus no atsaucēm, pirms tos nospiež uz Vec.
///
/// Šī ieviešana ir specializēta šķēļu atkārtotājiem, kur tā izmanto [`copy_from_slice`], lai pievienotu visu šķēli uzreiz.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Izpilda vektoru salīdzinājumu, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Izpilda vektoru pasūtīšanu, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // izmantojiet kritumu [T], izmantojiet neapstrādātu šķēli, lai atsauktos uz vector elementiem kā vājāko nepieciešamo tipu;
            //
            // dažos gadījumos varētu izvairīties no derīguma jautājumiem
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec veic darījumu izvietošanu
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Izveido tukšu `Vec<T>`.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: tests ievelk libstd, kas šeit rada kļūdas
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: tests ievelk libstd, kas šeit rada kļūdas
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Tiek iegūts viss `Vec<T>` saturs kā masīvs, ja tā lielums precīzi atbilst pieprasītā masīva lielumam.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Ja garums nesakrīt, ievade tiek atgriezta `Err` formātā:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Ja jums viss ir kārtībā ar `Vec<T>` prefiksa iegūšanu, vispirms varat piezvanīt uz [`.truncate(N)`](Vec::truncate).
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // DROŠĪBA: `.set_len(0)` vienmēr ir skaņa.
        unsafe { vec.set_len(0) };

        // DROŠĪBA: Vec rādītājs vienmēr ir pareizi izlīdzināts un
        // masīvam nepieciešamais izlīdzinājums ir tāds pats kā vienumiem.
        // Mēs iepriekš pārbaudījām, vai mums ir pietiekami daudz priekšmetu.
        // Vienumi netiks dubultā nomesti, jo `set_len` liek `Vec` tos arī nemest.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}