use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Pievieno visus atslēgu un vērtību pārus no divu augšupejošu atkārtotāju savienojuma, pa ceļam palielinot mainīgo `length`.Pēdējais ļauj zvanītājam izvairīties no noplūdes, kad pilienu apstrādātājs krīt panikā.
    ///
    /// Ja abi iteratori ražo vienu un to pašu atslēgu, šī metode pāra nomest no kreisā iteratora un pievieno pāri no labās iteratora.
    ///
    /// Ja vēlaties, lai koks nonāk stingri augošā secībā, piemēram, `BTreeMap`, abiem atkārtotājiem atslēgas jāveido stingri augošā secībā, katra no tām ir lielāka par visām koka atslēgām, ieskaitot visas atslēgas, kas jau ir ievadītas kokā.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Mēs gatavojamies apvienot `left` un `right` sakārtotā secībā lineārā laikā.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Tikmēr koku no sakārtotās secības uzbūvējam lineārā laikā.
        self.bulk_push(iter, length)
    }

    /// Nospiež visus atslēgas vērtību pārus līdz koka beigām, pa ceļam palielinot mainīgo `length`.
    /// Pēdējais ļauj zvanītājam vieglāk izvairīties no noplūdes, kad iterators krīt panikā.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Atkārtojiet visus atslēgas vērtību pārus, virzot tos pareizā līmeņa mezglos.
        for (key, value) in iter {
            // Mēģiniet atslēgu un vērtību pāri iestumt pašreizējā lapu mezglā.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Vietas vairs nav, dodieties augšup un spiediet tur.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Atradāt mezglu ar atstātu vietu, nospiediet šeit.
                                open_node = parent;
                                break;
                            } else {
                                // Atkal uz augšu.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Mēs esam augšpusē, izveidojam jaunu saknes mezglu un nospiežam tur.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Nospiediet atslēgu vērtību pāri un jauno labo apakškoku.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Atkal dodieties uz leju pie labās puses lapas.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Katras iterācijas garuma pieaugums, lai karte nomestu pievienotos elementus, pat ja virzās uz priekšu iterators.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Iterators divu sakārtotu secību apvienošanai vienā
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Ja divi taustiņi ir vienādi, atgriež atslēgas vērtību pāri no pareizā avota.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}