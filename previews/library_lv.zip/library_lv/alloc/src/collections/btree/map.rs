use core::borrow::Borrow;
use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, RangeBounds};
use core::ptr;

use super::borrow::DormantMutRef;
use super::navigate::LeafRange;
use super::node::{self, marker, ForceResult::*, Handle, NodeRef, Root};
use super::search::SearchResult::*;

mod entry;
pub use entry::{Entry, OccupiedEntry, OccupiedError, VacantEntry};
use Entry::*;

/// Minimālais elementu skaits mezglos, kas nav sakne.
/// Metodēs mums īslaicīgi var būt mazāk elementu.
pub(super) const MIN_LEN: usize = node::MIN_LEN_AFTER_SPLIT;

// Koks `BTreeMap` ir koks `node` modulī ar papildu nemainīgajiem:
// - Taustiņiem jābūt parādītiem augošā secībā (atbilstoši atslēgas tipam).
// - Ja saknes mezgls ir iekšējs, tajā jābūt vismaz 1 elementam.
// - Katrā mezglā, kas nav saknes, ir vismaz MIN_LEN elementi.
//
// Tukšu karti var attēlot gan ar saknes mezgla neesamību, gan ar saknes mezglu, kas ir tukša lapa.
//

/// Karte, kuras pamatā ir [B-Tree].
///
/// B-Trees ir būtisks kompromiss starp kešatmiņas efektivitāti un faktiski samazinātu meklēšanas darbu skaitu.Teorētiski binārā meklēšanas koks (BST) ir optimāla izvēle sakārtotai kartei, jo pilnīgi līdzsvarots BST veic teorētisko minimālo salīdzinājumu daudzumu, kas nepieciešams elementa (log<sub>2</sub>n) atrašanai.
/// Tomēr praksē veids, kā tas tiek darīts, mūsdienu datoru arhitektūrā ir *ļoti* neefektīvs.
/// Katrs elements tiek glabāts atsevišķā kaudzē piešķirtajā mezglā.
/// Tas nozīmē, ka katrs atsevišķs ievietojums izraisa kaudzes piešķiršanu, un katram salīdzinājumam vajadzētu būt kešatmiņā.
/// Tā kā praksē šīs abas ir īpaši dārgas lietas, mēs esam spiesti vismaz pārskatīt BST stratēģiju.
///
/// B-Tree vietā katrs mezgls satur blakus esošajā masīvā elementus B-1 līdz 2B-1.To darot, mēs samazinām piešķīrumu skaitu ar koeficientu B un uzlabojam kešatmiņas efektivitāti meklējumos.Tomēr tas nozīmē, ka meklējumiem vidēji būs jāveic *vairāk* salīdzinājumu.
/// Precīzs salīdzinājumu skaits ir atkarīgs no izmantotās mezglu meklēšanas stratēģijas.Optimālai kešatmiņas efektivitātei mezglus varētu meklēt lineāri.Lai iegūtu optimālus salīdzinājumus, mezglā varētu meklēt, izmantojot bināro meklēšanu.Kā kompromisu, kāds varētu arī veikt lineāru meklēšanu, kas sākotnēji pārbauda tikai ik i <sup>th</sup> elementu kādu izvēli i.
///
/// Pašlaik mūsu ieviešana vienkārši veic naivu lineāru meklēšanu.Tas nodrošina lielisku veiktspēju *mazos* elementu mezglos, kurus ir lēti salīdzināt.Tomēr future mēs vēlētos turpināt izpētīt optimālās meklēšanas stratēģijas izvēli, pamatojoties uz B izvēli un, iespējams, citiem faktoriem.Izmantojot lineāro meklēšanu, sagaidāms, ka nejauša elementa meklēšanai tiks izmantoti O(B * log(n)) salīdzinājumi, kas parasti ir sliktāki nekā BST.
///
/// Tomēr praksē sniegums ir lielisks.
///
/// Tā ir loģiska kļūda, ka atslēgu modificē tā, ka atslēgas secība attiecībā pret jebkuru citu atslēgu, ko nosaka [`Ord`] trait, mainās, kamēr tā atrodas kartē.Parasti tas ir iespējams tikai ar [`Cell`], [`RefCell`], globālo stāvokli, I/O vai nedrošu kodu.
/// Rīcība, kas izriet no šādas loģiskās kļūdas, nav norādīta, taču neizraisīs nedefinētu rīcību.Tas var ietvert panics, nepareizus rezultātus, pārtraukumus, atmiņas noplūdi un nepārtraukšanu.
///
/// [B-Tree]: https://en.wikipedia.org/wiki/B-tree
/// [`Cell`]: core::cell::Cell
/// [`RefCell`]: core::cell::RefCell
///
/// # Examples
///
/// ```
/// use std::collections::BTreeMap;
///
/// // tipa secinājums ļauj mums izlaist skaidru tipa parakstu (kas šajā piemērā būtu `BTreeMap<&str, &str>`).
/////
/// let mut movie_reviews = BTreeMap::new();
///
/// // pārskatīt dažas filmas.
/// movie_reviews.insert("Office Space",       "Deals with real issues in the workplace.");
/// movie_reviews.insert("Pulp Fiction",       "Masterpiece.");
/// movie_reviews.insert("The Godfather",      "Very enjoyable.");
/// movie_reviews.insert("The Blues Brothers", "Eye lyked it a lot.");
///
/// // pārbaudiet konkrētu.
/// if !movie_reviews.contains_key("Les Misérables") {
///     println!("We've got {} reviews, but Les Misérables ain't one.",
///              movie_reviews.len());
/// }
///
/// // Hmm, šajā pārskatā ir daudz pareizrakstības kļūdu, dzēsīsim to.
/// movie_reviews.remove("The Blues Brothers");
///
/// // atrodiet vērtības, kas saistītas ar dažiem taustiņiem.
/// let to_find = ["Up!", "Office Space"];
/// for movie in &to_find {
///     match movie_reviews.get(movie) {
///        Some(review) => println!("{}: {}", movie, review),
///        None => println!("{} is unreviewed.", movie)
///     }
/// }
///
/// // Atrodiet atslēgas vērtību (ja panic būs, ja atslēga nav atrasta).
/// println!("Movie review: {}", movie_reviews["Office Space"]);
///
/// // atkārtot visu.
/// for (movie, review) in &movie_reviews {
///     println!("{}: \"{}\"", movie, review);
/// }
/// ```
///
/// `BTreeMap` ievieš arī [`Entry API`], kas ļauj izmantot sarežģītākas atslēgas un to vērtību iegūšanas, iestatīšanas, atjaunināšanas un noņemšanas metodes:
///
/// [`Entry API`]: BTreeMap::entry
///
/// ```
/// use std::collections::BTreeMap;
///
/// // tipa secinājums ļauj mums izlaist skaidru tipa parakstu (kas šajā piemērā būtu `BTreeMap<&str, u8>`).
/////
/// let mut player_stats = BTreeMap::new();
///
/// fn random_stat_buff() -> u8 {
///     // faktiski varētu atgriezt kādu nejaušu vērtību šeit, tagad atgriezīsim tikai noteiktu vērtību
/////
///     42
/// }
///
/// // ievietojiet atslēgu tikai tad, ja tās vēl nav
/// player_stats.entry("health").or_insert(100);
///
/// // ievietojiet atslēgu, izmantojot funkciju, kas nodrošina jaunu vērtību tikai tad, ja tās vēl nav
/////
/// player_stats.entry("defence").or_insert_with(random_stat_buff);
///
/// // atjauniniet atslēgu, nodrošinoties, lai atslēga, iespējams, netiktu iestatīta
/// let stat = player_stats.entry("attack").or_insert(100);
/// *stat += random_stat_buff();
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BTreeMap")]
pub struct BTreeMap<K, V> {
    root: Option<Root<K, V>>,
    length: usize,
}

#[stable(feature = "btree_drop", since = "1.7.0")]
unsafe impl<#[may_dangle] K, #[may_dangle] V> Drop for BTreeMap<K, V> {
    fn drop(&mut self) {
        if let Some(root) = self.root.take() {
            Dropper { front: root.into_dying().first_leaf_edge(), remaining_length: self.length };
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Clone, V: Clone> Clone for BTreeMap<K, V> {
    fn clone(&self) -> BTreeMap<K, V> {
        fn clone_subtree<'a, K: Clone, V: Clone>(
            node: NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal>,
        ) -> BTreeMap<K, V>
        where
            K: 'a,
            V: 'a,
        {
            match node.force() {
                Leaf(leaf) => {
                    let mut out_tree = BTreeMap { root: Some(Root::new()), length: 0 };

                    {
                        let root = out_tree.root.as_mut().unwrap(); // attīšana izdodas, jo mēs tikko iesaiņojām
                        let mut out_node = match root.borrow_mut().force() {
                            Leaf(leaf) => leaf,
                            Internal(_) => unreachable!(),
                        };

                        let mut in_edge = leaf.first_edge();
                        while let Ok(kv) = in_edge.right_kv() {
                            let (k, v) = kv.into_kv();
                            in_edge = kv.right_edge();

                            out_node.push(k.clone(), v.clone());
                            out_tree.length += 1;
                        }
                    }

                    out_tree
                }
                Internal(internal) => {
                    let mut out_tree = clone_subtree(internal.first_edge().descend());

                    {
                        let out_root = BTreeMap::ensure_is_owned(&mut out_tree.root);
                        let mut out_node = out_root.push_internal_level();
                        let mut in_edge = internal.first_edge();
                        while let Ok(kv) = in_edge.right_kv() {
                            let (k, v) = kv.into_kv();
                            in_edge = kv.right_edge();

                            let k = (*k).clone();
                            let v = (*v).clone();
                            let subtree = clone_subtree(in_edge.descend());

                            // Apakškoku mēs nevaram tieši iznīcināt, jo BTreeMap ievieš Drop
                            //
                            let (subroot, sublength) = unsafe {
                                let subtree = ManuallyDrop::new(subtree);
                                let root = ptr::read(&subtree.root);
                                let length = subtree.length;
                                (root, length)
                            };

                            out_node.push(k, v, subroot.unwrap_or_else(Root::new));
                            out_tree.length += 1 + sublength;
                        }
                    }

                    out_tree
                }
            }
        }

        if self.is_empty() {
            // Ideālā gadījumā mēs šeit izsauktu `BTreeMap::new`, bet tam ir `K:
            // Ord` ierobežojums, kas šai metodei trūkst.
            BTreeMap { root: None, length: 0 }
        } else {
            clone_subtree(self.root.as_ref().unwrap().reborrow()) // attīšana izdodas, jo nav tukša
        }
    }
}

impl<K, Q: ?Sized> super::Recover<Q> for BTreeMap<K, ()>
where
    K: Borrow<Q> + Ord,
    Q: Ord,
{
    type Key = K;

    fn get(&self, key: &Q) -> Option<&K> {
        let root_node = self.root.as_ref()?.reborrow();
        match root_node.search_tree(key) {
            Found(handle) => Some(handle.into_kv().0),
            GoDown(_) => None,
        }
    }

    fn take(&mut self, key: &Q) -> Option<K> {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        match root_node.search_tree(key) {
            Found(handle) => {
                Some(OccupiedEntry { handle, dormant_map, _marker: PhantomData }.remove_kv().0)
            }
            GoDown(_) => None,
        }
    }

    fn replace(&mut self, key: K) -> Option<K> {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = Self::ensure_is_owned(&mut map.root).borrow_mut();
        match root_node.search_tree::<K>(&key) {
            Found(mut kv) => Some(mem::replace(kv.key_mut(), key)),
            GoDown(handle) => {
                VacantEntry { key, handle, dormant_map, _marker: PhantomData }.insert(());
                None
            }
        }
    }
}

/// Iterators pār `BTreeMap` ierakstiem.
///
/// Šis `struct` ir izveidots ar [`iter`] metodi uz [`BTreeMap`].
/// Plašāku informāciju skatiet tās dokumentācijā.
///
/// [`iter`]: BTreeMap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, K: 'a, V: 'a> {
    range: Range<'a, K, V>,
    length: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for Iter<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// Maināms iterators pār `BTreeMap` ierakstiem.
///
/// Šis `struct` ir izveidots ar [`iter_mut`] metodi uz [`BTreeMap`].
/// Plašāku informāciju skatiet tās dokumentācijā.
///
/// [`iter_mut`]: BTreeMap::iter_mut
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, K: 'a, V: 'a> {
    range: RangeMut<'a, K, V>,
    length: usize,
}

/// Iterators, kas pieder `BTreeMap` ierakstiem.
///
/// Šis `struct` ir izveidots ar [`into_iter`] metodi uz [`BTreeMap`] (nodrošina `IntoIterator` trait).
/// Plašāku informāciju skatiet tās dokumentācijā.
///
/// [`into_iter`]: IntoIterator::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<K, V> {
    range: LeafRange<marker::Dying, K, V>,
    length: usize,
}

impl<K, V> IntoIter<K, V> {
    /// Atgriež atsauču atkārtotāju pārējiem vienumiem.
    #[inline]
    pub(super) fn iter(&self) -> Iter<'_, K, V> {
        let range = Range { inner: self.range.reborrow() };
        Iter { range: range, length: self.length }
    }
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for IntoIter<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

/// Vienkāršota `IntoIter` versija, kas nav divpusēja un kurai ir tikai viens mērķis: pamest atlikušo `IntoIter`.
/// Tāpēc tas kalpo arī visa koka nometšanai, vispirms neizmeklējot `back` lapu edge.
///
struct Dropper<K, V> {
    front: Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge>,
    remaining_length: usize,
}

/// Iterators pār `BTreeMap` taustiņiem.
///
/// Šis `struct` ir izveidots ar [`keys`] metodi uz [`BTreeMap`].
/// Plašāku informāciju skatiet tās dokumentācijā.
///
/// [`keys`]: BTreeMap::keys
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Keys<'a, K: 'a, V: 'a> {
    inner: Iter<'a, K, V>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V> fmt::Debug for Keys<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// Atkārtotājs pār `BTreeMap` vērtībām.
///
/// Šis `struct` ir izveidots ar [`values`] metodi uz [`BTreeMap`].
/// Plašāku informāciju skatiet tās dokumentācijā.
///
/// [`values`]: BTreeMap::values
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Values<'a, K: 'a, V: 'a> {
    inner: Iter<'a, K, V>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K, V: fmt::Debug> fmt::Debug for Values<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// Maināms atkārtotājs `BTreeMap` vērtībām.
///
/// Šis `struct` ir izveidots ar [`values_mut`] metodi uz [`BTreeMap`].
/// Plašāku informāciju skatiet tās dokumentācijā.
///
/// [`values_mut`]: BTreeMap::values_mut
#[stable(feature = "map_values_mut", since = "1.10.0")]
pub struct ValuesMut<'a, K: 'a, V: 'a> {
    inner: IterMut<'a, K, V>,
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<K, V: fmt::Debug> fmt::Debug for ValuesMut<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.inner.iter().map(|(_, val)| val)).finish()
    }
}

/// Iteratora īpašnieks pār `BTreeMap` taustiņiem.
///
/// Šis `struct` ir izveidots ar [`into_keys`] metodi uz [`BTreeMap`].
/// Plašāku informāciju skatiet tās dokumentācijā.
///
/// [`into_keys`]: BTreeMap::into_keys
#[unstable(feature = "map_into_keys_values", issue = "75294")]
pub struct IntoKeys<K, V> {
    inner: IntoIter<K, V>,
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K: fmt::Debug, V> fmt::Debug for IntoKeys<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.inner.iter().map(|(key, _)| key)).finish()
    }
}

/// `BTreeMap` vērtību atkārtotājs.
///
/// Šis `struct` ir izveidots ar [`into_values`] metodi uz [`BTreeMap`].
/// Plašāku informāciju skatiet tās dokumentācijā.
///
/// [`into_values`]: BTreeMap::into_values
#[unstable(feature = "map_into_keys_values", issue = "75294")]
pub struct IntoValues<K, V> {
    inner: IntoIter<K, V>,
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V: fmt::Debug> fmt::Debug for IntoValues<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.inner.iter().map(|(_, val)| val)).finish()
    }
}

/// Iterators `BTreeMap` ierakstu apakškopā.
///
/// Šis `struct` ir izveidots ar [`range`] metodi uz [`BTreeMap`].
/// Plašāku informāciju skatiet tās dokumentācijā.
///
/// [`range`]: BTreeMap::range
#[stable(feature = "btree_range", since = "1.17.0")]
pub struct Range<'a, K: 'a, V: 'a> {
    inner: LeafRange<marker::Immut<'a>, K, V>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for Range<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// Maināms iterators `BTreeMap` ierakstu apakškopā.
///
/// Šis `struct` ir izveidots ar [`range_mut`] metodi uz [`BTreeMap`].
/// Plašāku informāciju skatiet tās dokumentācijā.
///
/// [`range_mut`]: BTreeMap::range_mut
#[stable(feature = "btree_range", since = "1.17.0")]
pub struct RangeMut<'a, K: 'a, V: 'a> {
    inner: LeafRange<marker::ValMut<'a>, K, V>,

    // Esiet nemainīgs `K` un `V`
    _marker: PhantomData<&'a mut (K, V)>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for RangeMut<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let range = Range { inner: self.inner.reborrow() };
        f.debug_list().entries(range).finish()
    }
}

impl<K, V> BTreeMap<K, V> {
    /// Izgatavo jaunu, tukšu `BTreeMap`.
    ///
    /// Pats neko nepiešķir.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    ///
    /// // ierakstus tagad var ievietot tukšajā kartē
    /// map.insert(1, "a");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn new() -> BTreeMap<K, V>
    where
        K: Ord,
    {
        BTreeMap { root: None, length: 0 }
    }

    /// Notīra karti, noņemot visus elementus.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "a");
    /// a.clear();
    /// assert!(a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = BTreeMap { root: None, length: 0 };
    }

    /// Atgriež atsauci uz vērtību, kas atbilst atslēgai.
    ///
    /// Atslēga var būt jebkura kartes atslēgas veida aizņemta forma, bet pasūtīšanai aizņemtajā formā * jāatbilst pasūtījumam pēc atslēgas veida.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.get(&1), Some(&"a"));
    /// assert_eq!(map.get(&2), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get<Q: ?Sized>(&self, key: &Q) -> Option<&V>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        match root_node.search_tree(key) {
            Found(handle) => Some(handle.into_kv().1),
            GoDown(_) => None,
        }
    }

    /// Atgriež atslēgas vērtību pāri, kas atbilst komplektā iekļautajai atslēgai.
    ///
    /// Komplektā esošā atslēga var būt jebkura kartes atslēgas veida aizņemta forma, taču pasūtīšanai aizņemtajā formā * jāatbilst pasūtījumam pēc atslēgas veida.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.get_key_value(&1), Some((&1, &"a")));
    /// assert_eq!(map.get_key_value(&2), None);
    /// ```
    #[stable(feature = "map_get_key_value", since = "1.40.0")]
    pub fn get_key_value<Q: ?Sized>(&self, k: &Q) -> Option<(&K, &V)>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        match root_node.search_tree(k) {
            Found(handle) => Some(handle.into_kv()),
            GoDown(_) => None,
        }
    }

    /// Atgriež pirmo atslēgas vērtību pāri kartē.
    /// Šī pāra atslēga ir minimālā atslēga kartē.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// assert_eq!(map.first_key_value(), None);
    /// map.insert(1, "b");
    /// map.insert(2, "a");
    /// assert_eq!(map.first_key_value(), Some((&1, &"b")));
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn first_key_value(&self) -> Option<(&K, &V)>
    where
        K: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        root_node.first_leaf_edge().right_kv().ok().map(Handle::into_kv)
    }

    /// Atgriež pirmo ierakstu kartē, lai veiktu manipulācijas ar vietu.
    /// Šī ieraksta atslēga ir minimālā atslēga kartē.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// if let Some(mut entry) = map.first_entry() {
    ///     if *entry.key() > 0 {
    ///         entry.insert("first");
    ///     }
    /// }
    /// assert_eq!(*map.get(&1).unwrap(), "first");
    /// assert_eq!(*map.get(&2).unwrap(), "b");
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn first_entry(&mut self) -> Option<OccupiedEntry<'_, K, V>>
    where
        K: Ord,
    {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        let kv = root_node.first_leaf_edge().right_kv().ok()?;
        Some(OccupiedEntry { handle: kv.forget_node_type(), dormant_map, _marker: PhantomData })
    }

    /// Noņem un atgriež pirmo kartes elementu.
    /// Šī elementa atslēga ir minimālā atslēga, kas bija kartē.
    ///
    /// # Examples
    ///
    /// Elementu iztukšošana augošā secībā, vienlaikus saglabājot izmantojamo karti katrā atkārtojumā.
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// while let Some((key, _val)) = map.pop_first() {
    ///     assert!(map.iter().all(|(k, _v)| *k > key));
    /// }
    /// assert!(map.is_empty());
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn pop_first(&mut self) -> Option<(K, V)>
    where
        K: Ord,
    {
        self.first_entry().map(|entry| entry.remove_entry())
    }

    /// Atgriež pēdējo atslēgas vērtību pāri kartē.
    /// Šī pāra atslēga ir maksimālā atslēga kartē.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "b");
    /// map.insert(2, "a");
    /// assert_eq!(map.last_key_value(), Some((&2, &"a")));
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn last_key_value(&self) -> Option<(&K, &V)>
    where
        K: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        root_node.last_leaf_edge().left_kv().ok().map(Handle::into_kv)
    }

    /// Atgriež pēdējo ierakstu kartē, lai veiktu manipulācijas ar vietu.
    /// Šī ieraksta atslēga ir maksimālā atslēga kartē.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// if let Some(mut entry) = map.last_entry() {
    ///     if *entry.key() > 0 {
    ///         entry.insert("last");
    ///     }
    /// }
    /// assert_eq!(*map.get(&1).unwrap(), "a");
    /// assert_eq!(*map.get(&2).unwrap(), "last");
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn last_entry(&mut self) -> Option<OccupiedEntry<'_, K, V>>
    where
        K: Ord,
    {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        let kv = root_node.last_leaf_edge().left_kv().ok()?;
        Some(OccupiedEntry { handle: kv.forget_node_type(), dormant_map, _marker: PhantomData })
    }

    /// Noņem un atgriež pēdējo kartes elementu.
    /// Šī elementa atslēga ir maksimālā atslēga, kas bija kartē.
    ///
    /// # Examples
    ///
    /// Elementu iztukšošana dilstošā secībā, vienlaikus saglabājot izmantojamo karti katrā atkārtojumā.
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// while let Some((key, _val)) = map.pop_last() {
    ///     assert!(map.iter().all(|(k, _v)| *k < key));
    /// }
    /// assert!(map.is_empty());
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn pop_last(&mut self) -> Option<(K, V)>
    where
        K: Ord,
    {
        self.last_entry().map(|entry| entry.remove_entry())
    }

    /// Atgriež vērtību `true`, ja kartē ir norādītās atslēgas vērtība.
    ///
    /// Atslēga var būt jebkura kartes atslēgas veida aizņemta forma, bet pasūtīšanai aizņemtajā formā * jāatbilst pasūtījumam pēc atslēgas veida.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.contains_key(&1), true);
    /// assert_eq!(map.contains_key(&2), false);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn contains_key<Q: ?Sized>(&self, key: &Q) -> bool
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        self.get(key).is_some()
    }

    /// Atgriež maināmu atsauci uz vērtību, kas atbilst atslēgai.
    ///
    /// Atslēga var būt jebkura kartes atslēgas veida aizņemta forma, bet pasūtīšanai aizņemtajā formā * jāatbilst pasūtījumam pēc atslēgas veida.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// if let Some(x) = map.get_mut(&1) {
    ///     *x = "b";
    /// }
    /// assert_eq!(map[&1], "b");
    /// ```
    // Skatiet `get`, lai uzzinātu par ieviešanu. Tas būtībā ir copy-paste ar pievienotu mut
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut<Q: ?Sized>(&mut self, key: &Q) -> Option<&mut V>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let root_node = self.root.as_mut()?.borrow_mut();
        match root_node.search_tree(key) {
            Found(handle) => Some(handle.into_val_mut()),
            GoDown(_) => None,
        }
    }

    /// Ievieto kartē atslēgas un vērtības pāri.
    ///
    /// Ja kartē nebija šīs atslēgas, `None` tiek atgriezta.
    ///
    /// Ja kartē bija šī atslēga, vērtība tiek atjaunināta un vecā vērtība tiek atgriezta.
    /// Tomēr atslēga netiek atjaunināta;tas ir svarīgi tipiem, kas var būt `==`, taču nav identiski.
    ///
    /// Lai uzzinātu vairāk, skatiet [module-level documentation].
    ///
    /// [module-level documentation]: index.html#insert-and-complex-keys
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// assert_eq!(map.insert(37, "a"), None);
    /// assert_eq!(map.is_empty(), false);
    ///
    /// map.insert(37, "b");
    /// assert_eq!(map.insert(37, "c"), Some("b"));
    /// assert_eq!(map[&37], "c");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, key: K, value: V) -> Option<V>
    where
        K: Ord,
    {
        match self.entry(key) {
            Occupied(mut entry) => Some(entry.insert(value)),
            Vacant(entry) => {
                entry.insert(value);
                None
            }
        }
    }

    /// Mēģina kartē ievietot atslēgu un vērtību pāri un atgriež maināmu atsauci uz ieraksta vērtību.
    ///
    /// Ja kartē jau bija šī atslēga, nekas netiek atjaunināts un tiek atgriezta kļūda, kas satur aizņemto ierakstu un vērtību.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// #![feature(map_try_insert)]
    ///
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// assert_eq!(map.try_insert(37, "a").unwrap(), &"a");
    ///
    /// let err = map.try_insert(37, "b").unwrap_err();
    /// assert_eq!(err.entry.key(), &37);
    /// assert_eq!(err.entry.get(), &"a");
    /// assert_eq!(err.value, "b");
    /// ```
    ///
    #[unstable(feature = "map_try_insert", issue = "82766")]
    pub fn try_insert(&mut self, key: K, value: V) -> Result<&mut V, OccupiedError<'_, K, V>>
    where
        K: Ord,
    {
        match self.entry(key) {
            Occupied(entry) => Err(OccupiedError { entry, value }),
            Vacant(entry) => Ok(entry.insert(value)),
        }
    }

    /// Noņem atslēgu no kartes, atgriežot vērtību pie atslēgas, ja atslēga iepriekš bija kartē.
    ///
    /// Atslēga var būt jebkura kartes atslēgas veida aizņemta forma, bet pasūtīšanai aizņemtajā formā * jāatbilst pasūtījumam pēc atslēgas veida.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.remove(&1), Some("a"));
    /// assert_eq!(map.remove(&1), None);
    /// ```
    ///
    #[doc(alias = "delete")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove<Q: ?Sized>(&mut self, key: &Q) -> Option<V>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        self.remove_entry(key).map(|(_, v)| v)
    }

    /// Tiek noņemta atslēga no kartes, atgriežot saglabāto atslēgu un vērtību, ja atslēga iepriekš bija kartē.
    ///
    /// Atslēga var būt jebkura kartes atslēgas veida aizņemta forma, bet pasūtīšanai aizņemtajā formā * jāatbilst pasūtījumam pēc atslēgas veida.
    ///
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.remove_entry(&1), Some((1, "a")));
    /// assert_eq!(map.remove_entry(&1), None);
    /// ```
    ///
    #[stable(feature = "btreemap_remove_entry", since = "1.45.0")]
    pub fn remove_entry<Q: ?Sized>(&mut self, key: &Q) -> Option<(K, V)>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        match root_node.search_tree(key) {
            Found(handle) => {
                Some(OccupiedEntry { handle, dormant_map, _marker: PhantomData }.remove_entry())
            }
            GoDown(_) => None,
        }
    }

    /// Saglabā tikai predikātā norādītos elementus.
    ///
    /// Citiem vārdiem sakot, noņemiet visus `(k, v)` pārus tā, lai `f(&k, &mut v)` atgrieztu `false`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(btree_retain)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<i32, i32> = (0..8).map(|x| (x, x*10)).collect();
    /// // Saglabājiet tikai elementus ar pāra numuriem.
    /// map.retain(|&k, _| k % 2 == 0);
    /// assert!(map.into_iter().eq(vec![(0, 0), (2, 20), (4, 40), (6, 60)]));
    /// ```
    #[inline]
    #[unstable(feature = "btree_retain", issue = "79025")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        K: Ord,
        F: FnMut(&K, &mut V) -> bool,
    {
        self.drain_filter(|k, v| !f(k, v));
    }

    /// Pārvieto visus elementus no `other` uz `Self`, atstājot `other` tukšu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "a");
    /// a.insert(2, "b");
    /// a.insert(3, "c");
    ///
    /// let mut b = BTreeMap::new();
    /// b.insert(3, "d");
    /// b.insert(4, "e");
    /// b.insert(5, "f");
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.len(), 5);
    /// assert_eq!(b.len(), 0);
    ///
    /// assert_eq!(a[&1], "a");
    /// assert_eq!(a[&2], "b");
    /// assert_eq!(a[&3], "d");
    /// assert_eq!(a[&4], "e");
    /// assert_eq!(a[&5], "f");
    /// ```
    #[stable(feature = "btree_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self)
    where
        K: Ord,
    {
        // Vai mums vispār kaut kas jāpievieno?
        if other.is_empty() {
            return;
        }

        // Mēs varam vienkārši nomainīt `self` un `other`, ja `self` ir tukšs.
        if self.is_empty() {
            mem::swap(self, other);
            return;
        }

        let self_iter = mem::take(self).into_iter();
        let other_iter = mem::take(other).into_iter();
        let root = BTreeMap::ensure_is_owned(&mut self.root);
        root.append_from_sorted_iters(self_iter, other_iter, &mut self.length)
    }

    /// Konstruē divkāršu iteratoru virs kartes elementu apakšgrupas.
    /// Vienkāršākais veids ir izmantot diapazona sintaksi `min..max`, tādējādi `range(min..max)` iegūs elementus no min (inclusive) līdz max (exclusive).
    /// Diapazonu var ievadīt arī kā `(Bound<T>, Bound<T>)`, tāpēc, piemēram, `range((Excluded(4), Included(10)))` radīs kreiso ekskluzīvo, labo iekļaujošo diapazonu no 4 līdz 10.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ja diapazons `start > end`.
    /// Panics, ja diapazons `start == end` un abas robežas ir `Excluded`.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    /// use std::ops::Bound::Included;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(3, "a");
    /// map.insert(5, "b");
    /// map.insert(8, "c");
    /// for (&key, &value) in map.range((Included(&4), Included(&8))) {
    ///     println!("{}: {}", key, value);
    /// }
    /// assert_eq!(Some((&5, &"b")), map.range(4..).next());
    /// ```
    ///
    ///
    #[stable(feature = "btree_range", since = "1.17.0")]
    pub fn range<T: ?Sized, R>(&self, range: R) -> Range<'_, K, V>
    where
        T: Ord,
        K: Borrow<T> + Ord,
        R: RangeBounds<T>,
    {
        if let Some(root) = &self.root {
            Range { inner: root.reborrow().range_search(range) }
        } else {
            Range { inner: LeafRange::none() }
        }
    }

    /// Kontrolē maināmu divgalu iteratoru virs kartes elementu apakšgrupas.
    /// Vienkāršākais veids ir izmantot diapazona sintaksi `min..max`, tādējādi `range(min..max)` iegūs elementus no min (inclusive) līdz max (exclusive).
    /// Diapazonu var ievadīt arī kā `(Bound<T>, Bound<T>)`, tāpēc, piemēram, `range((Excluded(4), Included(10)))` radīs kreiso ekskluzīvo, labo iekļaujošo diapazonu no 4 līdz 10.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ja diapazons `start > end`.
    /// Panics, ja diapazons `start == end` un abas robežas ir `Excluded`.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<&str, i32> = ["Alice", "Bob", "Carol", "Cheryl"]
    ///     .iter()
    ///     .map(|&s| (s, 0))
    ///     .collect();
    /// for (_, balance) in map.range_mut("B".."Cheryl") {
    ///     *balance += 100;
    /// }
    /// for (name, balance) in &map {
    ///     println!("{} => {}", name, balance);
    /// }
    /// ```
    ///
    ///
    #[stable(feature = "btree_range", since = "1.17.0")]
    pub fn range_mut<T: ?Sized, R>(&mut self, range: R) -> RangeMut<'_, K, V>
    where
        T: Ord,
        K: Borrow<T> + Ord,
        R: RangeBounds<T>,
    {
        if let Some(root) = &mut self.root {
            RangeMut { inner: root.borrow_valmut().range_search(range), _marker: PhantomData }
        } else {
            RangeMut { inner: LeafRange::none(), _marker: PhantomData }
        }
    }

    /// Iegūst attiecīgās atslēgas atbilstošo ierakstu kartē, lai veiktu manipulācijas ar vietu.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut count: BTreeMap<&str, usize> = BTreeMap::new();
    ///
    /// // saskaitīt veco burtu sastopamības skaitu
    /// for x in vec!["a", "b", "a", "c", "a", "b"] {
    ///     *count.entry(x).or_insert(0) += 1;
    /// }
    ///
    /// assert_eq!(count["a"], 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn entry(&mut self, key: K) -> Entry<'_, K, V>
    where
        K: Ord,
    {
        // FIXME(@porglezomp) Izvairieties no piešķiršanas, ja mēs to neievietojam
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = Self::ensure_is_owned(&mut map.root).borrow_mut();
        match root_node.search_tree(&key) {
            Found(handle) => Occupied(OccupiedEntry { handle, dormant_map, _marker: PhantomData }),
            GoDown(handle) => {
                Vacant(VacantEntry { key, handle, dormant_map, _marker: PhantomData })
            }
        }
    }

    /// Sadaliet kolekciju divās daļās pie norādītās atslēgas.
    /// Atgriež visu pēc norādītās atslēgas, ieskaitot atslēgu.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "a");
    /// a.insert(2, "b");
    /// a.insert(3, "c");
    /// a.insert(17, "d");
    /// a.insert(41, "e");
    ///
    /// let b = a.split_off(&3);
    ///
    /// assert_eq!(a.len(), 2);
    /// assert_eq!(b.len(), 3);
    ///
    /// assert_eq!(a[&1], "a");
    /// assert_eq!(a[&2], "b");
    ///
    /// assert_eq!(b[&3], "c");
    /// assert_eq!(b[&17], "d");
    /// assert_eq!(b[&41], "e");
    /// ```
    #[stable(feature = "btree_split_off", since = "1.11.0")]
    pub fn split_off<Q: ?Sized + Ord>(&mut self, key: &Q) -> Self
    where
        K: Borrow<Q> + Ord,
    {
        if self.is_empty() {
            return Self::new();
        }

        let total_num = self.len();
        let left_root = self.root.as_mut().unwrap(); // attīšana izdodas, jo nav tukša

        let right_root = left_root.split_off(key);

        let (new_left_len, right_len) = Root::calc_split_length(total_num, &left_root, &right_root);
        self.length = new_left_len;

        BTreeMap { root: Some(right_root), length: right_len }
    }

    /// Izveido iteratoru, kas visus elementus (atslēgu un vērtību pārus) apmeklē augšupejošā secībā un izmanto slēgšanu, lai noteiktu, vai elements ir jānoņem.
    /// Ja aizvēršana atgriež vērtību `true`, elements tiek noņemts no kartes un tiek iegūts.
    /// Ja aizvēršana atgriež `false` vai panics, elements paliek kartē un netiks iegūts.
    ///
    /// Atkārtotājs ļauj arī mutēt katra aizvērēja elementa vērtību neatkarīgi no tā, vai izvēlaties to paturēt vai noņemt.
    ///
    /// Ja iterators tiek patērēts tikai daļēji vai netiek patērēts vispār, katrs no atlikušajiem elementiem joprojām tiek pakļauts slēgšanai, kas var mainīt tā vērtību un, atgriežot `true`, elementu noņemt un nomest.
    ///
    ///
    /// Nav norādīts, cik daudz elementu vēl tiks pakļauti slēgšanai, ja panic notiek aizvēršanā vai panic notiek, nometot elementu vai ja `DrainFilter` vērtība ir noplūdusi.
    ///
    /// # Examples
    ///
    /// Kartes sadalīšana pāra un nepāra taustiņos, sākotnējās kartes atkārtota izmantošana:
    ///
    /// ```
    /// #![feature(btree_drain_filter)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<i32, i32> = (0..8).map(|x| (x, x)).collect();
    /// let evens: BTreeMap<_, _> = map.drain_filter(|k, _v| k % 2 == 0).collect();
    /// let odds = map;
    /// assert_eq!(evens.keys().copied().collect::<Vec<_>>(), vec![0, 2, 4, 6]);
    /// assert_eq!(odds.keys().copied().collect::<Vec<_>>(), vec![1, 3, 5, 7]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "btree_drain_filter", issue = "70530")]
    pub fn drain_filter<F>(&mut self, pred: F) -> DrainFilter<'_, K, V, F>
    where
        K: Ord,
        F: FnMut(&K, &mut V) -> bool,
    {
        DrainFilter { pred, inner: self.drain_filter_inner() }
    }

    pub(super) fn drain_filter_inner(&mut self) -> DrainFilterInner<'_, K, V>
    where
        K: Ord,
    {
        if let Some(root) = self.root.as_mut() {
            let (root, dormant_root) = DormantMutRef::new(root);
            let front = root.borrow_mut().first_leaf_edge();
            DrainFilterInner {
                length: &mut self.length,
                dormant_root: Some(dormant_root),
                cur_leaf_edge: Some(front),
            }
        } else {
            DrainFilterInner { length: &mut self.length, dormant_root: None, cur_leaf_edge: None }
        }
    }

    /// Izveido patērētāju, kas kārto secībā apmeklē visus taustiņus.
    /// Pēc šī izsaukšanas karti nevar izmantot.
    /// Iteratora elementa tips ir `K`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_into_keys_values)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(2, "b");
    /// a.insert(1, "a");
    ///
    /// let keys: Vec<i32> = a.into_keys().collect();
    /// assert_eq!(keys, [1, 2]);
    /// ```
    #[inline]
    #[unstable(feature = "map_into_keys_values", issue = "75294")]
    pub fn into_keys(self) -> IntoKeys<K, V> {
        IntoKeys { inner: self.into_iter() }
    }

    /// Izveido patērētāju atkārtotāju, kurš apmeklē visas vērtības secībā pēc atslēgas.
    /// Pēc šī izsaukšanas karti nevar izmantot.
    /// Iteratora elementa tips ir `V`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_into_keys_values)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "hello");
    /// a.insert(2, "goodbye");
    ///
    /// let values: Vec<&str> = a.into_values().collect();
    /// assert_eq!(values, ["hello", "goodbye"]);
    /// ```
    #[inline]
    #[unstable(feature = "map_into_keys_values", issue = "75294")]
    pub fn into_values(self) -> IntoValues<K, V> {
        IntoValues { inner: self.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> IntoIterator for &'a BTreeMap<K, V> {
    type Item = (&'a K, &'a V);
    type IntoIter = Iter<'a, K, V>;

    fn into_iter(self) -> Iter<'a, K, V> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> Iterator for Iter<'a, K, V> {
    type Item = (&'a K, &'a V);

    fn next(&mut self) -> Option<(&'a K, &'a V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_unchecked() })
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.length, Some(self.length))
    }

    fn last(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Iter<'_, K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> DoubleEndedIterator for Iter<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_back_unchecked() })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for Iter<'_, K, V> {
    fn len(&self) -> usize {
        self.length
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Clone for Iter<'_, K, V> {
    fn clone(&self) -> Self {
        Iter { range: self.range.clone(), length: self.length }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> IntoIterator for &'a mut BTreeMap<K, V> {
    type Item = (&'a K, &'a mut V);
    type IntoIter = IterMut<'a, K, V>;

    fn into_iter(self) -> IterMut<'a, K, V> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> Iterator for IterMut<'a, K, V> {
    type Item = (&'a K, &'a mut V);

    fn next(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_unchecked() })
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.length, Some(self.length))
    }

    fn last(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> DoubleEndedIterator for IterMut<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_back_unchecked() })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for IterMut<'_, K, V> {
    fn len(&self) -> usize {
        self.length
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for IterMut<'_, K, V> {}

impl<'a, K, V> IterMut<'a, K, V> {
    /// Atgriež atsauču atkārtotāju pārējiem vienumiem.
    #[inline]
    pub(super) fn iter(&self) -> Iter<'_, K, V> {
        Iter { range: self.range.iter(), length: self.length }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> IntoIterator for BTreeMap<K, V> {
    type Item = (K, V);
    type IntoIter = IntoIter<K, V>;

    fn into_iter(self) -> IntoIter<K, V> {
        let mut me = ManuallyDrop::new(self);
        if let Some(root) = me.root.take() {
            let full_range = root.into_dying().full_range();

            IntoIter { range: full_range, length: me.length }
        } else {
            IntoIter { range: LeafRange::none(), length: 0 }
        }
    }
}

impl<K, V> Drop for Dropper<K, V> {
    fn drop(&mut self) {
        // Līdzīgi iteratora, kas nav apvienojams, virzīšanai uz priekšu.
        fn next_or_end<K, V>(this: &mut Dropper<K, V>) -> Option<(K, V)> {
            if this.remaining_length == 0 {
                unsafe { ptr::read(&this.front).deallocating_end() }
                None
            } else {
                this.remaining_length -= 1;
                Some(unsafe { this.front.deallocating_next_unchecked() })
            }
        }

        struct DropGuard<'a, K, V>(&'a mut Dropper<K, V>);

        impl<'a, K, V> Drop for DropGuard<'a, K, V> {
            fn drop(&mut self) {
                // Turpiniet to pašu cilpu, kuru mēs veicam tālāk.
                // Tas darbojas tikai tad, kad atritat, tāpēc mums šoreiz nav jāuztraucas par panics (viņi pārtrauks darbību).
                while let Some(_pair) = next_or_end(&mut self.0) {}
            }
        }

        while let Some(pair) = next_or_end(self) {
            let guard = DropGuard(self);
            drop(pair);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "btree_drop", since = "1.7.0")]
impl<K, V> Drop for IntoIter<K, V> {
    fn drop(&mut self) {
        if let Some(front) = self.range.front.take() {
            Dropper { front, remaining_length: self.length };
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Iterator for IntoIter<K, V> {
    type Item = (K, V);

    fn next(&mut self) -> Option<(K, V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.front.as_mut().unwrap().deallocating_next_unchecked() })
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.length, Some(self.length))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> DoubleEndedIterator for IntoIter<K, V> {
    fn next_back(&mut self) -> Option<(K, V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.back.as_mut().unwrap().deallocating_next_back_unchecked() })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for IntoIter<K, V> {
    fn len(&self) -> usize {
        self.length
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for IntoIter<K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> Iterator for Keys<'a, K, V> {
    type Item = &'a K;

    fn next(&mut self) -> Option<&'a K> {
        self.inner.next().map(|(k, _)| k)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<&'a K> {
        self.next_back()
    }

    fn min(mut self) -> Option<&'a K> {
        self.next()
    }

    fn max(mut self) -> Option<&'a K> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> DoubleEndedIterator for Keys<'a, K, V> {
    fn next_back(&mut self) -> Option<&'a K> {
        self.inner.next_back().map(|(k, _)| k)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for Keys<'_, K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Keys<'_, K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Clone for Keys<'_, K, V> {
    fn clone(&self) -> Self {
        Keys { inner: self.inner.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> Iterator for Values<'a, K, V> {
    type Item = &'a V;

    fn next(&mut self) -> Option<&'a V> {
        self.inner.next().map(|(_, v)| v)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<&'a V> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> DoubleEndedIterator for Values<'a, K, V> {
    fn next_back(&mut self) -> Option<&'a V> {
        self.inner.next_back().map(|(_, v)| v)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for Values<'_, K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Values<'_, K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Clone for Values<'_, K, V> {
    fn clone(&self) -> Self {
        Values { inner: self.inner.clone() }
    }
}

/// Atkārtotājs, kas izveidots, zvanot uz `drain_filter` vietnē BTreeMap.
#[unstable(feature = "btree_drain_filter", issue = "70530")]
pub struct DrainFilter<'a, K, V, F>
where
    K: 'a,
    V: 'a,
    F: 'a + FnMut(&K, &mut V) -> bool,
{
    pred: F,
    inner: DrainFilterInner<'a, K, V>,
}
/// Lielākā daļa DrainFilter ieviešanas gadījumu ir predikāta veida vispārīgi, tādējādi kalpojot arī BTreeSet::DrainFilter.
///
pub(super) struct DrainFilterInner<'a, K: 'a, V: 'a> {
    /// Atsauce uz garuma lauku aizņemtajā kartē, atjaunināta tiešraidē.
    length: &'a mut usize,
    /// Apglabāta atsauce uz saknes lauku aizņemtajā kartē.
    /// Iesaiņots `Option`, lai pilienu apstrādātājs to varētu `take`.
    dormant_root: Option<DormantMutRef<'a, Root<K, V>>>,
    /// Satur lapu edge pirms nākamā atdodamā elementa vai pēdējo lapu edge.
    /// Iztukšojiet, ja kartei nav saknes, ja iterācija pārsniedza pēdējo lapu edge vai ja predikātā notika panic.
    ///
    cur_leaf_edge: Option<Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>>,
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> Drop for DrainFilter<'_, K, V, F>
where
    F: FnMut(&K, &mut V) -> bool,
{
    fn drop(&mut self) {
        self.for_each(drop);
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> fmt::Debug for DrainFilter<'_, K, V, F>
where
    K: fmt::Debug,
    V: fmt::Debug,
    F: FnMut(&K, &mut V) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.inner.peek()).finish()
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> Iterator for DrainFilter<'_, K, V, F>
where
    F: FnMut(&K, &mut V) -> bool,
{
    type Item = (K, V);

    fn next(&mut self) -> Option<(K, V)> {
        self.inner.next(&mut self.pred)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

impl<'a, K: 'a, V: 'a> DrainFilterInner<'a, K, V> {
    /// Ļaujiet atkļūdošanas ieviešanai paredzēt nākamo elementu.
    pub(super) fn peek(&self) -> Option<(&K, &V)> {
        let edge = self.cur_leaf_edge.as_ref()?;
        edge.reborrow().next_kv().ok().map(Handle::into_kv)
    }

    /// Tipiskas `DrainFilter::next` metodes ieviešana, ņemot vērā predikātu.
    pub(super) fn next<F>(&mut self, pred: &mut F) -> Option<(K, V)>
    where
        F: FnMut(&K, &mut V) -> bool,
    {
        while let Ok(mut kv) = self.cur_leaf_edge.take()?.next_kv() {
            let (k, v) = kv.kv_mut();
            if pred(k, v) {
                *self.length -= 1;
                let (kv, pos) = kv.remove_kv_tracking(|| {
                    // DROŠĪBA: mēs pieskaramies saknei tā, lai to nedarītu
                    // anulēt atgriezto pozīciju.
                    let root = unsafe { self.dormant_root.take().unwrap().awaken() };
                    root.pop_internal_level();
                    self.dormant_root = Some(DormantMutRef::new(root).1);
                });
                self.cur_leaf_edge = Some(pos);
                return Some(kv);
            }
            self.cur_leaf_edge = Some(kv.next_leaf_edge());
        }
        None
    }

    /// Tipiskas `DrainFilter::size_hint` metodes ieviešana.
    pub(super) fn size_hint(&self) -> (usize, Option<usize>) {
        // Lielākajā daļā btree atkārtotāju `self.length` ir vēl neapmeklēto elementu skaits.
        // Šeit tas ietver elementus, kas tika apmeklēti un kurus predikāts nolēma nedarīt drain.
        // Lai padarītu šo augšējo robežu precīzāku, ir jāuztur papildu lauks, un tas nav vērts.
        //
        (0, Some(*self.length))
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> FusedIterator for DrainFilter<'_, K, V, F> where F: FnMut(&K, &mut V) -> bool {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> Iterator for Range<'a, K, V> {
    type Item = (&'a K, &'a V);

    fn next(&mut self) -> Option<(&'a K, &'a V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_unchecked() }) }
    }

    fn last(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<'a, K, V> Iterator for ValuesMut<'a, K, V> {
    type Item = &'a mut V;

    fn next(&mut self) -> Option<&'a mut V> {
        self.inner.next().map(|(_, v)| v)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<&'a mut V> {
        self.next_back()
    }
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<'a, K, V> DoubleEndedIterator for ValuesMut<'a, K, V> {
    fn next_back(&mut self) -> Option<&'a mut V> {
        self.inner.next_back().map(|(_, v)| v)
    }
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<K, V> ExactSizeIterator for ValuesMut<'_, K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for ValuesMut<'_, K, V> {}

impl<'a, K, V> Range<'a, K, V> {
    unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        unsafe { self.inner.front.as_mut().unwrap_unchecked().next_unchecked() }
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> Iterator for IntoKeys<K, V> {
    type Item = K;

    fn next(&mut self) -> Option<K> {
        self.inner.next().map(|(k, _)| k)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<K> {
        self.next_back()
    }

    fn min(mut self) -> Option<K> {
        self.next()
    }

    fn max(mut self) -> Option<K> {
        self.next_back()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> DoubleEndedIterator for IntoKeys<K, V> {
    fn next_back(&mut self) -> Option<K> {
        self.inner.next_back().map(|(k, _)| k)
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> ExactSizeIterator for IntoKeys<K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> FusedIterator for IntoKeys<K, V> {}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> Iterator for IntoValues<K, V> {
    type Item = V;

    fn next(&mut self) -> Option<V> {
        self.inner.next().map(|(_, v)| v)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<V> {
        self.next_back()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> DoubleEndedIterator for IntoValues<K, V> {
    fn next_back(&mut self) -> Option<V> {
        self.inner.next_back().map(|(_, v)| v)
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> ExactSizeIterator for IntoValues<K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> FusedIterator for IntoValues<K, V> {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> DoubleEndedIterator for Range<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_back_unchecked() }) }
    }
}

impl<'a, K, V> Range<'a, K, V> {
    unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        unsafe { self.inner.back.as_mut().unwrap_unchecked().next_back_unchecked() }
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Range<'_, K, V> {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<K, V> Clone for Range<'_, K, V> {
    fn clone(&self) -> Self {
        Range { inner: LeafRange { front: self.inner.front, back: self.inner.back } }
    }
}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> Iterator for RangeMut<'a, K, V> {
    type Item = (&'a K, &'a mut V);

    fn next(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_unchecked() }) }
    }

    fn last(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }
}

impl<'a, K, V> RangeMut<'a, K, V> {
    unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        unsafe { self.inner.front.as_mut().unwrap_unchecked().next_unchecked() }
    }

    /// Atgriež atsauču atkārtotāju pārējiem vienumiem.
    #[inline]
    pub(super) fn iter(&self) -> Range<'_, K, V> {
        Range { inner: self.inner.reborrow() }
    }
}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> DoubleEndedIterator for RangeMut<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_back_unchecked() }) }
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for RangeMut<'_, K, V> {}

impl<'a, K, V> RangeMut<'a, K, V> {
    unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        unsafe { self.inner.back.as_mut().unwrap_unchecked().next_back_unchecked() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V> FromIterator<(K, V)> for BTreeMap<K, V> {
    fn from_iter<T: IntoIterator<Item = (K, V)>>(iter: T) -> BTreeMap<K, V> {
        let mut map = BTreeMap::new();
        map.extend(iter);
        map
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V> Extend<(K, V)> for BTreeMap<K, V> {
    #[inline]
    fn extend<T: IntoIterator<Item = (K, V)>>(&mut self, iter: T) {
        iter.into_iter().for_each(move |(k, v)| {
            self.insert(k, v);
        });
    }

    #[inline]
    fn extend_one(&mut self, (k, v): (K, V)) {
        self.insert(k, v);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, K: Ord + Copy, V: Copy> Extend<(&'a K, &'a V)> for BTreeMap<K, V> {
    fn extend<I: IntoIterator<Item = (&'a K, &'a V)>>(&mut self, iter: I) {
        self.extend(iter.into_iter().map(|(&key, &value)| (key, value)));
    }

    #[inline]
    fn extend_one(&mut self, (&k, &v): (&'a K, &'a V)) {
        self.insert(k, v);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Hash, V: Hash> Hash for BTreeMap<K, V> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        for elt in self {
            elt.hash(state);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V> Default for BTreeMap<K, V> {
    /// Izveido tukšu `BTreeMap`.
    fn default() -> BTreeMap<K, V> {
        BTreeMap::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: PartialEq, V: PartialEq> PartialEq for BTreeMap<K, V> {
    fn eq(&self, other: &BTreeMap<K, V>) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a == b)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Eq, V: Eq> Eq for BTreeMap<K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: PartialOrd, V: PartialOrd> PartialOrd for BTreeMap<K, V> {
    #[inline]
    fn partial_cmp(&self, other: &BTreeMap<K, V>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V: Ord> Ord for BTreeMap<K, V> {
    #[inline]
    fn cmp(&self, other: &BTreeMap<K, V>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Debug, V: Debug> Debug for BTreeMap<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_map().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, Q: ?Sized, V> Index<&Q> for BTreeMap<K, V>
where
    K: Borrow<Q> + Ord,
    Q: Ord,
{
    type Output = V;

    /// Atgriež atsauci uz vērtību, kas atbilst piegādātajai atslēgai.
    ///
    /// # Panics
    ///
    /// Panics, ja `BTreeMap` nav atslēgas.
    #[inline]
    fn index(&self, key: &Q) -> &V {
        self.get(key).expect("no entry found for key")
    }
}

impl<K, V> BTreeMap<K, V> {
    /// Iegūst iteratoru pār kartes ierakstiem, kas sakārtoti pēc atslēgas.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(3, "c");
    /// map.insert(2, "b");
    /// map.insert(1, "a");
    ///
    /// for (key, value) in map.iter() {
    ///     println!("{}: {}", key, value);
    /// }
    ///
    /// let (first_key, first_value) = map.iter().next().unwrap();
    /// assert_eq!((*first_key, *first_value), (1, "a"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, K, V> {
        if let Some(root) = &self.root {
            let full_range = root.reborrow().full_range();

            Iter { range: Range { inner: full_range }, length: self.length }
        } else {
            Iter { range: Range { inner: LeafRange::none() }, length: 0 }
        }
    }

    /// Tiek iegūts maināms iterators pār kartes ierakstiem, sakārtots pēc atslēgas.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert("a", 1);
    /// map.insert("b", 2);
    /// map.insert("c", 3);
    ///
    /// // pievienojiet vērtībai 10, ja atslēga nav "a"
    /// for (key, value) in map.iter_mut() {
    ///     if key != &"a" {
    ///         *value += 10;
    ///     }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, K, V> {
        if let Some(root) = &mut self.root {
            let full_range = root.borrow_valmut().full_range();

            IterMut {
                range: RangeMut { inner: full_range, _marker: PhantomData },
                length: self.length,
            }
        } else {
            IterMut {
                range: RangeMut { inner: LeafRange::none(), _marker: PhantomData },
                length: 0,
            }
        }
    }

    /// Saņem iteratoru pār kartes taustiņiem, sakārtotā secībā.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(2, "b");
    /// a.insert(1, "a");
    ///
    /// let keys: Vec<_> = a.keys().cloned().collect();
    /// assert_eq!(keys, [1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn keys(&self) -> Keys<'_, K, V> {
        Keys { inner: self.iter() }
    }

    /// Iet iterators pār kartes vērtībām secībā pēc atslēgas.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "hello");
    /// a.insert(2, "goodbye");
    ///
    /// let values: Vec<&str> = a.values().cloned().collect();
    /// assert_eq!(values, ["hello", "goodbye"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn values(&self) -> Values<'_, K, V> {
        Values { inner: self.iter() }
    }

    /// Iegūst maināmu kartes iteratoru kārtojumu pēc atslēgas.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, String::from("hello"));
    /// a.insert(2, String::from("goodbye"));
    ///
    /// for value in a.values_mut() {
    ///     value.push_str("!");
    /// }
    ///
    /// let values: Vec<String> = a.values().cloned().collect();
    /// assert_eq!(values, [String::from("hello!"),
    ///                     String::from("goodbye!")]);
    /// ```
    #[stable(feature = "map_values_mut", since = "1.10.0")]
    pub fn values_mut(&mut self) -> ValuesMut<'_, K, V> {
        ValuesMut { inner: self.iter_mut() }
    }

    /// Atgriež elementu skaitu kartē.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// assert_eq!(a.len(), 0);
    /// a.insert(1, "a");
    /// assert_eq!(a.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn len(&self) -> usize {
        self.length
    }

    /// Atgriež vērtību `true`, ja kartē nav elementu.
    ///
    /// # Examples
    ///
    /// Pamata lietojums:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// assert!(a.is_empty());
    /// a.insert(1, "a");
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Ja saknes mezgls ir tukšs (non-allocated) saknes mezgls, piešķiriet mūsu pašu mezglu.
    /// Ir saistīta funkcija, lai izvairītos no visa BTreeMap aizņemšanās.
    fn ensure_is_owned(root: &mut Option<Root<K, V>>) -> &mut Root<K, V> {
        root.get_or_insert_with(Root::new)
    }
}

#[cfg(test)]
mod tests;