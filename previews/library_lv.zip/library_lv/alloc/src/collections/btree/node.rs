// Šis ir mēģinājums ieviest ideālu
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Tā kā Rust faktiski nav atkarīgu tipu un polimorfas rekursijas, mēs iztikt ar daudz nedrošību.
//

// Galvenais šī moduļa mērķis ir izvairīties no sarežģītības, apstrādājot koku kā vispārēju (ja dīvainas formas) konteineru un izvairoties no darījumu ar lielāko daļu B-Tree invariantu.
//
// Šim modulim ir pilnīgi vienalga, vai ieraksti ir sakārtoti, kuri mezgli var būt nepilnīgi, vai pat tas, ko nepietiekami nozīmē.Tomēr mēs paļaujamies uz dažiem nemainīgajiem:
//
// - Kokiem jābūt vienādam depth/height.Tas nozīmē, ka katram ceļam uz leju līdz lapai no noteiktā mezgla ir tieši tāds pats garums.
// - `n` garuma mezglā ir atslēgas `n`, vērtības `n` un malas `n + 1`.
//   Tas nozīmē, ka pat tukšam mezglam ir vismaz viens edge.
//   Lapu mezglam "having an edge" nozīmē tikai to, ka mēs varam noteikt pozīciju mezglā, jo lapu malas ir tukšas un tām nav nepieciešams attēlot datus.
// Iekšējā mezglā edge gan identificē pozīciju, gan satur rādītāju uz bērna mezglu.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Lapu mezglu pamatā esošais attēlojums un daļa no iekšējo mezglu attēlojuma.
struct LeafNode<K, V> {
    /// Mēs vēlamies būt mainīgi `K` un `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Šī mezgla indekss vecākā mezgla masīvā `edges`.
    /// `*node.parent.edges[node.parent_idx]` jābūt vienādai ar `node`.
    /// Tas tiek garantēts tikai tad, ja `parent` nav nulle.
    parent_idx: MaybeUninit<u16>,

    /// Šajā mezglā saglabāto atslēgu un vērtību skaits.
    len: u16,

    /// Masīvi, kas glabā mezgla faktiskos datus.
    /// Inicializēti un derīgi ir tikai katra masīva pirmie `len` elementi.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Inicializē jaunu `LeafNode` vietā.
    unsafe fn init(this: *mut Self) {
        // Kā vispārēju politiku mēs atstājam laukus neinicializētus, ja tādi ir, jo Valgrindā tam vajadzētu būt gan nedaudz ātrākam, gan vieglāk izsekojamam.
        //
        unsafe {
            // parent_idx, atslēgas un vals ir Varbūt Unininit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Izveido jaunu `LeafNode`.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Iekšējo mezglu pamatā esošais attēlojums.Tāpat kā ar `LeafNode`, tie ir jāslēpj aiz `BoxedNode`, lai nepieļautu neinicializētu atslēgu un vērtību nomešanu.
/// Jebkuru rādītāju uz `InternalNode` var tieši nodot rādītājam uz mezgla pakārtoto `LeafNode` daļu, ļaujot kodam vispārīgi iedarboties uz lapu un iekšējiem mezgliem, pat nepārbaudot, uz kuru no abiem rādītājs norāda.
///
/// Šis īpašums ir iespējots, izmantojot `repr(C)`.
///
#[repr(C)]
// gdb_providers.py introspekcijai izmanto šo tipa nosaukumu.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Norādes uz šī mezgla bērniem.
    /// `len + 1` no tām tiek uzskatītas par inicializētām un derīgām, izņemot to, ka tuvu beigām, kamēr koks tiek turēts, izmantojot `Dying` aizdevuma veidu, daži no šiem norādījumiem ir karājas.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Izveido jaunu `InternalNode`.
    ///
    /// # Safety
    /// Iekšējo mezglu nemainīgais ir tas, ka tiem ir vismaz viens inicializēts un derīgs edge.
    /// Šī funkcija nenosaka šādu edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Mums tikai inicializēt datus;malas ir Varbūt Unininit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Pārvaldīts, nenulles rādītājs uz mezglu.Tas ir vai nu īpašnieks rādītājs uz `LeafNode<K, V>`, vai arī īpašnieks rādītājs uz `InternalNode<K, V>`.
///
/// Tomēr `BoxedNode` nesatur informāciju par to, kurš no diviem mezglu veidiem tajā faktiski atrodas, un daļēji šī informācijas trūkuma dēļ nav atsevišķs tips un tam nav iznīcinātāja.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Īpašumā esoša koka saknes mezgls.
///
/// Ņemiet vērā, ka tam nav iznīcinātāja, un tas ir jātīra manuāli.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Atgriež jaunu īpašumā esošu koku ar savu saknes mezglu, kas sākotnēji ir tukšs.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` nedrīkst būt nulle.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Mainīgi aizņemas piederošo saknes mezglu.
    /// Atšķirībā no `reborrow_mut`, tas ir droši, jo atgriešanās vērtību nevar izmantot saknes iznīcināšanai, un nevar būt citu atsauču uz koku.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Nedaudz mainīgi aizņemas piederošo saknes mezglu.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Neatgriezeniski pāriet uz atsauci, kas ļauj šķērsot un piedāvā destruktīvas metodes un neko citu.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Pievieno jaunu iekšējo mezglu ar vienu edge, kas norāda uz iepriekšējo saknes mezglu, izveido šo jauno mezglu par saknes mezglu un atdod to.
    /// Tas palielina augstumu par 1 un ir pretējs `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, izņemot to, ka mēs vienkārši aizmirsām, ka tagad esam iekšēji:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Noņem iekšējo saknes mezglu, tā jauno bērnu izmantojot kā jauno saknes mezglu.
    /// Tā kā to ir paredzēts izsaukt tikai tad, ja saknes mezglā ir tikai viens bērns, nevienam no taustiņiem, vērtībām un citiem bērniem netiek veikta tīrīšana.
    ///
    /// Tas samazina augstumu par 1 un ir pretējs `push_internal_level`.
    ///
    /// Nepieciešama ekskluzīva piekļuve objektam `Root`, bet ne saknes mezglam;
    /// tas nederēs citus rokturus vai atsauces uz saknes mezglu.
    ///
    /// Panics, ja nav iekšējā līmeņa, ti, ja saknes mezgls ir lapa.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // DROŠĪBA: mēs apgalvojām, ka esam iekšēji.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // DROŠĪBA: mēs aizņēmāmies tikai `self`, un tā aizņēmuma veids ir ekskluzīvs.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // DROŠĪBA: pirmais edge vienmēr tiek inicializēts.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` vienmēr ir mainīgs `K` un `V`, pat ja `BorrowType` ir `Mut`.
// Tas ir tehniski nepareizi, taču `NodeRef` iekšējās izmantošanas dēļ tas nevar izraisīt nekādu nedrošību, jo `K` un `V` ir pilnīgi vispārīgi.
//
// Tomēr vienmēr, kad publisks tips aptin `NodeRef`, pārliecinieties, vai tam ir pareizā dispersija.
//
/// Atsauce uz mezglu.
///
/// Šim tipam ir vairāki parametri, kas kontrolē tā darbību:
/// - `BorrowType`: Manekena tips, kas raksturo aizņēmuma veidu un ir mūža garumā.
///    - Kad tas ir `Immut<'a>`, `NodeRef` darbojas aptuveni tāpat kā `&'a Node`.
///    - Kad tas ir `ValMut<'a>`, `NodeRef` darbojas aptuveni tāpat kā `&'a Node` attiecībā uz atslēgām un koka struktūru, bet ļauj vienlaikus pastāvēt daudzām maināmām atsaucēm uz vērtībām visā kokā.
///    - Kad tas ir `Mut<'a>`, `NodeRef` darbojas aptuveni tāpat kā `&'a mut Node`, lai gan ievietošanas metodes ļauj līdzāspastāvēt maināmam rādītājam uz vērtību.
///    - Kad tas ir `Owned`, `NodeRef` darbojas aptuveni tāpat kā `Box<Node>`, bet tam nav iznīcinātāja, un tas ir jātīra manuāli.
///    - Kad tas ir `Dying`, `NodeRef` joprojām darbojas aptuveni tāpat kā `Box<Node>`, taču tam ir metodes, kā koku iznīcināt pa bitam, un parastās metodes, kaut arī nav atzīmētas kā nedrošas zvanīšanai, var izsaukt UB, ja to izsauc nepareizi.
///
///   Tā kā jebkura `NodeRef` ļauj pārvietoties pa koku, `BorrowType` efektīvi attiecas uz visu koku, ne tikai uz pašu mezglu.
/// - `K` un `V`: šie ir mezglos saglabāto atslēgu un vērtību veidi.
/// - `Type`: Tas var būt `Leaf`, `Internal` vai `LeafOrInternal`.
/// Kad tas ir `Leaf`, `NodeRef` norāda uz lapu mezglu, kad tas ir `Internal`, `NodeRef` norāda uz iekšējo mezglu, un, kad tas ir `LeafOrInternal`, `NodeRef` varētu norādīt uz jebkura veida mezglu.
///   `Type` tiek nosaukts `NodeType`, ja to lieto ārpus `NodeRef`.
///
/// Gan `BorrowType`, gan `NodeType` ierobežo to, kādas metodes mēs ieviešam, lai izmantotu statiskā tipa drošību.Šādu ierobežojumu piemērošanā ir ierobežojumi:
/// - Katram tipa parametram metodi var definēt tikai vispārīgi vai vienam konkrētam tipam.
/// Piemēram, mēs nevaram vispārīgi definēt tādu metodi kā `into_kv` visiem `BorrowType` vai vienreiz visiem tipiem, kuriem ir mūžs, jo mēs vēlamies, lai tas atgriež atsauces `&'a`.
///   Tāpēc mēs to definējam tikai vismazāk jaudīgajam `Immut<'a>` tipam.
/// - Mēs nevaram iegūt netiešu piespiešanu no teiciena `Mut<'a>` līdz `Immut<'a>`.
///   Tāpēc mums ir skaidri jāsauc `reborrow` ar jaudīgāku `NodeRef`, lai sasniegtu tādu metodi kā `into_kv`.
///
/// Visas `NodeRef` metodes, kas atgriež kaut kādu atsauci, vai nu:
/// - Paņemiet vērtību `self` un atgrieziet `BorrowType` kalpošanas laiku.
///   Dažreiz, lai izmantotu šādu metodi, mums jāzvana uz `reborrow_mut`.
/// - Paņemiet `self` ar atsauci un (implicitly) atgriež šīs atsauces kalpošanas laiku, nevis `BorrowType` nesamo kalpošanas laiku.
/// Tādā veidā aizņēmuma pārbaudītājs garantē, ka `NodeRef` paliek aizņemts tik ilgi, kamēr tiek izmantota atgrieztā atsauce.
///   Metodes, kas atbalsta ieliktni, izliek šo noteikumu, atgriežot neapstrādātu rādītāju, ti, atsauci bez jebkāda kalpošanas laika.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Līmeņu skaits, ko mezgls un lapu līmenis atdala, mezgla konstante, kuru `Type` nevar pilnībā aprakstīt un kuru pats mezgls neglabā.
    /// Mums tikai jāuzglabā saknes mezgla augstums un no tā jāgūst katra otrā mezgla augstums.
    /// Jābūt nullei, ja `Type` ir `Leaf`, un nullei, ja `Type` ir `Internal`.
    ///
    ///
    height: usize,
    /// Rādītājs uz lapas vai iekšējā mezgla.
    /// `InternalNode` definīcija nodrošina, ka rādītājs ir derīgs jebkurā gadījumā.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Izpakojiet mezgla atsauci, kas bija iepakota kā `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Atklāj iekšējā mezgla datus.
    ///
    /// Atgriež neapstrādātu ptr, lai nederētu citas atsauces uz šo mezglu.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // DROŠĪBA: statiskā mezgla tips ir `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Aizņemas ekskluzīvu piekļuvi iekšējā mezgla datiem.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Atrod mezgla garumu.Tas ir atslēgu vai vērtību skaits.
    /// Malu skaits ir `len() + 1`.
    /// Ņemiet vērā, ka, neskatoties uz drošību, šīs funkcijas izsaukšana var radīt nederīgu maināmo atsauču nederīgumu, kuras ir radījis nedrošs kods.
    ///
    pub fn len(&self) -> usize {
        // Būtiski, ka šeit mēs piekļūstam tikai `len` laukam.
        // Ja BorrowType ir marker::ValMut, var būt izcilas maināmas atsauces uz vērtībām, kuras mēs nedrīkstam atcelt.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Atgriež to līmeņu skaitu, kurus mezgls un atstāj atsevišķi.
    /// Nulles augstums nozīmē, ka mezgls ir pati lapa.
    /// Ja attēlojat kokus ar sakni augšpusē, skaitlis norāda, kurā augstumā parādās mezgls.
    /// Ja attēlojat kokus ar lapām uz augšu, skaitlis norāda, cik augsts koks sniedzas virs mezgla.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Uz laiku izņem citu, nemaināmu atsauci uz to pašu mezglu.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Pakļauj jebkuras lapas vai iekšējā mezgla lapu daļu.
    ///
    /// Atgriež neapstrādātu ptr, lai nederētu citas atsauces uz šo mezglu.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Mezglam jābūt derīgam vismaz LeafNode daļai.
        // Šī nav atsauce tipā NodeRef, jo mēs nezinām, vai tai jābūt unikālai vai koplietotai.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Atrod pašreizējā mezgla vecāku.
    /// Atgriež vērtību `Ok(handle)`, ja pašreizējam mezglam faktiski ir vecāks, kur `handle` norāda uz vecāka edge, kas norāda uz pašreizējo mezglu.
    ///
    /// Atgriež `Err(self)`, ja pašreizējam mezglam nav vecāku, atdodot sākotnējo `NodeRef`.
    ///
    /// Metodes nosaukums pieņem, ka jūs attēlojat kokus ar saknes mezglu augšpusē.
    ///
    /// `edge.descend().ascend().unwrap()` Gan panākumiem, gan `node.ascend().unwrap().descend()` neko nedarīt.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Mezgliem mums jāizmanto neapstrādātas norādes, jo, ja BorrowType ir marker::ValMut, var būt izcilas maināmas atsauces uz vērtībām, kuras mēs nedrīkstam nederēt.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Ņemiet vērā, ka `self` nedrīkst būt tukšs.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Ņemiet vērā, ka `self` nedrīkst būt tukšs.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Pakļauj jebkuras nemainīga koka lapas vai iekšējā mezgla lapu daļu.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // DROŠĪBA: šajā kokā, kas aizņemts kā `Immut`, nevar būt maināmas atsauces.
        unsafe { &*ptr }
    }

    /// Aizņemas skatu mezglā saglabātajās atslēgās.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Līdzīgi kā `ascend`, iegūst atsauci uz mezgla vecāku mezglu, bet arī procesa laikā sadala pašreizējo mezglu.
    /// Tas ir nedroši, jo pašreizējais mezgls joprojām būs pieejams, neskatoties uz tā izvietošanu.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Droši sastādītājam apgalvo statisko informāciju, ka šis mezgls ir `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Droši sastādītājam apgalvo statisko informāciju, ka šis mezgls ir `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Uz laiku noņem citu maināmu atsauci uz to pašu mezglu.Uzmanieties, jo šī metode ir ļoti bīstama, divkārši, jo tā var nešķist uzreiz bīstama.
    ///
    /// Tā kā maināmie rādītāji var klīst jebkurā vietā ap koku, atgriezto rādītāju var viegli izmantot, lai sākotnējo rādītāju padarītu karājošu, ārpus robežas vai nederīgu saskaņā ar sakrautajiem aizņēmuma noteikumiem.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) apsveriet iespēju pievienot vēl vienu tipa parametru `NodeRef`, kas ierobežo navigācijas metožu izmantošanu pārņemtajos rādītājos, novēršot šo nedrošību.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Aizņemas ekskluzīvu piekļuvi jebkuras lapas vai iekšējā mezgla lapu daļai.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // DROŠĪBA: mums ir ekskluzīva piekļuve visam mezglam.
        unsafe { &mut *ptr }
    }

    /// Piedāvā ekskluzīvu piekļuvi jebkuras lapas vai iekšējā mezgla lapu daļai.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // DROŠĪBA: mums ir ekskluzīva piekļuve visam mezglam.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Aizņemas ekskluzīvu piekļuvi atslēgas glabāšanas zonas elementam.
    ///
    /// # Safety
    /// `index` atrodas robežās ar 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // DROŠĪBA: zvanītājs nevarēs piezvanīt uz citām metodēm
        // līdz atslēgas sadaļas atsauce tiek nomesta, jo mums ir unikāla piekļuve visā aizņemšanās laikā.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Aizņemas ekskluzīvu piekļuvi mezgla vērtību glabāšanas zonas elementam vai šķēlei.
    ///
    /// # Safety
    /// `index` atrodas robežās ar 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // DROŠĪBA: zvanītājs nevarēs piezvanīt uz citām metodēm
        // līdz tiek atcelta atsauce uz vērtības sadaļu, jo mums ir unikāla piekļuve visā aizņēmuma darbības laikā.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Aizņemas ekskluzīvu piekļuvi mezgla edge satura glabāšanas zonas elementam vai šķēlei.
    ///
    /// # Safety
    /// `index` atrodas robežās ar 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // DROŠĪBA: zvanītājs nevarēs piezvanīt uz citām metodēm
        // līdz tiek atcelta edge šķēles atsauce, jo mums ir unikāla piekļuve visā aizņēmuma darbības laikā.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Mezglā ir vairāk nekā `idx` inicializēti elementi.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Mēs izveidojam tikai atsauci uz vienu mūs interesējošo elementu, lai izvairītos no aizstājējvērtības ar izcilām atsaucēm uz citiem elementiem, jo īpaši tiem, kas atgriezušies zvanītājam iepriekšējās atkārtojumos.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Rust problēmas #74679 dēļ mums jāpiespiež izmēru masīva rādītāji.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Aizņemas ekskluzīvu piekļuvi mezgla garumam.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Iestata mezgla saiti uz vecāku edge, nederējot citas atsauces uz mezglu.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Notīra saknes saiti uz vecāku edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Mezgla beigās pievieno atslēgas un vērtību pāri.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Katrs `range` atgrieztais vienums ir derīgs edge indekss mezglam.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Pievieno atslēgu vērtību pāri un edge, lai pārietu pa labi no šī pāra līdz mezgla beigām.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Pārbauda, vai mezgls ir `Internal` mezgls vai `Leaf` mezgls.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Atsauce uz noteiktu atslēgu un vērtību pāri vai edge mezglā.
/// Parametram `Node` ir jābūt `NodeRef`, savukārt `Type` var būt vai nu `KV` (apzīmē rokturi atslēgas vērtību pārī), vai `Edge` (apzīmē rokturi uz edge).
///
/// Ņemiet vērā, ka pat `Leaf` mezgliem var būt `Edge` rokturi.
/// Tā vietā, lai attēlotu rādītāju bērna mezglam, tie attēlo vietas, kur bērnu rādītāji ietu starp atslēgu un vērtību pāriem.
/// Piemēram, mezglā, kura garums ir 2, būtu 3 iespējamās edge atrašanās vietas: viena no mezgla kreisās puses, viena starp abiem pāriem un otra mezgla labajā pusē.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Mums nav nepieciešama visa `#[derive(Clone)]` vispārība, jo vienīgais laiks, kad `Node` būs "klonējams", ir tad, kad tā ir nemaināma atsauce un tāpēc `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Izgūst mezglu, kurā ir edge vai atslēgu un vērtību pāris, uz kuru norāda šis rokturis.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Atgriež šī roktura pozīciju mezglā.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Izveido jaunu rokturi atslēgas vērtību pārim `node`.
    /// Droša, jo zvanītājam ir jānodrošina, ka `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Varētu būt PartialEq publiska ieviešana, taču to var izmantot tikai šajā modulī.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Uz laiku tajā pašā vietā izņem citu, nemainīgu rokturi.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Mēs nevaram izmantot Handle::new_kv vai Handle::new_edge, jo mēs nezinām savu tipu
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Droši sastādītājam apgalvo statisko informāciju, ka roktura mezgls ir `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Uz laiku tajā pašā vietā izņem citu, maināmu rokturi.
    /// Uzmanieties, jo šī metode ir ļoti bīstama, divkārši, jo tā var nešķist uzreiz bīstama.
    ///
    ///
    /// Sīkāku informāciju skatiet `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Mēs nevaram izmantot Handle::new_kv vai Handle::new_edge, jo mēs nezinām savu tipu
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Izveido jaunu edge rokturi `node`.
    /// Droša, jo zvanītājam ir jānodrošina, ka `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Ņemot vērā edge indeksu, kur mēs vēlamies ievietot mezglā, kas piepildīts līdz jaudai, aprēķina saprātīgu sadalījuma punkta KV indeksu un vietu, kur veikt ievietošanu.
///
/// Sadalījuma punkta mērķis ir panākt, lai tā atslēga un vērtība nonāktu vecāku mezglā;
/// atslēgas, vērtības un malas pa kreisi no sadalīšanas punkta kļūst par kreiso bērnu;
/// atslēgas, vērtības un malas pa labi no sadalījuma punkta kļūst par pareizo bērnu.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust jautājums #74834 mēģina izskaidrot šos simetriskos noteikumus.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Starp atslēgas vērtību pāriem pa labi un pa kreisi no šīs edge ievieto jaunu atslēgas vērtību pāri.
    /// Ar šo metodi tiek pieņemts, ka mezglā ir pietiekami daudz vietas, lai jaunais pāris ietilptu.
    ///
    /// Atgrieztais rādītājs norāda uz ievietoto vērtību.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Starp atslēgas vērtību pāriem pa labi un pa kreisi no šīs edge ievieto jaunu atslēgas vērtību pāri.
    /// Šī metode sadala mezglu, ja nav pietiekami daudz vietas.
    ///
    /// Atgrieztais rādītājs norāda uz ievietoto vērtību.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Fiksē vecāku rādītāju un indeksu pakārtotajā mezglā, ar kuru saista šis edge.
    /// Tas ir noderīgi, ja ir mainīta malu secība,
    fn correct_parent_link(self) {
        // Izveidojiet aizmugures rādītāju, nederējot citas atsauces uz mezglu.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Ievieto jaunu atslēgas vērtību pāri un edge, kas iet pa labi no šī jaunā pāra starp šo edge un atslēgu vērtību pāri pa labi no šī edge.
    /// Ar šo metodi tiek pieņemts, ka mezglā ir pietiekami daudz vietas, lai jaunais pāris ietilptu.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Ievieto jaunu atslēgas vērtību pāri un edge, kas iet pa labi no šī jaunā pāra starp šo edge un atslēgu vērtību pāri pa labi no šī edge.
    /// Šī metode sadala mezglu, ja nav pietiekami daudz vietas.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Starp atslēgas vērtību pāriem pa labi un pa kreisi no šīs edge ievieto jaunu atslēgas vērtību pāri.
    /// Šī metode sadala mezglu, ja nav pietiekami daudz vietas, un mēģina rekursīvi ievietot sadalīto daļu vecākmezglā, līdz tiek sasniegta sakne.
    ///
    ///
    /// Ja atgrieztais rezultāts ir `Fit`, tā roktura mezgls var būt šī edge mezgls vai sencis.
    /// Ja atgrieztais rezultāts ir `Split`, lauks `left` būs saknes mezgls.
    /// Atgrieztais rādītājs norāda uz ievietoto vērtību.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Atrod mezglu, uz kuru norāda šis edge.
    ///
    /// Metodes nosaukums pieņem, ka jūs attēlojat kokus ar saknes mezglu augšpusē.
    ///
    /// `edge.descend().ascend().unwrap()` Gan panākumiem, gan `node.ascend().unwrap().descend()` neko nedarīt.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Mezgliem mums jāizmanto neapstrādātas norādes, jo, ja BorrowType ir marker::ValMut, var būt izcilas maināmas atsauces uz vērtībām, kuras mēs nedrīkstam nederēt.
        // Piekļuve augstuma laukam neuztraucas, jo šī vērtība tiek kopēta.
        // Uzmanieties, ka pēc mezgla rādītāja novirzīšanas mēs piekļūstam malu masīvam ar atsauci (Rust jautājums #73987) un nederīgas citas atsauces uz masīvu vai tā iekšpusē, ja tādas būtu.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Mēs nevaram izsaukt atsevišķas atslēgu un vērtību metodes, jo, izsaucot otro, tiek nederīga pirmā atgrieztā atsauce.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Nomainiet atslēgu un vērtību, uz kuru attiecas KV rokturis.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Palīdz `split` ieviešanu konkrētam `NodeType`, rūpējoties par lapu datiem.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Sadala pamata mezglu trīs daļās:
    ///
    /// - Mezgls tiek saīsināts, lai tajā būtu tikai atslēgu un vērtību pāri pa kreisi no šī roktura.
    /// - Tiek izvilkta atslēga un vērtība, uz kuru norāda šis rokturis.
    /// - Visi atslēgu un vērtību pāri pa labi no šī roktura tiek ievietoti nesen piešķirtajā mezglā.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Noņem atslēgas vērtību pāri, uz kuru norāda šis rokturis, un atdod to kopā ar edge, kurā sabruka atslēgas vērtību pāris.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Sadala pamata mezglu trīs daļās:
    ///
    /// - Mezgls tiek saīsināts, lai saturētu tikai malas un atslēgu vērtību pārus pa kreisi no šī roktura.
    /// - Tiek izvilkta atslēga un vērtība, uz kuru norāda šis rokturis.
    /// - Visas malas un atslēgu vērtību pāri pa labi no šī roktura tiek ievietoti nesen piešķirtajā mezglā.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Pārstāv sesiju, lai novērtētu un veiktu balansēšanas operāciju ap iekšējo atslēgu un vērtību pāri.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Izvēlas līdzsvarojošu kontekstu, kurā mezgls ir iesaistīts kā bērns, tādējādi starp KV vecāku mezglā uzreiz pa kreisi vai pa labi.
    /// Atgriež `Err`, ja nav vecāku.
    /// Panics, ja vecāks ir tukšs.
    ///
    /// Dod priekšroku kreisajai pusei, lai tā būtu optimāla, ja dotais mezgls ir kaut kā nepilnīgs, šeit nozīmē tikai to, ka tajā ir mazāk elementu nekā kreisajam brālim un labajam brālim, ja tādi pastāv.
    /// Tādā gadījumā apvienošanās ar kreiso brāli ir ātrāka, jo mums jāpārvieto tikai mezgla N elementi, nevis jāpārvieto pa labi un jāpārvieto vairāk nekā N elementu priekšā.
    /// Zagšana no kreisā brāļa un māsas parasti ir arī ātrāka, jo mums tikai jāpārvieto mezgla N elementi pa labi, nevis jāpārvieto vismaz N no brāļa/māsas elementiem pa kreisi.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Atgriež, vai apvienošana ir iespējama, ti, vai mezglā ir pietiekami daudz vietas, lai centrālo KV apvienotu ar abiem blakus esošajiem bērnu mezgliem.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Veic apvienošanu un ļauj slēgšanai izlemt, ko atgriezt.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // DROŠĪBA: apvienojamo mezglu augstums ir viens zem augstuma
                // no šī edge mezgla, tādējādi virs nulles, tāpēc tie ir iekšēji.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Apvieno vecāku atslēgu un vērtību pāri un abus blakus esošos bērnu mezglus kreisajā bērna mezglā un atgriež sarukušo vecāku mezglu.
    ///
    ///
    /// Panics, ja vien mēs `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Apvieno vecāku atslēgu un vērtību pāri un abus blakus esošos bērna mezglus kreisajā bērna mezglā un atgriež šo bērna mezglu.
    ///
    ///
    /// Panics, ja vien mēs `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Apvieno vecāku atslēgas vērtību pāri un abus blakus esošos bērna mezglus kreisajā bērna mezglā un atgriež edge rokturi tajā bērna mezglā, kur nonāca izsekotais bērns edge,
    ///
    ///
    /// Panics, ja vien mēs `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// No kreisā bērna noņem atslēgas vērtību pāri un ievieto vecāku atslēgas vērtību krātuvē, vienlaikus veco vecāku atslēgu un vērtību pāri iestumjot pareizajā bērnā.
    ///
    /// Atgriež rokturi labajam bērnam edge atbilstoši tam, kur nonāca `track_right_edge_idx` norādītais sākotnējais edge.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Noņem labā bērna atslēgas vērtību pāri un ievieto vecāku atslēgas vērtību krātuvē, vienlaikus veco vecāku atslēgu un vērtību pāri uz kreiso bērnu.
    ///
    /// Atgriež rokturi `track_left_edge_idx` norādītajam kreisajam bērnam edge, kurš nekustējās.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Zādzība ir līdzīga `steal_left`, taču vienlaikus tiek nozagti vairāki elementi.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Pārliecinieties, ka mēs varam droši zagt.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Pārvietot lapu datus.
            {
                // Atbrīvojiet vietu pareizā bērna nozagtiem elementiem.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Pārvietojiet elementus no kreisā bērna uz labo.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Pārvietojiet pa kreisi visvairāk nozagto pāri vecākam.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Pārvietojiet vecāku atslēgu un vērtību pāri uz pareizo bērnu.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Atbrīvojiet vietu nozagtām malām.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Nozog malas.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Simetrisks `bulk_steal_left` klons.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Pārliecinieties, ka mēs varam droši zagt.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Pārvietot lapu datus.
            {
                // Pārvietojiet vecākam visvairāk zagto pāri.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Pārvietojiet vecāku atslēgu un vērtību pāri uz kreiso bērnu.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Pārvietojiet elementus no labā bērna uz kreiso.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Aizpildiet atstarpi, kur agrāk atradās nozagtie elementi.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Nozog malas.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Aizpildiet atstarpi vietā, kur agrāk bija nozagtas malas.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Noņem visu statisko informāciju, apgalvojot, ka šis mezgls ir `Leaf` mezgls.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Noņem visu statisko informāciju, apgalvojot, ka šis mezgls ir `Internal` mezgls.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Pārbauda, vai pamatā esošais mezgls ir `Internal` mezgls vai `Leaf` mezgls.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Pārvietojiet sufiksu pēc `self` no viena mezgla uz citu.`right` jābūt tukšam.
    /// `right` pirmais edge paliek nemainīgs.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Ievietošanas rezultāts, kad mezglam vajadzēja paplašināties, pārsniedzot tā ietilpību.
pub struct SplitResult<'a, K, V, NodeType> {
    // Mainīts mezgls esošajā kokā ar elementiem un malām, kas pieder pa kreisi no `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Daži atslēgas un vērtības sadalīti, kas jāievieto citur.
    pub kv: (K, V),
    // Īpašumā esošs, nepievienots jauns mezgls ar elementiem un malām, kas pieder `kv` pa labi.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Vai šī aizņēmuma veida mezglu atsauces ļauj pārvietoties uz citiem koka mezgliem.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Pārbrauciens nav nepieciešams, tas notiek, izmantojot `borrow_mut` rezultātu.
        // Atspējojot šķērsošanu un izveidojot tikai jaunas atsauces uz saknēm, mēs zinām, ka visas `Owned` tipa atsauces ir uz saknes mezglu.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Ievieto vērtību inicializētu elementu šķēlumā, kam seko viens neinicializēts elements.
///
/// # Safety
/// Šķēlē ir vairāk nekā `idx` elementi.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Noņem un atdod vērtību no visu inicializēto elementu daļas, atstājot aiz viena neinicializēta elementa.
///
///
/// # Safety
/// Šķēlē ir vairāk nekā `idx` elementi.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Pārvieto elementus šķēles `distance` pozīcijās pa kreisi.
///
/// # Safety
/// Šķēlē ir vismaz `distance` elementi.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Pārvieto elementus šķēles `distance` pozīcijās pa labi.
///
/// # Safety
/// Šķēlē ir vismaz `distance` elementi.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Visas vērtības tiek pārvietotas no inicializētu elementu šķēles uz neinicializētu elementu šķēli, atstājot aiz `src` kā visas neinicializētās.
///
/// Darbojas tāpat kā `dst.copy_from_slice(src)`, taču nav nepieciešams, lai `T` būtu `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;