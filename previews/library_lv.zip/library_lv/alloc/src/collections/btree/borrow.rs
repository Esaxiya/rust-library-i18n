use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modelē kādas unikālas atsauces aizņēmumu, kad jūs zināt, ka atdošana un visi tās pēcteči (ti, visi no tās izrietošie norādījumi un atsauces) kādā brīdī vairs netiks izmantoti, pēc kura vēlaties vēlreiz izmantot sākotnējo unikālo atsauci. .
///
///
/// Aizņēmumu pārbaudītājs parasti veic šo aizņēmumu sakraušanu jūsu vietā, taču dažas vadības plūsmas, kas veic šo sakraušanu, ir pārāk sarežģītas, lai kompilators to varētu sekot.
/// `DormantMutRef` ļauj jums pašiem pārbaudīt aizņemšanos, vienlaikus izsakot tā sakrautību, un iekapsulējot neapstrādātu rādītāja kodu, kas nepieciešams, lai to izdarītu bez noteiktas uzvedības.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Uztveriet unikālu aizņēmumu un nekavējoties to aizņemieties.
    /// Sastādītājam jaunās atsauces kalpošanas laiks ir tāds pats kā sākotnējās atsauces kalpošanas laiks, bet jūs promise to izmantot īsāku laiku.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // DROŠĪBA: mēs aizturējam aizņēmumu visā X caur `_marker`, un mēs pakļaujam
        // tikai šī atsauce, tāpēc tā ir unikāla.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Atgriezieties pie sākotnēji piesaistītā unikālā aizņēmuma.
    ///
    /// # Safety
    ///
    /// Aizņēmumam jābūt beidzies, ti, atsauci, ko atdeva `new`, un visas no tās iegūtās norādes un atsauces vairs nedrīkst izmantot.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // DROŠĪBA: mūsu pašu drošības apstākļi nozīmē, ka šī atsauce atkal ir unikāla.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;